"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.registerActionRoutes = registerActionRoutes;
var _configSchema = require("@osd/config-schema");
var _constants = require("../../common/constants");
var _graphClient = require("../lib/graph-client");
var fs = _interopRequireWildcard(require("fs"));
var path = _interopRequireWildcard(require("path"));
var _otp = require("../lib/otp");
function _getRequireWildcardCache(e) { if ("function" != typeof WeakMap) return null; var r = new WeakMap(), t = new WeakMap(); return (_getRequireWildcardCache = function (e) { return e ? t : r; })(e); }
function _interopRequireWildcard(e, r) { if (!r && e && e.__esModule) return e; if (null === e || "object" != typeof e && "function" != typeof e) return { default: e }; var t = _getRequireWildcardCache(r); if (t && t.has(e)) return t.get(e); var n = { __proto__: null }, a = Object.defineProperty && Object.getOwnPropertyDescriptor; for (var u in e) if ("default" !== u && {}.hasOwnProperty.call(e, u)) { var i = a ? Object.getOwnPropertyDescriptor(e, u) : null; i && (i.get || i.set) ? Object.defineProperty(n, u, i) : n[u] = e[u]; } return n.default = e, t && t.set(e, n), n; }
/*
 * Intune Plugin - Action routes.
 *
 * Calls Microsoft Graph API directly (no external action service).
 * Credentials from env: INTUNE_TENANT_ID, INTUNE_CLIENT_ID, INTUNE_CLIENT_SECRET
 * OTP/SMTP from env: SMTP_HOST, SMTP_PORT, SMTP_USER, SMTP_PASS, OTP_RECIPIENT_EMAIL
 */

function getUserFromRequest(req) {
  var _req$headers, _req$headers2;
  const user = ((_req$headers = req.headers) === null || _req$headers === void 0 ? void 0 : _req$headers['x-intune-user']) || 'dashboard-user';
  const role = ((_req$headers2 = req.headers) === null || _req$headers2 === void 0 ? void 0 : _req$headers2['x-intune-role']) || 'intune_operator';
  return {
    user,
    role
  };
}
function getOTPConfig() {
  return {
    smtpHost: process.env.SMTP_HOST,
    smtpPort: process.env.SMTP_PORT ? parseInt(process.env.SMTP_PORT, 10) : 587,
    smtpUser: process.env.SMTP_USER,
    smtpPass: process.env.SMTP_PASS,
    otpRecipientEmail: process.env.OTP_RECIPIENT_EMAIL,
    smtpSecure: process.env.SMTP_SECURE === 'true'
  };
}
async function writeAuditLog(client, entry) {
  try {
    await client.index({
      index: _constants.INTUNE_AUDIT_LOG_INDEX,
      body: {
        ...entry,
        timestamp: new Date().toISOString()
      }
    });
  } catch (err) {
    console.error('[Intune] Audit log write failed:', err);
  }
}
function makeActionHandler(router, path, actionName, bodySchema, fn) {
  router.post({
    path,
    validate: {
      body: bodySchema
    }
  }, async (context, req, res) => {
    const config = (0, _graphClient.getGraphConfig)();
    if (!config) {
      return res.customError({
        statusCode: 503,
        body: 'Intune credentials not configured. Set INTUNE_TENANT_ID, INTUNE_CLIENT_ID, INTUNE_CLIENT_SECRET.'
      });
    }
    const {
      user
    } = getUserFromRequest(req);
    const client = context.core.opensearch.client.asCurrentUser;
    const deviceId = req.body.intune_device_id;
    const deviceName = req.body.device_name || '';
    try {
      var _headers, _info;
      const result = await fn(config, req.body, user);
      await writeAuditLog(client, {
        action: actionName,
        intune_device_id: deviceId || '',
        device_name: deviceName,
        performed_by: user,
        role: ((_headers = req.headers) === null || _headers === void 0 ? void 0 : _headers['x-intune-role']) || 'intune_operator',
        status: 'success',
        message: result.message,
        source_ip: (_info = req.info) === null || _info === void 0 ? void 0 : _info.remoteAddress
      });
      return res.ok({
        body: {
          ...result,
          action: actionName,
          intune_device_id: deviceId,
          timestamp: new Date().toISOString()
        }
      });
    } catch (err) {
      var _headers2, _err$message, _info2, _response, _err$message2;
      await writeAuditLog(client, {
        action: actionName,
        intune_device_id: deviceId || '',
        device_name: deviceName,
        performed_by: user,
        role: ((_headers2 = req.headers) === null || _headers2 === void 0 ? void 0 : _headers2['x-intune-role']) || 'intune_operator',
        status: 'failure',
        message: (_err$message = err === null || err === void 0 ? void 0 : err.message) !== null && _err$message !== void 0 ? _err$message : String(err),
        source_ip: (_info2 = req.info) === null || _info2 === void 0 ? void 0 : _info2.remoteAddress
      });
      const status = (err === null || err === void 0 || (_response = err.response) === null || _response === void 0 ? void 0 : _response.status) || 500;
      return res.customError({
        statusCode: status,
        body: (_err$message2 = err === null || err === void 0 ? void 0 : err.message) !== null && _err$message2 !== void 0 ? _err$message2 : String(err)
      });
    }
  });
}
function registerActionRoutes(router) {
  const deviceBody = _configSchema.schema.object({
    intune_device_id: _configSchema.schema.string(),
    device_name: _configSchema.schema.maybe(_configSchema.schema.string())
  });
  makeActionHandler(router, '/api/intune_plugin/actions/sync-device', 'sync_device', deviceBody, (c, b) => (0, _graphClient.syncDevice)(c, b.intune_device_id));
  makeActionHandler(router, '/api/intune_plugin/actions/remote-lock', 'remote_lock', deviceBody, (c, b) => (0, _graphClient.remoteLock)(c, b.intune_device_id));
  makeActionHandler(router, '/api/intune_plugin/actions/reset-passcode', 'reset_passcode', deviceBody, (c, b) => (0, _graphClient.resetPasscode)(c, b.intune_device_id));
  makeActionHandler(router, '/api/intune_plugin/actions/reboot-device', 'reboot_device', deviceBody, (c, b) => (0, _graphClient.rebootDevice)(c, b.intune_device_id));
  makeActionHandler(router, '/api/intune_plugin/actions/shutdown-device', 'shutdown_device', deviceBody, (c, b) => (0, _graphClient.shutDownDevice)(c, b.intune_device_id));
  makeActionHandler(router, '/api/intune_plugin/actions/update-defender-signatures', 'update_defender_signatures', deviceBody, (c, b) => (0, _graphClient.updateDefenderSignatures)(c, b.intune_device_id));
  makeActionHandler(router, '/api/intune_plugin/actions/collect-diagnostics', 'collect_diagnostics', deviceBody, (c, b) => (0, _graphClient.collectDiagnostics)(c, b.intune_device_id));
  makeActionHandler(router, '/api/intune_plugin/actions/rotate-bitlocker', 'rotate_bitlocker', deviceBody, (c, b) => (0, _graphClient.rotateBitLockerKeys)(c, b.intune_device_id));
  router.post({
    path: '/api/intune_plugin/actions/defender-scan',
    validate: {
      body: _configSchema.schema.object({
        intune_device_id: _configSchema.schema.string(),
        device_name: _configSchema.schema.maybe(_configSchema.schema.string()),
        quick_scan: _configSchema.schema.maybe(_configSchema.schema.boolean())
      })
    }
  }, async (context, req, res) => {
    const config = (0, _graphClient.getGraphConfig)();
    if (!config) {
      return res.customError({
        statusCode: 503,
        body: 'Intune credentials not configured.'
      });
    }
    const {
      user
    } = getUserFromRequest(req);
    const {
      intune_device_id,
      device_name,
      quick_scan = true
    } = req.body;
    const client = context.core.opensearch.client.asCurrentUser;
    try {
      var _headers3, _info3;
      const result = await (0, _graphClient.defenderScan)(config, intune_device_id, quick_scan);
      await writeAuditLog(client, {
        action: 'defender_scan',
        intune_device_id,
        device_name: device_name || '',
        performed_by: user,
        role: ((_headers3 = req.headers) === null || _headers3 === void 0 ? void 0 : _headers3['x-intune-role']) || 'intune_operator',
        status: 'success',
        message: result.message,
        source_ip: (_info3 = req.info) === null || _info3 === void 0 ? void 0 : _info3.remoteAddress
      });
      return res.ok({
        body: {
          ...result,
          action: 'defender_scan',
          intune_device_id,
          timestamp: new Date().toISOString()
        }
      });
    } catch (err) {
      var _headers4, _err$message3, _info4, _err$response, _err$message4;
      await writeAuditLog(client, {
        action: 'defender_scan',
        intune_device_id,
        device_name: device_name || '',
        performed_by: user,
        role: ((_headers4 = req.headers) === null || _headers4 === void 0 ? void 0 : _headers4['x-intune-role']) || 'intune_operator',
        status: 'failure',
        message: (_err$message3 = err === null || err === void 0 ? void 0 : err.message) !== null && _err$message3 !== void 0 ? _err$message3 : String(err),
        source_ip: (_info4 = req.info) === null || _info4 === void 0 ? void 0 : _info4.remoteAddress
      });
      return res.customError({
        statusCode: (err === null || err === void 0 || (_err$response = err.response) === null || _err$response === void 0 ? void 0 : _err$response.status) || 500,
        body: (_err$message4 = err === null || err === void 0 ? void 0 : err.message) !== null && _err$message4 !== void 0 ? _err$message4 : String(err)
      });
    }
  });
  router.post({
    path: '/api/intune_plugin/actions/mark-remediation',
    validate: {
      body: deviceBody
    }
  }, async (context, req, res) => {
    const config = (0, _graphClient.getGraphConfig)();
    if (!config) {
      return res.customError({
        statusCode: 503,
        body: 'Intune credentials not configured.'
      });
    }
    const {
      user
    } = getUserFromRequest(req);
    const {
      intune_device_id,
      device_name
    } = req.body;
    const client = context.core.opensearch.client.asCurrentUser;
    try {
      var _headers5, _info5;
      const result = await (0, _graphClient.markRemediation)(config, intune_device_id, user);
      try {
        await client.update({
          index: _constants.INTUNE_DEVICES_INDEX,
          id: intune_device_id,
          body: {
            doc: {
              needs_remediation: true,
              remediation_flagged_by: user,
              remediation_flagged_at: new Date().toISOString()
            }
          }
        });
      } catch {
        // Index update optional
      }
      await writeAuditLog(client, {
        action: 'mark_remediation',
        intune_device_id,
        device_name: device_name || '',
        performed_by: user,
        role: ((_headers5 = req.headers) === null || _headers5 === void 0 ? void 0 : _headers5['x-intune-role']) || 'intune_operator',
        status: 'success',
        message: result.message,
        source_ip: (_info5 = req.info) === null || _info5 === void 0 ? void 0 : _info5.remoteAddress
      });
      return res.ok({
        body: {
          ...result,
          action: 'mark_remediation',
          intune_device_id,
          timestamp: new Date().toISOString()
        }
      });
    } catch (err) {
      var _headers6, _err$message5, _info6, _err$response2, _err$message6;
      await writeAuditLog(client, {
        action: 'mark_remediation',
        intune_device_id,
        device_name: device_name || '',
        performed_by: user,
        role: ((_headers6 = req.headers) === null || _headers6 === void 0 ? void 0 : _headers6['x-intune-role']) || 'intune_operator',
        status: 'failure',
        message: (_err$message5 = err === null || err === void 0 ? void 0 : err.message) !== null && _err$message5 !== void 0 ? _err$message5 : String(err),
        source_ip: (_info6 = req.info) === null || _info6 === void 0 ? void 0 : _info6.remoteAddress
      });
      return res.customError({
        statusCode: (err === null || err === void 0 || (_err$response2 = err.response) === null || _err$response2 === void 0 ? void 0 : _err$response2.status) || 500,
        body: (_err$message6 = err === null || err === void 0 ? void 0 : err.message) !== null && _err$message6 !== void 0 ? _err$message6 : String(err)
      });
    }
  });
  router.post({
    path: '/api/intune_plugin/actions/assign-script',
    validate: {
      body: _configSchema.schema.object({
        script_id: _configSchema.schema.string(),
        script_type: _configSchema.schema.maybe(_configSchema.schema.string()),
        group_id: _configSchema.schema.maybe(_configSchema.schema.string())
      })
    }
  }, async (context, req, res) => {
    const config = (0, _graphClient.getGraphConfig)();
    if (!config) {
      return res.customError({
        statusCode: 503,
        body: 'Intune credentials not configured.'
      });
    }
    const {
      user
    } = getUserFromRequest(req);
    const {
      script_id,
      script_type = 'powershell',
      group_id = 'all'
    } = req.body;
    const client = context.core.opensearch.client.asCurrentUser;
    try {
      var _headers7, _info7;
      const result = await (0, _graphClient.assignScript)(config, script_id, script_type, group_id);
      await writeAuditLog(client, {
        action: 'assign_script',
        intune_device_id: script_id,
        device_name: '',
        performed_by: user,
        role: ((_headers7 = req.headers) === null || _headers7 === void 0 ? void 0 : _headers7['x-intune-role']) || 'intune_operator',
        status: 'success',
        message: result.message,
        source_ip: (_info7 = req.info) === null || _info7 === void 0 ? void 0 : _info7.remoteAddress
      });
      return res.ok({
        body: {
          ...result,
          action: 'assign_script',
          script_id,
          timestamp: new Date().toISOString()
        }
      });
    } catch (err) {
      var _err$response3, _err$message7;
      return res.customError({
        statusCode: (err === null || err === void 0 || (_err$response3 = err.response) === null || _err$response3 === void 0 ? void 0 : _err$response3.status) || 500,
        body: (_err$message7 = err === null || err === void 0 ? void 0 : err.message) !== null && _err$message7 !== void 0 ? _err$message7 : String(err)
      });
    }
  });
  router.post({
    path: '/api/intune_plugin/actions/assign-app',
    validate: {
      body: _configSchema.schema.object({
        app_id: _configSchema.schema.string(),
        group_id: _configSchema.schema.maybe(_configSchema.schema.string()),
        intent: _configSchema.schema.maybe(_configSchema.schema.string())
      })
    }
  }, async (context, req, res) => {
    const config = (0, _graphClient.getGraphConfig)();
    if (!config) {
      return res.customError({
        statusCode: 503,
        body: 'Intune credentials not configured.'
      });
    }
    const {
      user
    } = getUserFromRequest(req);
    const {
      app_id,
      group_id = 'all',
      intent = 'required'
    } = req.body;
    const client = context.core.opensearch.client.asCurrentUser;
    try {
      var _headers8, _info8;
      const result = await (0, _graphClient.assignApp)(config, app_id, group_id, intent);
      await writeAuditLog(client, {
        action: 'assign_app',
        intune_device_id: app_id,
        device_name: '',
        performed_by: user,
        role: ((_headers8 = req.headers) === null || _headers8 === void 0 ? void 0 : _headers8['x-intune-role']) || 'intune_operator',
        status: 'success',
        message: result.message,
        source_ip: (_info8 = req.info) === null || _info8 === void 0 ? void 0 : _info8.remoteAddress
      });
      return res.ok({
        body: {
          ...result,
          action: 'assign_app',
          app_id,
          timestamp: new Date().toISOString()
        }
      });
    } catch (err) {
      var _err$response4, _err$message8;
      return res.customError({
        statusCode: (err === null || err === void 0 || (_err$response4 = err.response) === null || _err$response4 === void 0 ? void 0 : _err$response4.status) || 500,
        body: (_err$message8 = err === null || err === void 0 ? void 0 : err.message) !== null && _err$message8 !== void 0 ? _err$message8 : String(err)
      });
    }
  });
  router.get({
    path: '/api/intune_plugin/actions/conditional-access/{id}',
    validate: {
      params: _configSchema.schema.object({
        id: _configSchema.schema.string()
      })
    }
  }, async (context, req, res) => {
    const config = (0, _graphClient.getGraphConfig)();
    if (!config) {
      return res.customError({
        statusCode: 503,
        body: 'Intune credentials not configured.'
      });
    }
    const {
      user
    } = getUserFromRequest(req);
    const id = req.params.id;
    const client = context.core.opensearch.client.asCurrentUser;
    try {
      var _result$data, _headers9, _info9;
      const result = await (0, _graphClient.getConditionalAccessStatus)(config, id);
      await writeAuditLog(client, {
        action: 'view_conditional_access',
        intune_device_id: id,
        device_name: ((_result$data = result.data) === null || _result$data === void 0 || (_result$data = _result$data.device) === null || _result$data === void 0 ? void 0 : _result$data.deviceName) || '',
        performed_by: user,
        role: ((_headers9 = req.headers) === null || _headers9 === void 0 ? void 0 : _headers9['x-intune-role']) || 'intune_operator',
        status: 'success',
        message: result.message,
        source_ip: (_info9 = req.info) === null || _info9 === void 0 ? void 0 : _info9.remoteAddress
      });
      return res.ok({
        body: {
          ...result,
          action: 'view_conditional_access',
          intune_device_id: id,
          timestamp: new Date().toISOString()
        }
      });
    } catch (err) {
      var _err$response5, _err$message9;
      return res.customError({
        statusCode: (err === null || err === void 0 || (_err$response5 = err.response) === null || _err$response5 === void 0 ? void 0 : _err$response5.status) || 500,
        body: (_err$message9 = err === null || err === void 0 ? void 0 : err.message) !== null && _err$message9 !== void 0 ? _err$message9 : String(err)
      });
    }
  });

  // Map frontend action names to OTP keys (frontend sends 'retire'|'wipe'|'factory_reset')
  const VALID_OTP_ACTIONS = ['retire', 'wipe', 'factory_reset'];

  // ── OTP: Request ─────────────────────────────────────────────
  router.post({
    path: '/api/intune_plugin/actions/request-otp',
    validate: {
      body: _configSchema.schema.object({
        intune_device_id: _configSchema.schema.string(),
        device_name: _configSchema.schema.maybe(_configSchema.schema.string()),
        action: _configSchema.schema.string()
      })
    }
  }, async (context, req, res) => {
    const {
      intune_device_id,
      device_name,
      action
    } = req.body;
    const otpAction = VALID_OTP_ACTIONS.includes(action) ? action : null;
    if (!intune_device_id || !otpAction) {
      return res.badRequest({
        body: {
          success: false,
          message: `action must be one of: ${VALID_OTP_ACTIONS.join(', ')}`
        }
      });
    }
    const otp = (0, _otp.generateOTP)();
    (0, _otp.storeOTP)(intune_device_id, otpAction, otp);
    const emailResult = await (0, _otp.sendOTPEmail)(getOTPConfig(), otp, device_name || intune_device_id, otpAction);
    return res.ok({
      body: {
        success: true,
        message: emailResult.devMode ? 'DEV MODE: OTP logged to server console (SMTP not configured)' : `OTP sent to ${emailResult.recipient}`,
        dev_mode: emailResult.devMode || false,
        ...(emailResult.devMode ? {
          otp
        } : {})
      }
    });
  });

  // ── DESTRUCTIVE: Retire ──────────────────────────────────────
  router.post({
    path: '/api/intune_plugin/actions/retire-device',
    validate: {
      body: _configSchema.schema.object({
        intune_device_id: _configSchema.schema.string(),
        device_name: _configSchema.schema.maybe(_configSchema.schema.string()),
        otp: _configSchema.schema.string()
      })
    }
  }, async (context, req, res) => {
    const config = (0, _graphClient.getGraphConfig)();
    if (!config) {
      return res.customError({
        statusCode: 503,
        body: 'Intune credentials not configured.'
      });
    }
    const {
      user
    } = getUserFromRequest(req);
    const {
      intune_device_id,
      device_name,
      otp
    } = req.body;
    const validation = (0, _otp.validateOTP)(intune_device_id, 'retire', otp);
    if (!validation.valid) {
      return res.forbidden({
        body: {
          success: false,
          message: validation.reason
        }
      });
    }
    const client = context.core.opensearch.client.asCurrentUser;
    try {
      var _headers10, _info10;
      const result = await (0, _graphClient.retireDevice)(config, intune_device_id);
      await writeAuditLog(client, {
        action: 'retire_device',
        intune_device_id,
        device_name: device_name || '',
        performed_by: user,
        role: ((_headers10 = req.headers) === null || _headers10 === void 0 ? void 0 : _headers10['x-intune-role']) || 'intune_operator',
        status: 'success',
        message: result.message,
        source_ip: (_info10 = req.info) === null || _info10 === void 0 ? void 0 : _info10.remoteAddress
      });
      return res.ok({
        body: {
          ...result,
          action: 'retire_device',
          intune_device_id,
          timestamp: new Date().toISOString()
        }
      });
    } catch (err) {
      var _err$response6, _err$message10;
      return res.customError({
        statusCode: (err === null || err === void 0 || (_err$response6 = err.response) === null || _err$response6 === void 0 ? void 0 : _err$response6.status) || 500,
        body: (_err$message10 = err === null || err === void 0 ? void 0 : err.message) !== null && _err$message10 !== void 0 ? _err$message10 : String(err)
      });
    }
  });
  router.post({
    path: '/api/intune_plugin/actions/wipe-device',
    validate: {
      body: _configSchema.schema.object({
        intune_device_id: _configSchema.schema.string(),
        device_name: _configSchema.schema.maybe(_configSchema.schema.string()),
        otp: _configSchema.schema.string(),
        keep_enrollment_data: _configSchema.schema.maybe(_configSchema.schema.boolean()),
        keep_user_data: _configSchema.schema.maybe(_configSchema.schema.boolean())
      })
    }
  }, async (context, req, res) => {
    const config = (0, _graphClient.getGraphConfig)();
    if (!config) {
      return res.customError({
        statusCode: 503,
        body: 'Intune credentials not configured.'
      });
    }
    const {
      user
    } = getUserFromRequest(req);
    const {
      intune_device_id,
      device_name,
      otp,
      keep_enrollment_data,
      keep_user_data
    } = req.body;
    const validation = (0, _otp.validateOTP)(intune_device_id, 'wipe', otp);
    if (!validation.valid) {
      return res.forbidden({
        body: {
          success: false,
          message: validation.reason
        }
      });
    }
    const client = context.core.opensearch.client.asCurrentUser;
    try {
      var _headers11, _info11;
      const result = await (0, _graphClient.wipeDevice)(config, intune_device_id, keep_enrollment_data, keep_user_data);
      await writeAuditLog(client, {
        action: 'wipe_device',
        intune_device_id,
        device_name: device_name || '',
        performed_by: user,
        role: ((_headers11 = req.headers) === null || _headers11 === void 0 ? void 0 : _headers11['x-intune-role']) || 'intune_operator',
        status: 'success',
        message: result.message,
        source_ip: (_info11 = req.info) === null || _info11 === void 0 ? void 0 : _info11.remoteAddress
      });
      return res.ok({
        body: {
          ...result,
          action: 'wipe_device',
          intune_device_id,
          timestamp: new Date().toISOString()
        }
      });
    } catch (err) {
      var _err$response7, _err$message11;
      return res.customError({
        statusCode: (err === null || err === void 0 || (_err$response7 = err.response) === null || _err$response7 === void 0 ? void 0 : _err$response7.status) || 500,
        body: (_err$message11 = err === null || err === void 0 ? void 0 : err.message) !== null && _err$message11 !== void 0 ? _err$message11 : String(err)
      });
    }
  });
  router.post({
    path: '/api/intune_plugin/actions/factory-reset',
    validate: {
      body: _configSchema.schema.object({
        intune_device_id: _configSchema.schema.string(),
        device_name: _configSchema.schema.maybe(_configSchema.schema.string()),
        otp: _configSchema.schema.string()
      })
    }
  }, async (context, req, res) => {
    const config = (0, _graphClient.getGraphConfig)();
    if (!config) {
      return res.customError({
        statusCode: 503,
        body: 'Intune credentials not configured.'
      });
    }
    const {
      user
    } = getUserFromRequest(req);
    const {
      intune_device_id,
      device_name,
      otp
    } = req.body;
    const validation = (0, _otp.validateOTP)(intune_device_id, 'factory_reset', otp);
    if (!validation.valid) {
      return res.forbidden({
        body: {
          success: false,
          message: validation.reason
        }
      });
    }
    const client = context.core.opensearch.client.asCurrentUser;
    try {
      var _headers12, _info12;
      const result = await (0, _graphClient.factoryResetDevice)(config, intune_device_id);
      await writeAuditLog(client, {
        action: 'factory_reset',
        intune_device_id,
        device_name: device_name || '',
        performed_by: user,
        role: ((_headers12 = req.headers) === null || _headers12 === void 0 ? void 0 : _headers12['x-intune-role']) || 'intune_operator',
        status: 'success',
        message: result.message,
        source_ip: (_info12 = req.info) === null || _info12 === void 0 ? void 0 : _info12.remoteAddress
      });
      return res.ok({
        body: {
          ...result,
          action: 'factory_reset',
          intune_device_id,
          timestamp: new Date().toISOString()
        }
      });
    } catch (err) {
      var _err$response8, _err$message12;
      return res.customError({
        statusCode: (err === null || err === void 0 || (_err$response8 = err.response) === null || _err$response8 === void 0 ? void 0 : _err$response8.status) || 500,
        body: (_err$message12 = err === null || err === void 0 ? void 0 : err.message) !== null && _err$message12 !== void 0 ? _err$message12 : String(err)
      });
    }
  });

  // ── Audit log (GET) ──────────────────────────────────────────
  router.get({
    path: '/api/intune_plugin/actions/audit-log',
    validate: {
      query: _configSchema.schema.object({
        size: _configSchema.schema.maybe(_configSchema.schema.string())
      })
    }
  }, async (context, req, res) => {
    try {
      var _hits$hits, _response$body;
      const client = context.core.opensearch.client.asCurrentUser;
      const size = Math.min(500, parseInt(req.query.size || '50', 10) || 50);
      const response = await client.search({
        index: _constants.INTUNE_AUDIT_LOG_INDEX,
        ignore_unavailable: true,
        body: {
          size,
          sort: [{
            timestamp: {
              order: 'desc',
              missing: '_last'
            }
          }],
          query: {
            match_all: {}
          }
        }
      });
      const hits = (_hits$hits = (_response$body = response.body) === null || _response$body === void 0 || (_response$body = _response$body.hits) === null || _response$body === void 0 ? void 0 : _response$body.hits) !== null && _hits$hits !== void 0 ? _hits$hits : [];
      const logs = hits.map(h => h._source).filter(Boolean);
      return res.ok({
        body: {
          success: true,
          logs,
          total: logs.length
        }
      });
    } catch (err) {
      var _err$message13;
      return res.customError({
        statusCode: 500,
        body: (_err$message13 = err === null || err === void 0 ? void 0 : err.message) !== null && _err$message13 !== void 0 ? _err$message13 : String(err)
      });
    }
  });

  // ── Wazuh Agent Deployment ────────────────────────────────────
  router.post({
    path: '/api/intune_plugin/actions/deploy-wazuh',
    validate: {
      body: _configSchema.schema.object({
        platform: _configSchema.schema.oneOf([_configSchema.schema.literal('windows'), _configSchema.schema.literal('macos')]),
        api_endpoint: _configSchema.schema.string(),
        api_username: _configSchema.schema.string(),
        api_password: _configSchema.schema.string(),
        enable_yara: _configSchema.schema.boolean(),
        target: _configSchema.schema.oneOf([_configSchema.schema.literal('all'), _configSchema.schema.literal('selected')]),
        device_ids: _configSchema.schema.maybe(_configSchema.schema.arrayOf(_configSchema.schema.string()))
      })
    }
  }, async (context, req, res) => {
    const config = (0, _graphClient.getGraphConfig)();
    if (!config) {
      return res.customError({
        statusCode: 503,
        body: 'Intune credentials not configured.'
      });
    }
    const {
      user
    } = getUserFromRequest(req);
    const client = context.core.opensearch.client.asCurrentUser;
    const {
      platform,
      api_endpoint,
      api_username,
      api_password,
      enable_yara,
      target,
      device_ids
    } = req.body;
    try {
      var _device_ids$length, _headers13;
      // 1. Read the template script (public/assets/ relative to plugin root)
      const templateDir = path.resolve(__dirname, '..', '..', 'public', 'assets');
      const templateFile = platform === 'windows' ? 'wazuh-deploy-windows.ps1.template' : 'wazuh-deploy-macos.sh.template';
      const templatePath = path.join(templateDir, templateFile);
      if (!fs.existsSync(templatePath)) {
        return res.customError({
          statusCode: 500,
          body: `Template not found: ${templateFile}`
        });
      }
      let scriptContent = fs.readFileSync(templatePath, 'utf-8');

      // 2. Patch the script with user's config
      if (platform === 'windows') {
        scriptContent = scriptContent.replace(/\$API_ENDPOINT\s*=\s*"[^"]*"/, `$API_ENDPOINT = "${api_endpoint}"`);
        scriptContent = scriptContent.replace(/\$API_USERNAME\s*=\s*"[^"]*"/, `$API_USERNAME = "${api_username}"`);
        // Set defaults for silent Intune execution
        scriptContent = scriptContent.replace(/param\(\s*\n\s*\[string\]\$ApiPassword\s*=\s*""/, `param(\n    [string]$ApiPassword = "${api_password}"`);
        scriptContent = scriptContent.replace(/\[string\]\$AgentName\s*=\s*""/, `[string]$AgentName = "$env:COMPUTERNAME"`);
        scriptContent = scriptContent.replace(/\[string\]\$ExistingAgentAction\s*=\s*"ask"/, `[string]$ExistingAgentAction = "replace"`);
      } else {
        // macOS shell
        scriptContent = scriptContent.replace(/API_ENDPOINT="[^"]*"/, `API_ENDPOINT="${api_endpoint}"`);
        scriptContent = scriptContent.replace(/API_USERNAME="[^"]*"/, `API_USERNAME="${api_username}"`);
        scriptContent = scriptContent.replace(/API_PASSWORD=""/, `API_PASSWORD="${api_password}"`);
        // Patch defaults for non-interactive execution
        scriptContent = scriptContent.replace(/agentName=""/g, 'agentName="$(hostname -s)"');
        scriptContent = scriptContent.replace(/existingAgentAction="ask"/, 'existingAgentAction="replace"');
        if (!enable_yara) {
          scriptContent = scriptContent.replace(/enableYara="yes"/, 'enableYara="no"');
        }
      }

      // 3. Base64 encode
      const scriptBase64 = Buffer.from(scriptContent, 'utf-8').toString('base64');
      const ts = new Date().toISOString().replace(/[:.]/g, '-').slice(0, 19);
      const displayName = `Athena Wazuh Agent - ${platform} - ${ts}`;
      const description = `Wazuh agent deployment for ${platform}. Created by Athena Intune plugin on ${new Date().toISOString()}.`;

      // 4. Upload to Intune
      let scriptResult;
      if (platform === 'windows') {
        scriptResult = await (0, _graphClient.uploadPowerShellScript)(config, displayName, scriptBase64, description);
      } else {
        scriptResult = await (0, _graphClient.uploadShellScript)(config, displayName, scriptBase64, description);
      }

      // 5. Assign to target
      let groupId = 'all';
      let groupName = 'All Devices';
      if (target === 'selected' && device_ids && device_ids.length > 0) {
        try {
          const resolved = await (0, _graphClient.resolveAzureAdDeviceObjectIds)(config, device_ids);
          if (resolved.length === 0) {
            return res.customError({
              statusCode: 400,
              body: 'Could not resolve any selected devices to Azure AD objects. Ensure devices are Azure AD joined.'
            });
          }
          groupName = `Athena Wazuh Deploy ${platform} ${ts}`;
          groupId = await (0, _graphClient.createSecurityGroup)(config, groupName);
          await (0, _graphClient.addDevicesToGroup)(config, groupId, resolved.map(d => d.azureAdObjectId));
        } catch (groupErr) {
          var _groupErr$message, _groupErr$message2, _groupErr$message3;
          if ((_groupErr$message = groupErr.message) !== null && _groupErr$message !== void 0 && _groupErr$message.includes('Authorization') || (_groupErr$message2 = groupErr.message) !== null && _groupErr$message2 !== void 0 && _groupErr$message2.includes('Forbidden') || (_groupErr$message3 = groupErr.message) !== null && _groupErr$message3 !== void 0 && _groupErr$message3.includes('Insufficient privileges')) {
            return res.customError({
              statusCode: 403,
              body: 'Group.ReadWrite.All permission is required for per-device targeting. Use "All Devices" instead, or add the permission to your Azure AD app.'
            });
          }
          throw groupErr;
        }
      }
      const scriptType = platform === 'windows' ? 'powershell' : 'shell';
      await (0, _graphClient.assignScript)(config, scriptResult.id, scriptType, groupId);

      // 6. Audit log
      await writeAuditLog(client, {
        action: 'deploy_wazuh_agent',
        intune_device_id: '',
        device_name: `${platform} (${target === 'all' ? 'all devices' : `${(_device_ids$length = device_ids === null || device_ids === void 0 ? void 0 : device_ids.length) !== null && _device_ids$length !== void 0 ? _device_ids$length : 0} selected`})`,
        performed_by: user,
        role: ((_headers13 = req.headers) === null || _headers13 === void 0 ? void 0 : _headers13['x-intune-role']) || 'intune_operator',
        status: 'success',
        message: `Wazuh agent script uploaded and assigned: ${scriptResult.displayName} → ${groupName}`
      });
      return res.ok({
        body: {
          success: true,
          action: 'deploy_wazuh_agent',
          script_id: scriptResult.id,
          script_name: scriptResult.displayName,
          assigned_to: groupName,
          platform,
          timestamp: new Date().toISOString(),
          message: `Wazuh agent deployment script uploaded to Intune and assigned to ${groupName}. Devices will receive the script on their next check-in.`
        }
      });
    } catch (err) {
      var _headers14, _err$message14, _err$response9, _err$message15;
      await writeAuditLog(client, {
        action: 'deploy_wazuh_agent',
        intune_device_id: '',
        device_name: `${platform} (${target})`,
        performed_by: user,
        role: ((_headers14 = req.headers) === null || _headers14 === void 0 ? void 0 : _headers14['x-intune-role']) || 'intune_operator',
        status: 'failure',
        message: (_err$message14 = err === null || err === void 0 ? void 0 : err.message) !== null && _err$message14 !== void 0 ? _err$message14 : String(err)
      });
      return res.customError({
        statusCode: (err === null || err === void 0 || (_err$response9 = err.response) === null || _err$response9 === void 0 ? void 0 : _err$response9.status) || 500,
        body: (_err$message15 = err === null || err === void 0 ? void 0 : err.message) !== null && _err$message15 !== void 0 ? _err$message15 : String(err)
      });
    }
  });
}
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfY29uZmlnU2NoZW1hIiwicmVxdWlyZSIsIl9jb25zdGFudHMiLCJfZ3JhcGhDbGllbnQiLCJmcyIsIl9pbnRlcm9wUmVxdWlyZVdpbGRjYXJkIiwicGF0aCIsIl9vdHAiLCJfZ2V0UmVxdWlyZVdpbGRjYXJkQ2FjaGUiLCJlIiwiV2Vha01hcCIsInIiLCJ0IiwiX19lc01vZHVsZSIsImRlZmF1bHQiLCJoYXMiLCJnZXQiLCJuIiwiX19wcm90b19fIiwiYSIsIk9iamVjdCIsImRlZmluZVByb3BlcnR5IiwiZ2V0T3duUHJvcGVydHlEZXNjcmlwdG9yIiwidSIsImhhc093blByb3BlcnR5IiwiY2FsbCIsImkiLCJzZXQiLCJnZXRVc2VyRnJvbVJlcXVlc3QiLCJyZXEiLCJfcmVxJGhlYWRlcnMiLCJfcmVxJGhlYWRlcnMyIiwidXNlciIsImhlYWRlcnMiLCJyb2xlIiwiZ2V0T1RQQ29uZmlnIiwic210cEhvc3QiLCJwcm9jZXNzIiwiZW52IiwiU01UUF9IT1NUIiwic210cFBvcnQiLCJTTVRQX1BPUlQiLCJwYXJzZUludCIsInNtdHBVc2VyIiwiU01UUF9VU0VSIiwic210cFBhc3MiLCJTTVRQX1BBU1MiLCJvdHBSZWNpcGllbnRFbWFpbCIsIk9UUF9SRUNJUElFTlRfRU1BSUwiLCJzbXRwU2VjdXJlIiwiU01UUF9TRUNVUkUiLCJ3cml0ZUF1ZGl0TG9nIiwiY2xpZW50IiwiZW50cnkiLCJpbmRleCIsIklOVFVORV9BVURJVF9MT0dfSU5ERVgiLCJib2R5IiwidGltZXN0YW1wIiwiRGF0ZSIsInRvSVNPU3RyaW5nIiwiZXJyIiwiY29uc29sZSIsImVycm9yIiwibWFrZUFjdGlvbkhhbmRsZXIiLCJyb3V0ZXIiLCJhY3Rpb25OYW1lIiwiYm9keVNjaGVtYSIsImZuIiwicG9zdCIsInZhbGlkYXRlIiwiY29udGV4dCIsInJlcyIsImNvbmZpZyIsImdldEdyYXBoQ29uZmlnIiwiY3VzdG9tRXJyb3IiLCJzdGF0dXNDb2RlIiwiY29yZSIsIm9wZW5zZWFyY2giLCJhc0N1cnJlbnRVc2VyIiwiZGV2aWNlSWQiLCJpbnR1bmVfZGV2aWNlX2lkIiwiZGV2aWNlTmFtZSIsImRldmljZV9uYW1lIiwiX2hlYWRlcnMiLCJfaW5mbyIsInJlc3VsdCIsImFjdGlvbiIsInBlcmZvcm1lZF9ieSIsInN0YXR1cyIsIm1lc3NhZ2UiLCJzb3VyY2VfaXAiLCJpbmZvIiwicmVtb3RlQWRkcmVzcyIsIm9rIiwiX2hlYWRlcnMyIiwiX2VyciRtZXNzYWdlIiwiX2luZm8yIiwiX3Jlc3BvbnNlIiwiX2VyciRtZXNzYWdlMiIsIlN0cmluZyIsInJlc3BvbnNlIiwicmVnaXN0ZXJBY3Rpb25Sb3V0ZXMiLCJkZXZpY2VCb2R5Iiwic2NoZW1hIiwib2JqZWN0Iiwic3RyaW5nIiwibWF5YmUiLCJjIiwiYiIsInN5bmNEZXZpY2UiLCJyZW1vdGVMb2NrIiwicmVzZXRQYXNzY29kZSIsInJlYm9vdERldmljZSIsInNodXREb3duRGV2aWNlIiwidXBkYXRlRGVmZW5kZXJTaWduYXR1cmVzIiwiY29sbGVjdERpYWdub3N0aWNzIiwicm90YXRlQml0TG9ja2VyS2V5cyIsInF1aWNrX3NjYW4iLCJib29sZWFuIiwiX2hlYWRlcnMzIiwiX2luZm8zIiwiZGVmZW5kZXJTY2FuIiwiX2hlYWRlcnM0IiwiX2VyciRtZXNzYWdlMyIsIl9pbmZvNCIsIl9lcnIkcmVzcG9uc2UiLCJfZXJyJG1lc3NhZ2U0IiwiX2hlYWRlcnM1IiwiX2luZm81IiwibWFya1JlbWVkaWF0aW9uIiwidXBkYXRlIiwiSU5UVU5FX0RFVklDRVNfSU5ERVgiLCJpZCIsImRvYyIsIm5lZWRzX3JlbWVkaWF0aW9uIiwicmVtZWRpYXRpb25fZmxhZ2dlZF9ieSIsInJlbWVkaWF0aW9uX2ZsYWdnZWRfYXQiLCJfaGVhZGVyczYiLCJfZXJyJG1lc3NhZ2U1IiwiX2luZm82IiwiX2VyciRyZXNwb25zZTIiLCJfZXJyJG1lc3NhZ2U2Iiwic2NyaXB0X2lkIiwic2NyaXB0X3R5cGUiLCJncm91cF9pZCIsIl9oZWFkZXJzNyIsIl9pbmZvNyIsImFzc2lnblNjcmlwdCIsIl9lcnIkcmVzcG9uc2UzIiwiX2VyciRtZXNzYWdlNyIsImFwcF9pZCIsImludGVudCIsIl9oZWFkZXJzOCIsIl9pbmZvOCIsImFzc2lnbkFwcCIsIl9lcnIkcmVzcG9uc2U0IiwiX2VyciRtZXNzYWdlOCIsInBhcmFtcyIsIl9yZXN1bHQkZGF0YSIsIl9oZWFkZXJzOSIsIl9pbmZvOSIsImdldENvbmRpdGlvbmFsQWNjZXNzU3RhdHVzIiwiZGF0YSIsImRldmljZSIsIl9lcnIkcmVzcG9uc2U1IiwiX2VyciRtZXNzYWdlOSIsIlZBTElEX09UUF9BQ1RJT05TIiwib3RwQWN0aW9uIiwiaW5jbHVkZXMiLCJiYWRSZXF1ZXN0Iiwic3VjY2VzcyIsImpvaW4iLCJvdHAiLCJnZW5lcmF0ZU9UUCIsInN0b3JlT1RQIiwiZW1haWxSZXN1bHQiLCJzZW5kT1RQRW1haWwiLCJkZXZNb2RlIiwicmVjaXBpZW50IiwiZGV2X21vZGUiLCJ2YWxpZGF0aW9uIiwidmFsaWRhdGVPVFAiLCJ2YWxpZCIsImZvcmJpZGRlbiIsInJlYXNvbiIsIl9oZWFkZXJzMTAiLCJfaW5mbzEwIiwicmV0aXJlRGV2aWNlIiwiX2VyciRyZXNwb25zZTYiLCJfZXJyJG1lc3NhZ2UxMCIsImtlZXBfZW5yb2xsbWVudF9kYXRhIiwia2VlcF91c2VyX2RhdGEiLCJfaGVhZGVyczExIiwiX2luZm8xMSIsIndpcGVEZXZpY2UiLCJfZXJyJHJlc3BvbnNlNyIsIl9lcnIkbWVzc2FnZTExIiwiX2hlYWRlcnMxMiIsIl9pbmZvMTIiLCJmYWN0b3J5UmVzZXREZXZpY2UiLCJfZXJyJHJlc3BvbnNlOCIsIl9lcnIkbWVzc2FnZTEyIiwicXVlcnkiLCJzaXplIiwiX2hpdHMkaGl0cyIsIl9yZXNwb25zZSRib2R5IiwiTWF0aCIsIm1pbiIsInNlYXJjaCIsImlnbm9yZV91bmF2YWlsYWJsZSIsInNvcnQiLCJvcmRlciIsIm1pc3NpbmciLCJtYXRjaF9hbGwiLCJoaXRzIiwibG9ncyIsIm1hcCIsImgiLCJfc291cmNlIiwiZmlsdGVyIiwiQm9vbGVhbiIsInRvdGFsIiwibGVuZ3RoIiwiX2VyciRtZXNzYWdlMTMiLCJwbGF0Zm9ybSIsIm9uZU9mIiwibGl0ZXJhbCIsImFwaV9lbmRwb2ludCIsImFwaV91c2VybmFtZSIsImFwaV9wYXNzd29yZCIsImVuYWJsZV95YXJhIiwidGFyZ2V0IiwiZGV2aWNlX2lkcyIsImFycmF5T2YiLCJfZGV2aWNlX2lkcyRsZW5ndGgiLCJfaGVhZGVyczEzIiwidGVtcGxhdGVEaXIiLCJyZXNvbHZlIiwiX19kaXJuYW1lIiwidGVtcGxhdGVGaWxlIiwidGVtcGxhdGVQYXRoIiwiZXhpc3RzU3luYyIsInNjcmlwdENvbnRlbnQiLCJyZWFkRmlsZVN5bmMiLCJyZXBsYWNlIiwic2NyaXB0QmFzZTY0IiwiQnVmZmVyIiwiZnJvbSIsInRvU3RyaW5nIiwidHMiLCJzbGljZSIsImRpc3BsYXlOYW1lIiwiZGVzY3JpcHRpb24iLCJzY3JpcHRSZXN1bHQiLCJ1cGxvYWRQb3dlclNoZWxsU2NyaXB0IiwidXBsb2FkU2hlbGxTY3JpcHQiLCJncm91cElkIiwiZ3JvdXBOYW1lIiwicmVzb2x2ZWQiLCJyZXNvbHZlQXp1cmVBZERldmljZU9iamVjdElkcyIsImNyZWF0ZVNlY3VyaXR5R3JvdXAiLCJhZGREZXZpY2VzVG9Hcm91cCIsImQiLCJhenVyZUFkT2JqZWN0SWQiLCJncm91cEVyciIsIl9ncm91cEVyciRtZXNzYWdlIiwiX2dyb3VwRXJyJG1lc3NhZ2UyIiwiX2dyb3VwRXJyJG1lc3NhZ2UzIiwic2NyaXB0VHlwZSIsInNjcmlwdF9uYW1lIiwiYXNzaWduZWRfdG8iLCJfaGVhZGVyczE0IiwiX2VyciRtZXNzYWdlMTQiLCJfZXJyJHJlc3BvbnNlOSIsIl9lcnIkbWVzc2FnZTE1Il0sInNvdXJjZXMiOlsiYWN0aW9ucy50cyJdLCJzb3VyY2VzQ29udGVudCI6WyIvKlxuICogSW50dW5lIFBsdWdpbiAtIEFjdGlvbiByb3V0ZXMuXG4gKlxuICogQ2FsbHMgTWljcm9zb2Z0IEdyYXBoIEFQSSBkaXJlY3RseSAobm8gZXh0ZXJuYWwgYWN0aW9uIHNlcnZpY2UpLlxuICogQ3JlZGVudGlhbHMgZnJvbSBlbnY6IElOVFVORV9URU5BTlRfSUQsIElOVFVORV9DTElFTlRfSUQsIElOVFVORV9DTElFTlRfU0VDUkVUXG4gKiBPVFAvU01UUCBmcm9tIGVudjogU01UUF9IT1NULCBTTVRQX1BPUlQsIFNNVFBfVVNFUiwgU01UUF9QQVNTLCBPVFBfUkVDSVBJRU5UX0VNQUlMXG4gKi9cblxuaW1wb3J0IHsgSVJvdXRlciB9IGZyb20gJ29wZW5zZWFyY2gtZGFzaGJvYXJkcy9zZXJ2ZXInO1xuaW1wb3J0IHsgc2NoZW1hIH0gZnJvbSAnQG9zZC9jb25maWctc2NoZW1hJztcbmltcG9ydCB7IElOVFVORV9BVURJVF9MT0dfSU5ERVgsIElOVFVORV9ERVZJQ0VTX0lOREVYIH0gZnJvbSAnLi4vLi4vY29tbW9uL2NvbnN0YW50cyc7XG5pbXBvcnQge1xuICBnZXRHcmFwaENvbmZpZyxcbiAgc3luY0RldmljZSxcbiAgcmVtb3RlTG9jayxcbiAgcmVzZXRQYXNzY29kZSxcbiAgcmVib290RGV2aWNlLFxuICBzaHV0RG93bkRldmljZSxcbiAgZGVmZW5kZXJTY2FuLFxuICB1cGRhdGVEZWZlbmRlclNpZ25hdHVyZXMsXG4gIGNvbGxlY3REaWFnbm9zdGljcyxcbiAgcm90YXRlQml0TG9ja2VyS2V5cyxcbiAgbWFya1JlbWVkaWF0aW9uLFxuICBnZXRDb25kaXRpb25hbEFjY2Vzc1N0YXR1cyxcbiAgcmV0aXJlRGV2aWNlLFxuICB3aXBlRGV2aWNlLFxuICBmYWN0b3J5UmVzZXREZXZpY2UsXG4gIGFzc2lnblNjcmlwdCxcbiAgYXNzaWduQXBwLFxuICB1cGxvYWRQb3dlclNoZWxsU2NyaXB0LFxuICB1cGxvYWRTaGVsbFNjcmlwdCxcbiAgY3JlYXRlU2VjdXJpdHlHcm91cCxcbiAgYWRkRGV2aWNlc1RvR3JvdXAsXG4gIHJlc29sdmVBenVyZUFkRGV2aWNlT2JqZWN0SWRzLFxufSBmcm9tICcuLi9saWIvZ3JhcGgtY2xpZW50JztcbmltcG9ydCAqIGFzIGZzIGZyb20gJ2ZzJztcbmltcG9ydCAqIGFzIHBhdGggZnJvbSAncGF0aCc7XG5pbXBvcnQgeyBnZW5lcmF0ZU9UUCwgc3RvcmVPVFAsIHZhbGlkYXRlT1RQLCBzZW5kT1RQRW1haWwsIHR5cGUgT1RQRW1haWxDb25maWcgfSBmcm9tICcuLi9saWIvb3RwJztcblxuZnVuY3Rpb24gZ2V0VXNlckZyb21SZXF1ZXN0KHJlcTogYW55KTogeyB1c2VyOiBzdHJpbmc7IHJvbGU6IHN0cmluZyB9IHtcbiAgY29uc3QgdXNlciA9IChyZXEuaGVhZGVycz8uWyd4LWludHVuZS11c2VyJ10gYXMgc3RyaW5nKSB8fCAnZGFzaGJvYXJkLXVzZXInO1xuICBjb25zdCByb2xlID0gKHJlcS5oZWFkZXJzPy5bJ3gtaW50dW5lLXJvbGUnXSBhcyBzdHJpbmcpIHx8ICdpbnR1bmVfb3BlcmF0b3InO1xuICByZXR1cm4geyB1c2VyLCByb2xlIH07XG59XG5cbmZ1bmN0aW9uIGdldE9UUENvbmZpZygpOiBPVFBFbWFpbENvbmZpZyB7XG4gIHJldHVybiB7XG4gICAgc210cEhvc3Q6IHByb2Nlc3MuZW52LlNNVFBfSE9TVCxcbiAgICBzbXRwUG9ydDogcHJvY2Vzcy5lbnYuU01UUF9QT1JUID8gcGFyc2VJbnQocHJvY2Vzcy5lbnYuU01UUF9QT1JULCAxMCkgOiA1ODcsXG4gICAgc210cFVzZXI6IHByb2Nlc3MuZW52LlNNVFBfVVNFUixcbiAgICBzbXRwUGFzczogcHJvY2Vzcy5lbnYuU01UUF9QQVNTLFxuICAgIG90cFJlY2lwaWVudEVtYWlsOiBwcm9jZXNzLmVudi5PVFBfUkVDSVBJRU5UX0VNQUlMLFxuICAgIHNtdHBTZWN1cmU6IHByb2Nlc3MuZW52LlNNVFBfU0VDVVJFID09PSAndHJ1ZScsXG4gIH07XG59XG5cbmFzeW5jIGZ1bmN0aW9uIHdyaXRlQXVkaXRMb2coXG4gIGNsaWVudDogYW55LFxuICBlbnRyeToge1xuICAgIGFjdGlvbjogc3RyaW5nO1xuICAgIGludHVuZV9kZXZpY2VfaWQ6IHN0cmluZztcbiAgICBkZXZpY2VfbmFtZTogc3RyaW5nO1xuICAgIHBlcmZvcm1lZF9ieTogc3RyaW5nO1xuICAgIHJvbGU6IHN0cmluZztcbiAgICBzdGF0dXM6IHN0cmluZztcbiAgICBtZXNzYWdlOiBzdHJpbmc7XG4gICAgc291cmNlX2lwPzogc3RyaW5nO1xuICB9XG4pIHtcbiAgdHJ5IHtcbiAgICBhd2FpdCBjbGllbnQuaW5kZXgoe1xuICAgICAgaW5kZXg6IElOVFVORV9BVURJVF9MT0dfSU5ERVgsXG4gICAgICBib2R5OiB7IC4uLmVudHJ5LCB0aW1lc3RhbXA6IG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKSB9LFxuICAgIH0pO1xuICB9IGNhdGNoIChlcnIpIHtcbiAgICBjb25zb2xlLmVycm9yKCdbSW50dW5lXSBBdWRpdCBsb2cgd3JpdGUgZmFpbGVkOicsIGVycik7XG4gIH1cbn1cblxuZnVuY3Rpb24gbWFrZUFjdGlvbkhhbmRsZXIoXG4gIHJvdXRlcjogSVJvdXRlcixcbiAgcGF0aDogc3RyaW5nLFxuICBhY3Rpb25OYW1lOiBzdHJpbmcsXG4gIGJvZHlTY2hlbWE6IGFueSxcbiAgZm46IChjb25maWc6IGFueSwgYm9keTogYW55LCB1c2VyOiBzdHJpbmcpID0+IFByb21pc2U8eyBzdWNjZXNzOiBib29sZWFuOyBtZXNzYWdlOiBzdHJpbmc7IGRhdGE/OiBhbnkgfT5cbikge1xuICByb3V0ZXIucG9zdChcbiAgICB7IHBhdGgsIHZhbGlkYXRlOiB7IGJvZHk6IGJvZHlTY2hlbWEgfSB9LFxuICAgIGFzeW5jIChjb250ZXh0LCByZXEsIHJlcykgPT4ge1xuICAgICAgY29uc3QgY29uZmlnID0gZ2V0R3JhcGhDb25maWcoKTtcbiAgICAgIGlmICghY29uZmlnKSB7XG4gICAgICAgIHJldHVybiByZXMuY3VzdG9tRXJyb3Ioe1xuICAgICAgICAgIHN0YXR1c0NvZGU6IDUwMyxcbiAgICAgICAgICBib2R5OiAnSW50dW5lIGNyZWRlbnRpYWxzIG5vdCBjb25maWd1cmVkLiBTZXQgSU5UVU5FX1RFTkFOVF9JRCwgSU5UVU5FX0NMSUVOVF9JRCwgSU5UVU5FX0NMSUVOVF9TRUNSRVQuJyxcbiAgICAgICAgfSk7XG4gICAgICB9XG4gICAgICBjb25zdCB7IHVzZXIgfSA9IGdldFVzZXJGcm9tUmVxdWVzdChyZXEpO1xuICAgICAgY29uc3QgY2xpZW50ID0gY29udGV4dC5jb3JlLm9wZW5zZWFyY2guY2xpZW50LmFzQ3VycmVudFVzZXI7XG4gICAgICBjb25zdCBkZXZpY2VJZCA9IChyZXEuYm9keSBhcyBhbnkpLmludHVuZV9kZXZpY2VfaWQ7XG4gICAgICBjb25zdCBkZXZpY2VOYW1lID0gKHJlcS5ib2R5IGFzIGFueSkuZGV2aWNlX25hbWUgfHwgJyc7XG4gICAgICB0cnkge1xuICAgICAgICBjb25zdCByZXN1bHQgPSBhd2FpdCBmbihjb25maWcsIHJlcS5ib2R5LCB1c2VyKTtcbiAgICAgICAgYXdhaXQgd3JpdGVBdWRpdExvZyhjbGllbnQsIHtcbiAgICAgICAgICBhY3Rpb246IGFjdGlvbk5hbWUsXG4gICAgICAgICAgaW50dW5lX2RldmljZV9pZDogZGV2aWNlSWQgfHwgJycsXG4gICAgICAgICAgZGV2aWNlX25hbWU6IGRldmljZU5hbWUsXG4gICAgICAgICAgcGVyZm9ybWVkX2J5OiB1c2VyLFxuICAgICAgICAgIHJvbGU6IChyZXEgYXMgYW55KS5oZWFkZXJzPy5bJ3gtaW50dW5lLXJvbGUnXSB8fCAnaW50dW5lX29wZXJhdG9yJyxcbiAgICAgICAgICBzdGF0dXM6ICdzdWNjZXNzJyxcbiAgICAgICAgICBtZXNzYWdlOiByZXN1bHQubWVzc2FnZSxcbiAgICAgICAgICBzb3VyY2VfaXA6IChyZXEgYXMgYW55KS5pbmZvPy5yZW1vdGVBZGRyZXNzLFxuICAgICAgICB9KTtcbiAgICAgICAgcmV0dXJuIHJlcy5vayh7XG4gICAgICAgICAgYm9keTogeyAuLi5yZXN1bHQsIGFjdGlvbjogYWN0aW9uTmFtZSwgaW50dW5lX2RldmljZV9pZDogZGV2aWNlSWQsIHRpbWVzdGFtcDogbmV3IERhdGUoKS50b0lTT1N0cmluZygpIH0sXG4gICAgICAgIH0pO1xuICAgICAgfSBjYXRjaCAoZXJyOiBhbnkpIHtcbiAgICAgICAgYXdhaXQgd3JpdGVBdWRpdExvZyhjbGllbnQsIHtcbiAgICAgICAgICBhY3Rpb246IGFjdGlvbk5hbWUsXG4gICAgICAgICAgaW50dW5lX2RldmljZV9pZDogZGV2aWNlSWQgfHwgJycsXG4gICAgICAgICAgZGV2aWNlX25hbWU6IGRldmljZU5hbWUsXG4gICAgICAgICAgcGVyZm9ybWVkX2J5OiB1c2VyLFxuICAgICAgICAgIHJvbGU6IChyZXEgYXMgYW55KS5oZWFkZXJzPy5bJ3gtaW50dW5lLXJvbGUnXSB8fCAnaW50dW5lX29wZXJhdG9yJyxcbiAgICAgICAgICBzdGF0dXM6ICdmYWlsdXJlJyxcbiAgICAgICAgICBtZXNzYWdlOiBlcnI/Lm1lc3NhZ2UgPz8gU3RyaW5nKGVyciksXG4gICAgICAgICAgc291cmNlX2lwOiAocmVxIGFzIGFueSkuaW5mbz8ucmVtb3RlQWRkcmVzcyxcbiAgICAgICAgfSk7XG4gICAgICAgIGNvbnN0IHN0YXR1cyA9IChlcnIgYXMgYW55KT8ucmVzcG9uc2U/LnN0YXR1cyB8fCA1MDA7XG4gICAgICAgIHJldHVybiByZXMuY3VzdG9tRXJyb3Ioe1xuICAgICAgICAgIHN0YXR1c0NvZGU6IHN0YXR1cyxcbiAgICAgICAgICBib2R5OiBlcnI/Lm1lc3NhZ2UgPz8gU3RyaW5nKGVyciksXG4gICAgICAgIH0pO1xuICAgICAgfVxuICAgIH1cbiAgKTtcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIHJlZ2lzdGVyQWN0aW9uUm91dGVzKHJvdXRlcjogSVJvdXRlcikge1xuICBjb25zdCBkZXZpY2VCb2R5ID0gc2NoZW1hLm9iamVjdCh7XG4gICAgaW50dW5lX2RldmljZV9pZDogc2NoZW1hLnN0cmluZygpLFxuICAgIGRldmljZV9uYW1lOiBzY2hlbWEubWF5YmUoc2NoZW1hLnN0cmluZygpKSxcbiAgfSk7XG5cbiAgbWFrZUFjdGlvbkhhbmRsZXIoXG4gICAgcm91dGVyLFxuICAgICcvYXBpL2ludHVuZV9wbHVnaW4vYWN0aW9ucy9zeW5jLWRldmljZScsXG4gICAgJ3N5bmNfZGV2aWNlJyxcbiAgICBkZXZpY2VCb2R5LFxuICAgIChjLCBiKSA9PiBzeW5jRGV2aWNlKGMsIGIuaW50dW5lX2RldmljZV9pZClcbiAgKTtcbiAgbWFrZUFjdGlvbkhhbmRsZXIoXG4gICAgcm91dGVyLFxuICAgICcvYXBpL2ludHVuZV9wbHVnaW4vYWN0aW9ucy9yZW1vdGUtbG9jaycsXG4gICAgJ3JlbW90ZV9sb2NrJyxcbiAgICBkZXZpY2VCb2R5LFxuICAgIChjLCBiKSA9PiByZW1vdGVMb2NrKGMsIGIuaW50dW5lX2RldmljZV9pZClcbiAgKTtcbiAgbWFrZUFjdGlvbkhhbmRsZXIoXG4gICAgcm91dGVyLFxuICAgICcvYXBpL2ludHVuZV9wbHVnaW4vYWN0aW9ucy9yZXNldC1wYXNzY29kZScsXG4gICAgJ3Jlc2V0X3Bhc3Njb2RlJyxcbiAgICBkZXZpY2VCb2R5LFxuICAgIChjLCBiKSA9PiByZXNldFBhc3Njb2RlKGMsIGIuaW50dW5lX2RldmljZV9pZClcbiAgKTtcbiAgbWFrZUFjdGlvbkhhbmRsZXIoXG4gICAgcm91dGVyLFxuICAgICcvYXBpL2ludHVuZV9wbHVnaW4vYWN0aW9ucy9yZWJvb3QtZGV2aWNlJyxcbiAgICAncmVib290X2RldmljZScsXG4gICAgZGV2aWNlQm9keSxcbiAgICAoYywgYikgPT4gcmVib290RGV2aWNlKGMsIGIuaW50dW5lX2RldmljZV9pZClcbiAgKTtcbiAgbWFrZUFjdGlvbkhhbmRsZXIoXG4gICAgcm91dGVyLFxuICAgICcvYXBpL2ludHVuZV9wbHVnaW4vYWN0aW9ucy9zaHV0ZG93bi1kZXZpY2UnLFxuICAgICdzaHV0ZG93bl9kZXZpY2UnLFxuICAgIGRldmljZUJvZHksXG4gICAgKGMsIGIpID0+IHNodXREb3duRGV2aWNlKGMsIGIuaW50dW5lX2RldmljZV9pZClcbiAgKTtcbiAgbWFrZUFjdGlvbkhhbmRsZXIoXG4gICAgcm91dGVyLFxuICAgICcvYXBpL2ludHVuZV9wbHVnaW4vYWN0aW9ucy91cGRhdGUtZGVmZW5kZXItc2lnbmF0dXJlcycsXG4gICAgJ3VwZGF0ZV9kZWZlbmRlcl9zaWduYXR1cmVzJyxcbiAgICBkZXZpY2VCb2R5LFxuICAgIChjLCBiKSA9PiB1cGRhdGVEZWZlbmRlclNpZ25hdHVyZXMoYywgYi5pbnR1bmVfZGV2aWNlX2lkKVxuICApO1xuICBtYWtlQWN0aW9uSGFuZGxlcihcbiAgICByb3V0ZXIsXG4gICAgJy9hcGkvaW50dW5lX3BsdWdpbi9hY3Rpb25zL2NvbGxlY3QtZGlhZ25vc3RpY3MnLFxuICAgICdjb2xsZWN0X2RpYWdub3N0aWNzJyxcbiAgICBkZXZpY2VCb2R5LFxuICAgIChjLCBiKSA9PiBjb2xsZWN0RGlhZ25vc3RpY3MoYywgYi5pbnR1bmVfZGV2aWNlX2lkKVxuICApO1xuICBtYWtlQWN0aW9uSGFuZGxlcihcbiAgICByb3V0ZXIsXG4gICAgJy9hcGkvaW50dW5lX3BsdWdpbi9hY3Rpb25zL3JvdGF0ZS1iaXRsb2NrZXInLFxuICAgICdyb3RhdGVfYml0bG9ja2VyJyxcbiAgICBkZXZpY2VCb2R5LFxuICAgIChjLCBiKSA9PiByb3RhdGVCaXRMb2NrZXJLZXlzKGMsIGIuaW50dW5lX2RldmljZV9pZClcbiAgKTtcblxuICByb3V0ZXIucG9zdChcbiAgICB7XG4gICAgICBwYXRoOiAnL2FwaS9pbnR1bmVfcGx1Z2luL2FjdGlvbnMvZGVmZW5kZXItc2NhbicsXG4gICAgICB2YWxpZGF0ZToge1xuICAgICAgICBib2R5OiBzY2hlbWEub2JqZWN0KHtcbiAgICAgICAgICBpbnR1bmVfZGV2aWNlX2lkOiBzY2hlbWEuc3RyaW5nKCksXG4gICAgICAgICAgZGV2aWNlX25hbWU6IHNjaGVtYS5tYXliZShzY2hlbWEuc3RyaW5nKCkpLFxuICAgICAgICAgIHF1aWNrX3NjYW46IHNjaGVtYS5tYXliZShzY2hlbWEuYm9vbGVhbigpKSxcbiAgICAgICAgfSksXG4gICAgICB9LFxuICAgIH0sXG4gICAgYXN5bmMgKGNvbnRleHQsIHJlcSwgcmVzKSA9PiB7XG4gICAgICBjb25zdCBjb25maWcgPSBnZXRHcmFwaENvbmZpZygpO1xuICAgICAgaWYgKCFjb25maWcpIHtcbiAgICAgICAgcmV0dXJuIHJlcy5jdXN0b21FcnJvcih7IHN0YXR1c0NvZGU6IDUwMywgYm9keTogJ0ludHVuZSBjcmVkZW50aWFscyBub3QgY29uZmlndXJlZC4nIH0pO1xuICAgICAgfVxuICAgICAgY29uc3QgeyB1c2VyIH0gPSBnZXRVc2VyRnJvbVJlcXVlc3QocmVxKTtcbiAgICAgIGNvbnN0IHsgaW50dW5lX2RldmljZV9pZCwgZGV2aWNlX25hbWUsIHF1aWNrX3NjYW4gPSB0cnVlIH0gPSByZXEuYm9keSBhcyBhbnk7XG4gICAgICBjb25zdCBjbGllbnQgPSBjb250ZXh0LmNvcmUub3BlbnNlYXJjaC5jbGllbnQuYXNDdXJyZW50VXNlcjtcbiAgICAgIHRyeSB7XG4gICAgICAgIGNvbnN0IHJlc3VsdCA9IGF3YWl0IGRlZmVuZGVyU2Nhbihjb25maWcsIGludHVuZV9kZXZpY2VfaWQsIHF1aWNrX3NjYW4pO1xuICAgICAgICBhd2FpdCB3cml0ZUF1ZGl0TG9nKGNsaWVudCwge1xuICAgICAgICAgIGFjdGlvbjogJ2RlZmVuZGVyX3NjYW4nLFxuICAgICAgICAgIGludHVuZV9kZXZpY2VfaWQsXG4gICAgICAgICAgZGV2aWNlX25hbWU6IGRldmljZV9uYW1lIHx8ICcnLFxuICAgICAgICAgIHBlcmZvcm1lZF9ieTogdXNlcixcbiAgICAgICAgICByb2xlOiAocmVxIGFzIGFueSkuaGVhZGVycz8uWyd4LWludHVuZS1yb2xlJ10gfHwgJ2ludHVuZV9vcGVyYXRvcicsXG4gICAgICAgICAgc3RhdHVzOiAnc3VjY2VzcycsXG4gICAgICAgICAgbWVzc2FnZTogcmVzdWx0Lm1lc3NhZ2UsXG4gICAgICAgICAgc291cmNlX2lwOiAocmVxIGFzIGFueSkuaW5mbz8ucmVtb3RlQWRkcmVzcyxcbiAgICAgICAgfSk7XG4gICAgICAgIHJldHVybiByZXMub2soeyBib2R5OiB7IC4uLnJlc3VsdCwgYWN0aW9uOiAnZGVmZW5kZXJfc2NhbicsIGludHVuZV9kZXZpY2VfaWQsIHRpbWVzdGFtcDogbmV3IERhdGUoKS50b0lTT1N0cmluZygpIH0gfSk7XG4gICAgICB9IGNhdGNoIChlcnI6IGFueSkge1xuICAgICAgICBhd2FpdCB3cml0ZUF1ZGl0TG9nKGNsaWVudCwge1xuICAgICAgICAgIGFjdGlvbjogJ2RlZmVuZGVyX3NjYW4nLFxuICAgICAgICAgIGludHVuZV9kZXZpY2VfaWQsXG4gICAgICAgICAgZGV2aWNlX25hbWU6IGRldmljZV9uYW1lIHx8ICcnLFxuICAgICAgICAgIHBlcmZvcm1lZF9ieTogdXNlcixcbiAgICAgICAgICByb2xlOiAocmVxIGFzIGFueSkuaGVhZGVycz8uWyd4LWludHVuZS1yb2xlJ10gfHwgJ2ludHVuZV9vcGVyYXRvcicsXG4gICAgICAgICAgc3RhdHVzOiAnZmFpbHVyZScsXG4gICAgICAgICAgbWVzc2FnZTogZXJyPy5tZXNzYWdlID8/IFN0cmluZyhlcnIpLFxuICAgICAgICAgIHNvdXJjZV9pcDogKHJlcSBhcyBhbnkpLmluZm8/LnJlbW90ZUFkZHJlc3MsXG4gICAgICAgIH0pO1xuICAgICAgICByZXR1cm4gcmVzLmN1c3RvbUVycm9yKHsgc3RhdHVzQ29kZTogZXJyPy5yZXNwb25zZT8uc3RhdHVzIHx8IDUwMCwgYm9keTogZXJyPy5tZXNzYWdlID8/IFN0cmluZyhlcnIpIH0pO1xuICAgICAgfVxuICAgIH1cbiAgKTtcblxuICByb3V0ZXIucG9zdChcbiAgICB7XG4gICAgICBwYXRoOiAnL2FwaS9pbnR1bmVfcGx1Z2luL2FjdGlvbnMvbWFyay1yZW1lZGlhdGlvbicsXG4gICAgICB2YWxpZGF0ZTogeyBib2R5OiBkZXZpY2VCb2R5IH0sXG4gICAgfSxcbiAgICBhc3luYyAoY29udGV4dCwgcmVxLCByZXMpID0+IHtcbiAgICAgIGNvbnN0IGNvbmZpZyA9IGdldEdyYXBoQ29uZmlnKCk7XG4gICAgICBpZiAoIWNvbmZpZykge1xuICAgICAgICByZXR1cm4gcmVzLmN1c3RvbUVycm9yKHsgc3RhdHVzQ29kZTogNTAzLCBib2R5OiAnSW50dW5lIGNyZWRlbnRpYWxzIG5vdCBjb25maWd1cmVkLicgfSk7XG4gICAgICB9XG4gICAgICBjb25zdCB7IHVzZXIgfSA9IGdldFVzZXJGcm9tUmVxdWVzdChyZXEpO1xuICAgICAgY29uc3QgeyBpbnR1bmVfZGV2aWNlX2lkLCBkZXZpY2VfbmFtZSB9ID0gcmVxLmJvZHkgYXMgYW55O1xuICAgICAgY29uc3QgY2xpZW50ID0gY29udGV4dC5jb3JlLm9wZW5zZWFyY2guY2xpZW50LmFzQ3VycmVudFVzZXI7XG4gICAgICB0cnkge1xuICAgICAgICBjb25zdCByZXN1bHQgPSBhd2FpdCBtYXJrUmVtZWRpYXRpb24oY29uZmlnLCBpbnR1bmVfZGV2aWNlX2lkLCB1c2VyKTtcbiAgICAgICAgdHJ5IHtcbiAgICAgICAgICBhd2FpdCBjbGllbnQudXBkYXRlKHtcbiAgICAgICAgICAgIGluZGV4OiBJTlRVTkVfREVWSUNFU19JTkRFWCxcbiAgICAgICAgICAgIGlkOiBpbnR1bmVfZGV2aWNlX2lkLFxuICAgICAgICAgICAgYm9keToge1xuICAgICAgICAgICAgICBkb2M6IHtcbiAgICAgICAgICAgICAgICBuZWVkc19yZW1lZGlhdGlvbjogdHJ1ZSxcbiAgICAgICAgICAgICAgICByZW1lZGlhdGlvbl9mbGFnZ2VkX2J5OiB1c2VyLFxuICAgICAgICAgICAgICAgIHJlbWVkaWF0aW9uX2ZsYWdnZWRfYXQ6IG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKSxcbiAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgfSk7XG4gICAgICAgIH0gY2F0Y2gge1xuICAgICAgICAgIC8vIEluZGV4IHVwZGF0ZSBvcHRpb25hbFxuICAgICAgICB9XG4gICAgICAgIGF3YWl0IHdyaXRlQXVkaXRMb2coY2xpZW50LCB7XG4gICAgICAgICAgYWN0aW9uOiAnbWFya19yZW1lZGlhdGlvbicsXG4gICAgICAgICAgaW50dW5lX2RldmljZV9pZCxcbiAgICAgICAgICBkZXZpY2VfbmFtZTogZGV2aWNlX25hbWUgfHwgJycsXG4gICAgICAgICAgcGVyZm9ybWVkX2J5OiB1c2VyLFxuICAgICAgICAgIHJvbGU6IChyZXEgYXMgYW55KS5oZWFkZXJzPy5bJ3gtaW50dW5lLXJvbGUnXSB8fCAnaW50dW5lX29wZXJhdG9yJyxcbiAgICAgICAgICBzdGF0dXM6ICdzdWNjZXNzJyxcbiAgICAgICAgICBtZXNzYWdlOiByZXN1bHQubWVzc2FnZSxcbiAgICAgICAgICBzb3VyY2VfaXA6IChyZXEgYXMgYW55KS5pbmZvPy5yZW1vdGVBZGRyZXNzLFxuICAgICAgICB9KTtcbiAgICAgICAgcmV0dXJuIHJlcy5vayh7IGJvZHk6IHsgLi4ucmVzdWx0LCBhY3Rpb246ICdtYXJrX3JlbWVkaWF0aW9uJywgaW50dW5lX2RldmljZV9pZCwgdGltZXN0YW1wOiBuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCkgfSB9KTtcbiAgICAgIH0gY2F0Y2ggKGVycjogYW55KSB7XG4gICAgICAgIGF3YWl0IHdyaXRlQXVkaXRMb2coY2xpZW50LCB7XG4gICAgICAgICAgYWN0aW9uOiAnbWFya19yZW1lZGlhdGlvbicsXG4gICAgICAgICAgaW50dW5lX2RldmljZV9pZCxcbiAgICAgICAgICBkZXZpY2VfbmFtZTogZGV2aWNlX25hbWUgfHwgJycsXG4gICAgICAgICAgcGVyZm9ybWVkX2J5OiB1c2VyLFxuICAgICAgICAgIHJvbGU6IChyZXEgYXMgYW55KS5oZWFkZXJzPy5bJ3gtaW50dW5lLXJvbGUnXSB8fCAnaW50dW5lX29wZXJhdG9yJyxcbiAgICAgICAgICBzdGF0dXM6ICdmYWlsdXJlJyxcbiAgICAgICAgICBtZXNzYWdlOiBlcnI/Lm1lc3NhZ2UgPz8gU3RyaW5nKGVyciksXG4gICAgICAgICAgc291cmNlX2lwOiAocmVxIGFzIGFueSkuaW5mbz8ucmVtb3RlQWRkcmVzcyxcbiAgICAgICAgfSk7XG4gICAgICAgIHJldHVybiByZXMuY3VzdG9tRXJyb3IoeyBzdGF0dXNDb2RlOiBlcnI/LnJlc3BvbnNlPy5zdGF0dXMgfHwgNTAwLCBib2R5OiBlcnI/Lm1lc3NhZ2UgPz8gU3RyaW5nKGVycikgfSk7XG4gICAgICB9XG4gICAgfVxuICApO1xuXG4gIHJvdXRlci5wb3N0KFxuICAgIHtcbiAgICAgIHBhdGg6ICcvYXBpL2ludHVuZV9wbHVnaW4vYWN0aW9ucy9hc3NpZ24tc2NyaXB0JyxcbiAgICAgIHZhbGlkYXRlOiB7XG4gICAgICAgIGJvZHk6IHNjaGVtYS5vYmplY3Qoe1xuICAgICAgICAgIHNjcmlwdF9pZDogc2NoZW1hLnN0cmluZygpLFxuICAgICAgICAgIHNjcmlwdF90eXBlOiBzY2hlbWEubWF5YmUoc2NoZW1hLnN0cmluZygpKSxcbiAgICAgICAgICBncm91cF9pZDogc2NoZW1hLm1heWJlKHNjaGVtYS5zdHJpbmcoKSksXG4gICAgICAgIH0pLFxuICAgICAgfSxcbiAgICB9LFxuICAgIGFzeW5jIChjb250ZXh0LCByZXEsIHJlcykgPT4ge1xuICAgICAgY29uc3QgY29uZmlnID0gZ2V0R3JhcGhDb25maWcoKTtcbiAgICAgIGlmICghY29uZmlnKSB7XG4gICAgICAgIHJldHVybiByZXMuY3VzdG9tRXJyb3IoeyBzdGF0dXNDb2RlOiA1MDMsIGJvZHk6ICdJbnR1bmUgY3JlZGVudGlhbHMgbm90IGNvbmZpZ3VyZWQuJyB9KTtcbiAgICAgIH1cbiAgICAgIGNvbnN0IHsgdXNlciB9ID0gZ2V0VXNlckZyb21SZXF1ZXN0KHJlcSk7XG4gICAgICBjb25zdCB7IHNjcmlwdF9pZCwgc2NyaXB0X3R5cGUgPSAncG93ZXJzaGVsbCcsIGdyb3VwX2lkID0gJ2FsbCcgfSA9IHJlcS5ib2R5IGFzIGFueTtcbiAgICAgIGNvbnN0IGNsaWVudCA9IGNvbnRleHQuY29yZS5vcGVuc2VhcmNoLmNsaWVudC5hc0N1cnJlbnRVc2VyO1xuICAgICAgdHJ5IHtcbiAgICAgICAgY29uc3QgcmVzdWx0ID0gYXdhaXQgYXNzaWduU2NyaXB0KGNvbmZpZywgc2NyaXB0X2lkLCBzY3JpcHRfdHlwZSwgZ3JvdXBfaWQpO1xuICAgICAgICBhd2FpdCB3cml0ZUF1ZGl0TG9nKGNsaWVudCwge1xuICAgICAgICAgIGFjdGlvbjogJ2Fzc2lnbl9zY3JpcHQnLFxuICAgICAgICAgIGludHVuZV9kZXZpY2VfaWQ6IHNjcmlwdF9pZCxcbiAgICAgICAgICBkZXZpY2VfbmFtZTogJycsXG4gICAgICAgICAgcGVyZm9ybWVkX2J5OiB1c2VyLFxuICAgICAgICAgIHJvbGU6IChyZXEgYXMgYW55KS5oZWFkZXJzPy5bJ3gtaW50dW5lLXJvbGUnXSB8fCAnaW50dW5lX29wZXJhdG9yJyxcbiAgICAgICAgICBzdGF0dXM6ICdzdWNjZXNzJyxcbiAgICAgICAgICBtZXNzYWdlOiByZXN1bHQubWVzc2FnZSxcbiAgICAgICAgICBzb3VyY2VfaXA6IChyZXEgYXMgYW55KS5pbmZvPy5yZW1vdGVBZGRyZXNzLFxuICAgICAgICB9KTtcbiAgICAgICAgcmV0dXJuIHJlcy5vayh7IGJvZHk6IHsgLi4ucmVzdWx0LCBhY3Rpb246ICdhc3NpZ25fc2NyaXB0Jywgc2NyaXB0X2lkLCB0aW1lc3RhbXA6IG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKSB9IH0pO1xuICAgICAgfSBjYXRjaCAoZXJyOiBhbnkpIHtcbiAgICAgICAgcmV0dXJuIHJlcy5jdXN0b21FcnJvcih7IHN0YXR1c0NvZGU6IGVycj8ucmVzcG9uc2U/LnN0YXR1cyB8fCA1MDAsIGJvZHk6IGVycj8ubWVzc2FnZSA/PyBTdHJpbmcoZXJyKSB9KTtcbiAgICAgIH1cbiAgICB9XG4gICk7XG5cbiAgcm91dGVyLnBvc3QoXG4gICAge1xuICAgICAgcGF0aDogJy9hcGkvaW50dW5lX3BsdWdpbi9hY3Rpb25zL2Fzc2lnbi1hcHAnLFxuICAgICAgdmFsaWRhdGU6IHtcbiAgICAgICAgYm9keTogc2NoZW1hLm9iamVjdCh7XG4gICAgICAgICAgYXBwX2lkOiBzY2hlbWEuc3RyaW5nKCksXG4gICAgICAgICAgZ3JvdXBfaWQ6IHNjaGVtYS5tYXliZShzY2hlbWEuc3RyaW5nKCkpLFxuICAgICAgICAgIGludGVudDogc2NoZW1hLm1heWJlKHNjaGVtYS5zdHJpbmcoKSksXG4gICAgICAgIH0pLFxuICAgICAgfSxcbiAgICB9LFxuICAgIGFzeW5jIChjb250ZXh0LCByZXEsIHJlcykgPT4ge1xuICAgICAgY29uc3QgY29uZmlnID0gZ2V0R3JhcGhDb25maWcoKTtcbiAgICAgIGlmICghY29uZmlnKSB7XG4gICAgICAgIHJldHVybiByZXMuY3VzdG9tRXJyb3IoeyBzdGF0dXNDb2RlOiA1MDMsIGJvZHk6ICdJbnR1bmUgY3JlZGVudGlhbHMgbm90IGNvbmZpZ3VyZWQuJyB9KTtcbiAgICAgIH1cbiAgICAgIGNvbnN0IHsgdXNlciB9ID0gZ2V0VXNlckZyb21SZXF1ZXN0KHJlcSk7XG4gICAgICBjb25zdCB7IGFwcF9pZCwgZ3JvdXBfaWQgPSAnYWxsJywgaW50ZW50ID0gJ3JlcXVpcmVkJyB9ID0gcmVxLmJvZHkgYXMgYW55O1xuICAgICAgY29uc3QgY2xpZW50ID0gY29udGV4dC5jb3JlLm9wZW5zZWFyY2guY2xpZW50LmFzQ3VycmVudFVzZXI7XG4gICAgICB0cnkge1xuICAgICAgICBjb25zdCByZXN1bHQgPSBhd2FpdCBhc3NpZ25BcHAoY29uZmlnLCBhcHBfaWQsIGdyb3VwX2lkLCBpbnRlbnQpO1xuICAgICAgICBhd2FpdCB3cml0ZUF1ZGl0TG9nKGNsaWVudCwge1xuICAgICAgICAgIGFjdGlvbjogJ2Fzc2lnbl9hcHAnLFxuICAgICAgICAgIGludHVuZV9kZXZpY2VfaWQ6IGFwcF9pZCxcbiAgICAgICAgICBkZXZpY2VfbmFtZTogJycsXG4gICAgICAgICAgcGVyZm9ybWVkX2J5OiB1c2VyLFxuICAgICAgICAgIHJvbGU6IChyZXEgYXMgYW55KS5oZWFkZXJzPy5bJ3gtaW50dW5lLXJvbGUnXSB8fCAnaW50dW5lX29wZXJhdG9yJyxcbiAgICAgICAgICBzdGF0dXM6ICdzdWNjZXNzJyxcbiAgICAgICAgICBtZXNzYWdlOiByZXN1bHQubWVzc2FnZSxcbiAgICAgICAgICBzb3VyY2VfaXA6IChyZXEgYXMgYW55KS5pbmZvPy5yZW1vdGVBZGRyZXNzLFxuICAgICAgICB9KTtcbiAgICAgICAgcmV0dXJuIHJlcy5vayh7IGJvZHk6IHsgLi4ucmVzdWx0LCBhY3Rpb246ICdhc3NpZ25fYXBwJywgYXBwX2lkLCB0aW1lc3RhbXA6IG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKSB9IH0pO1xuICAgICAgfSBjYXRjaCAoZXJyOiBhbnkpIHtcbiAgICAgICAgcmV0dXJuIHJlcy5jdXN0b21FcnJvcih7IHN0YXR1c0NvZGU6IGVycj8ucmVzcG9uc2U/LnN0YXR1cyB8fCA1MDAsIGJvZHk6IGVycj8ubWVzc2FnZSA/PyBTdHJpbmcoZXJyKSB9KTtcbiAgICAgIH1cbiAgICB9XG4gICk7XG5cbiAgcm91dGVyLmdldChcbiAgICB7XG4gICAgICBwYXRoOiAnL2FwaS9pbnR1bmVfcGx1Z2luL2FjdGlvbnMvY29uZGl0aW9uYWwtYWNjZXNzL3tpZH0nLFxuICAgICAgdmFsaWRhdGU6IHsgcGFyYW1zOiBzY2hlbWEub2JqZWN0KHsgaWQ6IHNjaGVtYS5zdHJpbmcoKSB9KSB9LFxuICAgIH0sXG4gICAgYXN5bmMgKGNvbnRleHQsIHJlcSwgcmVzKSA9PiB7XG4gICAgICBjb25zdCBjb25maWcgPSBnZXRHcmFwaENvbmZpZygpO1xuICAgICAgaWYgKCFjb25maWcpIHtcbiAgICAgICAgcmV0dXJuIHJlcy5jdXN0b21FcnJvcih7IHN0YXR1c0NvZGU6IDUwMywgYm9keTogJ0ludHVuZSBjcmVkZW50aWFscyBub3QgY29uZmlndXJlZC4nIH0pO1xuICAgICAgfVxuICAgICAgY29uc3QgeyB1c2VyIH0gPSBnZXRVc2VyRnJvbVJlcXVlc3QocmVxKTtcbiAgICAgIGNvbnN0IGlkID0gKHJlcS5wYXJhbXMgYXMgYW55KS5pZDtcbiAgICAgIGNvbnN0IGNsaWVudCA9IGNvbnRleHQuY29yZS5vcGVuc2VhcmNoLmNsaWVudC5hc0N1cnJlbnRVc2VyO1xuICAgICAgdHJ5IHtcbiAgICAgICAgY29uc3QgcmVzdWx0ID0gYXdhaXQgZ2V0Q29uZGl0aW9uYWxBY2Nlc3NTdGF0dXMoY29uZmlnLCBpZCk7XG4gICAgICAgIGF3YWl0IHdyaXRlQXVkaXRMb2coY2xpZW50LCB7XG4gICAgICAgICAgYWN0aW9uOiAndmlld19jb25kaXRpb25hbF9hY2Nlc3MnLFxuICAgICAgICAgIGludHVuZV9kZXZpY2VfaWQ6IGlkLFxuICAgICAgICAgIGRldmljZV9uYW1lOiAocmVzdWx0LmRhdGE/LmRldmljZSBhcyBhbnkpPy5kZXZpY2VOYW1lIHx8ICcnLFxuICAgICAgICAgIHBlcmZvcm1lZF9ieTogdXNlcixcbiAgICAgICAgICByb2xlOiAocmVxIGFzIGFueSkuaGVhZGVycz8uWyd4LWludHVuZS1yb2xlJ10gfHwgJ2ludHVuZV9vcGVyYXRvcicsXG4gICAgICAgICAgc3RhdHVzOiAnc3VjY2VzcycsXG4gICAgICAgICAgbWVzc2FnZTogcmVzdWx0Lm1lc3NhZ2UsXG4gICAgICAgICAgc291cmNlX2lwOiAocmVxIGFzIGFueSkuaW5mbz8ucmVtb3RlQWRkcmVzcyxcbiAgICAgICAgfSk7XG4gICAgICAgIHJldHVybiByZXMub2soeyBib2R5OiB7IC4uLnJlc3VsdCwgYWN0aW9uOiAndmlld19jb25kaXRpb25hbF9hY2Nlc3MnLCBpbnR1bmVfZGV2aWNlX2lkOiBpZCwgdGltZXN0YW1wOiBuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCkgfSB9KTtcbiAgICAgIH0gY2F0Y2ggKGVycjogYW55KSB7XG4gICAgICAgIHJldHVybiByZXMuY3VzdG9tRXJyb3IoeyBzdGF0dXNDb2RlOiBlcnI/LnJlc3BvbnNlPy5zdGF0dXMgfHwgNTAwLCBib2R5OiBlcnI/Lm1lc3NhZ2UgPz8gU3RyaW5nKGVycikgfSk7XG4gICAgICB9XG4gICAgfVxuICApO1xuXG4gIC8vIE1hcCBmcm9udGVuZCBhY3Rpb24gbmFtZXMgdG8gT1RQIGtleXMgKGZyb250ZW5kIHNlbmRzICdyZXRpcmUnfCd3aXBlJ3wnZmFjdG9yeV9yZXNldCcpXG4gIGNvbnN0IFZBTElEX09UUF9BQ1RJT05TID0gWydyZXRpcmUnLCAnd2lwZScsICdmYWN0b3J5X3Jlc2V0J107XG5cbiAgLy8g4pSA4pSAIE9UUDogUmVxdWVzdCDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIBcbiAgcm91dGVyLnBvc3QoXG4gICAge1xuICAgICAgcGF0aDogJy9hcGkvaW50dW5lX3BsdWdpbi9hY3Rpb25zL3JlcXVlc3Qtb3RwJyxcbiAgICAgIHZhbGlkYXRlOiB7XG4gICAgICAgIGJvZHk6IHNjaGVtYS5vYmplY3Qoe1xuICAgICAgICAgIGludHVuZV9kZXZpY2VfaWQ6IHNjaGVtYS5zdHJpbmcoKSxcbiAgICAgICAgICBkZXZpY2VfbmFtZTogc2NoZW1hLm1heWJlKHNjaGVtYS5zdHJpbmcoKSksXG4gICAgICAgICAgYWN0aW9uOiBzY2hlbWEuc3RyaW5nKCksXG4gICAgICAgIH0pLFxuICAgICAgfSxcbiAgICB9LFxuICAgIGFzeW5jIChjb250ZXh0LCByZXEsIHJlcykgPT4ge1xuICAgICAgY29uc3QgeyBpbnR1bmVfZGV2aWNlX2lkLCBkZXZpY2VfbmFtZSwgYWN0aW9uIH0gPSByZXEuYm9keSBhcyBhbnk7XG4gICAgICBjb25zdCBvdHBBY3Rpb24gPSBWQUxJRF9PVFBfQUNUSU9OUy5pbmNsdWRlcyhhY3Rpb24pID8gYWN0aW9uIDogbnVsbDtcbiAgICAgIGlmICghaW50dW5lX2RldmljZV9pZCB8fCAhb3RwQWN0aW9uKSB7XG4gICAgICAgIHJldHVybiByZXMuYmFkUmVxdWVzdCh7XG4gICAgICAgICAgYm9keTogeyBzdWNjZXNzOiBmYWxzZSwgbWVzc2FnZTogYGFjdGlvbiBtdXN0IGJlIG9uZSBvZjogJHtWQUxJRF9PVFBfQUNUSU9OUy5qb2luKCcsICcpfWAgfSxcbiAgICAgICAgfSk7XG4gICAgICB9XG4gICAgICBjb25zdCBvdHAgPSBnZW5lcmF0ZU9UUCgpO1xuICAgICAgc3RvcmVPVFAoaW50dW5lX2RldmljZV9pZCwgb3RwQWN0aW9uLCBvdHApO1xuICAgICAgY29uc3QgZW1haWxSZXN1bHQgPSBhd2FpdCBzZW5kT1RQRW1haWwoXG4gICAgICAgIGdldE9UUENvbmZpZygpLFxuICAgICAgICBvdHAsXG4gICAgICAgIGRldmljZV9uYW1lIHx8IGludHVuZV9kZXZpY2VfaWQsXG4gICAgICAgIG90cEFjdGlvblxuICAgICAgKTtcbiAgICAgIHJldHVybiByZXMub2soe1xuICAgICAgICBib2R5OiB7XG4gICAgICAgICAgc3VjY2VzczogdHJ1ZSxcbiAgICAgICAgICBtZXNzYWdlOiBlbWFpbFJlc3VsdC5kZXZNb2RlXG4gICAgICAgICAgICA/ICdERVYgTU9ERTogT1RQIGxvZ2dlZCB0byBzZXJ2ZXIgY29uc29sZSAoU01UUCBub3QgY29uZmlndXJlZCknXG4gICAgICAgICAgICA6IGBPVFAgc2VudCB0byAke2VtYWlsUmVzdWx0LnJlY2lwaWVudH1gLFxuICAgICAgICAgIGRldl9tb2RlOiBlbWFpbFJlc3VsdC5kZXZNb2RlIHx8IGZhbHNlLFxuICAgICAgICAgIC4uLihlbWFpbFJlc3VsdC5kZXZNb2RlID8geyBvdHAgfSA6IHt9KSxcbiAgICAgICAgfSxcbiAgICAgIH0pO1xuICAgIH1cbiAgKTtcblxuICAvLyDilIDilIAgREVTVFJVQ1RJVkU6IFJldGlyZSDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIBcbiAgcm91dGVyLnBvc3QoXG4gICAge1xuICAgICAgcGF0aDogJy9hcGkvaW50dW5lX3BsdWdpbi9hY3Rpb25zL3JldGlyZS1kZXZpY2UnLFxuICAgICAgdmFsaWRhdGU6IHtcbiAgICAgICAgYm9keTogc2NoZW1hLm9iamVjdCh7XG4gICAgICAgICAgaW50dW5lX2RldmljZV9pZDogc2NoZW1hLnN0cmluZygpLFxuICAgICAgICAgIGRldmljZV9uYW1lOiBzY2hlbWEubWF5YmUoc2NoZW1hLnN0cmluZygpKSxcbiAgICAgICAgICBvdHA6IHNjaGVtYS5zdHJpbmcoKSxcbiAgICAgICAgfSksXG4gICAgICB9LFxuICAgIH0sXG4gICAgYXN5bmMgKGNvbnRleHQsIHJlcSwgcmVzKSA9PiB7XG4gICAgICBjb25zdCBjb25maWcgPSBnZXRHcmFwaENvbmZpZygpO1xuICAgICAgaWYgKCFjb25maWcpIHtcbiAgICAgICAgcmV0dXJuIHJlcy5jdXN0b21FcnJvcih7IHN0YXR1c0NvZGU6IDUwMywgYm9keTogJ0ludHVuZSBjcmVkZW50aWFscyBub3QgY29uZmlndXJlZC4nIH0pO1xuICAgICAgfVxuICAgICAgY29uc3QgeyB1c2VyIH0gPSBnZXRVc2VyRnJvbVJlcXVlc3QocmVxKTtcbiAgICAgIGNvbnN0IHsgaW50dW5lX2RldmljZV9pZCwgZGV2aWNlX25hbWUsIG90cCB9ID0gcmVxLmJvZHkgYXMgYW55O1xuICAgICAgY29uc3QgdmFsaWRhdGlvbiA9IHZhbGlkYXRlT1RQKGludHVuZV9kZXZpY2VfaWQsICdyZXRpcmUnLCBvdHApO1xuICAgICAgaWYgKCF2YWxpZGF0aW9uLnZhbGlkKSB7XG4gICAgICAgIHJldHVybiByZXMuZm9yYmlkZGVuKHsgYm9keTogeyBzdWNjZXNzOiBmYWxzZSwgbWVzc2FnZTogdmFsaWRhdGlvbi5yZWFzb24gfSB9KTtcbiAgICAgIH1cbiAgICAgIGNvbnN0IGNsaWVudCA9IGNvbnRleHQuY29yZS5vcGVuc2VhcmNoLmNsaWVudC5hc0N1cnJlbnRVc2VyO1xuICAgICAgdHJ5IHtcbiAgICAgICAgY29uc3QgcmVzdWx0ID0gYXdhaXQgcmV0aXJlRGV2aWNlKGNvbmZpZywgaW50dW5lX2RldmljZV9pZCk7XG4gICAgICAgIGF3YWl0IHdyaXRlQXVkaXRMb2coY2xpZW50LCB7XG4gICAgICAgICAgYWN0aW9uOiAncmV0aXJlX2RldmljZScsXG4gICAgICAgICAgaW50dW5lX2RldmljZV9pZCxcbiAgICAgICAgICBkZXZpY2VfbmFtZTogZGV2aWNlX25hbWUgfHwgJycsXG4gICAgICAgICAgcGVyZm9ybWVkX2J5OiB1c2VyLFxuICAgICAgICAgIHJvbGU6IChyZXEgYXMgYW55KS5oZWFkZXJzPy5bJ3gtaW50dW5lLXJvbGUnXSB8fCAnaW50dW5lX29wZXJhdG9yJyxcbiAgICAgICAgICBzdGF0dXM6ICdzdWNjZXNzJyxcbiAgICAgICAgICBtZXNzYWdlOiByZXN1bHQubWVzc2FnZSxcbiAgICAgICAgICBzb3VyY2VfaXA6IChyZXEgYXMgYW55KS5pbmZvPy5yZW1vdGVBZGRyZXNzLFxuICAgICAgICB9KTtcbiAgICAgICAgcmV0dXJuIHJlcy5vayh7IGJvZHk6IHsgLi4ucmVzdWx0LCBhY3Rpb246ICdyZXRpcmVfZGV2aWNlJywgaW50dW5lX2RldmljZV9pZCwgdGltZXN0YW1wOiBuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCkgfSB9KTtcbiAgICAgIH0gY2F0Y2ggKGVycjogYW55KSB7XG4gICAgICAgIHJldHVybiByZXMuY3VzdG9tRXJyb3IoeyBzdGF0dXNDb2RlOiBlcnI/LnJlc3BvbnNlPy5zdGF0dXMgfHwgNTAwLCBib2R5OiBlcnI/Lm1lc3NhZ2UgPz8gU3RyaW5nKGVycikgfSk7XG4gICAgICB9XG4gICAgfVxuICApO1xuXG4gIHJvdXRlci5wb3N0KFxuICAgIHtcbiAgICAgIHBhdGg6ICcvYXBpL2ludHVuZV9wbHVnaW4vYWN0aW9ucy93aXBlLWRldmljZScsXG4gICAgICB2YWxpZGF0ZToge1xuICAgICAgICBib2R5OiBzY2hlbWEub2JqZWN0KHtcbiAgICAgICAgICBpbnR1bmVfZGV2aWNlX2lkOiBzY2hlbWEuc3RyaW5nKCksXG4gICAgICAgICAgZGV2aWNlX25hbWU6IHNjaGVtYS5tYXliZShzY2hlbWEuc3RyaW5nKCkpLFxuICAgICAgICAgIG90cDogc2NoZW1hLnN0cmluZygpLFxuICAgICAgICAgIGtlZXBfZW5yb2xsbWVudF9kYXRhOiBzY2hlbWEubWF5YmUoc2NoZW1hLmJvb2xlYW4oKSksXG4gICAgICAgICAga2VlcF91c2VyX2RhdGE6IHNjaGVtYS5tYXliZShzY2hlbWEuYm9vbGVhbigpKSxcbiAgICAgICAgfSksXG4gICAgICB9LFxuICAgIH0sXG4gICAgYXN5bmMgKGNvbnRleHQsIHJlcSwgcmVzKSA9PiB7XG4gICAgICBjb25zdCBjb25maWcgPSBnZXRHcmFwaENvbmZpZygpO1xuICAgICAgaWYgKCFjb25maWcpIHtcbiAgICAgICAgcmV0dXJuIHJlcy5jdXN0b21FcnJvcih7IHN0YXR1c0NvZGU6IDUwMywgYm9keTogJ0ludHVuZSBjcmVkZW50aWFscyBub3QgY29uZmlndXJlZC4nIH0pO1xuICAgICAgfVxuICAgICAgY29uc3QgeyB1c2VyIH0gPSBnZXRVc2VyRnJvbVJlcXVlc3QocmVxKTtcbiAgICAgIGNvbnN0IHsgaW50dW5lX2RldmljZV9pZCwgZGV2aWNlX25hbWUsIG90cCwga2VlcF9lbnJvbGxtZW50X2RhdGEsIGtlZXBfdXNlcl9kYXRhIH0gPSByZXEuYm9keSBhcyBhbnk7XG4gICAgICBjb25zdCB2YWxpZGF0aW9uID0gdmFsaWRhdGVPVFAoaW50dW5lX2RldmljZV9pZCwgJ3dpcGUnLCBvdHApO1xuICAgICAgaWYgKCF2YWxpZGF0aW9uLnZhbGlkKSB7XG4gICAgICAgIHJldHVybiByZXMuZm9yYmlkZGVuKHsgYm9keTogeyBzdWNjZXNzOiBmYWxzZSwgbWVzc2FnZTogdmFsaWRhdGlvbi5yZWFzb24gfSB9KTtcbiAgICAgIH1cbiAgICAgIGNvbnN0IGNsaWVudCA9IGNvbnRleHQuY29yZS5vcGVuc2VhcmNoLmNsaWVudC5hc0N1cnJlbnRVc2VyO1xuICAgICAgdHJ5IHtcbiAgICAgICAgY29uc3QgcmVzdWx0ID0gYXdhaXQgd2lwZURldmljZShjb25maWcsIGludHVuZV9kZXZpY2VfaWQsIGtlZXBfZW5yb2xsbWVudF9kYXRhLCBrZWVwX3VzZXJfZGF0YSk7XG4gICAgICAgIGF3YWl0IHdyaXRlQXVkaXRMb2coY2xpZW50LCB7XG4gICAgICAgICAgYWN0aW9uOiAnd2lwZV9kZXZpY2UnLFxuICAgICAgICAgIGludHVuZV9kZXZpY2VfaWQsXG4gICAgICAgICAgZGV2aWNlX25hbWU6IGRldmljZV9uYW1lIHx8ICcnLFxuICAgICAgICAgIHBlcmZvcm1lZF9ieTogdXNlcixcbiAgICAgICAgICByb2xlOiAocmVxIGFzIGFueSkuaGVhZGVycz8uWyd4LWludHVuZS1yb2xlJ10gfHwgJ2ludHVuZV9vcGVyYXRvcicsXG4gICAgICAgICAgc3RhdHVzOiAnc3VjY2VzcycsXG4gICAgICAgICAgbWVzc2FnZTogcmVzdWx0Lm1lc3NhZ2UsXG4gICAgICAgICAgc291cmNlX2lwOiAocmVxIGFzIGFueSkuaW5mbz8ucmVtb3RlQWRkcmVzcyxcbiAgICAgICAgfSk7XG4gICAgICAgIHJldHVybiByZXMub2soeyBib2R5OiB7IC4uLnJlc3VsdCwgYWN0aW9uOiAnd2lwZV9kZXZpY2UnLCBpbnR1bmVfZGV2aWNlX2lkLCB0aW1lc3RhbXA6IG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKSB9IH0pO1xuICAgICAgfSBjYXRjaCAoZXJyOiBhbnkpIHtcbiAgICAgICAgcmV0dXJuIHJlcy5jdXN0b21FcnJvcih7IHN0YXR1c0NvZGU6IGVycj8ucmVzcG9uc2U/LnN0YXR1cyB8fCA1MDAsIGJvZHk6IGVycj8ubWVzc2FnZSA/PyBTdHJpbmcoZXJyKSB9KTtcbiAgICAgIH1cbiAgICB9XG4gICk7XG5cbiAgcm91dGVyLnBvc3QoXG4gICAge1xuICAgICAgcGF0aDogJy9hcGkvaW50dW5lX3BsdWdpbi9hY3Rpb25zL2ZhY3RvcnktcmVzZXQnLFxuICAgICAgdmFsaWRhdGU6IHtcbiAgICAgICAgYm9keTogc2NoZW1hLm9iamVjdCh7XG4gICAgICAgICAgaW50dW5lX2RldmljZV9pZDogc2NoZW1hLnN0cmluZygpLFxuICAgICAgICAgIGRldmljZV9uYW1lOiBzY2hlbWEubWF5YmUoc2NoZW1hLnN0cmluZygpKSxcbiAgICAgICAgICBvdHA6IHNjaGVtYS5zdHJpbmcoKSxcbiAgICAgICAgfSksXG4gICAgICB9LFxuICAgIH0sXG4gICAgYXN5bmMgKGNvbnRleHQsIHJlcSwgcmVzKSA9PiB7XG4gICAgICBjb25zdCBjb25maWcgPSBnZXRHcmFwaENvbmZpZygpO1xuICAgICAgaWYgKCFjb25maWcpIHtcbiAgICAgICAgcmV0dXJuIHJlcy5jdXN0b21FcnJvcih7IHN0YXR1c0NvZGU6IDUwMywgYm9keTogJ0ludHVuZSBjcmVkZW50aWFscyBub3QgY29uZmlndXJlZC4nIH0pO1xuICAgICAgfVxuICAgICAgY29uc3QgeyB1c2VyIH0gPSBnZXRVc2VyRnJvbVJlcXVlc3QocmVxKTtcbiAgICAgIGNvbnN0IHsgaW50dW5lX2RldmljZV9pZCwgZGV2aWNlX25hbWUsIG90cCB9ID0gcmVxLmJvZHkgYXMgYW55O1xuICAgICAgY29uc3QgdmFsaWRhdGlvbiA9IHZhbGlkYXRlT1RQKGludHVuZV9kZXZpY2VfaWQsICdmYWN0b3J5X3Jlc2V0Jywgb3RwKTtcbiAgICAgIGlmICghdmFsaWRhdGlvbi52YWxpZCkge1xuICAgICAgICByZXR1cm4gcmVzLmZvcmJpZGRlbih7IGJvZHk6IHsgc3VjY2VzczogZmFsc2UsIG1lc3NhZ2U6IHZhbGlkYXRpb24ucmVhc29uIH0gfSk7XG4gICAgICB9XG4gICAgICBjb25zdCBjbGllbnQgPSBjb250ZXh0LmNvcmUub3BlbnNlYXJjaC5jbGllbnQuYXNDdXJyZW50VXNlcjtcbiAgICAgIHRyeSB7XG4gICAgICAgIGNvbnN0IHJlc3VsdCA9IGF3YWl0IGZhY3RvcnlSZXNldERldmljZShjb25maWcsIGludHVuZV9kZXZpY2VfaWQpO1xuICAgICAgICBhd2FpdCB3cml0ZUF1ZGl0TG9nKGNsaWVudCwge1xuICAgICAgICAgIGFjdGlvbjogJ2ZhY3RvcnlfcmVzZXQnLFxuICAgICAgICAgIGludHVuZV9kZXZpY2VfaWQsXG4gICAgICAgICAgZGV2aWNlX25hbWU6IGRldmljZV9uYW1lIHx8ICcnLFxuICAgICAgICAgIHBlcmZvcm1lZF9ieTogdXNlcixcbiAgICAgICAgICByb2xlOiAocmVxIGFzIGFueSkuaGVhZGVycz8uWyd4LWludHVuZS1yb2xlJ10gfHwgJ2ludHVuZV9vcGVyYXRvcicsXG4gICAgICAgICAgc3RhdHVzOiAnc3VjY2VzcycsXG4gICAgICAgICAgbWVzc2FnZTogcmVzdWx0Lm1lc3NhZ2UsXG4gICAgICAgICAgc291cmNlX2lwOiAocmVxIGFzIGFueSkuaW5mbz8ucmVtb3RlQWRkcmVzcyxcbiAgICAgICAgfSk7XG4gICAgICAgIHJldHVybiByZXMub2soeyBib2R5OiB7IC4uLnJlc3VsdCwgYWN0aW9uOiAnZmFjdG9yeV9yZXNldCcsIGludHVuZV9kZXZpY2VfaWQsIHRpbWVzdGFtcDogbmV3IERhdGUoKS50b0lTT1N0cmluZygpIH0gfSk7XG4gICAgICB9IGNhdGNoIChlcnI6IGFueSkge1xuICAgICAgICByZXR1cm4gcmVzLmN1c3RvbUVycm9yKHsgc3RhdHVzQ29kZTogZXJyPy5yZXNwb25zZT8uc3RhdHVzIHx8IDUwMCwgYm9keTogZXJyPy5tZXNzYWdlID8/IFN0cmluZyhlcnIpIH0pO1xuICAgICAgfVxuICAgIH1cbiAgKTtcblxuICAvLyDilIDilIAgQXVkaXQgbG9nIChHRVQpIOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgFxuICByb3V0ZXIuZ2V0KFxuICAgIHtcbiAgICAgIHBhdGg6ICcvYXBpL2ludHVuZV9wbHVnaW4vYWN0aW9ucy9hdWRpdC1sb2cnLFxuICAgICAgdmFsaWRhdGU6IHsgcXVlcnk6IHNjaGVtYS5vYmplY3QoeyBzaXplOiBzY2hlbWEubWF5YmUoc2NoZW1hLnN0cmluZygpKSB9KSB9LFxuICAgIH0sXG4gICAgYXN5bmMgKGNvbnRleHQsIHJlcSwgcmVzKSA9PiB7XG4gICAgICB0cnkge1xuICAgICAgICBjb25zdCBjbGllbnQgPSBjb250ZXh0LmNvcmUub3BlbnNlYXJjaC5jbGllbnQuYXNDdXJyZW50VXNlcjtcbiAgICAgICAgY29uc3Qgc2l6ZSA9IE1hdGgubWluKDUwMCwgcGFyc2VJbnQoKHJlcS5xdWVyeSBhcyBhbnkpLnNpemUgfHwgJzUwJywgMTApIHx8IDUwKTtcbiAgICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBjbGllbnQuc2VhcmNoKHtcbiAgICAgICAgICBpbmRleDogSU5UVU5FX0FVRElUX0xPR19JTkRFWCxcbiAgICAgICAgICBpZ25vcmVfdW5hdmFpbGFibGU6IHRydWUsXG4gICAgICAgICAgYm9keToge1xuICAgICAgICAgICAgc2l6ZSxcbiAgICAgICAgICAgIHNvcnQ6IFt7IHRpbWVzdGFtcDogeyBvcmRlcjogJ2Rlc2MnLCBtaXNzaW5nOiAnX2xhc3QnIH0gfV0sXG4gICAgICAgICAgICBxdWVyeTogeyBtYXRjaF9hbGw6IHt9IH0sXG4gICAgICAgICAgfSxcbiAgICAgICAgfSk7XG4gICAgICAgIGNvbnN0IGhpdHMgPSAocmVzcG9uc2UuYm9keSBhcyBhbnkpPy5oaXRzPy5oaXRzID8/IFtdO1xuICAgICAgICBjb25zdCBsb2dzID0gaGl0cy5tYXAoKGg6IGFueSkgPT4gaC5fc291cmNlKS5maWx0ZXIoQm9vbGVhbik7XG4gICAgICAgIHJldHVybiByZXMub2soeyBib2R5OiB7IHN1Y2Nlc3M6IHRydWUsIGxvZ3MsIHRvdGFsOiBsb2dzLmxlbmd0aCB9IH0pO1xuICAgICAgfSBjYXRjaCAoZXJyOiBhbnkpIHtcbiAgICAgICAgcmV0dXJuIHJlcy5jdXN0b21FcnJvcih7IHN0YXR1c0NvZGU6IDUwMCwgYm9keTogZXJyPy5tZXNzYWdlID8/IFN0cmluZyhlcnIpIH0pO1xuICAgICAgfVxuICAgIH1cbiAgKTtcblxuICAvLyDilIDilIAgV2F6dWggQWdlbnQgRGVwbG95bWVudCDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIBcbiAgcm91dGVyLnBvc3QoXG4gICAge1xuICAgICAgcGF0aDogJy9hcGkvaW50dW5lX3BsdWdpbi9hY3Rpb25zL2RlcGxveS13YXp1aCcsXG4gICAgICB2YWxpZGF0ZToge1xuICAgICAgICBib2R5OiBzY2hlbWEub2JqZWN0KHtcbiAgICAgICAgICBwbGF0Zm9ybTogc2NoZW1hLm9uZU9mKFtzY2hlbWEubGl0ZXJhbCgnd2luZG93cycpLCBzY2hlbWEubGl0ZXJhbCgnbWFjb3MnKV0pLFxuICAgICAgICAgIGFwaV9lbmRwb2ludDogc2NoZW1hLnN0cmluZygpLFxuICAgICAgICAgIGFwaV91c2VybmFtZTogc2NoZW1hLnN0cmluZygpLFxuICAgICAgICAgIGFwaV9wYXNzd29yZDogc2NoZW1hLnN0cmluZygpLFxuICAgICAgICAgIGVuYWJsZV95YXJhOiBzY2hlbWEuYm9vbGVhbigpLFxuICAgICAgICAgIHRhcmdldDogc2NoZW1hLm9uZU9mKFtzY2hlbWEubGl0ZXJhbCgnYWxsJyksIHNjaGVtYS5saXRlcmFsKCdzZWxlY3RlZCcpXSksXG4gICAgICAgICAgZGV2aWNlX2lkczogc2NoZW1hLm1heWJlKHNjaGVtYS5hcnJheU9mKHNjaGVtYS5zdHJpbmcoKSkpLFxuICAgICAgICB9KSxcbiAgICAgIH0sXG4gICAgfSxcbiAgICBhc3luYyAoY29udGV4dCwgcmVxLCByZXMpID0+IHtcbiAgICAgIGNvbnN0IGNvbmZpZyA9IGdldEdyYXBoQ29uZmlnKCk7XG4gICAgICBpZiAoIWNvbmZpZykge1xuICAgICAgICByZXR1cm4gcmVzLmN1c3RvbUVycm9yKHtcbiAgICAgICAgICBzdGF0dXNDb2RlOiA1MDMsXG4gICAgICAgICAgYm9keTogJ0ludHVuZSBjcmVkZW50aWFscyBub3QgY29uZmlndXJlZC4nLFxuICAgICAgICB9KTtcbiAgICAgIH1cbiAgICAgIGNvbnN0IHsgdXNlciB9ID0gZ2V0VXNlckZyb21SZXF1ZXN0KHJlcSk7XG4gICAgICBjb25zdCBjbGllbnQgPSBjb250ZXh0LmNvcmUub3BlbnNlYXJjaC5jbGllbnQuYXNDdXJyZW50VXNlcjtcbiAgICAgIGNvbnN0IHtcbiAgICAgICAgcGxhdGZvcm0sXG4gICAgICAgIGFwaV9lbmRwb2ludCxcbiAgICAgICAgYXBpX3VzZXJuYW1lLFxuICAgICAgICBhcGlfcGFzc3dvcmQsXG4gICAgICAgIGVuYWJsZV95YXJhLFxuICAgICAgICB0YXJnZXQsXG4gICAgICAgIGRldmljZV9pZHMsXG4gICAgICB9ID0gcmVxLmJvZHkgYXMgYW55O1xuXG4gICAgICB0cnkge1xuICAgICAgICAvLyAxLiBSZWFkIHRoZSB0ZW1wbGF0ZSBzY3JpcHQgKHB1YmxpYy9hc3NldHMvIHJlbGF0aXZlIHRvIHBsdWdpbiByb290KVxuICAgICAgICBjb25zdCB0ZW1wbGF0ZURpciA9IHBhdGgucmVzb2x2ZShfX2Rpcm5hbWUsICcuLicsICcuLicsICdwdWJsaWMnLCAnYXNzZXRzJyk7XG4gICAgICAgIGNvbnN0IHRlbXBsYXRlRmlsZSA9XG4gICAgICAgICAgcGxhdGZvcm0gPT09ICd3aW5kb3dzJ1xuICAgICAgICAgICAgPyAnd2F6dWgtZGVwbG95LXdpbmRvd3MucHMxLnRlbXBsYXRlJ1xuICAgICAgICAgICAgOiAnd2F6dWgtZGVwbG95LW1hY29zLnNoLnRlbXBsYXRlJztcbiAgICAgICAgY29uc3QgdGVtcGxhdGVQYXRoID0gcGF0aC5qb2luKHRlbXBsYXRlRGlyLCB0ZW1wbGF0ZUZpbGUpO1xuXG4gICAgICAgIGlmICghZnMuZXhpc3RzU3luYyh0ZW1wbGF0ZVBhdGgpKSB7XG4gICAgICAgICAgcmV0dXJuIHJlcy5jdXN0b21FcnJvcih7XG4gICAgICAgICAgICBzdGF0dXNDb2RlOiA1MDAsXG4gICAgICAgICAgICBib2R5OiBgVGVtcGxhdGUgbm90IGZvdW5kOiAke3RlbXBsYXRlRmlsZX1gLFxuICAgICAgICAgIH0pO1xuICAgICAgICB9XG4gICAgICAgIGxldCBzY3JpcHRDb250ZW50ID0gZnMucmVhZEZpbGVTeW5jKHRlbXBsYXRlUGF0aCwgJ3V0Zi04Jyk7XG5cbiAgICAgICAgLy8gMi4gUGF0Y2ggdGhlIHNjcmlwdCB3aXRoIHVzZXIncyBjb25maWdcbiAgICAgICAgaWYgKHBsYXRmb3JtID09PSAnd2luZG93cycpIHtcbiAgICAgICAgICBzY3JpcHRDb250ZW50ID0gc2NyaXB0Q29udGVudC5yZXBsYWNlKFxuICAgICAgICAgICAgL1xcJEFQSV9FTkRQT0lOVFxccyo9XFxzKlwiW15cIl0qXCIvLFxuICAgICAgICAgICAgYCRBUElfRU5EUE9JTlQgPSBcIiR7YXBpX2VuZHBvaW50fVwiYFxuICAgICAgICAgICk7XG4gICAgICAgICAgc2NyaXB0Q29udGVudCA9IHNjcmlwdENvbnRlbnQucmVwbGFjZShcbiAgICAgICAgICAgIC9cXCRBUElfVVNFUk5BTUVcXHMqPVxccypcIlteXCJdKlwiLyxcbiAgICAgICAgICAgIGAkQVBJX1VTRVJOQU1FID0gXCIke2FwaV91c2VybmFtZX1cImBcbiAgICAgICAgICApO1xuICAgICAgICAgIC8vIFNldCBkZWZhdWx0cyBmb3Igc2lsZW50IEludHVuZSBleGVjdXRpb25cbiAgICAgICAgICBzY3JpcHRDb250ZW50ID0gc2NyaXB0Q29udGVudC5yZXBsYWNlKFxuICAgICAgICAgICAgL3BhcmFtXFwoXFxzKlxcblxccypcXFtzdHJpbmdcXF1cXCRBcGlQYXNzd29yZFxccyo9XFxzKlwiXCIvLFxuICAgICAgICAgICAgYHBhcmFtKFxcbiAgICBbc3RyaW5nXSRBcGlQYXNzd29yZCA9IFwiJHthcGlfcGFzc3dvcmR9XCJgXG4gICAgICAgICAgKTtcbiAgICAgICAgICBzY3JpcHRDb250ZW50ID0gc2NyaXB0Q29udGVudC5yZXBsYWNlKFxuICAgICAgICAgICAgL1xcW3N0cmluZ1xcXVxcJEFnZW50TmFtZVxccyo9XFxzKlwiXCIvLFxuICAgICAgICAgICAgYFtzdHJpbmddJEFnZW50TmFtZSA9IFwiJGVudjpDT01QVVRFUk5BTUVcImBcbiAgICAgICAgICApO1xuICAgICAgICAgIHNjcmlwdENvbnRlbnQgPSBzY3JpcHRDb250ZW50LnJlcGxhY2UoXG4gICAgICAgICAgICAvXFxbc3RyaW5nXFxdXFwkRXhpc3RpbmdBZ2VudEFjdGlvblxccyo9XFxzKlwiYXNrXCIvLFxuICAgICAgICAgICAgYFtzdHJpbmddJEV4aXN0aW5nQWdlbnRBY3Rpb24gPSBcInJlcGxhY2VcImBcbiAgICAgICAgICApO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgIC8vIG1hY09TIHNoZWxsXG4gICAgICAgICAgc2NyaXB0Q29udGVudCA9IHNjcmlwdENvbnRlbnQucmVwbGFjZShcbiAgICAgICAgICAgIC9BUElfRU5EUE9JTlQ9XCJbXlwiXSpcIi8sXG4gICAgICAgICAgICBgQVBJX0VORFBPSU5UPVwiJHthcGlfZW5kcG9pbnR9XCJgXG4gICAgICAgICAgKTtcbiAgICAgICAgICBzY3JpcHRDb250ZW50ID0gc2NyaXB0Q29udGVudC5yZXBsYWNlKFxuICAgICAgICAgICAgL0FQSV9VU0VSTkFNRT1cIlteXCJdKlwiLyxcbiAgICAgICAgICAgIGBBUElfVVNFUk5BTUU9XCIke2FwaV91c2VybmFtZX1cImBcbiAgICAgICAgICApO1xuICAgICAgICAgIHNjcmlwdENvbnRlbnQgPSBzY3JpcHRDb250ZW50LnJlcGxhY2UoXG4gICAgICAgICAgICAvQVBJX1BBU1NXT1JEPVwiXCIvLFxuICAgICAgICAgICAgYEFQSV9QQVNTV09SRD1cIiR7YXBpX3Bhc3N3b3JkfVwiYFxuICAgICAgICAgICk7XG4gICAgICAgICAgLy8gUGF0Y2ggZGVmYXVsdHMgZm9yIG5vbi1pbnRlcmFjdGl2ZSBleGVjdXRpb25cbiAgICAgICAgICBzY3JpcHRDb250ZW50ID0gc2NyaXB0Q29udGVudC5yZXBsYWNlKFxuICAgICAgICAgICAgL2FnZW50TmFtZT1cIlwiL2csXG4gICAgICAgICAgICAnYWdlbnROYW1lPVwiJChob3N0bmFtZSAtcylcIidcbiAgICAgICAgICApO1xuICAgICAgICAgIHNjcmlwdENvbnRlbnQgPSBzY3JpcHRDb250ZW50LnJlcGxhY2UoXG4gICAgICAgICAgICAvZXhpc3RpbmdBZ2VudEFjdGlvbj1cImFza1wiLyxcbiAgICAgICAgICAgICdleGlzdGluZ0FnZW50QWN0aW9uPVwicmVwbGFjZVwiJ1xuICAgICAgICAgICk7XG4gICAgICAgICAgaWYgKCFlbmFibGVfeWFyYSkge1xuICAgICAgICAgICAgc2NyaXB0Q29udGVudCA9IHNjcmlwdENvbnRlbnQucmVwbGFjZShcbiAgICAgICAgICAgICAgL2VuYWJsZVlhcmE9XCJ5ZXNcIi8sXG4gICAgICAgICAgICAgICdlbmFibGVZYXJhPVwibm9cIidcbiAgICAgICAgICAgICk7XG4gICAgICAgICAgfVxuICAgICAgICB9XG5cbiAgICAgICAgLy8gMy4gQmFzZTY0IGVuY29kZVxuICAgICAgICBjb25zdCBzY3JpcHRCYXNlNjQgPSBCdWZmZXIuZnJvbShzY3JpcHRDb250ZW50LCAndXRmLTgnKS50b1N0cmluZygnYmFzZTY0Jyk7XG4gICAgICAgIGNvbnN0IHRzID0gbmV3IERhdGUoKS50b0lTT1N0cmluZygpLnJlcGxhY2UoL1s6Ll0vZywgJy0nKS5zbGljZSgwLCAxOSk7XG4gICAgICAgIGNvbnN0IGRpc3BsYXlOYW1lID0gYEF0aGVuYSBXYXp1aCBBZ2VudCAtICR7cGxhdGZvcm19IC0gJHt0c31gO1xuICAgICAgICBjb25zdCBkZXNjcmlwdGlvbiA9IGBXYXp1aCBhZ2VudCBkZXBsb3ltZW50IGZvciAke3BsYXRmb3JtfS4gQ3JlYXRlZCBieSBBdGhlbmEgSW50dW5lIHBsdWdpbiBvbiAke25ldyBEYXRlKCkudG9JU09TdHJpbmcoKX0uYDtcblxuICAgICAgICAvLyA0LiBVcGxvYWQgdG8gSW50dW5lXG4gICAgICAgIGxldCBzY3JpcHRSZXN1bHQ6IHsgaWQ6IHN0cmluZzsgZGlzcGxheU5hbWU6IHN0cmluZyB9O1xuICAgICAgICBpZiAocGxhdGZvcm0gPT09ICd3aW5kb3dzJykge1xuICAgICAgICAgIHNjcmlwdFJlc3VsdCA9IGF3YWl0IHVwbG9hZFBvd2VyU2hlbGxTY3JpcHQoXG4gICAgICAgICAgICBjb25maWcsXG4gICAgICAgICAgICBkaXNwbGF5TmFtZSxcbiAgICAgICAgICAgIHNjcmlwdEJhc2U2NCxcbiAgICAgICAgICAgIGRlc2NyaXB0aW9uXG4gICAgICAgICAgKTtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICBzY3JpcHRSZXN1bHQgPSBhd2FpdCB1cGxvYWRTaGVsbFNjcmlwdChcbiAgICAgICAgICAgIGNvbmZpZyxcbiAgICAgICAgICAgIGRpc3BsYXlOYW1lLFxuICAgICAgICAgICAgc2NyaXB0QmFzZTY0LFxuICAgICAgICAgICAgZGVzY3JpcHRpb25cbiAgICAgICAgICApO1xuICAgICAgICB9XG5cbiAgICAgICAgLy8gNS4gQXNzaWduIHRvIHRhcmdldFxuICAgICAgICBsZXQgZ3JvdXBJZCA9ICdhbGwnO1xuICAgICAgICBsZXQgZ3JvdXBOYW1lID0gJ0FsbCBEZXZpY2VzJztcbiAgICAgICAgaWYgKHRhcmdldCA9PT0gJ3NlbGVjdGVkJyAmJiBkZXZpY2VfaWRzICYmIGRldmljZV9pZHMubGVuZ3RoID4gMCkge1xuICAgICAgICAgIHRyeSB7XG4gICAgICAgICAgICBjb25zdCByZXNvbHZlZCA9IGF3YWl0IHJlc29sdmVBenVyZUFkRGV2aWNlT2JqZWN0SWRzKGNvbmZpZywgZGV2aWNlX2lkcyk7XG4gICAgICAgICAgICBpZiAocmVzb2x2ZWQubGVuZ3RoID09PSAwKSB7XG4gICAgICAgICAgICAgIHJldHVybiByZXMuY3VzdG9tRXJyb3Ioe1xuICAgICAgICAgICAgICAgIHN0YXR1c0NvZGU6IDQwMCxcbiAgICAgICAgICAgICAgICBib2R5OiAnQ291bGQgbm90IHJlc29sdmUgYW55IHNlbGVjdGVkIGRldmljZXMgdG8gQXp1cmUgQUQgb2JqZWN0cy4gRW5zdXJlIGRldmljZXMgYXJlIEF6dXJlIEFEIGpvaW5lZC4nLFxuICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGdyb3VwTmFtZSA9IGBBdGhlbmEgV2F6dWggRGVwbG95ICR7cGxhdGZvcm19ICR7dHN9YDtcbiAgICAgICAgICAgIGdyb3VwSWQgPSBhd2FpdCBjcmVhdGVTZWN1cml0eUdyb3VwKGNvbmZpZywgZ3JvdXBOYW1lKTtcbiAgICAgICAgICAgIGF3YWl0IGFkZERldmljZXNUb0dyb3VwKFxuICAgICAgICAgICAgICBjb25maWcsXG4gICAgICAgICAgICAgIGdyb3VwSWQsXG4gICAgICAgICAgICAgIHJlc29sdmVkLm1hcCgoZCkgPT4gZC5henVyZUFkT2JqZWN0SWQpXG4gICAgICAgICAgICApO1xuICAgICAgICAgIH0gY2F0Y2ggKGdyb3VwRXJyOiBhbnkpIHtcbiAgICAgICAgICAgIGlmIChcbiAgICAgICAgICAgICAgZ3JvdXBFcnIubWVzc2FnZT8uaW5jbHVkZXMoJ0F1dGhvcml6YXRpb24nKSB8fFxuICAgICAgICAgICAgICBncm91cEVyci5tZXNzYWdlPy5pbmNsdWRlcygnRm9yYmlkZGVuJykgfHxcbiAgICAgICAgICAgICAgZ3JvdXBFcnIubWVzc2FnZT8uaW5jbHVkZXMoJ0luc3VmZmljaWVudCBwcml2aWxlZ2VzJylcbiAgICAgICAgICAgICkge1xuICAgICAgICAgICAgICByZXR1cm4gcmVzLmN1c3RvbUVycm9yKHtcbiAgICAgICAgICAgICAgICBzdGF0dXNDb2RlOiA0MDMsXG4gICAgICAgICAgICAgICAgYm9keTogJ0dyb3VwLlJlYWRXcml0ZS5BbGwgcGVybWlzc2lvbiBpcyByZXF1aXJlZCBmb3IgcGVyLWRldmljZSB0YXJnZXRpbmcuIFVzZSBcIkFsbCBEZXZpY2VzXCIgaW5zdGVhZCwgb3IgYWRkIHRoZSBwZXJtaXNzaW9uIHRvIHlvdXIgQXp1cmUgQUQgYXBwLicsXG4gICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgdGhyb3cgZ3JvdXBFcnI7XG4gICAgICAgICAgfVxuICAgICAgICB9XG5cbiAgICAgICAgY29uc3Qgc2NyaXB0VHlwZSA9IHBsYXRmb3JtID09PSAnd2luZG93cycgPyAncG93ZXJzaGVsbCcgOiAnc2hlbGwnO1xuICAgICAgICBhd2FpdCBhc3NpZ25TY3JpcHQoY29uZmlnLCBzY3JpcHRSZXN1bHQuaWQsIHNjcmlwdFR5cGUsIGdyb3VwSWQpO1xuXG4gICAgICAgIC8vIDYuIEF1ZGl0IGxvZ1xuICAgICAgICBhd2FpdCB3cml0ZUF1ZGl0TG9nKGNsaWVudCwge1xuICAgICAgICAgIGFjdGlvbjogJ2RlcGxveV93YXp1aF9hZ2VudCcsXG4gICAgICAgICAgaW50dW5lX2RldmljZV9pZDogJycsXG4gICAgICAgICAgZGV2aWNlX25hbWU6IGAke3BsYXRmb3JtfSAoJHt0YXJnZXQgPT09ICdhbGwnID8gJ2FsbCBkZXZpY2VzJyA6IGAke2RldmljZV9pZHM/Lmxlbmd0aCA/PyAwfSBzZWxlY3RlZGB9KWAsXG4gICAgICAgICAgcGVyZm9ybWVkX2J5OiB1c2VyLFxuICAgICAgICAgIHJvbGU6IChyZXEgYXMgYW55KS5oZWFkZXJzPy5bJ3gtaW50dW5lLXJvbGUnXSB8fCAnaW50dW5lX29wZXJhdG9yJyxcbiAgICAgICAgICBzdGF0dXM6ICdzdWNjZXNzJyxcbiAgICAgICAgICBtZXNzYWdlOiBgV2F6dWggYWdlbnQgc2NyaXB0IHVwbG9hZGVkIGFuZCBhc3NpZ25lZDogJHtzY3JpcHRSZXN1bHQuZGlzcGxheU5hbWV9IOKGkiAke2dyb3VwTmFtZX1gLFxuICAgICAgICB9KTtcblxuICAgICAgICByZXR1cm4gcmVzLm9rKHtcbiAgICAgICAgICBib2R5OiB7XG4gICAgICAgICAgICBzdWNjZXNzOiB0cnVlLFxuICAgICAgICAgICAgYWN0aW9uOiAnZGVwbG95X3dhenVoX2FnZW50JyxcbiAgICAgICAgICAgIHNjcmlwdF9pZDogc2NyaXB0UmVzdWx0LmlkLFxuICAgICAgICAgICAgc2NyaXB0X25hbWU6IHNjcmlwdFJlc3VsdC5kaXNwbGF5TmFtZSxcbiAgICAgICAgICAgIGFzc2lnbmVkX3RvOiBncm91cE5hbWUsXG4gICAgICAgICAgICBwbGF0Zm9ybSxcbiAgICAgICAgICAgIHRpbWVzdGFtcDogbmV3IERhdGUoKS50b0lTT1N0cmluZygpLFxuICAgICAgICAgICAgbWVzc2FnZTogYFdhenVoIGFnZW50IGRlcGxveW1lbnQgc2NyaXB0IHVwbG9hZGVkIHRvIEludHVuZSBhbmQgYXNzaWduZWQgdG8gJHtncm91cE5hbWV9LiBEZXZpY2VzIHdpbGwgcmVjZWl2ZSB0aGUgc2NyaXB0IG9uIHRoZWlyIG5leHQgY2hlY2staW4uYCxcbiAgICAgICAgICB9LFxuICAgICAgICB9KTtcbiAgICAgIH0gY2F0Y2ggKGVycjogYW55KSB7XG4gICAgICAgIGF3YWl0IHdyaXRlQXVkaXRMb2coY2xpZW50LCB7XG4gICAgICAgICAgYWN0aW9uOiAnZGVwbG95X3dhenVoX2FnZW50JyxcbiAgICAgICAgICBpbnR1bmVfZGV2aWNlX2lkOiAnJyxcbiAgICAgICAgICBkZXZpY2VfbmFtZTogYCR7cGxhdGZvcm19ICgke3RhcmdldH0pYCxcbiAgICAgICAgICBwZXJmb3JtZWRfYnk6IHVzZXIsXG4gICAgICAgICAgcm9sZTogKHJlcSBhcyBhbnkpLmhlYWRlcnM/LlsneC1pbnR1bmUtcm9sZSddIHx8ICdpbnR1bmVfb3BlcmF0b3InLFxuICAgICAgICAgIHN0YXR1czogJ2ZhaWx1cmUnLFxuICAgICAgICAgIG1lc3NhZ2U6IGVycj8ubWVzc2FnZSA/PyBTdHJpbmcoZXJyKSxcbiAgICAgICAgfSk7XG4gICAgICAgIHJldHVybiByZXMuY3VzdG9tRXJyb3Ioe1xuICAgICAgICAgIHN0YXR1c0NvZGU6IGVycj8ucmVzcG9uc2U/LnN0YXR1cyB8fCA1MDAsXG4gICAgICAgICAgYm9keTogZXJyPy5tZXNzYWdlID8/IFN0cmluZyhlcnIpLFxuICAgICAgICB9KTtcbiAgICAgIH1cbiAgICB9XG4gICk7XG59XG4iXSwibWFwcGluZ3MiOiI7Ozs7OztBQVNBLElBQUFBLGFBQUEsR0FBQUMsT0FBQTtBQUNBLElBQUFDLFVBQUEsR0FBQUQsT0FBQTtBQUNBLElBQUFFLFlBQUEsR0FBQUYsT0FBQTtBQXdCQSxJQUFBRyxFQUFBLEdBQUFDLHVCQUFBLENBQUFKLE9BQUE7QUFDQSxJQUFBSyxJQUFBLEdBQUFELHVCQUFBLENBQUFKLE9BQUE7QUFDQSxJQUFBTSxJQUFBLEdBQUFOLE9BQUE7QUFBbUcsU0FBQU8seUJBQUFDLENBQUEsNkJBQUFDLE9BQUEsbUJBQUFDLENBQUEsT0FBQUQsT0FBQSxJQUFBRSxDQUFBLE9BQUFGLE9BQUEsWUFBQUYsd0JBQUEsWUFBQUEsQ0FBQUMsQ0FBQSxXQUFBQSxDQUFBLEdBQUFHLENBQUEsR0FBQUQsQ0FBQSxLQUFBRixDQUFBO0FBQUEsU0FBQUosd0JBQUFJLENBQUEsRUFBQUUsQ0FBQSxTQUFBQSxDQUFBLElBQUFGLENBQUEsSUFBQUEsQ0FBQSxDQUFBSSxVQUFBLFNBQUFKLENBQUEsZUFBQUEsQ0FBQSx1QkFBQUEsQ0FBQSx5QkFBQUEsQ0FBQSxXQUFBSyxPQUFBLEVBQUFMLENBQUEsUUFBQUcsQ0FBQSxHQUFBSix3QkFBQSxDQUFBRyxDQUFBLE9BQUFDLENBQUEsSUFBQUEsQ0FBQSxDQUFBRyxHQUFBLENBQUFOLENBQUEsVUFBQUcsQ0FBQSxDQUFBSSxHQUFBLENBQUFQLENBQUEsT0FBQVEsQ0FBQSxLQUFBQyxTQUFBLFVBQUFDLENBQUEsR0FBQUMsTUFBQSxDQUFBQyxjQUFBLElBQUFELE1BQUEsQ0FBQUUsd0JBQUEsV0FBQUMsQ0FBQSxJQUFBZCxDQUFBLG9CQUFBYyxDQUFBLE9BQUFDLGNBQUEsQ0FBQUMsSUFBQSxDQUFBaEIsQ0FBQSxFQUFBYyxDQUFBLFNBQUFHLENBQUEsR0FBQVAsQ0FBQSxHQUFBQyxNQUFBLENBQUFFLHdCQUFBLENBQUFiLENBQUEsRUFBQWMsQ0FBQSxVQUFBRyxDQUFBLEtBQUFBLENBQUEsQ0FBQVYsR0FBQSxJQUFBVSxDQUFBLENBQUFDLEdBQUEsSUFBQVAsTUFBQSxDQUFBQyxjQUFBLENBQUFKLENBQUEsRUFBQU0sQ0FBQSxFQUFBRyxDQUFBLElBQUFULENBQUEsQ0FBQU0sQ0FBQSxJQUFBZCxDQUFBLENBQUFjLENBQUEsWUFBQU4sQ0FBQSxDQUFBSCxPQUFBLEdBQUFMLENBQUEsRUFBQUcsQ0FBQSxJQUFBQSxDQUFBLENBQUFlLEdBQUEsQ0FBQWxCLENBQUEsRUFBQVEsQ0FBQSxHQUFBQSxDQUFBO0FBckNuRztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFpQ0EsU0FBU1csa0JBQWtCQSxDQUFDQyxHQUFRLEVBQWtDO0VBQUEsSUFBQUMsWUFBQSxFQUFBQyxhQUFBO0VBQ3BFLE1BQU1DLElBQUksR0FBRyxFQUFBRixZQUFBLEdBQUNELEdBQUcsQ0FBQ0ksT0FBTyxjQUFBSCxZQUFBLHVCQUFYQSxZQUFBLENBQWMsZUFBZSxDQUFDLEtBQWUsZ0JBQWdCO0VBQzNFLE1BQU1JLElBQUksR0FBRyxFQUFBSCxhQUFBLEdBQUNGLEdBQUcsQ0FBQ0ksT0FBTyxjQUFBRixhQUFBLHVCQUFYQSxhQUFBLENBQWMsZUFBZSxDQUFDLEtBQWUsaUJBQWlCO0VBQzVFLE9BQU87SUFBRUMsSUFBSTtJQUFFRTtFQUFLLENBQUM7QUFDdkI7QUFFQSxTQUFTQyxZQUFZQSxDQUFBLEVBQW1CO0VBQ3RDLE9BQU87SUFDTEMsUUFBUSxFQUFFQyxPQUFPLENBQUNDLEdBQUcsQ0FBQ0MsU0FBUztJQUMvQkMsUUFBUSxFQUFFSCxPQUFPLENBQUNDLEdBQUcsQ0FBQ0csU0FBUyxHQUFHQyxRQUFRLENBQUNMLE9BQU8sQ0FBQ0MsR0FBRyxDQUFDRyxTQUFTLEVBQUUsRUFBRSxDQUFDLEdBQUcsR0FBRztJQUMzRUUsUUFBUSxFQUFFTixPQUFPLENBQUNDLEdBQUcsQ0FBQ00sU0FBUztJQUMvQkMsUUFBUSxFQUFFUixPQUFPLENBQUNDLEdBQUcsQ0FBQ1EsU0FBUztJQUMvQkMsaUJBQWlCLEVBQUVWLE9BQU8sQ0FBQ0MsR0FBRyxDQUFDVSxtQkFBbUI7SUFDbERDLFVBQVUsRUFBRVosT0FBTyxDQUFDQyxHQUFHLENBQUNZLFdBQVcsS0FBSztFQUMxQyxDQUFDO0FBQ0g7QUFFQSxlQUFlQyxhQUFhQSxDQUMxQkMsTUFBVyxFQUNYQyxLQVNDLEVBQ0Q7RUFDQSxJQUFJO0lBQ0YsTUFBTUQsTUFBTSxDQUFDRSxLQUFLLENBQUM7TUFDakJBLEtBQUssRUFBRUMsaUNBQXNCO01BQzdCQyxJQUFJLEVBQUU7UUFBRSxHQUFHSCxLQUFLO1FBQUVJLFNBQVMsRUFBRSxJQUFJQyxJQUFJLENBQUMsQ0FBQyxDQUFDQyxXQUFXLENBQUM7TUFBRTtJQUN4RCxDQUFDLENBQUM7RUFDSixDQUFDLENBQUMsT0FBT0MsR0FBRyxFQUFFO0lBQ1pDLE9BQU8sQ0FBQ0MsS0FBSyxDQUFDLGtDQUFrQyxFQUFFRixHQUFHLENBQUM7RUFDeEQ7QUFDRjtBQUVBLFNBQVNHLGlCQUFpQkEsQ0FDeEJDLE1BQWUsRUFDZjFELElBQVksRUFDWjJELFVBQWtCLEVBQ2xCQyxVQUFlLEVBQ2ZDLEVBQXdHLEVBQ3hHO0VBQ0FILE1BQU0sQ0FBQ0ksSUFBSSxDQUNUO0lBQUU5RCxJQUFJO0lBQUUrRCxRQUFRLEVBQUU7TUFBRWIsSUFBSSxFQUFFVTtJQUFXO0VBQUUsQ0FBQyxFQUN4QyxPQUFPSSxPQUFPLEVBQUV6QyxHQUFHLEVBQUUwQyxHQUFHLEtBQUs7SUFDM0IsTUFBTUMsTUFBTSxHQUFHLElBQUFDLDJCQUFjLEVBQUMsQ0FBQztJQUMvQixJQUFJLENBQUNELE1BQU0sRUFBRTtNQUNYLE9BQU9ELEdBQUcsQ0FBQ0csV0FBVyxDQUFDO1FBQ3JCQyxVQUFVLEVBQUUsR0FBRztRQUNmbkIsSUFBSSxFQUFFO01BQ1IsQ0FBQyxDQUFDO0lBQ0o7SUFDQSxNQUFNO01BQUV4QjtJQUFLLENBQUMsR0FBR0osa0JBQWtCLENBQUNDLEdBQUcsQ0FBQztJQUN4QyxNQUFNdUIsTUFBTSxHQUFHa0IsT0FBTyxDQUFDTSxJQUFJLENBQUNDLFVBQVUsQ0FBQ3pCLE1BQU0sQ0FBQzBCLGFBQWE7SUFDM0QsTUFBTUMsUUFBUSxHQUFJbEQsR0FBRyxDQUFDMkIsSUFBSSxDQUFTd0IsZ0JBQWdCO0lBQ25ELE1BQU1DLFVBQVUsR0FBSXBELEdBQUcsQ0FBQzJCLElBQUksQ0FBUzBCLFdBQVcsSUFBSSxFQUFFO0lBQ3RELElBQUk7TUFBQSxJQUFBQyxRQUFBLEVBQUFDLEtBQUE7TUFDRixNQUFNQyxNQUFNLEdBQUcsTUFBTWxCLEVBQUUsQ0FBQ0ssTUFBTSxFQUFFM0MsR0FBRyxDQUFDMkIsSUFBSSxFQUFFeEIsSUFBSSxDQUFDO01BQy9DLE1BQU1tQixhQUFhLENBQUNDLE1BQU0sRUFBRTtRQUMxQmtDLE1BQU0sRUFBRXJCLFVBQVU7UUFDbEJlLGdCQUFnQixFQUFFRCxRQUFRLElBQUksRUFBRTtRQUNoQ0csV0FBVyxFQUFFRCxVQUFVO1FBQ3ZCTSxZQUFZLEVBQUV2RCxJQUFJO1FBQ2xCRSxJQUFJLEVBQUUsRUFBQWlELFFBQUEsR0FBQ3RELEdBQUcsQ0FBU0ksT0FBTyxjQUFBa0QsUUFBQSx1QkFBcEJBLFFBQUEsQ0FBdUIsZUFBZSxDQUFDLEtBQUksaUJBQWlCO1FBQ2xFSyxNQUFNLEVBQUUsU0FBUztRQUNqQkMsT0FBTyxFQUFFSixNQUFNLENBQUNJLE9BQU87UUFDdkJDLFNBQVMsR0FBQU4sS0FBQSxHQUFHdkQsR0FBRyxDQUFTOEQsSUFBSSxjQUFBUCxLQUFBLHVCQUFqQkEsS0FBQSxDQUFtQlE7TUFDaEMsQ0FBQyxDQUFDO01BQ0YsT0FBT3JCLEdBQUcsQ0FBQ3NCLEVBQUUsQ0FBQztRQUNackMsSUFBSSxFQUFFO1VBQUUsR0FBRzZCLE1BQU07VUFBRUMsTUFBTSxFQUFFckIsVUFBVTtVQUFFZSxnQkFBZ0IsRUFBRUQsUUFBUTtVQUFFdEIsU0FBUyxFQUFFLElBQUlDLElBQUksQ0FBQyxDQUFDLENBQUNDLFdBQVcsQ0FBQztRQUFFO01BQ3pHLENBQUMsQ0FBQztJQUNKLENBQUMsQ0FBQyxPQUFPQyxHQUFRLEVBQUU7TUFBQSxJQUFBa0MsU0FBQSxFQUFBQyxZQUFBLEVBQUFDLE1BQUEsRUFBQUMsU0FBQSxFQUFBQyxhQUFBO01BQ2pCLE1BQU0vQyxhQUFhLENBQUNDLE1BQU0sRUFBRTtRQUMxQmtDLE1BQU0sRUFBRXJCLFVBQVU7UUFDbEJlLGdCQUFnQixFQUFFRCxRQUFRLElBQUksRUFBRTtRQUNoQ0csV0FBVyxFQUFFRCxVQUFVO1FBQ3ZCTSxZQUFZLEVBQUV2RCxJQUFJO1FBQ2xCRSxJQUFJLEVBQUUsRUFBQTRELFNBQUEsR0FBQ2pFLEdBQUcsQ0FBU0ksT0FBTyxjQUFBNkQsU0FBQSx1QkFBcEJBLFNBQUEsQ0FBdUIsZUFBZSxDQUFDLEtBQUksaUJBQWlCO1FBQ2xFTixNQUFNLEVBQUUsU0FBUztRQUNqQkMsT0FBTyxHQUFBTSxZQUFBLEdBQUVuQyxHQUFHLGFBQUhBLEdBQUcsdUJBQUhBLEdBQUcsQ0FBRTZCLE9BQU8sY0FBQU0sWUFBQSxjQUFBQSxZQUFBLEdBQUlJLE1BQU0sQ0FBQ3ZDLEdBQUcsQ0FBQztRQUNwQzhCLFNBQVMsR0FBQU0sTUFBQSxHQUFHbkUsR0FBRyxDQUFTOEQsSUFBSSxjQUFBSyxNQUFBLHVCQUFqQkEsTUFBQSxDQUFtQko7TUFDaEMsQ0FBQyxDQUFDO01BQ0YsTUFBTUosTUFBTSxHQUFHLENBQUM1QixHQUFHLGFBQUhBLEdBQUcsZ0JBQUFxQyxTQUFBLEdBQUhyQyxHQUFHLENBQVV3QyxRQUFRLGNBQUFILFNBQUEsdUJBQXRCQSxTQUFBLENBQXdCVCxNQUFNLEtBQUksR0FBRztNQUNwRCxPQUFPakIsR0FBRyxDQUFDRyxXQUFXLENBQUM7UUFDckJDLFVBQVUsRUFBRWEsTUFBTTtRQUNsQmhDLElBQUksR0FBQTBDLGFBQUEsR0FBRXRDLEdBQUcsYUFBSEEsR0FBRyx1QkFBSEEsR0FBRyxDQUFFNkIsT0FBTyxjQUFBUyxhQUFBLGNBQUFBLGFBQUEsR0FBSUMsTUFBTSxDQUFDdkMsR0FBRztNQUNsQyxDQUFDLENBQUM7SUFDSjtFQUNGLENBQ0YsQ0FBQztBQUNIO0FBRU8sU0FBU3lDLG9CQUFvQkEsQ0FBQ3JDLE1BQWUsRUFBRTtFQUNwRCxNQUFNc0MsVUFBVSxHQUFHQyxvQkFBTSxDQUFDQyxNQUFNLENBQUM7SUFDL0J4QixnQkFBZ0IsRUFBRXVCLG9CQUFNLENBQUNFLE1BQU0sQ0FBQyxDQUFDO0lBQ2pDdkIsV0FBVyxFQUFFcUIsb0JBQU0sQ0FBQ0csS0FBSyxDQUFDSCxvQkFBTSxDQUFDRSxNQUFNLENBQUMsQ0FBQztFQUMzQyxDQUFDLENBQUM7RUFFRjFDLGlCQUFpQixDQUNmQyxNQUFNLEVBQ04sd0NBQXdDLEVBQ3hDLGFBQWEsRUFDYnNDLFVBQVUsRUFDVixDQUFDSyxDQUFDLEVBQUVDLENBQUMsS0FBSyxJQUFBQyx1QkFBVSxFQUFDRixDQUFDLEVBQUVDLENBQUMsQ0FBQzVCLGdCQUFnQixDQUM1QyxDQUFDO0VBQ0RqQixpQkFBaUIsQ0FDZkMsTUFBTSxFQUNOLHdDQUF3QyxFQUN4QyxhQUFhLEVBQ2JzQyxVQUFVLEVBQ1YsQ0FBQ0ssQ0FBQyxFQUFFQyxDQUFDLEtBQUssSUFBQUUsdUJBQVUsRUFBQ0gsQ0FBQyxFQUFFQyxDQUFDLENBQUM1QixnQkFBZ0IsQ0FDNUMsQ0FBQztFQUNEakIsaUJBQWlCLENBQ2ZDLE1BQU0sRUFDTiwyQ0FBMkMsRUFDM0MsZ0JBQWdCLEVBQ2hCc0MsVUFBVSxFQUNWLENBQUNLLENBQUMsRUFBRUMsQ0FBQyxLQUFLLElBQUFHLDBCQUFhLEVBQUNKLENBQUMsRUFBRUMsQ0FBQyxDQUFDNUIsZ0JBQWdCLENBQy9DLENBQUM7RUFDRGpCLGlCQUFpQixDQUNmQyxNQUFNLEVBQ04sMENBQTBDLEVBQzFDLGVBQWUsRUFDZnNDLFVBQVUsRUFDVixDQUFDSyxDQUFDLEVBQUVDLENBQUMsS0FBSyxJQUFBSSx5QkFBWSxFQUFDTCxDQUFDLEVBQUVDLENBQUMsQ0FBQzVCLGdCQUFnQixDQUM5QyxDQUFDO0VBQ0RqQixpQkFBaUIsQ0FDZkMsTUFBTSxFQUNOLDRDQUE0QyxFQUM1QyxpQkFBaUIsRUFDakJzQyxVQUFVLEVBQ1YsQ0FBQ0ssQ0FBQyxFQUFFQyxDQUFDLEtBQUssSUFBQUssMkJBQWMsRUFBQ04sQ0FBQyxFQUFFQyxDQUFDLENBQUM1QixnQkFBZ0IsQ0FDaEQsQ0FBQztFQUNEakIsaUJBQWlCLENBQ2ZDLE1BQU0sRUFDTix1REFBdUQsRUFDdkQsNEJBQTRCLEVBQzVCc0MsVUFBVSxFQUNWLENBQUNLLENBQUMsRUFBRUMsQ0FBQyxLQUFLLElBQUFNLHFDQUF3QixFQUFDUCxDQUFDLEVBQUVDLENBQUMsQ0FBQzVCLGdCQUFnQixDQUMxRCxDQUFDO0VBQ0RqQixpQkFBaUIsQ0FDZkMsTUFBTSxFQUNOLGdEQUFnRCxFQUNoRCxxQkFBcUIsRUFDckJzQyxVQUFVLEVBQ1YsQ0FBQ0ssQ0FBQyxFQUFFQyxDQUFDLEtBQUssSUFBQU8sK0JBQWtCLEVBQUNSLENBQUMsRUFBRUMsQ0FBQyxDQUFDNUIsZ0JBQWdCLENBQ3BELENBQUM7RUFDRGpCLGlCQUFpQixDQUNmQyxNQUFNLEVBQ04sNkNBQTZDLEVBQzdDLGtCQUFrQixFQUNsQnNDLFVBQVUsRUFDVixDQUFDSyxDQUFDLEVBQUVDLENBQUMsS0FBSyxJQUFBUSxnQ0FBbUIsRUFBQ1QsQ0FBQyxFQUFFQyxDQUFDLENBQUM1QixnQkFBZ0IsQ0FDckQsQ0FBQztFQUVEaEIsTUFBTSxDQUFDSSxJQUFJLENBQ1Q7SUFDRTlELElBQUksRUFBRSwwQ0FBMEM7SUFDaEQrRCxRQUFRLEVBQUU7TUFDUmIsSUFBSSxFQUFFK0Msb0JBQU0sQ0FBQ0MsTUFBTSxDQUFDO1FBQ2xCeEIsZ0JBQWdCLEVBQUV1QixvQkFBTSxDQUFDRSxNQUFNLENBQUMsQ0FBQztRQUNqQ3ZCLFdBQVcsRUFBRXFCLG9CQUFNLENBQUNHLEtBQUssQ0FBQ0gsb0JBQU0sQ0FBQ0UsTUFBTSxDQUFDLENBQUMsQ0FBQztRQUMxQ1ksVUFBVSxFQUFFZCxvQkFBTSxDQUFDRyxLQUFLLENBQUNILG9CQUFNLENBQUNlLE9BQU8sQ0FBQyxDQUFDO01BQzNDLENBQUM7SUFDSDtFQUNGLENBQUMsRUFDRCxPQUFPaEQsT0FBTyxFQUFFekMsR0FBRyxFQUFFMEMsR0FBRyxLQUFLO0lBQzNCLE1BQU1DLE1BQU0sR0FBRyxJQUFBQywyQkFBYyxFQUFDLENBQUM7SUFDL0IsSUFBSSxDQUFDRCxNQUFNLEVBQUU7TUFDWCxPQUFPRCxHQUFHLENBQUNHLFdBQVcsQ0FBQztRQUFFQyxVQUFVLEVBQUUsR0FBRztRQUFFbkIsSUFBSSxFQUFFO01BQXFDLENBQUMsQ0FBQztJQUN6RjtJQUNBLE1BQU07TUFBRXhCO0lBQUssQ0FBQyxHQUFHSixrQkFBa0IsQ0FBQ0MsR0FBRyxDQUFDO0lBQ3hDLE1BQU07TUFBRW1ELGdCQUFnQjtNQUFFRSxXQUFXO01BQUVtQyxVQUFVLEdBQUc7SUFBSyxDQUFDLEdBQUd4RixHQUFHLENBQUMyQixJQUFXO0lBQzVFLE1BQU1KLE1BQU0sR0FBR2tCLE9BQU8sQ0FBQ00sSUFBSSxDQUFDQyxVQUFVLENBQUN6QixNQUFNLENBQUMwQixhQUFhO0lBQzNELElBQUk7TUFBQSxJQUFBeUMsU0FBQSxFQUFBQyxNQUFBO01BQ0YsTUFBTW5DLE1BQU0sR0FBRyxNQUFNLElBQUFvQyx5QkFBWSxFQUFDakQsTUFBTSxFQUFFUSxnQkFBZ0IsRUFBRXFDLFVBQVUsQ0FBQztNQUN2RSxNQUFNbEUsYUFBYSxDQUFDQyxNQUFNLEVBQUU7UUFDMUJrQyxNQUFNLEVBQUUsZUFBZTtRQUN2Qk4sZ0JBQWdCO1FBQ2hCRSxXQUFXLEVBQUVBLFdBQVcsSUFBSSxFQUFFO1FBQzlCSyxZQUFZLEVBQUV2RCxJQUFJO1FBQ2xCRSxJQUFJLEVBQUUsRUFBQXFGLFNBQUEsR0FBQzFGLEdBQUcsQ0FBU0ksT0FBTyxjQUFBc0YsU0FBQSx1QkFBcEJBLFNBQUEsQ0FBdUIsZUFBZSxDQUFDLEtBQUksaUJBQWlCO1FBQ2xFL0IsTUFBTSxFQUFFLFNBQVM7UUFDakJDLE9BQU8sRUFBRUosTUFBTSxDQUFDSSxPQUFPO1FBQ3ZCQyxTQUFTLEdBQUE4QixNQUFBLEdBQUczRixHQUFHLENBQVM4RCxJQUFJLGNBQUE2QixNQUFBLHVCQUFqQkEsTUFBQSxDQUFtQjVCO01BQ2hDLENBQUMsQ0FBQztNQUNGLE9BQU9yQixHQUFHLENBQUNzQixFQUFFLENBQUM7UUFBRXJDLElBQUksRUFBRTtVQUFFLEdBQUc2QixNQUFNO1VBQUVDLE1BQU0sRUFBRSxlQUFlO1VBQUVOLGdCQUFnQjtVQUFFdkIsU0FBUyxFQUFFLElBQUlDLElBQUksQ0FBQyxDQUFDLENBQUNDLFdBQVcsQ0FBQztRQUFFO01BQUUsQ0FBQyxDQUFDO0lBQ3hILENBQUMsQ0FBQyxPQUFPQyxHQUFRLEVBQUU7TUFBQSxJQUFBOEQsU0FBQSxFQUFBQyxhQUFBLEVBQUFDLE1BQUEsRUFBQUMsYUFBQSxFQUFBQyxhQUFBO01BQ2pCLE1BQU0zRSxhQUFhLENBQUNDLE1BQU0sRUFBRTtRQUMxQmtDLE1BQU0sRUFBRSxlQUFlO1FBQ3ZCTixnQkFBZ0I7UUFDaEJFLFdBQVcsRUFBRUEsV0FBVyxJQUFJLEVBQUU7UUFDOUJLLFlBQVksRUFBRXZELElBQUk7UUFDbEJFLElBQUksRUFBRSxFQUFBd0YsU0FBQSxHQUFDN0YsR0FBRyxDQUFTSSxPQUFPLGNBQUF5RixTQUFBLHVCQUFwQkEsU0FBQSxDQUF1QixlQUFlLENBQUMsS0FBSSxpQkFBaUI7UUFDbEVsQyxNQUFNLEVBQUUsU0FBUztRQUNqQkMsT0FBTyxHQUFBa0MsYUFBQSxHQUFFL0QsR0FBRyxhQUFIQSxHQUFHLHVCQUFIQSxHQUFHLENBQUU2QixPQUFPLGNBQUFrQyxhQUFBLGNBQUFBLGFBQUEsR0FBSXhCLE1BQU0sQ0FBQ3ZDLEdBQUcsQ0FBQztRQUNwQzhCLFNBQVMsR0FBQWtDLE1BQUEsR0FBRy9GLEdBQUcsQ0FBUzhELElBQUksY0FBQWlDLE1BQUEsdUJBQWpCQSxNQUFBLENBQW1CaEM7TUFDaEMsQ0FBQyxDQUFDO01BQ0YsT0FBT3JCLEdBQUcsQ0FBQ0csV0FBVyxDQUFDO1FBQUVDLFVBQVUsRUFBRSxDQUFBZixHQUFHLGFBQUhBLEdBQUcsZ0JBQUFpRSxhQUFBLEdBQUhqRSxHQUFHLENBQUV3QyxRQUFRLGNBQUF5QixhQUFBLHVCQUFiQSxhQUFBLENBQWVyQyxNQUFNLEtBQUksR0FBRztRQUFFaEMsSUFBSSxHQUFBc0UsYUFBQSxHQUFFbEUsR0FBRyxhQUFIQSxHQUFHLHVCQUFIQSxHQUFHLENBQUU2QixPQUFPLGNBQUFxQyxhQUFBLGNBQUFBLGFBQUEsR0FBSTNCLE1BQU0sQ0FBQ3ZDLEdBQUc7TUFBRSxDQUFDLENBQUM7SUFDekc7RUFDRixDQUNGLENBQUM7RUFFREksTUFBTSxDQUFDSSxJQUFJLENBQ1Q7SUFDRTlELElBQUksRUFBRSw2Q0FBNkM7SUFDbkQrRCxRQUFRLEVBQUU7TUFBRWIsSUFBSSxFQUFFOEM7SUFBVztFQUMvQixDQUFDLEVBQ0QsT0FBT2hDLE9BQU8sRUFBRXpDLEdBQUcsRUFBRTBDLEdBQUcsS0FBSztJQUMzQixNQUFNQyxNQUFNLEdBQUcsSUFBQUMsMkJBQWMsRUFBQyxDQUFDO0lBQy9CLElBQUksQ0FBQ0QsTUFBTSxFQUFFO01BQ1gsT0FBT0QsR0FBRyxDQUFDRyxXQUFXLENBQUM7UUFBRUMsVUFBVSxFQUFFLEdBQUc7UUFBRW5CLElBQUksRUFBRTtNQUFxQyxDQUFDLENBQUM7SUFDekY7SUFDQSxNQUFNO01BQUV4QjtJQUFLLENBQUMsR0FBR0osa0JBQWtCLENBQUNDLEdBQUcsQ0FBQztJQUN4QyxNQUFNO01BQUVtRCxnQkFBZ0I7TUFBRUU7SUFBWSxDQUFDLEdBQUdyRCxHQUFHLENBQUMyQixJQUFXO0lBQ3pELE1BQU1KLE1BQU0sR0FBR2tCLE9BQU8sQ0FBQ00sSUFBSSxDQUFDQyxVQUFVLENBQUN6QixNQUFNLENBQUMwQixhQUFhO0lBQzNELElBQUk7TUFBQSxJQUFBaUQsU0FBQSxFQUFBQyxNQUFBO01BQ0YsTUFBTTNDLE1BQU0sR0FBRyxNQUFNLElBQUE0Qyw0QkFBZSxFQUFDekQsTUFBTSxFQUFFUSxnQkFBZ0IsRUFBRWhELElBQUksQ0FBQztNQUNwRSxJQUFJO1FBQ0YsTUFBTW9CLE1BQU0sQ0FBQzhFLE1BQU0sQ0FBQztVQUNsQjVFLEtBQUssRUFBRTZFLCtCQUFvQjtVQUMzQkMsRUFBRSxFQUFFcEQsZ0JBQWdCO1VBQ3BCeEIsSUFBSSxFQUFFO1lBQ0o2RSxHQUFHLEVBQUU7Y0FDSEMsaUJBQWlCLEVBQUUsSUFBSTtjQUN2QkMsc0JBQXNCLEVBQUV2RyxJQUFJO2NBQzVCd0csc0JBQXNCLEVBQUUsSUFBSTlFLElBQUksQ0FBQyxDQUFDLENBQUNDLFdBQVcsQ0FBQztZQUNqRDtVQUNGO1FBQ0YsQ0FBQyxDQUFDO01BQ0osQ0FBQyxDQUFDLE1BQU07UUFDTjtNQUFBO01BRUYsTUFBTVIsYUFBYSxDQUFDQyxNQUFNLEVBQUU7UUFDMUJrQyxNQUFNLEVBQUUsa0JBQWtCO1FBQzFCTixnQkFBZ0I7UUFDaEJFLFdBQVcsRUFBRUEsV0FBVyxJQUFJLEVBQUU7UUFDOUJLLFlBQVksRUFBRXZELElBQUk7UUFDbEJFLElBQUksRUFBRSxFQUFBNkYsU0FBQSxHQUFDbEcsR0FBRyxDQUFTSSxPQUFPLGNBQUE4RixTQUFBLHVCQUFwQkEsU0FBQSxDQUF1QixlQUFlLENBQUMsS0FBSSxpQkFBaUI7UUFDbEV2QyxNQUFNLEVBQUUsU0FBUztRQUNqQkMsT0FBTyxFQUFFSixNQUFNLENBQUNJLE9BQU87UUFDdkJDLFNBQVMsR0FBQXNDLE1BQUEsR0FBR25HLEdBQUcsQ0FBUzhELElBQUksY0FBQXFDLE1BQUEsdUJBQWpCQSxNQUFBLENBQW1CcEM7TUFDaEMsQ0FBQyxDQUFDO01BQ0YsT0FBT3JCLEdBQUcsQ0FBQ3NCLEVBQUUsQ0FBQztRQUFFckMsSUFBSSxFQUFFO1VBQUUsR0FBRzZCLE1BQU07VUFBRUMsTUFBTSxFQUFFLGtCQUFrQjtVQUFFTixnQkFBZ0I7VUFBRXZCLFNBQVMsRUFBRSxJQUFJQyxJQUFJLENBQUMsQ0FBQyxDQUFDQyxXQUFXLENBQUM7UUFBRTtNQUFFLENBQUMsQ0FBQztJQUMzSCxDQUFDLENBQUMsT0FBT0MsR0FBUSxFQUFFO01BQUEsSUFBQTZFLFNBQUEsRUFBQUMsYUFBQSxFQUFBQyxNQUFBLEVBQUFDLGNBQUEsRUFBQUMsYUFBQTtNQUNqQixNQUFNMUYsYUFBYSxDQUFDQyxNQUFNLEVBQUU7UUFDMUJrQyxNQUFNLEVBQUUsa0JBQWtCO1FBQzFCTixnQkFBZ0I7UUFDaEJFLFdBQVcsRUFBRUEsV0FBVyxJQUFJLEVBQUU7UUFDOUJLLFlBQVksRUFBRXZELElBQUk7UUFDbEJFLElBQUksRUFBRSxFQUFBdUcsU0FBQSxHQUFDNUcsR0FBRyxDQUFTSSxPQUFPLGNBQUF3RyxTQUFBLHVCQUFwQkEsU0FBQSxDQUF1QixlQUFlLENBQUMsS0FBSSxpQkFBaUI7UUFDbEVqRCxNQUFNLEVBQUUsU0FBUztRQUNqQkMsT0FBTyxHQUFBaUQsYUFBQSxHQUFFOUUsR0FBRyxhQUFIQSxHQUFHLHVCQUFIQSxHQUFHLENBQUU2QixPQUFPLGNBQUFpRCxhQUFBLGNBQUFBLGFBQUEsR0FBSXZDLE1BQU0sQ0FBQ3ZDLEdBQUcsQ0FBQztRQUNwQzhCLFNBQVMsR0FBQWlELE1BQUEsR0FBRzlHLEdBQUcsQ0FBUzhELElBQUksY0FBQWdELE1BQUEsdUJBQWpCQSxNQUFBLENBQW1CL0M7TUFDaEMsQ0FBQyxDQUFDO01BQ0YsT0FBT3JCLEdBQUcsQ0FBQ0csV0FBVyxDQUFDO1FBQUVDLFVBQVUsRUFBRSxDQUFBZixHQUFHLGFBQUhBLEdBQUcsZ0JBQUFnRixjQUFBLEdBQUhoRixHQUFHLENBQUV3QyxRQUFRLGNBQUF3QyxjQUFBLHVCQUFiQSxjQUFBLENBQWVwRCxNQUFNLEtBQUksR0FBRztRQUFFaEMsSUFBSSxHQUFBcUYsYUFBQSxHQUFFakYsR0FBRyxhQUFIQSxHQUFHLHVCQUFIQSxHQUFHLENBQUU2QixPQUFPLGNBQUFvRCxhQUFBLGNBQUFBLGFBQUEsR0FBSTFDLE1BQU0sQ0FBQ3ZDLEdBQUc7TUFBRSxDQUFDLENBQUM7SUFDekc7RUFDRixDQUNGLENBQUM7RUFFREksTUFBTSxDQUFDSSxJQUFJLENBQ1Q7SUFDRTlELElBQUksRUFBRSwwQ0FBMEM7SUFDaEQrRCxRQUFRLEVBQUU7TUFDUmIsSUFBSSxFQUFFK0Msb0JBQU0sQ0FBQ0MsTUFBTSxDQUFDO1FBQ2xCc0MsU0FBUyxFQUFFdkMsb0JBQU0sQ0FBQ0UsTUFBTSxDQUFDLENBQUM7UUFDMUJzQyxXQUFXLEVBQUV4QyxvQkFBTSxDQUFDRyxLQUFLLENBQUNILG9CQUFNLENBQUNFLE1BQU0sQ0FBQyxDQUFDLENBQUM7UUFDMUN1QyxRQUFRLEVBQUV6QyxvQkFBTSxDQUFDRyxLQUFLLENBQUNILG9CQUFNLENBQUNFLE1BQU0sQ0FBQyxDQUFDO01BQ3hDLENBQUM7SUFDSDtFQUNGLENBQUMsRUFDRCxPQUFPbkMsT0FBTyxFQUFFekMsR0FBRyxFQUFFMEMsR0FBRyxLQUFLO0lBQzNCLE1BQU1DLE1BQU0sR0FBRyxJQUFBQywyQkFBYyxFQUFDLENBQUM7SUFDL0IsSUFBSSxDQUFDRCxNQUFNLEVBQUU7TUFDWCxPQUFPRCxHQUFHLENBQUNHLFdBQVcsQ0FBQztRQUFFQyxVQUFVLEVBQUUsR0FBRztRQUFFbkIsSUFBSSxFQUFFO01BQXFDLENBQUMsQ0FBQztJQUN6RjtJQUNBLE1BQU07TUFBRXhCO0lBQUssQ0FBQyxHQUFHSixrQkFBa0IsQ0FBQ0MsR0FBRyxDQUFDO0lBQ3hDLE1BQU07TUFBRWlILFNBQVM7TUFBRUMsV0FBVyxHQUFHLFlBQVk7TUFBRUMsUUFBUSxHQUFHO0lBQU0sQ0FBQyxHQUFHbkgsR0FBRyxDQUFDMkIsSUFBVztJQUNuRixNQUFNSixNQUFNLEdBQUdrQixPQUFPLENBQUNNLElBQUksQ0FBQ0MsVUFBVSxDQUFDekIsTUFBTSxDQUFDMEIsYUFBYTtJQUMzRCxJQUFJO01BQUEsSUFBQW1FLFNBQUEsRUFBQUMsTUFBQTtNQUNGLE1BQU03RCxNQUFNLEdBQUcsTUFBTSxJQUFBOEQseUJBQVksRUFBQzNFLE1BQU0sRUFBRXNFLFNBQVMsRUFBRUMsV0FBVyxFQUFFQyxRQUFRLENBQUM7TUFDM0UsTUFBTTdGLGFBQWEsQ0FBQ0MsTUFBTSxFQUFFO1FBQzFCa0MsTUFBTSxFQUFFLGVBQWU7UUFDdkJOLGdCQUFnQixFQUFFOEQsU0FBUztRQUMzQjVELFdBQVcsRUFBRSxFQUFFO1FBQ2ZLLFlBQVksRUFBRXZELElBQUk7UUFDbEJFLElBQUksRUFBRSxFQUFBK0csU0FBQSxHQUFDcEgsR0FBRyxDQUFTSSxPQUFPLGNBQUFnSCxTQUFBLHVCQUFwQkEsU0FBQSxDQUF1QixlQUFlLENBQUMsS0FBSSxpQkFBaUI7UUFDbEV6RCxNQUFNLEVBQUUsU0FBUztRQUNqQkMsT0FBTyxFQUFFSixNQUFNLENBQUNJLE9BQU87UUFDdkJDLFNBQVMsR0FBQXdELE1BQUEsR0FBR3JILEdBQUcsQ0FBUzhELElBQUksY0FBQXVELE1BQUEsdUJBQWpCQSxNQUFBLENBQW1CdEQ7TUFDaEMsQ0FBQyxDQUFDO01BQ0YsT0FBT3JCLEdBQUcsQ0FBQ3NCLEVBQUUsQ0FBQztRQUFFckMsSUFBSSxFQUFFO1VBQUUsR0FBRzZCLE1BQU07VUFBRUMsTUFBTSxFQUFFLGVBQWU7VUFBRXdELFNBQVM7VUFBRXJGLFNBQVMsRUFBRSxJQUFJQyxJQUFJLENBQUMsQ0FBQyxDQUFDQyxXQUFXLENBQUM7UUFBRTtNQUFFLENBQUMsQ0FBQztJQUNqSCxDQUFDLENBQUMsT0FBT0MsR0FBUSxFQUFFO01BQUEsSUFBQXdGLGNBQUEsRUFBQUMsYUFBQTtNQUNqQixPQUFPOUUsR0FBRyxDQUFDRyxXQUFXLENBQUM7UUFBRUMsVUFBVSxFQUFFLENBQUFmLEdBQUcsYUFBSEEsR0FBRyxnQkFBQXdGLGNBQUEsR0FBSHhGLEdBQUcsQ0FBRXdDLFFBQVEsY0FBQWdELGNBQUEsdUJBQWJBLGNBQUEsQ0FBZTVELE1BQU0sS0FBSSxHQUFHO1FBQUVoQyxJQUFJLEdBQUE2RixhQUFBLEdBQUV6RixHQUFHLGFBQUhBLEdBQUcsdUJBQUhBLEdBQUcsQ0FBRTZCLE9BQU8sY0FBQTRELGFBQUEsY0FBQUEsYUFBQSxHQUFJbEQsTUFBTSxDQUFDdkMsR0FBRztNQUFFLENBQUMsQ0FBQztJQUN6RztFQUNGLENBQ0YsQ0FBQztFQUVESSxNQUFNLENBQUNJLElBQUksQ0FDVDtJQUNFOUQsSUFBSSxFQUFFLHVDQUF1QztJQUM3QytELFFBQVEsRUFBRTtNQUNSYixJQUFJLEVBQUUrQyxvQkFBTSxDQUFDQyxNQUFNLENBQUM7UUFDbEI4QyxNQUFNLEVBQUUvQyxvQkFBTSxDQUFDRSxNQUFNLENBQUMsQ0FBQztRQUN2QnVDLFFBQVEsRUFBRXpDLG9CQUFNLENBQUNHLEtBQUssQ0FBQ0gsb0JBQU0sQ0FBQ0UsTUFBTSxDQUFDLENBQUMsQ0FBQztRQUN2QzhDLE1BQU0sRUFBRWhELG9CQUFNLENBQUNHLEtBQUssQ0FBQ0gsb0JBQU0sQ0FBQ0UsTUFBTSxDQUFDLENBQUM7TUFDdEMsQ0FBQztJQUNIO0VBQ0YsQ0FBQyxFQUNELE9BQU9uQyxPQUFPLEVBQUV6QyxHQUFHLEVBQUUwQyxHQUFHLEtBQUs7SUFDM0IsTUFBTUMsTUFBTSxHQUFHLElBQUFDLDJCQUFjLEVBQUMsQ0FBQztJQUMvQixJQUFJLENBQUNELE1BQU0sRUFBRTtNQUNYLE9BQU9ELEdBQUcsQ0FBQ0csV0FBVyxDQUFDO1FBQUVDLFVBQVUsRUFBRSxHQUFHO1FBQUVuQixJQUFJLEVBQUU7TUFBcUMsQ0FBQyxDQUFDO0lBQ3pGO0lBQ0EsTUFBTTtNQUFFeEI7SUFBSyxDQUFDLEdBQUdKLGtCQUFrQixDQUFDQyxHQUFHLENBQUM7SUFDeEMsTUFBTTtNQUFFeUgsTUFBTTtNQUFFTixRQUFRLEdBQUcsS0FBSztNQUFFTyxNQUFNLEdBQUc7SUFBVyxDQUFDLEdBQUcxSCxHQUFHLENBQUMyQixJQUFXO0lBQ3pFLE1BQU1KLE1BQU0sR0FBR2tCLE9BQU8sQ0FBQ00sSUFBSSxDQUFDQyxVQUFVLENBQUN6QixNQUFNLENBQUMwQixhQUFhO0lBQzNELElBQUk7TUFBQSxJQUFBMEUsU0FBQSxFQUFBQyxNQUFBO01BQ0YsTUFBTXBFLE1BQU0sR0FBRyxNQUFNLElBQUFxRSxzQkFBUyxFQUFDbEYsTUFBTSxFQUFFOEUsTUFBTSxFQUFFTixRQUFRLEVBQUVPLE1BQU0sQ0FBQztNQUNoRSxNQUFNcEcsYUFBYSxDQUFDQyxNQUFNLEVBQUU7UUFDMUJrQyxNQUFNLEVBQUUsWUFBWTtRQUNwQk4sZ0JBQWdCLEVBQUVzRSxNQUFNO1FBQ3hCcEUsV0FBVyxFQUFFLEVBQUU7UUFDZkssWUFBWSxFQUFFdkQsSUFBSTtRQUNsQkUsSUFBSSxFQUFFLEVBQUFzSCxTQUFBLEdBQUMzSCxHQUFHLENBQVNJLE9BQU8sY0FBQXVILFNBQUEsdUJBQXBCQSxTQUFBLENBQXVCLGVBQWUsQ0FBQyxLQUFJLGlCQUFpQjtRQUNsRWhFLE1BQU0sRUFBRSxTQUFTO1FBQ2pCQyxPQUFPLEVBQUVKLE1BQU0sQ0FBQ0ksT0FBTztRQUN2QkMsU0FBUyxHQUFBK0QsTUFBQSxHQUFHNUgsR0FBRyxDQUFTOEQsSUFBSSxjQUFBOEQsTUFBQSx1QkFBakJBLE1BQUEsQ0FBbUI3RDtNQUNoQyxDQUFDLENBQUM7TUFDRixPQUFPckIsR0FBRyxDQUFDc0IsRUFBRSxDQUFDO1FBQUVyQyxJQUFJLEVBQUU7VUFBRSxHQUFHNkIsTUFBTTtVQUFFQyxNQUFNLEVBQUUsWUFBWTtVQUFFZ0UsTUFBTTtVQUFFN0YsU0FBUyxFQUFFLElBQUlDLElBQUksQ0FBQyxDQUFDLENBQUNDLFdBQVcsQ0FBQztRQUFFO01BQUUsQ0FBQyxDQUFDO0lBQzNHLENBQUMsQ0FBQyxPQUFPQyxHQUFRLEVBQUU7TUFBQSxJQUFBK0YsY0FBQSxFQUFBQyxhQUFBO01BQ2pCLE9BQU9yRixHQUFHLENBQUNHLFdBQVcsQ0FBQztRQUFFQyxVQUFVLEVBQUUsQ0FBQWYsR0FBRyxhQUFIQSxHQUFHLGdCQUFBK0YsY0FBQSxHQUFIL0YsR0FBRyxDQUFFd0MsUUFBUSxjQUFBdUQsY0FBQSx1QkFBYkEsY0FBQSxDQUFlbkUsTUFBTSxLQUFJLEdBQUc7UUFBRWhDLElBQUksR0FBQW9HLGFBQUEsR0FBRWhHLEdBQUcsYUFBSEEsR0FBRyx1QkFBSEEsR0FBRyxDQUFFNkIsT0FBTyxjQUFBbUUsYUFBQSxjQUFBQSxhQUFBLEdBQUl6RCxNQUFNLENBQUN2QyxHQUFHO01BQUUsQ0FBQyxDQUFDO0lBQ3pHO0VBQ0YsQ0FDRixDQUFDO0VBRURJLE1BQU0sQ0FBQ2hELEdBQUcsQ0FDUjtJQUNFVixJQUFJLEVBQUUsb0RBQW9EO0lBQzFEK0QsUUFBUSxFQUFFO01BQUV3RixNQUFNLEVBQUV0RCxvQkFBTSxDQUFDQyxNQUFNLENBQUM7UUFBRTRCLEVBQUUsRUFBRTdCLG9CQUFNLENBQUNFLE1BQU0sQ0FBQztNQUFFLENBQUM7SUFBRTtFQUM3RCxDQUFDLEVBQ0QsT0FBT25DLE9BQU8sRUFBRXpDLEdBQUcsRUFBRTBDLEdBQUcsS0FBSztJQUMzQixNQUFNQyxNQUFNLEdBQUcsSUFBQUMsMkJBQWMsRUFBQyxDQUFDO0lBQy9CLElBQUksQ0FBQ0QsTUFBTSxFQUFFO01BQ1gsT0FBT0QsR0FBRyxDQUFDRyxXQUFXLENBQUM7UUFBRUMsVUFBVSxFQUFFLEdBQUc7UUFBRW5CLElBQUksRUFBRTtNQUFxQyxDQUFDLENBQUM7SUFDekY7SUFDQSxNQUFNO01BQUV4QjtJQUFLLENBQUMsR0FBR0osa0JBQWtCLENBQUNDLEdBQUcsQ0FBQztJQUN4QyxNQUFNdUcsRUFBRSxHQUFJdkcsR0FBRyxDQUFDZ0ksTUFBTSxDQUFTekIsRUFBRTtJQUNqQyxNQUFNaEYsTUFBTSxHQUFHa0IsT0FBTyxDQUFDTSxJQUFJLENBQUNDLFVBQVUsQ0FBQ3pCLE1BQU0sQ0FBQzBCLGFBQWE7SUFDM0QsSUFBSTtNQUFBLElBQUFnRixZQUFBLEVBQUFDLFNBQUEsRUFBQUMsTUFBQTtNQUNGLE1BQU0zRSxNQUFNLEdBQUcsTUFBTSxJQUFBNEUsdUNBQTBCLEVBQUN6RixNQUFNLEVBQUU0RCxFQUFFLENBQUM7TUFDM0QsTUFBTWpGLGFBQWEsQ0FBQ0MsTUFBTSxFQUFFO1FBQzFCa0MsTUFBTSxFQUFFLHlCQUF5QjtRQUNqQ04sZ0JBQWdCLEVBQUVvRCxFQUFFO1FBQ3BCbEQsV0FBVyxFQUFFLEVBQUE0RSxZQUFBLEdBQUN6RSxNQUFNLENBQUM2RSxJQUFJLGNBQUFKLFlBQUEsZ0JBQUFBLFlBQUEsR0FBWEEsWUFBQSxDQUFhSyxNQUFNLGNBQUFMLFlBQUEsdUJBQXBCQSxZQUFBLENBQThCN0UsVUFBVSxLQUFJLEVBQUU7UUFDM0RNLFlBQVksRUFBRXZELElBQUk7UUFDbEJFLElBQUksRUFBRSxFQUFBNkgsU0FBQSxHQUFDbEksR0FBRyxDQUFTSSxPQUFPLGNBQUE4SCxTQUFBLHVCQUFwQkEsU0FBQSxDQUF1QixlQUFlLENBQUMsS0FBSSxpQkFBaUI7UUFDbEV2RSxNQUFNLEVBQUUsU0FBUztRQUNqQkMsT0FBTyxFQUFFSixNQUFNLENBQUNJLE9BQU87UUFDdkJDLFNBQVMsR0FBQXNFLE1BQUEsR0FBR25JLEdBQUcsQ0FBUzhELElBQUksY0FBQXFFLE1BQUEsdUJBQWpCQSxNQUFBLENBQW1CcEU7TUFDaEMsQ0FBQyxDQUFDO01BQ0YsT0FBT3JCLEdBQUcsQ0FBQ3NCLEVBQUUsQ0FBQztRQUFFckMsSUFBSSxFQUFFO1VBQUUsR0FBRzZCLE1BQU07VUFBRUMsTUFBTSxFQUFFLHlCQUF5QjtVQUFFTixnQkFBZ0IsRUFBRW9ELEVBQUU7VUFBRTNFLFNBQVMsRUFBRSxJQUFJQyxJQUFJLENBQUMsQ0FBQyxDQUFDQyxXQUFXLENBQUM7UUFBRTtNQUFFLENBQUMsQ0FBQztJQUN0SSxDQUFDLENBQUMsT0FBT0MsR0FBUSxFQUFFO01BQUEsSUFBQXdHLGNBQUEsRUFBQUMsYUFBQTtNQUNqQixPQUFPOUYsR0FBRyxDQUFDRyxXQUFXLENBQUM7UUFBRUMsVUFBVSxFQUFFLENBQUFmLEdBQUcsYUFBSEEsR0FBRyxnQkFBQXdHLGNBQUEsR0FBSHhHLEdBQUcsQ0FBRXdDLFFBQVEsY0FBQWdFLGNBQUEsdUJBQWJBLGNBQUEsQ0FBZTVFLE1BQU0sS0FBSSxHQUFHO1FBQUVoQyxJQUFJLEdBQUE2RyxhQUFBLEdBQUV6RyxHQUFHLGFBQUhBLEdBQUcsdUJBQUhBLEdBQUcsQ0FBRTZCLE9BQU8sY0FBQTRFLGFBQUEsY0FBQUEsYUFBQSxHQUFJbEUsTUFBTSxDQUFDdkMsR0FBRztNQUFFLENBQUMsQ0FBQztJQUN6RztFQUNGLENBQ0YsQ0FBQzs7RUFFRDtFQUNBLE1BQU0wRyxpQkFBaUIsR0FBRyxDQUFDLFFBQVEsRUFBRSxNQUFNLEVBQUUsZUFBZSxDQUFDOztFQUU3RDtFQUNBdEcsTUFBTSxDQUFDSSxJQUFJLENBQ1Q7SUFDRTlELElBQUksRUFBRSx3Q0FBd0M7SUFDOUMrRCxRQUFRLEVBQUU7TUFDUmIsSUFBSSxFQUFFK0Msb0JBQU0sQ0FBQ0MsTUFBTSxDQUFDO1FBQ2xCeEIsZ0JBQWdCLEVBQUV1QixvQkFBTSxDQUFDRSxNQUFNLENBQUMsQ0FBQztRQUNqQ3ZCLFdBQVcsRUFBRXFCLG9CQUFNLENBQUNHLEtBQUssQ0FBQ0gsb0JBQU0sQ0FBQ0UsTUFBTSxDQUFDLENBQUMsQ0FBQztRQUMxQ25CLE1BQU0sRUFBRWlCLG9CQUFNLENBQUNFLE1BQU0sQ0FBQztNQUN4QixDQUFDO0lBQ0g7RUFDRixDQUFDLEVBQ0QsT0FBT25DLE9BQU8sRUFBRXpDLEdBQUcsRUFBRTBDLEdBQUcsS0FBSztJQUMzQixNQUFNO01BQUVTLGdCQUFnQjtNQUFFRSxXQUFXO01BQUVJO0lBQU8sQ0FBQyxHQUFHekQsR0FBRyxDQUFDMkIsSUFBVztJQUNqRSxNQUFNK0csU0FBUyxHQUFHRCxpQkFBaUIsQ0FBQ0UsUUFBUSxDQUFDbEYsTUFBTSxDQUFDLEdBQUdBLE1BQU0sR0FBRyxJQUFJO0lBQ3BFLElBQUksQ0FBQ04sZ0JBQWdCLElBQUksQ0FBQ3VGLFNBQVMsRUFBRTtNQUNuQyxPQUFPaEcsR0FBRyxDQUFDa0csVUFBVSxDQUFDO1FBQ3BCakgsSUFBSSxFQUFFO1VBQUVrSCxPQUFPLEVBQUUsS0FBSztVQUFFakYsT0FBTyxFQUFHLDBCQUF5QjZFLGlCQUFpQixDQUFDSyxJQUFJLENBQUMsSUFBSSxDQUFFO1FBQUU7TUFDNUYsQ0FBQyxDQUFDO0lBQ0o7SUFDQSxNQUFNQyxHQUFHLEdBQUcsSUFBQUMsZ0JBQVcsRUFBQyxDQUFDO0lBQ3pCLElBQUFDLGFBQVEsRUFBQzlGLGdCQUFnQixFQUFFdUYsU0FBUyxFQUFFSyxHQUFHLENBQUM7SUFDMUMsTUFBTUcsV0FBVyxHQUFHLE1BQU0sSUFBQUMsaUJBQVksRUFDcEM3SSxZQUFZLENBQUMsQ0FBQyxFQUNkeUksR0FBRyxFQUNIMUYsV0FBVyxJQUFJRixnQkFBZ0IsRUFDL0J1RixTQUNGLENBQUM7SUFDRCxPQUFPaEcsR0FBRyxDQUFDc0IsRUFBRSxDQUFDO01BQ1pyQyxJQUFJLEVBQUU7UUFDSmtILE9BQU8sRUFBRSxJQUFJO1FBQ2JqRixPQUFPLEVBQUVzRixXQUFXLENBQUNFLE9BQU8sR0FDeEIsOERBQThELEdBQzdELGVBQWNGLFdBQVcsQ0FBQ0csU0FBVSxFQUFDO1FBQzFDQyxRQUFRLEVBQUVKLFdBQVcsQ0FBQ0UsT0FBTyxJQUFJLEtBQUs7UUFDdEMsSUFBSUYsV0FBVyxDQUFDRSxPQUFPLEdBQUc7VUFBRUw7UUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFDO01BQ3hDO0lBQ0YsQ0FBQyxDQUFDO0VBQ0osQ0FDRixDQUFDOztFQUVEO0VBQ0E1RyxNQUFNLENBQUNJLElBQUksQ0FDVDtJQUNFOUQsSUFBSSxFQUFFLDBDQUEwQztJQUNoRCtELFFBQVEsRUFBRTtNQUNSYixJQUFJLEVBQUUrQyxvQkFBTSxDQUFDQyxNQUFNLENBQUM7UUFDbEJ4QixnQkFBZ0IsRUFBRXVCLG9CQUFNLENBQUNFLE1BQU0sQ0FBQyxDQUFDO1FBQ2pDdkIsV0FBVyxFQUFFcUIsb0JBQU0sQ0FBQ0csS0FBSyxDQUFDSCxvQkFBTSxDQUFDRSxNQUFNLENBQUMsQ0FBQyxDQUFDO1FBQzFDbUUsR0FBRyxFQUFFckUsb0JBQU0sQ0FBQ0UsTUFBTSxDQUFDO01BQ3JCLENBQUM7SUFDSDtFQUNGLENBQUMsRUFDRCxPQUFPbkMsT0FBTyxFQUFFekMsR0FBRyxFQUFFMEMsR0FBRyxLQUFLO0lBQzNCLE1BQU1DLE1BQU0sR0FBRyxJQUFBQywyQkFBYyxFQUFDLENBQUM7SUFDL0IsSUFBSSxDQUFDRCxNQUFNLEVBQUU7TUFDWCxPQUFPRCxHQUFHLENBQUNHLFdBQVcsQ0FBQztRQUFFQyxVQUFVLEVBQUUsR0FBRztRQUFFbkIsSUFBSSxFQUFFO01BQXFDLENBQUMsQ0FBQztJQUN6RjtJQUNBLE1BQU07TUFBRXhCO0lBQUssQ0FBQyxHQUFHSixrQkFBa0IsQ0FBQ0MsR0FBRyxDQUFDO0lBQ3hDLE1BQU07TUFBRW1ELGdCQUFnQjtNQUFFRSxXQUFXO01BQUUwRjtJQUFJLENBQUMsR0FBRy9JLEdBQUcsQ0FBQzJCLElBQVc7SUFDOUQsTUFBTTRILFVBQVUsR0FBRyxJQUFBQyxnQkFBVyxFQUFDckcsZ0JBQWdCLEVBQUUsUUFBUSxFQUFFNEYsR0FBRyxDQUFDO0lBQy9ELElBQUksQ0FBQ1EsVUFBVSxDQUFDRSxLQUFLLEVBQUU7TUFDckIsT0FBTy9HLEdBQUcsQ0FBQ2dILFNBQVMsQ0FBQztRQUFFL0gsSUFBSSxFQUFFO1VBQUVrSCxPQUFPLEVBQUUsS0FBSztVQUFFakYsT0FBTyxFQUFFMkYsVUFBVSxDQUFDSTtRQUFPO01BQUUsQ0FBQyxDQUFDO0lBQ2hGO0lBQ0EsTUFBTXBJLE1BQU0sR0FBR2tCLE9BQU8sQ0FBQ00sSUFBSSxDQUFDQyxVQUFVLENBQUN6QixNQUFNLENBQUMwQixhQUFhO0lBQzNELElBQUk7TUFBQSxJQUFBMkcsVUFBQSxFQUFBQyxPQUFBO01BQ0YsTUFBTXJHLE1BQU0sR0FBRyxNQUFNLElBQUFzRyx5QkFBWSxFQUFDbkgsTUFBTSxFQUFFUSxnQkFBZ0IsQ0FBQztNQUMzRCxNQUFNN0IsYUFBYSxDQUFDQyxNQUFNLEVBQUU7UUFDMUJrQyxNQUFNLEVBQUUsZUFBZTtRQUN2Qk4sZ0JBQWdCO1FBQ2hCRSxXQUFXLEVBQUVBLFdBQVcsSUFBSSxFQUFFO1FBQzlCSyxZQUFZLEVBQUV2RCxJQUFJO1FBQ2xCRSxJQUFJLEVBQUUsRUFBQXVKLFVBQUEsR0FBQzVKLEdBQUcsQ0FBU0ksT0FBTyxjQUFBd0osVUFBQSx1QkFBcEJBLFVBQUEsQ0FBdUIsZUFBZSxDQUFDLEtBQUksaUJBQWlCO1FBQ2xFakcsTUFBTSxFQUFFLFNBQVM7UUFDakJDLE9BQU8sRUFBRUosTUFBTSxDQUFDSSxPQUFPO1FBQ3ZCQyxTQUFTLEdBQUFnRyxPQUFBLEdBQUc3SixHQUFHLENBQVM4RCxJQUFJLGNBQUErRixPQUFBLHVCQUFqQkEsT0FBQSxDQUFtQjlGO01BQ2hDLENBQUMsQ0FBQztNQUNGLE9BQU9yQixHQUFHLENBQUNzQixFQUFFLENBQUM7UUFBRXJDLElBQUksRUFBRTtVQUFFLEdBQUc2QixNQUFNO1VBQUVDLE1BQU0sRUFBRSxlQUFlO1VBQUVOLGdCQUFnQjtVQUFFdkIsU0FBUyxFQUFFLElBQUlDLElBQUksQ0FBQyxDQUFDLENBQUNDLFdBQVcsQ0FBQztRQUFFO01BQUUsQ0FBQyxDQUFDO0lBQ3hILENBQUMsQ0FBQyxPQUFPQyxHQUFRLEVBQUU7TUFBQSxJQUFBZ0ksY0FBQSxFQUFBQyxjQUFBO01BQ2pCLE9BQU90SCxHQUFHLENBQUNHLFdBQVcsQ0FBQztRQUFFQyxVQUFVLEVBQUUsQ0FBQWYsR0FBRyxhQUFIQSxHQUFHLGdCQUFBZ0ksY0FBQSxHQUFIaEksR0FBRyxDQUFFd0MsUUFBUSxjQUFBd0YsY0FBQSx1QkFBYkEsY0FBQSxDQUFlcEcsTUFBTSxLQUFJLEdBQUc7UUFBRWhDLElBQUksR0FBQXFJLGNBQUEsR0FBRWpJLEdBQUcsYUFBSEEsR0FBRyx1QkFBSEEsR0FBRyxDQUFFNkIsT0FBTyxjQUFBb0csY0FBQSxjQUFBQSxjQUFBLEdBQUkxRixNQUFNLENBQUN2QyxHQUFHO01BQUUsQ0FBQyxDQUFDO0lBQ3pHO0VBQ0YsQ0FDRixDQUFDO0VBRURJLE1BQU0sQ0FBQ0ksSUFBSSxDQUNUO0lBQ0U5RCxJQUFJLEVBQUUsd0NBQXdDO0lBQzlDK0QsUUFBUSxFQUFFO01BQ1JiLElBQUksRUFBRStDLG9CQUFNLENBQUNDLE1BQU0sQ0FBQztRQUNsQnhCLGdCQUFnQixFQUFFdUIsb0JBQU0sQ0FBQ0UsTUFBTSxDQUFDLENBQUM7UUFDakN2QixXQUFXLEVBQUVxQixvQkFBTSxDQUFDRyxLQUFLLENBQUNILG9CQUFNLENBQUNFLE1BQU0sQ0FBQyxDQUFDLENBQUM7UUFDMUNtRSxHQUFHLEVBQUVyRSxvQkFBTSxDQUFDRSxNQUFNLENBQUMsQ0FBQztRQUNwQnFGLG9CQUFvQixFQUFFdkYsb0JBQU0sQ0FBQ0csS0FBSyxDQUFDSCxvQkFBTSxDQUFDZSxPQUFPLENBQUMsQ0FBQyxDQUFDO1FBQ3BEeUUsY0FBYyxFQUFFeEYsb0JBQU0sQ0FBQ0csS0FBSyxDQUFDSCxvQkFBTSxDQUFDZSxPQUFPLENBQUMsQ0FBQztNQUMvQyxDQUFDO0lBQ0g7RUFDRixDQUFDLEVBQ0QsT0FBT2hELE9BQU8sRUFBRXpDLEdBQUcsRUFBRTBDLEdBQUcsS0FBSztJQUMzQixNQUFNQyxNQUFNLEdBQUcsSUFBQUMsMkJBQWMsRUFBQyxDQUFDO0lBQy9CLElBQUksQ0FBQ0QsTUFBTSxFQUFFO01BQ1gsT0FBT0QsR0FBRyxDQUFDRyxXQUFXLENBQUM7UUFBRUMsVUFBVSxFQUFFLEdBQUc7UUFBRW5CLElBQUksRUFBRTtNQUFxQyxDQUFDLENBQUM7SUFDekY7SUFDQSxNQUFNO01BQUV4QjtJQUFLLENBQUMsR0FBR0osa0JBQWtCLENBQUNDLEdBQUcsQ0FBQztJQUN4QyxNQUFNO01BQUVtRCxnQkFBZ0I7TUFBRUUsV0FBVztNQUFFMEYsR0FBRztNQUFFa0Isb0JBQW9CO01BQUVDO0lBQWUsQ0FBQyxHQUFHbEssR0FBRyxDQUFDMkIsSUFBVztJQUNwRyxNQUFNNEgsVUFBVSxHQUFHLElBQUFDLGdCQUFXLEVBQUNyRyxnQkFBZ0IsRUFBRSxNQUFNLEVBQUU0RixHQUFHLENBQUM7SUFDN0QsSUFBSSxDQUFDUSxVQUFVLENBQUNFLEtBQUssRUFBRTtNQUNyQixPQUFPL0csR0FBRyxDQUFDZ0gsU0FBUyxDQUFDO1FBQUUvSCxJQUFJLEVBQUU7VUFBRWtILE9BQU8sRUFBRSxLQUFLO1VBQUVqRixPQUFPLEVBQUUyRixVQUFVLENBQUNJO1FBQU87TUFBRSxDQUFDLENBQUM7SUFDaEY7SUFDQSxNQUFNcEksTUFBTSxHQUFHa0IsT0FBTyxDQUFDTSxJQUFJLENBQUNDLFVBQVUsQ0FBQ3pCLE1BQU0sQ0FBQzBCLGFBQWE7SUFDM0QsSUFBSTtNQUFBLElBQUFrSCxVQUFBLEVBQUFDLE9BQUE7TUFDRixNQUFNNUcsTUFBTSxHQUFHLE1BQU0sSUFBQTZHLHVCQUFVLEVBQUMxSCxNQUFNLEVBQUVRLGdCQUFnQixFQUFFOEcsb0JBQW9CLEVBQUVDLGNBQWMsQ0FBQztNQUMvRixNQUFNNUksYUFBYSxDQUFDQyxNQUFNLEVBQUU7UUFDMUJrQyxNQUFNLEVBQUUsYUFBYTtRQUNyQk4sZ0JBQWdCO1FBQ2hCRSxXQUFXLEVBQUVBLFdBQVcsSUFBSSxFQUFFO1FBQzlCSyxZQUFZLEVBQUV2RCxJQUFJO1FBQ2xCRSxJQUFJLEVBQUUsRUFBQThKLFVBQUEsR0FBQ25LLEdBQUcsQ0FBU0ksT0FBTyxjQUFBK0osVUFBQSx1QkFBcEJBLFVBQUEsQ0FBdUIsZUFBZSxDQUFDLEtBQUksaUJBQWlCO1FBQ2xFeEcsTUFBTSxFQUFFLFNBQVM7UUFDakJDLE9BQU8sRUFBRUosTUFBTSxDQUFDSSxPQUFPO1FBQ3ZCQyxTQUFTLEdBQUF1RyxPQUFBLEdBQUdwSyxHQUFHLENBQVM4RCxJQUFJLGNBQUFzRyxPQUFBLHVCQUFqQkEsT0FBQSxDQUFtQnJHO01BQ2hDLENBQUMsQ0FBQztNQUNGLE9BQU9yQixHQUFHLENBQUNzQixFQUFFLENBQUM7UUFBRXJDLElBQUksRUFBRTtVQUFFLEdBQUc2QixNQUFNO1VBQUVDLE1BQU0sRUFBRSxhQUFhO1VBQUVOLGdCQUFnQjtVQUFFdkIsU0FBUyxFQUFFLElBQUlDLElBQUksQ0FBQyxDQUFDLENBQUNDLFdBQVcsQ0FBQztRQUFFO01BQUUsQ0FBQyxDQUFDO0lBQ3RILENBQUMsQ0FBQyxPQUFPQyxHQUFRLEVBQUU7TUFBQSxJQUFBdUksY0FBQSxFQUFBQyxjQUFBO01BQ2pCLE9BQU83SCxHQUFHLENBQUNHLFdBQVcsQ0FBQztRQUFFQyxVQUFVLEVBQUUsQ0FBQWYsR0FBRyxhQUFIQSxHQUFHLGdCQUFBdUksY0FBQSxHQUFIdkksR0FBRyxDQUFFd0MsUUFBUSxjQUFBK0YsY0FBQSx1QkFBYkEsY0FBQSxDQUFlM0csTUFBTSxLQUFJLEdBQUc7UUFBRWhDLElBQUksR0FBQTRJLGNBQUEsR0FBRXhJLEdBQUcsYUFBSEEsR0FBRyx1QkFBSEEsR0FBRyxDQUFFNkIsT0FBTyxjQUFBMkcsY0FBQSxjQUFBQSxjQUFBLEdBQUlqRyxNQUFNLENBQUN2QyxHQUFHO01BQUUsQ0FBQyxDQUFDO0lBQ3pHO0VBQ0YsQ0FDRixDQUFDO0VBRURJLE1BQU0sQ0FBQ0ksSUFBSSxDQUNUO0lBQ0U5RCxJQUFJLEVBQUUsMENBQTBDO0lBQ2hEK0QsUUFBUSxFQUFFO01BQ1JiLElBQUksRUFBRStDLG9CQUFNLENBQUNDLE1BQU0sQ0FBQztRQUNsQnhCLGdCQUFnQixFQUFFdUIsb0JBQU0sQ0FBQ0UsTUFBTSxDQUFDLENBQUM7UUFDakN2QixXQUFXLEVBQUVxQixvQkFBTSxDQUFDRyxLQUFLLENBQUNILG9CQUFNLENBQUNFLE1BQU0sQ0FBQyxDQUFDLENBQUM7UUFDMUNtRSxHQUFHLEVBQUVyRSxvQkFBTSxDQUFDRSxNQUFNLENBQUM7TUFDckIsQ0FBQztJQUNIO0VBQ0YsQ0FBQyxFQUNELE9BQU9uQyxPQUFPLEVBQUV6QyxHQUFHLEVBQUUwQyxHQUFHLEtBQUs7SUFDM0IsTUFBTUMsTUFBTSxHQUFHLElBQUFDLDJCQUFjLEVBQUMsQ0FBQztJQUMvQixJQUFJLENBQUNELE1BQU0sRUFBRTtNQUNYLE9BQU9ELEdBQUcsQ0FBQ0csV0FBVyxDQUFDO1FBQUVDLFVBQVUsRUFBRSxHQUFHO1FBQUVuQixJQUFJLEVBQUU7TUFBcUMsQ0FBQyxDQUFDO0lBQ3pGO0lBQ0EsTUFBTTtNQUFFeEI7SUFBSyxDQUFDLEdBQUdKLGtCQUFrQixDQUFDQyxHQUFHLENBQUM7SUFDeEMsTUFBTTtNQUFFbUQsZ0JBQWdCO01BQUVFLFdBQVc7TUFBRTBGO0lBQUksQ0FBQyxHQUFHL0ksR0FBRyxDQUFDMkIsSUFBVztJQUM5RCxNQUFNNEgsVUFBVSxHQUFHLElBQUFDLGdCQUFXLEVBQUNyRyxnQkFBZ0IsRUFBRSxlQUFlLEVBQUU0RixHQUFHLENBQUM7SUFDdEUsSUFBSSxDQUFDUSxVQUFVLENBQUNFLEtBQUssRUFBRTtNQUNyQixPQUFPL0csR0FBRyxDQUFDZ0gsU0FBUyxDQUFDO1FBQUUvSCxJQUFJLEVBQUU7VUFBRWtILE9BQU8sRUFBRSxLQUFLO1VBQUVqRixPQUFPLEVBQUUyRixVQUFVLENBQUNJO1FBQU87TUFBRSxDQUFDLENBQUM7SUFDaEY7SUFDQSxNQUFNcEksTUFBTSxHQUFHa0IsT0FBTyxDQUFDTSxJQUFJLENBQUNDLFVBQVUsQ0FBQ3pCLE1BQU0sQ0FBQzBCLGFBQWE7SUFDM0QsSUFBSTtNQUFBLElBQUF1SCxVQUFBLEVBQUFDLE9BQUE7TUFDRixNQUFNakgsTUFBTSxHQUFHLE1BQU0sSUFBQWtILCtCQUFrQixFQUFDL0gsTUFBTSxFQUFFUSxnQkFBZ0IsQ0FBQztNQUNqRSxNQUFNN0IsYUFBYSxDQUFDQyxNQUFNLEVBQUU7UUFDMUJrQyxNQUFNLEVBQUUsZUFBZTtRQUN2Qk4sZ0JBQWdCO1FBQ2hCRSxXQUFXLEVBQUVBLFdBQVcsSUFBSSxFQUFFO1FBQzlCSyxZQUFZLEVBQUV2RCxJQUFJO1FBQ2xCRSxJQUFJLEVBQUUsRUFBQW1LLFVBQUEsR0FBQ3hLLEdBQUcsQ0FBU0ksT0FBTyxjQUFBb0ssVUFBQSx1QkFBcEJBLFVBQUEsQ0FBdUIsZUFBZSxDQUFDLEtBQUksaUJBQWlCO1FBQ2xFN0csTUFBTSxFQUFFLFNBQVM7UUFDakJDLE9BQU8sRUFBRUosTUFBTSxDQUFDSSxPQUFPO1FBQ3ZCQyxTQUFTLEdBQUE0RyxPQUFBLEdBQUd6SyxHQUFHLENBQVM4RCxJQUFJLGNBQUEyRyxPQUFBLHVCQUFqQkEsT0FBQSxDQUFtQjFHO01BQ2hDLENBQUMsQ0FBQztNQUNGLE9BQU9yQixHQUFHLENBQUNzQixFQUFFLENBQUM7UUFBRXJDLElBQUksRUFBRTtVQUFFLEdBQUc2QixNQUFNO1VBQUVDLE1BQU0sRUFBRSxlQUFlO1VBQUVOLGdCQUFnQjtVQUFFdkIsU0FBUyxFQUFFLElBQUlDLElBQUksQ0FBQyxDQUFDLENBQUNDLFdBQVcsQ0FBQztRQUFFO01BQUUsQ0FBQyxDQUFDO0lBQ3hILENBQUMsQ0FBQyxPQUFPQyxHQUFRLEVBQUU7TUFBQSxJQUFBNEksY0FBQSxFQUFBQyxjQUFBO01BQ2pCLE9BQU9sSSxHQUFHLENBQUNHLFdBQVcsQ0FBQztRQUFFQyxVQUFVLEVBQUUsQ0FBQWYsR0FBRyxhQUFIQSxHQUFHLGdCQUFBNEksY0FBQSxHQUFINUksR0FBRyxDQUFFd0MsUUFBUSxjQUFBb0csY0FBQSx1QkFBYkEsY0FBQSxDQUFlaEgsTUFBTSxLQUFJLEdBQUc7UUFBRWhDLElBQUksR0FBQWlKLGNBQUEsR0FBRTdJLEdBQUcsYUFBSEEsR0FBRyx1QkFBSEEsR0FBRyxDQUFFNkIsT0FBTyxjQUFBZ0gsY0FBQSxjQUFBQSxjQUFBLEdBQUl0RyxNQUFNLENBQUN2QyxHQUFHO01BQUUsQ0FBQyxDQUFDO0lBQ3pHO0VBQ0YsQ0FDRixDQUFDOztFQUVEO0VBQ0FJLE1BQU0sQ0FBQ2hELEdBQUcsQ0FDUjtJQUNFVixJQUFJLEVBQUUsc0NBQXNDO0lBQzVDK0QsUUFBUSxFQUFFO01BQUVxSSxLQUFLLEVBQUVuRyxvQkFBTSxDQUFDQyxNQUFNLENBQUM7UUFBRW1HLElBQUksRUFBRXBHLG9CQUFNLENBQUNHLEtBQUssQ0FBQ0gsb0JBQU0sQ0FBQ0UsTUFBTSxDQUFDLENBQUM7TUFBRSxDQUFDO0lBQUU7RUFDNUUsQ0FBQyxFQUNELE9BQU9uQyxPQUFPLEVBQUV6QyxHQUFHLEVBQUUwQyxHQUFHLEtBQUs7SUFDM0IsSUFBSTtNQUFBLElBQUFxSSxVQUFBLEVBQUFDLGNBQUE7TUFDRixNQUFNekosTUFBTSxHQUFHa0IsT0FBTyxDQUFDTSxJQUFJLENBQUNDLFVBQVUsQ0FBQ3pCLE1BQU0sQ0FBQzBCLGFBQWE7TUFDM0QsTUFBTTZILElBQUksR0FBR0csSUFBSSxDQUFDQyxHQUFHLENBQUMsR0FBRyxFQUFFckssUUFBUSxDQUFFYixHQUFHLENBQUM2SyxLQUFLLENBQVNDLElBQUksSUFBSSxJQUFJLEVBQUUsRUFBRSxDQUFDLElBQUksRUFBRSxDQUFDO01BQy9FLE1BQU12RyxRQUFRLEdBQUcsTUFBTWhELE1BQU0sQ0FBQzRKLE1BQU0sQ0FBQztRQUNuQzFKLEtBQUssRUFBRUMsaUNBQXNCO1FBQzdCMEosa0JBQWtCLEVBQUUsSUFBSTtRQUN4QnpKLElBQUksRUFBRTtVQUNKbUosSUFBSTtVQUNKTyxJQUFJLEVBQUUsQ0FBQztZQUFFekosU0FBUyxFQUFFO2NBQUUwSixLQUFLLEVBQUUsTUFBTTtjQUFFQyxPQUFPLEVBQUU7WUFBUTtVQUFFLENBQUMsQ0FBQztVQUMxRFYsS0FBSyxFQUFFO1lBQUVXLFNBQVMsRUFBRSxDQUFDO1VBQUU7UUFDekI7TUFDRixDQUFDLENBQUM7TUFDRixNQUFNQyxJQUFJLElBQUFWLFVBQUEsSUFBQUMsY0FBQSxHQUFJekcsUUFBUSxDQUFDNUMsSUFBSSxjQUFBcUosY0FBQSxnQkFBQUEsY0FBQSxHQUFkQSxjQUFBLENBQXdCUyxJQUFJLGNBQUFULGNBQUEsdUJBQTVCQSxjQUFBLENBQThCUyxJQUFJLGNBQUFWLFVBQUEsY0FBQUEsVUFBQSxHQUFJLEVBQUU7TUFDckQsTUFBTVcsSUFBSSxHQUFHRCxJQUFJLENBQUNFLEdBQUcsQ0FBRUMsQ0FBTSxJQUFLQSxDQUFDLENBQUNDLE9BQU8sQ0FBQyxDQUFDQyxNQUFNLENBQUNDLE9BQU8sQ0FBQztNQUM1RCxPQUFPckosR0FBRyxDQUFDc0IsRUFBRSxDQUFDO1FBQUVyQyxJQUFJLEVBQUU7VUFBRWtILE9BQU8sRUFBRSxJQUFJO1VBQUU2QyxJQUFJO1VBQUVNLEtBQUssRUFBRU4sSUFBSSxDQUFDTztRQUFPO01BQUUsQ0FBQyxDQUFDO0lBQ3RFLENBQUMsQ0FBQyxPQUFPbEssR0FBUSxFQUFFO01BQUEsSUFBQW1LLGNBQUE7TUFDakIsT0FBT3hKLEdBQUcsQ0FBQ0csV0FBVyxDQUFDO1FBQUVDLFVBQVUsRUFBRSxHQUFHO1FBQUVuQixJQUFJLEdBQUF1SyxjQUFBLEdBQUVuSyxHQUFHLGFBQUhBLEdBQUcsdUJBQUhBLEdBQUcsQ0FBRTZCLE9BQU8sY0FBQXNJLGNBQUEsY0FBQUEsY0FBQSxHQUFJNUgsTUFBTSxDQUFDdkMsR0FBRztNQUFFLENBQUMsQ0FBQztJQUNoRjtFQUNGLENBQ0YsQ0FBQzs7RUFFRDtFQUNBSSxNQUFNLENBQUNJLElBQUksQ0FDVDtJQUNFOUQsSUFBSSxFQUFFLHlDQUF5QztJQUMvQytELFFBQVEsRUFBRTtNQUNSYixJQUFJLEVBQUUrQyxvQkFBTSxDQUFDQyxNQUFNLENBQUM7UUFDbEJ3SCxRQUFRLEVBQUV6SCxvQkFBTSxDQUFDMEgsS0FBSyxDQUFDLENBQUMxSCxvQkFBTSxDQUFDMkgsT0FBTyxDQUFDLFNBQVMsQ0FBQyxFQUFFM0gsb0JBQU0sQ0FBQzJILE9BQU8sQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDO1FBQzVFQyxZQUFZLEVBQUU1SCxvQkFBTSxDQUFDRSxNQUFNLENBQUMsQ0FBQztRQUM3QjJILFlBQVksRUFBRTdILG9CQUFNLENBQUNFLE1BQU0sQ0FBQyxDQUFDO1FBQzdCNEgsWUFBWSxFQUFFOUgsb0JBQU0sQ0FBQ0UsTUFBTSxDQUFDLENBQUM7UUFDN0I2SCxXQUFXLEVBQUUvSCxvQkFBTSxDQUFDZSxPQUFPLENBQUMsQ0FBQztRQUM3QmlILE1BQU0sRUFBRWhJLG9CQUFNLENBQUMwSCxLQUFLLENBQUMsQ0FBQzFILG9CQUFNLENBQUMySCxPQUFPLENBQUMsS0FBSyxDQUFDLEVBQUUzSCxvQkFBTSxDQUFDMkgsT0FBTyxDQUFDLFVBQVUsQ0FBQyxDQUFDLENBQUM7UUFDekVNLFVBQVUsRUFBRWpJLG9CQUFNLENBQUNHLEtBQUssQ0FBQ0gsb0JBQU0sQ0FBQ2tJLE9BQU8sQ0FBQ2xJLG9CQUFNLENBQUNFLE1BQU0sQ0FBQyxDQUFDLENBQUM7TUFDMUQsQ0FBQztJQUNIO0VBQ0YsQ0FBQyxFQUNELE9BQU9uQyxPQUFPLEVBQUV6QyxHQUFHLEVBQUUwQyxHQUFHLEtBQUs7SUFDM0IsTUFBTUMsTUFBTSxHQUFHLElBQUFDLDJCQUFjLEVBQUMsQ0FBQztJQUMvQixJQUFJLENBQUNELE1BQU0sRUFBRTtNQUNYLE9BQU9ELEdBQUcsQ0FBQ0csV0FBVyxDQUFDO1FBQ3JCQyxVQUFVLEVBQUUsR0FBRztRQUNmbkIsSUFBSSxFQUFFO01BQ1IsQ0FBQyxDQUFDO0lBQ0o7SUFDQSxNQUFNO01BQUV4QjtJQUFLLENBQUMsR0FBR0osa0JBQWtCLENBQUNDLEdBQUcsQ0FBQztJQUN4QyxNQUFNdUIsTUFBTSxHQUFHa0IsT0FBTyxDQUFDTSxJQUFJLENBQUNDLFVBQVUsQ0FBQ3pCLE1BQU0sQ0FBQzBCLGFBQWE7SUFDM0QsTUFBTTtNQUNKa0osUUFBUTtNQUNSRyxZQUFZO01BQ1pDLFlBQVk7TUFDWkMsWUFBWTtNQUNaQyxXQUFXO01BQ1hDLE1BQU07TUFDTkM7SUFDRixDQUFDLEdBQUczTSxHQUFHLENBQUMyQixJQUFXO0lBRW5CLElBQUk7TUFBQSxJQUFBa0wsa0JBQUEsRUFBQUMsVUFBQTtNQUNGO01BQ0EsTUFBTUMsV0FBVyxHQUFHdE8sSUFBSSxDQUFDdU8sT0FBTyxDQUFDQyxTQUFTLEVBQUUsSUFBSSxFQUFFLElBQUksRUFBRSxRQUFRLEVBQUUsUUFBUSxDQUFDO01BQzNFLE1BQU1DLFlBQVksR0FDaEJmLFFBQVEsS0FBSyxTQUFTLEdBQ2xCLG1DQUFtQyxHQUNuQyxnQ0FBZ0M7TUFDdEMsTUFBTWdCLFlBQVksR0FBRzFPLElBQUksQ0FBQ3FLLElBQUksQ0FBQ2lFLFdBQVcsRUFBRUcsWUFBWSxDQUFDO01BRXpELElBQUksQ0FBQzNPLEVBQUUsQ0FBQzZPLFVBQVUsQ0FBQ0QsWUFBWSxDQUFDLEVBQUU7UUFDaEMsT0FBT3pLLEdBQUcsQ0FBQ0csV0FBVyxDQUFDO1VBQ3JCQyxVQUFVLEVBQUUsR0FBRztVQUNmbkIsSUFBSSxFQUFHLHVCQUFzQnVMLFlBQWE7UUFDNUMsQ0FBQyxDQUFDO01BQ0o7TUFDQSxJQUFJRyxhQUFhLEdBQUc5TyxFQUFFLENBQUMrTyxZQUFZLENBQUNILFlBQVksRUFBRSxPQUFPLENBQUM7O01BRTFEO01BQ0EsSUFBSWhCLFFBQVEsS0FBSyxTQUFTLEVBQUU7UUFDMUJrQixhQUFhLEdBQUdBLGFBQWEsQ0FBQ0UsT0FBTyxDQUNuQyw4QkFBOEIsRUFDN0Isb0JBQW1CakIsWUFBYSxHQUNuQyxDQUFDO1FBQ0RlLGFBQWEsR0FBR0EsYUFBYSxDQUFDRSxPQUFPLENBQ25DLDhCQUE4QixFQUM3QixvQkFBbUJoQixZQUFhLEdBQ25DLENBQUM7UUFDRDtRQUNBYyxhQUFhLEdBQUdBLGFBQWEsQ0FBQ0UsT0FBTyxDQUNuQyxpREFBaUQsRUFDaEQsdUNBQXNDZixZQUFhLEdBQ3RELENBQUM7UUFDRGEsYUFBYSxHQUFHQSxhQUFhLENBQUNFLE9BQU8sQ0FDbkMsZ0NBQWdDLEVBQy9CLDBDQUNILENBQUM7UUFDREYsYUFBYSxHQUFHQSxhQUFhLENBQUNFLE9BQU8sQ0FDbkMsNkNBQTZDLEVBQzVDLDBDQUNILENBQUM7TUFDSCxDQUFDLE1BQU07UUFDTDtRQUNBRixhQUFhLEdBQUdBLGFBQWEsQ0FBQ0UsT0FBTyxDQUNuQyxzQkFBc0IsRUFDckIsaUJBQWdCakIsWUFBYSxHQUNoQyxDQUFDO1FBQ0RlLGFBQWEsR0FBR0EsYUFBYSxDQUFDRSxPQUFPLENBQ25DLHNCQUFzQixFQUNyQixpQkFBZ0JoQixZQUFhLEdBQ2hDLENBQUM7UUFDRGMsYUFBYSxHQUFHQSxhQUFhLENBQUNFLE9BQU8sQ0FDbkMsaUJBQWlCLEVBQ2hCLGlCQUFnQmYsWUFBYSxHQUNoQyxDQUFDO1FBQ0Q7UUFDQWEsYUFBYSxHQUFHQSxhQUFhLENBQUNFLE9BQU8sQ0FDbkMsZUFBZSxFQUNmLDRCQUNGLENBQUM7UUFDREYsYUFBYSxHQUFHQSxhQUFhLENBQUNFLE9BQU8sQ0FDbkMsMkJBQTJCLEVBQzNCLCtCQUNGLENBQUM7UUFDRCxJQUFJLENBQUNkLFdBQVcsRUFBRTtVQUNoQlksYUFBYSxHQUFHQSxhQUFhLENBQUNFLE9BQU8sQ0FDbkMsa0JBQWtCLEVBQ2xCLGlCQUNGLENBQUM7UUFDSDtNQUNGOztNQUVBO01BQ0EsTUFBTUMsWUFBWSxHQUFHQyxNQUFNLENBQUNDLElBQUksQ0FBQ0wsYUFBYSxFQUFFLE9BQU8sQ0FBQyxDQUFDTSxRQUFRLENBQUMsUUFBUSxDQUFDO01BQzNFLE1BQU1DLEVBQUUsR0FBRyxJQUFJL0wsSUFBSSxDQUFDLENBQUMsQ0FBQ0MsV0FBVyxDQUFDLENBQUMsQ0FBQ3lMLE9BQU8sQ0FBQyxPQUFPLEVBQUUsR0FBRyxDQUFDLENBQUNNLEtBQUssQ0FBQyxDQUFDLEVBQUUsRUFBRSxDQUFDO01BQ3RFLE1BQU1DLFdBQVcsR0FBSSx3QkFBdUIzQixRQUFTLE1BQUt5QixFQUFHLEVBQUM7TUFDOUQsTUFBTUcsV0FBVyxHQUFJLDhCQUE2QjVCLFFBQVMsd0NBQXVDLElBQUl0SyxJQUFJLENBQUMsQ0FBQyxDQUFDQyxXQUFXLENBQUMsQ0FBRSxHQUFFOztNQUU3SDtNQUNBLElBQUlrTSxZQUFpRDtNQUNyRCxJQUFJN0IsUUFBUSxLQUFLLFNBQVMsRUFBRTtRQUMxQjZCLFlBQVksR0FBRyxNQUFNLElBQUFDLG1DQUFzQixFQUN6Q3RMLE1BQU0sRUFDTm1MLFdBQVcsRUFDWE4sWUFBWSxFQUNaTyxXQUNGLENBQUM7TUFDSCxDQUFDLE1BQU07UUFDTEMsWUFBWSxHQUFHLE1BQU0sSUFBQUUsOEJBQWlCLEVBQ3BDdkwsTUFBTSxFQUNObUwsV0FBVyxFQUNYTixZQUFZLEVBQ1pPLFdBQ0YsQ0FBQztNQUNIOztNQUVBO01BQ0EsSUFBSUksT0FBTyxHQUFHLEtBQUs7TUFDbkIsSUFBSUMsU0FBUyxHQUFHLGFBQWE7TUFDN0IsSUFBSTFCLE1BQU0sS0FBSyxVQUFVLElBQUlDLFVBQVUsSUFBSUEsVUFBVSxDQUFDVixNQUFNLEdBQUcsQ0FBQyxFQUFFO1FBQ2hFLElBQUk7VUFDRixNQUFNb0MsUUFBUSxHQUFHLE1BQU0sSUFBQUMsMENBQTZCLEVBQUMzTCxNQUFNLEVBQUVnSyxVQUFVLENBQUM7VUFDeEUsSUFBSTBCLFFBQVEsQ0FBQ3BDLE1BQU0sS0FBSyxDQUFDLEVBQUU7WUFDekIsT0FBT3ZKLEdBQUcsQ0FBQ0csV0FBVyxDQUFDO2NBQ3JCQyxVQUFVLEVBQUUsR0FBRztjQUNmbkIsSUFBSSxFQUFFO1lBQ1IsQ0FBQyxDQUFDO1VBQ0o7VUFDQXlNLFNBQVMsR0FBSSx1QkFBc0JqQyxRQUFTLElBQUd5QixFQUFHLEVBQUM7VUFDbkRPLE9BQU8sR0FBRyxNQUFNLElBQUFJLGdDQUFtQixFQUFDNUwsTUFBTSxFQUFFeUwsU0FBUyxDQUFDO1VBQ3RELE1BQU0sSUFBQUksOEJBQWlCLEVBQ3JCN0wsTUFBTSxFQUNOd0wsT0FBTyxFQUNQRSxRQUFRLENBQUMxQyxHQUFHLENBQUU4QyxDQUFDLElBQUtBLENBQUMsQ0FBQ0MsZUFBZSxDQUN2QyxDQUFDO1FBQ0gsQ0FBQyxDQUFDLE9BQU9DLFFBQWEsRUFBRTtVQUFBLElBQUFDLGlCQUFBLEVBQUFDLGtCQUFBLEVBQUFDLGtCQUFBO1VBQ3RCLElBQ0UsQ0FBQUYsaUJBQUEsR0FBQUQsUUFBUSxDQUFDL0ssT0FBTyxjQUFBZ0wsaUJBQUEsZUFBaEJBLGlCQUFBLENBQWtCakcsUUFBUSxDQUFDLGVBQWUsQ0FBQyxLQUFBa0csa0JBQUEsR0FDM0NGLFFBQVEsQ0FBQy9LLE9BQU8sY0FBQWlMLGtCQUFBLGVBQWhCQSxrQkFBQSxDQUFrQmxHLFFBQVEsQ0FBQyxXQUFXLENBQUMsS0FBQW1HLGtCQUFBLEdBQ3ZDSCxRQUFRLENBQUMvSyxPQUFPLGNBQUFrTCxrQkFBQSxlQUFoQkEsa0JBQUEsQ0FBa0JuRyxRQUFRLENBQUMseUJBQXlCLENBQUMsRUFDckQ7WUFDQSxPQUFPakcsR0FBRyxDQUFDRyxXQUFXLENBQUM7Y0FDckJDLFVBQVUsRUFBRSxHQUFHO2NBQ2ZuQixJQUFJLEVBQUU7WUFDUixDQUFDLENBQUM7VUFDSjtVQUNBLE1BQU1nTixRQUFRO1FBQ2hCO01BQ0Y7TUFFQSxNQUFNSSxVQUFVLEdBQUc1QyxRQUFRLEtBQUssU0FBUyxHQUFHLFlBQVksR0FBRyxPQUFPO01BQ2xFLE1BQU0sSUFBQTdFLHlCQUFZLEVBQUMzRSxNQUFNLEVBQUVxTCxZQUFZLENBQUN6SCxFQUFFLEVBQUV3SSxVQUFVLEVBQUVaLE9BQU8sQ0FBQzs7TUFFaEU7TUFDQSxNQUFNN00sYUFBYSxDQUFDQyxNQUFNLEVBQUU7UUFDMUJrQyxNQUFNLEVBQUUsb0JBQW9CO1FBQzVCTixnQkFBZ0IsRUFBRSxFQUFFO1FBQ3BCRSxXQUFXLEVBQUcsR0FBRThJLFFBQVMsS0FBSU8sTUFBTSxLQUFLLEtBQUssR0FBRyxhQUFhLEdBQUksSUFBQUcsa0JBQUEsR0FBRUYsVUFBVSxhQUFWQSxVQUFVLHVCQUFWQSxVQUFVLENBQUVWLE1BQU0sY0FBQVksa0JBQUEsY0FBQUEsa0JBQUEsR0FBSSxDQUFFLFdBQVcsR0FBRTtRQUN4R25KLFlBQVksRUFBRXZELElBQUk7UUFDbEJFLElBQUksRUFBRSxFQUFBeU0sVUFBQSxHQUFDOU0sR0FBRyxDQUFTSSxPQUFPLGNBQUEwTSxVQUFBLHVCQUFwQkEsVUFBQSxDQUF1QixlQUFlLENBQUMsS0FBSSxpQkFBaUI7UUFDbEVuSixNQUFNLEVBQUUsU0FBUztRQUNqQkMsT0FBTyxFQUFHLDZDQUE0Q29LLFlBQVksQ0FBQ0YsV0FBWSxNQUFLTSxTQUFVO01BQ2hHLENBQUMsQ0FBQztNQUVGLE9BQU8xTCxHQUFHLENBQUNzQixFQUFFLENBQUM7UUFDWnJDLElBQUksRUFBRTtVQUNKa0gsT0FBTyxFQUFFLElBQUk7VUFDYnBGLE1BQU0sRUFBRSxvQkFBb0I7VUFDNUJ3RCxTQUFTLEVBQUUrRyxZQUFZLENBQUN6SCxFQUFFO1VBQzFCeUksV0FBVyxFQUFFaEIsWUFBWSxDQUFDRixXQUFXO1VBQ3JDbUIsV0FBVyxFQUFFYixTQUFTO1VBQ3RCakMsUUFBUTtVQUNSdkssU0FBUyxFQUFFLElBQUlDLElBQUksQ0FBQyxDQUFDLENBQUNDLFdBQVcsQ0FBQyxDQUFDO1VBQ25DOEIsT0FBTyxFQUFHLG9FQUFtRXdLLFNBQVU7UUFDekY7TUFDRixDQUFDLENBQUM7SUFDSixDQUFDLENBQUMsT0FBT3JNLEdBQVEsRUFBRTtNQUFBLElBQUFtTixVQUFBLEVBQUFDLGNBQUEsRUFBQUMsY0FBQSxFQUFBQyxjQUFBO01BQ2pCLE1BQU0vTixhQUFhLENBQUNDLE1BQU0sRUFBRTtRQUMxQmtDLE1BQU0sRUFBRSxvQkFBb0I7UUFDNUJOLGdCQUFnQixFQUFFLEVBQUU7UUFDcEJFLFdBQVcsRUFBRyxHQUFFOEksUUFBUyxLQUFJTyxNQUFPLEdBQUU7UUFDdENoSixZQUFZLEVBQUV2RCxJQUFJO1FBQ2xCRSxJQUFJLEVBQUUsRUFBQTZPLFVBQUEsR0FBQ2xQLEdBQUcsQ0FBU0ksT0FBTyxjQUFBOE8sVUFBQSx1QkFBcEJBLFVBQUEsQ0FBdUIsZUFBZSxDQUFDLEtBQUksaUJBQWlCO1FBQ2xFdkwsTUFBTSxFQUFFLFNBQVM7UUFDakJDLE9BQU8sR0FBQXVMLGNBQUEsR0FBRXBOLEdBQUcsYUFBSEEsR0FBRyx1QkFBSEEsR0FBRyxDQUFFNkIsT0FBTyxjQUFBdUwsY0FBQSxjQUFBQSxjQUFBLEdBQUk3SyxNQUFNLENBQUN2QyxHQUFHO01BQ3JDLENBQUMsQ0FBQztNQUNGLE9BQU9XLEdBQUcsQ0FBQ0csV0FBVyxDQUFDO1FBQ3JCQyxVQUFVLEVBQUUsQ0FBQWYsR0FBRyxhQUFIQSxHQUFHLGdCQUFBcU4sY0FBQSxHQUFIck4sR0FBRyxDQUFFd0MsUUFBUSxjQUFBNkssY0FBQSx1QkFBYkEsY0FBQSxDQUFlekwsTUFBTSxLQUFJLEdBQUc7UUFDeENoQyxJQUFJLEdBQUEwTixjQUFBLEdBQUV0TixHQUFHLGFBQUhBLEdBQUcsdUJBQUhBLEdBQUcsQ0FBRTZCLE9BQU8sY0FBQXlMLGNBQUEsY0FBQUEsY0FBQSxHQUFJL0ssTUFBTSxDQUFDdkMsR0FBRztNQUNsQyxDQUFDLENBQUM7SUFDSjtFQUNGLENBQ0YsQ0FBQztBQUNIIn0=