"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.registerIntuneRoutes = registerIntuneRoutes;
var _graphClient = require("../lib/graph-client");
var _configSchema = require("@osd/config-schema");
var _constants = require("../../common/constants");
/*
 * Intune Plugin - Server routes (OpenSearch queries + Graph API for status)
 */

function getClient(context) {
  return context.core.opensearch.client.asCurrentUser;
}
function registerIntuneRoutes(router) {
  // GET devices list (with optional filters)
  router.get({
    path: '/api/intune_plugin/devices',
    validate: {
      query: _configSchema.schema.object({
        size: _configSchema.schema.maybe(_configSchema.schema.number()),
        from: _configSchema.schema.maybe(_configSchema.schema.number()),
        compliance_state: _configSchema.schema.maybe(_configSchema.schema.string()),
        operating_system: _configSchema.schema.maybe(_configSchema.schema.string()),
        device_category: _configSchema.schema.maybe(_configSchema.schema.string())
      })
    }
  }, async (context, req, res) => {
    try {
      var _hits, _response$body, _hits$hits;
      const client = getClient(context);
      const {
        size = 50,
        from = 0,
        compliance_state,
        operating_system,
        device_category
      } = req.query;
      const must = [];
      if (compliance_state) must.push({
        term: {
          compliance_state
        }
      });
      if (operating_system) must.push({
        term: {
          operating_system
        }
      });
      if (device_category) must.push({
        term: {
          device_category
        }
      });
      const body = {
        size,
        from,
        sort: [{
          last_sync_at: {
            order: 'desc'
          }
        }, {
          device_name: 'asc'
        }],
        query: must.length ? {
          bool: {
            must
          }
        } : {
          match_all: {}
        }
      };
      const response = await client.search({
        index: _constants.INTUNE_DEVICES_INDEX,
        ignore_unavailable: true,
        body
      });
      const hits = (_hits = (_response$body = response.body) === null || _response$body === void 0 ? void 0 : _response$body.hits) !== null && _hits !== void 0 ? _hits : {};
      return res.ok({
        body: {
          hits: (_hits$hits = hits.hits) !== null && _hits$hits !== void 0 ? _hits$hits : [],
          total: hits.total
        }
      });
    } catch (err) {
      var _err$statusCode, _err$message;
      return res.customError({
        statusCode: (_err$statusCode = err.statusCode) !== null && _err$statusCode !== void 0 ? _err$statusCode : 500,
        body: (_err$message = err.message) !== null && _err$message !== void 0 ? _err$message : String(err)
      });
    }
  });

  // GET users aggregation (users with their devices)
  router.get({
    path: '/api/intune_plugin/users',
    validate: {
      query: _configSchema.schema.object({
        size: _configSchema.schema.maybe(_configSchema.schema.number())
      })
    }
  }, async (context, req, res) => {
    try {
      var _req$query$size, _aggregations$by_user, _response$body2, _aggs$buckets;
      const client = getClient(context);
      const size = (_req$query$size = req.query.size) !== null && _req$query$size !== void 0 ? _req$query$size : 100;
      const body = {
        size: 0,
        aggs: {
          by_user: {
            terms: {
              field: 'user_principal_name',
              size: 500,
              missing: '—'
            },
            aggs: {
              devices: {
                top_hits: {
                  size: 50,
                  _source: ['device_name', 'compliance_state', 'operating_system', 'last_sync_at']
                }
              }
            }
          }
        }
      };
      const response = await client.search({
        index: _constants.INTUNE_DEVICES_INDEX,
        ignore_unavailable: true,
        body
      });
      const aggs = (_aggregations$by_user = (_response$body2 = response.body) === null || _response$body2 === void 0 || (_response$body2 = _response$body2.aggregations) === null || _response$body2 === void 0 ? void 0 : _response$body2.by_user) !== null && _aggregations$by_user !== void 0 ? _aggregations$by_user : {};
      const buckets = (_aggs$buckets = aggs.buckets) !== null && _aggs$buckets !== void 0 ? _aggs$buckets : [];
      return res.ok({
        body: {
          users: buckets,
          size
        }
      });
    } catch (err) {
      var _err$statusCode2, _err$message2;
      return res.customError({
        statusCode: (_err$statusCode2 = err.statusCode) !== null && _err$statusCode2 !== void 0 ? _err$statusCode2 : 500,
        body: (_err$message2 = err.message) !== null && _err$message2 !== void 0 ? _err$message2 : String(err)
      });
    }
  });

  // GET compliance overview (aggregations)
  router.get({
    path: '/api/intune_plugin/compliance',
    validate: false
  }, async (context, req, res) => {
    try {
      var _aggregations, _response$body3, _aggs$by_compliance$b, _aggs$by_compliance, _aggs$by_os$buckets, _aggs$by_os;
      const client = getClient(context);
      const body = {
        size: 0,
        aggs: {
          by_compliance: {
            terms: {
              field: 'compliance_state',
              size: 20
            }
          },
          by_os: {
            terms: {
              field: 'operating_system',
              size: 10
            }
          }
        }
      };
      const response = await client.search({
        index: _constants.INTUNE_DEVICES_INDEX,
        ignore_unavailable: true,
        body
      });
      const aggs = (_aggregations = (_response$body3 = response.body) === null || _response$body3 === void 0 ? void 0 : _response$body3.aggregations) !== null && _aggregations !== void 0 ? _aggregations : {};
      return res.ok({
        body: {
          by_compliance: (_aggs$by_compliance$b = (_aggs$by_compliance = aggs.by_compliance) === null || _aggs$by_compliance === void 0 ? void 0 : _aggs$by_compliance.buckets) !== null && _aggs$by_compliance$b !== void 0 ? _aggs$by_compliance$b : [],
          by_os: (_aggs$by_os$buckets = (_aggs$by_os = aggs.by_os) === null || _aggs$by_os === void 0 ? void 0 : _aggs$by_os.buckets) !== null && _aggs$by_os$buckets !== void 0 ? _aggs$by_os$buckets : []
        }
      });
    } catch (err) {
      var _err$statusCode3, _err$message3;
      return res.customError({
        statusCode: (_err$statusCode3 = err.statusCode) !== null && _err$statusCode3 !== void 0 ? _err$statusCode3 : 500,
        body: (_err$message3 = err.message) !== null && _err$message3 !== void 0 ? _err$message3 : String(err)
      });
    }
  });

  // GET overview (dashboard-style: devices, compliance, ownership, top apps)
  router.get({
    path: '/api/intune_plugin/overview',
    validate: false
  }, async (context, req, res) => {
    try {
      var _hits2, _devicesRes$body, _aggregations2, _devicesRes$body2, _devicesBody$hits, _devicesAggs$by_compl, _devicesAggs$by_compl2, _devicesAggs$by_os$bu, _devicesAggs$by_os;
      const client = getClient(context);
      const devicesRes = await client.search({
        index: _constants.INTUNE_DEVICES_INDEX,
        ignore_unavailable: true,
        body: {
          size: 5,
          sort: [{
            last_sync_at: {
              order: 'desc',
              missing: '_last'
            }
          }, {
            device_name: 'asc'
          }],
          query: {
            match_all: {}
          },
          aggs: {
            by_compliance: {
              terms: {
                field: 'compliance_state',
                size: 10
              }
            },
            by_os: {
              terms: {
                field: 'operating_system',
                size: 10
              }
            }
          }
        }
      });
      let by_owner = [];
      try {
        var _aggregations$by_owne, _ownerRes$body;
        const ownerRes = await client.search({
          index: _constants.INTUNE_DEVICES_INDEX,
          ignore_unavailable: true,
          body: {
            size: 0,
            aggs: {
              by_owner: {
                terms: {
                  field: 'managed_device_owner_type',
                  size: 10
                }
              }
            }
          }
        });
        by_owner = (_aggregations$by_owne = (_ownerRes$body = ownerRes.body) === null || _ownerRes$body === void 0 || (_ownerRes$body = _ownerRes$body.aggregations) === null || _ownerRes$body === void 0 || (_ownerRes$body = _ownerRes$body.by_owner) === null || _ownerRes$body === void 0 ? void 0 : _ownerRes$body.buckets) !== null && _aggregations$by_owne !== void 0 ? _aggregations$by_owne : [];
      } catch {
        by_owner = [];
      }
      let top_apps = [];
      try {
        var _hits$hits2, _appsRes$body;
        const appsRes = await client.search({
          index: _constants.INTUNE_DETECTED_APPS_INDEX,
          ignore_unavailable: true,
          body: {
            size: 10,
            sort: [{
              device_count: {
                order: 'desc'
              }
            }],
            _source: ['display_name', 'device_count', 'platform'],
            query: {
              match_all: {}
            }
          }
        });
        const appsHits = (_hits$hits2 = (_appsRes$body = appsRes.body) === null || _appsRes$body === void 0 || (_appsRes$body = _appsRes$body.hits) === null || _appsRes$body === void 0 ? void 0 : _appsRes$body.hits) !== null && _hits$hits2 !== void 0 ? _hits$hits2 : [];
        top_apps = appsHits.map(h => h._source).filter(Boolean);
      } catch {
        top_apps = [];
      }
      const devicesBody = (_hits2 = (_devicesRes$body = devicesRes.body) === null || _devicesRes$body === void 0 ? void 0 : _devicesRes$body.hits) !== null && _hits2 !== void 0 ? _hits2 : {};
      const devicesAggs = (_aggregations2 = (_devicesRes$body2 = devicesRes.body) === null || _devicesRes$body2 === void 0 ? void 0 : _devicesRes$body2.aggregations) !== null && _aggregations2 !== void 0 ? _aggregations2 : {};
      const recent_devices = ((_devicesBody$hits = devicesBody.hits) !== null && _devicesBody$hits !== void 0 ? _devicesBody$hits : []).map(h => h._source).filter(Boolean);
      let mobile_apps_count = 0;
      let compliance_policies_count = 0;
      let top_non_compliant = [];
      let enrollment_count = 0;
      let scripts_count = 0;
      let linked_agents_count = 0;
      let stale_devices_count = 0;
      try {
        var _count, _appsCountRes$body, _count2, _policiesCountRes$bod, _hits$hits3, _nonCompliantRes$body, _count3, _enrollRes$body, _count4, _scriptsRes$body, _count5, _identityRes$body, _count6, _staleRes$body;
        const staleDate = new Date(Date.now() - 7 * 24 * 60 * 60 * 1000).toISOString();
        const [appsCountRes, policiesCountRes, nonCompliantRes, enrollRes, scriptsRes, identityRes, staleRes] = await Promise.all([client.count({
          index: _constants.INTUNE_MOBILE_APPS_INDEX,
          ignore_unavailable: true
        }), client.count({
          index: _constants.INTUNE_COMPLIANCE_POLICIES_INDEX,
          ignore_unavailable: true
        }), client.search({
          index: _constants.INTUNE_DEVICES_INDEX,
          ignore_unavailable: true,
          body: {
            size: 5,
            sort: [{
              last_sync_at: {
                order: 'desc',
                missing: '_last'
              }
            }],
            query: {
              term: {
                compliance_state: 'noncompliant'
              }
            },
            _source: ['device_name', 'user_principal_name', 'operating_system', 'compliance_state', 'last_sync_at']
          }
        }), client.count({
          index: _constants.INTUNE_ENROLLMENT_INDEX,
          ignore_unavailable: true
        }).catch(() => ({
          body: {
            count: 0
          }
        })), client.count({
          index: _constants.INTUNE_SCRIPTS_INDEX,
          ignore_unavailable: true
        }).catch(() => ({
          body: {
            count: 0
          }
        })), client.count({
          index: _constants.INTUNE_DEVICE_IDENTITY_INDEX,
          ignore_unavailable: true
        }).catch(() => ({
          body: {
            count: 0
          }
        })), client.count({
          index: _constants.INTUNE_DEVICES_INDEX,
          ignore_unavailable: true,
          body: {
            query: {
              range: {
                last_sync_at: {
                  lt: staleDate
                }
              }
            }
          }
        }).catch(() => ({
          body: {
            count: 0
          }
        }))]);
        mobile_apps_count = (_count = (_appsCountRes$body = appsCountRes.body) === null || _appsCountRes$body === void 0 ? void 0 : _appsCountRes$body.count) !== null && _count !== void 0 ? _count : 0;
        compliance_policies_count = (_count2 = (_policiesCountRes$bod = policiesCountRes.body) === null || _policiesCountRes$bod === void 0 ? void 0 : _policiesCountRes$bod.count) !== null && _count2 !== void 0 ? _count2 : 0;
        const ncHits = (_hits$hits3 = (_nonCompliantRes$body = nonCompliantRes.body) === null || _nonCompliantRes$body === void 0 || (_nonCompliantRes$body = _nonCompliantRes$body.hits) === null || _nonCompliantRes$body === void 0 ? void 0 : _nonCompliantRes$body.hits) !== null && _hits$hits3 !== void 0 ? _hits$hits3 : [];
        top_non_compliant = ncHits.map(h => h._source).filter(Boolean);
        enrollment_count = (_count3 = (_enrollRes$body = enrollRes.body) === null || _enrollRes$body === void 0 ? void 0 : _enrollRes$body.count) !== null && _count3 !== void 0 ? _count3 : 0;
        scripts_count = (_count4 = (_scriptsRes$body = scriptsRes.body) === null || _scriptsRes$body === void 0 ? void 0 : _scriptsRes$body.count) !== null && _count4 !== void 0 ? _count4 : 0;
        linked_agents_count = (_count5 = (_identityRes$body = identityRes.body) === null || _identityRes$body === void 0 ? void 0 : _identityRes$body.count) !== null && _count5 !== void 0 ? _count5 : 0;
        stale_devices_count = (_count6 = (_staleRes$body = staleRes.body) === null || _staleRes$body === void 0 ? void 0 : _staleRes$body.count) !== null && _count6 !== void 0 ? _count6 : 0;
      } catch {
        /* ignore */
      }
      return res.ok({
        body: {
          by_compliance: (_devicesAggs$by_compl = (_devicesAggs$by_compl2 = devicesAggs.by_compliance) === null || _devicesAggs$by_compl2 === void 0 ? void 0 : _devicesAggs$by_compl2.buckets) !== null && _devicesAggs$by_compl !== void 0 ? _devicesAggs$by_compl : [],
          by_os: (_devicesAggs$by_os$bu = (_devicesAggs$by_os = devicesAggs.by_os) === null || _devicesAggs$by_os === void 0 ? void 0 : _devicesAggs$by_os.buckets) !== null && _devicesAggs$by_os$bu !== void 0 ? _devicesAggs$by_os$bu : [],
          by_owner,
          top_apps,
          recent_devices,
          mobile_apps_count,
          compliance_policies_count,
          top_non_compliant_devices: top_non_compliant,
          enrollment_count,
          scripts_count,
          linked_agents_count,
          stale_devices_count
        }
      });
    } catch (err) {
      var _err$statusCode4, _err$message4;
      return res.customError({
        statusCode: (_err$statusCode4 = err.statusCode) !== null && _err$statusCode4 !== void 0 ? _err$statusCode4 : 500,
        body: (_err$message4 = err.message) !== null && _err$message4 !== void 0 ? _err$message4 : String(err)
      });
    }
  });

  // GET alert enrichment: Wazuh alerts from Intune-correlated agents only,
  // with time range, pagination, and Intune compliance/user/device context
  router.post({
    path: '/api/intune_plugin/alerts_enrichment',
    validate: {
      body: _configSchema.schema.object({
        size: _configSchema.schema.maybe(_configSchema.schema.number()),
        from: _configSchema.schema.maybe(_configSchema.schema.number()),
        time_from: _configSchema.schema.maybe(_configSchema.schema.string()),
        time_to: _configSchema.schema.maybe(_configSchema.schema.string()),
        intune_correlated_only: _configSchema.schema.maybe(_configSchema.schema.boolean())
      })
    }
  }, async (context, req, res) => {
    try {
      var _hits$hits5, _alertsResponse$body, _ref, _hits$total$value, _countResponse$body, _countResponse$body2;
      const client = getClient(context);
      const {
        size = 25,
        from = 0,
        time_from,
        time_to,
        intune_correlated_only = true
      } = req.body;

      // Time range filter (required for meaningful results)
      const now = new Date();
      const defaultTo = now.toISOString();
      const defaultFrom = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000).toISOString();
      const timeGte = time_from || defaultFrom;
      const timeLte = time_to || defaultTo;
      const timeRangeFilter = {
        range: {
          timestamp: {
            gte: timeGte,
            lte: timeLte
          }
        }
      };
      let agentIdsToQuery = null;
      let agentToIntuneId = {};
      let devicesMap = {};
      if (intune_correlated_only) {
        var _hits$hits4, _identityRes$body2;
        // Fetch all linked Wazuh agent IDs from identity index
        const identityRes = await client.search({
          index: _constants.INTUNE_DEVICE_IDENTITY_INDEX,
          ignore_unavailable: true,
          body: {
            size: 1000,
            _source: ['wazuh_agent_id', 'intune_device_id'],
            query: {
              match_all: {}
            }
          }
        });
        const identityHits = (_hits$hits4 = (_identityRes$body2 = identityRes.body) === null || _identityRes$body2 === void 0 || (_identityRes$body2 = _identityRes$body2.hits) === null || _identityRes$body2 === void 0 ? void 0 : _identityRes$body2.hits) !== null && _hits$hits4 !== void 0 ? _hits$hits4 : [];
        agentIdsToQuery = identityHits.map(h => {
          var _h$_source;
          return (_h$_source = h._source) === null || _h$_source === void 0 ? void 0 : _h$_source.wazuh_agent_id;
        }).filter(id => id && id !== '000');
        if (agentIdsToQuery.length === 0) {
          return res.ok({
            body: {
              alerts: [],
              enrichments: {},
              total: 0,
              identity_count: 0
            }
          });
        }
        identityHits.forEach(h => {
          const s = h._source;
          if (s !== null && s !== void 0 && s.wazuh_agent_id) agentToIntuneId[s.wazuh_agent_id] = s.intune_device_id;
        });
      }

      // Build alerts query: exclude agent 000 (manager), apply time range,
      // and optionally restrict to Intune-correlated agents only
      const must = [timeRangeFilter];
      must.push({
        bool: {
          must_not: [{
            term: {
              'agent.id': '000'
            }
          }]
        }
      });
      if (agentIdsToQuery && agentIdsToQuery.length > 0) {
        must.push({
          terms: {
            'agent.id': agentIdsToQuery
          }
        });
      }
      const alertsBody = {
        from,
        size,
        sort: [{
          timestamp: {
            order: 'desc'
          }
        }],
        _source: ['agent.id', 'agent.name', 'rule.description', 'rule.level', 'timestamp'],
        query: {
          bool: {
            must
          }
        }
      };
      const [alertsResponse, countResponse] = await Promise.all([client.search({
        index: _constants.WAZUH_ALERTS_PATTERN,
        ignore_unavailable: true,
        body: alertsBody
      }), client.search({
        index: _constants.WAZUH_ALERTS_PATTERN,
        ignore_unavailable: true,
        body: {
          size: 0,
          query: alertsBody.query,
          track_total_hits: true
        }
      })]);
      const alertHits = (_hits$hits5 = (_alertsResponse$body = alertsResponse.body) === null || _alertsResponse$body === void 0 || (_alertsResponse$body = _alertsResponse$body.hits) === null || _alertsResponse$body === void 0 ? void 0 : _alertsResponse$body.hits) !== null && _hits$hits5 !== void 0 ? _hits$hits5 : [];
      const total = (_ref = (_hits$total$value = (_countResponse$body = countResponse.body) === null || _countResponse$body === void 0 || (_countResponse$body = _countResponse$body.hits) === null || _countResponse$body === void 0 || (_countResponse$body = _countResponse$body.total) === null || _countResponse$body === void 0 ? void 0 : _countResponse$body.value) !== null && _hits$total$value !== void 0 ? _hits$total$value : (_countResponse$body2 = countResponse.body) === null || _countResponse$body2 === void 0 || (_countResponse$body2 = _countResponse$body2.hits) === null || _countResponse$body2 === void 0 ? void 0 : _countResponse$body2.total) !== null && _ref !== void 0 ? _ref : 0;
      const agentIds = [...new Set(alertHits.map(h => {
        var _h$_source2;
        return (_h$_source2 = h._source) === null || _h$_source2 === void 0 ? void 0 : _h$_source2['agent.id'];
      }).filter(Boolean))];
      if (agentIds.length > 0) {
        var _hits$hits6, _identityLookup$body;
        const identityLookup = await client.search({
          index: _constants.INTUNE_DEVICE_IDENTITY_INDEX,
          ignore_unavailable: true,
          body: {
            size: 500,
            query: {
              terms: {
                wazuh_agent_id: agentIds
              }
            },
            _source: ['wazuh_agent_id', 'intune_device_id']
          }
        });
        const lookupHits = (_hits$hits6 = (_identityLookup$body = identityLookup.body) === null || _identityLookup$body === void 0 || (_identityLookup$body = _identityLookup$body.hits) === null || _identityLookup$body === void 0 ? void 0 : _identityLookup$body.hits) !== null && _hits$hits6 !== void 0 ? _hits$hits6 : [];
        lookupHits.forEach(h => {
          const s = h._source;
          if (s !== null && s !== void 0 && s.wazuh_agent_id) agentToIntuneId[s.wazuh_agent_id] = s.intune_device_id;
        });
      }
      const intuneIds = [...new Set(Object.values(agentToIntuneId).filter(Boolean))];
      if (intuneIds.length > 0) {
        var _hits$hits7, _devRes$body;
        const devRes = await client.search({
          index: _constants.INTUNE_DEVICES_INDEX,
          ignore_unavailable: true,
          body: {
            size: intuneIds.length,
            query: {
              terms: {
                intune_device_id: intuneIds
              }
            },
            _source: ['intune_device_id', 'compliance_state', 'device_name', 'user_principal_name']
          }
        });
        const devHits = (_hits$hits7 = (_devRes$body = devRes.body) === null || _devRes$body === void 0 || (_devRes$body = _devRes$body.hits) === null || _devRes$body === void 0 ? void 0 : _devRes$body.hits) !== null && _hits$hits7 !== void 0 ? _hits$hits7 : [];
        devHits.forEach(h => {
          const s = h._source;
          if (s !== null && s !== void 0 && s.intune_device_id) devicesMap[s.intune_device_id] = s;
        });
      }
      const enrichments = {};
      Object.entries(agentToIntuneId).forEach(([agentId, intuneId]) => {
        var _devicesMap$intuneId;
        enrichments[agentId] = (_devicesMap$intuneId = devicesMap[intuneId]) !== null && _devicesMap$intuneId !== void 0 ? _devicesMap$intuneId : null;
      });
      return res.ok({
        body: {
          alerts: alertHits,
          enrichments,
          total,
          identity_count: Object.keys(agentToIntuneId).length
        }
      });
    } catch (err) {
      var _err$statusCode5, _err$message5;
      return res.customError({
        statusCode: (_err$statusCode5 = err.statusCode) !== null && _err$statusCode5 !== void 0 ? _err$statusCode5 : 500,
        body: (_err$message5 = err.message) !== null && _err$message5 !== void 0 ? _err$message5 : String(err)
      });
    }
  });

  // GET Intune audit events (synced from Graph deviceManagement/auditEvents)
  router.get({
    path: '/api/intune_plugin/intune_audit_events',
    validate: {
      query: _configSchema.schema.object({
        size: _configSchema.schema.maybe(_configSchema.schema.number())
      })
    }
  }, async (context, req, res) => {
    try {
      var _req$query$size2, _hits3, _response$body4, _hits$hits8, _hits$total;
      const client = getClient(context);
      const size = (_req$query$size2 = req.query.size) !== null && _req$query$size2 !== void 0 ? _req$query$size2 : 100;
      const body = {
        size,
        sort: [{
          activity_date_time: {
            order: 'desc'
          }
        }],
        query: {
          match_all: {}
        }
      };
      const response = await client.search({
        index: _constants.INTUNE_AUDIT_EVENTS_INDEX,
        ignore_unavailable: true,
        body
      });
      const hits = (_hits3 = (_response$body4 = response.body) === null || _response$body4 === void 0 ? void 0 : _response$body4.hits) !== null && _hits3 !== void 0 ? _hits3 : {};
      return res.ok({
        body: {
          events: ((_hits$hits8 = hits.hits) !== null && _hits$hits8 !== void 0 ? _hits$hits8 : []).map(h => h._source).filter(Boolean),
          total: (_hits$total = hits.total) !== null && _hits$total !== void 0 ? _hits$total : {
            value: 0
          }
        }
      });
    } catch (err) {
      var _err$statusCode6, _err$message6;
      return res.customError({
        statusCode: (_err$statusCode6 = err.statusCode) !== null && _err$statusCode6 !== void 0 ? _err$statusCode6 : 500,
        body: (_err$message6 = err.message) !== null && _err$message6 !== void 0 ? _err$message6 : String(err)
      });
    }
  });

  // GET detected apps
  router.get({
    path: '/api/intune_plugin/detected_apps',
    validate: {
      query: _configSchema.schema.object({
        size: _configSchema.schema.maybe(_configSchema.schema.number()),
        from: _configSchema.schema.maybe(_configSchema.schema.number())
      })
    }
  }, async (context, req, res) => {
    try {
      var _req$query$size3, _req$query$from, _hits4, _response$body5, _hits$hits9, _hits$total2;
      const client = getClient(context);
      const size = (_req$query$size3 = req.query.size) !== null && _req$query$size3 !== void 0 ? _req$query$size3 : 50;
      const from = (_req$query$from = req.query.from) !== null && _req$query$from !== void 0 ? _req$query$from : 0;
      const body = {
        size,
        from,
        sort: [{
          device_count: {
            order: 'desc',
            missing: '_last'
          }
        }, {
          'display_name.keyword': {
            order: 'asc',
            missing: '_last'
          }
        }],
        query: {
          match_all: {}
        }
      };
      const response = await client.search({
        index: _constants.INTUNE_DETECTED_APPS_INDEX,
        ignore_unavailable: true,
        body
      });
      const hits = (_hits4 = (_response$body5 = response.body) === null || _response$body5 === void 0 ? void 0 : _response$body5.hits) !== null && _hits4 !== void 0 ? _hits4 : {};
      return res.ok({
        body: {
          apps: ((_hits$hits9 = hits.hits) !== null && _hits$hits9 !== void 0 ? _hits$hits9 : []).map(h => h._source).filter(Boolean),
          total: (_hits$total2 = hits.total) !== null && _hits$total2 !== void 0 ? _hits$total2 : {
            value: 0
          }
        }
      });
    } catch (err) {
      var _err$statusCode7, _err$message7;
      return res.customError({
        statusCode: (_err$statusCode7 = err.statusCode) !== null && _err$statusCode7 !== void 0 ? _err$statusCode7 : 500,
        body: (_err$message7 = err.message) !== null && _err$message7 !== void 0 ? _err$message7 : String(err)
      });
    }
  });

  // GET mobile apps (from deviceAppManagement)
  router.get({
    path: '/api/intune_plugin/mobile_apps',
    validate: {
      query: _configSchema.schema.object({
        size: _configSchema.schema.maybe(_configSchema.schema.number()),
        from: _configSchema.schema.maybe(_configSchema.schema.number()),
        app_type: _configSchema.schema.maybe(_configSchema.schema.string()),
        publish_state: _configSchema.schema.maybe(_configSchema.schema.string())
      })
    }
  }, async (context, req, res) => {
    try {
      var _hits5, _response$body6, _hits$hits10;
      const client = getClient(context);
      const {
        size = 50,
        from = 0,
        app_type,
        publish_state
      } = req.query;
      const must = [];
      if (app_type) must.push({
        term: {
          app_type
        }
      });
      if (publish_state) must.push({
        term: {
          publish_state
        }
      });
      const response = await client.search({
        index: _constants.INTUNE_MOBILE_APPS_INDEX,
        ignore_unavailable: true,
        body: {
          size,
          from,
          sort: [{
            'display_name.keyword': {
              order: 'asc',
              missing: '_last'
            }
          }],
          query: must.length ? {
            bool: {
              must
            }
          } : {
            match_all: {}
          }
        }
      });
      const hits = (_hits5 = (_response$body6 = response.body) === null || _response$body6 === void 0 ? void 0 : _response$body6.hits) !== null && _hits5 !== void 0 ? _hits5 : {};
      return res.ok({
        body: {
          apps: ((_hits$hits10 = hits.hits) !== null && _hits$hits10 !== void 0 ? _hits$hits10 : []).map(h => h._source).filter(Boolean),
          total: hits.total
        }
      });
    } catch (err) {
      var _err$statusCode8, _err$message8;
      return res.customError({
        statusCode: (_err$statusCode8 = err.statusCode) !== null && _err$statusCode8 !== void 0 ? _err$statusCode8 : 500,
        body: (_err$message8 = err.message) !== null && _err$message8 !== void 0 ? _err$message8 : String(err)
      });
    }
  });

  // GET compliance policies
  router.get({
    path: '/api/intune_plugin/compliance_policies',
    validate: {
      query: _configSchema.schema.object({
        size: _configSchema.schema.maybe(_configSchema.schema.number()),
        from: _configSchema.schema.maybe(_configSchema.schema.number())
      })
    }
  }, async (context, req, res) => {
    try {
      var _hits6, _response$body7, _hits$hits11;
      const client = getClient(context);
      const {
        size = 50,
        from = 0
      } = req.query;
      const response = await client.search({
        index: _constants.INTUNE_COMPLIANCE_POLICIES_INDEX,
        ignore_unavailable: true,
        body: {
          size,
          from,
          sort: [{
            'display_name.keyword': {
              order: 'asc',
              missing: '_last'
            }
          }],
          query: {
            match_all: {}
          }
        }
      });
      const hits = (_hits6 = (_response$body7 = response.body) === null || _response$body7 === void 0 ? void 0 : _response$body7.hits) !== null && _hits6 !== void 0 ? _hits6 : {};
      return res.ok({
        body: {
          policies: ((_hits$hits11 = hits.hits) !== null && _hits$hits11 !== void 0 ? _hits$hits11 : []).map(h => h._source).filter(Boolean),
          total: hits.total
        }
      });
    } catch (err) {
      var _err$statusCode9, _err$message9;
      return res.customError({
        statusCode: (_err$statusCode9 = err.statusCode) !== null && _err$statusCode9 !== void 0 ? _err$statusCode9 : 500,
        body: (_err$message9 = err.message) !== null && _err$message9 !== void 0 ? _err$message9 : String(err)
      });
    }
  });

  // GET config profiles
  router.get({
    path: '/api/intune_plugin/config_profiles',
    validate: {
      query: _configSchema.schema.object({
        size: _configSchema.schema.maybe(_configSchema.schema.number()),
        from: _configSchema.schema.maybe(_configSchema.schema.number())
      })
    }
  }, async (context, req, res) => {
    try {
      var _hits7, _response$body8, _hits$hits12;
      const client = getClient(context);
      const {
        size = 50,
        from = 0
      } = req.query;
      const response = await client.search({
        index: _constants.INTUNE_CONFIG_PROFILES_INDEX,
        ignore_unavailable: true,
        body: {
          size,
          from,
          sort: [{
            'display_name.keyword': {
              order: 'asc',
              missing: '_last'
            }
          }],
          query: {
            match_all: {}
          }
        }
      });
      const hits = (_hits7 = (_response$body8 = response.body) === null || _response$body8 === void 0 ? void 0 : _response$body8.hits) !== null && _hits7 !== void 0 ? _hits7 : {};
      return res.ok({
        body: {
          profiles: ((_hits$hits12 = hits.hits) !== null && _hits$hits12 !== void 0 ? _hits$hits12 : []).map(h => h._source).filter(Boolean),
          total: hits.total
        }
      });
    } catch (err) {
      var _err$statusCode10, _err$message10;
      return res.customError({
        statusCode: (_err$statusCode10 = err.statusCode) !== null && _err$statusCode10 !== void 0 ? _err$statusCode10 : 500,
        body: (_err$message10 = err.message) !== null && _err$message10 !== void 0 ? _err$message10 : String(err)
      });
    }
  });

  // GET scripts (PowerShell + shell)
  router.get({
    path: '/api/intune_plugin/scripts',
    validate: {
      query: _configSchema.schema.object({
        size: _configSchema.schema.maybe(_configSchema.schema.number()),
        from: _configSchema.schema.maybe(_configSchema.schema.number()),
        script_type: _configSchema.schema.maybe(_configSchema.schema.string())
      })
    }
  }, async (context, req, res) => {
    try {
      var _hits8, _response$body9, _hits$hits13;
      const client = getClient(context);
      const {
        size = 50,
        from = 0,
        script_type
      } = req.query;
      const must = [];
      if (script_type) must.push({
        term: {
          script_type
        }
      });
      const response = await client.search({
        index: _constants.INTUNE_SCRIPTS_INDEX,
        ignore_unavailable: true,
        body: {
          size,
          from,
          sort: [{
            last_modified_date_time: {
              order: 'desc',
              missing: '_last'
            }
          }],
          query: must.length ? {
            bool: {
              must
            }
          } : {
            match_all: {}
          }
        }
      });
      const hits = (_hits8 = (_response$body9 = response.body) === null || _response$body9 === void 0 ? void 0 : _response$body9.hits) !== null && _hits8 !== void 0 ? _hits8 : {};
      return res.ok({
        body: {
          scripts: ((_hits$hits13 = hits.hits) !== null && _hits$hits13 !== void 0 ? _hits$hits13 : []).map(h => h._source).filter(Boolean),
          total: hits.total
        }
      });
    } catch (err) {
      var _err$statusCode11, _err$message11;
      return res.customError({
        statusCode: (_err$statusCode11 = err.statusCode) !== null && _err$statusCode11 !== void 0 ? _err$statusCode11 : 500,
        body: (_err$message11 = err.message) !== null && _err$message11 !== void 0 ? _err$message11 : String(err)
      });
    }
  });

  // GET enrollment configurations
  router.get({
    path: '/api/intune_plugin/enrollment_configs',
    validate: {
      query: _configSchema.schema.object({
        size: _configSchema.schema.maybe(_configSchema.schema.number()),
        from: _configSchema.schema.maybe(_configSchema.schema.number())
      })
    }
  }, async (context, req, res) => {
    try {
      var _hits9, _response$body10, _hits$hits14;
      const client = getClient(context);
      const {
        size = 50,
        from = 0
      } = req.query;
      const response = await client.search({
        index: _constants.INTUNE_ENROLLMENT_INDEX,
        ignore_unavailable: true,
        body: {
          size,
          from,
          sort: [{
            priority: {
              order: 'asc',
              missing: '_last'
            }
          }, {
            'display_name.keyword': {
              order: 'asc',
              missing: '_last'
            }
          }],
          query: {
            match_all: {}
          }
        }
      });
      const hits = (_hits9 = (_response$body10 = response.body) === null || _response$body10 === void 0 ? void 0 : _response$body10.hits) !== null && _hits9 !== void 0 ? _hits9 : {};
      return res.ok({
        body: {
          configs: ((_hits$hits14 = hits.hits) !== null && _hits$hits14 !== void 0 ? _hits$hits14 : []).map(h => h._source).filter(Boolean),
          total: hits.total
        }
      });
    } catch (err) {
      var _err$statusCode12, _err$message12;
      return res.customError({
        statusCode: (_err$statusCode12 = err.statusCode) !== null && _err$statusCode12 !== void 0 ? _err$statusCode12 : 500,
        body: (_err$message12 = err.message) !== null && _err$message12 !== void 0 ? _err$message12 : String(err)
      });
    }
  });

  // GET Autopilot devices
  router.get({
    path: '/api/intune_plugin/autopilot_devices',
    validate: {
      query: _configSchema.schema.object({
        size: _configSchema.schema.maybe(_configSchema.schema.number()),
        from: _configSchema.schema.maybe(_configSchema.schema.number()),
        enrollment_state: _configSchema.schema.maybe(_configSchema.schema.string())
      })
    }
  }, async (context, req, res) => {
    try {
      var _hits10, _response$body11, _hits$hits15;
      const client = getClient(context);
      const {
        size = 50,
        from = 0,
        enrollment_state
      } = req.query;
      const must = [];
      if (enrollment_state) must.push({
        term: {
          enrollment_state
        }
      });
      const response = await client.search({
        index: _constants.INTUNE_AUTOPILOT_INDEX,
        ignore_unavailable: true,
        body: {
          size,
          from,
          sort: [{
            last_contacted_date_time: {
              order: 'desc',
              missing: '_last'
            }
          }],
          query: must.length ? {
            bool: {
              must
            }
          } : {
            match_all: {}
          }
        }
      });
      const hits = (_hits10 = (_response$body11 = response.body) === null || _response$body11 === void 0 ? void 0 : _response$body11.hits) !== null && _hits10 !== void 0 ? _hits10 : {};
      return res.ok({
        body: {
          devices: ((_hits$hits15 = hits.hits) !== null && _hits$hits15 !== void 0 ? _hits$hits15 : []).map(h => h._source).filter(Boolean),
          total: hits.total
        }
      });
    } catch (err) {
      var _err$statusCode13, _err$message13;
      return res.customError({
        statusCode: (_err$statusCode13 = err.statusCode) !== null && _err$statusCode13 !== void 0 ? _err$statusCode13 : 500,
        body: (_err$message13 = err.message) !== null && _err$message13 !== void 0 ? _err$message13 : String(err)
      });
    }
  });

  // GET Conditional Access policies
  router.get({
    path: '/api/intune_plugin/ca_policies',
    validate: {
      query: _configSchema.schema.object({
        size: _configSchema.schema.maybe(_configSchema.schema.number()),
        from: _configSchema.schema.maybe(_configSchema.schema.number()),
        state: _configSchema.schema.maybe(_configSchema.schema.string())
      })
    }
  }, async (context, req, res) => {
    try {
      var _hits11, _response$body12, _hits$hits16;
      const client = getClient(context);
      const {
        size = 50,
        from = 0,
        state
      } = req.query;
      const must = [];
      if (state) must.push({
        term: {
          state
        }
      });
      const response = await client.search({
        index: _constants.INTUNE_CA_POLICIES_INDEX,
        ignore_unavailable: true,
        body: {
          size,
          from,
          sort: [{
            'display_name.keyword': {
              order: 'asc',
              missing: '_last'
            }
          }],
          query: must.length ? {
            bool: {
              must
            }
          } : {
            match_all: {}
          }
        }
      });
      const hits = (_hits11 = (_response$body12 = response.body) === null || _response$body12 === void 0 ? void 0 : _response$body12.hits) !== null && _hits11 !== void 0 ? _hits11 : {};
      return res.ok({
        body: {
          policies: ((_hits$hits16 = hits.hits) !== null && _hits$hits16 !== void 0 ? _hits$hits16 : []).map(h => h._source).filter(Boolean),
          total: hits.total
        }
      });
    } catch (err) {
      var _err$statusCode14, _err$message14;
      return res.customError({
        statusCode: (_err$statusCode14 = err.statusCode) !== null && _err$statusCode14 !== void 0 ? _err$statusCode14 : 500,
        body: (_err$message14 = err.message) !== null && _err$message14 !== void 0 ? _err$message14 : String(err)
      });
    }
  });

  // GET app install summary (Graph API)
  router.get({
    path: '/api/intune_plugin/apps/{id}/install-summary',
    validate: {
      params: _configSchema.schema.object({
        id: _configSchema.schema.string()
      })
    }
  }, async (context, req, res) => {
    const config = (0, _graphClient.getGraphConfig)();
    if (!config) {
      return res.customError({
        statusCode: 503,
        body: 'Graph credentials not configured'
      });
    }
    try {
      const id = req.params.id;
      const summary = await (0, _graphClient.getAppInstallSummary)(config, id);
      return res.ok({
        body: summary
      });
    } catch (err) {
      var _err$response$status, _err$response, _err$message15;
      return res.customError({
        statusCode: (_err$response$status = err === null || err === void 0 || (_err$response = err.response) === null || _err$response === void 0 ? void 0 : _err$response.status) !== null && _err$response$status !== void 0 ? _err$response$status : 500,
        body: (_err$message15 = err === null || err === void 0 ? void 0 : err.message) !== null && _err$message15 !== void 0 ? _err$message15 : String(err)
      });
    }
  });

  // GET compliance policy device status summary (Graph API)
  router.get({
    path: '/api/intune_plugin/compliance-policies/{id}/device-status',
    validate: {
      params: _configSchema.schema.object({
        id: _configSchema.schema.string()
      })
    }
  }, async (context, req, res) => {
    const config = (0, _graphClient.getGraphConfig)();
    if (!config) {
      return res.customError({
        statusCode: 503,
        body: 'Graph credentials not configured'
      });
    }
    try {
      const id = req.params.id;
      const summary = await (0, _graphClient.getCompliancePolicyDeviceStatusSummary)(config, id);
      return res.ok({
        body: summary
      });
    } catch (err) {
      var _err$response$status2, _err$response2, _err$message16;
      return res.customError({
        statusCode: (_err$response$status2 = err === null || err === void 0 || (_err$response2 = err.response) === null || _err$response2 === void 0 ? void 0 : _err$response2.status) !== null && _err$response$status2 !== void 0 ? _err$response$status2 : 500,
        body: (_err$message16 = err === null || err === void 0 ? void 0 : err.message) !== null && _err$message16 !== void 0 ? _err$message16 : String(err)
      });
    }
  });

  // GET config profile device status summary (Graph API)
  router.get({
    path: '/api/intune_plugin/config-profiles/{id}/device-status',
    validate: {
      params: _configSchema.schema.object({
        id: _configSchema.schema.string()
      })
    }
  }, async (context, req, res) => {
    const config = (0, _graphClient.getGraphConfig)();
    if (!config) {
      return res.customError({
        statusCode: 503,
        body: 'Graph credentials not configured'
      });
    }
    try {
      const id = req.params.id;
      const summary = await (0, _graphClient.getConfigProfileDeviceStatusSummary)(config, id);
      return res.ok({
        body: summary
      });
    } catch (err) {
      var _err$response$status3, _err$response3, _err$message17;
      return res.customError({
        statusCode: (_err$response$status3 = err === null || err === void 0 || (_err$response3 = err.response) === null || _err$response3 === void 0 ? void 0 : _err$response3.status) !== null && _err$response$status3 !== void 0 ? _err$response$status3 : 500,
        body: (_err$message17 = err === null || err === void 0 ? void 0 : err.message) !== null && _err$message17 !== void 0 ? _err$message17 : String(err)
      });
    }
  });

  // GET script run states (Graph API beta)
  router.get({
    path: '/api/intune_plugin/scripts/{id}/run-states',
    validate: {
      params: _configSchema.schema.object({
        id: _configSchema.schema.string()
      }),
      query: _configSchema.schema.object({
        script_type: _configSchema.schema.maybe(_configSchema.schema.string())
      })
    }
  }, async (context, req, res) => {
    const config = (0, _graphClient.getGraphConfig)();
    if (!config) {
      return res.customError({
        statusCode: 503,
        body: 'Graph credentials not configured'
      });
    }
    try {
      const id = req.params.id;
      const scriptType = req.query.script_type || 'powershell';
      const summary = await (0, _graphClient.getScriptRunStates)(config, id, scriptType);
      return res.ok({
        body: summary
      });
    } catch (err) {
      var _err$response$status4, _err$response4, _err$message18;
      return res.customError({
        statusCode: (_err$response$status4 = err === null || err === void 0 || (_err$response4 = err.response) === null || _err$response4 === void 0 ? void 0 : _err$response4.status) !== null && _err$response$status4 !== void 0 ? _err$response$status4 : 500,
        body: (_err$message18 = err === null || err === void 0 ? void 0 : err.message) !== null && _err$message18 !== void 0 ? _err$message18 : String(err)
      });
    }
  });

  // GET device categories
  router.get({
    path: '/api/intune_plugin/device_categories',
    validate: false
  }, async (context, req, res) => {
    try {
      var _hits$hits17, _response$body13;
      const client = getClient(context);
      const response = await client.search({
        index: _constants.INTUNE_DEVICE_CATEGORIES_INDEX,
        ignore_unavailable: true,
        body: {
          size: 100,
          sort: [{
            'display_name.keyword': {
              order: 'asc',
              missing: '_last'
            }
          }],
          query: {
            match_all: {}
          },
          _source: ['intune_category_id', 'display_name']
        }
      });
      const hits = (_hits$hits17 = (_response$body13 = response.body) === null || _response$body13 === void 0 || (_response$body13 = _response$body13.hits) === null || _response$body13 === void 0 ? void 0 : _response$body13.hits) !== null && _hits$hits17 !== void 0 ? _hits$hits17 : [];
      const categories = hits.map(h => h._source).filter(Boolean);
      return res.ok({
        body: {
          categories
        }
      });
    } catch (err) {
      return res.ok({
        body: {
          categories: []
        }
      });
    }
  });

  // Health check
  router.get({
    path: '/api/intune_plugin/health',
    validate: false
  }, async (context, req, res) => {
    return res.ok({
      body: {
        status: 'ok',
        plugin: 'intunePlugin'
      }
    });
  });
}
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfZ3JhcGhDbGllbnQiLCJyZXF1aXJlIiwiX2NvbmZpZ1NjaGVtYSIsIl9jb25zdGFudHMiLCJnZXRDbGllbnQiLCJjb250ZXh0IiwiY29yZSIsIm9wZW5zZWFyY2giLCJjbGllbnQiLCJhc0N1cnJlbnRVc2VyIiwicmVnaXN0ZXJJbnR1bmVSb3V0ZXMiLCJyb3V0ZXIiLCJnZXQiLCJwYXRoIiwidmFsaWRhdGUiLCJxdWVyeSIsInNjaGVtYSIsIm9iamVjdCIsInNpemUiLCJtYXliZSIsIm51bWJlciIsImZyb20iLCJjb21wbGlhbmNlX3N0YXRlIiwic3RyaW5nIiwib3BlcmF0aW5nX3N5c3RlbSIsImRldmljZV9jYXRlZ29yeSIsInJlcSIsInJlcyIsIl9oaXRzIiwiX3Jlc3BvbnNlJGJvZHkiLCJfaGl0cyRoaXRzIiwibXVzdCIsInB1c2giLCJ0ZXJtIiwiYm9keSIsInNvcnQiLCJsYXN0X3N5bmNfYXQiLCJvcmRlciIsImRldmljZV9uYW1lIiwibGVuZ3RoIiwiYm9vbCIsIm1hdGNoX2FsbCIsInJlc3BvbnNlIiwic2VhcmNoIiwiaW5kZXgiLCJJTlRVTkVfREVWSUNFU19JTkRFWCIsImlnbm9yZV91bmF2YWlsYWJsZSIsImhpdHMiLCJvayIsInRvdGFsIiwiZXJyIiwiX2VyciRzdGF0dXNDb2RlIiwiX2VyciRtZXNzYWdlIiwiY3VzdG9tRXJyb3IiLCJzdGF0dXNDb2RlIiwibWVzc2FnZSIsIlN0cmluZyIsIl9yZXEkcXVlcnkkc2l6ZSIsIl9hZ2dyZWdhdGlvbnMkYnlfdXNlciIsIl9yZXNwb25zZSRib2R5MiIsIl9hZ2dzJGJ1Y2tldHMiLCJhZ2dzIiwiYnlfdXNlciIsInRlcm1zIiwiZmllbGQiLCJtaXNzaW5nIiwiZGV2aWNlcyIsInRvcF9oaXRzIiwiX3NvdXJjZSIsImFnZ3JlZ2F0aW9ucyIsImJ1Y2tldHMiLCJ1c2VycyIsIl9lcnIkc3RhdHVzQ29kZTIiLCJfZXJyJG1lc3NhZ2UyIiwiX2FnZ3JlZ2F0aW9ucyIsIl9yZXNwb25zZSRib2R5MyIsIl9hZ2dzJGJ5X2NvbXBsaWFuY2UkYiIsIl9hZ2dzJGJ5X2NvbXBsaWFuY2UiLCJfYWdncyRieV9vcyRidWNrZXRzIiwiX2FnZ3MkYnlfb3MiLCJieV9jb21wbGlhbmNlIiwiYnlfb3MiLCJfZXJyJHN0YXR1c0NvZGUzIiwiX2VyciRtZXNzYWdlMyIsIl9oaXRzMiIsIl9kZXZpY2VzUmVzJGJvZHkiLCJfYWdncmVnYXRpb25zMiIsIl9kZXZpY2VzUmVzJGJvZHkyIiwiX2RldmljZXNCb2R5JGhpdHMiLCJfZGV2aWNlc0FnZ3MkYnlfY29tcGwiLCJfZGV2aWNlc0FnZ3MkYnlfY29tcGwyIiwiX2RldmljZXNBZ2dzJGJ5X29zJGJ1IiwiX2RldmljZXNBZ2dzJGJ5X29zIiwiZGV2aWNlc1JlcyIsImJ5X293bmVyIiwiX2FnZ3JlZ2F0aW9ucyRieV9vd25lIiwiX293bmVyUmVzJGJvZHkiLCJvd25lclJlcyIsInRvcF9hcHBzIiwiX2hpdHMkaGl0czIiLCJfYXBwc1JlcyRib2R5IiwiYXBwc1JlcyIsIklOVFVORV9ERVRFQ1RFRF9BUFBTX0lOREVYIiwiZGV2aWNlX2NvdW50IiwiYXBwc0hpdHMiLCJtYXAiLCJoIiwiZmlsdGVyIiwiQm9vbGVhbiIsImRldmljZXNCb2R5IiwiZGV2aWNlc0FnZ3MiLCJyZWNlbnRfZGV2aWNlcyIsIm1vYmlsZV9hcHBzX2NvdW50IiwiY29tcGxpYW5jZV9wb2xpY2llc19jb3VudCIsInRvcF9ub25fY29tcGxpYW50IiwiZW5yb2xsbWVudF9jb3VudCIsInNjcmlwdHNfY291bnQiLCJsaW5rZWRfYWdlbnRzX2NvdW50Iiwic3RhbGVfZGV2aWNlc19jb3VudCIsIl9jb3VudCIsIl9hcHBzQ291bnRSZXMkYm9keSIsIl9jb3VudDIiLCJfcG9saWNpZXNDb3VudFJlcyRib2QiLCJfaGl0cyRoaXRzMyIsIl9ub25Db21wbGlhbnRSZXMkYm9keSIsIl9jb3VudDMiLCJfZW5yb2xsUmVzJGJvZHkiLCJfY291bnQ0IiwiX3NjcmlwdHNSZXMkYm9keSIsIl9jb3VudDUiLCJfaWRlbnRpdHlSZXMkYm9keSIsIl9jb3VudDYiLCJfc3RhbGVSZXMkYm9keSIsInN0YWxlRGF0ZSIsIkRhdGUiLCJub3ciLCJ0b0lTT1N0cmluZyIsImFwcHNDb3VudFJlcyIsInBvbGljaWVzQ291bnRSZXMiLCJub25Db21wbGlhbnRSZXMiLCJlbnJvbGxSZXMiLCJzY3JpcHRzUmVzIiwiaWRlbnRpdHlSZXMiLCJzdGFsZVJlcyIsIlByb21pc2UiLCJhbGwiLCJjb3VudCIsIklOVFVORV9NT0JJTEVfQVBQU19JTkRFWCIsIklOVFVORV9DT01QTElBTkNFX1BPTElDSUVTX0lOREVYIiwiSU5UVU5FX0VOUk9MTE1FTlRfSU5ERVgiLCJjYXRjaCIsIklOVFVORV9TQ1JJUFRTX0lOREVYIiwiSU5UVU5FX0RFVklDRV9JREVOVElUWV9JTkRFWCIsInJhbmdlIiwibHQiLCJuY0hpdHMiLCJ0b3Bfbm9uX2NvbXBsaWFudF9kZXZpY2VzIiwiX2VyciRzdGF0dXNDb2RlNCIsIl9lcnIkbWVzc2FnZTQiLCJwb3N0IiwidGltZV9mcm9tIiwidGltZV90byIsImludHVuZV9jb3JyZWxhdGVkX29ubHkiLCJib29sZWFuIiwiX2hpdHMkaGl0czUiLCJfYWxlcnRzUmVzcG9uc2UkYm9keSIsIl9yZWYiLCJfaGl0cyR0b3RhbCR2YWx1ZSIsIl9jb3VudFJlc3BvbnNlJGJvZHkiLCJfY291bnRSZXNwb25zZSRib2R5MiIsImRlZmF1bHRUbyIsImRlZmF1bHRGcm9tIiwiZ2V0VGltZSIsInRpbWVHdGUiLCJ0aW1lTHRlIiwidGltZVJhbmdlRmlsdGVyIiwidGltZXN0YW1wIiwiZ3RlIiwibHRlIiwiYWdlbnRJZHNUb1F1ZXJ5IiwiYWdlbnRUb0ludHVuZUlkIiwiZGV2aWNlc01hcCIsIl9oaXRzJGhpdHM0IiwiX2lkZW50aXR5UmVzJGJvZHkyIiwiaWRlbnRpdHlIaXRzIiwiX2gkX3NvdXJjZSIsIndhenVoX2FnZW50X2lkIiwiaWQiLCJhbGVydHMiLCJlbnJpY2htZW50cyIsImlkZW50aXR5X2NvdW50IiwiZm9yRWFjaCIsInMiLCJpbnR1bmVfZGV2aWNlX2lkIiwibXVzdF9ub3QiLCJhbGVydHNCb2R5IiwiYWxlcnRzUmVzcG9uc2UiLCJjb3VudFJlc3BvbnNlIiwiV0FaVUhfQUxFUlRTX1BBVFRFUk4iLCJ0cmFja190b3RhbF9oaXRzIiwiYWxlcnRIaXRzIiwidmFsdWUiLCJhZ2VudElkcyIsIlNldCIsIl9oJF9zb3VyY2UyIiwiX2hpdHMkaGl0czYiLCJfaWRlbnRpdHlMb29rdXAkYm9keSIsImlkZW50aXR5TG9va3VwIiwibG9va3VwSGl0cyIsImludHVuZUlkcyIsIk9iamVjdCIsInZhbHVlcyIsIl9oaXRzJGhpdHM3IiwiX2RldlJlcyRib2R5IiwiZGV2UmVzIiwiZGV2SGl0cyIsImVudHJpZXMiLCJhZ2VudElkIiwiaW50dW5lSWQiLCJfZGV2aWNlc01hcCRpbnR1bmVJZCIsImtleXMiLCJfZXJyJHN0YXR1c0NvZGU1IiwiX2VyciRtZXNzYWdlNSIsIl9yZXEkcXVlcnkkc2l6ZTIiLCJfaGl0czMiLCJfcmVzcG9uc2UkYm9keTQiLCJfaGl0cyRoaXRzOCIsIl9oaXRzJHRvdGFsIiwiYWN0aXZpdHlfZGF0ZV90aW1lIiwiSU5UVU5FX0FVRElUX0VWRU5UU19JTkRFWCIsImV2ZW50cyIsIl9lcnIkc3RhdHVzQ29kZTYiLCJfZXJyJG1lc3NhZ2U2IiwiX3JlcSRxdWVyeSRzaXplMyIsIl9yZXEkcXVlcnkkZnJvbSIsIl9oaXRzNCIsIl9yZXNwb25zZSRib2R5NSIsIl9oaXRzJGhpdHM5IiwiX2hpdHMkdG90YWwyIiwiYXBwcyIsIl9lcnIkc3RhdHVzQ29kZTciLCJfZXJyJG1lc3NhZ2U3IiwiYXBwX3R5cGUiLCJwdWJsaXNoX3N0YXRlIiwiX2hpdHM1IiwiX3Jlc3BvbnNlJGJvZHk2IiwiX2hpdHMkaGl0czEwIiwiX2VyciRzdGF0dXNDb2RlOCIsIl9lcnIkbWVzc2FnZTgiLCJfaGl0czYiLCJfcmVzcG9uc2UkYm9keTciLCJfaGl0cyRoaXRzMTEiLCJwb2xpY2llcyIsIl9lcnIkc3RhdHVzQ29kZTkiLCJfZXJyJG1lc3NhZ2U5IiwiX2hpdHM3IiwiX3Jlc3BvbnNlJGJvZHk4IiwiX2hpdHMkaGl0czEyIiwiSU5UVU5FX0NPTkZJR19QUk9GSUxFU19JTkRFWCIsInByb2ZpbGVzIiwiX2VyciRzdGF0dXNDb2RlMTAiLCJfZXJyJG1lc3NhZ2UxMCIsInNjcmlwdF90eXBlIiwiX2hpdHM4IiwiX3Jlc3BvbnNlJGJvZHk5IiwiX2hpdHMkaGl0czEzIiwibGFzdF9tb2RpZmllZF9kYXRlX3RpbWUiLCJzY3JpcHRzIiwiX2VyciRzdGF0dXNDb2RlMTEiLCJfZXJyJG1lc3NhZ2UxMSIsIl9oaXRzOSIsIl9yZXNwb25zZSRib2R5MTAiLCJfaGl0cyRoaXRzMTQiLCJwcmlvcml0eSIsImNvbmZpZ3MiLCJfZXJyJHN0YXR1c0NvZGUxMiIsIl9lcnIkbWVzc2FnZTEyIiwiZW5yb2xsbWVudF9zdGF0ZSIsIl9oaXRzMTAiLCJfcmVzcG9uc2UkYm9keTExIiwiX2hpdHMkaGl0czE1IiwiSU5UVU5FX0FVVE9QSUxPVF9JTkRFWCIsImxhc3RfY29udGFjdGVkX2RhdGVfdGltZSIsIl9lcnIkc3RhdHVzQ29kZTEzIiwiX2VyciRtZXNzYWdlMTMiLCJzdGF0ZSIsIl9oaXRzMTEiLCJfcmVzcG9uc2UkYm9keTEyIiwiX2hpdHMkaGl0czE2IiwiSU5UVU5FX0NBX1BPTElDSUVTX0lOREVYIiwiX2VyciRzdGF0dXNDb2RlMTQiLCJfZXJyJG1lc3NhZ2UxNCIsInBhcmFtcyIsImNvbmZpZyIsImdldEdyYXBoQ29uZmlnIiwic3VtbWFyeSIsImdldEFwcEluc3RhbGxTdW1tYXJ5IiwiX2VyciRyZXNwb25zZSRzdGF0dXMiLCJfZXJyJHJlc3BvbnNlIiwiX2VyciRtZXNzYWdlMTUiLCJzdGF0dXMiLCJnZXRDb21wbGlhbmNlUG9saWN5RGV2aWNlU3RhdHVzU3VtbWFyeSIsIl9lcnIkcmVzcG9uc2Ukc3RhdHVzMiIsIl9lcnIkcmVzcG9uc2UyIiwiX2VyciRtZXNzYWdlMTYiLCJnZXRDb25maWdQcm9maWxlRGV2aWNlU3RhdHVzU3VtbWFyeSIsIl9lcnIkcmVzcG9uc2Ukc3RhdHVzMyIsIl9lcnIkcmVzcG9uc2UzIiwiX2VyciRtZXNzYWdlMTciLCJzY3JpcHRUeXBlIiwiZ2V0U2NyaXB0UnVuU3RhdGVzIiwiX2VyciRyZXNwb25zZSRzdGF0dXM0IiwiX2VyciRyZXNwb25zZTQiLCJfZXJyJG1lc3NhZ2UxOCIsIl9oaXRzJGhpdHMxNyIsIl9yZXNwb25zZSRib2R5MTMiLCJJTlRVTkVfREVWSUNFX0NBVEVHT1JJRVNfSU5ERVgiLCJjYXRlZ29yaWVzIiwicGx1Z2luIl0sInNvdXJjZXMiOlsic2VhcmNoLnRzIl0sInNvdXJjZXNDb250ZW50IjpbIi8qXG4gKiBJbnR1bmUgUGx1Z2luIC0gU2VydmVyIHJvdXRlcyAoT3BlblNlYXJjaCBxdWVyaWVzICsgR3JhcGggQVBJIGZvciBzdGF0dXMpXG4gKi9cblxuaW1wb3J0IHsgSVJvdXRlciB9IGZyb20gJ29wZW5zZWFyY2gtZGFzaGJvYXJkcy9zZXJ2ZXInO1xuaW1wb3J0IHtcbiAgZ2V0R3JhcGhDb25maWcsXG4gIGdldEFwcEluc3RhbGxTdW1tYXJ5LFxuICBnZXRDb21wbGlhbmNlUG9saWN5RGV2aWNlU3RhdHVzU3VtbWFyeSxcbiAgZ2V0Q29uZmlnUHJvZmlsZURldmljZVN0YXR1c1N1bW1hcnksXG4gIGdldFNjcmlwdFJ1blN0YXRlcyxcbn0gZnJvbSAnLi4vbGliL2dyYXBoLWNsaWVudCc7XG5pbXBvcnQgeyBzY2hlbWEgfSBmcm9tICdAb3NkL2NvbmZpZy1zY2hlbWEnO1xuaW1wb3J0IHtcbiAgSU5UVU5FX0RFVklDRVNfSU5ERVgsXG4gIElOVFVORV9ERVZJQ0VfSURFTlRJVFlfSU5ERVgsXG4gIElOVFVORV9BVURJVF9FVkVOVFNfSU5ERVgsXG4gIElOVFVORV9ERVRFQ1RFRF9BUFBTX0lOREVYLFxuICBJTlRVTkVfTU9CSUxFX0FQUFNfSU5ERVgsXG4gIElOVFVORV9DT01QTElBTkNFX1BPTElDSUVTX0lOREVYLFxuICBJTlRVTkVfQ09ORklHX1BST0ZJTEVTX0lOREVYLFxuICBJTlRVTkVfU0NSSVBUU19JTkRFWCxcbiAgSU5UVU5FX0VOUk9MTE1FTlRfSU5ERVgsXG4gIElOVFVORV9BVVRPUElMT1RfSU5ERVgsXG4gIElOVFVORV9DQV9QT0xJQ0lFU19JTkRFWCxcbiAgSU5UVU5FX0RFVklDRV9DQVRFR09SSUVTX0lOREVYLFxuICBXQVpVSF9BTEVSVFNfUEFUVEVSTixcbn0gZnJvbSAnLi4vLi4vY29tbW9uL2NvbnN0YW50cyc7XG5cbmZ1bmN0aW9uIGdldENsaWVudChjb250ZXh0OiBhbnkpIHtcbiAgcmV0dXJuIGNvbnRleHQuY29yZS5vcGVuc2VhcmNoLmNsaWVudC5hc0N1cnJlbnRVc2VyO1xufVxuXG5leHBvcnQgZnVuY3Rpb24gcmVnaXN0ZXJJbnR1bmVSb3V0ZXMocm91dGVyOiBJUm91dGVyKSB7XG4gIC8vIEdFVCBkZXZpY2VzIGxpc3QgKHdpdGggb3B0aW9uYWwgZmlsdGVycylcbiAgcm91dGVyLmdldChcbiAgICB7XG4gICAgICBwYXRoOiAnL2FwaS9pbnR1bmVfcGx1Z2luL2RldmljZXMnLFxuICAgICAgdmFsaWRhdGU6IHtcbiAgICAgICAgcXVlcnk6IHNjaGVtYS5vYmplY3Qoe1xuICAgICAgICAgIHNpemU6IHNjaGVtYS5tYXliZShzY2hlbWEubnVtYmVyKCkpLFxuICAgICAgICAgIGZyb206IHNjaGVtYS5tYXliZShzY2hlbWEubnVtYmVyKCkpLFxuICAgICAgICAgIGNvbXBsaWFuY2Vfc3RhdGU6IHNjaGVtYS5tYXliZShzY2hlbWEuc3RyaW5nKCkpLFxuICAgICAgICAgIG9wZXJhdGluZ19zeXN0ZW06IHNjaGVtYS5tYXliZShzY2hlbWEuc3RyaW5nKCkpLFxuICAgICAgICAgIGRldmljZV9jYXRlZ29yeTogc2NoZW1hLm1heWJlKHNjaGVtYS5zdHJpbmcoKSksXG4gICAgICAgIH0pLFxuICAgICAgfSxcbiAgICB9LFxuICAgIGFzeW5jIChjb250ZXh0LCByZXEsIHJlcykgPT4ge1xuICAgICAgdHJ5IHtcbiAgICAgICAgY29uc3QgY2xpZW50ID0gZ2V0Q2xpZW50KGNvbnRleHQpO1xuICAgICAgICBjb25zdCB7IHNpemUgPSA1MCwgZnJvbSA9IDAsIGNvbXBsaWFuY2Vfc3RhdGUsIG9wZXJhdGluZ19zeXN0ZW0sIGRldmljZV9jYXRlZ29yeSB9ID0gcmVxLnF1ZXJ5O1xuICAgICAgICBjb25zdCBtdXN0OiBhbnlbXSA9IFtdO1xuICAgICAgICBpZiAoY29tcGxpYW5jZV9zdGF0ZSkgbXVzdC5wdXNoKHsgdGVybTogeyBjb21wbGlhbmNlX3N0YXRlIH0gfSk7XG4gICAgICAgIGlmIChvcGVyYXRpbmdfc3lzdGVtKSBtdXN0LnB1c2goeyB0ZXJtOiB7IG9wZXJhdGluZ19zeXN0ZW0gfSB9KTtcbiAgICAgICAgaWYgKGRldmljZV9jYXRlZ29yeSkgbXVzdC5wdXNoKHsgdGVybTogeyBkZXZpY2VfY2F0ZWdvcnkgfSB9KTtcbiAgICAgICAgY29uc3QgYm9keTogYW55ID0ge1xuICAgICAgICAgIHNpemUsXG4gICAgICAgICAgZnJvbSxcbiAgICAgICAgICBzb3J0OiBbeyBsYXN0X3N5bmNfYXQ6IHsgb3JkZXI6ICdkZXNjJyB9IH0sIHsgZGV2aWNlX25hbWU6ICdhc2MnIH1dLFxuICAgICAgICAgIHF1ZXJ5OiBtdXN0Lmxlbmd0aCA/IHsgYm9vbDogeyBtdXN0IH0gfSA6IHsgbWF0Y2hfYWxsOiB7fSB9LFxuICAgICAgICB9O1xuICAgICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGNsaWVudC5zZWFyY2goe1xuICAgICAgICAgIGluZGV4OiBJTlRVTkVfREVWSUNFU19JTkRFWCxcbiAgICAgICAgICBpZ25vcmVfdW5hdmFpbGFibGU6IHRydWUsXG4gICAgICAgICAgYm9keSxcbiAgICAgICAgfSk7XG4gICAgICAgIGNvbnN0IGhpdHMgPSAocmVzcG9uc2UuYm9keSBhcyBhbnkpPy5oaXRzID8/IHt9O1xuICAgICAgICByZXR1cm4gcmVzLm9rKHsgYm9keTogeyBoaXRzOiBoaXRzLmhpdHMgPz8gW10sIHRvdGFsOiBoaXRzLnRvdGFsIH0gfSk7XG4gICAgICB9IGNhdGNoIChlcnI6IGFueSkge1xuICAgICAgICByZXR1cm4gcmVzLmN1c3RvbUVycm9yKHtcbiAgICAgICAgICBzdGF0dXNDb2RlOiBlcnIuc3RhdHVzQ29kZSA/PyA1MDAsXG4gICAgICAgICAgYm9keTogZXJyLm1lc3NhZ2UgPz8gU3RyaW5nKGVyciksXG4gICAgICAgIH0pO1xuICAgICAgfVxuICAgIH1cbiAgKTtcblxuICAvLyBHRVQgdXNlcnMgYWdncmVnYXRpb24gKHVzZXJzIHdpdGggdGhlaXIgZGV2aWNlcylcbiAgcm91dGVyLmdldChcbiAgICB7XG4gICAgICBwYXRoOiAnL2FwaS9pbnR1bmVfcGx1Z2luL3VzZXJzJyxcbiAgICAgIHZhbGlkYXRlOiB7XG4gICAgICAgIHF1ZXJ5OiBzY2hlbWEub2JqZWN0KHtcbiAgICAgICAgICBzaXplOiBzY2hlbWEubWF5YmUoc2NoZW1hLm51bWJlcigpKSxcbiAgICAgICAgfSksXG4gICAgICB9LFxuICAgIH0sXG4gICAgYXN5bmMgKGNvbnRleHQsIHJlcSwgcmVzKSA9PiB7XG4gICAgICB0cnkge1xuICAgICAgICBjb25zdCBjbGllbnQgPSBnZXRDbGllbnQoY29udGV4dCk7XG4gICAgICAgIGNvbnN0IHNpemUgPSByZXEucXVlcnkuc2l6ZSA/PyAxMDA7XG4gICAgICAgIGNvbnN0IGJvZHkgPSB7XG4gICAgICAgICAgc2l6ZTogMCxcbiAgICAgICAgICBhZ2dzOiB7XG4gICAgICAgICAgICBieV91c2VyOiB7XG4gICAgICAgICAgICAgIHRlcm1zOiB7IGZpZWxkOiAndXNlcl9wcmluY2lwYWxfbmFtZScsIHNpemU6IDUwMCwgbWlzc2luZzogJ+KAlCcgfSxcbiAgICAgICAgICAgICAgYWdnczoge1xuICAgICAgICAgICAgICAgIGRldmljZXM6IHtcbiAgICAgICAgICAgICAgICAgIHRvcF9oaXRzOiB7IHNpemU6IDUwLCBfc291cmNlOiBbJ2RldmljZV9uYW1lJywgJ2NvbXBsaWFuY2Vfc3RhdGUnLCAnb3BlcmF0aW5nX3N5c3RlbScsICdsYXN0X3N5bmNfYXQnXSB9LFxuICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICB9LFxuICAgICAgICAgIH0sXG4gICAgICAgIH07XG4gICAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgY2xpZW50LnNlYXJjaCh7XG4gICAgICAgICAgaW5kZXg6IElOVFVORV9ERVZJQ0VTX0lOREVYLFxuICAgICAgICAgIGlnbm9yZV91bmF2YWlsYWJsZTogdHJ1ZSxcbiAgICAgICAgICBib2R5LFxuICAgICAgICB9KTtcbiAgICAgICAgY29uc3QgYWdncyA9IChyZXNwb25zZS5ib2R5IGFzIGFueSk/LmFnZ3JlZ2F0aW9ucz8uYnlfdXNlciA/PyB7fTtcbiAgICAgICAgY29uc3QgYnVja2V0cyA9IGFnZ3MuYnVja2V0cyA/PyBbXTtcbiAgICAgICAgcmV0dXJuIHJlcy5vayh7IGJvZHk6IHsgdXNlcnM6IGJ1Y2tldHMsIHNpemUgfSB9KTtcbiAgICAgIH0gY2F0Y2ggKGVycjogYW55KSB7XG4gICAgICAgIHJldHVybiByZXMuY3VzdG9tRXJyb3Ioe1xuICAgICAgICAgIHN0YXR1c0NvZGU6IGVyci5zdGF0dXNDb2RlID8/IDUwMCxcbiAgICAgICAgICBib2R5OiBlcnIubWVzc2FnZSA/PyBTdHJpbmcoZXJyKSxcbiAgICAgICAgfSk7XG4gICAgICB9XG4gICAgfVxuICApO1xuXG4gIC8vIEdFVCBjb21wbGlhbmNlIG92ZXJ2aWV3IChhZ2dyZWdhdGlvbnMpXG4gIHJvdXRlci5nZXQoXG4gICAge1xuICAgICAgcGF0aDogJy9hcGkvaW50dW5lX3BsdWdpbi9jb21wbGlhbmNlJyxcbiAgICAgIHZhbGlkYXRlOiBmYWxzZSxcbiAgICB9LFxuICAgIGFzeW5jIChjb250ZXh0LCByZXEsIHJlcykgPT4ge1xuICAgICAgdHJ5IHtcbiAgICAgICAgY29uc3QgY2xpZW50ID0gZ2V0Q2xpZW50KGNvbnRleHQpO1xuICAgICAgICBjb25zdCBib2R5ID0ge1xuICAgICAgICAgIHNpemU6IDAsXG4gICAgICAgICAgYWdnczoge1xuICAgICAgICAgICAgYnlfY29tcGxpYW5jZToge1xuICAgICAgICAgICAgICB0ZXJtczogeyBmaWVsZDogJ2NvbXBsaWFuY2Vfc3RhdGUnLCBzaXplOiAyMCB9LFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIGJ5X29zOiB7XG4gICAgICAgICAgICAgIHRlcm1zOiB7IGZpZWxkOiAnb3BlcmF0aW5nX3N5c3RlbScsIHNpemU6IDEwIH0sXG4gICAgICAgICAgICB9LFxuICAgICAgICAgIH0sXG4gICAgICAgIH07XG4gICAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgY2xpZW50LnNlYXJjaCh7XG4gICAgICAgICAgaW5kZXg6IElOVFVORV9ERVZJQ0VTX0lOREVYLFxuICAgICAgICAgIGlnbm9yZV91bmF2YWlsYWJsZTogdHJ1ZSxcbiAgICAgICAgICBib2R5LFxuICAgICAgICB9KTtcbiAgICAgICAgY29uc3QgYWdncyA9IChyZXNwb25zZS5ib2R5IGFzIGFueSk/LmFnZ3JlZ2F0aW9ucyA/PyB7fTtcbiAgICAgICAgcmV0dXJuIHJlcy5vayh7XG4gICAgICAgICAgYm9keToge1xuICAgICAgICAgICAgYnlfY29tcGxpYW5jZTogYWdncy5ieV9jb21wbGlhbmNlPy5idWNrZXRzID8/IFtdLFxuICAgICAgICAgICAgYnlfb3M6IGFnZ3MuYnlfb3M/LmJ1Y2tldHMgPz8gW10sXG4gICAgICAgICAgfSxcbiAgICAgICAgfSk7XG4gICAgICB9IGNhdGNoIChlcnI6IGFueSkge1xuICAgICAgICByZXR1cm4gcmVzLmN1c3RvbUVycm9yKHtcbiAgICAgICAgICBzdGF0dXNDb2RlOiBlcnIuc3RhdHVzQ29kZSA/PyA1MDAsXG4gICAgICAgICAgYm9keTogZXJyLm1lc3NhZ2UgPz8gU3RyaW5nKGVyciksXG4gICAgICAgIH0pO1xuICAgICAgfVxuICAgIH1cbiAgKTtcblxuICAvLyBHRVQgb3ZlcnZpZXcgKGRhc2hib2FyZC1zdHlsZTogZGV2aWNlcywgY29tcGxpYW5jZSwgb3duZXJzaGlwLCB0b3AgYXBwcylcbiAgcm91dGVyLmdldChcbiAgICB7XG4gICAgICBwYXRoOiAnL2FwaS9pbnR1bmVfcGx1Z2luL292ZXJ2aWV3JyxcbiAgICAgIHZhbGlkYXRlOiBmYWxzZSxcbiAgICB9LFxuICAgIGFzeW5jIChjb250ZXh0LCByZXEsIHJlcykgPT4ge1xuICAgICAgdHJ5IHtcbiAgICAgICAgY29uc3QgY2xpZW50ID0gZ2V0Q2xpZW50KGNvbnRleHQpO1xuXG4gICAgICAgIGNvbnN0IGRldmljZXNSZXMgPSBhd2FpdCBjbGllbnQuc2VhcmNoKHtcbiAgICAgICAgICBpbmRleDogSU5UVU5FX0RFVklDRVNfSU5ERVgsXG4gICAgICAgICAgaWdub3JlX3VuYXZhaWxhYmxlOiB0cnVlLFxuICAgICAgICAgIGJvZHk6IHtcbiAgICAgICAgICAgIHNpemU6IDUsXG4gICAgICAgICAgICBzb3J0OiBbXG4gICAgICAgICAgICAgIHsgbGFzdF9zeW5jX2F0OiB7IG9yZGVyOiAnZGVzYycsIG1pc3Npbmc6ICdfbGFzdCcgfSB9LFxuICAgICAgICAgICAgICB7IGRldmljZV9uYW1lOiAnYXNjJyB9LFxuICAgICAgICAgICAgXSxcbiAgICAgICAgICAgIHF1ZXJ5OiB7IG1hdGNoX2FsbDoge30gfSxcbiAgICAgICAgICAgIGFnZ3M6IHtcbiAgICAgICAgICAgICAgYnlfY29tcGxpYW5jZTogeyB0ZXJtczogeyBmaWVsZDogJ2NvbXBsaWFuY2Vfc3RhdGUnLCBzaXplOiAxMCB9IH0sXG4gICAgICAgICAgICAgIGJ5X29zOiB7IHRlcm1zOiB7IGZpZWxkOiAnb3BlcmF0aW5nX3N5c3RlbScsIHNpemU6IDEwIH0gfSxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgfSxcbiAgICAgICAgfSk7XG5cbiAgICAgICAgbGV0IGJ5X293bmVyOiBhbnlbXSA9IFtdO1xuICAgICAgICB0cnkge1xuICAgICAgICAgIGNvbnN0IG93bmVyUmVzID0gYXdhaXQgY2xpZW50LnNlYXJjaCh7XG4gICAgICAgICAgICBpbmRleDogSU5UVU5FX0RFVklDRVNfSU5ERVgsXG4gICAgICAgICAgICBpZ25vcmVfdW5hdmFpbGFibGU6IHRydWUsXG4gICAgICAgICAgICBib2R5OiB7XG4gICAgICAgICAgICAgIHNpemU6IDAsXG4gICAgICAgICAgICAgIGFnZ3M6IHtcbiAgICAgICAgICAgICAgICBieV9vd25lcjoge1xuICAgICAgICAgICAgICAgICAgdGVybXM6IHsgZmllbGQ6ICdtYW5hZ2VkX2RldmljZV9vd25lcl90eXBlJywgc2l6ZTogMTAgfSxcbiAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICB9KTtcbiAgICAgICAgICBieV9vd25lciA9IChvd25lclJlcy5ib2R5IGFzIGFueSk/LmFnZ3JlZ2F0aW9ucz8uYnlfb3duZXI/LmJ1Y2tldHMgPz8gW107XG4gICAgICAgIH0gY2F0Y2gge1xuICAgICAgICAgIGJ5X293bmVyID0gW107XG4gICAgICAgIH1cblxuICAgICAgICBsZXQgdG9wX2FwcHM6IGFueVtdID0gW107XG4gICAgICAgIHRyeSB7XG4gICAgICAgICAgY29uc3QgYXBwc1JlcyA9IGF3YWl0IGNsaWVudC5zZWFyY2goe1xuICAgICAgICAgICAgaW5kZXg6IElOVFVORV9ERVRFQ1RFRF9BUFBTX0lOREVYLFxuICAgICAgICAgICAgaWdub3JlX3VuYXZhaWxhYmxlOiB0cnVlLFxuICAgICAgICAgICAgYm9keToge1xuICAgICAgICAgICAgICBzaXplOiAxMCxcbiAgICAgICAgICAgICAgc29ydDogW3sgZGV2aWNlX2NvdW50OiB7IG9yZGVyOiAnZGVzYycgfSB9XSxcbiAgICAgICAgICAgICAgX3NvdXJjZTogWydkaXNwbGF5X25hbWUnLCAnZGV2aWNlX2NvdW50JywgJ3BsYXRmb3JtJ10sXG4gICAgICAgICAgICAgIHF1ZXJ5OiB7IG1hdGNoX2FsbDoge30gfSxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgfSk7XG4gICAgICAgICAgY29uc3QgYXBwc0hpdHMgPSAoYXBwc1Jlcy5ib2R5IGFzIGFueSk/LmhpdHM/LmhpdHMgPz8gW107XG4gICAgICAgICAgdG9wX2FwcHMgPSBhcHBzSGl0cy5tYXAoKGg6IGFueSkgPT4gaC5fc291cmNlKS5maWx0ZXIoQm9vbGVhbik7XG4gICAgICAgIH0gY2F0Y2gge1xuICAgICAgICAgIHRvcF9hcHBzID0gW107XG4gICAgICAgIH1cblxuICAgICAgICBjb25zdCBkZXZpY2VzQm9keSA9IChkZXZpY2VzUmVzLmJvZHkgYXMgYW55KT8uaGl0cyA/PyB7fTtcbiAgICAgICAgY29uc3QgZGV2aWNlc0FnZ3MgPSAoZGV2aWNlc1Jlcy5ib2R5IGFzIGFueSk/LmFnZ3JlZ2F0aW9ucyA/PyB7fTtcbiAgICAgICAgY29uc3QgcmVjZW50X2RldmljZXMgPSAoZGV2aWNlc0JvZHkuaGl0cyA/PyBbXSkubWFwKChoOiBhbnkpID0+IGguX3NvdXJjZSkuZmlsdGVyKEJvb2xlYW4pO1xuXG4gICAgICAgIGxldCBtb2JpbGVfYXBwc19jb3VudCA9IDA7XG4gICAgICAgIGxldCBjb21wbGlhbmNlX3BvbGljaWVzX2NvdW50ID0gMDtcbiAgICAgICAgbGV0IHRvcF9ub25fY29tcGxpYW50OiBhbnlbXSA9IFtdO1xuICAgICAgICBsZXQgZW5yb2xsbWVudF9jb3VudCA9IDA7XG4gICAgICAgIGxldCBzY3JpcHRzX2NvdW50ID0gMDtcbiAgICAgICAgbGV0IGxpbmtlZF9hZ2VudHNfY291bnQgPSAwO1xuICAgICAgICBsZXQgc3RhbGVfZGV2aWNlc19jb3VudCA9IDA7XG4gICAgICAgIHRyeSB7XG4gICAgICAgICAgY29uc3Qgc3RhbGVEYXRlID0gbmV3IERhdGUoRGF0ZS5ub3coKSAtIDcgKiAyNCAqIDYwICogNjAgKiAxMDAwKS50b0lTT1N0cmluZygpO1xuICAgICAgICAgIGNvbnN0IFtcbiAgICAgICAgICAgIGFwcHNDb3VudFJlcywgcG9saWNpZXNDb3VudFJlcywgbm9uQ29tcGxpYW50UmVzLFxuICAgICAgICAgICAgZW5yb2xsUmVzLCBzY3JpcHRzUmVzLCBpZGVudGl0eVJlcywgc3RhbGVSZXMsXG4gICAgICAgICAgXSA9IGF3YWl0IFByb21pc2UuYWxsKFtcbiAgICAgICAgICAgIGNsaWVudC5jb3VudCh7IGluZGV4OiBJTlRVTkVfTU9CSUxFX0FQUFNfSU5ERVgsIGlnbm9yZV91bmF2YWlsYWJsZTogdHJ1ZSB9KSxcbiAgICAgICAgICAgIGNsaWVudC5jb3VudCh7IGluZGV4OiBJTlRVTkVfQ09NUExJQU5DRV9QT0xJQ0lFU19JTkRFWCwgaWdub3JlX3VuYXZhaWxhYmxlOiB0cnVlIH0pLFxuICAgICAgICAgICAgY2xpZW50LnNlYXJjaCh7XG4gICAgICAgICAgICAgIGluZGV4OiBJTlRVTkVfREVWSUNFU19JTkRFWCxcbiAgICAgICAgICAgICAgaWdub3JlX3VuYXZhaWxhYmxlOiB0cnVlLFxuICAgICAgICAgICAgICBib2R5OiB7XG4gICAgICAgICAgICAgICAgc2l6ZTogNSxcbiAgICAgICAgICAgICAgICBzb3J0OiBbeyBsYXN0X3N5bmNfYXQ6IHsgb3JkZXI6ICdkZXNjJywgbWlzc2luZzogJ19sYXN0JyB9IH1dLFxuICAgICAgICAgICAgICAgIHF1ZXJ5OiB7IHRlcm06IHsgY29tcGxpYW5jZV9zdGF0ZTogJ25vbmNvbXBsaWFudCcgfSB9LFxuICAgICAgICAgICAgICAgIF9zb3VyY2U6IFsnZGV2aWNlX25hbWUnLCAndXNlcl9wcmluY2lwYWxfbmFtZScsICdvcGVyYXRpbmdfc3lzdGVtJywgJ2NvbXBsaWFuY2Vfc3RhdGUnLCAnbGFzdF9zeW5jX2F0J10sXG4gICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICB9KSxcbiAgICAgICAgICAgIGNsaWVudC5jb3VudCh7IGluZGV4OiBJTlRVTkVfRU5ST0xMTUVOVF9JTkRFWCwgaWdub3JlX3VuYXZhaWxhYmxlOiB0cnVlIH0pLmNhdGNoKCgpID0+ICh7IGJvZHk6IHsgY291bnQ6IDAgfSB9KSksXG4gICAgICAgICAgICBjbGllbnQuY291bnQoeyBpbmRleDogSU5UVU5FX1NDUklQVFNfSU5ERVgsIGlnbm9yZV91bmF2YWlsYWJsZTogdHJ1ZSB9KS5jYXRjaCgoKSA9PiAoeyBib2R5OiB7IGNvdW50OiAwIH0gfSkpLFxuICAgICAgICAgICAgY2xpZW50LmNvdW50KHsgaW5kZXg6IElOVFVORV9ERVZJQ0VfSURFTlRJVFlfSU5ERVgsIGlnbm9yZV91bmF2YWlsYWJsZTogdHJ1ZSB9KS5jYXRjaCgoKSA9PiAoeyBib2R5OiB7IGNvdW50OiAwIH0gfSkpLFxuICAgICAgICAgICAgY2xpZW50LmNvdW50KHtcbiAgICAgICAgICAgICAgaW5kZXg6IElOVFVORV9ERVZJQ0VTX0lOREVYLFxuICAgICAgICAgICAgICBpZ25vcmVfdW5hdmFpbGFibGU6IHRydWUsXG4gICAgICAgICAgICAgIGJvZHk6IHsgcXVlcnk6IHsgcmFuZ2U6IHsgbGFzdF9zeW5jX2F0OiB7IGx0OiBzdGFsZURhdGUgfSB9IH0gfSxcbiAgICAgICAgICAgIH0pLmNhdGNoKCgpID0+ICh7IGJvZHk6IHsgY291bnQ6IDAgfSB9KSksXG4gICAgICAgICAgXSk7XG4gICAgICAgICAgbW9iaWxlX2FwcHNfY291bnQgPSAoYXBwc0NvdW50UmVzLmJvZHkgYXMgYW55KT8uY291bnQgPz8gMDtcbiAgICAgICAgICBjb21wbGlhbmNlX3BvbGljaWVzX2NvdW50ID0gKHBvbGljaWVzQ291bnRSZXMuYm9keSBhcyBhbnkpPy5jb3VudCA/PyAwO1xuICAgICAgICAgIGNvbnN0IG5jSGl0cyA9IChub25Db21wbGlhbnRSZXMuYm9keSBhcyBhbnkpPy5oaXRzPy5oaXRzID8/IFtdO1xuICAgICAgICAgIHRvcF9ub25fY29tcGxpYW50ID0gbmNIaXRzLm1hcCgoaDogYW55KSA9PiBoLl9zb3VyY2UpLmZpbHRlcihCb29sZWFuKTtcbiAgICAgICAgICBlbnJvbGxtZW50X2NvdW50ID0gKGVucm9sbFJlcy5ib2R5IGFzIGFueSk/LmNvdW50ID8/IDA7XG4gICAgICAgICAgc2NyaXB0c19jb3VudCA9IChzY3JpcHRzUmVzLmJvZHkgYXMgYW55KT8uY291bnQgPz8gMDtcbiAgICAgICAgICBsaW5rZWRfYWdlbnRzX2NvdW50ID0gKGlkZW50aXR5UmVzLmJvZHkgYXMgYW55KT8uY291bnQgPz8gMDtcbiAgICAgICAgICBzdGFsZV9kZXZpY2VzX2NvdW50ID0gKHN0YWxlUmVzLmJvZHkgYXMgYW55KT8uY291bnQgPz8gMDtcbiAgICAgICAgfSBjYXRjaCB7XG4gICAgICAgICAgLyogaWdub3JlICovXG4gICAgICAgIH1cblxuICAgICAgICByZXR1cm4gcmVzLm9rKHtcbiAgICAgICAgICBib2R5OiB7XG4gICAgICAgICAgICBieV9jb21wbGlhbmNlOiBkZXZpY2VzQWdncy5ieV9jb21wbGlhbmNlPy5idWNrZXRzID8/IFtdLFxuICAgICAgICAgICAgYnlfb3M6IGRldmljZXNBZ2dzLmJ5X29zPy5idWNrZXRzID8/IFtdLFxuICAgICAgICAgICAgYnlfb3duZXIsXG4gICAgICAgICAgICB0b3BfYXBwcyxcbiAgICAgICAgICAgIHJlY2VudF9kZXZpY2VzLFxuICAgICAgICAgICAgbW9iaWxlX2FwcHNfY291bnQsXG4gICAgICAgICAgICBjb21wbGlhbmNlX3BvbGljaWVzX2NvdW50LFxuICAgICAgICAgICAgdG9wX25vbl9jb21wbGlhbnRfZGV2aWNlczogdG9wX25vbl9jb21wbGlhbnQsXG4gICAgICAgICAgICBlbnJvbGxtZW50X2NvdW50LFxuICAgICAgICAgICAgc2NyaXB0c19jb3VudCxcbiAgICAgICAgICAgIGxpbmtlZF9hZ2VudHNfY291bnQsXG4gICAgICAgICAgICBzdGFsZV9kZXZpY2VzX2NvdW50LFxuICAgICAgICAgIH0sXG4gICAgICAgIH0pO1xuICAgICAgfSBjYXRjaCAoZXJyOiBhbnkpIHtcbiAgICAgICAgcmV0dXJuIHJlcy5jdXN0b21FcnJvcih7XG4gICAgICAgICAgc3RhdHVzQ29kZTogZXJyLnN0YXR1c0NvZGUgPz8gNTAwLFxuICAgICAgICAgIGJvZHk6IGVyci5tZXNzYWdlID8/IFN0cmluZyhlcnIpLFxuICAgICAgICB9KTtcbiAgICAgIH1cbiAgICB9XG4gICk7XG5cbiAgLy8gR0VUIGFsZXJ0IGVucmljaG1lbnQ6IFdhenVoIGFsZXJ0cyBmcm9tIEludHVuZS1jb3JyZWxhdGVkIGFnZW50cyBvbmx5LFxuICAvLyB3aXRoIHRpbWUgcmFuZ2UsIHBhZ2luYXRpb24sIGFuZCBJbnR1bmUgY29tcGxpYW5jZS91c2VyL2RldmljZSBjb250ZXh0XG4gIHJvdXRlci5wb3N0KFxuICAgIHtcbiAgICAgIHBhdGg6ICcvYXBpL2ludHVuZV9wbHVnaW4vYWxlcnRzX2VucmljaG1lbnQnLFxuICAgICAgdmFsaWRhdGU6IHtcbiAgICAgICAgYm9keTogc2NoZW1hLm9iamVjdCh7XG4gICAgICAgICAgc2l6ZTogc2NoZW1hLm1heWJlKHNjaGVtYS5udW1iZXIoKSksXG4gICAgICAgICAgZnJvbTogc2NoZW1hLm1heWJlKHNjaGVtYS5udW1iZXIoKSksXG4gICAgICAgICAgdGltZV9mcm9tOiBzY2hlbWEubWF5YmUoc2NoZW1hLnN0cmluZygpKSxcbiAgICAgICAgICB0aW1lX3RvOiBzY2hlbWEubWF5YmUoc2NoZW1hLnN0cmluZygpKSxcbiAgICAgICAgICBpbnR1bmVfY29ycmVsYXRlZF9vbmx5OiBzY2hlbWEubWF5YmUoc2NoZW1hLmJvb2xlYW4oKSksXG4gICAgICAgIH0pLFxuICAgICAgfSxcbiAgICB9LFxuICAgIGFzeW5jIChjb250ZXh0LCByZXEsIHJlcykgPT4ge1xuICAgICAgdHJ5IHtcbiAgICAgICAgY29uc3QgY2xpZW50ID0gZ2V0Q2xpZW50KGNvbnRleHQpO1xuICAgICAgICBjb25zdCB7XG4gICAgICAgICAgc2l6ZSA9IDI1LFxuICAgICAgICAgIGZyb20gPSAwLFxuICAgICAgICAgIHRpbWVfZnJvbSxcbiAgICAgICAgICB0aW1lX3RvLFxuICAgICAgICAgIGludHVuZV9jb3JyZWxhdGVkX29ubHkgPSB0cnVlLFxuICAgICAgICB9ID0gcmVxLmJvZHk7XG5cbiAgICAgICAgLy8gVGltZSByYW5nZSBmaWx0ZXIgKHJlcXVpcmVkIGZvciBtZWFuaW5nZnVsIHJlc3VsdHMpXG4gICAgICAgIGNvbnN0IG5vdyA9IG5ldyBEYXRlKCk7XG4gICAgICAgIGNvbnN0IGRlZmF1bHRUbyA9IG5vdy50b0lTT1N0cmluZygpO1xuICAgICAgICBjb25zdCBkZWZhdWx0RnJvbSA9IG5ldyBEYXRlKG5vdy5nZXRUaW1lKCkgLSA3ICogMjQgKiA2MCAqIDYwICogMTAwMCkudG9JU09TdHJpbmcoKTtcbiAgICAgICAgY29uc3QgdGltZUd0ZSA9IHRpbWVfZnJvbSB8fCBkZWZhdWx0RnJvbTtcbiAgICAgICAgY29uc3QgdGltZUx0ZSA9IHRpbWVfdG8gfHwgZGVmYXVsdFRvO1xuICAgICAgICBjb25zdCB0aW1lUmFuZ2VGaWx0ZXIgPSB7IHJhbmdlOiB7IHRpbWVzdGFtcDogeyBndGU6IHRpbWVHdGUsIGx0ZTogdGltZUx0ZSB9IH0gfTtcblxuICAgICAgICBsZXQgYWdlbnRJZHNUb1F1ZXJ5OiBzdHJpbmdbXSB8IG51bGwgPSBudWxsO1xuICAgICAgICBsZXQgYWdlbnRUb0ludHVuZUlkOiBSZWNvcmQ8c3RyaW5nLCBzdHJpbmc+ID0ge307XG4gICAgICAgIGxldCBkZXZpY2VzTWFwOiBSZWNvcmQ8c3RyaW5nLCBhbnk+ID0ge307XG5cbiAgICAgICAgaWYgKGludHVuZV9jb3JyZWxhdGVkX29ubHkpIHtcbiAgICAgICAgICAvLyBGZXRjaCBhbGwgbGlua2VkIFdhenVoIGFnZW50IElEcyBmcm9tIGlkZW50aXR5IGluZGV4XG4gICAgICAgICAgY29uc3QgaWRlbnRpdHlSZXMgPSBhd2FpdCBjbGllbnQuc2VhcmNoKHtcbiAgICAgICAgICAgIGluZGV4OiBJTlRVTkVfREVWSUNFX0lERU5USVRZX0lOREVYLFxuICAgICAgICAgICAgaWdub3JlX3VuYXZhaWxhYmxlOiB0cnVlLFxuICAgICAgICAgICAgYm9keToge1xuICAgICAgICAgICAgICBzaXplOiAxMDAwLFxuICAgICAgICAgICAgICBfc291cmNlOiBbJ3dhenVoX2FnZW50X2lkJywgJ2ludHVuZV9kZXZpY2VfaWQnXSxcbiAgICAgICAgICAgICAgcXVlcnk6IHsgbWF0Y2hfYWxsOiB7fSB9LFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICB9KTtcbiAgICAgICAgICBjb25zdCBpZGVudGl0eUhpdHMgPSAoaWRlbnRpdHlSZXMuYm9keSBhcyBhbnkpPy5oaXRzPy5oaXRzID8/IFtdO1xuICAgICAgICAgIGFnZW50SWRzVG9RdWVyeSA9IGlkZW50aXR5SGl0c1xuICAgICAgICAgICAgLm1hcCgoaDogYW55KSA9PiBoLl9zb3VyY2U/LndhenVoX2FnZW50X2lkKVxuICAgICAgICAgICAgLmZpbHRlcigoaWQ6IHN0cmluZykgPT4gaWQgJiYgaWQgIT09ICcwMDAnKTtcbiAgICAgICAgICBpZiAoYWdlbnRJZHNUb1F1ZXJ5Lmxlbmd0aCA9PT0gMCkge1xuICAgICAgICAgICAgcmV0dXJuIHJlcy5vayh7XG4gICAgICAgICAgICAgIGJvZHk6IHtcbiAgICAgICAgICAgICAgICBhbGVydHM6IFtdLFxuICAgICAgICAgICAgICAgIGVucmljaG1lbnRzOiB7fSxcbiAgICAgICAgICAgICAgICB0b3RhbDogMCxcbiAgICAgICAgICAgICAgICBpZGVudGl0eV9jb3VudDogMCxcbiAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIH0pO1xuICAgICAgICAgIH1cbiAgICAgICAgICBpZGVudGl0eUhpdHMuZm9yRWFjaCgoaDogYW55KSA9PiB7XG4gICAgICAgICAgICBjb25zdCBzID0gaC5fc291cmNlO1xuICAgICAgICAgICAgaWYgKHM/LndhenVoX2FnZW50X2lkKSBhZ2VudFRvSW50dW5lSWRbcy53YXp1aF9hZ2VudF9pZF0gPSBzLmludHVuZV9kZXZpY2VfaWQ7XG4gICAgICAgICAgfSk7XG4gICAgICAgIH1cblxuICAgICAgICAvLyBCdWlsZCBhbGVydHMgcXVlcnk6IGV4Y2x1ZGUgYWdlbnQgMDAwIChtYW5hZ2VyKSwgYXBwbHkgdGltZSByYW5nZSxcbiAgICAgICAgLy8gYW5kIG9wdGlvbmFsbHkgcmVzdHJpY3QgdG8gSW50dW5lLWNvcnJlbGF0ZWQgYWdlbnRzIG9ubHlcbiAgICAgICAgY29uc3QgbXVzdDogYW55W10gPSBbdGltZVJhbmdlRmlsdGVyXTtcbiAgICAgICAgbXVzdC5wdXNoKHsgYm9vbDogeyBtdXN0X25vdDogW3sgdGVybTogeyAnYWdlbnQuaWQnOiAnMDAwJyB9IH1dIH0gfSk7XG4gICAgICAgIGlmIChhZ2VudElkc1RvUXVlcnkgJiYgYWdlbnRJZHNUb1F1ZXJ5Lmxlbmd0aCA+IDApIHtcbiAgICAgICAgICBtdXN0LnB1c2goeyB0ZXJtczogeyAnYWdlbnQuaWQnOiBhZ2VudElkc1RvUXVlcnkgfSB9KTtcbiAgICAgICAgfVxuXG4gICAgICAgIGNvbnN0IGFsZXJ0c0JvZHkgPSB7XG4gICAgICAgICAgZnJvbSxcbiAgICAgICAgICBzaXplLFxuICAgICAgICAgIHNvcnQ6IFt7IHRpbWVzdGFtcDogeyBvcmRlcjogJ2Rlc2MnIH0gfV0sXG4gICAgICAgICAgX3NvdXJjZTogWydhZ2VudC5pZCcsICdhZ2VudC5uYW1lJywgJ3J1bGUuZGVzY3JpcHRpb24nLCAncnVsZS5sZXZlbCcsICd0aW1lc3RhbXAnXSxcbiAgICAgICAgICBxdWVyeTogeyBib29sOiB7IG11c3QgfSB9LFxuICAgICAgICB9O1xuXG4gICAgICAgIGNvbnN0IFthbGVydHNSZXNwb25zZSwgY291bnRSZXNwb25zZV0gPSBhd2FpdCBQcm9taXNlLmFsbChbXG4gICAgICAgICAgY2xpZW50LnNlYXJjaCh7XG4gICAgICAgICAgICBpbmRleDogV0FaVUhfQUxFUlRTX1BBVFRFUk4sXG4gICAgICAgICAgICBpZ25vcmVfdW5hdmFpbGFibGU6IHRydWUsXG4gICAgICAgICAgICBib2R5OiBhbGVydHNCb2R5LFxuICAgICAgICAgIH0pLFxuICAgICAgICAgIGNsaWVudC5zZWFyY2goe1xuICAgICAgICAgICAgaW5kZXg6IFdBWlVIX0FMRVJUU19QQVRURVJOLFxuICAgICAgICAgICAgaWdub3JlX3VuYXZhaWxhYmxlOiB0cnVlLFxuICAgICAgICAgICAgYm9keToge1xuICAgICAgICAgICAgICBzaXplOiAwLFxuICAgICAgICAgICAgICBxdWVyeTogYWxlcnRzQm9keS5xdWVyeSxcbiAgICAgICAgICAgICAgdHJhY2tfdG90YWxfaGl0czogdHJ1ZSxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgfSksXG4gICAgICAgIF0pO1xuXG4gICAgICAgIGNvbnN0IGFsZXJ0SGl0cyA9IChhbGVydHNSZXNwb25zZS5ib2R5IGFzIGFueSk/LmhpdHM/LmhpdHMgPz8gW107XG4gICAgICAgIGNvbnN0IHRvdGFsID1cbiAgICAgICAgICAoY291bnRSZXNwb25zZS5ib2R5IGFzIGFueSk/LmhpdHM/LnRvdGFsPy52YWx1ZSA/P1xuICAgICAgICAgIChjb3VudFJlc3BvbnNlLmJvZHkgYXMgYW55KT8uaGl0cz8udG90YWwgPz9cbiAgICAgICAgICAwO1xuXG4gICAgICAgIGNvbnN0IGFnZW50SWRzID0gW1xuICAgICAgICAgIC4uLm5ldyBTZXQoYWxlcnRIaXRzLm1hcCgoaDogYW55KSA9PiBoLl9zb3VyY2U/LlsnYWdlbnQuaWQnXSkuZmlsdGVyKEJvb2xlYW4pKSxcbiAgICAgICAgXTtcblxuICAgICAgICBpZiAoYWdlbnRJZHMubGVuZ3RoID4gMCkge1xuICAgICAgICAgIGNvbnN0IGlkZW50aXR5TG9va3VwID0gYXdhaXQgY2xpZW50LnNlYXJjaCh7XG4gICAgICAgICAgICBpbmRleDogSU5UVU5FX0RFVklDRV9JREVOVElUWV9JTkRFWCxcbiAgICAgICAgICAgIGlnbm9yZV91bmF2YWlsYWJsZTogdHJ1ZSxcbiAgICAgICAgICAgIGJvZHk6IHtcbiAgICAgICAgICAgICAgc2l6ZTogNTAwLFxuICAgICAgICAgICAgICBxdWVyeTogeyB0ZXJtczogeyB3YXp1aF9hZ2VudF9pZDogYWdlbnRJZHMgfSB9LFxuICAgICAgICAgICAgICBfc291cmNlOiBbJ3dhenVoX2FnZW50X2lkJywgJ2ludHVuZV9kZXZpY2VfaWQnXSxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgfSk7XG4gICAgICAgICAgY29uc3QgbG9va3VwSGl0cyA9IChpZGVudGl0eUxvb2t1cC5ib2R5IGFzIGFueSk/LmhpdHM/LmhpdHMgPz8gW107XG4gICAgICAgICAgbG9va3VwSGl0cy5mb3JFYWNoKChoOiBhbnkpID0+IHtcbiAgICAgICAgICAgIGNvbnN0IHMgPSBoLl9zb3VyY2U7XG4gICAgICAgICAgICBpZiAocz8ud2F6dWhfYWdlbnRfaWQpXG4gICAgICAgICAgICAgIGFnZW50VG9JbnR1bmVJZFtzLndhenVoX2FnZW50X2lkXSA9IHMuaW50dW5lX2RldmljZV9pZDtcbiAgICAgICAgICB9KTtcbiAgICAgICAgfVxuXG4gICAgICAgIGNvbnN0IGludHVuZUlkcyA9IFsuLi5uZXcgU2V0KE9iamVjdC52YWx1ZXMoYWdlbnRUb0ludHVuZUlkKS5maWx0ZXIoQm9vbGVhbikpXTtcbiAgICAgICAgaWYgKGludHVuZUlkcy5sZW5ndGggPiAwKSB7XG4gICAgICAgICAgY29uc3QgZGV2UmVzID0gYXdhaXQgY2xpZW50LnNlYXJjaCh7XG4gICAgICAgICAgICBpbmRleDogSU5UVU5FX0RFVklDRVNfSU5ERVgsXG4gICAgICAgICAgICBpZ25vcmVfdW5hdmFpbGFibGU6IHRydWUsXG4gICAgICAgICAgICBib2R5OiB7XG4gICAgICAgICAgICAgIHNpemU6IGludHVuZUlkcy5sZW5ndGgsXG4gICAgICAgICAgICAgIHF1ZXJ5OiB7IHRlcm1zOiB7IGludHVuZV9kZXZpY2VfaWQ6IGludHVuZUlkcyB9IH0sXG4gICAgICAgICAgICAgIF9zb3VyY2U6IFsnaW50dW5lX2RldmljZV9pZCcsICdjb21wbGlhbmNlX3N0YXRlJywgJ2RldmljZV9uYW1lJywgJ3VzZXJfcHJpbmNpcGFsX25hbWUnXSxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgfSk7XG4gICAgICAgICAgY29uc3QgZGV2SGl0cyA9IChkZXZSZXMuYm9keSBhcyBhbnkpPy5oaXRzPy5oaXRzID8/IFtdO1xuICAgICAgICAgIGRldkhpdHMuZm9yRWFjaCgoaDogYW55KSA9PiB7XG4gICAgICAgICAgICBjb25zdCBzID0gaC5fc291cmNlO1xuICAgICAgICAgICAgaWYgKHM/LmludHVuZV9kZXZpY2VfaWQpIGRldmljZXNNYXBbcy5pbnR1bmVfZGV2aWNlX2lkXSA9IHM7XG4gICAgICAgICAgfSk7XG4gICAgICAgIH1cblxuICAgICAgICBjb25zdCBlbnJpY2htZW50czogUmVjb3JkPHN0cmluZywgYW55PiA9IHt9O1xuICAgICAgICBPYmplY3QuZW50cmllcyhhZ2VudFRvSW50dW5lSWQpLmZvckVhY2goKFthZ2VudElkLCBpbnR1bmVJZF0pID0+IHtcbiAgICAgICAgICBlbnJpY2htZW50c1thZ2VudElkXSA9IGRldmljZXNNYXBbaW50dW5lSWRdID8/IG51bGw7XG4gICAgICAgIH0pO1xuXG4gICAgICAgIHJldHVybiByZXMub2soe1xuICAgICAgICAgIGJvZHk6IHtcbiAgICAgICAgICAgIGFsZXJ0czogYWxlcnRIaXRzLFxuICAgICAgICAgICAgZW5yaWNobWVudHMsXG4gICAgICAgICAgICB0b3RhbCxcbiAgICAgICAgICAgIGlkZW50aXR5X2NvdW50OiBPYmplY3Qua2V5cyhhZ2VudFRvSW50dW5lSWQpLmxlbmd0aCxcbiAgICAgICAgICB9LFxuICAgICAgICB9KTtcbiAgICAgIH0gY2F0Y2ggKGVycjogYW55KSB7XG4gICAgICAgIHJldHVybiByZXMuY3VzdG9tRXJyb3Ioe1xuICAgICAgICAgIHN0YXR1c0NvZGU6IGVyci5zdGF0dXNDb2RlID8/IDUwMCxcbiAgICAgICAgICBib2R5OiBlcnIubWVzc2FnZSA/PyBTdHJpbmcoZXJyKSxcbiAgICAgICAgfSk7XG4gICAgICB9XG4gICAgfVxuICApO1xuXG4gIC8vIEdFVCBJbnR1bmUgYXVkaXQgZXZlbnRzIChzeW5jZWQgZnJvbSBHcmFwaCBkZXZpY2VNYW5hZ2VtZW50L2F1ZGl0RXZlbnRzKVxuICByb3V0ZXIuZ2V0KFxuICAgIHtcbiAgICAgIHBhdGg6ICcvYXBpL2ludHVuZV9wbHVnaW4vaW50dW5lX2F1ZGl0X2V2ZW50cycsXG4gICAgICB2YWxpZGF0ZToge1xuICAgICAgICBxdWVyeTogc2NoZW1hLm9iamVjdCh7XG4gICAgICAgICAgc2l6ZTogc2NoZW1hLm1heWJlKHNjaGVtYS5udW1iZXIoKSksXG4gICAgICAgIH0pLFxuICAgICAgfSxcbiAgICB9LFxuICAgIGFzeW5jIChjb250ZXh0LCByZXEsIHJlcykgPT4ge1xuICAgICAgdHJ5IHtcbiAgICAgICAgY29uc3QgY2xpZW50ID0gZ2V0Q2xpZW50KGNvbnRleHQpO1xuICAgICAgICBjb25zdCBzaXplID0gcmVxLnF1ZXJ5LnNpemUgPz8gMTAwO1xuICAgICAgICBjb25zdCBib2R5ID0ge1xuICAgICAgICAgIHNpemUsXG4gICAgICAgICAgc29ydDogW3sgYWN0aXZpdHlfZGF0ZV90aW1lOiB7IG9yZGVyOiAnZGVzYycgfSB9XSxcbiAgICAgICAgICBxdWVyeTogeyBtYXRjaF9hbGw6IHt9IH0sXG4gICAgICAgIH07XG4gICAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgY2xpZW50LnNlYXJjaCh7XG4gICAgICAgICAgaW5kZXg6IElOVFVORV9BVURJVF9FVkVOVFNfSU5ERVgsXG4gICAgICAgICAgaWdub3JlX3VuYXZhaWxhYmxlOiB0cnVlLFxuICAgICAgICAgIGJvZHksXG4gICAgICAgIH0pO1xuICAgICAgICBjb25zdCBoaXRzID0gKHJlc3BvbnNlLmJvZHkgYXMgYW55KT8uaGl0cyA/PyB7fTtcbiAgICAgICAgcmV0dXJuIHJlcy5vayh7XG4gICAgICAgICAgYm9keToge1xuICAgICAgICAgICAgZXZlbnRzOiAoaGl0cy5oaXRzID8/IFtdKS5tYXAoKGg6IGFueSkgPT4gaC5fc291cmNlKS5maWx0ZXIoQm9vbGVhbiksXG4gICAgICAgICAgICB0b3RhbDogaGl0cy50b3RhbCA/PyB7IHZhbHVlOiAwIH0sXG4gICAgICAgICAgfSxcbiAgICAgICAgfSk7XG4gICAgICB9IGNhdGNoIChlcnI6IGFueSkge1xuICAgICAgICByZXR1cm4gcmVzLmN1c3RvbUVycm9yKHtcbiAgICAgICAgICBzdGF0dXNDb2RlOiBlcnIuc3RhdHVzQ29kZSA/PyA1MDAsXG4gICAgICAgICAgYm9keTogZXJyLm1lc3NhZ2UgPz8gU3RyaW5nKGVyciksXG4gICAgICAgIH0pO1xuICAgICAgfVxuICAgIH1cbiAgKTtcblxuICAvLyBHRVQgZGV0ZWN0ZWQgYXBwc1xuICByb3V0ZXIuZ2V0KFxuICAgIHtcbiAgICAgIHBhdGg6ICcvYXBpL2ludHVuZV9wbHVnaW4vZGV0ZWN0ZWRfYXBwcycsXG4gICAgICB2YWxpZGF0ZToge1xuICAgICAgICBxdWVyeTogc2NoZW1hLm9iamVjdCh7XG4gICAgICAgICAgc2l6ZTogc2NoZW1hLm1heWJlKHNjaGVtYS5udW1iZXIoKSksXG4gICAgICAgICAgZnJvbTogc2NoZW1hLm1heWJlKHNjaGVtYS5udW1iZXIoKSksXG4gICAgICAgIH0pLFxuICAgICAgfSxcbiAgICB9LFxuICAgIGFzeW5jIChjb250ZXh0LCByZXEsIHJlcykgPT4ge1xuICAgICAgdHJ5IHtcbiAgICAgICAgY29uc3QgY2xpZW50ID0gZ2V0Q2xpZW50KGNvbnRleHQpO1xuICAgICAgICBjb25zdCBzaXplID0gcmVxLnF1ZXJ5LnNpemUgPz8gNTA7XG4gICAgICAgIGNvbnN0IGZyb20gPSByZXEucXVlcnkuZnJvbSA/PyAwO1xuICAgICAgICBjb25zdCBib2R5ID0ge1xuICAgICAgICAgIHNpemUsXG4gICAgICAgICAgZnJvbSxcbiAgICAgICAgICBzb3J0OiBbeyBkZXZpY2VfY291bnQ6IHsgb3JkZXI6ICdkZXNjJywgbWlzc2luZzogJ19sYXN0JyB9IH0sIHsgJ2Rpc3BsYXlfbmFtZS5rZXl3b3JkJzogeyBvcmRlcjogJ2FzYycsIG1pc3Npbmc6ICdfbGFzdCcgfSB9XSxcbiAgICAgICAgICBxdWVyeTogeyBtYXRjaF9hbGw6IHt9IH0sXG4gICAgICAgIH07XG4gICAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgY2xpZW50LnNlYXJjaCh7XG4gICAgICAgICAgaW5kZXg6IElOVFVORV9ERVRFQ1RFRF9BUFBTX0lOREVYLFxuICAgICAgICAgIGlnbm9yZV91bmF2YWlsYWJsZTogdHJ1ZSxcbiAgICAgICAgICBib2R5LFxuICAgICAgICB9KTtcbiAgICAgICAgY29uc3QgaGl0cyA9IChyZXNwb25zZS5ib2R5IGFzIGFueSk/LmhpdHMgPz8ge307XG4gICAgICAgIHJldHVybiByZXMub2soe1xuICAgICAgICAgIGJvZHk6IHtcbiAgICAgICAgICAgIGFwcHM6IChoaXRzLmhpdHMgPz8gW10pLm1hcCgoaDogYW55KSA9PiBoLl9zb3VyY2UpLmZpbHRlcihCb29sZWFuKSxcbiAgICAgICAgICAgIHRvdGFsOiBoaXRzLnRvdGFsID8/IHsgdmFsdWU6IDAgfSxcbiAgICAgICAgICB9LFxuICAgICAgICB9KTtcbiAgICAgIH0gY2F0Y2ggKGVycjogYW55KSB7XG4gICAgICAgIHJldHVybiByZXMuY3VzdG9tRXJyb3Ioe1xuICAgICAgICAgIHN0YXR1c0NvZGU6IGVyci5zdGF0dXNDb2RlID8/IDUwMCxcbiAgICAgICAgICBib2R5OiBlcnIubWVzc2FnZSA/PyBTdHJpbmcoZXJyKSxcbiAgICAgICAgfSk7XG4gICAgICB9XG4gICAgfVxuICApO1xuXG4gIC8vIEdFVCBtb2JpbGUgYXBwcyAoZnJvbSBkZXZpY2VBcHBNYW5hZ2VtZW50KVxuICByb3V0ZXIuZ2V0KFxuICAgIHtcbiAgICAgIHBhdGg6ICcvYXBpL2ludHVuZV9wbHVnaW4vbW9iaWxlX2FwcHMnLFxuICAgICAgdmFsaWRhdGU6IHtcbiAgICAgICAgcXVlcnk6IHNjaGVtYS5vYmplY3Qoe1xuICAgICAgICAgIHNpemU6IHNjaGVtYS5tYXliZShzY2hlbWEubnVtYmVyKCkpLFxuICAgICAgICAgIGZyb206IHNjaGVtYS5tYXliZShzY2hlbWEubnVtYmVyKCkpLFxuICAgICAgICAgIGFwcF90eXBlOiBzY2hlbWEubWF5YmUoc2NoZW1hLnN0cmluZygpKSxcbiAgICAgICAgICBwdWJsaXNoX3N0YXRlOiBzY2hlbWEubWF5YmUoc2NoZW1hLnN0cmluZygpKSxcbiAgICAgICAgfSksXG4gICAgICB9LFxuICAgIH0sXG4gICAgYXN5bmMgKGNvbnRleHQsIHJlcSwgcmVzKSA9PiB7XG4gICAgICB0cnkge1xuICAgICAgICBjb25zdCBjbGllbnQgPSBnZXRDbGllbnQoY29udGV4dCk7XG4gICAgICAgIGNvbnN0IHsgc2l6ZSA9IDUwLCBmcm9tID0gMCwgYXBwX3R5cGUsIHB1Ymxpc2hfc3RhdGUgfSA9IHJlcS5xdWVyeTtcbiAgICAgICAgY29uc3QgbXVzdDogYW55W10gPSBbXTtcbiAgICAgICAgaWYgKGFwcF90eXBlKSBtdXN0LnB1c2goeyB0ZXJtOiB7IGFwcF90eXBlIH0gfSk7XG4gICAgICAgIGlmIChwdWJsaXNoX3N0YXRlKSBtdXN0LnB1c2goeyB0ZXJtOiB7IHB1Ymxpc2hfc3RhdGUgfSB9KTtcbiAgICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBjbGllbnQuc2VhcmNoKHtcbiAgICAgICAgICBpbmRleDogSU5UVU5FX01PQklMRV9BUFBTX0lOREVYLFxuICAgICAgICAgIGlnbm9yZV91bmF2YWlsYWJsZTogdHJ1ZSxcbiAgICAgICAgICBib2R5OiB7XG4gICAgICAgICAgICBzaXplLFxuICAgICAgICAgICAgZnJvbSxcbiAgICAgICAgICAgIHNvcnQ6IFt7ICdkaXNwbGF5X25hbWUua2V5d29yZCc6IHsgb3JkZXI6ICdhc2MnLCBtaXNzaW5nOiAnX2xhc3QnIH0gfV0sXG4gICAgICAgICAgICBxdWVyeTogbXVzdC5sZW5ndGggPyB7IGJvb2w6IHsgbXVzdCB9IH0gOiB7IG1hdGNoX2FsbDoge30gfSxcbiAgICAgICAgICB9LFxuICAgICAgICB9KTtcbiAgICAgICAgY29uc3QgaGl0cyA9IChyZXNwb25zZS5ib2R5IGFzIGFueSk/LmhpdHMgPz8ge307XG4gICAgICAgIHJldHVybiByZXMub2soeyBib2R5OiB7IGFwcHM6IChoaXRzLmhpdHMgPz8gW10pLm1hcCgoaDogYW55KSA9PiBoLl9zb3VyY2UpLmZpbHRlcihCb29sZWFuKSwgdG90YWw6IGhpdHMudG90YWwgfSB9KTtcbiAgICAgIH0gY2F0Y2ggKGVycjogYW55KSB7XG4gICAgICAgIHJldHVybiByZXMuY3VzdG9tRXJyb3IoeyBzdGF0dXNDb2RlOiBlcnIuc3RhdHVzQ29kZSA/PyA1MDAsIGJvZHk6IGVyci5tZXNzYWdlID8/IFN0cmluZyhlcnIpIH0pO1xuICAgICAgfVxuICAgIH1cbiAgKTtcblxuICAvLyBHRVQgY29tcGxpYW5jZSBwb2xpY2llc1xuICByb3V0ZXIuZ2V0KFxuICAgIHtcbiAgICAgIHBhdGg6ICcvYXBpL2ludHVuZV9wbHVnaW4vY29tcGxpYW5jZV9wb2xpY2llcycsXG4gICAgICB2YWxpZGF0ZToge1xuICAgICAgICBxdWVyeTogc2NoZW1hLm9iamVjdCh7XG4gICAgICAgICAgc2l6ZTogc2NoZW1hLm1heWJlKHNjaGVtYS5udW1iZXIoKSksXG4gICAgICAgICAgZnJvbTogc2NoZW1hLm1heWJlKHNjaGVtYS5udW1iZXIoKSksXG4gICAgICAgIH0pLFxuICAgICAgfSxcbiAgICB9LFxuICAgIGFzeW5jIChjb250ZXh0LCByZXEsIHJlcykgPT4ge1xuICAgICAgdHJ5IHtcbiAgICAgICAgY29uc3QgY2xpZW50ID0gZ2V0Q2xpZW50KGNvbnRleHQpO1xuICAgICAgICBjb25zdCB7IHNpemUgPSA1MCwgZnJvbSA9IDAgfSA9IHJlcS5xdWVyeTtcbiAgICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBjbGllbnQuc2VhcmNoKHtcbiAgICAgICAgICBpbmRleDogSU5UVU5FX0NPTVBMSUFOQ0VfUE9MSUNJRVNfSU5ERVgsXG4gICAgICAgICAgaWdub3JlX3VuYXZhaWxhYmxlOiB0cnVlLFxuICAgICAgICAgIGJvZHk6IHtcbiAgICAgICAgICAgIHNpemUsXG4gICAgICAgICAgICBmcm9tLFxuICAgICAgICAgICAgc29ydDogW3sgJ2Rpc3BsYXlfbmFtZS5rZXl3b3JkJzogeyBvcmRlcjogJ2FzYycsIG1pc3Npbmc6ICdfbGFzdCcgfSB9XSxcbiAgICAgICAgICAgIHF1ZXJ5OiB7IG1hdGNoX2FsbDoge30gfSxcbiAgICAgICAgICB9LFxuICAgICAgICB9KTtcbiAgICAgICAgY29uc3QgaGl0cyA9IChyZXNwb25zZS5ib2R5IGFzIGFueSk/LmhpdHMgPz8ge307XG4gICAgICAgIHJldHVybiByZXMub2soeyBib2R5OiB7IHBvbGljaWVzOiAoaGl0cy5oaXRzID8/IFtdKS5tYXAoKGg6IGFueSkgPT4gaC5fc291cmNlKS5maWx0ZXIoQm9vbGVhbiksIHRvdGFsOiBoaXRzLnRvdGFsIH0gfSk7XG4gICAgICB9IGNhdGNoIChlcnI6IGFueSkge1xuICAgICAgICByZXR1cm4gcmVzLmN1c3RvbUVycm9yKHsgc3RhdHVzQ29kZTogZXJyLnN0YXR1c0NvZGUgPz8gNTAwLCBib2R5OiBlcnIubWVzc2FnZSA/PyBTdHJpbmcoZXJyKSB9KTtcbiAgICAgIH1cbiAgICB9XG4gICk7XG5cbiAgLy8gR0VUIGNvbmZpZyBwcm9maWxlc1xuICByb3V0ZXIuZ2V0KFxuICAgIHtcbiAgICAgIHBhdGg6ICcvYXBpL2ludHVuZV9wbHVnaW4vY29uZmlnX3Byb2ZpbGVzJyxcbiAgICAgIHZhbGlkYXRlOiB7XG4gICAgICAgIHF1ZXJ5OiBzY2hlbWEub2JqZWN0KHtcbiAgICAgICAgICBzaXplOiBzY2hlbWEubWF5YmUoc2NoZW1hLm51bWJlcigpKSxcbiAgICAgICAgICBmcm9tOiBzY2hlbWEubWF5YmUoc2NoZW1hLm51bWJlcigpKSxcbiAgICAgICAgfSksXG4gICAgICB9LFxuICAgIH0sXG4gICAgYXN5bmMgKGNvbnRleHQsIHJlcSwgcmVzKSA9PiB7XG4gICAgICB0cnkge1xuICAgICAgICBjb25zdCBjbGllbnQgPSBnZXRDbGllbnQoY29udGV4dCk7XG4gICAgICAgIGNvbnN0IHsgc2l6ZSA9IDUwLCBmcm9tID0gMCB9ID0gcmVxLnF1ZXJ5O1xuICAgICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGNsaWVudC5zZWFyY2goe1xuICAgICAgICAgIGluZGV4OiBJTlRVTkVfQ09ORklHX1BST0ZJTEVTX0lOREVYLFxuICAgICAgICAgIGlnbm9yZV91bmF2YWlsYWJsZTogdHJ1ZSxcbiAgICAgICAgICBib2R5OiB7XG4gICAgICAgICAgICBzaXplLFxuICAgICAgICAgICAgZnJvbSxcbiAgICAgICAgICAgIHNvcnQ6IFt7ICdkaXNwbGF5X25hbWUua2V5d29yZCc6IHsgb3JkZXI6ICdhc2MnLCBtaXNzaW5nOiAnX2xhc3QnIH0gfV0sXG4gICAgICAgICAgICBxdWVyeTogeyBtYXRjaF9hbGw6IHt9IH0sXG4gICAgICAgICAgfSxcbiAgICAgICAgfSk7XG4gICAgICAgIGNvbnN0IGhpdHMgPSAocmVzcG9uc2UuYm9keSBhcyBhbnkpPy5oaXRzID8/IHt9O1xuICAgICAgICByZXR1cm4gcmVzLm9rKHsgYm9keTogeyBwcm9maWxlczogKGhpdHMuaGl0cyA/PyBbXSkubWFwKChoOiBhbnkpID0+IGguX3NvdXJjZSkuZmlsdGVyKEJvb2xlYW4pLCB0b3RhbDogaGl0cy50b3RhbCB9IH0pO1xuICAgICAgfSBjYXRjaCAoZXJyOiBhbnkpIHtcbiAgICAgICAgcmV0dXJuIHJlcy5jdXN0b21FcnJvcih7IHN0YXR1c0NvZGU6IGVyci5zdGF0dXNDb2RlID8/IDUwMCwgYm9keTogZXJyLm1lc3NhZ2UgPz8gU3RyaW5nKGVycikgfSk7XG4gICAgICB9XG4gICAgfVxuICApO1xuXG4gIC8vIEdFVCBzY3JpcHRzIChQb3dlclNoZWxsICsgc2hlbGwpXG4gIHJvdXRlci5nZXQoXG4gICAge1xuICAgICAgcGF0aDogJy9hcGkvaW50dW5lX3BsdWdpbi9zY3JpcHRzJyxcbiAgICAgIHZhbGlkYXRlOiB7XG4gICAgICAgIHF1ZXJ5OiBzY2hlbWEub2JqZWN0KHtcbiAgICAgICAgICBzaXplOiBzY2hlbWEubWF5YmUoc2NoZW1hLm51bWJlcigpKSxcbiAgICAgICAgICBmcm9tOiBzY2hlbWEubWF5YmUoc2NoZW1hLm51bWJlcigpKSxcbiAgICAgICAgICBzY3JpcHRfdHlwZTogc2NoZW1hLm1heWJlKHNjaGVtYS5zdHJpbmcoKSksXG4gICAgICAgIH0pLFxuICAgICAgfSxcbiAgICB9LFxuICAgIGFzeW5jIChjb250ZXh0LCByZXEsIHJlcykgPT4ge1xuICAgICAgdHJ5IHtcbiAgICAgICAgY29uc3QgY2xpZW50ID0gZ2V0Q2xpZW50KGNvbnRleHQpO1xuICAgICAgICBjb25zdCB7IHNpemUgPSA1MCwgZnJvbSA9IDAsIHNjcmlwdF90eXBlIH0gPSByZXEucXVlcnk7XG4gICAgICAgIGNvbnN0IG11c3Q6IGFueVtdID0gW107XG4gICAgICAgIGlmIChzY3JpcHRfdHlwZSkgbXVzdC5wdXNoKHsgdGVybTogeyBzY3JpcHRfdHlwZSB9IH0pO1xuICAgICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGNsaWVudC5zZWFyY2goe1xuICAgICAgICAgIGluZGV4OiBJTlRVTkVfU0NSSVBUU19JTkRFWCxcbiAgICAgICAgICBpZ25vcmVfdW5hdmFpbGFibGU6IHRydWUsXG4gICAgICAgICAgYm9keToge1xuICAgICAgICAgICAgc2l6ZSxcbiAgICAgICAgICAgIGZyb20sXG4gICAgICAgICAgICBzb3J0OiBbeyBsYXN0X21vZGlmaWVkX2RhdGVfdGltZTogeyBvcmRlcjogJ2Rlc2MnLCBtaXNzaW5nOiAnX2xhc3QnIH0gfV0sXG4gICAgICAgICAgICBxdWVyeTogbXVzdC5sZW5ndGggPyB7IGJvb2w6IHsgbXVzdCB9IH0gOiB7IG1hdGNoX2FsbDoge30gfSxcbiAgICAgICAgICB9LFxuICAgICAgICB9KTtcbiAgICAgICAgY29uc3QgaGl0cyA9IChyZXNwb25zZS5ib2R5IGFzIGFueSk/LmhpdHMgPz8ge307XG4gICAgICAgIHJldHVybiByZXMub2soeyBib2R5OiB7IHNjcmlwdHM6IChoaXRzLmhpdHMgPz8gW10pLm1hcCgoaDogYW55KSA9PiBoLl9zb3VyY2UpLmZpbHRlcihCb29sZWFuKSwgdG90YWw6IGhpdHMudG90YWwgfSB9KTtcbiAgICAgIH0gY2F0Y2ggKGVycjogYW55KSB7XG4gICAgICAgIHJldHVybiByZXMuY3VzdG9tRXJyb3IoeyBzdGF0dXNDb2RlOiBlcnIuc3RhdHVzQ29kZSA/PyA1MDAsIGJvZHk6IGVyci5tZXNzYWdlID8/IFN0cmluZyhlcnIpIH0pO1xuICAgICAgfVxuICAgIH1cbiAgKTtcblxuICAvLyBHRVQgZW5yb2xsbWVudCBjb25maWd1cmF0aW9uc1xuICByb3V0ZXIuZ2V0KFxuICAgIHtcbiAgICAgIHBhdGg6ICcvYXBpL2ludHVuZV9wbHVnaW4vZW5yb2xsbWVudF9jb25maWdzJyxcbiAgICAgIHZhbGlkYXRlOiB7XG4gICAgICAgIHF1ZXJ5OiBzY2hlbWEub2JqZWN0KHtcbiAgICAgICAgICBzaXplOiBzY2hlbWEubWF5YmUoc2NoZW1hLm51bWJlcigpKSxcbiAgICAgICAgICBmcm9tOiBzY2hlbWEubWF5YmUoc2NoZW1hLm51bWJlcigpKSxcbiAgICAgICAgfSksXG4gICAgICB9LFxuICAgIH0sXG4gICAgYXN5bmMgKGNvbnRleHQsIHJlcSwgcmVzKSA9PiB7XG4gICAgICB0cnkge1xuICAgICAgICBjb25zdCBjbGllbnQgPSBnZXRDbGllbnQoY29udGV4dCk7XG4gICAgICAgIGNvbnN0IHsgc2l6ZSA9IDUwLCBmcm9tID0gMCB9ID0gcmVxLnF1ZXJ5O1xuICAgICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGNsaWVudC5zZWFyY2goe1xuICAgICAgICAgIGluZGV4OiBJTlRVTkVfRU5ST0xMTUVOVF9JTkRFWCxcbiAgICAgICAgICBpZ25vcmVfdW5hdmFpbGFibGU6IHRydWUsXG4gICAgICAgICAgYm9keToge1xuICAgICAgICAgICAgc2l6ZSxcbiAgICAgICAgICAgIGZyb20sXG4gICAgICAgICAgICBzb3J0OiBbeyBwcmlvcml0eTogeyBvcmRlcjogJ2FzYycsIG1pc3Npbmc6ICdfbGFzdCcgfSB9LCB7ICdkaXNwbGF5X25hbWUua2V5d29yZCc6IHsgb3JkZXI6ICdhc2MnLCBtaXNzaW5nOiAnX2xhc3QnIH0gfV0sXG4gICAgICAgICAgICBxdWVyeTogeyBtYXRjaF9hbGw6IHt9IH0sXG4gICAgICAgICAgfSxcbiAgICAgICAgfSk7XG4gICAgICAgIGNvbnN0IGhpdHMgPSAocmVzcG9uc2UuYm9keSBhcyBhbnkpPy5oaXRzID8/IHt9O1xuICAgICAgICByZXR1cm4gcmVzLm9rKHsgYm9keTogeyBjb25maWdzOiAoaGl0cy5oaXRzID8/IFtdKS5tYXAoKGg6IGFueSkgPT4gaC5fc291cmNlKS5maWx0ZXIoQm9vbGVhbiksIHRvdGFsOiBoaXRzLnRvdGFsIH0gfSk7XG4gICAgICB9IGNhdGNoIChlcnI6IGFueSkge1xuICAgICAgICByZXR1cm4gcmVzLmN1c3RvbUVycm9yKHsgc3RhdHVzQ29kZTogZXJyLnN0YXR1c0NvZGUgPz8gNTAwLCBib2R5OiBlcnIubWVzc2FnZSA/PyBTdHJpbmcoZXJyKSB9KTtcbiAgICAgIH1cbiAgICB9XG4gICk7XG5cbiAgLy8gR0VUIEF1dG9waWxvdCBkZXZpY2VzXG4gIHJvdXRlci5nZXQoXG4gICAge1xuICAgICAgcGF0aDogJy9hcGkvaW50dW5lX3BsdWdpbi9hdXRvcGlsb3RfZGV2aWNlcycsXG4gICAgICB2YWxpZGF0ZToge1xuICAgICAgICBxdWVyeTogc2NoZW1hLm9iamVjdCh7XG4gICAgICAgICAgc2l6ZTogc2NoZW1hLm1heWJlKHNjaGVtYS5udW1iZXIoKSksXG4gICAgICAgICAgZnJvbTogc2NoZW1hLm1heWJlKHNjaGVtYS5udW1iZXIoKSksXG4gICAgICAgICAgZW5yb2xsbWVudF9zdGF0ZTogc2NoZW1hLm1heWJlKHNjaGVtYS5zdHJpbmcoKSksXG4gICAgICAgIH0pLFxuICAgICAgfSxcbiAgICB9LFxuICAgIGFzeW5jIChjb250ZXh0LCByZXEsIHJlcykgPT4ge1xuICAgICAgdHJ5IHtcbiAgICAgICAgY29uc3QgY2xpZW50ID0gZ2V0Q2xpZW50KGNvbnRleHQpO1xuICAgICAgICBjb25zdCB7IHNpemUgPSA1MCwgZnJvbSA9IDAsIGVucm9sbG1lbnRfc3RhdGUgfSA9IHJlcS5xdWVyeTtcbiAgICAgICAgY29uc3QgbXVzdDogYW55W10gPSBbXTtcbiAgICAgICAgaWYgKGVucm9sbG1lbnRfc3RhdGUpIG11c3QucHVzaCh7IHRlcm06IHsgZW5yb2xsbWVudF9zdGF0ZSB9IH0pO1xuICAgICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGNsaWVudC5zZWFyY2goe1xuICAgICAgICAgIGluZGV4OiBJTlRVTkVfQVVUT1BJTE9UX0lOREVYLFxuICAgICAgICAgIGlnbm9yZV91bmF2YWlsYWJsZTogdHJ1ZSxcbiAgICAgICAgICBib2R5OiB7XG4gICAgICAgICAgICBzaXplLFxuICAgICAgICAgICAgZnJvbSxcbiAgICAgICAgICAgIHNvcnQ6IFt7IGxhc3RfY29udGFjdGVkX2RhdGVfdGltZTogeyBvcmRlcjogJ2Rlc2MnLCBtaXNzaW5nOiAnX2xhc3QnIH0gfV0sXG4gICAgICAgICAgICBxdWVyeTogbXVzdC5sZW5ndGggPyB7IGJvb2w6IHsgbXVzdCB9IH0gOiB7IG1hdGNoX2FsbDoge30gfSxcbiAgICAgICAgICB9LFxuICAgICAgICB9KTtcbiAgICAgICAgY29uc3QgaGl0cyA9IChyZXNwb25zZS5ib2R5IGFzIGFueSk/LmhpdHMgPz8ge307XG4gICAgICAgIHJldHVybiByZXMub2soeyBib2R5OiB7IGRldmljZXM6IChoaXRzLmhpdHMgPz8gW10pLm1hcCgoaDogYW55KSA9PiBoLl9zb3VyY2UpLmZpbHRlcihCb29sZWFuKSwgdG90YWw6IGhpdHMudG90YWwgfSB9KTtcbiAgICAgIH0gY2F0Y2ggKGVycjogYW55KSB7XG4gICAgICAgIHJldHVybiByZXMuY3VzdG9tRXJyb3IoeyBzdGF0dXNDb2RlOiBlcnIuc3RhdHVzQ29kZSA/PyA1MDAsIGJvZHk6IGVyci5tZXNzYWdlID8/IFN0cmluZyhlcnIpIH0pO1xuICAgICAgfVxuICAgIH1cbiAgKTtcblxuICAvLyBHRVQgQ29uZGl0aW9uYWwgQWNjZXNzIHBvbGljaWVzXG4gIHJvdXRlci5nZXQoXG4gICAge1xuICAgICAgcGF0aDogJy9hcGkvaW50dW5lX3BsdWdpbi9jYV9wb2xpY2llcycsXG4gICAgICB2YWxpZGF0ZToge1xuICAgICAgICBxdWVyeTogc2NoZW1hLm9iamVjdCh7XG4gICAgICAgICAgc2l6ZTogc2NoZW1hLm1heWJlKHNjaGVtYS5udW1iZXIoKSksXG4gICAgICAgICAgZnJvbTogc2NoZW1hLm1heWJlKHNjaGVtYS5udW1iZXIoKSksXG4gICAgICAgICAgc3RhdGU6IHNjaGVtYS5tYXliZShzY2hlbWEuc3RyaW5nKCkpLFxuICAgICAgICB9KSxcbiAgICAgIH0sXG4gICAgfSxcbiAgICBhc3luYyAoY29udGV4dCwgcmVxLCByZXMpID0+IHtcbiAgICAgIHRyeSB7XG4gICAgICAgIGNvbnN0IGNsaWVudCA9IGdldENsaWVudChjb250ZXh0KTtcbiAgICAgICAgY29uc3QgeyBzaXplID0gNTAsIGZyb20gPSAwLCBzdGF0ZSB9ID0gcmVxLnF1ZXJ5O1xuICAgICAgICBjb25zdCBtdXN0OiBhbnlbXSA9IFtdO1xuICAgICAgICBpZiAoc3RhdGUpIG11c3QucHVzaCh7IHRlcm06IHsgc3RhdGUgfSB9KTtcbiAgICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBjbGllbnQuc2VhcmNoKHtcbiAgICAgICAgICBpbmRleDogSU5UVU5FX0NBX1BPTElDSUVTX0lOREVYLFxuICAgICAgICAgIGlnbm9yZV91bmF2YWlsYWJsZTogdHJ1ZSxcbiAgICAgICAgICBib2R5OiB7XG4gICAgICAgICAgICBzaXplLFxuICAgICAgICAgICAgZnJvbSxcbiAgICAgICAgICAgIHNvcnQ6IFt7ICdkaXNwbGF5X25hbWUua2V5d29yZCc6IHsgb3JkZXI6ICdhc2MnLCBtaXNzaW5nOiAnX2xhc3QnIH0gfV0sXG4gICAgICAgICAgICBxdWVyeTogbXVzdC5sZW5ndGggPyB7IGJvb2w6IHsgbXVzdCB9IH0gOiB7IG1hdGNoX2FsbDoge30gfSxcbiAgICAgICAgICB9LFxuICAgICAgICB9KTtcbiAgICAgICAgY29uc3QgaGl0cyA9IChyZXNwb25zZS5ib2R5IGFzIGFueSk/LmhpdHMgPz8ge307XG4gICAgICAgIHJldHVybiByZXMub2soeyBib2R5OiB7IHBvbGljaWVzOiAoaGl0cy5oaXRzID8/IFtdKS5tYXAoKGg6IGFueSkgPT4gaC5fc291cmNlKS5maWx0ZXIoQm9vbGVhbiksIHRvdGFsOiBoaXRzLnRvdGFsIH0gfSk7XG4gICAgICB9IGNhdGNoIChlcnI6IGFueSkge1xuICAgICAgICByZXR1cm4gcmVzLmN1c3RvbUVycm9yKHsgc3RhdHVzQ29kZTogZXJyLnN0YXR1c0NvZGUgPz8gNTAwLCBib2R5OiBlcnIubWVzc2FnZSA/PyBTdHJpbmcoZXJyKSB9KTtcbiAgICAgIH1cbiAgICB9XG4gICk7XG5cbiAgLy8gR0VUIGFwcCBpbnN0YWxsIHN1bW1hcnkgKEdyYXBoIEFQSSlcbiAgcm91dGVyLmdldChcbiAgICB7XG4gICAgICBwYXRoOiAnL2FwaS9pbnR1bmVfcGx1Z2luL2FwcHMve2lkfS9pbnN0YWxsLXN1bW1hcnknLFxuICAgICAgdmFsaWRhdGU6IHsgcGFyYW1zOiBzY2hlbWEub2JqZWN0KHsgaWQ6IHNjaGVtYS5zdHJpbmcoKSB9KSB9LFxuICAgIH0sXG4gICAgYXN5bmMgKGNvbnRleHQsIHJlcSwgcmVzKSA9PiB7XG4gICAgICBjb25zdCBjb25maWcgPSBnZXRHcmFwaENvbmZpZygpO1xuICAgICAgaWYgKCFjb25maWcpIHtcbiAgICAgICAgcmV0dXJuIHJlcy5jdXN0b21FcnJvcih7IHN0YXR1c0NvZGU6IDUwMywgYm9keTogJ0dyYXBoIGNyZWRlbnRpYWxzIG5vdCBjb25maWd1cmVkJyB9KTtcbiAgICAgIH1cbiAgICAgIHRyeSB7XG4gICAgICAgIGNvbnN0IGlkID0gKHJlcS5wYXJhbXMgYXMgYW55KS5pZDtcbiAgICAgICAgY29uc3Qgc3VtbWFyeSA9IGF3YWl0IGdldEFwcEluc3RhbGxTdW1tYXJ5KGNvbmZpZywgaWQpO1xuICAgICAgICByZXR1cm4gcmVzLm9rKHsgYm9keTogc3VtbWFyeSB9KTtcbiAgICAgIH0gY2F0Y2ggKGVycjogYW55KSB7XG4gICAgICAgIHJldHVybiByZXMuY3VzdG9tRXJyb3IoeyBzdGF0dXNDb2RlOiBlcnI/LnJlc3BvbnNlPy5zdGF0dXMgPz8gNTAwLCBib2R5OiBlcnI/Lm1lc3NhZ2UgPz8gU3RyaW5nKGVycikgfSk7XG4gICAgICB9XG4gICAgfVxuICApO1xuXG4gIC8vIEdFVCBjb21wbGlhbmNlIHBvbGljeSBkZXZpY2Ugc3RhdHVzIHN1bW1hcnkgKEdyYXBoIEFQSSlcbiAgcm91dGVyLmdldChcbiAgICB7XG4gICAgICBwYXRoOiAnL2FwaS9pbnR1bmVfcGx1Z2luL2NvbXBsaWFuY2UtcG9saWNpZXMve2lkfS9kZXZpY2Utc3RhdHVzJyxcbiAgICAgIHZhbGlkYXRlOiB7IHBhcmFtczogc2NoZW1hLm9iamVjdCh7IGlkOiBzY2hlbWEuc3RyaW5nKCkgfSkgfSxcbiAgICB9LFxuICAgIGFzeW5jIChjb250ZXh0LCByZXEsIHJlcykgPT4ge1xuICAgICAgY29uc3QgY29uZmlnID0gZ2V0R3JhcGhDb25maWcoKTtcbiAgICAgIGlmICghY29uZmlnKSB7XG4gICAgICAgIHJldHVybiByZXMuY3VzdG9tRXJyb3IoeyBzdGF0dXNDb2RlOiA1MDMsIGJvZHk6ICdHcmFwaCBjcmVkZW50aWFscyBub3QgY29uZmlndXJlZCcgfSk7XG4gICAgICB9XG4gICAgICB0cnkge1xuICAgICAgICBjb25zdCBpZCA9IChyZXEucGFyYW1zIGFzIGFueSkuaWQ7XG4gICAgICAgIGNvbnN0IHN1bW1hcnkgPSBhd2FpdCBnZXRDb21wbGlhbmNlUG9saWN5RGV2aWNlU3RhdHVzU3VtbWFyeShjb25maWcsIGlkKTtcbiAgICAgICAgcmV0dXJuIHJlcy5vayh7IGJvZHk6IHN1bW1hcnkgfSk7XG4gICAgICB9IGNhdGNoIChlcnI6IGFueSkge1xuICAgICAgICByZXR1cm4gcmVzLmN1c3RvbUVycm9yKHsgc3RhdHVzQ29kZTogZXJyPy5yZXNwb25zZT8uc3RhdHVzID8/IDUwMCwgYm9keTogZXJyPy5tZXNzYWdlID8/IFN0cmluZyhlcnIpIH0pO1xuICAgICAgfVxuICAgIH1cbiAgKTtcblxuICAvLyBHRVQgY29uZmlnIHByb2ZpbGUgZGV2aWNlIHN0YXR1cyBzdW1tYXJ5IChHcmFwaCBBUEkpXG4gIHJvdXRlci5nZXQoXG4gICAge1xuICAgICAgcGF0aDogJy9hcGkvaW50dW5lX3BsdWdpbi9jb25maWctcHJvZmlsZXMve2lkfS9kZXZpY2Utc3RhdHVzJyxcbiAgICAgIHZhbGlkYXRlOiB7IHBhcmFtczogc2NoZW1hLm9iamVjdCh7IGlkOiBzY2hlbWEuc3RyaW5nKCkgfSkgfSxcbiAgICB9LFxuICAgIGFzeW5jIChjb250ZXh0LCByZXEsIHJlcykgPT4ge1xuICAgICAgY29uc3QgY29uZmlnID0gZ2V0R3JhcGhDb25maWcoKTtcbiAgICAgIGlmICghY29uZmlnKSB7XG4gICAgICAgIHJldHVybiByZXMuY3VzdG9tRXJyb3IoeyBzdGF0dXNDb2RlOiA1MDMsIGJvZHk6ICdHcmFwaCBjcmVkZW50aWFscyBub3QgY29uZmlndXJlZCcgfSk7XG4gICAgICB9XG4gICAgICB0cnkge1xuICAgICAgICBjb25zdCBpZCA9IChyZXEucGFyYW1zIGFzIGFueSkuaWQ7XG4gICAgICAgIGNvbnN0IHN1bW1hcnkgPSBhd2FpdCBnZXRDb25maWdQcm9maWxlRGV2aWNlU3RhdHVzU3VtbWFyeShjb25maWcsIGlkKTtcbiAgICAgICAgcmV0dXJuIHJlcy5vayh7IGJvZHk6IHN1bW1hcnkgfSk7XG4gICAgICB9IGNhdGNoIChlcnI6IGFueSkge1xuICAgICAgICByZXR1cm4gcmVzLmN1c3RvbUVycm9yKHsgc3RhdHVzQ29kZTogZXJyPy5yZXNwb25zZT8uc3RhdHVzID8/IDUwMCwgYm9keTogZXJyPy5tZXNzYWdlID8/IFN0cmluZyhlcnIpIH0pO1xuICAgICAgfVxuICAgIH1cbiAgKTtcblxuICAvLyBHRVQgc2NyaXB0IHJ1biBzdGF0ZXMgKEdyYXBoIEFQSSBiZXRhKVxuICByb3V0ZXIuZ2V0KFxuICAgIHtcbiAgICAgIHBhdGg6ICcvYXBpL2ludHVuZV9wbHVnaW4vc2NyaXB0cy97aWR9L3J1bi1zdGF0ZXMnLFxuICAgICAgdmFsaWRhdGU6IHtcbiAgICAgICAgcGFyYW1zOiBzY2hlbWEub2JqZWN0KHsgaWQ6IHNjaGVtYS5zdHJpbmcoKSB9KSxcbiAgICAgICAgcXVlcnk6IHNjaGVtYS5vYmplY3QoeyBzY3JpcHRfdHlwZTogc2NoZW1hLm1heWJlKHNjaGVtYS5zdHJpbmcoKSkgfSksXG4gICAgICB9LFxuICAgIH0sXG4gICAgYXN5bmMgKGNvbnRleHQsIHJlcSwgcmVzKSA9PiB7XG4gICAgICBjb25zdCBjb25maWcgPSBnZXRHcmFwaENvbmZpZygpO1xuICAgICAgaWYgKCFjb25maWcpIHtcbiAgICAgICAgcmV0dXJuIHJlcy5jdXN0b21FcnJvcih7IHN0YXR1c0NvZGU6IDUwMywgYm9keTogJ0dyYXBoIGNyZWRlbnRpYWxzIG5vdCBjb25maWd1cmVkJyB9KTtcbiAgICAgIH1cbiAgICAgIHRyeSB7XG4gICAgICAgIGNvbnN0IGlkID0gKHJlcS5wYXJhbXMgYXMgYW55KS5pZDtcbiAgICAgICAgY29uc3Qgc2NyaXB0VHlwZSA9ICgocmVxLnF1ZXJ5IGFzIGFueSkuc2NyaXB0X3R5cGUgfHwgJ3Bvd2Vyc2hlbGwnKSBhcyAncG93ZXJzaGVsbCcgfCAnc2hlbGwnO1xuICAgICAgICBjb25zdCBzdW1tYXJ5ID0gYXdhaXQgZ2V0U2NyaXB0UnVuU3RhdGVzKGNvbmZpZywgaWQsIHNjcmlwdFR5cGUpO1xuICAgICAgICByZXR1cm4gcmVzLm9rKHsgYm9keTogc3VtbWFyeSB9KTtcbiAgICAgIH0gY2F0Y2ggKGVycjogYW55KSB7XG4gICAgICAgIHJldHVybiByZXMuY3VzdG9tRXJyb3IoeyBzdGF0dXNDb2RlOiBlcnI/LnJlc3BvbnNlPy5zdGF0dXMgPz8gNTAwLCBib2R5OiBlcnI/Lm1lc3NhZ2UgPz8gU3RyaW5nKGVycikgfSk7XG4gICAgICB9XG4gICAgfVxuICApO1xuXG4gIC8vIEdFVCBkZXZpY2UgY2F0ZWdvcmllc1xuICByb3V0ZXIuZ2V0KFxuICAgIHtcbiAgICAgIHBhdGg6ICcvYXBpL2ludHVuZV9wbHVnaW4vZGV2aWNlX2NhdGVnb3JpZXMnLFxuICAgICAgdmFsaWRhdGU6IGZhbHNlLFxuICAgIH0sXG4gICAgYXN5bmMgKGNvbnRleHQsIHJlcSwgcmVzKSA9PiB7XG4gICAgICB0cnkge1xuICAgICAgICBjb25zdCBjbGllbnQgPSBnZXRDbGllbnQoY29udGV4dCk7XG4gICAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgY2xpZW50LnNlYXJjaCh7XG4gICAgICAgICAgaW5kZXg6IElOVFVORV9ERVZJQ0VfQ0FURUdPUklFU19JTkRFWCxcbiAgICAgICAgICBpZ25vcmVfdW5hdmFpbGFibGU6IHRydWUsXG4gICAgICAgICAgYm9keToge1xuICAgICAgICAgICAgc2l6ZTogMTAwLFxuICAgICAgICAgICAgc29ydDogW3sgJ2Rpc3BsYXlfbmFtZS5rZXl3b3JkJzogeyBvcmRlcjogJ2FzYycsIG1pc3Npbmc6ICdfbGFzdCcgfSB9XSxcbiAgICAgICAgICAgIHF1ZXJ5OiB7IG1hdGNoX2FsbDoge30gfSxcbiAgICAgICAgICAgIF9zb3VyY2U6IFsnaW50dW5lX2NhdGVnb3J5X2lkJywgJ2Rpc3BsYXlfbmFtZSddLFxuICAgICAgICAgIH0sXG4gICAgICAgIH0pO1xuICAgICAgICBjb25zdCBoaXRzID0gKHJlc3BvbnNlLmJvZHkgYXMgYW55KT8uaGl0cz8uaGl0cyA/PyBbXTtcbiAgICAgICAgY29uc3QgY2F0ZWdvcmllcyA9IGhpdHMubWFwKChoOiBhbnkpID0+IGguX3NvdXJjZSkuZmlsdGVyKEJvb2xlYW4pO1xuICAgICAgICByZXR1cm4gcmVzLm9rKHsgYm9keTogeyBjYXRlZ29yaWVzIH0gfSk7XG4gICAgICB9IGNhdGNoIChlcnI6IGFueSkge1xuICAgICAgICByZXR1cm4gcmVzLm9rKHsgYm9keTogeyBjYXRlZ29yaWVzOiBbXSB9IH0pO1xuICAgICAgfVxuICAgIH1cbiAgKTtcblxuICAvLyBIZWFsdGggY2hlY2tcbiAgcm91dGVyLmdldChcbiAgICB7XG4gICAgICBwYXRoOiAnL2FwaS9pbnR1bmVfcGx1Z2luL2hlYWx0aCcsXG4gICAgICB2YWxpZGF0ZTogZmFsc2UsXG4gICAgfSxcbiAgICBhc3luYyAoY29udGV4dCwgcmVxLCByZXMpID0+IHtcbiAgICAgIHJldHVybiByZXMub2soeyBib2R5OiB7IHN0YXR1czogJ29rJywgcGx1Z2luOiAnaW50dW5lUGx1Z2luJyB9IH0pO1xuICAgIH1cbiAgKTtcbn1cbiJdLCJtYXBwaW5ncyI6Ijs7Ozs7O0FBS0EsSUFBQUEsWUFBQSxHQUFBQyxPQUFBO0FBT0EsSUFBQUMsYUFBQSxHQUFBRCxPQUFBO0FBQ0EsSUFBQUUsVUFBQSxHQUFBRixPQUFBO0FBYkE7QUFDQTtBQUNBOztBQTJCQSxTQUFTRyxTQUFTQSxDQUFDQyxPQUFZLEVBQUU7RUFDL0IsT0FBT0EsT0FBTyxDQUFDQyxJQUFJLENBQUNDLFVBQVUsQ0FBQ0MsTUFBTSxDQUFDQyxhQUFhO0FBQ3JEO0FBRU8sU0FBU0Msb0JBQW9CQSxDQUFDQyxNQUFlLEVBQUU7RUFDcEQ7RUFDQUEsTUFBTSxDQUFDQyxHQUFHLENBQ1I7SUFDRUMsSUFBSSxFQUFFLDRCQUE0QjtJQUNsQ0MsUUFBUSxFQUFFO01BQ1JDLEtBQUssRUFBRUMsb0JBQU0sQ0FBQ0MsTUFBTSxDQUFDO1FBQ25CQyxJQUFJLEVBQUVGLG9CQUFNLENBQUNHLEtBQUssQ0FBQ0gsb0JBQU0sQ0FBQ0ksTUFBTSxDQUFDLENBQUMsQ0FBQztRQUNuQ0MsSUFBSSxFQUFFTCxvQkFBTSxDQUFDRyxLQUFLLENBQUNILG9CQUFNLENBQUNJLE1BQU0sQ0FBQyxDQUFDLENBQUM7UUFDbkNFLGdCQUFnQixFQUFFTixvQkFBTSxDQUFDRyxLQUFLLENBQUNILG9CQUFNLENBQUNPLE1BQU0sQ0FBQyxDQUFDLENBQUM7UUFDL0NDLGdCQUFnQixFQUFFUixvQkFBTSxDQUFDRyxLQUFLLENBQUNILG9CQUFNLENBQUNPLE1BQU0sQ0FBQyxDQUFDLENBQUM7UUFDL0NFLGVBQWUsRUFBRVQsb0JBQU0sQ0FBQ0csS0FBSyxDQUFDSCxvQkFBTSxDQUFDTyxNQUFNLENBQUMsQ0FBQztNQUMvQyxDQUFDO0lBQ0g7RUFDRixDQUFDLEVBQ0QsT0FBT2xCLE9BQU8sRUFBRXFCLEdBQUcsRUFBRUMsR0FBRyxLQUFLO0lBQzNCLElBQUk7TUFBQSxJQUFBQyxLQUFBLEVBQUFDLGNBQUEsRUFBQUMsVUFBQTtNQUNGLE1BQU10QixNQUFNLEdBQUdKLFNBQVMsQ0FBQ0MsT0FBTyxDQUFDO01BQ2pDLE1BQU07UUFBRWEsSUFBSSxHQUFHLEVBQUU7UUFBRUcsSUFBSSxHQUFHLENBQUM7UUFBRUMsZ0JBQWdCO1FBQUVFLGdCQUFnQjtRQUFFQztNQUFnQixDQUFDLEdBQUdDLEdBQUcsQ0FBQ1gsS0FBSztNQUM5RixNQUFNZ0IsSUFBVyxHQUFHLEVBQUU7TUFDdEIsSUFBSVQsZ0JBQWdCLEVBQUVTLElBQUksQ0FBQ0MsSUFBSSxDQUFDO1FBQUVDLElBQUksRUFBRTtVQUFFWDtRQUFpQjtNQUFFLENBQUMsQ0FBQztNQUMvRCxJQUFJRSxnQkFBZ0IsRUFBRU8sSUFBSSxDQUFDQyxJQUFJLENBQUM7UUFBRUMsSUFBSSxFQUFFO1VBQUVUO1FBQWlCO01BQUUsQ0FBQyxDQUFDO01BQy9ELElBQUlDLGVBQWUsRUFBRU0sSUFBSSxDQUFDQyxJQUFJLENBQUM7UUFBRUMsSUFBSSxFQUFFO1VBQUVSO1FBQWdCO01BQUUsQ0FBQyxDQUFDO01BQzdELE1BQU1TLElBQVMsR0FBRztRQUNoQmhCLElBQUk7UUFDSkcsSUFBSTtRQUNKYyxJQUFJLEVBQUUsQ0FBQztVQUFFQyxZQUFZLEVBQUU7WUFBRUMsS0FBSyxFQUFFO1VBQU87UUFBRSxDQUFDLEVBQUU7VUFBRUMsV0FBVyxFQUFFO1FBQU0sQ0FBQyxDQUFDO1FBQ25FdkIsS0FBSyxFQUFFZ0IsSUFBSSxDQUFDUSxNQUFNLEdBQUc7VUFBRUMsSUFBSSxFQUFFO1lBQUVUO1VBQUs7UUFBRSxDQUFDLEdBQUc7VUFBRVUsU0FBUyxFQUFFLENBQUM7UUFBRTtNQUM1RCxDQUFDO01BQ0QsTUFBTUMsUUFBUSxHQUFHLE1BQU1sQyxNQUFNLENBQUNtQyxNQUFNLENBQUM7UUFDbkNDLEtBQUssRUFBRUMsK0JBQW9CO1FBQzNCQyxrQkFBa0IsRUFBRSxJQUFJO1FBQ3hCWjtNQUNGLENBQUMsQ0FBQztNQUNGLE1BQU1hLElBQUksSUFBQW5CLEtBQUEsSUFBQUMsY0FBQSxHQUFJYSxRQUFRLENBQUNSLElBQUksY0FBQUwsY0FBQSx1QkFBZEEsY0FBQSxDQUF3QmtCLElBQUksY0FBQW5CLEtBQUEsY0FBQUEsS0FBQSxHQUFJLENBQUMsQ0FBQztNQUMvQyxPQUFPRCxHQUFHLENBQUNxQixFQUFFLENBQUM7UUFBRWQsSUFBSSxFQUFFO1VBQUVhLElBQUksR0FBQWpCLFVBQUEsR0FBRWlCLElBQUksQ0FBQ0EsSUFBSSxjQUFBakIsVUFBQSxjQUFBQSxVQUFBLEdBQUksRUFBRTtVQUFFbUIsS0FBSyxFQUFFRixJQUFJLENBQUNFO1FBQU07TUFBRSxDQUFDLENBQUM7SUFDdkUsQ0FBQyxDQUFDLE9BQU9DLEdBQVEsRUFBRTtNQUFBLElBQUFDLGVBQUEsRUFBQUMsWUFBQTtNQUNqQixPQUFPekIsR0FBRyxDQUFDMEIsV0FBVyxDQUFDO1FBQ3JCQyxVQUFVLEdBQUFILGVBQUEsR0FBRUQsR0FBRyxDQUFDSSxVQUFVLGNBQUFILGVBQUEsY0FBQUEsZUFBQSxHQUFJLEdBQUc7UUFDakNqQixJQUFJLEdBQUFrQixZQUFBLEdBQUVGLEdBQUcsQ0FBQ0ssT0FBTyxjQUFBSCxZQUFBLGNBQUFBLFlBQUEsR0FBSUksTUFBTSxDQUFDTixHQUFHO01BQ2pDLENBQUMsQ0FBQztJQUNKO0VBQ0YsQ0FDRixDQUFDOztFQUVEO0VBQ0F2QyxNQUFNLENBQUNDLEdBQUcsQ0FDUjtJQUNFQyxJQUFJLEVBQUUsMEJBQTBCO0lBQ2hDQyxRQUFRLEVBQUU7TUFDUkMsS0FBSyxFQUFFQyxvQkFBTSxDQUFDQyxNQUFNLENBQUM7UUFDbkJDLElBQUksRUFBRUYsb0JBQU0sQ0FBQ0csS0FBSyxDQUFDSCxvQkFBTSxDQUFDSSxNQUFNLENBQUMsQ0FBQztNQUNwQyxDQUFDO0lBQ0g7RUFDRixDQUFDLEVBQ0QsT0FBT2YsT0FBTyxFQUFFcUIsR0FBRyxFQUFFQyxHQUFHLEtBQUs7SUFDM0IsSUFBSTtNQUFBLElBQUE4QixlQUFBLEVBQUFDLHFCQUFBLEVBQUFDLGVBQUEsRUFBQUMsYUFBQTtNQUNGLE1BQU1wRCxNQUFNLEdBQUdKLFNBQVMsQ0FBQ0MsT0FBTyxDQUFDO01BQ2pDLE1BQU1hLElBQUksSUFBQXVDLGVBQUEsR0FBRy9CLEdBQUcsQ0FBQ1gsS0FBSyxDQUFDRyxJQUFJLGNBQUF1QyxlQUFBLGNBQUFBLGVBQUEsR0FBSSxHQUFHO01BQ2xDLE1BQU12QixJQUFJLEdBQUc7UUFDWGhCLElBQUksRUFBRSxDQUFDO1FBQ1AyQyxJQUFJLEVBQUU7VUFDSkMsT0FBTyxFQUFFO1lBQ1BDLEtBQUssRUFBRTtjQUFFQyxLQUFLLEVBQUUscUJBQXFCO2NBQUU5QyxJQUFJLEVBQUUsR0FBRztjQUFFK0MsT0FBTyxFQUFFO1lBQUksQ0FBQztZQUNoRUosSUFBSSxFQUFFO2NBQ0pLLE9BQU8sRUFBRTtnQkFDUEMsUUFBUSxFQUFFO2tCQUFFakQsSUFBSSxFQUFFLEVBQUU7a0JBQUVrRCxPQUFPLEVBQUUsQ0FBQyxhQUFhLEVBQUUsa0JBQWtCLEVBQUUsa0JBQWtCLEVBQUUsY0FBYztnQkFBRTtjQUN6RztZQUNGO1VBQ0Y7UUFDRjtNQUNGLENBQUM7TUFDRCxNQUFNMUIsUUFBUSxHQUFHLE1BQU1sQyxNQUFNLENBQUNtQyxNQUFNLENBQUM7UUFDbkNDLEtBQUssRUFBRUMsK0JBQW9CO1FBQzNCQyxrQkFBa0IsRUFBRSxJQUFJO1FBQ3hCWjtNQUNGLENBQUMsQ0FBQztNQUNGLE1BQU0yQixJQUFJLElBQUFILHFCQUFBLElBQUFDLGVBQUEsR0FBSWpCLFFBQVEsQ0FBQ1IsSUFBSSxjQUFBeUIsZUFBQSxnQkFBQUEsZUFBQSxHQUFkQSxlQUFBLENBQXdCVSxZQUFZLGNBQUFWLGVBQUEsdUJBQXBDQSxlQUFBLENBQXNDRyxPQUFPLGNBQUFKLHFCQUFBLGNBQUFBLHFCQUFBLEdBQUksQ0FBQyxDQUFDO01BQ2hFLE1BQU1ZLE9BQU8sSUFBQVYsYUFBQSxHQUFHQyxJQUFJLENBQUNTLE9BQU8sY0FBQVYsYUFBQSxjQUFBQSxhQUFBLEdBQUksRUFBRTtNQUNsQyxPQUFPakMsR0FBRyxDQUFDcUIsRUFBRSxDQUFDO1FBQUVkLElBQUksRUFBRTtVQUFFcUMsS0FBSyxFQUFFRCxPQUFPO1VBQUVwRDtRQUFLO01BQUUsQ0FBQyxDQUFDO0lBQ25ELENBQUMsQ0FBQyxPQUFPZ0MsR0FBUSxFQUFFO01BQUEsSUFBQXNCLGdCQUFBLEVBQUFDLGFBQUE7TUFDakIsT0FBTzlDLEdBQUcsQ0FBQzBCLFdBQVcsQ0FBQztRQUNyQkMsVUFBVSxHQUFBa0IsZ0JBQUEsR0FBRXRCLEdBQUcsQ0FBQ0ksVUFBVSxjQUFBa0IsZ0JBQUEsY0FBQUEsZ0JBQUEsR0FBSSxHQUFHO1FBQ2pDdEMsSUFBSSxHQUFBdUMsYUFBQSxHQUFFdkIsR0FBRyxDQUFDSyxPQUFPLGNBQUFrQixhQUFBLGNBQUFBLGFBQUEsR0FBSWpCLE1BQU0sQ0FBQ04sR0FBRztNQUNqQyxDQUFDLENBQUM7SUFDSjtFQUNGLENBQ0YsQ0FBQzs7RUFFRDtFQUNBdkMsTUFBTSxDQUFDQyxHQUFHLENBQ1I7SUFDRUMsSUFBSSxFQUFFLCtCQUErQjtJQUNyQ0MsUUFBUSxFQUFFO0VBQ1osQ0FBQyxFQUNELE9BQU9ULE9BQU8sRUFBRXFCLEdBQUcsRUFBRUMsR0FBRyxLQUFLO0lBQzNCLElBQUk7TUFBQSxJQUFBK0MsYUFBQSxFQUFBQyxlQUFBLEVBQUFDLHFCQUFBLEVBQUFDLG1CQUFBLEVBQUFDLG1CQUFBLEVBQUFDLFdBQUE7TUFDRixNQUFNdkUsTUFBTSxHQUFHSixTQUFTLENBQUNDLE9BQU8sQ0FBQztNQUNqQyxNQUFNNkIsSUFBSSxHQUFHO1FBQ1hoQixJQUFJLEVBQUUsQ0FBQztRQUNQMkMsSUFBSSxFQUFFO1VBQ0ptQixhQUFhLEVBQUU7WUFDYmpCLEtBQUssRUFBRTtjQUFFQyxLQUFLLEVBQUUsa0JBQWtCO2NBQUU5QyxJQUFJLEVBQUU7WUFBRztVQUMvQyxDQUFDO1VBQ0QrRCxLQUFLLEVBQUU7WUFDTGxCLEtBQUssRUFBRTtjQUFFQyxLQUFLLEVBQUUsa0JBQWtCO2NBQUU5QyxJQUFJLEVBQUU7WUFBRztVQUMvQztRQUNGO01BQ0YsQ0FBQztNQUNELE1BQU13QixRQUFRLEdBQUcsTUFBTWxDLE1BQU0sQ0FBQ21DLE1BQU0sQ0FBQztRQUNuQ0MsS0FBSyxFQUFFQywrQkFBb0I7UUFDM0JDLGtCQUFrQixFQUFFLElBQUk7UUFDeEJaO01BQ0YsQ0FBQyxDQUFDO01BQ0YsTUFBTTJCLElBQUksSUFBQWEsYUFBQSxJQUFBQyxlQUFBLEdBQUlqQyxRQUFRLENBQUNSLElBQUksY0FBQXlDLGVBQUEsdUJBQWRBLGVBQUEsQ0FBd0JOLFlBQVksY0FBQUssYUFBQSxjQUFBQSxhQUFBLEdBQUksQ0FBQyxDQUFDO01BQ3ZELE9BQU8vQyxHQUFHLENBQUNxQixFQUFFLENBQUM7UUFDWmQsSUFBSSxFQUFFO1VBQ0o4QyxhQUFhLEdBQUFKLHFCQUFBLElBQUFDLG1CQUFBLEdBQUVoQixJQUFJLENBQUNtQixhQUFhLGNBQUFILG1CQUFBLHVCQUFsQkEsbUJBQUEsQ0FBb0JQLE9BQU8sY0FBQU0scUJBQUEsY0FBQUEscUJBQUEsR0FBSSxFQUFFO1VBQ2hESyxLQUFLLEdBQUFILG1CQUFBLElBQUFDLFdBQUEsR0FBRWxCLElBQUksQ0FBQ29CLEtBQUssY0FBQUYsV0FBQSx1QkFBVkEsV0FBQSxDQUFZVCxPQUFPLGNBQUFRLG1CQUFBLGNBQUFBLG1CQUFBLEdBQUk7UUFDaEM7TUFDRixDQUFDLENBQUM7SUFDSixDQUFDLENBQUMsT0FBTzVCLEdBQVEsRUFBRTtNQUFBLElBQUFnQyxnQkFBQSxFQUFBQyxhQUFBO01BQ2pCLE9BQU94RCxHQUFHLENBQUMwQixXQUFXLENBQUM7UUFDckJDLFVBQVUsR0FBQTRCLGdCQUFBLEdBQUVoQyxHQUFHLENBQUNJLFVBQVUsY0FBQTRCLGdCQUFBLGNBQUFBLGdCQUFBLEdBQUksR0FBRztRQUNqQ2hELElBQUksR0FBQWlELGFBQUEsR0FBRWpDLEdBQUcsQ0FBQ0ssT0FBTyxjQUFBNEIsYUFBQSxjQUFBQSxhQUFBLEdBQUkzQixNQUFNLENBQUNOLEdBQUc7TUFDakMsQ0FBQyxDQUFDO0lBQ0o7RUFDRixDQUNGLENBQUM7O0VBRUQ7RUFDQXZDLE1BQU0sQ0FBQ0MsR0FBRyxDQUNSO0lBQ0VDLElBQUksRUFBRSw2QkFBNkI7SUFDbkNDLFFBQVEsRUFBRTtFQUNaLENBQUMsRUFDRCxPQUFPVCxPQUFPLEVBQUVxQixHQUFHLEVBQUVDLEdBQUcsS0FBSztJQUMzQixJQUFJO01BQUEsSUFBQXlELE1BQUEsRUFBQUMsZ0JBQUEsRUFBQUMsY0FBQSxFQUFBQyxpQkFBQSxFQUFBQyxpQkFBQSxFQUFBQyxxQkFBQSxFQUFBQyxzQkFBQSxFQUFBQyxxQkFBQSxFQUFBQyxrQkFBQTtNQUNGLE1BQU1wRixNQUFNLEdBQUdKLFNBQVMsQ0FBQ0MsT0FBTyxDQUFDO01BRWpDLE1BQU13RixVQUFVLEdBQUcsTUFBTXJGLE1BQU0sQ0FBQ21DLE1BQU0sQ0FBQztRQUNyQ0MsS0FBSyxFQUFFQywrQkFBb0I7UUFDM0JDLGtCQUFrQixFQUFFLElBQUk7UUFDeEJaLElBQUksRUFBRTtVQUNKaEIsSUFBSSxFQUFFLENBQUM7VUFDUGlCLElBQUksRUFBRSxDQUNKO1lBQUVDLFlBQVksRUFBRTtjQUFFQyxLQUFLLEVBQUUsTUFBTTtjQUFFNEIsT0FBTyxFQUFFO1lBQVE7VUFBRSxDQUFDLEVBQ3JEO1lBQUUzQixXQUFXLEVBQUU7VUFBTSxDQUFDLENBQ3ZCO1VBQ0R2QixLQUFLLEVBQUU7WUFBRTBCLFNBQVMsRUFBRSxDQUFDO1VBQUUsQ0FBQztVQUN4Qm9CLElBQUksRUFBRTtZQUNKbUIsYUFBYSxFQUFFO2NBQUVqQixLQUFLLEVBQUU7Z0JBQUVDLEtBQUssRUFBRSxrQkFBa0I7Z0JBQUU5QyxJQUFJLEVBQUU7Y0FBRztZQUFFLENBQUM7WUFDakUrRCxLQUFLLEVBQUU7Y0FBRWxCLEtBQUssRUFBRTtnQkFBRUMsS0FBSyxFQUFFLGtCQUFrQjtnQkFBRTlDLElBQUksRUFBRTtjQUFHO1lBQUU7VUFDMUQ7UUFDRjtNQUNGLENBQUMsQ0FBQztNQUVGLElBQUk0RSxRQUFlLEdBQUcsRUFBRTtNQUN4QixJQUFJO1FBQUEsSUFBQUMscUJBQUEsRUFBQUMsY0FBQTtRQUNGLE1BQU1DLFFBQVEsR0FBRyxNQUFNekYsTUFBTSxDQUFDbUMsTUFBTSxDQUFDO1VBQ25DQyxLQUFLLEVBQUVDLCtCQUFvQjtVQUMzQkMsa0JBQWtCLEVBQUUsSUFBSTtVQUN4QlosSUFBSSxFQUFFO1lBQ0poQixJQUFJLEVBQUUsQ0FBQztZQUNQMkMsSUFBSSxFQUFFO2NBQ0ppQyxRQUFRLEVBQUU7Z0JBQ1IvQixLQUFLLEVBQUU7a0JBQUVDLEtBQUssRUFBRSwyQkFBMkI7a0JBQUU5QyxJQUFJLEVBQUU7Z0JBQUc7Y0FDeEQ7WUFDRjtVQUNGO1FBQ0YsQ0FBQyxDQUFDO1FBQ0Y0RSxRQUFRLElBQUFDLHFCQUFBLElBQUFDLGNBQUEsR0FBSUMsUUFBUSxDQUFDL0QsSUFBSSxjQUFBOEQsY0FBQSxnQkFBQUEsY0FBQSxHQUFkQSxjQUFBLENBQXdCM0IsWUFBWSxjQUFBMkIsY0FBQSxnQkFBQUEsY0FBQSxHQUFwQ0EsY0FBQSxDQUFzQ0YsUUFBUSxjQUFBRSxjQUFBLHVCQUE5Q0EsY0FBQSxDQUFnRDFCLE9BQU8sY0FBQXlCLHFCQUFBLGNBQUFBLHFCQUFBLEdBQUksRUFBRTtNQUMxRSxDQUFDLENBQUMsTUFBTTtRQUNORCxRQUFRLEdBQUcsRUFBRTtNQUNmO01BRUEsSUFBSUksUUFBZSxHQUFHLEVBQUU7TUFDeEIsSUFBSTtRQUFBLElBQUFDLFdBQUEsRUFBQUMsYUFBQTtRQUNGLE1BQU1DLE9BQU8sR0FBRyxNQUFNN0YsTUFBTSxDQUFDbUMsTUFBTSxDQUFDO1VBQ2xDQyxLQUFLLEVBQUUwRCxxQ0FBMEI7VUFDakN4RCxrQkFBa0IsRUFBRSxJQUFJO1VBQ3hCWixJQUFJLEVBQUU7WUFDSmhCLElBQUksRUFBRSxFQUFFO1lBQ1JpQixJQUFJLEVBQUUsQ0FBQztjQUFFb0UsWUFBWSxFQUFFO2dCQUFFbEUsS0FBSyxFQUFFO2NBQU87WUFBRSxDQUFDLENBQUM7WUFDM0MrQixPQUFPLEVBQUUsQ0FBQyxjQUFjLEVBQUUsY0FBYyxFQUFFLFVBQVUsQ0FBQztZQUNyRHJELEtBQUssRUFBRTtjQUFFMEIsU0FBUyxFQUFFLENBQUM7WUFBRTtVQUN6QjtRQUNGLENBQUMsQ0FBQztRQUNGLE1BQU0rRCxRQUFRLElBQUFMLFdBQUEsSUFBQUMsYUFBQSxHQUFJQyxPQUFPLENBQUNuRSxJQUFJLGNBQUFrRSxhQUFBLGdCQUFBQSxhQUFBLEdBQWJBLGFBQUEsQ0FBdUJyRCxJQUFJLGNBQUFxRCxhQUFBLHVCQUEzQkEsYUFBQSxDQUE2QnJELElBQUksY0FBQW9ELFdBQUEsY0FBQUEsV0FBQSxHQUFJLEVBQUU7UUFDeERELFFBQVEsR0FBR00sUUFBUSxDQUFDQyxHQUFHLENBQUVDLENBQU0sSUFBS0EsQ0FBQyxDQUFDdEMsT0FBTyxDQUFDLENBQUN1QyxNQUFNLENBQUNDLE9BQU8sQ0FBQztNQUNoRSxDQUFDLENBQUMsTUFBTTtRQUNOVixRQUFRLEdBQUcsRUFBRTtNQUNmO01BRUEsTUFBTVcsV0FBVyxJQUFBekIsTUFBQSxJQUFBQyxnQkFBQSxHQUFJUSxVQUFVLENBQUMzRCxJQUFJLGNBQUFtRCxnQkFBQSx1QkFBaEJBLGdCQUFBLENBQTBCdEMsSUFBSSxjQUFBcUMsTUFBQSxjQUFBQSxNQUFBLEdBQUksQ0FBQyxDQUFDO01BQ3hELE1BQU0wQixXQUFXLElBQUF4QixjQUFBLElBQUFDLGlCQUFBLEdBQUlNLFVBQVUsQ0FBQzNELElBQUksY0FBQXFELGlCQUFBLHVCQUFoQkEsaUJBQUEsQ0FBMEJsQixZQUFZLGNBQUFpQixjQUFBLGNBQUFBLGNBQUEsR0FBSSxDQUFDLENBQUM7TUFDaEUsTUFBTXlCLGNBQWMsR0FBRyxFQUFBdkIsaUJBQUEsR0FBQ3FCLFdBQVcsQ0FBQzlELElBQUksY0FBQXlDLGlCQUFBLGNBQUFBLGlCQUFBLEdBQUksRUFBRSxFQUFFaUIsR0FBRyxDQUFFQyxDQUFNLElBQUtBLENBQUMsQ0FBQ3RDLE9BQU8sQ0FBQyxDQUFDdUMsTUFBTSxDQUFDQyxPQUFPLENBQUM7TUFFMUYsSUFBSUksaUJBQWlCLEdBQUcsQ0FBQztNQUN6QixJQUFJQyx5QkFBeUIsR0FBRyxDQUFDO01BQ2pDLElBQUlDLGlCQUF3QixHQUFHLEVBQUU7TUFDakMsSUFBSUMsZ0JBQWdCLEdBQUcsQ0FBQztNQUN4QixJQUFJQyxhQUFhLEdBQUcsQ0FBQztNQUNyQixJQUFJQyxtQkFBbUIsR0FBRyxDQUFDO01BQzNCLElBQUlDLG1CQUFtQixHQUFHLENBQUM7TUFDM0IsSUFBSTtRQUFBLElBQUFDLE1BQUEsRUFBQUMsa0JBQUEsRUFBQUMsT0FBQSxFQUFBQyxxQkFBQSxFQUFBQyxXQUFBLEVBQUFDLHFCQUFBLEVBQUFDLE9BQUEsRUFBQUMsZUFBQSxFQUFBQyxPQUFBLEVBQUFDLGdCQUFBLEVBQUFDLE9BQUEsRUFBQUMsaUJBQUEsRUFBQUMsT0FBQSxFQUFBQyxjQUFBO1FBQ0YsTUFBTUMsU0FBUyxHQUFHLElBQUlDLElBQUksQ0FBQ0EsSUFBSSxDQUFDQyxHQUFHLENBQUMsQ0FBQyxHQUFHLENBQUMsR0FBRyxFQUFFLEdBQUcsRUFBRSxHQUFHLEVBQUUsR0FBRyxJQUFJLENBQUMsQ0FBQ0MsV0FBVyxDQUFDLENBQUM7UUFDOUUsTUFBTSxDQUNKQyxZQUFZLEVBQUVDLGdCQUFnQixFQUFFQyxlQUFlLEVBQy9DQyxTQUFTLEVBQUVDLFVBQVUsRUFBRUMsV0FBVyxFQUFFQyxRQUFRLENBQzdDLEdBQUcsTUFBTUMsT0FBTyxDQUFDQyxHQUFHLENBQUMsQ0FDcEJ6SSxNQUFNLENBQUMwSSxLQUFLLENBQUM7VUFBRXRHLEtBQUssRUFBRXVHLG1DQUF3QjtVQUFFckcsa0JBQWtCLEVBQUU7UUFBSyxDQUFDLENBQUMsRUFDM0V0QyxNQUFNLENBQUMwSSxLQUFLLENBQUM7VUFBRXRHLEtBQUssRUFBRXdHLDJDQUFnQztVQUFFdEcsa0JBQWtCLEVBQUU7UUFBSyxDQUFDLENBQUMsRUFDbkZ0QyxNQUFNLENBQUNtQyxNQUFNLENBQUM7VUFDWkMsS0FBSyxFQUFFQywrQkFBb0I7VUFDM0JDLGtCQUFrQixFQUFFLElBQUk7VUFDeEJaLElBQUksRUFBRTtZQUNKaEIsSUFBSSxFQUFFLENBQUM7WUFDUGlCLElBQUksRUFBRSxDQUFDO2NBQUVDLFlBQVksRUFBRTtnQkFBRUMsS0FBSyxFQUFFLE1BQU07Z0JBQUU0QixPQUFPLEVBQUU7Y0FBUTtZQUFFLENBQUMsQ0FBQztZQUM3RGxELEtBQUssRUFBRTtjQUFFa0IsSUFBSSxFQUFFO2dCQUFFWCxnQkFBZ0IsRUFBRTtjQUFlO1lBQUUsQ0FBQztZQUNyRDhDLE9BQU8sRUFBRSxDQUFDLGFBQWEsRUFBRSxxQkFBcUIsRUFBRSxrQkFBa0IsRUFBRSxrQkFBa0IsRUFBRSxjQUFjO1VBQ3hHO1FBQ0YsQ0FBQyxDQUFDLEVBQ0Y1RCxNQUFNLENBQUMwSSxLQUFLLENBQUM7VUFBRXRHLEtBQUssRUFBRXlHLGtDQUF1QjtVQUFFdkcsa0JBQWtCLEVBQUU7UUFBSyxDQUFDLENBQUMsQ0FBQ3dHLEtBQUssQ0FBQyxPQUFPO1VBQUVwSCxJQUFJLEVBQUU7WUFBRWdILEtBQUssRUFBRTtVQUFFO1FBQUUsQ0FBQyxDQUFDLENBQUMsRUFDaEgxSSxNQUFNLENBQUMwSSxLQUFLLENBQUM7VUFBRXRHLEtBQUssRUFBRTJHLCtCQUFvQjtVQUFFekcsa0JBQWtCLEVBQUU7UUFBSyxDQUFDLENBQUMsQ0FBQ3dHLEtBQUssQ0FBQyxPQUFPO1VBQUVwSCxJQUFJLEVBQUU7WUFBRWdILEtBQUssRUFBRTtVQUFFO1FBQUUsQ0FBQyxDQUFDLENBQUMsRUFDN0cxSSxNQUFNLENBQUMwSSxLQUFLLENBQUM7VUFBRXRHLEtBQUssRUFBRTRHLHVDQUE0QjtVQUFFMUcsa0JBQWtCLEVBQUU7UUFBSyxDQUFDLENBQUMsQ0FBQ3dHLEtBQUssQ0FBQyxPQUFPO1VBQUVwSCxJQUFJLEVBQUU7WUFBRWdILEtBQUssRUFBRTtVQUFFO1FBQUUsQ0FBQyxDQUFDLENBQUMsRUFDckgxSSxNQUFNLENBQUMwSSxLQUFLLENBQUM7VUFDWHRHLEtBQUssRUFBRUMsK0JBQW9CO1VBQzNCQyxrQkFBa0IsRUFBRSxJQUFJO1VBQ3hCWixJQUFJLEVBQUU7WUFBRW5CLEtBQUssRUFBRTtjQUFFMEksS0FBSyxFQUFFO2dCQUFFckgsWUFBWSxFQUFFO2tCQUFFc0gsRUFBRSxFQUFFckI7Z0JBQVU7Y0FBRTtZQUFFO1VBQUU7UUFDaEUsQ0FBQyxDQUFDLENBQUNpQixLQUFLLENBQUMsT0FBTztVQUFFcEgsSUFBSSxFQUFFO1lBQUVnSCxLQUFLLEVBQUU7VUFBRTtRQUFFLENBQUMsQ0FBQyxDQUFDLENBQ3pDLENBQUM7UUFDRmxDLGlCQUFpQixJQUFBTyxNQUFBLElBQUFDLGtCQUFBLEdBQUlpQixZQUFZLENBQUN2RyxJQUFJLGNBQUFzRixrQkFBQSx1QkFBbEJBLGtCQUFBLENBQTRCMEIsS0FBSyxjQUFBM0IsTUFBQSxjQUFBQSxNQUFBLEdBQUksQ0FBQztRQUMxRE4seUJBQXlCLElBQUFRLE9BQUEsSUFBQUMscUJBQUEsR0FBSWdCLGdCQUFnQixDQUFDeEcsSUFBSSxjQUFBd0YscUJBQUEsdUJBQXRCQSxxQkFBQSxDQUFnQ3dCLEtBQUssY0FBQXpCLE9BQUEsY0FBQUEsT0FBQSxHQUFJLENBQUM7UUFDdEUsTUFBTWtDLE1BQU0sSUFBQWhDLFdBQUEsSUFBQUMscUJBQUEsR0FBSWUsZUFBZSxDQUFDekcsSUFBSSxjQUFBMEYscUJBQUEsZ0JBQUFBLHFCQUFBLEdBQXJCQSxxQkFBQSxDQUErQjdFLElBQUksY0FBQTZFLHFCQUFBLHVCQUFuQ0EscUJBQUEsQ0FBcUM3RSxJQUFJLGNBQUE0RSxXQUFBLGNBQUFBLFdBQUEsR0FBSSxFQUFFO1FBQzlEVCxpQkFBaUIsR0FBR3lDLE1BQU0sQ0FBQ2xELEdBQUcsQ0FBRUMsQ0FBTSxJQUFLQSxDQUFDLENBQUN0QyxPQUFPLENBQUMsQ0FBQ3VDLE1BQU0sQ0FBQ0MsT0FBTyxDQUFDO1FBQ3JFTyxnQkFBZ0IsSUFBQVUsT0FBQSxJQUFBQyxlQUFBLEdBQUljLFNBQVMsQ0FBQzFHLElBQUksY0FBQTRGLGVBQUEsdUJBQWZBLGVBQUEsQ0FBeUJvQixLQUFLLGNBQUFyQixPQUFBLGNBQUFBLE9BQUEsR0FBSSxDQUFDO1FBQ3REVCxhQUFhLElBQUFXLE9BQUEsSUFBQUMsZ0JBQUEsR0FBSWEsVUFBVSxDQUFDM0csSUFBSSxjQUFBOEYsZ0JBQUEsdUJBQWhCQSxnQkFBQSxDQUEwQmtCLEtBQUssY0FBQW5CLE9BQUEsY0FBQUEsT0FBQSxHQUFJLENBQUM7UUFDcERWLG1CQUFtQixJQUFBWSxPQUFBLElBQUFDLGlCQUFBLEdBQUlZLFdBQVcsQ0FBQzVHLElBQUksY0FBQWdHLGlCQUFBLHVCQUFqQkEsaUJBQUEsQ0FBMkJnQixLQUFLLGNBQUFqQixPQUFBLGNBQUFBLE9BQUEsR0FBSSxDQUFDO1FBQzNEWCxtQkFBbUIsSUFBQWEsT0FBQSxJQUFBQyxjQUFBLEdBQUlXLFFBQVEsQ0FBQzdHLElBQUksY0FBQWtHLGNBQUEsdUJBQWRBLGNBQUEsQ0FBd0JjLEtBQUssY0FBQWYsT0FBQSxjQUFBQSxPQUFBLEdBQUksQ0FBQztNQUMxRCxDQUFDLENBQUMsTUFBTTtRQUNOO01BQUE7TUFHRixPQUFPeEcsR0FBRyxDQUFDcUIsRUFBRSxDQUFDO1FBQ1pkLElBQUksRUFBRTtVQUNKOEMsYUFBYSxHQUFBUyxxQkFBQSxJQUFBQyxzQkFBQSxHQUFFb0IsV0FBVyxDQUFDOUIsYUFBYSxjQUFBVSxzQkFBQSx1QkFBekJBLHNCQUFBLENBQTJCcEIsT0FBTyxjQUFBbUIscUJBQUEsY0FBQUEscUJBQUEsR0FBSSxFQUFFO1VBQ3ZEUixLQUFLLEdBQUFVLHFCQUFBLElBQUFDLGtCQUFBLEdBQUVrQixXQUFXLENBQUM3QixLQUFLLGNBQUFXLGtCQUFBLHVCQUFqQkEsa0JBQUEsQ0FBbUJ0QixPQUFPLGNBQUFxQixxQkFBQSxjQUFBQSxxQkFBQSxHQUFJLEVBQUU7VUFDdkNHLFFBQVE7VUFDUkksUUFBUTtVQUNSYSxjQUFjO1VBQ2RDLGlCQUFpQjtVQUNqQkMseUJBQXlCO1VBQ3pCMkMseUJBQXlCLEVBQUUxQyxpQkFBaUI7VUFDNUNDLGdCQUFnQjtVQUNoQkMsYUFBYTtVQUNiQyxtQkFBbUI7VUFDbkJDO1FBQ0Y7TUFDRixDQUFDLENBQUM7SUFDSixDQUFDLENBQUMsT0FBT3BFLEdBQVEsRUFBRTtNQUFBLElBQUEyRyxnQkFBQSxFQUFBQyxhQUFBO01BQ2pCLE9BQU9uSSxHQUFHLENBQUMwQixXQUFXLENBQUM7UUFDckJDLFVBQVUsR0FBQXVHLGdCQUFBLEdBQUUzRyxHQUFHLENBQUNJLFVBQVUsY0FBQXVHLGdCQUFBLGNBQUFBLGdCQUFBLEdBQUksR0FBRztRQUNqQzNILElBQUksR0FBQTRILGFBQUEsR0FBRTVHLEdBQUcsQ0FBQ0ssT0FBTyxjQUFBdUcsYUFBQSxjQUFBQSxhQUFBLEdBQUl0RyxNQUFNLENBQUNOLEdBQUc7TUFDakMsQ0FBQyxDQUFDO0lBQ0o7RUFDRixDQUNGLENBQUM7O0VBRUQ7RUFDQTtFQUNBdkMsTUFBTSxDQUFDb0osSUFBSSxDQUNUO0lBQ0VsSixJQUFJLEVBQUUsc0NBQXNDO0lBQzVDQyxRQUFRLEVBQUU7TUFDUm9CLElBQUksRUFBRWxCLG9CQUFNLENBQUNDLE1BQU0sQ0FBQztRQUNsQkMsSUFBSSxFQUFFRixvQkFBTSxDQUFDRyxLQUFLLENBQUNILG9CQUFNLENBQUNJLE1BQU0sQ0FBQyxDQUFDLENBQUM7UUFDbkNDLElBQUksRUFBRUwsb0JBQU0sQ0FBQ0csS0FBSyxDQUFDSCxvQkFBTSxDQUFDSSxNQUFNLENBQUMsQ0FBQyxDQUFDO1FBQ25DNEksU0FBUyxFQUFFaEosb0JBQU0sQ0FBQ0csS0FBSyxDQUFDSCxvQkFBTSxDQUFDTyxNQUFNLENBQUMsQ0FBQyxDQUFDO1FBQ3hDMEksT0FBTyxFQUFFakosb0JBQU0sQ0FBQ0csS0FBSyxDQUFDSCxvQkFBTSxDQUFDTyxNQUFNLENBQUMsQ0FBQyxDQUFDO1FBQ3RDMkksc0JBQXNCLEVBQUVsSixvQkFBTSxDQUFDRyxLQUFLLENBQUNILG9CQUFNLENBQUNtSixPQUFPLENBQUMsQ0FBQztNQUN2RCxDQUFDO0lBQ0g7RUFDRixDQUFDLEVBQ0QsT0FBTzlKLE9BQU8sRUFBRXFCLEdBQUcsRUFBRUMsR0FBRyxLQUFLO0lBQzNCLElBQUk7TUFBQSxJQUFBeUksV0FBQSxFQUFBQyxvQkFBQSxFQUFBQyxJQUFBLEVBQUFDLGlCQUFBLEVBQUFDLG1CQUFBLEVBQUFDLG9CQUFBO01BQ0YsTUFBTWpLLE1BQU0sR0FBR0osU0FBUyxDQUFDQyxPQUFPLENBQUM7TUFDakMsTUFBTTtRQUNKYSxJQUFJLEdBQUcsRUFBRTtRQUNURyxJQUFJLEdBQUcsQ0FBQztRQUNSMkksU0FBUztRQUNUQyxPQUFPO1FBQ1BDLHNCQUFzQixHQUFHO01BQzNCLENBQUMsR0FBR3hJLEdBQUcsQ0FBQ1EsSUFBSTs7TUFFWjtNQUNBLE1BQU1xRyxHQUFHLEdBQUcsSUFBSUQsSUFBSSxDQUFDLENBQUM7TUFDdEIsTUFBTW9DLFNBQVMsR0FBR25DLEdBQUcsQ0FBQ0MsV0FBVyxDQUFDLENBQUM7TUFDbkMsTUFBTW1DLFdBQVcsR0FBRyxJQUFJckMsSUFBSSxDQUFDQyxHQUFHLENBQUNxQyxPQUFPLENBQUMsQ0FBQyxHQUFHLENBQUMsR0FBRyxFQUFFLEdBQUcsRUFBRSxHQUFHLEVBQUUsR0FBRyxJQUFJLENBQUMsQ0FBQ3BDLFdBQVcsQ0FBQyxDQUFDO01BQ25GLE1BQU1xQyxPQUFPLEdBQUdiLFNBQVMsSUFBSVcsV0FBVztNQUN4QyxNQUFNRyxPQUFPLEdBQUdiLE9BQU8sSUFBSVMsU0FBUztNQUNwQyxNQUFNSyxlQUFlLEdBQUc7UUFBRXRCLEtBQUssRUFBRTtVQUFFdUIsU0FBUyxFQUFFO1lBQUVDLEdBQUcsRUFBRUosT0FBTztZQUFFSyxHQUFHLEVBQUVKO1VBQVE7UUFBRTtNQUFFLENBQUM7TUFFaEYsSUFBSUssZUFBZ0MsR0FBRyxJQUFJO01BQzNDLElBQUlDLGVBQXVDLEdBQUcsQ0FBQyxDQUFDO01BQ2hELElBQUlDLFVBQStCLEdBQUcsQ0FBQyxDQUFDO01BRXhDLElBQUluQixzQkFBc0IsRUFBRTtRQUFBLElBQUFvQixXQUFBLEVBQUFDLGtCQUFBO1FBQzFCO1FBQ0EsTUFBTXpDLFdBQVcsR0FBRyxNQUFNdEksTUFBTSxDQUFDbUMsTUFBTSxDQUFDO1VBQ3RDQyxLQUFLLEVBQUU0Ryx1Q0FBNEI7VUFDbkMxRyxrQkFBa0IsRUFBRSxJQUFJO1VBQ3hCWixJQUFJLEVBQUU7WUFDSmhCLElBQUksRUFBRSxJQUFJO1lBQ1ZrRCxPQUFPLEVBQUUsQ0FBQyxnQkFBZ0IsRUFBRSxrQkFBa0IsQ0FBQztZQUMvQ3JELEtBQUssRUFBRTtjQUFFMEIsU0FBUyxFQUFFLENBQUM7WUFBRTtVQUN6QjtRQUNGLENBQUMsQ0FBQztRQUNGLE1BQU0rSSxZQUFZLElBQUFGLFdBQUEsSUFBQUMsa0JBQUEsR0FBSXpDLFdBQVcsQ0FBQzVHLElBQUksY0FBQXFKLGtCQUFBLGdCQUFBQSxrQkFBQSxHQUFqQkEsa0JBQUEsQ0FBMkJ4SSxJQUFJLGNBQUF3SSxrQkFBQSx1QkFBL0JBLGtCQUFBLENBQWlDeEksSUFBSSxjQUFBdUksV0FBQSxjQUFBQSxXQUFBLEdBQUksRUFBRTtRQUNoRUgsZUFBZSxHQUFHSyxZQUFZLENBQzNCL0UsR0FBRyxDQUFFQyxDQUFNO1VBQUEsSUFBQStFLFVBQUE7VUFBQSxRQUFBQSxVQUFBLEdBQUsvRSxDQUFDLENBQUN0QyxPQUFPLGNBQUFxSCxVQUFBLHVCQUFUQSxVQUFBLENBQVdDLGNBQWM7UUFBQSxFQUFDLENBQzFDL0UsTUFBTSxDQUFFZ0YsRUFBVSxJQUFLQSxFQUFFLElBQUlBLEVBQUUsS0FBSyxLQUFLLENBQUM7UUFDN0MsSUFBSVIsZUFBZSxDQUFDNUksTUFBTSxLQUFLLENBQUMsRUFBRTtVQUNoQyxPQUFPWixHQUFHLENBQUNxQixFQUFFLENBQUM7WUFDWmQsSUFBSSxFQUFFO2NBQ0owSixNQUFNLEVBQUUsRUFBRTtjQUNWQyxXQUFXLEVBQUUsQ0FBQyxDQUFDO2NBQ2Y1SSxLQUFLLEVBQUUsQ0FBQztjQUNSNkksY0FBYyxFQUFFO1lBQ2xCO1VBQ0YsQ0FBQyxDQUFDO1FBQ0o7UUFDQU4sWUFBWSxDQUFDTyxPQUFPLENBQUVyRixDQUFNLElBQUs7VUFDL0IsTUFBTXNGLENBQUMsR0FBR3RGLENBQUMsQ0FBQ3RDLE9BQU87VUFDbkIsSUFBSTRILENBQUMsYUFBREEsQ0FBQyxlQUFEQSxDQUFDLENBQUVOLGNBQWMsRUFBRU4sZUFBZSxDQUFDWSxDQUFDLENBQUNOLGNBQWMsQ0FBQyxHQUFHTSxDQUFDLENBQUNDLGdCQUFnQjtRQUMvRSxDQUFDLENBQUM7TUFDSjs7TUFFQTtNQUNBO01BQ0EsTUFBTWxLLElBQVcsR0FBRyxDQUFDZ0osZUFBZSxDQUFDO01BQ3JDaEosSUFBSSxDQUFDQyxJQUFJLENBQUM7UUFBRVEsSUFBSSxFQUFFO1VBQUUwSixRQUFRLEVBQUUsQ0FBQztZQUFFakssSUFBSSxFQUFFO2NBQUUsVUFBVSxFQUFFO1lBQU07VUFBRSxDQUFDO1FBQUU7TUFBRSxDQUFDLENBQUM7TUFDcEUsSUFBSWtKLGVBQWUsSUFBSUEsZUFBZSxDQUFDNUksTUFBTSxHQUFHLENBQUMsRUFBRTtRQUNqRFIsSUFBSSxDQUFDQyxJQUFJLENBQUM7VUFBRStCLEtBQUssRUFBRTtZQUFFLFVBQVUsRUFBRW9IO1VBQWdCO1FBQUUsQ0FBQyxDQUFDO01BQ3ZEO01BRUEsTUFBTWdCLFVBQVUsR0FBRztRQUNqQjlLLElBQUk7UUFDSkgsSUFBSTtRQUNKaUIsSUFBSSxFQUFFLENBQUM7VUFBRTZJLFNBQVMsRUFBRTtZQUFFM0ksS0FBSyxFQUFFO1VBQU87UUFBRSxDQUFDLENBQUM7UUFDeEMrQixPQUFPLEVBQUUsQ0FBQyxVQUFVLEVBQUUsWUFBWSxFQUFFLGtCQUFrQixFQUFFLFlBQVksRUFBRSxXQUFXLENBQUM7UUFDbEZyRCxLQUFLLEVBQUU7VUFBRXlCLElBQUksRUFBRTtZQUFFVDtVQUFLO1FBQUU7TUFDMUIsQ0FBQztNQUVELE1BQU0sQ0FBQ3FLLGNBQWMsRUFBRUMsYUFBYSxDQUFDLEdBQUcsTUFBTXJELE9BQU8sQ0FBQ0MsR0FBRyxDQUFDLENBQ3hEekksTUFBTSxDQUFDbUMsTUFBTSxDQUFDO1FBQ1pDLEtBQUssRUFBRTBKLCtCQUFvQjtRQUMzQnhKLGtCQUFrQixFQUFFLElBQUk7UUFDeEJaLElBQUksRUFBRWlLO01BQ1IsQ0FBQyxDQUFDLEVBQ0YzTCxNQUFNLENBQUNtQyxNQUFNLENBQUM7UUFDWkMsS0FBSyxFQUFFMEosK0JBQW9CO1FBQzNCeEosa0JBQWtCLEVBQUUsSUFBSTtRQUN4QlosSUFBSSxFQUFFO1VBQ0poQixJQUFJLEVBQUUsQ0FBQztVQUNQSCxLQUFLLEVBQUVvTCxVQUFVLENBQUNwTCxLQUFLO1VBQ3ZCd0wsZ0JBQWdCLEVBQUU7UUFDcEI7TUFDRixDQUFDLENBQUMsQ0FDSCxDQUFDO01BRUYsTUFBTUMsU0FBUyxJQUFBcEMsV0FBQSxJQUFBQyxvQkFBQSxHQUFJK0IsY0FBYyxDQUFDbEssSUFBSSxjQUFBbUksb0JBQUEsZ0JBQUFBLG9CQUFBLEdBQXBCQSxvQkFBQSxDQUE4QnRILElBQUksY0FBQXNILG9CQUFBLHVCQUFsQ0Esb0JBQUEsQ0FBb0N0SCxJQUFJLGNBQUFxSCxXQUFBLGNBQUFBLFdBQUEsR0FBSSxFQUFFO01BQ2hFLE1BQU1uSCxLQUFLLElBQUFxSCxJQUFBLElBQUFDLGlCQUFBLElBQUFDLG1CQUFBLEdBQ1I2QixhQUFhLENBQUNuSyxJQUFJLGNBQUFzSSxtQkFBQSxnQkFBQUEsbUJBQUEsR0FBbkJBLG1CQUFBLENBQTZCekgsSUFBSSxjQUFBeUgsbUJBQUEsZ0JBQUFBLG1CQUFBLEdBQWpDQSxtQkFBQSxDQUFtQ3ZILEtBQUssY0FBQXVILG1CQUFBLHVCQUF4Q0EsbUJBQUEsQ0FBMENpQyxLQUFLLGNBQUFsQyxpQkFBQSxjQUFBQSxpQkFBQSxJQUFBRSxvQkFBQSxHQUM5QzRCLGFBQWEsQ0FBQ25LLElBQUksY0FBQXVJLG9CQUFBLGdCQUFBQSxvQkFBQSxHQUFuQkEsb0JBQUEsQ0FBNkIxSCxJQUFJLGNBQUEwSCxvQkFBQSx1QkFBakNBLG9CQUFBLENBQW1DeEgsS0FBSyxjQUFBcUgsSUFBQSxjQUFBQSxJQUFBLEdBQ3hDLENBQUM7TUFFSCxNQUFNb0MsUUFBUSxHQUFHLENBQ2YsR0FBRyxJQUFJQyxHQUFHLENBQUNILFNBQVMsQ0FBQy9GLEdBQUcsQ0FBRUMsQ0FBTTtRQUFBLElBQUFrRyxXQUFBO1FBQUEsUUFBQUEsV0FBQSxHQUFLbEcsQ0FBQyxDQUFDdEMsT0FBTyxjQUFBd0ksV0FBQSx1QkFBVEEsV0FBQSxDQUFZLFVBQVUsQ0FBQztNQUFBLEVBQUMsQ0FBQ2pHLE1BQU0sQ0FBQ0MsT0FBTyxDQUFDLENBQUMsQ0FDL0U7TUFFRCxJQUFJOEYsUUFBUSxDQUFDbkssTUFBTSxHQUFHLENBQUMsRUFBRTtRQUFBLElBQUFzSyxXQUFBLEVBQUFDLG9CQUFBO1FBQ3ZCLE1BQU1DLGNBQWMsR0FBRyxNQUFNdk0sTUFBTSxDQUFDbUMsTUFBTSxDQUFDO1VBQ3pDQyxLQUFLLEVBQUU0Ryx1Q0FBNEI7VUFDbkMxRyxrQkFBa0IsRUFBRSxJQUFJO1VBQ3hCWixJQUFJLEVBQUU7WUFDSmhCLElBQUksRUFBRSxHQUFHO1lBQ1RILEtBQUssRUFBRTtjQUFFZ0QsS0FBSyxFQUFFO2dCQUFFMkgsY0FBYyxFQUFFZ0I7Y0FBUztZQUFFLENBQUM7WUFDOUN0SSxPQUFPLEVBQUUsQ0FBQyxnQkFBZ0IsRUFBRSxrQkFBa0I7VUFDaEQ7UUFDRixDQUFDLENBQUM7UUFDRixNQUFNNEksVUFBVSxJQUFBSCxXQUFBLElBQUFDLG9CQUFBLEdBQUlDLGNBQWMsQ0FBQzdLLElBQUksY0FBQTRLLG9CQUFBLGdCQUFBQSxvQkFBQSxHQUFwQkEsb0JBQUEsQ0FBOEIvSixJQUFJLGNBQUErSixvQkFBQSx1QkFBbENBLG9CQUFBLENBQW9DL0osSUFBSSxjQUFBOEosV0FBQSxjQUFBQSxXQUFBLEdBQUksRUFBRTtRQUNqRUcsVUFBVSxDQUFDakIsT0FBTyxDQUFFckYsQ0FBTSxJQUFLO1VBQzdCLE1BQU1zRixDQUFDLEdBQUd0RixDQUFDLENBQUN0QyxPQUFPO1VBQ25CLElBQUk0SCxDQUFDLGFBQURBLENBQUMsZUFBREEsQ0FBQyxDQUFFTixjQUFjLEVBQ25CTixlQUFlLENBQUNZLENBQUMsQ0FBQ04sY0FBYyxDQUFDLEdBQUdNLENBQUMsQ0FBQ0MsZ0JBQWdCO1FBQzFELENBQUMsQ0FBQztNQUNKO01BRUEsTUFBTWdCLFNBQVMsR0FBRyxDQUFDLEdBQUcsSUFBSU4sR0FBRyxDQUFDTyxNQUFNLENBQUNDLE1BQU0sQ0FBQy9CLGVBQWUsQ0FBQyxDQUFDekUsTUFBTSxDQUFDQyxPQUFPLENBQUMsQ0FBQyxDQUFDO01BQzlFLElBQUlxRyxTQUFTLENBQUMxSyxNQUFNLEdBQUcsQ0FBQyxFQUFFO1FBQUEsSUFBQTZLLFdBQUEsRUFBQUMsWUFBQTtRQUN4QixNQUFNQyxNQUFNLEdBQUcsTUFBTTlNLE1BQU0sQ0FBQ21DLE1BQU0sQ0FBQztVQUNqQ0MsS0FBSyxFQUFFQywrQkFBb0I7VUFDM0JDLGtCQUFrQixFQUFFLElBQUk7VUFDeEJaLElBQUksRUFBRTtZQUNKaEIsSUFBSSxFQUFFK0wsU0FBUyxDQUFDMUssTUFBTTtZQUN0QnhCLEtBQUssRUFBRTtjQUFFZ0QsS0FBSyxFQUFFO2dCQUFFa0ksZ0JBQWdCLEVBQUVnQjtjQUFVO1lBQUUsQ0FBQztZQUNqRDdJLE9BQU8sRUFBRSxDQUFDLGtCQUFrQixFQUFFLGtCQUFrQixFQUFFLGFBQWEsRUFBRSxxQkFBcUI7VUFDeEY7UUFDRixDQUFDLENBQUM7UUFDRixNQUFNbUosT0FBTyxJQUFBSCxXQUFBLElBQUFDLFlBQUEsR0FBSUMsTUFBTSxDQUFDcEwsSUFBSSxjQUFBbUwsWUFBQSxnQkFBQUEsWUFBQSxHQUFaQSxZQUFBLENBQXNCdEssSUFBSSxjQUFBc0ssWUFBQSx1QkFBMUJBLFlBQUEsQ0FBNEJ0SyxJQUFJLGNBQUFxSyxXQUFBLGNBQUFBLFdBQUEsR0FBSSxFQUFFO1FBQ3RERyxPQUFPLENBQUN4QixPQUFPLENBQUVyRixDQUFNLElBQUs7VUFDMUIsTUFBTXNGLENBQUMsR0FBR3RGLENBQUMsQ0FBQ3RDLE9BQU87VUFDbkIsSUFBSTRILENBQUMsYUFBREEsQ0FBQyxlQUFEQSxDQUFDLENBQUVDLGdCQUFnQixFQUFFWixVQUFVLENBQUNXLENBQUMsQ0FBQ0MsZ0JBQWdCLENBQUMsR0FBR0QsQ0FBQztRQUM3RCxDQUFDLENBQUM7TUFDSjtNQUVBLE1BQU1ILFdBQWdDLEdBQUcsQ0FBQyxDQUFDO01BQzNDcUIsTUFBTSxDQUFDTSxPQUFPLENBQUNwQyxlQUFlLENBQUMsQ0FBQ1csT0FBTyxDQUFDLENBQUMsQ0FBQzBCLE9BQU8sRUFBRUMsUUFBUSxDQUFDLEtBQUs7UUFBQSxJQUFBQyxvQkFBQTtRQUMvRDlCLFdBQVcsQ0FBQzRCLE9BQU8sQ0FBQyxJQUFBRSxvQkFBQSxHQUFHdEMsVUFBVSxDQUFDcUMsUUFBUSxDQUFDLGNBQUFDLG9CQUFBLGNBQUFBLG9CQUFBLEdBQUksSUFBSTtNQUNyRCxDQUFDLENBQUM7TUFFRixPQUFPaE0sR0FBRyxDQUFDcUIsRUFBRSxDQUFDO1FBQ1pkLElBQUksRUFBRTtVQUNKMEosTUFBTSxFQUFFWSxTQUFTO1VBQ2pCWCxXQUFXO1VBQ1g1SSxLQUFLO1VBQ0w2SSxjQUFjLEVBQUVvQixNQUFNLENBQUNVLElBQUksQ0FBQ3hDLGVBQWUsQ0FBQyxDQUFDN0k7UUFDL0M7TUFDRixDQUFDLENBQUM7SUFDSixDQUFDLENBQUMsT0FBT1csR0FBUSxFQUFFO01BQUEsSUFBQTJLLGdCQUFBLEVBQUFDLGFBQUE7TUFDakIsT0FBT25NLEdBQUcsQ0FBQzBCLFdBQVcsQ0FBQztRQUNyQkMsVUFBVSxHQUFBdUssZ0JBQUEsR0FBRTNLLEdBQUcsQ0FBQ0ksVUFBVSxjQUFBdUssZ0JBQUEsY0FBQUEsZ0JBQUEsR0FBSSxHQUFHO1FBQ2pDM0wsSUFBSSxHQUFBNEwsYUFBQSxHQUFFNUssR0FBRyxDQUFDSyxPQUFPLGNBQUF1SyxhQUFBLGNBQUFBLGFBQUEsR0FBSXRLLE1BQU0sQ0FBQ04sR0FBRztNQUNqQyxDQUFDLENBQUM7SUFDSjtFQUNGLENBQ0YsQ0FBQzs7RUFFRDtFQUNBdkMsTUFBTSxDQUFDQyxHQUFHLENBQ1I7SUFDRUMsSUFBSSxFQUFFLHdDQUF3QztJQUM5Q0MsUUFBUSxFQUFFO01BQ1JDLEtBQUssRUFBRUMsb0JBQU0sQ0FBQ0MsTUFBTSxDQUFDO1FBQ25CQyxJQUFJLEVBQUVGLG9CQUFNLENBQUNHLEtBQUssQ0FBQ0gsb0JBQU0sQ0FBQ0ksTUFBTSxDQUFDLENBQUM7TUFDcEMsQ0FBQztJQUNIO0VBQ0YsQ0FBQyxFQUNELE9BQU9mLE9BQU8sRUFBRXFCLEdBQUcsRUFBRUMsR0FBRyxLQUFLO0lBQzNCLElBQUk7TUFBQSxJQUFBb00sZ0JBQUEsRUFBQUMsTUFBQSxFQUFBQyxlQUFBLEVBQUFDLFdBQUEsRUFBQUMsV0FBQTtNQUNGLE1BQU0zTixNQUFNLEdBQUdKLFNBQVMsQ0FBQ0MsT0FBTyxDQUFDO01BQ2pDLE1BQU1hLElBQUksSUFBQTZNLGdCQUFBLEdBQUdyTSxHQUFHLENBQUNYLEtBQUssQ0FBQ0csSUFBSSxjQUFBNk0sZ0JBQUEsY0FBQUEsZ0JBQUEsR0FBSSxHQUFHO01BQ2xDLE1BQU03TCxJQUFJLEdBQUc7UUFDWGhCLElBQUk7UUFDSmlCLElBQUksRUFBRSxDQUFDO1VBQUVpTSxrQkFBa0IsRUFBRTtZQUFFL0wsS0FBSyxFQUFFO1VBQU87UUFBRSxDQUFDLENBQUM7UUFDakR0QixLQUFLLEVBQUU7VUFBRTBCLFNBQVMsRUFBRSxDQUFDO1FBQUU7TUFDekIsQ0FBQztNQUNELE1BQU1DLFFBQVEsR0FBRyxNQUFNbEMsTUFBTSxDQUFDbUMsTUFBTSxDQUFDO1FBQ25DQyxLQUFLLEVBQUV5TCxvQ0FBeUI7UUFDaEN2TCxrQkFBa0IsRUFBRSxJQUFJO1FBQ3hCWjtNQUNGLENBQUMsQ0FBQztNQUNGLE1BQU1hLElBQUksSUFBQWlMLE1BQUEsSUFBQUMsZUFBQSxHQUFJdkwsUUFBUSxDQUFDUixJQUFJLGNBQUErTCxlQUFBLHVCQUFkQSxlQUFBLENBQXdCbEwsSUFBSSxjQUFBaUwsTUFBQSxjQUFBQSxNQUFBLEdBQUksQ0FBQyxDQUFDO01BQy9DLE9BQU9yTSxHQUFHLENBQUNxQixFQUFFLENBQUM7UUFDWmQsSUFBSSxFQUFFO1VBQ0pvTSxNQUFNLEVBQUUsRUFBQUosV0FBQSxHQUFDbkwsSUFBSSxDQUFDQSxJQUFJLGNBQUFtTCxXQUFBLGNBQUFBLFdBQUEsR0FBSSxFQUFFLEVBQUV6SCxHQUFHLENBQUVDLENBQU0sSUFBS0EsQ0FBQyxDQUFDdEMsT0FBTyxDQUFDLENBQUN1QyxNQUFNLENBQUNDLE9BQU8sQ0FBQztVQUNwRTNELEtBQUssR0FBQWtMLFdBQUEsR0FBRXBMLElBQUksQ0FBQ0UsS0FBSyxjQUFBa0wsV0FBQSxjQUFBQSxXQUFBLEdBQUk7WUFBRTFCLEtBQUssRUFBRTtVQUFFO1FBQ2xDO01BQ0YsQ0FBQyxDQUFDO0lBQ0osQ0FBQyxDQUFDLE9BQU92SixHQUFRLEVBQUU7TUFBQSxJQUFBcUwsZ0JBQUEsRUFBQUMsYUFBQTtNQUNqQixPQUFPN00sR0FBRyxDQUFDMEIsV0FBVyxDQUFDO1FBQ3JCQyxVQUFVLEdBQUFpTCxnQkFBQSxHQUFFckwsR0FBRyxDQUFDSSxVQUFVLGNBQUFpTCxnQkFBQSxjQUFBQSxnQkFBQSxHQUFJLEdBQUc7UUFDakNyTSxJQUFJLEdBQUFzTSxhQUFBLEdBQUV0TCxHQUFHLENBQUNLLE9BQU8sY0FBQWlMLGFBQUEsY0FBQUEsYUFBQSxHQUFJaEwsTUFBTSxDQUFDTixHQUFHO01BQ2pDLENBQUMsQ0FBQztJQUNKO0VBQ0YsQ0FDRixDQUFDOztFQUVEO0VBQ0F2QyxNQUFNLENBQUNDLEdBQUcsQ0FDUjtJQUNFQyxJQUFJLEVBQUUsa0NBQWtDO0lBQ3hDQyxRQUFRLEVBQUU7TUFDUkMsS0FBSyxFQUFFQyxvQkFBTSxDQUFDQyxNQUFNLENBQUM7UUFDbkJDLElBQUksRUFBRUYsb0JBQU0sQ0FBQ0csS0FBSyxDQUFDSCxvQkFBTSxDQUFDSSxNQUFNLENBQUMsQ0FBQyxDQUFDO1FBQ25DQyxJQUFJLEVBQUVMLG9CQUFNLENBQUNHLEtBQUssQ0FBQ0gsb0JBQU0sQ0FBQ0ksTUFBTSxDQUFDLENBQUM7TUFDcEMsQ0FBQztJQUNIO0VBQ0YsQ0FBQyxFQUNELE9BQU9mLE9BQU8sRUFBRXFCLEdBQUcsRUFBRUMsR0FBRyxLQUFLO0lBQzNCLElBQUk7TUFBQSxJQUFBOE0sZ0JBQUEsRUFBQUMsZUFBQSxFQUFBQyxNQUFBLEVBQUFDLGVBQUEsRUFBQUMsV0FBQSxFQUFBQyxZQUFBO01BQ0YsTUFBTXRPLE1BQU0sR0FBR0osU0FBUyxDQUFDQyxPQUFPLENBQUM7TUFDakMsTUFBTWEsSUFBSSxJQUFBdU4sZ0JBQUEsR0FBRy9NLEdBQUcsQ0FBQ1gsS0FBSyxDQUFDRyxJQUFJLGNBQUF1TixnQkFBQSxjQUFBQSxnQkFBQSxHQUFJLEVBQUU7TUFDakMsTUFBTXBOLElBQUksSUFBQXFOLGVBQUEsR0FBR2hOLEdBQUcsQ0FBQ1gsS0FBSyxDQUFDTSxJQUFJLGNBQUFxTixlQUFBLGNBQUFBLGVBQUEsR0FBSSxDQUFDO01BQ2hDLE1BQU14TSxJQUFJLEdBQUc7UUFDWGhCLElBQUk7UUFDSkcsSUFBSTtRQUNKYyxJQUFJLEVBQUUsQ0FBQztVQUFFb0UsWUFBWSxFQUFFO1lBQUVsRSxLQUFLLEVBQUUsTUFBTTtZQUFFNEIsT0FBTyxFQUFFO1VBQVE7UUFBRSxDQUFDLEVBQUU7VUFBRSxzQkFBc0IsRUFBRTtZQUFFNUIsS0FBSyxFQUFFLEtBQUs7WUFBRTRCLE9BQU8sRUFBRTtVQUFRO1FBQUUsQ0FBQyxDQUFDO1FBQzdIbEQsS0FBSyxFQUFFO1VBQUUwQixTQUFTLEVBQUUsQ0FBQztRQUFFO01BQ3pCLENBQUM7TUFDRCxNQUFNQyxRQUFRLEdBQUcsTUFBTWxDLE1BQU0sQ0FBQ21DLE1BQU0sQ0FBQztRQUNuQ0MsS0FBSyxFQUFFMEQscUNBQTBCO1FBQ2pDeEQsa0JBQWtCLEVBQUUsSUFBSTtRQUN4Qlo7TUFDRixDQUFDLENBQUM7TUFDRixNQUFNYSxJQUFJLElBQUE0TCxNQUFBLElBQUFDLGVBQUEsR0FBSWxNLFFBQVEsQ0FBQ1IsSUFBSSxjQUFBME0sZUFBQSx1QkFBZEEsZUFBQSxDQUF3QjdMLElBQUksY0FBQTRMLE1BQUEsY0FBQUEsTUFBQSxHQUFJLENBQUMsQ0FBQztNQUMvQyxPQUFPaE4sR0FBRyxDQUFDcUIsRUFBRSxDQUFDO1FBQ1pkLElBQUksRUFBRTtVQUNKNk0sSUFBSSxFQUFFLEVBQUFGLFdBQUEsR0FBQzlMLElBQUksQ0FBQ0EsSUFBSSxjQUFBOEwsV0FBQSxjQUFBQSxXQUFBLEdBQUksRUFBRSxFQUFFcEksR0FBRyxDQUFFQyxDQUFNLElBQUtBLENBQUMsQ0FBQ3RDLE9BQU8sQ0FBQyxDQUFDdUMsTUFBTSxDQUFDQyxPQUFPLENBQUM7VUFDbEUzRCxLQUFLLEdBQUE2TCxZQUFBLEdBQUUvTCxJQUFJLENBQUNFLEtBQUssY0FBQTZMLFlBQUEsY0FBQUEsWUFBQSxHQUFJO1lBQUVyQyxLQUFLLEVBQUU7VUFBRTtRQUNsQztNQUNGLENBQUMsQ0FBQztJQUNKLENBQUMsQ0FBQyxPQUFPdkosR0FBUSxFQUFFO01BQUEsSUFBQThMLGdCQUFBLEVBQUFDLGFBQUE7TUFDakIsT0FBT3ROLEdBQUcsQ0FBQzBCLFdBQVcsQ0FBQztRQUNyQkMsVUFBVSxHQUFBMEwsZ0JBQUEsR0FBRTlMLEdBQUcsQ0FBQ0ksVUFBVSxjQUFBMEwsZ0JBQUEsY0FBQUEsZ0JBQUEsR0FBSSxHQUFHO1FBQ2pDOU0sSUFBSSxHQUFBK00sYUFBQSxHQUFFL0wsR0FBRyxDQUFDSyxPQUFPLGNBQUEwTCxhQUFBLGNBQUFBLGFBQUEsR0FBSXpMLE1BQU0sQ0FBQ04sR0FBRztNQUNqQyxDQUFDLENBQUM7SUFDSjtFQUNGLENBQ0YsQ0FBQzs7RUFFRDtFQUNBdkMsTUFBTSxDQUFDQyxHQUFHLENBQ1I7SUFDRUMsSUFBSSxFQUFFLGdDQUFnQztJQUN0Q0MsUUFBUSxFQUFFO01BQ1JDLEtBQUssRUFBRUMsb0JBQU0sQ0FBQ0MsTUFBTSxDQUFDO1FBQ25CQyxJQUFJLEVBQUVGLG9CQUFNLENBQUNHLEtBQUssQ0FBQ0gsb0JBQU0sQ0FBQ0ksTUFBTSxDQUFDLENBQUMsQ0FBQztRQUNuQ0MsSUFBSSxFQUFFTCxvQkFBTSxDQUFDRyxLQUFLLENBQUNILG9CQUFNLENBQUNJLE1BQU0sQ0FBQyxDQUFDLENBQUM7UUFDbkM4TixRQUFRLEVBQUVsTyxvQkFBTSxDQUFDRyxLQUFLLENBQUNILG9CQUFNLENBQUNPLE1BQU0sQ0FBQyxDQUFDLENBQUM7UUFDdkM0TixhQUFhLEVBQUVuTyxvQkFBTSxDQUFDRyxLQUFLLENBQUNILG9CQUFNLENBQUNPLE1BQU0sQ0FBQyxDQUFDO01BQzdDLENBQUM7SUFDSDtFQUNGLENBQUMsRUFDRCxPQUFPbEIsT0FBTyxFQUFFcUIsR0FBRyxFQUFFQyxHQUFHLEtBQUs7SUFDM0IsSUFBSTtNQUFBLElBQUF5TixNQUFBLEVBQUFDLGVBQUEsRUFBQUMsWUFBQTtNQUNGLE1BQU05TyxNQUFNLEdBQUdKLFNBQVMsQ0FBQ0MsT0FBTyxDQUFDO01BQ2pDLE1BQU07UUFBRWEsSUFBSSxHQUFHLEVBQUU7UUFBRUcsSUFBSSxHQUFHLENBQUM7UUFBRTZOLFFBQVE7UUFBRUM7TUFBYyxDQUFDLEdBQUd6TixHQUFHLENBQUNYLEtBQUs7TUFDbEUsTUFBTWdCLElBQVcsR0FBRyxFQUFFO01BQ3RCLElBQUltTixRQUFRLEVBQUVuTixJQUFJLENBQUNDLElBQUksQ0FBQztRQUFFQyxJQUFJLEVBQUU7VUFBRWlOO1FBQVM7TUFBRSxDQUFDLENBQUM7TUFDL0MsSUFBSUMsYUFBYSxFQUFFcE4sSUFBSSxDQUFDQyxJQUFJLENBQUM7UUFBRUMsSUFBSSxFQUFFO1VBQUVrTjtRQUFjO01BQUUsQ0FBQyxDQUFDO01BQ3pELE1BQU16TSxRQUFRLEdBQUcsTUFBTWxDLE1BQU0sQ0FBQ21DLE1BQU0sQ0FBQztRQUNuQ0MsS0FBSyxFQUFFdUcsbUNBQXdCO1FBQy9Cckcsa0JBQWtCLEVBQUUsSUFBSTtRQUN4QlosSUFBSSxFQUFFO1VBQ0poQixJQUFJO1VBQ0pHLElBQUk7VUFDSmMsSUFBSSxFQUFFLENBQUM7WUFBRSxzQkFBc0IsRUFBRTtjQUFFRSxLQUFLLEVBQUUsS0FBSztjQUFFNEIsT0FBTyxFQUFFO1lBQVE7VUFBRSxDQUFDLENBQUM7VUFDdEVsRCxLQUFLLEVBQUVnQixJQUFJLENBQUNRLE1BQU0sR0FBRztZQUFFQyxJQUFJLEVBQUU7Y0FBRVQ7WUFBSztVQUFFLENBQUMsR0FBRztZQUFFVSxTQUFTLEVBQUUsQ0FBQztVQUFFO1FBQzVEO01BQ0YsQ0FBQyxDQUFDO01BQ0YsTUFBTU0sSUFBSSxJQUFBcU0sTUFBQSxJQUFBQyxlQUFBLEdBQUkzTSxRQUFRLENBQUNSLElBQUksY0FBQW1OLGVBQUEsdUJBQWRBLGVBQUEsQ0FBd0J0TSxJQUFJLGNBQUFxTSxNQUFBLGNBQUFBLE1BQUEsR0FBSSxDQUFDLENBQUM7TUFDL0MsT0FBT3pOLEdBQUcsQ0FBQ3FCLEVBQUUsQ0FBQztRQUFFZCxJQUFJLEVBQUU7VUFBRTZNLElBQUksRUFBRSxFQUFBTyxZQUFBLEdBQUN2TSxJQUFJLENBQUNBLElBQUksY0FBQXVNLFlBQUEsY0FBQUEsWUFBQSxHQUFJLEVBQUUsRUFBRTdJLEdBQUcsQ0FBRUMsQ0FBTSxJQUFLQSxDQUFDLENBQUN0QyxPQUFPLENBQUMsQ0FBQ3VDLE1BQU0sQ0FBQ0MsT0FBTyxDQUFDO1VBQUUzRCxLQUFLLEVBQUVGLElBQUksQ0FBQ0U7UUFBTTtNQUFFLENBQUMsQ0FBQztJQUNwSCxDQUFDLENBQUMsT0FBT0MsR0FBUSxFQUFFO01BQUEsSUFBQXFNLGdCQUFBLEVBQUFDLGFBQUE7TUFDakIsT0FBTzdOLEdBQUcsQ0FBQzBCLFdBQVcsQ0FBQztRQUFFQyxVQUFVLEdBQUFpTSxnQkFBQSxHQUFFck0sR0FBRyxDQUFDSSxVQUFVLGNBQUFpTSxnQkFBQSxjQUFBQSxnQkFBQSxHQUFJLEdBQUc7UUFBRXJOLElBQUksR0FBQXNOLGFBQUEsR0FBRXRNLEdBQUcsQ0FBQ0ssT0FBTyxjQUFBaU0sYUFBQSxjQUFBQSxhQUFBLEdBQUloTSxNQUFNLENBQUNOLEdBQUc7TUFBRSxDQUFDLENBQUM7SUFDakc7RUFDRixDQUNGLENBQUM7O0VBRUQ7RUFDQXZDLE1BQU0sQ0FBQ0MsR0FBRyxDQUNSO0lBQ0VDLElBQUksRUFBRSx3Q0FBd0M7SUFDOUNDLFFBQVEsRUFBRTtNQUNSQyxLQUFLLEVBQUVDLG9CQUFNLENBQUNDLE1BQU0sQ0FBQztRQUNuQkMsSUFBSSxFQUFFRixvQkFBTSxDQUFDRyxLQUFLLENBQUNILG9CQUFNLENBQUNJLE1BQU0sQ0FBQyxDQUFDLENBQUM7UUFDbkNDLElBQUksRUFBRUwsb0JBQU0sQ0FBQ0csS0FBSyxDQUFDSCxvQkFBTSxDQUFDSSxNQUFNLENBQUMsQ0FBQztNQUNwQyxDQUFDO0lBQ0g7RUFDRixDQUFDLEVBQ0QsT0FBT2YsT0FBTyxFQUFFcUIsR0FBRyxFQUFFQyxHQUFHLEtBQUs7SUFDM0IsSUFBSTtNQUFBLElBQUE4TixNQUFBLEVBQUFDLGVBQUEsRUFBQUMsWUFBQTtNQUNGLE1BQU1uUCxNQUFNLEdBQUdKLFNBQVMsQ0FBQ0MsT0FBTyxDQUFDO01BQ2pDLE1BQU07UUFBRWEsSUFBSSxHQUFHLEVBQUU7UUFBRUcsSUFBSSxHQUFHO01BQUUsQ0FBQyxHQUFHSyxHQUFHLENBQUNYLEtBQUs7TUFDekMsTUFBTTJCLFFBQVEsR0FBRyxNQUFNbEMsTUFBTSxDQUFDbUMsTUFBTSxDQUFDO1FBQ25DQyxLQUFLLEVBQUV3RywyQ0FBZ0M7UUFDdkN0RyxrQkFBa0IsRUFBRSxJQUFJO1FBQ3hCWixJQUFJLEVBQUU7VUFDSmhCLElBQUk7VUFDSkcsSUFBSTtVQUNKYyxJQUFJLEVBQUUsQ0FBQztZQUFFLHNCQUFzQixFQUFFO2NBQUVFLEtBQUssRUFBRSxLQUFLO2NBQUU0QixPQUFPLEVBQUU7WUFBUTtVQUFFLENBQUMsQ0FBQztVQUN0RWxELEtBQUssRUFBRTtZQUFFMEIsU0FBUyxFQUFFLENBQUM7VUFBRTtRQUN6QjtNQUNGLENBQUMsQ0FBQztNQUNGLE1BQU1NLElBQUksSUFBQTBNLE1BQUEsSUFBQUMsZUFBQSxHQUFJaE4sUUFBUSxDQUFDUixJQUFJLGNBQUF3TixlQUFBLHVCQUFkQSxlQUFBLENBQXdCM00sSUFBSSxjQUFBME0sTUFBQSxjQUFBQSxNQUFBLEdBQUksQ0FBQyxDQUFDO01BQy9DLE9BQU85TixHQUFHLENBQUNxQixFQUFFLENBQUM7UUFBRWQsSUFBSSxFQUFFO1VBQUUwTixRQUFRLEVBQUUsRUFBQUQsWUFBQSxHQUFDNU0sSUFBSSxDQUFDQSxJQUFJLGNBQUE0TSxZQUFBLGNBQUFBLFlBQUEsR0FBSSxFQUFFLEVBQUVsSixHQUFHLENBQUVDLENBQU0sSUFBS0EsQ0FBQyxDQUFDdEMsT0FBTyxDQUFDLENBQUN1QyxNQUFNLENBQUNDLE9BQU8sQ0FBQztVQUFFM0QsS0FBSyxFQUFFRixJQUFJLENBQUNFO1FBQU07TUFBRSxDQUFDLENBQUM7SUFDeEgsQ0FBQyxDQUFDLE9BQU9DLEdBQVEsRUFBRTtNQUFBLElBQUEyTSxnQkFBQSxFQUFBQyxhQUFBO01BQ2pCLE9BQU9uTyxHQUFHLENBQUMwQixXQUFXLENBQUM7UUFBRUMsVUFBVSxHQUFBdU0sZ0JBQUEsR0FBRTNNLEdBQUcsQ0FBQ0ksVUFBVSxjQUFBdU0sZ0JBQUEsY0FBQUEsZ0JBQUEsR0FBSSxHQUFHO1FBQUUzTixJQUFJLEdBQUE0TixhQUFBLEdBQUU1TSxHQUFHLENBQUNLLE9BQU8sY0FBQXVNLGFBQUEsY0FBQUEsYUFBQSxHQUFJdE0sTUFBTSxDQUFDTixHQUFHO01BQUUsQ0FBQyxDQUFDO0lBQ2pHO0VBQ0YsQ0FDRixDQUFDOztFQUVEO0VBQ0F2QyxNQUFNLENBQUNDLEdBQUcsQ0FDUjtJQUNFQyxJQUFJLEVBQUUsb0NBQW9DO0lBQzFDQyxRQUFRLEVBQUU7TUFDUkMsS0FBSyxFQUFFQyxvQkFBTSxDQUFDQyxNQUFNLENBQUM7UUFDbkJDLElBQUksRUFBRUYsb0JBQU0sQ0FBQ0csS0FBSyxDQUFDSCxvQkFBTSxDQUFDSSxNQUFNLENBQUMsQ0FBQyxDQUFDO1FBQ25DQyxJQUFJLEVBQUVMLG9CQUFNLENBQUNHLEtBQUssQ0FBQ0gsb0JBQU0sQ0FBQ0ksTUFBTSxDQUFDLENBQUM7TUFDcEMsQ0FBQztJQUNIO0VBQ0YsQ0FBQyxFQUNELE9BQU9mLE9BQU8sRUFBRXFCLEdBQUcsRUFBRUMsR0FBRyxLQUFLO0lBQzNCLElBQUk7TUFBQSxJQUFBb08sTUFBQSxFQUFBQyxlQUFBLEVBQUFDLFlBQUE7TUFDRixNQUFNelAsTUFBTSxHQUFHSixTQUFTLENBQUNDLE9BQU8sQ0FBQztNQUNqQyxNQUFNO1FBQUVhLElBQUksR0FBRyxFQUFFO1FBQUVHLElBQUksR0FBRztNQUFFLENBQUMsR0FBR0ssR0FBRyxDQUFDWCxLQUFLO01BQ3pDLE1BQU0yQixRQUFRLEdBQUcsTUFBTWxDLE1BQU0sQ0FBQ21DLE1BQU0sQ0FBQztRQUNuQ0MsS0FBSyxFQUFFc04sdUNBQTRCO1FBQ25DcE4sa0JBQWtCLEVBQUUsSUFBSTtRQUN4QlosSUFBSSxFQUFFO1VBQ0poQixJQUFJO1VBQ0pHLElBQUk7VUFDSmMsSUFBSSxFQUFFLENBQUM7WUFBRSxzQkFBc0IsRUFBRTtjQUFFRSxLQUFLLEVBQUUsS0FBSztjQUFFNEIsT0FBTyxFQUFFO1lBQVE7VUFBRSxDQUFDLENBQUM7VUFDdEVsRCxLQUFLLEVBQUU7WUFBRTBCLFNBQVMsRUFBRSxDQUFDO1VBQUU7UUFDekI7TUFDRixDQUFDLENBQUM7TUFDRixNQUFNTSxJQUFJLElBQUFnTixNQUFBLElBQUFDLGVBQUEsR0FBSXROLFFBQVEsQ0FBQ1IsSUFBSSxjQUFBOE4sZUFBQSx1QkFBZEEsZUFBQSxDQUF3QmpOLElBQUksY0FBQWdOLE1BQUEsY0FBQUEsTUFBQSxHQUFJLENBQUMsQ0FBQztNQUMvQyxPQUFPcE8sR0FBRyxDQUFDcUIsRUFBRSxDQUFDO1FBQUVkLElBQUksRUFBRTtVQUFFaU8sUUFBUSxFQUFFLEVBQUFGLFlBQUEsR0FBQ2xOLElBQUksQ0FBQ0EsSUFBSSxjQUFBa04sWUFBQSxjQUFBQSxZQUFBLEdBQUksRUFBRSxFQUFFeEosR0FBRyxDQUFFQyxDQUFNLElBQUtBLENBQUMsQ0FBQ3RDLE9BQU8sQ0FBQyxDQUFDdUMsTUFBTSxDQUFDQyxPQUFPLENBQUM7VUFBRTNELEtBQUssRUFBRUYsSUFBSSxDQUFDRTtRQUFNO01BQUUsQ0FBQyxDQUFDO0lBQ3hILENBQUMsQ0FBQyxPQUFPQyxHQUFRLEVBQUU7TUFBQSxJQUFBa04saUJBQUEsRUFBQUMsY0FBQTtNQUNqQixPQUFPMU8sR0FBRyxDQUFDMEIsV0FBVyxDQUFDO1FBQUVDLFVBQVUsR0FBQThNLGlCQUFBLEdBQUVsTixHQUFHLENBQUNJLFVBQVUsY0FBQThNLGlCQUFBLGNBQUFBLGlCQUFBLEdBQUksR0FBRztRQUFFbE8sSUFBSSxHQUFBbU8sY0FBQSxHQUFFbk4sR0FBRyxDQUFDSyxPQUFPLGNBQUE4TSxjQUFBLGNBQUFBLGNBQUEsR0FBSTdNLE1BQU0sQ0FBQ04sR0FBRztNQUFFLENBQUMsQ0FBQztJQUNqRztFQUNGLENBQ0YsQ0FBQzs7RUFFRDtFQUNBdkMsTUFBTSxDQUFDQyxHQUFHLENBQ1I7SUFDRUMsSUFBSSxFQUFFLDRCQUE0QjtJQUNsQ0MsUUFBUSxFQUFFO01BQ1JDLEtBQUssRUFBRUMsb0JBQU0sQ0FBQ0MsTUFBTSxDQUFDO1FBQ25CQyxJQUFJLEVBQUVGLG9CQUFNLENBQUNHLEtBQUssQ0FBQ0gsb0JBQU0sQ0FBQ0ksTUFBTSxDQUFDLENBQUMsQ0FBQztRQUNuQ0MsSUFBSSxFQUFFTCxvQkFBTSxDQUFDRyxLQUFLLENBQUNILG9CQUFNLENBQUNJLE1BQU0sQ0FBQyxDQUFDLENBQUM7UUFDbkNrUCxXQUFXLEVBQUV0UCxvQkFBTSxDQUFDRyxLQUFLLENBQUNILG9CQUFNLENBQUNPLE1BQU0sQ0FBQyxDQUFDO01BQzNDLENBQUM7SUFDSDtFQUNGLENBQUMsRUFDRCxPQUFPbEIsT0FBTyxFQUFFcUIsR0FBRyxFQUFFQyxHQUFHLEtBQUs7SUFDM0IsSUFBSTtNQUFBLElBQUE0TyxNQUFBLEVBQUFDLGVBQUEsRUFBQUMsWUFBQTtNQUNGLE1BQU1qUSxNQUFNLEdBQUdKLFNBQVMsQ0FBQ0MsT0FBTyxDQUFDO01BQ2pDLE1BQU07UUFBRWEsSUFBSSxHQUFHLEVBQUU7UUFBRUcsSUFBSSxHQUFHLENBQUM7UUFBRWlQO01BQVksQ0FBQyxHQUFHNU8sR0FBRyxDQUFDWCxLQUFLO01BQ3RELE1BQU1nQixJQUFXLEdBQUcsRUFBRTtNQUN0QixJQUFJdU8sV0FBVyxFQUFFdk8sSUFBSSxDQUFDQyxJQUFJLENBQUM7UUFBRUMsSUFBSSxFQUFFO1VBQUVxTztRQUFZO01BQUUsQ0FBQyxDQUFDO01BQ3JELE1BQU01TixRQUFRLEdBQUcsTUFBTWxDLE1BQU0sQ0FBQ21DLE1BQU0sQ0FBQztRQUNuQ0MsS0FBSyxFQUFFMkcsK0JBQW9CO1FBQzNCekcsa0JBQWtCLEVBQUUsSUFBSTtRQUN4QlosSUFBSSxFQUFFO1VBQ0poQixJQUFJO1VBQ0pHLElBQUk7VUFDSmMsSUFBSSxFQUFFLENBQUM7WUFBRXVPLHVCQUF1QixFQUFFO2NBQUVyTyxLQUFLLEVBQUUsTUFBTTtjQUFFNEIsT0FBTyxFQUFFO1lBQVE7VUFBRSxDQUFDLENBQUM7VUFDeEVsRCxLQUFLLEVBQUVnQixJQUFJLENBQUNRLE1BQU0sR0FBRztZQUFFQyxJQUFJLEVBQUU7Y0FBRVQ7WUFBSztVQUFFLENBQUMsR0FBRztZQUFFVSxTQUFTLEVBQUUsQ0FBQztVQUFFO1FBQzVEO01BQ0YsQ0FBQyxDQUFDO01BQ0YsTUFBTU0sSUFBSSxJQUFBd04sTUFBQSxJQUFBQyxlQUFBLEdBQUk5TixRQUFRLENBQUNSLElBQUksY0FBQXNPLGVBQUEsdUJBQWRBLGVBQUEsQ0FBd0J6TixJQUFJLGNBQUF3TixNQUFBLGNBQUFBLE1BQUEsR0FBSSxDQUFDLENBQUM7TUFDL0MsT0FBTzVPLEdBQUcsQ0FBQ3FCLEVBQUUsQ0FBQztRQUFFZCxJQUFJLEVBQUU7VUFBRXlPLE9BQU8sRUFBRSxFQUFBRixZQUFBLEdBQUMxTixJQUFJLENBQUNBLElBQUksY0FBQTBOLFlBQUEsY0FBQUEsWUFBQSxHQUFJLEVBQUUsRUFBRWhLLEdBQUcsQ0FBRUMsQ0FBTSxJQUFLQSxDQUFDLENBQUN0QyxPQUFPLENBQUMsQ0FBQ3VDLE1BQU0sQ0FBQ0MsT0FBTyxDQUFDO1VBQUUzRCxLQUFLLEVBQUVGLElBQUksQ0FBQ0U7UUFBTTtNQUFFLENBQUMsQ0FBQztJQUN2SCxDQUFDLENBQUMsT0FBT0MsR0FBUSxFQUFFO01BQUEsSUFBQTBOLGlCQUFBLEVBQUFDLGNBQUE7TUFDakIsT0FBT2xQLEdBQUcsQ0FBQzBCLFdBQVcsQ0FBQztRQUFFQyxVQUFVLEdBQUFzTixpQkFBQSxHQUFFMU4sR0FBRyxDQUFDSSxVQUFVLGNBQUFzTixpQkFBQSxjQUFBQSxpQkFBQSxHQUFJLEdBQUc7UUFBRTFPLElBQUksR0FBQTJPLGNBQUEsR0FBRTNOLEdBQUcsQ0FBQ0ssT0FBTyxjQUFBc04sY0FBQSxjQUFBQSxjQUFBLEdBQUlyTixNQUFNLENBQUNOLEdBQUc7TUFBRSxDQUFDLENBQUM7SUFDakc7RUFDRixDQUNGLENBQUM7O0VBRUQ7RUFDQXZDLE1BQU0sQ0FBQ0MsR0FBRyxDQUNSO0lBQ0VDLElBQUksRUFBRSx1Q0FBdUM7SUFDN0NDLFFBQVEsRUFBRTtNQUNSQyxLQUFLLEVBQUVDLG9CQUFNLENBQUNDLE1BQU0sQ0FBQztRQUNuQkMsSUFBSSxFQUFFRixvQkFBTSxDQUFDRyxLQUFLLENBQUNILG9CQUFNLENBQUNJLE1BQU0sQ0FBQyxDQUFDLENBQUM7UUFDbkNDLElBQUksRUFBRUwsb0JBQU0sQ0FBQ0csS0FBSyxDQUFDSCxvQkFBTSxDQUFDSSxNQUFNLENBQUMsQ0FBQztNQUNwQyxDQUFDO0lBQ0g7RUFDRixDQUFDLEVBQ0QsT0FBT2YsT0FBTyxFQUFFcUIsR0FBRyxFQUFFQyxHQUFHLEtBQUs7SUFDM0IsSUFBSTtNQUFBLElBQUFtUCxNQUFBLEVBQUFDLGdCQUFBLEVBQUFDLFlBQUE7TUFDRixNQUFNeFEsTUFBTSxHQUFHSixTQUFTLENBQUNDLE9BQU8sQ0FBQztNQUNqQyxNQUFNO1FBQUVhLElBQUksR0FBRyxFQUFFO1FBQUVHLElBQUksR0FBRztNQUFFLENBQUMsR0FBR0ssR0FBRyxDQUFDWCxLQUFLO01BQ3pDLE1BQU0yQixRQUFRLEdBQUcsTUFBTWxDLE1BQU0sQ0FBQ21DLE1BQU0sQ0FBQztRQUNuQ0MsS0FBSyxFQUFFeUcsa0NBQXVCO1FBQzlCdkcsa0JBQWtCLEVBQUUsSUFBSTtRQUN4QlosSUFBSSxFQUFFO1VBQ0poQixJQUFJO1VBQ0pHLElBQUk7VUFDSmMsSUFBSSxFQUFFLENBQUM7WUFBRThPLFFBQVEsRUFBRTtjQUFFNU8sS0FBSyxFQUFFLEtBQUs7Y0FBRTRCLE9BQU8sRUFBRTtZQUFRO1VBQUUsQ0FBQyxFQUFFO1lBQUUsc0JBQXNCLEVBQUU7Y0FBRTVCLEtBQUssRUFBRSxLQUFLO2NBQUU0QixPQUFPLEVBQUU7WUFBUTtVQUFFLENBQUMsQ0FBQztVQUN4SGxELEtBQUssRUFBRTtZQUFFMEIsU0FBUyxFQUFFLENBQUM7VUFBRTtRQUN6QjtNQUNGLENBQUMsQ0FBQztNQUNGLE1BQU1NLElBQUksSUFBQStOLE1BQUEsSUFBQUMsZ0JBQUEsR0FBSXJPLFFBQVEsQ0FBQ1IsSUFBSSxjQUFBNk8sZ0JBQUEsdUJBQWRBLGdCQUFBLENBQXdCaE8sSUFBSSxjQUFBK04sTUFBQSxjQUFBQSxNQUFBLEdBQUksQ0FBQyxDQUFDO01BQy9DLE9BQU9uUCxHQUFHLENBQUNxQixFQUFFLENBQUM7UUFBRWQsSUFBSSxFQUFFO1VBQUVnUCxPQUFPLEVBQUUsRUFBQUYsWUFBQSxHQUFDak8sSUFBSSxDQUFDQSxJQUFJLGNBQUFpTyxZQUFBLGNBQUFBLFlBQUEsR0FBSSxFQUFFLEVBQUV2SyxHQUFHLENBQUVDLENBQU0sSUFBS0EsQ0FBQyxDQUFDdEMsT0FBTyxDQUFDLENBQUN1QyxNQUFNLENBQUNDLE9BQU8sQ0FBQztVQUFFM0QsS0FBSyxFQUFFRixJQUFJLENBQUNFO1FBQU07TUFBRSxDQUFDLENBQUM7SUFDdkgsQ0FBQyxDQUFDLE9BQU9DLEdBQVEsRUFBRTtNQUFBLElBQUFpTyxpQkFBQSxFQUFBQyxjQUFBO01BQ2pCLE9BQU96UCxHQUFHLENBQUMwQixXQUFXLENBQUM7UUFBRUMsVUFBVSxHQUFBNk4saUJBQUEsR0FBRWpPLEdBQUcsQ0FBQ0ksVUFBVSxjQUFBNk4saUJBQUEsY0FBQUEsaUJBQUEsR0FBSSxHQUFHO1FBQUVqUCxJQUFJLEdBQUFrUCxjQUFBLEdBQUVsTyxHQUFHLENBQUNLLE9BQU8sY0FBQTZOLGNBQUEsY0FBQUEsY0FBQSxHQUFJNU4sTUFBTSxDQUFDTixHQUFHO01BQUUsQ0FBQyxDQUFDO0lBQ2pHO0VBQ0YsQ0FDRixDQUFDOztFQUVEO0VBQ0F2QyxNQUFNLENBQUNDLEdBQUcsQ0FDUjtJQUNFQyxJQUFJLEVBQUUsc0NBQXNDO0lBQzVDQyxRQUFRLEVBQUU7TUFDUkMsS0FBSyxFQUFFQyxvQkFBTSxDQUFDQyxNQUFNLENBQUM7UUFDbkJDLElBQUksRUFBRUYsb0JBQU0sQ0FBQ0csS0FBSyxDQUFDSCxvQkFBTSxDQUFDSSxNQUFNLENBQUMsQ0FBQyxDQUFDO1FBQ25DQyxJQUFJLEVBQUVMLG9CQUFNLENBQUNHLEtBQUssQ0FBQ0gsb0JBQU0sQ0FBQ0ksTUFBTSxDQUFDLENBQUMsQ0FBQztRQUNuQ2lRLGdCQUFnQixFQUFFclEsb0JBQU0sQ0FBQ0csS0FBSyxDQUFDSCxvQkFBTSxDQUFDTyxNQUFNLENBQUMsQ0FBQztNQUNoRCxDQUFDO0lBQ0g7RUFDRixDQUFDLEVBQ0QsT0FBT2xCLE9BQU8sRUFBRXFCLEdBQUcsRUFBRUMsR0FBRyxLQUFLO0lBQzNCLElBQUk7TUFBQSxJQUFBMlAsT0FBQSxFQUFBQyxnQkFBQSxFQUFBQyxZQUFBO01BQ0YsTUFBTWhSLE1BQU0sR0FBR0osU0FBUyxDQUFDQyxPQUFPLENBQUM7TUFDakMsTUFBTTtRQUFFYSxJQUFJLEdBQUcsRUFBRTtRQUFFRyxJQUFJLEdBQUcsQ0FBQztRQUFFZ1E7TUFBaUIsQ0FBQyxHQUFHM1AsR0FBRyxDQUFDWCxLQUFLO01BQzNELE1BQU1nQixJQUFXLEdBQUcsRUFBRTtNQUN0QixJQUFJc1AsZ0JBQWdCLEVBQUV0UCxJQUFJLENBQUNDLElBQUksQ0FBQztRQUFFQyxJQUFJLEVBQUU7VUFBRW9QO1FBQWlCO01BQUUsQ0FBQyxDQUFDO01BQy9ELE1BQU0zTyxRQUFRLEdBQUcsTUFBTWxDLE1BQU0sQ0FBQ21DLE1BQU0sQ0FBQztRQUNuQ0MsS0FBSyxFQUFFNk8saUNBQXNCO1FBQzdCM08sa0JBQWtCLEVBQUUsSUFBSTtRQUN4QlosSUFBSSxFQUFFO1VBQ0poQixJQUFJO1VBQ0pHLElBQUk7VUFDSmMsSUFBSSxFQUFFLENBQUM7WUFBRXVQLHdCQUF3QixFQUFFO2NBQUVyUCxLQUFLLEVBQUUsTUFBTTtjQUFFNEIsT0FBTyxFQUFFO1lBQVE7VUFBRSxDQUFDLENBQUM7VUFDekVsRCxLQUFLLEVBQUVnQixJQUFJLENBQUNRLE1BQU0sR0FBRztZQUFFQyxJQUFJLEVBQUU7Y0FBRVQ7WUFBSztVQUFFLENBQUMsR0FBRztZQUFFVSxTQUFTLEVBQUUsQ0FBQztVQUFFO1FBQzVEO01BQ0YsQ0FBQyxDQUFDO01BQ0YsTUFBTU0sSUFBSSxJQUFBdU8sT0FBQSxJQUFBQyxnQkFBQSxHQUFJN08sUUFBUSxDQUFDUixJQUFJLGNBQUFxUCxnQkFBQSx1QkFBZEEsZ0JBQUEsQ0FBd0J4TyxJQUFJLGNBQUF1TyxPQUFBLGNBQUFBLE9BQUEsR0FBSSxDQUFDLENBQUM7TUFDL0MsT0FBTzNQLEdBQUcsQ0FBQ3FCLEVBQUUsQ0FBQztRQUFFZCxJQUFJLEVBQUU7VUFBRWdDLE9BQU8sRUFBRSxFQUFBc04sWUFBQSxHQUFDek8sSUFBSSxDQUFDQSxJQUFJLGNBQUF5TyxZQUFBLGNBQUFBLFlBQUEsR0FBSSxFQUFFLEVBQUUvSyxHQUFHLENBQUVDLENBQU0sSUFBS0EsQ0FBQyxDQUFDdEMsT0FBTyxDQUFDLENBQUN1QyxNQUFNLENBQUNDLE9BQU8sQ0FBQztVQUFFM0QsS0FBSyxFQUFFRixJQUFJLENBQUNFO1FBQU07TUFBRSxDQUFDLENBQUM7SUFDdkgsQ0FBQyxDQUFDLE9BQU9DLEdBQVEsRUFBRTtNQUFBLElBQUF5TyxpQkFBQSxFQUFBQyxjQUFBO01BQ2pCLE9BQU9qUSxHQUFHLENBQUMwQixXQUFXLENBQUM7UUFBRUMsVUFBVSxHQUFBcU8saUJBQUEsR0FBRXpPLEdBQUcsQ0FBQ0ksVUFBVSxjQUFBcU8saUJBQUEsY0FBQUEsaUJBQUEsR0FBSSxHQUFHO1FBQUV6UCxJQUFJLEdBQUEwUCxjQUFBLEdBQUUxTyxHQUFHLENBQUNLLE9BQU8sY0FBQXFPLGNBQUEsY0FBQUEsY0FBQSxHQUFJcE8sTUFBTSxDQUFDTixHQUFHO01BQUUsQ0FBQyxDQUFDO0lBQ2pHO0VBQ0YsQ0FDRixDQUFDOztFQUVEO0VBQ0F2QyxNQUFNLENBQUNDLEdBQUcsQ0FDUjtJQUNFQyxJQUFJLEVBQUUsZ0NBQWdDO0lBQ3RDQyxRQUFRLEVBQUU7TUFDUkMsS0FBSyxFQUFFQyxvQkFBTSxDQUFDQyxNQUFNLENBQUM7UUFDbkJDLElBQUksRUFBRUYsb0JBQU0sQ0FBQ0csS0FBSyxDQUFDSCxvQkFBTSxDQUFDSSxNQUFNLENBQUMsQ0FBQyxDQUFDO1FBQ25DQyxJQUFJLEVBQUVMLG9CQUFNLENBQUNHLEtBQUssQ0FBQ0gsb0JBQU0sQ0FBQ0ksTUFBTSxDQUFDLENBQUMsQ0FBQztRQUNuQ3lRLEtBQUssRUFBRTdRLG9CQUFNLENBQUNHLEtBQUssQ0FBQ0gsb0JBQU0sQ0FBQ08sTUFBTSxDQUFDLENBQUM7TUFDckMsQ0FBQztJQUNIO0VBQ0YsQ0FBQyxFQUNELE9BQU9sQixPQUFPLEVBQUVxQixHQUFHLEVBQUVDLEdBQUcsS0FBSztJQUMzQixJQUFJO01BQUEsSUFBQW1RLE9BQUEsRUFBQUMsZ0JBQUEsRUFBQUMsWUFBQTtNQUNGLE1BQU14UixNQUFNLEdBQUdKLFNBQVMsQ0FBQ0MsT0FBTyxDQUFDO01BQ2pDLE1BQU07UUFBRWEsSUFBSSxHQUFHLEVBQUU7UUFBRUcsSUFBSSxHQUFHLENBQUM7UUFBRXdRO01BQU0sQ0FBQyxHQUFHblEsR0FBRyxDQUFDWCxLQUFLO01BQ2hELE1BQU1nQixJQUFXLEdBQUcsRUFBRTtNQUN0QixJQUFJOFAsS0FBSyxFQUFFOVAsSUFBSSxDQUFDQyxJQUFJLENBQUM7UUFBRUMsSUFBSSxFQUFFO1VBQUU0UDtRQUFNO01BQUUsQ0FBQyxDQUFDO01BQ3pDLE1BQU1uUCxRQUFRLEdBQUcsTUFBTWxDLE1BQU0sQ0FBQ21DLE1BQU0sQ0FBQztRQUNuQ0MsS0FBSyxFQUFFcVAsbUNBQXdCO1FBQy9CblAsa0JBQWtCLEVBQUUsSUFBSTtRQUN4QlosSUFBSSxFQUFFO1VBQ0poQixJQUFJO1VBQ0pHLElBQUk7VUFDSmMsSUFBSSxFQUFFLENBQUM7WUFBRSxzQkFBc0IsRUFBRTtjQUFFRSxLQUFLLEVBQUUsS0FBSztjQUFFNEIsT0FBTyxFQUFFO1lBQVE7VUFBRSxDQUFDLENBQUM7VUFDdEVsRCxLQUFLLEVBQUVnQixJQUFJLENBQUNRLE1BQU0sR0FBRztZQUFFQyxJQUFJLEVBQUU7Y0FBRVQ7WUFBSztVQUFFLENBQUMsR0FBRztZQUFFVSxTQUFTLEVBQUUsQ0FBQztVQUFFO1FBQzVEO01BQ0YsQ0FBQyxDQUFDO01BQ0YsTUFBTU0sSUFBSSxJQUFBK08sT0FBQSxJQUFBQyxnQkFBQSxHQUFJclAsUUFBUSxDQUFDUixJQUFJLGNBQUE2UCxnQkFBQSx1QkFBZEEsZ0JBQUEsQ0FBd0JoUCxJQUFJLGNBQUErTyxPQUFBLGNBQUFBLE9BQUEsR0FBSSxDQUFDLENBQUM7TUFDL0MsT0FBT25RLEdBQUcsQ0FBQ3FCLEVBQUUsQ0FBQztRQUFFZCxJQUFJLEVBQUU7VUFBRTBOLFFBQVEsRUFBRSxFQUFBb0MsWUFBQSxHQUFDalAsSUFBSSxDQUFDQSxJQUFJLGNBQUFpUCxZQUFBLGNBQUFBLFlBQUEsR0FBSSxFQUFFLEVBQUV2TCxHQUFHLENBQUVDLENBQU0sSUFBS0EsQ0FBQyxDQUFDdEMsT0FBTyxDQUFDLENBQUN1QyxNQUFNLENBQUNDLE9BQU8sQ0FBQztVQUFFM0QsS0FBSyxFQUFFRixJQUFJLENBQUNFO1FBQU07TUFBRSxDQUFDLENBQUM7SUFDeEgsQ0FBQyxDQUFDLE9BQU9DLEdBQVEsRUFBRTtNQUFBLElBQUFnUCxpQkFBQSxFQUFBQyxjQUFBO01BQ2pCLE9BQU94USxHQUFHLENBQUMwQixXQUFXLENBQUM7UUFBRUMsVUFBVSxHQUFBNE8saUJBQUEsR0FBRWhQLEdBQUcsQ0FBQ0ksVUFBVSxjQUFBNE8saUJBQUEsY0FBQUEsaUJBQUEsR0FBSSxHQUFHO1FBQUVoUSxJQUFJLEdBQUFpUSxjQUFBLEdBQUVqUCxHQUFHLENBQUNLLE9BQU8sY0FBQTRPLGNBQUEsY0FBQUEsY0FBQSxHQUFJM08sTUFBTSxDQUFDTixHQUFHO01BQUUsQ0FBQyxDQUFDO0lBQ2pHO0VBQ0YsQ0FDRixDQUFDOztFQUVEO0VBQ0F2QyxNQUFNLENBQUNDLEdBQUcsQ0FDUjtJQUNFQyxJQUFJLEVBQUUsOENBQThDO0lBQ3BEQyxRQUFRLEVBQUU7TUFBRXNSLE1BQU0sRUFBRXBSLG9CQUFNLENBQUNDLE1BQU0sQ0FBQztRQUFFMEssRUFBRSxFQUFFM0ssb0JBQU0sQ0FBQ08sTUFBTSxDQUFDO01BQUUsQ0FBQztJQUFFO0VBQzdELENBQUMsRUFDRCxPQUFPbEIsT0FBTyxFQUFFcUIsR0FBRyxFQUFFQyxHQUFHLEtBQUs7SUFDM0IsTUFBTTBRLE1BQU0sR0FBRyxJQUFBQywyQkFBYyxFQUFDLENBQUM7SUFDL0IsSUFBSSxDQUFDRCxNQUFNLEVBQUU7TUFDWCxPQUFPMVEsR0FBRyxDQUFDMEIsV0FBVyxDQUFDO1FBQUVDLFVBQVUsRUFBRSxHQUFHO1FBQUVwQixJQUFJLEVBQUU7TUFBbUMsQ0FBQyxDQUFDO0lBQ3ZGO0lBQ0EsSUFBSTtNQUNGLE1BQU15SixFQUFFLEdBQUlqSyxHQUFHLENBQUMwUSxNQUFNLENBQVN6RyxFQUFFO01BQ2pDLE1BQU00RyxPQUFPLEdBQUcsTUFBTSxJQUFBQyxpQ0FBb0IsRUFBQ0gsTUFBTSxFQUFFMUcsRUFBRSxDQUFDO01BQ3RELE9BQU9oSyxHQUFHLENBQUNxQixFQUFFLENBQUM7UUFBRWQsSUFBSSxFQUFFcVE7TUFBUSxDQUFDLENBQUM7SUFDbEMsQ0FBQyxDQUFDLE9BQU9yUCxHQUFRLEVBQUU7TUFBQSxJQUFBdVAsb0JBQUEsRUFBQUMsYUFBQSxFQUFBQyxjQUFBO01BQ2pCLE9BQU9oUixHQUFHLENBQUMwQixXQUFXLENBQUM7UUFBRUMsVUFBVSxHQUFBbVAsb0JBQUEsR0FBRXZQLEdBQUcsYUFBSEEsR0FBRyxnQkFBQXdQLGFBQUEsR0FBSHhQLEdBQUcsQ0FBRVIsUUFBUSxjQUFBZ1EsYUFBQSx1QkFBYkEsYUFBQSxDQUFlRSxNQUFNLGNBQUFILG9CQUFBLGNBQUFBLG9CQUFBLEdBQUksR0FBRztRQUFFdlEsSUFBSSxHQUFBeVEsY0FBQSxHQUFFelAsR0FBRyxhQUFIQSxHQUFHLHVCQUFIQSxHQUFHLENBQUVLLE9BQU8sY0FBQW9QLGNBQUEsY0FBQUEsY0FBQSxHQUFJblAsTUFBTSxDQUFDTixHQUFHO01BQUUsQ0FBQyxDQUFDO0lBQ3pHO0VBQ0YsQ0FDRixDQUFDOztFQUVEO0VBQ0F2QyxNQUFNLENBQUNDLEdBQUcsQ0FDUjtJQUNFQyxJQUFJLEVBQUUsMkRBQTJEO0lBQ2pFQyxRQUFRLEVBQUU7TUFBRXNSLE1BQU0sRUFBRXBSLG9CQUFNLENBQUNDLE1BQU0sQ0FBQztRQUFFMEssRUFBRSxFQUFFM0ssb0JBQU0sQ0FBQ08sTUFBTSxDQUFDO01BQUUsQ0FBQztJQUFFO0VBQzdELENBQUMsRUFDRCxPQUFPbEIsT0FBTyxFQUFFcUIsR0FBRyxFQUFFQyxHQUFHLEtBQUs7SUFDM0IsTUFBTTBRLE1BQU0sR0FBRyxJQUFBQywyQkFBYyxFQUFDLENBQUM7SUFDL0IsSUFBSSxDQUFDRCxNQUFNLEVBQUU7TUFDWCxPQUFPMVEsR0FBRyxDQUFDMEIsV0FBVyxDQUFDO1FBQUVDLFVBQVUsRUFBRSxHQUFHO1FBQUVwQixJQUFJLEVBQUU7TUFBbUMsQ0FBQyxDQUFDO0lBQ3ZGO0lBQ0EsSUFBSTtNQUNGLE1BQU15SixFQUFFLEdBQUlqSyxHQUFHLENBQUMwUSxNQUFNLENBQVN6RyxFQUFFO01BQ2pDLE1BQU00RyxPQUFPLEdBQUcsTUFBTSxJQUFBTSxtREFBc0MsRUFBQ1IsTUFBTSxFQUFFMUcsRUFBRSxDQUFDO01BQ3hFLE9BQU9oSyxHQUFHLENBQUNxQixFQUFFLENBQUM7UUFBRWQsSUFBSSxFQUFFcVE7TUFBUSxDQUFDLENBQUM7SUFDbEMsQ0FBQyxDQUFDLE9BQU9yUCxHQUFRLEVBQUU7TUFBQSxJQUFBNFAscUJBQUEsRUFBQUMsY0FBQSxFQUFBQyxjQUFBO01BQ2pCLE9BQU9yUixHQUFHLENBQUMwQixXQUFXLENBQUM7UUFBRUMsVUFBVSxHQUFBd1AscUJBQUEsR0FBRTVQLEdBQUcsYUFBSEEsR0FBRyxnQkFBQTZQLGNBQUEsR0FBSDdQLEdBQUcsQ0FBRVIsUUFBUSxjQUFBcVEsY0FBQSx1QkFBYkEsY0FBQSxDQUFlSCxNQUFNLGNBQUFFLHFCQUFBLGNBQUFBLHFCQUFBLEdBQUksR0FBRztRQUFFNVEsSUFBSSxHQUFBOFEsY0FBQSxHQUFFOVAsR0FBRyxhQUFIQSxHQUFHLHVCQUFIQSxHQUFHLENBQUVLLE9BQU8sY0FBQXlQLGNBQUEsY0FBQUEsY0FBQSxHQUFJeFAsTUFBTSxDQUFDTixHQUFHO01BQUUsQ0FBQyxDQUFDO0lBQ3pHO0VBQ0YsQ0FDRixDQUFDOztFQUVEO0VBQ0F2QyxNQUFNLENBQUNDLEdBQUcsQ0FDUjtJQUNFQyxJQUFJLEVBQUUsdURBQXVEO0lBQzdEQyxRQUFRLEVBQUU7TUFBRXNSLE1BQU0sRUFBRXBSLG9CQUFNLENBQUNDLE1BQU0sQ0FBQztRQUFFMEssRUFBRSxFQUFFM0ssb0JBQU0sQ0FBQ08sTUFBTSxDQUFDO01BQUUsQ0FBQztJQUFFO0VBQzdELENBQUMsRUFDRCxPQUFPbEIsT0FBTyxFQUFFcUIsR0FBRyxFQUFFQyxHQUFHLEtBQUs7SUFDM0IsTUFBTTBRLE1BQU0sR0FBRyxJQUFBQywyQkFBYyxFQUFDLENBQUM7SUFDL0IsSUFBSSxDQUFDRCxNQUFNLEVBQUU7TUFDWCxPQUFPMVEsR0FBRyxDQUFDMEIsV0FBVyxDQUFDO1FBQUVDLFVBQVUsRUFBRSxHQUFHO1FBQUVwQixJQUFJLEVBQUU7TUFBbUMsQ0FBQyxDQUFDO0lBQ3ZGO0lBQ0EsSUFBSTtNQUNGLE1BQU15SixFQUFFLEdBQUlqSyxHQUFHLENBQUMwUSxNQUFNLENBQVN6RyxFQUFFO01BQ2pDLE1BQU00RyxPQUFPLEdBQUcsTUFBTSxJQUFBVSxnREFBbUMsRUFBQ1osTUFBTSxFQUFFMUcsRUFBRSxDQUFDO01BQ3JFLE9BQU9oSyxHQUFHLENBQUNxQixFQUFFLENBQUM7UUFBRWQsSUFBSSxFQUFFcVE7TUFBUSxDQUFDLENBQUM7SUFDbEMsQ0FBQyxDQUFDLE9BQU9yUCxHQUFRLEVBQUU7TUFBQSxJQUFBZ1EscUJBQUEsRUFBQUMsY0FBQSxFQUFBQyxjQUFBO01BQ2pCLE9BQU96UixHQUFHLENBQUMwQixXQUFXLENBQUM7UUFBRUMsVUFBVSxHQUFBNFAscUJBQUEsR0FBRWhRLEdBQUcsYUFBSEEsR0FBRyxnQkFBQWlRLGNBQUEsR0FBSGpRLEdBQUcsQ0FBRVIsUUFBUSxjQUFBeVEsY0FBQSx1QkFBYkEsY0FBQSxDQUFlUCxNQUFNLGNBQUFNLHFCQUFBLGNBQUFBLHFCQUFBLEdBQUksR0FBRztRQUFFaFIsSUFBSSxHQUFBa1IsY0FBQSxHQUFFbFEsR0FBRyxhQUFIQSxHQUFHLHVCQUFIQSxHQUFHLENBQUVLLE9BQU8sY0FBQTZQLGNBQUEsY0FBQUEsY0FBQSxHQUFJNVAsTUFBTSxDQUFDTixHQUFHO01BQUUsQ0FBQyxDQUFDO0lBQ3pHO0VBQ0YsQ0FDRixDQUFDOztFQUVEO0VBQ0F2QyxNQUFNLENBQUNDLEdBQUcsQ0FDUjtJQUNFQyxJQUFJLEVBQUUsNENBQTRDO0lBQ2xEQyxRQUFRLEVBQUU7TUFDUnNSLE1BQU0sRUFBRXBSLG9CQUFNLENBQUNDLE1BQU0sQ0FBQztRQUFFMEssRUFBRSxFQUFFM0ssb0JBQU0sQ0FBQ08sTUFBTSxDQUFDO01BQUUsQ0FBQyxDQUFDO01BQzlDUixLQUFLLEVBQUVDLG9CQUFNLENBQUNDLE1BQU0sQ0FBQztRQUFFcVAsV0FBVyxFQUFFdFAsb0JBQU0sQ0FBQ0csS0FBSyxDQUFDSCxvQkFBTSxDQUFDTyxNQUFNLENBQUMsQ0FBQztNQUFFLENBQUM7SUFDckU7RUFDRixDQUFDLEVBQ0QsT0FBT2xCLE9BQU8sRUFBRXFCLEdBQUcsRUFBRUMsR0FBRyxLQUFLO0lBQzNCLE1BQU0wUSxNQUFNLEdBQUcsSUFBQUMsMkJBQWMsRUFBQyxDQUFDO0lBQy9CLElBQUksQ0FBQ0QsTUFBTSxFQUFFO01BQ1gsT0FBTzFRLEdBQUcsQ0FBQzBCLFdBQVcsQ0FBQztRQUFFQyxVQUFVLEVBQUUsR0FBRztRQUFFcEIsSUFBSSxFQUFFO01BQW1DLENBQUMsQ0FBQztJQUN2RjtJQUNBLElBQUk7TUFDRixNQUFNeUosRUFBRSxHQUFJakssR0FBRyxDQUFDMFEsTUFBTSxDQUFTekcsRUFBRTtNQUNqQyxNQUFNMEgsVUFBVSxHQUFLM1IsR0FBRyxDQUFDWCxLQUFLLENBQVN1UCxXQUFXLElBQUksWUFBdUM7TUFDN0YsTUFBTWlDLE9BQU8sR0FBRyxNQUFNLElBQUFlLCtCQUFrQixFQUFDakIsTUFBTSxFQUFFMUcsRUFBRSxFQUFFMEgsVUFBVSxDQUFDO01BQ2hFLE9BQU8xUixHQUFHLENBQUNxQixFQUFFLENBQUM7UUFBRWQsSUFBSSxFQUFFcVE7TUFBUSxDQUFDLENBQUM7SUFDbEMsQ0FBQyxDQUFDLE9BQU9yUCxHQUFRLEVBQUU7TUFBQSxJQUFBcVEscUJBQUEsRUFBQUMsY0FBQSxFQUFBQyxjQUFBO01BQ2pCLE9BQU85UixHQUFHLENBQUMwQixXQUFXLENBQUM7UUFBRUMsVUFBVSxHQUFBaVEscUJBQUEsR0FBRXJRLEdBQUcsYUFBSEEsR0FBRyxnQkFBQXNRLGNBQUEsR0FBSHRRLEdBQUcsQ0FBRVIsUUFBUSxjQUFBOFEsY0FBQSx1QkFBYkEsY0FBQSxDQUFlWixNQUFNLGNBQUFXLHFCQUFBLGNBQUFBLHFCQUFBLEdBQUksR0FBRztRQUFFclIsSUFBSSxHQUFBdVIsY0FBQSxHQUFFdlEsR0FBRyxhQUFIQSxHQUFHLHVCQUFIQSxHQUFHLENBQUVLLE9BQU8sY0FBQWtRLGNBQUEsY0FBQUEsY0FBQSxHQUFJalEsTUFBTSxDQUFDTixHQUFHO01BQUUsQ0FBQyxDQUFDO0lBQ3pHO0VBQ0YsQ0FDRixDQUFDOztFQUVEO0VBQ0F2QyxNQUFNLENBQUNDLEdBQUcsQ0FDUjtJQUNFQyxJQUFJLEVBQUUsc0NBQXNDO0lBQzVDQyxRQUFRLEVBQUU7RUFDWixDQUFDLEVBQ0QsT0FBT1QsT0FBTyxFQUFFcUIsR0FBRyxFQUFFQyxHQUFHLEtBQUs7SUFDM0IsSUFBSTtNQUFBLElBQUErUixZQUFBLEVBQUFDLGdCQUFBO01BQ0YsTUFBTW5ULE1BQU0sR0FBR0osU0FBUyxDQUFDQyxPQUFPLENBQUM7TUFDakMsTUFBTXFDLFFBQVEsR0FBRyxNQUFNbEMsTUFBTSxDQUFDbUMsTUFBTSxDQUFDO1FBQ25DQyxLQUFLLEVBQUVnUix5Q0FBOEI7UUFDckM5USxrQkFBa0IsRUFBRSxJQUFJO1FBQ3hCWixJQUFJLEVBQUU7VUFDSmhCLElBQUksRUFBRSxHQUFHO1VBQ1RpQixJQUFJLEVBQUUsQ0FBQztZQUFFLHNCQUFzQixFQUFFO2NBQUVFLEtBQUssRUFBRSxLQUFLO2NBQUU0QixPQUFPLEVBQUU7WUFBUTtVQUFFLENBQUMsQ0FBQztVQUN0RWxELEtBQUssRUFBRTtZQUFFMEIsU0FBUyxFQUFFLENBQUM7VUFBRSxDQUFDO1VBQ3hCMkIsT0FBTyxFQUFFLENBQUMsb0JBQW9CLEVBQUUsY0FBYztRQUNoRDtNQUNGLENBQUMsQ0FBQztNQUNGLE1BQU1yQixJQUFJLElBQUEyUSxZQUFBLElBQUFDLGdCQUFBLEdBQUlqUixRQUFRLENBQUNSLElBQUksY0FBQXlSLGdCQUFBLGdCQUFBQSxnQkFBQSxHQUFkQSxnQkFBQSxDQUF3QjVRLElBQUksY0FBQTRRLGdCQUFBLHVCQUE1QkEsZ0JBQUEsQ0FBOEI1USxJQUFJLGNBQUEyUSxZQUFBLGNBQUFBLFlBQUEsR0FBSSxFQUFFO01BQ3JELE1BQU1HLFVBQVUsR0FBRzlRLElBQUksQ0FBQzBELEdBQUcsQ0FBRUMsQ0FBTSxJQUFLQSxDQUFDLENBQUN0QyxPQUFPLENBQUMsQ0FBQ3VDLE1BQU0sQ0FBQ0MsT0FBTyxDQUFDO01BQ2xFLE9BQU9qRixHQUFHLENBQUNxQixFQUFFLENBQUM7UUFBRWQsSUFBSSxFQUFFO1VBQUUyUjtRQUFXO01BQUUsQ0FBQyxDQUFDO0lBQ3pDLENBQUMsQ0FBQyxPQUFPM1EsR0FBUSxFQUFFO01BQ2pCLE9BQU92QixHQUFHLENBQUNxQixFQUFFLENBQUM7UUFBRWQsSUFBSSxFQUFFO1VBQUUyUixVQUFVLEVBQUU7UUFBRztNQUFFLENBQUMsQ0FBQztJQUM3QztFQUNGLENBQ0YsQ0FBQzs7RUFFRDtFQUNBbFQsTUFBTSxDQUFDQyxHQUFHLENBQ1I7SUFDRUMsSUFBSSxFQUFFLDJCQUEyQjtJQUNqQ0MsUUFBUSxFQUFFO0VBQ1osQ0FBQyxFQUNELE9BQU9ULE9BQU8sRUFBRXFCLEdBQUcsRUFBRUMsR0FBRyxLQUFLO0lBQzNCLE9BQU9BLEdBQUcsQ0FBQ3FCLEVBQUUsQ0FBQztNQUFFZCxJQUFJLEVBQUU7UUFBRTBRLE1BQU0sRUFBRSxJQUFJO1FBQUVrQixNQUFNLEVBQUU7TUFBZTtJQUFFLENBQUMsQ0FBQztFQUNuRSxDQUNGLENBQUM7QUFDSCJ9