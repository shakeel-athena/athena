# Athena Integrations

This repository contains integrations, alert processing pipelines, enrichment services, and automation scripts used by the Athena security platform.

It centralizes connectors and operational tooling for security data sources and services such as Wazuh, AWS GuardDuty, GitHub, NIDS alerts, VirusTotal, and other external systems. It also includes scheduled reporting jobs and notification handlers used for daily, weekly, and monthly security reporting.

## Modules

- **notifications/** – NIDS and SIEM alert notification pipelines
- **reporting/** – Daily, weekly, and monthly reporting jobs for SIEM and NIDS data
- **connectors/** – External integrations such as GitHub (Dependabot), GuardDuty, and other security data sources