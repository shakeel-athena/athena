#!/var/ossec/framework/python/bin/python3
# -*- coding: utf-8 -*-
"""
Athena SOC - Compliance Summary Email & HTML Report Generator

This module generates per-standard compliance reports (one report per enabled framework):
- For each compliance standard enabled for a Client (PCI DSS, GDPR, HIPAA, NIST 800-53, TSC),
  one dedicated compliance report is generated and sent per run
- Each report includes: top active agents, inactive agents (>24 hours), that framework's
  control violations, and AI-generated insights
- Enable/disable frameworks per Client via complianceConfig or env vars

Reuses existing reporting module patterns for branding, email sending, and HTML templates.
"""

import json
import sys
import time
import os
import smtplib
import html
from datetime import datetime, timedelta, timezone
from urllib.parse import quote
from email.message import EmailMessage
from email.utils import formataddr
from collections import defaultdict
from dotenv import load_dotenv

load_dotenv()


# === CONFIGURATION FROM ENVIRONMENT ===
ATHENA_NAME = os.getenv("ATHENA_NAME", "Athena SOC")
TENANT_NAME = os.getenv("TENANT_NAME", "test.athenasecuritygrp.com")
ATHENA_WEBSITE = os.getenv("ATHENA_WEBSITE", "https://athenasoftwaregroup.ai/")
ATHENA_DOCS = os.getenv("ATHENA_DOCS", "https://athenasoftwaregroup.ai/")
ATHENA_SUPPORT = os.getenv("ATHENA_SUPPORT", "alerts@athena.athenasecuritygrp.com")
DASHBOARD_BASE_URL = os.getenv("DASHBOARD_BASE_URL", "https://test.athenasecuritygrp.com")

# === SMTP CONFIGURATION ===
SMTP_HOST = os.getenv("SMTP_HOST", "smtp.office365.com")
SMTP_PORT = int(os.getenv("SMTP_PORT", "587"))
SMTP_USE_TLS = os.getenv("SMTP_USE_TLS", "true").lower() == "true"
SMTP_USE_SSL = os.getenv("SMTP_USE_SSL", "false").lower() == "true"
SMTP_USERNAME = os.getenv("SMTP_USERNAME", "alerts@athenasoftwaregrp.com")
SMTP_PASSWORD = os.getenv("SMTP_PASSWORD", "")
SMTP_FROM = os.getenv("SMTP_FROM", "alerts@athena.athenasecuritygrp.com")
SMTP_RECIPIENT = os.getenv("SMTP_RECIPIENT", "secops@athena.athenasecuritygrp.com").split(",")
# Sender display name for compliance report emails (may be overridden by mail server)
COMPLIANCE_REPORT_FROM_NAME = os.getenv("COMPLIANCE_REPORT_FROM_NAME", "Athena Compliance Report")

# === OLLAMA CONFIGURATION ===
OLLAMA_HOST = os.getenv("OLLAMA_HOST", "localhost")
OLLAMA_PORT = os.getenv("OLLAMA_PORT", "11434")
OLLAMA_MODEL = os.getenv("OLLAMA_MODEL", "qwen2.5:14b-instruct")
OLLAMA_ENABLED = os.getenv("OLLAMA_ENABLED", "true").lower() == "true"
OLLAMA_API_URL = f"http://{OLLAMA_HOST}:{OLLAMA_PORT}/v1/chat/completions"

# === ELASTICSEARCH CONFIGURATION ===
ES_HOST = os.getenv("ES_HOST", "https://localhost:9200")
ES_USERNAME = os.getenv("ES_USERNAME", "")
ES_PASSWORD = os.getenv("ES_PASSWORD", "")
ES_INDEX_PATTERN = os.getenv("ES_INDEX_PATTERN_SIEM", "athena-alerts-*")
ES_VERIFY_SSL = os.getenv("ES_VERIFY_SSL", "false").lower() == "true"


# === COMPLIANCE CONFIGURATION FROM ENVIRONMENT ===
# Enable/disable specific compliance frameworks
COMPLIANCE_ENABLE_PCI_DSS = os.getenv("COMPLIANCE_ENABLE_PCI_DSS", "true").lower() == "true"
COMPLIANCE_ENABLE_GDPR = os.getenv("COMPLIANCE_ENABLE_GDPR", "true").lower() == "true"
COMPLIANCE_ENABLE_HIPAA = os.getenv("COMPLIANCE_ENABLE_HIPAA", "true").lower() == "true"
COMPLIANCE_ENABLE_NIST_800_53 = os.getenv("COMPLIANCE_ENABLE_NIST_800_53", "true").lower() == "true"
COMPLIANCE_ENABLE_TSC = os.getenv("COMPLIANCE_ENABLE_TSC", "true").lower() == "true"
COMPLIANCE_TOP_AGENTS_COUNT = int(os.getenv("COMPLIANCE_TOP_AGENTS_COUNT", "5"))
COMPLIANCE_INACTIVE_THRESHOLD_HOURS = int(os.getenv("COMPLIANCE_INACTIVE_THRESHOLD_HOURS", "24"))
# KQL applied on agents-preview when clicking Inactive Agents (endpoints-summary). Override if your index uses a different field.
AGENTS_PREVIEW_STATUS_KQL = os.getenv("AGENTS_PREVIEW_STATUS_KQL", "status: disconnected")

# === DEFAULT COMPLIANCE CONFIGURATION ===
DEFAULT_COMPLIANCE_CONFIG = {
    "enablePciDss": COMPLIANCE_ENABLE_PCI_DSS,
    "enableGdpr": COMPLIANCE_ENABLE_GDPR,
    "enableHipaa": COMPLIANCE_ENABLE_HIPAA,
    "enableNist80053": COMPLIANCE_ENABLE_NIST_800_53,
    "enableTsc": COMPLIANCE_ENABLE_TSC,
    "topAgentsCount": COMPLIANCE_TOP_AGENTS_COUNT,
    "inactiveThresholdHours": COMPLIANCE_INACTIVE_THRESHOLD_HOURS
}


# === LOGGING ===
pwd = os.path.dirname(os.path.realpath(__file__))
logFile = f"{pwd}/logs/compliance_reporting.log"


def log(msg: str):
    """Log message to console and file"""
    now = time.strftime("%a %b %d %H:%M:%S %Z %Y")
    line = f"{now}: {msg}\n"
    print(line, end="")
    try:
        os.makedirs(os.path.dirname(logFile), exist_ok=True)
        with open(logFile, "a") as f:
            f.write(line)
    except Exception:
        pass


# === PROFESSIONAL COLOR SCHEME (Reused from existing reports) ===
def getColorScheme():
    """Return the professional color scheme used across all reports"""
    return {
        "primary": "#1e40af",
        "secondary": "#64748b",
        "success": "#059669",
        "warning": "#d97706",
        "danger": "#dc2626",
        "info": "#0284c7",
        "light": "#f8fafc",
        "dark": "#1e293b",
        "border": "#e2e8f0",
        "text": "#374151",
        "textLight": "#6b7280"
    }


# === ELASTICSEARCH QUERIES ===
def queryTopActiveAgents(timeFrom, timeTo, topCount=10):
    """Query Elasticsearch for top active agents based on alert volume"""
    try:
        import requests
        from requests.auth import HTTPBasicAuth
        import urllib3
        
        if not ES_VERIFY_SSL:
            urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
        
        query = {
            "size": 0,
            "query": {
                "bool": {
                    "must": [
                        {
                            "range": {
                                "timestamp": {
                                    "gte": timeFrom,
                                    "lte": timeTo,
                                    "format": "strict_date_optional_time"
                                }
                            }
                        }
                    ]
                }
            },
            "aggs": {
                "topAgents": {
                    "terms": {
                        "field": "agent.name",
                        "size": topCount
                    },
                    "aggs": {
                        "agentId": {
                            "terms": {
                                "field": "agent.id",
                                "size": 1
                            }
                        },
                        "severityBreakdown": {
                            "terms": {
                                "script": {
                                    "source": """
                                        def level = doc['rule.level'].value;
                                        if (level >= 15) return 'Critical';
                                        else if (level >= 12) return 'High';
                                        else if (level >= 7) return 'Medium';
                                        else return 'Low';
                                    """
                                },
                                "size": 10
                            }
                        },
                        "alertTimeline": {
                            "date_histogram": {
                                "field": "timestamp",
                                "calendar_interval": "day",
                                "min_doc_count": 0
                            }
                        }
                    }
                }
            }
        }
        
        log("Querying top active agents...")
        
        response = requests.post(
            f"{ES_HOST}/{ES_INDEX_PATTERN}/_search",
            json=query,
            auth=HTTPBasicAuth(ES_USERNAME, ES_PASSWORD),
            verify=ES_VERIFY_SSL,
            timeout=30
        )
        
        if response.status_code == 200:
            data = response.json()
            aggregations = data.get("aggregations", {})
            log(f"Retrieved top active agents data")
            return aggregations
        else:
            log(f"Top active agents query failed: {response.status_code} - {response.text}")
            return {}
            
    except Exception as e:
        log(f"Error querying top active agents: {e}")
        return {}


def queryAllAgents():
    """Query Elasticsearch for all known agents and their last activity"""
    try:
        import requests
        from requests.auth import HTTPBasicAuth
        import urllib3
        
        if not ES_VERIFY_SSL:
            urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
        
        # Query for all agents with their last activity timestamp
        # Include multiple OS fields to improve detection
        query = {
            "size": 0,
            "aggs": {
                "allAgents": {
                    "terms": {
                        "field": "agent.name",
                        "size": 1000
                    },
                    "aggs": {
                        "agentId": {
                            "terms": {
                                "field": "agent.id",
                                "size": 1
                            }
                        },
                        "lastSeen": {
                            "max": {
                                "field": "timestamp"
                            }
                        },
                        "hostOs": {
                            "terms": {
                                "field": "agent.os.name",
                                "size": 1
                            }
                        },
                        "hostOsPlatform": {
                            "terms": {
                                "field": "agent.os.platform",
                                "size": 1
                            }
                        },
                        "hostOsFull": {
                            "terms": {
                                "field": "agent.os.full",
                                "size": 1
                            }
                        },
                        "hostOsType": {
                            "terms": {
                                "field": "host.os.type",
                                "size": 1
                            }
                        },
                        "hostOsName": {
                            "terms": {
                                "field": "host.os.name",
                                "size": 1
                            }
                        },
                        "hostOsFamily": {
                            "terms": {
                                "field": "host.os.family",
                                "size": 1
                            }
                        },
                        "sysCheckOs": {
                            "terms": {
                                "field": "syscheck.uname_after",
                                "size": 1
                            }
                        }
                    }
                }
            }
        }
        
        log("Querying all agents for inactive detection...")
        
        response = requests.post(
            f"{ES_HOST}/{ES_INDEX_PATTERN}/_search",
            json=query,
            auth=HTTPBasicAuth(ES_USERNAME, ES_PASSWORD),
            verify=ES_VERIFY_SSL,
            timeout=30
        )
        
        if response.status_code == 200:
            data = response.json()
            aggregations = data.get("aggregations", {})
            log(f"Retrieved all agents data")
            return aggregations
        else:
            log(f"All agents query failed: {response.status_code} - {response.text}")
            return {}
            
    except Exception as e:
        log(f"Error querying all agents: {e}")
        return {}


def queryComplianceData(timeFrom, timeTo, complianceConfig):
    """Query Elasticsearch for compliance framework data"""
    try:
        import requests
        from requests.auth import HTTPBasicAuth
        import urllib3
        
        if not ES_VERIFY_SSL:
            urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
        
        # Build dynamic compliance aggregations based on config
        complianceAggs = {}
        
        if complianceConfig.get("enablePciDss", True):
            complianceAggs["pciDss"] = {
                "filter": {"exists": {"field": "rule.pci_dss"}},
                "aggs": {
                    "totalAlerts": {"value_count": {"field": "rule.id"}},
                    "uniqueRules": {"cardinality": {"field": "rule.id"}},
                    "topRules": {
                        "terms": {"field": "rule.id", "size": 6},
                        "aggs": {"ruleDesc": {"terms": {"field": "rule.description", "size": 1}}}
                    },
                    "alertsTimeline": {
                        "date_histogram": {"field": "timestamp", "calendar_interval": "day", "min_doc_count": 0}
                    },
                    "topControls": {
                        "terms": {"field": "rule.pci_dss", "size": 10},
                        "aggs": {"topAgentsPerControl": {"terms": {"field": "agent.name", "size": 3}}}
                    },
                    "affectedAgents": {"terms": {"field": "agent.name", "size": 10}},
                    "severityBreakdown": {
                        "terms": {
                            "script": {
                                "source": """
                                    def level = doc['rule.level'].value;
                                    if (level >= 15) return 'Critical';
                                    else if (level >= 12) return 'High';
                                    else if (level >= 7) return 'Medium';
                                    else return 'Low';
                                """
                            },
                            "size": 4
                        }
                    }
                }
            }
        
        if complianceConfig.get("enableGdpr", True):
            complianceAggs["gdpr"] = {
                "filter": {"exists": {"field": "rule.gdpr"}},
                "aggs": {
                    "totalAlerts": {"value_count": {"field": "rule.id"}},
                    "uniqueRules": {"cardinality": {"field": "rule.id"}},
                    "topRules": {
                        "terms": {"field": "rule.id", "size": 6},
                        "aggs": {
                            "ruleDesc": {"terms": {"field": "rule.description", "size": 1}}
                        }
                    },
                    "alertsTimeline": {
                        "date_histogram": {"field": "timestamp", "calendar_interval": "day", "min_doc_count": 0}
                    },
                    "topControls": {
                        "terms": {"field": "rule.gdpr", "size": 10},
                        "aggs": {
                            "topAgentsPerControl": {"terms": {"field": "agent.name", "size": 3}}
                        }
                    },
                    "affectedAgents": {
                        "terms": {"field": "agent.name", "size": 10}
                    },
                    "severityBreakdown": {
                        "terms": {
                            "script": {
                                "source": """
                                    def level = doc['rule.level'].value;
                                    if (level >= 15) return 'Critical';
                                    else if (level >= 12) return 'High';
                                    else if (level >= 7) return 'Medium';
                                    else return 'Low';
                                """
                            },
                            "size": 4
                        }
                    }
                }
            }
        
        if complianceConfig.get("enableHipaa", True):
            complianceAggs["hipaa"] = {
                "filter": {"exists": {"field": "rule.hipaa"}},
                "aggs": {
                    "totalAlerts": {"value_count": {"field": "rule.id"}},
                    "uniqueRules": {"cardinality": {"field": "rule.id"}},
                    "topRules": {
                        "terms": {"field": "rule.id", "size": 6},
                        "aggs": {"ruleDesc": {"terms": {"field": "rule.description", "size": 1}}}
                    },
                    "alertsTimeline": {
                        "date_histogram": {"field": "timestamp", "calendar_interval": "day", "min_doc_count": 0}
                    },
                    "topControls": {
                        "terms": {"field": "rule.hipaa", "size": 10},
                        "aggs": {"topAgentsPerControl": {"terms": {"field": "agent.name", "size": 3}}}
                    },
                    "affectedAgents": {"terms": {"field": "agent.name", "size": 10}},
                    "severityBreakdown": {
                        "terms": {
                            "script": {
                                "source": """
                                    def level = doc['rule.level'].value;
                                    if (level >= 15) return 'Critical';
                                    else if (level >= 12) return 'High';
                                    else if (level >= 7) return 'Medium';
                                    else return 'Low';
                                """
                            },
                            "size": 4
                        }
                    }
                }
            }
        
        if complianceConfig.get("enableNist80053", True):
            complianceAggs["nist80053"] = {
                "filter": {"exists": {"field": "rule.nist_800_53"}},
                "aggs": {
                    "totalAlerts": {"value_count": {"field": "rule.id"}},
                    "uniqueRules": {"cardinality": {"field": "rule.id"}},
                    "topRules": {
                        "terms": {"field": "rule.id", "size": 6},
                        "aggs": {"ruleDesc": {"terms": {"field": "rule.description", "size": 1}}}
                    },
                    "alertsTimeline": {
                        "date_histogram": {"field": "timestamp", "calendar_interval": "day", "min_doc_count": 0}
                    },
                    "topControls": {
                        "terms": {"field": "rule.nist_800_53", "size": 10},
                        "aggs": {"topAgentsPerControl": {"terms": {"field": "agent.name", "size": 3}}}
                    },
                    "affectedAgents": {"terms": {"field": "agent.name", "size": 10}},
                    "severityBreakdown": {
                        "terms": {
                            "script": {
                                "source": """
                                    def level = doc['rule.level'].value;
                                    if (level >= 15) return 'Critical';
                                    else if (level >= 12) return 'High';
                                    else if (level >= 7) return 'Medium';
                                    else return 'Low';
                                """
                            },
                            "size": 4
                        }
                    }
                }
            }
        
        if complianceConfig.get("enableTsc", True):
            complianceAggs["tsc"] = {
                "filter": {"exists": {"field": "rule.tsc"}},
                "aggs": {
                    "totalAlerts": {"value_count": {"field": "rule.id"}},
                    "uniqueRules": {"cardinality": {"field": "rule.id"}},
                    "topRules": {
                        "terms": {"field": "rule.id", "size": 6},
                        "aggs": {"ruleDesc": {"terms": {"field": "rule.description", "size": 1}}}
                    },
                    "alertsTimeline": {
                        "date_histogram": {"field": "timestamp", "calendar_interval": "day", "min_doc_count": 0}
                    },
                    "topControls": {
                        "terms": {"field": "rule.tsc", "size": 10},
                        "aggs": {"topAgentsPerControl": {"terms": {"field": "agent.name", "size": 3}}}
                    },
                    "affectedAgents": {"terms": {"field": "agent.name", "size": 10}},
                    "severityBreakdown": {
                        "terms": {
                            "script": {
                                "source": """
                                    def level = doc['rule.level'].value;
                                    if (level >= 15) return 'Critical';
                                    else if (level >= 12) return 'High';
                                    else if (level >= 7) return 'Medium';
                                    else return 'Low';
                                """
                            },
                            "size": 4
                        }
                    }
                }
            }
        
        if not complianceAggs:
            log("No compliance frameworks enabled in configuration")
            return {}
        
        query = {
            "size": 0,
            "query": {
                "bool": {
                    "must": [
                        {
                            "range": {
                                "timestamp": {
                                    "gte": timeFrom,
                                    "lte": timeTo,
                                    "format": "strict_date_optional_time"
                                }
                            }
                        }
                    ]
                }
            },
            "aggs": complianceAggs
        }
        
        log(f"Querying compliance data for enabled frameworks...")
        
        response = requests.post(
            f"{ES_HOST}/{ES_INDEX_PATTERN}/_search",
            json=query,
            auth=HTTPBasicAuth(ES_USERNAME, ES_PASSWORD),
            verify=ES_VERIFY_SSL,
            timeout=30
        )
        
        if response.status_code == 200:
            data = response.json()
            aggregations = data.get("aggregations", {})
            log(f"Retrieved compliance data")
            return aggregations
        else:
            log(f"Compliance query failed: {response.status_code} - {response.text}")
            return {}
            
    except Exception as e:
        log(f"Error querying compliance data: {e}")
        return {}


def queryOverallStats(timeFrom, timeTo):
    """Query overall alert statistics for the time period"""
    try:
        import requests
        from requests.auth import HTTPBasicAuth
        import urllib3
        
        if not ES_VERIFY_SSL:
            urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
        
        query = {
            "size": 0,
            "query": {
                "bool": {
                    "must": [
                        {
                            "range": {
                                "timestamp": {
                                    "gte": timeFrom,
                                    "lte": timeTo,
                                    "format": "strict_date_optional_time"
                                }
                            }
                        }
                    ]
                }
            },
            "aggs": {
                "totalAlerts": {
                    "value_count": {"field": "rule.id"}
                },
                "severityBreakdown": {
                    "terms": {
                        "script": {
                            "source": """
                                def level = doc['rule.level'].value;
                                if (level >= 15) return 'Critical';
                                else if (level >= 12) return 'High';
                                else if (level >= 7) return 'Medium';
                                else return 'Low';
                            """
                        },
                        "size": 10
                    }
                },
                "uniqueAgents": {
                    "cardinality": {"field": "agent.name"}
                },
                "uniqueRules": {
                    "cardinality": {"field": "rule.id"}
                }
            }
        }
        
        log("Querying overall statistics...")
        
        response = requests.post(
            f"{ES_HOST}/{ES_INDEX_PATTERN}/_search",
            json=query,
            auth=HTTPBasicAuth(ES_USERNAME, ES_PASSWORD),
            verify=ES_VERIFY_SSL,
            timeout=30
        )
        
        if response.status_code == 200:
            data = response.json()
            aggregations = data.get("aggregations", {})
            log(f"Retrieved overall statistics")
            return aggregations
        else:
            log(f"Overall stats query failed: {response.status_code} - {response.text}")
            return {}
            
    except Exception as e:
        log(f"Error querying overall stats: {e}")
        return {}


# === DATA PROCESSING ===
def processTopActiveAgents(aggregations):
    """Process top active agents from aggregations"""
    topAgents = []
    
    agentBuckets = aggregations.get("topAgents", {}).get("buckets", [])
    for bucket in agentBuckets:
        agentName = bucket.get("key", "Unknown")
        alertCount = bucket.get("doc_count", 0)
        
        # Get agent ID
        agentIdBuckets = bucket.get("agentId", {}).get("buckets", [])
        agentId = agentIdBuckets[0].get("key", "N/A") if agentIdBuckets else "N/A"
        
        # Get severity breakdown
        severityBuckets = bucket.get("severityBreakdown", {}).get("buckets", [])
        severityBreakdown = {}
        for sevBucket in severityBuckets:
            severity = sevBucket.get("key", "Unknown")
            count = sevBucket.get("doc_count", 0)
            severityBreakdown[severity] = count
        
        # Get alert timeline for sparkline
        timelineBuckets = bucket.get("alertTimeline", {}).get("buckets", [])
        timeline = [tb.get("doc_count", 0) for tb in timelineBuckets]
        
        topAgents.append({
            "name": agentName,
            "id": agentId,
            "alertCount": alertCount,
            "critical": severityBreakdown.get("Critical", 0),
            "high": severityBreakdown.get("High", 0),
            "medium": severityBreakdown.get("Medium", 0),
            "low": severityBreakdown.get("Low", 0),
            "timeline": timeline
        })
    
    return topAgents


def processInactiveAgents(aggregations, inactiveThresholdHours=24):
    """Process inactive agents (no events in specified hours)
    
    Categorizes agents into:
    - Abandoned: No heartbeat for more than 7 days (168+ hours)
    - Inactive 3+ days: No heartbeat for 3-7 days (72-168 hours)
    - Inactive 24+ hours: No heartbeat for 24-72 hours
    """
    inactiveAgents = []
    
    now = datetime.now(timezone.utc).replace(tzinfo=None)
    thresholdTime = now - timedelta(hours=inactiveThresholdHours)
    
    agentBuckets = aggregations.get("allAgents", {}).get("buckets", [])
    for bucket in agentBuckets:
        agentName = bucket.get("key", "Unknown")
        
        # Get agent ID
        agentIdBuckets = bucket.get("agentId", {}).get("buckets", [])
        agentId = agentIdBuckets[0].get("key", "N/A") if agentIdBuckets else "N/A"
        
        # Get last seen timestamp
        lastSeenMs = bucket.get("lastSeen", {}).get("value")
        if lastSeenMs:
            lastSeenDt = datetime.fromtimestamp(lastSeenMs / 1000, tz=timezone.utc).replace(tzinfo=None)
            
            # Check if agent is inactive
            if lastSeenDt < thresholdTime:
                # Get host OS - try multiple fields for better detection
                hostOs = ""
                
                # Try agent.os.name first
                hostOsBuckets = bucket.get("hostOs", {}).get("buckets", [])
                if hostOsBuckets:
                    hostOs = hostOsBuckets[0].get("key", "")
                
                # Try agent.os.full
                if not hostOs:
                    hostOsFullBuckets = bucket.get("hostOsFull", {}).get("buckets", [])
                    if hostOsFullBuckets:
                        hostOs = hostOsFullBuckets[0].get("key", "")
                
                # Try agent.os.platform
                if not hostOs:
                    platformBuckets = bucket.get("hostOsPlatform", {}).get("buckets", [])
                    if platformBuckets:
                        hostOs = platformBuckets[0].get("key", "")
                
                # Try host.os.name
                if not hostOs:
                    hostOsNameBuckets = bucket.get("hostOsName", {}).get("buckets", [])
                    if hostOsNameBuckets:
                        hostOs = hostOsNameBuckets[0].get("key", "")
                
                # Try host.os.type
                if not hostOs:
                    hostOsTypeBuckets = bucket.get("hostOsType", {}).get("buckets", [])
                    if hostOsTypeBuckets:
                        hostOs = hostOsTypeBuckets[0].get("key", "")
                
                # Try host.os.family
                if not hostOs:
                    hostOsFamilyBuckets = bucket.get("hostOsFamily", {}).get("buckets", [])
                    if hostOsFamilyBuckets:
                        hostOs = hostOsFamilyBuckets[0].get("key", "")
                
                # Try syscheck.uname_after (contains OS info)
                if not hostOs:
                    sysCheckOsBuckets = bucket.get("sysCheckOs", {}).get("buckets", [])
                    if sysCheckOsBuckets:
                        uname = sysCheckOsBuckets[0].get("key", "")
                        # Extract OS from uname string
                        if uname:
                            if "linux" in uname.lower():
                                hostOs = "Linux"
                            elif "darwin" in uname.lower() or "macos" in uname.lower():
                                hostOs = "macOS"
                            elif "windows" in uname.lower():
                                hostOs = "Windows"
                            else:
                                hostOs = uname[:50] if len(uname) > 50 else uname
                
                # Default to Unknown if nothing found
                if not hostOs:
                    hostOs = "Unknown"
                
                # Calculate hours since last seen
                hoursSinceLastSeen = int((now - lastSeenDt).total_seconds() / 3600)
                
                # Skip agents inactive for more than 30 days (too old to be relevant)
                if hoursSinceLastSeen > 720:  # 30 days = 720 hours
                    continue
                
                # Determine category based on hours
                # Category priority: 1 = Inactive 24+ hours, 2 = Inactive 3+ days, 3 = Abandoned (7+ days)
                if hoursSinceLastSeen >= 168:  # 7 days = 168 hours
                    category = "Abandoned"
                    categoryPriority = 3
                    categoryDescription = "No heartbeat for 7+ days"
                elif hoursSinceLastSeen >= 72:  # 3 days = 72 hours
                    category = "Inactive 3+ days"
                    categoryPriority = 2
                    categoryDescription = "No heartbeat for 3-7 days"
                else:  # 24-72 hours
                    category = "Inactive 24+ hours"
                    categoryPriority = 1
                    categoryDescription = "No heartbeat for 24-72 hours"
                
                inactiveAgents.append({
                    "name": agentName,
                    "id": agentId,
                    "lastSeen": lastSeenDt.isoformat() + "Z",
                    "lastSeenFormatted": lastSeenDt.strftime("%Y-%m-%d %H:%M UTC"),
                    "hostOs": hostOs,
                    "hoursSinceLastSeen": hoursSinceLastSeen,
                    "category": category,
                    "categoryPriority": categoryPriority,
                    "categoryDescription": categoryDescription
                })
    
    # Sort by category priority first (Abandoned first), then by hours since last seen within each category
    inactiveAgents.sort(key=lambda x: (x["categoryPriority"], -x["hoursSinceLastSeen"]))
    
    return inactiveAgents


def processComplianceData(aggregations, complianceConfig):
    """Process compliance framework data"""
    complianceData = {}
    
    frameworkMapping = {
        "pciDss": {"enabled": complianceConfig.get("enablePciDss", True), "displayName": "PCI DSS", "key": "pciDss"},
        "gdpr": {"enabled": complianceConfig.get("enableGdpr", True), "displayName": "GDPR", "key": "gdpr"},
        "hipaa": {"enabled": complianceConfig.get("enableHipaa", True), "displayName": "HIPAA", "key": "hipaa"},
        "nist80053": {"enabled": complianceConfig.get("enableNist80053", True), "displayName": "NIST 800-53", "key": "nist80053"},
        "tsc": {"enabled": complianceConfig.get("enableTsc", True), "displayName": "TSC", "key": "tsc"}
    }
    
    for frameworkKey, frameworkInfo in frameworkMapping.items():
        if not frameworkInfo["enabled"]:
            continue
        
        frameworkAgg = aggregations.get(frameworkKey, {})
        if not frameworkAgg:
            continue
        
        totalAlerts = frameworkAgg.get("totalAlerts", {}).get("value", 0)
        uniqueRules = frameworkAgg.get("uniqueRules", {}).get("value", 0)
        
        # Get top controls with per-control agent breakdown
        topControls = []
        controlBuckets = frameworkAgg.get("topControls", {}).get("buckets", [])
        for bucket in controlBuckets:
            control = bucket.get("key", "Unknown")
            count = bucket.get("doc_count", 0)
            agentBuckets = bucket.get("topAgentsPerControl", {}).get("buckets", [])
            topAgentsForControl = [{"agent": b["key"], "count": b["doc_count"]} for b in agentBuckets[:3]]
            topControls.append({"control": control, "count": count, "topAgents": topAgentsForControl})
        
        # Get affected agents
        affectedAgents = []
        agentBuckets = frameworkAgg.get("affectedAgents", {}).get("buckets", [])
        for bucket in agentBuckets:
            agent = bucket.get("key", "Unknown")
            count = bucket.get("doc_count", 0)
            affectedAgents.append({"agent": agent, "count": count})
        
        # Get severity breakdown
        severityBreakdown = {}
        severityBuckets = frameworkAgg.get("severityBreakdown", {}).get("buckets", [])
        for bucket in severityBuckets:
            severity = bucket.get("key", "Unknown")
            count = bucket.get("doc_count", 0)
            severityBreakdown[severity] = count
        
        # Get top rules (rule ID + description)
        topRules = []
        ruleBuckets = frameworkAgg.get("topRules", {}).get("buckets", [])
        for bucket in ruleBuckets:
            ruleId = bucket.get("key", "Unknown")
            count = bucket.get("doc_count", 0)
            descBuckets = bucket.get("ruleDesc", {}).get("buckets", [])
            desc = str(descBuckets[0].get("key", "")) if descBuckets else ""
            topRules.append({"ruleId": ruleId, "count": count, "description": desc})
        
        # Get alerts timeline for sparkline
        timelineBuckets = frameworkAgg.get("alertsTimeline", {}).get("buckets", [])
        alertsTimeline = [b.get("doc_count", 0) for b in timelineBuckets]
        
        complianceData[frameworkKey] = {
            "displayName": frameworkInfo["displayName"],
            "totalAlerts": totalAlerts,
            "uniqueRules": uniqueRules,
            "topControls": topControls[:10],
            "affectedAgents": affectedAgents[:10],
            "severityBreakdown": severityBreakdown,
            "topRules": topRules[:6],
            "alertsTimeline": alertsTimeline
        }
    
    return complianceData


def processOverallStats(aggregations):
    """Process overall statistics"""
    stats = {
        "totalAlerts": aggregations.get("totalAlerts", {}).get("value", 0),
        "uniqueAgents": aggregations.get("uniqueAgents", {}).get("value", 0),
        "uniqueRules": aggregations.get("uniqueRules", {}).get("value", 0),
        "bySeverity": {}
    }
    
    severityBuckets = aggregations.get("severityBreakdown", {}).get("buckets", [])
    for bucket in severityBuckets:
        severity = bucket.get("key", "Unknown")
        count = bucket.get("doc_count", 0)
        stats["bySeverity"][severity] = count
    
    return stats


# === OLLAMA INTEGRATION ===
# Framework-specific context to guide AI toward standards-centric, in-depth insights
FRAMEWORK_CONTEXT = {
    "pciDss": {
        "name": "PCI DSS",
        "scope": "Payment Card Industry Data Security Standard - protects cardholder data and payment systems",
        "focus": "Access control, log monitoring, encryption, network security, vulnerability management. Key areas: Requirement 10 (logging), 11 (testing), 12 (policies).",
    },
    "gdpr": {
        "name": "GDPR",
        "scope": "General Data Protection Regulation - EU data privacy and protection",
        "focus": "Data protection, consent, breach notification, data processing, rights of data subjects. Key areas: Art 32 (security), 33 (breach), 35 (DPIA).",
    },
    "hipaa": {
        "name": "HIPAA",
        "scope": "Health Insurance Portability and Accountability Act - protects health information",
        "focus": "PHI protection, access controls, audit controls, integrity. Key areas: 164.308 (administrative), 164.312 (technical safeguards).",
    },
    "nist80053": {
        "name": "NIST 800-53",
        "scope": "NIST SP 800-53 - Security and privacy controls for federal systems",
        "focus": "Access control, audit, identification, incident response, system integrity. Control families: AC, AU, IA, IR, SI.",
    },
    "tsc": {
        "name": "TSC",
        "scope": "Trust Services Criteria (AICPA) - security, availability, confidentiality",
        "focus": "Control environment, risk assessment, monitoring. Categories: security, availability, processing integrity.",
    },
}


def generateAiInsights(reportData, timeFrom, timeTo, frameworkKey=None, frameworkDisplayName=None):
    """Generate AI-powered compliance insights using Ollama.
    When frameworkKey is provided, insights are STRICTLY limited to that compliance standard only."""
    if not OLLAMA_ENABLED:
        log("Ollama is disabled")
        return None
    
    try:
        import requests
        
        # Prepare data summary for AI
        overallStats = reportData.get("overallStats", {})
        topAgents = reportData.get("topAgents", [])
        inactiveAgents = reportData.get("inactiveAgents", [])
        complianceData = reportData.get("complianceData", {})
        
        # When framework-specific: use ONLY that framework's data
        if frameworkKey and frameworkDisplayName:
            complianceData = {k: v for k, v in complianceData.items() if k == frameworkKey}
        
        # Build compliance summary string (now only one framework when frameworkKey is set)
        complianceSummary = []
        for framework, data in complianceData.items():
            displayName = data.get("displayName", framework)
            totalAlerts = data.get("totalAlerts", 0)
            topControls = data.get("topControls", [])[:5]
            controlsStr = ", ".join([f"{c['control']}({c['count']})" for c in topControls])
            severityBreakdown = data.get("severityBreakdown", {})
            sevStr = ", ".join([f"{k}:{v}" for k, v in severityBreakdown.items()])
            complianceSummary.append(f"  - {displayName}: {totalAlerts} alerts | Top Controls: {controlsStr} | Severity: {sevStr}")
        complianceSummaryStr = "\n".join(complianceSummary) if complianceSummary else "  - No compliance data available"
        
        # Build top agents string
        topAgentsStr = "\n".join([
            f"  - {a['name']} (ID: {a['id']}): {a['alertCount']} alerts (C:{a['critical']}, H:{a['high']}, M:{a['medium']})"
            for a in topAgents[:5]
        ]) if topAgents else "  - No agent data available"
        
        # Build inactive agents string - grouped by category (24+ hours first, then 3+ days, then Abandoned)
        inactiveAgentsStr = ""
        if inactiveAgents:
            # Group by category
            inactive24HoursAgents = [a for a in inactiveAgents if a.get("categoryPriority") == 1]
            inactive3DaysAgents = [a for a in inactiveAgents if a.get("categoryPriority") == 2]
            abandonedAgents = [a for a in inactiveAgents if a.get("categoryPriority") == 3]
            
            if inactive24HoursAgents:
                inactiveAgentsStr += f"\n  INACTIVE 24+ HOURS ({len(inactive24HoursAgents)} agents):\n"
                for a in inactive24HoursAgents[:3]:
                    inactiveAgentsStr += f"    - {a['name']} (ID: {a['id']}): Last seen {a['hoursSinceLastSeen']} hours ago ({a['hostOs']})\n"
            
            if inactive3DaysAgents:
                inactiveAgentsStr += f"\n  INACTIVE 3+ DAYS ({len(inactive3DaysAgents)} agents):\n"
                for a in inactive3DaysAgents[:3]:
                    inactiveAgentsStr += f"    - {a['name']} (ID: {a['id']}): Last seen {a['hoursSinceLastSeen']} hours ago ({a['hostOs']})\n"
            
            if abandonedAgents:
                inactiveAgentsStr += f"\n  ABANDONED (7+ days, {len(abandonedAgents)} agents):\n"
                for a in abandonedAgents[:3]:
                    inactiveAgentsStr += f"    - {a['name']} (ID: {a['id']}): Last seen {a['hoursSinceLastSeen']} hours ago ({a['hostOs']})\n"
        else:
            inactiveAgentsStr = "  - No inactive agents detected"
        
        # Framework-specific vs. multi-framework prompt
        fwContext = FRAMEWORK_CONTEXT.get(frameworkKey, {}) if frameworkKey else {}
        fwScope = fwContext.get("scope", "")
        fwFocus = fwContext.get("focus", "")
        fwName = frameworkDisplayName or fwContext.get("name", frameworkKey or "compliance")
        
        frameworkSpecificBlock = ""
        if frameworkKey and frameworkDisplayName:
            frameworkSpecificBlock = f"""
**CRITICAL - THIS IS A {fwName.upper()}-ONLY REPORT:**
- This report covers ONLY {fwName}. Do NOT mention HIPAA, GDPR, NIST 800-53, TSC, or any other compliance framework.
- All risk highlights, recommendations, and insights MUST be exclusively about {fwName} and its controls.
- Scope: {fwScope}
- Focus areas: {fwFocus}
- Reference specific {fwName} control IDs (e.g., requirement numbers) when discussing violations.
"""

        prompt = f"""You are a senior compliance and security analyst for Athena SOC. Generate a compliance summary report for the period {timeFrom} to {timeTo}.
{frameworkSpecificBlock}

**OVERALL METRICS (all alerts in period):**
- Total Alerts: {overallStats.get('totalAlerts', 0)}
- Critical: {overallStats.get('bySeverity', {}).get('Critical', 0)}
- High: {overallStats.get('bySeverity', {}).get('High', 0)}
- Medium: {overallStats.get('bySeverity', {}).get('Medium', 0)}
- Unique Agents: {overallStats.get('uniqueAgents', 0)}
- Unique Rules Triggered: {overallStats.get('uniqueRules', 0)}

**COMPLIANCE DATA ({"this framework only" if frameworkKey else "all frameworks"}):**
{complianceSummaryStr}

**TOP ACTIVE AGENTS (by alert volume):**
{topAgentsStr}

**INACTIVE AGENTS (categorized by severity):**
{inactiveAgentsStr}
Total Inactive: {len(inactiveAgents)} agents (Inactive 24+ hours: {len([a for a in inactiveAgents if a.get('categoryPriority') == 1])}, Inactive 3+ days: {len([a for a in inactiveAgents if a.get('categoryPriority') == 2])}, Abandoned 7+ days: {len([a for a in inactiveAgents if a.get('categoryPriority') == 3])})

**OUTPUT JSON:**
{{
  "executiveSummary": "2-3 paragraph executive summary. {"Focus ONLY on " + fwName + " compliance - control violations, posture, and priorities. Do not mention other frameworks." if frameworkKey else "Cover overall compliance posture, key findings, and priority areas."} Be specific with numbers and control IDs.",
  "riskHighlights": ["3-5 specific risk highlights. {"Each must relate ONLY to " + fwName + " controls and requirements." if frameworkKey else "Include concrete numbers and affected systems."}"],
  "notableTrends": ["2-4 notable trends or anomalies. {"Each must be relevant to " + fwName + " only." if frameworkKey else "Observe patterns in the data."}"],
  "complianceInsights": {{
    "{frameworkKey or '<framework_key>'}": "Brief insight with specific control violations and recommendations {"for " + fwName + "" if frameworkKey else ""}"
  }},
  "agentHealthInsights": "Summary of agent health - highly active agents and inactive agents. {"Connect to " + fwName + " monitoring coverage where relevant." if frameworkKey else ""}",
  "recommendations": ["3-5 prioritized, actionable recommendations. {"Every recommendation MUST be about " + fwName + " only - e.g., address specific control IDs, not other frameworks." if frameworkKey else ""}"],
  "overallComplianceRating": "Strong/Moderate/Weak/Critical (SINGLE WORD ONLY - no explanation)"
}}

**GUIDELINES:**
- Be specific and data-driven - reference exact numbers, percentages, agent names, and control IDs
- {"ALL content must relate ONLY to " + fwName + ". Never recommend HIPAA, GDPR, or other framework actions." if frameworkKey else "Focus on actionable insights for compliance officers."}
- Base ALL content strictly on the provided data - do not hallucinate
- CRITICAL: overallComplianceRating MUST be exactly ONE WORD (Strong, Moderate, Weak, or Critical) - NO explanations"""

        headers = {
            "Content-Type": "application/json"
        }
        
        systemContent = (
            f"You are a senior compliance analyst specializing in {fwName}. "
            f"Provide clear, executive-level analysis with actionable insights. "
            "Your reports must be data-driven, specific, and focus exclusively on the compliance standard in scope. "
            "Reference specific control IDs and requirement numbers. Do not discuss or recommend actions for other frameworks. "
            "If a data field is empty, null, or 'N/A', state that the information is unavailable — do not speculate or hallucinate. "
            "Return ONLY valid JSON. Do not include any text before or after the JSON object."
        ) if frameworkKey else (
            "You are a senior compliance and security analyst specializing in regulatory frameworks (PCI DSS, GDPR, HIPAA, NIST 800-53, TSC). "
            "Provide clear, executive-level compliance analysis with actionable insights. "
            "Your reports should be data-driven, specific, and prioritize findings by compliance risk and business impact. "
            "If a data field is empty, null, or 'N/A', state that the information is unavailable — do not speculate or hallucinate. "
            "Return ONLY valid JSON. Do not include any text before or after the JSON object."
        )

        payload = {
            "model": OLLAMA_MODEL,
            "messages": [
                {
                    "role": "system",
                    "content": systemContent
                },
                {
                    "role": "user",
                    "content": prompt
                }
            ],
            "temperature": 0.3,
            "max_tokens": 8192,
            "response_format": {"type": "json_object"}
        }

        log(f"Calling Ollama API at {OLLAMA_API_URL} for compliance insights...")

        response = requests.post(
            OLLAMA_API_URL,
            headers=headers,
            json=payload,
            timeout=300
        )

        if response.status_code == 200:
            result = response.json()
            aiContent = result['choices'][0]['message']['content']
            aiInsights = json.loads(aiContent)
            log("AI compliance insights generated successfully")
            return aiInsights
        else:
            log(f"Ollama API error: {response.status_code} - {response.text}")
            return None
            
    except Exception as e:
        import traceback
        log(f"Error generating AI insights: {e}")
        log(traceback.format_exc())
        return None


# === DASHBOARD URL BUILDERS ===
def buildDashboardUrl(timeFrom, timeTo, filters=None, kqlQuery=None):
    """Build OpenSearch Dashboard URL with proper Rison encoding.
    kqlQuery: optional KQL query string (e.g. 'rule.gdpr: *' for framework filter)"""
    base = f"{DASHBOARD_BASE_URL}/app/discover#"
    
    filterRison = "!()"
    if filters:
        filterItems = []
        for f in filters:
            if f["type"] == "phrase":
                field = str(f["field"])
                value = str(f["value"])
                fieldEscaped = field.replace("\\", "\\\\").replace("'", "\\'")
                valueEscaped = value.replace("\\", "\\\\").replace("'", "\\'")
                indexPatternEscaped = ES_INDEX_PATTERN.replace("\\", "\\\\").replace("'", "\\'")
                filterItems.append(
                    f"(meta:(alias:!n,disabled:!f,index:'{indexPatternEscaped}',key:'{fieldEscaped}',negate:!f,params:(query:'{valueEscaped}'),type:phrase,value:'{valueEscaped}'),query:(match_phrase:({fieldEscaped}:'{valueEscaped}')))"
                )
            elif f["type"] == "range":
                field = str(f["field"])
                fieldEscaped = field.replace("\\", "\\\\").replace("'", "\\'")
                indexPatternEscaped = ES_INDEX_PATTERN.replace("\\", "\\\\").replace("'", "\\'")
                params = f.get("params", {})
                gte = params.get("gte")
                lte = params.get("lte")
                
                paramParts = []
                rangeParts = []
                if gte is not None:
                    paramParts.append(f"gte:{gte}")
                    rangeParts.append(f"gte:{gte}")
                if lte is not None:
                    paramParts.append(f"lte:{lte}")
                    rangeParts.append(f"lte:{lte}")
                paramsStr = ",".join(paramParts)
                rangeStr = ",".join(rangeParts)
                
                filterItems.append(
                    f"(meta:(alias:!n,disabled:!f,index:'{indexPatternEscaped}',key:'{fieldEscaped}',negate:!f,params:({paramsStr}),type:range),range:({fieldEscaped}:({rangeStr})))"
                )
        if filterItems:
            filterRison = f"!({','.join(filterItems)})"
    
    indexPatternEscaped = ES_INDEX_PATTERN.replace("\\", "\\\\").replace("'", "\\'")
    _a = f"(columns:!(_source),filters:{filterRison},index:'{indexPatternEscaped}',sort:!())"
    
    timeFromEscaped = timeFrom.replace("'", "\\'")
    timeToEscaped = timeTo.replace("'", "\\'")
    _g = f"(time:(from:'{timeFromEscaped}',to:'{timeToEscaped}'))"
    queryStr = (kqlQuery or "").replace("\\", "\\\\").replace("'", "\\'")
    _q = f"(query:(language:kuery,query:'{queryStr}'))"
    
    _aEncoded = quote(_a, safe='()!,\':')
    _gEncoded = quote(_g, safe='()!,\':')
    _qEncoded = quote(_q, safe='()!,\':')
    
    url = f"{base}?_a={_aEncoded}&_g={_gEncoded}&_q={_qEncoded}"
    return url


def buildComplianceUrl(timeFrom, timeTo, framework, tabView="events", kqlQuery=None):
    """Build compliance framework dashboard URL.
    tabView: 'events' for violations/alerts view, 'inventory' for controls view.
    kqlQuery: optional KQL filter string (e.g. 'rule.tsc: CC7.2' or 'agent.name: my-host')."""
    appNameMap = {
        "pciDss": "pci",
        "gdpr": "gdpr",
        "hipaa": "hipaa",
        "nist80053": "nist-800-53",
        "tsc": "tsc"
    }
    tabNameMap = {
        "pciDss": "pci",
        "gdpr": "gdpr",
        "hipaa": "hipaa",
        "nist80053": "nist",
        "tsc": "tsc"
    }

    appName = appNameMap.get(framework, framework.lower())
    tabName = tabNameMap.get(framework, framework.lower())
    base = f"{DASHBOARD_BASE_URL}/app/{appName}#/overview/"

    queryStr = (kqlQuery or "").replace("\\", "\\\\").replace("'", "\\'")
    _a = f"(filters:!(),query:(language:kuery,query:'{queryStr}'))"

    timeFromEscaped = timeFrom.replace("'", "\\'")
    timeToEscaped = timeTo.replace("'", "\\'")
    _g = f"(filters:!(),refreshInterval:(pause:!t,value:0),time:(from:'{timeFromEscaped}',to:'{timeToEscaped}'))"
    
    _aEncoded = quote(_a, safe='()!,\':')
    _gEncoded = quote(_g, safe='()!,\':')
    
    url = f"{base}?tab={tabName}&tabView={tabView}&_a={_aEncoded}&_g={_gEncoded}"
    return url


def buildComplianceEventsUrl(timeFrom, timeTo, frameworkKey, kqlQuery=None):
    """Build compliance framework events/alerts URL (violations view, tabView=events)."""
    return buildComplianceUrl(timeFrom, timeTo, frameworkKey, tabView="events", kqlQuery=kqlQuery)


def buildComplianceInventoryUrl(timeFrom, timeTo, frameworkKey, kqlQuery=None):
    """Build compliance framework inventory/controls URL (tabView=inventory)."""
    return buildComplianceUrl(timeFrom, timeTo, frameworkKey, tabView="inventory", kqlQuery=kqlQuery)


def buildAgentsPreviewUrl():
    """Build agents preview URL (no filter). Prefer buildAgentsPreviewDisconnectedUrl for inactive agents."""
    return f"{DASHBOARD_BASE_URL}/app/endpoints-summary#/agents-preview/"


def buildAgentsPreviewDisconnectedUrl():
    """Agents preview filtered to disconnected/inactive agents (default KQL: status: disconnected)."""
    base = f"{DASHBOARD_BASE_URL}/app/endpoints-summary#/agents-preview/"
    kql = (AGENTS_PREVIEW_STATUS_KQL or "status: disconnected").strip()
    query_str = kql.replace("\\", "\\\\").replace("'", "\\'")
    _a = f"(filters:!(),query:(language:kuery,query:'{query_str}'))"
    _a_encoded = quote(_a, safe='()!,\':')
    return f"{base}?_a={_a_encoded}"


def buildAgentUrl(timeFrom, timeTo, agentName):
    """Build URL to filter by specific agent"""
    return buildDashboardUrl(timeFrom, timeTo, [
        {"type": "phrase", "field": "agent.name", "value": agentName}
    ])


# Framework key -> Elasticsearch field for compliance mappings
_COMPLIANCE_FIELD_MAP = {
    "pciDss": "rule.pci_dss",
    "gdpr": "rule.gdpr",
    "hipaa": "rule.hipaa",
    "nist80053": "rule.nist_800_53",
    "tsc": "rule.tsc",
}

# Severity -> rule.level range (Critical>=15, High>=12, Medium>=7, Low<7)
_SEVERITY_LEVEL_RANGE = {
    "Critical": {"gte": 15},
    "High": {"gte": 12, "lte": 14},
    "Medium": {"gte": 7, "lte": 11},
    "Low": {"gte": 0, "lte": 6},
}


def _kql_escape_phrase(value):
    """Escape a string for use inside a double-quoted KQL phrase."""
    return str(value).replace("\\", "\\\\").replace('"', '\\"')


def _compliance_scope_kql(framework_key):
    """KQL clause matching any alert for this framework (e.g. rule.gdpr: *)."""
    field = _COMPLIANCE_FIELD_MAP.get(framework_key)
    return f"{field}: *" if field else ""


def _compliance_severity_kql(framework_key, severity_name):
    """KQL: framework scope + rule.level range for severity badge deep-links."""
    scope = _compliance_scope_kql(framework_key)
    r = _SEVERITY_LEVEL_RANGE.get(severity_name)
    if not r:
        return scope
    if "gte" in r and "lte" in r:
        level_clause = f"rule.level >= {r['gte']} and rule.level <= {r['lte']}"
    elif "gte" in r:
        level_clause = f"rule.level >= {r['gte']}"
    else:
        level_clause = ""
    if not scope:
        return level_clause
    return f"{scope} and {level_clause}" if level_clause else scope


def buildComplianceDiscoverUrl(timeFrom, timeTo, frameworkKey, controlId=None, severity=None, agentName=None, ruleId=None):
    """Build Discover URL filtered by compliance framework, optionally by control, severity, agent, or rule.
    Links open wazuh-alerts filtered to the specific compliance context."""
    field = _COMPLIANCE_FIELD_MAP.get(frameworkKey)
    if not field:
        return buildDashboardUrl(timeFrom, timeTo)
    filters = []
    kqlParts = []
    if controlId:
        filters.append({"type": "phrase", "field": field, "value": controlId})
    else:
        kqlParts.append(f"{field}: *")
    if agentName:
        filters.append({"type": "phrase", "field": "agent.name", "value": agentName})
    if ruleId:
        filters.append({"type": "phrase", "field": "rule.id", "value": str(ruleId)})
    if severity and severity in _SEVERITY_LEVEL_RANGE:
        r = _SEVERITY_LEVEL_RANGE[severity]
        params = {}
        if "gte" in r:
            params["gte"] = r["gte"]
        if "lte" in r:
            params["lte"] = r["lte"]
        filters.append({"type": "range", "field": "rule.level", "params": params})
    kqlQuery = " and ".join(kqlParts) if kqlParts else None
    return buildDashboardUrl(timeFrom, timeTo, filters=filters if filters else None, kqlQuery=kqlQuery)


# === SVG CHART GENERATORS ===
def generateSparklineSvg(data, width=100, height=30, color="#1e40af"):
    """Generate inline SVG sparkline chart"""
    if not data or len(data) < 2:
        return ""
    
    maxVal = max(data) if max(data) > 0 else 1
    points = []
    
    for i, val in enumerate(data):
        x = (i / (len(data) - 1)) * width
        y = height - (val / maxVal * height * 0.8) - 2
        points.append(f"{x:.1f},{y:.1f}")
    
    pointsStr = " ".join(points)
    
    svg = f'''<svg width="{width}" height="{height}" xmlns="http://www.w3.org/2000/svg">
        <polyline fill="none" stroke="{color}" stroke-width="2" points="{pointsStr}"/>
    </svg>'''
    
    return svg


def generateMiniBarSvg(critical, high, medium, width=120, height=16):
    """Generate inline SVG mini bar chart for severity breakdown"""
    total = critical + high + medium
    if total == 0:
        return ""
    
    colors = getColorScheme()
    
    critWidth = (critical / total) * width if total > 0 else 0
    highWidth = (high / total) * width if total > 0 else 0
    medWidth = (medium / total) * width if total > 0 else 0
    
    critX = 0
    highX = critWidth
    medX = critWidth + highWidth
    
    svg = f'''<svg width="{width}" height="{height}" xmlns="http://www.w3.org/2000/svg">
        <rect x="{critX}" y="0" width="{critWidth}" height="{height}" fill="{colors['danger']}" rx="2"/>
        <rect x="{highX}" y="0" width="{highWidth}" height="{height}" fill="{colors['warning']}" rx="0"/>
        <rect x="{medX}" y="0" width="{medWidth}" height="{height}" fill="{colors['info']}" rx="2"/>
    </svg>'''
    
    return svg


# === HTML REPORT BUILDER ===
def buildHtmlReport(reportType, timeFrom, timeTo, reportData, aiInsights):
    """Build professional HTML email report"""
    from html import escape as htmlEscape
    
    # Format dates
    fromDate = datetime.fromisoformat(timeFrom.replace('Z', '+00:00')).strftime('%B %d, %Y')
    toDate = datetime.fromisoformat(timeTo.replace('Z', '+00:00')).strftime('%B %d, %Y')
    generatedAt = datetime.now(timezone.utc).strftime('%B %d, %Y at %I:%M %p UTC')
    
    colors = getColorScheme()
    
    overallStats = reportData.get("overallStats", {})
    topAgents = reportData.get("topAgents", [])
    inactiveAgents = reportData.get("inactiveAgents", [])
    complianceData = reportData.get("complianceData", {})
    
    # Build AI Insights Section
    aiSection = ""
    if aiInsights:
        # Build risk highlights
        riskHighlightsHtml = ""
        if aiInsights.get("riskHighlights"):
            riskHighlightsHtml = f"""
            <div style='margin-bottom:16px;background:#fef2f2;padding:12px;border-radius:4px;border-left:4px solid {colors["danger"]};'>
                <strong style='color:{colors["danger"]};'>Risk Highlights:</strong>
                <ul style='margin:6px 0;padding-left:20px;'>
                {''.join([f"<li style='margin:4px 0;color:{colors['danger']};'>{htmlEscape(risk)}</li>" for risk in aiInsights.get('riskHighlights', [])])}
                </ul>
            </div>
            """
        
        # Build notable trends
        notableTrendsHtml = ""
        if aiInsights.get("notableTrends"):
            notableTrendsHtml = f"""
            <div style='margin-bottom:16px;'>
                <strong>Notable Trends & Anomalies:</strong>
                <ul style='margin:6px 0;padding-left:20px;'>
                {''.join([f"<li style='margin:4px 0;'>{htmlEscape(trend)}</li>" for trend in aiInsights.get('notableTrends', [])])}
                </ul>
            </div>
            """
        
        # Build recommendations
        recommendationsHtml = ""
        if aiInsights.get("recommendations"):
            recommendationsHtml = f"""
            <div style='margin-bottom:16px;background:#f0fdf4;padding:12px;border-radius:4px;border-left:4px solid {colors["success"]};'>
                <strong style='color:{colors["success"]};'>Recommendations:</strong>
                <ol style='margin:6px 0;padding-left:20px;'>
                {''.join([f"<li style='margin:4px 0;'>{htmlEscape(rec)}</li>" for rec in aiInsights.get('recommendations', [])])}
                </ol>
            </div>
            """
        
        aiSection = f"""
        <table width="100%" cellpadding="0" cellspacing="0" border="0" 
            style="background:#f0f9ff;border:1px solid #c7d2fe;border-radius:6px;margin:24px 0;">
        <tr>
            <td style="background:#0d47a1;padding:12px 20px;
                    border-top-left-radius:6px;border-top-right-radius:6px;">
            <h2 style="margin:0;color:#fff;font-size:16px;font-weight:600;">
                Athena-AI Compliance Insights
            </h2>
            <div style="color:#fff;font-size:11px;opacity:0.9;margin-top:4px;">
                Based strictly on the data included in this report
            </div>
            </td>
        </tr>
        <tr>
            <td style="padding:20px;color:#1e293b;font-size:14px;line-height:1.6;">
            
            <!-- Executive Summary -->
            <div style="margin-bottom:16px;">
                <strong>Executive Summary:</strong>
                <p style="margin:8px 0;white-space:pre-wrap;">{htmlEscape(aiInsights.get('executiveSummary', 'No summary available.'))}</p>
            </div>
            
            {riskHighlightsHtml}
            
            {notableTrendsHtml}
            
            <!-- Agent Health Insights -->
            {f'''
            <div style='margin-bottom:16px;background:#fff7ed;padding:12px;border-radius:4px;border-left:4px solid {colors["warning"]};'>
                <strong style='color:{colors["warning"]};'>Agent Health Assessment:</strong>
                <p style="margin:8px 0;">{htmlEscape(aiInsights.get('agentHealthInsights', ''))}</p>
            </div>
            ''' if aiInsights.get('agentHealthInsights') else ''}
            
            {recommendationsHtml}
            
            </td>
        </tr>
        </table>
        """
    
    # Build Quick Stats Cards - Compliance-focused metrics
    inactiveCount = len(inactiveAgents)
    activeAgentsCount = overallStats.get("uniqueAgents", 0)
    singleFramework = reportData.get("_singleFramework")
    frameworkDisplayName = reportData.get("_frameworkDisplayName", "")

    # Calculate compliance-focused metrics (for single-framework report, these reflect that framework only)
    frameworksMonitored = len(complianceData)
    totalComplianceViolations = sum([fw.get("totalAlerts", 0) for fw in complianceData.values()])
    
    # Count unique controls violated across all frameworks
    uniqueControlsViolated = set()
    for fw in complianceData.values():
        for ctrl in fw.get("topControls", []):
            uniqueControlsViolated.add(ctrl.get("control", ""))
    controlsViolatedCount = len(uniqueControlsViolated)
    
    # Get compliance rating from AI insights or calculate it
    complianceRatingWord = "N/A"
    complianceRatingColor = "#6b7280"
    if aiInsights:
        rating = aiInsights.get("overallComplianceRating", "").strip()
        # Extract just the first word if there's more text
        complianceRatingWord = rating.split()[0] if rating else "N/A"
        # Clean up common variations
        complianceRatingWord = complianceRatingWord.rstrip(':-,.')
        complianceRatingColor = {
            "Strong": "#22c55e",
            "Moderate": "#facc15", 
            "Weak": "#fb8c00",
            "Critical": "#dc2626"
        }.get(complianceRatingWord.capitalize(), "#6b7280")
        complianceRatingWord = complianceRatingWord.capitalize()
    
    allAlertsUrl = buildDashboardUrl(timeFrom, timeTo)

    # Clickable stat card URLs (scoped to this report's framework when single-framework)
    _scope_field = _COMPLIANCE_FIELD_MAP.get(singleFramework, "") if singleFramework else ""
    _scope_kql_top = f"{_scope_field}: *" if _scope_field else None
    violationsCardUrl = (
        buildComplianceEventsUrl(timeFrom, timeTo, singleFramework, kqlQuery=_scope_kql_top)
        if singleFramework
        else allAlertsUrl
    )
    controlsCardUrl = (
        buildComplianceInventoryUrl(timeFrom, timeTo, singleFramework, kqlQuery=_scope_kql_top)
        if singleFramework
        else allAlertsUrl
    )
    inactiveAgentsCardUrl = buildAgentsPreviewDisconnectedUrl()
    
    # Build Agents Overview (compliance context only - no detailed tables)
    agentsWithComplianceAlerts = set()
    for fwData in complianceData.values():
        for agnt in fwData.get("affectedAgents", []):
            agentsWithComplianceAlerts.add(agnt.get("agent", ""))
    agentsOverviewHtml = f"""
    <table width="100%" cellpadding="0" cellspacing="0" border="0" style="background:#fff;border:1px solid {colors['border']};border-radius:6px;margin:24px 0;">
        <tr>
            <td style="padding:16px 20px;">
                <h3 style="margin:0 0 12px 0;color:{colors['dark']};font-size:16px;font-weight:600;border-bottom:2px solid {colors['border']};padding-bottom:8px;">
                    Agents Overview (Compliance Context)
                </h3>
                <div style="font-size:14px;color:{colors['text']};line-height:1.6;">
                    <p style="margin:0 0 8px 0;">{len(agentsWithComplianceAlerts)} agent(s) contributed to compliance alerts this period. Most affected agents are listed in each framework section above.</p>
                    <p style="margin:0;">{inactiveCount} agent(s) inactive (&gt;24h no events). <a href="{htmlEscape(inactiveAgentsCardUrl, quote=True)}" style="color:{colors['primary']};text-decoration:none;font-weight:600;">Open disconnected agents →</a> Inactive agents may reduce compliance monitoring coverage.</p>
                </div>
            </td>
        </tr>
    </table>
    """
    
    # Build Compliance Frameworks Section
    complianceSectionsHtml = ""
    if complianceData:
        for frameworkKey, data in complianceData.items():
            displayName = data.get("displayName", frameworkKey)
            totalFrameworkAlerts = data.get("totalAlerts", 0)
            uniqueRules = data.get("uniqueRules", 0)
            topControls = data.get("topControls", [])
            affectedAgents = data.get("affectedAgents", [])
            topRules = data.get("topRules", [])
            severityBreakdown = data.get("severityBreakdown", {})
            alertsTimeline = data.get("alertsTimeline", [])
            
            frameworkField = _COMPLIANCE_FIELD_MAP.get(frameworkKey, "")
            scope_kql = _compliance_scope_kql(frameworkKey) or None
            frameworkUrl = buildComplianceEventsUrl(timeFrom, timeTo, frameworkKey, kqlQuery=scope_kql)
            frameworkInventoryUrl = buildComplianceInventoryUrl(timeFrom, timeTo, frameworkKey, kqlQuery=scope_kql)

            # Top violated controls with per-control top agents
            controlsHtml = ""
            if topControls:
                controlsHtml = "<ul style='margin:8px 0;padding-left:20px;'>"
                for ctrl in topControls[:8]:
                    topAgents = ctrl.get("topAgents") or []
                    # Deep-link: inventory tab filtered to this specific control (within framework)
                    if frameworkField:
                        ctrl_esc = _kql_escape_phrase(ctrl["control"])
                        ctrlKql = f'{frameworkField}: "{ctrl_esc}"'
                    else:
                        ctrlKql = ""
                    ctrlUrl = buildComplianceInventoryUrl(timeFrom, timeTo, frameworkKey, kqlQuery=ctrlKql)
                    agentsSub = ""
                    if topAgents:
                        agentsSub = " <span style='color:" + colors['textLight'] + ";font-size:11px;'>→ " + ", ".join([f"{a['agent']} ({a['count']})" for a in topAgents]) + "</span>"
                    controlsHtml += f"<li style='margin:6px 0;font-size:13px;'><a href=\"{htmlEscape(ctrlUrl, quote=True)}\" style='color:{colors['primary']};text-decoration:none;'><strong>{htmlEscape(ctrl['control'])}</strong>: {ctrl['count']} violations</a>{agentsSub}</li>"
                controlsHtml += "</ul>"
                if len(topControls) > 8:
                    controlsHtml += f"<div style='margin-top:4px;'><a href=\"{htmlEscape(frameworkInventoryUrl, quote=True)}\" style='color:{colors['textLight']};font-size:11px;'>View all controls →</a></div>"

            # Top triggering rules
            rulesHtml = ""
            if topRules:
                rulesHtml = "<ul style='margin:8px 0;padding-left:20px;'>"
                for r in topRules[:6]:
                    # Deep-link: events tab — framework scope + specific rule
                    rid_esc = _kql_escape_phrase(r["ruleId"])
                    if frameworkField:
                        ruleKql = f'{frameworkField}: * and rule.id: "{rid_esc}"'
                    else:
                        ruleKql = f'rule.id: "{rid_esc}"'
                    ruleUrl = buildComplianceEventsUrl(timeFrom, timeTo, frameworkKey, kqlQuery=ruleKql)
                    desc = (r.get("description") or "")[:60] + ("..." if len(r.get("description") or "") > 60 else "")
                    rulesHtml += f"<li style='margin:4px 0;font-size:12px;'><a href=\"{htmlEscape(ruleUrl, quote=True)}\" style='color:{colors['primary']};text-decoration:none;'><strong>{htmlEscape(r['ruleId'])}</strong> ({r['count']})</a>"
                    if desc:
                        rulesHtml += f"<div style='color:{colors['textLight']};font-size:11px;margin-left:4px;'>{htmlEscape(desc)}</div>"
                    rulesHtml += "</li>"
                rulesHtml += "</ul>"

            # Affected agents list
            agentsHtml = ""
            if affectedAgents:
                agentsHtml = "<div style='margin-top:8px;'>"
                for agnt in affectedAgents[:6]:
                    # Deep-link: events tab — framework scope + specific agent
                    an_esc = _kql_escape_phrase(agnt["agent"])
                    if frameworkField:
                        agentKql = f'{frameworkField}: * and agent.name: "{an_esc}"'
                    else:
                        agentKql = f'agent.name: "{an_esc}"'
                    agentUrl = buildComplianceEventsUrl(timeFrom, timeTo, frameworkKey, kqlQuery=agentKql)
                    agentsHtml += f"<a href=\"{htmlEscape(agentUrl, quote=True)}\" style='background:{colors['light']};padding:2px 8px;border-radius:4px;font-size:11px;margin-right:4px;margin-bottom:4px;display:inline-block;color:{colors['primary']};text-decoration:none;'>{htmlEscape(agnt['agent'])} ({agnt['count']})</a>"
                if len(affectedAgents) > 6:
                    agentsHtml += f"<a href=\"{htmlEscape(frameworkUrl, quote=True)}\" style='color:{colors['textLight']};font-size:11px;margin-left:4px;'>+{len(affectedAgents) - 6} more →</a>"
                agentsHtml += "</div>"
            
            # Severity badges
            sevCritical = severityBreakdown.get("Critical", 0)
            sevHigh = severityBreakdown.get("High", 0)
            sevMedium = severityBreakdown.get("Medium", 0)
            sevLow = severityBreakdown.get("Low", 0)
            sevCriticalUrl = buildComplianceEventsUrl(
                timeFrom, timeTo, frameworkKey, kqlQuery=_compliance_severity_kql(frameworkKey, "Critical") or None
            )
            sevHighUrl = buildComplianceEventsUrl(
                timeFrom, timeTo, frameworkKey, kqlQuery=_compliance_severity_kql(frameworkKey, "High") or None
            )
            sevMediumUrl = buildComplianceEventsUrl(
                timeFrom, timeTo, frameworkKey, kqlQuery=_compliance_severity_kql(frameworkKey, "Medium") or None
            )
            sevLowUrl = buildComplianceEventsUrl(
                timeFrom, timeTo, frameworkKey, kqlQuery=_compliance_severity_kql(frameworkKey, "Low") or None
            )
            severityBarSvg = generateMiniBarSvg(sevCritical, sevHigh, sevMedium, width=140, height=14)
            
            # Alerts timeline sparkline
            sparklineSvg = generateSparklineSvg(alertsTimeline, width=120, height=28, color=colors["primary"]) if alertsTimeline and len(alertsTimeline) >= 2 else ""
            
            complianceSectionsHtml += f"""
            <table width="100%" cellpadding="0" cellspacing="0" border="0" style="background:#fff;border:1px solid {colors['border']};border-radius:6px;margin-bottom:16px;">
                <tr>
                    <td style="padding:16px 20px;border-bottom:1px solid {colors['border']};background:{colors['light']};">
                        <table width="100%" cellpadding="0" cellspacing="0" border="0">
                            <tr>
                                <td>
                                    <a href="{htmlEscape(frameworkUrl, quote=True)}" style="color:{colors['primary']};text-decoration:none;font-weight:700;font-size:16px;">{htmlEscape(displayName)}</a>
                                    <a href="{htmlEscape(frameworkInventoryUrl, quote=True)}" style="margin-left:10px;background:#e0e7ff;color:{colors['primary']};padding:3px 8px;border-radius:10px;font-size:11px;text-decoration:none;">{uniqueRules} unique rules</a>
                                </td>
                                <td style="text-align:right;vertical-align:middle;">
                                    <a href="{htmlEscape(frameworkUrl, quote=True)}" style="background:{colors['primary']};color:#fff;padding:6px 14px;border-radius:16px;font-size:14px;font-weight:700;text-decoration:none;display:inline-block;">{totalFrameworkAlerts} alerts</a>
                                </td>
                            </tr>
                        </table>
                    </td>
                </tr>
                <tr>
                    <td style="padding:16px 20px;">
                        <table width="100%" cellpadding="0" cellspacing="0" border="0">
                            <tr>
                                <td style="vertical-align:top;">
                                    <div style="font-weight:600;font-size:13px;color:{colors['text']};margin-bottom:6px;">Severity</div>
                                    <div style="margin-bottom:8px;">
                                        <a href="{htmlEscape(sevCriticalUrl, quote=True)}" style="background:{colors['danger']};color:#fff;padding:2px 8px;border-radius:4px;font-size:11px;margin-right:4px;text-decoration:none;">C:{sevCritical}</a>
                                        <a href="{htmlEscape(sevHighUrl, quote=True)}" style="background:{colors['warning']};color:#fff;padding:2px 8px;border-radius:4px;font-size:11px;margin-right:4px;text-decoration:none;">H:{sevHigh}</a>
                                        <a href="{htmlEscape(sevMediumUrl, quote=True)}" style="background:{colors['info']};color:#fff;padding:2px 8px;border-radius:4px;font-size:11px;margin-right:4px;text-decoration:none;">M:{sevMedium}</a>
                                        <a href="{htmlEscape(sevLowUrl, quote=True)}" style="background:#9ca3af;color:#fff;padding:2px 8px;border-radius:4px;font-size:11px;text-decoration:none;">L:{sevLow}</a>
                                    </div>
                                    <div style="margin-bottom:4px;">{severityBarSvg}</div>
                                    <div style="font-weight:600;font-size:12px;color:{colors['textLight']};margin-bottom:12px;">Alerts over time</div>
                                    <div>{sparklineSvg}</div>
                                </td>
                            </tr>
                        </table>
                        <table width="100%" cellpadding="0" cellspacing="0" border="0" style="margin-top:16px;">
                            <tr>
                                <td width="33%" style="vertical-align:top;padding-right:16px;">
                                    <div style="font-weight:600;font-size:13px;color:{colors['text']};margin-bottom:8px;">Top Violated Controls</div>
                                    {controlsHtml if controlsHtml else '<div style="color:' + colors['textLight'] + ';font-size:13px;">No control data</div>'}
                                </td>
                                <td width="33%" style="vertical-align:top;padding-right:16px;border-left:1px solid {colors['border']};padding-left:16px;">
                                    <div style="font-weight:600;font-size:13px;color:{colors['text']};margin-bottom:8px;">Top Triggering Rules</div>
                                    {rulesHtml if rulesHtml else '<div style="color:' + colors['textLight'] + ';font-size:13px;">No rule data</div>'}
                                </td>
                                <td width="34%" style="vertical-align:top;padding-left:16px;border-left:1px solid {colors['border']};">
                                    <div style="font-weight:600;font-size:13px;color:{colors['text']};margin-bottom:8px;">Most Affected Agents</div>
                                    {agentsHtml if agentsHtml else '<div style="color:' + colors['textLight'] + ';font-size:13px;">No agent data</div>'}
                                </td>
                            </tr>
                        </table>
                        <div style="margin-top:12px;padding-top:12px;border-top:1px solid {colors['border']};">
                            <a href="{htmlEscape(frameworkUrl, quote=True)}" style="color:{colors['primary']};font-size:12px;text-decoration:none;">View all {htmlEscape(displayName)} alerts →</a>
                            &nbsp;&nbsp;
                            <a href="{htmlEscape(frameworkInventoryUrl, quote=True)}" style="color:{colors['textLight']};font-size:12px;text-decoration:none;">Controls inventory →</a>
                        </div>
                    </td>
                </tr>
            </table>
            """
    else:
        complianceSectionsHtml = f"""
        <table width="100%" cellpadding="0" cellspacing="0" border="0" style="background:{colors['light']};border:1px solid {colors['border']};border-radius:6px;">
            <tr>
                <td style="padding:32px;text-align:center;">
                    <div style="font-size:16px;color:{colors['textLight']};margin-bottom:8px;">No compliance data available for the selected period</div>
                    <div style="font-size:13px;color:{colors['textLight']};">Ensure compliance framework rules are configured and enabled</div>
                </td>
            </tr>
        </table>
        """
    
    # Build final HTML
    htmlOutput = f"""
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <!--[if mso]>
    <style type="text/css">
        body, table, td {{font-family: Arial, sans-serif !important;}}
    </style>
    <![endif]-->
</head>
<body style="margin:0;padding:0;font-family:Arial,sans-serif;background:{colors['light']};width:100%;">
    
    <table width="100%" cellpadding="0" cellspacing="0" border="0" style="background:{colors['light']};margin:0;padding:0;">
        <tr>
            <td align="center" style="padding:0;">
                
                <!-- Header -->
                <div style="background:#0d47a1;color:#fff;padding:16px 20px;font-size:20px;font-weight:700;">
                    {ATHENA_NAME} — {htmlEscape(frameworkDisplayName + ' Compliance Report') if singleFramework else 'Compliance Summary Report'}
                    <div style="font-size:12px;font-weight:400;opacity:0.95;margin-top:4px;">Tenant: {htmlEscape(TENANT_NAME)}</div>
                    <div style="font-size:12px;font-weight:400;opacity:0.95;margin-top:4px;">📅 {fromDate} — {toDate}</div>
                </div>
                
                <!-- Main Content -->
                <div style="padding:20px;font-family:Arial,sans-serif;line-height:1.5;max-width:900px;margin:0 auto;">
                    
                    <!-- Quick Stats Cards - Compliance Metrics -->
                    <table width="100%" cellpadding="0" cellspacing="0" border="0" style="margin-bottom:24px;">
                        <tr>
                            <!-- Compliance Rating -->
                            <td width="20%" style="padding:8px;vertical-align:top;">
                                <table width="100%" cellpadding="0" cellspacing="0" border="0" style="background:{complianceRatingColor}20;border:2px solid {complianceRatingColor};border-radius:6px;height:120px;">
                                    <tr>
                                        <td style="padding:16px;text-align:center;vertical-align:middle;">
                                            <div style="font-size:22px;font-weight:700;color:{complianceRatingColor};margin-bottom:4px;">{complianceRatingWord}</div>
                                            <div style="color:{complianceRatingColor};font-size:11px;text-transform:uppercase;letter-spacing:0.5px;">Compliance Rating</div>
                                            <div style="color:{colors['textLight']};font-size:10px;margin-top:4px;">AI Assessment</div>
                                        </td>
                                    </tr>
                                </table>
                            </td>
                            <!-- Frameworks Monitored -->
                            <td width="20%" style="padding:8px;vertical-align:top;">
                                <table width="100%" cellpadding="0" cellspacing="0" border="0" style="background:#f0f9ff;border:1px solid #bae6fd;border-radius:6px;height:120px;">
                                    <tr>
                                        <td style="padding:16px;text-align:center;vertical-align:middle;">
                                            <div style="font-size:28px;font-weight:700;color:{colors['primary']};margin-bottom:4px;">{frameworksMonitored}</div>
                                            <div style="color:{colors['primary']};font-size:11px;text-transform:uppercase;letter-spacing:0.5px;">Frameworks</div>
                                            <div style="color:{colors['textLight']};font-size:10px;margin-top:4px;">Monitored</div>
                                        </td>
                                    </tr>
                                </table>
                            </td>
                            <!-- Total Violations (clickable → events tab) -->
                            <td width="20%" style="padding:8px;vertical-align:top;">
                                <a href="{htmlEscape(violationsCardUrl, quote=True)}" style="display:block;text-decoration:none;">
                                <table width="100%" cellpadding="0" cellspacing="0" border="0" style="background:{'#fef2f2' if totalComplianceViolations > 100 else '#fff7ed' if totalComplianceViolations > 0 else '#f0fdf4'};border:1px solid {'#fecaca' if totalComplianceViolations > 100 else '#fed7aa' if totalComplianceViolations > 0 else '#bbf7d0'};border-radius:6px;height:120px;cursor:pointer;">
                                    <tr>
                                        <td style="padding:16px;text-align:center;vertical-align:middle;">
                                            <div style="font-size:28px;font-weight:700;color:{colors['danger'] if totalComplianceViolations > 100 else colors['warning'] if totalComplianceViolations > 0 else colors['success']};margin-bottom:4px;">{totalComplianceViolations}</div>
                                            <div style="color:{colors['danger'] if totalComplianceViolations > 100 else colors['warning'] if totalComplianceViolations > 0 else colors['success']};font-size:11px;text-transform:uppercase;letter-spacing:0.5px;">Violations</div>
                                            <div style="color:{colors['primary']};font-size:10px;font-weight:500;margin-top:4px;">View All →</div>
                                        </td>
                                    </tr>
                                </table>
                                </a>
                            </td>
                            <!-- Controls Violated (clickable → inventory tab) -->
                            <td width="20%" style="padding:8px;vertical-align:top;">
                                <a href="{htmlEscape(controlsCardUrl, quote=True)}" style="display:block;text-decoration:none;">
                                <table width="100%" cellpadding="0" cellspacing="0" border="0" style="background:#fff;border:1px solid {colors['border']};border-radius:6px;height:120px;cursor:pointer;">
                                    <tr>
                                        <td style="padding:16px;text-align:center;vertical-align:middle;">
                                            <div style="font-size:28px;font-weight:700;color:{colors['warning']};margin-bottom:4px;">{controlsViolatedCount}</div>
                                            <div style="color:{colors['textLight']};font-size:11px;text-transform:uppercase;letter-spacing:0.5px;">Controls</div>
                                            <div style="color:{colors['textLight']};font-size:10px;margin-top:4px;">Violated</div>
                                        </td>
                                    </tr>
                                </table>
                                </a>
                            </td>
                            <!-- Inactive Agents (clickable → agents-preview) -->
                            <td width="20%" style="padding:8px;vertical-align:top;">
                                <a href="{htmlEscape(inactiveAgentsCardUrl, quote=True)}" style="display:block;text-decoration:none;">
                                <table width="100%" cellpadding="0" cellspacing="0" border="0" style="background:{'#fef2f2' if inactiveCount > 0 else '#f0fdf4'};border:1px solid {'#fecaca' if inactiveCount > 0 else '#bbf7d0'};border-radius:6px;height:120px;cursor:pointer;">
                                    <tr>
                                        <td style="padding:16px;text-align:center;vertical-align:middle;">
                                            <div style="font-size:28px;font-weight:700;color:{colors['danger'] if inactiveCount > 0 else colors['success']};margin-bottom:4px;">{inactiveCount}</div>
                                            <div style="color:{colors['danger'] if inactiveCount > 0 else colors['success']};font-size:11px;text-transform:uppercase;letter-spacing:0.5px;">Inactive Agents</div>
                                            <div style="color:{colors['textLight']};font-size:10px;margin-top:4px;">&gt;24h no events</div>
                                        </td>
                                    </tr>
                                </table>
                                </a>
                            </td>
                        </tr>
                    </table>
                    
                    <!-- AI Insights Section -->
                    {aiSection}
                    
                    <!-- Compliance Frameworks Overview -->
                    <h2 style="margin:32px 0 16px 0;color:{colors['dark']};font-size:18px;font-weight:600;border-bottom:2px solid {colors['border']};padding-bottom:8px;">
                        {'Athena ' + htmlEscape(frameworkDisplayName) + ' Summary' if singleFramework else 'Athena Compliance Framework Summary'}
                    </h2>
                    {complianceSectionsHtml}
                    
                    <!-- Agents Overview (Compliance Context) -->
                    {agentsOverviewHtml}
                    
                </div>
                
                <!-- Footer -->
                <div style="background:#f3f4f6;color:#333;padding:16px 20px;font-size:12px;">
                    <p style="margin:2px 0 6px 0;"><strong>Athena Security Group</strong></p>
                    <p style="margin:2px 0;">🌐 <a href="{ATHENA_WEBSITE}" style="color:#0d47a1;text-decoration:none;">Website</a>
                       &nbsp;|&nbsp; 📄 <a href="{ATHENA_DOCS}" style="color:#0d47a1;text-decoration:none;">Docs</a>
                       &nbsp;|&nbsp; 📧 <a href="mailto:{ATHENA_SUPPORT}" style="color:#0d47a1;text-decoration:none;">{ATHENA_SUPPORT}</a></p>
                    <p style="margin:10px 0 0 0;">This compliance summary report was generated on {generatedAt}. Do not reply to this email.</p>
                </div>
                
            </td>
        </tr>
    </table>
    
</body>
</html>
"""
    
    return htmlOutput


def buildPlainReport(reportType, timeFrom, timeTo, reportData, aiInsights):
    """Build plain text version of the report"""
    fromDate = datetime.fromisoformat(timeFrom.replace('Z', '+00:00')).strftime('%B %d, %Y')
    toDate = datetime.fromisoformat(timeTo.replace('Z', '+00:00')).strftime('%B %d, %Y')
    
    overallStats = reportData.get("overallStats", {})
    topAgents = reportData.get("topAgents", [])
    inactiveAgents = reportData.get("inactiveAgents", [])
    complianceData = reportData.get("complianceData", {})
    frameworkDisplayName = reportData.get("_frameworkDisplayName", "")
    
    lines = []
    lines.append("=" * 80)
    reportTitle = f"{ATHENA_NAME} - {frameworkDisplayName.upper()} COMPLIANCE REPORT" if frameworkDisplayName else f"{ATHENA_NAME} - COMPLIANCE SUMMARY REPORT"
    lines.append(reportTitle)
    lines.append("=" * 80)
    lines.append(f"Tenant: {TENANT_NAME}")
    lines.append(f"Period: {fromDate} — {toDate}")
    lines.append("")
    
    lines.append("OVERALL SUMMARY")
    lines.append("-" * 80)
    lines.append(f"Total Alerts: {overallStats.get('totalAlerts', 0)}")
    lines.append(f"  Critical: {overallStats.get('bySeverity', {}).get('Critical', 0)}")
    lines.append(f"  High: {overallStats.get('bySeverity', {}).get('High', 0)}")
    lines.append(f"  Medium: {overallStats.get('bySeverity', {}).get('Medium', 0)}")
    lines.append(f"Unique Agents: {overallStats.get('uniqueAgents', 0)}")
    lines.append(f"Inactive Agents: {len(inactiveAgents)}")
    lines.append("")
    
    if aiInsights:
        lines.append("AI-GENERATED COMPLIANCE INSIGHTS")
        lines.append("-" * 80)
        lines.append(f"Compliance Rating: {aiInsights.get('overallComplianceRating', 'N/A')}")
        lines.append("")
        lines.append("Executive Summary:")
        lines.append(aiInsights.get('executiveSummary', 'No summary available.'))
        lines.append("")
        
        if aiInsights.get('riskHighlights'):
            lines.append("Risk Highlights:")
            for risk in aiInsights['riskHighlights']:
                lines.append(f"  • {risk}")
            lines.append("")
        
        if aiInsights.get('recommendations'):
            lines.append("Recommendations:")
            for i, rec in enumerate(aiInsights['recommendations'], 1):
                lines.append(f"  {i}. {rec}")
            lines.append("")
    
    lines.append("COMPLIANCE FRAMEWORK SUMMARY" if not frameworkDisplayName else f"{frameworkDisplayName.upper()} SUMMARY")
    lines.append("-" * 80)
    if complianceData:
        for frameworkKey, data in complianceData.items():
            displayName = data.get("displayName", frameworkKey)
            lines.append(f"\n{displayName}:")
            lines.append(f"  Total Alerts: {data.get('totalAlerts', 0)} | Unique Rules: {data.get('uniqueRules', 0)}")
            lines.append("  Top Violated Controls:")
            for ctrl in data.get('topControls', [])[:8]:
                topAgents = ctrl.get('topAgents') or []
                agentsStr = f" -> {', '.join([a['agent'] + ' (' + str(a['count']) + ')' for a in topAgents[:3]])}" if topAgents else ""
                lines.append(f"    - {ctrl['control']}: {ctrl['count']}{agentsStr}")
            lines.append("  Top Triggering Rules:")
            for r in data.get('topRules', [])[:6]:
                lines.append(f"    - {r['ruleId']}: {r['count']}" + (f" - {r.get('description', '')[:50]}" if r.get('description') else ""))
            lines.append("  Most Affected Agents:")
            for agnt in data.get('affectedAgents', [])[:6]:
                lines.append(f"    - {agnt['agent']}: {agnt['count']}")
    else:
        lines.append("No compliance data available")
    lines.append("")
    
    # Agents Overview (compliance context only)
    agentsWithCompliance = set()
    for fwData in complianceData.values():
        for agnt in fwData.get("affectedAgents", []):
            agentsWithCompliance.add(agnt.get("agent", ""))
    lines.append("AGENTS OVERVIEW (COMPLIANCE CONTEXT)")
    lines.append("-" * 80)
    lines.append(f"{len(agentsWithCompliance)} agent(s) contributed to compliance alerts. Most affected agents are in each framework section above.")
    lines.append(f"{len(inactiveAgents)} agent(s) inactive (>24h). Inactive agents may reduce compliance monitoring coverage.")
    lines.append("")
    
    lines.append("=" * 80)
    lines.append(f"{ATHENA_NAME}")
    lines.append(f"Website: {ATHENA_WEBSITE}")
    lines.append(f"Support: {ATHENA_SUPPORT}")
    lines.append("")
    lines.append(f"This compliance report was generated on {datetime.now(timezone.utc).strftime('%B %d, %Y at %I:%M %p UTC')}")
    lines.append("Do not reply to this email.")
    lines.append("=" * 80)
    
    return "\n".join(lines)


# === EMAIL SENDING ===
def sendEmail(recipients, subject, plainBody, htmlBody) -> bool:
    """Send the report email"""
    try:
        msg = EmailMessage()
        msg["Subject"] = subject
        msg["To"] = ", ".join(recipients)
        msg["From"] = formataddr((COMPLIANCE_REPORT_FROM_NAME, SMTP_FROM))

        msg.set_content(plainBody)
        msg.add_alternative(htmlBody, subtype='html')

        if SMTP_USE_SSL:
            server = smtplib.SMTP_SSL(SMTP_HOST, SMTP_PORT, timeout=30)
        else:
            server = smtplib.SMTP(SMTP_HOST, SMTP_PORT, timeout=30)

        server.ehlo()
        if SMTP_USE_TLS and not SMTP_USE_SSL:
            server.starttls()
            server.ehlo()

        if SMTP_USERNAME and SMTP_PASSWORD:
            server.login(SMTP_USERNAME, SMTP_PASSWORD)

        server.send_message(msg)
        server.quit()
        log(f"Compliance report sent successfully to {recipients}")
        return True

    except Exception as e:
        log(f"Error sending compliance report email: {e}")
        return False


# === MAIN REPORT GENERATOR ===
def generateComplianceReport(
    reportType: str,
    timeFrom: str,
    timeTo: str,
    recipients: list,
    complianceConfig: dict = None
) -> bool:
    """
    Generate and send a compliance summary report.
    
    Args:
        reportType: Type of report (daily, weekly, monthly, custom)
        timeFrom: Start time in ISO format (e.g., 2025-01-01T00:00:00Z)
        timeTo: End time in ISO format
        recipients: List of email recipients
        complianceConfig: Optional configuration dict with:
            - enablePciDss: bool (default True)
            - enableGdpr: bool (default True)
            - enableHipaa: bool (default True)
            - enableNist80053: bool (default True)
            - enableTsc: bool (default True)
            - topAgentsCount: int (default 10)
            - inactiveThresholdHours: int (default 24)
    
    Returns:
        bool: True if report was generated and sent successfully
    """
    log(f"Generating {reportType} compliance report from {timeFrom} to {timeTo}")
    
    # Merge with default config
    config = {**DEFAULT_COMPLIANCE_CONFIG, **(complianceConfig or {})}
    
    # Collect all data
    log("Collecting report data...")
    
    # Query all data sources
    topAgentsAgg = queryTopActiveAgents(timeFrom, timeTo, config.get("topAgentsCount", 10))
    allAgentsAgg = queryAllAgents()
    complianceAgg = queryComplianceData(timeFrom, timeTo, config)
    overallStatsAgg = queryOverallStats(timeFrom, timeTo)
    
    # Process data
    topAgents = processTopActiveAgents(topAgentsAgg) if topAgentsAgg else []
    inactiveAgents = processInactiveAgents(allAgentsAgg, config.get("inactiveThresholdHours", 24)) if allAgentsAgg else []
    complianceData = processComplianceData(complianceAgg, config) if complianceAgg else {}
    overallStats = processOverallStats(overallStatsAgg) if overallStatsAgg else {}
    
    reportData = {
        "overallStats": overallStats,
        "topAgents": topAgents,
        "inactiveAgents": inactiveAgents,
        "complianceData": complianceData,
        "config": config
    }
    
    # Check if we have any meaningful data (overall stats or inactive agents)
    if overallStats.get("totalAlerts", 0) == 0 and not inactiveAgents:
        log("No data found for the specified time range")
        return False

    # Per-standard compliance reports: one report per enabled framework
    frameworkMapping = {
        "pciDss": ("enablePciDss", "PCI DSS"),
        "gdpr": ("enableGdpr", "GDPR"),
        "hipaa": ("enableHipaa", "HIPAA"),
        "nist80053": ("enableNist80053", "NIST 800-53"),
        "tsc": ("enableTsc", "TSC"),
    }

    sentCount = 0
    for frameworkKey, (configKey, displayName) in frameworkMapping.items():
        if not config.get(configKey, True):
            continue

        # Build report data for this framework only
        complianceDataSingle = {}
        if frameworkKey in reportData.get("complianceData", {}):
            complianceDataSingle[frameworkKey] = reportData["complianceData"][frameworkKey]
        else:
            # Framework enabled but no data; include placeholder for "0 violations"
            complianceDataSingle[frameworkKey] = {
                "displayName": displayName,
                "totalAlerts": 0,
                "topControls": [],
                "affectedAgents": [],
                "severityBreakdown": {},
            }

        reportDataSingle = {
            **reportData,
            "complianceData": complianceDataSingle,
            "_singleFramework": frameworkKey,
            "_frameworkDisplayName": displayName,
        }

        # Generate AI insights PER FRAMEWORK - framework-specific context and prompts
        aiInsightsSingle = generateAiInsights(
            reportDataSingle, timeFrom, timeTo,
            frameworkKey=frameworkKey, frameworkDisplayName=displayName
        )

        subject = f"[{TENANT_NAME}] {displayName} Compliance Report - {datetime.fromisoformat(timeFrom.replace('Z', '+00:00')).strftime('%b %d, %Y')}"
        htmlBody = buildHtmlReport(reportType, timeFrom, timeTo, reportDataSingle, aiInsightsSingle)
        plainBody = buildPlainReport(reportType, timeFrom, timeTo, reportDataSingle, aiInsightsSingle)

        if sendEmail(recipients, subject, plainBody, htmlBody):
            sentCount += 1
            log(f"Sent {displayName} compliance report")

    return sentCount > 0


# === CONVENIENCE FUNCTIONS ===
def generateDailyComplianceReport(recipients: list = None, complianceConfig: dict = None) -> bool:
    """Generate a daily compliance report (last 24 hours)"""
    now = datetime.now(timezone.utc)
    timeTo = now.isoformat().replace("+00:00", "Z")
    timeFrom = (now - timedelta(days=1)).isoformat().replace("+00:00", "Z")
    
    return generateComplianceReport(
        "daily",
        timeFrom,
        timeTo,
        recipients or SMTP_RECIPIENT,
        complianceConfig
    )


def generateWeeklyComplianceReport(recipients: list = None, complianceConfig: dict = None) -> bool:
    """Generate a weekly compliance report (last 7 days)"""
    now = datetime.now(timezone.utc)
    timeTo = now.isoformat().replace("+00:00", "Z")
    timeFrom = (now - timedelta(days=7)).isoformat().replace("+00:00", "Z")
    
    return generateComplianceReport(
        "weekly",
        timeFrom,
        timeTo,
        recipients or SMTP_RECIPIENT,
        complianceConfig
    )


def generateMonthlyComplianceReport(recipients: list = None, complianceConfig: dict = None) -> bool:
    """Generate a monthly compliance report (last 30 days)"""
    now = datetime.now(timezone.utc)
    timeTo = now.isoformat().replace("+00:00", "Z")
    timeFrom = (now - timedelta(days=30)).isoformat().replace("+00:00", "Z")
    
    return generateComplianceReport(
        "monthly",
        timeFrom,
        timeTo,
        recipients or SMTP_RECIPIENT,
        complianceConfig
    )


def generateCustomComplianceReport(
    timeFrom: str,
    timeTo: str,
    recipients: list = None,
    complianceConfig: dict = None
) -> bool:
    """Generate a compliance report for a custom time range"""
    return generateComplianceReport(
        "custom",
        timeFrom,
        timeTo,
        recipients or SMTP_RECIPIENT,
        complianceConfig
    )


# === MAIN ENTRY POINT ===
def main(args):
    """
    Usage: 
      python reports_compliance.py daily
      python reports_compliance.py weekly
      python reports_compliance.py monthly
      python reports_compliance.py custom 2025-01-01T00:00:00Z 2025-01-28T23:59:59Z
      
    Optional environment variables for compliance config:
      COMPLIANCE_ENABLE_PCI_DSS=true
      COMPLIANCE_ENABLE_GDPR=true
      COMPLIANCE_ENABLE_HIPAA=true
      COMPLIANCE_ENABLE_NIST_800_53=true
      COMPLIANCE_ENABLE_TSC=true
      AGENTS_PREVIEW_STATUS_KQL="status: disconnected"  # optional; agents-preview filter for Inactive Agents card
    """
    log("# Starting compliance report generation")
    
    if len(args) < 2:
        log("Usage: reports_compliance.py <daily|weekly|monthly|custom> [start_time] [end_time]")
        return
    
    reportType = args[1].lower()
    
    # Build compliance config from environment
    complianceConfig = {
        "enablePciDss": os.getenv("COMPLIANCE_ENABLE_PCI_DSS", "true").lower() == "true",
        "enableGdpr": os.getenv("COMPLIANCE_ENABLE_GDPR", "true").lower() == "true",
        "enableHipaa": os.getenv("COMPLIANCE_ENABLE_HIPAA", "true").lower() == "true",
        "enableNist80053": os.getenv("COMPLIANCE_ENABLE_NIST_800_53", "true").lower() == "true",
        "enableTsc": os.getenv("COMPLIANCE_ENABLE_TSC", "true").lower() == "true",
        "topAgentsCount": int(os.getenv("COMPLIANCE_TOP_AGENTS_COUNT", "10")),
        "inactiveThresholdHours": int(os.getenv("COMPLIANCE_INACTIVE_THRESHOLD_HOURS", "24"))
    }
    
    # Calculate time range
    now = datetime.now(timezone.utc)
    
    if reportType == "daily":
        timeTo = now.isoformat().replace("+00:00", "Z")
        timeFrom = (now - timedelta(days=1)).isoformat().replace("+00:00", "Z")
        recipients = SMTP_RECIPIENT
    elif reportType == "weekly":
        timeTo = now.isoformat().replace("+00:00", "Z")
        timeFrom = (now - timedelta(days=7)).isoformat().replace("+00:00", "Z")
        recipients = SMTP_RECIPIENT
    elif reportType == "monthly":
        timeTo = now.isoformat().replace("+00:00", "Z")
        timeFrom = (now - timedelta(days=30)).isoformat().replace("+00:00", "Z")
        recipients = SMTP_RECIPIENT
    elif reportType == "custom":
        if len(args) < 4:
            log("Custom report requires: reports_compliance.py custom <start_time> <end_time>")
            return
        timeFrom = args[2]
        timeTo = args[3]
        recipients = SMTP_RECIPIENT
    else:
        log(f"Unknown report type: {reportType}")
        return
    
    log(f"Generating {reportType} compliance report from {timeFrom} to {timeTo}")
    log(f"Recipients: {recipients}")
    log(f"Compliance config: {complianceConfig}")
    
    try:
        success = generateComplianceReport(reportType, timeFrom, timeTo, recipients, complianceConfig)
        if success:
            log("Compliance report generation completed successfully")
        else:
            log("Compliance report generation failed or no data found")
    except Exception as e:
        log(f"Error generating compliance report: {e}")
        import traceback
        log(traceback.format_exc())


if __name__ == "__main__":
    try:
        main(sys.argv)
    except Exception as e:
        log(f"Unhandled exception: {e}")
        import traceback
        log(traceback.format_exc())
        raise
