#!/var/ossec/framework/python/bin/python3
# -*- coding: utf-8 -*-

import json
import sys
import time
import os
import smtplib
import html
from datetime import datetime, timedelta
from urllib.parse import quote
from email.message import EmailMessage
from email.utils import formataddr
from collections import defaultdict
from dotenv import load_dotenv

load_dotenv()


# === CONFIGURATION FROM ENVIRONMENT ===
ATHENA_NAME = os.getenv("ATHENA_NAME", "Athena SOC")
TENANT_NAME = os.getenv("TENANT_NAME", "test.athenasecuritygrp.com")
ATHENA_WEBSITE = os.getenv("ATHENA_WEBSITE", "https://athenasoftwaregroup.ai/")
ATHENA_DOCS = os.getenv("ATHENA_DOCS", "https://athenasoftwaregroup.ai/")
ATHENA_SUPPORT = os.getenv("ATHENA_SUPPORT", "alerts@athena.athenasecuritygrp.com")
DASHBOARD_BASE_URL = os.getenv("DASHBOARD_BASE_URL", "https://test.athenasecuritygrp.com")

# === SMTP CONFIGURATION ===
SMTP_HOST = os.getenv("SMTP_HOST", "smtp.office365.com")
SMTP_PORT = int(os.getenv("SMTP_PORT", "587"))
SMTP_USE_TLS = os.getenv("SMTP_USE_TLS", "true").lower() == "true"
SMTP_USE_SSL = os.getenv("SMTP_USE_SSL", "false").lower() == "true"
SMTP_USERNAME = os.getenv("SMTP_USERNAME", "alerts@athenasoftwaregrp.com")
SMTP_PASSWORD = os.getenv("SMTP_PASSWORD", "")
SMTP_FROM = os.getenv("SMTP_FROM", "alerts@athena.athenasecuritygrp.com")
SMTP_RECIPIENT = os.getenv("SMTP_RECIPIENT", "secops@athena.athenasecuritygrp.com").split(",")

# === OLLAMA CONFIGURATION ===
OLLAMA_HOST = os.getenv("OLLAMA_HOST", "localhost")
OLLAMA_PORT = os.getenv("OLLAMA_PORT", "11434")
OLLAMA_MODEL = os.getenv("OLLAMA_MODEL", "qwen2.5:14b-instruct")
OLLAMA_ENABLED = os.getenv("OLLAMA_ENABLED", "true").lower() == "true"
OLLAMA_API_URL = f"http://{OLLAMA_HOST}:{OLLAMA_PORT}/v1/chat/completions"

# === ELASTICSEARCH CONFIGURATION ===
ES_HOST = os.getenv("ES_HOST", "https://localhost:9200")
ES_USERNAME = os.getenv("ES_USERNAME", "")
ES_PASSWORD = os.getenv("ES_PASSWORD", "")
ES_INDEX_PATTERN = os.getenv("ES_INDEX_PATTERN_SIEM", "athena-alerts-*")
ES_VERIFY_SSL = os.getenv("ES_VERIFY_SSL", "false").lower() == "true"



# === LOGGING ===
pwd = os.path.dirname(os.path.realpath(__file__))
log_file = f"{pwd}/logs/reporting.log"

def log(msg: str):
    now = time.strftime("%a %b %d %H:%M:%S %Z %Y")
    line = f"{now}: {msg}\n"
    print(line, end="")
    try:
        with open(log_file, "a") as f:
            f.write(line)
    except Exception:
        pass

# === ELASTICSEARCH QUERY ===
def query_elasticsearch(time_from, time_to, min_level=7):
    """Query Elasticsearch for aggregated alert statistics in the given time range"""
    try:
        import requests
        from requests.auth import HTTPBasicAuth
        import urllib3
        
        if not ES_VERIFY_SSL:
            urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
        
        query = {
            "size": 0,  # We don't need individual documents, only aggregations
            "query": {
                "bool": {
                    "must": [
                        {
                            "range": {
                                "timestamp": {
                                    "gte": time_from,
                                    "lte": time_to,
                                    "format": "strict_date_optional_time"
                                }
                            }
                        }
                    ],
                    "filter": [
                        {
                            "range": {
                                "rule.level": {
                                    "gte": min_level
                                }
                            }
                        }
                    ]
                }
            },
            "aggs": {
                "total_alerts": {
                    "value_count": {
                        "field": "rule.id"
                    }
                },
                "severity_breakdown": {
                    "terms": {
                        "script": {
                            "source": """
                                def level = doc['rule.level'].value;
                                if (level >= 15) return 'Critical';
                                else if (level >= 12) return 'High';
                                else if (level >= 7) return 'Medium';
                                else return 'Low';
                            """
                        },
                        "size": 10
                    }
                },
                "top_agents": {
                    "terms": {
                        "field": "agent.name",
                        "size": 5
                    },
                    "aggs": {
                        "severity_breakdown": {
                            "terms": {
                                "script": {
                                    "source": """
                                        def level = doc['rule.level'].value;
                                        if (level >= 15) return 'Critical';
                                        else if (level >= 12) return 'High';
                                        else if (level >= 7) return 'Medium';
                                        else return 'Low';
                                    """
                                },
                                "size": 10
                            }
                        }
                    }
                },
                "top_rules": {
                    "terms": {
                        "field": "rule.id",
                        "size": 5
                    },
                    "aggs": {
                        "rule_description": {
                            "terms": {
                                "field": "rule.description",
                                "size": 1
                            }
                        },
                        "rule_level": {
                            "terms": {
                                "field": "rule.level",
                                "size": 1
                            }
                        },
                        "mitre_tactics": {
                            "terms": {
                                "field": "rule.mitre.tactic",
                                "size": 10
                            }
                        }
                    }
                },
                "mitre_tactics": {
                    "terms": {
                        "field": "rule.mitre.tactic",
                        "size": 15
                    }
                },
                "mitre_techniques": {
                    "terms": {
                        "field": "rule.mitre.technique",
                        "size": 15
                    }
                },
                "compliance_frameworks": {
                    "filters": {
                        "filters": {
                            "pci_dss": {"exists": {"field": "rule.pci_dss"}},
                            "gdpr": {"exists": {"field": "rule.gdpr"}},
                            "hipaa": {"exists": {"field": "rule.hipaa"}},
                            "nist_800_53": {"exists": {"field": "rule.nist_800_53"}}
                        }
                    }
                },
                "event_categories": {
                    "filters": {
                        "filters": {
                            "file_integrity": {"terms": {"rule.groups": ["syscheck"]}},
                            "vulnerability": {"terms": {"rule.groups": ["vulnerability", "vulnerability-detector"]}},
                            "authentication": {"terms": {"rule.groups": ["authentication"]}}
                        }
                    }
                },
                "critical_alerts_sample": {
                    "filter": {
                        "range": {
                            "rule.level": {
                                "gte": 15
                            }
                        }
                    },
                    "aggs": {
                        "sample_alerts": {
                            "top_hits": {
                                "size": 5,
                                "sort": [{"timestamp": {"order": "desc"}}]
                            }
                        }
                    }
                },
                "high_alerts_sample": {
                    "filter": {
                        "range": {
                            "rule.level": {
                                "gte": 12,
                                "lt": 15
                            }
                        }
                    },
                    "aggs": {
                        "sample_alerts": {
                            "top_hits": {
                                "size": 5,
                                "sort": [{"timestamp": {"order": "desc"}}]
                            }
                        }
                    }
                },
            }
        }
        
        # log(f"Executing aggregation query for alert statistics...{ES_INDEX_PATTERN} : {query}")

        response = requests.post(
            f"{ES_HOST}/{ES_INDEX_PATTERN}/_search",
            json=query,
            auth=HTTPBasicAuth(ES_USERNAME, ES_PASSWORD),
            verify=ES_VERIFY_SSL,
            timeout=30
        )
        
        if response.status_code == 200:
            data = response.json()
            aggregations = data.get("aggregations", {})
            log(f"Retrieved aggregated statistics from Elasticsearch")
            return aggregations
        else:
            log(f"Elasticsearch query failed: {response.status_code} - {response.text}")
            return {}
            
    except Exception as e:
        log(f"Error querying Elasticsearch: {e}")
        return {}

# === VULNERABILITY DATA QUERY ===
def query_vulnerability_data(time_from, time_to):
    """Query Elasticsearch specifically for vulnerability alerts (no level filtering)"""
    try:
        import requests
        from requests.auth import HTTPBasicAuth
        import urllib3
        
        if not ES_VERIFY_SSL:
            urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
        
        query = {
            "size": 0,
            "query": {
                "bool": {
                    "must": [
                        {
                            "range": {
                                "timestamp": {
                                    "gte": time_from,
                                    "lte": time_to,
                                    "format": "strict_date_optional_time"
                                }
                            }
                        },
                        {
                            "terms": {
                                "rule.groups": ["vulnerability", "vulnerability-detector"]
                            }
                        }
                    ]
                }
            },
            "aggs": {
                "total_vulnerabilities": {
                    "value_count": {
                        "field": "data.vulnerability.cve"
                    }
                },
                "top_cves": {
                    "terms": {
                        "field": "data.vulnerability.cve",
                        "size": 5
                    },
                    "aggs": {
                        "cve_title": {
                            "terms": {
                                "field": "data.vulnerability.title",
                                "size": 1
                            }
                        },
                        "cve_severity": {
                            "terms": {
                                "field": "data.vulnerability.severity",
                                "size": 1
                            }
                        },
                        "cve_score": {
                            "terms": {
                                "field": "data.vulnerability.score.base",
                                "size": 1
                            }
                        },
                        "affected_agents": {
                            "terms": {
                                "field": "agent.name",
                                "size": 10
                            }
                        }
                    }
                },
                "vulnerability_severity": {
                    "terms": {
                        "field": "data.vulnerability.severity",
                        "size": 10
                    }
                },
                "top_affected_agents": {
                    "terms": {
                        "field": "agent.name",
                        "size": 5
                    },
                    "aggs": {
                        "severity_breakdown": {
                            "terms": {
                                "field": "data.vulnerability.severity",
                                "size": 10
                            }
                        }
                    }
                },
                "top_affected_packages": {
                    "terms": {
                        "field": "data.vulnerability.package.name",
                        "size": 5
                    },
                    "aggs": {
                        "severity_breakdown": {
                            "terms": {
                                "field": "data.vulnerability.severity",
                                "size": 10
                            }
                        }
                    }
                },
                "cvss_score_distribution": {
                    "range": {
                        "script": {
                            "lang": "painless",
                            "source": """
                                if (doc.containsKey('data.vulnerability.score.base') && !doc['data.vulnerability.score.base'].empty) {
                                    try {
                                        return Double.parseDouble(doc['data.vulnerability.score.base'].value);
                                    } catch (Exception e) {
                                        return null;
                                    }
                                }
                                return null;
                            """
                        },
                        "ranges": [
                            {"key": "Critical", "from": 9.0},
                            {"key": "High", "from": 7.0, "to": 9.0},
                            {"key": "Medium", "from": 4.0, "to": 7.0},
                            {"key": "Low", "from": 0.0, "to": 4.0}
                        ]
                    }
                },
                "vulnerability_status": {
                    "terms": {
                        "field": "data.vulnerability.status",
                        "size": 5
                    }
                }
            }
        }
        
        log(f"Executing vulnerability data query...{ES_INDEX_PATTERN}")
        
        response = requests.post(
            f"{ES_HOST}/{ES_INDEX_PATTERN}/_search",
            json=query,
            auth=HTTPBasicAuth(ES_USERNAME, ES_PASSWORD),
            verify=ES_VERIFY_SSL,
            timeout=30
        )
        
        if response.status_code == 200:
            data = response.json()
            aggregations = data.get("aggregations", {})
            total_vulns = aggregations.get("total_vulnerabilities", {}).get("value", 0)
            log(f"Retrieved vulnerability data from Elasticsearch: {total_vulns} total vulnerabilities")
            if total_vulns == 0:
                log(f"Warning: No vulnerabilities found")
            return aggregations
        else:
            log(f"Vulnerability query failed: {response.status_code} - {response.text}")
            return {}
            
    except Exception as e:
        log(f"Error querying vulnerability data: {e}")
        return {}

# === PERIOD COMPARISON ===
def calculate_previous_period(time_from, time_to, report_type):
    """Calculate the previous period time range for comparison"""
    from datetime import datetime, timedelta
    
    # Parse current period
    if isinstance(time_from, str):
        current_from = datetime.fromisoformat(time_from.replace('Z', '+00:00'))
        current_to = datetime.fromisoformat(time_to.replace('Z', '+00:00'))
    else:
        current_from = time_from
        current_to = time_to
    
    # Calculate period duration
    period_duration = current_to - current_from
    
    # Calculate previous period
    previous_to = current_from
    previous_from = previous_to - period_duration
    
    # Convert back to ISO format strings
    prev_from_str = previous_from.isoformat().replace('+00:00', 'Z')
    prev_to_str = previous_to.isoformat().replace('+00:00', 'Z')
    
    return prev_from_str, prev_to_str

def calculate_percentage_change(current, previous):
    """Calculate percentage change between current and previous values"""
    if previous == 0:
        if current == 0:
            return 0, "no change"
        return 100, "increase"
    
    change = ((current - previous) / previous) * 100
    if change > 0:
        return change, "increase"
    elif change < 0:
        return abs(change), "decrease"
    else:
        return 0, "no change"

# === DATA PROCESSING ===
def analyze_alerts(aggregations, vulnerability_aggregations=None):
    """Process aggregated alert data from Elasticsearch"""
    stats = {
        "total_alerts": 0,
        "by_severity": {},
        "by_agent": {},
        "by_rule": {},
        "by_mitre_tactic": {},
        "by_mitre_technique": {},
        "top_agents": [],
        "top_rules": [],
        "critical_alerts": [],
        "high_alerts": [],
        "medium_alerts": [],
        "compliance_summary": {},
        "file_integrity_events": 0,
        "vulnerability_alerts": 0,
        "authentication_events": 0,
        "vulnerabilities": {
            "total": 0,
            "top_cves": [],
            "by_severity": {},
            "top_affected_agents": [],
            "top_affected_packages": [],
            "by_cvss_score": {},
            "by_status": {}
        }
    }
    
    # Total alerts count
    stats["total_alerts"] = aggregations.get("total_alerts", {}).get("value", 0)
    
    # Severity breakdown
    severity_buckets = aggregations.get("severity_breakdown", {}).get("buckets", [])
    for bucket in severity_buckets:
        severity = bucket.get("key", "Unknown")
        count = bucket.get("doc_count", 0)
        stats["by_severity"][severity] = count
    
    # Top agents with severity breakdown
    agent_buckets = aggregations.get("top_agents", {}).get("buckets", [])
    for bucket in agent_buckets:
        agent_name = bucket.get("key", "Unknown")
        total_count = bucket.get("doc_count", 0)
        stats["by_agent"][agent_name] = total_count
        
        # Get severity breakdown
        severity_buckets = bucket.get("severity_breakdown", {}).get("buckets", [])
        critical_count = 0
        high_count = 0
        medium_count = 0
        for sev_bucket in severity_buckets:
            sev = sev_bucket.get("key", "")
            sev_count = sev_bucket.get("doc_count", 0)
            if sev == "Critical":
                critical_count = sev_count
            elif sev == "High":
                high_count = sev_count
            elif sev == "Medium":
                medium_count = sev_count
        
        # Store as dict with severity breakdown
        stats["top_agents"].append({
            "name": agent_name,
            "total": total_count,
            "critical": critical_count,
            "high": high_count,
            "medium": medium_count
        })
    
    # Sort by critical+high+medium count, then total
    stats["top_agents"] = sorted(
        stats["top_agents"],
        key=lambda x: (x["critical"] + x["high"] + x["medium"], x["total"]),
        reverse=True
    )[:10]
    
    # Top rules with descriptions, levels, and MITRE tactics
    rule_buckets = aggregations.get("top_rules", {}).get("buckets", [])
    for bucket in rule_buckets:
        rule_id = bucket.get("key", "N/A")
        count = bucket.get("doc_count", 0)
        
        # Get rule description and level from sub-aggregations
        rule_desc_buckets = bucket.get("rule_description", {}).get("buckets", [])
        description = rule_desc_buckets[0].get("key", "") if rule_desc_buckets else ""
        
        rule_level_buckets = bucket.get("rule_level", {}).get("buckets", [])
        level = rule_level_buckets[0].get("key", 0) if rule_level_buckets else 0
        
        # Get MITRE tactics for this rule
        mitre_tactic_buckets = bucket.get("mitre_tactics", {}).get("buckets", [])
        mitre_tactics = {}
        for tactic_bucket in mitre_tactic_buckets:
            tactic = tactic_bucket.get("key", "")
            tactic_count = tactic_bucket.get("doc_count", 0)
            if tactic:
                mitre_tactics[tactic] = tactic_count
        
        stats["by_rule"][rule_id] = {
            "count": count,
            "description": description,
            "level": level,
            "mitre_tactics": mitre_tactics
        }
    
    stats["top_rules"] = [
        (rule_id, data["count"], data["description"], data["level"], data["mitre_tactics"]) 
        for rule_id, data in stats["by_rule"].items()
    ][:10]
    
    # MITRE ATT&CK tactics
    tactic_buckets = aggregations.get("mitre_tactics", {}).get("buckets", [])
    for bucket in tactic_buckets:
        tactic = bucket.get("key", "")
        count = bucket.get("doc_count", 0)
        stats["by_mitre_tactic"][tactic] = count
    
    # MITRE ATT&CK techniques
    technique_buckets = aggregations.get("mitre_techniques", {}).get("buckets", [])
    for bucket in technique_buckets:
        technique = bucket.get("key", "")
        count = bucket.get("doc_count", 0)
        stats["by_mitre_technique"][technique] = count
    
    # Compliance frameworks
    compliance_buckets = aggregations.get("compliance_frameworks", {}).get("buckets", {})
    for framework, bucket in compliance_buckets.items():
        count = bucket.get("doc_count", 0)
        stats["compliance_summary"][framework.upper()] = count
    
    # Event categories
    event_buckets = aggregations.get("event_categories", {}).get("buckets", {})
    stats["file_integrity_events"] = event_buckets.get("file_integrity", {}).get("doc_count", 0)
    stats["vulnerability_alerts"] = event_buckets.get("vulnerability", {}).get("doc_count", 0)
    stats["authentication_events"] = event_buckets.get("authentication", {}).get("doc_count", 0)
    
    # Sample critical and high alerts for detailed reporting
    critical_sample = aggregations.get("critical_alerts_sample", {}).get("sample_alerts", {}).get("hits", {}).get("hits", [])
    stats["critical_alerts"] = [hit["_source"] for hit in critical_sample]
    
    high_sample = aggregations.get("high_alerts_sample", {}).get("sample_alerts", {}).get("hits", {}).get("hits", [])
    stats["high_alerts"] = [hit["_source"] for hit in high_sample]
    
    # Process vulnerability data (from separate query)
    vuln_aggs = vulnerability_aggregations if vulnerability_aggregations else {}
    if vuln_aggs:
        stats["vulnerabilities"]["total"] = vuln_aggs.get("total_vulnerabilities", {}).get("value", 0)
        
        # Top CVEs
        cve_buckets = vuln_aggs.get("top_cves", {}).get("buckets", [])
        for bucket in cve_buckets:
            cve_id = bucket.get("key", "N/A")
            count = bucket.get("doc_count", 0)
            
            # Get CVE details from sub-aggregations
            title_buckets = bucket.get("cve_title", {}).get("buckets", [])
            title = title_buckets[0].get("key", "") if title_buckets else ""
            
            severity_buckets = bucket.get("cve_severity", {}).get("buckets", [])
            severity = severity_buckets[0].get("key", "Unknown") if severity_buckets else "Unknown"
            
            score_buckets = bucket.get("cve_score", {}).get("buckets", [])
            score_str = score_buckets[0].get("key", "0") if score_buckets else "0"
            try:
                score = float(score_str) if score_str not in ["-", "-1", ""] else 0.0
            except (ValueError, TypeError):
                score = 0.0
            
            # Get affected agents
            agent_buckets = bucket.get("affected_agents", {}).get("buckets", [])
            affected_agents = [agent.get("key", "") for agent in agent_buckets]
            
            stats["vulnerabilities"]["top_cves"].append({
                "cve": cve_id,
                "count": count,
                "title": title,
                "severity": severity,
                "score": score,
                "affected_agents": affected_agents
            })
        
        # Sort by count and limit to top 10
        stats["vulnerabilities"]["top_cves"] = sorted(
            stats["vulnerabilities"]["top_cves"],
            key=lambda x: x["count"],
            reverse=True
        )[:10]
        
        # Vulnerability severity breakdown
        vuln_severity_buckets = vuln_aggs.get("vulnerability_severity", {}).get("buckets", [])
        for bucket in vuln_severity_buckets:
            severity = bucket.get("key", "Unknown")
            count = bucket.get("doc_count", 0)
            # Skip "-" or empty severity values
            if severity and severity not in ["-", "", "Unknown"]:
                stats["vulnerabilities"]["by_severity"][severity] = count
        
        # Top affected agents with severity breakdown
        vuln_agent_buckets = vuln_aggs.get("top_affected_agents", {}).get("buckets", [])
        for bucket in vuln_agent_buckets:
            agent_name = bucket.get("key", "Unknown")
            total_count = bucket.get("doc_count", 0)
            
            # Get severity breakdown
            severity_buckets = bucket.get("severity_breakdown", {}).get("buckets", [])
            critical_count = 0
            high_count = 0
            medium_count = 0
            for sev_bucket in severity_buckets:
                sev = sev_bucket.get("key", "").lower()
                sev_count = sev_bucket.get("doc_count", 0)
                if sev == "critical":
                    critical_count = sev_count
                elif sev == "high":
                    high_count = sev_count
                elif sev == "medium":
                    medium_count = sev_count
            
            stats["vulnerabilities"]["top_affected_agents"].append({
                "name": agent_name,
                "total": total_count,
                "critical": critical_count,
                "high": high_count,
                "medium": medium_count
            })
        
        # Sort by Critical count first, then High, then Medium, then total
        stats["vulnerabilities"]["top_affected_agents"] = sorted(
            stats["vulnerabilities"]["top_affected_agents"],
            key=lambda x: (x["critical"], x["high"], x["medium"], x["total"]),
            reverse=True
        )[:10]
        
        # Top affected packages with severity breakdown
        package_buckets = vuln_aggs.get("top_affected_packages", {}).get("buckets", [])
        for bucket in package_buckets:
            package_name = bucket.get("key", "Unknown")
            total_count = bucket.get("doc_count", 0)
            
            # Get severity breakdown
            severity_buckets = bucket.get("severity_breakdown", {}).get("buckets", [])
            critical_count = 0
            high_count = 0
            medium_count = 0
            for sev_bucket in severity_buckets:
                sev = sev_bucket.get("key", "").lower()
                sev_count = sev_bucket.get("doc_count", 0)
                if sev == "critical":
                    critical_count = sev_count
                elif sev == "high":
                    high_count = sev_count
                elif sev == "medium":
                    medium_count = sev_count
            
            stats["vulnerabilities"]["top_affected_packages"].append({
                "name": package_name,
                "total": total_count,
                "critical": critical_count,
                "high": high_count,
                "medium": medium_count
            })
        
        # Sort by Critical count first, then High, then Medium, then total
        stats["vulnerabilities"]["top_affected_packages"] = sorted(
            stats["vulnerabilities"]["top_affected_packages"],
            key=lambda x: (x["critical"], x["high"], x["medium"], x["total"]),
            reverse=True
        )[:10]
        
        # CVSS score distribution
        cvss_buckets = vuln_aggs.get("cvss_score_distribution", {}).get("buckets", [])
        for bucket in cvss_buckets:
            range_key = bucket.get("key", "Unknown")
            count = bucket.get("doc_count", 0)
            stats["vulnerabilities"]["by_cvss_score"][range_key] = count
        
        # Vulnerability status
        status_buckets = vuln_aggs.get("vulnerability_status", {}).get("buckets", [])
        for bucket in status_buckets:
            status = bucket.get("key", "Unknown")
            count = bucket.get("doc_count", 0)
            stats["vulnerabilities"]["by_status"][status] = count
    
    return stats

# === DASHBOARD URL BUILDER ===
# def build_dashboard_url(time_from, time_to, filters=None):
#     """Build Opensearch Dashboard URL with filters"""
#     base = f"{DASHBOARD_BASE_URL}/app/data-explorer/discover#"
    
#     # Base discover state
#     discover_state = {
#         "columns": ["_source"],
#         "isDirty": False,
#         "sort": []
#     }
    
#     metadata = {
#         "indexPattern": ES_INDEX_PATTERN,
#         "view": "discover"
#     }
    
#     # Time range
#     time_state = {
#         "from": time_from,
#         "to": time_to
#     }
    
#     # Filters
#     filter_list = []
#     if filters:
#         for f in filters:
#             if f["type"] == "phrase":
#                 filter_list.append({
#                     "$state": {"store": "appState"},
#                     "meta": {
#                         "alias": None,
#                         "disabled": False,
#                         "index": ES_INDEX_PATTERN,
#                         "key": f["field"],
#                         "negate": False,
#                         "params": f["value"],
#                         "type": "phrase",
#                         "value": f["value"]
#                     },
#                     "query": {
#                         "match_phrase": {
#                             f["field"]: {"query": f["value"]}
#                         }
#                     }
#                 })
#             elif f["type"] == "range":
#                 filter_list.append({
#                     "$state": {"store": "appState"},
#                     "meta": {
#                         "alias": None,
#                         "disabled": False,
#                         "index": ES_INDEX_PATTERN,
#                         "key": f["field"],
#                         "negate": False,
#                         "params": f["params"],
#                         "type": "range"
#                     },
#                     "range": {
#                         f["field"]: f["params"]
#                     }
#                 })
    
#     # Build URL components
#     url_params = {
#         "_a": f"(discover:{json.dumps(discover_state)},metadata:{json.dumps(metadata)})",
#         "_g": f"(filters:{json.dumps(filter_list)},time:{json.dumps(time_state)})",
#         "_q": "(filters:!(),query:(language:kuery,query:''))"
#     }
    
#     # Simplified encoding
#     url = base + "?"
#     url += f"_a=(discover:(columns:!(_source),isDirty:!f,sort:!()),metadata:(indexPattern:'{ES_INDEX_PATTERN}',view:discover))"
#     url += "&_g="
#     url += f"(filters:!("
    
#     if filter_list:
#         for i, f in enumerate(filter_list):
#             if i > 0:
#                 url += ","
#             if "query" in f:  # phrase filter
#                 field = f["meta"]["key"]
#                 value = f["meta"]["value"]
#                 url += f"(('$state':(store:appState),meta:(alias:!n,disabled:!f,index:'{ES_INDEX_PATTERN}',key:{field},negate:!f,params:{value},type:phrase,value:{value}),query:(match_phrase:({field}:(query:{value})))))"
#             elif "range" in f:  # range filter
#                 field = f["meta"]["key"]
#                 params = f["meta"]["params"]
#                 url += f"(('$state':(store:appState),meta:(alias:!n,disabled:!f,index:'{ES_INDEX_PATTERN}',key:{field},negate:!f,params:(gte:{params.get('gte', 0)},lte:{params.get('lte', 15)}),type:range),range:({field}:(gte:{params.get('gte', 0)},lte:{params.get('lte', 15)}))))"
    
#     url += f"),time:(from:'{time_from}',to:'{time_to}'))"
#     url += "&_q=(filters:!(),query:(language:kuery,query:''))"
    
#     return url
def build_dashboard_url(time_from, time_to, filters=None):
    """
    Build a valid OpenSearch Discover URL with proper Rison encoding.
    Produces URLs that properly drill through to filtered views in OpenSearch Dashboard.
    Handles special characters in field names and values correctly.
    """
    from urllib.parse import quote
    
    base = f"{DASHBOARD_BASE_URL}/app/discover#"

    # === Build filter Rison manually with proper escaping ===
    filter_rison = "!()"
    if filters:
        filter_items = []
        for f in filters:
            if f["type"] == "phrase":
                field = str(f["field"])
                value = str(f["value"])
                # Escape single quotes and backslashes for Rison string literals
                field_escaped = field.replace("\\", "\\\\").replace("'", "\\'")
                value_escaped = value.replace("\\", "\\\\").replace("'", "\\'")
                # Escape index pattern
                index_pattern_escaped = ES_INDEX_PATTERN.replace("\\", "\\\\").replace("'", "\\'")
                filter_items.append(
                    f"(meta:(alias:!n,disabled:!f,index:'{index_pattern_escaped}',key:'{field_escaped}',negate:!f,params:(query:'{value_escaped}'),type:phrase,value:'{value_escaped}'),query:(match_phrase:({field_escaped}:'{value_escaped}')))"
                )
            elif f["type"] == "range":
                field = str(f["field"])
                field_escaped = field.replace("\\", "\\\\").replace("'", "\\'")
                index_pattern_escaped = ES_INDEX_PATTERN.replace("\\", "\\\\").replace("'", "\\'")
                params = f.get("params", {})
                gte = params.get("gte")
                lte = params.get("lte")
                lt = params.get("lt")
                
                # Build params string
                param_parts = []
                if gte is not None:
                    param_parts.append(f"gte:{gte}")
                if lte is not None:
                    param_parts.append(f"lte:{lte}")
                if lt is not None:
                    param_parts.append(f"lt:{lt}")
                params_str = ",".join(param_parts)
                
                # Build range query string
                range_parts = []
                if gte is not None:
                    range_parts.append(f"gte:{gte}")
                if lte is not None:
                    range_parts.append(f"lte:{lte}")
                if lt is not None:
                    range_parts.append(f"lt:{lt}")
                range_str = ",".join(range_parts)
                
                filter_items.append(
                    f"(meta:(alias:!n,disabled:!f,index:'{index_pattern_escaped}',key:'{field_escaped}',negate:!f,params:({params_str}),type:range),range:({field_escaped}:({range_str})))"
                )
        if filter_items:
            filter_rison = f"!({','.join(filter_items)})"

    # === Compose Rison states ===
    # Escape single quotes in index pattern
    index_pattern_escaped = ES_INDEX_PATTERN.replace("\\", "\\\\").replace("'", "\\'")
    _a = f"(columns:!(_source),filters:{filter_rison},index:'{index_pattern_escaped}',sort:!())"
    
    # Escape single quotes in timestamps
    time_from_escaped = time_from.replace("'", "\\'")
    time_to_escaped = time_to.replace("'", "\\'")
    _g = f"(time:(from:'{time_from_escaped}',to:'{time_to_escaped}'))"
    _q = "(query:(language:kuery,query:''))"

    # === Assemble final URL ===
    # Rison strings need to be URL-encoded, but preserve Rison syntax characters
    # Preserve: () for structure, ! for arrays, , for separators, : for key-value, ' for strings
    # Encode: spaces, &, =, #, and other special URL characters
    _a_encoded = quote(_a, safe='()!,\':')
    _g_encoded = quote(_g, safe='()!,\':')
    _q_encoded = quote(_q, safe='()!,\':')
    
    url = f"{base}?_a={_a_encoded}&_g={_g_encoded}&_q={_q_encoded}"
    return url

def build_mitre_attack_url(time_from, time_to, tactic):
    """
    Build MITRE ATT&CK dashboard URL with tactic filter.
    """
    from urllib.parse import quote
    import re
    
    base = f"{DASHBOARD_BASE_URL}/app/mitre-attack#/overview/"
    
    # Escape index pattern for Rison
    index_pattern_escaped = ES_INDEX_PATTERN.replace("\\", "\\\\").replace("'", "\\'")
    
    # Check if tactic needs quotes (if it contains spaces or special characters)
    # Rison identifiers don't need quotes, but strings with spaces/special chars do
    tactic_clean = str(tactic).strip()
    needs_quotes = bool(re.search(r'[^a-zA-Z0-9_-]', tactic_clean))
    
    if needs_quotes:
        # Escape single quotes and backslashes for Rison string
        tactic_escaped = tactic_clean.replace("\\", "\\\\").replace("'", "\\'")
        tactic_value = f"'{tactic_escaped}'"
    else:
        # Simple identifier, no quotes needed
        tactic_value = tactic_clean
    
    # Build filter for the specific tactic
    # The filter structure matches: ('$state':(store:appState),meta:(...),query:(...))
    filter_rison = f"!(('$state':(store:appState),meta:(alias:!n,disabled:!f,index:'{index_pattern_escaped}',key:rule.mitre.tactic,negate:!f,params:(query:{tactic_value}),type:phrase),query:(match_phrase:(rule.mitre.tactic:{tactic_value}))))"
    
    # Build Rison states
    _a = f"(filters:{filter_rison},query:(language:kuery,query:''))"
    
    # Convert time range - use absolute time format
    time_from_escaped = time_from.replace("'", "\\'")
    time_to_escaped = time_to.replace("'", "\\'")
    _g = f"(filters:!(),refreshInterval:(pause:!t,value:0),time:(from:'{time_from_escaped}',to:'{time_to_escaped}'))"
    
    # URL encode
    _a_encoded = quote(_a, safe='()!,\':')
    _g_encoded = quote(_g, safe='()!,\':')
    
    url = f"{base}?tab=mitre&tabView=dashboard&_a={_a_encoded}&_g={_g_encoded}&tabRedirect=groups"
    return url

def build_compliance_url(time_from, time_to, framework):
    """
    Build compliance framework dashboard URL (GDPR, HIPAA, NIST_800_53, PCI_DSS).
    """
    from urllib.parse import quote
    
    # Map framework names to dashboard paths
    framework_map = {
        "GDPR": "gdpr",
        "HIPAA": "hipaa",
        "NIST_800_53": "nist",
        "PCI_DSS": "pci"
    }
    
    framework_lower = framework_map.get(framework.upper(), framework.lower())
    base = f"{DASHBOARD_BASE_URL}/app/{framework_lower}#/overview/"
    
    # Build Rison states
    _a = "(filters:!(),query:(language:kuery,query:''))"
    
    # Convert time range
    time_from_escaped = time_from.replace("'", "\\'")
    time_to_escaped = time_to.replace("'", "\\'")
    _g = f"(filters:!(),refreshInterval:(pause:!t,value:0),time:(from:'{time_from_escaped}',to:'{time_to_escaped}'))"
    
    # URL encode
    _a_encoded = quote(_a, safe='()!,\':')
    _g_encoded = quote(_g, safe='()!,\':')
    
    url = f"{base}?tab={framework_lower}&tabView=dashboard&_a={_a_encoded}&_g={_g_encoded}"
    return url

def build_file_integrity_url(time_from, time_to):
    """
    Build File Integrity Monitoring dashboard URL.
    """
    from urllib.parse import quote
    
    base = f"{DASHBOARD_BASE_URL}/app/file-integrity-monitoring#/overview/"
    
    # Build Rison states
    _a = "(filters:!(),query:(language:kuery,query:''))"
    
    # Convert time range
    time_from_escaped = time_from.replace("'", "\\'")
    time_to_escaped = time_to.replace("'", "\\'")
    _g = f"(filters:!(),refreshInterval:(pause:!t,value:0),time:(from:'{time_from_escaped}',to:'{time_to_escaped}'))"
    
    # URL encode
    _a_encoded = quote(_a, safe='()!,\':')
    _g_encoded = quote(_g, safe='()!,\':')
    
    url = f"{base}?tab=fim&tabView=dashboard&_a={_a_encoded}&_g={_g_encoded}"
    return url

def build_vulnerability_detection_url(time_from, time_to, cve_id=None, agent_name=None, package_name=None, severity=None):
    """
    Build Vulnerability Detection dashboard URL with filters.
    Uses wazuh-states-vulnerabilities-* index and proper field mappings.
    Supports filtering by CVE ID, agent/host name, package name, and severity.
    """
    from urllib.parse import quote, quote_plus
    
    base = f"{DASHBOARD_BASE_URL}/app/vulnerability-detection#/overview/"
    
    # Convert time range
    time_from_escaped = time_from.replace("'", "\\'")
    time_to_escaped = time_to.replace("'", "\\'")
    _g = f"(filters:!(),refreshInterval:(pause:!t,value:0),time:(from:'{time_from_escaped}',to:'{time_to_escaped}'))"
    
    # Use wazuh-states-vulnerabilities-* index pattern for vulnerability dashboard
    vuln_index_pattern = "wazuh-states-vulnerabilities-*"
    filter_items = []
    
    # Add severity filter if provided - uses custom query type with bool query
    if severity:
        severity_escaped = str(severity).replace("'", "\\'").replace("\\", "\\\\")
        # Build the bool query JSON and URL encode it (percent encoding)
        bool_query_json = f'{{"bool":{{"must":[],"filter":[{{"bool":{{"should":[{{"match_phrase":{{"vulnerability.severity":"{severity_escaped}"}}}}],"minimum_should_match":1}}}}],"should":[],"must_not":[]}}}}'
        bool_query_encoded = quote_plus(bool_query_json)
        
        # Build the Rison filter with proper structure
        filter_items.append(f"('$state':(store:appState),meta:(alias:{severity_escaped},disabled:!f,index:'{vuln_index_pattern}',key:query,negate:!f,type:custom,value:'{bool_query_encoded}'),query:(bool:(filter:!((bool:(minimum_should_match:1,should:!((match_phrase:(vulnerability.severity:{severity_escaped})))))),must:!(),must_not:!(),should:!())))")
    
    # Add CVE filter if provided - uses vulnerability.id field
    if cve_id:
        cve_escaped = str(cve_id).replace("'", "\\'").replace("\\", "\\\\")
        # CVE values don't need quotes in params if they're simple identifiers (no spaces)
        # But we need to check if it needs quotes
        if ' ' in cve_escaped or '-' in cve_escaped:
            # Has spaces or special chars, use quotes
            filter_items.append(f"('$state':(store:appState),meta:(alias:!n,disabled:!f,index:'{vuln_index_pattern}',key:vulnerability.id,negate:!f,params:(query:'{cve_escaped}'),type:phrase),query:(match_phrase:(vulnerability.id:'{cve_escaped}')))")
        else:
            # Simple identifier, no quotes needed
            filter_items.append(f"('$state':(store:appState),meta:(alias:!n,disabled:!f,index:'{vuln_index_pattern}',key:vulnerability.id,negate:!f,params:(query:{cve_escaped}),type:phrase),query:(match_phrase:(vulnerability.id:{cve_escaped})))")
    
    # Add agent name filter if provided - uses agent.name field
    if agent_name:
        agent_escaped = str(agent_name).replace("'", "\\'").replace("\\", "\\\\")
        # Agent names without spaces don't need quotes in params
        if ' ' in agent_escaped or any(c in agent_escaped for c in ['(', ')', ':', '/']):
            # Has spaces or special chars, use quotes
            filter_items.append(f"('$state':(store:appState),meta:(alias:!n,disabled:!f,index:'{vuln_index_pattern}',key:agent.name,negate:!f,params:(query:'{agent_escaped}'),type:phrase),query:(match_phrase:(agent.name:'{agent_escaped}')))")
        else:
            # Simple identifier, no quotes needed
            filter_items.append(f"('$state':(store:appState),meta:(alias:!n,disabled:!f,index:'{vuln_index_pattern}',key:agent.name,negate:!f,params:(query:{agent_escaped}),type:phrase),query:(match_phrase:(agent.name:{agent_escaped})))")
    
    # Add package name filter if provided - uses package.name field
    if package_name:
        package_escaped = str(package_name).replace("'", "\\'").replace("\\", "\\\\")
        # Package names without spaces don't need quotes in params
        if ' ' in package_escaped or any(c in package_escaped for c in ['(', ')', ':', '/']):
            # Has spaces or special chars, use quotes
            package_url_encoded = quote_plus(package_escaped)
            filter_items.append(f"('$state':(store:appState),meta:(alias:!n,disabled:!f,index:'{vuln_index_pattern}',key:package.name,negate:!f,params:(query:'{package_url_encoded}'),type:phrase),query:(match_phrase:(package.name:'{package_url_encoded}')))")
        else:
            # Simple identifier, no quotes needed
            filter_items.append(f"('$state':(store:appState),meta:(alias:!n,disabled:!f,index:'{vuln_index_pattern}',key:package.name,negate:!f,params:(query:{package_escaped}),type:phrase),query:(match_phrase:(package.name:{package_escaped})))")
    
    # Build filter Rison
    if filter_items:
        filter_rison = f"!({','.join(filter_items)})"
        _a = f"(filters:{filter_rison},query:(language:kuery,query:''))"
    else:
        _a = "(filters:!(),query:(language:kuery,query:''))"
    
    # URL encode
    _a_encoded = quote(_a, safe='()!,\':')
    _g_encoded = quote(_g, safe='()!,\':')
    
    # Note: For vulnerability detection, _g comes before _a in the URL
    url = f"{base}?tab=vuls&tabView=dashboard&_g={_g_encoded}&_a={_a_encoded}"
    return url


# === AI ANALYSIS ===
def get_ai_report_summary(stats, report_type, time_from, time_to):
    """Generate AI-powered executive summary and insights"""
    if not OLLAMA_ENABLED:
        return None
    
    try:
        import requests
        
        # Prepare data summary for AI
        top_agents_list = []
        for agent_data in stats["top_agents"][:5]:
            if isinstance(agent_data, dict):
                name = agent_data.get('name', 'Unknown')
                critical = agent_data.get('critical', 0)
                high = agent_data.get('high', 0)
                medium = agent_data.get('medium', 0)
                top_agents_list.append(f"  - {name}: Critical: {critical}, High: {high}, Medium: {medium}")
            else:
                # Fallback for old format
                name = agent_data[0]
                count = agent_data[1]
                top_agents_list.append(f"  - {name}: {count} alerts")
        top_agents_str = "\n".join(top_agents_list)
        
        # Handle top_rules - ensure it's a list of tuples
        top_rules_list = []
        try:
            if stats.get("top_rules"):
                for rule_item in stats["top_rules"][:5]:
                    try:
                        if isinstance(rule_item, (list, tuple)) and len(rule_item) >= 5:
                            # New format with MITRE tactics
                            rule_id, count, desc, level, mitre_tactics = rule_item[0], rule_item[1], rule_item[2], rule_item[3], rule_item[4]
                            mitre_str = ""
                            if mitre_tactics and len(mitre_tactics) > 0:
                                sorted_tactics = sorted(mitre_tactics.items(), key=lambda x: x[1], reverse=True)[:3]
                                tactic_names = [f"{tactic}({t_count})" for tactic, t_count in sorted_tactics]
                                mitre_str = f", MITRE: {', '.join(tactic_names)}"
                            top_rules_list.append(f"  - Rule {rule_id}: {desc} ({count} occurrences, Level {level}{mitre_str})")
                        elif isinstance(rule_item, (list, tuple)) and len(rule_item) >= 4:
                            # Old format without MITRE tactics
                            rule_id, count, desc, level = rule_item[0], rule_item[1], rule_item[2], rule_item[3]
                            top_rules_list.append(f"  - Rule {rule_id}: {desc} ({count} occurrences, Level {level})")
                        elif isinstance(rule_item, (list, tuple)) and len(rule_item) == 2:
                            # Fallback for very old format
                            rule_id, count = rule_item[0], rule_item[1]
                            top_rules_list.append(f"  - Rule {rule_id}: {count} occurrences")
                        else:
                            log(f"Warning: Unexpected top_rules item format: {type(rule_item)}, value: {rule_item}")
                    except Exception as e:
                        log(f"Error processing top_rules item {rule_item}: {e}")
                        continue
        except Exception as e:
            log(f"Error processing top_rules: {e}, top_rules type: {type(stats.get('top_rules'))}, value: {stats.get('top_rules')}")
        top_rules_str = "\n".join(top_rules_list) if top_rules_list else "  - No rules data available"
        
        # Handle MITRE tactics - ensure it's a dict
        mitre_tactics_list = []
        try:
            by_mitre_tactic = stats.get("by_mitre_tactic", {})
            # log(f"Debug: by_mitre_tactic type: {type(by_mitre_tactic)}, value: {by_mitre_tactic}")
            
            if isinstance(by_mitre_tactic, dict):
                try:
                    sorted_tactics = sorted(by_mitre_tactic.items(), key=lambda x: x[1] if isinstance(x[1], (int, float)) else 0, reverse=True)[:5]
                    for item in sorted_tactics:
                        try:
                            if len(item) == 2:
                                tactic, count = item[0], item[1]
                                mitre_tactics_list.append(f"  - {tactic}: {count}")
                            else:
                                log(f"Warning: Unexpected MITRE tactic item format: {item}, length: {len(item)}")
                        except Exception as e:
                            log(f"Error unpacking MITRE tactic item {item}: {e}")
                            continue
                except Exception as e:
                    log(f"Error sorting MITRE tactics: {e}")
            elif isinstance(by_mitre_tactic, list):
                # Handle if it's a list instead of dict
                for item in by_mitre_tactic[:5]:
                    try:
                        if isinstance(item, (list, tuple)) and len(item) >= 2:
                            tactic, count = item[0], item[1]
                            mitre_tactics_list.append(f"  - {tactic}: {count}")
                    except Exception as e:
                        log(f"Error processing MITRE tactic list item {item}: {e}")
                        continue
            else:
                log(f"Warning: by_mitre_tactic is neither dict nor list: {type(by_mitre_tactic)}")
        except Exception as e:
            log(f"Error processing MITRE tactics: {e}")
        mitre_tactics_str = "\n".join(mitre_tactics_list) if mitre_tactics_list else "  - No MITRE tactics data available"
        
        # Prepare comparison data for AI
        comparison_str = ""
        if stats.get('comparisons'):
            comp = stats['comparisons']
            prev_period = stats.get('previous_period', {})
            comparison_str = f"""
**PERIOD-OVER-PERIOD COMPARISON (vs Previous Period: {prev_period.get('from', 'N/A')} to {prev_period.get('to', 'N/A')}):**
- Total Alerts: {comp['total_alerts']['current']} (Previous: {comp['total_alerts']['previous']}, Change: {comp['total_alerts']['change_pct']:.1f}% {comp['total_alerts']['change_type']})
- Critical Alerts: {comp['critical']['current']} (Previous: {comp['critical']['previous']}, Change: {comp['critical']['change_pct']:.1f}% {comp['critical']['change_type']})
- High Alerts: {comp['high']['current']} (Previous: {comp['high']['previous']}, Change: {comp['high']['change_pct']:.1f}% {comp['high']['change_type']})
- Medium Alerts: {comp['medium']['current']} (Previous: {comp['medium']['previous']}, Change: {comp['medium']['change_pct']:.1f}% {comp['medium']['change_type']})

Note: A decrease in alerts is generally positive (green), while an increase may indicate growing threats (red). Consider these trends in your analysis.
"""
        
        # Prepare vulnerability comparison data
        vuln_comparison_str = ""
        if stats.get('vulnerabilities') and stats.get('previous_period'):
            prev_vuln_total = stats.get('prev_vulnerabilities', {}).get('total', 0)
            current_vuln_total = stats['vulnerabilities'].get('total', 0)
            if prev_vuln_total > 0 or current_vuln_total > 0:
                vuln_pct_change, vuln_change_type = calculate_percentage_change(current_vuln_total, prev_vuln_total)
                vuln_comparison_str = f"""
**VULNERABILITY TRENDS (vs Previous Period):**
- Total Vulnerabilities: {current_vuln_total} (Previous: {prev_vuln_total}, Change: {vuln_pct_change:.1f}% {vuln_change_type})
"""
        
        prompt = f"""Senior cybersecurity analyst for Athena SOC. Generate {report_type} security report for {time_from} to {time_to}.

**METRICS:**
Alerts: Total={stats['total_alerts']}, Critical={stats['by_severity'].get('Critical', 0)}, High={stats['by_severity'].get('High', 0)}, Medium={stats['by_severity'].get('Medium', 0)}
{comparison_str}

**TOP SYSTEMS (Top 5):**
{top_agents_str if top_agents_str else 'None'}

**TOP RULES (Top 5):**
{top_rules_str if top_rules_str else 'None'}
(Rule levels: 15+=Critical, 12-14=High, 7-11=Medium)

**MITRE ATT&CK:**
{mitre_tactics_str}

**EVENT CATEGORIES:**
FIM={stats['file_integrity_events']}, Vuln={stats['vulnerability_alerts']}, Auth={stats['authentication_events']}

**VULNERABILITIES:**
{f'''Total={stats['vulnerabilities'].get('total', 0)}
{vuln_comparison_str}
Severity: {', '.join([f"{k}={v}" for k, v in sorted(stats['vulnerabilities'].get('by_severity', {}).items(), key=lambda x: {'Critical': 4, 'High': 3, 'Medium': 2, 'Low': 1}.get(x[0], 0), reverse=True)]) if stats['vulnerabilities'].get('by_severity') else 'N/A'}

Top CVEs (Top 5):
{chr(10).join([f"{cve.get('cve', 'N/A')}: {cve.get('title', 'N/A')[:50]}{'...' if len(cve.get('title', '')) > 50 else ''} | Sev={cve.get('severity', 'N/A')}, CVSS={cve.get('score', 0):.1f}, Count={cve.get('count', 0)}, Systems={len(cve.get('affected_agents', []))}" for cve in stats['vulnerabilities'].get('top_cves', [])[:5]]) if stats['vulnerabilities'].get('top_cves') else 'None'}

Top Affected Systems:
{chr(10).join([f"{agent_data.get('name', 'N/A')}: Total={agent_data.get('total', 0)} (C={agent_data.get('critical', 0)}, H={agent_data.get('high', 0)}, M={agent_data.get('medium', 0)})" if isinstance(agent_data, dict) else f"{agent_data[0]}: {agent_data[1]}" for agent_data in stats['vulnerabilities'].get('top_affected_agents', [])[:5]]) if stats['vulnerabilities'].get('top_affected_agents') else 'None'}

Top Packages:
{chr(10).join([f"{pkg_data.get('name', 'N/A')}: Total={pkg_data.get('total', 0)} (C={pkg_data.get('critical', 0)}, H={pkg_data.get('high', 0)}, M={pkg_data.get('medium', 0)})" if isinstance(pkg_data, dict) else f"{pkg_data[0]}: {pkg_data[1]}" for pkg_data in stats['vulnerabilities'].get('top_affected_packages', [])[:5]]) if stats['vulnerabilities'].get('top_affected_packages') else 'None'}
''' if stats.get('vulnerabilities', {}).get('total', 0) > 0 else 'None'}

**COMPLIANCE:**
{', '.join([f"{k}={v}" for k, v in stats['compliance_summary'].items()]) if stats['compliance_summary'] else 'None'}

**ALERTS:**
Critical={len(stats['critical_alerts'])}, High={len(stats['high_alerts'])}

**OUTPUT JSON:**
{{
  "executive_summary": "2-3 paragraphs: security posture, key trends, critical items. Reference specific numbers.",
  "trend_summary": "Period-over-period trend analysis with specific numbers, percentage changes, and what they indicate for security posture",
  "key_findings": ["3-5 specific findings with numbers/percentages"],
  "threat_landscape": "Attack patterns, MITRE tactics, threat trends",
  "critical_concerns": ["Immediate attention items"] or null,
  "recommendations": ["3-5 actionable, prioritized recommendations"],
  "positive_observations": ["Security improvements/positive trends"] or null,
  "overall_risk_rating": "Low/Medium/High/Critical"
}}

**GUIDELINES:**
- Data-driven: reference numbers, percentages, system names, CVE IDs, rule IDs
- Prioritize: high CVSS vulns, wide system impact, significant trends
- Executive-friendly: explain business/security impact, not just technical details
- Risk-based: assess using alert volumes, severity, vuln status, trends"""

        headers = {
            "Content-Type": "application/json"
        }

        payload = {
            "model": OLLAMA_MODEL,
            "messages": [
                {
                    "role": "system",
                    "content": "You are a senior cybersecurity analyst and report writer with expertise in SIEM analysis, threat intelligence, and vulnerability management. Provide clear, executive-level security analysis with actionable insights. Your reports should be data-driven, specific, and prioritize findings by risk and business impact. If a data field is empty, null, or 'N/A', state that the information is unavailable — do not speculate or hallucinate. Return ONLY valid JSON. Do not include any text before or after the JSON object."
                },
                {
                    "role": "user",
                    "content": prompt
                }
            ],
            "temperature": 0.3,
            "max_tokens": 8192,
            "response_format": {"type": "json_object"}
        }

        log(f"Calling Ollama API at {OLLAMA_API_URL} for {report_type} report analysis...")

        # Retry logic with exponential backoff
        max_retries = 2
        retry_delay = 5  # seconds
        timeout_config = (10, 300)  # (connect_timeout, read_timeout)

        for attempt in range(max_retries + 1):
            try:
                response = requests.post(
                    OLLAMA_API_URL,
                    headers=headers,
                    json=payload,
                    timeout=timeout_config
                )

                if response.status_code == 200:
                    result = response.json()
                    ai_content = result['choices'][0]['message']['content']
                    ai_analysis = json.loads(ai_content)
                    log("AI report analysis completed successfully")
                    return ai_analysis
                elif response.status_code == 429:  # Rate limit
                    if attempt < max_retries:
                        wait_time = retry_delay * (2 ** attempt)
                        log(f"Rate limited. Retrying in {wait_time} seconds...")
                        time.sleep(wait_time)
                        continue
                    else:
                        log(f"Ollama API rate limit error after {max_retries} retries")
                        return None
                else:
                    log(f"Ollama API error: {response.status_code} - {response.text}")
                    return None

            except requests.exceptions.Timeout as e:
                if attempt < max_retries:
                    log(f"Ollama API timeout (attempt {attempt + 1}/{max_retries + 1}). Retrying...")
                    time.sleep(retry_delay)
                    continue
                else:
                    log(f"Ollama API timeout after {max_retries} retries: {e}")
                    return None
            except requests.exceptions.RequestException as e:
                if attempt < max_retries:
                    log(f"Ollama API request error (attempt {attempt + 1}/{max_retries + 1}): {e}. Retrying...")
                    time.sleep(retry_delay)
                    continue
                else:
                    log(f"Ollama API request error after {max_retries} retries: {e}")
                    return None
            
    except Exception as e:
        import traceback
        traceback.print_exc()
        log(f"Error getting AI report analysis: {e}")
        log(f"Traceback: {traceback.format_exc()}")
        return None

# === PROFESSIONAL HTML REPORT GENERATOR ===
def format_comparison_html(comparison_key, stats, colors):
    """Format comparison indicator HTML"""
    if not stats.get('comparisons') or comparison_key not in stats['comparisons']:
        return '<div style="color:' + colors['text_light'] + ';font-size:11px;margin-bottom:8px;visibility:hidden;height:14px;">&nbsp;</div>'
    
    comp = stats['comparisons'][comparison_key]
    change_type = comp.get('change_type', 'no change')
    change_pct = comp.get('change_pct', 0)
    
    if change_type == 'decrease':
        color = colors['success']
        arrow = '↓'
    elif change_type == 'increase':
        color = colors['danger']
        arrow = '↑'
    else:
        color = colors['text_light']
        arrow = '→'
    
    return f'<div style="color:{color};font-size:11px;margin-bottom:8px;font-weight:500;">{arrow} {change_pct:.1f}% vs previous period</div>'

def build_html_report(report_type, time_from, time_to, stats, ai_analysis):
    """Build professional HTML email report"""
    
    from html import escape as html_escape
    
    # Format dates
    from_date = datetime.fromisoformat(time_from.replace('Z', '+00:00')).strftime('%B %d, %Y')
    to_date = datetime.fromisoformat(time_to.replace('Z', '+00:00')).strftime('%B %d, %Y')
    
    # Professional color scheme
    colors = {
        "primary": "#1e40af",
        "secondary": "#64748b", 
        "success": "#059669",
        "warning": "#d97706",
        "danger": "#dc2626",
        "info": "#0284c7",
        "light": "#f8fafc",
        "dark": "#1e293b",
        "border": "#e2e8f0",
        "text": "#374151",
        "text_light": "#6b7280"
    }
    
    # Build dashboard links
    all_alerts_url = build_dashboard_url(time_from, time_to)
    critical_url = build_dashboard_url(time_from, time_to, [
        {"type": "range", "field": "rule.level", "params": {"gte": 15, "lte": 20}}
    ])
    high_url = build_dashboard_url(time_from, time_to, [
        {"type": "range", "field": "rule.level", "params": {"gte": 12, "lte": 14}}
    ])
    medium_url = build_dashboard_url(time_from, time_to, [
        {"type": "range", "field": "rule.level", "params": {"gte": 7, "lte": 11}}
    ])
    # low_url = build_dashboard_url(time_from, time_to, [
    #     {"type": "range", "field": "rule.level", "params": {"gte": 0, "lte": 6}}
    # ])

# === Unified AI Analysis Section (Complete Version) ===
    ai_section = ""
    if ai_analysis:
        # Dynamic color map for priority
        priority = ai_analysis.get("recommended_priority", "").capitalize()
        priority_color = {
            "Immediate": "#dc2626",  # red
            "High": "#fb8c00",       # orange
            "Medium": "#facc15",     # yellow
            "Low": "#22c55e"         # green
        }.get(priority, "#6b7280")

        # Dynamic color map for risk rating
        risk = ai_analysis.get("overall_risk_rating", "").capitalize()
        risk_color = {
            "Critical": "#b91c1c",
            "High": "#fb8c00",
            "Medium": "#facc15",
            "Low": "#22c55e"
        }.get(risk, "#6b7280")

        # Build unified boxed container
        ai_section = f"""
        <table width="100%" cellpadding="0" cellspacing="0" border="0" 
            style="background:#f0f9ff;border:1px solid #c7d2fe;border-radius:6px;margin:24px 0;">
        <tr>
            <td style="background:#0d47a1;padding:12px 20px;
                    border-top-left-radius:6px;border-top-right-radius:6px;">
            <h2 style="margin:0;color:#fff;font-size:16px;font-weight:600;">
                Athena AI: Security Analysis
            </h2>
            </td>
        </tr>
        <tr>
            <td style="padding:20px;color:#1e293b;font-size:14px;line-height:1.6;">


            <!-- Overall Risk Rating -->
            {f"""
            <div style='margin-top:6px;margin-bottom:24px;'>
                <span style='background:{risk_color};color:#fff;padding:4px 10px;
                            border-radius:12px;font-size:13px;font-weight:600;'>
                Overall Risk Rating: {html.escape(risk or 'N/A')}
                </span>
            </div>
            """ if risk else ''}

            <!-- Executive Summary -->
            <div style="margin-bottom:16px;">
                <strong>Executive Summary:</strong>
                <p style="margin:4px 0;">{html.escape(ai_analysis.get('executive_summary', 'No executive summary available.'))}</p>
            </div>

            <!-- Key Findings -->
            {f"""
            <div style='margin-bottom:16px;'>
                <strong>Key Findings:</strong>
                <ul style='margin:6px 0;padding-left:20px;'>
                {''.join([f"<li style='margin:4px 0;'>{html.escape(finding)}</li>" for finding in ai_analysis.get('key_findings', [])])}
                </ul>
            </div>
            """ if ai_analysis.get('key_findings') else ''}

            <!-- Critical Concerns -->
            {f"""
            <div style='margin-bottom:16px;background:#fef2f2;padding:12px;border-radius:4px;border-left:4px solid #dc2626;'>
                <strong style='color:#dc2626;'>Critical Concerns:</strong>
                <ul style='margin:6px 0;padding-left:20px;'>
                {''.join([f"<li style='margin:4px 0;color:#dc2626;'><strong>{html.escape(concern)}</strong></li>" for concern in ai_analysis.get('critical_concerns', [])])}
                </ul>
            </div>
            """ if ai_analysis.get('critical_concerns') else ''}

            <!-- Recommendations -->
            {f"""
            <div style='margin-bottom:16px;'>
                <strong>Recommendations:</strong>
                <ol style='margin:6px 0;padding-left:20px;'>
                {''.join([f"<li style='margin:4px 0;'>{html.escape(rec)}</li>" for rec in ai_analysis.get('recommendations', [])])}
                </ol>
            </div>
            """ if ai_analysis.get('recommendations') else ''}

            <!-- AI Recommended Priority -->
            {f"""
            <div style='margin-top:20px;'>
                <span style='background:{priority_color};color:#fff;padding:4px 10px;
                            border-radius:12px;font-size:13px;font-weight:600;'>
                AI Recommended Priority: {html.escape(priority or 'N/A')}
                </span>
            </div>
            """ if priority else ''}


            </td>
        </tr>
        </table>
        """
    
    # Top Agents Table with severity breakdown and drill-through links
    top_agents_rows = ""
    for i, agent_data in enumerate(stats["top_agents"][:10], 1):
        agent_name = agent_data.get("name") if isinstance(agent_data, dict) else agent_data[0]
        critical_count = agent_data.get("critical", 0) if isinstance(agent_data, dict) else 0
        high_count = agent_data.get("high", 0) if isinstance(agent_data, dict) else 0
        medium_count = agent_data.get("medium", 0) if isinstance(agent_data, dict) else 0
        
        # Base agent URL
        agent_url = build_dashboard_url(time_from, time_to, [
            {"type": "phrase", "field": "agent.name", "value": agent_name}
        ])
        
        # URLs for each severity level (based on rule.level ranges)
        critical_url = build_dashboard_url(time_from, time_to, [
            {"type": "phrase", "field": "agent.name", "value": agent_name},
            {"type": "range", "field": "rule.level", "params": {"gte": 15}}
        ])
        high_url = build_dashboard_url(time_from, time_to, [
            {"type": "phrase", "field": "agent.name", "value": agent_name},
            {"type": "range", "field": "rule.level", "params": {"gte": 12, "lt": 15}}
        ])
        medium_url = build_dashboard_url(time_from, time_to, [
            {"type": "phrase", "field": "agent.name", "value": agent_name},
            {"type": "range", "field": "rule.level", "params": {"gte": 7, "lt": 12}}
        ])
        
        top_agents_rows += f"""
        <tr style="background:{'#fafafa' if i % 2 == 0 else '#fff'};">
            <td style="padding:14px 16px;border-bottom:1px solid {colors['border']};font-size:14px;color:{colors['text']};font-weight:600;">{i}</td>
            <td style="padding:14px 16px;border-bottom:1px solid {colors['border']};">
                <a href="{agent_url}" style="color:{colors['primary']};text-decoration:none;font-weight:600;font-size:14px;display:inline-block;margin-bottom:6px;">{html_escape(agent_name)}</a>
            </td>
            <td style="padding:14px 16px;border-bottom:1px solid {colors['border']};text-align:right;vertical-align:middle;">
                <div style="display:inline-block;text-align:right;">
                    <a href="{critical_url}" style="text-decoration:none;display:inline-block;margin-right:4px;"><span style="background:{colors['danger']};color:#fff;padding:4px 8px;border-radius:4px;font-weight:600;font-size:12px;display:inline-block;">Critical: {critical_count}</span></a>
                    <a href="{high_url}" style="text-decoration:none;display:inline-block;margin-right:4px;"><span style="background:{colors['warning']};color:#fff;padding:4px 8px;border-radius:4px;font-weight:600;font-size:12px;display:inline-block;">High: {high_count}</span></a>
                    <a href="{medium_url}" style="text-decoration:none;display:inline-block;"><span style="background:{colors['info']};color:#fff;padding:4px 8px;border-radius:4px;font-weight:600;font-size:12px;display:inline-block;">Medium: {medium_count}</span></a>
                </div>
            </td>
        </tr>
"""
    
    # Top Rules Table
    top_rules_rows = ""
    for i, rule_data in enumerate(stats["top_rules"][:5], 1):
        # Handle both old format (4 items) and new format (5 items with MITRE tactics)
        if len(rule_data) == 5:
            rule_id, count, desc, level, mitre_tactics = rule_data
        else:
            rule_id, count, desc, level = rule_data[:4]
            mitre_tactics = {}
        
        severity = "Critical" if level >= 15 else "High" if level >= 12 else "Medium" if level >= 7 else "Low"
        rule_url = build_dashboard_url(time_from, time_to, [
            {"type": "phrase", "field": "rule.id", "value": rule_id}
        ])
        severity_color = colors['danger'] if severity == 'Critical' else colors['warning'] if severity == 'High' else colors['info'] if severity == 'Medium' else colors['success']
        
        # Build MITRE tactics distribution display
        mitre_display = ""
        if mitre_tactics and len(mitre_tactics) > 0:
            sorted_tactics = sorted(mitre_tactics.items(), key=lambda x: x[1], reverse=True)
            total_tactics_count = sum(mitre_tactics.values())
            tactic_badges = []
            for tactic, tactic_count in sorted_tactics[:3]:  # Show top 3 tactics
                percentage = (tactic_count * 100) // total_tactics_count if total_tactics_count > 0 else 0
                tactic_badges.append(f'<span style="background:{colors["light"]};color:{colors["text"]};padding:2px 6px;border-radius:3px;font-size:11px;margin-right:4px;border:1px solid {colors["border"]};">{html_escape(tactic[:20])} ({tactic_count})</span>')
            if len(sorted_tactics) > 3:
                tactic_badges.append(f'<span style="color:{colors["text_light"]};font-size:11px;">+{len(sorted_tactics) - 3} more</span>')
            mitre_display = '<div style="margin-top:4px;">' + ''.join(tactic_badges) + '</div>'
        else:
            mitre_display = '<div style="margin-top:4px;color:' + colors['text_light'] + ';font-size:11px;font-style:italic;">No MITRE tactics</div>'
        
        top_rules_rows += f"""
        <tr>
            <td style="padding:12px 16px;border-bottom:1px solid {colors['border']};">
                <a href="{rule_url}" style="color:{colors['primary']};text-decoration:none;font-weight:500;font-size:14px;">{rule_id}</a>
            </td>
            <td style="padding:12px 16px;border-bottom:1px solid {colors['border']};font-size:14px;color:{colors['text']};">{html_escape(desc[:60] + '...' if len(desc) > 60 else desc)}</td>
            <td style="padding:12px 16px;border-bottom:1px solid {colors['border']};text-align:center;">
                <span style="background:{severity_color};color:#fff;padding:4px 12px;border-radius:4px;font-size:12px;font-weight:500;display:inline-block;width:80px;text-align:center;box-sizing:border-box;">
                    {severity}
                </span>
            </td>
            <td style="padding:12px 16px;border-bottom:1px solid {colors['border']};text-align:right;">
                <div style="font-weight:600;font-size:14px;color:{colors['text']};margin-bottom:4px;">{count}</div>
                {mitre_display}
            </td>
        </tr>
"""
    
    # MITRE ATT&CK Table with enhanced visualization
    mitre_rows = ""
    sorted_tactics = sorted(stats["by_mitre_tactic"].items(), key=lambda x: x[1], reverse=True)[:8]
    total_mitre_alerts = sum([count for _, count in sorted_tactics]) if sorted_tactics else 1
    
    for i, (tactic, count) in enumerate(sorted_tactics, 1):
        max_count = max([count for _, count in sorted_tactics]) if sorted_tactics else 1
        percentage = min(100, (count * 100) // max_count)
        total_percentage = (count * 100) // total_mitre_alerts if total_mitre_alerts > 0 else 0
        mitre_url = build_mitre_attack_url(time_from, time_to, tactic)
        
        # Color coding based on count (risk level)
        if count >= max_count * 0.7:
            bar_color = colors['danger']
            badge_color = colors['danger']
            badge_bg = "#fef2f2"
        elif count >= max_count * 0.4:
            bar_color = colors['warning']
            badge_color = colors['warning']
            badge_bg = "#fff7ed"
        elif count >= max_count * 0.2:
            bar_color = colors['info']
            badge_color = colors['info']
            badge_bg = "#f0f9ff"
        else:
            bar_color = colors['success']
            badge_color = colors['success']
            badge_bg = "#f0fdf4"
        
        # Calculate risk level and text color
        risk_level = "High" if count >= max_count * 0.7 else "Medium" if count >= max_count * 0.4 else "Low"
        risk_text_color = colors['danger'] if risk_level == "High" else colors['warning'] if risk_level == "Medium" else colors['success']
        
        mitre_rows += f"""
        <tr style="background:{'#fafafa' if i % 2 == 0 else '#fff'};">
            <td style="padding:14px 16px;border-bottom:1px solid {colors['border']};vertical-align:middle;">
                <div>
                    <a href="{mitre_url}" style="color:{colors['primary']};text-decoration:none;font-weight:600;font-size:15px;display:block;margin-bottom:4px;">{html_escape(tactic)}</a>
                    <div style="font-size:11px;">
                        <span style="color:{risk_text_color};font-weight:600;">Risk: {risk_level}</span>
                        <span style="color:{colors['border']};margin:0 6px;">•</span>
                        <span style="color:{colors['text_light']};">{total_percentage}% of MITRE alerts</span>
                    </div>
                </div>
            </td>
            <td style="padding:14px 16px;border-bottom:1px solid {colors['border']};text-align:right;vertical-align:middle;">
                <span style="background:{badge_bg};color:{badge_color};padding:4px 10px;border-radius:12px;font-weight:700;font-size:14px;display:inline-block;border:1px solid {badge_color};">{count}</span>
            </td>
            <td style="padding:14px 16px;border-bottom:1px solid {colors['border']};vertical-align:middle;">
                <div style="position:relative;">
                    <div style="background:{colors['light']};height:8px;border-radius:4px;overflow:hidden;position:relative;">
                        <div style="background:{bar_color};height:100%;width:{percentage}%;border-radius:4px;box-shadow:0 1px 2px rgba(0,0,0,0.1);"></div>
                    </div>
                    <div style="color:{colors['text_light']};font-size:10px;margin-top:4px;text-align:right;">{percentage}% of max</div>
                </div>
            </td>
        </tr>
"""
    
    # Vulnerability CVE Table with enhanced visualizations
    vulnerability_cve_rows = ""
    if stats.get("vulnerabilities", {}).get("top_cves"):
        for i, cve_data in enumerate(stats["vulnerabilities"]["top_cves"][:10], 1):
            cve_id = cve_data.get("cve", "N/A")
            count = cve_data.get("count", 0)
            title = cve_data.get("title", "")
            severity = cve_data.get("severity", "Unknown")
            score = cve_data.get("score", 0.0)
            affected_agents = cve_data.get("affected_agents", [])
            
            # Build CVE dashboard URL - use vulnerability detection page with CVE filter
            cve_url = build_vulnerability_detection_url(time_from, time_to, cve_id)
            
            # Determine severity color and icon based on severity or CVSS score
            severity_lower = str(severity).lower() if severity else ""
            if severity_lower in ['critical', 'high', 'medium', 'low']:
                if severity_lower == 'critical':
                    severity_color = "#dc2626"
                    severity_bg = "#fef2f2"
                elif severity_lower == 'high':
                    severity_color = "#d97706"
                    severity_bg = "#fff7ed"
                elif severity_lower == 'medium':
                    severity_color = "#0284c7"
                    severity_bg = "#f0f9ff"
                else:  # low
                    severity_color = "#059669"
                    severity_bg = "#f0fdf4"
            elif score > 0:
                # Use CVSS score to determine severity if severity is missing
                if score >= 9.0:
                    severity_color = "#dc2626"
                    severity_bg = "#fef2f2"
                    severity = "Critical" if severity == "Unknown" else severity
                elif score >= 7.0:
                    severity_color = "#d97706"
                    severity_bg = "#fff7ed"
                    severity = "High" if severity == "Unknown" else severity
                elif score >= 4.0:
                    severity_color = "#0284c7"
                    severity_bg = "#f0f9ff"
                    severity = "Medium" if severity == "Unknown" else severity
                else:
                    severity_color = "#059669"
                    severity_bg = "#f0fdf4"
                    severity = "Low" if severity == "Unknown" else severity
            else:
                # Unknown severity
                severity_color = colors['secondary']
                severity_bg = colors['light']
                severity = "Unclassified"
            
            # CVSS score visualization
            score_display = f"{score:.1f}" if score > 0 else "N/A"
            score_percentage = min(100, (score / 10.0 * 100)) if score > 0 else 0
            
            # Affected agents display with badges
            agents_display = ""
            if affected_agents:
                agents_list = affected_agents[:2]
                agents_display = " ".join([f'<span style="background:{colors["light"]};color:{colors["text"]};padding:2px 6px;border-radius:3px;font-size:11px;margin-right:4px;display:inline-block;">{html_escape(agent)}</span>' for agent in agents_list])
                if len(affected_agents) > 2:
                    agents_display += f'<span style="color:{colors["text_light"]};font-size:11px;">+{len(affected_agents) - 2} more</span>'
            else:
                agents_display = '<span style="color:' + colors['text_light'] + ';">N/A</span>'
            
            vulnerability_cve_rows += f"""
        <tr style="background:{'#fafafa' if i % 2 == 0 else '#fff'};">
            <td style="padding:14px 16px;border-bottom:1px solid {colors['border']};font-size:14px;color:{colors['text']};font-weight:600;">{i}</td>
            <td style="padding:14px 16px;border-bottom:1px solid {colors['border']};">
                <a href="{cve_url}" style="color:{colors['primary']};text-decoration:none;font-weight:700;font-size:15px;display:inline-block;margin-bottom:4px;">{html_escape(cve_id)}</a>
                <div style="color:{colors['text']};font-size:12px;line-height:1.4;margin-top:4px;">{html_escape(title[:75] + '...' if len(title) > 75 else title)}</div>
            </td>
            <td style="padding:14px 16px;border-bottom:1px solid {colors['border']};text-align:center;vertical-align:middle;">
                <div style="background:{severity_bg};border-left:4px solid {severity_color};padding:8px;border-radius:4px;display:inline-block;min-width:80px;">
                    <span style="background:{severity_color};color:#fff;padding:3px 8px;border-radius:3px;font-size:11px;font-weight:600;display:inline-block;margin-bottom:6px;">
                        {severity}
                    </span>
                    <div style="margin-top:6px;">
                        <div style="color:{colors['text_light']};font-size:10px;margin-bottom:3px;">CVSS: {score_display}</div>
                        {f'''<div style="background:{colors['border']};height:4px;border-radius:2px;overflow:hidden;width:60px;margin:0 auto;">
                            <div style="background:{severity_color};height:100%;width:{score_percentage:.1f}%;"></div>
                        </div>''' if score > 0 else ''}
                    </div>
                </div>
            </td>
            <td style="padding:14px 16px;border-bottom:1px solid {colors['border']};font-size:12px;line-height:1.6;">
                {agents_display}
            </td>
            <td style="padding:14px 16px;border-bottom:1px solid {colors['border']};text-align:right;vertical-align:middle;">
                <span style="background:{colors['primary']};color:#fff;padding:6px 10px;border-radius:4px;font-weight:700;font-size:14px;display:inline-block;min-width:40px;text-align:center;">{count}</span>
            </td>
        </tr>
"""
    
    # Vulnerability Affected Agents Table showing Critical, High, and Medium counts with drill-through
    vulnerability_agent_rows = ""
    if stats.get("vulnerabilities", {}).get("top_affected_agents"):
        for i, agent_data in enumerate(stats["vulnerabilities"]["top_affected_agents"][:10], 1):
            agent_name = agent_data.get("name", "Unknown")
            critical_count = agent_data.get("critical", 0)
            high_count = agent_data.get("high", 0)
            medium_count = agent_data.get("medium", 0)
            
            # Base agent URL - use vulnerability dashboard
            agent_url = build_vulnerability_detection_url(time_from, time_to, agent_name=agent_name)
            
            # URLs for each severity level - use vulnerability dashboard
            critical_url = build_vulnerability_detection_url(time_from, time_to, agent_name=agent_name, severity="Critical")
            high_url = build_vulnerability_detection_url(time_from, time_to, agent_name=agent_name, severity="High")
            medium_url = build_vulnerability_detection_url(time_from, time_to, agent_name=agent_name, severity="Medium")
            
            vulnerability_agent_rows += f"""
        <tr style="background:{'#fafafa' if i % 2 == 0 else '#fff'};">
            <td style="padding:14px 16px;border-bottom:1px solid {colors['border']};font-size:14px;color:{colors['text']};font-weight:600;">{i}</td>
            <td style="padding:14px 16px;border-bottom:1px solid {colors['border']};">
                <a href="{agent_url}" style="color:{colors['primary']};text-decoration:none;font-weight:600;font-size:14px;display:inline-block;margin-bottom:6px;">{html_escape(agent_name)}</a>
            </td>
            <td style="padding:14px 16px;border-bottom:1px solid {colors['border']};text-align:right;vertical-align:middle;">
                <div style="display:inline-block;text-align:right;white-space:nowrap;">
                    <a href="{critical_url}" style="text-decoration:none;display:inline-block;margin-right:4px;"><span style="background:{colors['danger']};color:#fff;padding:4px 8px;border-radius:4px;font-weight:600;font-size:12px;display:inline-block;">Critical: {critical_count}</span></a>
                    <a href="{high_url}" style="text-decoration:none;display:inline-block;margin-right:4px;"><span style="background:{colors['warning']};color:#fff;padding:4px 8px;border-radius:4px;font-weight:600;font-size:12px;display:inline-block;">High: {high_count}</span></a>
                    <a href="{medium_url}" style="text-decoration:none;display:inline-block;"><span style="background:{colors['info']};color:#fff;padding:4px 8px;border-radius:4px;font-weight:600;font-size:12px;display:inline-block;">Medium: {medium_count}</span></a>
                </div>
            </td>
        </tr>
"""
    
    # Vulnerability Affected Packages Table showing Critical, High, and Medium counts with drill-through
    vulnerability_package_rows = ""
    if stats.get("vulnerabilities", {}).get("top_affected_packages"):
        for i, package_data in enumerate(stats["vulnerabilities"]["top_affected_packages"][:10], 1):
            package_name = package_data.get("name", "Unknown")
            critical_count = package_data.get("critical", 0)
            high_count = package_data.get("high", 0)
            medium_count = package_data.get("medium", 0)
            
            # Base package URL - use vulnerability dashboard
            package_url = build_vulnerability_detection_url(time_from, time_to, package_name=package_name)
            
            # URLs for each severity level - use vulnerability dashboard
            critical_url = build_vulnerability_detection_url(time_from, time_to, package_name=package_name, severity="Critical")
            high_url = build_vulnerability_detection_url(time_from, time_to, package_name=package_name, severity="High")
            medium_url = build_vulnerability_detection_url(time_from, time_to, package_name=package_name, severity="Medium")
            
            vulnerability_package_rows += f"""
        <tr style="background:{'#fafafa' if i % 2 == 0 else '#fff'};">
            <td style="padding:14px 16px;border-bottom:1px solid {colors['border']};font-size:14px;color:{colors['text']};font-weight:600;">{i}</td>
            <td style="padding:14px 16px;border-bottom:1px solid {colors['border']};">
                <a href="{package_url}" style="color:{colors['primary']};text-decoration:none;font-weight:600;font-size:14px;display:inline-block;margin-bottom:6px;">{html_escape(package_name)}</a>
            </td>
            <td style="padding:14px 16px;border-bottom:1px solid {colors['border']};text-align:right;vertical-align:middle;">
                <div style="display:inline-block;text-align:right;white-space:nowrap;">
                    <a href="{critical_url}" style="text-decoration:none;display:inline-block;margin-right:4px;"><span style="background:{colors['danger']};color:#fff;padding:4px 8px;border-radius:4px;font-weight:600;font-size:12px;display:inline-block;">Critical: {critical_count}</span></a>
                    <a href="{high_url}" style="text-decoration:none;display:inline-block;margin-right:4px;"><span style="background:{colors['warning']};color:#fff;padding:4px 8px;border-radius:4px;font-weight:600;font-size:12px;display:inline-block;">High: {high_count}</span></a>
                    <a href="{medium_url}" style="text-decoration:none;display:inline-block;"><span style="background:{colors['info']};color:#fff;padding:4px 8px;border-radius:4px;font-weight:600;font-size:12px;display:inline-block;">Medium: {medium_count}</span></a>
                </div>
            </td>
        </tr>
"""
    
    # Vulnerability Severity Summary Cards - matching Total Alerts card style
    vulnerability_severity_cards = ""
    vuln_total = stats.get("vulnerabilities", {}).get("total", 0)
    
    if stats.get("vulnerabilities", {}).get("by_severity"):
        vuln_severities = stats["vulnerabilities"]["by_severity"]
        # Filter out invalid severities and sort by priority
        severity_order = ["Critical", "High", "Medium", "Low"]
        sorted_severities = []
        for sev in severity_order:
            if sev in vuln_severities and vuln_severities[sev] > 0:
                sorted_severities.append((sev, vuln_severities[sev]))
        # Add any other severities not in the standard list
        for sev, count in vuln_severities.items():
            if sev not in severity_order and count > 0:
                sorted_severities.append((sev, count))
        
        num_severities = len(sorted_severities)
        if num_severities > 0:
            # Make each severity card exactly 25% width to match Total Vulnerabilities card
            # Limit to 3 cards max (25% each = 75%, leaving 25% for total)
            
            for severity, count in sorted_severities[:3]:  # Limit to 3 cards
                # Determine colors matching the alert severity cards style
                if severity.lower() == 'critical':
                    severity_color = colors['danger']
                    bg_color = "#fef2f2"
                    border_color = "#fecaca"
                elif severity.lower() == 'high':
                    severity_color = colors['warning']
                    bg_color = "#fff7ed"
                    border_color = "#fed7aa"
                elif severity.lower() == 'medium':
                    severity_color = colors['info']
                    bg_color = "#fff"
                    border_color = colors['border']
                elif severity.lower() == 'low':
                    severity_color = colors['success']
                    bg_color = "#fff"
                    border_color = colors['border']
                else:
                    severity_color = colors['secondary']
                    bg_color = colors['light']
                    border_color = colors['border']
                
                # Build URL for this severity
                severity_url = build_vulnerability_detection_url(time_from, time_to, severity=severity)
                
                vulnerability_severity_cards += f"""
                                                <td width="25%" style="padding:8px;vertical-align:top;">
                                                    <table width="100%" cellpadding="0" cellspacing="0" border="0" style="background:{bg_color};border:1px solid {border_color};border-radius:6px;height:130px;table-layout:fixed;">
                                                        <tr>
                                                            <td style="padding:20px;text-align:center;height:130px;vertical-align:middle;">
                                                                <div style="font-size:32px;font-weight:700;color:{severity_color};margin-bottom:4px;">{count}</div>
                                                                <div style="color:{severity_color if severity.lower() in ['critical', 'high'] else colors['text_light']};font-size:12px;text-transform:uppercase;letter-spacing:0.5px;margin-bottom:4px;">{severity}</div>
                                                                <div style="min-height:20px;margin-bottom:4px;">&nbsp;</div>
                                                                <a href="{severity_url}" style="color:{severity_color};text-decoration:none;font-size:12px;font-weight:500;">View Details →</a>
                                                            </td>
                                                        </tr>
                                                    </table>
                                                </td>
"""
        else:
            # No valid severity data
            vulnerability_severity_cards = f"""
                                                <td colspan="3" style="padding:8px;vertical-align:top;">
                                                    <table width="100%" cellpadding="0" cellspacing="0" border="0" style="background:{colors['light']};border:1px solid {colors['border']};border-radius:6px;height:130px;table-layout:fixed;">
                                                        <tr>
                                                            <td style="padding:20px;text-align:center;height:130px;vertical-align:middle;">
                                                                <div style="font-size:16px;font-weight:600;color:{colors['text_light']};">No severity classification available</div>
                                                                <div style="font-size:12px;color:{colors['text_light']};margin-top:4px;">Vulnerabilities may have unclassified severity</div>
                                                            </td>
                                                        </tr>
                                                    </table>
                                                </td>
"""
    else:
        # No severity data at all
        vulnerability_severity_cards = f"""
                                                <td colspan="3" style="padding:8px;vertical-align:top;">
                                                    <table width="100%" cellpadding="0" cellspacing="0" border="0" style="background:{colors['light']};border:1px solid {colors['border']};border-radius:6px;height:130px;table-layout:fixed;">
                                                        <tr>
                                                            <td style="padding:20px;text-align:center;height:130px;vertical-align:middle;">
                                                                <div style="font-size:16px;font-weight:600;color:{colors['text_light']};">No severity data</div>
                                                                <div style="font-size:12px;color:{colors['text_light']};margin-top:4px;">Vulnerability severity information not available</div>
                                                            </td>
                                                        </tr>
                                                    </table>
                                                </td>
"""
    
    # Generate comparison HTML strings before the f-string
    total_comparison_html = format_comparison_html('total_alerts', stats, colors)
    critical_comparison_html = format_comparison_html('critical', stats, colors)
    high_comparison_html = format_comparison_html('high', stats, colors)
    medium_comparison_html = format_comparison_html('medium', stats, colors)
    
    html_output = f"""
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <!--[if mso]>
    <style type="text/css">
        body, table, td {{font-family: Arial, sans-serif !important;}}
    </style>
    <![endif]-->
</head>
<body style="margin:0;padding:0;font-family:Arial,sans-serif;background:{colors['light']};width:100%;">
    
    <table width="100%" cellpadding="0" cellspacing="0" border="0" style="background:{colors['light']};margin:0;padding:0;">
        <tr>
            <td align="center" style="padding:0;">
                
                <!-- Header -->
                <div style="background:#0d47a1;color:#fff;padding:12px 18px;font-size:18px;font-weight:700;">
                {ATHENA_NAME} — {report_type.title()} SIEM Report
                <div style="font-size:12px;font-weight:400;opacity:0.95;color:#ffffff !important;">Tenant: {html_escape(TENANT_NAME)}</div>
                <div style="font-size:12px;font-weight:400;opacity:0.95;color:#ffffff;margin-top:4px;">📅 {from_date} — {to_date}</div>
                </div>
                <div style="padding:16px 18px;font-family:Arial,sans-serif;line-height:1.5;">
                <p style="margin:0 0 16px 0;">This is an automated SIEM report generated by {ATHENA_NAME}.</p>
                            
                            <!-- Quick Stats -->
                            <table width="100%" cellpadding="0" cellspacing="0" border="0" style="margin-bottom:32px;">
                                <tr>
                                    <td style="padding:0;">
                                        <table width="100%" cellpadding="0" cellspacing="0" border="0">
                                            <tr>
                                                                                                <!-- Total Alerts -->
                                                <td width="25%" style="padding:8px;vertical-align:top;">
                                                    <table width="100%" cellpadding="0" cellspacing="0" border="0" style="background:#fff;border:1px solid {colors['border']};border-radius:6px;height:160px;table-layout:fixed;">
                                                        <tr>
                                                            <td style="padding:20px;text-align:center;height:160px;vertical-align:middle;">
                                                                <div style="font-size:32px;font-weight:700;color:{colors['primary']};margin-bottom:4px;">{stats['total_alerts']}</div>
                                                                <div style="color:{colors['text_light']};font-size:12px;text-transform:uppercase;letter-spacing:0.5px;margin-bottom:4px;">Total Alerts</div>
                                                                <div style="min-height:20px;margin-bottom:4px;">{total_comparison_html}</div>
                                                                <a href="{all_alerts_url}" style="color:{colors['primary']};text-decoration:none;font-size:12px;font-weight:500;">View All →</a>
                                                            </td>
                                                        </tr>
                                                    </table>
                                                </td>
                                                
                                                <!-- Critical -->
                                                <td width="25%" style="padding:8px;vertical-align:top;">
                                                    <table width="100%" cellpadding="0" cellspacing="0" border="0" style="background:#fef2f2;border:1px solid #fecaca;border-radius:6px;height:160px;table-layout:fixed;">
                                                        <tr>
                                                            <td style="padding:20px;text-align:center;height:160px;vertical-align:middle;">
                                                                <div style="font-size:32px;font-weight:700;color:{colors['danger']};margin-bottom:4px;">{stats['by_severity'].get('Critical', 0)}</div>
                                                                <div style="color:{colors['danger']};font-size:12px;text-transform:uppercase;letter-spacing:0.5px;margin-bottom:4px;">Critical</div>
                                                                <div style="color:{colors['text_light']};font-size:11px;margin-bottom:4px;">Rule level 15 or higher</div>
                                                                <div style="min-height:20px;margin-bottom:4px;">{critical_comparison_html}</div>
                                                                <a href="{critical_url}" style="color:{colors['danger']};text-decoration:none;font-size:12px;font-weight:500;">View Details →</a>
                                                            </td>
                                                        </tr>
                                                    </table>
                                                </td>
                                                
                                                <!-- High -->
                                                <td width="25%" style="padding:8px;vertical-align:top;">
                                                    <table width="100%" cellpadding="0" cellspacing="0" border="0" style="background:#fff7ed;border:1px solid #fed7aa;border-radius:6px;height:160px;table-layout:fixed;">
                                                        <tr>
                                                            <td style="padding:20px;text-align:center;height:160px;vertical-align:middle;">
                                                                <div style="font-size:32px;font-weight:700;color:{colors['warning']};margin-bottom:4px;">{stats['by_severity'].get('High', 0)}</div>
                                                                <div style="color:{colors['warning']};font-size:12px;text-transform:uppercase;letter-spacing:0.5px;margin-bottom:4px;">High</div>
                                                                <div style="color:{colors['text_light']};font-size:11px;margin-bottom:4px;">Rule level 12 to 14</div>
                                                                <div style="min-height:20px;margin-bottom:4px;">{high_comparison_html}</div>
                                                                <a href="{high_url}" style="color:{colors['warning']};text-decoration:none;font-size:12px;font-weight:500;">View Details →</a>
                                                            </td>
                                                        </tr>
                                                    </table>
                                                </td>
                                                
                                                <!-- Medium -->
                                                <td width="25%" style="padding:8px;vertical-align:top;">
                                                    <table width="100%" cellpadding="0" cellspacing="0" border="0" style="background:#fff;border:1px solid {colors['border']};border-radius:6px;height:160px;table-layout:fixed;">
                                                        <tr>
                                                            <td style="padding:20px;text-align:center;height:160px;vertical-align:middle;">
                                                                <div style="font-size:32px;font-weight:700;color:{colors['info']};margin-bottom:4px;">{stats['by_severity'].get('Medium', 0)}</div>
                                                                <div style="color:{colors['text_light']};font-size:12px;text-transform:uppercase;letter-spacing:0.5px;margin-bottom:4px;">Medium</div>
                                                                <div style="color:{colors['text_light']};font-size:11px;margin-bottom:4px;">Rule level 7 to 11</div>
                                                                <div style="min-height:20px;margin-bottom:4px;">{medium_comparison_html}</div>
                                                                <a href="{medium_url}" style="color:{colors['info']};text-decoration:none;font-size:12px;font-weight:500;">View Details →</a>
                                                            </td>
                                                        </tr>
                                                    </table>
                                                </td>
                                            </tr>
                                        </table>
                                    </td>
                                </tr>
                            </table>
                            
                            {ai_section}
        
                            <!-- Event Categories -->
                            <table width="100%" cellpadding="0" cellspacing="0" border="0" style="background:#fff;border:1px solid {colors['border']};border-radius:6px;margin:24px 0;">
                                <tr>
                                    <td style="padding:24px;">
                                        <h3 style="margin:0 0 20px 0;color:{colors['dark']};font-size:18px;font-weight:600;border-bottom:2px solid {colors['border']};padding-bottom:8px;">Event Categories</h3>
                                        <table width="100%" cellpadding="0" cellspacing="0" border="0">
                                            <tr>
                                                <td width="33%" style="padding:8px;">
                                                    <a href="{build_file_integrity_url(time_from, time_to)}" style="text-decoration:none;display:block;">
                                                        <table width="100%" cellpadding="0" cellspacing="0" border="0" style="background:{colors['light']};border:1px solid {colors['border']};border-radius:4px;transition:all 0.2s;">
                                                            <tr>
                                                                <td style="padding:16px;text-align:center;">
                                                                    <div style="font-size:24px;font-weight:700;color:{colors['info']};margin-bottom:4px;">{stats['file_integrity_events']}</div>
                                                                    <div style="color:{colors['text_light']};font-size:13px;">File Integrity Monitoring</div>
                                                                </td>
                                                            </tr>
                                                        </table>
                                                    </a>
                                                </td>
                                                <td width="33%" style="padding:8px;">
                                                    <a href="{build_vulnerability_detection_url(time_from, time_to)}" style="text-decoration:none;display:block;">
                                                        <table width="100%" cellpadding="0" cellspacing="0" border="0" style="background:{colors['light']};border:1px solid {colors['border']};border-radius:4px;transition:all 0.2s;">
                                                            <tr>
                                                                <td style="padding:16px;text-align:center;">
                                                                    <div style="font-size:24px;font-weight:700;color:{colors['warning']};margin-bottom:4px;">{stats['vulnerability_alerts']}</div>
                                                                    <div style="color:{colors['text_light']};font-size:13px;">Vulnerability Alerts</div>
                                                                </td>
                                                            </tr>
                                                        </table>
                                                    </a>
                                                </td>
                                                <td width="33%" style="padding:8px;">
                                                    <a href="{build_dashboard_url(time_from, time_to, [{'type': 'phrase', 'field': 'rule.groups', 'value': 'authentication'}])}" style="text-decoration:none;display:block;">
                                                        <table width="100%" cellpadding="0" cellspacing="0" border="0" style="background:{colors['light']};border:1px solid {colors['border']};border-radius:4px;transition:all 0.2s;">
                                                            <tr>
                                                                <td style="padding:16px;text-align:center;">
                                                                    <div style="font-size:24px;font-weight:700;color:{colors['secondary']};margin-bottom:4px;">{stats['authentication_events']}</div>
                                                                    <div style="color:{colors['text_light']};font-size:13px;">Authentication Events</div>
                                                                </td>
                                                            </tr>
                                                        </table>
                                                    </a>
                                                </td>
                                            </tr>
                                        </table>
                                    </td>
                                </tr>
                            </table>
        
                            <!-- Vulnerability Section -->
                            {f'''
                            <table width="100%" cellpadding="0" cellspacing="0" border="0" style="background:#fff;border:1px solid {colors['border']};border-radius:6px;margin:24px 0;">
                                <tr>
                                    <td style="padding:24px;">
                                        <h3 style="margin:0 0 20px 0;color:{colors['dark']};font-size:18px;font-weight:600;border-bottom:2px solid {colors['border']};padding-bottom:8px;">
                                            <a href="{build_vulnerability_detection_url(time_from, time_to)}" style="color:{colors['dark']};text-decoration:none;">Vulnerability Management</a>
                                        </h3>
                                        
                                        <!-- Vulnerability Summary Cards -->
                                        <table width="100%" cellpadding="0" cellspacing="0" border="0" style="margin-bottom:24px;">
                                            <tr>
                                                <td width="25%" style="padding:8px;vertical-align:top;">
                                                    <table width="100%" cellpadding="0" cellspacing="0" border="0" style="background:#fff;border:1px solid {colors['border']};border-radius:6px;height:130px;table-layout:fixed;">
                                                        <tr>
                                                            <td style="padding:20px;text-align:center;height:130px;vertical-align:middle;">
                                                                <div style="font-size:32px;font-weight:700;color:{colors['primary']};margin-bottom:4px;">{stats['vulnerabilities'].get('total', 0)}</div>
                                                                <div style="color:{colors['text_light']};font-size:12px;text-transform:uppercase;letter-spacing:0.5px;margin-bottom:4px;">Total Vulnerabilities</div>
                                                                <div style="min-height:20px;margin-bottom:4px;">&nbsp;</div>
                                                                <a href="{build_vulnerability_detection_url(time_from, time_to)}" style="color:{colors['primary']};text-decoration:none;font-size:12px;font-weight:500;">View Details →</a>
                                                            </td>
                                                        </tr>
                                                    </table>
                                                </td>
                                                {vulnerability_severity_cards}
                                            </tr>
                                        </table>
                                        
                                        <!-- Top CVEs Table -->
                                        {f'''
                                        <h4 style="margin:24px 0 16px 0;color:{colors['dark']};font-size:16px;font-weight:600;">Top CVEs by Alert Count</h4>
                                        <table width="100%" cellpadding="0" cellspacing="0" border="0" style="border-collapse:collapse;margin-bottom:24px;">
                                            <thead>
                                                <tr style="background:{colors['light']};">
                                                    <th style="padding:12px 16px;text-align:left;font-size:12px;color:{colors['text_light']};text-transform:uppercase;letter-spacing:0.5px;border-bottom:1px solid {colors['border']};width:50px;">#</th>
                                                    <th style="padding:12px 16px;text-align:left;font-size:12px;color:{colors['text_light']};text-transform:uppercase;letter-spacing:0.5px;border-bottom:1px solid {colors['border']};">CVE ID & Title</th>
                                                    <th style="padding:12px 16px;text-align:center;font-size:12px;color:{colors['text_light']};text-transform:uppercase;letter-spacing:0.5px;border-bottom:1px solid {colors['border']};width:120px;">Severity</th>
                                                    <th style="padding:12px 16px;text-align:left;font-size:12px;color:{colors['text_light']};text-transform:uppercase;letter-spacing:0.5px;border-bottom:1px solid {colors['border']};width:200px;">Affected Systems</th>
                                                    <th style="padding:12px 16px;text-align:right;font-size:12px;color:{colors['text_light']};text-transform:uppercase;letter-spacing:0.5px;border-bottom:1px solid {colors['border']};width:80px;">Count</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                {vulnerability_cve_rows if vulnerability_cve_rows else '<tr><td colspan="5" style="padding:20px;text-align:center;color:' + colors['text_light'] + ';">No vulnerability data available</td></tr>'}
                                            </tbody>
                                        </table>
                                        ''' if stats['vulnerabilities'].get('top_cves') else ''}
                                        
                                        <!-- Top Affected Agents by Vulnerabilities -->
                                        {f'''
                                        <h4 style="margin:24px 0 16px 0;color:{colors['dark']};font-size:16px;font-weight:600;">Top Affected Systems</h4>
                                        <table width="100%" cellpadding="0" cellspacing="0" border="0" style="border-collapse:collapse;margin-bottom:24px;">
                                            <thead>
                                                <tr style="background:{colors['light']};">
                                                    <th style="padding:12px 16px;text-align:left;font-size:12px;color:{colors['text_light']};text-transform:uppercase;letter-spacing:0.5px;border-bottom:1px solid {colors['border']};width:60px;">#</th>
                                                    <th style="padding:12px 16px;text-align:left;font-size:12px;color:{colors['text_light']};text-transform:uppercase;letter-spacing:0.5px;border-bottom:1px solid {colors['border']};">System Name</th>
                                                    <th style="padding:12px 16px;text-align:right;font-size:12px;color:{colors['text_light']};text-transform:uppercase;letter-spacing:0.5px;border-bottom:1px solid {colors['border']};width:200px;">Count</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                {vulnerability_agent_rows if vulnerability_agent_rows else '<tr><td colspan="3" style="padding:20px;text-align:center;color:' + colors['text_light'] + ';">No data available</td></tr>'}
                                            </tbody>
                                        </table>
                                        ''' if stats['vulnerabilities'].get('top_affected_agents') else ''}
                                        
                                        <!-- Top Affected Packages -->
                                        {f'''
                                        <h4 style="margin:24px 0 16px 0;color:{colors['dark']};font-size:16px;font-weight:600;">Top Affected Packages</h4>
                                        <table width="100%" cellpadding="0" cellspacing="0" border="0" style="border-collapse:collapse;">
                                            <thead>
                                                <tr style="background:{colors['light']};">
                                                    <th style="padding:12px 16px;text-align:left;font-size:12px;color:{colors['text_light']};text-transform:uppercase;letter-spacing:0.5px;border-bottom:1px solid {colors['border']};width:60px;">#</th>
                                                    <th style="padding:12px 16px;text-align:left;font-size:12px;color:{colors['text_light']};text-transform:uppercase;letter-spacing:0.5px;border-bottom:1px solid {colors['border']};">Package Name</th>
                                                    <th style="padding:12px 16px;text-align:right;font-size:12px;color:{colors['text_light']};text-transform:uppercase;letter-spacing:0.5px;border-bottom:1px solid {colors['border']};width:200px;">Count</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                {vulnerability_package_rows if vulnerability_package_rows else '<tr><td colspan="3" style="padding:20px;text-align:center;color:' + colors['text_light'] + ';">No data available</td></tr>'}
                                            </tbody>
                                        </table>
                                        ''' if stats['vulnerabilities'].get('top_affected_packages') else ''}
                                    </td>
                                </tr>
                            </table>
                            ''' if stats.get('vulnerabilities') is not None else ''}
        
                            <!-- Top Affected Systems -->
                            <table width="100%" cellpadding="0" cellspacing="0" border="0" style="background:#fff;border:1px solid {colors['border']};border-radius:6px;margin:24px 0;">
                                <tr>
                                    <td style="padding:24px;">
                                        <h3 style="margin:0 0 16px 0;color:{colors['dark']};font-size:18px;font-weight:600;border-bottom:2px solid {colors['border']};padding-bottom:8px;">Top Affected Systems</h3>
                                        <table width="100%" cellpadding="0" cellspacing="0" border="0" style="border-collapse:collapse;">
                                            <thead>
                                                <tr style="background:{colors['light']};">
                                                    <th style="padding:12px 16px;text-align:left;font-size:12px;color:{colors['text_light']};text-transform:uppercase;letter-spacing:0.5px;border-bottom:1px solid {colors['border']};width:60px;">#</th>
                                                    <th style="padding:12px 16px;text-align:left;font-size:12px;color:{colors['text_light']};text-transform:uppercase;letter-spacing:0.5px;border-bottom:1px solid {colors['border']};">Agent Name</th>
                                                    <th style="padding:12px 16px;text-align:right;font-size:12px;color:{colors['text_light']};text-transform:uppercase;letter-spacing:0.5px;border-bottom:1px solid {colors['border']};width:300px;">Count</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                {top_agents_rows}
                                            </tbody>
                                        </table>
                                    </td>
                                </tr>
                            </table>
        
                            <!-- Most Triggered Rules -->
                            <table width="100%" cellpadding="0" cellspacing="0" border="0" style="background:#fff;border:1px solid {colors['border']};border-radius:6px;margin:24px 0;">
                                <tr>
                                    <td style="padding:24px;">
                                        <h3 style="margin:0 0 16px 0;color:{colors['dark']};font-size:18px;font-weight:600;border-bottom:2px solid {colors['border']};padding-bottom:8px;">Most Triggered Rules</h3>
                                        <table width="100%" cellpadding="0" cellspacing="0" border="0" style="border-collapse:collapse;">
                                            <thead>
                                                <tr style="background:{colors['light']};">
                                                    <th style="padding:12px 16px;text-align:left;font-size:12px;color:{colors['text_light']};text-transform:uppercase;letter-spacing:0.5px;border-bottom:1px solid {colors['border']};width:100px;">Rule ID</th>
                                                    <th style="padding:12px 16px;text-align:left;font-size:12px;color:{colors['text_light']};text-transform:uppercase;letter-spacing:0.5px;border-bottom:1px solid {colors['border']};">Description</th>
                                                    <th style="padding:12px 16px;text-align:center;font-size:12px;color:{colors['text_light']};text-transform:uppercase;letter-spacing:0.5px;border-bottom:1px solid {colors['border']};width:100px;">Severity</th>
                                                    <th style="padding:12px 16px;text-align:right;font-size:12px;color:{colors['text_light']};text-transform:uppercase;letter-spacing:0.5px;border-bottom:1px solid {colors['border']};width:250px;">Alerts Count & MITRE ATT&CK Tactics</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                {top_rules_rows}
                                            </tbody>
                                        </table>
                                    </td>
                                </tr>
                            </table>
        
                            <!-- MITRE ATT&CK -->
                            {f'''
                            <table width="100%" cellpadding="0" cellspacing="0" border="0" style="background:#fff;border:1px solid {colors['border']};border-radius:6px;margin:24px 0;">
                                <tr>
                                    <td style="padding:24px;">
                                        <h3 style="margin:0 0 16px 0;color:{colors['dark']};font-size:18px;font-weight:600;border-bottom:2px solid {colors['border']};padding-bottom:8px;">MITRE ATT&CK Tactics</h3>
                                        <table width="100%" cellpadding="0" cellspacing="0" border="0" style="border-collapse:collapse;">
                                            <thead>
                                                <tr style="background:{colors['light']};">
                                                    <th style="padding:12px 16px;text-align:left;font-size:12px;color:{colors['text_light']};text-transform:uppercase;letter-spacing:0.5px;border-bottom:1px solid {colors['border']};">Tactic & Techniques</th>
                                                    <th style="padding:12px 16px;text-align:right;font-size:12px;color:{colors['text_light']};text-transform:uppercase;letter-spacing:0.5px;border-bottom:1px solid {colors['border']};width:120px;">Alerts</th>
                                                    <th style="padding:12px 16px;text-align:left;font-size:12px;color:{colors['text_light']};text-transform:uppercase;letter-spacing:0.5px;border-bottom:1px solid {colors['border']};width:150px;">Distribution</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                {mitre_rows}
                                            </tbody>
                                        </table>
                                    </td>
                                </tr>
                            </table>
                            ''' if stats['by_mitre_tactic'] else ''}
        
                            <!-- Compliance Coverage -->
                            {f'''
                            <table width="100%" cellpadding="0" cellspacing="0" border="0" style="background:#fff;border:1px solid {colors['border']};border-radius:6px;margin:24px 0;">
                                <tr>
                                    <td style="padding:24px;">
                                        <h3 style="margin:0 0 16px 0;color:{colors['dark']};font-size:18px;font-weight:600;border-bottom:2px solid {colors['border']};padding-bottom:8px;">Compliance Framework Coverage</h3>
                                        <table width="100%" cellpadding="0" cellspacing="0" border="0">
                                            <tr>
                                                {''.join([f'''
                                                <td width="{100//len(stats['compliance_summary'])}%" style="padding:8px;">
                                                    <a href="{build_compliance_url(time_from, time_to, framework)}" style="text-decoration:none;display:block;">
                                                        <table width="100%" cellpadding="0" cellspacing="0" border="0" style="background:{colors['light']};border:1px solid {colors['border']};border-radius:4px;transition:all 0.2s;">
                                                            <tr>
                                                                <td style="padding:16px;text-align:center;">
                                                                    <div style="font-size:20px;font-weight:700;color:{colors['primary']};margin-bottom:4px;">{count}</div>
                                                                    <div style="color:{colors['text_light']};font-size:12px;font-weight:500;">{framework}</div>
                                                                    <div style="color:{colors['text_light']};font-size:11px;margin-top:2px;">Mapped Alerts</div>
                                                                </td>
                                                            </tr>
                                                        </table>
                                                    </a>
                                                </td>
                                                ''' for framework, count in stats['compliance_summary'].items()])}
                                            </tr>
                                        </table>
                                    </td>
                                </tr>
                            </table>
                            ''' if stats['compliance_summary'] else ''}
    
        
                        </td>
                    </tr>
                </table>
                
                <!-- Footer -->
                <div style="background:#f3f4f6;color:#333;padding:12px 18px;font-size:12px;">
                <p style="margin:2px 0 6px 0;"><strong>Athena Security Group</strong></p>
                <p style="margin:2px 0;">🌐 <a href="{ATHENA_WEBSITE}" style="color:#0d47a1;text-decoration:none;">Website</a>
                   &nbsp;|&nbsp; 📄 <a href="{ATHENA_DOCS}" style="color:#0d47a1;text-decoration:none;">Docs</a>
                   &nbsp;|&nbsp; 📧 <a href="mailto:{ATHENA_SUPPORT}" style="color:#0d47a1;text-decoration:none;">{ATHENA_SUPPORT}</a></p>
                <p style="margin:10px 0 0 0;">This automated {report_type} report was generated on {datetime.now().strftime('%B %d, %Y at %I:%M %p UTC')}. Do not reply to this email.</p>
                </div>
                
            </td>
        </tr>
    </table>
    
</body>
</html>
"""
    
    return html_output

def build_plain_report(report_type, time_from, time_to, stats, ai_analysis):
    """Build plain text version of the report"""
    from_date = datetime.fromisoformat(time_from.replace('Z', '+00:00')).strftime('%B %d, %Y')
    to_date = datetime.fromisoformat(time_to.replace('Z', '+00:00')).strftime('%B %d, %Y')
    
    lines = []
    lines.append("=" * 80)
    lines.append(f"{ATHENA_NAME} - {report_type.upper()} SIEM REPORT")
    lines.append("=" * 80)
    lines.append(f"Tenant: {TENANT_NAME}")
    lines.append(f"Period: {from_date} — {to_date}")
    lines.append("")
    
    lines.append("ALERT SUMMARY")
    lines.append("-" * 80)
    lines.append(f"Total Alerts: {stats['total_alerts']}")
    lines.append(f"  Critical: {stats['by_severity'].get('Critical', 0)}")
    lines.append(f"  High: {stats['by_severity'].get('High', 0)}")
    lines.append(f"  Medium: {stats['by_severity'].get('Medium', 0)}")
    # lines.append(f"  Low: {stats['by_severity'].get('Low', 0)}")
    lines.append("")
    
    if ai_analysis:
        lines.append("AI-POWERED EXECUTIVE SUMMARY")
        lines.append("-" * 80)
        lines.append(ai_analysis.get('executive_summary', ''))
        lines.append("")
        lines.append(f"Overall Risk Rating: {ai_analysis.get('overall_risk_rating', 'N/A')}")
        lines.append("")

        if ai_analysis.get('trend_summary'):
            lines.append("TREND SUMMARY:")
            lines.append(f"  {ai_analysis['trend_summary']}")
            lines.append("")

        if ai_analysis.get('key_findings'):
            lines.append("KEY FINDINGS:")
            for i, finding in enumerate(ai_analysis['key_findings'], 1):
                lines.append(f"  {i}. {finding}")
            lines.append("")

        if ai_analysis.get('threat_landscape'):
            lines.append("THREAT LANDSCAPE:")
            lines.append(f"  {ai_analysis['threat_landscape']}")
            lines.append("")

        if ai_analysis.get('critical_concerns'):
            lines.append("⚠️  CRITICAL CONCERNS:")
            for concern in ai_analysis['critical_concerns']:
                lines.append(f"  • {concern}")
            lines.append("")

        if ai_analysis.get('recommendations'):
            lines.append("RECOMMENDATIONS:")
            for i, rec in enumerate(ai_analysis['recommendations'], 1):
                lines.append(f"  {i}. {rec}")
            lines.append("")

        if ai_analysis.get('positive_observations'):
            lines.append("✅ POSITIVE OBSERVATIONS:")
            for obs in ai_analysis['positive_observations']:
                lines.append(f"  • {obs}")
            lines.append("")

    lines.append("EVENT CATEGORIES")
    lines.append("-" * 80)
    lines.append(f"File Integrity Monitoring Events: {stats['file_integrity_events']}")
    lines.append(f"Vulnerability Alerts: {stats['vulnerability_alerts']}")
    lines.append(f"Authentication Events: {stats['authentication_events']}")
    lines.append("")
    
    lines.append("TOP AFFECTED SYSTEMS")
    lines.append("-" * 80)
    for i, agent_data in enumerate(stats["top_agents"][:10], 1):
        if isinstance(agent_data, dict):
            agent_name = agent_data.get("name", "Unknown")
            critical = agent_data.get("critical", 0)
            high = agent_data.get("high", 0)
            medium = agent_data.get("medium", 0)
            lines.append(f"{i:2}. {agent_name}: Critical: {critical}, High: {high}, Medium: {medium}")
        else:
            # Fallback for old format
            agent_name = agent_data[0]
            count = agent_data[1]
            lines.append(f"{i:2}. {agent_name}: {count} alerts")
    lines.append("")
    
    lines.append("MOST TRIGGERED RULES")
    lines.append("-" * 80)
    for i, rule_data in enumerate(stats["top_rules"][:10], 1):
        # Handle both old format (4 items) and new format (5 items with MITRE tactics)
        if len(rule_data) == 5:
            rule_id, count, desc, level, mitre_tactics = rule_data
        else:
            rule_id, count, desc, level = rule_data[:4]
            mitre_tactics = {}
        severity = "Critical" if level >= 15 else "High" if level >= 12 else "Medium" if level >= 7 else "Low"
        lines.append(f"{i:2}. Rule {rule_id} [{severity}]: {desc[:60]}")
        lines.append(f"    Triggered {count} times")
        if mitre_tactics and len(mitre_tactics) > 0:
            sorted_tactics = sorted(mitre_tactics.items(), key=lambda x: x[1], reverse=True)[:3]
            tactic_str = ", ".join([f"{tactic}({t_count})" for tactic, t_count in sorted_tactics])
            lines.append(f"    MITRE Tactics: {tactic_str}")
    lines.append("")
    
    if stats['by_mitre_tactic']:
        lines.append("MITRE ATT&CK TACTICS")
        lines.append("-" * 80)
        for tactic, count in sorted(stats["by_mitre_tactic"].items(), key=lambda x: x[1], reverse=True)[:8]:
            lines.append(f"  {tactic}: {count}")
        lines.append("")
    
    if stats['compliance_summary']:
        lines.append("COMPLIANCE FRAMEWORK COVERAGE")
        lines.append("-" * 80)
        for framework, count in stats['compliance_summary'].items():
            lines.append(f"  {framework}: {count} mapped alerts")
        lines.append("")
    
    lines.append("=" * 80)
    lines.append(f"{ATHENA_NAME}")
    lines.append(f"Website: {ATHENA_WEBSITE}")
    lines.append(f"Support: {ATHENA_SUPPORT}")
    lines.append("")
    lines.append(f"This automated {report_type} report was generated on {datetime.now().strftime('%B %d, %Y at %I:%M %p UTC')}")
    lines.append("Do not reply to this email.")
    lines.append("=" * 80)
    
    return "\n".join(lines)

def send_email(recipients, subject, plain_body, html_body) -> bool:
    """Send the report email"""
    try:
        msg = EmailMessage()
        msg["Subject"] = subject
        msg["To"] = ", ".join(recipients)
        msg["From"] = formataddr((f"{ATHENA_NAME} Reports", SMTP_FROM))

        msg.set_content(plain_body)
        msg.add_alternative(html_body, subtype='html')

        if SMTP_USE_SSL:
            server = smtplib.SMTP_SSL(SMTP_HOST, SMTP_PORT, timeout=30)
        else:
            server = smtplib.SMTP(SMTP_HOST, SMTP_PORT, timeout=30)

        server.ehlo()
        if SMTP_USE_TLS and not SMTP_USE_SSL:
            server.starttls()
            server.ehlo()

        if SMTP_USERNAME and SMTP_PASSWORD:
            server.login(SMTP_USERNAME, SMTP_PASSWORD)

        server.send_message(msg)
        server.quit()
        log(f"Report sent successfully to {recipients}")
        return True

    except Exception as e:
        log(f"Error sending report email: {e}")
        return False

# === REPORT GENERATOR ===
def generate_report(report_type, time_from, time_to, recipients):
    """Generate and send the security report"""
    
    # Query aggregated statistics for current period
    log(f"Generating {report_type} report from {time_from} to {time_to}")
    aggregations = query_elasticsearch(time_from, time_to, min_level=0)
    
    # Query vulnerability data separately (no level filtering)
    vulnerability_aggregations = query_vulnerability_data(time_from, time_to)
    
    if not aggregations:
        log("No data found for the specified time range")
        return False
    
    # Analyze aggregated data
    stats = analyze_alerts(aggregations, vulnerability_aggregations)
    
    if stats['total_alerts'] == 0:
        log("No alerts found for the specified time range")
        return False
    
    # Fetch previous period data for comparison
    log("Fetching previous period data for comparison...")
    prev_time_from, prev_time_to = calculate_previous_period(time_from, time_to, report_type)
    prev_aggregations = query_elasticsearch(prev_time_from, prev_time_to, min_level=0)
    prev_vulnerability_aggregations = query_vulnerability_data(prev_time_from, prev_time_to)
    prev_stats = analyze_alerts(prev_aggregations, prev_vulnerability_aggregations) if prev_aggregations else {
        "total_alerts": 0,
        "by_severity": {"Critical": 0, "High": 0, "Medium": 0, "Low": 0}
    }
    
    # Calculate comparisons
    comparisons = {
        "total_alerts": {
            "current": stats['total_alerts'],
            "previous": prev_stats['total_alerts'],
            "change_pct": 0,
            "change_type": "no change"
        },
        "critical": {
            "current": stats['by_severity'].get('Critical', 0),
            "previous": prev_stats['by_severity'].get('Critical', 0),
            "change_pct": 0,
            "change_type": "no change"
        },
        "high": {
            "current": stats['by_severity'].get('High', 0),
            "previous": prev_stats['by_severity'].get('High', 0),
            "change_pct": 0,
            "change_type": "no change"
        },
        "medium": {
            "current": stats['by_severity'].get('Medium', 0),
            "previous": prev_stats['by_severity'].get('Medium', 0),
            "change_pct": 0,
            "change_type": "no change"
        }
    }
    
    # Calculate percentage changes
    for key in comparisons:
        current_val = comparisons[key]["current"]
        previous_val = comparisons[key]["previous"]
        pct_change, change_type = calculate_percentage_change(current_val, previous_val)
        comparisons[key]["change_pct"] = pct_change
        comparisons[key]["change_type"] = change_type
    
    # Add comparisons to stats
    stats['comparisons'] = comparisons
    stats['previous_period'] = {
        "from": prev_time_from,
        "to": prev_time_to
    }
    
    # Store previous vulnerability data for AI comparison
    if prev_stats.get('vulnerabilities'):
        stats['prev_vulnerabilities'] = prev_stats['vulnerabilities']
    else:
        stats['prev_vulnerabilities'] = {"total": 0}
    
    # Get AI analysis
    ai_analysis = get_ai_report_summary(stats, report_type, time_from, time_to)
    
    # Generate email
    subject = f"[{TENANT_NAME}] Athena SOC {report_type.title()} SIEM Report - {datetime.fromisoformat(time_from.replace('Z', '+00:00')).strftime('%b %d, %Y')}"
    
    html_body = build_html_report(report_type, time_from, time_to, stats, ai_analysis)
    plain_body = build_plain_report(report_type, time_from, time_to, stats, ai_analysis)
    
    # Send email
    return send_email(recipients, subject, plain_body, html_body)

# === MAIN ===
def main(args):
    """
    Usage: 
      python script.py daily
      python script.py weekly
      python script.py monthly
      python script.py custom 2025-10-01T00:00:00Z 2025-10-18T23:59:59Z
    """
    log("# Starting report generation")
    
    if len(args) < 2:
        log("Usage: script.py <daily|weekly|monthly|custom> [start_time] [end_time]")
        return
    
    report_type = args[1].lower()
    
    # Calculate time range
    now = datetime.now(datetime.UTC) if hasattr(datetime, 'UTC') else datetime.utcnow()
    
    if report_type == "daily":
        time_to = now.isoformat() + "Z"
        time_from = (now - timedelta(days=1)).isoformat() + "Z"
        recipients = SMTP_RECIPIENT
    elif report_type == "weekly":
        time_to = now.isoformat() + "Z"
        time_from = (now - timedelta(days=7)).isoformat() + "Z"
        recipients = SMTP_RECIPIENT
    elif report_type == "monthly":
        time_to = now.isoformat() + "Z"
        time_from = (now - timedelta(days=30)).isoformat() + "Z"
        recipients = SMTP_RECIPIENT
    elif report_type == "custom":
        if len(args) < 5:
            log("Custom report requires: script.py custom <recipients> <start_time> <end_time>")
            return
        recipients = SMTP_RECIPIENT
        time_from = args[3]
        time_to = args[4]
    else:
        log(f"Unknown report type: {report_type}")
        return
    
    log(f"Generating {report_type} report from {time_from} to {time_to}")
    log(f"Recipients: {recipients}")
    
    try:
        generate_report(report_type, time_from, time_to, recipients)
        log("Report generation completed successfully")
    except Exception as e:
        log(f"Error generating report: {e}")
        import traceback
        log(traceback.format_exc())

if __name__ == "__main__":
    try:
        main(sys.argv)
    except Exception as e:
        log(f"Unhandled exception: {e}")
        import traceback
        log(traceback.format_exc())
        raise
