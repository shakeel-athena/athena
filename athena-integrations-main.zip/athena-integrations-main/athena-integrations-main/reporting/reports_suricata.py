#!/var/ossec/framework/python/bin/python3
# -*- coding: utf-8 -*-

import json
import sys
import time
import os
import smtplib
import html
from datetime import datetime, timedelta
from urllib.parse import quote
from email.message import EmailMessage
from email.utils import formataddr
from collections import defaultdict
from dotenv import load_dotenv

# Load environment variables
load_dotenv()


# === CONFIGURATION FROM ENVIRONMENT ===
ATHENA_NAME = os.getenv("ATHENA_NAME", "Athena SOC")
TENANT_NAME = os.getenv("TENANT_NAME", "test.athenasecuritygrp.com")
ATHENA_WEBSITE = os.getenv("ATHENA_WEBSITE", "https://athenasoftwaregroup.ai/")
ATHENA_DOCS = os.getenv("ATHENA_DOCS", "https://athenasoftwaregroup.ai/")
ATHENA_SUPPORT = os.getenv("ATHENA_SUPPORT", "alerts@athena.athenasecuritygrp.com")
DASHBOARD_BASE_URL = os.getenv("DASHBOARD_BASE_URL", "https://test.athenasecuritygrp.com")

# === SMTP CONFIGURATION ===
SMTP_HOST = os.getenv("SMTP_HOST", "smtp.office365.com")
SMTP_PORT = int(os.getenv("SMTP_PORT", "587"))
SMTP_USE_TLS = os.getenv("SMTP_USE_TLS", "true").lower() == "true"
SMTP_USE_SSL = os.getenv("SMTP_USE_SSL", "false").lower() == "true"
SMTP_USERNAME = os.getenv("SMTP_USERNAME", "alerts@athenasoftwaregrp.com")
SMTP_PASSWORD = os.getenv("SMTP_PASSWORD", "")
SMTP_FROM = os.getenv("SMTP_FROM", "alerts@athena.athenasecuritygrp.com")
SMTP_RECIPIENT = os.getenv("SMTP_RECIPIENT", "secops@athena.athenasecuritygrp.com").split(",")

# === OLLAMA CONFIGURATION ===
OLLAMA_HOST = os.getenv("OLLAMA_HOST", "localhost")
OLLAMA_PORT = os.getenv("OLLAMA_PORT", "11434")
OLLAMA_MODEL = os.getenv("OLLAMA_MODEL", "qwen2.5:14b-instruct")
OLLAMA_ENABLED = os.getenv("OLLAMA_ENABLED", "false").lower() == "true"
OLLAMA_API_URL = f"http://{OLLAMA_HOST}:{OLLAMA_PORT}/v1/chat/completions"

# === ELASTICSEARCH CONFIGURATION ===
ES_HOST = os.getenv("ES_HOST", "https://localhost:9200")
ES_USERNAME = os.getenv("ES_USERNAME", "")
ES_PASSWORD = os.getenv("ES_PASSWORD", "")
ES_INDEX_PATTERN = os.getenv("ES_INDEX_PATTERN_SURICATA", "suricata-*")
ES_VERIFY_SSL = os.getenv("ES_VERIFY_SSL", "false").lower() == "true"


# === LOGGING ===
pwd = os.path.dirname(os.path.realpath(__file__))
log_file = f"{pwd}/logs/reporting.log"

def log(msg: str):
    now = time.strftime("%a %b %d %H:%M:%S %Z %Y")
    line = f"{now}: {msg}\n"
    print(line, end="")
    try:
        with open(log_file, "a") as f:
            f.write(line)
    except Exception:
        pass

# === ELASTICSEARCH QUERY ===
def query_elasticsearch(time_from, time_to, max_severity=3):
    """Query Elasticsearch for aggregated Suricata alert statistics in the given time range"""
    try:
        import requests
        from requests.auth import HTTPBasicAuth
        import urllib3
        
        if not ES_VERIFY_SSL:
            urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
        
        query = {
            "size": 0, 
            "query": {
                "bool": {
                    "must": [
                        {
                            "range": {
                                "@timestamp": {
                                    "gte": time_from,
                                    "lte": time_to,
                                    "format": "strict_date_optional_time"
                                }
                            }
                        }
                    ],
                    "filter": [
                        {
                            "range": {
                                "alert.severity": {
                                    "lte": max_severity
                                }
                            }
                        }
                    ]
                }
            },
            "aggs": {
                "total_alerts": {
                    "value_count": {
                        "field": "alert.signature_id"
                    }
                },
                "severity_breakdown": {
                    "terms": {
                        "script": {
                            "source": """
                                def severity = doc['alert.severity'].value;
                                if (severity == 1) return 'Critical';
                                else if (severity == 2) return 'High';
                                else if (severity == 3) return 'Medium';
                                else if (severity == 4) return 'Low';
                                else return 'Unknown';
                            """
                        },
                        "size": 10
                    }
                },
                "top_source_ips": {
                    "terms": {
                        "field": "src_ip",
                        "size": 20
                    },
                    "aggs": {
                        "top_protocol": {
                            "terms": {
                                "field": "proto",
                                "size": 1
                            }
                        },
                        "top_port": {
                            "terms": {
                                "field": "src_port",
                                "size": 1
                            }
                        }
                    }
                },
                "top_dest_ips": {
                    "terms": {
                        "field": "dest_ip",
                        "size": 20
                    },
                    "aggs": {
                        "top_protocol": {
                            "terms": {
                                "field": "proto",
                                "size": 1
                            }
                        },
                        "top_port": {
                            "terms": {
                                "field": "dest_port",
                                "size": 1
                            }
                        }
                    }
                },
                "top_signatures": {
                    "terms": {
                        "field": "alert.signature_id",
                        "size": 20
                    },
                    "aggs": {
                        "signature_description": {
                            "terms": {
                                "field": "alert.signature",
                                "size": 1
                            }
                        },
                        "signature_severity": {
                            "terms": {
                                "field": "alert.severity",
                                "size": 1
                            }
                        }
                    }
                },
                "alert_categories": {
                    "terms": {
                        "field": "alert.category",
                        "size": 15
                    }
                },
                "protocol_distribution": {
                    "terms": {
                        "field": "proto",
                        "size": 10
                    }
                },
                "network_traffic_types": {
                    "filters": {
                        "filters": {
                            "dns_queries": {"exists": {"field": "dns"}},
                            "http_requests": {"exists": {"field": "http"}},
                            "tls_connections": {"exists": {"field": "tls"}},
                            "tcp_connections": {"term": {"proto": "TCP"}},
                            "udp_connections": {"term": {"proto": "UDP"}}
                        }
                    }
                },
                "critical_alerts_sample": {
                    "filter": {
                        "range": {
                            "alert.severity": {
                                "gte": 1,
                                "lte": 1
                            }
                        }
                    },
                    "aggs": {
                        "sample_alerts": {
                            "top_hits": {
                                "size": 5,
                                "sort": [{"@timestamp": {"order": "desc"}}]
                            }
                        }
                    }
                },
                "high_alerts_sample": {
                    "filter": {
                        "range": {
                            "alert.severity": {
                                "gte": 2,
                                "lte": 2
                            }
                        }
                    },
                    "aggs": {
                        "sample_alerts": {
                            "top_hits": {
                                "size": 5,
                                "sort": [{"@timestamp": {"order": "desc"}}]
                            }
                        }
                    }
                }
            }
        }
        
        log("Executing aggregation query for Suricata alert statistics...")

        response = requests.post(
            f"{ES_HOST}/{ES_INDEX_PATTERN}/_search",
            json=query,
            auth=HTTPBasicAuth(ES_USERNAME, ES_PASSWORD),
            verify=ES_VERIFY_SSL,
            timeout=30
        )
        
        if response.status_code == 200:
            data = response.json()
            aggregations = data.get("aggregations", {})
            log(f"Retrieved aggregated Suricata statistics from Elasticsearch")
            return aggregations
        else:
            log(f"Elasticsearch query failed: {response.status_code} - {response.text}")
            return {}
            
    except Exception as e:
        log(f"Error querying Elasticsearch: {e}")
        return {}

# === PERIOD COMPARISON ===
def calculate_previous_period(time_from, time_to, report_type):
    """Calculate the previous period time range for comparison"""
    from datetime import datetime, timedelta
    
    # Parse current period
    if isinstance(time_from, str):
        current_from = datetime.fromisoformat(time_from.replace('Z', '+00:00'))
        current_to = datetime.fromisoformat(time_to.replace('Z', '+00:00'))
    else:
        current_from = time_from
        current_to = time_to
    
    # Calculate period duration
    period_duration = current_to - current_from
    
    # Calculate previous period
    previous_to = current_from
    previous_from = previous_to - period_duration
    
    # Convert back to ISO format strings
    prev_from_str = previous_from.isoformat().replace('+00:00', 'Z')
    prev_to_str = previous_to.isoformat().replace('+00:00', 'Z')
    
    return prev_from_str, prev_to_str

def calculate_percentage_change(current, previous):
    """Calculate percentage change between current and previous values"""
    if previous == 0:
        if current == 0:
            return 0, "no change"
        return 100, "increase"
    
    change = ((current - previous) / previous) * 100
    if change > 0:
        return change, "increase"
    elif change < 0:
        return abs(change), "decrease"
    else:
        return 0, "no change"

# === DATA PROCESSING ===
def analyze_alerts(aggregations):
    """Process aggregated Suricata alert data from Elasticsearch"""
    stats = {
        "total_alerts": 0,
        "by_severity": {},
        "by_source_ip": {},
        "by_dest_ip": {},
        "by_signature": {},
        "by_category": {},
        "by_protocol": {},
        "top_source_ips": [],
        "top_dest_ips": [],
        "top_signatures": [],
        "critical_alerts": [],
        "high_alerts": [],
        "medium_alerts": [],
        "low_alerts": [],
        "dns_queries": 0,
        "http_requests": 0,
        "tls_connections": 0,
        "tcp_connections": 0,
        "udp_connections": 0
    }
    
    # Total alerts count
    stats["total_alerts"] = aggregations.get("total_alerts", {}).get("value", 0)
    
    # Severity breakdown
    severity_buckets = aggregations.get("severity_breakdown", {}).get("buckets", [])
    for bucket in severity_buckets:
        severity = bucket.get("key", "Unknown")
        count = bucket.get("doc_count", 0)
        stats["by_severity"][severity] = count
    
    # Top source IPs with additional details
    src_ip_buckets = aggregations.get("top_source_ips", {}).get("buckets", [])
    for bucket in src_ip_buckets:
        src_ip = bucket.get("key", "Unknown")
        count = bucket.get("doc_count", 0)
        
        # Get top protocol and port
        protocol_buckets = bucket.get("top_protocol", {}).get("buckets", [])
        protocol = protocol_buckets[0].get("key", "N/A") if protocol_buckets else "N/A"
        
        port_buckets = bucket.get("top_port", {}).get("buckets", [])
        port = port_buckets[0].get("key", "N/A") if port_buckets else "N/A"
        
        stats["by_source_ip"][src_ip] = {
            "count": count,
            "protocol": protocol,
            "port": port
        }
    
    stats["top_source_ips"] = [
        (ip, data["count"], data["protocol"], data["port"]) 
        for ip, data in stats["by_source_ip"].items()
    ][:10]
    
    # Top destination IPs with additional details
    dest_ip_buckets = aggregations.get("top_dest_ips", {}).get("buckets", [])
    for bucket in dest_ip_buckets:
        dest_ip = bucket.get("key", "Unknown")
        count = bucket.get("doc_count", 0)
        
        # Get top protocol and port
        protocol_buckets = bucket.get("top_protocol", {}).get("buckets", [])
        protocol = protocol_buckets[0].get("key", "N/A") if protocol_buckets else "N/A"
        
        port_buckets = bucket.get("top_port", {}).get("buckets", [])
        port = port_buckets[0].get("key", "N/A") if port_buckets else "N/A"
        
        stats["by_dest_ip"][dest_ip] = {
            "count": count,
            "protocol": protocol,
            "port": port
        }
    
    stats["top_dest_ips"] = [
        (ip, data["count"], data["protocol"], data["port"]) 
        for ip, data in stats["by_dest_ip"].items()
    ][:10]
    
    # Top signatures with descriptions and severities
    signature_buckets = aggregations.get("top_signatures", {}).get("buckets", [])
    for bucket in signature_buckets:
        sig_id = bucket.get("key", "N/A")
        count = bucket.get("doc_count", 0)
        
        # Get signature description and severity from sub-aggregations
        sig_desc_buckets = bucket.get("signature_description", {}).get("buckets", [])
        description = sig_desc_buckets[0].get("key", "") if sig_desc_buckets else ""
        
        sig_severity_buckets = bucket.get("signature_severity", {}).get("buckets", [])
        severity = sig_severity_buckets[0].get("key", 1) if sig_severity_buckets else 1
        
        stats["by_signature"][sig_id] = {
            "count": count,
            "signature": description,
            "severity": severity
        }
    
    stats["top_signatures"] = [
        (sig_id, data["count"], data["signature"], data["severity"]) 
        for sig_id, data in stats["by_signature"].items()
    ][:10]
    
    # Alert categories
    category_buckets = aggregations.get("alert_categories", {}).get("buckets", [])
    for bucket in category_buckets:
        category = bucket.get("key", "Unknown")
        count = bucket.get("doc_count", 0)
        stats["by_category"][category] = count
    
    # Protocol distribution
    protocol_buckets = aggregations.get("protocol_distribution", {}).get("buckets", [])
    for bucket in protocol_buckets:
        protocol = bucket.get("key", "Unknown")
        count = bucket.get("doc_count", 0)
        stats["by_protocol"][protocol] = count
    
    # Network traffic types
    traffic_buckets = aggregations.get("network_traffic_types", {}).get("buckets", {})
    stats["dns_queries"] = traffic_buckets.get("dns_queries", {}).get("doc_count", 0)
    stats["http_requests"] = traffic_buckets.get("http_requests", {}).get("doc_count", 0)
    stats["tls_connections"] = traffic_buckets.get("tls_connections", {}).get("doc_count", 0)
    stats["tcp_connections"] = traffic_buckets.get("tcp_connections", {}).get("doc_count", 0)
    stats["udp_connections"] = traffic_buckets.get("udp_connections", {}).get("doc_count", 0)
    
    # Sample critical and high alerts for detailed reporting
    critical_sample = aggregations.get("critical_alerts_sample", {}).get("sample_alerts", {}).get("hits", {}).get("hits", [])
    stats["critical_alerts"] = [hit["_source"] for hit in critical_sample]
    
    high_sample = aggregations.get("high_alerts_sample", {}).get("sample_alerts", {}).get("hits", {}).get("hits", [])
    stats["high_alerts"] = [hit["_source"] for hit in high_sample]
    
    return stats


def build_dashboard_url(time_from, time_to, filters=None):
    """
    Build a valid OpenSearch Discover URL with proper Rison encoding.
    Produces URLs that properly drill through to filtered views in OpenSearch Dashboard.
    Handles special characters in field names and values correctly.
    """
    from urllib.parse import quote
    
    base = f"{DASHBOARD_BASE_URL}/app/discover#"

    # --- Build Rison strings manually with proper escaping ---
    # Filters section
    filter_str = "!()"
    if filters:
        filter_parts = []
        for f in filters:
            if f["type"] == "phrase":
                field = str(f["field"])
                value = str(f["value"])
                # Escape single quotes and backslashes for Rison string literals
                field_escaped = field.replace("\\", "\\\\").replace("'", "\\'")
                value_escaped = value.replace("\\", "\\\\").replace("'", "\\'")
                # Escape index pattern
                index_pattern_escaped = ES_INDEX_PATTERN.replace("\\", "\\\\").replace("'", "\\'")
                filter_parts.append(
                    f"(meta:(alias:!n,disabled:!f,index:'{index_pattern_escaped}',key:'{field_escaped}',negate:!f,params:(query:'{value_escaped}'),type:phrase,value:'{value_escaped}'),query:(match_phrase:({field_escaped}:'{value_escaped}')))"
                )
            elif f["type"] == "range":
                field = str(f["field"])
                field_escaped = field.replace("\\", "\\\\").replace("'", "\\'")
                index_pattern_escaped = ES_INDEX_PATTERN.replace("\\", "\\\\").replace("'", "\\'")
                gte = f["params"].get("gte", 0)
                lte = f["params"].get("lte", 0)
                filter_parts.append(
                    f"(meta:(alias:!n,disabled:!f,index:'{index_pattern_escaped}',key:'{field_escaped}',negate:!f,params:(gte:{gte},lte:{lte}),type:range),range:({field_escaped}:(gte:{gte},lte:{lte})))"
                )
            elif f["type"] == "exists":
                field = str(f["field"])
                field_escaped = field.replace("\\", "\\\\").replace("'", "\\'")
                index_pattern_escaped = ES_INDEX_PATTERN.replace("\\", "\\\\").replace("'", "\\'")
                filter_parts.append(
                    f"(meta:(alias:!n,disabled:!f,index:'{index_pattern_escaped}',key:'{field_escaped}',negate:!f,type:exists),exists:(field:'{field_escaped}'))"
                )
        filter_str = f"!({','.join(filter_parts)})"

    # --- Assemble states ---
    # Escape single quotes in index pattern
    index_pattern_escaped = ES_INDEX_PATTERN.replace("\\", "\\\\").replace("'", "\\'")
    _a = f"(columns:!(_source),filters:{filter_str},index:'{index_pattern_escaped}',sort:!())"
    
    # Escape single quotes in timestamps
    time_from_escaped = time_from.replace("'", "\\'")
    time_to_escaped = time_to.replace("'", "\\'")
    _g = f"(time:(from:'{time_from_escaped}',to:'{time_to_escaped}'))"
    _q = "(query:(language:kuery,query:''))"

    # --- Combine with proper URL encoding ---
    # Rison strings need to be URL-encoded, but preserve Rison syntax characters
    # Preserve: () for structure, ! for arrays, , for separators, : for key-value, ' for strings
    # Encode: spaces, &, =, #, and other special URL characters
    _a_encoded = quote(_a, safe='()!,\':')
    _g_encoded = quote(_g, safe='()!,\':')
    _q_encoded = quote(_q, safe='()!,\':')
    
    url = f"{base}?_a={_a_encoded}&_g={_g_encoded}&_q={_q_encoded}"
    return url


# === AI ANALYSIS ===
def get_ai_report_summary(stats, report_type, time_from, time_to):
    """Generate AI-powered executive summary and insights for Suricata alerts"""
    if not OLLAMA_ENABLED:
        return None
    
    try:
        import requests
        
        # Prepare data summary for AI
        top_src_ips_str = "\n".join([f"  - {ip}: {count} alerts" for ip, count, _, _ in stats["top_source_ips"][:5]])
        top_dest_ips_str = "\n".join([f"  - {ip}: {count} alerts" for ip, count, _, _ in stats["top_dest_ips"][:5]])
        top_signatures_str = "\n".join([f"  - Signature {sig_id}: {desc} ({count} occurrences, Severity {severity})" 
                                       for sig_id, count, desc, severity in stats["top_signatures"][:5]])
        categories_str = "\n".join([f"  - {category}: {count}" for category, count in 
                                   sorted(stats["by_category"].items(), key=lambda x: x[1], reverse=True)[:5]])
        
        # Prepare comparison data for AI
        comparison_str = ""
        if stats.get('comparisons'):
            comp = stats['comparisons']
            prev_period = stats.get('previous_period', {})
            comparison_str = f"""
**PERIOD-OVER-PERIOD COMPARISON (vs Previous Period: {prev_period.get('from', 'N/A')} to {prev_period.get('to', 'N/A')}):**
- Total Alerts: {comp['total_alerts']['current']} (Previous: {comp['total_alerts']['previous']}, Change: {comp['total_alerts']['change_pct']:.1f}% {comp['total_alerts']['change_type']})
- Critical Alerts: {comp['critical']['current']} (Previous: {comp['critical']['previous']}, Change: {comp['critical']['change_pct']:.1f}% {comp['critical']['change_type']})
- High Alerts: {comp['high']['current']} (Previous: {comp['high']['previous']}, Change: {comp['high']['change_pct']:.1f}% {comp['high']['change_type']})
- Medium Alerts: {comp['medium']['current']} (Previous: {comp['medium']['previous']}, Change: {comp['medium']['change_pct']:.1f}% {comp['medium']['change_type']})

Note: A decrease in alerts is generally positive (green), while an increase may indicate growing threats (red). Consider these trends in your analysis.
"""
        
        prompt = f"""You are a senior cybersecurity analyst for Athena SOC specializing in Network Intrusion Detection Systems (NIDS). Generate a comprehensive {report_type} security report for Suricata alerts during the period from {time_from} to {time_to}.

**NETWORK SECURITY METRICS SUMMARY:**
- Total Alerts: {stats['total_alerts']}
- Critical Severity: {stats['by_severity'].get('Critical', 0)}
- High Severity: {stats['by_severity'].get('High', 0)}
- Medium Severity: {stats['by_severity'].get('Medium', 0)}
{comparison_str}

**TOP SOURCE IPs (Top 5):**
{top_src_ips_str}

**TOP DESTINATION IPs (Top 5):**
{top_dest_ips_str}

**MOST TRIGGERED SIGNATURES (Top 5):**
{top_signatures_str}

**ALERT CATEGORIES:**
{categories_str}

**NETWORK TRAFFIC DISTRIBUTION:**
- TCP Connections: {stats['tcp_connections']}
- UDP Connections: {stats['udp_connections']}
- DNS Queries: {stats['dns_queries']}
- HTTP Requests: {stats['http_requests']}
- TLS Connections: {stats['tls_connections']}

**PROTOCOL BREAKDOWN:**
{', '.join([f"{proto}: {count}" for proto, count in sorted(stats['by_protocol'].items(), key=lambda x: x[1], reverse=True)[:5]]) if stats['by_protocol'] else 'No protocol data available'}

**SAMPLE CRITICAL ALERTS:**
{len(stats['critical_alerts'])} critical alerts detected (sample data available for analysis)

**SAMPLE HIGH SEVERITY ALERTS:**
{len(stats['high_alerts'])} high severity alerts detected (sample data available for analysis)

Provide your analysis in the following JSON format:
{{
    "executive_summary": "2-3 paragraph high-level summary for executives covering the overall network security posture, key threats detected, and critical network security items requiring attention",
    "key_findings": ["Finding 1", "Finding 2", "Finding 3", ...],
    "threat_landscape": "Analysis of the network threat landscape during this period, including attack patterns, suspicious network activities, and emerging network-based threats",
    "critical_concerns": ["Concern 1", "Concern 2", ...] or null if none,
    "recommendations": ["Recommendation 1", "Recommendation 2", "Recommendation 3", ...],
    "positive_observations": ["Positive observation 1", "Positive observation 2", ...] or null,
    "overall_risk_rating": "Low/Medium/High/Critical"
}}

Be specific, data-driven, and provide actionable insights focused on network security and intrusion detection. Use the aggregated statistics to identify patterns and trends rather than individual alert details. Focus on what matters most to network security leadership."""

        headers = {
            "Content-Type": "application/json"
        }

        payload = {
            "model": OLLAMA_MODEL,
            "messages": [
                {
                    "role": "system",
                    "content": "You are a senior cybersecurity analyst and report writer specializing in network intrusion detection, Suricata NIDS analysis, and network traffic security. Provide clear, executive-level security analysis with actionable insights. If a data field is empty, null, or 'N/A', state that the information is unavailable — do not speculate or hallucinate. Return ONLY valid JSON. Do not include any text before or after the JSON object."
                },
                {
                    "role": "user",
                    "content": prompt
                }
            ],
            "temperature": 0.3,
            "max_tokens": 4096,
            "response_format": {"type": "json_object"}
        }

        log(f"Calling Ollama API at {OLLAMA_API_URL} for {report_type} report analysis...")
        response = requests.post(
            OLLAMA_API_URL,
            headers=headers,
            json=payload,
            timeout=240
        )

        if response.status_code == 200:
            result = response.json()
            ai_content = result['choices'][0]['message']['content']
            ai_analysis = json.loads(ai_content)
            log("AI report analysis completed successfully")
            return ai_analysis
        else:
            log(f"Ollama API error: {response.status_code} - {response.text}")
            return None
            
    except Exception as e:
        import traceback
        traceback.print_exc()
        log(f"Error getting AI report analysis: {e}")
        log(f"Traceback: {traceback.format_exc()}")
        return None

# === PROFESSIONAL HTML REPORT GENERATOR ===
def format_comparison_html(comparison_key, stats, colors):
    """Format comparison indicator HTML"""
    if not stats.get('comparisons') or comparison_key not in stats['comparisons']:
        return '<div style="color:' + colors['text_light'] + ';font-size:11px;margin-bottom:8px;visibility:hidden;height:14px;">&nbsp;</div>'
    
    comp = stats['comparisons'][comparison_key]
    change_type = comp.get('change_type', 'no change')
    change_pct = comp.get('change_pct', 0)
    
    if change_type == 'decrease':
        color = colors['success']
        arrow = '↓'
    elif change_type == 'increase':
        color = colors['danger']
        arrow = '↑'
    else:
        color = colors['text_light']
        arrow = '→'
    
    return f'<div style="color:{color};font-size:11px;margin-bottom:8px;font-weight:500;">{arrow} {change_pct:.1f}% vs previous period</div>'

def build_html_report(report_type, time_from, time_to, stats, ai_analysis):
    """Build professional HTML email report"""
    
    from html import escape as html_escape
    
    # Format dates
    from_date = datetime.fromisoformat(time_from.replace('Z', '+00:00')).strftime('%B %d, %Y')
    to_date = datetime.fromisoformat(time_to.replace('Z', '+00:00')).strftime('%B %d, %Y')
    
    # Professional color scheme
    colors = {
        "primary": "#1e40af",
        "secondary": "#64748b", 
        "success": "#059669",
        "warning": "#d97706",
        "danger": "#dc2626",
        "info": "#0284c7",
        "light": "#f8fafc",
        "dark": "#1e293b",
        "border": "#e2e8f0",
        "text": "#374151",
        "text_light": "#6b7280"
    }
    
    # Build dashboard links
    all_alerts_url = build_dashboard_url(time_from, time_to)
    critical_url = build_dashboard_url(time_from, time_to, [
        {"type": "range", "field": "alert.severity", "params": {"gte": 1, "lte": 1}}
    ])
    high_url = build_dashboard_url(time_from, time_to, [
        {"type": "range", "field": "alert.severity", "params": {"gte": 2, "lte": 2}}
    ])
    medium_url = build_dashboard_url(time_from, time_to, [
        {"type": "range", "field": "alert.severity", "params": {"gte": 3, "lte": 3}}
    ])
    
    # Network Traffic Categories drill-through URLs
    tcp_url = build_dashboard_url(time_from, time_to, [
        {"type": "phrase", "field": "proto", "value": "TCP"}
    ])
    udp_url = build_dashboard_url(time_from, time_to, [
        {"type": "phrase", "field": "proto", "value": "UDP"}
    ])
    dns_url = build_dashboard_url(time_from, time_to, [
        {"type": "exists", "field": "dns"}
    ])
    http_url = build_dashboard_url(time_from, time_to, [
        {"type": "exists", "field": "http"}
    ])
    tls_url = build_dashboard_url(time_from, time_to, [
        {"type": "exists", "field": "tls"}
    ])
    
    # Generate comparison HTML strings before the f-string
    total_comparison_html = format_comparison_html('total_alerts', stats, colors)
    critical_comparison_html = format_comparison_html('critical', stats, colors)
    high_comparison_html = format_comparison_html('high', stats, colors)
    medium_comparison_html = format_comparison_html('medium', stats, colors)

# === Unified AI Analysis Section (Complete Version) ===
    ai_section = ""
    if ai_analysis:
        # Dynamic color map for risk rating
        risk = ai_analysis.get("overall_risk_rating", "").capitalize()
        risk_color = {
            "Critical": "#b91c1c",
            "High": "#fb8c00",
            "Medium": "#facc15",
            "Low": "#22c55e"
        }.get(risk, "#6b7280")

        # Build unified boxed container using concatenation (Python 3.11 compatible)
        ai_section = """
        <table width="100%" cellpadding="0" cellspacing="0" border="0"
            style="background:#f0f9ff;border:1px solid #c7d2fe;border-radius:6px;margin:24px 0;">
        <tr>
            <td style="background:#0d47a1;padding:12px 20px;
                    border-top-left-radius:6px;border-top-right-radius:6px;">
            <h2 style="margin:0;color:#fff;font-size:16px;font-weight:600;">
                Athena AI: Security Analysis
            </h2>
            </td>
        </tr>
        <tr>
            <td style="padding:20px;color:#1e293b;font-size:14px;line-height:1.6;">
        """

        # Overall Risk Rating
        if risk:
            ai_section += f"""
            <div style='margin-top:6px;margin-bottom:24px;'>
                <span style='background:{risk_color};color:#fff;padding:4px 10px;
                            border-radius:12px;font-size:13px;font-weight:600;'>
                Overall Risk Rating: {html.escape(risk or 'N/A')}
                </span>
            </div>
            """

        # Executive Summary
        ai_section += f"""
            <div style="margin-bottom:16px;">
                <strong>Executive Summary:</strong>
                <p style="margin:4px 0;">{html.escape(ai_analysis.get('executive_summary', 'No executive summary available.'))}</p>
            </div>
        """

        # Key Findings
        if ai_analysis.get('key_findings'):
            findings_html = ''.join([f"<li style='margin:4px 0;'>{html.escape(finding)}</li>" for finding in ai_analysis['key_findings']])
            ai_section += f"""
            <div style='margin-bottom:16px;'>
                <strong>Key Findings:</strong>
                <ul style='margin:6px 0;padding-left:20px;'>
                {findings_html}
                </ul>
            </div>
            """

        # Threat Landscape
        if ai_analysis.get('threat_landscape'):
            ai_section += f"""
            <div style='margin-bottom:16px;'>
                <strong>Threat Landscape:</strong>
                <p style="margin:4px 0;">{html.escape(ai_analysis.get('threat_landscape', ''))}</p>
            </div>
            """

        # Critical Concerns
        if ai_analysis.get('critical_concerns'):
            concerns_html = ''.join([f"<li style='margin:4px 0;color:#dc2626;'><strong>{html.escape(concern)}</strong></li>" for concern in ai_analysis['critical_concerns']])
            ai_section += f"""
            <div style='margin-bottom:16px;background:#fef2f2;padding:12px;border-radius:4px;border-left:4px solid #dc2626;'>
                <strong style='color:#dc2626;'>Critical Concerns:</strong>
                <ul style='margin:6px 0;padding-left:20px;'>
                {concerns_html}
                </ul>
            </div>
            """

        # Recommendations
        if ai_analysis.get('recommendations'):
            recs_html = ''.join([f"<li style='margin:4px 0;'>{html.escape(rec)}</li>" for rec in ai_analysis['recommendations']])
            ai_section += f"""
            <div style='margin-bottom:16px;'>
                <strong>Recommendations:</strong>
                <ol style='margin:6px 0;padding-left:20px;'>
                {recs_html}
                </ol>
            </div>
            """

        # Positive Observations
        if ai_analysis.get('positive_observations'):
            obs_html = ''.join([f"<li style='margin:4px 0;color:#166534;'>{html.escape(obs)}</li>" for obs in ai_analysis['positive_observations']])
            ai_section += f"""
            <div style='margin-bottom:16px;background:#f0fdf4;padding:12px;border-radius:4px;border-left:4px solid #22c55e;'>
                <strong style='color:#166534;'>Positive Observations:</strong>
                <ul style='margin:6px 0;padding-left:20px;'>
                {obs_html}
                </ul>
            </div>
            """

        ai_section += """
            </td>
        </tr>
        </table>
        """
    
    # Top Source IPs Table with enhanced columns
    top_src_ips_rows = ""
    for i, ip_data in enumerate(stats["top_source_ips"][:10], 1):
        # Handle both old format (tuple) and new format (tuple with protocol/port)
        if len(ip_data) == 4:
            src_ip, count, protocol, port = ip_data
        else:
            src_ip, count = ip_data[:2]
            protocol, port = "N/A", "N/A"
        
        src_ip_url = build_dashboard_url(time_from, time_to, [
            {"type": "phrase", "field": "src_ip", "value": src_ip}
        ])
        protocol_url = build_dashboard_url(time_from, time_to, [
            {"type": "phrase", "field": "src_ip", "value": src_ip},
            {"type": "phrase", "field": "proto", "value": protocol}
        ]) if protocol != "N/A" else "#"
        port_url = build_dashboard_url(time_from, time_to, [
            {"type": "phrase", "field": "src_ip", "value": src_ip},
            {"type": "phrase", "field": "src_port", "value": str(port)}
        ]) if port != "N/A" else "#"
        
        top_src_ips_rows += f"""
        <tr>
            <td style="padding:12px 16px;border-bottom:1px solid {colors['border']};font-size:14px;color:{colors['text']};">{i}</td>
            <td style="padding:12px 16px;border-bottom:1px solid {colors['border']};">
                <a href="{src_ip_url}" style="color:{colors['primary']};text-decoration:none;font-weight:500;font-size:14px;">{html_escape(src_ip)}</a>
            </td>
            <td style="padding:12px 16px;border-bottom:1px solid {colors['border']};text-align:center;">
                {f'<a href="{protocol_url}" style="color:{colors["info"]};text-decoration:none;font-size:13px;">{html_escape(protocol)}</a>' if protocol != "N/A" else '<span style="color:' + colors['text_light'] + ';font-size:13px;">N/A</span>'}
            </td>
            <td style="padding:12px 16px;border-bottom:1px solid {colors['border']};text-align:center;">
                {f'<a href="{port_url}" style="color:{colors["secondary"]};text-decoration:none;font-size:13px;">{port}</a>' if port != "N/A" else '<span style="color:' + colors['text_light'] + ';font-size:13px;">N/A</span>'}
            </td>
            <td style="padding:12px 16px;border-bottom:1px solid {colors['border']};text-align:right;font-weight:600;font-size:14px;color:{colors['text']};">
                <a href="{src_ip_url}" style="color:{colors['text']};text-decoration:none;">{count}</a>
            </td>
        </tr>
"""
    
    # Top Destination IPs Table with enhanced columns
    top_dest_ips_rows = ""
    for i, ip_data in enumerate(stats["top_dest_ips"][:10], 1):
        # Handle both old format (tuple) and new format (tuple with protocol/port)
        if len(ip_data) == 4:
            dest_ip, count, protocol, port = ip_data
        else:
            dest_ip, count = ip_data[:2]
            protocol, port = "N/A", "N/A"
        
        dest_ip_url = build_dashboard_url(time_from, time_to, [
            {"type": "phrase", "field": "dest_ip", "value": dest_ip}
        ])
        protocol_url = build_dashboard_url(time_from, time_to, [
            {"type": "phrase", "field": "dest_ip", "value": dest_ip},
            {"type": "phrase", "field": "proto", "value": protocol}
        ]) if protocol != "N/A" else "#"
        port_url = build_dashboard_url(time_from, time_to, [
            {"type": "phrase", "field": "dest_ip", "value": dest_ip},
            {"type": "phrase", "field": "dest_port", "value": str(port)}
        ]) if port != "N/A" else "#"
        
        top_dest_ips_rows += f"""
        <tr>
            <td style="padding:12px 16px;border-bottom:1px solid {colors['border']};font-size:14px;color:{colors['text']};">{i}</td>
            <td style="padding:12px 16px;border-bottom:1px solid {colors['border']};">
                <a href="{dest_ip_url}" style="color:{colors['primary']};text-decoration:none;font-weight:500;font-size:14px;">{html_escape(dest_ip)}</a>
            </td>
            <td style="padding:12px 16px;border-bottom:1px solid {colors['border']};text-align:center;">
                {f'<a href="{protocol_url}" style="color:{colors["info"]};text-decoration:none;font-size:13px;">{html_escape(protocol)}</a>' if protocol != "N/A" else '<span style="color:' + colors['text_light'] + ';font-size:13px;">N/A</span>'}
            </td>
            <td style="padding:12px 16px;border-bottom:1px solid {colors['border']};text-align:center;">
                {f'<a href="{port_url}" style="color:{colors["secondary"]};text-decoration:none;font-size:13px;">{port}</a>' if port != "N/A" else '<span style="color:' + colors['text_light'] + ';font-size:13px;">N/A</span>'}
            </td>
            <td style="padding:12px 16px;border-bottom:1px solid {colors['border']};text-align:right;font-weight:600;font-size:14px;color:{colors['text']};">
                <a href="{dest_ip_url}" style="color:{colors['text']};text-decoration:none;">{count}</a>
            </td>
        </tr>
"""
    
    # Top Signatures Table
    top_signatures_rows = ""
    for i, (sig_id, count, desc, severity) in enumerate(stats["top_signatures"][:10], 1):
        severity_label = "Critical" if severity >= 4 else "High" if severity >= 3 else "Medium" if severity >= 2 else "Unknown"
        sig_url = build_dashboard_url(time_from, time_to, [
            {"type": "phrase", "field": "alert.signature_id", "value": str(sig_id)}
        ])
        severity_color = colors['danger'] if severity_label == 'Critical' else colors['warning'] if severity_label == 'High' else colors['info'] if severity_label == 'Medium' else colors['success']
        top_signatures_rows += f"""
        <tr>
            <td style="padding:12px 16px;border-bottom:1px solid {colors['border']};">
                <a href="{sig_url}" style="color:{colors['primary']};text-decoration:none;font-weight:500;font-size:14px;">{sig_id}</a>
            </td>
            <td style="padding:12px 16px;border-bottom:1px solid {colors['border']};font-size:14px;color:{colors['text']};">{html_escape(desc[:60] + '...' if len(desc) > 60 else desc)}</td>
            <td style="padding:12px 16px;border-bottom:1px solid {colors['border']};text-align:center;">
                <span style="background:{severity_color};color:#fff;padding:4px 12px;border-radius:4px;font-size:12px;font-weight:500;display:inline-block;width:80px;text-align:center;box-sizing:border-box;">
                    {severity_label}
                </span>
            </td>
            <td style="padding:12px 16px;border-bottom:1px solid {colors['border']};text-align:right;font-weight:600;font-size:14px;color:{colors['text']};">{count}</td>
        </tr>
"""
    
    # Protocol Distribution Table with drill-through
    protocol_rows = ""
    sorted_protocols = sorted(stats["by_protocol"].items(), key=lambda x: x[1], reverse=True)[:8]
    for protocol, count in sorted_protocols:
        max_count = max([count for _, count in sorted_protocols]) if sorted_protocols else 1
        percentage = min(100, (count * 100) // max_count)
        protocol_url = build_dashboard_url(time_from, time_to, [
            {"type": "phrase", "field": "proto", "value": protocol}
        ])
        protocol_rows += f"""
        <tr>
            <td style="padding:12px 16px;border-bottom:1px solid {colors['border']};">
                <a href="{protocol_url}" style="color:{colors['primary']};text-decoration:none;font-weight:500;font-size:14px;">{html_escape(protocol)}</a>
            </td>
            <td style="padding:12px 16px;border-bottom:1px solid {colors['border']};text-align:right;font-weight:600;font-size:14px;color:{colors['text']};">
                <a href="{protocol_url}" style="color:{colors['text']};text-decoration:none;">{count}</a>
            </td>
            <td style="padding:12px 16px;border-bottom:1px solid {colors['border']};">
                <a href="{protocol_url}" style="text-decoration:none;display:block;">
                    <div style="background:#e0e7ff;height:6px;border-radius:3px;overflow:hidden;">
                        <div style="background:{colors['primary']};height:100%;width:{percentage}%;"></div>
                    </div>
                </a>
            </td>
        </tr>
"""
    
    html_output = f"""
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <!--[if mso]>
    <style type="text/css">
        body, table, td {{font-family: Arial, sans-serif !important;}}
    </style>
    <![endif]-->
</head>
<body style="margin:0;padding:0;font-family:Arial,sans-serif;background:{colors['light']};width:100%;">
    
    <table width="100%" cellpadding="0" cellspacing="0" border="0" style="background:{colors['light']};margin:0;padding:0;">
        <tr>
            <td align="center" style="padding:0;">
                
                <!-- Header -->
                <div style="background:#0d47a1;color:#fff;padding:12px 18px;font-size:18px;font-weight:700;">
                {ATHENA_NAME} — {report_type.title()} NIDS Report
                <div style="font-size:12px;font-weight:400;opacity:0.95;color:#ffffff !important;">Tenant: {html_escape(TENANT_NAME)}</div>
                <div style="font-size:12px;font-weight:400;opacity:0.95;color:#ffffff;margin-top:4px;">📅 {from_date} — {to_date}</div>
                </div>
                <div style="padding:16px 18px;font-family:Arial,sans-serif;line-height:1.5;">
                <p style="margin:0 0 16px 0;">This is an automated NIDS report generated by {ATHENA_NAME}.</p>
                            
                            <!-- Quick Stats -->
                            <table width="100%" cellpadding="0" cellspacing="0" border="0" style="margin-bottom:32px;">
                                <tr>
                                    <td style="padding:0;">
                                        <table width="100%" cellpadding="0" cellspacing="0" border="0">
                                            <tr>
                                                <!-- Total Alerts -->
                                                <td width="25%" style="padding:8px;vertical-align:top;">
                                                    <table width="100%" cellpadding="0" cellspacing="0" border="0" style="background:#fff;border:1px solid {colors['border']};border-radius:6px;height:160px;table-layout:fixed;">
                                                        <tr>
                                                            <td style="padding:20px;text-align:center;height:160px;vertical-align:middle;">
                                                                <div style="font-size:32px;font-weight:700;color:{colors['primary']};margin-bottom:4px;">{stats['total_alerts']}</div>
                                                                <div style="color:{colors['text_light']};font-size:12px;text-transform:uppercase;letter-spacing:0.5px;margin-bottom:4px;">Total Alerts</div>
                                                                <div style="min-height:20px;margin-bottom:4px;">{total_comparison_html}</div>
                                                                <a href="{all_alerts_url}" style="color:{colors['primary']};text-decoration:none;font-size:12px;font-weight:500;">View All →</a>
                                                            </td>
                                                        </tr>
                                                    </table>
                                                </td>
                                                
                                                <!-- Critical (Level 1) -->
                                                <td width="25%" style="padding:8px;vertical-align:top;">
                                                    <table width="100%" cellpadding="0" cellspacing="0" border="0" style="background:#fef2f2;border:1px solid #fecaca;border-radius:6px;height:160px;table-layout:fixed;">
                                                        <tr>
                                                            <td style="padding:20px;text-align:center;height:160px;vertical-align:middle;">
                                                                <div style="font-size:32px;font-weight:700;color:{colors['danger']};margin-bottom:4px;">{stats['by_severity'].get('Critical', 0)}</div>
                                                                <div style="color:{colors['danger']};font-size:12px;text-transform:uppercase;letter-spacing:0.5px;margin-bottom:4px;">Critical</div>
                                                                <div style="color:{colors['text_light']};font-size:11px;margin-bottom:4px;">Severity Level 1</div>
                                                                <div style="min-height:20px;margin-bottom:4px;">{critical_comparison_html}</div>
                                                                <a href="{critical_url}" style="color:{colors['danger']};text-decoration:none;font-size:12px;font-weight:500;">View Details →</a>
                                                            </td>
                                                        </tr>
                                                    </table>
                                                </td>
                                                
                                                <!-- High (Level 2) -->
                                                <td width="25%" style="padding:8px;vertical-align:top;">
                                                    <table width="100%" cellpadding="0" cellspacing="0" border="0" style="background:#fff7ed;border:1px solid #fed7aa;border-radius:6px;height:160px;table-layout:fixed;">
                                                        <tr>
                                                            <td style="padding:20px;text-align:center;height:160px;vertical-align:middle;">
                                                                <div style="font-size:32px;font-weight:700;color:{colors['warning']};margin-bottom:4px;">{stats['by_severity'].get('High', 0)}</div>
                                                                <div style="color:{colors['warning']};font-size:12px;text-transform:uppercase;letter-spacing:0.5px;margin-bottom:4px;">High</div>
                                                                <div style="color:{colors['text_light']};font-size:11px;margin-bottom:4px;">Severity Level 2</div>
                                                                <div style="min-height:20px;margin-bottom:4px;">{high_comparison_html}</div>
                                                                <a href="{high_url}" style="color:{colors['warning']};text-decoration:none;font-size:12px;font-weight:500;">View Details →</a>
                                                            </td>
                                                        </tr>
                                                    </table>
                                                </td>
                                                
                                                <!-- Medium (Level 3) -->
                                                <td width="25%" style="padding:8px;vertical-align:top;">
                                                    <table width="100%" cellpadding="0" cellspacing="0" border="0" style="background:#fff;border:1px solid {colors['border']};border-radius:6px;height:160px;table-layout:fixed;">
                                                        <tr>
                                                            <td style="padding:20px;text-align:center;height:160px;vertical-align:middle;">
                                                                <div style="font-size:32px;font-weight:700;color:{colors['info']};margin-bottom:4px;">{stats['by_severity'].get('Medium', 0)}</div>
                                                                <div style="color:{colors['text_light']};font-size:12px;text-transform:uppercase;letter-spacing:0.5px;margin-bottom:4px;">Medium</div>
                                                                <div style="color:{colors['text_light']};font-size:11px;margin-bottom:4px;">Severity Level 3</div>
                                                                <div style="min-height:20px;margin-bottom:4px;">{medium_comparison_html}</div>
                                                                <a href="{medium_url}" style="color:{colors['info']};text-decoration:none;font-size:12px;font-weight:500;">View Details →</a>
                                                            </td>
                                                        </tr>
                                                    </table>
                                                </td>
                                            </tr>
                                        </table>
                                    </td>
                                </tr>
                            </table>
                            
                            {ai_section}
        
                            <!-- Network Traffic Categories -->
                            <table width="100%" cellpadding="0" cellspacing="0" border="0" style="background:#fff;border:1px solid {colors['border']};border-radius:6px;margin:24px 0;">
                                <tr>
                                    <td style="padding:24px;">
                                        <h3 style="margin:0 0 20px 0;color:{colors['dark']};font-size:18px;font-weight:600;border-bottom:2px solid {colors['border']};padding-bottom:8px;">Network Traffic Categories</h3>
                                        <table width="100%" cellpadding="0" cellspacing="0" border="0">
                                            <tr>
                                                <td width="20%" style="padding:8px;">
                                                    <a href="{tcp_url}" style="text-decoration:none;display:block;">
                                                        <table width="100%" cellpadding="0" cellspacing="0" border="0" style="background:{colors['light']};border:1px solid {colors['border']};border-radius:4px;transition:all 0.2s;">
                                                            <tr>
                                                                <td style="padding:16px;text-align:center;">
                                                                    <div style="font-size:24px;font-weight:700;color:{colors['info']};margin-bottom:4px;">{stats['tcp_connections']}</div>
                                                                    <div style="color:{colors['text_light']};font-size:13px;">TCP Connections</div>
                                                                </td>
                                                            </tr>
                                                        </table>
                                                    </a>
                                                </td>
                                                <td width="20%" style="padding:8px;">
                                                    <a href="{udp_url}" style="text-decoration:none;display:block;">
                                                        <table width="100%" cellpadding="0" cellspacing="0" border="0" style="background:{colors['light']};border:1px solid {colors['border']};border-radius:4px;transition:all 0.2s;">
                                                            <tr>
                                                                <td style="padding:16px;text-align:center;">
                                                                    <div style="font-size:24px;font-weight:700;color:{colors['warning']};margin-bottom:4px;">{stats['udp_connections']}</div>
                                                                    <div style="color:{colors['text_light']};font-size:13px;">UDP Connections</div>
                                                                </td>
                                                            </tr>
                                                        </table>
                                                    </a>
                                                </td>
                                                <td width="20%" style="padding:8px;">
                                                    <a href="{dns_url}" style="text-decoration:none;display:block;">
                                                        <table width="100%" cellpadding="0" cellspacing="0" border="0" style="background:{colors['light']};border:1px solid {colors['border']};border-radius:4px;transition:all 0.2s;">
                                                            <tr>
                                                                <td style="padding:16px;text-align:center;">
                                                                    <div style="font-size:24px;font-weight:700;color:{colors['success']};margin-bottom:4px;">{stats['dns_queries']}</div>
                                                                    <div style="color:{colors['text_light']};font-size:13px;">DNS Queries</div>
                                                                </td>
                                                            </tr>
                                                        </table>
                                                    </a>
                                                </td>
                                                <td width="20%" style="padding:8px;">
                                                    <a href="{http_url}" style="text-decoration:none;display:block;">
                                                        <table width="100%" cellpadding="0" cellspacing="0" border="0" style="background:{colors['light']};border:1px solid {colors['border']};border-radius:4px;transition:all 0.2s;">
                                                            <tr>
                                                                <td style="padding:16px;text-align:center;">
                                                                    <div style="font-size:24px;font-weight:700;color:{colors['secondary']};margin-bottom:4px;">{stats['http_requests']}</div>
                                                                    <div style="color:{colors['text_light']};font-size:13px;">HTTP Requests</div>
                                                                </td>
                                                            </tr>
                                                        </table>
                                                    </a>
                                                </td>
                                                <td width="20%" style="padding:8px;">
                                                    <a href="{tls_url}" style="text-decoration:none;display:block;">
                                                        <table width="100%" cellpadding="0" cellspacing="0" border="0" style="background:{colors['light']};border:1px solid {colors['border']};border-radius:4px;transition:all 0.2s;">
                                                            <tr>
                                                                <td style="padding:16px;text-align:center;">
                                                                    <div style="font-size:24px;font-weight:700;color:{colors['primary']};margin-bottom:4px;">{stats['tls_connections']}</div>
                                                                    <div style="color:{colors['text_light']};font-size:13px;">TLS Connections</div>
                                                                </td>
                                                            </tr>
                                                        </table>
                                                    </a>
                                                </td>
                                            </tr>
                                        </table>
                                    </td>
                                </tr>
                            </table>
        
                            <!-- Top Source IPs -->
                            <table width="100%" cellpadding="0" cellspacing="0" border="0" style="background:#fff;border:1px solid {colors['border']};border-radius:6px;margin:24px 0;">
                                <tr>
                                    <td style="padding:24px;">
                                        <h3 style="margin:0 0 16px 0;color:{colors['dark']};font-size:18px;font-weight:600;border-bottom:2px solid {colors['border']};padding-bottom:8px;">Top Source IPs</h3>
                                        <table width="100%" cellpadding="0" cellspacing="0" border="0" style="border-collapse:collapse;">
                                            <thead>
                                                <tr style="background:{colors['light']};">
                                                    <th style="padding:12px 16px;text-align:left;font-size:12px;color:{colors['text_light']};text-transform:uppercase;letter-spacing:0.5px;border-bottom:1px solid {colors['border']};width:60px;">#</th>
                                                    <th style="padding:12px 16px;text-align:left;font-size:12px;color:{colors['text_light']};text-transform:uppercase;letter-spacing:0.5px;border-bottom:1px solid {colors['border']};">Source IP</th>
                                                    <th style="padding:12px 16px;text-align:center;font-size:12px;color:{colors['text_light']};text-transform:uppercase;letter-spacing:0.5px;border-bottom:1px solid {colors['border']};width:100px;">Protocol</th>
                                                    <th style="padding:12px 16px;text-align:center;font-size:12px;color:{colors['text_light']};text-transform:uppercase;letter-spacing:0.5px;border-bottom:1px solid {colors['border']};width:100px;">Port</th>
                                                    <th style="padding:12px 16px;text-align:right;font-size:12px;color:{colors['text_light']};text-transform:uppercase;letter-spacing:0.5px;border-bottom:1px solid {colors['border']};width:100px;">Alert Count</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                {top_src_ips_rows}
                                            </tbody>
                                        </table>
                                    </td>
                                </tr>
                            </table>
        
                            <!-- Top Destination IPs -->
                            <table width="100%" cellpadding="0" cellspacing="0" border="0" style="background:#fff;border:1px solid {colors['border']};border-radius:6px;margin:24px 0;">
                                <tr>
                                    <td style="padding:24px;">
                                        <h3 style="margin:0 0 16px 0;color:{colors['dark']};font-size:18px;font-weight:600;border-bottom:2px solid {colors['border']};padding-bottom:8px;">Top Destination IPs</h3>
                                        <table width="100%" cellpadding="0" cellspacing="0" border="0" style="border-collapse:collapse;">
                                            <thead>
                                                <tr style="background:{colors['light']};">
                                                    <th style="padding:12px 16px;text-align:left;font-size:12px;color:{colors['text_light']};text-transform:uppercase;letter-spacing:0.5px;border-bottom:1px solid {colors['border']};width:60px;">#</th>
                                                    <th style="padding:12px 16px;text-align:left;font-size:12px;color:{colors['text_light']};text-transform:uppercase;letter-spacing:0.5px;border-bottom:1px solid {colors['border']};">Destination IP</th>
                                                    <th style="padding:12px 16px;text-align:center;font-size:12px;color:{colors['text_light']};text-transform:uppercase;letter-spacing:0.5px;border-bottom:1px solid {colors['border']};width:100px;">Protocol</th>
                                                    <th style="padding:12px 16px;text-align:center;font-size:12px;color:{colors['text_light']};text-transform:uppercase;letter-spacing:0.5px;border-bottom:1px solid {colors['border']};width:100px;">Port</th>
                                                    <th style="padding:12px 16px;text-align:right;font-size:12px;color:{colors['text_light']};text-transform:uppercase;letter-spacing:0.5px;border-bottom:1px solid {colors['border']};width:100px;">Alert Count</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                {top_dest_ips_rows}
                                            </tbody>
                                        </table>
                                    </td>
                                </tr>
                            </table>
        
                            <!-- Most Triggered Signatures -->
                            <table width="100%" cellpadding="0" cellspacing="0" border="0" style="background:#fff;border:1px solid {colors['border']};border-radius:6px;margin:24px 0;">
                                <tr>
                                    <td style="padding:24px;">
                                        <h3 style="margin:0 0 16px 0;color:{colors['dark']};font-size:18px;font-weight:600;border-bottom:2px solid {colors['border']};padding-bottom:8px;">Most Triggered Signatures</h3>
                                        <table width="100%" cellpadding="0" cellspacing="0" border="0" style="border-collapse:collapse;">
                                            <thead>
                                                <tr style="background:{colors['light']};">
                                                    <th style="padding:12px 16px;text-align:left;font-size:12px;color:{colors['text_light']};text-transform:uppercase;letter-spacing:0.5px;border-bottom:1px solid {colors['border']};width:100px;">Signature ID</th>
                                                    <th style="padding:12px 16px;text-align:left;font-size:12px;color:{colors['text_light']};text-transform:uppercase;letter-spacing:0.5px;border-bottom:1px solid {colors['border']};">Description</th>
                                                    <th style="padding:12px 16px;text-align:center;font-size:12px;color:{colors['text_light']};text-transform:uppercase;letter-spacing:0.5px;border-bottom:1px solid {colors['border']};width:80px;">Severity</th>
                                                    <th style="padding:12px 16px;text-align:right;font-size:12px;color:{colors['text_light']};text-transform:uppercase;letter-spacing:0.5px;border-bottom:1px solid {colors['border']};width:80px;">Count</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                {top_signatures_rows}
                                            </tbody>
                                        </table>
                                    </td>
                                </tr>
                            </table>
        
                            <!-- Protocol Distribution -->
                            {f'''
                            <table width="100%" cellpadding="0" cellspacing="0" border="0" style="background:#fff;border:1px solid {colors['border']};border-radius:6px;margin:24px 0;">
                                <tr>
                                    <td style="padding:24px;">
                                        <h3 style="margin:0 0 16px 0;color:{colors['dark']};font-size:18px;font-weight:600;border-bottom:2px solid {colors['border']};padding-bottom:8px;">Protocol Distribution</h3>
                                        <table width="100%" cellpadding="0" cellspacing="0" border="0" style="border-collapse:collapse;">
                                            <thead>
                                                <tr style="background:{colors['light']};">
                                                    <th style="padding:12px 16px;text-align:left;font-size:12px;color:{colors['text_light']};text-transform:uppercase;letter-spacing:0.5px;border-bottom:1px solid {colors['border']};">Protocol</th>
                                                    <th style="padding:12px 16px;text-align:right;font-size:12px;color:{colors['text_light']};text-transform:uppercase;letter-spacing:0.5px;border-bottom:1px solid {colors['border']};width:80px;">Count</th>
                                                    <th style="padding:12px 16px;text-align:left;font-size:12px;color:{colors['text_light']};text-transform:uppercase;letter-spacing:0.5px;border-bottom:1px solid {colors['border']};width:120px;">Distribution</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                {protocol_rows}
                                            </tbody>
                                        </table>
                                    </td>
                                </tr>
                            </table>
                            ''' if stats['by_protocol'] else ''}
        
    
        
                        </td>
                    </tr>
                </table>
                
                <!-- Footer -->
                <div style="background:#f3f4f6;color:#333;padding:12px 18px;font-size:12px;">
                <p style="margin:2px 0 6px 0;"><strong>Athena Security Group</strong></p>
                <p style="margin:2px 0;">🌐 <a href="{ATHENA_WEBSITE}" style="color:#0d47a1;text-decoration:none;">Website</a>
                   &nbsp;|&nbsp; 📄 <a href="{ATHENA_DOCS}" style="color:#0d47a1;text-decoration:none;">Docs</a>
                   &nbsp;|&nbsp; 📧 <a href="mailto:{ATHENA_SUPPORT}" style="color:#0d47a1;text-decoration:none;">{ATHENA_SUPPORT}</a></p>
                <p style="margin:10px 0 0 0;">This automated {report_type} report was generated on {datetime.now().strftime('%B %d, %Y at %I:%M %p UTC')}. Do not reply to this email.</p>
                </div>
                
            </td>
        </tr>
    </table>
    
</body>
</html>
"""
    
    return html_output

def build_plain_report(report_type, time_from, time_to, stats, ai_analysis):
    """Build plain text version of the report"""
    from_date = datetime.fromisoformat(time_from.replace('Z', '+00:00')).strftime('%B %d, %Y')
    to_date = datetime.fromisoformat(time_to.replace('Z', '+00:00')).strftime('%B %d, %Y')
    
    lines = []
    lines.append("=" * 80)
    lines.append(f"{ATHENA_NAME} - {report_type.upper()} NIDS REPORT")
    lines.append("=" * 80)
    lines.append(f"Tenant: {TENANT_NAME}")
    lines.append(f"Period: {from_date} — {to_date}")
    lines.append("")
    
    lines.append("ALERT SUMMARY")
    lines.append("-" * 80)
    lines.append(f"Total Alerts: {stats['total_alerts']}")
    lines.append(f"  Critical: {stats['by_severity'].get('Critical', 0)}")
    lines.append(f"  High: {stats['by_severity'].get('High', 0)}")
    lines.append(f"  Medium: {stats['by_severity'].get('Medium', 0)}")
    lines.append("")
    
    if ai_analysis:
        lines.append("AI-POWERED EXECUTIVE SUMMARY")
        lines.append("-" * 80)
        lines.append(ai_analysis.get('executive_summary', ''))
        lines.append("")
        lines.append(f"Overall Risk Rating: {ai_analysis.get('overall_risk_rating', 'N/A')}")
        lines.append("")
        
        if ai_analysis.get('key_findings'):
            lines.append("KEY FINDINGS:")
            for i, finding in enumerate(ai_analysis['key_findings'], 1):
                lines.append(f"  {i}. {finding}")
            lines.append("")

        if ai_analysis.get('threat_landscape'):
            lines.append("THREAT LANDSCAPE:")
            lines.append(f"  {ai_analysis['threat_landscape']}")
            lines.append("")

        if ai_analysis.get('critical_concerns'):
            lines.append("⚠️  CRITICAL CONCERNS:")
            for concern in ai_analysis['critical_concerns']:
                lines.append(f"  • {concern}")
            lines.append("")

        if ai_analysis.get('recommendations'):
            lines.append("RECOMMENDATIONS:")
            for i, rec in enumerate(ai_analysis['recommendations'], 1):
                lines.append(f"  {i}. {rec}")
            lines.append("")

        if ai_analysis.get('positive_observations'):
            lines.append("✅ POSITIVE OBSERVATIONS:")
            for obs in ai_analysis['positive_observations']:
                lines.append(f"  • {obs}")
            lines.append("")

    lines.append("NETWORK TRAFFIC CATEGORIES")
    lines.append("-" * 80)
    lines.append(f"TCP Connections: {stats['tcp_connections']}")
    lines.append(f"UDP Connections: {stats['udp_connections']}")
    lines.append(f"DNS Queries: {stats['dns_queries']}")
    lines.append(f"HTTP Requests: {stats['http_requests']}")
    lines.append(f"TLS Connections: {stats['tls_connections']}")
    lines.append("")
    
    lines.append("TOP SOURCE IPs")
    lines.append("-" * 80)
    for i, ip_data in enumerate(stats["top_source_ips"][:10], 1):
        # Handle both old format (tuple) and new format (tuple with protocol/port)
        if len(ip_data) == 4:
            src_ip, count, protocol, port = ip_data
            lines.append(f"{i:2}. {src_ip}: {count} alerts (Protocol: {protocol}, Port: {port})")
        else:
            src_ip, count = ip_data[:2]
            lines.append(f"{i:2}. {src_ip}: {count} alerts")
    lines.append("")
    
    lines.append("TOP DESTINATION IPs")
    lines.append("-" * 80)
    for i, ip_data in enumerate(stats["top_dest_ips"][:10], 1):
        # Handle both old format (tuple) and new format (tuple with protocol/port)
        if len(ip_data) == 4:
            dest_ip, count, protocol, port = ip_data
            lines.append(f"{i:2}. {dest_ip}: {count} alerts (Protocol: {protocol}, Port: {port})")
        else:
            dest_ip, count = ip_data[:2]
            lines.append(f"{i:2}. {dest_ip}: {count} alerts")
    lines.append("")
    
    lines.append("MOST TRIGGERED SIGNATURES")
    lines.append("-" * 80)
    for i, (sig_id, count, desc, severity) in enumerate(stats["top_signatures"][:10], 1):
        severity_label = "Critical" if severity >= 4 else "High" if severity >= 3 else "Medium" if severity >= 2 else "Low"
        lines.append(f"{i:2}. Signature {sig_id} [{severity_label}]: {desc[:60]}")
        lines.append(f"    Triggered {count} times")
    lines.append("")
    
    if stats['by_protocol']:
        lines.append("PROTOCOL DISTRIBUTION")
        lines.append("-" * 80)
        for protocol, count in sorted(stats["by_protocol"].items(), key=lambda x: x[1], reverse=True)[:8]:
            lines.append(f"  {protocol}: {count}")
        lines.append("")
    
    lines.append("=" * 80)
    lines.append(f"{ATHENA_NAME}")
    lines.append(f"Website: {ATHENA_WEBSITE}")
    lines.append(f"Support: {ATHENA_SUPPORT}")
    lines.append("")
    lines.append(f"This automated {report_type} report was generated on {datetime.now().strftime('%B %d, %Y at %I:%M %p UTC')}")
    lines.append("Do not reply to this email.")
    lines.append("=" * 80)
    
    return "\n".join(lines)

def send_email(recipients, subject, plain_body, html_body) -> bool:
    """Send the report email"""
    try:
        msg = EmailMessage()
        msg["Subject"] = subject
        msg["To"] = ", ".join(recipients)
        msg["From"] = formataddr((f"{ATHENA_NAME} Reports", SMTP_FROM))

        msg.set_content(plain_body)
        msg.add_alternative(html_body, subtype='html')

        if SMTP_USE_SSL:
            server = smtplib.SMTP_SSL(SMTP_HOST, SMTP_PORT, timeout=30)
        else:
            server = smtplib.SMTP(SMTP_HOST, SMTP_PORT, timeout=30)

        server.ehlo()
        if SMTP_USE_TLS and not SMTP_USE_SSL:
            server.starttls()
            server.ehlo()

        if SMTP_USERNAME and SMTP_PASSWORD:
            server.login(SMTP_USERNAME, SMTP_PASSWORD)

        server.send_message(msg)
        server.quit()
        log(f"Report sent successfully to {recipients}")
        return True

    except Exception as e:
        log(f"Error sending report email: {e}")
        return False

# === REPORT GENERATOR ===
def generate_report(report_type, time_from, time_to, recipients):
    """Generate and send the security report"""
    
    # Query aggregated statistics for current period
    log(f"Generating {report_type} report from {time_from} to {time_to}")
    aggregations = query_elasticsearch(time_from, time_to, max_severity=3)
    
    if not aggregations:
        log("No data found for the specified time range")
        return False
    
    # Analyze aggregated data
    stats = analyze_alerts(aggregations)
    
    if stats['total_alerts'] == 0:
        log("No alerts found for the specified time range")
        return False
    
    # Fetch previous period data for comparison
    log("Fetching previous period data for comparison...")
    prev_time_from, prev_time_to = calculate_previous_period(time_from, time_to, report_type)
    prev_aggregations = query_elasticsearch(prev_time_from, prev_time_to, max_severity=3)
    prev_stats = analyze_alerts(prev_aggregations) if prev_aggregations else {
        "total_alerts": 0,
        "by_severity": {"Critical": 0, "High": 0, "Medium": 0, "Low": 0}
    }
    
    # Calculate comparisons
    comparisons = {
        "total_alerts": {
            "current": stats['total_alerts'],
            "previous": prev_stats['total_alerts'],
            "change_pct": 0,
            "change_type": "no change"
        },
        "critical": {
            "current": stats['by_severity'].get('Critical', 0),
            "previous": prev_stats['by_severity'].get('Critical', 0),
            "change_pct": 0,
            "change_type": "no change"
        },
        "high": {
            "current": stats['by_severity'].get('High', 0),
            "previous": prev_stats['by_severity'].get('High', 0),
            "change_pct": 0,
            "change_type": "no change"
        },
        "medium": {
            "current": stats['by_severity'].get('Medium', 0),
            "previous": prev_stats['by_severity'].get('Medium', 0),
            "change_pct": 0,
            "change_type": "no change"
        }
    }
    
    # Calculate percentage changes
    for key in comparisons:
        current_val = comparisons[key]["current"]
        previous_val = comparisons[key]["previous"]
        pct_change, change_type = calculate_percentage_change(current_val, previous_val)
        comparisons[key]["change_pct"] = pct_change
        comparisons[key]["change_type"] = change_type
    
    # Add comparisons to stats
    stats['comparisons'] = comparisons
    stats['previous_period'] = {
        "from": prev_time_from,
        "to": prev_time_to
    }
    
    # Get AI analysis
    ai_analysis = get_ai_report_summary(stats, report_type, time_from, time_to)
    
    # Generate email
    subject = f"[{TENANT_NAME}] Athena SOC {report_type.title()} NIDS Report - {datetime.fromisoformat(time_from.replace('Z', '+00:00')).strftime('%b %d, %Y')}"
    
    html_body = build_html_report(report_type, time_from, time_to, stats, ai_analysis)
    plain_body = build_plain_report(report_type, time_from, time_to, stats, ai_analysis)
    
    # Send email
    return send_email(recipients, subject, plain_body, html_body)

# === MAIN ===
def main(args):
    """
    Usage: 
      python script.py daily
      python script.py weekly
      python script.py monthly
      python script.py custom 2025-10-01T00:00:00Z 2025-10-18T23:59:59Z
    """
    log("# Starting report generation")
    
    if len(args) < 2:
        log("Usage: script.py <daily|weekly|monthly|custom> [start_time] [end_time]")
        return
    
    report_type = args[1].lower()
    
    # Calculate time range
    now = datetime.now(datetime.UTC) if hasattr(datetime, 'UTC') else datetime.utcnow()
    
    if report_type == "daily":
        time_to = now.isoformat() + "Z"
        time_from = (now - timedelta(days=1)).isoformat() + "Z"
        recipients = SMTP_RECIPIENT
    elif report_type == "weekly":
        time_to = now.isoformat() + "Z"
        time_from = (now - timedelta(days=7)).isoformat() + "Z"
        recipients = SMTP_RECIPIENT
    elif report_type == "monthly":
        time_to = now.isoformat() + "Z"
        time_from = (now - timedelta(days=30)).isoformat() + "Z"
        recipients = SMTP_RECIPIENT
    elif report_type == "custom":
        if len(args) < 5:
            log("Custom report requires: script.py custom <start_time> <end_time>")
            return
        recipients = SMTP_RECIPIENT
        time_from = args[3]
        time_to = args[4]
    else:
        log(f"Unknown report type: {report_type}")
        return
    
    log(f"Generating {report_type} report from {time_from} to {time_to}")
    log(f"Recipients: {recipients}")
    
    try:
        generate_report(report_type, time_from, time_to, recipients)
        log("Report generation completed successfully")
    except Exception as e:
        log(f"Error generating report: {e}")
        import traceback
        log(traceback.format_exc())

if __name__ == "__main__":
    try:
        main(sys.argv)
    except Exception as e:
        log(f"Unhandled exception: {e}")
        import traceback
        log(traceback.format_exc())
        raise
