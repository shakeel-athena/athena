#!/bin/bash
# Athena Reports Installation Script
# Sets up cron jobs to run SIEM, Suricata, and Compliance reports
# Supports granular control over existing cron jobs

set -e

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
CYAN='\033[0;36m'
BOLD='\033[1m'
NC='\033[0m' # No Color

# Module flags - which modules to install
INSTALL_SIEM=false
INSTALL_SURICATA=false
INSTALL_COMPLIANCE=false

echo ""
echo -e "${GREEN}${BOLD}╔══════════════════════════════════════════════════════════════╗${NC}"
echo -e "${GREEN}${BOLD}║          Athena Reports Installation Wizard                  ║${NC}"
echo -e "${GREEN}${BOLD}║     SIEM • Suricata (NIDS) • Compliance Reporting            ║${NC}"
echo -e "${GREEN}${BOLD}╚══════════════════════════════════════════════════════════════╝${NC}"
echo ""

# Get the directory where the script is located
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPORTS_DIR="$SCRIPT_DIR"

# Detect Python interpreter
PYTHON=$(which python3 || which python)
if [ -z "$PYTHON" ]; then
    echo -e "  ${RED}✗ Error: Python 3 not found${NC}"
    exit 1
fi
echo -e "  ${GREEN}✓${NC} Using system Python: $PYTHON"

# Check Python version
PYTHON_VERSION=$($PYTHON --version 2>&1)
echo -e "  ${GREEN}✓${NC} Python version: $PYTHON_VERSION"

# Check for required Python packages
echo ""
echo -e "${CYAN}[2/5] Checking Python dependencies...${NC}"
$PYTHON -c "import dotenv" 2>/dev/null || {
    echo -e "  ${YELLOW}⚠${NC} python-dotenv not found. Installing..."
    $PYTHON -m pip install python-dotenv --quiet
}

$PYTHON -c "import requests" 2>/dev/null || {
    echo -e "  ${YELLOW}⚠${NC} requests not found. Installing..."
    $PYTHON -m pip install requests --quiet
}

echo -e "  ${GREEN}✓${NC} All Python dependencies available"

# Check which report scripts exist
echo ""
echo -e "${CYAN}[3/5] Checking available report modules...${NC}"

SIEM_AVAILABLE=false
SURICATA_AVAILABLE=false
COMPLIANCE_AVAILABLE=false

if [ -f "$REPORTS_DIR/reports_siem.py" ]; then
    SIEM_AVAILABLE=true
    echo -e "  ${GREEN}✓${NC} SIEM module found: reports_siem.py"
else
    echo -e "  ${YELLOW}⚠${NC} SIEM module not found: reports_siem.py"
fi

if [ -f "$REPORTS_DIR/reports_suricata.py" ]; then
    SURICATA_AVAILABLE=true
    echo -e "  ${GREEN}✓${NC} Suricata (NIDS) module found: reports_suricata.py"
else
    echo -e "  ${YELLOW}⚠${NC} Suricata (NIDS) module not found: reports_suricata.py"
fi

if [ -f "$REPORTS_DIR/reports_compliance.py" ]; then
    COMPLIANCE_AVAILABLE=true
    echo -e "  ${GREEN}✓${NC} Compliance module found: reports_compliance.py"
else
    echo -e "  ${YELLOW}⚠${NC} Compliance module not found: reports_compliance.py"
fi

# Check if at least one module is available
if [ "$SIEM_AVAILABLE" = false ] && [ "$SURICATA_AVAILABLE" = false ] && [ "$COMPLIANCE_AVAILABLE" = false ]; then
    echo -e "${RED}Error: No report modules found in $REPORTS_DIR${NC}"
    exit 1
fi

# Make available report scripts executable
echo ""
echo -e "${CYAN}[4/5] Setting up report modules...${NC}"

# Create log directory
mkdir -p "$REPORTS_DIR/logs"
touch "$REPORTS_DIR/logs/reporting.log"
echo -e "  ${GREEN}✓${NC} Log directory created"

# Check if .env file exists
if [ ! -f "$REPORTS_DIR/.env" ]; then
    echo -e "  ${YELLOW}⚠${NC} Warning: .env file not found. Please create one with required configuration."
fi

# Backup existing crontab
echo ""
echo -e "${CYAN}[5/5] Configuring cron jobs...${NC}"
CRON_BACKUP="/tmp/crontab_backup_$(date +%Y%m%d_%H%M%S)"
crontab -l 2>/dev/null > "$CRON_BACKUP" || true
echo -e "  ${GREEN}✓${NC} Backed up existing crontab to: $CRON_BACKUP"

# Get current crontab
CURRENT_CRON=$(crontab -l 2>/dev/null || echo "")

# Check for existing Athena cron jobs
SIEM_EXISTS=false
SURICATA_EXISTS=false
COMPLIANCE_EXISTS=false

if echo "$CURRENT_CRON" | grep -q "reports_siem.py"; then
    SIEM_EXISTS=true
fi
if echo "$CURRENT_CRON" | grep -q "reports_suricata.py"; then
    SURICATA_EXISTS=true
fi
if echo "$CURRENT_CRON" | grep -q "reports_compliance.py"; then
    COMPLIANCE_EXISTS=true
fi

# Display existing cron jobs status
echo ""
echo -e "${BOLD}Current Athena cron job status:${NC}"
echo -e "  ┌─────────────────────────────────────────────────────────────┐"
if [ "$SIEM_EXISTS" = true ]; then
    echo -e "  │  ${GREEN}●${NC} SIEM Reports              ${GREEN}[INSTALLED]${NC}                   │"
else
    echo -e "  │  ${RED}○${NC} SIEM Reports              ${RED}[NOT INSTALLED]${NC}               │"
fi
if [ "$SURICATA_EXISTS" = true ]; then
    echo -e "  │  ${GREEN}●${NC} Suricata (NIDS) Reports   ${GREEN}[INSTALLED]${NC}                   │"
else
    echo -e "  │  ${RED}○${NC} Suricata (NIDS) Reports   ${RED}[NOT INSTALLED]${NC}               │"
fi
if [ "$COMPLIANCE_EXISTS" = true ]; then
    echo -e "  │  ${GREEN}●${NC} Compliance Reports        ${GREEN}[INSTALLED]${NC}                   │"
else
    echo -e "  │  ${RED}○${NC} Compliance Reports        ${RED}[NOT INSTALLED]${NC}               │"
fi
echo -e "  └─────────────────────────────────────────────────────────────┘"
echo ""

# Function to prompt for module installation
prompt_module() {
    local module_name=$1
    local exists=$2
    local available=$3
    local var_name=$4
    
    if [ "$available" = false ]; then
        echo -e "  ${YELLOW}⚠${NC} $module_name module not available (script not found)"
        return 1
    fi
    
    if [ "$exists" = true ]; then
        echo -e "${YELLOW}$module_name cron jobs already exist.${NC}"
        echo "  [K] Keep existing (don't modify)"
        echo "  [R] Replace/Reinstall"
        echo "  [D] Delete (remove cron jobs)"
        read -p "  Your choice [K/R/D]: " -n 1 -r choice
        echo ""
        case $choice in
            [Rr])
                eval "$var_name=true"
                return 0
                ;;
            [Dd])
                eval "$var_name=delete"
                return 0
                ;;
            *)
                eval "$var_name=keep"
                return 0
                ;;
        esac
    else
        read -p "Install $module_name cron jobs? (Y/n): " -n 1 -r choice
        echo ""
        if [[ ! $choice =~ ^[Nn]$ ]]; then
            eval "$var_name=true"
            return 0
        fi
    fi
    return 1
}

echo -e "${BOLD}Configure each module:${NC}"
echo ""

# Prompt for SIEM module
echo -e "${BLUE}━━━ SIEM Reports ━━━${NC}"
prompt_module "SIEM" "$SIEM_EXISTS" "$SIEM_AVAILABLE" "INSTALL_SIEM"
echo ""

# Prompt for Suricata module
echo -e "${BLUE}━━━ Suricata (NIDS) Reports ━━━${NC}"
prompt_module "Suricata (NIDS)" "$SURICATA_EXISTS" "$SURICATA_AVAILABLE" "INSTALL_SURICATA"
echo ""

# Prompt for Compliance module
echo -e "${BLUE}━━━ Compliance Reports ━━━${NC}"
prompt_module "Compliance" "$COMPLIANCE_EXISTS" "$COMPLIANCE_AVAILABLE" "INSTALL_COMPLIANCE"
echo ""

# Process cron job changes
echo -e "${CYAN}Processing cron job changes...${NC}"

# Start with current cron, removing Athena-related entries as needed
NEW_CRON="$CURRENT_CRON"

# Remove SIEM entries if replacing or deleting
if [ "$INSTALL_SIEM" = "true" ] || [ "$INSTALL_SIEM" = "delete" ]; then
    NEW_CRON=$(echo "$NEW_CRON" | grep -v "reports_siem.py" || echo "$NEW_CRON")
fi

# Remove Suricata entries if replacing or deleting
if [ "$INSTALL_SURICATA" = "true" ] || [ "$INSTALL_SURICATA" = "delete" ]; then
    NEW_CRON=$(echo "$NEW_CRON" | grep -v "reports_suricata.py" || echo "$NEW_CRON")
fi

# Remove Compliance entries if replacing or deleting
if [ "$INSTALL_COMPLIANCE" = "true" ] || [ "$INSTALL_COMPLIANCE" = "delete" ]; then
    NEW_CRON=$(echo "$NEW_CRON" | grep -v "reports_compliance.py" || echo "$NEW_CRON")
fi

# Remove old Athena header comments if we're modifying anything
if [ "$INSTALL_SIEM" = "true" ] || [ "$INSTALL_SURICATA" = "true" ] || [ "$INSTALL_COMPLIANCE" = "true" ]; then
    NEW_CRON=$(echo "$NEW_CRON" | grep -v "# Athena Reports" | grep -v "# Daily —" | grep -v "# Weekly —" | grep -v "# Monthly —" || echo "$NEW_CRON")
fi

# Build new cron entries
CRON_ADDITIONS=""

# Check if any modules are being installed (not kept or deleted)
INSTALLING_ANY=false
if [ "$INSTALL_SIEM" = "true" ] || [ "$INSTALL_SURICATA" = "true" ] || [ "$INSTALL_COMPLIANCE" = "true" ]; then
    INSTALLING_ANY=true
fi

if [ "$INSTALLING_ANY" = true ]; then
    CRON_ADDITIONS="
# ═══════════════════════════════════════════════════════════════
# Athena Reports - Automated Security Reporting
# Installed: $(date '+%Y-%m-%d %H:%M:%S')
# ═══════════════════════════════════════════════════════════════
SHELL=/bin/bash
PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin
TZ=America/New_York
"
    
    # Build daily cron line
    DAILY_CMD=""
    if [ "$INSTALL_SIEM" = "true" ]; then
        DAILY_CMD="cd $REPORTS_DIR && nice -n 10 $PYTHON reports_siem.py daily >> /var/log/athena-reporter.log 2>&1"
    fi
    if [ "$INSTALL_SURICATA" = "true" ]; then
        if [ -n "$DAILY_CMD" ]; then
            DAILY_CMD="$DAILY_CMD && cd $REPORTS_DIR && nice -n 10 $PYTHON reports_suricata.py daily >> /var/log/athena-reporter.log 2>&1"
        else
            DAILY_CMD="cd $REPORTS_DIR && nice -n 10 $PYTHON reports_suricata.py daily >> /var/log/athena-reporter.log 2>&1"
        fi
    fi
    if [ "$INSTALL_COMPLIANCE" = "true" ]; then
        if [ -n "$DAILY_CMD" ]; then
            DAILY_CMD="$DAILY_CMD && cd $REPORTS_DIR && nice -n 10 $PYTHON reports_compliance.py daily >> /var/log/athena-reporter.log 2>&1"
        else
            DAILY_CMD="cd $REPORTS_DIR && nice -n 10 $PYTHON reports_compliance.py daily >> /var/log/athena-reporter.log 2>&1"
        fi
    fi
    
    # Build weekly cron line
    WEEKLY_CMD=""
    if [ "$INSTALL_SIEM" = "true" ]; then
        WEEKLY_CMD="cd $REPORTS_DIR && nice -n 10 $PYTHON reports_siem.py weekly >> /var/log/athena-reporter.log 2>&1"
    fi
    if [ "$INSTALL_SURICATA" = "true" ]; then
        if [ -n "$WEEKLY_CMD" ]; then
            WEEKLY_CMD="$WEEKLY_CMD && cd $REPORTS_DIR && nice -n 10 $PYTHON reports_suricata.py weekly >> /var/log/athena-reporter.log 2>&1"
        else
            WEEKLY_CMD="cd $REPORTS_DIR && nice -n 10 $PYTHON reports_suricata.py weekly >> /var/log/athena-reporter.log 2>&1"
        fi
    fi
    if [ "$INSTALL_COMPLIANCE" = "true" ]; then
        if [ -n "$WEEKLY_CMD" ]; then
            WEEKLY_CMD="$WEEKLY_CMD && cd $REPORTS_DIR && nice -n 10 $PYTHON reports_compliance.py weekly >> /var/log/athena-reporter.log 2>&1"
        else
            WEEKLY_CMD="cd $REPORTS_DIR && nice -n 10 $PYTHON reports_compliance.py weekly >> /var/log/athena-reporter.log 2>&1"
        fi
    fi
    
    # Build monthly cron line
    MONTHLY_CMD=""
    if [ "$INSTALL_SIEM" = "true" ]; then
        MONTHLY_CMD="cd $REPORTS_DIR && nice -n 10 $PYTHON reports_siem.py monthly >> /var/log/athena-reporter.log 2>&1"
    fi
    if [ "$INSTALL_SURICATA" = "true" ]; then
        if [ -n "$MONTHLY_CMD" ]; then
            MONTHLY_CMD="$MONTHLY_CMD && cd $REPORTS_DIR && nice -n 10 $PYTHON reports_suricata.py monthly >> /var/log/athena-reporter.log 2>&1"
        else
            MONTHLY_CMD="cd $REPORTS_DIR && nice -n 10 $PYTHON reports_suricata.py monthly >> /var/log/athena-reporter.log 2>&1"
        fi
    fi
    if [ "$INSTALL_COMPLIANCE" = "true" ]; then
        if [ -n "$MONTHLY_CMD" ]; then
            MONTHLY_CMD="$MONTHLY_CMD && cd $REPORTS_DIR && nice -n 10 $PYTHON reports_compliance.py monthly >> /var/log/athena-reporter.log 2>&1"
        else
            MONTHLY_CMD="cd $REPORTS_DIR && nice -n 10 $PYTHON reports_compliance.py monthly >> /var/log/athena-reporter.log 2>&1"
        fi
    fi
    
    # Add cron lines if commands exist
    if [ -n "$DAILY_CMD" ]; then
        CRON_ADDITIONS="$CRON_ADDITIONS
# Daily — 09:00 ET (Last 24 hours)
0 9 * * * $DAILY_CMD
"
    fi
    
    if [ -n "$WEEKLY_CMD" ]; then
        CRON_ADDITIONS="$CRON_ADDITIONS
# Weekly — Fridays 18:00 ET (Last 7 days)
0 18 * * 5 $WEEKLY_CMD
"
    fi
    
    if [ -n "$MONTHLY_CMD" ]; then
        CRON_ADDITIONS="$CRON_ADDITIONS
# Monthly — Day 30 at 09:00 ET (Last 30 days)
0 9 30 * * $MONTHLY_CMD
"
    fi
fi

# Apply the new crontab
echo "$NEW_CRON$CRON_ADDITIONS" | crontab -

# Create log file if it doesn't exist
sudo touch /var/log/athena-reporter.log 2>/dev/null || touch "$REPORTS_DIR/logs/athena-reporter.log"
sudo chmod 666 /var/log/athena-reporter.log 2>/dev/null || chmod 666 "$REPORTS_DIR/logs/athena-reporter.log" 2>/dev/null

# Summary
echo ""
echo -e "${GREEN}${BOLD}╔══════════════════════════════════════════════════════════════╗${NC}"
echo -e "${GREEN}${BOLD}║              Installation Complete!                          ║${NC}"
echo -e "${GREEN}${BOLD}╚══════════════════════════════════════════════════════════════╝${NC}"
echo ""

echo -e "${BOLD}Module Status:${NC}"
echo -e "  ┌─────────────────────────────────────────────────────────────┐"

# SIEM status
if [ "$INSTALL_SIEM" = "true" ]; then
    echo -e "  │  ${GREEN}✓${NC} SIEM Reports              ${GREEN}[INSTALLED]${NC}                   │"
elif [ "$INSTALL_SIEM" = "delete" ]; then
    echo -e "  │  ${RED}✗${NC} SIEM Reports              ${RED}[REMOVED]${NC}                     │"
elif [ "$INSTALL_SIEM" = "keep" ]; then
    echo -e "  │  ${BLUE}●${NC} SIEM Reports              ${BLUE}[KEPT EXISTING]${NC}               │"
elif [ "$SIEM_EXISTS" = true ]; then
    echo -e "  │  ${BLUE}●${NC} SIEM Reports              ${BLUE}[EXISTING - UNCHANGED]${NC}        │"
else
    echo -e "  │  ${YELLOW}○${NC} SIEM Reports              ${YELLOW}[NOT INSTALLED]${NC}               │"
fi

# Suricata status
if [ "$INSTALL_SURICATA" = "true" ]; then
    echo -e "  │  ${GREEN}✓${NC} Suricata (NIDS) Reports   ${GREEN}[INSTALLED]${NC}                   │"
elif [ "$INSTALL_SURICATA" = "delete" ]; then
    echo -e "  │  ${RED}✗${NC} Suricata (NIDS) Reports   ${RED}[REMOVED]${NC}                     │"
elif [ "$INSTALL_SURICATA" = "keep" ]; then
    echo -e "  │  ${BLUE}●${NC} Suricata (NIDS) Reports   ${BLUE}[KEPT EXISTING]${NC}               │"
elif [ "$SURICATA_EXISTS" = true ]; then
    echo -e "  │  ${BLUE}●${NC} Suricata (NIDS) Reports   ${BLUE}[EXISTING - UNCHANGED]${NC}        │"
else
    echo -e "  │  ${YELLOW}○${NC} Suricata (NIDS) Reports   ${YELLOW}[NOT INSTALLED]${NC}               │"
fi

# Compliance status
if [ "$INSTALL_COMPLIANCE" = "true" ]; then
    echo -e "  │  ${GREEN}✓${NC} Compliance Reports        ${GREEN}[INSTALLED]${NC}                   │"
elif [ "$INSTALL_COMPLIANCE" = "delete" ]; then
    echo -e "  │  ${RED}✗${NC} Compliance Reports        ${RED}[REMOVED]${NC}                     │"
elif [ "$INSTALL_COMPLIANCE" = "keep" ]; then
    echo -e "  │  ${BLUE}●${NC} Compliance Reports        ${BLUE}[KEPT EXISTING]${NC}               │"
elif [ "$COMPLIANCE_EXISTS" = true ]; then
    echo -e "  │  ${BLUE}●${NC} Compliance Reports        ${BLUE}[EXISTING - UNCHANGED]${NC}        │"
else
    echo -e "  │  ${YELLOW}○${NC} Compliance Reports        ${YELLOW}[NOT INSTALLED]${NC}               │"
fi

echo -e "  └─────────────────────────────────────────────────────────────┘"
echo ""

if [ "$INSTALLING_ANY" = true ]; then
    echo -e "${BOLD}Cron Schedule:${NC}"
    echo "  • Daily:   09:00 ET (Last 24 hours)"
    echo "  • Weekly:  Fridays 18:00 ET (Last 7 days)"
    echo "  • Monthly: Day 30 at 09:00 ET (Last 30 days)"
    echo ""
fi

echo -e "${BOLD}Script Locations:${NC}"
[ "$SIEM_AVAILABLE" = true ] && echo "  • SIEM:       $REPORTS_DIR/reports_siem.py"
[ "$SURICATA_AVAILABLE" = true ] && echo "  • Suricata:   $REPORTS_DIR/reports_suricata.py"
[ "$COMPLIANCE_AVAILABLE" = true ] && echo "  • Compliance: $REPORTS_DIR/reports_compliance.py"
echo "  • Python:     $PYTHON"
echo ""

echo -e "${BOLD}Useful Commands:${NC}"
echo "  View cron jobs:     crontab -l"
echo "  View logs:          tail -f /var/log/athena-reporter.log"
echo ""
echo -e "${BOLD}Manual Testing:${NC}"
[ "$SIEM_AVAILABLE" = true ] && echo "  cd $REPORTS_DIR && $PYTHON reports_siem.py daily"
[ "$SURICATA_AVAILABLE" = true ] && echo "  cd $REPORTS_DIR && $PYTHON reports_suricata.py daily"
[ "$COMPLIANCE_AVAILABLE" = true ] && echo "  cd $REPORTS_DIR && $PYTHON reports_compliance.py daily"
echo ""
echo -e "${BOLD}Crontab Backup:${NC} $CRON_BACKUP"
echo ""