#!/var/ossec/framework/python/bin/python3
# -*- coding: utf-8 -*-
"""
Athena SOC - Agent Status Report with Vulnerability Summary

This module generates a dedicated report listing all agents (or a defined subset) with:
- Status: active / inactive, last seen timestamp
- Vulnerability summary per agent: count of vulnerability-related alerts
  (from rule.groups: vulnerability, vulnerability-detector)
- Severity breakdown (Critical/High/Medium/Low from rule.level)
- Top affected rules and CVEs per agent

Reuses existing patterns: Elasticsearch queries, branding, HTML/plain email,
and dashboard links (buildAgentUrl, buildDashboardUrl).
"""

import sys
import time
import os
from datetime import datetime, timedelta, timezone
from html import escape as htmlEscape
from dotenv import load_dotenv

load_dotenv()

# Import shared utilities from reports_compliance
from reports_compliance import (
    ATHENA_NAME,
    TENANT_NAME,
    ATHENA_WEBSITE,
    ATHENA_DOCS,
    ATHENA_SUPPORT,
    DASHBOARD_BASE_URL,
    SMTP_HOST,
    SMTP_PORT,
    SMTP_USE_TLS,
    SMTP_USE_SSL,
    SMTP_USERNAME,
    SMTP_PASSWORD,
    SMTP_FROM,
    SMTP_RECIPIENT,
    ES_HOST,
    ES_USERNAME,
    ES_PASSWORD,
    ES_INDEX_PATTERN,
    ES_VERIFY_SSL,
    log,
    getColorScheme,
    buildDashboardUrl,
    buildAgentUrl,
    sendEmail,
)

# === AGENT REPORT CONFIGURATION ===
AGENT_REPORT_TOP_CVES = int(os.getenv("AGENT_REPORT_TOP_CVES", "5"))
AGENT_REPORT_TOP_RULES = int(os.getenv("AGENT_REPORT_TOP_RULES", "5"))
AGENT_REPORT_INACTIVE_THRESHOLD_HOURS = int(os.getenv("AGENT_REPORT_INACTIVE_THRESHOLD_HOURS", "24"))


# === ELASTICSEARCH QUERIES ===
def queryAllAgentsWithStatus():
    """Query Elasticsearch for all agents with last activity timestamp (for status determination)"""
    try:
        import requests
        from requests.auth import HTTPBasicAuth
        import urllib3

        if not ES_VERIFY_SSL:
            urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

        query = {
            "size": 0,
            "aggs": {
                "allAgents": {
                    "terms": {"field": "agent.name", "size": 1000},
                    "aggs": {
                        "agentId": {"terms": {"field": "agent.id", "size": 1}},
                        "lastSeen": {"max": {"field": "timestamp"}},
                        "hostOs": {"terms": {"field": "agent.os.name", "size": 1}},
                        "hostOsPlatform": {"terms": {"field": "agent.os.platform", "size": 1}},
                        "hostOsFull": {"terms": {"field": "agent.os.full", "size": 1}},
                        "hostOsType": {"terms": {"field": "host.os.type", "size": 1}},
                        "hostOsName": {"terms": {"field": "host.os.name", "size": 1}},
                        "hostOsFamily": {"terms": {"field": "host.os.family", "size": 1}},
                        "sysCheckOs": {"terms": {"field": "syscheck.uname_after", "size": 1}},
                    },
                }
            },
        }

        log("Querying all agents for status report...")

        response = requests.post(
            f"{ES_HOST}/{ES_INDEX_PATTERN}/_search",
            json=query,
            auth=HTTPBasicAuth(ES_USERNAME, ES_PASSWORD),
            verify=ES_VERIFY_SSL,
            timeout=60,
        )

        if response.status_code == 200:
            data = response.json()
            aggregations = data.get("aggregations", {})
            log(f"Retrieved all agents data ({len(aggregations.get('allAgents', {}).get('buckets', []))} agents)")
            return aggregations
        else:
            log(f"All agents query failed: {response.status_code} - {response.text}")
            return {}

    except Exception as e:
        log(f"Error querying all agents: {e}")
        return {}


def queryVulnerabilityByAgent(timeFrom, timeTo, agentNames=None):
    """
    Query vulnerability alerts (rule.groups: vulnerability, vulnerability-detector) grouped by agent.
    Returns per-agent: total count, severity breakdown (rule.level), top rules, top CVEs.
    agentNames: optional list to filter specific agents only.
    """
    try:
        import requests
        from requests.auth import HTTPBasicAuth
        import urllib3

        if not ES_VERIFY_SSL:
            urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

        must_clauses = [
            {
                "range": {
                    "timestamp": {
                        "gte": timeFrom,
                        "lte": timeTo,
                        "format": "strict_date_optional_time",
                    }
                }
            },
            {"terms": {"rule.groups": ["vulnerability", "vulnerability-detector"]}},
        ]
        if agentNames:
            must_clauses.append({"terms": {"agent.name": agentNames}})

        aggs = {
            "byAgent": {
                "terms": {"field": "agent.name", "size": 1000},
                "aggs": {
                    "totalVulnAlerts": {"value_count": {"field": "rule.id"}},
                    "severityByVulnField": {
                        "terms": {"field": "data.vulnerability.severity", "size": 5}
                    },
                    "topRules": {
                        "terms": {"field": "rule.id", "size": AGENT_REPORT_TOP_RULES},
                        "aggs": {
                            "ruleDesc": {"terms": {"field": "rule.description", "size": 1}}
                        },
                    },
                    "topCvesFiltered": {
                        "filter": {
                            "terms": {"data.vulnerability.severity": ["Critical", "High", "Medium"]}
                        },
                        "aggs": {
                            "topCves": {
                                "terms": {"field": "data.vulnerability.cve", "size": 10},
                                "aggs": {
                                    "cveSeverity": {"terms": {"field": "data.vulnerability.severity", "size": 1}},
                                },
                            }
                        },
                    },
                },
            }
        }

        query = {
            "size": 0,
            "query": {"bool": {"must": must_clauses}},
            "aggs": aggs,
        }

        log("Querying vulnerability data by agent...")

        response = requests.post(
            f"{ES_HOST}/{ES_INDEX_PATTERN}/_search",
            json=query,
            auth=HTTPBasicAuth(ES_USERNAME, ES_PASSWORD),
            verify=ES_VERIFY_SSL,
            timeout=60,
        )

        if response.status_code == 200:
            data = response.json()
            agg = data.get("aggregations", {})
            log("Retrieved vulnerability-by-agent data")
            return agg
        else:
            log(f"Vulnerability-by-agent query failed: {response.status_code} - {response.text}")
            return {}

    except Exception as e:
        log(f"Error querying vulnerability by agent: {e}")
        return {}


def queryAlertsByAgent(timeFrom, timeTo, agentNames=None):
    """
    Query all alerts (wazuh-alerts) grouped by agent for Top Active Agents.
    Returns per-agent: total alert count and severity breakdown (rule.level).
    agentNames: optional list to filter specific agents only.
    """
    try:
        import requests
        from requests.auth import HTTPBasicAuth
        import urllib3

        if not ES_VERIFY_SSL:
            urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

        must_clauses = [
            {
                "range": {
                    "timestamp": {
                        "gte": timeFrom,
                        "lte": timeTo,
                        "format": "strict_date_optional_time",
                    }
                }
            },
        ]
        if agentNames:
            must_clauses.append({"terms": {"agent.name": agentNames}})

        query = {
            "size": 0,
            "query": {"bool": {"must": must_clauses}},
            "aggs": {
                "byAgent": {
                    "terms": {"field": "agent.name", "size": 1000},
                    "aggs": {
                        "totalAlerts": {"value_count": {"field": "rule.id"}},
                        "severityByRuleLevel": {
                            "terms": {
                                "script": {
                                    "source": """
                                        def level = doc['rule.level'].value;
                                        if (level >= 15) return 'Critical';
                                        else if (level >= 12) return 'High';
                                        else if (level >= 7) return 'Medium';
                                        else return 'Low';
                                    """
                                },
                                "size": 4,
                            }
                        },
                    },
                }
            },
        }

        log("Querying alerts by agent for Top Active Agents...")
        response = requests.post(
            f"{ES_HOST}/{ES_INDEX_PATTERN}/_search",
            json=query,
            auth=HTTPBasicAuth(ES_USERNAME, ES_PASSWORD),
            verify=ES_VERIFY_SSL,
            timeout=60,
        )

        if response.status_code == 200:
            data = response.json()
            agg = data.get("aggregations", {})
            log("Retrieved alerts-by-agent data")
            return agg
        else:
            log(f"Alerts-by-agent query failed: {response.status_code} - {response.text}")
            return {}
    except Exception as e:
        log(f"Error querying alerts by agent: {e}")
        return {}


# === DATA PROCESSING ===
def _resolveHostOs(bucket):
    """Extract host OS from bucket using multiple fallback fields"""
    for key in ["hostOs", "hostOsFull", "hostOsPlatform", "hostOsName", "hostOsType", "hostOsFamily"]:
        buckets = bucket.get(key, {}).get("buckets", [])
        if buckets:
            val = buckets[0].get("key", "")
            if val:
                return str(val)
    # Fallback: syscheck.uname_after
    buckets = bucket.get("sysCheckOs", {}).get("buckets", [])
    if buckets:
        uname = str(buckets[0].get("key", "")).lower()
        if "linux" in uname:
            return "Linux"
        if "darwin" in uname or "macos" in uname:
            return "macOS"
        if "windows" in uname:
            return "Windows"
        return str(buckets[0].get("key", ""))[:50] if uname else "Unknown"
    return "Unknown"


def processAllAgentsWithStatus(aggregations, inactiveThresholdHours=24, agentSubset=None):
    """
    Process all agents with status (active/inactive) and last seen.
    Inactive agents get category grouping matching the compliance report style:
    - Inactive 24+ hours (24-72h), Inactive 3+ days (72-168h), Abandoned (168h+)
    Agents inactive >14 days are excluded from the report.
    agentSubset: optional list of agent names to include; None = all agents.
    """
    activeAgents = []
    inactiveAgents = []
    now = datetime.now(timezone.utc)
    thresholdTime = now - timedelta(hours=inactiveThresholdHours)

    agentBuckets = aggregations.get("allAgents", {}).get("buckets", [])
    for bucket in agentBuckets:
        agentName = bucket.get("key", "Unknown")
        if agentSubset and agentName not in agentSubset:
            continue

        agentIdBuckets = bucket.get("agentId", {}).get("buckets", [])
        agentId = agentIdBuckets[0].get("key", "N/A") if agentIdBuckets else "N/A"

        lastSeenMs = bucket.get("lastSeen", {}).get("value")
        if not lastSeenMs:
            continue
        lastSeenDt = datetime.fromtimestamp(lastSeenMs / 1000, tz=timezone.utc)
        hoursSinceLastSeen = int((now - lastSeenDt).total_seconds() / 3600)
        hostOs = _resolveHostOs(bucket)

        if hoursSinceLastSeen > 336:  # Exclude agents inactive >14 days
            continue

        entry = {
            "name": agentName,
            "id": agentId,
            "lastSeen": lastSeenDt.isoformat().replace("+00:00", "Z"),
            "lastSeenFormatted": lastSeenDt.strftime("%Y-%m-%d %H:%M UTC"),
            "hostOs": hostOs,
            "hoursSinceLastSeen": hoursSinceLastSeen,
        }

        if lastSeenDt >= thresholdTime:
            entry["status"] = "active"
            activeAgents.append(entry)
        else:
            entry["status"] = "inactive"
            if hoursSinceLastSeen >= 168:
                entry["category"] = "Abandoned"
                entry["categoryPriority"] = 3
                entry["categoryDescription"] = "No heartbeat for 7+ days(Covers 14+ days inactive agents)"
            elif hoursSinceLastSeen >= 72:
                entry["category"] = "Inactive 3+ days"
                entry["categoryPriority"] = 2
                entry["categoryDescription"] = "No heartbeat for 3-7 days"
            else:
                entry["category"] = "Inactive 24+ hours"
                entry["categoryPriority"] = 1
                entry["categoryDescription"] = "No heartbeat for 24-72 hours"
            inactiveAgents.append(entry)

    activeAgents.sort(key=lambda a: a["hoursSinceLastSeen"])
    inactiveAgents.sort(key=lambda a: (a["categoryPriority"], -a["hoursSinceLastSeen"]))

    return activeAgents, inactiveAgents


def queryVulnerabilityOverview(timeFrom, timeTo):
    """Query global vulnerability statistics: total alerts, severity distribution, top CVEs, top packages"""
    try:
        import requests
        from requests.auth import HTTPBasicAuth
        import urllib3

        if not ES_VERIFY_SSL:
            urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

        query = {
            "size": 0,
            "query": {
                "bool": {
                    "must": [
                        {"range": {"timestamp": {"gte": timeFrom, "lte": timeTo, "format": "strict_date_optional_time"}}},
                        {"terms": {"rule.groups": ["vulnerability", "vulnerability-detector"]}},
                    ]
                }
            },
            "aggs": {
                "totalVulnAlerts": {"value_count": {"field": "rule.id"}},
                "uniqueCves": {"cardinality": {"field": "data.vulnerability.cve"}},
                "uniqueAgents": {"cardinality": {"field": "agent.name"}},
                "severityByLevel": {
                    "terms": {"field": "data.vulnerability.severity", "size": 5}
                },
                "topCvesMediumHighCritical": {
                    "filter": {
                        "terms": {"data.vulnerability.severity": ["Critical", "High", "Medium"]}
                    },
                    "aggs": {
                        "topCves": {
                            "terms": {"field": "data.vulnerability.cve", "size": 10},
                            "aggs": {
                                "cveSeverity": {"terms": {"field": "data.vulnerability.severity", "size": 1}},
                                "cveScore": {"terms": {"field": "data.vulnerability.score.base", "size": 1}},
                                "affectedAgents": {"cardinality": {"field": "agent.name"}},
                            },
                        }
                    },
                },
                "topPackages": {
                    "terms": {"field": "data.vulnerability.package.name", "size": 5},
                    "aggs": {
                        "severityBreakdown": {"terms": {"field": "data.vulnerability.severity", "size": 5}},
                    },
                },
                "vulnStatus": {"terms": {"field": "data.vulnerability.status", "size": 5}},
            },
        }

        log("Querying global vulnerability overview...")
        response = requests.post(
            f"{ES_HOST}/{ES_INDEX_PATTERN}/_search",
            json=query,
            auth=HTTPBasicAuth(ES_USERNAME, ES_PASSWORD),
            verify=ES_VERIFY_SSL,
            timeout=60,
        )

        if response.status_code == 200:
            data = response.json()
            agg = data.get("aggregations", {})
            log("Retrieved global vulnerability overview")
            return agg
        else:
            log(f"Vulnerability overview query failed: {response.status_code}")
            return {}
    except Exception as e:
        log(f"Error querying vulnerability overview: {e}")
        return {}


def processVulnerabilityOverview(aggregations):
    """Process global vulnerability overview aggregations.
    Top CVEs are filtered to only Medium, High, Critical (exclude Low)."""
    if not aggregations:
        return {}

    severity = {}
    for b in aggregations.get("severityByLevel", {}).get("buckets", []):
        severity[b["key"]] = b["doc_count"]

    topCvesBuckets = aggregations.get("topCvesMediumHighCritical", {}).get("topCves", {}).get("buckets", [])
    topCves = []
    for b in topCvesBuckets:
        sevBuckets = b.get("cveSeverity", {}).get("buckets", [])
        scoreBuckets = b.get("cveScore", {}).get("buckets", [])
        sev = sevBuckets[0]["key"] if sevBuckets else None
        if sev not in ("High", "Medium", "Critical"):
            continue
        topCves.append({
            "cve": b["key"],
            "count": b["doc_count"],
            "severity": sev,
            "score": scoreBuckets[0]["key"] if scoreBuckets else "N/A",
            "affectedAgents": b.get("affectedAgents", {}).get("value", 0),
        })
    # Sort: count desc first, then criticality (Critical > High > Medium)
    _sev_order = {"Critical": 0, "High": 1, "Medium": 2}
    topCves.sort(key=lambda x: (-x["count"], _sev_order.get(x["severity"] or "", 99)))

    topPackages = []
    for b in aggregations.get("topPackages", {}).get("buckets", []):
        sevBreak = {}
        for sb in b.get("severityBreakdown", {}).get("buckets", []):
            sevBreak[sb["key"]] = sb["doc_count"]
        topPackages.append({"package": b["key"], "count": b["doc_count"], "severityBreakdown": sevBreak})

    return {
        "totalVulnAlerts": aggregations.get("totalVulnAlerts", {}).get("value", 0),
        "uniqueCves": aggregations.get("uniqueCves", {}).get("value", 0),
        "uniqueAgents": aggregations.get("uniqueAgents", {}).get("value", 0),
        "severity": severity,
        "topCves": topCves,
        "topPackages": topPackages,
    }


def processVulnerabilityByAgent(aggregations):
    """Process vulnerability aggregations into per-agent vulnerability summaries.
    Uses data.vulnerability.severity for both severity breakdown and CVE severity."""
    result = {}
    _sev_order = {"Critical": 0, "High": 1, "Medium": 2}
    byAgent = aggregations.get("byAgent", {}).get("buckets", [])
    for bucket in byAgent:
        agentName = bucket.get("key", "Unknown")
        total = bucket.get("totalVulnAlerts", {}).get("value", bucket.get("doc_count", 0))

        severityBreakdown = {}
        for sb in bucket.get("severityByVulnField", {}).get("buckets", []):
            severityBreakdown[sb["key"]] = sb["doc_count"]

        topRules = []
        for rb in bucket.get("topRules", {}).get("buckets", []):
            ruleId = rb.get("key", "N/A")
            descBuckets = rb.get("ruleDesc", {}).get("buckets", [])
            desc = descBuckets[0].get("key", ruleId) if descBuckets else ruleId
            topRules.append({"ruleId": ruleId, "description": desc, "count": rb["doc_count"]})

        topCves = []
        for cb in bucket.get("topCvesFiltered", {}).get("topCves", {}).get("buckets", []):
            cve = cb.get("key", "N/A")
            sevBuckets = cb.get("cveSeverity", {}).get("buckets", [])
            severity = sevBuckets[0].get("key", "N/A") if sevBuckets else "N/A"
            if severity not in ("High", "Medium", "Critical"):
                continue
            topCves.append({"cve": cve, "severity": severity, "count": cb["doc_count"]})
        # Sort: count desc first, then criticality (Critical > High > Medium)
        topCves.sort(key=lambda x: (-x["count"], _sev_order.get(x["severity"], 99)))

        result[agentName] = {
            "totalVulnAlerts": total,
            "severityBreakdown": severityBreakdown,
            "topRules": topRules,
            "topCves": topCves,
        }
    return result


def processAlertsByAgent(aggregations):
    """Process alerts aggregations into per-agent total alerts and severity breakdown (for Top Active Agents)"""
    result = {}
    byAgent = aggregations.get("byAgent", {}).get("buckets", [])
    for bucket in byAgent:
        agentName = bucket.get("key", "Unknown")
        total = bucket.get("totalAlerts", {}).get("value", bucket.get("doc_count", 0))
        severityBreakdown = {}
        for sb in bucket.get("severityByRuleLevel", {}).get("buckets", []):
            severityBreakdown[sb["key"]] = sb["doc_count"]
        result[agentName] = {
            "totalAlerts": total,
            "severityBreakdown": severityBreakdown,
        }
    return result


# === URL BUILDERS ===
def buildAgentsOverviewUrl(timeFrom=None, timeTo=None):
    """Build URL to agents overview page (endpoints-summary/agents-preview)"""
    base = f"{DASHBOARD_BASE_URL}/app/endpoints-summary#/agents-preview/"
    if timeFrom and timeTo:
        timeFromEsc = timeFrom.replace("'", "\\'")
        timeToEsc = timeTo.replace("'", "\\'")
        _g = f"(filters:!(),refreshInterval:(pause:!t,value:0),time:(from:'{timeFromEsc}',to:'{timeToEsc}'))"
        from urllib.parse import quote
        return base + "?_g=" + quote(_g, safe="()!:,'")
    return base


def buildVulnerabilityDetectionUrl(timeFrom, timeTo, agentName=None, cveId=None):
    """Build URL to vulnerability detection app with optional agent and/or CVE filter.
    - agentName only: filter by agent
    - cveId only: filter by CVE
    - agentName + cveId: filter by both
    Uses $state structure to match OpenSearch Dashboard format.
    """
    from urllib.parse import quote

    timeFromEsc = timeFrom.replace("\\", "\\\\").replace("'", "\\'")
    timeToEsc = timeTo.replace("\\", "\\\\").replace("'", "\\'")
    indexEsc = ES_INDEX_PATTERN.replace("\\", "\\\\").replace("'", "\\'")

    _g = f"(filters:!(),refreshInterval:(pause:!t,value:0),time:(from:'{timeFromEsc}',to:'{timeToEsc}'))"

    filterParts = []
    if agentName:
        agentEsc = str(agentName).replace("\\", "\\\\").replace("'", "\\'")
        fp = f"('$state':(store:appState),meta:(alias:!n,disabled:!f,index:'{indexEsc}',key:agent.name,negate:!f,params:(query:'{agentEsc}'),type:phrase),query:(match_phrase:(agent.name:(query:'{agentEsc}'))))"
        filterParts.append(fp)
    if cveId:
        cveEsc = str(cveId).replace("\\", "\\\\").replace("'", "\\'")
        fp = f"('$state':(store:appState),meta:(alias:!n,disabled:!f,index:'{indexEsc}',key:data.vulnerability.cve,negate:!f,params:(query:'{cveEsc}'),type:phrase),query:(match_phrase:(data.vulnerability.cve:(query:'{cveEsc}'))))"
        filterParts.append(fp)

    if filterParts:
        _a = f"(filters:!({','.join(filterParts)}),query:(language:kuery,query:''))"
    else:
        _a = "(filters:!(),query:(language:kuery,query:''))"

    base = f"{DASHBOARD_BASE_URL}/app/vulnerability-detection#/overview/"
    safe_chars = "()!:,'"
    return f"{base}?tab=vuls&tabView=events&_g={quote(_g, safe=safe_chars)}&_a={quote(_a, safe=safe_chars)}"


def buildVulnerabilityUrl(timeFrom, timeTo, agentName=None):
    """Build URL for vulnerability alerts (Discover); optionally filter by agent.
    For vulnerability detection app, use buildVulnerabilityDetectionUrl instead."""
    filters = [
        {"type": "phrase", "field": "rule.groups", "value": "vulnerability"},
    ]
    if agentName:
        filters.append({"type": "phrase", "field": "agent.name", "value": agentName})
    return buildDashboardUrl(timeFrom, timeTo, filters)


# === HTML REPORT BUILDER ===
def _buildStatCard(value, label, sublabel, bgColor, borderColor, textColor, linkUrl=None, linkText="View in Dashboard →"):
    """Build one stat card for the summary row"""
    linkHtml = f'<a href="{linkUrl}" style="color:#1e40af;text-decoration:none;font-size:10px;font-weight:500;margin-top:4px;display:inline-block;">{linkText}</a>' if linkUrl else ""
    return f"""<table width="100%" cellpadding="0" cellspacing="0" border="0" style="background:{bgColor};border:1px solid {borderColor};border-radius:6px;height:120px;">
<tr><td style="padding:16px;text-align:center;vertical-align:middle;">
    <div style="font-size:28px;font-weight:700;color:{textColor};margin-bottom:4px;">{value}</div>
    <div style="color:{textColor};font-size:11px;text-transform:uppercase;letter-spacing:0.5px;">{label}</div>
    <div style="color:#6b7280;font-size:10px;margin-top:4px;">{sublabel}</div>
    {linkHtml}
</td></tr></table>"""


def buildHtmlReport(timeFrom, timeTo, activeAgents, inactiveAgents, vulnByAgent, vulnOverview, alertsByAgent=None):
    """Build professional HTML email: summary cards, top active agents, inactive agents, vulnerability table"""
    fromDate = datetime.fromisoformat(timeFrom.replace("Z", "+00:00")).strftime("%B %d, %Y")
    toDate = datetime.fromisoformat(timeTo.replace("Z", "+00:00")).strftime("%B %d, %Y")
    generatedAt = datetime.now(timezone.utc).strftime("%B %d, %Y at %I:%M %p UTC")
    colors = getColorScheme()

    allAgents = activeAgents + inactiveAgents
    activeCount = len(activeAgents)
    inactiveCount = len(inactiveAgents)
    totalVulnAlerts = vulnOverview.get("totalVulnAlerts", 0)
    uniqueCves = vulnOverview.get("uniqueCves", 0)
    vulnAgentCount = vulnOverview.get("uniqueAgents", 0)
    globalSev = vulnOverview.get("severity", {})

    agentsOverviewUrl = buildAgentsOverviewUrl(timeFrom, timeTo)
    allVulnUrl = buildVulnerabilityDetectionUrl(timeFrom, timeTo)

    # ── Section 1: Summary Stat Cards ──
    summaryCardsHtml = f"""
    <table width="100%" cellpadding="0" cellspacing="0" border="0" style="margin-bottom:24px;">
    <tr>
        <td width="20%" style="padding:6px;">{_buildStatCard(activeCount + inactiveCount, "Total Agents", f"{activeCount} active", "#f0f9ff", "#bae6fd", colors["primary"], agentsOverviewUrl)}</td>
        <td width="20%" style="padding:6px;">{_buildStatCard(activeCount, "Active", "Reporting", "#f0fdf4", "#bbf7d0", colors["success"], agentsOverviewUrl)}</td>
        <td width="20%" style="padding:6px;">{_buildStatCard(inactiveCount, "Inactive", "&gt;24h no events", "#fef2f2" if inactiveCount > 0 else "#f0fdf4", "#fecaca" if inactiveCount > 0 else "#bbf7d0", colors["danger"] if inactiveCount > 0 else colors["success"], agentsOverviewUrl)}</td>
        <td width="20%" style="padding:6px;">{_buildStatCard(totalVulnAlerts, "Vuln Alerts", f"{uniqueCves} unique CVEs", "#fef2f2" if totalVulnAlerts > 0 else "#f0fdf4", "#fecaca" if totalVulnAlerts > 0 else "#bbf7d0", colors["danger"] if totalVulnAlerts > 0 else colors["success"], allVulnUrl)}</td>
        <td width="20%" style="padding:6px;">{_buildStatCard(vulnAgentCount, "Agents w/ Vulns", f"C:{globalSev.get('Critical',0)} H:{globalSev.get('High',0)} M:{globalSev.get('Medium',0)}", "#fff7ed" if vulnAgentCount > 0 else "#f0fdf4", "#fed7aa" if vulnAgentCount > 0 else "#bbf7d0", colors["warning"] if vulnAgentCount > 0 else colors["success"], allVulnUrl)}</td>
    </tr>
    </table>"""

    # ── Section 2: Top Active Agents (based on alerts; links to Discover/wazuh-alerts) ──
    alertsByAgent = alertsByAgent or {}
    topActiveRows = ""
    for i, agent in enumerate(activeAgents[:10], 1):
        agentUrl = buildAgentUrl(timeFrom, timeTo, agent["name"])
        alerts = alertsByAgent.get(agent["name"], {})
        totalAlerts = alerts.get("totalAlerts", 0)
        sev = alerts.get("severityBreakdown", {})
        alertsNumCell = f'<a href="{agentUrl}" style="color:{colors["primary"]};text-decoration:none;font-weight:700;font-size:16px;">{totalAlerts}</a>' if totalAlerts > 0 else "—"

        topActiveRows += f"""
        <tr style="background:{'#fafafa' if i % 2 == 0 else '#fff'};">
            <td style="padding:12px 16px;border-bottom:1px solid {colors['border']};font-size:14px;color:{colors['text']};font-weight:600;">{i}</td>
            <td style="padding:12px 16px;border-bottom:1px solid {colors['border']};">
                <a href="{agentUrl}" style="color:{colors['primary']};text-decoration:none;font-weight:600;font-size:14px;">{htmlEscape(agent['name'])}</a>
                <div style="color:{colors['textLight']};font-size:12px;margin-top:2px;">ID: {htmlEscape(str(agent['id']))} &middot; {htmlEscape(agent['hostOs'])}</div>
            </td>
            <td style="padding:12px 16px;border-bottom:1px solid {colors['border']};text-align:center;font-size:13px;color:{colors['textLight']};">
                {htmlEscape(agent['lastSeenFormatted'])}
            </td>
            <td style="padding:12px 16px;border-bottom:1px solid {colors['border']};text-align:center;font-weight:700;font-size:16px;color:{colors['primary'] if totalAlerts > 0 else colors['textLight']};">
                {alertsNumCell}
            </td>
            <td style="padding:12px 16px;border-bottom:1px solid {colors['border']};text-align:right;">
                <a href="{agentUrl}" style="text-decoration:none;"><span style="background:{colors['danger']};color:#fff;padding:2px 8px;border-radius:4px;font-size:11px;margin-right:4px;">C:{sev.get('Critical',0)}</span></a>
                <a href="{agentUrl}" style="text-decoration:none;"><span style="background:{colors['warning']};color:#fff;padding:2px 8px;border-radius:4px;font-size:11px;margin-right:4px;">H:{sev.get('High',0)}</span></a>
                <a href="{agentUrl}" style="text-decoration:none;"><span style="background:{colors['info']};color:#fff;padding:2px 8px;border-radius:4px;font-size:11px;">M:{sev.get('Medium',0)}</span></a>
            </td>
        </tr>"""

    if not topActiveRows:
        topActiveRows = f'<tr><td colspan="5" style="padding:24px;text-align:center;color:{colors["textLight"]};">No active agents found</td></tr>'

    topActiveHtml = f"""
    <table width="100%" cellpadding="0" cellspacing="0" border="0" style="background:#fff;border:1px solid {colors['border']};border-radius:6px;margin:24px 0;">
    <tr><td style="padding:20px;">
        <h3 style="margin:0 0 16px 0;color:{colors['dark']};font-size:18px;font-weight:600;border-bottom:2px solid {colors['border']};padding-bottom:8px;">
            Top Active Agents
        </h3>
        <table width="100%" cellpadding="0" cellspacing="0" border="0" style="border-collapse:collapse;">
        <thead><tr style="background:{colors['light']};">
            <th style="padding:12px 16px;text-align:left;font-size:11px;color:{colors['textLight']};text-transform:uppercase;letter-spacing:0.5px;border-bottom:1px solid {colors['border']};width:50px;">#</th>
            <th style="padding:12px 16px;text-align:left;font-size:11px;color:{colors['textLight']};text-transform:uppercase;letter-spacing:0.5px;border-bottom:1px solid {colors['border']};">Agent</th>
            <th style="padding:12px 16px;text-align:center;font-size:11px;color:{colors['textLight']};text-transform:uppercase;letter-spacing:0.5px;border-bottom:1px solid {colors['border']};width:150px;">Last Seen</th>
            <th style="padding:12px 16px;text-align:center;font-size:11px;color:{colors['textLight']};text-transform:uppercase;letter-spacing:0.5px;border-bottom:1px solid {colors['border']};width:100px;">Alerts</th>
            <th style="padding:12px 16px;text-align:right;font-size:11px;color:{colors['textLight']};text-transform:uppercase;letter-spacing:0.5px;border-bottom:1px solid {colors['border']};width:200px;">Severity Breakdown</th>
        </tr></thead>
        <tbody>{topActiveRows}</tbody>
        </table>
    </td></tr></table>"""

    # ── Section 3: Inactive Agents (grouped by category) ──
    inactiveRows = ""
    if inactiveAgents:
        currentCategory = None
        rowNum = 0
        for agent in inactiveAgents:
            hoursSince = agent["hoursSinceLastSeen"]
            category = agent.get("category", "Inactive")
            categoryPriority = agent.get("categoryPriority", 3)

            if categoryPriority == 1:
                urgencyColor = colors["info"]
                rowBgColor = "#f0f9ff"
                categoryBgColor = "#0284c7"
            elif categoryPriority == 2:
                urgencyColor = colors["warning"]
                rowBgColor = "#fff7ed"
                categoryBgColor = "#d97706"
            else:
                urgencyColor = colors["danger"]
                rowBgColor = "#fef2f2"
                categoryBgColor = "#dc2626"

            if category != currentCategory:
                currentCategory = category
                categoryDescription = agent.get("categoryDescription", category)
                categoryCount = sum(1 for a in inactiveAgents if a.get("category") == category)
                agentWord = "agent" if categoryCount == 1 else "agents"
                inactiveRows += f"""
                <tr style="background:{categoryBgColor};">
                    <td colspan="5" style="padding:10px 16px;color:#fff;font-weight:700;font-size:13px;">
                        {htmlEscape(category)} ({categoryCount} {agentWord}) — {htmlEscape(categoryDescription)}
                    </td>
                </tr>"""

            rowNum += 1
            agentDiscoverUrl = buildAgentUrl(timeFrom, timeTo, agent["name"])
            inactiveRows += f"""
            <tr style="background:{rowBgColor};">
                <td style="padding:12px 16px;border-bottom:1px solid {colors['border']};font-size:14px;color:{colors['text']};font-weight:600;">{rowNum}</td>
                <td style="padding:12px 16px;border-bottom:1px solid {colors['border']};">
                    <a href="{agentDiscoverUrl}" style="color:{urgencyColor};text-decoration:none;font-weight:600;font-size:14px;">{htmlEscape(agent['name'])}</a>
                    <div style="color:{colors['textLight']};font-size:12px;margin-top:2px;">ID: {htmlEscape(str(agent['id']))} &middot; {htmlEscape(agent['hostOs'])}</div>
                </td>
                <td style="padding:12px 16px;border-bottom:1px solid {colors['border']};text-align:center;font-size:13px;color:{colors['textLight']};">
                    {htmlEscape(agent['lastSeenFormatted'])}
                </td>
                <td style="padding:12px 16px;border-bottom:1px solid {colors['border']};text-align:center;">
                    <span style="background:{urgencyColor};color:#fff;padding:4px 10px;border-radius:12px;font-size:12px;font-weight:600;">{hoursSince}h ago</span>
                </td>
                <td style="padding:12px 16px;border-bottom:1px solid {colors['border']};font-size:13px;color:{colors['text']};">
                    {htmlEscape(agent['hostOs'])}
                </td>
            </tr>"""
    else:
        inactiveRows = f'<tr><td colspan="5" style="padding:24px;text-align:center;color:{colors["success"]};font-size:14px;">All agents are reporting normally — no inactive agents detected</td></tr>'

    inactiveHtml = f"""
    <table width="100%" cellpadding="0" cellspacing="0" border="0" style="background:#fff;border:1px solid {'#fecaca' if inactiveCount > 0 else colors['border']};border-radius:6px;margin:24px 0;">
    <tr><td style="padding:20px;">
        <h3 style="margin:0 0 16px 0;color:{colors['danger'] if inactiveCount > 0 else colors['dark']};font-size:18px;font-weight:600;border-bottom:2px solid {colors['border']};padding-bottom:8px;">
            Inactive Agents {'— Attention Required' if inactiveCount > 0 else ''}
        </h3>
        <table width="100%" cellpadding="0" cellspacing="0" border="0" style="border-collapse:collapse;">
        <thead><tr style="background:{colors['light']};">
            <th style="padding:12px 16px;text-align:left;font-size:11px;color:{colors['textLight']};text-transform:uppercase;letter-spacing:0.5px;border-bottom:1px solid {colors['border']};width:50px;">#</th>
            <th style="padding:12px 16px;text-align:left;font-size:11px;color:{colors['textLight']};text-transform:uppercase;letter-spacing:0.5px;border-bottom:1px solid {colors['border']};">Agent</th>
            <th style="padding:12px 16px;text-align:center;font-size:11px;color:{colors['textLight']};text-transform:uppercase;letter-spacing:0.5px;border-bottom:1px solid {colors['border']};width:150px;">Last Seen</th>
            <th style="padding:12px 16px;text-align:center;font-size:11px;color:{colors['textLight']};text-transform:uppercase;letter-spacing:0.5px;border-bottom:1px solid {colors['border']};width:100px;">Inactive</th>
            <th style="padding:12px 16px;text-align:left;font-size:11px;color:{colors['textLight']};text-transform:uppercase;letter-spacing:0.5px;border-bottom:1px solid {colors['border']};width:120px;">Host OS</th>
        </tr></thead>
        <tbody>{inactiveRows}</tbody>
        </table>
    </td></tr></table>"""

    # ── Section 4: Vulnerability Summary by Agent ──
    agentsWithVulnData = [(a, vulnByAgent.get(a["name"], {})) for a in allAgents if vulnByAgent.get(a["name"], {}).get("totalVulnAlerts", 0) > 0]
    agentsWithVulnData.sort(key=lambda x: x[1].get("totalVulnAlerts", 0), reverse=True)

    vulnRows = ""
    for i, (agent, vuln) in enumerate(agentsWithVulnData[:15], 1):
        vulnUrl = buildVulnerabilityDetectionUrl(timeFrom, timeTo, agent["name"])
        totalVuln = vuln.get("totalVulnAlerts", 0)
        sev = vuln.get("severityBreakdown", {})
        crit = sev.get("Critical", 0)
        high = sev.get("High", 0)
        med = sev.get("Medium", 0)

        topCvesHtml = ""
        for c in vuln.get("topCves", [])[:5]:
            sevLabel = c.get("severity")  # Only High, Medium, Critical; omit Low
            sevColor = {"Critical": colors["danger"], "High": colors["warning"], "Medium": colors["info"]}.get(sevLabel, colors["secondary"])
            cveAgentUrl = buildVulnerabilityDetectionUrl(timeFrom, timeTo, agentName=agent["name"], cveId=c["cve"])
            badge = f'<span style="background:{sevColor}20;color:{sevColor};padding:1px 6px;border-radius:3px;font-size:10px;margin-right:4px;">{htmlEscape(sevLabel)}</span> ' if sevLabel else ''
            topCvesHtml += f'<div style="margin:2px 0;font-size:12px;">{badge}<a href="{cveAgentUrl}" style="color:{colors["primary"]};text-decoration:none;font-weight:600;">{htmlEscape(c["cve"])}</a> <span style="color:{colors["textLight"]};">({c["count"]})</span></div>'
        if not topCvesHtml:
            topCvesHtml = '<span style="color:#94a3b8;">—</span>'

        vulnRows += f"""
        <tr style="background:{'#fafafa' if i % 2 == 0 else '#fff'};">
            <td style="padding:12px 16px;border-bottom:1px solid {colors['border']};font-weight:600;font-size:14px;">{i}</td>
            <td style="padding:12px 16px;border-bottom:1px solid {colors['border']};">
                <a href="{vulnUrl}" style="color:{colors['primary']};text-decoration:none;font-weight:600;font-size:14px;">{htmlEscape(agent['name'])}</a>
                <div style="color:{colors['textLight']};font-size:12px;margin-top:2px;">ID: {htmlEscape(str(agent['id']))}</div>
            </td>
            <td style="padding:12px 16px;border-bottom:1px solid {colors['border']};text-align:center;">
                <a href="{vulnUrl}" style="color:{colors['primary']};text-decoration:none;font-weight:700;font-size:18px;">{totalVuln}</a>
            </td>
            <td style="padding:12px 16px;border-bottom:1px solid {colors['border']};text-align:center;">
                <span style="background:{colors['danger']};color:#fff;padding:2px 8px;border-radius:4px;font-size:11px;margin-right:2px;">C:{crit}</span>
                <span style="background:{colors['warning']};color:#fff;padding:2px 8px;border-radius:4px;font-size:11px;margin-right:2px;">H:{high}</span>
                <span style="background:{colors['info']};color:#fff;padding:2px 8px;border-radius:4px;font-size:11px;">M:{med}</span>
            </td>
            <td style="padding:10px 16px;border-bottom:1px solid {colors['border']};vertical-align:top;">{topCvesHtml}</td>
        </tr>"""

    if not vulnRows:
        vulnRows = f'<tr><td colspan="5" style="padding:24px;text-align:center;color:{colors["success"]};font-size:14px;">No vulnerability alerts detected in this period</td></tr>'

    # Top CVEs global summary cards (Medium, High, Critical only) with hyperlinks
    topCvesGlobal = vulnOverview.get("topCves", [])[:5]
    topCvesGlobalHtml = ""
    if topCvesGlobal:
        cards = []
        for cve in topCvesGlobal:
            cveOnlyUrl = buildVulnerabilityDetectionUrl(timeFrom, timeTo, cveId=cve["cve"])
            sevLabel = cve.get("severity")  # Only High, Medium, Critical; omit Low
            sevColor = {"Critical": colors["danger"], "High": colors["warning"], "Medium": colors["info"]}.get(sevLabel, colors["secondary"])
            scoreVal = cve.get("score", "N/A")
            badgeHtml = f'<span style="background:{sevColor};color:#fff;padding:2px 6px;border-radius:3px;font-size:10px;">{htmlEscape(str(sevLabel))}</span>' if sevLabel else ''
            cards.append(f"""<div style="display:inline-block;background:#fff;border:1px solid {colors['border']};border-radius:6px;padding:12px 16px;margin:4px 8px 4px 0;vertical-align:top;min-width:140px;">
                <div style="font-weight:700;font-size:13px;margin-bottom:4px;"><a href="{cveOnlyUrl}" style="color:{colors['primary']};text-decoration:none;">{htmlEscape(cve['cve'])}</a></div>
                <div style="font-size:12px;">{badgeHtml} <span style="color:{colors['textLight']};margin-left:6px;">CVSS: {htmlEscape(str(scoreVal))}</span></div>
                <div style="color:{colors['textLight']};font-size:11px;margin-top:4px;">{cve['count']} alerts &middot; {cve.get('affectedAgents', 0)} agents</div>
            </div>""")
        topCvesGlobalHtml = f'<div style="margin-top:8px;">{"".join(cards)}</div>'

    vulnSectionHtml = f"""
    <table width="100%" cellpadding="0" cellspacing="0" border="0" style="background:#fff;border:1px solid {colors['border']};border-radius:6px;margin:24px 0;">
    <tr><td style="padding:20px;">
        <h3 style="margin:0 0 16px 0;color:{colors['dark']};font-size:18px;font-weight:600;border-bottom:2px solid {colors['border']};padding-bottom:8px;">
            Vulnerability Summary by Agent
        </h3>
        {f'<div style="margin-bottom:20px;"><strong style="font-size:13px;color:{colors["text"]};">Top CVEs Detected (High, Medium, Critical):</strong><div style="margin-top:10px;">{topCvesGlobalHtml}</div></div>' if topCvesGlobalHtml else ''}
        <table width="100%" cellpadding="0" cellspacing="0" border="0" style="border-collapse:collapse;">
        <thead><tr style="background:{colors['light']};">
            <th style="padding:12px 16px;text-align:left;font-size:11px;color:{colors['textLight']};text-transform:uppercase;letter-spacing:0.5px;border-bottom:1px solid {colors['border']};width:40px;">#</th>
            <th style="padding:12px 16px;text-align:left;font-size:11px;color:{colors['textLight']};text-transform:uppercase;letter-spacing:0.5px;border-bottom:1px solid {colors['border']};">Agent</th>
            <th style="padding:12px 16px;text-align:center;font-size:11px;color:{colors['textLight']};text-transform:uppercase;letter-spacing:0.5px;border-bottom:1px solid {colors['border']};width:80px;">Total</th>
            <th style="padding:12px 16px;text-align:center;font-size:11px;color:{colors['textLight']};text-transform:uppercase;letter-spacing:0.5px;border-bottom:1px solid {colors['border']};width:210px;">Severity</th>
            <th style="padding:12px 16px;text-align:left;font-size:11px;color:{colors['textLight']};text-transform:uppercase;letter-spacing:0.5px;border-bottom:1px solid {colors['border']};">Top CVEs</th>
        </tr></thead>
        <tbody>{vulnRows}</tbody>
        </table>
    </td></tr></table>"""

    # ── Final HTML Assembly ──
    htmlOutput = f"""
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <!--[if mso]><style type="text/css">body, table, td {{font-family: Arial, sans-serif !important;}}</style><![endif]-->
</head>
<body style="margin:0;padding:0;font-family:Arial,sans-serif;background:{colors['light']};width:100%;">
<table width="100%" cellpadding="0" cellspacing="0" border="0" style="background:{colors['light']};margin:0;padding:0;">
<tr><td align="center" style="padding:0;">

    <!-- Header -->
    <div style="background:#0d47a1;color:#fff;padding:16px 20px;font-size:20px;font-weight:700;">
        {ATHENA_NAME} — Agent Status &amp; Vulnerability Report
        <div style="font-size:12px;font-weight:400;opacity:0.95;margin-top:4px;">Tenant: {htmlEscape(TENANT_NAME)}</div>
        <div style="font-size:12px;font-weight:400;opacity:0.95;margin-top:4px;">Period: {fromDate} — {toDate}</div>
    </div>

    <!-- Main Content -->
    <div style="padding:20px;font-family:Arial,sans-serif;line-height:1.5;max-width:960px;margin:0 auto;">

        {summaryCardsHtml}

        {topActiveHtml}

        {inactiveHtml}

        {vulnSectionHtml}

    </div>

    <!-- Footer -->
    <div style="background:#f3f4f6;color:#333;padding:16px 20px;font-size:12px;">
        <p style="margin:2px 0 6px 0;"><strong>Athena Security Group</strong></p>
        <p style="margin:2px 0;">🌐 <a href="{ATHENA_WEBSITE}" style="color:#0d47a1;text-decoration:none;">Website</a>
           &nbsp;|&nbsp; 📄 <a href="{ATHENA_DOCS}" style="color:#0d47a1;text-decoration:none;">Docs</a>
           &nbsp;|&nbsp; 📧 <a href="mailto:{ATHENA_SUPPORT}" style="color:#0d47a1;text-decoration:none;">{ATHENA_SUPPORT}</a></p>
        <p style="margin:10px 0 0 0;">This report was generated on {generatedAt}. Do not reply to this email.</p>
    </div>

</td></tr>
</table>
</body>
</html>"""
    return htmlOutput


def buildPlainReport(timeFrom, timeTo, activeAgents, inactiveAgents, vulnByAgent, vulnOverview, alertsByAgent=None):
    """Build plain text version of the agent status / vulnerability report"""
    fromDate = datetime.fromisoformat(timeFrom.replace("Z", "+00:00")).strftime("%B %d, %Y")
    toDate = datetime.fromisoformat(timeTo.replace("Z", "+00:00")).strftime("%B %d, %Y")
    allAgents = activeAgents + inactiveAgents
    activeCount = len(activeAgents)
    inactiveCount = len(inactiveAgents)
    totalVulnAlerts = vulnOverview.get("totalVulnAlerts", 0)
    uniqueCves = vulnOverview.get("uniqueCves", 0)
    globalSev = vulnOverview.get("severity", {})

    lines = []
    lines.append("=" * 80)
    lines.append(f"{ATHENA_NAME} - AGENT STATUS & VULNERABILITY REPORT")
    lines.append("=" * 80)
    lines.append(f"Tenant: {TENANT_NAME}")
    lines.append(f"Period: {fromDate} — {toDate}")
    lines.append("")

    lines.append("SUMMARY")
    lines.append("-" * 80)
    lines.append(f"Total Agents: {activeCount + inactiveCount} (Active: {activeCount}, Inactive: {inactiveCount})")
    lines.append(f"Vulnerability Alerts: {totalVulnAlerts} ({uniqueCves} unique CVEs)")
    lines.append(f"  Critical: {globalSev.get('Critical', 0)} | High: {globalSev.get('High', 0)} | Medium: {globalSev.get('Medium', 0)} | Low: {globalSev.get('Low', 0)}")
    lines.append("")

    # Top Active Agents (based on alerts)
    alertsByAgent = alertsByAgent or {}
    lines.append("TOP ACTIVE AGENTS")
    lines.append("-" * 80)
    for i, agent in enumerate(activeAgents[:10], 1):
        alerts = alertsByAgent.get(agent["name"], {})
        totalAlerts = alerts.get("totalAlerts", 0)
        sev = alerts.get("severityBreakdown", {})
        sevStr = f"C:{sev.get('Critical',0)} H:{sev.get('High',0)} M:{sev.get('Medium',0)}" if totalAlerts else "0 alerts"
        lines.append(f"{i:2}. {agent['name']} (ID: {agent['id']})")
        lines.append(f"    Last seen: {agent['lastSeenFormatted']} | OS: {agent['hostOs']} | Alerts: {totalAlerts} [{sevStr}]")
    lines.append("")

    # Inactive Agents (grouped)
    lines.append("INACTIVE AGENTS (>24h)")
    lines.append("-" * 80)
    if inactiveAgents:
        currentCategory = None
        rowNum = 0
        for agent in inactiveAgents:
            category = agent.get("category", "Inactive")
            if category != currentCategory:
                currentCategory = category
                categoryDescription = agent.get("categoryDescription", category)
                categoryCount = sum(1 for a in inactiveAgents if a.get("category") == category)
                agentWord = "agent" if categoryCount == 1 else "agents"
                lines.append("")
                lines.append(f"=== {category.upper()} ({categoryCount} {agentWord}) — {categoryDescription} ===")
                lines.append("")
            rowNum += 1
            lines.append(f"{rowNum:2}. {agent['name']} (ID: {agent['id']})")
            lines.append(f"    Last seen: {agent['lastSeenFormatted']} ({agent['hoursSinceLastSeen']}h ago) | OS: {agent['hostOs']}")
    else:
        lines.append("All agents are reporting normally")
    lines.append("")

    # Vulnerability by Agent
    lines.append("VULNERABILITY SUMMARY BY AGENT")
    lines.append("-" * 80)
    agentsWithVulnData = [(a, vulnByAgent.get(a["name"], {})) for a in allAgents if vulnByAgent.get(a["name"], {}).get("totalVulnAlerts", 0) > 0]
    agentsWithVulnData.sort(key=lambda x: x[1].get("totalVulnAlerts", 0), reverse=True)
    if agentsWithVulnData:
        for i, (agent, vuln) in enumerate(agentsWithVulnData[:15], 1):
            sev = vuln.get("severityBreakdown", {})
            cves = ", ".join([c["cve"] for c in vuln.get("topCves", [])[:5]]) or "—"
            lines.append(f"{i:2}. {agent['name']} — {vuln.get('totalVulnAlerts', 0)} alerts")
            lines.append(f"    Severity: C:{sev.get('Critical',0)} H:{sev.get('High',0)} M:{sev.get('Medium',0)} L:{sev.get('Low',0)}")
            lines.append(f"    Top CVEs: {cves}")
    else:
        lines.append("No vulnerability alerts detected in this period")
    lines.append("")

    # Top CVEs (Medium, High, Critical only)
    topCvesGlobal = vulnOverview.get("topCves", [])[:5]
    if topCvesGlobal:
        lines.append("TOP CVEs DETECTED (Medium, High, Critical)")
        lines.append("-" * 80)
        for cve in topCvesGlobal:
            lines.append(f"  {cve['cve']} | Severity: {cve.get('severity', 'N/A')} | CVSS: {cve.get('score', 'N/A')} | {cve['count']} alerts | {cve.get('affectedAgents', 0)} agents")
        lines.append("")

    lines.append("=" * 80)
    lines.append(f"{ATHENA_NAME} | {ATHENA_WEBSITE} | {ATHENA_SUPPORT}")
    lines.append(f"Generated on {datetime.now(timezone.utc).strftime('%B %d, %Y at %I:%M %p UTC')}")
    lines.append("=" * 80)
    return "\n".join(lines)


# === MAIN REPORT GENERATOR ===
def generateAgentStatusReport(
    reportType: str,
    timeFrom: str,
    timeTo: str,
    recipients: list,
    agentSubset: list = None,
    inactiveThresholdHours: int = None,
) -> bool:
    """
    Generate and send the agent status report with vulnerability summary.

    Args:
        reportType: daily, weekly, monthly, custom
        timeFrom: Start time (ISO)
        timeTo: End time (ISO)
        recipients: Email recipients
        agentSubset: Optional list of agent names to include (None = all)
        inactiveThresholdHours: Override default inactive threshold (default: 24)

    Returns:
        True if report was sent successfully.
    """
    log(f"Generating {reportType} agent status report from {timeFrom} to {timeTo}")

    inactiveThresholdHours = inactiveThresholdHours or AGENT_REPORT_INACTIVE_THRESHOLD_HOURS

    agentsAgg = queryAllAgentsWithStatus()
    vulnAgg = queryVulnerabilityByAgent(timeFrom, timeTo, agentSubset)
    vulnOverviewAgg = queryVulnerabilityOverview(timeFrom, timeTo)
    alertsAgg = queryAlertsByAgent(timeFrom, timeTo, agentSubset)

    activeAgents, inactiveAgents = processAllAgentsWithStatus(agentsAgg, inactiveThresholdHours, agentSubset)
    vulnByAgent = processVulnerabilityByAgent(vulnAgg)
    vulnOverview = processVulnerabilityOverview(vulnOverviewAgg)
    alertsByAgent = processAlertsByAgent(alertsAgg)

    if not activeAgents and not inactiveAgents:
        log("No agents found for the report")
        return False

    subject = f"[{TENANT_NAME}] Agent Status & Vulnerability Report - {datetime.fromisoformat(timeFrom.replace('Z', '+00:00')).strftime('%b %d, %Y')}"
    htmlBody = buildHtmlReport(timeFrom, timeTo, activeAgents, inactiveAgents, vulnByAgent, vulnOverview, alertsByAgent)
    plainBody = buildPlainReport(timeFrom, timeTo, activeAgents, inactiveAgents, vulnByAgent, vulnOverview, alertsByAgent)

    return sendEmail(recipients, subject, plainBody, htmlBody)


def generateDailyAgentReport(recipients: list = None, agentSubset: list = None) -> bool:
    """Generate daily agent status report (last 24 hours)"""
    now = datetime.now(timezone.utc)
    timeTo = now.isoformat().replace("+00:00", "Z")
    timeFrom = (now - timedelta(days=1)).isoformat().replace("+00:00", "Z")
    return generateAgentStatusReport("daily", timeFrom, timeTo, recipients or SMTP_RECIPIENT, agentSubset)


def generateWeeklyAgentReport(recipients: list = None, agentSubset: list = None) -> bool:
    """Generate weekly agent status report (last 7 days)"""
    now = datetime.now(timezone.utc)
    timeTo = now.isoformat().replace("+00:00", "Z")
    timeFrom = (now - timedelta(days=7)).isoformat().replace("+00:00", "Z")
    return generateAgentStatusReport("weekly", timeFrom, timeTo, recipients or SMTP_RECIPIENT, agentSubset)


# === MAIN ENTRY POINT ===
def main(args):
    """
    Usage:
      python reports_agents.py daily
      python reports_agents.py weekly
    """
    log("# Starting agent status report generation")
    if len(args) < 2:
        log("Usage: reports_agents.py <daily|weekly>")
        return

    reportType = args[1].lower()
    now = datetime.now(timezone.utc)

    if reportType == "daily":
        timeTo = now.isoformat().replace("+00:00", "Z")
        timeFrom = (now - timedelta(days=1)).isoformat().replace("+00:00", "Z")
    elif reportType == "weekly":
        timeTo = now.isoformat().replace("+00:00", "Z")
        timeFrom = (now - timedelta(days=7)).isoformat().replace("+00:00", "Z")
    else:
        log(f"Unknown report type: {reportType}. Use daily or weekly.")
        return

    recipients = SMTP_RECIPIENT
    log(f"Generating {reportType} agent report from {timeFrom} to {timeTo}")

    try:
        success = generateAgentStatusReport(reportType, timeFrom, timeTo, recipients)
        if success:
            log("Agent status report sent successfully")
        else:
            log("Agent status report failed or no data found")
    except Exception as e:
        log(f"Error: {e}")
        import traceback
        log(traceback.format_exc())


if __name__ == "__main__":
    try:
        main(sys.argv)
    except Exception as e:
        log(f"Unhandled exception: {e}")
        import traceback
        log(traceback.format_exc())
        raise
