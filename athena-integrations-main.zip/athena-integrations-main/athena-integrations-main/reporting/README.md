# Athena-Reports
Reporting module for Daily, Weekly and Monthly Reports for SIEM and NIDS data

## AI Integration

All reports use **Ollama** with the `qwen2.5:14b-instruct` model for AI-powered analysis and insights. Ollama runs locally — no external API keys required.

### Ollama Configuration

Set the following in your `.env` file:

```env
OLLAMA_HOST=localhost
OLLAMA_PORT=11434
OLLAMA_MODEL=qwen2.5:14b-instruct
OLLAMA_ENABLED=true
```

| Variable | Description | Default |
|----------|-------------|---------|
| `OLLAMA_HOST` | Ollama server IP or hostname | `localhost` |
| `OLLAMA_PORT` | Ollama server port | `11434` |
| `OLLAMA_MODEL` | Model to use for AI analysis | `qwen2.5:14b-instruct` |
| `OLLAMA_ENABLED` | Enable/disable AI insights | `true` (`false` for Suricata reports) |

### Ollama Variable Reference

| Variable | Description | Default | Notes |
|----------|-------------|---------|-------|
| `OLLAMA_HOST` | IP or hostname of the Ollama server | `localhost` | Use the IP/hostname where Ollama is running. Can be a remote server. |
| `OLLAMA_PORT` | Ollama HTTP API port | `11434` | Default Ollama port. Only change if Ollama is configured on a custom port. |
| `OLLAMA_MODEL` | Model name for AI analysis | `qwen2.5:14b-instruct` | Must be pulled first via `ollama pull`. 14B model recommended for quality/speed balance. |
| `OLLAMA_ENABLED` | Enable/disable AI insights | `true` (`false` for Suricata) | Set to `false` to skip AI analysis. Reports will still be generated but without AI sections. |

> **Note:** Ollama uses the OpenAI-compatible API endpoint (`/v1/chat/completions`). No API key is required — authentication is not needed for local Ollama instances.

### AI Analysis Tuning

The following parameters are configured internally (not via `.env`) and optimized for the `qwen2.5:14b-instruct` model running on Ollama:

| Parameter | SIEM Reports | Compliance | Suricata Reports | Description |
|-----------|-------------|------------|-----------------|-------------|
| `max_tokens` | 8192 | 8192 | 4096 | Maximum response length. Optimized for Ollama (no per-token cost). |
| `temperature` | 0.3 | 0.3 | 0.3 | Low temperature for consistent, factual responses. |
| `timeout` | 300s | 300s | 240s | HTTP request timeout for Ollama API calls. |

All prompts include anti-hallucination guardrails — the model is instructed not to speculate when data fields are empty or unavailable.

### Prerequisites

- Ollama server installed and running
- `qwen2.5:14b-instruct` model pulled (`ollama pull qwen2.5:14b-instruct`)
- Network connectivity from Athena server to Ollama server

## Report Types

### Agent Status Report (`reports_agents.py`)
Dedicated report listing all agents with status (active/inactive, last seen) and a vulnerability summary:
- Vulnerability-related alerts from `rule.groups` (vulnerability, vulnerability-detector)
- Severity breakdown (Critical/High/Medium/Low from rule.level)
- Top affected rules and CVEs per agent
- Dashboard links via `buildAgentUrl` and `buildDashboardUrl`

```bash
python reports_agents.py daily
python reports_agents.py weekly
```

### Compliance Reports (`reports_compliance.py`)
Per-standard compliance reports: one report per enabled framework per Client:
- PCI DSS, GDPR, HIPAA, NIST 800-53, TSC (each gets its own email when enabled)
- Enable/disable via `COMPLIANCE_ENABLE_*` env vars or `complianceConfig` dict
- AI-generated compliance insights per framework using Ollama

```bash
python reports_compliance.py daily
python reports_compliance.py weekly
python reports_compliance.py monthly
```

### SIEM Reports (`reports_siem.py`)
Daily/weekly aggregated SIEM alert statistics with AI-powered executive summary:
- Alert severity breakdown, top agents, top rules, MITRE ATT&CK tactics
- Vulnerability summary with top CVEs and affected systems
- Period-over-period comparison trends
- AI analysis includes key findings, threat landscape, recommendations, and risk rating
- AI `trend_summary` — dedicated period-over-period trend analysis with specific numbers
- AI `threat_landscape` — attack patterns, MITRE tactics, and threat trends analysis
- AI `positive_observations` — security improvements and positive trends

```bash
python reports_siem.py daily
python reports_siem.py weekly
```

### Suricata/NIDS Reports (`reports_suricata.py`)
Aggregated Suricata network IDS alert statistics:
- Alert breakdown by severity, category, protocol
- Top source/destination IPs, top signatures
- Network traffic distribution (TCP, UDP, DNS, HTTP, TLS)
- AI `threat_landscape` — network threat landscape analysis
- AI `positive_observations` — positive security observations
- AI analysis disabled by default (`OLLAMA_ENABLED=false`)

```bash
python reports_suricata.py daily
python reports_suricata.py weekly
```

## Environment Configuration

Copy `.env.example` to `.env` and configure:

```bash
cp .env.example .env
nano .env
```

### Required Variables

| Variable | Description |
|----------|-------------|
| `ES_HOST` | Elasticsearch/OpenSearch URL |
| `ES_USERNAME` | Elasticsearch username |
| `ES_PASSWORD` | Elasticsearch password |
| `SMTP_HOST` | SMTP server |
| `SMTP_USERNAME` | SMTP username |
| `SMTP_PASSWORD` | SMTP password |
| `SMTP_RECIPIENT` | Email recipient(s), comma-separated |
| `OLLAMA_HOST` | Ollama server IP/hostname |

## Installation

Reports are typically scheduled via cron. Use the provided `install.sh` script:

```bash
./install.sh
```
