#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import json
import sys
import time
import os
import smtplib
import html
import re
import requests
from datetime import datetime, timezone, timedelta
from email.message import EmailMessage
from email.utils import formataddr
from dotenv import load_dotenv
from collections import defaultdict

load_dotenv()

# === CONFIGURATION FROM ENVIRONMENT ===
ATHENA_NAME = os.getenv("ATHENA_NAME", "Athena SOC")
TENANT_NAME = os.getenv("TENANT_NAME", "test.athenasecuritygrp.com")
ATHENA_WEBSITE = os.getenv("ATHENA_WEBSITE", "https://athenasoftwaregroup.ai/")
ATHENA_DOCS = os.getenv("ATHENA_DOCS", "https://athenasoftwaregroup.ai/")
ATHENA_SUPPORT = os.getenv("ATHENA_SUPPORT", "alerts@athena.athenasecuritygrp.com")
DASHBOARD_BASE_URL = os.getenv("DASHBOARD_BASE_URL", "https://test.athenasecuritygrp.com")

# === SMTP CONFIGURATION ===
SMTP_HOST = os.getenv("SMTP_HOST", "smtp.office365.com")
SMTP_PORT = int(os.getenv("SMTP_PORT", "587"))
SMTP_USE_TLS = os.getenv("SMTP_USE_TLS", "true").lower() == "true"
SMTP_USE_SSL = os.getenv("SMTP_USE_SSL", "false").lower() == "true"
SMTP_USERNAME = os.getenv("SMTP_USERNAME", "alerts@athenasoftwaregrp.com")
SMTP_PASSWORD = os.getenv("SMTP_PASSWORD", "")
SMTP_FROM = os.getenv("SMTP_FROM", "alerts@athena.athenasecuritygrp.com")
SMTP_RECIPIENT = os.getenv("SMTP_RECIPIENT", "secops@athena.athenasecuritygrp.com").split(",")

# === OLLAMA CONFIGURATION ===
OLLAMA_HOST = os.getenv("OLLAMA_HOST", "localhost")
OLLAMA_PORT = os.getenv("OLLAMA_PORT", "11434")
OLLAMA_MODEL = os.getenv("OLLAMA_MODEL", "qwen2.5:14b-instruct")
OLLAMA_ENABLED = os.getenv("OLLAMA_ENABLED", "true").lower() == "true"
OLLAMA_API_URL = f"http://{OLLAMA_HOST}:{OLLAMA_PORT}/v1/chat/completions"

# === AGELIA MUTE CHECK ===
AGELIA_API_URL      = os.getenv("AGELIA_API_URL", "")
INTEGRATION_API_KEY = os.getenv("INTEGRATION_API_KEY", "")
MUTE_CHECK_ENABLED  = os.getenv("MUTE_CHECK_ENABLED", "true").lower() == "true"
MUTE_CHECK_TIMEOUT  = int(os.getenv("MUTE_CHECK_TIMEOUT_SECONDS", "3"))

# === OPENSEARCH CONFIGURATION ===
OS_URL = os.getenv("ES_HOST", "https://localhost:9200")
OS_USER = os.getenv("ES_USERNAME", "elastic")
OS_PASS = os.getenv("ES_PASSWORD", "elastic")
OS_VERIFY_TLS = os.getenv("ES_VERIFY_SSL", "false").lower() == "true"
INDEX_PATTERNS = [os.getenv("ES_INDEX_PATTERN_SURICATA", "suricata-*")]

# === LOGGING ===
pwd = os.path.dirname(os.path.realpath(__file__))
log_file = f"{pwd}/logs/athena-suricata-email-notifier.log"
STATE_DIR = f"{pwd}/athena-notifier-nids"
STATE_FILE = os.path.join(STATE_DIR, "suricata-email-notifier.state.json")

def log(msg: str):
    now = time.strftime("%a %b %d %H:%M:%S %Z %Y")
    line = f"{now}: {msg}\n"
    print(line, end="")
    try:
        os.makedirs(os.path.dirname(log_file), exist_ok=True)
        with open(log_file, "a") as f:
            f.write(line)
    except Exception:
        pass

def is_nids_alert_muted(hit: dict) -> bool:
    """Check Agelia mute rules before sending. Fails open (returns False) on any error."""
    if not MUTE_CHECK_ENABLED or not AGELIA_API_URL or not INTEGRATION_API_KEY:
        return False
    try:
        src = hit.get('_source', hit)
        alert_block = src.get('alert', {})
        sig_id = alert_block.get('signature_id') or alert_block.get('gid')
        raw_sev = alert_block.get('severity')
        normalized_severity = {1: 'critical', 2: 'high', 3: 'medium', 4: 'low'}.get(
            int(raw_sev) if raw_sev is not None else 0, 'low'
        )
        payload = {
            'id':                   src.get('_id') or hit.get('_id', ''),
            'signature_id':         sig_id,
            'src_ip':               src.get('src_ip'),
            'dest_ip':              src.get('dest_ip'),
            'normalized_severity':  normalized_severity,
            'category':             alert_block.get('category', ''),
            'agent_name':           (src.get('agent') or {}).get('name', ''),
        }
        resp = requests.post(
            f"{AGELIA_API_URL}/api/integrations/alerts/check-mute",
            json=payload,
            headers={'X-Integration-Key': INTEGRATION_API_KEY},
            timeout=MUTE_CHECK_TIMEOUT,
        )
        if resp.status_code == 200:
            data = resp.json().get('data', {})
            if data.get('muted'):
                log(f"Alert {payload.get('signature_id', 'unknown')} suppressed by mute rule")
                return True
    except Exception as e:
        log(f"Mute check failed (failing open): {e}")
    return False


def ensure_dirs():
    os.makedirs(STATE_DIR, exist_ok=True)
    os.makedirs(os.path.dirname(log_file), exist_ok=True)

def load_state():
    if not os.path.exists(STATE_FILE):
        return {"last_ts": None}
    try:
        with open(STATE_FILE) as f:
            return json.load(f)
    except Exception:
        return {"last_ts": None}

def save_state(state):
    tmp = STATE_FILE + ".tmp"
    try:
        os.makedirs(os.path.dirname(STATE_FILE), exist_ok=True)
        with open(tmp, "w") as f:
            json.dump(state, f, indent=2)
        os.replace(tmp, STATE_FILE)
        log(f"State saved successfully: {state}")
    except Exception as e:
        log(f"Error saving state: {e}")
        import traceback
        log(traceback.format_exc())
        raise

def iso_now():
    return datetime.now(timezone.utc).isoformat()

def build_query(last_ts=None):
    BASE_MUST = [
        {"term": {"event.type": "suricata"}},
        {"term": {"event.subtype": "alert"}},
        {"terms": {"alert.severity": [1, 2]}}
    ]
    if last_ts:
        time_filter = {"range": {"@timestamp": {"gt": last_ts}}}
    else:
        time_filter = {"range": {"@timestamp": {"gte": "now-5m"}}}
    return {
        "size": 200,
        "query": {"bool": {"must": BASE_MUST + [time_filter]}},
        "sort": [{"@timestamp": "asc"}]
    }

def os_search(body):
    url = f"{OS_URL}/{','.join(INDEX_PATTERNS)}/_search"
    if not OS_VERIFY_TLS:
        import urllib3
        urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
    print(url)
    r = requests.post(url, auth=(OS_USER, OS_PASS), json=body, verify=OS_VERIFY_TLS, timeout=30)
    r.raise_for_status()
    return r.json()

def gf(d, path, default=None):
    """Get nested dict value by path"""
    cur = d
    for k in path:
        if not isinstance(cur, dict) or k not in cur:
            return default
        cur = cur[k]
    return cur

def sev_label(n):
    """Convert Suricata severity number to label (1=Critical, 2=High, 3=Medium, 4=Low)"""
    try:
        n = int(n)
    except Exception:
        return "unknown"
    return {1: "critical", 2: "high", 3: "medium", 4: "low"}.get(n, "unknown")

def get_severity_color(sev):
    """Get color for severity badge"""
    sev_lower = sev.lower()
    return {
        "critical": "#e53935",
        "high": "#fb8c00",
        "medium": "#fdd835",
        "low": "#43a047",
        "notice": "#43a047",  # legacy alias
        "warning": "#fdd835"  # legacy alias
    }.get(sev_lower, "#757575")

def is_present(v):
    return v not in (None, "", "N/A", "-")

def sanitize_for_subject(text: str, max_len: int = 80) -> str:
    if not text:
        return ""
    t = " ".join(str(text).split())
    return (t[:max_len] + "…") if len(t) > max_len else t

def build_dashboard_url(filters=None, time_from=None, time_to=None):
    """
    Build OpenSearch Dashboard Discover URL with KQL query filters.
    
    Args:
        filters: List of dicts with 'field' and 'value' keys for KQL filters
        time_from: Start time (ISO format), defaults to 1 hour before now
        time_to: End time (ISO format), defaults to now
    
    Returns:
        URL string for OpenSearch Dashboard Discover view
    """
    from urllib.parse import quote
    
    base = f"{DASHBOARD_BASE_URL}/app/data-explorer/discover#"
    index_pattern = INDEX_PATTERNS[0] if INDEX_PATTERNS else "suricata-*"
    
    # Default time range: last 1 hour
    if not time_from or not time_to:
        now = datetime.now(timezone.utc)
        time_to = now.isoformat()
        time_from = (now - timedelta(hours=1)).isoformat()
    
    # Normalize time format - ensure it has timezone info
    if time_from and not ('+' in time_from or time_from.endswith('Z')):
        time_from = time_from + '+00:00'
    if time_to and not ('+' in time_to or time_to.endswith('Z')):
        time_to = time_to + '+00:00'
    
    # Replace Z with +00:00 for consistency
    time_from = time_from.replace('Z', '+00:00')
    time_to = time_to.replace('Z', '+00:00')
    
    # Build KQL query from filters
    kql_parts = []
    if filters:
        for f in filters:
            field = f.get("field", "")
            value = f.get("value", "")
            if field and value and value != "-" and value != "N/A":
                # Escape special characters for KQL - need to escape quotes and backslashes
                value_escaped = str(value).replace('\\', '\\\\').replace('"', '\\"')
                kql_parts.append(f'{field}:"{value_escaped}"')
    
    kql_query = " AND ".join(kql_parts) if kql_parts else ""
    
    # Build URL parameters
    # _g: global time range
    time_from_escaped = time_from.replace("'", "\\'")
    time_to_escaped = time_to.replace("'", "\\'")
    _g = f"(time:(from:'{time_from_escaped}',to:'{time_to_escaped}'))"
    
    # _a: application state with discover columns and metadata
    _a = f"(discover:(columns:!(_source)),metadata:(indexPattern:'{index_pattern}',view:discover))"
    
    # _q: query with KQL
    if kql_query:
        # Escape single quotes in KQL query for Rison encoding
        kql_escaped = kql_query.replace("'", "\\'")
        _q = f"(query:(language:kuery,query:'{kql_escaped}'))"
    else:
        _q = "(query:(language:kuery,query:''))"
    
    # Build final URL - URL encode the parameters
    params = {
        "_g": _g,
        "_a": _a,
        "_q": _q
    }
    
    url = base + "?" + "&".join([f"{k}={quote(v, safe='')}" for k, v in params.items()])
    return url

# === OLLAMA INTEGRATION ===
def get_ai_analysis(alerts_context: list) -> dict:
    """
    Call Ollama API to analyze Suricata NIDS alerts and provide comprehensive assessment.
    This function analyzes multiple alerts together to provide overall threat assessment.
    """
    if not OLLAMA_ENABLED:
        log("Ollama analysis disabled")
        return None
    
    try:
        # Prepare context from all alerts
        alerts_summary = []
        for ctx in alerts_context:
            alerts_summary.append({
                "signature": ctx.get("signature", "N/A"),
                "signature_id": ctx.get("signature_id", "N/A"),
                "severity": ctx.get("severity", "N/A"),
                "category": ctx.get("category", "N/A"),
                "action": ctx.get("action", "N/A"),
                "timestamp": ctx.get("timestamp", "N/A"),
                "attacker_ip": ctx.get("attacker_ip", "N/A"),
                "source_ip": ctx.get("source_ip", "N/A"),
                "dest_ip": ctx.get("dest_ip", "N/A"),
                "source_port": ctx.get("source_port", "N/A"),
                "dest_port": ctx.get("dest_port", "N/A"),
                "protocol": ctx.get("protocol", "N/A"),
                "app_proto": ctx.get("app_proto", "N/A"),
                "hostname": ctx.get("hostname", "N/A"),
                "server_hostname": ctx.get("server_hostname", "N/A"),
                "user_agent": ctx.get("user_agent", "N/A"),
                "http_status": ctx.get("http_status", "N/A"),
                "http_url": ctx.get("http_url", "N/A"),
                "http_context": ctx.get("http_context", "N/A"),
                "destination_context": ctx.get("destination_context", "N/A"),
                "flow_info": ctx.get("flow_info", "N/A"),
                "tunnel_info": ctx.get("tunnel_info", "N/A")
            })
        
        # Count alerts by signature - MUST be defined before prompt
        sig_counts = defaultdict(int)
        for ctx in alerts_context:
            sig_counts[ctx.get("signature", "Unknown")] += 1
        
        # Build alert details string separately to avoid quote issues
        alert_details_lines = []
        for i, ctx in enumerate(alerts_context[:10]):
            sig = ctx.get('signature', 'N/A')
            sig_id = ctx.get('signature_id', 'N/A')
            sev = ctx.get('severity', 'N/A')
            cat = ctx.get('category', 'N/A')
            action = ctx.get('action', 'N/A')
            src_ip = ctx.get('source_ip', 'N/A')
            src_port = ctx.get('source_port', 'N/A')
            dst_ip = ctx.get('dest_ip', 'N/A')
            dst_port = ctx.get('dest_port', 'N/A')
            proto = ctx.get('protocol', 'N/A')
            app_proto = ctx.get('app_proto', 'N/A')
            http_ctx = ctx.get('http_context', 'N/A')
            dest_ctx = ctx.get('destination_context', 'N/A')
            flow_info = ctx.get('flow_info', 'N/A')
            attacker_ip = ctx.get('attacker_ip', 'N/A')
            hostname = ctx.get('hostname', 'N/A')
            user_agent = ctx.get('user_agent', 'N/A')
            
            server_hostname = ctx.get('server_hostname', 'N/A')
            http_status = ctx.get('http_status', 'N/A')
            http_url = ctx.get('http_url', 'N/A')
            tunnel_info = ctx.get('tunnel_info', 'N/A')
            
            details = f"Alert {i+1}: {sig} (ID: {sig_id}) - Severity: {sev} - Category: {cat} - Action: {action}"
            details += f"\n  Timestamp: {ctx.get('timestamp', 'N/A')}"
            details += f"\n  Attacker IP (XFF - Actual Source): {attacker_ip}"
            details += f"\n  Internal Source IP: {src_ip}:{src_port} -> Destination: {dst_ip}:{dst_port}"
            details += f"\n  Protocol: {proto}"
            if app_proto != 'N/A':
                details += f" / Application Protocol: {app_proto}"
            details += f"\n  Hostname/Agent (Sensor): {hostname}"
            if server_hostname != 'N/A':
                details += f"\n  Server Hostname (Target): {server_hostname}"
            if http_status != 'N/A':
                details += f"\n  HTTP Status Code: {http_status}"
            if http_url != 'N/A':
                details += f"\n  HTTP URL: {http_url}"
            if user_agent != 'N/A':
                details += f"\n  User-Agent: {user_agent}"
            if http_ctx != 'N/A':
                details += f"\n  HTTP Context: {http_ctx}"
            if dest_ctx != 'N/A':
                details += f"\n  Destination Context: {dest_ctx}"
            if flow_info != 'N/A':
                details += f"\n  Flow Info: {flow_info}"
            if tunnel_info != 'N/A':
                details += f"\n  Tunnel/VXLAN Info: {tunnel_info}"
            
            alert_details_lines.append(details)
        
        alert_details_text = chr(10).join(alert_details_lines)
        
        # Adjust prompt based on number of alerts
        if len(alerts_context) == 1:
            # Single alert analysis
            ctx = alerts_context[0]
            prompt = f"""You are a cybersecurity analyst for Athena SOC specializing in network intrusion detection. 
Analyze the following Suricata NIDS (Network Intrusion Detection System) alert generated by the Suricata plugin on Wazuh.

**IMPORTANT CONTEXT:**
- This alert is generated by Suricata NIDS plugin integrated with Wazuh security platform
- Suricata is a network intrusion detection and prevention system (IDS/IPS)
- This alert represents a network traffic anomaly or potential security threat detected at the network layer
- **CRITICAL**: The "Attacker IP (XFF)" field contains the ACTUAL attacker source IP address from the X-Forwarded-For header. This is the real external IP of the attacker, not the internal load balancer IP. Use this for attacker attribution and threat intelligence.
- **NIDS Severity Scale** (use for recommended_priority and risk assessment): 1=Critical, 2=High, 3=Medium. Align your recommended_priority with this scale (e.g., severity 2 = High priority, not Critical).

**Alert Details:**
- Event Timestamp: {ctx.get('timestamp', 'N/A')}
- Signature: {ctx.get('signature', 'N/A')}
- Signature ID: {ctx.get('signature_id', 'N/A')}
- Severity Level: {ctx.get('severity', 'N/A')}
- Rule Category: {ctx.get('category', 'N/A')}
- Action: {ctx.get('action', 'N/A')}
- **Attacker Source IP (XFF - Actual Attacker)**: {ctx.get('attacker_ip', 'N/A')}
- Internal Source IP: {ctx.get('source_ip', 'N/A')}:{ctx.get('source_port', 'N/A')}
- Destination IP: {ctx.get('dest_ip', 'N/A')}:{ctx.get('dest_port', 'N/A')}
- Protocol: {ctx.get('protocol', 'N/A')}
- Application Protocol: {ctx.get('app_proto', 'N/A')}
- Hostname/Agent (Sensor): {ctx.get('hostname', 'N/A')}
- Server Hostname (Target): {ctx.get('server_hostname', 'N/A')}
- User-Agent: {ctx.get('user_agent', 'N/A')}
- HTTP Status Code: {ctx.get('http_status', 'N/A')}
- HTTP URL: {ctx.get('http_url', 'N/A')}
- HTTP Context: {ctx.get('http_context', 'N/A')}
- Destination Context: {ctx.get('destination_context', 'N/A')}
- Flow Information: {ctx.get('flow_info', 'N/A')}
- Tunnel/VXLAN Information: {ctx.get('tunnel_info', 'N/A')}

**ANALYSIS INSTRUCTIONS:**
1. **Attacker Attribution**: Focus on the "Attacker IP (XFF)" field as the primary source for identifying the actual attacker. This IP should be used for threat intelligence lookups, reputation checks, and blocking recommendations.
2. **Attack Success Assessment**: The HTTP Status Code is critical - 200 indicates successful request, 403/404 may indicate blocked/failed attempts, 500+ indicates server errors. Use this to assess attack effectiveness.
3. **Threat Assessment**: Analyze the combination of signature, attacker IP, user-agent, destination, and HTTP status to assess the threat level and potential attack vectors.
4. **Network Topology**: Consider tunnel/VXLAN information to understand network architecture and actual traffic paths. Server hostname shows the actual target server.
5. **Traffic Analysis**: Use detailed flow information (bytes/packets to/from server/client) to understand attack volume and data exfiltration potential.
6. **IOC Extraction**: Extract all relevant indicators including the attacker IP, user-agent patterns, HTTP URLs, and any payload indicators from the HTTP context.

Provide your analysis in the following JSON format:
{{
    "executive_summary": "2-3 sentence overview of this network security alert and threat assessment, emphasizing the attacker IP (XFF) and key threat indicators",
    "detailed_analysis": "Detailed explanation of what network activity was detected, why it's significant from a network security perspective, potential attack vectors, and impact on network infrastructure. Include analysis of the attacker IP (XFF) and any threat intelligence insights",
    "mitigation_steps": ["Step 1", "Step 2", "Step 3", ...],
    "risk_assessment": "Assessment of the risk level to network infrastructure and potential business impact",
    "indicators_of_compromise": ["IOC 1 (include attacker IP XFF)", "IOC 2 (user-agent patterns)", "IOC 3 (signature patterns)", ...] or null if none,
    "recommended_priority": "Immediate/High/Medium/Low - MUST align with NIDS severity (1=Immediate/Critical, 2=High, 3=Medium)",
    "false_positive_likelihood": "High/Medium/Low — brief justification for why this alert may or may not be a false positive based on signature, traffic pattern, and context",
    "confidence_level": "High/Medium/Low — how confident the analysis is given the available data quality and context",
    "network_insights": "Specific insights about this network traffic pattern, potential attack chain, or suspicious network behavior. Include observations about attacker attribution and attack methodology"
}}

Be specific, actionable, and network security-focused. Focus on practical network defense guidance and accurate attacker attribution using the XFF field."""
        else:
            # Multiple alerts analysis (for reference, though we'll send individually)
            prompt = f"""You are a cybersecurity analyst for Athena SOC specializing in network intrusion detection. 
Analyze the following Suricata NIDS (Network Intrusion Detection System) alerts generated by the Suricata plugin on Wazuh.

**IMPORTANT CONTEXT:**
- These alerts are generated by Suricata NIDS plugin integrated with Wazuh security platform
- Suricata is a network intrusion detection and prevention system (IDS/IPS)
- The alerts represent network traffic anomalies and potential security threats detected at the network layer
- **CRITICAL**: The "attacker_ip" field (XFF) contains the ACTUAL attacker source IP addresses from the X-Forwarded-For header. These are the real external IPs of the attackers, not internal load balancer IPs. Use these for attacker attribution and threat intelligence.
- **NIDS Severity Scale** (use for recommended_priority and risk assessment): 1=Critical, 2=High, 3=Medium. When multiple alerts have different severities, base overall priority on the highest severity. Align recommended_priority with this scale.

**Alert Summary:**
Total alerts detected: {len(alerts_context)}

**Alert Breakdown by Signature:**
{chr(10).join([f"- {sig}: {count} occurrence(s)" for sig, count in sig_counts.items()])}

**Detailed Alert Information:**
{json.dumps(alerts_summary, indent=2)}

**Alert Details:**
{alert_details_text}

**ANALYSIS INSTRUCTIONS:**
1. **Attacker Attribution**: Focus on the "Attacker IP (XFF)" fields as the primary source for identifying actual attackers. These IPs should be used for threat intelligence lookups, reputation checks, and blocking recommendations.
2. **Pattern Analysis**: Look for patterns across multiple alerts - same attacker IPs, similar user-agents, coordinated attacks, etc.
3. **Correlation Analysis**: Identify relationships between the batched alerts: common attacker IPs, campaign patterns, sequential attack stages, or coordinated activity. Determine if these alerts represent a single campaign or unrelated events.
4. **Threat Assessment**: Analyze the combination of signatures, attacker IPs, user-agents, and destinations to assess the overall threat level and potential attack campaigns.
5. **IOC Extraction**: Extract all relevant indicators including attacker IPs, user-agent patterns, signature patterns, and any payload indicators.

Provide your analysis in the following JSON format:
{{
    "executive_summary": "2-3 sentence overview of the network security alerts and overall threat assessment, emphasizing attacker IPs (XFF) and key threat patterns",
    "detailed_analysis": "Detailed explanation of what network activity was detected, why it's significant from a network security perspective, potential attack vectors, and impact on network infrastructure. Include analysis of attacker IPs (XFF), attack patterns, and any threat intelligence insights",
    "mitigation_steps": ["Step 1", "Step 2", "Step 3", ...],
    "risk_assessment": "Assessment of the risk level to network infrastructure and potential business impact",
    "indicators_of_compromise": ["IOC 1 (attacker IPs from XFF)", "IOC 2 (user-agent patterns)", "IOC 3 (signature patterns)", ...] or null if none,
    "recommended_priority": "Immediate/High/Medium/Low - MUST align with highest NIDS severity across alerts (1=Immediate/Critical, 2=High, 3=Medium)",
    "false_positive_likelihood": "High/Medium/Low — brief justification for why these alerts may or may not be false positives based on signatures, traffic patterns, and context",
    "confidence_level": "High/Medium/Low — how confident the analysis is given the available data quality and context",
    "correlation_analysis": "Cross-alert pattern analysis: identify common attacker IPs, campaign patterns, sequential attack stages, or coordinated activity across the batched alerts",
    "network_insights": "Specific insights about network traffic patterns, potential attack chains, or suspicious network behavior. Include observations about attacker attribution, coordinated attacks, and attack methodology"
}}

Be specific, actionable, and network security-focused. Focus on practical network defense guidance and accurate attacker attribution using the XFF fields."""

        headers = {
            "Content-Type": "application/json"
        }

        payload = {
            "model": OLLAMA_MODEL,
            "messages": [
                {
                    "role": "system",
                    "content": "You are an expert cybersecurity analyst specializing in network intrusion detection, Suricata NIDS, and network security threat analysis. Provide clear, actionable network security assessments. If a data field is empty, null, or 'N/A', state that the information is unavailable — do not speculate or hallucinate. Return ONLY valid JSON. Do not include any text before or after the JSON object."
                },
                {
                    "role": "user",
                    "content": prompt
                }
            ],
            "temperature": 0.3,
            "max_tokens": 4096,
            "response_format": {"type": "json_object"}
        }

        log(f"Calling Ollama API at {OLLAMA_API_URL} with model {OLLAMA_MODEL} for {len(alerts_context)} alerts...")
        response = requests.post(
            OLLAMA_API_URL,
            headers=headers,
            json=payload,
            timeout=180
        )

        if response.status_code == 200:
            result = response.json()
            ai_content = result['choices'][0]['message']['content']
            ai_analysis = json.loads(ai_content)
            log("Ollama analysis completed successfully")
            return ai_analysis
        else:
            log(f"Ollama API error: {response.status_code} - {response.text}")
            return None
            
    except Exception as e:
        log(f"Error getting AI analysis: {e}")
        import traceback
        log(traceback.format_exc())
        return None

def extract_alert_context(hit):
    """Extract relevant context from Suricata alert for AI analysis"""
    s = hit.get("_source", {})
    
    # Basic alert info
    alert = s.get("alert", {}) or {}
    http = s.get("http", {}) or {}
    flow = s.get("flow", {}) or {}
    destination = s.get("destination", {}) or {}
    dest_geo = destination.get("geo", {}) or {}
    dest_as = destination.get("as", {}) or {}
    node = s.get("node", {}) or {}
    event = s.get("event", {}) or {}
    tunnel = s.get("tunnel", {}) or {}
    
    # Extract XFF (attacker source IP) - prefer http.xff, fallback to alert.xff
    attacker_ip = http.get("xff") or alert.get("xff") or "N/A"
    
    # Extract hostname/agent name - prefer node.hostname, fallback to event.host
    hostname = node.get("hostname") or event.get("host") or "N/A"
    
    # Extract server hostname (actual server being targeted, different from http.hostname)
    server_hostname = s.get("server_hostname") or s.get("dest_hostname") or "N/A"
    
    # Build HTTP context string
    http_context = ""
    if http:
        http_parts = []
        if http.get("hostname"):
            http_parts.append(f"Hostname: {http.get('hostname')}")
        if http.get("url"):
            http_parts.append(f"URL: {http.get('url')}")
        if http.get("http_method"):
            http_parts.append(f"Method: {http.get('http_method')}")
        if http.get("http_user_agent"):
            http_parts.append(f"User-Agent: {http.get('http_user_agent')}")
        if http.get("status"):
            http_parts.append(f"Status: {http.get('status')}")
        if http_parts:
            http_context = " | ".join(http_parts)
    
    # Build destination context
    dest_context = ""
    dest_parts = []
    if dest_geo.get("country_name"):
        dest_parts.append(f"Country: {dest_geo.get('country_name')}")
    if dest_as.get("organization", {}).get("name"):
        dest_parts.append(f"ASN: {dest_as.get('organization', {}).get('name')}")
    if dest_parts:
        dest_context = " | ".join(dest_parts)
    
    # Enhanced flow information with detailed metrics
    flow_info = ""
    if flow:
        flow_parts = []
        if flow.get("bytes"):
            flow_parts.append(f"Total Bytes: {flow.get('bytes')}")
        if flow.get("bytes_toserver"):
            flow_parts.append(f"Bytes to Server: {flow.get('bytes_toserver')}")
        if flow.get("bytes_toclient"):
            flow_parts.append(f"Bytes to Client: {flow.get('bytes_toclient')}")
        if flow.get("pkts"):
            flow_parts.append(f"Total Packets: {flow.get('pkts')}")
        if flow.get("pkts_toserver"):
            flow_parts.append(f"Packets to Server: {flow.get('pkts_toserver')}")
        if flow.get("pkts_toclient"):
            flow_parts.append(f"Packets to Client: {flow.get('pkts_toclient')}")
        if flow.get("state"):
            flow_parts.append(f"State: {flow.get('state')}")
        if flow_parts:
            flow_info = " | ".join(flow_parts)
    
    # Build tunnel/VXLAN metadata
    tunnel_info = ""
    if tunnel:
        tunnel_parts = []
        if tunnel.get("src_ip"):
            tunnel_parts.append(f"Tunnel Src: {tunnel.get('src_ip')}")
        if tunnel.get("dest_ip"):
            tunnel_parts.append(f"Tunnel Dest: {tunnel.get('dest_ip')}")
        if tunnel.get("proto"):
            tunnel_parts.append(f"Tunnel Proto: {tunnel.get('proto')}")
        if tunnel.get("depth"):
            tunnel_parts.append(f"Tunnel Depth: {tunnel.get('depth')}")
        if tunnel_parts:
            tunnel_info = " | ".join(tunnel_parts)
    
    return {
        "alert_id": hit.get("_id", "N/A"),  # OpenSearch document ID
        "signature": alert.get("signature", "Suricata alert"),
        "signature_id": alert.get("signature_id"),
        "severity": sev_label(alert.get("severity")),
        "severity_numeric": alert.get("severity"),
        "category": alert.get("category", "N/A"),
        "action": alert.get("action", "N/A"),
        "timestamp": s.get("@timestamp", iso_now()),
        "attacker_ip": attacker_ip,  # XFF - actual attacker IP
        "source_ip": s.get("src_ip", "N/A"),  # Internal source IP
        "dest_ip": s.get("dest_ip", "N/A"),
        "source_port": s.get("src_port", "N/A"),
        "dest_port": s.get("dest_port", "N/A"),
        "protocol": s.get("proto", "N/A"),
        "app_proto": s.get("app_proto", "N/A"),
        "hostname": hostname,  # Sensor/Node hostname
        "server_hostname": server_hostname,  # Actual server being targeted
        "user_agent": http.get("http_user_agent", "N/A"),
        "http_status": http.get("status", "N/A"),  # HTTP status code
        "http_url": http.get("url", "N/A"),  # Raw URL
        "http_context": http_context if http_context else "N/A",
        "destination_context": dest_context if dest_context else "N/A",
        "flow_info": flow_info if flow_info else "N/A",
        "tunnel_info": tunnel_info if tunnel_info else "N/A",
        "log_severity": s.get("log", {}).get("severity", "N/A")
    }

# === MESSAGE BUILDER ===
def generate_msg(alerts, ai_analysis=None):
    """Generate email message for multiple Suricata alerts"""
    alert_count = len(alerts)
    
    # Determine overall severity (highest severity found)
    severities = []
    for hit in alerts:
        s = hit.get("_source", {})
        sev = gf(s, ["alert", "severity"])
        if sev:
            severities.append(int(sev))
    
    max_severity = max(severities) if severities else 1
    overall_severity = sev_label(max_severity)
    sev_color = get_severity_color(overall_severity)
    
    # Subject
    if alert_count == 1:
        sig = gf(alerts[0].get("_source", {}), ["alert", "signature"], "Suricata Alert")
        subject = f"[{TENANT_NAME}] NIDS Alert - {sanitize_for_subject(sig, 60)}"
    else:
        subject = f"[{TENANT_NAME}] NIDS Alert - {alert_count} Network Security Alerts Detected"
    
    # === Plain text body ===
    plain_lines = []
    plain_lines.append(f"{ATHENA_NAME} — Automated NIDS Notification")
    plain_lines.append(f"Tenant: {TENANT_NAME}")
    plain_lines.append(f"Total Alerts: {alert_count}")
    plain_lines.append(f"Overall Severity: {overall_severity.upper()}")
    plain_lines.append("")
    plain_lines.append("This is an automated network intrusion detection alert generated by Athena SOC.")
    plain_lines.append("These alerts are generated by Suricata NIDS plugin on Wazuh.")
    plain_lines.append("")
    
    # Add AI Analysis if available
    if ai_analysis:
        plain_lines.append("═══════════════════════════════════════════════════════")
        plain_lines.append("🤖  Athena AI POWERED NETWORK SECURITY ANALYSIS")
        plain_lines.append("═══════════════════════════════════════════════════════")
        plain_lines.append("")
        
        if ai_analysis.get("executive_summary"):
            plain_lines.append("EXECUTIVE SUMMARY:")
            plain_lines.append(ai_analysis["executive_summary"])
            plain_lines.append("")
        
        if ai_analysis.get("detailed_analysis"):
            plain_lines.append("DETAILED ANALYSIS:")
            plain_lines.append(ai_analysis["detailed_analysis"])
            plain_lines.append("")
        
        if ai_analysis.get("risk_assessment"):
            plain_lines.append("RISK ASSESSMENT:")
            plain_lines.append(ai_analysis["risk_assessment"])
            plain_lines.append("")
        
        if ai_analysis.get("indicators_of_compromise"):
            plain_lines.append("INDICATORS OF COMPROMISE:")
            for ioc in ai_analysis["indicators_of_compromise"]:
                plain_lines.append(f"  • {ioc}")
            plain_lines.append("")
        
        if ai_analysis.get("network_insights"):
            plain_lines.append("NETWORK INSIGHTS:")
            plain_lines.append(ai_analysis["network_insights"])
            plain_lines.append("")

        if ai_analysis.get("correlation_analysis"):
            plain_lines.append("CORRELATION ANALYSIS:")
            plain_lines.append(ai_analysis["correlation_analysis"])
            plain_lines.append("")

        if ai_analysis.get("recommended_priority"):
            plain_lines.append(f"AI PRIORITY: {ai_analysis['recommended_priority']}")
            plain_lines.append("")

        if ai_analysis.get("false_positive_likelihood"):
            plain_lines.append(f"FALSE POSITIVE LIKELIHOOD: {ai_analysis['false_positive_likelihood']}")
            plain_lines.append("")

        if ai_analysis.get("confidence_level"):
            plain_lines.append(f"CONFIDENCE LEVEL: {ai_analysis['confidence_level']}")
            plain_lines.append("")

        plain_lines.append("═══════════════════════════════════════════════════════")
        plain_lines.append("")
    
    # Alert details
    plain_lines.append("ALERT DETAILS:")
    plain_lines.append("")
    for i, hit in enumerate(alerts, 1):
        s = hit.get("_source", {})
        alert = s.get("alert", {}) or {}
        http = s.get("http", {}) or {}
        node = s.get("node", {}) or {}
        event = s.get("event", {}) or {}
        
        ts = s.get("@timestamp", iso_now())
        sig = alert.get("signature", "Suricata alert")
        sid = alert.get("signature_id")
        sev = sev_label(alert.get("severity"))
        cat = alert.get("category", "-")
        proto = s.get("proto", "-")
        app_proto = s.get("app_proto")
        attacker_ip = http.get("xff") or alert.get("xff") or "-"
        src_ip = s.get("src_ip", "-")
        dst_ip = s.get("dest_ip", "-")
        src_prt = s.get("src_port", "-")
        dst_prt = s.get("dest_port", "-")
        hostname = node.get("hostname") or event.get("host") or "-"
        user_agent = http.get("http_user_agent", "-")
        
        plain_lines.append(f"Alert #{i}:")
        server_hostname = s.get("server_hostname") or s.get("dest_hostname") or "-"
        http_status = http.get("status", "-")
        http_url = http.get("url", "-")
        flow = s.get("flow", {}) or {}
        tunnel = s.get("tunnel", {}) or {}
        alert_id = hit.get("_id", "-")
        
        plain_lines.append(f"  Alert ID: {alert_id}")
        plain_lines.append(f"  Event Time (UTC): {ts}")
        plain_lines.append(f"  Signature: {sig}")
        plain_lines.append(f"  Signature ID: {sid or '-'}")
        plain_lines.append(f"  Severity: {sev}")
        plain_lines.append(f"  Category: {cat}")
        proto_display = proto
        if app_proto:
            proto_display += f" ({app_proto})"
        plain_lines.append(f"  Protocol: {proto_display}")
        plain_lines.append(f"  Attacker Source IP (XFF): {attacker_ip}")
        plain_lines.append(f"  Internal Source IP: {src_ip}:{src_prt}")
        plain_lines.append(f"  Destination IP: {dst_ip}:{dst_prt}")
        plain_lines.append(f"  Hostname/Agent (Sensor): {hostname}")
        if server_hostname != "-":
            plain_lines.append(f"  Server Hostname (Target): {server_hostname}")
        if http_status != "-":
            plain_lines.append(f"  HTTP Status Code: {http_status}")
        if http_url != "-":
            plain_lines.append(f"  HTTP URL: {http_url}")
        if user_agent != "-":
            plain_lines.append(f"  User-Agent: {user_agent}")
        if flow:
            flow_parts = []
            if flow.get("bytes"):
                flow_parts.append(f"Total: {flow.get('bytes')} bytes")
            if flow.get("pkts"):
                flow_parts.append(f"{flow.get('pkts')} packets")
            if flow.get("bytes_toserver"):
                flow_parts.append(f"To Server: {flow.get('bytes_toserver')} bytes")
            if flow.get("bytes_toclient"):
                flow_parts.append(f"To Client: {flow.get('bytes_toclient')} bytes")
            if flow_parts:
                plain_lines.append(f"  Flow Information: {' | '.join(flow_parts)}")
        if tunnel:
            tunnel_parts = []
            if tunnel.get("src_ip"):
                tunnel_parts.append(f"Tunnel Src: {tunnel.get('src_ip')}")
            if tunnel.get("dest_ip"):
                tunnel_parts.append(f"Tunnel Dest: {tunnel.get('dest_ip')}")
            if tunnel.get("proto"):
                tunnel_parts.append(f"Tunnel Proto: {tunnel.get('proto')}")
            if tunnel_parts:
                plain_lines.append(f"  Tunnel/VXLAN: {' | '.join(tunnel_parts)}")
        plain_lines.append("")
    
    plain_lines.append("────────────────────────────────────────────────────────")
    plain_lines.append("Athena Security Group")
    plain_lines.append(f"Website: {ATHENA_WEBSITE}")
    plain_lines.append(f"Docs: {ATHENA_DOCS}")
    plain_lines.append(f"Support: {ATHENA_SUPPORT}")
    plain_lines.append("")
    plain_lines.append(f"This message was generated automatically by {ATHENA_NAME}.")
    plain_lines.append("Do not reply to this email.")
    plain = "\n".join(plain_lines).strip()
    
    # === HTML body ===
    def html_row(label, value):
        return f"<tr><td style='padding:6px 8px;width:180px;color:#555;'><strong>{label}</strong></td><td style='padding:6px 8px;color:#222;'>{html.escape(str(value))}</td></tr>"
    
    def html_row_link(label, value, dashboard_url):
        """HTML row with clickable value that links to dashboard"""
        if dashboard_url:
            link_html = f"<a href='{html.escape(dashboard_url)}' style='color:#0d47a1;text-decoration:none;'>{html.escape(str(value))}</a>"
            return f"<tr><td style='padding:6px 8px;width:180px;color:#555;'><strong>{label}</strong></td><td style='padding:6px 8px;color:#222;'>{link_html}</td></tr>"
        else:
            return html_row(label, value)
    
    def html_row_raw(label, value):
        """HTML row that doesn't escape HTML (for links)"""
        return f"<tr><td style='padding:6px 8px;width:180px;color:#555;'><strong>{label}</strong></td><td style='padding:6px 8px;color:#222;'>{value}</td></tr>"

    # Build AI analysis HTML section
    ai_html = ""
    priority_badge = ""  # Initialize priority badge variable
    
    if ai_analysis:
        # Extract priority badge first (before building AI HTML)
        if ai_analysis.get("recommended_priority"):
            priority_color = {
                "Immediate": "#e53935",
                "High": "#fb8c00",
                "Medium": "#fdd835",
                "Low": "#43a047"
            }.get(ai_analysis["recommended_priority"], "#757575")
            
            priority_badge = f"""
    <span style="background:{priority_color};color:#fff;padding:4px 12px;border-radius:12px;font-size:13px;font-weight:600;white-space:nowrap;">
      AI Priority: {html.escape(ai_analysis['recommended_priority'])}
    </span>
"""
        
        ai_html = """
<div style="background:#f0f9ff;border-left:4px solid #0d47a1;padding:16px;margin:16px 0;border-radius:4px;">
  <h3 style="margin:0 0 12px 0;color:#0d47a1;font-size:16px;">🤖 Athena AI: Network Security Analysis</h3>
"""
        
        if ai_analysis.get("executive_summary"):
            ai_html += f"""
  <div style="margin-bottom:12px;">
    <strong style="color:#333;">Executive Summary:</strong>
    <p style="margin:4px 0;color:#555;line-height:1.6;">{html.escape(ai_analysis['executive_summary'])}</p>
  </div>
"""
        
        if ai_analysis.get("detailed_analysis"):
            ai_html += f"""
  <div style="margin-bottom:12px;">
    <strong style="color:#333;">Detailed Analysis:</strong>
    <p style="margin:4px 0;color:#555;line-height:1.6;">{html.escape(ai_analysis['detailed_analysis'])}</p>
  </div>
"""
        
        if ai_analysis.get("risk_assessment"):
            ai_html += f"""
  <div style="margin-bottom:12px;">
    <strong style="color:#333;">Risk Assessment:</strong>
    <p style="margin:4px 0;color:#555;line-height:1.6;">{html.escape(ai_analysis['risk_assessment'])}</p>
  </div>
"""
        
        if ai_analysis.get("indicators_of_compromise"):
            ai_html += """
  <div style="margin-bottom:12px;">
    <strong style="color:#333;">Indicators of Compromise:</strong>
    <ul style="margin:4px 0;padding-left:20px;color:#555;">
"""
            for ioc in ai_analysis["indicators_of_compromise"]:
                ai_html += f"      <li style='margin:4px 0;font-family:monospace;'>{html.escape(ioc)}</li>\n"
            ai_html += "    </ul>\n  </div>\n"
        
        if ai_analysis.get("network_insights"):
            ai_html += f"""
  <div style="margin-bottom:12px;">
    <strong style="color:#333;">Network Insights:</strong>
    <p style="margin:4px 0;color:#555;line-height:1.6;">{html.escape(ai_analysis['network_insights'])}</p>
  </div>
"""
        if ai_analysis.get("correlation_analysis"):
            ai_html += f"""
  <div style="margin-bottom:12px;background:#eff6ff;padding:10px;border-radius:4px;border-left:3px solid #2563eb;">
    <strong style="color:#1e40af;">Correlation Analysis:</strong>
    <p style="margin:4px 0;color:#1e293b;line-height:1.6;">{html.escape(ai_analysis['correlation_analysis'])}</p>
  </div>
"""
        # False Positive Likelihood + Confidence Level badges
        fp_conf_badges = ""
        if ai_analysis.get("false_positive_likelihood"):
            fp_value = ai_analysis["false_positive_likelihood"].split("—")[0].split("-")[0].strip()
            fp_color = {"High": "#22c55e", "Medium": "#facc15", "Low": "#dc2626"}.get(fp_value, "#6b7280")
            fp_conf_badges += f"<span style='display:inline-block;background:{fp_color};color:#fff;padding:4px 10px;border-radius:12px;font-size:12px;font-weight:600;margin-right:8px;'>FP Likelihood: {html.escape(ai_analysis['false_positive_likelihood'])}</span>"
        if ai_analysis.get("confidence_level"):
            cl_value = ai_analysis["confidence_level"].split("—")[0].split("-")[0].strip()
            cl_color = {"High": "#22c55e", "Medium": "#facc15", "Low": "#dc2626"}.get(cl_value, "#6b7280")
            fp_conf_badges += f"<span style='display:inline-block;background:{cl_color};color:#fff;padding:4px 10px;border-radius:12px;font-size:12px;font-weight:600;'>Confidence: {html.escape(ai_analysis['confidence_level'])}</span>"
        if fp_conf_badges:
            ai_html += f"""
  <div style="margin-top:12px;">
    {fp_conf_badges}
  </div>
"""

        # Priority badge removed from here - it's now in the header
        ai_html += "</div>\n"
    
    # Build alerts table
    if alert_count == 1:
        # Single alert - detailed view
        s = alerts[0].get("_source", {})
        alert = s.get("alert", {}) or {}
        http = s.get("http", {}) or {}
        destination = s.get("destination", {}) or {}
        dest_geo = destination.get("geo", {}) or {}
        dest_as = destination.get("as", {}) or {}
        node = s.get("node", {}) or {}
        event = s.get("event", {}) or {}
        
        ts = s.get("@timestamp", iso_now())
        alert_id = alerts[0].get("_id", "-")
        sig = alert.get("signature", "Suricata alert")
        sid = alert.get("signature_id")
        sev = sev_label(alert.get("severity"))
        cat = alert.get("category")
        action = alert.get("action")
        proto = s.get("proto", "-")
        app_proto = s.get("app_proto")
        attacker_ip = http.get("xff") or alert.get("xff") or "-"
        src_ip = s.get("src_ip", "-")
        dst_ip = s.get("dest_ip", "-")
        src_prt = s.get("src_port", "-")
        dst_prt = s.get("dest_port", "-")
        hostname = node.get("hostname") or event.get("host") or "-"
        server_hostname = s.get("server_hostname") or s.get("dest_hostname") or "-"
        user_agent = http.get("http_user_agent", "-")
        http_status = http.get("status", "-")
        http_url = http.get("url", "-")
        tunnel = s.get("tunnel", {}) or {}
        
        # Build HTTP context display (using XFF instead of hostname)
        http_display = ""
        if http.get("url"):
            http_display = http.get("url")
        if http.get("http_method"):
            if http_display:
                http_display = f"{http.get('http_method')} {http_display}"
            else:
                http_display = http.get("http_method")
        
        # Build destination context display
        dest_display = ""
        dest_parts = []
        if dest_geo.get("country_name"):
            dest_parts.append(dest_geo.get("country_name"))
        if dest_as.get("organization", {}).get("name"):
            dest_parts.append(dest_as.get("organization", {}).get("name"))
        if dest_parts:
            dest_display = " | ".join(dest_parts)
        
        # Build "View Full Alert" URL with alert ID as primary filter
        full_alert_filters = []
        if is_present(ts):
            # Use timestamp for time range (1 hour window around the event)
            try:
                ts_dt = datetime.fromisoformat(ts.replace('Z', '+00:00'))
                time_from = (ts_dt - timedelta(minutes=30)).isoformat()
                time_to = (ts_dt + timedelta(minutes=30)).isoformat()
            except:
                time_from = None
                time_to = None
        else:
            time_from = None
            time_to = None
        
        # Use alert ID as primary filter to show only this specific alert
        if is_present(alert_id) and alert_id != "-":
            full_alert_filters.append({"field": "_id", "value": alert_id})
        else:
            # Fallback to other filters if alert ID is not available
            if is_present(sig): full_alert_filters.append({"field": "alert.signature", "value": sig})
            if is_present(sid): full_alert_filters.append({"field": "alert.signature_id", "value": str(sid)})
            if is_present(attacker_ip) and attacker_ip != "-": full_alert_filters.append({"field": "http.xff", "value": attacker_ip})
            if is_present(src_ip) and src_ip != "-": full_alert_filters.append({"field": "src_ip", "value": src_ip})
            if is_present(dst_ip) and dst_ip != "-": full_alert_filters.append({"field": "dest_ip", "value": dst_ip})
            if is_present(cat): full_alert_filters.append({"field": "alert.category", "value": cat})
            if is_present(proto) and proto != "-": full_alert_filters.append({"field": "proto", "value": proto})
        
        full_alert_url = build_dashboard_url(filters=full_alert_filters, time_from=time_from, time_to=time_to) if full_alert_filters else None
        
        html_rows = ""
        html_rows += f"<tr><td colspan='2' style='padding:8px;'><span style='display:inline-block;background:{sev_color};color:#fff;border-radius:12px;padding:6px 16px;font-weight:700;font-size:14px;'>Severity: {sev.upper()}</span>"
        if ai_analysis and ai_analysis.get("recommended_priority"):
            priority_color = {
                "Immediate": "#e53935",
                "High": "#fb8c00",
                "Medium": "#fdd835",
                "Low": "#43a047"
            }.get(ai_analysis["recommended_priority"], "#757575")
            html_rows += f" <span style='display:inline-block;background:{priority_color};color:#fff;border-radius:12px;padding:6px 16px;font-weight:700;font-size:14px;margin-left:8px;'>AI Priority: {html.escape(ai_analysis['recommended_priority'])}</span>"
        html_rows += "</td></tr>"
        html_rows += "<tr><td colspan='2' style='padding:4px 0;'></td></tr>"
        
        # Alert ID - link to dashboard filtered by alert ID
        if is_present(alert_id) and alert_id != "-":
            alert_id_url = build_dashboard_url(filters=[{"field": "_id", "value": alert_id}], time_from=time_from, time_to=time_to) if time_from and time_to else build_dashboard_url(filters=[{"field": "_id", "value": alert_id}])
            html_rows += html_row_link("Alert ID", alert_id, alert_id_url)
        
        # Event Time - link to dashboard with time filter
        if is_present(ts):
            time_url = build_dashboard_url(filters=[{"field": "@timestamp", "value": ts}], time_from=time_from, time_to=time_to) if time_from and time_to else None
            html_rows += html_row_link("Event Time (UTC)", f"{ts}", time_url)
        
        # Hostname/Agent Name (Sensor)
        if is_present(hostname) and hostname != "-":
            html_rows += html_row("Hostname/Agent (Sensor)", hostname)
        
        # Server Hostname (Target)
        if is_present(server_hostname) and server_hostname != "-":
            html_rows += html_row("Server Hostname (Target)", server_hostname)
        
        # Signature - link to dashboard filtered by signature
        if is_present(sig):
            sig_url = build_dashboard_url(filters=[{"field": "alert.signature", "value": sig}], time_from=time_from, time_to=time_to) if time_from and time_to else build_dashboard_url(filters=[{"field": "alert.signature", "value": sig}])
            html_rows += html_row_link("Signature", sig, sig_url)
        
        # Signature ID - link to dashboard filtered by signature ID
        if is_present(sid):
            sid_url = build_dashboard_url(filters=[{"field": "alert.signature_id", "value": str(sid)}], time_from=time_from, time_to=time_to) if time_from and time_to else build_dashboard_url(filters=[{"field": "alert.signature_id", "value": str(sid)}])
            html_rows += html_row_link("Signature ID", sid, sid_url)
        
        if is_present(sev): html_rows += html_row("Severity Level", sev.upper())
        
        # Category - link to dashboard filtered by category
        if is_present(cat):
            cat_url = build_dashboard_url(filters=[{"field": "alert.category", "value": cat}], time_from=time_from, time_to=time_to) if time_from and time_to else build_dashboard_url(filters=[{"field": "alert.category", "value": cat}])
            html_rows += html_row_link("Rule Category", cat, cat_url)
        
        if is_present(action): html_rows += html_row("Action", action)
        
        # Protocol - link to dashboard filtered by protocol
        if is_present(proto): 
            proto_display = proto
            if app_proto:
                proto_display += f" ({app_proto})"
            proto_url = build_dashboard_url(filters=[{"field": "proto", "value": proto}], time_from=time_from, time_to=time_to) if time_from and time_to and proto != "-" else (build_dashboard_url(filters=[{"field": "proto", "value": proto}]) if proto != "-" else None)
            html_rows += html_row_link("Protocol", proto_display, proto_url) if proto_url else html_row("Protocol", proto_display)
        
        # Attacker Source IP (XFF) - prominently displayed
        if is_present(attacker_ip) and attacker_ip != "-":
            xff_url = build_dashboard_url(filters=[{"field": "http.xff", "value": attacker_ip}], time_from=time_from, time_to=time_to) if time_from and time_to else build_dashboard_url(filters=[{"field": "http.xff", "value": attacker_ip}])
            attacker_link = f"<a href='{html.escape(xff_url)}' style='color:#e53935;text-decoration:none;font-weight:600;'>{html.escape(attacker_ip)}</a>"
            html_rows += html_row_raw("Attacker Source IP (XFF)", attacker_link)
        
        # Internal Source IP (for reference)
        if is_present(src_ip) and src_ip != "-": 
            link_html = f"<a href='{DASHBOARD_BASE_URL}/#/agents?agent={html.escape(src_ip)}' style='color:#0d47a1;text-decoration:none;'>{html.escape(src_ip)}:{html.escape(str(src_prt))}</a>"
            html_rows += html_row_raw("Internal Source IP", link_html)
        
        # Destination IP and Port
        if is_present(dst_ip) and dst_ip != "-": 
            link_html = f"<a href='{DASHBOARD_BASE_URL}/#/agents?agent={html.escape(dst_ip)}' style='color:#0d47a1;text-decoration:none;'>{html.escape(dst_ip)}:{html.escape(str(dst_prt))}</a>"
            html_rows += html_row_raw("Destination IP", link_html)
        
        # User-Agent
        if is_present(user_agent) and user_agent != "-":
            html_rows += html_row("User-Agent", user_agent)
        
        # HTTP Status Code (critical for attack success assessment)
        if is_present(http_status) and http_status != "-":
            status_color = "#43a047" if str(http_status).startswith("2") else ("#fb8c00" if str(http_status).startswith("4") else "#e53935")
            status_display = f"<span style='color:{status_color};font-weight:600;'>{html.escape(str(http_status))}</span>"
            html_rows += html_row_raw("HTTP Status Code", status_display)
        
        # HTTP URL/Method (if available)
        if http_display or (is_present(http_url) and http_url != "-"):
            if http_display:
                html_rows += html_row("HTTP Request", http_display)
            elif is_present(http_url) and http_url != "-":
                html_rows += html_row("HTTP URL", http_url)
        
        # Flow Information (detailed)
        flow = s.get("flow", {}) or {}
        if flow:
            flow_parts = []
            if flow.get("bytes"):
                flow_parts.append(f"Total: {flow.get('bytes')} bytes")
            if flow.get("pkts"):
                flow_parts.append(f"{flow.get('pkts')} packets")
            if flow.get("bytes_toserver"):
                flow_parts.append(f"To Server: {flow.get('bytes_toserver')} bytes")
            if flow.get("bytes_toclient"):
                flow_parts.append(f"To Client: {flow.get('bytes_toclient')} bytes")
            if flow_parts:
                html_rows += html_row("Flow Information", " | ".join(flow_parts))
        
        # Tunnel/VXLAN Information
        if tunnel:
            tunnel_parts = []
            if tunnel.get("src_ip"):
                tunnel_parts.append(f"Src: {tunnel.get('src_ip')}")
            if tunnel.get("dest_ip"):
                tunnel_parts.append(f"Dest: {tunnel.get('dest_ip')}")
            if tunnel.get("proto"):
                tunnel_parts.append(f"Proto: {tunnel.get('proto')}")
            if tunnel_parts:
                html_rows += html_row("Tunnel/VXLAN", " | ".join(tunnel_parts))
        
        if dest_display: html_rows += html_row("Destination Context", dest_display)
        
        # Add "View Full Alert" button
        if full_alert_url:
            html_rows += f"""
<tr><td colspan='2' style='padding:16px 8px;text-align:left;'>
  <a href='{html.escape(full_alert_url)}' style='display:inline-block;background:#0d47a1;color:#fff;padding:10px 24px;border-radius:6px;text-decoration:none;font-weight:600;font-size:14px;'>View Alert</a>
</td></tr>
"""
    else:
        # Multiple alerts - table view
        html_rows = ""
        html_rows += f"<tr><td colspan='8' style='padding:8px;'><span style='display:inline-block;background:{sev_color};color:#fff;border-radius:12px;padding:6px 16px;font-weight:700;font-size:14px;'>Total Alerts: {alert_count} | Overall Severity: {overall_severity.upper()}</span></td></tr>"
        html_rows += "<tr style='background:#f3f4f6;'><th style='padding:8px;text-align:left;border-bottom:2px solid #ddd;'>Time</th><th style='padding:8px;text-align:left;border-bottom:2px solid #ddd;'>Signature</th><th style='padding:8px;text-align:left;border-bottom:2px solid #ddd;'>Severity</th><th style='padding:8px;text-align:left;border-bottom:2px solid #ddd;'>Category</th><th style='padding:8px;text-align:left;border-bottom:2px solid #ddd;'>Attacker IP (XFF)</th><th style='padding:8px;text-align:left;border-bottom:2px solid #ddd;'>Destination</th><th style='padding:8px;text-align:left;border-bottom:2px solid #ddd;'>Port/Proto</th><th style='padding:8px;text-align:left;border-bottom:2px solid #ddd;'>User-Agent</th></tr>"
        
        for hit in alerts:
            s = hit.get("_source", {})
            alert = s.get("alert", {}) or {}
            http = s.get("http", {}) or {}
            ts = s.get("@timestamp", iso_now())
            sig = alert.get("signature", "Suricata alert")
            sid = alert.get("signature_id")
            sev = sev_label(alert.get("severity"))
            cat = alert.get("category", "-")
            proto = s.get("proto", "-")
            app_proto = s.get("app_proto")
            attacker_ip = http.get("xff") or alert.get("xff") or "-"
            dst_ip = s.get("dest_ip", "-")
            dst_prt = s.get("dest_port", "-")
            user_agent = http.get("http_user_agent", "-")
            
            sev_bg = get_severity_color(sev)
            sig_display = sig[:35] + ('…' if len(sig) > 35 else '')
            
            # Build attacker IP (XFF) link
            if attacker_ip != "-":
                xff_url = build_dashboard_url(filters=[{"field": "http.xff", "value": attacker_ip}])
                attacker_link = f"<a href='{html.escape(xff_url)}' style='color:#e53935;text-decoration:none;font-weight:600;font-family:monospace;'>{html.escape(str(attacker_ip))}</a>"
            else:
                attacker_link = "-"
            
            # Build destination link
            dst_link = f"<a href='{DASHBOARD_BASE_URL}/#/agents?agent={html.escape(dst_ip)}' style='color:#0d47a1;text-decoration:none;font-family:monospace;'>{html.escape(str(dst_ip))}:{html.escape(str(dst_prt))}</a>" if dst_ip != "-" else "-"
            
            # Build port/protocol display
            port_proto = f"{dst_prt}/{proto}"
            if app_proto:
                port_proto += f" ({app_proto})"
            
            # Build User-Agent display
            ua_display = user_agent[:30] + ('…' if len(user_agent) > 30 else '') if user_agent != "-" else "-"
            
            html_rows += f"""
<tr style='border-bottom:1px solid #e5e7eb;'>
  <td style='padding:6px 8px;font-size:12px;'>{html.escape(str(ts)[:19])}</td>
  <td style='padding:6px 8px;'>{html.escape(sig_display)}</td>
  <td style='padding:6px 8px;'><span style='background:{sev_bg};color:#fff;padding:2px 8px;border-radius:8px;font-size:11px;'>{sev.upper()}</span></td>
  <td style='padding:6px 8px;font-size:12px;'>{html.escape(cat)}</td>
  <td style='padding:6px 8px;font-family:monospace;font-size:12px;'>{attacker_link}</td>
  <td style='padding:6px 8px;font-family:monospace;font-size:12px;'>{dst_link}</td>
  <td style='padding:6px 8px;font-size:12px;'>{html.escape(port_proto)}</td>
  <td style='padding:6px 8px;font-size:11px;'>{html.escape(ua_display)}</td>
</tr>"""
    
    html_body = f"""
<html><body>
<div style="background:#0d47a1;color:#fff;padding:12px 18px;font-size:18px;font-weight:700;">
  {ATHENA_NAME} — Automated NIDS Notification
  <div style="font-size:12px;font-weight:400;opacity:0.95;color:#ffffff;">Tenant: {html.escape(TENANT_NAME)}</div>
</div>
<div style="padding:16px 18px;font-family:Arial,sans-serif;line-height:1.5;">
  <p style="margin:0 0 16px 0;color:#666;font-size:13px;">This is an automated network intrusion detection alert generated by {ATHENA_NAME}.</p>
  <table cellspacing="0" cellpadding="0" border="0" style="border-collapse:collapse;font-size:14px;width:100%;">{html_rows}</table>
  {ai_html}
</div>
<div style="background:#f3f4f6;color:#333;padding:12px 18px;font-size:12px;">
  <p style="margin:2px 0 6px 0;"><strong>Athena Security Group</strong></p>
  <p style="margin:2px 0;">🌐 <a href="{ATHENA_WEBSITE}" style="color:#0d47a1;text-decoration:none;">Website</a>
     &nbsp;|&nbsp; 📄 <a href="{ATHENA_DOCS}" style="color:#0d47a1;text-decoration:none;">Docs</a>
     &nbsp;|&nbsp; 📧 <a href="mailto:{ATHENA_SUPPORT}" style="color:#0d47a1;text-decoration:none;">{ATHENA_SUPPORT}</a></p>
  <p style="margin:10px 0 0 0;">This message was generated automatically by {ATHENA_NAME}. Do not reply to this email.</p>
</div>
</body></html>
""".strip()
    
    return subject, plain, html_body

# === SMTP SENDER ===
def send_email(to_emails, subject, plain_body, html_body) -> bool:
    try:
        if isinstance(to_emails, str):
            to_emails = [e.strip() for e in to_emails.split(",")]
        
        msg = EmailMessage()
        msg["Subject"] = subject
        msg["To"] = ", ".join(to_emails)
        msg["From"] = formataddr((f"{ATHENA_NAME} ({TENANT_NAME})", SMTP_FROM))
        
        msg.set_content(plain_body)
        msg.add_alternative(html_body, subtype='html')
        
        if SMTP_USE_SSL:
            server = smtplib.SMTP_SSL(SMTP_HOST, SMTP_PORT, timeout=30)
        else:
            server = smtplib.SMTP(SMTP_HOST, SMTP_PORT, timeout=30)
        
        server.ehlo()
        if SMTP_USE_TLS and not SMTP_USE_SSL:
            server.starttls()
            server.ehlo()
        
        if SMTP_USERNAME and SMTP_PASSWORD:
            server.login(SMTP_USERNAME, SMTP_PASSWORD)
        
        server.send_message(msg)
        server.quit()
        log(f"Email sent to {to_emails}. Subject: {subject}")
        return True
        
    except Exception as e:
        log(f"Error sending email via SMTP: {e}")
        import traceback
        log(traceback.format_exc())
        return False

def get_ts(hit):
    return hit.get("_source", {}).get("@timestamp", iso_now())

# === MAIN ===
def main():
    ensure_dirs()
    state = load_state()
    last_ts = state.get("last_ts")
    
    print(build_query(last_ts))
    
    try:
        result = os_search(build_query(last_ts))
        hits = result.get("hits", {}).get("hits", [])
        
        if not hits:
            log("No new alerts found")
            return
        
        log(f"Found {len(hits)} Suricata alert(s)")
        
        sent_count = 0
        failed_count = 0
        
        # Process each alert individually - send one email per alert
        for i, hit in enumerate(hits):
            try:
                log(f"Processing alert {i+1}/{len(hits)}")
                
                # Extract alert context for this single alert
                alert_context = extract_alert_context(hit)
                
                # Get AI analysis for this single alert
                ai_analysis = None
                if OLLAMA_ENABLED:
                    ai_analysis = get_ai_analysis([alert_context])  # Pass as list with one item
                    if ai_analysis:
                        log(f"AI analysis completed for alert {i+1}")
                    else:
                        log(f"Proceeding without AI analysis for alert {i+1}")
                
                # Check Agelia mute rules before sending
                if is_nids_alert_muted(hit):
                    log(f"Skipping muted alert {i+1}/{len(hits)}")
                    continue

                # Generate email for this single alert
                subject, plain, html_body = generate_msg([hit], ai_analysis)  # Pass as list with one alert
                log(f"Subject: {subject}")

                # Send email for this alert
                if send_email(SMTP_RECIPIENT, subject, plain, html_body):
                    sent_count += 1
                    log(f"Successfully sent email {i+1}/{len(hits)}")
                    
                    # Update state with this alert's timestamp after successful send
                    current_ts = get_ts(hit)
                    # Add 1ms to avoid reprocessing
                    try:
                        ts_dt = datetime.fromisoformat(current_ts.replace('Z', '+00:00'))
                        ts_dt = ts_dt + timedelta(milliseconds=1)
                        last_ts = ts_dt.isoformat().replace('+00:00', 'Z')
                    except Exception:
                        last_ts = current_ts
                    
                    save_state({"last_ts": last_ts})
                    log(f"Updated last_ts to: {last_ts}")
                else:
                    failed_count += 1
                    log(f"Failed to send email {i+1}/{len(hits)}")
                    # Don't update last_ts if email failed - we want to retry
                
                # Small delay between emails to avoid overwhelming SMTP server
                if i < len(hits) - 1:
                    time.sleep(1)
                    
            except Exception as e:
                failed_count += 1
                log(f"Error processing alert {i+1}: {e}")
                import traceback
                log(traceback.format_exc())
                # Continue with next alert
        
        log(f"Processing complete - Sent: {sent_count}, Failed: {failed_count}")
            
    except Exception as e:
        log(f"OpenSearch query error: {e}")
        import traceback
        log(traceback.format_exc())
        # Don't update last_ts on error - we want to retry these alerts

if __name__ == "__main__":
    try:
        main()
    except Exception as e:
        log(f"Unhandled exception: {e}")
        import traceback
        log(traceback.format_exc())
        raise