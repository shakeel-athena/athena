#!/bin/bash
# Athena NIDS Notifier Setup Script for Linux (systemd)

set -e

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

echo -e "${GREEN}Athena NIDS Notifier Setup${NC}"
echo "================================"

INSTALL_DIR="/opt/athena-integrations/notifications"
SERVICE_USER=$(whoami)
PYTHON_PATH=$(which python3)

if [ -z "$PYTHON_PATH" ]; then
    echo -e "${RED}Error: python3 not found in PATH${NC}"
    exit 1
fi

echo "Installation directory: $INSTALL_DIR"
echo "Python: $PYTHON_PATH"
echo "Service User: $SERVICE_USER"

# Check if running as root
if [ "$EUID" -ne 0 ]; then 
    echo -e "${YELLOW}Note: This script requires sudo for systemd installation${NC}"
fi

# Check if directory exists
if [ -d "$INSTALL_DIR" ]; then
    echo -e "${YELLOW}Directory exists. Updating repository...${NC}"
    cd "$INSTALL_DIR"
    sudo git pull || echo "Warning: Could not update repository"
else
    echo "Cloning repository..."
    sudo mkdir -p /opt
    cd /opt
    sudo git clone git@github.com:Athena-Software-Group/athena-integrations.git
    cd "$INSTALL_DIR"
fi

# Set ownership to current user
echo "Setting ownership..."
sudo chown -R $SERVICE_USER:$SERVICE_USER "$INSTALL_DIR"

# Create directories with proper permissions
echo "Creating directories..."
mkdir -p "$INSTALL_DIR/logs"
mkdir -p "$INSTALL_DIR/athena-notifier-nids"

# Ensure directories are writable
chmod 755 "$INSTALL_DIR/logs"
chmod 755 "$INSTALL_DIR/athena-notifier-nids"

# Create log file if it doesn't exist and set permissions
touch "$INSTALL_DIR/logs/athena-suricata-email-notifier.log"
chmod 666 "$INSTALL_DIR/logs/athena-suricata-email-notifier.log"

# Create state file if it doesn't exist and set permissions
STATE_FILE="$INSTALL_DIR/athena-notifier-nids/suricata-email-notifier.state.json"
if [ ! -f "$STATE_FILE" ]; then
    echo '{"last_ts": null}' > "$STATE_FILE"
fi
chmod 666 "$STATE_FILE"

# Check for .env file
if [ ! -f "$INSTALL_DIR/.env" ]; then
    echo -e "${YELLOW}Warning: .env file not found${NC}"
    echo "Please create $INSTALL_DIR/.env with required configuration"
fi

# Setup systemd timer
echo ""
echo "Setting up systemd timer..."

# Create service file
sudo tee /etc/systemd/system/athena-nids-notifier.service > /dev/null <<EOF
[Unit]
Description=Athena NIDS Email Notifier
After=network.target

[Service]
Type=oneshot
User=$SERVICE_USER
WorkingDirectory=$INSTALL_DIR
Environment="PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin"
ExecStart=$PYTHON_PATH $INSTALL_DIR/email_notifications_nids.py
StandardOutput=journal
StandardError=journal
EOF

# Create timer file
sudo tee /etc/systemd/system/athena-nids-notifier.timer > /dev/null <<EOF
[Unit]
Description=Run Athena NIDS Notifier every 60 seconds
Requires=athena-nids-notifier.service

[Timer]
OnBootSec=1min
OnUnitActiveSec=60s
AccuracySec=1s

[Install]
WantedBy=timers.target
EOF

# Enable and start
sudo systemctl daemon-reload
sudo systemctl enable athena-nids-notifier.timer
sudo systemctl start athena-nids-notifier.timer

echo -e "${GREEN}✓ Systemd timer installed successfully${NC}"
echo ""
echo "Setup complete!"
echo ""
echo "Installation directory: $INSTALL_DIR"
echo "Configuration file: $INSTALL_DIR/.env"
echo "Logs: $INSTALL_DIR/logs/"
echo "State file: $INSTALL_DIR/athena-notifier-nids/suricata-email-notifier.state.json"
echo ""
echo "Service Management:"
echo "  Status:  sudo systemctl status athena-nids-notifier.timer"
echo "  Stop:    sudo systemctl stop athena-nids-notifier.timer"
echo "  Start:   sudo systemctl start athena-nids-notifier.timer"
echo "  Logs:    sudo journalctl -u athena-nids-notifier.service -f"
echo ""
echo "Next steps:"
echo "1. Configure $INSTALL_DIR/.env with your settings"
echo "2. Test manually: cd $INSTALL_DIR && python3 email_notifications_nids.py"
echo "3. The service will run automatically every 60 seconds"