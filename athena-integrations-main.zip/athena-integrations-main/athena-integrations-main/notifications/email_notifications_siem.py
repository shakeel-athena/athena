#!/var/ossec/framework/python/bin/python3
# -*- coding: utf-8 -*-

import json
import sys
import time
import os
import smtplib
import html
import re
from email.message import EmailMessage
from email.utils import formataddr
from dotenv import load_dotenv
from datetime import datetime, timedelta, timezone

load_dotenv()

# === CONFIGURATION FROM ENVIRONMENT ===
ATHENA_NAME = os.getenv("ATHENA_NAME", "Athena SOC")
TENANT_NAME = os.getenv("TENANT_NAME", "test.athenasecuritygrp.com")
ATHENA_WEBSITE = os.getenv("ATHENA_WEBSITE", "https://athenasoftwaregroup.ai/")
ATHENA_DOCS = os.getenv("ATHENA_DOCS", "https://athenasoftwaregroup.ai/")
ATHENA_SUPPORT = os.getenv("ATHENA_SUPPORT", "alerts@athena.athenasecuritygrp.com")
DASHBOARD_BASE_URL = os.getenv("DASHBOARD_BASE_URL", "https://test.athenasecuritygrp.com")

# === SMTP CONFIGURATION ===
SMTP_HOST = os.getenv("SMTP_HOST", "smtp.office365.com")
SMTP_PORT = int(os.getenv("SMTP_PORT", "587"))
SMTP_USE_TLS = os.getenv("SMTP_USE_TLS", "true").lower() == "true"
SMTP_USE_SSL = os.getenv("SMTP_USE_SSL", "false").lower() == "true"
SMTP_USERNAME = os.getenv("SMTP_USERNAME", "alerts@athenasoftwaregrp.com")
SMTP_PASSWORD = os.getenv("SMTP_PASSWORD", "")
SMTP_FROM = os.getenv("SMTP_FROM", "alerts@athena.athenasecuritygrp.com")

# === OLLAMA CONFIGURATION ===
OLLAMA_HOST = os.getenv("OLLAMA_HOST", "localhost")
OLLAMA_PORT = os.getenv("OLLAMA_PORT", "11434")
OLLAMA_MODEL = os.getenv("OLLAMA_MODEL", "qwen2.5:14b-instruct")
OLLAMA_ENABLED = os.getenv("OLLAMA_ENABLED", "true").lower() == "true"
OLLAMA_API_URL = f"http://{OLLAMA_HOST}:{OLLAMA_PORT}/v1/chat/completions"

# === GUARDDUTY CONFIGURATION ===
SEND_GUARDDUTY_SAMPLE_ALERTS = os.getenv("SEND_GUARDDUTY_SAMPLE_ALERTS", "false").lower() == "true"

# === AGELIA NRM MUTE CHECK ===
AGELIA_API_URL       = os.getenv("AGELIA_API_URL", "")
INTEGRATION_API_KEY  = os.getenv("INTEGRATION_API_KEY", "")
MUTE_CHECK_ENABLED   = os.getenv("MUTE_CHECK_ENABLED", "true").lower() == "true"
MUTE_CHECK_TIMEOUT   = int(os.getenv("MUTE_CHECK_TIMEOUT_SECONDS", "3"))

# === LOGGING ===
debug_enabled = False
pwd = os.path.dirname(os.path.dirname(os.path.realpath(__file__)))
log_file = f"{pwd}/logs/integrations.log"


def log(msg: str):
    now = time.strftime("%a %b %d %H:%M:%S %Z %Y")
    line = f"{now}: {msg}\n"
    print(line, end="")
    try:
        with open(log_file, "a") as f:
            f.write(line)
    except Exception:
        pass


def is_alert_muted(alert_doc: dict) -> bool:
    """
    Check with the Agelia backend whether this alert is suppressed by a mute rule.
    Fails OPEN (returns False) on any error so emails are never silently dropped
    due to backend connectivity issues.
    """
    if not MUTE_CHECK_ENABLED or not AGELIA_API_URL or not INTEGRATION_API_KEY:
        return False
    try:
        import requests as _req
        rule  = alert_doc.get("rule", {})
        agent = alert_doc.get("agent", {})
        groups = rule.get("groups") or []
        level = rule.get("level", 0)
        sev_map = {range(0, 7): "Low", range(7, 12): "Medium", range(12, 15): "High", range(15, 20): "Critical"}
        normalized_severity = next((v for r, v in sev_map.items() if level in r), "Low")

        payload = {
            "id":                   alert_doc.get("id", ""),
            "rule_id":              str(rule.get("id", "")),
            "normalized_severity":  normalized_severity,
            "src_ip":               alert_doc.get("data", {}).get("srcip", ""),
            "dest_ip":              alert_doc.get("data", {}).get("dstip", ""),
            "agent_name":           agent.get("name", ""),
            "category":             groups[0] if groups else "",
        }
        resp = _req.post(
            f"{AGELIA_API_URL}/api/integrations/alerts/check-mute",
            json=payload,
            headers={"X-Integration-Key": INTEGRATION_API_KEY,
                     "Content-Type": "application/json"},
            timeout=MUTE_CHECK_TIMEOUT,
            verify=False,
        )
        if resp.status_code == 200:
            muted = resp.json().get("data", {}).get("muted", False)
            if muted:
                log(f"Alert {payload['id']} suppressed by Agelia mute rule — skipping email")
            return muted
        log(f"Mute check returned HTTP {resp.status_code} — failing open")
        return False
    except Exception as e:
        log(f"Mute check error (failing open): {e}")
        return False


def should_skip_alert(alert_doc: dict) -> bool:
    """
    Skip non-actionable alerts that should not consume AI tokens or send email.
    Currently skips VirusTotal public API rate-limit alerts.
    """
    data = alert_doc.get("data", {}) or {}
    vt = data.get("virustotal", {}) or {}
    integration = str(data.get("integration", "")).strip().lower()
    vt_desc = str(vt.get("description", "")).strip()

    if integration == "virustotal" and vt_desc == "Error: Public API request rate limit reached":
        log("Skipping VirusTotal alert because public API request rate limit was reached")
        return True

    return False


# === OLLAMA INTEGRATION ===
def get_ai_analysis(alert_context: dict) -> dict:
    """
    Call Ollama API to analyze the security alert and provide:
    - Executive Summary
    - Detailed Analysis
    - Mitigation Steps
    - Risk Assessment
    """
    if not OLLAMA_ENABLED:
        log("Ollama analysis disabled")
        return None

    try:
        import requests

        prompt = f"""You are a cybersecurity analyst for Athena SOC specializing in endpoint detection and response (EDR/XDR). Analyze the following security alert and provide a comprehensive assessment.

**IMPORTANT CONTEXT:**
- This alert is generated by Wazuh XDR/SIEM platform integrated with Athena SOC
- The alert represents a security event detected on an endpoint or system
- Consider the full context including vulnerability data, MITRE ATT&CK mapping, and compliance implications

**Alert Details:**
- Event Timestamp: {alert_context.get('timestamp', 'N/A')}
- Alert ID: {alert_context.get('alert_id', 'N/A')}
- Rule Description: {alert_context.get('description', 'N/A')}
- Severity (from rule): {alert_context.get('severity', 'N/A')}
- GitHub Advisory Severity (authoritative when present; use for recommended_priority): {alert_context.get('ghsa_severity', 'N/A')}
- Rule Level: {alert_context.get('rule_level', 'N/A')}
- Rule ID: {alert_context.get('rule_id', 'N/A')}
- Rule Groups: {alert_context.get('rule_groups', 'N/A')}
- Times Fired: {alert_context.get('firedtimes', 'N/A')}
- Location: {alert_context.get('location', 'N/A')}
- Decoder: {alert_context.get('decoder_name', 'N/A')}
{'- Repository: ' + (alert_context.get('github_repo') or '') + ' | https://github.com/' + (alert_context.get('github_repo') or '') if alert_context.get('github_repo') else ''}

**Agent/Endpoint Information:**
- Agent ID: {alert_context.get('agent_id', 'N/A')}
- Agent Name: {alert_context.get('agent_name', 'N/A')}
- Agent IP: {alert_context.get('agent_ip', 'N/A')}
- Wazuh Manager: {alert_context.get('manager_name', 'N/A')}
- Username: {alert_context.get('username', 'N/A')}

**MITRE ATT&CK Context:**
- MITRE IDs: {alert_context.get('mitre_ids', 'N/A')}
- MITRE Tactics: {alert_context.get('mitre_tactics', 'N/A')}
- MITRE Techniques: {alert_context.get('mitre_techniques', 'N/A')}

**Compliance Context:**
- PCI DSS: {alert_context.get('pci_dss', 'N/A')}
- GDPR: {alert_context.get('gdpr', 'N/A')}
- TSC (Trust Services Criteria): {alert_context.get('tsc', 'N/A')}

**Vulnerability Information:**
{alert_context.get('vulnerability_info', 'No vulnerability data available')}

**GitHub Security Advisory (GHSA) - PRIMARY SOURCE when present (use for analysis: GHSA ID, Summary, Severity, Type, CVE, CVSS Score/Vector, Published/Updated/Withdrawn At, Advisory URL, and affected packages with vulnerable/patched versions; excludes Description and References):**
{alert_context.get('ghsa_info', 'N/A')}

**VirusTotal (when present):**
{alert_context.get('virustotal_info', 'N/A')}

**Additional Log Context:**
{alert_context.get('full_log', 'No additional log data')}

**GuardDuty Context:**
{alert_context.get('guardduty_info', 'N/A')}

**ANALYSIS INSTRUCTIONS:**
1. **When GitHub Security Advisory (GHSA) data is present**: Treat it as the authoritative source for this vulnerability. Base your severity assessment, recommended_priority, executive summary, and detailed analysis on the GHSA severity, summary, CVE, CVSS score, withdrawn status, and patched versions. Do not override with the generic rule severity (e.g. "High" from rule level 12); use the GitHub Advisory Severity (e.g. "medium") for recommended_priority and risk wording. Explicitly reference the GHSA summary, CVE ID, package name, patched version, and affected repository (when present) in your analysis. If the advisory is withdrawn, state that and adjust risk/priority accordingly.
2. **When VirusTotal data is present**: Treat detection ratio (positives/total), file path, hashes (SHA1/MD5), scan date, and permalink as key evidence. Highlight whether the detection count is high and recommend containment steps (quarantine file/host, isolate endpoint, validate EICAR test vs real malware, etc.).
3. **Threat Assessment**: Analyze the combination of rule description, severity (prefer GHSA severity when present), MITRE ATT&CK mapping, VirusTotal detections, and vulnerability data to assess the threat level and potential attack vectors.
4. **Vulnerability Analysis**: If GHSA or other vulnerability data is present, use the GHSA summary to explain the issue. Assess CVSS scores, attack vectors, and exploitability. Mention patched versions and withdrawn status when relevant.
5. **Endpoint Context**: Consider the agent name, IP, and username to understand the affected system and user context. When Repository is present in alert metadata, reference the affected repository by name and link (e.g. "vulnerability in repository Athena-Software-Group/athena-promachos - https://github.com/Athena-Software-Group/athena-promachos") in your analysis and recommendations.
6. **Compliance Impact**: Assess the compliance implications (PCI DSS, GDPR, TSC) if applicable.
7. **Attack Chain Analysis**: Use MITRE ATT&CK tactics and techniques where applicable; for pure dependency/repo alerts, focus on the vulnerability details from GHSA; for VirusTotal alerts, focus on malware detection + containment.
8. **IOC Extraction**: Extract all relevant indicators including usernames, agent IPs, rule patterns, CVE/GHSA IDs, package names, file paths, hashes, and VirusTotal permalink.
9. **Recurrence Analysis**: Consider the "Times Fired" field - if high, this may indicate a persistent threat or misconfiguration.

Provide your analysis in the following JSON format:
{{
    "executive_summary": "2-3 sentence overview. When GHSA is present, cite the GHSA summary, CVE, and advisory severity (e.g. medium). When repository is present, reference the repo by name. When VirusTotal is present, cite detections (positives/total) and file path. Mention withdrawn status if applicable.",
    "detailed_analysis": "Detailed explanation. When GHSA is present, use its summary, severity, CVSS, patched version, and withdrawn status. When repository is present, reference the repo name and link. When VirusTotal is present, explain detection evidence, what it likely means, and immediate containment actions.",
    "mitigation_steps": ["Step 1", "Step 2", "Step 3", ...],
    "risk_assessment": "Risk level and business impact. Align with GHSA severity when present (e.g. medium = Medium risk, not High). For VirusTotal detections, base risk on detection ratio and context (EICAR/test vs real).",
    "indicators_of_compromise": ["IOC 1", "IOC 2", ...] or null,
    "recommended_priority": "Immediate/High/Medium/Low - MUST align with GitHub Advisory Severity when present (e.g. if GHSA says medium, use Medium, not Immediate/High). For VirusTotal-only alerts, choose based on detection evidence and endpoint exposure.",
    "false_positive_likelihood": "High/Medium/Low — brief justification for why this alert may or may not be a false positive based on the available evidence",
    "confidence_level": "High/Medium/Low — how confident the analysis is given the available data quality and context",
    "attack_chain_insights": "Insights; for repo/dependency alerts focus on GHSA vulnerability details and remediation (upgrade to patched version). For VirusTotal alerts focus on containment + validation."
}}

Be specific, actionable, and security-focused. When GHSA data is present, treat it as canonical for severity and priority."""

        headers = {
            "Content-Type": "application/json"
        }

        payload = {
            "model": OLLAMA_MODEL,
            "messages": [
                {
                    "role": "system",
                    "content": "You are an expert cybersecurity analyst specializing in threat detection, incident response, and endpoint security (EDR/XDR). Provide clear, actionable security assessments. If a data field is empty, null, or 'N/A', state that the information is unavailable — do not speculate or hallucinate. Return ONLY valid JSON. Do not include any text before or after the JSON object."
                },
                {
                    "role": "user",
                    "content": prompt
                }
            ],
            "temperature": 0.3,
            "max_tokens": 4096,
            "response_format": {"type": "json_object"}
        }

        log(f"Calling Ollama API at {OLLAMA_API_URL} with model {OLLAMA_MODEL}...")
        response = requests.post(
            OLLAMA_API_URL,
            headers=headers,
            json=payload,
            timeout=180
        )

        if response.status_code == 200:
            result = response.json()
            ai_content = result['choices'][0]['message']['content']
            ai_analysis = json.loads(ai_content)
            log("Ollama analysis completed successfully")
            return ai_analysis
        else:
            log(f"Ollama API error: {response.status_code} - {response.text}")
            return None

    except Exception as e:
        log(f"Error getting AI analysis: {e}")
        return None


# === GITHUB SECURITY ADVISORY (GHSA) HELPERS ===
def _fetch_ghsa_advisory(ghsa_id: str):
    """Fetch GitHub Security Advisory by GHSA ID. Returns dict or None."""
    if not ghsa_id or not isinstance(ghsa_id, str) or not ghsa_id.strip().upper().startswith("GHSA-"):
        return None
    ghsa_id = ghsa_id.strip()
    try:
        import requests
        token = os.getenv("GITHUB_TOKEN", "")
        headers = {"Accept": "application/vnd.github+json", "X-GitHub-Api-Version": "2022-11-28"}
        if token:
            headers["Authorization"] = f"Bearer {token}"
        r = requests.get(f"https://api.github.com/advisories/{ghsa_id}", headers=headers, timeout=15)
        if r.status_code != 200:
            log(f"GHSA fetch failed for {ghsa_id}: HTTP {r.status_code}")
            return None
        return r.json()
    except Exception as e:
        log(f"GHSA fetch error for {ghsa_id}: {e}")
        return None


def _format_ghsa_for_alert(ghsa_data: dict) -> str:
    """Format GHSA data for alert metadata and AI context (excludes Description and References)."""
    if not ghsa_data or not isinstance(ghsa_data, dict):
        return ""
    lines = []
    lines.append(f"GHSA ID: {ghsa_data.get('ghsa_id', 'N/A')}")
    lines.append(f"Summary: {ghsa_data.get('summary') or 'N/A'}")
    lines.append(f"Severity: {ghsa_data.get('severity', 'N/A')}")
    if ghsa_data.get("cve_id"):
        lines.append(f"CVE: {ghsa_data.get('cve_id')}")
    cvss = ghsa_data.get("cvss") or {}
    if isinstance(cvss, dict) and cvss.get("score") is not None:
        lines.append(f"CVSS Score: {cvss.get('score')}")
        if cvss.get("vector_string"):
            lines.append(f"CVSS Vector: {cvss.get('vector_string')}")
    if ghsa_data.get("withdrawn_at"):
        lines.append("Status: Withdrawn")
    vulns = ghsa_data.get("vulnerabilities") or []
    if vulns:
        for i, v in enumerate(vulns[:5], 1):
            pkg = v.get("package") or {}
            name = pkg.get("name") or "N/A"
            eco = pkg.get("ecosystem") or ""
            vr = v.get("vulnerable_version_range") or "N/A"
            fp = v.get("first_patched_version")
            patched = fp.get("identifier", fp) if isinstance(fp, dict) else fp
            patched = patched if patched else "N/A"
            lines.append(f"Package {i}: {name} ({eco}) | Vulnerable: {vr} | Patched: {patched}")
    url = ghsa_data.get("html_url") or f"https://github.com/advisories/{ghsa_data.get('ghsa_id', '')}"
    lines.append(f"Advisory URL: {url}")
    return "\n".join(lines)


# === HELPERS ===
def action_hint(severity: str) -> str:
    sev = (severity or "").lower()
    return {
        "critical": "TRIAGE IMMEDIATELY and initiate incident response.",
        "high": "Triage as HIGH priority and investigate promptly.",
        "medium": "Review within 24 hours and monitor for recurrence."
    }.get(sev, "Monitor. Escalate if activity repeats or context changes.")


def is_present(v):
    return v not in (None, "", "N/A")


def get_severity_color(sev):
    return {
        "Critical": "#e53935", "High": "#fb8c00",
        "Medium": "#fdd835", "Low": "#43a047"
    }.get(sev, "#757575")


def get_vuln_severity_color(sev):
    """Return text color for vulnerability severity, defaulting to neutral gray."""
    key = (sev or "").strip().lower()
    return {
        "critical": "#e53935",
        "high": "#fb8c00",
        "medium": "#fdd835",
        "low": "#43a047",
        "informational": "#1e88e5"
    }.get(key, "#37474f")


def normalize_refs(refs):
    if not refs:
        return []
    if isinstance(refs, list):
        out = []
        for r in refs:
            if not r:
                continue
            parts = [p.strip() for p in str(r).split(",") if p.strip()]
            out.extend(parts)
        return out
    return [p.strip() for p in str(refs).split(",") if p.strip()]


def linkify(url):
    u = str(url).strip()
    esc = html.escape(u)
    if u.startswith("http"):
        return f'<a href="{esc}" style="color:#0d47a1;text-decoration:none;">{esc}</a>'
    return esc


def sanitize_for_subject(text: str, max_len: int = 80) -> str:
    if not text:
        return ""
    t = " ".join(str(text).split())
    return (t[:max_len] + "…") if len(t) > max_len else t


def build_dashboard_url(filters=None, time_from=None, time_to=None):
    """
    Build OpenSearch Dashboard Discover URL with KQL query filters for SIEM alerts.

    Args:
        filters: List of dicts with 'field' and 'value' keys for KQL filters
        time_from: Start time (ISO format), defaults to 1 hour before now
        time_to: End time (ISO format), defaults to now

    Returns:
        URL string for OpenSearch Dashboard Discover view
    """
    from urllib.parse import quote

    base = f"{DASHBOARD_BASE_URL}/app/data-explorer/discover#"
    index_pattern = os.getenv("ES_INDEX_PATTERN_SIEM", "athena-alerts-*")

    # Default time range: last 1 hour
    if not time_from or not time_to:
        now = datetime.now(timezone.utc)
        time_to = now.isoformat()
        time_from = (now - timedelta(hours=1)).isoformat()

    # Normalize time format - ensure it has timezone info
    if time_from and not ('+' in time_from or time_from.endswith('Z')):
        time_from = time_from + '+00:00'
    if time_to and not ('+' in time_to or time_to.endswith('Z')):
        time_to = time_to + '+00:00'

    # Replace Z with +00:00 for consistency
    time_from = time_from.replace('Z', '+00:00')
    time_to = time_to.replace('Z', '+00:00')

    # Build KQL query from filters
    kql_parts = []
    if filters:
        for f in filters:
            field = f.get("field", "")
            value = f.get("value", "")
            if field and value and value != "-" and value != "N/A":
                value_escaped = str(value).replace('\\', '\\\\').replace('"', '\\"')
                kql_parts.append(f'{field}:"{value_escaped}"')

    kql_query = " AND ".join(kql_parts) if kql_parts else ""

    # _g: global time range
    time_from_escaped = time_from.replace("'", "\\'")
    time_to_escaped = time_to.replace("'", "\\'")
    _g = f"(time:(from:'{time_from_escaped}',to:'{time_to_escaped}'))"

    # _a: application state with discover columns and metadata
    _a = f"(discover:(columns:!(_source)),metadata:(indexPattern:'{index_pattern}',view:discover))"

    # _q: query with KQL
    if kql_query:
        kql_escaped = kql_query.replace("'", "\\'")
        _q = f"(query:(language:kuery,query:'{kql_escaped}'))"
    else:
        _q = "(query:(language:kuery,query:''))"

    params = {"_g": _g, "_a": _a, "_q": _q}
    url = base + "?" + "&".join([f"{k}={quote(v, safe='')}" for k, v in params.items()])
    return url

def to_list(value):
    if value is None:
        return []
    if isinstance(value, list):
        return value
    if isinstance(value, tuple):
        return list(value)
    return [value]


def unique_preserve(items):
    seen = set()
    out = []
    for item in items:
        key = json.dumps(item, sort_keys=True, default=str) if isinstance(item, (dict, list, tuple)) else str(item)
        if key in seen:
            continue
        seen.add(key)
        out.append(item)
    return out


def flatten_scalars(value):
    """
    Recursively flatten nested lists/tuples and collect only scalar values as strings.
    Useful for GuardDuty arrays that may contain nested arrays in sample findings.
    """
    out = []
    if value is None:
        return out
    if isinstance(value, (list, tuple, set)):
        for item in value:
            out.extend(flatten_scalars(item))
        return out
    if isinstance(value, dict):
        # Ignore dicts for scalar flattening
        return out
    text = str(value).strip()
    if text and text not in ("[]", "{}"):
        out.append(text)
    return out


def first_present(*values, default=None):
    for value in values:
        if value is None:
            continue
        if isinstance(value, str):
            if value.strip():
                return value
            continue
        if isinstance(value, (list, tuple, set, dict)) and len(value) == 0:
            continue
        return value
    return default


def normalize_boolish(value):
    if isinstance(value, bool):
        return value
    if isinstance(value, (int, float)):
        return bool(value)
    if isinstance(value, str):
        v = value.strip().lower()
        if v in ("true", "yes", "1"):
            return True
        if v in ("false", "no", "0"):
            return False
    return None


def bool_display(value):
    normalized = normalize_boolish(value)
    if normalized is None:
        return "N/A"
    return "Yes" if normalized else "No"


def format_display_list(items, max_items=6):
    values = [str(x).strip() for x in unique_preserve(flatten_scalars(items)) if str(x).strip()]
    if not values:
        return ""
    if len(values) <= max_items:
        return ", ".join(values)
    return ", ".join(values[:max_items]) + f" (+{len(values) - max_items} more)"


def format_tag_pairs(tags, max_items=8):
    tag_pairs = []
    for tag in to_list(tags):
        if isinstance(tag, dict):
            key = first_present(tag.get("key"), tag.get("Key"))
            value = first_present(tag.get("value"), tag.get("Value"))
            if key and value is not None:
                tag_pairs.append(f"{key}={value}")
            elif key:
                tag_pairs.append(str(key))
        else:
            tag_pairs.extend(flatten_scalars(tag))
    return format_display_list(tag_pairs, max_items=max_items)

def get_gd_severity(gd_score):
    try:
        gd_score = float(gd_score)
    except (TypeError, ValueError):
        return "Unknown"

    if gd_score >= 9.0:
        return "Critical"
    if gd_score >= 7.0:
        return "High"
    if gd_score >= 4.0:
        return "Medium"
    return "Low"

def extract_guardduty_context(alert, data, rule=None):
    """
    Extract GuardDuty-specific context from a Wazuh alert for richer email content and AI analysis.
    Handles common GuardDuty finding types: network connection, API call, DNS, instance findings,
    and attack sequence findings.
    """
    rule = rule or {}
    data = data or {}
    aws = data.get("aws", {}) or {}
    groups = rule.get("groups", []) or []

    is_guardduty = ("aws_guardduty" in groups) or ((aws.get("source") or "").lower() == "guardduty")
    if not is_guardduty:
        return {"is_guardduty": False}

    service = aws.get("service", {}) or {}
    resource = aws.get("resource", {}) or {}
    instance = resource.get("instanceDetails", {}) or {}
    access_key_details = resource.get("accessKeyDetails", {}) or {}
    s3_bucket_details = resource.get("s3BucketDetails", {}) or {}
    eks_cluster_details = resource.get("eksClusterDetails", {}) or resource.get("eksCluster", {}) or {}
    rds_db_instance_details = resource.get("rdsDbInstanceDetails", {}) or {}
    evidence = service.get("evidence", {}) or {}
    additional_info = service.get("additionalInfo", {}) or {}
    action = service.get("action", {}) or {}
    sequence = ((service.get("detection", {}) or {}).get("sequence", {}) or {})

    details = {
        "is_guardduty": True,
        "finding_severity": get_gd_severity(first_present(aws.get("severity"))),
        "finding_type": first_present(aws.get("type")),
        "finding_title": first_present(aws.get("title")),
        "finding_description": first_present(aws.get("description")),
        "finding_id": first_present(aws.get("id")),
        "finding_arn": first_present(aws.get("arn")),
        "account_id": first_present(aws.get("accountId")),
        "region": first_present(aws.get("region")),
        "created_at": first_present(aws.get("createdAt")),
        "updated_at": first_present(aws.get("updatedAt")),
        "detector_id": first_present(service.get("detectorId")),
        "feature_name": first_present(service.get("featureName")),
        "event_first_seen": first_present(service.get("eventFirstSeen")),
        "event_last_seen": first_present(service.get("eventLastSeen")),
        "finding_count": first_present(service.get("count")),
        "resource_role": first_present(service.get("resourceRole")),
        "service_name": first_present(service.get("serviceName")),
        "archived": service.get("archived"),
        "sample": first_present(additional_info.get("sample")),
        "resource_type": first_present(resource.get("resourceType")),
        "log_bucket": first_present((aws.get("log_info", {}) or {}).get("s3bucket")),
        "log_file": first_present((aws.get("log_info", {}) or {}).get("log_file")),
    }

    # Threat intelligence evidence
    threat_list_names = []
    threat_names = []
    for item in to_list(evidence.get("threatIntelligenceDetails")):
        if not isinstance(item, dict):
            continue
        threat_list_names.extend(flatten_scalars(item.get("threatListName")))
        threat_names.extend(flatten_scalars(item.get("threatNames")))

    # Attack sequence details
    tactics = []
    techniques = []
    actors = []
    sequence_resource_names = []
    sequence_resource_types = []
    sequence_resource_entries = []
    signal_names = []
    signal_endpoint_summaries = []
    sequence_endpoint_summaries = []

    for indicator in to_list(sequence.get("sequenceIndicators")):
        if not isinstance(indicator, dict):
            continue
        key = indicator.get("key")
        values = flatten_scalars(indicator.get("values"))
        if key == "ATTACK_TACTIC":
            tactics.extend(values)
        elif key == "ATTACK_TECHNIQUE":
            techniques.extend(values)

    for signal in to_list(sequence.get("signals")):
        if not isinstance(signal, dict):
            continue
        sig_name = first_present(signal.get("name"), signal.get("description"))
        if sig_name:
            signal_names.append(sig_name)
        for endpoint_id in flatten_scalars(signal.get("endpointIds")):
            endpoint_summary = guardduty_format_endpoint_id(endpoint_id)
            if endpoint_summary:
                signal_endpoint_summaries.append(endpoint_summary)
        for indicator in to_list(signal.get("signalIndicators")):
            if not isinstance(indicator, dict):
                continue
            key = indicator.get("key")
            values = flatten_scalars(indicator.get("values"))
            if key == "ATTACK_TACTIC":
                tactics.extend(values)
            elif key == "ATTACK_TECHNIQUE":
                techniques.extend(values)

    for actor in to_list(sequence.get("actors")):
        if not isinstance(actor, dict):
            continue
        if actor.get("user"):
            user = actor.get("user", {}) or {}
            actor_name = first_present(user.get("name"), user.get("uid"), actor.get("id"))
            actor_type = first_present(user.get("type"), "User")
            if actor_name:
                actors.append(f"{actor_type}: {actor_name}")
        elif actor.get("process"):
            proc = actor.get("process", {}) or {}
            actor_name = first_present(proc.get("name"), proc.get("path"), actor.get("id"))
            if actor_name:
                actors.append(f"Process: {actor_name}")
        elif actor.get("id"):
            actors.append(str(actor.get("id")))

    for seq_resource in to_list(sequence.get("resources")):
        if not isinstance(seq_resource, dict):
            continue
        formatted_entry = guardduty_format_resource_entry(seq_resource)
        if formatted_entry:
            sequence_resource_entries.append(formatted_entry)
            sequence_resource_names.append(formatted_entry.get("value"))
            sequence_resource_types.append(formatted_entry.get("label"))
        else:
            sequence_resource_names.extend(flatten_scalars(first_present(seq_resource.get("name"), seq_resource.get("uid"))))
            sequence_resource_types.extend(flatten_scalars(seq_resource.get("resourceType")))

    for endpoint in to_list(sequence.get("endpoints")):
        if not isinstance(endpoint, dict):
            continue
        ip_value = first_present(endpoint.get("ip"))
        port_value = first_present(endpoint.get("port"))
        direction_value = first_present((endpoint.get("connection", {}) or {}).get("direction"))
        endpoint_bits = []
        if direction_value:
            endpoint_bits.append(str(direction_value))
        if ip_value:
            endpoint_text = str(ip_value)
            if is_present(port_value) and str(port_value) not in ("0", "0.0"):
                endpoint_text = f"{endpoint_text}:{port_value}"
            endpoint_bits.append(endpoint_text)
        if endpoint_bits:
            sequence_endpoint_summaries.append(" ".join(endpoint_bits))

    details["attack_tactics"] = unique_preserve(tactics)
    details["attack_techniques"] = unique_preserve(techniques)
    details["actors"] = unique_preserve(actors)
    details["signal_names"] = unique_preserve(signal_names)
    details["sequence_uid"] = first_present(sequence.get("uid"))
    details["sequence_resource_names"] = unique_preserve([x for x in sequence_resource_names if is_present(x)])
    details["sequence_resource_types"] = unique_preserve([x for x in sequence_resource_types if is_present(x)])
    details["sequence_resource_entries"] = unique_preserve(sequence_resource_entries)
    details["signal_endpoint_summaries"] = unique_preserve(signal_endpoint_summaries)
    details["sequence_endpoint_summaries"] = unique_preserve(sequence_endpoint_summaries)

    # Common resource details (EC2 / instance findings)
    network_interface_ids = []
    private_ips = []
    public_ips = []
    private_dns_names = []
    public_dns_names = []
    subnet_ids = []
    vpc_ids = []
    security_groups = []

    for eni in to_list(instance.get("networkInterfaces")):
        if not isinstance(eni, dict):
            continue
        network_interface_ids.extend(flatten_scalars(eni.get("networkInterfaceId")))
        private_ips.extend(flatten_scalars(eni.get("privateIpAddress")))
        public_ips.extend(flatten_scalars(eni.get("publicIp")))
        private_dns_names.extend(flatten_scalars(eni.get("privateDnsName")))
        public_dns_names.extend(flatten_scalars(eni.get("publicDnsName")))
        subnet_ids.extend(flatten_scalars(eni.get("subnetId")))
        vpc_ids.extend(flatten_scalars(eni.get("vpcId")))
        for ip_entry in to_list(eni.get("privateIpAddresses")):
            if isinstance(ip_entry, dict):
                private_ips.extend(flatten_scalars(ip_entry.get("privateIpAddress")))
                private_dns_names.extend(flatten_scalars(ip_entry.get("privateDnsName")))
            else:
                private_ips.extend(flatten_scalars(ip_entry))
        for sg in to_list(eni.get("securityGroups")):
            if isinstance(sg, dict):
                sg_name = first_present(sg.get("groupName"))
                sg_id = first_present(sg.get("groupId"))
                if sg_name and sg_id:
                    security_groups.append(f"{sg_name} ({sg_id})")
                elif sg_name:
                    security_groups.append(str(sg_name))
                elif sg_id:
                    security_groups.append(str(sg_id))
            else:
                security_groups.extend(flatten_scalars(sg))

    access_key_display = None
    if access_key_details:
        ak_user_name = first_present(access_key_details.get("userName"))
        ak_user_type = first_present(access_key_details.get("userType"))
        ak_principal = first_present(access_key_details.get("principalId"), access_key_details.get("accessKeyId"))
        if ak_user_name and ak_user_type:
            access_key_display = f"Access Key: {ak_user_type}: {ak_user_name}"
        else:
            fallback_access = first_present(ak_user_name, ak_principal)
            if fallback_access:
                access_key_display = f"Access Key: {fallback_access}"

    eks_cluster_display = None
    eks_cluster_name = first_present(eks_cluster_details.get("name"))
    if eks_cluster_name:
        eks_cluster_display = f"EKS Cluster: {eks_cluster_name}"

    s3_bucket_display = None
    s3_bucket_name = first_present(s3_bucket_details.get("name"))
    if s3_bucket_name:
        s3_bucket_display = f"S3 Bucket: {s3_bucket_name}"

    rds_db_display = None
    rds_db_id = first_present(rds_db_instance_details.get("dbInstanceIdentifier"))
    if rds_db_id:
        rds_db_display = f"RDS DB Instance: {rds_db_id}"

    details.update({
        "instance_id": first_present(instance.get("instanceId")),
        "instance_type": first_present(instance.get("instanceType")),
        "instance_state": first_present(instance.get("instanceState")),
        "launch_time": first_present(instance.get("launchTime")),
        "availability_zone": first_present(instance.get("availabilityZone")),
        "image_id": first_present(instance.get("imageId")),
        "image_description": first_present(instance.get("imageDescription")),
        "outpost_arn": first_present(instance.get("outpostArn")),
        "iam_instance_profile_arn": first_present((instance.get("iamInstanceProfile", {}) or {}).get("arn")),
        "iam_instance_profile_id": first_present((instance.get("iamInstanceProfile", {}) or {}).get("id")),
        "instance_tags": format_tag_pairs(instance.get("tags"), max_items=10),
        "network_interface_ids": unique_preserve(network_interface_ids),
        "private_ips": unique_preserve(private_ips),
        "public_ips": unique_preserve(public_ips),
        "private_dns_names": unique_preserve(private_dns_names),
        "public_dns_names": unique_preserve(public_dns_names),
        "subnet_ids": unique_preserve(subnet_ids),
        "vpc_ids": unique_preserve(vpc_ids),
        "security_groups": unique_preserve(security_groups),
        "access_key_display": access_key_display,
        "eks_cluster_display": eks_cluster_display,
        "s3_bucket_display": s3_bucket_display,
        "rds_db_display": rds_db_display,
    })

    # Action details
    network_action = action.get("networkConnectionAction", {}) or {}
    api_action = action.get("awsApiCallAction", {}) or {}
    dns_action = action.get("dnsRequestAction", {}) or {}
    port_probe_action = action.get("portProbeAction", {}) or {}
    kubernetes_action = action.get("kubernetesApiCallAction", {}) or {}

    local_ip_details = network_action.get("localIpDetails", {}) or {}
    remote_ip_details = network_action.get("remoteIpDetails", {}) or {}
    remote_org = remote_ip_details.get("organization", {}) or {}
    details.update({
        "action_type": first_present(action.get("actionType")),
        "connection_direction": first_present(network_action.get("connectionDirection")),
        "protocol": first_present(network_action.get("protocol")),
        "blocked": first_present(network_action.get("blocked")),
        "local_ip": first_present(local_ip_details.get("ipAddressV4"), local_ip_details.get("ipAddressV6")),
        "local_ip_v6": first_present(local_ip_details.get("ipAddressV6")),
        "local_port": first_present((network_action.get("localPortDetails", {}) or {}).get("port")),
        "local_port_name": first_present((network_action.get("localPortDetails", {}) or {}).get("portName")),
        "local_network_interface": first_present(network_action.get("localNetworkInterface")),
        "remote_ip": first_present(remote_ip_details.get("ipAddressV4"), remote_ip_details.get("ipAddressV6")),
        "remote_ip_v6": first_present(remote_ip_details.get("ipAddressV6")),
        "remote_port": first_present((network_action.get("remotePortDetails", {}) or {}).get("port")),
        "remote_port_name": first_present((network_action.get("remotePortDetails", {}) or {}).get("portName")),
        "remote_country": first_present((remote_ip_details.get("country", {}) or {}).get("countryName")),
        "remote_city": first_present((remote_ip_details.get("city", {}) or {}).get("cityName")),
        "remote_asn": first_present(remote_org.get("asn")),
        "remote_asn_org": first_present(remote_org.get("asnOrg")),
        "remote_org": first_present(remote_org.get("org")),
        "remote_isp": first_present(remote_org.get("isp")),
        "api_name": first_present(api_action.get("api")),
        "api_service_name": first_present(api_action.get("serviceName")),
        "api_caller_type": first_present(api_action.get("callerType")),
        "api_remote_ip": first_present((api_action.get("remoteIpDetails", {}) or {}).get("ipAddressV4")),
        "api_user_agent": first_present(api_action.get("userAgent")),
        "api_domain": first_present((api_action.get("remoteDomainDetails", {}) or {}).get("domain")),
        "dns_domain": first_present(dns_action.get("domain")),
        "port_probe_local_port": first_present((port_probe_action.get("portProbeDetails", [{}])[0] if to_list(port_probe_action.get("portProbeDetails")) else {}).get("localPortDetails", {}).get("port")),
        "k8s_api_call": first_present(kubernetes_action.get("verb")),
        "k8s_user": first_present((kubernetes_action.get("user", {}) or {}).get("username")),
        "k8s_resource": first_present((kubernetes_action.get("resource", {}) or {}).get("resource")),
    })

    details["threat_list_names"] = unique_preserve(threat_list_names)
    details["threat_names"] = unique_preserve(threat_names)

    return details


def guardduty_resource_side_label(resource_role):
    role = str(resource_role or '').strip().upper()
    if role == 'TARGET':
        return 'Target'
    if role == 'ACTOR':
        return 'Actor'
    return 'Resource'


def guardduty_resource_type_label(resource_type):
    resource_type = str(resource_type or '').strip().upper()
    mapping = {
        "EKS_CLUSTER": "EKS Cluster",
        "ECS_CLUSTER": "ECS Cluster",
        "KUBERNETES_WORKLOAD": "Kubernetes Workload",
        "ECS_TASK": "ECS Task",
        "EC2_INSTANCE": "EC2 Instance",
        "INSTANCE": "EC2 Instance",
        "ACCESS_KEY": "Access Key",
        "ACCESSKEY": "Access Key",
        "CONTAINER": "Container",
        "S3_BUCKET": "S3 Bucket",
        "S3BUCKET": "S3 Bucket",
        "RDS_DB_INSTANCE": "RDS DB Instance",
        "RDSDBINSTANCE": "RDS DB Instance",
    }
    return mapping.get(resource_type, resource_type.replace('_', ' ').title() if resource_type else 'Resource')


def guardduty_compact_identifier(value, max_len=22):
    if not is_present(value):
        return None
    text = str(value).strip()
    if len(text) <= max_len:
        return text
    return text[:max_len] + "…"


def guardduty_arn_tail(value):
    if not is_present(value):
        return None
    text = str(value).strip()
    if text.startswith("arn:"):
        tail = text.split(":", 5)[-1]
        if "/" in tail:
            return tail.rsplit("/", 1)[-1]
        if ":" in tail:
            return tail.rsplit(":", 1)[-1]
        return tail
    if text.startswith("container:"):
        return text.split(":", 1)[-1]
    return text


def guardduty_format_resource_entry(resource):
    if not isinstance(resource, dict):
        return None

    resource_type_raw = first_present(resource.get("resourceType"), resource.get("type"))
    resource_type = str(resource_type_raw or "").strip().upper()
    label = guardduty_resource_type_label(resource_type)

    data_block = resource.get("data", {}) or {}
    display = None

    if resource_type in ("EKS_CLUSTER", "ECS_CLUSTER"):
        display = first_present(resource.get("name"), guardduty_arn_tail(resource.get("uid")))
    elif resource_type == "KUBERNETES_WORKLOAD":
        workload = data_block.get("kubernetesWorkload", {}) or resource.get("kubernetesWorkloadDetails", {}) or {}
        namespace = first_present(workload.get("namespace"))
        workload_name = first_present(resource.get("name"), guardduty_arn_tail(resource.get("uid")), workload.get("type"))
        if namespace and workload_name:
            display = f"{namespace}/{workload_name}"
        else:
            display = workload_name
    elif resource_type == "ECS_TASK":
        task = data_block.get("ecsTask", {}) or resource.get("ecsTaskDetails", {}) or {}
        task_id = first_present(guardduty_arn_tail(resource.get("uid")))
        task_def = first_present(guardduty_arn_tail(task.get("taskDefinitionArn")))
        if task_id and task_def:
            display = f"{task_id} ({task_def})"
        else:
            display = first_present(task_id, task_def)
    elif resource_type in ("EC2_INSTANCE", "INSTANCE"):
        inst = data_block.get("ec2Instance", {}) or resource.get("instanceDetails", {}) or {}
        display = first_present(inst.get("instanceId"), resource.get("name"), guardduty_arn_tail(resource.get("uid")))
    elif resource_type in ("ACCESS_KEY", "ACCESSKEY"):
        access = data_block.get("accessKey", {}) or resource.get("accessKeyDetails", {}) or {}
        user_name = first_present(access.get("userName"))
        user_type = first_present(access.get("userType"))
        principal_id = first_present(access.get("principalId"), access.get("accessKeyId"), resource.get("uid"))
        if user_name and user_type:
            display = f"{user_type}: {user_name}"
        else:
            display = first_present(user_name, principal_id)
    elif resource_type == "CONTAINER":
        container = data_block.get("container", {}) or resource.get("containerDetails", {}) or {}
        display = first_present(
            container.get("image"),
            resource.get("name"),
            guardduty_compact_identifier(first_present(container.get("imageUid"), guardduty_arn_tail(resource.get("uid"))))
        )
    elif resource_type in ("S3_BUCKET", "S3BUCKET"):
        bucket = resource.get("s3BucketDetails", {}) or data_block.get("s3Bucket", {}) or {}
        display = first_present(bucket.get("name"), resource.get("name"), guardduty_arn_tail(resource.get("uid")))
    elif resource_type in ("RDS_DB_INSTANCE", "RDSDBINSTANCE"):
        dbi = resource.get("rdsDbInstanceDetails", {}) or data_block.get("rdsDbInstance", {}) or {}
        display = first_present(dbi.get("dbInstanceIdentifier"), resource.get("name"), guardduty_arn_tail(resource.get("uid")))

    if not display:
        display = first_present(resource.get("name"), guardduty_arn_tail(resource.get("uid")))
        if display and isinstance(display, str) and len(display) > 48 and re.fullmatch(r"[a-fA-F0-9]{40,}", display):
            display = guardduty_compact_identifier(display, max_len=18)

    if not display:
        return None

    return {
        "type": resource_type,
        "label": label,
        "value": str(display),
        "display": f"{label}: {display}"
    }


def guardduty_primary_resource_text(gd):
    if not gd or not gd.get("is_guardduty"):
        return None

    role = str(gd.get("resource_role") or "").strip().upper()
    role_label = guardduty_resource_side_label(gd.get("resource_role"))

    entries = []
    for entry in to_list(gd.get("sequence_resource_entries")):
        if isinstance(entry, dict) and is_present(entry.get("display")):
            entries.append(entry)

    if gd.get("instance_id"):
        entries.append({"type": "EC2_INSTANCE", "display": f"EC2 Instance: {gd['instance_id']}"})
    if gd.get("access_key_display"):
        entries.append({"type": "ACCESS_KEY", "display": str(gd["access_key_display"])})
    if gd.get("eks_cluster_display"):
        entries.append({"type": "EKS_CLUSTER", "display": str(gd["eks_cluster_display"])})
    if gd.get("s3_bucket_display"):
        entries.append({"type": "S3_BUCKET", "display": str(gd["s3_bucket_display"])})
    if gd.get("rds_db_display"):
        entries.append({"type": "RDS_DB_INSTANCE", "display": str(gd["rds_db_display"])})

    if not entries and gd.get("resource_type") and gd.get("resource_type") != "AttackSequence":
        fallback_label = guardduty_resource_type_label(gd.get("resource_type"))
        entries.append({
            "type": str(gd["resource_type"]).upper(),
            "display": f"{fallback_label}: {gd.get('resource_type')}"
        })

    if not entries:
        return None

    preferred_types_target = [
        "EKS_CLUSTER", "ECS_CLUSTER", "EC2_INSTANCE", "S3_BUCKET",
        "RDS_DB_INSTANCE", "KUBERNETES_WORKLOAD", "ECS_TASK",
        "ACCESS_KEY", "CONTAINER"
    ]
    preferred_types_actor = [
        "ACCESS_KEY", "EC2_INSTANCE", "KUBERNETES_WORKLOAD",
        "ECS_TASK", "CONTAINER", "EKS_CLUSTER", "ECS_CLUSTER",
        "S3_BUCKET", "RDS_DB_INSTANCE"
    ]
    preferred_types = preferred_types_actor if role == "ACTOR" else preferred_types_target

    for wanted in preferred_types:
        for entry in entries:
            if str(entry.get("type") or "").upper() == wanted and is_present(entry.get("display")):
                return role_label, str(entry["display"])

    for entry in entries:
        display = str(entry.get("display") or "")
        if display and not display.endswith(": AttackSequence"):
            return role_label, display

    return None


def guardduty_format_endpoint_id(endpoint_id):
    if not is_present(endpoint_id):
        return None

    text = str(endpoint_id).strip()
    raw_parts = text.split(":")
    if not raw_parts:
        return None

    ip = raw_parts[0] if raw_parts else None
    port = raw_parts[1] if len(raw_parts) > 1 and raw_parts[1] else None
    direction = next((p for p in raw_parts if p in ("INBOUND", "OUTBOUND")), None)

    endpoint = ip or text
    if port and port != "0":
        endpoint = f"{endpoint}:{port}"
    if direction:
        return f"{direction} {endpoint}"
    return endpoint


def guardduty_activity_text(gd):
    if not gd or not gd.get("is_guardduty"):
        return None

    if gd.get("api_name"):
        api_bits = []
        if gd.get("api_service_name"):
            api_bits.append(str(gd["api_service_name"]))
        api_bits.append(str(gd["api_name"]))
        extras = []
        if gd.get("api_caller_type"):
            extras.append(f"caller={gd['api_caller_type']}")
        if gd.get("api_remote_ip"):
            extras.append(f"source={gd['api_remote_ip']}")
        return "API call: " + " | ".join([".".join(api_bits)] + extras)

    if gd.get("dns_domain"):
        return f"DNS query: {gd['dns_domain']}"

    if gd.get("k8s_api_call") or gd.get("k8s_resource"):
        bits = []
        if gd.get("k8s_api_call"):
            bits.append(str(gd["k8s_api_call"]))
        if gd.get("k8s_resource"):
            bits.append(str(gd["k8s_resource"]))
        if gd.get("k8s_user"):
            bits.append(f"user={gd['k8s_user']}")
        return "Kubernetes API: " + " ".join(bits)

    if gd.get("connection_direction") or gd.get("remote_ip") or gd.get("local_ip"):
        endpoint_bits = []
        if gd.get("connection_direction"):
            endpoint_bits.append(str(gd["connection_direction"]))
        if gd.get("protocol"):
            endpoint_bits.append(str(gd["protocol"]))
        remote_value = first_present(gd.get("remote_ip"), gd.get("api_remote_ip"))
        if remote_value:
            remote_text = str(remote_value)
            if gd.get("remote_port"):
                remote_text = f"{remote_text}:{gd['remote_port']}"
            endpoint_bits.append(remote_text)
        if gd.get("blocked") is not None:
            endpoint_bits.append(f"blocked={bool_display(gd.get('blocked'))}")
        if endpoint_bits:
            return " ".join(endpoint_bits)

    endpoint_summaries = unique_preserve(to_list(gd.get("sequence_endpoint_summaries")) + to_list(gd.get("signal_endpoint_summaries")))
    if endpoint_summaries:
        return format_display_list(endpoint_summaries, max_items=3)

    return None


def guardduty_key_indicators(gd, max_items=6):
    indicators = []
    finding_type = str(gd.get('finding_type') or '')
    title = str(gd.get('finding_title') or '')
    description = str(gd.get('finding_description') or '')

    if 'CryptoMinerExecuted' in finding_type or 'cryptominer' in title.lower() or 'cryptominer' in description.lower() or 'xmrig' in description.lower():
        indicators.append('Cryptominer execution detected')
    if 'BitcoinTool' in finding_type or 'suspicious domain' in description.lower() or 'dns quer' in description.lower() or 'cryptomining domain' in description.lower():
        indicators.append('Suspicious DNS activity detected')
    if 'PrivilegedContainer' in finding_type or 'privileged container' in description.lower():
        indicators.append('Privileged container launched')
    if 'MaliciousFile' in finding_type or 'malicious file' in description.lower():
        indicators.append('Malicious file activity detected')
    if 'Resource Hijacking' in description or any('T1496' in t for t in to_list(gd.get('attack_techniques'))):
        indicators.append('Resource hijacking indicators observed')
    for sig in to_list(gd.get('signal_names')):
        if is_present(sig):
            indicators.append(str(sig))

    return unique_preserve(indicators)[:max_items]


def guardduty_context_summary(gd):
    if not gd or not gd.get("is_guardduty"):
        return "N/A"
    lines = []
    finding_sev = first_present(gd.get("finding_severity"))
    if finding_sev is not None:
        lines.append(f"Finding severity: {finding_sev}")
    if gd.get("finding_type"):
        lines.append(f"Finding type: {gd['finding_type']}")
    if gd.get("finding_title"):
        lines.append(f"Title: {gd['finding_title']}")
    primary_resource = guardduty_primary_resource_text(gd)
    if primary_resource:
        label, value = primary_resource
        lines.append(f"{label}: {value}")
    activity_text = guardduty_activity_text(gd)
    if activity_text:
        lines.append(f"Activity: {activity_text}")
    if gd.get("account_id"):
        lines.append(f"AWS account: {gd['account_id']}")
    if gd.get("region"):
        lines.append(f"Region: {gd['region']}")
    if gd.get("attack_tactics"):
        lines.append(f"ATT&CK tactics: {format_display_list(gd['attack_tactics'], max_items=6)}")
    if gd.get("attack_techniques"):
        lines.append(f"ATT&CK techniques: {format_display_list(gd['attack_techniques'], max_items=6)}")
    if gd.get("actors"):
        lines.append(f"Actors: {format_display_list(gd['actors'], max_items=5)}")
    return "\n".join(lines) if lines else "N/A"

def guardduty_plain_lines(gd):
    if not gd or not gd.get("is_guardduty"):
        return []

    lines = ["", "AWS GUARDDUTY DETAILS:"]

    finding_sev = gd.get("finding_severity")
    if finding_sev is not None:
        lines.append(f"  GuardDuty Severity: {finding_sev}")

    if gd.get("finding_type"):
        lines.append(f"  Finding Type: {gd['finding_type']}")
    if gd.get("finding_id"):
        lines.append(f"  Finding ID: {gd['finding_id']}")

    primary_resource = guardduty_primary_resource_text(gd)
    if primary_resource:
        label, value = primary_resource
        lines.append(f"  {label}: {value}")

    activity_text = guardduty_activity_text(gd)
    if activity_text:
        lines.append(f"  Activity: {activity_text}")

    signal_count = len(to_list(gd.get("signal_names")))
    if signal_count:
        lines.append(f"  Attack Chain Length: {signal_count} signal(s)")

    key_indicators = guardduty_key_indicators(gd)
    if key_indicators:
        lines.append("  Key Indicators: " + "; ".join(key_indicators))

    if gd.get("actors"):
        lines.append(f"  Actors: {format_display_list(gd.get('actors'), max_items=4)}")
    if gd.get("attack_tactics"):
        lines.append(f"  MITRE Tactics: {format_display_list(gd.get('attack_tactics'), max_items=6)}")
    if gd.get("attack_techniques"):
        lines.append(f"  MITRE Techniques: {format_display_list(gd.get('attack_techniques'), max_items=6)}")
    if gd.get("account_id"):
        lines.append(f"  AWS Account ID: {gd['account_id']}")
    if gd.get("region"):
        lines.append(f"  AWS Region: {gd['region']}")
    if gd.get("event_first_seen"):
        lines.append(f"  First Seen: {gd['event_first_seen']}")
    if gd.get("event_last_seen") and gd.get("event_last_seen") != gd.get("event_first_seen"):
        lines.append(f"  Last Seen: {gd['event_last_seen']}")

    return lines


def guardduty_html_rows(gd, time_from=None, time_to=None):
    if not gd or not gd.get("is_guardduty"):
        return ""

    def _filter_url(field, value):
        if not (field and is_present(value)):
            return None
        filters = [{"field": field, "value": value}]
        if time_from and time_to:
            return build_dashboard_url(filters=filters, time_from=time_from, time_to=time_to)
        return build_dashboard_url(filters=filters)

    def _row(label, value):
        return f"<tr><td style='padding:6px 8px;width:180px;color:#555;'><strong>{html.escape(str(label))}</strong></td><td style='padding:6px 8px;color:#222;'>{html.escape(str(value))}</td></tr>"

    def _row_raw(label, value):
        return f"<tr><td style='padding:6px 8px;width:180px;color:#555;'><strong>{html.escape(str(label))}</strong></td><td style='padding:6px 8px;color:#222;'>{value}</td></tr>"

    def _row_link(label, value, url):
        if url:
            return _row_raw(label, f"<a href='{html.escape(url)}' style='color:#0d47a1;text-decoration:none;'>{html.escape(str(value))}</a>")
        return _row(label, value)

    rows = ""
    rows += "<tr><td colspan='2' style='padding:10px 0;'><hr style='border:none;border-top:1px solid #e5e7eb;'></td></tr>"
    rows += "<tr><td colspan='2' style='padding:6px 8px;color:#111;'><strong>AWS GuardDuty Details</strong></td></tr>"

    finding_sev = gd.get("finding_severity")
    if finding_sev is not None:
        sev_color = get_severity_color(finding_sev)
        sev_html = f"<span style='color:{sev_color};font-weight:700;'>{html.escape(str(finding_sev))}</span>"
        rows += _row_raw("GuardDuty Severity", sev_html)
    if gd.get("finding_type"):
        rows += _row_link("Finding Type", gd["finding_type"], _filter_url("data.aws.type", gd["finding_type"]))
    if gd.get("finding_id"):
        rows += _row_link("Finding ID", gd["finding_id"], _filter_url("data.aws.id", gd["finding_id"]))

    primary_resource = guardduty_primary_resource_text(gd)
    if primary_resource:
        label, value = primary_resource
        rows += _row(label, value)

    activity_text = guardduty_activity_text(gd)
    if activity_text:
        rows += _row("Activity", activity_text)

    signal_count = len(to_list(gd.get("signal_names")))
    if signal_count:
        rows += _row("Attack Chain Length", f"{signal_count} signal(s)")

    key_indicators = guardduty_key_indicators(gd)
    if key_indicators:
        rows += _row("Key Indicators", format_display_list(key_indicators, max_items=6))
    if gd.get("actors"):
        rows += _row("Actors", format_display_list(gd.get("actors"), max_items=4))
    if gd.get("attack_tactics"):
        rows += _row("MITRE Tactics", format_display_list(gd.get("attack_tactics"), max_items=6))
    if gd.get("attack_techniques"):
        rows += _row("MITRE Techniques", format_display_list(gd.get("attack_techniques"), max_items=6))
    if gd.get("account_id"):
        rows += _row_link("AWS Account ID", gd["account_id"], _filter_url("data.aws.accountId", gd["account_id"]))
    if gd.get("region"):
        rows += _row_link("AWS Region", gd["region"], _filter_url("data.aws.region", gd["region"]))
    if gd.get("event_first_seen"):
        rows += _row("First Seen", gd["event_first_seen"])
    if gd.get("event_last_seen") and gd.get("event_last_seen") != gd.get("event_first_seen"):
        rows += _row("Last Seen", gd["event_last_seen"])

    return rows

def extract_alert_context(alert: dict) -> dict:
    """Extract relevant context from alert for AI analysis"""
    rule = alert.get("rule", {}) or {}
    agent = alert.get("agent", {}) or {}
    manager = alert.get("manager", {}) or {}
    data = alert.get("data", {}) or {}
    mitre = rule.get("mitre", {}) or {}

    # Username logic
    agent_id = agent.get("id", "N/A")
    if agent_id == "000":
        username = data.get("source_user", "N/A")
    else:
        username = data.get("win", {}).get("eventdata", {}).get("targetUserName", "N/A")

    # Enhanced Vulnerability info
    vuln = data.get("vulnerability", {}) or {}
    pkg = vuln.get("package", {}) or {}
    cvss = vuln.get("cvss", {}) or {}
    cvss3 = cvss.get("cvss3", {}) or {}
    score = vuln.get("score", {}) or {}

    vuln_text = ""
    if pkg.get("name"):
        vuln_text = f"CVE: {vuln.get('cve', 'N/A')}\n"
        vuln_text += f"Title: {vuln.get('title', 'N/A')}\n"
        vuln_text += f"Severity: {vuln.get('severity', 'N/A')}\n"
        vuln_text += f"Package: {pkg.get('name')} {pkg.get('version', '')}\n"
        vuln_text += f"Architecture: {pkg.get('architecture', 'N/A')}\n"
        vuln_text += f"Published: {vuln.get('published', 'N/A')}\n"
        vuln_text += f"Updated: {vuln.get('updated', 'N/A')}\n"
        vuln_text += f"Status: {vuln.get('status', 'N/A')}\n"
        if score.get("base"):
            vuln_text += f"CVSS Base Score: {score.get('base')} (v{score.get('version', 'N/A')})\n"
        if cvss3.get("base_score"):
            vuln_text += f"CVSS3 Base Score: {cvss3.get('base_score')}\n"
            vector = cvss3.get("vector", {}) or {}
            if vector:
                vuln_text += f"Attack Vector: {vector.get('attack_vector', 'N/A')}\n"
                vuln_text += f"Confidentiality Impact: {vector.get('confidentiality_impact', 'N/A')}\n"
                vuln_text += f"Integrity Impact: {vector.get('integrity_impact', 'N/A')}\n"
                vuln_text += f"Availability Impact: {vector.get('availability', 'N/A')}\n"
        refs = normalize_refs(vuln.get("reference"))
        if refs:
            vuln_text += f"CVE References: {', '.join(refs[:5])}"

    # Get full log data if available
    full_log = alert.get("full_log", "") or data.get("full_log", "") or ""

    # GuardDuty context for richer AI analysis and email content
    guardduty_context = extract_guardduty_context(alert, data, rule)
    guardduty_info = guardduty_context_summary(guardduty_context)

    display_description = (
        guardduty_context.get("finding_title")
        if guardduty_context.get("is_guardduty") and guardduty_context.get("finding_title")
        else rule.get("description", "Security Alert")
    )

    # === VIRUSTOTAL CONTEXT (for AI + email) ===
    vt = data.get("virustotal", {}) or {}
    vt_text = ""
    vt_summary = ""
    if vt and isinstance(vt, dict):
        vt_source = vt.get("source", {}) or {}
        vt_file = vt_source.get("file") or "N/A"
        vt_sha1 = vt.get("sha1") or vt_source.get("sha1") or "N/A"
        vt_md5 = vt_source.get("md5") or "N/A"
        vt_malicious = vt.get("malicious") or "N/A"
        vt_found = vt.get("found") or "N/A"
        vt_positives = vt.get("positives") or "N/A"
        vt_total = vt.get("total") or "N/A"
        vt_scan_date = vt.get("scan_date") or "N/A"
        vt_permalink = vt.get("permalink") or ""

        vt_summary = f"{vt_positives}/{vt_total} detections (malicious={vt_malicious}, found={vt_found})"
        lines = [
            "VirusTotal Integration:",
            f"File: {vt_file}",
            f"SHA1: {vt_sha1}",
            f"MD5: {vt_md5}",
            f"Detections: {vt_positives}/{vt_total}",
            f"Malicious: {vt_malicious} | Found: {vt_found}",
            f"Scan Date: {vt_scan_date}",
        ]
        if vt_permalink:
            lines.append(f"Permalink: {vt_permalink}")
        vt_text = "\n".join(lines)

    # GitHub Security Advisory (GHSA): fetch when alert has data.github.ghsa_id
    ghsa_advisory = None
    ghsa_info = ""
    ghsa_severity = ""
    ghsa_id = (data.get("github") or {}).get("ghsa_id")
    if ghsa_id:
        ghsa_advisory = _fetch_ghsa_advisory(ghsa_id)
        if ghsa_advisory:
            ghsa_info = _format_ghsa_for_alert(ghsa_advisory)
            ghsa_severity = (ghsa_advisory.get("severity") or "").strip() or ""
            if vuln_text:
                vuln_text = vuln_text + "\n\n---\nGitHub Security Advisory (GHSA):\n" + ghsa_info
            else:
                vuln_text = "GitHub Security Advisory (GHSA):\n" + ghsa_info

    # Get rule level and severity
    rule_level = rule.get("level", 0)
    severity = (
        "Critical" if isinstance(rule_level, int) and rule_level >= 15 else
        "High" if isinstance(rule_level, int) and rule_level >= 12 else
        "Medium" if isinstance(rule_level, int) and rule_level >= 7 else "Low"
    )

    # Rule groups and compliance
    rule_groups = ", ".join(rule.get("groups", [])) or "N/A"
    pci_dss = ", ".join(rule.get("pci_dss", [])) or "N/A"
    gdpr = ", ".join(rule.get("gdpr", [])) or "N/A"
    tsc = ", ".join(rule.get("tsc", [])) or "N/A"

    # Location and decoder
    location = alert.get("location", "N/A")
    decoder = alert.get("decoder", {}) or {}
    decoder_name = decoder.get("name", "N/A")

    # GitHub / repository context (when alert is from data.github, e.g. repository_vulnerability_alert)
    github_data = data.get("github") or {}
    github_repo = (github_data.get("repo") or "").strip() or ""
    github_owner = (github_data.get("owner") or "").strip() or ""
    github_org = (github_data.get("org") or "").strip() or ""
    github_alert_number = (github_data.get("alert_number") or "").strip() or ""
    github_action = (github_data.get("action") or "").strip() or ""

    return {
        "description": display_description,
        "severity": severity,
        "rule_level": rule_level,
        "rule_id": rule.get("id", "N/A"),
        "rule_groups": rule_groups,
        "firedtimes": rule.get("firedtimes", 0),
        "timestamp": alert.get("timestamp", "N/A"),
        "alert_id": alert.get("id", "N/A"),
        "agent_id": agent_id,
        "agent_name": agent.get("name", "Unknown Agent"),
        "agent_ip": agent.get("ip", "N/A"),
        "manager_name": manager.get("name", "N/A"),
        "username": username,
        "location": location,
        "decoder_name": decoder_name,
        "mitre_ids": ", ".join(mitre.get("id", [])),
        "mitre_tactics": ", ".join(mitre.get("tactic", [])),
        "mitre_techniques": ", ".join(mitre.get("technique", [])),
        "pci_dss": pci_dss,
        "gdpr": gdpr,
        "tsc": tsc,
        "vulnerability_info": vuln_text if vuln_text else "No vulnerability data",
        "full_log": full_log[:2000] if full_log else "No additional log data",
        "guardduty_info": guardduty_info,
        "guardduty_context": guardduty_context,
        "ghsa_advisory": ghsa_advisory,
        "ghsa_info": ghsa_info,
        "ghsa_severity": ghsa_severity,
        "virustotal_info": vt_text if vt_text else "N/A",
        "virustotal_summary": vt_summary if vt_summary else "N/A",
        "github_repo": github_repo,
        "github_owner": github_owner,
        "github_org": github_org,
        "github_alert_number": github_alert_number,
        "github_action": github_action,
    }


# === MESSAGE BUILDER ===
def generate_msg(alert, ai_analysis=None, ghsa_advisory=None):
    # Basic fields
    timestamp = alert.get("timestamp", "N/A")
    alert_id = alert.get("id", "N/A")
    rule = alert.get("rule", {}) or {}
    agent = alert.get("agent", {}) or {}
    manager = alert.get("manager", {}) or {}
    data = alert.get("data", {}) or {}
    location = alert.get("location", None)
    decoder = alert.get("decoder", {}) or {}

    rule_level = rule.get("level", 0)
    rule_id = rule.get("id", "N/A")
    rule_groups = rule.get("groups", [])
    firedtimes = rule.get("firedtimes", 0)

    # Severity
    severity = (
        "Critical" if isinstance(rule_level, int) and rule_level >= 15 else
        "High" if isinstance(rule_level, int) and rule_level >= 12 else
        "Medium" if isinstance(rule_level, int) and rule_level >= 7 else "Low"
    )

    agent_id = agent.get("id", "N/A")
    agent_name = agent.get("name", "Unknown Agent")
    agent_ip = agent.get("ip", "N/A")
    manager_name = manager.get("name", None)

    # Optional device_name override
    if agent_name == "server-master-001" and "device_name" in data:
        agent_name = data["device_name"]

    # Username logic
    if agent_id == "000":
        username = data.get("source_user", None)
    else:
        username = data.get("win", {}).get("eventdata", {}).get("targetUserName", None)

    # MITRE fields
    mitre = rule.get("mitre", {}) or {}
    mitre_ids = ", ".join(mitre.get("id", [])).strip() or None
    mitre_tactics = ", ".join(mitre.get("tactic", [])).strip() or None
    mitre_techniques = ", ".join(mitre.get("technique", [])).strip() or None

    # Vulnerability fields (enhanced)
    vuln = data.get("vulnerability", {}) or {}
    pkg = vuln.get("package", {}) or {}
    pkg_name = pkg.get("name")
    pkg_version = pkg.get("version")
    pkg_arch = pkg.get("architecture")
    pkg_source = pkg.get("source")
    cve = vuln.get("cve")
    vuln_title = vuln.get("title")
    vuln_severity = vuln.get("severity")
    published = vuln.get("published")
    updated = vuln.get("updated")
    vuln_status = vuln.get("status")
    refs = normalize_refs(vuln.get("reference"))
    scanner_refs = normalize_refs(vuln.get("scanner", {}).get("reference"))
    cvss = vuln.get("cvss", {}) or {}
    cvss3 = cvss.get("cvss3", {}) or {}
    score = vuln.get("score", {}) or {}
    cvss_base = score.get("base")
    cvss_version = score.get("version")
    cvss3_vector = cvss3.get("vector", {}) or {}
    has_vuln = any([pkg_name, pkg_version, published, refs, scanner_refs, cve])

    # === VIRUSTOTAL FIELDS (for email sections) ===
    vt = data.get("virustotal", {}) or {}
    has_vt = isinstance(vt, dict) and bool(vt)
    vt_source = vt.get("source", {}) or {}
    vt_file = vt_source.get("file")
    vt_sha1 = vt.get("sha1") or vt_source.get("sha1")
    vt_md5 = vt_source.get("md5")
    vt_malicious = vt.get("malicious")
    vt_found = vt.get("found")
    vt_positives = vt.get("positives")
    vt_total = vt.get("total")
    vt_scan_date = vt.get("scan_date")
    vt_permalink = vt.get("permalink")

    # GuardDuty details
    gd = extract_guardduty_context(alert, data, rule)
    is_guardduty = gd.get("is_guardduty", False)

    rule_description = rule.get("description", "Security Alert")
    description = (
        gd.get("finding_title")
        if is_guardduty and gd.get("finding_title")
        else rule_description
    )

    # Subject
    subject_prefix = "[GuardDuty] " if is_guardduty else ("[Vulnerability] " if has_vuln else ("[VirusTotal] " if has_vt else ""))
    subj_agent = sanitize_for_subject(agent_name, 60) or "Unknown Agent"
    subj_desc = sanitize_for_subject(description, 90) or "Security Alert"
    subject = f"{subject_prefix}[{TENANT_NAME}] Athena Alert - {severity} - {subj_agent} | {subj_desc}"

    # === Plain text body ===
    plain_lines = []
    plain_lines.append(f"{ATHENA_NAME} — Automated XDR Notification")
    plain_lines.append(f"Tenant: {TENANT_NAME}")
    plain_lines.append(f"Severity: {severity}")
    plain_lines.append("")
    plain_lines.append("This is an automated security alert generated by Athena SOC.")
    plain_lines.append("")

    # Add AI Analysis if available
    if ai_analysis:
        plain_lines.append("═══════════════════════════════════════════════════════")
        plain_lines.append("🤖  Athena AI POWERED SECURITY ANALYSIS")
        plain_lines.append("═══════════════════════════════════════════════════════")
        plain_lines.append("")

        if ai_analysis.get("executive_summary"):
            plain_lines.append("EXECUTIVE SUMMARY:")
            plain_lines.append(ai_analysis["executive_summary"])
            plain_lines.append("")

        if ai_analysis.get("detailed_analysis"):
            plain_lines.append("DETAILED ANALYSIS:")
            plain_lines.append(ai_analysis["detailed_analysis"])
            plain_lines.append("")

        if ai_analysis.get("risk_assessment"):
            plain_lines.append("RISK ASSESSMENT:")
            plain_lines.append(ai_analysis["risk_assessment"])
            plain_lines.append("")

        if ai_analysis.get("indicators_of_compromise"):
            plain_lines.append("INDICATORS OF COMPROMISE:")
            for ioc in ai_analysis["indicators_of_compromise"]:
                plain_lines.append(f"  • {ioc}")
            plain_lines.append("")

        if ai_analysis.get("recommended_priority"):
            plain_lines.append(f"AI PRIORITY: {ai_analysis['recommended_priority']}")
            plain_lines.append("")

        if ai_analysis.get("false_positive_likelihood"):
            plain_lines.append(f"FALSE POSITIVE LIKELIHOOD: {ai_analysis['false_positive_likelihood']}")
            plain_lines.append("")

        if ai_analysis.get("confidence_level"):
            plain_lines.append(f"CONFIDENCE LEVEL: {ai_analysis['confidence_level']}")
            plain_lines.append("")

        if ai_analysis.get("attack_chain_insights"):
            plain_lines.append("ATTACK CHAIN INSIGHTS:")
            plain_lines.append(ai_analysis["attack_chain_insights"])
            plain_lines.append("")

        plain_lines.append("═══════════════════════════════════════════════════════")
        plain_lines.append("")

    if is_present(timestamp): plain_lines.append(f"EVENT TIME (UTC): {timestamp}")
    if is_present(alert_id): plain_lines.append(f"ALERT ID: {alert_id}")
    if is_present(description): plain_lines.append(f"DESCRIPTION: {description}")
    if is_present(rule_level): plain_lines.append(f"RULE LEVEL: {rule_level}")
    if is_present(rule_id): plain_lines.append(f"RULE ID: {rule_id}")
    if rule_groups: plain_lines.append(f"RULE GROUPS: {', '.join(rule_groups)}")
    if firedtimes > 0: plain_lines.append(f"TIMES FIRED: {firedtimes}")
    if is_present(location): plain_lines.append(f"LOCATION: {location}")

    if is_guardduty:
        plain_lines.append("")
        plain_lines.extend(guardduty_plain_lines(gd))

    github = data.get("github") or {}
    if github and isinstance(github, dict) and github.get("repo"):
        repo = github.get("repo", "").strip()
        repo_url = f"https://github.com/{repo}" if repo else ""
        if repo_url:
            plain_lines.append(f"REPOSITORY: {repo} ({repo_url})")

    plain_lines.append("")

    if is_present(agent_name): plain_lines.append(f"AGENT NAME: {agent_name}")
    plain_lines.append("")

    if is_present(username):
        plain_lines.append(f"USERNAME: {username}")
        plain_lines.append("")

    if any([mitre_ids, mitre_tactics, mitre_techniques]):
        plain_lines.append("MITRE ATT&CK:")
        if mitre_ids: plain_lines.append(f"  MITRE ID: {mitre_ids}")
        if mitre_tactics: plain_lines.append(f"  MITRE TACTIC: {mitre_tactics}")
        if mitre_techniques: plain_lines.append(f"  MITRE TECHNIQUE: {mitre_techniques}")
        plain_lines.append("")

    if has_vuln:
        plain_lines.append("VULNERABILITY DETAILS:")
        if cve: plain_lines.append(f"  CVE: {cve}")
        if vuln_title: plain_lines.append(f"  Title: {vuln_title}")
        if vuln_severity: plain_lines.append(f"  Severity: {vuln_severity}")
        if pkg_name: plain_lines.append(f"  Package: {pkg_name}")
        if pkg_version: plain_lines.append(f"  Version: {pkg_version}")
        if pkg_arch: plain_lines.append(f"  Architecture: {pkg_arch}")
        if pkg_source: plain_lines.append(f"  Source: {pkg_source}")
        if published: plain_lines.append(f"  Published: {published}")
        if updated: plain_lines.append(f"  Updated: {updated}")
        if vuln_status: plain_lines.append(f"  Status: {vuln_status}")
        if cvss_base: plain_lines.append(f"  CVSS Base Score: {cvss_base} (v{cvss_version})")
        if cvss3_vector:
            if cvss3_vector.get("attack_vector"): plain_lines.append(f"    Attack Vector: {cvss3_vector.get('attack_vector')}")
            if cvss3_vector.get("confidentiality_impact"): plain_lines.append(f"    Confidentiality Impact: {cvss3_vector.get('confidentiality_impact')}")
            if cvss3_vector.get("integrity_impact"): plain_lines.append(f"    Integrity Impact: {cvss3_vector.get('integrity_impact')}")
            if cvss3_vector.get("availability"): plain_lines.append(f"    Availability Impact: {cvss3_vector.get('availability')}")
        if refs:
            plain_lines.append("  References:")
            for r in refs:
                plain_lines.append(f"    - {r}")
        if scanner_refs:
            plain_lines.append("  Scanner References:")
            for r in scanner_refs:
                plain_lines.append(f"    - {r}")
        plain_lines.append("")

    # === VIRUSTOTAL DETAILS (PLAIN) ===
    if has_vt:
        plain_lines.append("VIRUSTOTAL DETAILS:")
        if vt_file: plain_lines.append(f"  File: {vt_file}")
        if vt_sha1: plain_lines.append(f"  SHA1: {vt_sha1}")
        if vt_md5: plain_lines.append(f"  MD5: {vt_md5}")
        if vt_positives or vt_total:
            plain_lines.append(f"  Detections: {vt_positives or 'N/A'}/{vt_total or 'N/A'}")
        if vt_malicious is not None or vt_found is not None:
            plain_lines.append(f"  Malicious: {vt_malicious or 'N/A'} | Found: {vt_found or 'N/A'}")
        if vt_scan_date: plain_lines.append(f"  Scan Date: {vt_scan_date}")
        if vt_permalink: plain_lines.append(f"  Permalink: {vt_permalink}")
        plain_lines.append("")

    if ghsa_advisory and isinstance(ghsa_advisory, dict):
        plain_lines.append("GITHUB SECURITY ADVISORY (GHSA):")
        plain_lines.append(f"  GHSA ID: {ghsa_advisory.get('ghsa_id', 'N/A')}")
        if ghsa_advisory.get("summary"):
            plain_lines.append(f"  Summary: {ghsa_advisory['summary']}")
        plain_lines.append(f"  Severity: {ghsa_advisory.get('severity', 'N/A')}")
        if ghsa_advisory.get("type"):
            plain_lines.append(f"  Type: {ghsa_advisory['type']}")
        if ghsa_advisory.get("cve_id"):
            plain_lines.append(f"  CVE: {ghsa_advisory['cve_id']}")
        cvss = ghsa_advisory.get("cvss") or {}
        if isinstance(cvss, dict):
            if cvss.get("score") is not None:
                plain_lines.append(f"  CVSS Score: {cvss.get('score')}")
            if cvss.get("vector_string"):
                plain_lines.append(f"  CVSS Vector: {cvss.get('vector_string')}")
        if ghsa_advisory.get("published_at"):
            plain_lines.append(f"  Published At: {ghsa_advisory['published_at']}")
        if ghsa_advisory.get("updated_at"):
            plain_lines.append(f"  Updated At: {ghsa_advisory['updated_at']}")
        if ghsa_advisory.get("withdrawn_at"):
            plain_lines.append(f"  Withdrawn At: {ghsa_advisory['withdrawn_at']}")
        url = ghsa_advisory.get("html_url") or f"https://github.com/advisories/{ghsa_advisory.get('ghsa_id', '')}"
        plain_lines.append(f"  Advisory: {url}")
        vulns = ghsa_advisory.get("vulnerabilities") or []
        if vulns:
            for v in vulns[:5]:
                pkg = v.get("package") or {}
                vr = v.get("vulnerable_version_range") or "N/A"
                fp = v.get("first_patched_version")
                patched = fp.get("identifier", fp) if isinstance(fp, dict) else (fp or "N/A")
                plain_lines.append(f"  Package: {pkg.get('name', 'N/A')} ({pkg.get('ecosystem', '')}) | Vulnerable: {vr} | Patched: {patched}")
        plain_lines.append("")

    plain_lines.append("────────────────────────────────────────────────────────")
    plain_lines.append("Athena Security Group")
    plain_lines.append(f"Website: {ATHENA_WEBSITE}")
    plain_lines.append(f"Docs: {ATHENA_DOCS}")
    plain_lines.append(f"Support: {ATHENA_SUPPORT}")
    plain_lines.append("")
    plain_lines.append(f"This message was generated automatically by {ATHENA_NAME}.")
    plain_lines.append("Do not reply to this email.")
    plain = "\n".join(plain_lines).strip()

    # === HTML body ===
    def html_row(label, value):
        return f"<tr><td style='padding:6px 8px;width:180px;color:#555;'><strong>{label}</strong></td><td style='padding:6px 8px;color:#222;'>{html.escape(str(value))}</td></tr>"

    def html_row_link(label, value, dashboard_url):
        """HTML row with clickable value that links to dashboard"""
        if dashboard_url:
            link_html = f"<a href='{html.escape(dashboard_url)}' style='color:#0d47a1;text-decoration:none;'>{html.escape(str(value))}</a>"
            return f"<tr><td style='padding:6px 8px;width:180px;color:#555;'><strong>{label}</strong></td><td style='padding:6px 8px;color:#222;'>{link_html}</td></tr>"
        else:
            return html_row(label, value)

    def html_row_raw(label, value):
        """HTML row that doesn't escape HTML (for links and formatted content)"""
        return f"<tr><td style='padding:6px 8px;width:180px;color:#555;'><strong>{label}</strong></td><td style='padding:6px 8px;color:#222;'>{value}</td></tr>"

    sev_color = get_severity_color(severity)
    rec_action = action_hint(severity)

    # Build AI analysis HTML section
    ai_html = ""
    if ai_analysis:
        ai_html = """
<div style="background:#f0f9ff;border-left:4px solid #0d47a1;padding:16px;margin:16px 0;border-radius:4px;">
  <h3 style="margin:0 0 12px 0;color:#0d47a1;font-size:16px;">🤖 Athena AI: Security Analysis</h3>
"""
        if ai_analysis.get("executive_summary"):
            ai_html += f"""
  <div style="margin-bottom:12px;">
    <strong style="color:#333;">Executive Summary:</strong>
    <p style="margin:4px 0;color:#555;line-height:1.6;">{html.escape(ai_analysis['executive_summary'])}</p>
  </div>
"""
        if ai_analysis.get("detailed_analysis"):
            ai_html += f"""
  <div style="margin-bottom:12px;">
    <strong style="color:#333;">Detailed Analysis:</strong>
    <p style="margin:4px 0;color:#555;line-height:1.6;">{html.escape(ai_analysis['detailed_analysis'])}</p>
  </div>
"""
        if ai_analysis.get("risk_assessment"):
            ai_html += f"""
  <div style="margin-bottom:12px;">
    <strong style="color:#333;">Risk Assessment:</strong>
    <p style="margin:4px 0;color:#555;line-height:1.6;">{html.escape(ai_analysis['risk_assessment'])}</p>
  </div>
"""
        if ai_analysis.get("indicators_of_compromise"):
            ai_html += """
  <div style="margin-bottom:12px;">
    <strong style="color:#333;">Indicators of Compromise:</strong>
    <ul style="margin:4px 0;padding-left:20px;color:#555;">
"""
            for ioc in ai_analysis["indicators_of_compromise"]:
                ai_html += f"      <li style='margin:4px 0;font-family:monospace;'>{html.escape(ioc)}</li>\n"
            ai_html += "    </ul>\n  </div>\n"
        if ai_analysis.get("attack_chain_insights"):
            ai_html += f"""
  <div style="margin-bottom:12px;">
    <strong style="color:#333;">Attack Chain Insights:</strong>
    <p style="margin:4px 0;color:#555;line-height:1.6;">{html.escape(ai_analysis['attack_chain_insights'])}</p>
  </div>
"""
        # False Positive Likelihood + Confidence Level badges
        fp_conf_badges = ""
        if ai_analysis.get("false_positive_likelihood"):
            fp_value = ai_analysis["false_positive_likelihood"].split("—")[0].split("-")[0].strip()
            fp_color = {"High": "#22c55e", "Medium": "#facc15", "Low": "#dc2626"}.get(fp_value, "#6b7280")
            fp_conf_badges += f"<span style='display:inline-block;background:{fp_color};color:#fff;padding:4px 10px;border-radius:12px;font-size:12px;font-weight:600;margin-right:8px;'>FP Likelihood: {html.escape(ai_analysis['false_positive_likelihood'])}</span>"
        if ai_analysis.get("confidence_level"):
            cl_value = ai_analysis["confidence_level"].split("—")[0].split("-")[0].strip()
            cl_color = {"High": "#22c55e", "Medium": "#facc15", "Low": "#dc2626"}.get(cl_value, "#6b7280")
            fp_conf_badges += f"<span style='display:inline-block;background:{cl_color};color:#fff;padding:4px 10px;border-radius:12px;font-size:12px;font-weight:600;'>Confidence: {html.escape(ai_analysis['confidence_level'])}</span>"
        if fp_conf_badges:
            ai_html += f"""
  <div style="margin-top:12px;">
    {fp_conf_badges}
  </div>
"""
        ai_html += "</div>\n"

    # Build "View Full Alert" URL filtered by alert ID only
    full_alert_filters = []
    time_from = None
    time_to = None

    if is_present(timestamp):
        try:
            ts_dt = datetime.fromisoformat(timestamp.replace('Z', '+00:00'))
            time_from = (ts_dt - timedelta(minutes=30)).isoformat()
            time_to = (ts_dt + timedelta(minutes=30)).isoformat()
        except:
            pass

    if is_present(alert_id):
        full_alert_filters.append({"field": "id", "value": alert_id})

    full_alert_url = build_dashboard_url(filters=full_alert_filters, time_from=time_from, time_to=time_to) if full_alert_filters else None

    html_rows = ""
    html_rows += f"<tr><td colspan='2' style='padding:8px;'><span style='display:inline-block;background:{sev_color};color:#fff;border-radius:12px;padding:6px 16px;font-weight:700;font-size:14px;'>Severity: {severity}</span>"
    if ai_analysis and ai_analysis.get("recommended_priority"):
        priority_color = {
            "Immediate": "#e53935",
            "High": "#fb8c00",
            "Medium": "#fdd835",
            "Low": "#43a047"
        }.get(ai_analysis["recommended_priority"], "#757575")
        html_rows += f" <span style='display:inline-block;background:{priority_color};color:#fff;border-radius:12px;padding:6px 16px;font-weight:700;font-size:14px;margin-left:8px;'>AI Priority: {html.escape(ai_analysis['recommended_priority'])}</span>"
    html_rows += "</td></tr>"
    html_rows += "<tr><td colspan='2' style='padding:4px 0;'></td></tr>"

    if is_present(timestamp):
        time_url = build_dashboard_url(filters=[{"field": "timestamp", "value": timestamp}], time_from=time_from, time_to=time_to) if time_from and time_to else None
        html_rows += html_row_link("Event Time (UTC)", f"{timestamp}", time_url)

    if is_present(alert_id):
        html_rows += html_row("Alert ID", alert_id)

    if is_present(description):
        desc_filter_value = rule_description if is_present(rule_description) else description
        desc_url = build_dashboard_url(filters=[{"field": "rule.description", "value": desc_filter_value}], time_from=time_from, time_to=time_to) if time_from and time_to else build_dashboard_url(filters=[{"field": "rule.description", "value": desc_filter_value}])
        html_rows += html_row_link("Description", description, desc_url)

    if is_present(rule_level):
        html_rows += html_row("Rule Level", rule_level)

    if is_present(rule_id):
        rule_id_url = build_dashboard_url(filters=[{"field": "rule.id", "value": str(rule_id)}], time_from=time_from, time_to=time_to) if time_from and time_to else build_dashboard_url(filters=[{"field": "rule.id", "value": str(rule_id)}])
        html_rows += html_row_link("Rule ID", rule_id, rule_id_url)

    if rule_groups:
        html_rows += html_row("Rule Groups", ", ".join(rule_groups))

    if firedtimes > 0:
        fired_color = "#e53935" if firedtimes > 10 else ("#fb8c00" if firedtimes > 5 else "#757575")
        fired_display = f"<span style='color:{fired_color};font-weight:600;'>{firedtimes}</span>"
        html_rows += html_row_raw("Times Fired", fired_display)

    if is_present(location):
        html_rows += html_row("Location", location)

    if is_guardduty:
        html_rows += guardduty_html_rows(gd, time_from=time_from, time_to=time_to)

    github = data.get("github") or {}
    if github and isinstance(github, dict) and github.get("repo"):
        repo = github.get("repo", "").strip()
        repo_url = f"https://github.com/{repo}" if repo else ""
        if repo_url:
            html_rows += html_row_raw("Repository", f"<a href='{html.escape(repo_url)}' style='color:#0d47a1;text-decoration:none;'>{html.escape(repo)}</a>")

    if is_present(agent_name):
        agent_name_url = build_dashboard_url(filters=[{"field": "agent.name", "value": agent_name}], time_from=time_from, time_to=time_to) if time_from and time_to else build_dashboard_url(filters=[{"field": "agent.name", "value": agent_name}])
        html_rows += html_row_link("Agent Name", agent_name, agent_name_url)

    if is_present(username):
        username_url = build_dashboard_url(filters=[{"field": "data.win.eventdata.targetUserName", "value": username}], time_from=time_from, time_to=time_to) if time_from and time_to else build_dashboard_url(filters=[{"field": "data.win.eventdata.targetUserName", "value": username}])
        html_rows += html_row_link("Username", username, username_url)

    if any([mitre_ids, mitre_tactics, mitre_techniques]):
        html_rows += "<tr><td colspan='2' style='padding:10px 0;'><hr style='border:none;border-top:1px solid #e5e7eb;'></td></tr>"
        html_rows += "<tr><td colspan='2' style='padding:6px 8px;color:#111;'><strong>MITRE ATT&CK</strong></td></tr>"
        if mitre_ids: html_rows += html_row("MITRE ID", mitre_ids)
        if mitre_tactics: html_rows += html_row("MITRE Tactic", mitre_tactics)
        if mitre_techniques: html_rows += html_row("MITRE Technique", mitre_techniques)

    if has_vuln:
        html_rows += "<tr><td colspan='2' style='padding:10px 0;'><hr style='border:none;border-top:1px solid #e5e7eb;'></td></tr>"
        html_rows += "<tr><td colspan='2' style='padding:6px 8px;color:#111;'><strong>Vulnerability Details</strong></td></tr>"

        def vuln_filter_url(field, value):
            if not (field and is_present(value)):
                return None
            filters = [{"field": field, "value": value}]
            if time_from and time_to:
                return build_dashboard_url(filters=filters, time_from=time_from, time_to=time_to)
            return build_dashboard_url(filters=filters)

        if cve:
            html_rows += html_row_link("CVE", cve, vuln_filter_url("data.vulnerability.cve", cve))
        if vuln_title:
            html_rows += html_row_link("Title", vuln_title, vuln_filter_url("data.vulnerability.title", vuln_title))
        if vuln_severity:
            sev_color2 = get_vuln_severity_color(vuln_severity)
            sev_value = html.escape(str(vuln_severity))
            sev_url = vuln_filter_url("data.vulnerability.severity", vuln_severity)
            if sev_url:
                severity_display = f"<a href='{html.escape(sev_url)}' style='color:{sev_color2};font-weight:600;text-decoration:none;'>{sev_value}</a>"
            else:
                severity_display = f"<span style='color:{sev_color2};font-weight:600;'>{sev_value}</span>"
            html_rows += html_row_raw("Severity", severity_display)
        if pkg_name:
            html_rows += html_row_link("Package", pkg_name, vuln_filter_url("data.vulnerability.package.name", pkg_name))
        if pkg_version:
            html_rows += html_row_link("Version", pkg_version, vuln_filter_url("data.vulnerability.package.version", pkg_version))
        if pkg_arch:
            html_rows += html_row_link("Architecture", pkg_arch, vuln_filter_url("data.vulnerability.package.architecture", pkg_arch))
        if pkg_source:
            html_rows += html_row_link("Source", pkg_source, vuln_filter_url("data.vulnerability.package.source", pkg_source))
        if published: html_rows += html_row("Published", published)
        if updated: html_rows += html_row("Updated", updated)
        if vuln_status:
            html_rows += html_row_link("Status", vuln_status, vuln_filter_url("data.vulnerability.status", vuln_status))
        if cvss_base:
            html_rows += html_row("CVSS Base Score", f"{cvss_base} (v{cvss_version})")
        if cvss3_vector:
            vector_parts = []
            if cvss3_vector.get("attack_vector"): vector_parts.append(f"Attack Vector: {cvss3_vector.get('attack_vector')}")
            if cvss3_vector.get("confidentiality_impact"): vector_parts.append(f"Confidentiality: {cvss3_vector.get('confidentiality_impact')}")
            if cvss3_vector.get("integrity_impact"): vector_parts.append(f"Integrity: {cvss3_vector.get('integrity_impact')}")
            if cvss3_vector.get("availability"): vector_parts.append(f"Availability: {cvss3_vector.get('availability')}")
            if vector_parts:
                html_rows += html_row_raw("CVSS3 Vector", "<br>".join([html.escape(x) for x in vector_parts]))
        if refs:
            html_rows += html_row_raw("References", "<br>".join([linkify(r) for r in refs]))
        if scanner_refs:
            html_rows += html_row_raw("Scanner References", "<br>".join([linkify(r) for r in scanner_refs]))

    # === VIRUSTOTAL DETAILS (HTML) ===
    if has_vt:
        html_rows += "<tr><td colspan='2' style='padding:10px 0;'><hr style='border:none;border-top:1px solid #e5e7eb;'></td></tr>"
        html_rows += "<tr><td colspan='2' style='padding:6px 8px;color:#111;'><strong>VirusTotal</strong></td></tr>"

        def vt_filter_url(field, value):
            if not (field and is_present(value)):
                return None
            filters = [{"field": field, "value": value}]
            if time_from and time_to:
                return build_dashboard_url(filters=filters, time_from=time_from, time_to=time_to)
            return build_dashboard_url(filters=filters)

        if vt_file:
            html_rows += html_row_link("File", vt_file, vt_filter_url("data.virustotal.source.file", vt_file))
        if vt_sha1:
            html_rows += html_row_link("SHA1", vt_sha1, vt_filter_url("data.virustotal.sha1", vt_sha1))
        if vt_md5:
            html_rows += html_row_link("MD5", vt_md5, vt_filter_url("data.virustotal.source.md5", vt_md5))

        if vt_positives or vt_total:
            det_val = f"{vt_positives or 'N/A'}/{vt_total or 'N/A'}"
            html_rows += html_row("Detections", det_val)

        if vt_malicious is not None or vt_found is not None:
            html_rows += html_row("Flags", f"Malicious: {vt_malicious or 'N/A'} | Found: {vt_found or 'N/A'}")

        if vt_scan_date:
            html_rows += html_row("Scan Date", vt_scan_date)

        if vt_permalink:
            html_rows += html_row_raw(
                "Permalink",
                f"<a href='{html.escape(vt_permalink)}' style='color:#0d47a1;text-decoration:none;'>{html.escape(vt_permalink)}</a>"
            )

    if ghsa_advisory and isinstance(ghsa_advisory, dict):
        html_rows += "<tr><td colspan='2' style='padding:10px 0;'><hr style='border:none;border-top:1px solid #e5e7eb;'></td></tr>"
        html_rows += "<tr><td colspan='2' style='padding:6px 8px;color:#111;'><strong>GitHub Security Advisory (GHSA)</strong></td></tr>"
        html_rows += html_row("GHSA ID", ghsa_advisory.get("ghsa_id", "N/A"))
        if ghsa_advisory.get("summary"):
            html_rows += html_row("Summary", ghsa_advisory["summary"])
        if ghsa_advisory.get("severity"):
            sev_color3 = get_vuln_severity_color(ghsa_advisory["severity"])
            html_rows += html_row_raw("Severity", f"<span style='color:{sev_color3};font-weight:600;'>{html.escape(ghsa_advisory['severity'])}</span>")
        if ghsa_advisory.get("type"):
            html_rows += html_row("Type", ghsa_advisory["type"])
        if ghsa_advisory.get("cve_id"):
            html_rows += html_row("CVE", ghsa_advisory["cve_id"])
        cvss = ghsa_advisory.get("cvss") or {}
        if isinstance(cvss, dict):
            if cvss.get("score") is not None:
                html_rows += html_row("CVSS Score", cvss.get("score"))
            if cvss.get("vector_string"):
                html_rows += html_row("CVSS Vector", cvss.get("vector_string"))
        if ghsa_advisory.get("published_at"):
            html_rows += html_row("Published At", ghsa_advisory["published_at"])
        if ghsa_advisory.get("updated_at"):
            html_rows += html_row("Updated At", ghsa_advisory["updated_at"])
        if ghsa_advisory.get("withdrawn_at"):
            html_rows += html_row("Withdrawn At", ghsa_advisory["withdrawn_at"])
        url = ghsa_advisory.get("html_url") or f"https://github.com/advisories/{ghsa_advisory.get('ghsa_id', '')}"
        html_rows += html_row_raw("Advisory", f"<a href='{html.escape(url)}' style='color:#0d47a1;text-decoration:none;'>{html.escape(url)}</a>")
        vulns = ghsa_advisory.get("vulnerabilities") or []
        if vulns:
            for v in vulns[:5]:
                pkg = v.get("package") or {}
                vr = v.get("vulnerable_version_range") or "N/A"
                fp = v.get("first_patched_version")
                patched = fp.get("identifier", fp) if isinstance(fp, dict) else (fp or "N/A")
                html_rows += html_row(f"Package: {pkg.get('name', 'N/A')} ({pkg.get('ecosystem', '')})", f"Vulnerable: {vr} | Patched: {patched}")

    if full_alert_url:
        html_rows += f"""
<tr><td colspan='2' style='padding:16px 8px;text-align:left;'>
  <a href='{html.escape(full_alert_url)}' style='display:inline-block;background:#0d47a1;color:#fff;padding:10px 24px;border-radius:6px;text-decoration:none;font-weight:600;font-size:14px;'>View Alert</a>
</td></tr>
"""

    html_body = f"""
<html><body>
<div style="background:#0d47a1;color:#fff;padding:12px 18px;font-size:18px;font-weight:700;">
  {ATHENA_NAME} — Automated XDR Notification
  <div style="font-size:12px;font-weight:400;opacity:0.95;color:#ffffff;">Tenant: {html.escape(TENANT_NAME)}</div>
</div>
<div style="padding:16px 18px;font-family:Arial,sans-serif;line-height:1.5;">
  <p style="margin:0 0 16px 0;">This is an automated security alert generated by {ATHENA_NAME}.</p>
  <table cellspacing="0" cellpadding="0" border="0" style="border-collapse:collapse;font-size:14px;">{html_rows}</table>
  {ai_html}
</div>
<div style="background:#f3f4f6;color:#333;padding:12px 18px;font-size:12px;">
  <p style="margin:2px 0 6px 0;"><strong>Athena Security Group</strong></p>
  <p style="margin:2px 0;">🌐 <a href="{ATHENA_WEBSITE}" style="color:#0d47a1;text-decoration:none;">Website</a>
     &nbsp;|&nbsp; 📄 <a href="{ATHENA_DOCS}" style="color:#0d47a1;text-decoration:none;">Docs</a>
     &nbsp;|&nbsp; 📧 <a href="mailto:{ATHENA_SUPPORT}" style="color:#0d47a1;text-decoration:none;">{ATHENA_SUPPORT}</a></p>
  <p style="margin:10px 0 0 0;">This message was generated automatically by {ATHENA_NAME}. Do not reply to this email.</p>
</div>
</body></html>
""".strip()

    return subject, plain, html_body


# === SMTP SENDER (multipart: plain + HTML) ===
def send_email(to_emails, subject, plain_body, html_body) -> bool:
    try:
        msg = EmailMessage()
        msg["Subject"] = subject
        msg["To"] = ", ".join(to_emails)
        msg["From"] = formataddr((f"{ATHENA_NAME} ({TENANT_NAME})", SMTP_FROM))

        msg.set_content(plain_body)
        msg.add_alternative(html_body, subtype='html')

        if SMTP_USE_SSL:
            server = smtplib.SMTP_SSL(SMTP_HOST, SMTP_PORT, timeout=30)
        else:
            server = smtplib.SMTP(SMTP_HOST, SMTP_PORT, timeout=30)

        server.ehlo()
        if SMTP_USE_TLS and not SMTP_USE_SSL:
            server.starttls()
            server.ehlo()

        if SMTP_USERNAME and SMTP_PASSWORD:
            server.login(SMTP_USERNAME, SMTP_PASSWORD)

        server.send_message(msg)
        server.quit()
        log(f"Email sent to {to_emails}. Subject: {subject}")
        return True

    except Exception as e:
        log(f"Error sending email via SMTP: {e}")
        return False


def save_audit_report(alert, ai_analysis, subject, plain_body, html_body, recipients):
    """Save email report for audit purposes"""
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    audit_dir = f"{pwd}/audit_reports"

    os.makedirs(audit_dir, exist_ok=True)

    audit_file = f"{audit_dir}/alert_{timestamp}_{alert.get('id', 'unknown')}.json"

    audit_data = {
        "timestamp": timestamp,
        "alert_id": alert.get("id"),
        "recipients": recipients,
        "subject": subject,
        "plain_body": plain_body,
        "html_body": html_body,
        "ai_analysis": ai_analysis,
        "alert_data": alert
    }

    try:
        with open(audit_file, "w") as f:
            json.dump(audit_data, f, indent=2)
        log(f"Audit report saved: {audit_file}")
    except Exception as e:
        log(f"Failed to save audit report: {e}")


# === MAIN ===
def main(args):
    log("# Starting script execution")

    if len(args) < 4:
        log("Invalid arguments. Expected: <script> <alert_file> <not_used> <recipients> [debug]")
        return

    alert_file_location = args[1]
    recipients = args[3]
    if len(args) > 4 and args[4] == 'debug':
        global debug_enabled
        debug_enabled = True

    log(f"Alert file: {alert_file_location}")
    log(f"Recipients: {recipients}")

    try:
        with open(alert_file_location) as alert_file:
            alert = json.load(alert_file)
        log("Alert loaded successfully")

        # Use _source when alert is full ES hit; otherwise use alert as-is
        alert_doc = alert.get("_source", alert)

        if should_skip_alert(alert_doc):
            return

        # Check Agelia NRM mute rules before processing further
        if is_alert_muted(alert_doc):
            return

        # Get AI analysis (extract_alert_context fetches GHSA when data.github.ghsa_id is present)
        ai_analysis = None
        alert_context = extract_alert_context(alert_doc)

        # Skip GuardDuty sample findings unless explicitly enabled
        gd_ctx = alert_context.get("guardduty_context", {}) or {}
        is_gd_sample = gd_ctx.get("is_guardduty") and normalize_boolish(gd_ctx.get("sample")) is True
        if is_gd_sample and not SEND_GUARDDUTY_SAMPLE_ALERTS:
            log("Skipping GuardDuty sample finding because SEND_GUARDDUTY_SAMPLE_ALERTS=false")
            return

        if OLLAMA_ENABLED:
            ai_analysis = get_ai_analysis(alert_context)
            if ai_analysis:
                log("AI analysis integrated successfully")
            else:
                log("Proceeding without AI analysis")

        subject, plain, html_body = generate_msg(
            alert_doc,
            ai_analysis,
            ghsa_advisory=alert_context.get("ghsa_advisory")
        )

        log(f"Subject: {subject}")
        save_audit_report(alert, ai_analysis, subject, plain, html_body, recipients)
        send_email([r.strip() for r in recipients.split(',') if r.strip()], subject, plain, html_body)

    except Exception as e:
        log(f"Error processing alert: {e}")


if __name__ == "__main__":
    try:
        main(sys.argv)
    except Exception as e:
        log(f"Unhandled exception: {e}")
        raise
