# Athena Notifications Setup Instructions (Linux)

## AI Integration

All notification scripts use **Ollama** with the `qwen2.5:14b-instruct` model for AI-powered security analysis of alerts. Ollama runs locally — no external API keys required.

### Ollama Configuration

Set the following in your `.env` file:

```env
OLLAMA_HOST=localhost
OLLAMA_PORT=11434
OLLAMA_MODEL=qwen2.5:14b-instruct
OLLAMA_ENABLED=true
```

| Variable | Description | Default |
|----------|-------------|---------|
| `OLLAMA_HOST` | Ollama server IP or hostname | `localhost` |
| `OLLAMA_PORT` | Ollama server port | `11434` |
| `OLLAMA_MODEL` | Model to use for AI analysis | `qwen2.5:14b-instruct` |
| `OLLAMA_ENABLED` | Enable/disable AI analysis | `true` |

### Ollama Variable Reference

| Variable | Description | Default | Notes |
|----------|-------------|---------|-------|
| `OLLAMA_HOST` | IP or hostname of the Ollama server | `localhost` | Use the IP/hostname where Ollama is running. Can be a remote server. |
| `OLLAMA_PORT` | Ollama HTTP API port | `11434` | Default Ollama port. Only change if Ollama is configured on a custom port. |
| `OLLAMA_MODEL` | Model name for AI analysis | `qwen2.5:14b-instruct` | Must be pulled first via `ollama pull`. 14B model recommended for quality/speed balance. |
| `OLLAMA_ENABLED` | Enable/disable AI-powered analysis | `true` | Set to `false` to skip AI analysis entirely. Emails will still be sent but without AI sections. |

> **Note:** Ollama uses the OpenAI-compatible API endpoint (`/v1/chat/completions`). No API key is required — authentication is not needed for local Ollama instances.

### AI Analysis Tuning

The following parameters are configured internally (not via `.env`) and optimized for the `qwen2.5:14b-instruct` model running on Ollama:

| Parameter | SIEM Alerts | NIDS Alerts | Description |
|-----------|------------|-------------|-------------|
| `max_tokens` | 4096 | 4096 | Maximum response length. Optimized for Ollama (no per-token cost). |
| `temperature` | 0.3 | 0.3 | Low temperature for consistent, factual responses. |
| `timeout` | 180s | 180s | HTTP request timeout for Ollama API calls. |

All prompts include anti-hallucination guardrails — the model is instructed not to speculate when data fields are empty or unavailable.

### Ollama Prerequisites

- Ollama server installed and running
- `qwen2.5:14b-instruct` model pulled (`ollama pull qwen2.5:14b-instruct`)
- Network connectivity from Athena server to Ollama server

## Notification Types

### SIEM Alert Notifications (`email_notifications_siem.py`)
Real-time security alert notifications triggered by Wazuh integration:
- AI-powered analysis of individual security alerts (executive summary, mitigation steps, risk assessment)
- AI `false_positive_likelihood` — assesses likelihood of false positive with justification
- AI `confidence_level` — self-rates analysis confidence (High/Medium/Low) for analyst calibration
- GitHub Security Advisory (GHSA) enrichment for vulnerability alerts
- VirusTotal enrichment for malware alerts
- GuardDuty context for AWS findings
- MITRE ATT&CK mapping and compliance context

### NIDS/Suricata Alert Notifications (`email_notifications_nids.py`)
Network intrusion detection alert notifications via systemd timer (every 60 seconds):
- AI-powered analysis of Suricata NIDS alerts
- AI `false_positive_likelihood` — assesses likelihood of false positive with justification
- AI `confidence_level` — self-rates analysis confidence (High/Medium/Low) for analyst calibration
- Cross-alert `correlation_analysis` for batched alerts (common attacker IPs, campaign patterns, coordinated activity)
- Attacker attribution via X-Forwarded-For (XFF) header
- Network topology and traffic analysis
- HTTP status code analysis for attack success assessment

## Prerequisites

- Linux system with systemd
- Python 3 installed
- Git installed
- SSH access to GitHub repository
- sudo access
- Ollama server accessible from Athena server

## Quick Setup

### Step 1: Clone Repository

```bash
cd /opt
sudo git clone git@github.com:Athena-Software-Group/athena-integrations.git
cd athena-integrations/notifications
```

### Step 3: Run Setup Script

```bash
./setup_nids_notification.sh
```

The script will:
- Clone/update the repository to `/opt/athena-integrations/notifications`
- Set proper permissions for logs and state files
- Create necessary directories
- Set up systemd timer to run every 60 seconds
- Configure the service to start on boot

### Step 4: Configure Environment

Create or edit `.env` file:

```bash
nano /opt/athena-integrations/notifications/.env
```

Required variables:
- `ES_HOST` - Elasticsearch/OpenSearch URL
- `ES_USERNAME` - Elasticsearch username
- `ES_PASSWORD` - Elasticsearch password
- `SMTP_HOST` - SMTP server
- `SMTP_USERNAME` - SMTP username
- `SMTP_PASSWORD` - SMTP password
- `SMTP_RECIPIENT` - Email recipient(s)
- `OLLAMA_HOST` - Ollama server IP or hostname
- `OLLAMA_PORT` - Ollama server port (default: 11434)
- `OLLAMA_MODEL` - Ollama model (default: qwen2.5:14b-instruct)
- `OLLAMA_ENABLED` - Enable AI analysis (default: true)

### Step 5: Verify Installation

```bash
# Check timer status
sudo systemctl status athena-nids-notifier.timer

# View recent logs
sudo journalctl -u athena-nids-notifier.service -n 50

# Follow logs in real-time
sudo journalctl -u athena-nids-notifier.service -f

# Check application logs
tail -f /opt/athena-integrations/notifications/logs/athena-suricata-email-notifier.log
```

### Step 6: Test Manually

```bash
cd /opt/athena-integrations/notifications
python3 email_notifications_nids.py
```

## Upgrading to a New Version

### Upgrading NIDS Notifications

To upgrade an existing NIDS installation to the latest version:

```bash
# 1. Stop the service
sudo systemctl stop athena-nids-notifier.timer

# 2. Navigate to installation directory
cd /opt/athena-integrations/notifications

# 3. Pull latest changes
git pull

# 4. Start the service
sudo systemctl start athena-nids-notifier.timer

# 5. Verify the service is running
sudo systemctl status athena-nids-notifier.timer

# 6. Check logs to ensure everything is working
sudo journalctl -u athena-nids-notifier.service -n 50
```

**Note:** The state file (`athena-notifier-nids/suricata-email-notifier.state.json`) is not tracked in git and will remain unchanged during upgrades, preserving your notification state.

### Upgrading SIEM Notifications

To upgrade an existing SIEM installation to the latest version:

```bash
# 1. Navigate to installation directory
cd /opt/athena-integrations/notifications

# 2. Pull latest changes
git pull

# 3. Copy the updated SIEM notification script to Wazuh integration directory
sudo cp email_notifications_siem.py /var/ossec/integrations/custom-athena-email-notification

# 4. Restart Wazuh manager to pick up the changes
sudo systemctl restart wazuh-manager

# 5. Verify Wazuh manager is running
sudo systemctl status wazuh-manager

# 6. Check Wazuh logs to ensure everything is working
sudo tail -f /var/ossec/logs/ossec.log
```

**Note:** Make sure the integration is properly configured in `/var/ossec/etc/ossec.conf` and the environment variables are set in `/var/ossec/integrations/.env` before restarting the service.


## File Permissions

The setup script ensures:
- Log directory: `/opt/athena-integrations/notifications/logs/` - writable by service user
- Log file: `athena-suricata-email-notifier.log` - permissions 666
- State directory: `/opt/athena-integrations/notifications/athena-notifier-nids/` - writable by service user
- State file: `suricata-email-notifier.state.json` - permissions 666

## Service Management

```bash
# Start timer
sudo systemctl start athena-nids-notifier.timer

# Stop timer
sudo systemctl stop athena-nids-notifier.timer

# Enable on boot
sudo systemctl enable athena-nids-notifier.timer

# Disable on boot
sudo systemctl disable athena-nids-notifier.timer

# Check status
sudo systemctl status athena-nids-notifier.timer

# View logs
sudo journalctl -u athena-nids-notifier.service -f

# Restart timer
sudo systemctl restart athena-nids-notifier.timer
```

## Troubleshooting

### Permission Issues

If you see permission errors:

```bash
# Fix ownership
sudo chown -R $USER:$USER /opt/athena-integrations/notifications

# Fix permissions
chmod 755 /opt/athena-integrations/notifications/logs
chmod 666 /opt/athena-integrations/notifications/logs/*.log
chmod 755 /opt/athena-integrations/notifications/athena-notifier-nids
chmod 666 /opt/athena-integrations/notifications/athena-notifier-nids/*.json
```

### Service Not Running

```bash
# Check if timer is active
sudo systemctl is-active athena-nids-notifier.timer

# Check timer status
sudo systemctl status athena-nids-notifier.timer

# Restart timer
sudo systemctl restart athena-nids-notifier.timer

# Check if service failed
sudo systemctl status athena-nids-notifier.service
```

### Check Logs

```bash
# Systemd logs
sudo journalctl -u athena-nids-notifier.service -f

# Application logs
tail -f /opt/athena-integrations/notifications/logs/athena-suricata-email-notifier.log

# State file
cat /opt/athena-integrations/notifications/athena-notifier-nids/suricata-email-notifier.state.json
```

## Uninstallation

```bash
sudo systemctl stop athena-nids-notifier.timer
sudo systemctl disable athena-nids-notifier.timer
sudo rm /etc/systemd/system/athena-nids-notifier.service
sudo rm /etc/systemd/system/athena-nids-notifier.timer
sudo systemctl daemon-reload
```

## Quick Reference

```bash
# === COMPLETE SETUP ===
cd /opt
sudo git clone git@github.com:Athena-Software-Group/athena-integrations.git
cd athena-integrations/notifications
./setup_nids_notification.sh

# === VERIFY ===
sudo systemctl status athena-nids-notifier.timer
sudo journalctl -u athena-nids-notifier.service -f

# === TEST MANUALLY ===
cd /opt/athena-integrations/notifications
python3 email_notifications_nids.py
```
