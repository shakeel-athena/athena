#!/usr/bin/env python3
import requests
import json
import time
import sys
import os
from pathlib import Path
from datetime import datetime, timezone


BASE_DIR = Path(__file__).resolve().parent
ENV_FILE = BASE_DIR / ".env"

def load_env_file(env_path: Path):
    if not env_path.exists():
        return
    for raw_line in env_path.read_text().splitlines():
        line = raw_line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, value = line.split("=", 1)
        os.environ.setdefault(key.strip(), value.strip().strip('"').strip("'"))

load_env_file(ENV_FILE)

# =====================================================
# 🔧 CONFIGURATION (loaded from .env when present)
# =====================================================
GITHUB_TOKEN = os.getenv("GITHUB_TOKEN", "")
OWNER = os.getenv("GITHUB_OWNER", "Athena-Software-Group")
OUTPUT_FILE = os.getenv("OUTPUT_FILE", str(BASE_DIR / "github_dependabot.json"))
CHECKPOINT_FILE = os.getenv("CHECKPOINT_FILE", str(BASE_DIR / "github_dependabot_checkpoint.json"))

STATE_FILTER = os.getenv("STATE_FILTER", "open")
POLL_SECONDS = int(os.getenv("POLL_SECONDS", "60"))
PER_PAGE = int(os.getenv("PER_PAGE", "100"))

API_BASE = "https://api.github.com"


def iso_now():
    return datetime.now(timezone.utc).isoformat()

def load_checkpoint():
    try:
        with open(CHECKPOINT_FILE, "r") as f:
            return json.load(f)
    except:
        return {}

def save_checkpoint(data):
    with open(CHECKPOINT_FILE, "w") as f:
        json.dump(data, f, indent=2)

def fetch_org_alerts(session, last_updated):
    url = f"{API_BASE}/orgs/{OWNER}/dependabot/alerts"
    params = {
        "per_page": PER_PAGE,
        "sort": "updated",
        "direction": "asc"
    }
    if STATE_FILTER != "all":
        params["state"] = STATE_FILTER
    events = []
    newest = last_updated

    while url:
        r = session.get(url, params=params)
        if r.status_code != 200:
            print(f"[{iso_now()}] ERROR {r.status_code}: {r.text}")
            return [], last_updated
        data = r.json()

        if not isinstance(data, list):
            print(f"[{iso_now()}] ERROR: Unexpected response: {data}")
            return [], last_updated

        for alert in data:
            updated = alert.get("updated_at")
            if last_updated and updated and updated <= last_updated:
                continue

            advisory = alert.get("security_advisory", {}) or {}
            vuln = alert.get("security_vulnerability", {}) or {}
            cvss = advisory.get("cvss", {}) or {}
            repo_info = alert.get("repository", {}) or {}
            package_info = vuln.get("package") or {}
            dismissed_by = alert.get("dismissed_by", {}) or {}
            dependency = alert.get("dependency", {}) or {}

            event = {
                "@timestamp": iso_now(),
                "integration": "github_dependabot",
                "org": OWNER,
                "repo": repo_info.get("full_name"),
                "repo_name": repo_info.get("name"),
                "repo_private": repo_info.get("private"),
                "repo_archived": repo_info.get("archived"),
                "number": alert.get("number"),
                "state": alert.get("state"),
                "dependency_scope": alert.get("dependency_scope"),
                "created_at": alert.get("created_at"),
                "updated_at": updated,
                "dismissed_at": alert.get("dismissed_at"),
                "dismissed_reason": alert.get("dismissed_reason"),
                "dismissed_comment": alert.get("dismissed_comment"),
                "dismissed_by": dismissed_by.get("login"),
                "fixed_at": alert.get("fixed_at"),
                "severity": vuln.get("severity"),
                "cvss_score": cvss.get("score"),
                "cvss_vector": cvss.get("vector_string"),
                "ghsa_id": advisory.get("ghsa_id"),
                "cve_id": advisory.get("cve_id"),
                "summary": advisory.get("summary"),
                "description": advisory.get("description"),
                "package": package_info.get("name"),
                "ecosystem": package_info.get("ecosystem"),
                "manifest_path": dependency.get("manifest_path"),
                "manifest_name": dependency.get("manifest_name"),
                "html_url": alert.get("html_url")
            }
            events.append(event)
            if updated and (not newest or updated > newest):
                newest = updated
        if "next" in r.links:
            url = r.links["next"]["url"]
            params = {}
        else:
            url = None
    return events, newest


def main():
    if not GITHUB_TOKEN or GITHUB_TOKEN in ["your_github_token_here", "xxx"]:
        print("ERROR: Please paste your GitHub token in script.")
        sys.exit(1)

    session = requests.Session()
    session.headers.update({
        "Accept": "application/vnd.github+json",
        "Authorization": f"Bearer {GITHUB_TOKEN}",
        "X-GitHub-Api-Version": "2022-11-28"
    })

    print(f"[{iso_now()}] Collector started for org: {OWNER}")
    while True:
        checkpoint = load_checkpoint()
        last_updated = checkpoint.get(OWNER)
        events, newest = fetch_org_alerts(session, last_updated)
        total_new = 0
        if events:
            with open(OUTPUT_FILE, "a") as f:
                for e in events:
                    f.write(json.dumps(e, separators=(",", ":")) + "\n")
            total_new = len(events)
        if newest:
            checkpoint[OWNER] = newest
            save_checkpoint(checkpoint)
        print(f"[{iso_now()}] Cycle complete. New events: {total_new}")
        time.sleep(POLL_SECONDS)


if __name__ == "__main__":
    main()
