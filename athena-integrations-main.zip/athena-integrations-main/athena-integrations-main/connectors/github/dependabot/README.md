# GitHub Dependabot → Wazuh Integration
This module collects GitHub Dependabot security alerts from the Athena GitHub organization and forwards them to Wazuh so they can be processed by the Athena security pipeline.

The collector queries the GitHub API periodically and writes alerts to a JSON file that Wazuh ingests as events.


### Step 1: Clone Repository
```bash
cd /opt
sudo git clone git@github.com:Athena-Software-Group/athena-integrations.git
cd athena-integrations/connectors/github/dependabot
```

### Step 2: Configure Environment Variables
Copy the example env file
```bash
cp .env.example .env
```
Edit `.env`:
```bash
nano .env
```
> !Important The GitHub token must have permission to read Dependabot alerts.

### Step 3: Run Installation Script
```bash
sudo ./install.sh
```
This will:
- install Python dependencies
- install Wazuh detection rules
- create a systemd service
- start the Dependabot collector

### Step 4: Configure Wazuh Log Ingestion
Add following to `/var/ossec/etc/ossec.conf`:
```xml
<localfile>
  <log_format>json</log_format>
  <location>/opt/athena-integrations/connectors/github/dependabot/github_dependabot.json</location>
</localfile>
```

Restart Wazuh:
```bash
systemctl restart wazuh-manager
```

Start and enable GitHub Dependabot Collector Service:
```bash
systemctl enable --now ${SERVICE_NAME}
systemctl start ${SERVICE_NAME}
```

## Verifying Installation
Check the service:
```bash
systemctl status github-dependabot
```

Watch the collector output:
```bash
tail -f /opt/athena-integrations/connectors/github/dependabot/github_dependabot.json
```

Check checkpoints:
```bash
tail -f /opt/athena-integrations/connectors/github/dependabot/github_dependabot_checkpoint.json
```