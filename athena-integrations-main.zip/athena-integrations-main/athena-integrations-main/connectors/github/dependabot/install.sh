#!/bin/bash
set -e

echo "Installing GitHub Dependabot → Wazuh integration..."

INSTALL_DIR="/opt/athena-integrations/connectors/github/dependabot"
SCRIPT_NAME="github_dependabot.py"
SERVICE_NAME="github-dependabot"
SERVICE_USER=$(whoami)
PYTHON_PATH=$(which python3)

if [ -z "$PYTHON_PATH" ]; then
    echo -e "${RED}Error: python3 not found in PATH${NC}"
    exit 1
fi

echo "Setting up rules..."
sudo -u wazuh cp $INSTALL_DIR/rules/github-dependabot.xml /var/ossec/etc/rules/github-dependabot.xml

echo "Creating Python virtual environment..."
VENV_DIR="$INSTALL_DIR/venv"
sudo $PYTHON_PATH -m venv $VENV_DIR
echo "Installing Python dependencies inside venv..."
sudo $VENV_DIR/bin/pip install --upgrade pip
sudo $VENV_DIR/bin/pip install requests python-dotenv

echo "Creating systemd service..."
sudo tee /etc/systemd/system/${SERVICE_NAME}.service > /dev/null <<EOF
[Unit]
Description=GitHub Dependabot Collector
After=network.target

[Service]
Type=simple
WorkingDirectory=$INSTALL_DIR
Environment="PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin"
ExecStart=$INSTALL_DIR/venv/bin/python $INSTALL_DIR/$SCRIPT_NAME
Restart=always
RestartSec=10
User=root

[Install]
WantedBy=multi-user.target
EOF

echo "Reloading systemd..."
sudo systemctl daemon-reexec
sudo systemctl daemon-reload

echo ""
echo "GitHub Collector installed successfully."
echo "Output JSON file will be generated in:"
echo "  $INSTALL_DIR/github_dependabot.json"
echo ""
echo "Next, add this to /var/ossec/etc/ossec.conf"
echo "  <localfile>"
echo "      <log_format>json</log_format>"
echo "      <location>$INSTALL_DIR/github_dependabot.json</location>"
echo "  </localfile>"
echo ""
echo ""
echo "And restart the manager"
echo "  sudo systemctl restart wazuh-manager"
echo ""
echo "Start the GitHub Dependabot Collector Service"
echo "  sudo systemctl enable --now ${SERVICE_NAME}"
echo "  sudo systemctl start ${SERVICE_NAME}"
echo ""
echo "After, check if the collector is generating checkpoints:"
echo "  tail -f $INSTALL_DIR/github_dependabot_checkpoint.json"