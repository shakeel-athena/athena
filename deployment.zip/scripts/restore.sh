#!/bin/bash
# =============================================================================
# Athena Security Platform - Restore Script
# =============================================================================
# Restores database and configuration from backup files.
#
# Usage: ./restore.sh [--list] [--backup NAME] [--db-only] [--config-only]
# =============================================================================

set -e

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

# Configuration
APP_DIR="${APP_DIR:-/opt/athena/app}"
BACKUP_DIR="${BACKUP_DIR:-/opt/athena/app/deployment/backups}"
KEYCLOAK_DIR="${KEYCLOAK_DIR:-/opt/keycloak}"

# Flags
LIST_ONLY=false
DB_ONLY=false
CONFIG_ONLY=false
BACKUP_NAME=""

# =============================================================================
# Helper Functions
# =============================================================================

log_info() {
    echo -e "${GREEN}[INFO]${NC} $1"
}

log_warn() {
    echo -e "${YELLOW}[WARN]${NC} $1"
}

log_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

parse_args() {
    while [[ $# -gt 0 ]]; do
        case $1 in
            --list)
                LIST_ONLY=true
                shift
                ;;
            --backup)
                BACKUP_NAME="$2"
                shift 2
                ;;
            --db-only)
                DB_ONLY=true
                shift
                ;;
            --config-only)
                CONFIG_ONLY=true
                shift
                ;;
            --backup-dir)
                BACKUP_DIR="$2"
                shift 2
                ;;
            -h|--help)
                echo "Usage: $0 [OPTIONS]"
                echo ""
                echo "Options:"
                echo "  --list          List available backups"
                echo "  --backup NAME   Backup name to restore (without extension)"
                echo "  --db-only       Restore database only"
                echo "  --config-only   Restore configuration only"
                echo "  --backup-dir    Custom backup directory"
                echo "  -h, --help      Show this help"
                echo ""
                echo "Example:"
                echo "  $0 --list"
                echo "  $0 --backup athena_backup_20250115_120000"
                exit 0
                ;;
            *)
                log_error "Unknown option: $1"
                exit 1
                ;;
        esac
    done
}

load_env() {
    if [[ -f "$APP_DIR/.env" ]]; then
        set -a
        source "$APP_DIR/.env"
        set +a
    fi
}

# =============================================================================
# List Functions
# =============================================================================

list_backups() {
    echo ""
    echo "=== Available Backups ==="
    echo ""
    echo "Backup directory: $BACKUP_DIR"
    echo ""

    # Get unique backup names
    echo "Database backups:"
    if ls "$BACKUP_DIR"/*_database.sql.gz 2>/dev/null >/dev/null; then
        for f in $(ls -t "$BACKUP_DIR"/*_database.sql.gz); do
            name=$(basename "$f" _database.sql.gz)
            size=$(ls -lh "$f" | awk '{print $5}')
            date=$(stat -c %y "$f" 2>/dev/null || stat -f %Sm "$f" 2>/dev/null | cut -d' ' -f1-2)
            echo "  $name ($size) - $date"
        done
    else
        echo "  (none found)"
    fi

    echo ""
    echo "Configuration backups:"
    if ls "$BACKUP_DIR"/*_config.tar.gz 2>/dev/null >/dev/null; then
        for f in $(ls -t "$BACKUP_DIR"/*_config.tar.gz); do
            name=$(basename "$f" _config.tar.gz)
            size=$(ls -lh "$f" | awk '{print $5}')
            date=$(stat -c %y "$f" 2>/dev/null || stat -f %Sm "$f" 2>/dev/null | cut -d' ' -f1-2)
            echo "  $name ($size) - $date"
        done
    else
        echo "  (none found)"
    fi

    echo ""
    echo "Keycloak backups:"
    if ls "$BACKUP_DIR"/*_keycloak.sql.gz 2>/dev/null >/dev/null; then
        for f in $(ls -t "$BACKUP_DIR"/*_keycloak.sql.gz); do
            name=$(basename "$f" _keycloak.sql.gz)
            size=$(ls -lh "$f" | awk '{print $5}')
            date=$(stat -c %y "$f" 2>/dev/null || stat -f %Sm "$f" 2>/dev/null | cut -d' ' -f1-2)
            echo "  $name ($size) - $date"
        done
    else
        echo "  (none found)"
    fi

    echo ""
    echo "To restore, use: $0 --backup <backup_name>"
    echo ""
}

# =============================================================================
# Restore Functions
# =============================================================================

confirm_restore() {
    echo ""
    echo -e "${YELLOW}WARNING: This will overwrite existing data!${NC}"
    echo ""
    read -p "Are you sure you want to restore from '$BACKUP_NAME'? (y/N): " confirm
    if [[ "$confirm" != "y" && "$confirm" != "Y" ]]; then
        log_info "Restore cancelled"
        exit 0
    fi
}

restore_database() {
    if [[ "$CONFIG_ONLY" == "true" ]]; then
        return
    fi

    DB_BACKUP_FILE="$BACKUP_DIR/${BACKUP_NAME}_database.sql.gz"

    if [[ ! -f "$DB_BACKUP_FILE" ]]; then
        log_warn "Database backup not found: $DB_BACKUP_FILE"
        return
    fi

    log_info "Restoring PostgreSQL database..."

    DB_HOST="${POSTGRES_HOST:-localhost}"
    DB_USER="${POSTGRES_USER:-athena_user}"
    DB_NAME="${POSTGRES_DB:-athena_db}"

    # Stop backend service to prevent conflicts
    if systemctl is-active athena-backend >/dev/null 2>&1; then
        log_info "Stopping athena-backend service..."
        sudo systemctl stop athena-backend
    fi

    # Decompress and restore
    TEMP_SQL="/tmp/athena_restore_$$.sql"
    gunzip -c "$DB_BACKUP_FILE" > "$TEMP_SQL"

    # Drop and recreate database
    log_info "Recreating database..."
    PGPASSWORD="$POSTGRES_PASSWORD" psql -h "$DB_HOST" -U "$DB_USER" -d postgres <<EOF
SELECT pg_terminate_backend(pid) FROM pg_stat_activity WHERE datname = '$DB_NAME' AND pid <> pg_backend_pid();
DROP DATABASE IF EXISTS $DB_NAME;
CREATE DATABASE $DB_NAME OWNER $DB_USER;
EOF

    # Restore
    log_info "Restoring data..."
    PGPASSWORD="$POSTGRES_PASSWORD" psql -h "$DB_HOST" -U "$DB_USER" -d "$DB_NAME" -f "$TEMP_SQL"

    # Cleanup
    rm -f "$TEMP_SQL"

    # Grant permissions
    PGPASSWORD="$POSTGRES_PASSWORD" psql -h "$DB_HOST" -U "$DB_USER" -d "$DB_NAME" <<EOF
GRANT ALL ON ALL TABLES IN SCHEMA public TO $DB_USER;
GRANT ALL ON ALL SEQUENCES IN SCHEMA public TO $DB_USER;
EOF

    log_info "Database restore complete"
}

restore_config() {
    if [[ "$DB_ONLY" == "true" ]]; then
        return
    fi

    CONFIG_BACKUP_FILE="$BACKUP_DIR/${BACKUP_NAME}_config.tar.gz"

    if [[ ! -f "$CONFIG_BACKUP_FILE" ]]; then
        log_warn "Configuration backup not found: $CONFIG_BACKUP_FILE"
        return
    fi

    log_info "Restoring configuration files..."

    # Extract to temp directory
    TEMP_DIR="/tmp/athena_config_restore_$$"
    mkdir -p "$TEMP_DIR"
    tar -xzf "$CONFIG_BACKUP_FILE" -C "$TEMP_DIR"

    CONFIG_DIR="$TEMP_DIR/${BACKUP_NAME}_config"

    # Restore backend .env
    if [[ -f "$CONFIG_DIR/backend.env" ]]; then
        cp "$CONFIG_DIR/backend.env" "$APP_DIR/.env"
        log_info "Restored: backend .env"
    fi

    # Restore frontend .env.production
    if [[ -f "$CONFIG_DIR/frontend.env.production" ]]; then
        cp "$CONFIG_DIR/frontend.env.production" "$APP_DIR/frontend/.env.production"
        log_info "Restored: frontend .env.production"
    fi

    # Restore nginx config (with confirmation)
    if [[ -f "$CONFIG_DIR/nginx-athena.conf" ]]; then
        read -p "Restore nginx config? (y/N): " confirm_nginx
        if [[ "$confirm_nginx" == "y" || "$confirm_nginx" == "Y" ]]; then
            sudo cp "$CONFIG_DIR/nginx-athena.conf" "/etc/nginx/conf.d/athena.conf"
            log_info "Restored: nginx config"
        fi
    fi

    # Restore systemd service (with confirmation)
    if [[ -f "$CONFIG_DIR/athena-backend.service" ]]; then
        read -p "Restore systemd service? (y/N): " confirm_systemd
        if [[ "$confirm_systemd" == "y" || "$confirm_systemd" == "Y" ]]; then
            sudo cp "$CONFIG_DIR/athena-backend.service" "/etc/systemd/system/"
            sudo systemctl daemon-reload
            log_info "Restored: systemd service"
        fi
    fi

    # Restore keycloak docker-compose
    if [[ -f "$CONFIG_DIR/keycloak-docker-compose.yml" ]]; then
        cp "$CONFIG_DIR/keycloak-docker-compose.yml" "$KEYCLOAK_DIR/docker-compose.yml"
        log_info "Restored: keycloak docker-compose"
    fi

    # Cleanup
    rm -rf "$TEMP_DIR"

    log_info "Configuration restore complete"
}

restore_keycloak() {
    if [[ "$DB_ONLY" == "true" ]] || [[ "$CONFIG_ONLY" == "true" ]]; then
        return
    fi

    KC_BACKUP_FILE="$BACKUP_DIR/${BACKUP_NAME}_keycloak.sql.gz"

    if [[ ! -f "$KC_BACKUP_FILE" ]]; then
        log_warn "Keycloak backup not found: $KC_BACKUP_FILE"
        return
    fi

    read -p "Restore Keycloak data? This will restart Keycloak. (y/N): " confirm_kc
    if [[ "$confirm_kc" != "y" && "$confirm_kc" != "Y" ]]; then
        log_info "Skipping Keycloak restore"
        return
    fi

    log_info "Restoring Keycloak database..."

    # Stop Keycloak
    cd "$KEYCLOAK_DIR"
    docker compose stop keycloak || true

    # Decompress
    TEMP_SQL="/tmp/keycloak_restore_$$.sql"
    gunzip -c "$KC_BACKUP_FILE" > "$TEMP_SQL"

    # Restore to container
    docker exec -i keycloak-postgres psql -U keycloak -d keycloak < "$TEMP_SQL"

    # Cleanup
    rm -f "$TEMP_SQL"

    # Start Keycloak
    docker compose start keycloak

    log_info "Keycloak restore complete"
}

restart_services() {
    log_info "Restarting services..."

    # Start backend
    if systemctl is-enabled athena-backend >/dev/null 2>&1; then
        sudo systemctl start athena-backend
        log_info "Started athena-backend"
    fi

    # Restart nginx
    if systemctl is-active nginx >/dev/null 2>&1; then
        sudo systemctl restart nginx
        log_info "Restarted nginx"
    fi
}

# =============================================================================
# Main
# =============================================================================

main() {
    echo "=============================================="
    echo "  Athena Security Platform - Restore"
    echo "=============================================="

    parse_args "$@"
    load_env

    # List mode
    if [[ "$LIST_ONLY" == "true" ]]; then
        list_backups
        exit 0
    fi

    # Require backup name
    if [[ -z "$BACKUP_NAME" ]]; then
        log_error "Please specify a backup to restore with --backup"
        echo ""
        echo "Use --list to see available backups"
        exit 1
    fi

    # Confirm
    confirm_restore

    # Restore
    restore_database
    restore_config
    restore_keycloak

    # Restart
    restart_services

    echo ""
    log_info "Restore complete!"
    echo ""
    echo "Please verify:"
    echo "  1. Application is accessible: http://localhost"
    echo "  2. Backend health: curl http://localhost:5000/health"
    echo "  3. Keycloak is accessible: http://localhost:8080"
    echo ""
}

main "$@"
