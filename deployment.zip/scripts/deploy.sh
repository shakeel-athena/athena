#!/bin/bash
# =============================================================================
# Athena Security Platform - Deployment Script
# =============================================================================
# This script deploys or updates the Athena application.
#
# Usage: ./deploy.sh [OPTIONS]
#
# Options:
#   --skip-frontend    Skip frontend npm install and build
#   --skip-backend     Skip backend pip install
#   --skip-migrations  Skip database migrations
#   --skip-git         Skip git pull (use for manual file copy deployments)
#   --no-git           Alias for --skip-git
#   -h, --help         Show help message
#
# For Manual Copy Deployment:
#   1. Copy files to /opt/athena/app/ via SCP/SFTP
#   2. Run: ./deploy.sh --skip-git
# =============================================================================

set -e

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

# Configuration
APP_DIR="${APP_DIR:-/opt/athena/app}"
VENV_DIR="$APP_DIR/venv"
FRONTEND_DIR="$APP_DIR/frontend"
BACKEND_DIR="$APP_DIR/backend/response"
LOG_DIR="/var/log/athena"

# Flags
SKIP_FRONTEND=false
SKIP_BACKEND=false
SKIP_MIGRATIONS=false
SKIP_GIT_PULL=false

# =============================================================================
# Helper Functions
# =============================================================================

log_info() {
    echo -e "${GREEN}[INFO]${NC} $1"
}

log_warn() {
    echo -e "${YELLOW}[WARN]${NC} $1"
}

log_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

log_step() {
    echo -e "${BLUE}[$1]${NC} $2"
}

check_directory() {
    if [[ ! -d "$APP_DIR" ]]; then
        log_error "Application directory not found: $APP_DIR"
        log_error "Please clone the repository first or set APP_DIR environment variable"
        exit 1
    fi
}

parse_args() {
    while [[ $# -gt 0 ]]; do
        case $1 in
            --skip-frontend)
                SKIP_FRONTEND=true
                shift
                ;;
            --skip-backend)
                SKIP_BACKEND=true
                shift
                ;;
            --skip-migrations)
                SKIP_MIGRATIONS=true
                shift
                ;;
            --skip-git|--no-git)
                SKIP_GIT_PULL=true
                shift
                ;;
            -h|--help)
                echo "Usage: $0 [OPTIONS]"
                echo ""
                echo "Options:"
                echo "  --skip-frontend    Skip frontend npm install and build"
                echo "  --skip-backend     Skip backend pip dependency installation"
                echo "  --skip-migrations  Skip database migrations"
                echo "  --skip-git         Skip git pull (for manual file copy)"
                echo "  --no-git           Alias for --skip-git"
                echo "  -h, --help         Show this help"
                echo ""
                echo "Example for manual copy deployment:"
                echo "  ./deploy.sh --skip-git"
                exit 0
                ;;
            *)
                log_error "Unknown option: $1"
                exit 1
                ;;
        esac
    done
}

# =============================================================================
# Deployment Steps
# =============================================================================

step_git_pull() {
    if [[ "$SKIP_GIT_PULL" == "true" ]]; then
        log_warn "Skipping git pull"
        return
    fi

    log_step "1/7" "Pulling latest code..."
    cd "$APP_DIR"

    # Check for uncommitted changes
    if [[ -n $(git status --porcelain) ]]; then
        log_warn "Uncommitted changes detected. Stashing..."
        git stash
    fi

    # Pull latest
    git pull origin main || git pull origin master || {
        log_warn "Could not pull from main/master, skipping git pull"
    }

    log_info "Git pull complete"
}

step_backend_deps() {
    if [[ "$SKIP_BACKEND" == "true" ]]; then
        log_warn "Skipping backend dependencies"
        return
    fi

    log_step "2/7" "Installing backend dependencies..."

    # Create virtual environment if it doesn't exist
    if [[ ! -d "$VENV_DIR" ]]; then
        log_info "Creating Python virtual environment..."
        python3 -m venv "$VENV_DIR"
    fi

    # Activate virtual environment
    source "$VENV_DIR/bin/activate"

    # Upgrade pip
    pip install --upgrade pip

    # Install requirements
    if [[ -f "$APP_DIR/backend/requirements.txt" ]]; then
        pip install -r "$APP_DIR/backend/requirements.txt"
    fi

    if [[ -f "$BACKEND_DIR/requirements.txt" ]]; then
        pip install -r "$BACKEND_DIR/requirements.txt"
    fi

    # Ensure gunicorn is installed
    pip install gunicorn

    deactivate
    log_info "Backend dependencies installed"
}

step_frontend_deps() {
    if [[ "$SKIP_FRONTEND" == "true" ]]; then
        log_warn "Skipping frontend dependencies"
        return
    fi

    log_step "3/7" "Installing frontend dependencies..."
    cd "$FRONTEND_DIR"

    npm install

    log_info "Frontend dependencies installed"
}

step_frontend_build() {
    if [[ "$SKIP_FRONTEND" == "true" ]]; then
        log_warn "Skipping frontend build"
        return
    fi

    log_step "4/7" "Building frontend..."
    cd "$FRONTEND_DIR"

    # Check for .env.production
    if [[ ! -f ".env.production" ]]; then
        log_warn "No .env.production found. Frontend may not work correctly."
        log_warn "Copy and configure: deployment/config/.env.frontend.example"
    fi

    npm run build

    log_info "Frontend build complete"
}

step_migrations() {
    if [[ "$SKIP_MIGRATIONS" == "true" ]]; then
        log_warn "Skipping database migrations"
        return
    fi

    log_step "5/7" "Running database migrations..."

    # Load environment variables
    if [[ -f "$APP_DIR/.env" ]]; then
        set -a
        source "$APP_DIR/.env"
        set +a
    fi

    DB_HOST="${POSTGRES_HOST:-localhost}"
    DB_USER="${POSTGRES_USER:-athena_user}"
    DB_NAME="${POSTGRES_DB:-athena_db}"

    # Run migrations
    MIGRATION_DIR="$APP_DIR/deployment/database"
    if [[ -f "$MIGRATION_DIR/init-database.sql" ]]; then
        PGPASSWORD="$POSTGRES_PASSWORD" psql -U "$DB_USER" -h "$DB_HOST" -d "$DB_NAME" \
            -f "$MIGRATION_DIR/init-database.sql" 2>/dev/null || {
            log_warn "Some migrations may have already been applied"
        }
    else
        # Fall back to original migration files
        PGPASSWORD="$POSTGRES_PASSWORD" psql -U "$DB_USER" -h "$DB_HOST" -d "$DB_NAME" \
            -f "$APP_DIR/database/migrations/001_create_rbac_tables.sql" 2>/dev/null || true
        PGPASSWORD="$POSTGRES_PASSWORD" psql -U "$DB_USER" -h "$DB_HOST" -d "$DB_NAME" \
            -f "$APP_DIR/database/seeds/001_seed_pages.sql" 2>/dev/null || true
        PGPASSWORD="$POSTGRES_PASSWORD" psql -U "$DB_USER" -h "$DB_HOST" -d "$DB_NAME" \
            -f "$APP_DIR/database/seeds/002_seed_default_roles.sql" 2>/dev/null || true
    fi

    log_info "Database migrations complete"
}

step_restart_services() {
    log_step "6/7" "Restarting services..."

    # Restart backend
    if systemctl is-active athena-backend >/dev/null 2>&1; then
        sudo systemctl restart athena-backend
        log_info "Restarted athena-backend"
    else
        log_warn "athena-backend service not active. Starting..."
        sudo systemctl start athena-backend || {
            log_warn "Could not start athena-backend. Make sure systemd service is installed."
        }
    fi

    # Restart nginx
    if systemctl is-active nginx >/dev/null 2>&1; then
        sudo systemctl restart nginx
        log_info "Restarted nginx"
    else
        log_warn "nginx not active. Starting..."
        sudo systemctl start nginx || {
            log_warn "Could not start nginx"
        }
    fi
}

step_health_check() {
    log_step "7/7" "Running health checks..."

    sleep 5  # Wait for services to start

    # Check backend
    echo -n "Backend health: "
    if curl -sf http://localhost:5000/health >/dev/null 2>&1; then
        echo -e "${GREEN}OK${NC}"
    else
        echo -e "${RED}FAILED${NC}"
        log_warn "Backend may still be starting. Check logs: journalctl -u athena-backend -f"
    fi

    # Check frontend
    echo -n "Frontend health: "
    if curl -sf http://localhost/ -o /dev/null 2>&1; then
        echo -e "${GREEN}OK${NC}"
    else
        echo -e "${YELLOW}UNAVAILABLE${NC}"
        log_warn "Frontend may not be accessible. Check nginx configuration."
    fi

    # Check comprehensive health
    echo -n "API comprehensive: "
    HEALTH_RESPONSE=$(curl -sf http://localhost:5000/api/health/comprehensive 2>/dev/null || echo '{}')
    if echo "$HEALTH_RESPONSE" | grep -q '"status"'; then
        echo -e "${GREEN}OK${NC}"
    else
        echo -e "${YELLOW}PARTIAL${NC}"
    fi
}

print_summary() {
    echo ""
    echo "=== Deployment Summary ==="
    echo ""
    echo "Application directory: $APP_DIR"
    echo "Frontend build: $FRONTEND_DIR/build"
    echo "Backend service: athena-backend"
    echo ""
    echo "Service URLs:"
    echo "  Frontend: http://localhost (or your server IP)"
    echo "  Backend API: http://localhost:5000"
    echo "  Keycloak: http://localhost:8080"
    echo ""
    echo "Log files:"
    echo "  Backend: $LOG_DIR/backend-*.log"
    echo "  System: journalctl -u athena-backend -f"
    echo ""
}

# =============================================================================
# Main
# =============================================================================

main() {
    echo "=============================================="
    echo "  Athena Security Platform - Deployment"
    echo "=============================================="
    echo ""

    parse_args "$@"
    check_directory

    step_git_pull
    step_backend_deps
    step_frontend_deps
    step_frontend_build
    step_migrations
    step_restart_services
    step_health_check
    print_summary

    log_info "Deployment complete!"
}

main "$@"
