#!/bin/bash
# =============================================================================
# Athena Pre-Deployment Verification Script for NRM Server
# =============================================================================
# This script verifies all prerequisites before deploying Athena
# Run this on NRM server (172.16.129.133) before deployment
#
# Usage: bash verify_nrm_prerequisites.sh
# =============================================================================

set -e

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Configuration - UPDATE THESE VALUES
DEV_SERVER="172.16.132.198"
SSH_KEY="$HOME/.ssh/nrm_to_athena_ed25519"
SSH_USER="athena-sync"
ES_USER="admin"
ES_PASSWORD="zdmzO0?kB0eH*9Vc1e3fBf0*1Eb1kLeY"

# Counters
TOTAL_TESTS=0
PASSED_TESTS=0
FAILED_TESTS=0
WARNINGS=0

# =============================================================================
# Helper Functions
# =============================================================================

print_header() {
    echo ""
    echo "========================================="
    echo "  $1"
    echo "========================================="
    echo ""
}

print_test() {
    TOTAL_TESTS=$((TOTAL_TESTS + 1))
    echo -n "[$TOTAL_TESTS] $1: "
}

print_pass() {
    PASSED_TESTS=$((PASSED_TESTS + 1))
    echo -e "${GREEN}✓ PASS${NC} $1"
}

print_fail() {
    FAILED_TESTS=$((FAILED_TESTS + 1))
    echo -e "${RED}✗ FAIL${NC} $1"
}

print_warn() {
    WARNINGS=$((WARNINGS + 1))
    echo -e "${YELLOW}⚠ WARN${NC} $1"
}

print_info() {
    echo -e "${BLUE}ℹ INFO${NC} $1"
}

# =============================================================================
# Test Functions
# =============================================================================

test_basic_system() {
    print_header "Basic System Checks"

    # Test 1: Check if running as root or with sudo
    print_test "Sudo/root access available"
    if [ "$EUID" -eq 0 ] || sudo -n true 2>/dev/null; then
        print_pass ""
    else
        print_fail "Need sudo access for deployment"
        print_info "Run: sudo bash verify_nrm_prerequisites.sh"
        exit 1
    fi

    # Test 2: Check disk space
    print_test "Disk space (need 25GB free)"
    AVAILABLE=$(df / | tail -1 | awk '{print $4}')
    AVAILABLE_GB=$(($AVAILABLE / 1048576))
    if [ "$AVAILABLE" -gt 26214400 ]; then
        print_pass "($AVAILABLE_GB GB available)"
    elif [ "$AVAILABLE" -gt 20971520 ]; then
        print_warn "$AVAILABLE_GB GB available (25GB recommended, but acceptable with log rotation)"
    else
        print_fail "Only $AVAILABLE_GB GB available (need at least 20GB)"
    fi

    # Test 3: Check memory
    print_test "RAM (need 4GB minimum)"
    TOTAL_MEM=$(free -g | grep Mem | awk '{print $2}')
    if [ "$TOTAL_MEM" -ge 4 ]; then
        print_pass "($TOTAL_MEM GB total)"
    else
        print_warn "Only $TOTAL_MEM GB RAM (4GB recommended)"
    fi

    # Test 4: Check internet connectivity
    print_test "Internet connectivity"
    if curl -s -o /dev/null -w "%{http_code}" --max-time 5 https://www.google.com | grep -q "200"; then
        print_pass ""
    else
        print_fail "Cannot reach internet"
    fi

    # Test 5: Check if git is available
    print_test "Git available"
    if command -v git &> /dev/null; then
        GIT_VERSION=$(git --version | awk '{print $3}')
        print_pass "(version $GIT_VERSION)"
    else
        print_warn "Not installed (will be installed during setup)"
    fi
}

test_ssh_connectivity() {
    print_header "SSH Connectivity to Dev Server ($DEV_SERVER)"

    # Test 1: Check if SSH key exists
    print_test "SSH key exists ($SSH_KEY)"
    if [ -f "$SSH_KEY" ]; then
        print_pass ""
    else
        print_fail "Key file not found"
        print_info "Expected location: $SSH_KEY"
        return 1
    fi

    # Test 2: Check SSH key permissions
    print_test "SSH key permissions"
    KEY_PERMS=$(stat -c "%a" "$SSH_KEY" 2>/dev/null || stat -f "%OLp" "$SSH_KEY" 2>/dev/null)
    if [ "$KEY_PERMS" = "600" ] || [ "$KEY_PERMS" = "400" ]; then
        print_pass "(${KEY_PERMS})"
    else
        print_warn "Permissions are ${KEY_PERMS} (should be 600)"
        print_info "Run: chmod 600 $SSH_KEY"
    fi

    # Test 3: Test basic SSH connectivity
    print_test "SSH connection to Dev server"
    if timeout 10 ssh -i "$SSH_KEY" -o ConnectTimeout=5 -o StrictHostKeyChecking=no \
        "$SSH_USER@$DEV_SERVER" "exit" 2>/dev/null; then
        print_pass ""
    else
        print_fail "Cannot connect via SSH"
        print_info "Check: ssh -i $SSH_KEY $SSH_USER@$DEV_SERVER"
        return 1
    fi

    # Test 4: Test command execution
    print_test "SSH command execution"
    SSH_OUTPUT=$(ssh -i "$SSH_KEY" -o ConnectTimeout=5 -o StrictHostKeyChecking=no \
        "$SSH_USER@$DEV_SERVER" "echo 'test' 2>/dev/null" 2>/dev/null)
    if [ "$SSH_OUTPUT" = "test" ]; then
        print_pass ""
    else
        print_fail "Cannot execute commands"
    fi

    # Test 5: Access to Wazuh shared directory
    print_test "Access to /var/ossec/etc/shared/"
    if ssh -i "$SSH_KEY" -o ConnectTimeout=5 -o StrictHostKeyChecking=no \
        "$SSH_USER@$DEV_SERVER" "test -d /var/ossec/etc/shared" 2>/dev/null; then
        print_pass ""
    else
        print_fail "Cannot access Wazuh shared directory"
        print_info "User $SSH_USER needs read/write access to /var/ossec/etc/shared/"
    fi

    # Test 6: Write permissions to shared directory
    print_test "Write permissions to shared directory"
    TEST_FILE="/var/ossec/etc/shared/.athena_test_$(date +%s)"
    if ssh -i "$SSH_KEY" -o ConnectTimeout=5 -o StrictHostKeyChecking=no \
        "$SSH_USER@$DEV_SERVER" "touch $TEST_FILE && rm -f $TEST_FILE" 2>/dev/null; then
        print_pass ""
    else
        print_fail "Cannot write to shared directory"
    fi
}

test_elasticsearch() {
    print_header "Elasticsearch Connectivity"

    ES_URL="https://$DEV_SERVER:9200"

    # Test 1: Port 9200 reachable
    print_test "Port 9200 accessible"
    if timeout 5 bash -c "cat < /dev/null > /dev/tcp/$DEV_SERVER/9200" 2>/dev/null; then
        print_pass ""
    else
        print_fail "Port 9200 not reachable"
        print_info "Check security group allows outbound 9200 to $DEV_SERVER"
        return 1
    fi

    # Test 2: Elasticsearch responds
    print_test "Elasticsearch API responds"
    HTTP_CODE=$(curl -k -s -o /dev/null -w "%{http_code}" \
        -u "$ES_USER:$ES_PASSWORD" "$ES_URL" --max-time 5)
    if [ "$HTTP_CODE" = "200" ]; then
        print_pass ""
    else
        print_fail "HTTP $HTTP_CODE"
        print_info "Check credentials: $ES_USER / ******"
        return 1
    fi

    # Test 3: Get cluster info
    print_test "Elasticsearch cluster info"
    CLUSTER_NAME=$(curl -k -s -u "$ES_USER:$ES_PASSWORD" "$ES_URL" --max-time 5 | \
        grep -o '"cluster_name":"[^"]*"' | cut -d'"' -f4)
    if [ -n "$CLUSTER_NAME" ]; then
        print_pass "(cluster: $CLUSTER_NAME)"
    else
        print_warn "Cannot parse cluster name (Elasticsearch is functional)"
    fi

    # Test 4: Check Wazuh indices exist
    print_test "Wazuh indices (wazuh-alerts-*)"
    WAZUH_INDICES=$(curl -k -s -u "$ES_USER:$ES_PASSWORD" \
        "$ES_URL/_cat/indices/wazuh-alerts-*" --max-time 5 | wc -l)
    if [ "$WAZUH_INDICES" -gt 0 ]; then
        print_pass "($WAZUH_INDICES indices found)"
    else
        print_fail "No wazuh-alerts-* indices found"
        print_info "Wazuh may not be sending alerts to Elasticsearch"
    fi

    # Test 5: Check Suricata indices exist
    print_test "Suricata indices (suricata-*)"
    SURICATA_INDICES=$(curl -k -s -u "$ES_USER:$ES_PASSWORD" \
        "$ES_URL/_cat/indices/suricata-*" --max-time 5 | wc -l)
    if [ "$SURICATA_INDICES" -gt 0 ]; then
        print_pass "($SURICATA_INDICES indices found)"
    else
        print_warn "No suricata-* indices found"
        print_info "Suricata may not be configured or sending alerts"
    fi

    # Test 6: Test query capability
    print_test "Elasticsearch query capability"
    DOC_COUNT=$(curl -k -s -u "$ES_USER:$ES_PASSWORD" \
        "$ES_URL/wazuh-alerts-*/_count" --max-time 5 | \
        grep -o '"count":[0-9]*' | cut -d':' -f2)
    if [ -n "$DOC_COUNT" ]; then
        print_pass "($DOC_COUNT alerts indexed)"
    else
        print_fail "Cannot query indices"
    fi
}

test_wazuh_api() {
    print_header "Wazuh Manager API (SKIPPED - Not needed for this release)"

    print_info "Wazuh API integration is planned for next release"
    print_info "Skipping port 55000 and API connectivity tests"
    echo ""
}

test_network_connectivity() {
    print_header "Network Connectivity Summary"

    # Test 1: DNS resolution
    print_test "DNS resolution"
    if host google.com >/dev/null 2>&1 || nslookup google.com >/dev/null 2>&1; then
        print_pass ""
    else
        print_warn "DNS may not be working"
    fi

    # Test 2: AWS package mirrors
    print_test "AWS package mirrors accessible"
    if curl -s -o /dev/null -w "%{http_code}" --max-time 5 \
        https://amazonlinux-2-repos-us-east-2.s3.dualstack.us-east-2.amazonaws.com/ | \
        grep -q "200\|403"; then
        print_pass ""
    else
        print_warn "Cannot reach AWS repos (may affect package installation)"
    fi

    # Test 3: PyPI (Python packages)
    print_test "PyPI accessible"
    if curl -s -o /dev/null -w "%{http_code}" --max-time 5 https://pypi.org | grep -q "200"; then
        print_pass ""
    else
        print_warn "Cannot reach PyPI"
    fi

    # Test 4: npm registry
    print_test "npm registry accessible"
    if curl -s -o /dev/null -w "%{http_code}" --max-time 5 https://registry.npmjs.org | grep -q "200"; then
        print_pass ""
    else
        print_warn "Cannot reach npm registry"
    fi
}

test_security_groups() {
    print_header "Security Group Verification"

    print_info "Testing outbound connectivity from NRM to Dev server..."

    # Test SSH (22)
    print_test "Outbound SSH (22) to Dev"
    if timeout 5 bash -c "cat < /dev/null > /dev/tcp/$DEV_SERVER/22" 2>/dev/null; then
        print_pass ""
    else
        print_fail "Port 22 blocked"
    fi

    # Test Elasticsearch (9200)
    print_test "Outbound HTTPS (9200) to Dev"
    if timeout 5 bash -c "cat < /dev/null > /dev/tcp/$DEV_SERVER/9200" 2>/dev/null; then
        print_pass ""
    else
        print_fail "Port 9200 blocked"
    fi

    # Port 55000 (Wazuh API) - SKIPPED for this release
    print_info "Port 55000 (Wazuh API) - Not needed for this release"
}

print_summary() {
    print_header "Verification Summary"

    echo "Total Tests:  $TOTAL_TESTS"
    echo -e "Passed:       ${GREEN}$PASSED_TESTS${NC}"
    echo -e "Failed:       ${RED}$FAILED_TESTS${NC}"
    echo -e "Warnings:     ${YELLOW}$WARNINGS${NC}"
    echo ""

    if [ $FAILED_TESTS -eq 0 ]; then
        echo -e "${GREEN}╔════════════════════════════════════════════╗${NC}"
        echo -e "${GREEN}║  ✓ ALL CRITICAL TESTS PASSED              ║${NC}"
        echo -e "${GREEN}║  Ready to proceed with deployment!        ║${NC}"
        echo -e "${GREEN}╚════════════════════════════════════════════╝${NC}"
        echo ""
        echo "Next steps:"
        echo "1. Get Wazuh API password from Dev server:"
        echo "   ssh root@$DEV_SERVER 'cat /root/athena-passwords-*.yml | grep api_password'"
        echo ""
        echo "2. Configure .env file with all credentials"
        echo ""
        echo "3. Run deployment:"
        echo "   cd /opt/athena/app"
        echo "   sudo ./deployment/scripts/install.sh"
        echo ""
        return 0
    else
        echo -e "${RED}╔════════════════════════════════════════════╗${NC}"
        echo -e "${RED}║  ✗ SOME TESTS FAILED                       ║${NC}"
        echo -e "${RED}║  Fix issues before deployment              ║${NC}"
        echo -e "${RED}╚════════════════════════════════════════════╝${NC}"
        echo ""
        echo "Please fix the failed tests above before proceeding."
        echo ""
        return 1
    fi
}

# =============================================================================
# Main Execution
# =============================================================================

main() {
    clear
    echo "========================================="
    echo "  Athena Pre-Deployment Verification"
    echo "  NRM Server → Dev Server"
    echo "========================================="
    echo ""
    echo "NRM Server:  $(hostname) ($(hostname -I | awk '{print $1}'))"
    echo "Dev Server:  $DEV_SERVER"
    echo "SSH Key:     $SSH_KEY"
    echo "SSH User:    $SSH_USER"
    echo ""
    echo "Starting verification..."
    sleep 2

    # Run all test suites
    test_basic_system
    test_ssh_connectivity
    test_elasticsearch
    test_wazuh_api
    test_network_connectivity
    test_security_groups

    # Print summary and exit
    print_summary
    exit $?
}

# Run main function
main "$@"
