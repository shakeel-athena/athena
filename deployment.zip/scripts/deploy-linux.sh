#!/bin/bash
# =============================================================================
# Athena Security Platform - Linux Production Deployment Script
# =============================================================================
# This script deploys the complete Athena platform using Docker Compose.
#
# Prerequisites:
#   - Linux server (Ubuntu 22.04+, Amazon Linux 2023, RHEL 8+)
#   - Root or sudo access
#   - Internet access for pulling Docker images
#
# Usage:
#   chmod +x deploy-linux.sh
#   sudo ./deploy-linux.sh
#
# =============================================================================

set -e  # Exit on error

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Configuration
DEPLOY_DIR="/opt/athena"
KEYCLOAK_DIR="/opt/keycloak"
LOG_DIR="/var/log/athena"

# =============================================================================
# Helper Functions
# =============================================================================

log_info() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

log_success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1"
}

log_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

log_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

check_root() {
    if [ "$EUID" -ne 0 ]; then
        log_error "Please run as root (sudo ./deploy-linux.sh)"
        exit 1
    fi
}

# =============================================================================
# Step 1: Detect OS and Install Docker
# =============================================================================

install_docker() {
    log_info "Detecting operating system..."

    if [ -f /etc/os-release ]; then
        . /etc/os-release
        OS=$ID
        VERSION=$VERSION_ID
    else
        log_error "Cannot detect OS. Please install Docker manually."
        exit 1
    fi

    log_info "Detected OS: $OS $VERSION"

    # Check if Docker is already installed
    if command -v docker &> /dev/null; then
        log_success "Docker is already installed: $(docker --version)"
    else
        log_info "Installing Docker..."

        case $OS in
            ubuntu|debian)
                apt-get update
                apt-get install -y ca-certificates curl gnupg
                install -m 0755 -d /etc/apt/keyrings
                curl -fsSL https://download.docker.com/linux/$OS/gpg | gpg --dearmor -o /etc/apt/keyrings/docker.gpg
                chmod a+r /etc/apt/keyrings/docker.gpg
                echo "deb [arch=$(dpkg --print-architecture) signed-by=/etc/apt/keyrings/docker.gpg] https://download.docker.com/linux/$OS $(. /etc/os-release && echo "$VERSION_CODENAME") stable" | tee /etc/apt/sources.list.d/docker.list > /dev/null
                apt-get update
                apt-get install -y docker-ce docker-ce-cli containerd.io docker-buildx-plugin docker-compose-plugin
                ;;
            rhel|centos|fedora|amzn)
                if [ "$OS" = "amzn" ]; then
                    yum install -y docker
                    systemctl start docker
                    systemctl enable docker
                    # Install docker-compose separately for Amazon Linux
                    curl -L "https://github.com/docker/compose/releases/download/v2.24.0/docker-compose-$(uname -s)-$(uname -m)" -o /usr/local/bin/docker-compose
                    chmod +x /usr/local/bin/docker-compose
                    ln -sf /usr/local/bin/docker-compose /usr/bin/docker-compose
                else
                    yum install -y yum-utils
                    yum-config-manager --add-repo https://download.docker.com/linux/centos/docker-ce.repo
                    yum install -y docker-ce docker-ce-cli containerd.io docker-buildx-plugin docker-compose-plugin
                fi
                ;;
            *)
                log_error "Unsupported OS: $OS. Please install Docker manually."
                exit 1
                ;;
        esac

        systemctl start docker
        systemctl enable docker
        log_success "Docker installed successfully"
    fi

    # Check Docker Compose
    if command -v docker-compose &> /dev/null; then
        log_success "Docker Compose available: $(docker-compose --version)"
    elif docker compose version &> /dev/null; then
        log_success "Docker Compose (plugin) available: $(docker compose version)"
        # Create alias for compatibility
        echo 'alias docker-compose="docker compose"' >> /etc/profile.d/docker-compose.sh
    else
        log_error "Docker Compose not found. Please install it manually."
        exit 1
    fi
}

# =============================================================================
# Step 2: Create Directory Structure
# =============================================================================

create_directories() {
    log_info "Creating directory structure..."

    mkdir -p $DEPLOY_DIR
    mkdir -p $KEYCLOAK_DIR
    mkdir -p $LOG_DIR

    log_success "Directories created"
}

# =============================================================================
# Step 3: Copy Application Files
# =============================================================================

copy_files() {
    log_info "Copying application files..."

    # Get the directory where this script is located
    SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
    PROJECT_ROOT="$(cd "$SCRIPT_DIR/../.." && pwd)"

    # Copy entire project
    cp -r "$PROJECT_ROOT"/* $DEPLOY_DIR/

    # Copy Keycloak realm file
    if [ -f "$DEPLOY_DIR/deployment/docker/athena-security-realm.json" ]; then
        cp "$DEPLOY_DIR/deployment/docker/athena-security-realm.json" $KEYCLOAK_DIR/
    fi

    log_success "Files copied to $DEPLOY_DIR"
}

# =============================================================================
# Step 4: Configure Environment
# =============================================================================

configure_environment() {
    log_info "Configuring environment..."

    # Check if .env.docker exists, if not copy from example
    if [ ! -f "$DEPLOY_DIR/.env.docker" ]; then
        if [ -f "$DEPLOY_DIR/.env.docker.example" ]; then
            cp "$DEPLOY_DIR/.env.docker.example" "$DEPLOY_DIR/.env.docker"
            log_warning "Created .env.docker from example. Please edit it with your production values!"
        else
            log_error ".env.docker.example not found!"
            exit 1
        fi
    fi

    # Get server IP for configuration
    SERVER_IP=$(hostname -I | awk '{print $1}')
    log_info "Detected server IP: $SERVER_IP"

    # Prompt user for configuration
    echo ""
    echo "=============================================="
    echo "  PRODUCTION CONFIGURATION"
    echo "=============================================="
    echo ""
    read -p "Enter production server IP/hostname [$SERVER_IP]: " PROD_IP
    PROD_IP=${PROD_IP:-$SERVER_IP}

    read -p "Enter Elasticsearch host (leave empty if none): " ES_HOST
    read -p "Enter Wazuh API URL (leave empty if none): " WAZUH_URL

    # Generate secure passwords
    DB_PASSWORD=$(openssl rand -base64 24 | tr -dc 'a-zA-Z0-9' | head -c 20)
    KC_DB_PASSWORD=$(openssl rand -base64 24 | tr -dc 'a-zA-Z0-9' | head -c 20)
    KC_ADMIN_PASSWORD=$(openssl rand -base64 24 | tr -dc 'a-zA-Z0-9' | head -c 16)
    SECRET_KEY=$(openssl rand -base64 48 | tr -dc 'a-zA-Z0-9' | head -c 48)

    # Update .env.docker with production values
    cat > "$DEPLOY_DIR/.env.docker" << EOF
# =============================================================================
# Athena Security Platform - Production Environment Configuration
# Generated: $(date)
# Server: $PROD_IP
# =============================================================================

# APPLICATION DATABASE
POSTGRES_DB=athena_db
POSTGRES_USER=athena_user
POSTGRES_PASSWORD=$DB_PASSWORD

# KEYCLOAK CONFIGURATION
KEYCLOAK_DB_PASSWORD=$KC_DB_PASSWORD
KEYCLOAK_ADMIN=admin
KEYCLOAK_ADMIN_PASSWORD=$KC_ADMIN_PASSWORD
KEYCLOAK_REALM=athena-security
KEYCLOAK_CLIENT_ID=athena-backend
KEYCLOAK_CLIENT_SECRET=

# BACKEND CONFIGURATION
FLASK_ENV=production
DEBUG=false
SECRET_KEY=$SECRET_KEY
LOG_LEVEL=INFO
CORS_ORIGINS=http://$PROD_IP,http://$PROD_IP:80,http://$PROD_IP:8088

# FRONTEND CONFIGURATION
REACT_APP_API_BASE_URL=http://$PROD_IP:5000
REACT_APP_API_URL=http://$PROD_IP:5000/api
REACT_APP_KEYCLOAK_URL=http://$PROD_IP:8080
REACT_APP_KEYCLOAK_REALM=athena-security
REACT_APP_KEYCLOAK_CLIENT_ID=athena-frontend

# ELASTICSEARCH
ELASTICSEARCH_HOST=$ES_HOST
ELASTICSEARCH_PORT=9200
ELASTICSEARCH_USER=admin
ELASTICSEARCH_PASSWORD=
ELASTICSEARCH_VERIFY_SSL=false

# WAZUH
WAZUH_API_URL=$WAZUH_URL
WAZUH_API_USER=wazuh
WAZUH_API_PASSWORD=

# SURICATA
SURICATA_ES_HOST=$ES_HOST
SURICATA_ES_PORT=9200
SURICATA_ES_USERNAME=
SURICATA_ES_PASSWORD=

# AWS (optional)
AWS_REGION=us-east-2
AWS_PROFILE=
FIREWALL_RULE_GROUP=
WAF_WEB_ACL=
EOF

    # Save credentials to a secure file
    cat > "$DEPLOY_DIR/CREDENTIALS.txt" << EOF
=============================================================================
ATHENA SECURITY PLATFORM - CREDENTIALS
Generated: $(date)
IMPORTANT: Store these securely and delete this file after noting them down!
=============================================================================

PostgreSQL Database:
  Host: localhost:5432
  Database: athena_db
  User: athena_user
  Password: $DB_PASSWORD

Keycloak Admin Console:
  URL: http://$PROD_IP:8080/admin
  Username: admin
  Password: $KC_ADMIN_PASSWORD

Application:
  Frontend: http://$PROD_IP
  Backend API: http://$PROD_IP:5000

Flask Secret Key: $SECRET_KEY

=============================================================================
IMPORTANT: After Keycloak starts, get the client secret:
1. Go to Keycloak Admin Console
2. Select 'athena-security' realm
3. Go to Clients > athena-backend > Credentials
4. Copy the Client Secret and add it to .env.docker
5. Run: docker-compose restart backend
=============================================================================
EOF

    chmod 600 "$DEPLOY_DIR/CREDENTIALS.txt"

    log_success "Environment configured"
    log_warning "Credentials saved to $DEPLOY_DIR/CREDENTIALS.txt"
}

# =============================================================================
# Step 5: Configure Firewall
# =============================================================================

configure_firewall() {
    log_info "Configuring firewall..."

    # Check for firewalld (RHEL/CentOS/Amazon Linux)
    if command -v firewall-cmd &> /dev/null; then
        firewall-cmd --permanent --add-port=80/tcp   # Frontend
        firewall-cmd --permanent --add-port=5000/tcp # Backend API
        firewall-cmd --permanent --add-port=8080/tcp # Keycloak
        firewall-cmd --reload
        log_success "Firewalld configured"
    # Check for ufw (Ubuntu/Debian)
    elif command -v ufw &> /dev/null; then
        ufw allow 80/tcp    # Frontend
        ufw allow 5000/tcp  # Backend API
        ufw allow 8080/tcp  # Keycloak
        log_success "UFW configured"
    else
        log_warning "No firewall detected. Please manually open ports 80, 5000, 8080"
    fi
}

# =============================================================================
# Step 6: Build and Start Services
# =============================================================================

start_services() {
    log_info "Building and starting Docker services..."

    cd $DEPLOY_DIR

    # Use docker-compose or docker compose depending on what's available
    if command -v docker-compose &> /dev/null; then
        COMPOSE_CMD="docker-compose"
    else
        COMPOSE_CMD="docker compose"
    fi

    # Build and start
    $COMPOSE_CMD --env-file .env.docker up -d --build

    log_success "Services started"

    # Wait for services to be healthy
    log_info "Waiting for services to become healthy..."
    sleep 30

    # Check service status
    $COMPOSE_CMD ps
}

# =============================================================================
# Step 7: Health Check
# =============================================================================

health_check() {
    log_info "Running health checks..."

    # Get server IP
    SERVER_IP=$(grep "REACT_APP_API_BASE_URL" "$DEPLOY_DIR/.env.docker" | cut -d'/' -f3 | cut -d':' -f1)

    echo ""
    echo "Service Status:"
    echo "==============="

    # Check Backend
    if curl -s -o /dev/null -w "%{http_code}" "http://localhost:5000/health" | grep -q "200"; then
        echo -e "Backend API:  ${GREEN}✓ Healthy${NC}"
    else
        echo -e "Backend API:  ${RED}✗ Not responding${NC}"
    fi

    # Check Frontend
    if curl -s -o /dev/null -w "%{http_code}" "http://localhost:80" | grep -q "200"; then
        echo -e "Frontend:     ${GREEN}✓ Healthy${NC}"
    else
        echo -e "Frontend:     ${RED}✗ Not responding${NC}"
    fi

    # Check Keycloak
    if curl -s -o /dev/null -w "%{http_code}" "http://localhost:8080/health/ready" | grep -q "200"; then
        echo -e "Keycloak:     ${GREEN}✓ Healthy${NC}"
    else
        echo -e "Keycloak:     ${YELLOW}⏳ Starting (may take 1-2 minutes)${NC}"
    fi

    echo ""
}

# =============================================================================
# Step 8: Print Summary
# =============================================================================

print_summary() {
    SERVER_IP=$(grep "REACT_APP_API_BASE_URL" "$DEPLOY_DIR/.env.docker" | cut -d'/' -f3 | cut -d':' -f1)

    echo ""
    echo "=============================================="
    echo "  DEPLOYMENT COMPLETE!"
    echo "=============================================="
    echo ""
    echo "Access URLs:"
    echo "  Frontend:       http://$SERVER_IP"
    echo "  Backend API:    http://$SERVER_IP:5000"
    echo "  Keycloak Admin: http://$SERVER_IP:8080/admin"
    echo ""
    echo "Credentials:"
    echo "  See: $DEPLOY_DIR/CREDENTIALS.txt"
    echo ""
    echo "Next Steps:"
    echo "  1. Wait 1-2 minutes for Keycloak to fully start"
    echo "  2. Go to Keycloak Admin Console"
    echo "  3. Get client secret from athena-backend client"
    echo "  4. Update KEYCLOAK_CLIENT_SECRET in .env.docker"
    echo "  5. Run: cd $DEPLOY_DIR && docker-compose restart backend"
    echo ""
    echo "Useful Commands:"
    echo "  View logs:     cd $DEPLOY_DIR && docker-compose logs -f"
    echo "  Restart:       cd $DEPLOY_DIR && docker-compose restart"
    echo "  Stop:          cd $DEPLOY_DIR && docker-compose down"
    echo "  Status:        cd $DEPLOY_DIR && docker-compose ps"
    echo ""
    echo "=============================================="
}

# =============================================================================
# Main Execution
# =============================================================================

main() {
    echo ""
    echo "=============================================="
    echo "  Athena Security Platform - Linux Deployment"
    echo "=============================================="
    echo ""

    check_root
    install_docker
    create_directories
    copy_files
    configure_environment
    configure_firewall
    start_services
    health_check
    print_summary
}

# Run main function
main "$@"
