#!/bin/bash
# =============================================================================
# Athena Security Platform - Installation Script
# =============================================================================
# This script installs all prerequisites and sets up the environment for
# deploying Athena on Amazon Linux 2023.
#
# Usage: sudo ./install.sh
# =============================================================================

set -e

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# Configuration
APP_USER="athena"
APP_DIR="/opt/athena"
LOG_DIR="/var/log/athena"
KEYCLOAK_DIR="/opt/keycloak"

# =============================================================================
# Helper Functions
# =============================================================================

log_info() {
    echo -e "${GREEN}[INFO]${NC} $1"
}

log_warn() {
    echo -e "${YELLOW}[WARN]${NC} $1"
}

log_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

check_root() {
    if [[ $EUID -ne 0 ]]; then
        log_error "This script must be run as root (use sudo)"
        exit 1
    fi
}

# =============================================================================
# Installation Functions
# =============================================================================

install_system_packages() {
    log_info "Updating system packages..."
    dnf update -y

    log_info "Installing base packages..."
    dnf install -y git curl wget vim tar gzip

    log_info "Installing development tools..."
    dnf groupinstall -y "Development Tools"
    dnf install -y openssl-devel
}

install_python() {
    log_info "Installing Python 3.11..."
    dnf install -y python3.11 python3.11-pip python3.11-devel

    log_info "Setting Python 3.11 as default..."
    alternatives --set python3 /usr/bin/python3.11 || true

    log_info "Verifying Python installation..."
    python3 --version
    pip3 --version
}

install_nodejs() {
    log_info "Installing Node.js 18 LTS..."
    curl -fsSL https://rpm.nodesource.com/setup_18.x | bash -
    dnf install -y nodejs

    log_info "Verifying Node.js installation..."
    node --version
    npm --version
}

install_postgresql() {
    log_info "Installing PostgreSQL 15..."
    dnf install -y postgresql15-server postgresql15 postgresql15-devel

    log_info "Initializing PostgreSQL database..."
    postgresql-setup --initdb || log_warn "Database already initialized"

    log_info "Enabling PostgreSQL service..."
    systemctl enable postgresql
    systemctl start postgresql

    log_info "Verifying PostgreSQL installation..."
    sudo -u postgres psql -c "SELECT version();" | head -1
}

install_docker() {
    log_info "Installing Docker..."
    dnf install -y docker

    log_info "Enabling Docker service..."
    systemctl enable docker
    systemctl start docker

    log_info "Verifying Docker installation..."
    docker --version

    # Install Docker Compose
    log_info "Installing Docker Compose..."
    DOCKER_COMPOSE_VERSION="v2.24.0"
    curl -L "https://github.com/docker/compose/releases/download/${DOCKER_COMPOSE_VERSION}/docker-compose-$(uname -s)-$(uname -m)" -o /usr/local/bin/docker-compose
    chmod +x /usr/local/bin/docker-compose

    # Create symlink for 'docker compose' command
    ln -sf /usr/local/bin/docker-compose /usr/bin/docker-compose

    log_info "Verifying Docker Compose installation..."
    docker-compose --version
}

install_redis() {
    log_info "Installing Redis..."
    dnf install -y redis

    log_info "Enabling Redis service..."
    systemctl enable redis
    systemctl start redis

    log_info "Verifying Redis installation..."
    redis-cli --version
    redis-cli ping || log_warn "Redis is installed but not responding to ping"
}

install_nginx() {
    log_info "Installing Nginx..."
    dnf install -y nginx

    log_info "Enabling Nginx service..."
    systemctl enable nginx

    log_info "Verifying Nginx installation..."
    nginx -v
}

# =============================================================================
# Setup Functions
# =============================================================================

create_app_user() {
    log_info "Creating application user: $APP_USER..."

    if id "$APP_USER" &>/dev/null; then
        log_warn "User $APP_USER already exists"
    else
        useradd -m -s /bin/bash "$APP_USER"
        log_info "Created user: $APP_USER"
    fi

    # Add to docker group
    usermod -aG docker "$APP_USER"
    log_info "Added $APP_USER to docker group"
}

create_directories() {
    log_info "Creating application directories..."

    # Application directory
    mkdir -p "$APP_DIR"
    chown "$APP_USER:$APP_USER" "$APP_DIR"
    log_info "Created: $APP_DIR"

    # Log directory
    mkdir -p "$LOG_DIR"
    chown "$APP_USER:$APP_USER" "$LOG_DIR"
    log_info "Created: $LOG_DIR"

    # Keycloak directory
    mkdir -p "$KEYCLOAK_DIR"
    chown "$APP_USER:$APP_USER" "$KEYCLOAK_DIR"
    log_info "Created: $KEYCLOAK_DIR"
}

setup_postgresql() {
    log_info "Setting up PostgreSQL database..."

    # Generate random password if not provided
    DB_PASSWORD=${DB_PASSWORD:-$(openssl rand -base64 16 | tr -dc 'a-zA-Z0-9' | head -c 16)}

    # Create database and user
    sudo -u postgres psql <<EOF
-- Create database
CREATE DATABASE athena_db;

-- Create user
CREATE USER athena_user WITH ENCRYPTED PASSWORD '$DB_PASSWORD';

-- Grant privileges
GRANT ALL PRIVILEGES ON DATABASE athena_db TO athena_user;

-- Connect to athena_db and grant schema permissions
\c athena_db
GRANT ALL ON SCHEMA public TO athena_user;
GRANT ALL PRIVILEGES ON ALL TABLES IN SCHEMA public TO athena_user;
GRANT ALL PRIVILEGES ON ALL SEQUENCES IN SCHEMA public TO athena_user;
ALTER DEFAULT PRIVILEGES IN SCHEMA public GRANT ALL ON TABLES TO athena_user;
EOF

    # Update pg_hba.conf
    PG_HBA="/var/lib/pgsql/data/pg_hba.conf"
    if ! grep -q "athena_user" "$PG_HBA"; then
        log_info "Updating pg_hba.conf..."
        # Add before the first line
        sed -i '1i\# Athena application user\nlocal   all   athena_user   md5\nhost    all   athena_user   127.0.0.1/32   md5\nhost    all   athena_user   ::1/128        md5\n' "$PG_HBA"
    fi

    # Restart PostgreSQL
    systemctl restart postgresql

    log_info "Database created successfully!"
    log_info "Database password: $DB_PASSWORD"
    log_info "IMPORTANT: Save this password securely and add it to your .env file"
}

copy_config_templates() {
    log_info "Copying configuration templates..."

    SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
    CONFIG_DIR="$(dirname "$SCRIPT_DIR")/config"

    # Copy systemd service
    if [[ -f "$CONFIG_DIR/athena-backend.service" ]]; then
        cp "$CONFIG_DIR/athena-backend.service" /etc/systemd/system/
        systemctl daemon-reload
        log_info "Copied athena-backend.service"
    fi

    # Copy Keycloak compose file
    if [[ -f "$CONFIG_DIR/keycloak-docker-compose.yml" ]]; then
        cp "$CONFIG_DIR/keycloak-docker-compose.yml" "$KEYCLOAK_DIR/docker-compose.yml"
        chown "$APP_USER:$APP_USER" "$KEYCLOAK_DIR/docker-compose.yml"
        log_info "Copied keycloak docker-compose.yml"
    fi

    # Copy nginx config (don't enable yet)
    if [[ -f "$CONFIG_DIR/nginx-athena.conf" ]]; then
        cp "$CONFIG_DIR/nginx-athena.conf" /etc/nginx/conf.d/athena.conf.disabled
        log_info "Copied nginx config (disabled - rename to .conf to enable)"
    fi
}

# =============================================================================
# Verification
# =============================================================================

verify_installation() {
    log_info "Verifying installation..."

    echo ""
    echo "=== Installation Summary ==="
    echo ""

    echo -n "Python 3.11: "
    python3 --version 2>/dev/null && echo -e "${GREEN}OK${NC}" || echo -e "${RED}FAILED${NC}"

    echo -n "Node.js 18: "
    node --version 2>/dev/null && echo -e "${GREEN}OK${NC}" || echo -e "${RED}FAILED${NC}"

    echo -n "PostgreSQL: "
    systemctl is-active postgresql >/dev/null 2>&1 && echo -e "${GREEN}RUNNING${NC}" || echo -e "${RED}NOT RUNNING${NC}"

    echo -n "Docker: "
    systemctl is-active docker >/dev/null 2>&1 && echo -e "${GREEN}RUNNING${NC}" || echo -e "${RED}NOT RUNNING${NC}"

    echo -n "Docker Compose: "
    docker-compose --version >/dev/null 2>&1 && echo -e "${GREEN}INSTALLED${NC}" || echo -e "${RED}NOT INSTALLED${NC}"

    echo -n "Redis: "
    systemctl is-active redis >/dev/null 2>&1 && echo -e "${GREEN}RUNNING${NC}" || echo -e "${RED}NOT RUNNING${NC}"

    echo -n "Nginx: "
    which nginx >/dev/null 2>&1 && echo -e "${GREEN}INSTALLED${NC}" || echo -e "${RED}NOT INSTALLED${NC}"

    echo -n "App user ($APP_USER): "
    id "$APP_USER" >/dev/null 2>&1 && echo -e "${GREEN}EXISTS${NC}" || echo -e "${RED}NOT FOUND${NC}"

    echo -n "App directory ($APP_DIR): "
    [[ -d "$APP_DIR" ]] && echo -e "${GREEN}EXISTS${NC}" || echo -e "${RED}NOT FOUND${NC}"

    echo ""
}

print_next_steps() {
    echo ""
    echo "=== Next Steps ==="
    echo ""
    echo "1. Clone the repository:"
    echo "   sudo -u $APP_USER bash"
    echo "   cd $APP_DIR"
    echo "   git clone <your-repo-url> app"
    echo ""
    echo "2. Configure environment:"
    echo "   cp deployment/config/.env.production.example $APP_DIR/app/.env"
    echo "   nano $APP_DIR/app/.env"
    echo ""
    echo "3. Setup Keycloak:"
    echo "   cd $KEYCLOAK_DIR"
    echo "   nano docker-compose.yml  # Set passwords"
    echo "   docker compose up -d"
    echo ""
    echo "4. Initialize database:"
    echo "   cd $APP_DIR/app"
    echo "   psql -U athena_user -h localhost -d athena_db -f deployment/database/init-database.sql"
    echo ""
    echo "5. Deploy application:"
    echo "   ./deployment/scripts/deploy.sh"
    echo ""
    echo "6. Enable nginx:"
    echo "   mv /etc/nginx/conf.d/athena.conf.disabled /etc/nginx/conf.d/athena.conf"
    echo "   sudo nginx -t && sudo systemctl restart nginx"
    echo ""
}

# =============================================================================
# Main
# =============================================================================

main() {
    echo "=============================================="
    echo "  Athena Security Platform - Installation"
    echo "=============================================="
    echo ""

    check_root

    # Install prerequisites
    install_system_packages
    install_python
    install_nodejs
    install_postgresql
    install_docker
    install_redis
    install_nginx

    # Setup environment
    create_app_user
    create_directories
    setup_postgresql
    copy_config_templates

    # Verify
    verify_installation
    print_next_steps

    log_info "Installation complete!"
}

# Run main function
main "$@"
