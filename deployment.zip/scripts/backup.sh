#!/bin/bash
# =============================================================================
# Athena Security Platform - Backup Script
# =============================================================================
# Creates timestamped backups of the database and configuration files.
#
# Usage: ./backup.sh [--db-only] [--config-only] [--keep N]
# =============================================================================

set -e

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m'

# Configuration
APP_DIR="${APP_DIR:-/opt/athena/app}"
BACKUP_DIR="${BACKUP_DIR:-/opt/athena/app/deployment/backups}"
KEYCLOAK_DIR="${KEYCLOAK_DIR:-/opt/keycloak}"
TIMESTAMP=$(date +%Y%m%d_%H%M%S)
BACKUP_NAME="athena_backup_$TIMESTAMP"
KEEP_BACKUPS=5  # Number of backups to keep

# Flags
DB_ONLY=false
CONFIG_ONLY=false

# =============================================================================
# Helper Functions
# =============================================================================

log_info() {
    echo -e "${GREEN}[INFO]${NC} $1"
}

log_warn() {
    echo -e "${YELLOW}[WARN]${NC} $1"
}

log_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

parse_args() {
    while [[ $# -gt 0 ]]; do
        case $1 in
            --db-only)
                DB_ONLY=true
                shift
                ;;
            --config-only)
                CONFIG_ONLY=true
                shift
                ;;
            --keep)
                KEEP_BACKUPS="$2"
                shift 2
                ;;
            --backup-dir)
                BACKUP_DIR="$2"
                shift 2
                ;;
            -h|--help)
                echo "Usage: $0 [OPTIONS]"
                echo ""
                echo "Options:"
                echo "  --db-only       Backup database only"
                echo "  --config-only   Backup configuration files only"
                echo "  --keep N        Keep N most recent backups (default: 5)"
                echo "  --backup-dir    Custom backup directory"
                echo "  -h, --help      Show this help"
                exit 0
                ;;
            *)
                log_error "Unknown option: $1"
                exit 1
                ;;
        esac
    done
}

load_env() {
    if [[ -f "$APP_DIR/.env" ]]; then
        set -a
        source "$APP_DIR/.env"
        set +a
    fi
}

# =============================================================================
# Backup Functions
# =============================================================================

backup_database() {
    if [[ "$CONFIG_ONLY" == "true" ]]; then
        return
    fi

    log_info "Backing up PostgreSQL database..."

    DB_HOST="${POSTGRES_HOST:-localhost}"
    DB_USER="${POSTGRES_USER:-athena_user}"
    DB_NAME="${POSTGRES_DB:-athena_db}"
    DB_BACKUP_FILE="$BACKUP_DIR/${BACKUP_NAME}_database.sql"

    # Create backup using pg_dump
    PGPASSWORD="$POSTGRES_PASSWORD" pg_dump \
        -h "$DB_HOST" \
        -U "$DB_USER" \
        -d "$DB_NAME" \
        --no-owner \
        --no-privileges \
        -f "$DB_BACKUP_FILE"

    # Compress
    gzip "$DB_BACKUP_FILE"

    log_info "Database backup: ${DB_BACKUP_FILE}.gz"
}

backup_config() {
    if [[ "$DB_ONLY" == "true" ]]; then
        return
    fi

    log_info "Backing up configuration files..."

    CONFIG_BACKUP_DIR="$BACKUP_DIR/${BACKUP_NAME}_config"
    mkdir -p "$CONFIG_BACKUP_DIR"

    # Backend .env
    if [[ -f "$APP_DIR/.env" ]]; then
        cp "$APP_DIR/.env" "$CONFIG_BACKUP_DIR/backend.env"
        log_info "Backed up: backend .env"
    fi

    # Frontend .env.production
    if [[ -f "$APP_DIR/frontend/.env.production" ]]; then
        cp "$APP_DIR/frontend/.env.production" "$CONFIG_BACKUP_DIR/frontend.env.production"
        log_info "Backed up: frontend .env.production"
    fi

    # Nginx config
    if [[ -f "/etc/nginx/conf.d/athena.conf" ]]; then
        cp "/etc/nginx/conf.d/athena.conf" "$CONFIG_BACKUP_DIR/nginx-athena.conf"
        log_info "Backed up: nginx config"
    fi

    # Systemd service
    if [[ -f "/etc/systemd/system/athena-backend.service" ]]; then
        cp "/etc/systemd/system/athena-backend.service" "$CONFIG_BACKUP_DIR/athena-backend.service"
        log_info "Backed up: systemd service"
    fi

    # Keycloak docker-compose
    if [[ -f "$KEYCLOAK_DIR/docker-compose.yml" ]]; then
        cp "$KEYCLOAK_DIR/docker-compose.yml" "$CONFIG_BACKUP_DIR/keycloak-docker-compose.yml"
        log_info "Backed up: keycloak docker-compose"
    fi

    # Create archive
    cd "$BACKUP_DIR"
    tar -czf "${BACKUP_NAME}_config.tar.gz" "${BACKUP_NAME}_config"
    rm -rf "$CONFIG_BACKUP_DIR"

    log_info "Config backup: ${BACKUP_NAME}_config.tar.gz"
}

backup_keycloak_data() {
    if [[ "$DB_ONLY" == "true" ]] || [[ "$CONFIG_ONLY" == "true" ]]; then
        return
    fi

    log_info "Backing up Keycloak data..."

    # Check if Keycloak PostgreSQL container is running
    if docker ps | grep -q keycloak-postgres; then
        KC_BACKUP_FILE="$BACKUP_DIR/${BACKUP_NAME}_keycloak.sql"

        docker exec keycloak-postgres pg_dump \
            -U keycloak \
            -d keycloak \
            --no-owner \
            --no-privileges \
            > "$KC_BACKUP_FILE"

        gzip "$KC_BACKUP_FILE"
        log_info "Keycloak backup: ${KC_BACKUP_FILE}.gz"
    else
        log_warn "Keycloak PostgreSQL container not running. Skipping Keycloak backup."
    fi
}

cleanup_old_backups() {
    log_info "Cleaning up old backups (keeping last $KEEP_BACKUPS)..."

    # Database backups
    ls -t "$BACKUP_DIR"/*_database.sql.gz 2>/dev/null | tail -n +$((KEEP_BACKUPS + 1)) | xargs -r rm -f

    # Config backups
    ls -t "$BACKUP_DIR"/*_config.tar.gz 2>/dev/null | tail -n +$((KEEP_BACKUPS + 1)) | xargs -r rm -f

    # Keycloak backups
    ls -t "$BACKUP_DIR"/*_keycloak.sql.gz 2>/dev/null | tail -n +$((KEEP_BACKUPS + 1)) | xargs -r rm -f

    log_info "Cleanup complete"
}

print_summary() {
    echo ""
    echo "=== Backup Summary ==="
    echo ""
    echo "Backup name: $BACKUP_NAME"
    echo "Backup directory: $BACKUP_DIR"
    echo ""
    echo "Files created:"
    ls -lh "$BACKUP_DIR"/${BACKUP_NAME}* 2>/dev/null || echo "  (none)"
    echo ""
    echo "Total backups:"
    echo "  Database: $(ls "$BACKUP_DIR"/*_database.sql.gz 2>/dev/null | wc -l)"
    echo "  Config: $(ls "$BACKUP_DIR"/*_config.tar.gz 2>/dev/null | wc -l)"
    echo "  Keycloak: $(ls "$BACKUP_DIR"/*_keycloak.sql.gz 2>/dev/null | wc -l)"
    echo ""
}

# =============================================================================
# Main
# =============================================================================

main() {
    echo "=============================================="
    echo "  Athena Security Platform - Backup"
    echo "=============================================="
    echo ""

    parse_args "$@"
    load_env

    # Create backup directory
    mkdir -p "$BACKUP_DIR"

    # Run backups
    backup_database
    backup_config
    backup_keycloak_data

    # Cleanup
    cleanup_old_backups

    # Summary
    print_summary

    log_info "Backup complete!"
}

main "$@"
