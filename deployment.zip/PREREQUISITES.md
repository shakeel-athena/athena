# System Prerequisites

## Overview

This document details all system requirements and installation commands for deploying Athena on Amazon Linux 2023.

## Requirements Summary

| Component | Version | Purpose |
|-----------|---------|---------|
| Python | 3.11+ | Backend runtime |
| Node.js | 18 LTS | Frontend build |
| PostgreSQL | 15+ | Application database |
| Docker | Latest | Keycloak container |
| Docker Compose | 2.x+ | Container orchestration |
| Redis | 6.x+ | Caching & task queue |
| Nginx | Latest | Reverse proxy |

## Hardware Recommendations

### Minimum
- CPU: 2 vCPU
- RAM: 4 GB
- Storage: 20 GB SSD

### Recommended (Production)
- CPU: 4 vCPU
- RAM: 8 GB
- Storage: 50 GB SSD

## Installation (Amazon Linux 2023)

### 1. Update System

```bash
sudo dnf update -y
sudo dnf install -y git curl wget vim tar gzip
```

### 2. Install Python 3.11

```bash
# Install Python 3.11
sudo dnf install -y python3.11 python3.11-pip python3.11-devel

# Set as default python3
sudo alternatives --set python3 /usr/bin/python3.11

# Verify installation
python3 --version  # Should show 3.11.x
pip3 --version
```

### 3. Install Node.js 18 LTS

```bash
# Add NodeSource repository
curl -fsSL https://rpm.nodesource.com/setup_18.x | sudo bash -

# Install Node.js
sudo dnf install -y nodejs

# Verify installation
node --version  # Should show v18.x
npm --version
```

### 4. Install PostgreSQL 15

```bash
# Install PostgreSQL
sudo dnf install -y postgresql15-server postgresql15

# Initialize database
sudo postgresql-setup --initdb

# Enable and start service
sudo systemctl enable postgresql
sudo systemctl start postgresql

# Verify installation
sudo -u postgres psql -c "SELECT version();"
```

### 5. Install Docker & Docker Compose

```bash
# Install Docker
sudo dnf install -y docker

# Enable and start service
sudo systemctl enable docker
sudo systemctl start docker

# Add current user to docker group (logout required)
sudo usermod -aG docker $USER

# Install Docker Compose
DOCKER_COMPOSE_VERSION="v2.24.0"
sudo curl -L "https://github.com/docker/compose/releases/download/${DOCKER_COMPOSE_VERSION}/docker-compose-$(uname -s)-$(uname -m)" -o /usr/local/bin/docker-compose
sudo chmod +x /usr/local/bin/docker-compose
sudo ln -sf /usr/local/bin/docker-compose /usr/bin/docker-compose

# Verify installations (after re-login for Docker)
docker --version
docker-compose --version
docker ps
```

### 6. Install Redis

```bash
# Install Redis
sudo dnf install -y redis

# Enable and start service
sudo systemctl enable redis
sudo systemctl start redis

# Verify installation
redis-cli --version
redis-cli ping  # Should return "PONG"
```

### 7. Install Nginx

```bash
# Install Nginx
sudo dnf install -y nginx

# Enable service (don't start yet)
sudo systemctl enable nginx

# Verify installation
nginx -v
```

### 8. Install Additional Tools

```bash
# Build tools (for some Python packages)
sudo dnf groupinstall -y "Development Tools"

# PostgreSQL development headers
sudo dnf install -y postgresql15-devel

# SSL/TLS libraries
sudo dnf install -y openssl-devel
```

## Verification Script

Run this script to verify all prerequisites are installed:

```bash
#!/bin/bash
echo "=== Athena Prerequisites Check ==="

echo -n "Python 3.11: "
python3 --version 2>/dev/null || echo "NOT INSTALLED"

echo -n "pip: "
pip3 --version 2>/dev/null || echo "NOT INSTALLED"

echo -n "Node.js: "
node --version 2>/dev/null || echo "NOT INSTALLED"

echo -n "npm: "
npm --version 2>/dev/null || echo "NOT INSTALLED"

echo -n "PostgreSQL: "
sudo -u postgres psql -c "SELECT version();" 2>/dev/null | head -1 || echo "NOT INSTALLED"

echo -n "Docker: "
docker --version 2>/dev/null || echo "NOT INSTALLED"

echo -n "Docker Compose: "
docker-compose --version 2>/dev/null || echo "NOT INSTALLED"

echo -n "Redis: "
redis-cli --version 2>/dev/null || echo "NOT INSTALLED"

echo -n "Nginx: "
nginx -v 2>&1 || echo "NOT INSTALLED"

echo ""
echo "=== Service Status ==="
sudo systemctl is-active postgresql || echo "postgresql not running"
sudo systemctl is-active docker || echo "docker not running"
sudo systemctl is-active redis || echo "redis not running"
```

## Network Requirements

### Outbound Access Required
- npm registry (registry.npmjs.org)
- PyPI (pypi.org)
- Docker Hub (hub.docker.com)
- Quay.io (quay.io - for Keycloak)

### Inbound Ports
| Port | Service | Access |
|------|---------|--------|
| 22 | SSH | Admin only |
| 80 | HTTP/Nginx | Internal/VPN |
| 8080 | Keycloak | Internal/VPN |

### Internal Ports (localhost only)
| Port | Service |
|------|---------|
| 5000 | Backend API |
| 5432 | PostgreSQL |

## User Setup

Create a dedicated user for running the application:

```bash
# Create athena user
sudo useradd -m -s /bin/bash athena

# Add to docker group
sudo usermod -aG docker athena

# Create application directory
sudo mkdir -p /opt/athena
sudo chown athena:athena /opt/athena

# Create log directory
sudo mkdir -p /var/log/athena
sudo chown athena:athena /var/log/athena
```

## PostgreSQL Configuration

### Create Database and User

```bash
sudo -u postgres psql <<EOF
CREATE DATABASE athena_db;
CREATE USER athena_user WITH ENCRYPTED PASSWORD 'YOUR_SECURE_PASSWORD';
GRANT ALL PRIVILEGES ON DATABASE athena_db TO athena_user;
\c athena_db
GRANT ALL ON SCHEMA public TO athena_user;
GRANT ALL PRIVILEGES ON ALL TABLES IN SCHEMA public TO athena_user;
GRANT ALL PRIVILEGES ON ALL SEQUENCES IN SCHEMA public TO athena_user;
ALTER DEFAULT PRIVILEGES IN SCHEMA public GRANT ALL ON TABLES TO athena_user;
EOF
```

### Configure pg_hba.conf

Edit `/var/lib/pgsql/data/pg_hba.conf`:

```
# Allow local connections with password
local   all   athena_user   md5
host    all   athena_user   127.0.0.1/32   md5
host    all   athena_user   ::1/128        md5
```

Then restart PostgreSQL:
```bash
sudo systemctl restart postgresql
```

### Test Connection

```bash
psql -U athena_user -h localhost -d athena_db -c "SELECT 1"
```

## AWS-Specific Configuration

### Security Group Rules

Create or modify security group with these inbound rules:

| Type | Port | Source |
|------|------|--------|
| SSH | 22 | Your IP |
| HTTP | 80 | VPN/Internal |
| Custom TCP | 8080 | VPN/Internal |

### IAM Role (Optional)

If using AWS WAF/Firewall features, attach an IAM role with:
- `AWSNetworkFirewallFullAccess`
- `AWSWAFFullAccess`

Or create a custom policy with minimal permissions.

## Next Steps

After installing prerequisites:

1. Clone the application repository
2. Run `./scripts/install.sh` for automated setup
3. Configure environment files
4. Deploy with `./scripts/deploy.sh`

See [README.md](README.md) for complete deployment instructions.
