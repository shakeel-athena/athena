# Athena Security Platform - Deployment Guide

## Overview

This folder contains all scripts, configuration templates, and documentation needed to deploy the Athena Security Platform.

## Quick Start

For step-by-step deployment instructions, see:
- **[PRODUCTION_QUICK_START.md](docs/PRODUCTION_QUICK_START.md)** - Complete deployment guide with manual file copy
- **[POST_DEPLOYMENT_CHECKLIST.md](docs/POST_DEPLOYMENT_CHECKLIST.md)** - Verify your deployment is working

## Target Environment

- **OS**: Ubuntu 22.04/24.04 LTS or Amazon Linux 2023
- **Instance**: AWS EC2
- **Elasticsearch**: External (configured via .env)
- **Access**: Internal VPN (future: HTTPS)
- **Services**: Auto-start on reboot via systemd

## Required vs Optional Services

### Required Services
- ✅ Python 3.11+
- ✅ Node.js 18 LTS
- ✅ PostgreSQL 15+ (application database)
- ✅ Redis 6+ (caching & task queue)
- ✅ Docker + Docker Compose (for Keycloak)
- ✅ Nginx (reverse proxy)
- ✅ Elasticsearch (external - Wazuh Indexer)
- ✅ Keycloak (authentication)

### Optional Services
- ⚠️ AWS WAF (if using WAF blocking features)
- ⚠️ AWS Network Firewall (if using firewall management features)
- ⚠️ Wazuh Manager API (if using Active Response features)
- ❌ Neo4j (NOT required - advanced graph visualization only)

## Architecture

```
                     EC2 Instance (Amazon Linux 2023)
+-------------------------------------------------------------------+
|                                                                   |
|   +----------+     +-----------+     +------------------+        |
|   |  Nginx   |---->| Frontend  |     |     Backend      |        |
|   |  :80     |     |  (build)  |     |  Flask :5000     |-----+  |
|   +----+-----+     +-----------+     +--------+---------+     |  |
|        |                                      |               |  |
|        |           +--------------+           |               |  |
|        +---------->|   Keycloak   |<----------+               |  |
|                    |    :8080     |                           |  |
|                    +------+-------+                           |  |
|                           |                                   |  |
|                    +------v-------+     +-----------+         |  |
|                    |  PostgreSQL  |     |   Redis   |<--------+  |
|                    |    :5432     |     |   :6379   |            |
|                    +--------------+     +-----------+            |
|                                                                   |
+-----------------------------+-------------------------------------+
                              |
                              v
                  +------------------------+
                  | External Elasticsearch |
                  |    (Wazuh Indexer)     |
                  +------------------------+
```

## Deployment Steps

### Step 1: Install Prerequisites

See [PREREQUISITES.md](PREREQUISITES.md) for detailed system requirements.

```bash
# Run as root or with sudo
./scripts/install.sh
```

### Step 2: Configure Environment

Copy and edit configuration templates:

```bash
# Backend environment
cp config/.env.production.example /opt/athena/app/.env
nano /opt/athena/app/.env

# Frontend environment
cp config/.env.frontend.example /opt/athena/app/frontend/.env.production
nano /opt/athena/app/frontend/.env.production
```

### Step 3: Setup Keycloak

```bash
# Copy Keycloak compose file
cp config/keycloak-docker-compose.yml /opt/keycloak/docker-compose.yml

# Edit credentials
nano /opt/keycloak/docker-compose.yml

# Start Keycloak
cd /opt/keycloak && docker compose up -d
```

Then configure via Keycloak Admin UI (http://server:8080):
1. Create realm: `athena-security`
2. Create client: `athena-backend` (confidential)
3. Create client: `athena-frontend` (public)
4. Create users and assign roles

### Step 4: Setup Database

```bash
# Initialize database with all tables
psql -U athena_user -h localhost -d athena_db -f database/init-database.sql
```

### Step 5: Deploy Application

```bash
# Run deployment script
./scripts/deploy.sh
```

### Step 6: Start Services

```bash
# Copy and enable systemd service
sudo cp config/athena-backend.service /etc/systemd/system/
sudo systemctl daemon-reload
sudo systemctl enable athena-backend
sudo systemctl start athena-backend

# Copy and enable nginx config
sudo cp config/nginx-athena.conf /etc/nginx/conf.d/athena.conf
sudo nginx -t && sudo systemctl restart nginx
```

## Service Ports

| Service | Port | Access |
|---------|------|--------|
| Nginx (Frontend) | 80 | Public |
| Backend API | 5000 | Localhost only |
| Keycloak | 8080 | Public |
| PostgreSQL | 5432 | Localhost only |
| Redis | 6379 | Localhost only |

## Folder Structure

```
deployment/
├── README.md                        # This file
├── PREREQUISITES.md                 # System requirements
├── AWS_DEPLOYMENT_CHECKLIST.md      # AWS-specific verification
├── HOSTING_REQUIREMENTS.md          # Hosting requirements
├── docs/
│   ├── PRODUCTION_QUICK_START.md    # Step-by-step deployment guide
│   └── POST_DEPLOYMENT_CHECKLIST.md # Post-deployment verification
├── scripts/
│   ├── install.sh                   # System setup script (Amazon Linux)
│   ├── deploy.sh                    # Application deployment
│   ├── backup.sh                    # Database backup
│   └── restore.sh                   # Database restore
├── config/
│   ├── .env.production.example      # Backend env template
│   ├── .env.frontend.example        # Frontend env template
│   ├── athena-backend.service       # Systemd service
│   ├── nginx-athena.conf            # Nginx config
│   ├── keycloak-docker-compose.yml  # Keycloak stack
│   └── logrotate-athena.conf        # Log rotation config
├── database/
│   ├── init-database.sql            # All tables + seeds
│   ├── athena_db.sql                # Database backup (if present)
│   └── README.md                    # Database docs
├── docker/                          # Docker-related files
└── backups/
    └── .gitkeep                     # Backup storage
```

## Scripts

### install.sh
Installs all system prerequisites:
- Python 3.11
- Node.js 18 LTS
- PostgreSQL 15
- Docker
- Nginx

### deploy.sh
Deploys or updates the application:
- Pulls latest code
- Installs dependencies
- Builds frontend
- Runs migrations
- Restarts services

### backup.sh
Creates timestamped backups:
- PostgreSQL database dump
- Environment files
- Keycloak data (optional)

### restore.sh
Restores from backup:
- Database restore
- Configuration restore

## Troubleshooting

### Backend won't start
```bash
# Check logs
sudo journalctl -u athena-backend -f

# Check port
sudo ss -tlnp | grep 5000
```

### Database connection failed
```bash
# Test connection
psql -U athena_user -h localhost -d athena_db -c "SELECT 1"

# Check pg_hba.conf
sudo cat /var/lib/pgsql/data/pg_hba.conf | grep athena
```

### Nginx 502 Bad Gateway
```bash
# Check backend status
sudo systemctl status athena-backend

# Test backend directly
curl http://127.0.0.1:5000/health
```

### Keycloak issues
```bash
# Check container logs
docker logs keycloak

# Restart
cd /opt/keycloak && docker compose restart
```

## Maintenance

### Update Application
```bash
./scripts/deploy.sh
```

### Backup Database
```bash
./scripts/backup.sh
```

### View Logs
```bash
# Backend logs
sudo tail -f /var/log/athena/backend-access.log
sudo tail -f /var/log/athena/backend-error.log

# Nginx logs
sudo tail -f /var/log/nginx/access.log
sudo tail -f /var/log/nginx/error.log

# Systemd logs
sudo journalctl -u athena-backend -f
```

## HTTPS Setup (Future)

When ready for public HTTPS access:

```bash
# Install certbot
sudo dnf install certbot python3-certbot-nginx

# Get certificate
sudo certbot --nginx -d your-domain.com

# Test auto-renewal
sudo certbot renew --dry-run
```
