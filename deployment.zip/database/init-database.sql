-- =============================================================================
-- Athena Security Platform - Database Initialization Script
-- =============================================================================
-- This script creates all necessary tables, indexes, and seed data for the
-- Athena Security Platform database.
--
-- Usage: This is automatically run by Docker PostgreSQL on first startup
-- =============================================================================

-- Enable UUID extension
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- =============================================================================
-- RBAC TABLES (Role-Based Access Control)
-- =============================================================================

-- Users table (synced from Keycloak)
CREATE TABLE IF NOT EXISTS users (
    id SERIAL PRIMARY KEY,
    keycloak_user_id UUID UNIQUE NOT NULL,
    username VARCHAR(255) UNIQUE NOT NULL,
    email VARCHAR(255) UNIQUE NOT NULL,
    full_name VARCHAR(255),
    is_admin BOOLEAN DEFAULT FALSE,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_users_keycloak_id ON users(keycloak_user_id);
CREATE INDEX IF NOT EXISTS idx_users_username ON users(username);
CREATE INDEX IF NOT EXISTS idx_users_email ON users(email);
CREATE INDEX IF NOT EXISTS idx_users_is_active ON users(is_active);

-- Roles table
CREATE TABLE IF NOT EXISTS roles (
    id SERIAL PRIMARY KEY,
    role_name VARCHAR(255) UNIQUE NOT NULL,
    display_name VARCHAR(255) NOT NULL,
    description TEXT,
    is_system_role BOOLEAN DEFAULT FALSE,
    priority INTEGER DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_by INTEGER REFERENCES users(id) ON DELETE SET NULL
);

CREATE INDEX IF NOT EXISTS idx_roles_name ON roles(role_name);
CREATE INDEX IF NOT EXISTS idx_roles_priority ON roles(priority);

-- Pages table
CREATE TABLE IF NOT EXISTS pages (
    id SERIAL PRIMARY KEY,
    page_path VARCHAR(255) UNIQUE NOT NULL,
    page_name VARCHAR(255) NOT NULL,
    page_category VARCHAR(100),
    description TEXT,
    icon VARCHAR(50),
    display_order INTEGER DEFAULT 0,
    parent_page_id INTEGER REFERENCES pages(id) ON DELETE SET NULL,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_pages_path ON pages(page_path);
CREATE INDEX IF NOT EXISTS idx_pages_category ON pages(page_category);
CREATE INDEX IF NOT EXISTS idx_pages_parent ON pages(parent_page_id);
CREATE INDEX IF NOT EXISTS idx_pages_is_active ON pages(is_active);

-- Role-Pages mapping
CREATE TABLE IF NOT EXISTS role_pages (
    id SERIAL PRIMARY KEY,
    role_id INTEGER NOT NULL REFERENCES roles(id) ON DELETE CASCADE,
    page_id INTEGER NOT NULL REFERENCES pages(id) ON DELETE CASCADE,
    can_view BOOLEAN DEFAULT TRUE,
    can_edit BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(role_id, page_id)
);

CREATE INDEX IF NOT EXISTS idx_role_pages_role ON role_pages(role_id);
CREATE INDEX IF NOT EXISTS idx_role_pages_page ON role_pages(page_id);

-- User-Roles mapping
CREATE TABLE IF NOT EXISTS user_roles (
    id SERIAL PRIMARY KEY,
    user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    role_id INTEGER NOT NULL REFERENCES roles(id) ON DELETE CASCADE,
    assigned_by INTEGER REFERENCES users(id) ON DELETE SET NULL,
    assigned_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    expires_at TIMESTAMP,
    UNIQUE(user_id, role_id)
);

CREATE INDEX IF NOT EXISTS idx_user_roles_user ON user_roles(user_id);
CREATE INDEX IF NOT EXISTS idx_user_roles_role ON user_roles(role_id);

-- Audit log
CREATE TABLE IF NOT EXISTS audit_log (
    id SERIAL PRIMARY KEY,
    user_id INTEGER REFERENCES users(id) ON DELETE SET NULL,
    username VARCHAR(255),
    action VARCHAR(100) NOT NULL,
    page_path VARCHAR(255),
    result VARCHAR(50) NOT NULL,
    reason TEXT,
    ip_address VARCHAR(45),
    user_agent TEXT,
    request_method VARCHAR(10),
    request_path VARCHAR(255),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_audit_user ON audit_log(user_id);
CREATE INDEX IF NOT EXISTS idx_audit_action ON audit_log(action);
CREATE INDEX IF NOT EXISTS idx_audit_result ON audit_log(result);
CREATE INDEX IF NOT EXISTS idx_audit_created ON audit_log(created_at);

-- =============================================================================
-- MUTE RULES TABLE
-- =============================================================================
CREATE TABLE IF NOT EXISTS mute_rules (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    rule_name VARCHAR(255) NOT NULL,
    description TEXT,
    source VARCHAR(20) NOT NULL CHECK (source IN ('wazuh', 'suricata', 'both')),
    field_type VARCHAR(50) NOT NULL,
    field_value TEXT NOT NULL,
    match_type VARCHAR(20) DEFAULT 'exact' CHECK (match_type IN ('exact', 'contains', 'regex', 'cidr')),
    is_active BOOLEAN DEFAULT TRUE,
    expires_at TIMESTAMP,
    created_by VARCHAR(100) NOT NULL,
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_mute_rules_source ON mute_rules(source);
CREATE INDEX IF NOT EXISTS idx_mute_rules_active ON mute_rules(is_active);

-- =============================================================================
-- SUPPRESSION SYNC LOG
-- =============================================================================
CREATE TABLE IF NOT EXISTS suppression_sync_log (
    id SERIAL PRIMARY KEY,
    service VARCHAR(20) NOT NULL,
    sync_hash VARCHAR(64) NOT NULL,
    rules_count INTEGER DEFAULT 0,
    success BOOLEAN DEFAULT TRUE,
    error_message TEXT,
    synced_at TIMESTAMP DEFAULT NOW(),
    duration_ms INTEGER,
    CONSTRAINT valid_service CHECK (service IN ('suricata', 'wazuh', 'logstash'))
);

CREATE INDEX IF NOT EXISTS idx_suppression_sync_service ON suppression_sync_log(service, synced_at DESC);

-- =============================================================================
-- ACTIVE RESPONSE TABLES
-- =============================================================================

-- AR Whitelist
CREATE TABLE IF NOT EXISTS ar_whitelist (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    ip_address VARCHAR(45) NOT NULL UNIQUE,
    ip_type VARCHAR(10) NOT NULL CHECK (ip_type IN ('single', 'cidr')),
    description TEXT NOT NULL,
    created_by VARCHAR(100) NOT NULL,
    approved_by VARCHAR(100),
    approval_status VARCHAR(20) NOT NULL DEFAULT 'approved' CHECK (approval_status IN ('pending', 'approved', 'rejected')),
    created_at TIMESTAMP NOT NULL DEFAULT NOW(),
    approved_at TIMESTAMP,
    updated_at TIMESTAMP NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_ar_whitelist_approval ON ar_whitelist(approval_status);
CREATE INDEX IF NOT EXISTS idx_ar_whitelist_ip ON ar_whitelist(ip_address);

-- AR Manual Actions
CREATE TABLE IF NOT EXISTS ar_manual_actions (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    action_type VARCHAR(10) NOT NULL CHECK (action_type IN ('block', 'unblock')),
    ip_address VARCHAR(45) NOT NULL,
    agent_id VARCHAR(50) NOT NULL,
    timeout_seconds INTEGER DEFAULT 0,
    reason TEXT NOT NULL,
    analyst VARCHAR(100) NOT NULL,
    created_at TIMESTAMP DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_ar_manual_actions_created_at ON ar_manual_actions(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_ar_manual_actions_ip ON ar_manual_actions(ip_address);

-- Host Isolation Log
CREATE TABLE IF NOT EXISTS host_isolation_log (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    agent_id VARCHAR(50) NOT NULL,
    agent_name VARCHAR(255),
    agent_ip VARCHAR(45),
    alert_id VARCHAR(255),
    alert_source VARCHAR(20) CHECK (alert_source IN ('wazuh', 'suricata')),
    alert_severity VARCHAR(20),
    threat_type VARCHAR(50),
    reason TEXT NOT NULL,
    action VARCHAR(20) NOT NULL CHECK (action IN ('ISOLATE', 'RESTORE')),
    analyst VARCHAR(100) NOT NULL,
    isolated_at TIMESTAMP DEFAULT NOW(),
    restored_at TIMESTAMP,
    expires_at TIMESTAMP,
    wazuh_api_success BOOLEAN DEFAULT TRUE,
    wazuh_api_error TEXT,
    active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_host_isolation_agent_id ON host_isolation_log(agent_id);
CREATE INDEX IF NOT EXISTS idx_host_isolation_active ON host_isolation_log(active) WHERE active = TRUE;

-- =============================================================================
-- IP HISTORICAL STATS
-- =============================================================================
CREATE TABLE IF NOT EXISTS ip_historical_stats (
    ip_address VARCHAR(45) PRIMARY KEY,
    first_seen_at TIMESTAMP DEFAULT NOW(),
    last_seen_at TIMESTAMP DEFAULT NOW(),
    total_alerts_count INTEGER DEFAULT 0,
    alerts_last_24h INTEGER DEFAULT 0,
    alerts_last_7d INTEGER DEFAULT 0,
    alerts_last_30d INTEGER DEFAULT 0,
    wazuh_alerts_count INTEGER DEFAULT 0,
    suricata_alerts_count INTEGER DEFAULT 0,
    critical_alerts_count INTEGER DEFAULT 0,
    high_alerts_count INTEGER DEFAULT 0,
    medium_alerts_count INTEGER DEFAULT 0,
    low_alerts_count INTEGER DEFAULT 0,
    updated_at TIMESTAMP DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_ip_stats_last_seen ON ip_historical_stats(last_seen_at DESC);

-- =============================================================================
-- THREAT INTELLIGENCE CACHE
-- =============================================================================
CREATE TABLE IF NOT EXISTS threat_intel_cache (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    indicator_type VARCHAR(50) NOT NULL,
    indicator_value TEXT NOT NULL,
    source VARCHAR(100) NOT NULL,
    threat_data JSONB,
    confidence_score INTEGER,
    cache_expires_at TIMESTAMP NOT NULL,
    last_accessed_at TIMESTAMP DEFAULT NOW(),
    created_at TIMESTAMP DEFAULT NOW(),
    UNIQUE(indicator_type, indicator_value, source)
);

CREATE INDEX IF NOT EXISTS idx_threat_intel_indicator ON threat_intel_cache(indicator_type, indicator_value);
CREATE INDEX IF NOT EXISTS idx_threat_intel_expires ON threat_intel_cache(cache_expires_at);

-- =============================================================================
-- TRIGGERS
-- =============================================================================

-- Update timestamp trigger function
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Apply triggers
DO $$
BEGIN
    IF NOT EXISTS (SELECT 1 FROM pg_trigger WHERE tgname = 'update_users_updated_at') THEN
        CREATE TRIGGER update_users_updated_at BEFORE UPDATE ON users
            FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
    END IF;
    IF NOT EXISTS (SELECT 1 FROM pg_trigger WHERE tgname = 'update_roles_updated_at') THEN
        CREATE TRIGGER update_roles_updated_at BEFORE UPDATE ON roles
            FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
    END IF;
    IF NOT EXISTS (SELECT 1 FROM pg_trigger WHERE tgname = 'update_pages_updated_at') THEN
        CREATE TRIGGER update_pages_updated_at BEFORE UPDATE ON pages
            FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
    END IF;
END $$;

-- =============================================================================
-- SEED DATA: PAGES
-- =============================================================================
INSERT INTO pages (page_path, page_name, page_category, description, display_order, icon) VALUES
('/dashboard', 'Overview', 'Core', 'Main dashboard with system overview', 1, 'dashboard'),
('/detection/network-topology', 'Network Topology', 'Detection', 'Network topology visualization', 10, 'graphApp'),
('/detection/nids', 'NIDS Dashboard', 'Detection', 'Network Intrusion Detection System', 11, 'securitySignalDetected'),
('/detection/events', 'Alert Events', 'Detection', 'Security alerts from NIDS and EDR', 12, 'securityApp'),
('/detection/wazuh-rules', 'Wazuh Rules', 'Detection', 'Wazuh detection rules', 13, 'file-text'),
('/detection/promachos', 'Promachos Indexer', 'Detection', 'Security indexer', 14, 'search'),
('/detection/configuration', 'System Configuration', 'Detection', 'Detection system settings', 15, 'settings'),
('/security/firewall-waf', 'Unified Blocking', 'Response', 'Firewall and WAF blocked IPs', 20, 'securityApp'),
('/firewall', 'Linux Firewall', 'Response', 'Linux firewall rules', 21, 'lock'),
('/waf-signatures', 'WAF Rules', 'Response', 'WAF signatures', 22, 'securityApp'),
('/rules', 'WAF Custom Rules', 'Response', 'Custom WAF rules', 23, 'file-text'),
('/responses', 'Response Actions', 'Response', 'Automated response actions', 24, 'zap'),
('/policies', 'Security Policies', 'Response', 'Security policies', 25, 'file-text'),
('/alerts', 'Security Alerts', 'Response', 'Legacy alerts view', 26, 'alert'),
('/active-response', 'Response Dashboard', 'Active Response', 'Active response dashboard', 30, 'dashboardApp'),
('/active-response/advanced', 'Advanced Response', 'Active Response', 'Advanced configuration', 31, 'settings'),
('/threat-intelligence/datasets', 'CTI Datasets', 'Intelligence', 'Threat intelligence datasets', 40, 'database'),
('/intelligence', 'Threat Intelligence', 'Intelligence', 'Threat feeds and indicators', 41, 'globe'),
('/system-health', 'System Health', 'System', 'System health monitoring', 50, 'compute'),
('/admin/agent-control', 'Wazuh Agents', 'Admin', 'Wazuh agent management', 60, 'compute'),
('/admin/mute-rules', 'Mute Rules', 'Admin', 'Alert muting rules', 61, 'bellSlash'),
('/admin/blocked-ips', 'Blocked IPs', 'Admin', 'Blocked IP management', 62, 'securitySignalResolved'),
('/admin/users', 'Users', 'Admin', 'User management', 63, 'users'),
('/admin/roles', 'Roles & Permissions', 'Admin', 'Role management', 64, 'shield'),
('/audit', 'Audit Logs', 'Admin', 'System audit logs', 65, 'file-text'),
('/unauthorized', 'Unauthorized Access', 'System', 'Access denied page', 999, 'x-octagon')
ON CONFLICT (page_path) DO UPDATE SET page_name = EXCLUDED.page_name, description = EXCLUDED.description;

-- =============================================================================
-- SEED DATA: DEFAULT ROLES
-- =============================================================================
INSERT INTO roles (role_name, display_name, description, is_system_role, priority) VALUES
('system-admin', 'System Administrator', 'Full access to all system features', TRUE, 100),
('security-analyst', 'Security Analyst', 'Manage security alerts and response actions', FALSE, 50),
('security-viewer', 'Security Viewer', 'Read-only access to dashboards and alerts', FALSE, 10),
('incident-responder', 'Incident Responder', 'Manage active response and incidents', FALSE, 40),
('waf-manager', 'WAF Manager', 'Manage WAF rules and firewall configurations', FALSE, 45),
('auditor', 'Auditor', 'View-only access to audit logs', FALSE, 20)
ON CONFLICT (role_name) DO UPDATE SET display_name = EXCLUDED.display_name, description = EXCLUDED.description;

-- =============================================================================
-- SEED DATA: AR WHITELIST (Critical Infrastructure)
-- =============================================================================
INSERT INTO ar_whitelist (ip_address, ip_type, description, created_by, approved_by, approval_status, approved_at) VALUES
('127.0.0.1', 'single', 'Localhost', 'system', 'system', 'approved', NOW()),
('::1', 'single', 'Localhost IPv6', 'system', 'system', 'approved', NOW()),
('10.0.0.0/8', 'cidr', 'Internal Network RFC1918 - Class A', 'system', 'system', 'approved', NOW()),
('172.16.0.0/12', 'cidr', 'Internal Network RFC1918 - Class B', 'system', 'system', 'approved', NOW()),
('192.168.0.0/16', 'cidr', 'Internal Network RFC1918 - Class C', 'system', 'system', 'approved', NOW())
ON CONFLICT (ip_address) DO NOTHING;

-- =============================================================================
-- ASSIGN PAGES TO SYSTEM ADMIN ROLE
-- =============================================================================
INSERT INTO role_pages (role_id, page_id, can_view, can_edit)
SELECT
    (SELECT id FROM roles WHERE role_name = 'system-admin'),
    id,
    TRUE,
    TRUE
FROM pages
WHERE is_active = TRUE AND page_path != '/unauthorized'
ON CONFLICT (role_id, page_id) DO UPDATE SET can_view = TRUE, can_edit = TRUE;

-- =============================================================================
-- GRANT PERMISSIONS
-- =============================================================================
GRANT ALL PRIVILEGES ON ALL TABLES IN SCHEMA public TO athena_user;
GRANT ALL PRIVILEGES ON ALL SEQUENCES IN SCHEMA public TO athena_user;

-- =============================================================================
-- INITIALIZATION COMPLETE
-- =============================================================================
DO $$
BEGIN
    RAISE NOTICE '✅ Athena database initialized successfully';
    RAISE NOTICE '✅ Tables: users, roles, pages, role_pages, user_roles, audit_log';
    RAISE NOTICE '✅ Tables: mute_rules, suppression_sync_log, ar_whitelist, ar_manual_actions';
    RAISE NOTICE '✅ Tables: host_isolation_log, ip_historical_stats, threat_intel_cache';
    RAISE NOTICE '✅ Seed data: pages, roles, whitelist entries';
END $$;
