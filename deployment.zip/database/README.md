# Database Setup Guide

## Overview

This folder contains database initialization scripts for the Athena Security Platform.

## Files

| File | Description |
|------|-------------|
| `init-database.sql` | Complete database initialization (all tables + seeds) |

## Quick Setup

### 1. Create Database (if not done during install)

```bash
sudo -u postgres psql

CREATE DATABASE athena_db;
CREATE USER athena_user WITH ENCRYPTED PASSWORD 'your_password';
GRANT ALL PRIVILEGES ON DATABASE athena_db TO athena_user;

\c athena_db
GRANT ALL ON SCHEMA public TO athena_user;

\q
```

### 2. Initialize Tables

```bash
psql -U athena_user -h localhost -d athena_db -f init-database.sql
```

## Database Schema

### RBAC Tables

| Table | Description |
|-------|-------------|
| `users` | User accounts (synced from Keycloak) |
| `roles` | Role definitions |
| `pages` | Application pages/routes |
| `user_roles` | User-role assignments |
| `role_pages` | Role-page permissions |
| `audit_log` | Access audit trail |

### Response Tables

| Table | Description |
|-------|-------------|
| `mute_rules` | Alert suppression rules |
| `suppression_sync_log` | Tracks sync to Wazuh/Suricata |
| `host_isolation_log` | Host isolation actions |
| `ar_whitelist` | IPs that cannot be blocked |
| `ar_manual_actions` | Manual block/unblock log |

## Connection String

```
postgresql://athena_user:password@localhost:5432/athena_db
```

## Default Roles

The seed data creates three default roles:

| Role | Priority | Description |
|------|----------|-------------|
| `system-admin` | 100 | Full access to all features |
| `security-analyst` | 50 | Can manage alerts and responses |
| `security-viewer` | 10 | Read-only access |

## Migrations

Individual migration files are in:
- `database/migrations/` - RBAC tables
- `backend/response/migrations/` - Response tables

The `init-database.sql` file combines all migrations for easier deployment.

## Backup & Restore

### Backup

```bash
pg_dump -U athena_user -h localhost -d athena_db > backup.sql

# Or use the backup script
../scripts/backup.sh
```

### Restore

```bash
psql -U athena_user -h localhost -d athena_db < backup.sql

# Or use the restore script
../scripts/restore.sh --list
../scripts/restore.sh --backup athena_backup_20250115_120000
```

## Troubleshooting

### Connection Refused

```bash
# Check PostgreSQL is running
sudo systemctl status postgresql

# Check pg_hba.conf allows connection
sudo cat /var/lib/pgsql/data/pg_hba.conf | grep athena
```

### Permission Denied

```bash
# Reconnect as postgres and re-grant
sudo -u postgres psql
\c athena_db
GRANT ALL ON ALL TABLES IN SCHEMA public TO athena_user;
GRANT ALL ON ALL SEQUENCES IN SCHEMA public TO athena_user;
```

### View Tables

```bash
psql -U athena_user -h localhost -d athena_db -c "\dt"
```

### Check Table Contents

```bash
# Users
psql -U athena_user -h localhost -d athena_db -c "SELECT * FROM users;"

# Roles
psql -U athena_user -h localhost -d athena_db -c "SELECT * FROM roles;"

# Pages
psql -U athena_user -h localhost -d athena_db -c "SELECT page_path, page_name, page_category FROM pages ORDER BY display_order;"
```
