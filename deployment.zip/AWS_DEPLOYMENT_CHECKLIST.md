# AWS Deployment Verification Checklist

This checklist helps you verify all AWS resources and connectivity before deploying Athena Security Platform.

---

## Pre-Deployment Verification

### ✅ 1. EC2 Instance Setup

**Instance Requirements:**
- [ ] Instance Type: t3.medium or larger (4 vCPU, 8GB RAM recommended)
- [ ] AMI: Amazon Linux 2023
- [ ] Storage: 50GB SSD minimum
- [ ] Region: us-east-2 (or your preferred region)

**Verify Instance:**
```bash
# On your local machine
aws ec2 describe-instances --instance-ids i-YOUR_INSTANCE_ID --region us-east-2

# Check instance is running
aws ec2 describe-instance-status --instance-ids i-YOUR_INSTANCE_ID --region us-east-2
```

---

### ✅ 2. Security Groups Configuration

**Required Inbound Rules:**

| Type | Protocol | Port | Source | Purpose |
|------|----------|------|--------|---------|
| SSH | TCP | 22 | Your IP/CIDR | Management access |
| HTTP | TCP | 80 | VPN/Internal CIDR | Web interface |
| Custom TCP | TCP | 8080 | VPN/Internal CIDR | Keycloak |
| Custom TCP | TCP | 5000 | 127.0.0.1/32 | Backend API (localhost only) |

**Verify Security Group:**
```bash
# Get instance security groups
aws ec2 describe-instances --instance-ids i-YOUR_INSTANCE_ID \
  --query 'Reservations[0].Instances[0].SecurityGroups' --region us-east-2

# Check security group rules
aws ec2 describe-security-groups --group-ids sg-YOUR_SG_ID --region us-east-2
```

**Test connectivity:**
```bash
# From your local machine
ssh -i your-key.pem ec2-user@YOUR_EC2_PUBLIC_IP
```

---

### ✅ 3. IAM Role for EC2 (Recommended)

**If using AWS WAF/Firewall features, attach IAM role instead of using credentials.**

**Create IAM Policy:**
```json
{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Effect": "Allow",
      "Action": [
        "wafv2:GetWebACL",
        "wafv2:UpdateWebACL",
        "wafv2:GetIPSet",
        "wafv2:UpdateIPSet",
        "wafv2:ListIPSets",
        "wafv2:ListWebACLs",
        "wafv2:ListRuleGroups",
        "network-firewall:DescribeRuleGroup",
        "network-firewall:UpdateRuleGroup",
        "network-firewall:ListRuleGroups"
      ],
      "Resource": "*"
    }
  ]
}
```

**Attach role to EC2:**
```bash
# Create role
aws iam create-role --role-name AthenaSecurityRole \
  --assume-role-policy-document file://trust-policy.json

# Attach policy
aws iam put-role-policy --role-name AthenaSecurityRole \
  --policy-name AthenaWAFPolicy --policy-document file://waf-policy.json

# Attach to instance
aws ec2 associate-iam-instance-profile --instance-id i-YOUR_INSTANCE_ID \
  --iam-instance-profile Name=AthenaSecurityRole
```

**Verify IAM role:**
```bash
# On EC2 instance
curl http://169.254.169.254/latest/meta-data/iam/security-credentials/

# Should return role name if attached
```

---

### ✅ 4. Elasticsearch/Wazuh Indexer Connectivity

**Test from EC2 instance:**

```bash
# SSH to EC2
ssh -i your-key.pem ec2-user@YOUR_EC2_IP

# Test Elasticsearch connectivity
curl -k -u admin:YOUR_PASSWORD https://YOUR_ELASTICSEARCH_HOST:9200

# Should return cluster info
```

**Verify indices exist:**
```bash
# Check for Wazuh alerts
curl -k -u admin:YOUR_PASSWORD \
  'https://YOUR_ELASTICSEARCH_HOST:9200/_cat/indices/wazuh-alerts-*?v'

# Check for Suricata alerts
curl -k -u admin:YOUR_PASSWORD \
  'https://YOUR_ELASTICSEARCH_HOST:9200/_cat/indices/suricata-*?v'
```

**Required:**
- [ ] Elasticsearch is reachable from EC2
- [ ] Authentication works
- [ ] Wazuh indices exist (wazuh-alerts-*)
- [ ] Suricata indices exist (suricata-*)

---

### ✅ 5. Wazuh Manager API Connectivity

**Test Wazuh API:**

```bash
# Get Wazuh auth token
curl -k -u wazuh:YOUR_WAZUH_PASSWORD \
  -X POST 'https://YOUR_WAZUH_MANAGER:55000/security/user/authenticate?raw=true'

# Test with token
TOKEN="YOUR_TOKEN_FROM_ABOVE"
curl -k -H "Authorization: Bearer $TOKEN" \
  'https://YOUR_WAZUH_MANAGER:55000/agents?pretty'
```

**Test SSH access (for Active Response):**
```bash
# From EC2 instance
ssh YOUR_SSH_USER@YOUR_WAZUH_MANAGER

# Check AR rules directory
ls -la /var/ossec/etc/shared/
```

**Required:**
- [ ] Wazuh API is accessible
- [ ] Authentication works
- [ ] SSH access to Wazuh Manager works
- [ ] Can read/write /var/ossec/etc/shared/ directory

---

### ✅ 6. AWS WAF Resources (If Using)

**Verify WAF Web ACL exists:**
```bash
# List Web ACLs
aws wafv2 list-web-acls --scope REGIONAL --region us-east-2

# Get specific Web ACL
aws wafv2 get-web-acl --name YOUR_WAF_WEB_ACL \
  --scope REGIONAL --id YOUR_WEB_ACL_ID --region us-east-2
```

**Verify IP Set exists:**
```bash
# List IP Sets
aws wafv2 list-ip-sets --scope REGIONAL --region us-east-2

# Check if "Blocked" IP set exists
aws wafv2 list-ip-sets --scope REGIONAL --region us-east-2 \
  --query "IPSets[?Name=='Blocked']"
```

**Test WAF access from EC2:**
```bash
# On EC2 instance (after IAM role attached or credentials configured)
aws wafv2 list-web-acls --scope REGIONAL --region us-east-2
```

**Required:**
- [ ] WAF Web ACL exists (name matches WAF_WEB_ACL in .env)
- [ ] IP Set "Blocked" exists (or will be created by app)
- [ ] EC2 can access WAF APIs

---

### ✅ 7. AWS Network Firewall (If Using)

**Verify Firewall Rule Group:**
```bash
# List rule groups
aws network-firewall list-rule-groups --region us-east-2

# Get specific rule group
aws network-firewall describe-rule-group \
  --rule-group-name YOUR_FIREWALL_RULE_GROUP --type STATEFUL --region us-east-2
```

**Test access from EC2:**
```bash
# On EC2 instance
aws network-firewall list-rule-groups --region us-east-2
```

**Required:**
- [ ] Rule group exists (name matches FIREWALL_RULE_GROUP in .env)
- [ ] EC2 can access Network Firewall APIs

---

### ✅ 8. Network Connectivity Summary

**Create this test script on EC2:**

```bash
#!/bin/bash
# Save as /tmp/test_connectivity.sh

echo "=== Connectivity Test ==="

# Elasticsearch
echo -n "Elasticsearch: "
curl -k -s -o /dev/null -w "%{http_code}" \
  -u admin:YOUR_ES_PASSWORD https://YOUR_ES_HOST:9200 && echo " OK" || echo " FAILED"

# Wazuh API
echo -n "Wazuh API: "
curl -k -s -o /dev/null -w "%{http_code}" \
  -u wazuh:YOUR_WAZUH_PASSWORD \
  https://YOUR_WAZUH_MANAGER:55000 && echo " OK" || echo " FAILED"

# Wazuh SSH
echo -n "Wazuh SSH: "
ssh -o ConnectTimeout=5 -o BatchMode=yes \
  YOUR_SSH_USER@YOUR_WAZUH_MANAGER exit && echo "OK" || echo "FAILED (setup SSH key)"

# AWS WAF (if using)
echo -n "AWS WAF API: "
aws wafv2 list-web-acls --scope REGIONAL --region us-east-2 >/dev/null 2>&1 \
  && echo "OK" || echo "FAILED (check IAM role/credentials)"

echo "=== Test Complete ==="
```

**Run it:**
```bash
chmod +x /tmp/test_connectivity.sh
/tmp/test_connectivity.sh
```

---

## Deployment Steps

### 1. Clone Repository
```bash
sudo mkdir -p /opt/athena
sudo chown ec2-user:ec2-user /opt/athena
cd /opt/athena
git clone YOUR_REPO_URL app
cd app
```

### 2. Run Prerequisites Installation
```bash
cd /opt/athena/app
sudo ./deployment/scripts/install.sh
```

**What this installs:**
- Python 3.11
- Node.js 18 LTS
- PostgreSQL 15
- Docker + Docker Compose
- Redis
- Nginx

### 3. Configure Environment
```bash
# Copy template
cp .env.example .env

# Edit with your values
nano .env
```

**Critical values to set:**
- All passwords (PostgreSQL, Keycloak, Elasticsearch, Wazuh)
- Elasticsearch host and credentials
- Wazuh Manager host and credentials
- AWS region and resource names (if using WAF/Firewall)

### 4. Setup Keycloak
```bash
cd /opt/keycloak
nano docker-compose.yml  # Set passwords
docker-compose up -d

# Wait for it to start (30-60 seconds)
docker logs -f keycloak
```

**Keycloak Configuration (via UI at http://YOUR_EC2_IP:8080):**
1. Login with admin credentials
2. Create realm: `athena-security`
3. Create backend client: `athena-backend-flask` (confidential)
4. Create frontend client: `athena-frontend` (public)
5. Create roles: admin, security-analyst, security-viewer
6. Create test user and assign roles

### 5. Initialize Database
```bash
cd /opt/athena/app
psql -U athena_user -h localhost -d athena_db \
  -f deployment/database/init-database.sql
```

### 6. Deploy Application
```bash
cd /opt/athena/app
./deployment/scripts/deploy.sh
```

### 7. Enable and Start Services
```bash
# Enable backend service
sudo systemctl enable athena-backend
sudo systemctl start athena-backend

# Check status
sudo systemctl status athena-backend

# Enable nginx
sudo mv /etc/nginx/conf.d/athena.conf.disabled /etc/nginx/conf.d/athena.conf
sudo nginx -t
sudo systemctl restart nginx
```

---

## Post-Deployment Verification

### ✅ Backend Health Check
```bash
# From EC2 instance
curl http://localhost:5000/health

# Expected: {"status": "healthy"}
```

### ✅ Comprehensive Health Check
```bash
curl http://localhost:5000/api/health/comprehensive

# Should return status of all components
```

### ✅ Frontend Access
```bash
# From your browser
http://YOUR_EC2_PUBLIC_IP

# Should show Athena login page
```

### ✅ Keycloak Access
```bash
# From your browser
http://YOUR_EC2_PUBLIC_IP:8080

# Should show Keycloak admin console
```

### ✅ Test Alert Retrieval
```bash
# Get Wazuh alerts
curl -H "Authorization: Bearer YOUR_KEYCLOAK_TOKEN" \
  http://localhost:5000/api/alerts/wazuh?limit=10

# Should return alerts
```

### ✅ Test WAF/Firewall Access (If Using)
```bash
# List blocked IPs
curl -H "Authorization: Bearer YOUR_KEYCLOAK_TOKEN" \
  http://localhost:5000/api/waf/blocked-ips

# Should return list (may be empty initially)
```

---

## Monitoring & Logs

### View Logs
```bash
# Backend logs
sudo journalctl -u athena-backend -f

# Nginx access logs
sudo tail -f /var/log/nginx/access.log

# Nginx error logs
sudo tail -f /var/log/nginx/error.log

# Application logs
sudo tail -f /var/log/athena/backend-access.log
sudo tail -f /var/log/athena/backend-error.log
```

### Check Service Status
```bash
# All services
sudo systemctl status athena-backend nginx postgresql redis docker

# Keycloak container
docker ps | grep keycloak
docker logs keycloak
```

---

## Troubleshooting

### Backend Won't Start
```bash
# Check logs
sudo journalctl -u athena-backend -n 50

# Common issues:
# 1. Database connection - check POSTGRES_* in .env
# 2. Port 5000 in use - check: sudo ss -tlnp | grep 5000
# 3. Missing dependencies - run: source /opt/athena/app/venv/bin/activate && pip install -r backend/requirements.txt
```

### Can't Connect to Elasticsearch
```bash
# Test from EC2
curl -k -v -u admin:PASSWORD https://ES_HOST:9200

# Check security group allows outbound HTTPS
# Check VPC endpoint configuration if using AWS ES
```

### WAF/Firewall Not Working
```bash
# Verify IAM role
aws sts get-caller-identity

# Test WAF access
aws wafv2 list-web-acls --scope REGIONAL --region us-east-2

# Check .env has correct:
# - AWS_REGION
# - WAF_WEB_ACL
# - FIREWALL_RULE_GROUP
```

### Keycloak Issues
```bash
# Check container
docker ps
docker logs keycloak

# Restart
cd /opt/keycloak
docker-compose restart

# Check database
docker exec -it keycloak-postgres psql -U keycloak -d keycloak -c "\dt"
```

---

## Security Hardening (Optional)

### Setup HTTPS with Let's Encrypt
```bash
sudo dnf install certbot python3-certbot-nginx
sudo certbot --nginx -d your-domain.com
sudo certbot renew --dry-run
```

### Setup Firewall
```bash
sudo dnf install firewalld
sudo systemctl enable firewalld
sudo systemctl start firewalld

sudo firewall-cmd --permanent --add-service=http
sudo firewall-cmd --permanent --add-service=https
sudo firewall-cmd --permanent --add-port=8080/tcp
sudo firewall-cmd --reload
```

### Use AWS Secrets Manager (Recommended)
Instead of storing credentials in .env, use AWS Secrets Manager:

```bash
# Store secrets
aws secretsmanager create-secret --name athena/db-password \
  --secret-string "YOUR_DB_PASSWORD" --region us-east-2

# Retrieve in app startup script
DB_PASSWORD=$(aws secretsmanager get-secret-value \
  --secret-id athena/db-password --region us-east-2 \
  --query SecretString --output text)
```

---

## Backup & Disaster Recovery

### Automated Backups
```bash
# Setup cron job for daily backups
crontab -e

# Add this line (runs daily at 2 AM)
0 2 * * * /opt/athena/app/deployment/scripts/backup.sh
```

### Manual Backup
```bash
cd /opt/athena/app
./deployment/scripts/backup.sh

# Backups stored in: deployment/backups/
```

### Restore from Backup
```bash
# List available backups
./deployment/scripts/restore.sh --list

# Restore specific backup
./deployment/scripts/restore.sh --backup athena_backup_20260113_020000
```

---

## Final Checklist

**Before going live:**

- [ ] All services running (athena-backend, nginx, postgresql, redis, docker/keycloak)
- [ ] Health endpoints responding
- [ ] Can login to frontend
- [ ] Can retrieve alerts from Elasticsearch
- [ ] Wazuh API accessible
- [ ] WAF/Firewall APIs accessible (if using)
- [ ] All passwords changed from defaults
- [ ] .env file has production values
- [ ] DEBUG=False in .env
- [ ] Backups configured
- [ ] Logs being written
- [ ] Keycloak users and roles configured
- [ ] SSL/HTTPS configured (if public-facing)

**Ready to deploy! 🚀**
