# Production Deployment Checklist

Quick reference checklist for deploying Athena Security Platform to production via manual file transfer.

---

## Pre-Deployment (On Your Machine)

### 1. Prepare Files for Transfer

```bash
# Create deployment archive (excludes node_modules, venv, logs, etc.)
cd /path/to/athena/project
tar --exclude='node_modules' \
    --exclude='venv' \
    --exclude='__pycache__' \
    --exclude='.git' \
    --exclude='*.log' \
    --exclude='.env' \
    --exclude='frontend/build' \
    -czvf athena-deploy.tar.gz .
```

**Files to transfer:**
- [ ] `athena-deploy.tar.gz` (application code)
- [ ] Your SSH private key for NRM→Dev communication

---

## On Production Server (NRM)

### 2. System Prerequisites

Run the install script (requires root):

```bash
# SSH to production server
ssh root@YOUR_NRM_SERVER_IP

# Create app directory
sudo mkdir -p /opt/athena
sudo chown $USER:$USER /opt/athena

# Transfer and extract files
cd /opt/athena
# Upload athena-deploy.tar.gz via SCP/SFTP
tar -xzvf athena-deploy.tar.gz -C app/
cd app

# Run prerequisite installation
sudo bash deployment/scripts/install.sh
```

**Verify installation:**
- [ ] Python 3.11+ installed
- [ ] Node.js 18 LTS installed
- [ ] PostgreSQL 15 running
- [ ] Docker running
- [ ] Redis running (optional)
- [ ] Nginx installed

---

### 3. Configure Environment Variables

```bash
cd /opt/athena/app

# Backend configuration
cp deployment/config/.env.production.example .env
nano .env
```

**Required `.env` changes:**

| Variable | Action |
|----------|--------|
| `SECRET_KEY` | Generate: `python3 -c "import secrets; print(secrets.token_hex(32))"` |
| `POSTGRES_PASSWORD` | Use password from install.sh output |
| `ELASTICSEARCH_HOST` | Set to: `https://YOUR_DEV_SERVER:9200` |
| `ELASTICSEARCH_PASSWORD` | Get from Dev server |
| `WAZUH_MANAGER_HOST` | Set to: `YOUR_DEV_SERVER_IP` |
| `WAZUH_API_PASSWORD` | Get from Dev server |
| `WAZUH_INDEXER_URL` | Set to: `https://YOUR_DEV_SERVER:9200` |
| `WAZUH_INDEXER_PASSWORD` | Same as ES password |
| `KEYCLOAK_CLIENT_SECRET` | Get from Keycloak after setup |

```bash
# Frontend configuration
cp deployment/config/.env.frontend.example frontend/.env.production
nano frontend/.env.production
```

**Required frontend changes:**
- [ ] Replace `YOUR_SERVER_IP` with actual NRM server IP in all URLs

---

### 4. SSH Key Setup (NRM → Dev Server)

```bash
# Generate SSH key for Dev server communication
ssh-keygen -t ed25519 -f /opt/athena/app/.ssh/athena_sync_rsa -C "Athena NRM to Dev" -N ""

# Set permissions
chmod 700 /opt/athena/app/.ssh
chmod 600 /opt/athena/app/.ssh/athena_sync_rsa

# Display public key (copy this)
cat /opt/athena/app/.ssh/athena_sync_rsa.pub
```

**On Dev Server:**
```bash
# SSH to Dev server and add public key
ssh root@YOUR_DEV_SERVER_IP

# Switch to athena-sync user (create if needed)
sudo su - athena-sync

# Add public key
mkdir -p ~/.ssh && chmod 700 ~/.ssh
echo "PASTE_PUBLIC_KEY_HERE" >> ~/.ssh/authorized_keys
chmod 600 ~/.ssh/authorized_keys
```

**Test SSH connection:**
```bash
# From NRM server
ssh -i /opt/athena/app/.ssh/athena_sync_rsa athena-sync@YOUR_DEV_SERVER_IP "echo SUCCESS"
```

- [ ] SSH key authentication working

---

### 5. Database Initialization

```bash
cd /opt/athena/app

# Initialize database tables
PGPASSWORD="YOUR_DB_PASSWORD" psql -U athena_user -h localhost -d athena_db \
    -f deployment/database/init-database.sql
```

- [ ] Database tables created
- [ ] Default roles seeded
- [ ] Pages seeded

---

### 6. Keycloak Setup

```bash
cd /opt/keycloak

# Edit docker-compose.yml with secure passwords
nano docker-compose.yml

# Start Keycloak
docker compose up -d

# Wait for startup (1-2 minutes)
docker compose logs -f
```

**Configure Keycloak (via UI at http://YOUR_SERVER_IP:8080):**

1. [ ] Login as admin
2. [ ] Create realm: `athena-security`
3. [ ] Create client: `athena-backend` (Confidential, Service accounts enabled)
4. [ ] Create client: `athena-frontend` (Public)
5. [ ] Create roles: `admin`, `security-analyst`, `security-viewer`
6. [ ] Create initial admin user and assign roles
7. [ ] Copy `athena-backend` client secret to `.env` file

---

### 7. Deploy Application

```bash
cd /opt/athena/app

# Run deployment (skip git pull since we copied files)
bash deployment/scripts/deploy.sh --skip-git
```

**Deployment steps executed:**
- [ ] Backend dependencies installed
- [ ] Frontend dependencies installed
- [ ] Frontend built
- [ ] Database migrations applied
- [ ] Backend service started
- [ ] Nginx restarted

---

### 8. Enable Nginx

```bash
# Enable nginx config
sudo mv /etc/nginx/conf.d/athena.conf.disabled /etc/nginx/conf.d/athena.conf

# Test configuration
sudo nginx -t

# Restart nginx
sudo systemctl restart nginx
```

- [ ] Nginx configuration valid
- [ ] Nginx running

---

## Post-Deployment Verification

### 9. Health Checks

```bash
# Backend health
curl http://localhost:5000/health

# API comprehensive health
curl http://localhost:5000/api/health/comprehensive

# Frontend (through nginx)
curl http://localhost/

# Keycloak
curl http://localhost:8080/health
```

**Expected results:**
- [ ] Backend: `{"status": "healthy"}`
- [ ] API: Shows all services status
- [ ] Frontend: Returns HTML
- [ ] Keycloak: `{"status": "UP"}`

---

### 10. Wazuh Integration Test

```bash
# Test SSH to Dev server
ssh -i /opt/athena/app/.ssh/athena_sync_rsa athena-sync@YOUR_DEV_SERVER "sudo systemctl is-active wazuh-manager"

# Test Elasticsearch connectivity
curl -k -u admin:YOUR_ES_PASSWORD https://YOUR_DEV_SERVER:9200

# Verify Wazuh indices
curl -k -u admin:YOUR_ES_PASSWORD https://YOUR_DEV_SERVER:9200/_cat/indices/wazuh-alerts-*
```

- [ ] SSH connection working
- [ ] Elasticsearch accessible
- [ ] Wazuh indices exist

---

### 11. Application Access

Access URLs:
- **Frontend:** http://YOUR_SERVER_IP/
- **Backend API:** http://YOUR_SERVER_IP/api/
- **Keycloak:** http://YOUR_SERVER_IP:8080/

**Test login:**
1. [ ] Navigate to frontend
2. [ ] Redirected to Keycloak login
3. [ ] Login with created user
4. [ ] Dashboard loads
5. [ ] Alerts visible (if any exist)

---

## Service Management

### Start/Stop Services

```bash
# Backend
sudo systemctl start athena-backend
sudo systemctl stop athena-backend
sudo systemctl restart athena-backend
sudo systemctl status athena-backend

# Nginx
sudo systemctl restart nginx

# Keycloak
cd /opt/keycloak && docker compose restart

# PostgreSQL
sudo systemctl restart postgresql
```

### View Logs

```bash
# Backend logs
sudo journalctl -u athena-backend -f
tail -f /var/log/athena/backend-*.log

# Nginx logs
tail -f /var/log/nginx/access.log
tail -f /var/log/nginx/error.log

# Keycloak logs
cd /opt/keycloak && docker compose logs -f
```

---

## Troubleshooting

| Issue | Check | Fix |
|-------|-------|-----|
| Frontend 404s | `.env.production` has correct API URLs | Rebuild frontend after fixing |
| Backend won't start | Check `.env` for missing variables | Compare with `.env.production.example` |
| Can't connect to ES | Security groups allow outbound 9200 | Update AWS security group |
| SSH to Dev fails | Key permissions are 600 | `chmod 600 /opt/athena/app/.ssh/*` |
| Keycloak login fails | Client settings correct | Check realm and client config |
| No alerts showing | ES indices exist and have data | Check time range filter |

---

## Backup Reminder

After successful deployment, create initial backup:

```bash
bash deployment/scripts/backup.sh
```

This creates:
- Database dump
- Configuration backup
- Keycloak backup

---

**Deployment Complete!**
