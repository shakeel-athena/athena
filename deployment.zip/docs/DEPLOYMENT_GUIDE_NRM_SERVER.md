# Athena Security Platform - NRM Server Deployment Guide

## Server Information

| Property | Value |
|----------|-------|
| Server | NRM Production Server |
| IP Address | 172.16.129.133 |
| OS | Amazon Linux 2023 |
| Wazuh/Dev Server | 172.16.132.198 (Ubuntu 24.04 LTS) |

---

## Directory Structure

```
/opt/deployment/                    # Main application directory
├── backend/
│   └── response/
│       ├── src/                    # Flask backend source code
│       │   ├── api/                # API route blueprints
│       │   ├── core/               # Database, config modules
│       │   ├── middleware/         # Auth, rate limiting, etc.
│       │   ├── services/           # Business logic
│       │   └── utils/              # Utility functions (rbac.py)
│       ├── venv/                   # Python virtual environment
│       └── .env                    # Backend configuration
├── frontend/
│   ├── build/                      # Production React build
│   └── .env.production             # Frontend configuration
└── config/                         # Configuration templates

/opt/keycloak/                      # Keycloak authentication server
├── docker-compose.yml              # Keycloak Docker config
└── athena-security-realm.json      # Realm export (if exists)

/etc/nginx/conf.d/athena.conf       # Nginx proxy configuration
/etc/systemd/system/athena-backend.service  # Backend systemd service
```

---

## Services & Ports

| Service | Port | Description |
|---------|------|-------------|
| Nginx (Frontend) | 8088 | Serves React app & proxies /api/ |
| Nginx (API Proxy) | 5000 | Proxies to backend for frontend API calls |
| Backend (Gunicorn) | 5001 | Flask backend API |
| Keycloak | 8080 | Authentication server |
| PostgreSQL | 5432 | Database |
| Elasticsearch | 9200 | Alert data (on 172.16.132.198) |

---

## Configuration Files

### Backend Environment (`/opt/deployment/backend/response/.env`)

```bash
# Database
POSTGRES_HOST=localhost
POSTGRES_PORT=5432
POSTGRES_DB=athena_db
POSTGRES_USER=athena_user
POSTGRES_PASSWORD=<password>

# Keycloak
KEYCLOAK_URL=http://localhost:8080
KEYCLOAK_REALM=athena-security
KEYCLOAK_CLIENT_ID=athena-backend-flask
KEYCLOAK_CLIENT_SECRET=NIk44mzpG8F6k73rbTg4a0Yet4Lko7XW

# Elasticsearch (Wazuh server)
ELASTICSEARCH_HOST=172.16.132.198
ELASTICSEARCH_PORT=9200
ELASTICSEARCH_USER=admin
ELASTICSEARCH_PASSWORD=<password>
ELASTICSEARCH_INDEX=wazuh-alerts-*
```

### Frontend Environment (`/opt/deployment/frontend/.env.production`)

```bash
REACT_APP_API_URL=http://172.16.129.133:5000
REACT_APP_API_BASE_URL=http://172.16.129.133:5000
REACT_APP_KEYCLOAK_URL=http://172.16.129.133:8080
REACT_APP_KEYCLOAK_REALM=athena-security
REACT_APP_KEYCLOAK_CLIENT_ID=athena-frontend
```

### Nginx Configuration (`/etc/nginx/conf.d/athena.conf`)

```nginx
server {
    listen 8088;
    server_name _;

    root /opt/deployment/frontend/build;
    index index.html;

    location / {
        try_files $uri $uri/ /index.html;
    }

    location /api/ {
        proxy_pass http://127.0.0.1:5001/api/;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header Authorization $http_authorization;
        proxy_pass_header Authorization;
    }
}

server {
    listen 5000;
    server_name _;

    location / {
        # Handle CORS preflight
        if ($request_method = 'OPTIONS') {
            add_header 'Access-Control-Allow-Origin' '*';
            add_header 'Access-Control-Allow-Methods' 'GET, POST, PUT, DELETE, OPTIONS';
            add_header 'Access-Control-Allow-Headers' 'Authorization, Content-Type, Accept';
            add_header 'Access-Control-Max-Age' 86400;
            add_header 'Content-Length' 0;
            return 204;
        }

        proxy_pass http://127.0.0.1:5001;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header Authorization $http_authorization;
        proxy_pass_header Authorization;

        add_header 'Access-Control-Allow-Origin' '*' always;
        add_header 'Access-Control-Allow-Headers' 'Authorization, Content-Type' always;
    }
}
```

### Systemd Service (`/etc/systemd/system/athena-backend.service`)

```ini
[Unit]
Description=Athena Backend API
After=network.target postgresql.service

[Service]
Type=simple
User=root
WorkingDirectory=/opt/deployment/backend/response
Environment="PYTHONPATH=/opt/deployment:/opt/deployment/backend:/opt/deployment/backend/response:/opt/deployment/backend/response/src"
ExecStart=/opt/deployment/backend/response/venv/bin/gunicorn --bind 127.0.0.1:5001 --workers 2 --chdir src 'app_factory:create_app()'
Restart=always
RestartSec=5

[Install]
WantedBy=multi-user.target
```

---

## Keycloak Configuration

### Admin Credentials
- **URL**: http://172.16.129.133:8080
- **Admin Console**: http://172.16.129.133:8080/admin
- **Username**: admin
- **Password**: Admin@123*

### Realm: athena-security

#### Clients

| Client ID | Type | Purpose |
|-----------|------|---------|
| athena-frontend | Public | React frontend authentication |
| athena-backend-flask | Confidential | Backend API validation |

#### athena-frontend Client Settings
- **Client Protocol**: openid-connect
- **Access Type**: public
- **Valid Redirect URIs**:
  - `http://172.16.129.133:8088/*`
  - `http://localhost:3000/*`
  - `http://localhost:8088/*`
- **Web Origins**:
  - `http://172.16.129.133:8088`
  - `+`

#### athena-frontend Protocol Mappers
- **backend-audience**: Adds `athena-backend-flask` to token audience

#### athena-backend-flask Client Settings
- **Client Protocol**: openid-connect
- **Access Type**: confidential
- **Client Secret**: `NIk44mzpG8F6k73rbTg4a0Yet4Lko7XW`

### Default User
- **Username**: admin
- **Password**: Admin@123*
- **Email**: admin@athena.local
- **Roles**: system-admin

---

## Database

### PostgreSQL Configuration

**pg_hba.conf** (TCP/IP access enabled):
```
host    athena_db    athena_user    127.0.0.1/32    md5
```

### Connection Details
```
Host: localhost
Port: 5432
Database: athena_db
User: athena_user
```

### Database Tables

#### RBAC Tables
| Table | Description |
|-------|-------------|
| users | User accounts (synced from Keycloak) |
| roles | Role definitions |
| pages | Application pages/routes |
| user_roles | User-role assignments |
| role_pages | Role-page permissions |
| audit_log | Access audit trail |

#### Response Tables
| Table | Description |
|-------|-------------|
| mute_rules | Alert suppression rules |
| suppression_sync_log | Tracks sync to Wazuh/Suricata |
| host_isolation_log | Host isolation actions |
| ar_whitelist | IPs that cannot be blocked |
| ar_manual_actions | Manual block/unblock log |

---

## Service Management Commands

### Backend Service
```bash
# Start
systemctl start athena-backend

# Stop
systemctl stop athena-backend

# Restart
systemctl restart athena-backend

# Status
systemctl status athena-backend

# View logs
journalctl -u athena-backend -f
```

### Nginx
```bash
# Test configuration
nginx -t

# Reload
systemctl reload nginx

# Restart
systemctl restart nginx
```

### Keycloak (Docker)
```bash
cd /opt/keycloak

# Start
docker-compose up -d

# Stop
docker-compose down

# View logs
docker-compose logs -f

# Restart
docker-compose restart
```

### PostgreSQL
```bash
# Status
systemctl status postgresql

# Restart
systemctl restart postgresql

# Connect
sudo -u postgres psql -d athena_db
```

---

## Access URLs

| Service | URL |
|---------|-----|
| Web Application | http://172.16.129.133:8088 |
| Keycloak Admin | http://172.16.129.133:8080/admin |
| Backend Health | http://172.16.129.133:5001/api/health |

---

## Troubleshooting

### Backend Not Starting
```bash
# Check logs
journalctl -u athena-backend -n 50

# Manual start for debugging
cd /opt/deployment/backend/response
source venv/bin/activate
export PYTHONPATH=/opt/deployment:/opt/deployment/backend:/opt/deployment/backend/response:/opt/deployment/backend/response/src
gunicorn --bind 127.0.0.1:5001 --workers 1 --chdir src 'app_factory:create_app()' --log-level debug
```

### Authentication Issues (401 Errors)
1. Check Keycloak is running: `docker ps`
2. Verify client secret matches in backend .env
3. Ensure audience mapper is configured on athena-frontend client
4. Test token manually:
```bash
USER_TOKEN=$(curl -s -X POST "http://localhost:8080/realms/athena-security/protocol/openid-connect/token" \
  -H "Content-Type: application/x-www-form-urlencoded" \
  -d "username=admin" -d "password=Admin@123*" \
  -d "grant_type=password" -d "client_id=athena-frontend" | grep -o '"access_token":"[^"]*' | cut -d'"' -f4)

curl -s http://localhost:5001/api/admin/users -H "Authorization: Bearer $USER_TOKEN"
```

### Database Connection Issues
```bash
# Test connection
psql -U athena_user -h localhost -d athena_db -c "SELECT 1"

# Check pg_hba.conf
sudo cat /var/lib/pgsql/data/pg_hba.conf | grep athena
```

### Nginx Proxy Issues
```bash
# Check configuration
nginx -t

# Check for duplicate configs
grep -r "listen 8088" /etc/nginx/
grep -r "listen 5000" /etc/nginx/

# Remove duplicates from sites-enabled
ls -la /etc/nginx/sites-enabled/
```

---

## Fixes Applied During Deployment

| Issue | Fix |
|-------|-----|
| PostgreSQL TCP/IP disabled | Added host entry to pg_hba.conf |
| PYTHONPATH not set | Added to systemd service Environment |
| Keycloak token audience mismatch | Added audience mapper to athena-frontend client |
| RBAC decorator bug | Fixed `g.user_id is None` check in rbac.py |
| Keycloak redirect URI invalid | Added server IP to client redirect URIs |
| CORS blocking browser requests | Added CORS headers to nginx port 5000 |

---

## Maintenance

### Backup Database
```bash
pg_dump -U athena_user -h localhost -d athena_db > backup_$(date +%Y%m%d).sql
```

### Update Backend Code
```bash
# Stop service
systemctl stop athena-backend

# Update code (git pull or copy files)
cd /opt/deployment
# ... update files ...

# Restart service
systemctl start athena-backend
```

### Regenerate Keycloak Client Secret
```bash
ADMIN_TOKEN=$(curl -s -X POST "http://localhost:8080/realms/master/protocol/openid-connect/token" \
  -H "Content-Type: application/x-www-form-urlencoded" \
  -d "username=admin" -d "password=Admin@123*" \
  -d "grant_type=password" -d "client_id=admin-cli" | grep -o '"access_token":"[^"]*' | cut -d'"' -f4)

# Get client UUID
CLIENT_UUID=$(curl -s "http://localhost:8080/admin/realms/athena-security/clients?clientId=athena-backend-flask" \
  -H "Authorization: Bearer $ADMIN_TOKEN" | grep -o '"id":"[^"]*' | head -1 | cut -d'"' -f4)

# Regenerate secret
curl -s -X POST "http://localhost:8080/admin/realms/athena-security/clients/$CLIENT_UUID/client-secret" \
  -H "Authorization: Bearer $ADMIN_TOKEN"

# Get new secret
curl -s "http://localhost:8080/admin/realms/athena-security/clients/$CLIENT_UUID/client-secret" \
  -H "Authorization: Bearer $ADMIN_TOKEN"

# Update backend .env with new secret and restart
```

---

*Document generated: 2026-01-15*
*Deployment version: 1.1.02*
