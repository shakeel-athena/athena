# Athena Security Platform - Quick Start Checklist

**Use this for rapid deployment on new servers**

For detailed instructions, see: [DEPLOYMENT_GUIDE.md](DEPLOYMENT_GUIDE.md)

---

## Pre-Deployment Checklist

### Information Gathering

- [ ] Dev server IP address: `___________________`
- [ ] NRM server IP address: `___________________`
- [ ] Elasticsearch password: `___________________`
- [ ] Wazuh API password: `___________________`
- [ ] Network security groups configured
- [ ] SSH access to both servers confirmed

---

## Dev Server Setup (Security Stack)

**Server IP:** `172.16.132.198` (Ubuntu 24.04)

### Step 1: Create athena-sync User (5 min)

```bash
# SSH as root
ssh root@DEV_SERVER_IP

# Create user
sudo useradd -m -s /bin/bash athena-sync
sudo usermod -aG wazuh athena-sync

# Configure passwordless sudo
sudo tee /etc/sudoers.d/athena-sync > /dev/null << 'EOF'
athena-sync ALL=(ALL) NOPASSWD: ALL
EOF
sudo chmod 440 /etc/sudoers.d/athena-sync
sudo visudo -c

# Verify
sudo -u athena-sync sudo -n true && echo "OK"
```

- [ ] User created
- [ ] Passwordless sudo working

---

### Step 2: Install Dependencies (5 min)

```bash
# Install Python and tools
sudo apt update
sudo apt install -y python3 python3-pip python3-venv python3-paramiko

# Verify
python3 --version  # Should be 3.12.3+
pip3 --version
```

- [ ] Python installed
- [ ] pip installed
- [ ] paramiko installed

---

### Step 3: Verify Wazuh Installation (2 min)

```bash
# Check Wazuh status
sudo systemctl status wazuh-manager

# Check Elasticsearch
sudo systemctl status wazuh-indexer
curl -k -u admin:PASSWORD https://localhost:9200

# Check file ownership (MUST be wazuh:wazuh NOT root:ossec)
ls -la /var/ossec/etc/rules/*.xml
```

- [ ] Wazuh Manager running
- [ ] Elasticsearch accessible
- [ ] File ownership is `wazuh:wazuh`

---

### Step 4: Install Suricata (Optional - 5 min)

```bash
sudo apt update
sudo apt install -y suricata
sudo systemctl enable suricata
sudo systemctl start suricata
sudo systemctl status suricata
```

- [ ] Suricata installed (or skip if not needed)

---

## NRM Server Setup (Application Server)

**Server IP:** `172.16.129.133` (Amazon Linux 2023)

### Step 5: Install System Packages (10 min)

```bash
# SSH as root
ssh root@NRM_SERVER_IP

# Update system
sudo dnf update -y

# Install base packages
sudo dnf install -y git curl wget vim tar gzip

# Install development tools
sudo dnf groupinstall -y "Development Tools"
sudo dnf install -y openssl-devel
```

- [ ] System updated
- [ ] Base packages installed
- [ ] Development tools installed

---

### Step 6: Install Python (5 min)

```bash
# Install Python 3.11+
sudo dnf install -y python3.11 python3.11-pip python3.11-devel

# Install paramiko for integration scripts
pip3 install paramiko

# Verify
python3 --version
pip3 list | grep paramiko
```

- [ ] Python 3.11+ installed
- [ ] paramiko installed

---

### Step 7: Install Node.js 18 LTS (5 min)

```bash
# Add Node.js repository
curl -fsSL https://rpm.nodesource.com/setup_18.x | sudo bash -

# Install Node.js
sudo dnf install -y nodejs

# Verify
node --version   # Should be v18.x.x
npm --version
```

- [ ] Node.js 18 installed
- [ ] npm working

---

### Step 8: Install PostgreSQL 15 (5 min)

```bash
# Install PostgreSQL
sudo dnf install -y postgresql15-server postgresql15 postgresql15-devel

# Initialize database
sudo postgresql-setup --initdb

# Enable and start service
sudo systemctl enable postgresql
sudo systemctl start postgresql
sudo systemctl status postgresql

# Verify
sudo -u postgres psql -c "SELECT version();"
```

- [ ] PostgreSQL installed
- [ ] PostgreSQL service running

---

## SSH Key Configuration

### Step 9: Generate SSH Key on NRM Server (2 min)

```bash
# On NRM server
ssh-keygen -t ed25519 -f ~/.ssh/nrm_to_athena_ed25519 -C "NRM to Athena" -N ""

# Set permissions
chmod 600 ~/.ssh/nrm_to_athena_ed25519
chmod 644 ~/.ssh/nrm_to_athena_ed25519.pub

# View public key
cat ~/.ssh/nrm_to_athena_ed25519.pub
```

- [ ] SSH key generated
- [ ] Permissions set correctly

---

### Step 10: Copy Public Key to Dev Server (2 min)

```bash
# Option 1: Using ssh-copy-id
ssh-copy-id -i ~/.ssh/nrm_to_athena_ed25519.pub athena-sync@DEV_SERVER_IP

# Option 2: Manual (if ssh-copy-id not available)
# On Dev server as athena-sync:
mkdir -p ~/.ssh
chmod 700 ~/.ssh
nano ~/.ssh/authorized_keys  # Paste public key
chmod 600 ~/.ssh/authorized_keys
```

- [ ] Public key copied to Dev server

---

### Step 11: Test SSH Connection (1 min)

```bash
# From NRM server
ssh -i ~/.ssh/nrm_to_athena_ed25519 athena-sync@DEV_SERVER_IP "echo 'SSH working'"

# Test sudo
ssh -i ~/.ssh/nrm_to_athena_ed25519 athena-sync@DEV_SERVER_IP "sudo systemctl is-active wazuh-manager"

# Should print: active
```

- [ ] SSH connection working
- [ ] Passwordless sudo working
- [ ] Can access Wazuh Manager

**⚠️ CRITICAL: If this fails, deployment will not work. Fix before proceeding.**

---

## Wazuh Integration Setup

### Step 12: Run Wazuh Mute Integration Script (5 min)

```bash
# On NRM server
cd /path/to/athena/project

# Run integration script
python3 scripts/integration/setup_wazuh_mute_integration.py
```

**Expected output:**
```
[1/8] Testing SSH connection... ✅
[2/8] Verifying Wazuh Manager status... ✅
[3/8] Creating athena_mute_ips CDB file... ✅
[4/8] Creating athena_mute_rules.xml file... ✅
[5/8] Verifying ossec.conf configuration... ✅
[6/8] Adding CDB whitelist rule to local_rules.xml... ✅
[7/8] Compiling CDB lists... ✅
[8/8] Restarting Wazuh Manager... ✅

✅ Setup completed successfully!
```

- [ ] All 8 steps completed
- [ ] No errors reported
- [ ] Wazuh Manager restarted successfully

---

### Step 13: Verify Wazuh Integration (2 min)

```bash
# On Dev server
ssh -i ~/.ssh/nrm_to_athena_ed25519 athena-sync@DEV_SERVER_IP

# Check files were created
sudo ls -lh /var/ossec/etc/rules/athena_mute_rules.xml
sudo ls -lh /var/ossec/etc/lists/athena_mute_ips

# Check ownership (MUST be wazuh:wazuh)
# Check Wazuh Manager status
sudo systemctl status wazuh-manager
```

- [ ] Files created with correct ownership
- [ ] Wazuh Manager running

---

## Suricata Integration Setup (Optional)

### Step 14: Run Suricata Mute Integration Script (5 min)

**Only if Suricata is installed**

```bash
# On NRM server
python3 scripts/integration/setup_suricata_mute_integration.py
```

- [ ] Suricata integration completed (or skipped)

---

## Application Deployment

### Step 15: Clone Repository (2 min)

```bash
# On NRM server
sudo mkdir -p /opt/athena
sudo chown $USER:$USER /opt/athena

cd /opt/athena
git clone <REPOSITORY_URL> app
cd app
```

- [ ] Repository cloned to `/opt/athena/app/`

---

### Step 16: Configure Environment (.env) (10 min)

```bash
cd /opt/athena/app

# Copy template
cp .env.example .env

# Edit configuration
nano .env
```

**Critical settings to update:**

```bash
# Elasticsearch (Dev Server)
ELASTICSEARCH_HOST=https://172.16.132.198:9200
ELASTICSEARCH_USER=admin
ELASTICSEARCH_PASSWORD=<YOUR_ES_PASSWORD>

# Wazuh
WAZUH_HOST=172.16.132.198
WAZUH_PASSWORD=<YOUR_ES_PASSWORD>

# Wazuh SSH
WAZUH_MANAGER_HOST=172.16.132.198
WAZUH_SSH_USER=athena-sync
WAZUH_SSH_KEY_PATH=/root/.ssh/nrm_to_athena_ed25519

# PostgreSQL (Local)
POSTGRES_HOST=localhost
POSTGRES_PASSWORD=<GENERATE_STRONG_PASSWORD>

# Flask
SECRET_KEY=<GENERATE_WITH: python3 -c "import secrets; print(secrets.token_hex(32))">
DEBUG=False
FLASK_ENV=production

# Generate SECRET_KEY:
python3 -c "import secrets; print(secrets.token_hex(32))"
```

- [ ] .env file configured
- [ ] All passwords set
- [ ] SECRET_KEY generated

---

### Step 17: Initialize Database (5 min)

```bash
# Create database and user
sudo -u postgres psql << EOF
CREATE DATABASE athena_db;
CREATE USER athena_user WITH ENCRYPTED PASSWORD '<YOUR_POSTGRES_PASSWORD>';
GRANT ALL PRIVILEGES ON DATABASE athena_db TO athena_user;
\q
EOF

# Run migrations
cd /opt/athena/app
python3 backend/response/src/init_db.py
```

- [ ] Database created
- [ ] User created
- [ ] Schema initialized

---

### Step 18: Install Backend Dependencies (5 min)

```bash
cd /opt/athena/app/backend/response
pip3 install -r requirements.txt
```

- [ ] Backend dependencies installed

---

### Step 19: Install Frontend Dependencies (5 min)

```bash
cd /opt/athena/app/frontend
npm install
```

- [ ] Frontend dependencies installed

---

### Step 20: Build Frontend (5 min)

```bash
cd /opt/athena/app/frontend
npm run build
```

- [ ] Frontend built successfully

---

### Step 21: Start Services (2 min)

```bash
# Start backend (test mode)
cd /opt/athena/app/backend/response
python3 src/app.py &

# Note: For production, use systemd service
```

- [ ] Backend started
- [ ] No errors in console

---

## Verification

### Step 22: Run Verification Script (5 min)

```bash
cd /opt/athena/app
bash deployment/scripts/verify_nrm_prerequisites.sh
```

- [ ] All critical tests passed

---

### Step 23: Test Application (5 min)

```bash
# Test backend API
curl http://localhost:5001/api/health

# Access frontend (in browser)
http://NRM_SERVER_IP:3000

# Test Elasticsearch connection
curl http://localhost:5001/api/alerts
```

- [ ] Backend API responding
- [ ] Frontend accessible
- [ ] Can fetch alerts from Elasticsearch

---

## Post-Deployment

### Step 24: Security Hardening

- [ ] Change default passwords
- [ ] Restrict security group rules to known IPs
- [ ] Enable firewall rules
- [ ] Set up SSL/TLS certificates
- [ ] Configure log rotation
- [ ] Set up monitoring and alerting

---

### Step 25: Create Systemd Services

Create services for:
- [ ] Flask backend
- [ ] React frontend (if not using Nginx)
- [ ] Redis (if installed)

---

## Troubleshooting Quick Reference

### SSH Connection Failed
```bash
# Check key permissions
chmod 600 ~/.ssh/nrm_to_athena_ed25519

# Test with verbose output
ssh -vvv -i ~/.ssh/nrm_to_athena_ed25519 athena-sync@DEV_SERVER_IP

# Check authorized_keys on Dev server
ls -la /home/athena-sync/.ssh/
```

### Wazuh Manager Won't Start
```bash
# Check configuration
sudo /var/ossec/bin/wazuh-control check

# View logs
sudo tail -f /var/ossec/logs/ossec.log

# Common issues:
# - XML syntax errors
# - Empty groups (need placeholder rule)
# - Wrong file ownership (must be wazuh:wazuh)
```

### Integration Script Fails
```bash
# Test SSH first
ssh -i ~/.ssh/nrm_to_athena_ed25519 athena-sync@DEV_SERVER_IP "sudo -n true && echo OK"

# Check paramiko installed
pip3 list | grep paramiko

# Run with Python verbose
python3 -v scripts/integration/setup_wazuh_mute_integration.py
```

### Database Connection Failed
```bash
# Check PostgreSQL running
sudo systemctl status postgresql

# Test connection
psql -h localhost -U athena_user -d athena_db

# Check pg_hba.conf for authentication rules
sudo nano /var/lib/pgsql/data/pg_hba.conf
```

---

## Time Estimate

| Phase | Estimated Time |
|-------|----------------|
| Dev Server Setup | 20 minutes |
| NRM Server Setup | 30 minutes |
| SSH Configuration | 5 minutes |
| Integration Scripts | 10 minutes |
| Application Deployment | 30 minutes |
| Verification & Testing | 15 minutes |
| **Total** | **~2 hours** |

*Actual time may vary depending on download speeds and system performance*

---

## Contact Information

- **Documentation:** [DEPLOYMENT_GUIDE.md](DEPLOYMENT_GUIDE.md)
- **Status Tracking:** [DEPLOYMENT_STATUS.md](DEPLOYMENT_STATUS.md)
- **Integration Scripts:** `scripts/integration/`
- **Deployment Scripts:** `deployment/scripts/`

---

**Last Updated:** 2026-01-14
**Version:** 1.1.02
