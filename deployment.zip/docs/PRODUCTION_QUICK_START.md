# Athena Security Platform - Production Quick Start Guide

## Overview

This guide covers deploying Athena to a production server using **manual file copy** (SCP/SFTP) instead of git clone. This is the recommended approach for air-gapped environments or when git access is not available on the production server.

**Tested Environment:**
- Ubuntu 24.04 LTS (AWS EC2)
- Server IP: 172.16.129.133 (NRM Server)
- Wazuh/Dev Server: 172.16.132.198

---

## Prerequisites

### On Production Server
- Ubuntu 22.04/24.04 LTS or Amazon Linux 2023
- Minimum 4GB RAM, 2 vCPU
- 50GB disk space
- SSH access

### AWS Security Group Rules

Ensure your Security Group allows inbound traffic from your VPN/internal network:

| Port | Protocol | Source | Purpose |
|------|----------|--------|---------|
| 22 | TCP | Your IP | SSH access |
| 80 | TCP | VPN CIDR (e.g., 10.100.0.0/16) | Web interface |
| 5000 | TCP | VPN CIDR | Backend API |
| 8080 | TCP | VPN CIDR | Keycloak |
| 8088 | TCP | VPN CIDR | Nginx (if using custom port) |

---

## Step 1: Prepare Local Files

### 1.1 Build Frontend Locally

```bash
cd frontend
npm install
npm run build
```

### 1.2 Export Keycloak Realm (if migrating from dev)

```bash
# Find your local Keycloak container name
docker ps | grep keycloak

# Export realm (replace 'athena-keycloak' with your container name)
docker exec -it athena-keycloak /opt/keycloak/bin/kc.sh export \
  --dir /tmp/export --realm athena-security --users realm_file

# Copy export file to local machine
docker cp athena-keycloak:/tmp/export/athena-security-realm.json ./
```

---

## Step 2: Transfer Files to Server

### 2.1 Create Directory Structure

```bash
ssh ubuntu@YOUR_SERVER_IP
sudo mkdir -p /opt/deployment
sudo chown ubuntu:ubuntu /opt/deployment
```

### 2.2 Copy Files via SCP

From your local machine:

```bash
# Copy backend
scp -r backend ubuntu@YOUR_SERVER_IP:/opt/deployment/

# Copy frontend build
scp -r frontend/build ubuntu@YOUR_SERVER_IP:/opt/deployment/frontend/

# Copy deployment configs
scp -r deployment ubuntu@YOUR_SERVER_IP:/opt/deployment/

# Copy Keycloak realm export
scp athena-security-realm.json ubuntu@YOUR_SERVER_IP:/opt/keycloak/
```

---

## Step 3: Install System Dependencies

SSH to server and run:

```bash
# Update system
sudo apt update && sudo apt upgrade -y

# Install Python 3.11
sudo apt install -y python3.11 python3.11-venv python3-pip

# Install PostgreSQL
sudo apt install -y postgresql postgresql-contrib

# Install Redis
sudo apt install -y redis-server
sudo systemctl enable redis-server
sudo systemctl start redis-server

# Install Nginx
sudo apt install -y nginx
sudo systemctl enable nginx

# Install Docker
sudo apt install -y docker.io docker-compose-v2
sudo systemctl enable docker
sudo systemctl start docker
sudo usermod -aG docker ubuntu
```

---

## Step 4: Setup PostgreSQL Database

```bash
# Switch to postgres user
sudo -u postgres psql

# Create database and user
CREATE DATABASE athena_db;
CREATE USER athena_user WITH ENCRYPTED PASSWORD 'YOUR_SECURE_PASSWORD';
GRANT ALL PRIVILEGES ON DATABASE athena_db TO athena_user;
\c athena_db
GRANT ALL ON SCHEMA public TO athena_user;
\q
```

### Restore Database from Backup (if available)

```bash
psql -U athena_user -h localhost -d athena_db -f /opt/deployment/deployment/database/athena_db.sql
```

Or initialize fresh:

```bash
psql -U athena_user -h localhost -d athena_db -f /opt/deployment/deployment/database/init-database.sql
```

---

## Step 5: Setup Backend

### 5.1 Create Virtual Environment

```bash
cd /opt/deployment/backend/response
python3.11 -m venv venv
source venv/bin/activate
```

### 5.2 Install Dependencies

```bash
pip install --upgrade pip
pip install -r ../requirements.txt
pip install -r requirements.txt
pip install gunicorn
```

### 5.3 Configure Environment

```bash
# Copy and edit .env file
cp /opt/deployment/deployment/config/.env.production.example /opt/deployment/backend/response/.env
nano /opt/deployment/backend/response/.env
```

**Critical values to update:**
```bash
# Database
POSTGRES_HOST=localhost
POSTGRES_PASSWORD=YOUR_DATABASE_PASSWORD

# Keycloak (use your server IP)
KEYCLOAK_URL=http://172.16.129.133:8080

# Elasticsearch/Wazuh Indexer
ELASTICSEARCH_HOST=172.16.132.198
ELASTICSEARCH_PASSWORD=YOUR_ES_PASSWORD
WAZUH_INDEXER_URL=https://172.16.132.198:9200

# Wazuh Manager
WAZUH_MANAGER_HOST=172.16.132.198
WAZUH_API_URL=https://172.16.132.198:55000

# CORS (add your server IP)
CORS_ORIGINS=http://172.16.129.133:8088,http://172.16.129.133
```

### 5.4 Test Backend Startup

```bash
cd /opt/deployment/backend/response
source venv/bin/activate

PYTHONPATH=/opt/deployment:/opt/deployment/backend:/opt/deployment/backend/response/src \
  gunicorn --bind 0.0.0.0:5000 "src.app_factory:create_app()" --timeout 120
```

If successful, you should see:
```
[INFO] Starting gunicorn...
[INFO] Listening at: http://0.0.0.0:5000
```

Press Ctrl+C to stop.

---

## Step 6: Setup Keycloak

### 6.1 Create Docker Compose File

```bash
sudo mkdir -p /opt/keycloak
cd /opt/keycloak

sudo tee docker-compose.yml << 'EOF'
version: '3.8'
services:
  keycloak-db:
    image: postgres:15-alpine
    container_name: athena-keycloak-db
    environment:
      POSTGRES_DB: keycloak
      POSTGRES_USER: keycloak
      POSTGRES_PASSWORD: YOUR_KEYCLOAK_DB_PASSWORD
    volumes:
      - keycloak_db_data:/var/lib/postgresql/data
    restart: unless-stopped
    healthcheck:
      test: ["CMD-SHELL", "pg_isready -U keycloak"]
      interval: 10s
      timeout: 5s
      retries: 5

  keycloak:
    image: quay.io/keycloak/keycloak:22.0.5
    container_name: athena-keycloak
    environment:
      KC_DB: postgres
      KC_DB_URL: jdbc:postgresql://keycloak-db:5432/keycloak
      KC_DB_USERNAME: keycloak
      KC_DB_PASSWORD: YOUR_KEYCLOAK_DB_PASSWORD
      KEYCLOAK_ADMIN: admin
      KEYCLOAK_ADMIN_PASSWORD: YOUR_ADMIN_PASSWORD
      KC_PROXY: edge
      KC_HOSTNAME_STRICT: "false"
      KC_HTTP_ENABLED: "true"
    ports:
      - "8080:8080"
    depends_on:
      keycloak-db:
        condition: service_healthy
    command: start-dev --import-realm
    volumes:
      - ./athena-security-realm.json:/opt/keycloak/data/import/athena-security-realm.json
    restart: unless-stopped

volumes:
  keycloak_db_data:
EOF
```

### 6.2 Start Keycloak

```bash
cd /opt/keycloak
sudo docker compose up -d

# Check logs (wait for "Keycloak started")
sudo docker compose logs -f keycloak
```

### 6.3 Verify Realm Import

```bash
curl -s http://localhost:8080/realms/athena-security | head -5
```

Should return JSON with realm information.

### 6.4 Configure Client Redirect URIs

**IMPORTANT:** Access Keycloak Admin Console and update the athena-frontend client:

1. Go to `http://YOUR_SERVER_IP:8080/admin`
2. Login with admin credentials
3. Select **athena-security** realm
4. Go to **Clients** → **athena-frontend**
5. Update these fields:

| Field | Value |
|-------|-------|
| Root URL | `http://YOUR_SERVER_IP:8088` |
| Home URL | `http://YOUR_SERVER_IP:8088` |
| Valid redirect URIs | `http://YOUR_SERVER_IP:8088/*` |
| Valid post logout redirect URIs | `http://YOUR_SERVER_IP:8088/*` |
| Web origins | `http://YOUR_SERVER_IP:8088` |

6. Click **Save**

---

## Step 7: Configure Frontend

### 7.1 Update Keycloak URL in Built Files

The React build has Keycloak URLs baked in. Replace `localhost:8080` with your server IP:

```bash
# Replace localhost:8080 with server IP in all JS files
sudo find /opt/deployment/frontend/build -name "*.js" -exec \
  sed -i 's|localhost:8080|172.16.129.133:8080|g' {} \;

# Verify replacement
grep -r "172.16.129.133:8080" /opt/deployment/frontend/build/ | head -3
```

### 7.2 Update Frontend .env

```bash
cat > /opt/deployment/frontend/.env << 'EOF'
REACT_APP_API_BASE_URL=http://172.16.129.133:5000
REACT_APP_API_URL=http://172.16.129.133:5000/api
REACT_APP_KEYCLOAK_URL=http://172.16.129.133:8080
EOF
```

---

## Step 8: Configure Nginx

```bash
sudo tee /etc/nginx/sites-available/athena << 'EOF'
server {
    listen 8088;
    server_name _;

    # Frontend
    location / {
        root /opt/deployment/frontend/build;
        index index.html;
        try_files $uri $uri/ /index.html;
    }

    # Backend API proxy
    location /api/ {
        proxy_pass http://127.0.0.1:5000/api/;
        proxy_http_version 1.1;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_read_timeout 120s;
        proxy_connect_timeout 120s;
    }
}
EOF

# Enable site
sudo ln -sf /etc/nginx/sites-available/athena /etc/nginx/sites-enabled/
sudo rm -f /etc/nginx/sites-enabled/default

# Test and restart
sudo nginx -t && sudo systemctl restart nginx
```

---

## Step 9: Create Systemd Service (Optional)

```bash
sudo tee /etc/systemd/system/athena-backend.service << 'EOF'
[Unit]
Description=Athena Backend API
After=network.target postgresql.service redis.service

[Service]
Type=simple
User=ubuntu
Group=ubuntu
WorkingDirectory=/opt/deployment/backend/response
Environment="PYTHONPATH=/opt/deployment:/opt/deployment/backend:/opt/deployment/backend/response/src"
ExecStart=/opt/deployment/backend/response/venv/bin/gunicorn \
    --bind 0.0.0.0:5000 \
    --workers 4 \
    --timeout 120 \
    --access-logfile /var/log/athena/access.log \
    --error-logfile /var/log/athena/error.log \
    "src.app_factory:create_app()"
Restart=always
RestartSec=10

[Install]
WantedBy=multi-user.target
EOF

# Create log directory
sudo mkdir -p /var/log/athena
sudo chown ubuntu:ubuntu /var/log/athena

# Enable and start service
sudo systemctl daemon-reload
sudo systemctl enable athena-backend
sudo systemctl start athena-backend

# Check status
sudo systemctl status athena-backend
```

---

## Step 10: Verify Deployment

### 10.1 Check All Services

```bash
# Backend
curl http://localhost:5000/health

# Keycloak
curl http://localhost:8080/realms/athena-security

# Nginx
curl http://localhost:8088/
```

### 10.2 Access from Browser

Open in browser:
```
http://YOUR_SERVER_IP:8088/
```

You should see the Athena login page. After login, verify:
- Dashboard loads correctly
- Alerts are displayed from Elasticsearch
- Navigation works

---

## Troubleshooting

### Backend Won't Start

```bash
# Check logs
sudo journalctl -u athena-backend -f

# Common fixes:
# 1. Check PYTHONPATH is set correctly
# 2. Verify .env file exists and has correct values
# 3. Test database connection:
psql -U athena_user -h localhost -d athena_db -c "SELECT 1"
```

### Keycloak "Invalid redirect_uri" Error

Update client settings in Keycloak Admin:
1. Go to Clients → athena-frontend
2. Add your server URL to "Valid redirect URIs"
3. Add your server URL to "Web origins"

### Frontend Shows "localhost:8080" in URL

Run the sed command to replace URLs:
```bash
sudo find /opt/deployment/frontend/build -name "*.js" -exec \
  sed -i 's|localhost:8080|YOUR_SERVER_IP:8080|g' {} \;
```

### Cannot Access from Browser (Connection Timeout)

Check AWS Security Group allows traffic from your VPN CIDR:
- Ports: 80, 5000, 8080, 8088
- Source: Your VPN CIDR (e.g., 10.100.0.0/16)

### Keycloak Container Won't Start

```bash
# Check logs
sudo docker compose logs keycloak

# Common issues:
# 1. Database not ready - wait for health check
# 2. Port 8080 already in use
# 3. Realm JSON file path incorrect
```

---

## Quick Reference

| Component | URL | Port |
|-----------|-----|------|
| Frontend | http://SERVER_IP:8088 | 8088 |
| Backend API | http://SERVER_IP:5000 | 5000 |
| Keycloak Admin | http://SERVER_IP:8080/admin | 8080 |

| Service | Command |
|---------|---------|
| Start Backend | `sudo systemctl start athena-backend` |
| Stop Backend | `sudo systemctl stop athena-backend` |
| Backend Logs | `sudo journalctl -u athena-backend -f` |
| Start Keycloak | `cd /opt/keycloak && sudo docker compose up -d` |
| Stop Keycloak | `cd /opt/keycloak && sudo docker compose down` |
| Keycloak Logs | `sudo docker compose logs -f keycloak` |
| Restart Nginx | `sudo systemctl restart nginx` |

---

## Maintenance

### Backup Database

```bash
pg_dump -U athena_user -h localhost athena_db > backup_$(date +%Y%m%d).sql
```

### Update Application

1. Build new frontend locally
2. Copy new files via SCP
3. Restart services:
```bash
sudo systemctl restart athena-backend
sudo systemctl restart nginx
```

### View Logs

```bash
# Backend
sudo tail -f /var/log/athena/error.log

# Nginx
sudo tail -f /var/log/nginx/error.log

# Keycloak
sudo docker compose logs -f keycloak
```
