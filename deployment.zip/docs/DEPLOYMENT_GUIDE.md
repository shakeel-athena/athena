# Athena Security Platform - Complete Deployment Guide

## Document Information
- **Version:** 1.1.02
- **Last Updated:** 2026-01-14
- **Environment:** AWS EC2 (Ubuntu 24.04 LTS)
- **Purpose:** Step-by-step guide for deploying Athena Security Platform

---

## Table of Contents
1. [Infrastructure Overview](#infrastructure-overview)
2. [Prerequisites](#prerequisites)
3. [Server Setup](#server-setup)
4. [SSH Key Configuration](#ssh-key-configuration)
5. [Wazuh Mute Integration](#wazuh-mute-integration)
6. [Suricata Mute Integration](#suricata-mute-integration)
7. [Application Deployment](#application-deployment)
8. [Troubleshooting Guide](#troubleshooting-guide)
9. [Verification & Testing](#verification-testing)

---

## Infrastructure Overview

### Server Architecture

```
┌─────────────────────────────────────────────────────────────┐
│                    Athena Platform v1.1.02                   │
├─────────────────────────────────────────────────────────────┤
│                                                               │
│  ┌──────────────────────┐        ┌──────────────────────┐   │
│  │   NRM Server         │        │   Dev Server          │   │
│  │   172.16.129.133     │───SSH──│   172.16.132.198     │   │
│  │   (Amazon Linux)     │        │   (Ubuntu 24.04)     │   │
│  │                      │        │                      │   │
│  │  • Flask Backend     │        │  • Wazuh Manager     │   │
│  │  • React Frontend    │        │  • Elasticsearch     │   │
│  │  • PostgreSQL        │        │  • Suricata (TBD)    │   │
│  │  • Keycloak          │        │                      │   │
│  │  • Redis (optional)  │        │                      │   │
│  └──────────────────────┘        └──────────────────────┘   │
│                                                               │
└─────────────────────────────────────────────────────────────┘
```

### Component Distribution

| Component | Server | IP Address | Port | Purpose |
|-----------|--------|------------|------|---------|
| **Wazuh Manager** | Dev | 172.16.132.198 | 1514, 1515 | HIDS, Log Analysis |
| **Elasticsearch** | Dev | 172.16.132.198 | 9200 | Alert Storage |
| **Wazuh Indexer** | Dev | 172.16.132.198 | 9200 | Same as Elasticsearch |
| **Suricata IDS** | Dev | 172.16.132.198 | N/A | Network IDS (pending) |
| **Flask Backend** | NRM | 172.16.129.133 | 5001 | Athena API |
| **React Frontend** | NRM | 172.16.129.133 | 3000 | Web UI |
| **PostgreSQL** | NRM | 172.16.129.133 | 5432 | Athena Database |
| **Keycloak** | NRM | 172.16.129.133 | 8080 | Authentication |

---

## Prerequisites

### Hardware Requirements

#### NRM Server (Application Server)
- **CPU:** 4+ cores recommended
- **RAM:** 8GB minimum (16GB recommended)
- **Disk:** 50GB minimum
- **OS:** Amazon Linux 2023 or Ubuntu 22.04+

#### Dev Server (Security Stack)
- **CPU:** 4+ cores
- **RAM:** 8GB minimum (16GB recommended for ES)
- **Disk:** 100GB minimum (for alert storage)
- **OS:** Ubuntu 24.04 LTS

### Network Requirements

#### Security Group Rules

**NRM Server (172.16.129.133) - Outbound:**
- Port 22 → Dev Server (SSH)
- Port 9200 → Dev Server (Elasticsearch)
- Port 55000 → Dev Server (Wazuh API) - Optional
- Port 443 → Internet (HTTPS for package repos)

**NRM Server (172.16.129.133) - Inbound:**
- Port 22 → Admin IPs (SSH management)
- Port 3000 → User network (Frontend access)
- Port 5001 → Internal only (Backend API)
- Port 8080 → User network (Keycloak - optional)

**Dev Server (172.16.132.198) - Inbound:**
- Port 22 ← NRM Server (SSH for integration scripts)
- Port 9200 ← NRM Server (Elasticsearch queries)
- Port 1514 ← Agents (Wazuh agent communication)
- Port 1515 ← Agents (Wazuh enrollment)

### Software Prerequisites

#### Both Servers
- SSH server running
- Internet connectivity
- DNS resolution working

#### Dev Server (Already Installed)
- ✅ Ubuntu 24.04 LTS
- ✅ Wazuh Manager 4.x
- ✅ Elasticsearch/Wazuh Indexer
- ✅ Python 3.12.3
- ⏸️ Suricata IDS (pending installation)

#### NRM Server (To Be Installed)
- Python 3.11+ (has 3.12.3)
- Node.js 18 LTS
- PostgreSQL 15+
- pip3 and paramiko
- Git

---

## Server Setup

### 1. Dev Server Setup (172.16.132.198)

#### 1.1 Create Athena Sync User

```bash
# SSH into Dev server as root or sudo user
ssh root@172.16.132.198

# Create athena-sync user
sudo useradd -m -s /bin/bash athena-sync

# Add to wazuh group (for file access)
sudo usermod -aG wazuh athena-sync

# Configure passwordless sudo
sudo tee /etc/sudoers.d/athena-sync > /dev/null << 'EOF'
athena-sync ALL=(ALL) NOPASSWD: ALL
EOF

# Set proper permissions
sudo chmod 440 /etc/sudoers.d/athena-sync

# Verify
sudo visudo -c
```

**Why This Is Needed:**
- Integration scripts need to write files to Wazuh directories
- Scripts need to restart Wazuh Manager service
- Passwordless sudo allows automation without storing passwords

#### 1.2 Install Python and Dependencies

```bash
# Update system
sudo apt update

# Install Python 3 and pip (if not already installed)
sudo apt install -y python3 python3-pip python3-venv

# Install paramiko for SSH automation
sudo apt install -y python3-paramiko

# Verify installation
python3 --version  # Should show 3.12.3 or higher
pip3 --version
```

#### 1.3 Verify Wazuh Installation

```bash
# Check Wazuh Manager status
sudo systemctl status wazuh-manager

# Verify Wazuh directories exist
ls -la /var/ossec/etc/
ls -la /var/ossec/etc/rules/
ls -la /var/ossec/etc/lists/
ls -la /var/ossec/etc/shared/

# Check Wazuh file permissions
ls -la /var/ossec/etc/rules/*.xml

# Expected: -rw-r----- 1 wazuh wazuh (NOT root:ossec)
```

**IMPORTANT:** Ubuntu 24.04 Wazuh uses `wazuh:wazuh` ownership, not `root:ossec`.

#### 1.4 Verify Elasticsearch

```bash
# Check Elasticsearch/Wazuh Indexer status
sudo systemctl status wazuh-indexer

# Test connectivity (replace password)
curl -k -u admin:YOUR_PASSWORD https://localhost:9200

# Check Wazuh indices
curl -k -u admin:YOUR_PASSWORD https://localhost:9200/_cat/indices/wazuh-alerts-*
```

#### 1.5 Install Suricata (When Ready)

```bash
# Install Suricata
sudo apt update
sudo apt install -y suricata

# Enable and start service
sudo systemctl enable suricata
sudo systemctl start suricata

# Verify installation
suricata --version
sudo systemctl status suricata

# Check configuration directory
ls -la /etc/suricata/
```

---

### 2. NRM Server Setup (172.16.129.133)

#### 2.1 Install System Packages

```bash
# SSH into NRM server
ssh root@172.16.129.133

# Update system (Amazon Linux 2023)
sudo dnf update -y

# Install base packages
sudo dnf install -y git curl wget vim tar gzip

# Install development tools
sudo dnf groupinstall -y "Development Tools"
sudo dnf install -y openssl-devel
```

#### 2.2 Install Python 3.11+

```bash
# Install Python 3.11
sudo dnf install -y python3.11 python3.11-pip python3.11-devel

# Set as default (optional)
sudo alternatives --set python3 /usr/bin/python3.11

# Verify
python3 --version
pip3 --version

# Install paramiko for integration scripts
pip3 install paramiko
```

#### 2.3 Install Node.js 18 LTS

```bash
# Add Node.js repository
curl -fsSL https://rpm.nodesource.com/setup_18.x | sudo bash -

# Install Node.js
sudo dnf install -y nodejs

# Verify
node --version   # Should be v18.x.x
npm --version
```

#### 2.4 Install PostgreSQL 15

```bash
# Install PostgreSQL
sudo dnf install -y postgresql15-server postgresql15 postgresql15-devel

# Initialize database
sudo postgresql-setup --initdb

# Enable and start service
sudo systemctl enable postgresql
sudo systemctl start postgresql

# Verify
sudo systemctl status postgresql
sudo -u postgres psql -c "SELECT version();"
```

#### 2.5 Install Redis (Optional - for caching)

```bash
# Install Redis
sudo dnf install -y redis

# Enable and start service
sudo systemctl enable redis
sudo systemctl start redis

# Verify
redis-cli ping  # Should return PONG
```

---

## SSH Key Configuration

### 3. SSH Key Setup for NRM → Dev Communication

This is **critical** for integration scripts to work.

#### 3.1 Generate SSH Key on NRM Server

```bash
# On NRM server (172.16.129.133)
ssh-keygen -t ed25519 -f ~/.ssh/nrm_to_athena_ed25519 -C "NRM to Athena Dev" -N ""

# Set proper permissions
chmod 600 ~/.ssh/nrm_to_athena_ed25519
chmod 644 ~/.ssh/nrm_to_athena_ed25519.pub

# View public key (you'll need this)
cat ~/.ssh/nrm_to_athena_ed25519.pub
```

#### 3.2 Copy Public Key to Dev Server

```bash
# Method 1: Using ssh-copy-id (if you have password access)
ssh-copy-id -i ~/.ssh/nrm_to_athena_ed25519.pub athena-sync@172.16.132.198

# Method 2: Manual copy
# Copy the public key content, then on Dev server:
ssh root@172.16.132.198

# Switch to athena-sync user
sudo su - athena-sync

# Create .ssh directory
mkdir -p ~/.ssh
chmod 700 ~/.ssh

# Add public key
nano ~/.ssh/authorized_keys
# Paste the public key content

# Set permissions
chmod 600 ~/.ssh/authorized_keys

# Exit back to root
exit
```

#### 3.3 Test SSH Key Authentication

```bash
# From NRM server, test connection
ssh -i ~/.ssh/nrm_to_athena_ed25519 athena-sync@172.16.132.198 "echo 'SSH working'"

# Should print: SSH working

# Test sudo access
ssh -i ~/.ssh/nrm_to_athena_ed25519 athena-sync@172.16.132.198 "sudo systemctl is-active wazuh-manager"

# Should print: active
```

**If this test fails, deployment will not work.**

---

## Wazuh Mute Integration

### 4. Setup Wazuh Mute Rules Integration

This allows Athena to dynamically manage alert suppression rules on Wazuh Manager.

#### 4.1 Understanding the Integration

The Wazuh mute integration creates these files on Dev server:
- `/var/ossec/etc/lists/athena_mute_ips` - CDB list for IP whitelisting
- `/var/ossec/etc/rules/athena_mute_rules.xml` - Auto-generated suppression rules
- `/var/ossec/etc/rules/local_rules.xml` - Local rules with CDB whitelist

#### 4.2 Run Integration Setup Script

```bash
# On NRM server (172.16.129.133)
cd /path/to/athena/project

# Run Wazuh setup script
python3 scripts/integration/setup_wazuh_mute_integration.py
```

**Expected Output:**
```
================================================================================
Wazuh Mute Rules Integration - Setup
================================================================================
Target: 172.16.132.198
User: athena-sync
================================================================================

[1/8] Testing SSH connection...
✅ SSH connection successful

[2/8] Verifying Wazuh Manager status...
✅ Wazuh Manager is running

[3/8] Creating athena_mute_ips CDB file...
   -rw-r----- 1 wazuh wazuh 234 Jan 14 10:30 /var/ossec/etc/lists/athena_mute_ips
✅ CDB file created

[4/8] Creating athena_mute_rules.xml file...
   -rw-r----- 1 wazuh wazuh 567 Jan 14 10:30 /var/ossec/etc/rules/athena_mute_rules.xml
✅ Rules file created

[5/8] Verifying ossec.conf configuration...
   ✓ ossec.conf has <rule_dir>etc/rules</rule_dir>
   ✓ athena_mute_rules.xml will be auto-loaded from etc/rules
✅ ossec.conf verified

[6/8] Adding CDB whitelist rule to local_rules.xml...
   CDB whitelist rule added successfully
✅ CDB whitelist rule added

[7/8] Compiling CDB lists...
   Output: Lists updated
✅ CDB lists compiled

[8/8] Restarting Wazuh Manager...
   Waiting for Wazuh Manager to start...
   Status: active
✅ Wazuh Manager restarted

================================================================================
✅ Setup completed successfully!
================================================================================
```

#### 4.3 Manual Verification on Dev Server

```bash
# SSH to Dev server
ssh -i ~/.ssh/nrm_to_athena_ed25519 athena-sync@172.16.132.198

# Verify files were created
sudo ls -lh /var/ossec/etc/lists/athena_mute_ips
sudo ls -lh /var/ossec/etc/rules/athena_mute_rules.xml
sudo ls -lh /var/ossec/etc/rules/local_rules.xml

# Check file ownership (MUST be wazuh:wazuh)
# Correct: -rw-r----- 1 wazuh wazuh

# View athena_mute_rules.xml content
sudo cat /var/ossec/etc/rules/athena_mute_rules.xml
```

**Expected Content:**
```xml
<!-- ============================================================================ -->
<!-- Athena Security Platform - Auto-Generated Mute Rules                        -->
<!-- DO NOT EDIT MANUALLY - Changes will be overwritten                          -->
<!-- ============================================================================ -->

<group name="athena_suppressed,local,">
  <!-- Placeholder rule - do not delete (Wazuh requires at least one rule per group) -->
  <rule id="100201" level="0">
    <description>Athena mute rules placeholder - this rule does nothing</description>
  </rule>

  <!-- Auto-generated rules will appear here -->
</group>
```

#### 4.4 Common Issues and Fixes

**Issue 1: Wrong File Ownership**
```bash
# Error: chown: invalid group: 'root:ossec'
# Fix: Ubuntu 24.04 uses wazuh:wazuh, not root:ossec
sudo chown wazuh:wazuh /var/ossec/etc/rules/athena_mute_rules.xml
sudo chown wazuh:wazuh /var/ossec/etc/lists/athena_mute_ips
```

**Issue 2: XML Declaration Error**
```bash
# Error: XMLERR: Bad attribute closing for 'encoding'='UTF-8'
# Cause: Wazuh doesn't support <?xml version="1.0" encoding="UTF-8"?> declarations
# Fix: Files must start directly with <group> or comments (script already fixed)
```

**Issue 3: Empty Group Error**
```bash
# Error: Group 'group' without any rule
# Cause: Wazuh requires at least one rule per group
# Fix: Placeholder rule added (ID 100201) - do not delete it
```

**Issue 4: Nested Groups**
```bash
# Error: Invalid configuration. 'group' is not a valid element
# Cause: Wazuh doesn't support <group> inside another <group>
# Fix: Ensure each group is properly closed before opening a new one
```

**Issue 5: Wazuh Won't Restart**
```bash
# Check Wazuh logs for syntax errors
sudo tail -f /var/ossec/logs/ossec.log

# Test configuration manually
sudo /var/ossec/bin/wazuh-control check

# If errors, fix XML files and retry
sudo systemctl restart wazuh-manager
```

---

## Suricata Mute Integration

### 5. Setup Suricata Mute Rules Integration

**Status:** Pending - Suricata not yet installed on Dev server.

#### 5.1 Install Suricata First

```bash
# On Dev server (172.16.132.198)
ssh -i ~/.ssh/nrm_to_athena_ed25519 athena-sync@172.16.132.198

sudo apt update
sudo apt install -y suricata

sudo systemctl enable suricata
sudo systemctl start suricata
sudo systemctl status suricata
```

#### 5.2 Run Suricata Integration Setup

```bash
# On NRM server (172.16.129.133)
cd /path/to/athena/project

# Run Suricata setup script
python3 scripts/integration/setup_suricata_mute_integration.py
```

This will create:
- `/etc/suricata/athena-mute-rules.conf` - Auto-managed threshold rules
- Update `/etc/suricata/threshold.config` - Include directive

#### 5.3 Verification

```bash
# On Dev server
sudo cat /etc/suricata/athena-mute-rules.conf
sudo grep athena-mute-rules /etc/suricata/threshold.config

# Test Suricata reload
sudo suricatasc -c reload-rules
```

---

## Application Deployment

### 6. Deploy Athena Application on NRM Server

#### 6.1 Clone Repository

```bash
# On NRM server
sudo mkdir -p /opt/athena
sudo chown $USER:$USER /opt/athena

cd /opt/athena
git clone <repository-url> app
cd app
```

#### 6.2 Configure Environment Variables

```bash
# Copy example env file
cp .env.example .env

# Edit .env with actual values
nano .env
```

**Critical Configuration:**
```bash
# Elasticsearch (Dev Server)
ELASTICSEARCH_HOST=https://172.16.132.198:9200
ELASTICSEARCH_USER=admin
ELASTICSEARCH_PASSWORD=<GET_FROM_DEV_SERVER>
WAZUH_INDEX=wazuh-alerts-*

# Wazuh
WAZUH_HOST=172.16.132.198
WAZUH_PORT=9200
WAZUH_USERNAME=admin
WAZUH_PASSWORD=<SAME_AS_ES_PASSWORD>

# Wazuh Manager API (if needed)
WAZUH_MANAGER_URL=https://172.16.132.198:55000
WAZUH_API_USER=wazuh
WAZUH_API_PASSWORD=<GET_FROM_DEV_SERVER>

# Wazuh SSH (for integration scripts)
WAZUH_MANAGER_HOST=172.16.132.198
WAZUH_SSH_USER=athena-sync
WAZUH_SSH_KEY_PATH=/root/.ssh/nrm_to_athena_ed25519

# PostgreSQL (Local on NRM)
POSTGRES_HOST=localhost
POSTGRES_PORT=5432
POSTGRES_DB=athena_db
POSTGRES_USER=athena_user
POSTGRES_PASSWORD=<GENERATE_STRONG_PASSWORD>

# Flask
SECRET_KEY=<GENERATE_WITH: python3 -c "import secrets; print(secrets.token_hex(32))">
DEBUG=False
FLASK_ENV=production
FLASK_HOST=0.0.0.0
FLASK_PORT=5001

# Keycloak
KEYCLOAK_URL=http://localhost:8080
KEYCLOAK_REALM=athena-security
KEYCLOAK_CLIENT_ID=athena-backend-flask
KEYCLOAK_ADMIN_PASSWORD=<GENERATE_STRONG_PASSWORD>
```

#### 6.3 Get Passwords from Dev Server

```bash
# SSH to Dev server
ssh root@172.16.132.198

# Find Elasticsearch password
sudo grep "password" /etc/wazuh-indexer/opensearch-security/internal_users.yml

# OR check Wazuh installation files
sudo cat /root/athena-passwords-*.yml | grep -i password

# Find Wazuh API password
sudo cat /var/ossec/api/configuration/api.yaml | grep password
```

#### 6.4 Initialize Database

```bash
# Create PostgreSQL database and user
sudo -u postgres psql << EOF
CREATE DATABASE athena_db;
CREATE USER athena_user WITH ENCRYPTED PASSWORD '<YOUR_POSTGRES_PASSWORD>';
GRANT ALL PRIVILEGES ON DATABASE athena_db TO athena_user;
\q
EOF

# Run database migrations
cd /opt/athena/app
python3 backend/response/src/init_db.py
```

#### 6.5 Install Dependencies

```bash
# Backend dependencies
cd /opt/athena/app/backend/response
pip3 install -r requirements.txt

# Frontend dependencies
cd /opt/athena/app/frontend
npm install
```

#### 6.6 Build Frontend

```bash
cd /opt/athena/app/frontend
npm run build
```

#### 6.7 Start Services

```bash
# Start backend (Flask)
cd /opt/athena/app/backend/response
python3 src/app.py &

# OR use systemd service (recommended)
# Create systemd service file for production
```

#### 6.8 Access Application

```
Frontend: http://172.16.129.133:3000
Backend API: http://172.16.129.133:5001/api
```

---

## Troubleshooting Guide

### 7. Common Issues and Solutions

#### SSH Connection Issues

**Problem:** Cannot SSH from NRM to Dev server
```bash
# Debug SSH connection
ssh -vvv -i ~/.ssh/nrm_to_athena_ed25519 athena-sync@172.16.132.198

# Check key permissions
ls -la ~/.ssh/nrm_to_athena_ed25519  # Should be 600 or 400

# Fix permissions
chmod 600 ~/.ssh/nrm_to_athena_ed25519

# Check authorized_keys on Dev server
ssh root@172.16.132.198
sudo cat /home/athena-sync/.ssh/authorized_keys
ls -la /home/athena-sync/.ssh/  # authorized_keys should be 600
```

#### Wazuh Manager Won't Start

```bash
# Check configuration syntax
sudo /var/ossec/bin/wazuh-control check

# Check logs
sudo tail -f /var/ossec/logs/ossec.log

# Common errors:
# - XML syntax errors in rules files
# - Missing placeholder rule in group
# - Nested groups
# - XML declaration in rules files
```

#### Elasticsearch Connection Failed

```bash
# Test connectivity from NRM
curl -k -u admin:PASSWORD https://172.16.132.198:9200

# Check security group allows outbound 9200 from NRM
# Check firewall on Dev server
sudo ufw status

# If UFW is enabled, allow port 9200
sudo ufw allow from 172.16.129.133 to any port 9200
```

#### Integration Script Fails

```bash
# Check Python environment
python3 --version
pip3 list | grep paramiko

# Install missing dependencies
pip3 install paramiko

# Test SSH connection first
ssh -i ~/.ssh/nrm_to_athena_ed25519 athena-sync@172.16.132.198 "sudo systemctl is-active wazuh-manager"

# If sudo asks for password, fix sudoers file
```

#### File Permission Errors

```bash
# All Wazuh files must be wazuh:wazuh (NOT root:ossec)
sudo chown wazuh:wazuh /var/ossec/etc/rules/*.xml
sudo chown wazuh:wazuh /var/ossec/etc/lists/*
sudo chmod 640 /var/ossec/etc/rules/*.xml
sudo chmod 640 /var/ossec/etc/lists/*
```

---

## Verification & Testing

### 8. Post-Deployment Verification

#### 8.1 Run Prerequisite Verification Script

```bash
# On NRM server
cd /opt/athena/app
bash deployment/scripts/verify_nrm_prerequisites.sh
```

This checks:
- ✅ SSH connectivity
- ✅ Elasticsearch accessibility
- ✅ Wazuh indices exist
- ✅ Network connectivity
- ✅ Security groups configured

#### 8.2 Test Wazuh Integration

```bash
# Create a test mute rule from Athena UI
# OR use API:
curl -X POST http://localhost:5001/api/mute-rules \
  -H "Content-Type: application/json" \
  -d '{
    "type": "ip",
    "value": "192.168.1.100",
    "reason": "Test mute rule"
  }'

# Verify rule was created on Dev server
ssh -i ~/.ssh/nrm_to_athena_ed25519 athena-sync@172.16.132.198 \
  "sudo cat /var/ossec/etc/lists/athena_mute_ips"

# Should contain: 192.168.1.100
```

#### 8.3 Test Alert Suppression

```bash
# Generate a test alert from the whitelisted IP
# Check Elasticsearch to verify alert was suppressed
curl -k -u admin:PASSWORD https://172.16.132.198:9200/wazuh-alerts-*/_search?q=rule.id:100200
```

#### 8.4 Check Service Status

```bash
# On Dev server
sudo systemctl status wazuh-manager
sudo systemctl status wazuh-indexer

# On NRM server
systemctl status postgresql
ps aux | grep python  # Flask backend
ps aux | grep node    # Frontend (if running in dev mode)
```

---

## Appendix

### A. File Locations Reference

#### Dev Server (172.16.132.198)

| Component | Path | Ownership |
|-----------|------|-----------|
| Wazuh Config | `/var/ossec/etc/ossec.conf` | root:wazuh |
| Wazuh Rules | `/var/ossec/etc/rules/` | wazuh:wazuh |
| Athena Mute Rules | `/var/ossec/etc/rules/athena_mute_rules.xml` | wazuh:wazuh |
| Local Rules | `/var/ossec/etc/rules/local_rules.xml` | wazuh:wazuh |
| CDB Lists | `/var/ossec/etc/lists/` | wazuh:wazuh |
| Athena Mute IPs | `/var/ossec/etc/lists/athena_mute_ips` | wazuh:wazuh |
| Wazuh Logs | `/var/ossec/logs/ossec.log` | wazuh:wazuh |
| Suricata Config | `/etc/suricata/suricata.yaml` | root:root |
| Suricata Threshold | `/etc/suricata/threshold.config` | root:root |
| Athena Suricata Mute | `/etc/suricata/athena-mute-rules.conf` | root:root |

#### NRM Server (172.16.129.133)

| Component | Path | Purpose |
|-----------|------|---------|
| Application Root | `/opt/athena/app/` | Athena codebase |
| Backend | `/opt/athena/app/backend/response/` | Flask API |
| Frontend | `/opt/athena/app/frontend/` | React UI |
| Integration Scripts | `/opt/athena/app/scripts/integration/` | Setup scripts |
| Deployment Scripts | `/opt/athena/app/deployment/scripts/` | Deployment automation |
| Environment Config | `/opt/athena/app/.env` | Configuration |
| SSH Key | `/root/.ssh/nrm_to_athena_ed25519` | NRM→Dev authentication |
| Application Logs | `/var/log/athena/` | Application logs |

### B. Important Commands Reference

#### Wazuh Management
```bash
# Check Wazuh status
sudo systemctl status wazuh-manager

# Restart Wazuh
sudo systemctl restart wazuh-manager

# Check configuration
sudo /var/ossec/bin/wazuh-control check

# View logs
sudo tail -f /var/ossec/logs/ossec.log

# Compile CDB lists
sudo /var/ossec/bin/ossec-makelists
```

#### Elasticsearch Queries
```bash
# Test connection
curl -k -u admin:PASSWORD https://172.16.132.198:9200

# List indices
curl -k -u admin:PASSWORD https://172.16.132.198:9200/_cat/indices

# Search Wazuh alerts
curl -k -u admin:PASSWORD https://172.16.132.198:9200/wazuh-alerts-*/_search
```

#### SSH Management
```bash
# Test SSH from NRM to Dev
ssh -i ~/.ssh/nrm_to_athena_ed25519 athena-sync@172.16.132.198 "hostname"

# Test sudo access
ssh -i ~/.ssh/nrm_to_athena_ed25519 athena-sync@172.16.132.198 "sudo -n true && echo OK"
```

### C. Security Checklist

- [ ] SSH keys properly secured (600 permissions)
- [ ] Passwordless sudo only for athena-sync user
- [ ] .env file not committed to git
- [ ] Strong passwords for all services
- [ ] Security groups restrict access to known IPs
- [ ] Elasticsearch uses authentication
- [ ] DEBUG=False in production
- [ ] Regular backups configured
- [ ] Monitoring and logging enabled

### D. Backup and Recovery

#### Backup Important Files
```bash
# On Dev server - backup Wazuh rules
sudo tar czf /tmp/wazuh-rules-backup-$(date +%Y%m%d).tar.gz \
  /var/ossec/etc/rules/athena_mute_rules.xml \
  /var/ossec/etc/rules/local_rules.xml \
  /var/ossec/etc/lists/athena_mute_ips

# On NRM server - backup database
sudo -u postgres pg_dump athena_db > /tmp/athena-db-backup-$(date +%Y%m%d).sql

# Backup .env file
cp /opt/athena/app/.env /opt/athena/app/.env.backup-$(date +%Y%m%d)
```

---

## Contact and Support

For issues or questions:
1. Check this deployment guide
2. Review troubleshooting section
3. Check logs: `/var/ossec/logs/ossec.log` (Wazuh)
4. Check application logs: `/var/log/athena/` (Athena)

---

**End of Deployment Guide**
