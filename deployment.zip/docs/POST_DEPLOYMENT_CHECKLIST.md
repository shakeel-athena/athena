# Athena Security Platform - Post-Deployment Checklist

Use this checklist to verify your deployment is complete and working correctly.

---

## Service Status Checks

### Backend Service
```bash
# Check if running
sudo systemctl status athena-backend

# Test health endpoint
curl http://localhost:5000/health

# Expected: {"status": "healthy"}
```
- [ ] Service is running
- [ ] Health endpoint returns healthy

### Keycloak
```bash
# Check container status
docker ps | grep keycloak

# Test realm endpoint
curl http://localhost:8080/realms/athena-security

# Expected: JSON with realm info
```
- [ ] Keycloak container is running
- [ ] Realm endpoint returns data

### Nginx
```bash
# Check status
sudo systemctl status nginx

# Test frontend
curl -I http://localhost:8088
```
- [ ] Nginx is running
- [ ] Returns 200 OK

### PostgreSQL
```bash
# Test connection
psql -U athena_user -h localhost -d athena_db -c "SELECT COUNT(*) FROM users;"
```
- [ ] Database connection works
- [ ] Tables exist

### Redis
```bash
# Test connection
redis-cli ping

# Expected: PONG
```
- [ ] Redis is running

---

## Keycloak Client Configuration

### Frontend Client (athena-frontend)
Go to Keycloak Admin → Clients → athena-frontend

| Setting | Value | Status |
|---------|-------|--------|
| Root URL | `http://YOUR_SERVER:PORT` | [ ] |
| Home URL | `http://YOUR_SERVER:PORT` | [ ] |
| Valid redirect URIs | `http://YOUR_SERVER:PORT/*` | [ ] |
| Valid post logout redirect URIs | `http://YOUR_SERVER:PORT/*` | [ ] |
| Web origins | `http://YOUR_SERVER:PORT` | [ ] |

### Backend Client (athena-backend)
Go to Keycloak Admin → Clients → athena-backend

| Setting | Value | Status |
|---------|-------|--------|
| Client authentication | ON | [ ] |
| Valid redirect URIs | `http://YOUR_SERVER/*` | [ ] |
| Client secret copied to .env | Yes | [ ] |

---

## Frontend URL Configuration

### Check Keycloak URL in Build
```bash
grep -r "localhost:8080" /opt/deployment/frontend/build/

# Should return nothing if properly updated
```
- [ ] No localhost:8080 references in build

### Verify Frontend .env
```bash
cat /opt/deployment/frontend/.env
```
Should contain:
```
REACT_APP_API_BASE_URL=http://YOUR_SERVER:5000
REACT_APP_API_URL=http://YOUR_SERVER:5000/api
REACT_APP_KEYCLOAK_URL=http://YOUR_SERVER:8080
```
- [ ] All URLs point to production server

---

## Network Access

### Security Group Rules
Verify your AWS Security Group allows:

| Port | Source | Purpose | Status |
|------|--------|---------|--------|
| 22 | Your IP | SSH | [ ] |
| 80 | VPN CIDR | HTTP | [ ] |
| 5000 | VPN CIDR | Backend API | [ ] |
| 8080 | VPN CIDR | Keycloak | [ ] |
| 8088 | VPN CIDR | Nginx (if custom port) | [ ] |

### Test External Access
From your local machine (on VPN):
```bash
# Frontend
curl -I http://SERVER_IP:8088

# Backend
curl http://SERVER_IP:5000/health

# Keycloak
curl http://SERVER_IP:8080/realms/athena-security
```
- [ ] Frontend accessible
- [ ] Backend accessible
- [ ] Keycloak accessible

---

## Application Functionality

### Login Test
1. Open browser: `http://YOUR_SERVER:8088`
2. Should redirect to Keycloak login
3. Login with credentials
4. Should redirect back to dashboard

- [ ] Login page appears
- [ ] Can login successfully
- [ ] Dashboard loads after login

### API Connectivity
After login, verify:
- [ ] Dashboard shows data
- [ ] Alerts page loads (may be empty if no data)
- [ ] Navigation works between pages

### Backend Connectivity
```bash
# Test comprehensive health
curl http://localhost:5000/api/health/comprehensive
```
- [ ] Database connected
- [ ] Elasticsearch connected (if configured)
- [ ] Redis connected (if configured)

---

## Environment Configuration

### Backend .env
```bash
cat /opt/deployment/backend/response/.env | grep -v "^#" | grep -v "^$"
```

Critical settings to verify:
- [ ] `POSTGRES_PASSWORD` is set (not CHANGE_ME)
- [ ] `KEYCLOAK_URL` points to server IP (not localhost)
- [ ] `KEYCLOAK_CLIENT_SECRET` is set
- [ ] `ELASTICSEARCH_HOST` is correct
- [ ] `ELASTICSEARCH_PASSWORD` is set
- [ ] `DEBUG=False` for production

---

## Logs and Monitoring

### Check for Errors
```bash
# Backend errors
sudo journalctl -u athena-backend --since "1 hour ago" | grep -i error

# Nginx errors
sudo tail -50 /var/log/nginx/error.log

# Keycloak errors
docker logs athena-keycloak 2>&1 | grep -i error | tail -20
```
- [ ] No critical errors in backend logs
- [ ] No errors in nginx logs
- [ ] No errors in keycloak logs

---

## Security Checklist

- [ ] All default passwords changed
- [ ] `.env` files have production values
- [ ] `DEBUG=False` in backend .env
- [ ] Keycloak admin password changed from default
- [ ] No secrets in git repository

---

## Backup Configuration

- [ ] Database backup script tested
- [ ] Backup schedule configured (optional)
- [ ] Backup files stored securely

```bash
# Test backup
pg_dump -U athena_user -h localhost athena_db > /tmp/test_backup.sql
ls -la /tmp/test_backup.sql
rm /tmp/test_backup.sql
```

---

## Quick Troubleshooting

### "Invalid redirect_uri" Error
→ Update Keycloak client redirect URIs (see Keycloak section above)

### "Connection refused" to Backend
→ Check backend service is running: `sudo systemctl status athena-backend`

### "Connection refused" to Keycloak
→ Check container: `docker ps | grep keycloak`
→ Check logs: `docker logs athena-keycloak`

### "Connection timeout" from Browser
→ Check Security Group allows traffic from your IP/VPN CIDR

### Frontend Shows localhost URLs
→ Run sed replacement on build files (see PRODUCTION_QUICK_START.md)

---

## Final Sign-Off

| Component | Verified By | Date |
|-----------|-------------|------|
| Backend API | | |
| Frontend | | |
| Keycloak Auth | | |
| Database | | |
| Network Access | | |
| Security Settings | | |

**Deployment Status:** [ ] Complete / [ ] Issues Pending

**Notes:**
_________________________________
_________________________________
_________________________________
