# Athena Security Platform - Hosting Requirements

## Overview

This document outlines all infrastructure resources required to host the Athena Security Platform on AWS.

---

## 1. AWS EC2 Instance (Main Application Server)

### Minimum Requirements (Development/Testing)
- **Instance Type:** `t3.medium`
- **vCPUs:** 2
- **RAM:** 4 GB
- **Storage:** 30 GB gp3 SSD
- **Network:** Enhanced networking enabled
- **Cost:** ~$30/month (us-east-2)

### Recommended (Production)
- **Instance Type:** `t3.large` or `t3.xlarge`
- **vCPUs:** 4-8
- **RAM:** 8-16 GB
- **Storage:** 50-100 GB gp3 SSD
- **Network:** Enhanced networking enabled
- **Cost:** ~$60-120/month (us-east-2)

### High-Traffic Production
- **Instance Type:** `c6i.2xlarge` (compute-optimized)
- **vCPUs:** 8
- **RAM:** 16 GB
- **Storage:** 100 GB gp3 SSD
- **Network:** 10 Gbps enhanced networking
- **Cost:** ~$250/month (us-east-2)

### What Runs on This Instance:
```
┌─────────────────────────────────────┐
│     EC2 Instance (Amazon Linux)     │
├─────────────────────────────────────┤
│ ✓ Nginx (Frontend reverse proxy)   │
│ ✓ React Frontend (built static)    │
│ ✓ Flask Backend API (Gunicorn)     │
│ ✓ PostgreSQL Database              │
│ ✓ Redis Cache                      │
│ ✓ Keycloak (Docker container)      │
└─────────────────────────────────────┘
```

---

## 2. Storage Requirements

### EC2 Root Volume
- **Type:** gp3 (General Purpose SSD)
- **Size:** 50 GB minimum, 100 GB recommended
- **IOPS:** 3,000 baseline (gp3 default)
- **Throughput:** 125 MB/s baseline
- **Cost:** ~$4-8/month

### Breakdown:
- OS & System: ~8 GB
- Application Code: ~2 GB
- PostgreSQL Database: 5-20 GB (depends on usage)
- Docker Images (Keycloak): ~2 GB
- Logs: 5-10 GB (with rotation)
- Dependencies (Python/Node): ~3 GB
- Working Space: 10-15 GB

### Database Backups (Recommended)
- **Option 1:** Store on S3
  - Cost: $0.023/GB/month
  - Example: 10 GB backups = $0.23/month

- **Option 2:** EBS Snapshots
  - Cost: $0.05/GB/month
  - Example: 50 GB snapshot = $2.50/month

---

## 3. Network & Security

### Security Group Rules

**Inbound Rules Required:**

| Type | Protocol | Port | Source | Purpose |
|------|----------|------|--------|---------|
| SSH | TCP | 22 | Your IP/CIDR | Admin access |
| HTTP | TCP | 80 | Internal VPN CIDR | Web interface |
| Custom TCP | TCP | 8080 | Internal VPN CIDR | Keycloak |

**Optional (if using HTTPS):**

| Type | Protocol | Port | Source | Purpose |
|------|----------|------|--------|---------|
| HTTPS | TCP | 443 | Internal VPN CIDR | Secure web interface |

**Outbound Rules Required:**

| Type | Protocol | Port | Destination | Purpose |
|------|----------|------|-------------|---------|
| HTTPS | TCP | 443 | 0.0.0.0/0 | Package downloads, AWS APIs |
| HTTP | TCP | 80 | 0.0.0.0/0 | Package downloads |
| Custom TCP | TCP | 9200 | Elasticsearch IP | Wazuh Indexer |
| Custom TCP | TCP | 55000 | Wazuh Manager IP | Wazuh API |
| SSH | TCP | 22 | Wazuh Manager IP | Active Response sync |

**Data Transfer Costs:**
- Data IN: Free
- Data OUT to internet: $0.09/GB (first 10 TB)
- Data OUT to same region (VPC): Free
- **Estimated:** $5-20/month (depends on usage)

---

## 4. External Services Required

### A. Elasticsearch / Wazuh Indexer (Alert Storage)

**You Already Have:** 172.16.1.93

**Requirements:**
- Port 9200 accessible from EC2
- Admin credentials
- Indices: `wazuh-alerts-*`, `suricata-*`

**If Self-Hosting:**
- Instance: t3.large minimum (4 vCPU, 8 GB RAM)
- Storage: 100-500 GB (depends on alert volume)
- Cost: ~$60-150/month

**AWS Elasticsearch Alternative:**
- t3.small.search: ~$25/month (10 GB storage)
- t3.medium.search: ~$70/month (100 GB storage)

### B. Wazuh Manager (Security Monitoring)

**You Already Have:** 172.16.1.93

**Requirements:**
- Port 55000 (Wazuh API) accessible from EC2
- SSH access for Active Response sync
- API credentials

**If Self-Hosting:**
- Instance: t3.medium minimum (2 vCPU, 4 GB RAM)
- Storage: 50 GB
- Cost: ~$40/month

---

## 5. Optional AWS Services

### A. AWS WAF (Web Application Firewall)

**Use Case:** IP blocking, geo-restrictions, rate limiting

**Resources:**
- 1x Web ACL
- 1x IP Set (for blocked IPs)
- Rules for geo-restrictions, rate limiting

**Pricing:**
- Web ACL: $5/month
- Rules: $1/rule/month
- Requests: $0.60 per million requests
- **Estimated:** $10-30/month

### B. AWS Network Firewall

**Use Case:** Network-level traffic filtering

**Resources:**
- 1x Firewall
- 1x Firewall Policy
- 1+ Rule Groups

**Pricing:**
- Firewall Endpoint: $0.395/hour = ~$285/month
- Data Processing: $0.065/GB
- **Estimated:** $300-500/month
- **Note:** Expensive - only use if needed

### C. Elastic IP (Recommended)

**Use Case:** Static IP for your EC2 instance

**Pricing:**
- Free while attached to running instance
- $0.005/hour if not attached = ~$3.60/month
- **Cost:** Free (when in use)

### D. Application Load Balancer (Optional)

**Use Case:** Multiple instances, SSL termination, auto-scaling

**Pricing:**
- ALB: $16.20/month
- LCU (Load Balancer Capacity Units): $5.76/month
- **Estimated:** $25-40/month

---

## 6. Database Options Comparison

### Option 1: PostgreSQL on EC2 (Current Setup)
**Pros:**
- ✅ Included in EC2 instance cost
- ✅ Full control
- ✅ Simple deployment

**Cons:**
- ❌ Manual backups required
- ❌ No automatic failover
- ❌ Limited to instance resources

**Cost:** Included in EC2

### Option 2: AWS RDS PostgreSQL
**Pros:**
- ✅ Automated backups
- ✅ Automatic failover (Multi-AZ)
- ✅ Managed updates
- ✅ Read replicas

**Cons:**
- ❌ Additional cost
- ❌ More complex networking

**Pricing:**
- db.t3.micro: ~$15/month (1 vCPU, 1 GB)
- db.t3.small: ~$30/month (2 vCPU, 2 GB)
- db.t3.medium: ~$60/month (2 vCPU, 4 GB)

**Recommendation:** Start with PostgreSQL on EC2, migrate to RDS if scaling up

---

## 7. Total Cost Estimates

### Minimal Setup (Development/Testing)
```
EC2 t3.medium:              $30/month
EBS Storage (50 GB):         $4/month
Data Transfer:               $5/month
S3 Backups:                  $1/month
Elastic IP:                 Free
─────────────────────────────────────
TOTAL:                     ~$40/month
```

### Recommended Production Setup
```
EC2 t3.large:               $60/month
EBS Storage (100 GB):        $8/month
Data Transfer:              $15/month
S3 Backups:                  $2/month
Elastic IP:                 Free
AWS WAF (optional):         $20/month
Route 53 (domain):           $1/month
─────────────────────────────────────
TOTAL:                    ~$106/month
```

### High-Availability Production Setup
```
EC2 c6i.2xlarge:           $250/month
EBS Storage (200 GB):       $16/month
RDS PostgreSQL (t3.medium): $60/month
Data Transfer:              $30/month
S3 Backups:                  $5/month
Elastic IP:                 Free
AWS WAF:                    $30/month
CloudWatch:                 $10/month
Route 53:                    $1/month
Application Load Balancer:  $30/month
─────────────────────────────────────
TOTAL:                    ~$432/month
```

**Note:** These are estimates for us-east-2. Other regions may vary.

---

## 8. Scaling Recommendations

### Small Deployment (1-10 users, <10k alerts/day)
- **EC2:** t3.medium
- **RAM:** 4 GB
- **Storage:** 50 GB
- **Database:** PostgreSQL on EC2
- **Cost:** ~$40-60/month

### Medium Deployment (10-50 users, 10k-100k alerts/day)
- **EC2:** t3.large or t3.xlarge
- **RAM:** 8-16 GB
- **Storage:** 100 GB
- **Database:** PostgreSQL on EC2 or RDS t3.small
- **Redis:** Elasticache (optional for multi-instance)
- **Cost:** ~$100-150/month

### Large Deployment (50+ users, 100k+ alerts/day)
- **EC2:** c6i.2xlarge (or multiple t3.large with ALB)
- **RAM:** 16+ GB
- **Storage:** 200+ GB
- **Database:** RDS PostgreSQL t3.medium or larger
- **Redis:** Elasticache (required for multi-instance)
- **Elasticsearch:** Dedicated cluster
- **Load Balancer:** Application Load Balancer
- **Cost:** ~$400-800/month

---

## 9. Vertical vs Horizontal Scaling

### Vertical Scaling (Scale Up)
**When:** Increasing demand, single instance

**Steps:**
1. Stop EC2 instance
2. Change instance type (t3.medium → t3.large)
3. Start instance
4. **Downtime:** 5-10 minutes

**Limits:** Max instance size constraints

### Horizontal Scaling (Scale Out)
**When:** High availability, load distribution

**Requirements:**
- Application Load Balancer
- Multiple EC2 instances
- RDS PostgreSQL (shared database)
- Elasticache Redis (shared cache)
- Auto Scaling Group

**Cost Impact:** +100-200% (multiple instances + ALB + RDS)

---

## 10. Network Architecture Options

### Option A: Single VPC, Public Subnet (Simplest)
```
Internet
    ↓
EC2 (Public IP) ← Security Group filters traffic
    ↓
External Elasticsearch (172.16.1.93)
```

**Pros:** Simple, low cost
**Cons:** Direct internet exposure (use security groups carefully)

### Option B: VPC with Public/Private Subnets (Recommended)
```
Internet
    ↓
Application Load Balancer (Public Subnet)
    ↓
EC2 (Private Subnet) + NAT Gateway for outbound
    ↓
External Elasticsearch (172.16.1.93)
```

**Pros:** Better security, EC2 not directly exposed
**Cons:** +$32/month for NAT Gateway

### Option C: Fully Private with VPN (Most Secure)
```
VPN Gateway
    ↓
EC2 (Private Subnet)
    ↓
External Elasticsearch (172.16.1.93)
```

**Pros:** Maximum security, no internet exposure
**Cons:** Requires VPN setup, VPN Gateway costs ~$36/month

---

## 11. Disaster Recovery & Backups

### Backup Strategy

**Database Backups:**
- Daily automated backups via cron
- Retention: 30 days
- Storage: S3 (versioned bucket)
- Cost: ~$1-5/month

**Full Instance Backups:**
- Weekly EBS snapshots
- Retention: 4 weeks
- Cost: ~$10-20/month

**Configuration Backups:**
- .env file (encrypted in S3 or Secrets Manager)
- Keycloak export
- Nginx configs

### Recovery Time Objectives

**Database Restore:**
- **RTO:** 15-30 minutes
- **RPO:** 24 hours (daily backups)

**Full Instance Restore:**
- **RTO:** 1-2 hours (from EBS snapshot)
- **RPO:** 7 days (weekly snapshots)

**Complete Rebuild:**
- **RTO:** 2-4 hours (using deployment scripts)
- **RPO:** Depends on backup frequency

---

## 12. Monitoring & Logging Resources

### CloudWatch (AWS Native)
**Metrics:**
- EC2 CPU, memory, disk, network
- RDS (if used)
- Custom application metrics

**Logs:**
- Backend application logs
- Nginx access/error logs
- System logs

**Pricing:**
- First 10 custom metrics: Free
- Additional metrics: $0.30/metric/month
- Log ingestion: $0.50/GB
- Log storage: $0.03/GB/month
- **Estimated:** $5-20/month

### CloudWatch Alarms
- CPU > 80%: Send SNS notification
- Disk > 85%: Send SNS notification
- Application errors: Send SNS notification

**Cost:** $0.10/alarm/month (up to 10 alarms free tier)

---

## 13. SSL/TLS Certificates

### Option 1: Let's Encrypt (Free)
- **Cost:** Free
- **Renewal:** Automatic with certbot
- **Use:** HTTP/HTTPS on EC2

### Option 2: AWS Certificate Manager (ACM)
- **Cost:** Free
- **Requirements:** Must use with ALB or CloudFront
- **Auto-renewal:** Yes

### Option 3: Commercial Certificate
- **Cost:** $50-200/year
- **Warranty:** Included
- **Use:** Any server

**Recommendation:** Let's Encrypt for EC2, ACM if using ALB

---

## 14. Domain & DNS

### Route 53 (AWS DNS)
- **Hosted Zone:** $0.50/month
- **Queries:** $0.40 per million queries
- **Example:** athena.yourcompany.com
- **Total:** ~$1-2/month

### Alternative (External Registrar)
- Cloudflare: Free DNS
- Namecheap: $0.50/month
- GoDaddy: Varies

---

## 15. Quick Decision Matrix

| Scenario | EC2 Instance | Database | Estimated Cost |
|----------|--------------|----------|----------------|
| **Demo/POC** | t3.small | PostgreSQL on EC2 | $20/month |
| **Small Team (< 10 users)** | t3.medium | PostgreSQL on EC2 | $40/month |
| **Medium Team (10-50 users)** | t3.large | PostgreSQL on EC2 | $70/month |
| **Large Team (50+ users)** | t3.xlarge | RDS t3.medium | $180/month |
| **Enterprise HA** | 2x c6i.large + ALB | RDS Multi-AZ | $600/month |

---

## 16. Resource Checklist

Before deploying, ensure you have:

### AWS Resources
- [ ] AWS Account with billing enabled
- [ ] VPC with subnet(s)
- [ ] Security Group configured
- [ ] EC2 instance launched (t3.medium or larger)
- [ ] SSH key pair created
- [ ] Elastic IP allocated (recommended)
- [ ] IAM role for EC2 (if using WAF/Firewall)

### External Services
- [ ] Elasticsearch/Wazuh Indexer accessible (172.16.1.93:9200)
- [ ] Wazuh Manager API accessible (172.16.1.93:55000)
- [ ] SSH access to Wazuh Manager
- [ ] Credentials for all services

### Optional
- [ ] Domain name registered
- [ ] Route 53 hosted zone (or external DNS)
- [ ] SSL certificate ready
- [ ] WAF Web ACL created (if using)
- [ ] Network Firewall configured (if using)

---

## Summary

**Minimum to Get Started:**
- 1x EC2 instance (t3.medium, $30/month)
- 50 GB EBS storage ($4/month)
- Access to existing Elasticsearch & Wazuh (you have this)

**Total Minimum Cost: ~$40/month**

**Recommended Production:**
- 1x EC2 instance (t3.large, $60/month)
- 100 GB EBS storage ($8/month)
- Elastic IP (free)
- AWS WAF ($20/month optional)
- Backups on S3 ($2/month)

**Total Recommended Cost: ~$90-110/month**

You already have Elasticsearch and Wazuh Manager, so you're saving $100-200/month by not needing to host those separately!
