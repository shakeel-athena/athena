# Pallas AI — Wazuh Dashboard Plugin v2

## Overview

Thin OSD (OpenSearch Dashboards) plugin that adds "Pallas AI" to the Wazuh Dashboard sidebar. Loads the standalone Pallas app (`pallas.athenasecuritygrp.com`) in an iframe.

**No AI logic in the plugin** — all functionality lives in the standalone Pallas app. This plugin is just a navigation entry + iframe wrapper.

---

## Architecture

```
Wazuh Dashboard (test.athenasecuritygrp.com)
├── OSD Plugin: pallasAiPlugin
│   ├── Registers "Pallas AI" in sidebar
│   └── On click → renders iframe
│       └── iframe src = pallas.athenasecuritygrp.com
│           └── Standalone Pallas app (React)
│               └── Connects to Pallas MCP Server
```

## Authentication Modes

| Wazuh Setup | Pallas Auth Mode | User Experience |
|-------------|-----------------|-----------------|
| Keycloak SAML SSO | `keycloak` | SSO — no login prompt (same realm) |
| Basic auth (no SSO) | `apikey` | No login — API key handles auth |

---

## Prerequisites

1. **Pallas standalone app** deployed and accessible
   - Production: `https://pallas.athenasecuritygrp.com`
   - Testing: `http://172.16.134.12:8001`

2. **Wazuh Dashboard** version 4.x (OpenSearch Dashboards 2.19.x)

3. **If using Keycloak SSO**: Update Keycloak realm Content-Security-Policy to allow iframe:
   ```
   frame-ancestors 'self' https://test.athenasecuritygrp.com https://pallas.athenasecuritygrp.com;
   ```

---

## Configuration

### Set the Pallas App URL

Before building, edit `common/index.ts` and set the URL:

```typescript
// For production (with DNS)
return 'https://pallas.athenasecuritygrp.com';

// For testing (direct IP)
return 'http://172.16.134.12:8001';
```

Or set it dynamically at runtime by adding to `opensearch_dashboards.yml`:
```yaml
pallas.app_url: "https://pallas.athenasecuritygrp.com"
```

---

## Build

```bash
# Requires OpenSearch-Dashboards source tree at the expected relative path
# Typically the plugin lives in: opensearch-dashboards/plugins/pallas-ai-plugin/

cd /path/to/opensearch-dashboards
yarn osd bootstrap

cd plugins/pallas-ai-plugin
yarn build
```

This produces a `.zip` file in `build/`.

---

## Install

```bash
# On the Wazuh Dashboard server (172.16.52.125)
cd /usr/share/wazuh-dashboard

# Install plugin
bin/opensearch-dashboards-plugin install file:///path/to/pallasAiPlugin-2.0.0.zip

# Restart dashboard
systemctl restart wazuh-dashboard
```

---

## Verify

1. Open Wazuh Dashboard → sidebar should show "Pallas AI" under "AI & Intelligence"
2. Click "Pallas AI" → iframe loads the standalone Pallas app
3. If Keycloak SSO is configured → no login prompt (SSO cookie shared)
4. If no SSO → Pallas loads directly (API key mode)
5. Chat, daily standup, all modules work within the iframe

---

## Uninstall

```bash
cd /usr/share/wazuh-dashboard
bin/opensearch-dashboards-plugin remove pallasAiPlugin
systemctl restart wazuh-dashboard
```

---

## Troubleshooting

### "Unable to load Pallas AI" error
- Check if the standalone app is running: `curl http://172.16.134.12:8001/`
- Check DNS resolves: `nslookup pallas.athenasecuritygrp.com`
- Check network connectivity from Wazuh server to Pallas server

### Keycloak login shows inside iframe
- Expected on first visit if no SSO session exists
- With SSO configured, this should be a silent redirect (no visible login)
- If always showing login: check Keycloak CSP `frame-ancestors` includes the Wazuh domain

### Blank iframe
- Check browser console for X-Frame-Options or CSP errors
- Ensure Keycloak Security Defenses → Content-Security-Policy includes the domains
- Ensure X-Frame-Options is set to `ALLOWALL` or removed

### Plugin not appearing in sidebar
- Check plugin installed: `bin/opensearch-dashboards-plugin list`
- Check OSD version matches: `opensearchDashboardsVersion` in manifest must match exactly
- Check logs: `journalctl -u wazuh-dashboard -f`

---

## File Structure

```
pallas_wazuh_plugin_v2/
├── opensearch_dashboards.json   # Plugin manifest (ID, version, deps)
├── package.json                  # NPM config
├── tsconfig.json                 # TypeScript config
├── DEPLOYMENT.md                 # This file
├── common/
│   └── index.ts                  # Shared constants (PLUGIN_ID, URL helper)
└── public/
    ├── index.ts                  # Plugin entry point
    ├── plugin.ts                 # Plugin class (registers app + sidebar item)
    ├── application.tsx           # React mount/unmount
    └── components/
        └── pallas-frame.tsx      # iframe wrapper with loading/error states
```

**Total: 8 files.** Compare to old plugin v1: 30+ files with full chat UI, WebSocket, markdown rendering, theme system. All that complexity now lives in the standalone app.
