import React from 'react';
import ReactDOM from 'react-dom';
import { AppMountParameters, CoreSetup } from '../../../src/core/public';
import { PallasFrame } from './components/pallas-frame';

/**
 * Mount the Pallas AI iframe app into the OSD application container.
 * Returns an unmount function for cleanup.
 */
export function renderApp(params: AppMountParameters, _core: CoreSetup): () => void {
  ReactDOM.render(
    <PallasFrame appBasePath={params.appBasePath} />,
    params.element
  );

  return () => {
    ReactDOM.unmountComponentAtNode(params.element);
  };
}
