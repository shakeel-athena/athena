import { CoreSetup, CoreStart, Plugin } from '../../../src/core/public';
import { PLUGIN_ID, PLUGIN_NAME } from '../common';

/**
 * Pallas AI Plugin for Wazuh Dashboard (OpenSearch Dashboards)
 *
 * Thin plugin that registers "Pallas AI" in the Wazuh sidebar and loads
 * the standalone Pallas app in an iframe. All AI functionality lives in
 * the standalone app — this plugin is just the entry point.
 *
 * Authentication:
 *   - If Wazuh has Keycloak SSO → Pallas uses Keycloak mode, SSO cookie shared
 *   - If Wazuh has no SSO → Pallas uses API key mode, no login required
 */
export class PallasAiPlugin implements Plugin<void, void> {
  public setup(core: CoreSetup): void {
    core.application.register({
      id: 'aiAnalystApp',
      title: PLUGIN_NAME,
      order: 9000,
      category: {
        id: 'pallas',
        label: 'AI & Intelligence',
        order: 5000,
      },
      mount: async (params) => {
        const { renderApp } = await import('./application');
        return renderApp(params, core);
      },
    });
  }

  public start(_core: CoreStart): void {}

  public stop(): void {}
}
