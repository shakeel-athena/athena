import { PallasAiPlugin } from './plugin';

export const plugin = () => new PallasAiPlugin();
