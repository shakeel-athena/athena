import React, { useState, useCallback, useEffect, useRef } from 'react';
import { getPallasAppUrl, PLUGIN_NAME } from '../../common';

/**
 * PallasFrame — iframe wrapper that loads the standalone Pallas AI app.
 *
 * Authentication via postMessage:
 *   In-iframe Keycloak silent-SSO is unreliable across browsers (Firefox ETP,
 *   Safari ITP, Chrome's third-party-cookie phase-out all break it). Instead,
 *   this component:
 *     1. Reads the user identity from OpenSearch Dashboards' security plugin
 *        (`/_opendistro/_security/authinfo`)
 *     2. Posts that identity to the Pallas iframe via window.postMessage on load
 *     3. Listens for the iframe asking for a fresh token (e.g. on 401) and
 *        re-posts the latest credentials.
 *
 *   The Pallas frontend (auth=parent mode) listens for these messages, validates
 *   the origin, and uses the token as Bearer for backend calls.
 */

interface PallasFrameProps {
  appBasePath: string;
}

interface AuthInfo {
  user_name?: string;
  user_full_name?: string;
  user?: { name?: string };
  username?: string;
  // Token may be exposed by some OSD/Wazuh-dashboard auth plugins:
  user_requested_tenant?: string;
  // Other deployments expose the raw Keycloak token via custom endpoints.
}

/**
 * Fetch the current user's identity from OSD's security plugin.
 * Returns at minimum the username; token is best-effort.
 */
async function fetchUserAuthInfo(): Promise<{ username: string; displayName: string; token: string }> {
  // OSD security plugin endpoint — works for both OpenDistro & OpenSearch Security
  try {
    const resp = await fetch('/_opendistro/_security/authinfo', {
      method: 'GET',
      credentials: 'include',
      headers: { 'osd-xsrf': 'true' },
    });
    if (resp.ok) {
      const info: AuthInfo = await resp.json();
      const username = info.user_name || info.username || info.user?.name || '';
      const displayName = info.user_full_name || username;
      // Token: many OSD security plugins do not expose the raw Keycloak JWT
      // to the frontend for security reasons. We pass an empty token; Pallas
      // backend handles the no-JWT case via its integration-key fallback.
      return { username, displayName, token: '' };
    }
  } catch (_) {
    // Fall through
  }
  return { username: '', displayName: '', token: '' };
}

export const PallasFrame: React.FC<PallasFrameProps> = ({ appBasePath }) => {
  const [isLoading, setIsLoading] = useState(true);
  const [hasError, setHasError] = useState(false);
  const pallasUrl = getPallasAppUrl();
  const iframeRef = useRef<HTMLIFrameElement>(null);
  const authInfoRef = useRef<{ username: string; displayName: string; token: string }>({ username: '', displayName: '', token: '' });

  const postAuthToFrame = useCallback(() => {
    if (!iframeRef.current?.contentWindow) return;
    try {
      // Target origin extracted from the Pallas URL — postMessage refuses to
      // deliver if the iframe's actual origin doesn't match.
      const target = new URL(pallasUrl).origin;
      iframeRef.current.contentWindow.postMessage(
        {
          type: 'pallas-auth-token',
          token: authInfoRef.current.token,
          username: authInfoRef.current.username,
          displayName: authInfoRef.current.displayName,
        },
        target,
      );
    } catch (e) {
      // Invalid pallasUrl or other postMessage failure — non-fatal
      // (the Pallas frontend has its own ApiKey fallback)
    }
  }, [pallasUrl]);

  // Fetch the user's identity once on mount; re-post if iframe asks for refresh.
  useEffect(() => {
    let cancelled = false;
    fetchUserAuthInfo().then((info) => {
      if (cancelled) return;
      authInfoRef.current = info;
      // If iframe is already loaded by the time we get here, push immediately
      postAuthToFrame();
    });

    // Listen for iframe → parent messages (origin-validated below).
    const expectedOrigin = (() => {
      try { return new URL(pallasUrl).origin; } catch { return ''; }
    })();
    const handler = (event: MessageEvent) => {
      if (!expectedOrigin || event.origin !== expectedOrigin) return;
      const data = event.data;
      if (!data || typeof data !== 'object') return;
      // iframe asks for the current token (on load or after a 401)
      if (data.type === 'pallas-iframe-ready' || data.type === 'pallas-iframe-needs-token') {
        // Re-fetch fresh in case the OSD session was refreshed
        fetchUserAuthInfo().then((info) => {
          authInfoRef.current = info;
          postAuthToFrame();
        });
      }
    };
    window.addEventListener('message', handler);

    return () => {
      cancelled = true;
      window.removeEventListener('message', handler);
    };
  }, [pallasUrl, postAuthToFrame]);

  const handleLoad = useCallback(() => {
    setIsLoading(false);
    setHasError(false);
    // After the iframe loads, push current auth in case the iframe missed our
    // "ready" message (race condition: iframe may not have attached its
    // listener before we posted the first time).
    postAuthToFrame();
  }, [postAuthToFrame]);

  const handleError = useCallback(() => {
    setIsLoading(false);
    setHasError(true);
  }, []);

  return (
    <div style={{
      width: '100%',
      height: '100%',
      position: 'fixed',
      top: 48,
      left: 0,
      right: 0,
      bottom: 0,
      backgroundColor: '#0D1117',
      zIndex: 1,
    }}>

      {/* Loading overlay */}
      {isLoading && !hasError && (
        <div style={{
          position: 'absolute',
          inset: 0,
          display: 'flex',
          flexDirection: 'column',
          alignItems: 'center',
          justifyContent: 'center',
          backgroundColor: '#0D1117',
          color: '#8e9fbc',
          fontFamily: 'Inter, -apple-system, sans-serif',
          gap: 16,
          zIndex: 1,
        }}>
          <div style={{
            width: 28,
            height: 28,
            border: '2px solid #2A2B33',
            borderTopColor: '#16c5c0',
            borderRadius: '50%',
            animation: 'pallas-spin 0.8s linear infinite',
          }} />
          <span style={{ fontSize: 13 }}>Loading {PLUGIN_NAME}...</span>
          <style>{`@keyframes pallas-spin { to { transform: rotate(360deg); } }`}</style>
        </div>
      )}

      {/* Error state */}
      {hasError && (
        <div style={{
          position: 'absolute',
          inset: 0,
          display: 'flex',
          flexDirection: 'column',
          alignItems: 'center',
          justifyContent: 'center',
          backgroundColor: '#0D1117',
          color: '#E6EDF3',
          fontFamily: 'Inter, -apple-system, sans-serif',
          gap: 16,
          zIndex: 1,
        }}>
          <div style={{
            width: 48,
            height: 48,
            borderRadius: 12,
            background: 'rgba(248, 81, 73, 0.1)',
            border: '1px solid rgba(248, 81, 73, 0.3)',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            fontSize: 24,
          }}>
            !
          </div>
          <h3 style={{ margin: 0, fontSize: 18, fontWeight: 600 }}>
            Unable to load {PLUGIN_NAME}
          </h3>
          <p style={{
            margin: 0, fontSize: 13, color: '#8e9fbc',
            textAlign: 'center', lineHeight: 1.6, maxWidth: 400,
          }}>
            The Pallas AI server at <code style={{ color: '#16c5c0' }}>{pallasUrl}</code> is
            not reachable. Please check that the server is running and accessible.
          </p>
          <button
            onClick={() => {
              setHasError(false);
              setIsLoading(true);
            }}
            style={{
              padding: '8px 20px',
              borderRadius: 6,
              border: '1px solid #2A2B33',
              background: 'transparent',
              color: '#16c5c0',
              fontSize: 13,
              fontWeight: 600,
              cursor: 'pointer',
            }}
          >
            Retry
          </button>
        </div>
      )}

      {/* Pallas iframe */}
      {!hasError && (
        <iframe
          ref={iframeRef}
          src={pallasUrl}
          title={PLUGIN_NAME}
          onLoad={handleLoad}
          onError={handleError}
          style={{
            width: '100%',
            height: '100%',
            border: 'none',
            display: isLoading ? 'none' : 'block',
            backgroundColor: '#0D1117',
          }}
          allow="clipboard-write"
        />
      )}
    </div>
  );
};
