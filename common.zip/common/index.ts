/**
 * Pallas AI Plugin — Shared Constants
 */

export const PLUGIN_ID = 'aiAnalystPlugin';
export const PLUGIN_NAME = 'Pallas AI';

/**
 * Get the Pallas standalone app URL.
 *
 * Priority:
 * 1. Custom URL from config (for different-domain deployments)
 * 2. Same-origin path (default — assumes Pallas is proxied via ALB)
 *
 * Auth modes (query param ?auth=...):
 *   - parent  : iframe receives Keycloak token + username from parent via
 *               postMessage (default — works in Wazuh dashboard plugin embed
 *               across all browsers, including Firefox ETP / Safari ITP)
 *   - apikey  : no auth flow, API key only (Pallas standalone, no SSO)
 *   - keycloak: full SSO redirect (Pallas standalone with Keycloak)
 */
export function getPallasAppUrl(): string {
  // Default: Pallas standalone app at its own subdomain in parent-auth mode.
  // The plugin's PallasFrame posts the user's identity via postMessage on iframe load.
  // HTTPS required (no mixed content in iframe).
  return (window as any).__pallas_app_url || 'https://pallas.test.athenasecuritygrp.com?auth=parent';
}
