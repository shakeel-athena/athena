import React, { createContext, useContext, useMemo, useState, useEffect } from 'react';
import { useKeycloak } from '@react-keycloak/web';
import { getCurrentUserPages } from '../services/rbacApi';

const AuthContext = createContext(null);

/**
 * AuthProvider component that wraps the app with Keycloak authentication context
 */
export const AuthProvider = ({ children }) => {
  const { keycloak, initialized } = useKeycloak();
  const [accessiblePages, setAccessiblePages] = useState([]);
  const [isAdmin, setIsAdmin] = useState(false);
  const [pagesLoading, setPagesLoading] = useState(false);

  const userId = keycloak?.tokenParsed?.sub;

  // Fetch accessible pages when user identity changes
  useEffect(() => {
    if (initialized && keycloak.authenticated && userId) {
      let isActive = true;

      const fetchAccessiblePages = async () => {
        try {
          setPagesLoading(true);
          const response = await getCurrentUserPages();
          if (!isActive) return;

          setAccessiblePages(response.pages || []);
          setIsAdmin(response.is_admin || false);
        } catch (error) {
          if (!isActive) return;
          console.error('Failed to fetch accessible pages:', error);
          setAccessiblePages([]);
          setIsAdmin(false);
        } finally {
          if (isActive) {
            setPagesLoading(false);
          }
        }
      };

      fetchAccessiblePages();

      return () => {
        isActive = false;
      };
    } else {
      setAccessiblePages([]);
      setIsAdmin(false);
    }
  }, [initialized, keycloak.authenticated, userId]);

  const value = useMemo(() => {
    if (!initialized) {
      return {
        initialized: false,
        authenticated: false,
        user: null,
        token: null,
        roles: [],
        login: () => {},
        logout: () => {},
        hasRole: () => false,
        hasAnyRole: () => false,
        hasAllRoles: () => false,
      };
    }

    // Extract user information from token
    const user = keycloak.authenticated && keycloak.tokenParsed
      ? {
          id: keycloak.tokenParsed.sub,
          username: keycloak.tokenParsed.preferred_username,
          email: keycloak.tokenParsed.email,
          firstName: keycloak.tokenParsed.given_name,
          lastName: keycloak.tokenParsed.family_name,
          fullName: keycloak.tokenParsed.name,
          emailVerified: keycloak.tokenParsed.email_verified,
        }
      : null;

    // Extract roles from token
    const roles = keycloak.authenticated && keycloak.tokenParsed
      ? [
          ...(keycloak.tokenParsed.realm_access?.roles || []),
          ...(keycloak.tokenParsed.resource_access?.['athena-frontend']?.roles || []),
        ]
      : [];

    /**
     * Check if user has a specific role
     * @param {string} role - Role name to check
     * @returns {boolean}
     */
    const hasRole = (role) => {
      return roles.includes(role);
    };

    /**
     * Check if user has any of the specified roles
     * @param {string[]} rolesToCheck - Array of role names
     * @returns {boolean}
     */
    const hasAnyRole = (rolesToCheck) => {
      return rolesToCheck.some(role => hasRole(role));
    };

    /**
     * Check if user has all of the specified roles
     * @param {string[]} rolesToCheck - Array of role names
     * @returns {boolean}
     */
    const hasAllRoles = (rolesToCheck) => {
      return rolesToCheck.every(role => hasRole(role));
    };

    /**
     * Initiate login flow
     * @param {string} redirectPath - Optional path to redirect to after login (e.g., '/dashboard/siem-events')
     */
    const login = (redirectPath) => {
      const redirectUri = redirectPath
        ? window.location.origin + redirectPath
        : window.location.origin + window.location.pathname + window.location.search;
      keycloak.login({
        redirectUri,
      });
    };

    /**
     * Initiate logout flow
     */
    const logout = () => {
      keycloak.logout({
        redirectUri: window.location.origin,
      });
    };

    /**
     * Check if user can access a specific page
     * @param {string} pagePath - Page path to check
     * @returns {boolean}
     */
    const canAccessPage = (pagePath) => {
      if (isAdmin) return true; // Admin can access everything
      return accessiblePages.some(page => page.page_path === pagePath && page.can_view);
    };

    /**
     * Check if user can edit a specific page
     * @param {string} pagePath - Page path to check
     * @returns {boolean}
     */
    const canEditPage = (pagePath) => {
      if (isAdmin) return true; // Admin can edit everything
      return accessiblePages.some(page => page.page_path === pagePath && page.can_edit);
    };

    /**
     * Get all accessible page paths
     * @returns {string[]}
     */
    const getAccessiblePaths = () => {
      if (isAdmin) return ['*']; // Admin has access to all
      return accessiblePages
        .filter(page => page.can_view)
        .map(page => page.page_path);
    };

    /**
     * Get accessible pages grouped by category
     * @returns {object}
     */
    const getAccessiblePagesByCategory = () => {
      if (isAdmin) return {}; // Return empty for admin (has access to all)

      return accessiblePages
        .filter(page => page.can_view)
        .reduce((acc, page) => {
          const category = page.page_category || 'Other';
          if (!acc[category]) {
            acc[category] = [];
          }
          acc[category].push(page);
          return acc;
        }, {});
    };

    return {
      initialized: true,
      authenticated: keycloak.authenticated || false,
      user,
      token: keycloak.token,
      idToken: keycloak.idToken,
      refreshToken: keycloak.refreshToken,
      roles,
      isAdmin,
      accessiblePages,
      pagesLoading,
      keycloak, // Expose raw keycloak instance for advanced usage
      login,
      logout,
      hasRole,
      hasAnyRole,
      hasAllRoles,
      canAccessPage,
      canEditPage,
      getAccessiblePaths,
      getAccessiblePagesByCategory,
    };
  }, [keycloak, initialized, accessiblePages, isAdmin, pagesLoading]);

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
};

/**
 * Custom hook to access authentication context
 * @returns {object} Authentication context
 */
export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};

export default AuthContext;
