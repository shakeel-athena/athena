/**
 * Shared IP Enrichment Cache
 *
 * This singleton cache is shared across all IPEnrichmentTooltip instances
 * to prevent duplicate API calls and improve performance.
 *
 * Performance improvement: Instead of each tooltip instance maintaining
 * its own cache, we use a global cache that persists across component
 * instances and re-renders.
 */

class IPEnrichmentCache {
  constructor() {
    this.enrichmentCache = new Map();
    this.statusCache = new Map();
    this.CACHE_TTL = 5 * 60 * 1000; // 5 minutes

    // Track pending requests to prevent duplicate API calls
    this.pendingEnrichmentRequests = new Map();
    this.pendingStatusRequests = new Map();
  }

  /**
   * Get enrichment data from cache
   * @param {string} ip - IP address
   * @returns {object|null} Cached data or null if not found/expired
   */
  getEnrichment(ip) {
    const cached = this.enrichmentCache.get(ip);
    if (cached && Date.now() - cached.timestamp < this.CACHE_TTL) {
      return cached.data;
    }
    // Remove expired entry
    if (cached) {
      this.enrichmentCache.delete(ip);
    }
    return null;
  }

  /**
   * Set enrichment data in cache
   * @param {string} ip - IP address
   * @param {object} data - Enrichment data
   */
  setEnrichment(ip, data) {
    this.enrichmentCache.set(ip, {
      data,
      timestamp: Date.now()
    });
  }

  /**
   * Get status data from cache
   * @param {string} ip - IP address
   * @returns {object|null} Cached data or null if not found/expired
   */
  getStatus(ip) {
    const cached = this.statusCache.get(ip);
    if (cached && Date.now() - cached.timestamp < this.CACHE_TTL) {
      return cached.data;
    }
    // Remove expired entry
    if (cached) {
      this.statusCache.delete(ip);
    }
    return null;
  }

  /**
   * Set status data in cache
   * @param {string} ip - IP address
   * @param {object} data - Status data
   */
  setStatus(ip, data) {
    this.statusCache.set(ip, {
      data,
      timestamp: Date.now()
    });
  }

  /**
   * Check if an enrichment request is pending for this IP
   * @param {string} ip - IP address
   * @returns {Promise|null} Pending promise or null
   */
  getPendingEnrichmentRequest(ip) {
    return this.pendingEnrichmentRequests.get(ip) || null;
  }

  /**
   * Set a pending enrichment request
   * @param {string} ip - IP address
   * @param {Promise} promise - Request promise
   */
  setPendingEnrichmentRequest(ip, promise) {
    this.pendingEnrichmentRequests.set(ip, promise);

    // Clean up after request completes
    promise.finally(() => {
      this.pendingEnrichmentRequests.delete(ip);
    });
  }

  /**
   * Check if a status request is pending for this IP
   * @param {string} ip - IP address
   * @returns {Promise|null} Pending promise or null
   */
  getPendingStatusRequest(ip) {
    return this.pendingStatusRequests.get(ip) || null;
  }

  /**
   * Set a pending status request
   * @param {string} ip - IP address
   * @param {Promise} promise - Request promise
   */
  setPendingStatusRequest(ip, promise) {
    this.pendingStatusRequests.set(ip, promise);

    // Clean up after request completes
    promise.finally(() => {
      this.pendingStatusRequests.delete(ip);
    });
  }

  /**
   * Clear all caches (useful for testing or manual refresh)
   */
  clearAll() {
    this.enrichmentCache.clear();
    this.statusCache.clear();
    this.pendingEnrichmentRequests.clear();
    this.pendingStatusRequests.clear();
  }

  /**
   * Clear expired entries from all caches
   */
  clearExpired() {
    const now = Date.now();

    // Clear expired enrichment cache entries
    for (const [ip, cached] of this.enrichmentCache.entries()) {
      if (now - cached.timestamp >= this.CACHE_TTL) {
        this.enrichmentCache.delete(ip);
      }
    }

    // Clear expired status cache entries
    for (const [ip, cached] of this.statusCache.entries()) {
      if (now - cached.timestamp >= this.CACHE_TTL) {
        this.statusCache.delete(ip);
      }
    }
  }

  /**
   * Get cache statistics
   * @returns {object} Cache statistics
   */
  getStats() {
    return {
      enrichmentCacheSize: this.enrichmentCache.size,
      statusCacheSize: this.statusCache.size,
      pendingEnrichmentRequests: this.pendingEnrichmentRequests.size,
      pendingStatusRequests: this.pendingStatusRequests.size,
      cacheTTL: this.CACHE_TTL
    };
  }
}

// Export singleton instance
export const ipEnrichmentCache = new IPEnrichmentCache();

// Periodically clear expired entries (every 5 minutes)
setInterval(() => {
  ipEnrichmentCache.clearExpired();
}, 5 * 60 * 1000);

export default ipEnrichmentCache;
