import React from 'react';
import {
  EuiPanel,
  EuiFlexGroup,
  EuiFlexItem,
  EuiText,
  EuiBadge,
  EuiLoadingSpinner,
  EuiLink,
  EuiSpacer
} from '@elastic/eui';
import { AlertTriangle, Clock, MapPin, Shield, Network } from 'lucide-react';
import { formatDistanceToNow } from 'date-fns';

const RecentAlertsUnified = ({ alerts = [], loading = false }) => {
  const getSeverityColor = (severity) => {
    const colors = {
      Critical: 'danger',
      High: 'warning',
      Medium: 'primary',
      Low: 'default',
    };
    return colors[severity] || 'default';
  };

  const getSourceIcon = (source) => {
    return source === 'wazuh' ? (
      <Shield style={{ width: '16px', height: '16px', color: '#00BFB3' }} />
    ) : (
      <Network style={{ width: '16px', height: '16px', color: '#8b5cf6' }} />
    );
  };

  if (loading) {
    return (
      <EuiPanel paddingSize="l">
        <EuiFlexGroup alignItems="center" justifyContent="center">
          <EuiFlexItem grow={false}>
            <EuiFlexGroup alignItems="center" gutterSize="s">
              <EuiFlexItem grow={false}>
                <EuiLoadingSpinner size="l" />
              </EuiFlexItem>
              <EuiFlexItem grow={false}>
                <EuiText color="subdued">Loading alerts...</EuiText>
              </EuiFlexItem>
            </EuiFlexGroup>
          </EuiFlexItem>
        </EuiFlexGroup>
      </EuiPanel>
    );
  }

  return (
    <EuiFlexGroup direction="column" gutterSize="none" style={{ flex: 1 }}>
      {alerts.length === 0 ? (
        <EuiFlexItem style={{ flex: 1 }}>
          <EuiPanel paddingSize="l" color="transparent" style={{ height: '100%' }}>
            <EuiFlexGroup alignItems="center" justifyContent="center" style={{ height: '100%' }}>
              <EuiFlexItem grow={false}>
                <EuiFlexGroup direction="column" alignItems="center" gutterSize="s">
                  <EuiFlexItem>
                    <AlertTriangle style={{ width: '40px', height: '40px', opacity: 0.5 }} />
                  </EuiFlexItem>
                  <EuiFlexItem>
                    <EuiText size="s" color="subdued">No recent alerts</EuiText>
                  </EuiFlexItem>
                </EuiFlexGroup>
              </EuiFlexItem>
            </EuiFlexGroup>
          </EuiPanel>
        </EuiFlexItem>
      ) : (
        <>
          <EuiFlexItem style={{ flex: 1 }}>
            {alerts.slice(0, 5).map((alert, index) => (
              <div key={index}>
                <EuiPanel
                  paddingSize="m"
                  color="transparent"
                  hasBorder={false}
                  style={{
                    borderLeft: '2px solid transparent',
                    transition: 'all 0.2s'
                  }}
                  onMouseEnter={(e) => {
                    e.currentTarget.style.backgroundColor = 'rgba(52, 55, 65, 0.5)';
                    e.currentTarget.style.borderLeftColor = 'rgba(59, 130, 246, 0.5)';
                  }}
                  onMouseLeave={(e) => {
                    e.currentTarget.style.backgroundColor = 'transparent';
                    e.currentTarget.style.borderLeftColor = 'transparent';
                  }}
                >
                  <EuiFlexGroup alignItems="flex-start" gutterSize="s">
                    <EuiFlexItem grow={false} style={{ marginTop: '4px' }}>
                      <EuiPanel
                        color="subdued"
                        paddingSize="xs"
                        style={{ border: '1px solid #343741', borderRadius: '8px' }}
                      >
                        {getSourceIcon(alert.source)}
                      </EuiPanel>
                    </EuiFlexItem>

                    <EuiFlexItem style={{ minWidth: 0 }}>
                      <EuiFlexGroup alignItems="center" gutterSize="s" wrap responsive={false}>
                        <EuiFlexItem grow={false}>
                          <EuiBadge color={getSeverityColor(alert.normalized_severity)}>
                            {alert.normalized_severity?.toUpperCase()}
                          </EuiBadge>
                        </EuiFlexItem>
                        <EuiFlexItem grow={false}>
                          <EuiBadge
                            color="hollow"
                            style={{
                              backgroundColor: '#1F2937',
                              borderColor: '#374151',
                              fontWeight: 500
                            }}
                          >
                            {alert.source}
                          </EuiBadge>
                        </EuiFlexItem>
                        <EuiFlexItem grow={false}>
                          <EuiFlexGroup alignItems="center" gutterSize="xs" responsive={false}>
                            <EuiFlexItem grow={false}>
                              <Clock style={{ width: '12px', height: '12px' }} />
                            </EuiFlexItem>
                            <EuiFlexItem grow={false}>
                              <EuiText size="xs" color="subdued">
                                {formatDistanceToNow(new Date(alert.timestamp || alert['@timestamp']), { addSuffix: true })}
                              </EuiText>
                            </EuiFlexItem>
                          </EuiFlexGroup>
                        </EuiFlexItem>
                      </EuiFlexGroup>

                      <EuiSpacer size="s" />

                      <EuiText size="s">
                        <strong
                          style={{
                            display: '-webkit-box',
                            WebkitLineClamp: 2,
                            WebkitBoxOrient: 'vertical',
                            overflow: 'hidden'
                          }}
                        >
                          {alert.signature || alert.rule?.description || 'Security Event'}
                        </strong>
                      </EuiText>

                      <EuiSpacer size="s" />

                      <EuiFlexGroup alignItems="center" gutterSize="s" wrap responsive={false}>
                        <EuiFlexItem grow={false}>
                          <EuiFlexGroup alignItems="center" gutterSize="xs" responsive={false}>
                            <EuiFlexItem grow={false}>
                              <MapPin style={{ width: '12px', height: '12px' }} />
                            </EuiFlexItem>
                            <EuiFlexItem grow={false}>
                              <EuiText size="xs" color="subdued" style={{ fontFamily: 'monospace' }}>
                                {alert.src_ip || alert.data?.srcip || 'N/A'}
                              </EuiText>
                            </EuiFlexItem>
                          </EuiFlexGroup>
                        </EuiFlexItem>
                        <EuiFlexItem grow={false}>
                          <EuiText size="xs" color="subdued">→</EuiText>
                        </EuiFlexItem>
                        <EuiFlexItem grow={false}>
                          <EuiText size="xs" color="subdued" style={{ fontFamily: 'monospace' }}>
                            {alert.dest_ip || alert.data?.dstip || 'N/A'}
                          </EuiText>
                        </EuiFlexItem>
                        {alert.agent_name && (
                          <>
                            <EuiFlexItem grow={false}>
                              <EuiText size="xs" color="subdued">•</EuiText>
                            </EuiFlexItem>
                            <EuiFlexItem grow={false}>
                              <EuiText size="xs" color="subdued" style={{ textTransform: 'capitalize' }}>
                                {alert.agent_name}
                              </EuiText>
                            </EuiFlexItem>
                          </>
                        )}
                      </EuiFlexGroup>

                      {alert.actions && alert.actions.length > 0 && (
                        <>
                          <EuiSpacer size="s" />
                          <EuiFlexGroup alignItems="center" gutterSize="s" wrap responsive={false}>
                            <EuiFlexItem grow={false}>
                              <EuiText size="xs" color="subdued">Actions:</EuiText>
                            </EuiFlexItem>
                            {alert.actions.slice(0, 2).map((action, idx) => (
                              <EuiFlexItem grow={false} key={idx}>
                                <EuiBadge
                                  color="success"
                                  style={{
                                    backgroundColor: 'rgba(0, 191, 179, 0.2)',
                                    borderColor: 'rgba(0, 191, 179, 0.3)',
                                    fontWeight: 500
                                  }}
                                >
                                  {action.name}
                                </EuiBadge>
                              </EuiFlexItem>
                            ))}
                            {alert.actions.length > 2 && (
                              <EuiFlexItem grow={false}>
                                <EuiText size="xs" color="subdued">
                                  +{alert.actions.length - 2} more
                                </EuiText>
                              </EuiFlexItem>
                            )}
                          </EuiFlexGroup>
                        </>
                      )}
                    </EuiFlexItem>
                  </EuiFlexGroup>
                </EuiPanel>
                {index < alerts.slice(0, 5).length - 1 && (
                  <div style={{ borderBottom: '1px solid #343741' }} />
                )}
              </div>
            ))}
          </EuiFlexItem>

          <EuiFlexItem>
            <EuiPanel color="subdued" paddingSize="m" style={{ borderTop: '1px solid #343741' }}>
              <EuiLink href="/detection/events" style={{ display: 'block', textAlign: 'center' }}>
                <EuiText size="s">
                  <strong>View all alerts →</strong>
                </EuiText>
              </EuiLink>
            </EuiPanel>
          </EuiFlexItem>
        </>
      )}
    </EuiFlexGroup>
  );
};

export default RecentAlertsUnified;


