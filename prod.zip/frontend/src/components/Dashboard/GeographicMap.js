import React, { useRef } from 'react';
import {
  EuiPanel,
  EuiFlexGroup,
  EuiFlexItem,
  EuiText,
  EuiTitle
} from '@elastic/eui';

// Simple world map visualization using SVG
const GeographicMap = ({ data }) => {
  const mapRef = useRef(null);

  // Get threat intensity color based on count
  const getThreatColor = (count) => {
    if (count > 500) return '#dc2626'; // Critical
    if (count > 200) return '#ea580c'; // High
    if (count > 100) return '#d97706'; // Medium
    return '#65a30d'; // Low
  };

  // Get circle size based on count
  const getCircleSize = (count) => {
    const minSize = 4;
    const maxSize = 20;
    const maxCount = Math.max(...data.map(d => d.count));
    return minSize + (count / maxCount) * (maxSize - minSize);
  };

  return (
    <div style={{ height: '320px', position: 'relative' }}>
      {/* World map background */}
      <div style={{ position: 'absolute', inset: 0, borderRadius: '6px', overflow: 'hidden' }}>
        <svg
          ref={mapRef}
          viewBox="0 0 800 400"
          style={{
            width: '100%',
            height: '100%',
            background: 'linear-gradient(180deg, #0f172a 0%, #1e293b 100%)'
          }}
        >
          {/* Simple world map outline */}
          <defs>
            <pattern id="grid" width="40" height="40" patternUnits="userSpaceOnUse">
              <path d="M 40 0 L 0 0 0 40" fill="none" stroke="#334155" strokeWidth="0.5" opacity="0.3"/>
            </pattern>
          </defs>
          
          {/* Grid background */}
          <rect width="800" height="400" fill="url(#grid)" />
          
          {/* Simplified continent outlines */}
          <g fill="none" stroke="#475569" strokeWidth="1" opacity="0.6">
            {/* North America */}
            <path d="M 50 80 Q 80 60 120 70 Q 160 65 200 80 Q 220 100 210 140 Q 190 160 160 150 Q 120 155 80 140 Q 50 120 50 80 Z" />
            
            {/* South America */}
            <path d="M 180 200 Q 200 180 220 200 Q 230 240 225 280 Q 220 320 200 340 Q 180 350 170 330 Q 165 290 170 250 Q 175 220 180 200 Z" />
            
            {/* Europe */}
            <path d="M 380 60 Q 420 50 450 60 Q 470 80 460 100 Q 440 110 420 105 Q 400 100 380 90 Q 370 75 380 60 Z" />
            
            {/* Africa */}
            <path d="M 420 120 Q 450 110 480 130 Q 490 170 485 210 Q 480 250 470 280 Q 450 300 430 290 Q 410 270 415 230 Q 420 180 420 120 Z" />
            
            {/* Asia */}
            <path d="M 500 40 Q 580 30 650 50 Q 700 70 720 100 Q 730 130 720 160 Q 700 180 670 175 Q 620 170 580 160 Q 540 150 520 130 Q 500 100 500 40 Z" />
            
            {/* Australia */}
            <path d="M 620 280 Q 660 270 690 280 Q 700 300 690 320 Q 670 330 650 325 Q 630 320 620 300 Q 615 290 620 280 Z" />
          </g>
          
          {/* Threat indicators */}
          {data.map((location, index) => {
            // Convert lat/lng to SVG coordinates (simplified projection)
            const x = ((location.lng + 180) / 360) * 800;
            const y = ((90 - location.lat) / 180) * 400;
            const size = getCircleSize(location.count);
            const color = getThreatColor(location.count);
            
            return (
              <g key={index}>
                {/* Pulsing circle for high-threat locations */}
                {location.count > 200 && (
                  <circle
                    cx={x}
                    cy={y}
                    r={size + 5}
                    fill={color}
                    opacity="0.3"
                    style={{ animation: 'pulse 2s cubic-bezier(0.4, 0, 0.6, 1) infinite' }}
                  />
                )}

                {/* Main threat indicator */}
                <circle
                  cx={x}
                  cy={y}
                  r={size}
                  fill={color}
                  stroke="#ffffff"
                  strokeWidth="1"
                  opacity="0.8"
                  style={{ cursor: 'pointer', transition: 'opacity 0.2s' }}
                  onMouseEnter={(e) => e.target.style.opacity = '1'}
                  onMouseLeave={(e) => e.target.style.opacity = '0.8'}
                >
                  <title>
                    {location.city}, {location.country}: {location.count} threats
                  </title>
                </circle>

                {/* Location label for major threats */}
                {location.count > 300 && (
                  <text
                    x={x}
                    y={y - size - 8}
                    textAnchor="middle"
                    fill="#f8fafc"
                    fontSize="10"
                    fontWeight="medium"
                    style={{ pointerEvents: 'none' }}
                  >
                    {location.city}
                  </text>
                )}
              </g>
            );
          })}
        </svg>
      </div>

      {/* Legend */}
      <div style={{ position: 'absolute', bottom: '16px', left: '16px' }}>
        <EuiPanel paddingSize="s" style={{ backdropFilter: 'blur(4px)', backgroundColor: 'rgba(0, 0, 0, 0.8)' }}>
          <EuiTitle size="xxxs">
            <h4>Threat Intensity</h4>
          </EuiTitle>
          <div style={{ marginTop: '8px' }}>
            <EuiFlexGroup direction="column" gutterSize="xs">
              <EuiFlexItem>
                <EuiFlexGroup alignItems="center" gutterSize="xs">
                  <EuiFlexItem grow={false}>
                    <div style={{ width: '12px', height: '12px', borderRadius: '50%', backgroundColor: '#dc2626' }} />
                  </EuiFlexItem>
                  <EuiFlexItem grow={false}>
                    <EuiText size="xs" color="subdued">Critical (500+)</EuiText>
                  </EuiFlexItem>
                </EuiFlexGroup>
              </EuiFlexItem>
              <EuiFlexItem>
                <EuiFlexGroup alignItems="center" gutterSize="xs">
                  <EuiFlexItem grow={false}>
                    <div style={{ width: '12px', height: '12px', borderRadius: '50%', backgroundColor: '#ea580c' }} />
                  </EuiFlexItem>
                  <EuiFlexItem grow={false}>
                    <EuiText size="xs" color="subdued">High (200+)</EuiText>
                  </EuiFlexItem>
                </EuiFlexGroup>
              </EuiFlexItem>
              <EuiFlexItem>
                <EuiFlexGroup alignItems="center" gutterSize="xs">
                  <EuiFlexItem grow={false}>
                    <div style={{ width: '12px', height: '12px', borderRadius: '50%', backgroundColor: '#d97706' }} />
                  </EuiFlexItem>
                  <EuiFlexItem grow={false}>
                    <EuiText size="xs" color="subdued">Medium (100+)</EuiText>
                  </EuiFlexItem>
                </EuiFlexGroup>
              </EuiFlexItem>
              <EuiFlexItem>
                <EuiFlexGroup alignItems="center" gutterSize="xs">
                  <EuiFlexItem grow={false}>
                    <div style={{ width: '12px', height: '12px', borderRadius: '50%', backgroundColor: '#65a30d' }} />
                  </EuiFlexItem>
                  <EuiFlexItem grow={false}>
                    <EuiText size="xs" color="subdued">Low (&lt;100)</EuiText>
                  </EuiFlexItem>
                </EuiFlexGroup>
              </EuiFlexItem>
            </EuiFlexGroup>
          </div>
        </EuiPanel>
      </div>

      {/* Top countries summary */}
      <div style={{ position: 'absolute', top: '16px', right: '16px', maxWidth: '240px' }}>
        <EuiPanel paddingSize="s" style={{ backdropFilter: 'blur(4px)', backgroundColor: 'rgba(0, 0, 0, 0.8)' }}>
          <EuiTitle size="xxxs">
            <h4>Top Threat Sources</h4>
          </EuiTitle>
          <div style={{ marginTop: '8px' }}>
            <EuiFlexGroup direction="column" gutterSize="xs">
              {data.slice(0, 5).map((location, index) => (
                <EuiFlexItem key={index}>
                  <EuiFlexGroup alignItems="center" justifyContent="spaceBetween" gutterSize="s">
                    <EuiFlexItem>
                      <EuiText size="xs" color="subdued">{location.country}</EuiText>
                    </EuiFlexItem>
                    <EuiFlexItem grow={false}>
                      <EuiText size="xs">
                        <strong>{location.count}</strong>
                      </EuiText>
                    </EuiFlexItem>
                  </EuiFlexGroup>
                </EuiFlexItem>
              ))}
            </EuiFlexGroup>
          </div>
        </EuiPanel>
      </div>
    </div>
  );
};

export default GeographicMap;
