import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  EuiIcon,
  EuiPanel,
  EuiFlexGroup,
  EuiFlexItem,
  EuiText,
  EuiTitle,
  EuiBadge,
  EuiLoadingSpinner,
  EuiSpacer,
  EuiModal,
  EuiModalHeader,
  EuiModalHeaderTitle,
  EuiModalBody,
  EuiCodeBlock,
  EuiCallOut,
  EuiCard,
  EuiStat
} from '@elastic/eui';
import { formatDistanceToNow } from 'date-fns';
import { PieChart, Pie, Cell, ResponsiveContainer, Tooltip } from 'recharts';
import GeographicMap from './GeographicMap';

const AlertsSummaryCard = ({ stats, overallStats, loading, alerts = [], sourceFilter = null, onSourceFilter }) => {
  const navigate = useNavigate();
  const [selectedEvent, setSelectedEvent] = useState(null);
  const [donutHovered, setDonutHovered] = useState(false);
  if (loading) {
    return (
      <EuiPanel>
        <EuiFlexGroup alignItems="center" justifyContent="center" style={{ minHeight: '192px' }}>
          <EuiFlexItem grow={false}>
            <EuiFlexGroup alignItems="center" gutterSize="s">
              <EuiFlexItem grow={false}>
                <EuiLoadingSpinner size="l" />
              </EuiFlexItem>
              <EuiFlexItem grow={false}>
                <EuiText color="subdued">Loading alerts summary...</EuiText>
              </EuiFlexItem>
            </EuiFlexGroup>
          </EuiFlexItem>
        </EuiFlexGroup>
      </EuiPanel>
    );
  }

  // Use overall stats for the buttons (always show total counts regardless of filter)
  const overallTotalAlerts = overallStats?.total_alerts || stats?.total_alerts || 0;
  const overallBySource = overallStats?.by_source || stats?.by_source || {};
  
  // Use filtered stats for severity breakdown and top events (changes based on filter)
  const filteredTotalAlerts = stats?.total_alerts || 0;
  const bySeverity = stats?.by_severity || {};

  // Calculate severity percentages based on filtered data
  const criticalCount = bySeverity.Critical || bySeverity.critical || 0;
  const highCount = bySeverity.High || bySeverity.high || 0;
  const mediumCount = bySeverity.Medium || bySeverity.medium || 0;
  const lowCount = bySeverity.Low || bySeverity.low || 0;

  // Use filtered total for percentages (severity breakdown reflects filtered data)
  const criticalPercent = filteredTotalAlerts > 0 ? ((criticalCount / filteredTotalAlerts) * 100).toFixed(1) : 0;
  const highPercent = filteredTotalAlerts > 0 ? ((highCount / filteredTotalAlerts) * 100).toFixed(1) : 0;
  const mediumPercent = filteredTotalAlerts > 0 ? ((mediumCount / filteredTotalAlerts) * 100).toFixed(1) : 0;
  const lowPercent = filteredTotalAlerts > 0 ? ((lowCount / filteredTotalAlerts) * 100).toFixed(1) : 0;

  const severityData = [
    {
      name: 'Critical',
      value: criticalCount,
      label: 'Critical',
      count: criticalCount,
      percent: criticalPercent,
      color: 'bg-threat-critical',
      bgColor: 'bg-red-500/10',
      textColor: 'text-threat-critical',
      icon: 'alert',
      chartColor: '#ef4444', // Red for Critical
    },
    {
      name: 'High',
      value: highCount,
      label: 'High',
      count: highCount,
      percent: highPercent,
      color: 'bg-threat-high',
      bgColor: 'bg-orange-500/10',
      textColor: 'text-threat-high',
      icon: 'alert',
      chartColor: '#f97316', // Orange for High
    },
    {
      name: 'Medium',
      value: mediumCount,
      label: 'Medium',
      count: mediumCount,
      percent: mediumPercent,
      color: 'bg-threat-medium',
      bgColor: 'bg-yellow-500/10',
      textColor: 'text-threat-medium',
      icon: 'shield',
      chartColor: '#f59e0b', // Yellow for Medium
    },
    {
      name: 'Low',
      value: lowCount,
      label: 'Low',
      count: lowCount,
      percent: lowPercent,
      color: 'bg-status-info',
      bgColor: 'bg-blue-500/10',
      textColor: 'text-status-info',
      icon: 'pulse',
      chartColor: '#3b82f6', // Blue for Low
    },
  ];

  // Get top high-severity events with priority: Critical -> High -> Medium
  const getTopHighSeverityEvents = () => {
    // First, try to get Critical events
    let priorityAlerts = alerts.filter(alert => {
      const severity = alert.normalized_severity || alert.severity || '';
      return severity === 'Critical' || severity === 'critical';
    });
    
    // If no Critical, try High
    if (priorityAlerts.length === 0) {
      priorityAlerts = alerts.filter(alert => {
        const severity = alert.normalized_severity || alert.severity || '';
        return severity === 'High' || severity === 'high';
      });
    }
    
    // If no High, try Medium
    if (priorityAlerts.length === 0) {
      priorityAlerts = alerts.filter(alert => {
        const severity = alert.normalized_severity || alert.severity || '';
        return severity === 'Medium' || severity === 'medium';
      });
    }
    
    // Sort by severity (Critical first), then by timestamp (newest first)
    const sortedAlerts = priorityAlerts.sort((a, b) => {
      const severityOrder = { 
        'Critical': 1, 'critical': 1, 
        'High': 2, 'high': 2, 
        'Medium': 3, 'medium': 3,
        'Low': 4, 'low': 4
      };
      const aSev = severityOrder[a.normalized_severity || a.severity || ''] || 4;
      const bSev = severityOrder[b.normalized_severity || b.severity || ''] || 4;
      if (aSev !== bSev) return aSev - bSev;
      
      const aTime = new Date(a.timestamp || a['@timestamp'] || 0);
      const bTime = new Date(b.timestamp || b['@timestamp'] || 0);
      return bTime - aTime;
    });
    
    return sortedAlerts.slice(0, 5); // Top 5 events
  };

  // Get top signatures with counts and percentages
  const getTopSignatures = () => {
    if (!alerts || alerts.length === 0) return [];

    const signatureData = {}; // signature -> { count, severity, sources }
    
    alerts.forEach(alert => {
      const signature = alert.signature || alert.rule_description || 'Unknown';
      const severity = alert.normalized_severity || alert.severity || 'Medium';
      const source = alert.source || 'unknown';
      
      if (!signatureData[signature]) {
        signatureData[signature] = {
          count: 0,
          severity: severity,
          sources: new Set()
        };
      }
      
      signatureData[signature].count++;
      signatureData[signature].sources.add(source);
      // Keep the most severe severity if multiple
      const severityOrder = { 'Critical': 1, 'critical': 1, 'High': 2, 'high': 2, 'Medium': 3, 'medium': 3, 'Low': 4, 'low': 4 };
      const currentSev = severityOrder[signatureData[signature].severity] || 4;
      const newSev = severityOrder[severity] || 4;
      if (newSev < currentSev) {
        signatureData[signature].severity = severity;
      }
    });

    // Calculate total for percentage - use total alerts from stats if available,
    // otherwise use loaded alerts count
    const totalForPercentage = filteredTotalAlerts > 0 ? filteredTotalAlerts : alerts.length;

    // Convert to array and sort by count
    const signatureArray = Object.entries(signatureData)
      .map(([name, data]) => ({
        name,
        count: data.count,
        severity: data.severity,
        sources: Array.from(data.sources),
        percent: totalForPercentage > 0 ? ((data.count / totalForPercentage) * 100).toFixed(1) : 0
      }))
      .sort((a, b) => b.count - a.count)
      .slice(0, 5); // Top 5 signatures

    return signatureArray;
  };

  const topSignatures = getTopSignatures();

  const topEvents = getTopHighSeverityEvents();

  // Extract geographic data from alerts
  const extractGeographicData = () => {
    if (!alerts || alerts.length === 0) return [];

    // Collect unique IP addresses from alerts
    const ipCounts = new Map();
    
    alerts.forEach(alert => {
      // Use source IP primarily (external threats), fallback to destination IP
      const ip = alert.src_ip || alert.source_ip || alert.dest_ip || alert.destination_ip;
      
      if (ip && ip !== 'Unknown' && !ip.startsWith('192.168.') && !ip.startsWith('10.') && 
          !ip.startsWith('172.16.') && !ip.startsWith('127.')) {
        // Skip private IPs
        ipCounts.set(ip, (ipCounts.get(ip) || 0) + 1);
      }
    });

    // Convert IPs to approximate locations
    // Using a simple approximation - in production, use ip-api.com or MaxMind GeoIP2
    const ipToApproxLocation = (ip) => {
      try {
        const octets = ip.split('.').map(Number);
        if (octets.length !== 4) return null;
        
        // Simple approximation based on first octet ranges
        // This is a demo implementation - replace with real geolocation service
        const firstOctet = octets[0];
        const secondOctet = octets[1];
        
        // Approximate geographic regions based on IP ranges
        // Note: This is simplified and not accurate - use real geolocation API in production
        if (firstOctet >= 1 && firstOctet <= 126) {
          // Class A - mostly US/Europe
          return { lat: 40.7128, lng: -74.0060, city: 'New York', country: 'USA' };
        } else if (firstOctet >= 128 && firstOctet <= 191) {
          // Class B - mixed
          const hash = secondOctet % 5;
          const locations = [
            { lat: 51.5074, lng: -0.1278, city: 'London', country: 'UK' },
            { lat: 52.5200, lng: 13.4050, city: 'Berlin', country: 'Germany' },
            { lat: 48.8566, lng: 2.3522, city: 'Paris', country: 'France' },
            { lat: 35.6762, lng: 139.6503, city: 'Tokyo', country: 'Japan' },
            { lat: 39.9042, lng: 116.4074, city: 'Beijing', country: 'China' },
          ];
          return locations[hash];
        } else if (firstOctet >= 192 && firstOctet <= 223) {
          // Class C - mixed
          const hash = (secondOctet + octets[2]) % 7;
          const locations = [
            { lat: 28.6139, lng: 77.2090, city: 'New Delhi', country: 'India' },
            { lat: 1.3521, lng: 103.8198, city: 'Singapore', country: 'Singapore' },
            { lat: -33.8688, lng: 151.2093, city: 'Sydney', country: 'Australia' },
            { lat: -23.5505, lng: -46.6333, city: 'São Paulo', country: 'Brazil' },
            { lat: 55.7558, lng: 37.6173, city: 'Moscow', country: 'Russia' },
            { lat: 25.2048, lng: 55.2708, city: 'Dubai', country: 'UAE' },
            { lat: 40.7128, lng: -74.0060, city: 'New York', country: 'USA' },
          ];
          return locations[hash];
        }
      } catch (e) {
        return null;
      }
      return null;
    };

    // Group IPs by location and count alerts
    const locationMap = new Map();

    ipCounts.forEach((count, ip) => {
      const location = ipToApproxLocation(ip);
      if (location) {
        const key = `${location.lat.toFixed(2)},${location.lng.toFixed(2)}`;
        if (!locationMap.has(key)) {
          locationMap.set(key, {
            lat: location.lat,
            lng: location.lng,
            city: location.city,
            country: location.country,
            count: 0,
            uniqueIPs: 0
          });
        }
        const locData = locationMap.get(key);
        locData.count += count;
        locData.uniqueIPs += 1;
      }
    });

    // Convert to array and sort by count
    return Array.from(locationMap.values())
      .sort((a, b) => b.count - a.count)
      .slice(0, 20); // Limit to top 20 locations
  };

  const geographicThreatData = extractGeographicData();

  const formatTimestamp = (timestamp) => {
    if (!timestamp) return 'Unknown';
    try {
      return formatDistanceToNow(new Date(timestamp), { addSuffix: true });
    } catch {
      return 'Unknown';
    }
  };

  return (
    <EuiPanel paddingSize="none" hasBorder>
      {/* Header */}
      <EuiPanel color="subdued" paddingSize="m" style={{ borderRadius: 0 }}>
        <EuiFlexGroup alignItems="center" justifyContent="spaceBetween" gutterSize="s" responsive={true}>
          <EuiFlexItem>
            <EuiFlexGroup alignItems="center" gutterSize="s" responsive={false}>
              <EuiFlexItem grow={false}>
                <EuiIcon type="alert" size="m" color="primary" />
              </EuiFlexItem>
              <EuiFlexItem>
                <EuiFlexGroup direction="column" gutterSize="none">
                  <EuiFlexItem>
                    <EuiFlexGroup alignItems="center" gutterSize="s" responsive={false} wrap>
                      <EuiFlexItem grow={false}>
                        <EuiTitle size="s">
                          <h3>Alerts Summary</h3>
                        </EuiTitle>
                      </EuiFlexItem>
                      {sourceFilter && (
                        <EuiFlexItem grow={false}>
                          <EuiBadge color="primary">
                            Filtered: {sourceFilter === 'wazuh' ? 'Wazuh' : 'Suricata'}
                          </EuiBadge>
                        </EuiFlexItem>
                      )}
                    </EuiFlexGroup>
                  </EuiFlexItem>
                  <EuiFlexItem>
                    <EuiText size="xs" color="subdued">Real-time security events across all sources</EuiText>
                  </EuiFlexItem>
                </EuiFlexGroup>
              </EuiFlexItem>
            </EuiFlexGroup>
          </EuiFlexItem>
          <EuiFlexItem grow={false}>
            <EuiBadge color="success" iconType="dot">Live</EuiBadge>
          </EuiFlexItem>
        </EuiFlexGroup>
      </EuiPanel>

      <EuiPanel paddingSize="l" style={{ borderRadius: 0 }}>
        {/* Total Alerts Display */}
        <EuiFlexGroup gutterSize="m" responsive={true}>
          {/* Total */}
          <EuiFlexItem>
            <EuiCard
              textAlign="center"
              title=""
              description=""
              onClick={() => onSourceFilter && onSourceFilter(null)}
              selectable={{
                onClick: () => onSourceFilter && onSourceFilter(null),
                isSelected: sourceFilter === null
              }}
            >
              <EuiStat
                title={overallTotalAlerts.toLocaleString()}
                description="Total Alerts"
                titleSize="l"
                textAlign="center"
              />
              {sourceFilter === null && (
                <EuiText size="xs" color="primary" style={{ marginTop: '8px' }}>
                  <strong>Active Filter</strong>
                </EuiText>
              )}
            </EuiCard>
          </EuiFlexItem>

          {/* Wazuh */}
          <EuiFlexItem>
            <EuiCard
              textAlign="center"
              title=""
              description=""
              onClick={() => onSourceFilter && onSourceFilter('wazuh')}
              selectable={{
                onClick: () => onSourceFilter && onSourceFilter('wazuh'),
                isSelected: sourceFilter === 'wazuh'
              }}
            >
              <EuiStat
                title={overallBySource.wazuh?.toLocaleString() || '0'}
                description="Wazuh"
                titleSize="l"
                titleColor="success"
                textAlign="center"
              />
              {sourceFilter === 'wazuh' && (
                <EuiText size="xs" color="success" style={{ marginTop: '8px' }}>
                  <strong>Active Filter</strong>
                </EuiText>
              )}
            </EuiCard>
          </EuiFlexItem>

          {/* Suricata */}
          <EuiFlexItem>
            <EuiCard
              textAlign="center"
              title=""
              description=""
              onClick={() => onSourceFilter && onSourceFilter('suricata')}
              selectable={{
                onClick: () => onSourceFilter && onSourceFilter('suricata'),
                isSelected: sourceFilter === 'suricata'
              }}
            >
              <EuiStat
                title={overallBySource.suricata?.toLocaleString() || '0'}
                description="Suricata"
                titleSize="l"
                titleColor="primary"
                textAlign="center"
              />
              {sourceFilter === 'suricata' && (
                <EuiText size="xs" color="primary" style={{ marginTop: '8px' }}>
                  <strong>Active Filter</strong>
                </EuiText>
              )}
            </EuiCard>
          </EuiFlexItem>
        </EuiFlexGroup>

        <EuiSpacer size="l" />

        {/* Two Column Layout */}
        <EuiFlexGroup alignItems="stretch" gutterSize="l" responsive={true}>
                {/* Left: Severity Breakdown */}
                <EuiFlexItem style={{ minWidth: '300px' }}>
                  <EuiFlexGroup direction="column" gutterSize="s">
                    <EuiFlexItem grow={false}>
                      <EuiFlexGroup alignItems="center" justifyContent="spaceBetween" gutterSize="s" responsive={false}>
                        <EuiFlexItem grow={false}>
                          <EuiTitle size="xs">
                            <h4>SEVERITY BREAKDOWN</h4>
                          </EuiTitle>
                        </EuiFlexItem>
                        <EuiFlexItem grow={false}>
                          <EuiIcon type="arrowRight" size="s" color="subdued" />
                        </EuiFlexItem>
                      </EuiFlexGroup>
                    </EuiFlexItem>

                  {/* Donut Chart Centered with Top Right Stats */}
                  <EuiFlexItem grow={false}>
                    <EuiPanel
                      color="subdued"
                      paddingSize="l"
                      className="clickable-dashboard-panel"
                      onClick={() => navigate('/detection/events')}
                    >
                      <div style={{ position: 'relative', minHeight: '360px' }}>
                        {/* Centered Donut Chart */}
                        <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center', height: '100%' }}>
                          <div
                            className="donut-chart-clickable"
                            style={{
                              position: 'relative',
                              width: '320px',
                              height: '320px',
                              transform: donutHovered ? 'scale(1.05)' : 'scale(1)',
                              transition: 'transform 0.3s'
                            }}
                            onMouseEnter={() => setDonutHovered(true)}
                            onMouseLeave={() => setDonutHovered(false)}
                          >
                            <ResponsiveContainer width={320} height={320}>
                              <PieChart>
                                <Pie
                                  data={severityData.filter(item => item.count > 0)}
                                  cx="50%"
                                  cy="50%"
                                  innerRadius={80}
                                  outerRadius={120}
                                  paddingAngle={3}
                                  dataKey="count"
                                  startAngle={90}
                                  endAngle={-270}
                                  animationBegin={0}
                                  animationDuration={800}
                                >
                                  {severityData.filter(item => item.count > 0).map((entry, index) => (
                                    <Cell
                                      key={`cell-${index}`}
                                      fill={entry.chartColor}
                                      stroke="rgba(15, 23, 42, 0.8)"
                                      strokeWidth={2}
                                    />
                                  ))}
                                </Pie>
                                <Tooltip
                                  content={({ active, payload }) => {
                                    if (active && payload && payload.length) {
                                      const data = payload[0].payload;
                                      return (
                                        <EuiPanel paddingSize="s" hasShadow style={{ backgroundColor: '#1a1f2e' }}>
                                          <EuiText size="s">
                                            <strong>{data.label}</strong>
                                          </EuiText>
                                          <EuiText size="xs" color="subdued">
                                            <strong>{data.count.toLocaleString()}</strong> alerts
                                          </EuiText>
                                          <EuiText size="xs" color="subdued">
                                            <strong>{data.percent}%</strong> of total
                                          </EuiText>
                                        </EuiPanel>
                                      );
                                    }
                                    return null;
                                  }}
                                />
                              </PieChart>
                            </ResponsiveContainer>
                            {/* Center Text */}
                            <div style={{
                              position: 'absolute',
                              top: '50%',
                              left: '50%',
                              transform: 'translate(-50%, -50%)',
                              textAlign: 'center',
                              pointerEvents: 'none'
                            }}>
                              <EuiTitle size="l">
                                <h2 style={{ margin: 0, fontSize: '2.5rem', fontWeight: 'bold' }}>{filteredTotalAlerts.toLocaleString()}</h2>
                              </EuiTitle>
                              <EuiText size="xs" color="subdued" textAlign="center">
                                <strong>TOTAL ALERTS</strong>
                              </EuiText>
                              {sourceFilter && (
                                <EuiText size="xs" color="primary" style={{ marginTop: '4px' }}>
                                  ({sourceFilter === 'wazuh' ? 'Wazuh' : 'Suricata'})
                                </EuiText>
                              )}
                            </div>
                          </div>
                        </div>

                        {/* Legend Below Chart */}
                        <div style={{ marginTop: '16px' }}>
                          <EuiFlexGroup justifyContent="center" gutterSize="m" wrap responsive={false}>
                            {severityData.map((item) => (
                              <EuiFlexItem key={item.label} grow={false}>
                                <EuiFlexGroup gutterSize="s" alignItems="center" responsive={false}>
                                  <EuiFlexItem grow={false}>
                                    <div
                                      style={{
                                        width: '16px',
                                        height: '16px',
                                        backgroundColor: item.chartColor,
                                        borderRadius: '3px'
                                      }}
                                    />
                                  </EuiFlexItem>
                                  <EuiFlexItem grow={false}>
                                    <EuiText size="s">
                                      <strong>{item.label}</strong>: {item.count.toLocaleString()}
                                    </EuiText>
                                  </EuiFlexItem>
                                </EuiFlexGroup>
                              </EuiFlexItem>
                            ))}
                          </EuiFlexGroup>
                        </div>
                      </div>
                    </EuiPanel>
                  </EuiFlexItem>

                  {/* Top Signature Events */}
                  <EuiFlexItem grow={false}>
                    <EuiPanel
                      color="subdued"
                      paddingSize="m"
                      className={topSignatures.length > 0 ? 'clickable-dashboard-panel signature-panel-clickable' : ''}
                      style={{
                        cursor: topSignatures.length > 0 ? 'pointer' : 'default',
                        minHeight: '250px'
                      }}
                      onClick={() => topSignatures.length > 0 && navigate('/detection/events')}
                    >
                      <EuiFlexGroup justifyContent="spaceBetween" alignItems="center" responsive={false} gutterSize="s">
                        <EuiFlexItem grow={false}>
                          <EuiTitle size="xxs">
                            <h4>TOP SIGNATURE EVENTS</h4>
                          </EuiTitle>
                        </EuiFlexItem>
                        {topSignatures.length > 0 && (
                          <EuiFlexItem grow={false}>
                            <EuiIcon type="arrowRight" size="s" color="subdued" />
                          </EuiFlexItem>
                        )}
                      </EuiFlexGroup>
                      <EuiSpacer size="s" />
                      {topSignatures.length === 0 ? (
                        <EuiCallOut title="No signature data available" color="warning" iconType="alert" size="s" />
                      ) : (
                        <EuiFlexGroup direction="column" gutterSize="s">
                          {topSignatures.map((sig, index) => (
                            <EuiFlexItem key={index}>
                              <EuiPanel paddingSize="s" hasBorder>
                                <EuiFlexGroup alignItems="flexStart" justifyContent="spaceBetween" gutterSize="s" responsive={false}>
                                  <EuiFlexItem style={{ minWidth: 0, maxWidth: '70%' }}>
                                    <EuiFlexGroup alignItems="center" gutterSize="s" responsive={false} wrap>
                                      {sig.sources.map((source, sourceIdx) => (
                                        <EuiFlexItem key={sourceIdx} grow={false}>
                                          <EuiBadge color={source === 'wazuh' ? 'success' : 'primary'}>
                                            {source === 'wazuh' ? 'W' : source === 'suricata' ? 'S' : source.charAt(0).toUpperCase()}
                                          </EuiBadge>
                                        </EuiFlexItem>
                                      ))}
                                      <EuiFlexItem style={{ minWidth: 0 }}>
                                        <EuiText size="s" style={{
                                          overflow: 'hidden',
                                          textOverflow: 'ellipsis',
                                          display: '-webkit-box',
                                          WebkitLineClamp: 2,
                                          WebkitBoxOrient: 'vertical',
                                          wordBreak: 'break-word'
                                        }}>
                                          <strong title={sig.name}>{sig.name}</strong>
                                        </EuiText>
                                      </EuiFlexItem>
                                    </EuiFlexGroup>
                                  </EuiFlexItem>
                                  <EuiFlexItem grow={false} style={{ minWidth: '100px' }}>
                                    <EuiFlexGroup alignItems="center" justifyContent="flexEnd" gutterSize="s" responsive={false}>
                                      <EuiFlexItem grow={false}>
                                        <EuiText size="m" textAlign="right">
                                          <strong>{sig.count.toLocaleString()}</strong>
                                        </EuiText>
                                      </EuiFlexItem>
                                      <EuiFlexItem grow={false} style={{ minWidth: '50px' }}>
                                        <EuiText size="s" color="subdued" textAlign="right">
                                          <strong>{sig.percent}%</strong>
                                        </EuiText>
                                      </EuiFlexItem>
                                    </EuiFlexGroup>
                                  </EuiFlexItem>
                                </EuiFlexGroup>
                              </EuiPanel>
                            </EuiFlexItem>
                          ))}
                        </EuiFlexGroup>
                      )}
                    </EuiPanel>
                  </EuiFlexItem>
                  </EuiFlexGroup>
                </EuiFlexItem>

                {/* Right: Top High Severity Events */}
                <EuiFlexItem style={{ minWidth: '300px' }}>
                  <EuiFlexGroup direction="column" gutterSize="none">
                    <EuiFlexItem>
                      <EuiFlexGroup alignItems="center" justifyContent="spaceBetween" gutterSize="s" responsive={false}>
                        <EuiFlexItem grow={false}>
                          <EuiTitle size="xs">
                            <h4>TOP HIGH SEVERITY EVENTS</h4>
                          </EuiTitle>
                        </EuiFlexItem>
                        <EuiFlexItem grow={false}>
                          <EuiBadge>{topEvents.length} events</EuiBadge>
                        </EuiFlexItem>
                      </EuiFlexGroup>
                    </EuiFlexItem>
                    <EuiFlexItem>
                      <EuiSpacer size="m" />
                    </EuiFlexItem>
                  </EuiFlexGroup>

                  <EuiFlexGroup direction="column" gutterSize="m">
                  {topEvents.length === 0 ? (
                    <EuiFlexItem>
                      <EuiPanel color="subdued" paddingSize="l" style={{ minHeight: '200px' }}>
                        <EuiFlexGroup alignItems="center" justifyContent="center" style={{ minHeight: '168px' }}>
                          <EuiFlexItem grow={false}>
                            <EuiFlexGroup direction="column" alignItems="center" gutterSize="s">
                              <EuiFlexItem>
                                <EuiIcon type="alert" size="xl" color="subdued" />
                              </EuiFlexItem>
                              <EuiFlexItem>
                                <EuiText size="s" color="subdued">No high severity events</EuiText>
                              </EuiFlexItem>
                            </EuiFlexGroup>
                          </EuiFlexItem>
                        </EuiFlexGroup>
                      </EuiPanel>
                    </EuiFlexItem>
                  ) : (
                    <EuiFlexItem>
                      <EuiPanel color="subdued" paddingSize="none">
                        {topEvents.map((event, index) => {
                          const severity = event.normalized_severity || event.severity || 'Medium';
                          const signature = event.signature || event.rule_description || event.signature || 'Unknown Alert';
                          const timestamp = event.timestamp || event['@timestamp'] || '';
                          const srcIp = event.src_ip || event.source_ip || '';
                          const destIp = event.dest_ip || event.destination_ip || '';
                          const source = event.source || 'unknown';

                          const severityColorMap = {
                            critical: 'danger',
                            high: 'warning',
                            medium: 'primary',
                            low: 'default'
                          };
                          const badgeColor = severityColorMap[severity?.toLowerCase()] || 'default';

                          return (
                            <div key={index} style={{ borderBottom: index < topEvents.length - 1 ? '1px solid #343741' : 'none' }}>
                              <EuiPanel
                                paddingSize="s"
                                color="transparent"
                                onClick={() => setSelectedEvent(event)}
                                style={{ cursor: 'pointer' }}
                              >
                                <EuiFlexGroup alignItems="flexStart" justifyContent="spaceBetween" gutterSize="s">
                                  {/* Left: Severity Badge and Content */}
                                  <EuiFlexItem>
                                    <EuiFlexGroup alignItems="flexStart" gutterSize="s">
                                      <EuiFlexItem grow={false} style={{ marginTop: '2px' }}>
                                        <EuiBadge color={badgeColor}>
                                          {severity.toUpperCase()}
                                        </EuiBadge>
                                      </EuiFlexItem>
                                      <EuiFlexItem style={{ minWidth: 0 }}>
                                        <EuiText size="s">
                                          <strong style={{
                                            display: '-webkit-box',
                                            WebkitLineClamp: 2,
                                            WebkitBoxOrient: 'vertical',
                                            overflow: 'hidden'
                                          }}>
                                            {signature}
                                          </strong>
                                        </EuiText>
                                        <EuiSpacer size="xs" />
                                        <EuiFlexGroup alignItems="center" gutterSize="s">
                                          <EuiFlexItem grow={false}>
                                            <EuiFlexGroup alignItems="center" gutterSize="xs">
                                              <EuiFlexItem grow={false}>
                                                <EuiIcon type="clock" size="s" />
                                              </EuiFlexItem>
                                              <EuiFlexItem grow={false}>
                                                <EuiText size="xs" color="subdued">
                                                  {formatTimestamp(timestamp)}
                                                </EuiText>
                                              </EuiFlexItem>
                                            </EuiFlexGroup>
                                          </EuiFlexItem>
                                          {(srcIp || destIp) && (
                                            <>
                                              <EuiFlexItem grow={false}>
                                                <EuiText size="xs" color="subdued">•</EuiText>
                                              </EuiFlexItem>
                                              <EuiFlexItem grow={false}>
                                                <EuiText size="xs" style={{ fontFamily: 'monospace' }} color="subdued">
                                                  {srcIp && <span>{srcIp}</span>}
                                                  {srcIp && destIp && <span> → </span>}
                                                  {destIp && <span>{destIp}</span>}
                                                </EuiText>
                                              </EuiFlexItem>
                                            </>
                                          )}
                                        </EuiFlexGroup>
                                      </EuiFlexItem>
                                    </EuiFlexGroup>
                                  </EuiFlexItem>

                                  {/* Right: Source Badge */}
                                  <EuiFlexItem grow={false}>
                                    <EuiBadge color={source === 'wazuh' ? 'success' : 'primary'}>
                                      {source === 'wazuh' ? 'W' : source === 'suricata' ? 'S' : source.charAt(0).toUpperCase()}
                                    </EuiBadge>
                                  </EuiFlexItem>
                                </EuiFlexGroup>
                              </EuiPanel>
                            </div>
                          );
                        })}
                      </EuiPanel>
                    </EuiFlexItem>
                  )}

                  {/* Geographic Threat Map */}
                  <EuiFlexItem>
                    <EuiPanel color="subdued" paddingSize="none">
                      <EuiPanel color="transparent" paddingSize="m" hasBorder={false}>
                        <EuiFlexGroup alignItems="center" gutterSize="s">
                          <EuiFlexItem grow={false}>
                            <EuiIcon type="globe" size="m" color="primary" />
                          </EuiFlexItem>
                          <EuiFlexItem>
                            <EuiTitle size="xxs">
                              <h4>GEOGRAPHIC THREAT MAP</h4>
                            </EuiTitle>
                          </EuiFlexItem>
                          {geographicThreatData.length > 0 && (
                            <EuiFlexItem grow={false}>
                              <EuiBadge>{geographicThreatData.length} locations</EuiBadge>
                            </EuiFlexItem>
                          )}
                        </EuiFlexGroup>
                      </EuiPanel>
                      <EuiPanel color="transparent" paddingSize="m">
                        {geographicThreatData.length > 0 ? (
                          <GeographicMap data={geographicThreatData} />
                        ) : (
                          <EuiFlexGroup alignItems="center" justifyContent="center" style={{ minHeight: '320px' }}>
                            <EuiFlexItem grow={false}>
                              <EuiFlexGroup direction="column" alignItems="center" gutterSize="s">
                                <EuiFlexItem>
                                  <EuiIcon type="globe" size="xxl" color="subdued" />
                                </EuiFlexItem>
                                <EuiFlexItem>
                                  <EuiText size="s" color="subdued" textAlign="center">
                                    No geographic data available
                                  </EuiText>
                                </EuiFlexItem>
                                <EuiFlexItem>
                                  <EuiText size="xs" color="subdued" textAlign="center">
                                    IP addresses needed for geolocation
                                  </EuiText>
                                </EuiFlexItem>
                              </EuiFlexGroup>
                            </EuiFlexItem>
                          </EuiFlexGroup>
                        )}
                      </EuiPanel>
                    </EuiPanel>
                  </EuiFlexItem>
                  </EuiFlexGroup>
                </EuiFlexItem>
        </EuiFlexGroup>
      </EuiPanel>

      {/* Event Details Modal */}
      {selectedEvent && (
        <EuiModal onClose={() => setSelectedEvent(null)} maxWidth="800px">
          <EuiModalHeader>
            <EuiModalHeaderTitle>Event Details</EuiModalHeaderTitle>
          </EuiModalHeader>

          <EuiModalBody>
            <EuiFlexGroup direction="column" gutterSize="m">
              <EuiFlexItem>
                <EuiText size="xs">
                  <strong>Timestamp</strong>
                </EuiText>
                <EuiSpacer size="xs" />
                <EuiText size="s">
                  {selectedEvent.timestamp || selectedEvent['@timestamp']
                    ? new Date(selectedEvent.timestamp || selectedEvent['@timestamp']).toLocaleString()
                    : 'Unknown'}
                </EuiText>
              </EuiFlexItem>

              <EuiFlexItem>
                <EuiText size="xs">
                  <strong>Severity</strong>
                </EuiText>
                <EuiSpacer size="xs" />
                <EuiBadge color={
                  (selectedEvent.normalized_severity || selectedEvent.severity || '').toLowerCase() === 'critical' ? 'danger' :
                  (selectedEvent.normalized_severity || selectedEvent.severity || '').toLowerCase() === 'high' ? 'warning' :
                  (selectedEvent.normalized_severity || selectedEvent.severity || '').toLowerCase() === 'medium' ? 'primary' : 'default'
                }>
                  {(selectedEvent.normalized_severity || selectedEvent.severity || 'Medium').toUpperCase()}
                </EuiBadge>
              </EuiFlexItem>

              <EuiFlexItem>
                <EuiText size="xs">
                  <strong>Event Type / Signature</strong>
                </EuiText>
                <EuiSpacer size="xs" />
                <EuiText size="s">
                  {selectedEvent.signature || selectedEvent.rule_description || selectedEvent.rule?.description || 'Unknown Alert'}
                </EuiText>
              </EuiFlexItem>

              <EuiFlexItem>
                <EuiText size="xs">
                  <strong>Source</strong>
                </EuiText>
                <EuiSpacer size="xs" />
                <EuiText size="s" style={{ textTransform: 'capitalize' }}>
                  {selectedEvent.source || 'unknown'}
                </EuiText>
              </EuiFlexItem>

              <EuiFlexItem>
                <EuiFlexGroup gutterSize="m">
                  <EuiFlexItem>
                    <EuiText size="xs">
                      <strong>Source IP</strong>
                    </EuiText>
                    <EuiSpacer size="xs" />
                    <EuiText size="s" style={{ fontFamily: 'monospace' }}>
                      {selectedEvent.src_ip || selectedEvent.source_ip || '-'}
                    </EuiText>
                  </EuiFlexItem>
                  <EuiFlexItem>
                    <EuiText size="xs">
                      <strong>Destination IP</strong>
                    </EuiText>
                    <EuiSpacer size="xs" />
                    <EuiText size="s" style={{ fontFamily: 'monospace' }}>
                      {selectedEvent.dest_ip || selectedEvent.destination_ip || '-'}
                    </EuiText>
                  </EuiFlexItem>
                </EuiFlexGroup>
              </EuiFlexItem>

              {(selectedEvent.src_port || selectedEvent.dest_port) && (
                <EuiFlexItem>
                  <EuiFlexGroup gutterSize="m">
                    <EuiFlexItem>
                      <EuiText size="xs">
                        <strong>Source Port</strong>
                      </EuiText>
                      <EuiSpacer size="xs" />
                      <EuiText size="s" style={{ fontFamily: 'monospace' }}>
                        {selectedEvent.src_port || '-'}
                      </EuiText>
                    </EuiFlexItem>
                    <EuiFlexItem>
                      <EuiText size="xs">
                        <strong>Destination Port</strong>
                      </EuiText>
                      <EuiSpacer size="xs" />
                      <EuiText size="s" style={{ fontFamily: 'monospace' }}>
                        {selectedEvent.dest_port || '-'}
                      </EuiText>
                    </EuiFlexItem>
                  </EuiFlexGroup>
                </EuiFlexItem>
              )}

              {selectedEvent.protocol && (
                <EuiFlexItem>
                  <EuiText size="xs">
                    <strong>Protocol</strong>
                  </EuiText>
                  <EuiSpacer size="xs" />
                  <EuiText size="s">
                    {selectedEvent.protocol || selectedEvent.proto || '-'}
                  </EuiText>
                </EuiFlexItem>
              )}

              {selectedEvent.category && (
                <EuiFlexItem>
                  <EuiText size="xs">
                    <strong>Category</strong>
                  </EuiText>
                  <EuiSpacer size="xs" />
                  <EuiText size="s">
                    {selectedEvent.category}
                  </EuiText>
                </EuiFlexItem>
              )}

              {(selectedEvent.agent_name || selectedEvent.agent?.name) && (
                <EuiFlexItem>
                  <EuiText size="xs">
                    <strong>Agent</strong>
                  </EuiText>
                  <EuiSpacer size="xs" />
                  <EuiText size="s">
                    {selectedEvent.agent_name || selectedEvent.agent?.name || '-'}
                  </EuiText>
                </EuiFlexItem>
              )}

              {(selectedEvent.rule_id || selectedEvent.signature_id) && (
                <EuiFlexItem>
                  <EuiText size="xs">
                    <strong>Rule / Signature ID</strong>
                  </EuiText>
                  <EuiSpacer size="xs" />
                  <EuiText size="s">
                    {selectedEvent.rule_id || selectedEvent.signature_id || '-'}
                  </EuiText>
                </EuiFlexItem>
              )}

              {selectedEvent.rule?.mitre && (
                <EuiFlexItem>
                  <EuiText size="xs">
                    <strong>MITRE ATT&CK</strong>
                  </EuiText>
                  <EuiSpacer size="xs" />
                  <EuiFlexGroup direction="column" gutterSize="xs">
                    {selectedEvent.rule.mitre.tactic && (
                      <EuiFlexItem>
                        <EuiText size="s">
                          <span style={{ color: '#98A2B3' }}>Tactic: </span>
                          {Array.isArray(selectedEvent.rule.mitre.tactic)
                            ? selectedEvent.rule.mitre.tactic.join(', ')
                            : selectedEvent.rule.mitre.tactic}
                        </EuiText>
                      </EuiFlexItem>
                    )}
                    {selectedEvent.rule.mitre.technique && (
                      <EuiFlexItem>
                        <EuiText size="s">
                          <span style={{ color: '#98A2B3' }}>Technique: </span>
                          {Array.isArray(selectedEvent.rule.mitre.technique)
                            ? selectedEvent.rule.mitre.technique.join(', ')
                            : selectedEvent.rule.mitre.technique}
                        </EuiText>
                      </EuiFlexItem>
                    )}
                  </EuiFlexGroup>
                </EuiFlexItem>
              )}

              <EuiFlexItem>
                <EuiText size="xs">
                  <strong>Full Event Data</strong>
                </EuiText>
                <EuiSpacer size="s" />
                <EuiCodeBlock language="json" fontSize="s" paddingSize="m" isCopyable overflowHeight={300}>
                  {JSON.stringify(selectedEvent, null, 2)}
                </EuiCodeBlock>
              </EuiFlexItem>
            </EuiFlexGroup>
          </EuiModalBody>
        </EuiModal>
      )}
    </EuiPanel>
  );
};

export default AlertsSummaryCard;
