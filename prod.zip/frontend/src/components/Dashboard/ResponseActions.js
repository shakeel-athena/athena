import React from 'react';
import {
  EuiPanel,
  EuiFlexGroup,
  EuiFlexItem,
  EuiText,
  EuiProgress,
  EuiButton,
  EuiSpacer,
  EuiIcon
} from '@elastic/eui';
import { Shield, Clock, AlertCircle } from 'lucide-react';

const ResponseActions = ({ data }) => {
  const getActionIcon = (actionName) => {
    const icons = {
      block_ip: Shield,
      virtual_patch: Shield,
      challenge: AlertCircle,
      rate_limit_subnet: Clock,
      block_asn: Shield,
      geo_block: Shield,
    };
    const Icon = icons[actionName] || Shield;
    return <Icon style={{ width: '16px', height: '16px' }} />;
  };

  const getProviderColor = (provider) => {
    const colors = {
      waf: 'primary',
      firewall: 'accent',
    };
    return colors[provider] || 'subdued';
  };

  const getSuccessRateColor = (rate) => {
    if (rate >= 98) return 'success';
    if (rate >= 95) return 'warning';
    return 'danger';
  };

  return (
    <EuiFlexGroup direction="column" gutterSize="none">
      {data && data.length > 0 ? (
        <>
          <EuiFlexItem>
            {data.slice(0, 5).map((action, index) => (
              <div key={index}>
                <EuiPanel paddingSize="m" color="transparent" hasBorder={false}>
                  <EuiFlexGroup alignItems="center" justifyContent="spaceBetween" gutterSize="m">
                    <EuiFlexItem>
                      <EuiFlexGroup alignItems="center" gutterSize="s">
                        <EuiFlexItem grow={false}>
                          <EuiPanel color={getProviderColor(action.provider)} paddingSize="s">
                            {getActionIcon(action.action)}
                          </EuiPanel>
                        </EuiFlexItem>

                        <EuiFlexItem>
                          <EuiText size="s">
                            <strong style={{ textTransform: 'capitalize' }}>
                              {action.action.replace(/_/g, ' ')}
                            </strong>
                          </EuiText>
                          <EuiSpacer size="xs" />
                          <EuiFlexGroup alignItems="center" gutterSize="xs" wrap>
                            <EuiFlexItem grow={false}>
                              <EuiText size="xs" color="subdued" style={{ textTransform: 'capitalize' }}>
                                <strong>{action.provider}</strong>
                              </EuiText>
                            </EuiFlexItem>
                            <EuiFlexItem grow={false}>
                              <EuiText size="xs" color="subdued">•</EuiText>
                            </EuiFlexItem>
                            <EuiFlexItem grow={false}>
                              <EuiText size="xs" color="subdued">{action.count} executions</EuiText>
                            </EuiFlexItem>
                            <EuiFlexItem grow={false}>
                              <EuiText size="xs" color="subdued">•</EuiText>
                            </EuiFlexItem>
                            <EuiFlexItem grow={false}>
                              <EuiText size="xs" color="subdued">~{action.avg_time_ms}ms avg</EuiText>
                            </EuiFlexItem>
                          </EuiFlexGroup>
                        </EuiFlexItem>
                      </EuiFlexGroup>
                    </EuiFlexItem>

                    <EuiFlexItem grow={false}>
                      <EuiFlexGroup direction="column" alignItems="flexEnd" gutterSize="none">
                        <EuiFlexItem>
                          <EuiText size="m" color={getSuccessRateColor(action.success_rate)}>
                            <strong>{action.success_rate}%</strong>
                          </EuiText>
                        </EuiFlexItem>
                        <EuiFlexItem>
                          <EuiText size="xs" color="subdued">success rate</EuiText>
                        </EuiFlexItem>
                      </EuiFlexGroup>
                    </EuiFlexItem>
                  </EuiFlexGroup>

                  <EuiSpacer size="s" />

                  {/* Progress bar for success rate */}
                  <EuiFlexGroup alignItems="center" justifyContent="spaceBetween" gutterSize="xs">
                    <EuiFlexItem grow={false}>
                      <EuiText size="xs" color="subdued">
                        <strong>Success Rate</strong>
                      </EuiText>
                    </EuiFlexItem>
                    <EuiFlexItem grow={false}>
                      <EuiText size="xs" color="subdued">
                        <strong>{action.success_rate}%</strong>
                      </EuiText>
                    </EuiFlexItem>
                  </EuiFlexGroup>
                  <EuiSpacer size="xs" />
                  <EuiProgress
                    value={action.success_rate}
                    max={100}
                    size="s"
                    color={getSuccessRateColor(action.success_rate)}
                  />
                </EuiPanel>
                {index < data.slice(0, 5).length - 1 && (
                  <div style={{ borderBottom: '1px solid #343741' }} />
                )}
              </div>
            ))}
          </EuiFlexItem>

          <EuiFlexItem>
            <EuiPanel color="subdued" paddingSize="m">
              <EuiButton fullWidth color="text" size="s">
                View all response actions →
              </EuiButton>
            </EuiPanel>
          </EuiFlexItem>
        </>
      ) : (
        <EuiFlexItem>
          <EuiPanel paddingSize="l" color="transparent">
            <EuiFlexGroup alignItems="center" justifyContent="center" style={{ minHeight: '200px' }}>
              <EuiFlexItem grow={false}>
                <EuiFlexGroup direction="column" alignItems="center" gutterSize="s">
                  <EuiFlexItem>
                    <Shield style={{ width: '40px', height: '40px', opacity: 0.5 }} />
                  </EuiFlexItem>
                  <EuiFlexItem>
                    <EuiText size="s" color="subdued">No recent response actions</EuiText>
                  </EuiFlexItem>
                </EuiFlexGroup>
              </EuiFlexItem>
            </EuiFlexGroup>
          </EuiPanel>
        </EuiFlexItem>
      )}
    </EuiFlexGroup>
  );
};

export default ResponseActions;
