import React from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import {
  EuiSideNav,
  EuiButtonEmpty,
  EuiIcon,
  EuiFlexGroup,
  EuiFlexItem,
  EuiText,
  EuiTitle,
} from '@elastic/eui';
import DarkOwlLogo from '../../artifacts/Dark Owl Logo.png';

// Unified navigation - organized by function with nested structure
const navigation = [
  // Dashboard (nested)
  {
    name: 'Dashboard & Analytics',
    icon: 'dashboardApp',
    children: [
      { name: 'Summary Dashboard', href: '/dashboard', icon: 'visLine' },
      // { name: 'Threat Topology', href: '/detection/network-topology', icon: 'graphApp' },
      { name: 'NIDS Dashboard', href: '/detection/nids', icon: 'securitySignalDetected' },
      
      { name: 'System Analytics', href: '/system-health', icon: 'compute' },
      
    ],
  },

  // Alerts (nested)
  {
    name: 'Alert Management',
    icon: 'alert',
    children: [
      { name: 'All Alerts(NIDS & EDR)', href: '/detection/events', icon: 'securityApp' },
      // { name: 'Agent Summary', href: '/admin/agent-control', icon: 'compute' },
      { name: 'Mute Rules Management', href: '/admin/mute-rules', icon: 'bellSlash' },
      
    ],
  },


  // Network Management (nested)
  {
    name: 'Response Management',
    icon: 'globe',
    children: [
      { name: 'Firewall & WAF (Unified)', href: '/security/firewall-waf', icon: 'securityApp', badge: 'NEW' },
      { name: 'Firewall Management', href: '/firewall', icon: 'lock' },
      { name: 'Active Response', href: '/active-response', icon: 'dashboardApp' },
      { name: 'WAF Signatures', href: '/waf-signatures', icon: 'securityApp' },
      { name: 'Blocked IPs Management', href: '/admin/blocked-ips', icon: 'securitySignalResolved' },
    ],
  },

  // Admin (nested)
  {
    name: 'Admin',
    icon: 'user',
    children: [
      { name: 'User Management', href: '/admin/users', icon: 'users' },
      { name: 'Role Management', href: '/admin/roles', icon: 'securityApp' },
    ],
  },
];

const Sidebar = ({ isOpen, onClose }) => {
  const location = useLocation();
  const navigate = useNavigate();

  // Convert navigation structure to EUI SideNav format
  const sideNavItems = navigation.map(item => {
    const isExpanded = item.children ? item.children.some(child => 
      location.pathname === child.href || 
      (child.href === '/dashboard' && (location.pathname === '/dashboard' || location.pathname === '/')) ||
      (child.href !== '/dashboard' && location.pathname.startsWith(child.href))
    ) : false;

    const hasActiveChild = item.children ? item.children.some(child => 
      location.pathname === child.href || 
      (child.href === '/dashboard' && (location.pathname === '/dashboard' || location.pathname === '/')) ||
      (child.href !== '/dashboard' && location.pathname.startsWith(child.href))
    ) : false;

    if (item.children) {
      return {
        id: item.name,
        name: item.name,
        icon: <EuiIcon type={item.icon} size="m" />,
        isSelected: hasActiveChild,
        forceOpen: isExpanded,
        items: item.children.map(child => ({
          id: child.name,
          name: child.name,
          icon: <EuiIcon type={child.icon} size="s" />,
          isSelected: location.pathname === child.href ||
            (child.href === '/dashboard' && (location.pathname === '/dashboard' || location.pathname === '/')) ||
            (child.href !== '/dashboard' && location.pathname.startsWith(child.href)),
          onClick: () => {
            navigate(child.href);
            if (onClose) onClose();
          },
        })),
      };
    }

    return {
      id: item.name,
      name: item.name,
      icon: <EuiIcon type={item.icon} size="m" />,
      isSelected: location.pathname === item.href || (item.href === '/dashboard' && location.pathname === '/'),
      onClick: () => {
        navigate(item.href);
        if (onClose) onClose();
      },
    };
  });

  const renderLogo = () => (
    <EuiFlexGroup alignItems="center" gutterSize="s" responsive={false}>
      <EuiFlexItem grow={false}>
        <img
          src={DarkOwlLogo}
          alt="Athena Logo"
          style={{ width: '40px', height: '40px', objectFit: 'contain' }}
        />
      </EuiFlexItem>
      <EuiFlexItem>
        <div>
          <EuiTitle size="s">
            <h1 style={{ color: '#fff', margin: 0 }}>Athena</h1>
          </EuiTitle>
          <EuiText size="xs" color="subdued">
            <p style={{ margin: 0 }}>Security Platform</p>
          </EuiText>
        </div>
      </EuiFlexItem>
    </EuiFlexGroup>
  );

  const renderSystemStatus = () => (
    <EuiFlexGroup alignItems="center" gutterSize="s" responsive={false}>
      <EuiFlexItem grow={false}>
        <EuiIcon type="check" color="success" />
      </EuiFlexItem>
      <EuiFlexItem>
        <div>
          <EuiText size="s" color="default">
            <p style={{ fontWeight: 500, margin: 0 }}>System Online</p>
          </EuiText>
          <EuiText size="xs" color="subdued">
            <p style={{ margin: 0 }}>All services operational</p>
          </EuiText>
        </div>
      </EuiFlexItem>
    </EuiFlexGroup>
  );

  // Desktop Sidebar
  const DesktopSidebar = () => (
    <div style={{
      display: 'flex',
      flexDirection: 'column',
      width: '100%',
      height: '100%',
      backgroundColor: '#1a1a1a',
      borderRight: '1px solid #333'
    }}>
      {/* Logo */}
      <div style={{ padding: '20px 16px 24px 16px', flexShrink: 0 }}>
        {renderLogo()}
      </div>

      {/* Navigation */}
      <div style={{
        flex: 1,
        padding: '0 8px',
        overflowY: 'auto',
        overflowX: 'hidden'
      }}>
        <EuiSideNav
          items={sideNavItems}
          style={{ backgroundColor: 'transparent' }}
        />
      </div>

      {/* System Status */}
      <div style={{
        padding: '16px',
        borderTop: '1px solid #333',
        flexShrink: 0
      }}>
        {renderSystemStatus()}
      </div>
    </div>
  );

  // Mobile Sidebar (for flyout)
  const MobileSidebar = () => (
    <div style={{ display: 'flex', flexDirection: 'column', height: '100%' }}>
      {/* Mobile Header */}
      <div style={{ 
        display: 'flex', 
        alignItems: 'center', 
        justifyContent: 'space-between',
        padding: '16px',
        borderBottom: '1px solid #333'
      }}>
        {renderLogo()}
        <EuiButtonEmpty
          onClick={onClose}
          iconType="cross"
          aria-label="Close navigation"
        />
      </div>

      {/* Mobile Navigation */}
      <div style={{ flex: 1, padding: '16px 8px', overflowY: 'auto' }}>
        <EuiSideNav
          items={sideNavItems}
          style={{ backgroundColor: 'transparent' }}
        />
      </div>

      {/* Mobile System Status */}
      <div style={{ 
        padding: '16px', 
        borderTop: '1px solid #333',
        flexShrink: 0
      }}>
        {renderSystemStatus()}
      </div>
    </div>
  );

  return (
    <>
      {/* Desktop Sidebar - shown when not in mobile flyout */}
      {!onClose || onClose.toString() === '() => {}' ? (
        <DesktopSidebar />
      ) : (
        /* Mobile Sidebar (used in flyout) */
        <MobileSidebar />
      )}
    </>
  );
};

export default Sidebar;
