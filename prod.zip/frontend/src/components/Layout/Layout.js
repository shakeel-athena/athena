import React, { useState } from 'react';
import { useLocation } from 'react-router-dom';
import {
  EuiFlyout,
  EuiFlyoutHeader,
  EuiFlyoutBody,
  EuiTitle,
} from '@elastic/eui';
import Sidebar from './Sidebar';
import Header from './Header';
import PallasAssistant from '../Pallas/PallasAssistant';

const Layout = ({ children }) => {
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const location = useLocation();

  return (
    <div style={{
      display: 'flex',
      minHeight: '100vh',
      backgroundColor: '#0d0d0d'
    }}>
      {/* Desktop Sidebar - Always visible on desktop */}
      <div style={{
        width: '256px',
        flexShrink: 0,
        position: 'sticky',
        top: 0,
        height: '100vh',
        overflow: 'hidden'
      }}>
        <Sidebar isOpen={true} onClose={() => {}} />
      </div>

      {/* Main content area */}
      <div style={{
        flex: 1,
        display: 'flex',
        flexDirection: 'column',
        minWidth: 0
      }}>
        {/* Header */}
        <div style={{ flexShrink: 0 }}>
          <Header
            onMenuClick={() => setSidebarOpen(true)}
            currentPath={location.pathname}
            showMenuButton={false}
          />
        </div>

        {/* Page content */}
        <div style={{
          flex: 1,
          padding: '24px',
          overflowY: 'auto'
        }}>
          {children}
        </div>
      </div>

      {/* Pallas AI Assistant */}
      <PallasAssistant />

      {/* Mobile sidebar flyout - Slides from left */}
      {sidebarOpen && (
        <EuiFlyout
          ownFocus
          onClose={() => setSidebarOpen(false)}
          side="left"
          size="s"
          style={{ maxWidth: '280px' }}
          outsideClickCloses={true}
        >
          <EuiFlyoutHeader hasBorder>
            <EuiTitle size="s">
              <h2>Navigation</h2>
            </EuiTitle>
          </EuiFlyoutHeader>
          <EuiFlyoutBody>
            <Sidebar isOpen={sidebarOpen} onClose={() => setSidebarOpen(false)} />
          </EuiFlyoutBody>
        </EuiFlyout>
      )}
    </div>
  );
};

export default Layout;
