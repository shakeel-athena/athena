import React from 'react';
import {
  EuiHeader,
  EuiHeaderSectionItemButton,
  EuiFieldSearch,
  EuiIcon,
  EuiFlexGroup,
  EuiFlexItem,
  EuiText,
  EuiTitle,
  EuiNotificationBadge,
} from '@elastic/eui';
import { format } from 'date-fns';
import UserProfile from '../Auth/UserProfile';

const Header = ({ onMenuClick, currentPath }) => {
  const currentTime = new Date();
  
  const getPageTitle = (path) => {
    const titles = {
      '/': 'Security Operations Dashboard',
      '/dashboard': 'Security Operations Dashboard',
      '/alerts': 'Security Alerts',
      '/responses': 'Response Actions',
      '/policies': 'Policy Management',
      '/intelligence': 'Threat Intelligence',
      '/audit': 'Audit Trail',
      '/settings': 'System Settings',
    };
    return titles[path] || 'Athena Network Response';
  };

  const renderPageTitle = () => (
    <EuiFlexGroup direction="column" gutterSize="xs">
      <EuiFlexItem>
        <EuiTitle size="s">
          <h1 style={{ color: '#fff', margin: 0 }}>
            {getPageTitle(currentPath)}
          </h1>
        </EuiTitle>
      </EuiFlexItem>
      <EuiFlexItem>
        <EuiText size="xs" color="subdued">
          <p style={{ margin: 0 }}>
            {format(currentTime, 'EEEE, MMMM do, yyyy • HH:mm:ss')}
          </p>
        </EuiText>
      </EuiFlexItem>
    </EuiFlexGroup>
  );

  const renderSearchBar = () => (
    <EuiFieldSearch
      placeholder="Search alerts, IPs, signatures..."
      aria-label="Search"
      style={{ maxWidth: '400px' }}
    />
  );

  const renderSystemStatus = () => (
    <EuiFlexGroup alignItems="center" gutterSize="s" responsive={false}>
      <EuiFlexItem grow={false}>
        <EuiIcon type="check" color="success" />
      </EuiFlexItem>

    </EuiFlexGroup>
  );

  return (
    <EuiHeader
      sections={[
        {
          items: [
            // Mobile menu button
            <EuiHeaderSectionItemButton
              key="menu"
              onClick={onMenuClick}
              aria-label="Toggle navigation"
              style={{ display: 'none' }} // Hidden on desktop, shown on mobile via CSS
            >
              <EuiIcon type="menu" size="m" />
            </EuiHeaderSectionItemButton>,
            // Page title
            <div key="title" style={{ marginLeft: '16px' }}>
              {renderPageTitle()}
            </div>,
          ],
          borders: 'right',
        },
        {
          items: [
            // Search bar
            <div key="search" style={{ flex: 1, maxWidth: '400px', margin: '0 32px' }}>
              {renderSearchBar()}
            </div>,
          ],
        },
        {
          items: [
            // Refresh button
            <EuiHeaderSectionItemButton
              key="refresh"
              onClick={() => window.location.reload()}
              aria-label="Refresh"
            >
              <EuiIcon type="refresh" size="m" />
            </EuiHeaderSectionItemButton>,
            // Notifications
            <EuiHeaderSectionItemButton
              key="notifications"
              onClick={() => console.log('Notifications clicked')}
              aria-label="Notifications"
              notification={3}
            >
              <EuiIcon type="bell" size="m" />
            </EuiHeaderSectionItemButton>,
            // System status
            <div key="status" style={{ margin: '0 16px' }}>
              {renderSystemStatus()}
            </div>,
            // User Profile
            <div key="profile">
              <UserProfile />
            </div>,
          ],
        },
      ]}
      style={{
        backgroundColor: '#1a1a1a',
        borderBottom: '1px solid #333',
        padding: '0 16px',
      }}
    />
  );
};

export default Header;
