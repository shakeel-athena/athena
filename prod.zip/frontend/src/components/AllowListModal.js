import React, { useState, useEffect, useCallback } from 'react';
import toast from 'react-hot-toast';
import {
  EuiModal,
  EuiModalHeader,
  EuiModalHeaderTitle,
  EuiModalBody,
  EuiModalFooter,
  EuiButton,
  EuiButtonEmpty,
  EuiFieldText,
  EuiIcon,
  EuiFlexGroup,
  EuiFlexItem,
  EuiText,
  EuiTitle,
  EuiSpacer,
  EuiPanel,
  EuiBadge,
  EuiConfirmModal,
} from '@elastic/eui';
import { getRuleMapping, getAllowListData } from '../services/api';

const AllowListModal = ({ isOpen, ruleGroup, ruleName, onClose, onSave }) => {
  const [ipList, setIpList] = useState([]);
  const [domainList, setDomainList] = useState([]);
  const [newIp, setNewIp] = useState('');
  const [newDomain, setNewDomain] = useState('');
  const [existingRule, setExistingRule] = useState(false);
  const [showConfirmation, setShowConfirmation] = useState(false);
  const [isSaving, setIsSaving] = useState(false);
  const [lastSavedTime, setLastSavedTime] = useState(0);

  const loadExistingRule = useCallback(async () => {
    if (!isOpen || !ruleGroup || !ruleName) return;
    
    console.log(`Loading existing rule data for ${ruleGroup}/${ruleName} (lastSaved: ${lastSavedTime})`);
    
    try {
      // Get rule mapping to check if rule exists
      const mappingResponse = await getRuleMapping(ruleGroup, ruleName);
      console.log('Mapping response:', mappingResponse);
      
      if (mappingResponse && mappingResponse.exists) {
        setExistingRule(true);
        
        // Get actual allow list data
        const allowListResponse = await getAllowListData(ruleGroup, ruleName);
        console.log('Allow list response:', allowListResponse);
        if (allowListResponse) {
          console.log('Setting IP list:', allowListResponse.ipList);
          console.log('Setting domain list:', allowListResponse.domainList);
          setIpList(allowListResponse.ipList || []);
          setDomainList(allowListResponse.domainList || []);
        }
      } else {
        console.log('No existing rule found, setting empty lists');
        setExistingRule(false);
        setIpList([]);
        setDomainList([]);
      }
    } catch (error) {
      console.error('Error loading existing rule:', error);
      toast.error('Failed to load existing rule data');
    }
  }, [isOpen, ruleGroup, ruleName, lastSavedTime]);

  useEffect(() => {
    loadExistingRule();
  }, [loadExistingRule]);

  const handleAddIp = () => {
    if (!newIp.trim()) return;
    
    // Basic validation for IPv4 CIDR format
    const ipRegex = /^(\d{1,3}\.){3}\d{1,3}(\/\d{1,2})?$/;
    let formattedIp = newIp.trim();
    
    // Add /32 if no CIDR is specified
    if (!formattedIp.includes('/')) {
      formattedIp += '/32';
    }
    
    if (!ipRegex.test(formattedIp)) {
      toast.error('Please enter a valid IPv4 address (e.g., 192.168.1.1/32)');
      return;
    }
    
    if (ipList.includes(formattedIp)) {
      toast.error('IP address already exists in the list');
      return;
    }
    
    setIpList([...ipList, formattedIp]);
    setNewIp('');
  };

  const handleRemoveIp = (ipToRemove) => {
    setIpList(ipList.filter(ip => ip !== ipToRemove));
  };

  const handleAddDomain = () => {
    if (!newDomain.trim()) return;
    
    const domain = newDomain.trim();
    
    if (domainList.includes(domain)) {
      toast.error('Domain already exists in the list');
      return;
    }
    
    setDomainList([...domainList, domain]);
    setNewDomain('');
  };

  const handleRemoveDomain = (domainToRemove) => {
    setDomainList(domainList.filter(domain => domain !== domainToRemove));
  };

  const handleSave = () => {
    if (ipList.length === 0 && domainList.length === 0) {
      toast.error('Please add at least one IP address or domain');
      return;
    }
    
    setShowConfirmation(true);
  };

  const handleCancelSave = () => {
    setShowConfirmation(false);
  };

  const handleConfirmSave = async () => {
    setIsSaving(true);
    try {
      await onSave(ruleGroup, ruleName, ipList, domainList, existingRule);
      toast.success(existingRule ? 'Allow list updated successfully' : 'Allow list created successfully');
      setShowConfirmation(false);
      
      // Mark that we've saved data and need to refresh
      setLastSavedTime(Date.now());
      console.log('Save successful, marked for refresh on next open');
      
      // Small delay to ensure backend processing is complete
      setTimeout(() => {
        onClose();
      }, 500);
    } catch (error) {
      console.error('Save error:', error);
      toast.error('Failed to save allow list');
    } finally {
      setIsSaving(false);
    }
  };

  if (!isOpen) return null;

  console.log("AllowListModal rendering with:", { isOpen, ruleGroup, ruleName });
  console.log("Modal should be visible:", isOpen);
  console.log("AllowListModal JSX is rendering");

  return (
    <>
      <EuiModal onClose={onClose} style={{ maxWidth: '1200px' }}>
        <EuiModalHeader>
          <EuiModalHeaderTitle>
            <EuiFlexGroup alignItems="center" gutterSize="s">
              <EuiFlexItem>
                <EuiIcon type="list" size="m" />
              </EuiFlexItem>
              <EuiFlexItem>
                <h2>Allow List for {ruleName}</h2>
              </EuiFlexItem>
            </EuiFlexGroup>
          </EuiModalHeaderTitle>
        </EuiModalHeader>

        <EuiModalBody>
          <EuiFlexGroup>
            {/* IP Addresses Column */}
            <EuiFlexItem>
              <EuiTitle size="s">
                <h3>IP Addresses</h3>
              </EuiTitle>
              <EuiSpacer size="m" />
              
              <EuiFlexGroup gutterSize="s">
                <EuiFlexItem>
                  <EuiFieldText
                    value={newIp}
                    onChange={(e) => setNewIp(e.target.value)}
                    placeholder="Enter IPv4 address (e.g., 192.168.1.1/32)"
                    onKeyPress={(e) => e.key === 'Enter' && handleAddIp()}
                    aria-label="IP address"
                  />
                </EuiFlexItem>
                <EuiFlexItem grow={false}>
                  <EuiButton onClick={handleAddIp} size="s">
                    Add IP
                  </EuiButton>
                </EuiFlexItem>
              </EuiFlexGroup>
              
              <EuiSpacer size="m" />
              
              <EuiPanel style={{ maxHeight: '300px', overflowY: 'auto' }}>
                {ipList.length === 0 ? (
                  <EuiText color="subdued" textAlign="center">
                    <p>No IP addresses added</p>
                  </EuiText>
                ) : (
                  <EuiFlexGroup direction="column" gutterSize="s">
                    {ipList.map((ip, index) => (
                      <EuiFlexItem key={index}>
                        <EuiFlexGroup alignItems="center" justifyContent="spaceBetween" responsive={false}>
                          <EuiFlexItem>
                            <EuiBadge color="hollow">{ip}</EuiBadge>
                          </EuiFlexItem>
                          <EuiFlexItem grow={false}>
                            <EuiButtonEmpty
                              onClick={() => handleRemoveIp(ip)}
                              size="s"
                              color="danger"
                              iconType="cross"
                            >
                              Remove
                            </EuiButtonEmpty>
                          </EuiFlexItem>
                        </EuiFlexGroup>
                      </EuiFlexItem>
                    ))}
                  </EuiFlexGroup>
                )}
              </EuiPanel>
            </EuiFlexItem>

            {/* Domains Column */}
            <EuiFlexItem>
              <EuiTitle size="s">
                <h3>Domains</h3>
              </EuiTitle>
              <EuiSpacer size="m" />
              
              <EuiFlexGroup gutterSize="s">
                <EuiFlexItem>
                  <EuiFieldText
                    value={newDomain}
                    onChange={(e) => setNewDomain(e.target.value)}
                    placeholder="Enter domain (e.g., example.com)"
                    onKeyPress={(e) => e.key === 'Enter' && handleAddDomain()}
                    aria-label="Domain"
                  />
                </EuiFlexItem>
                <EuiFlexItem grow={false}>
                  <EuiButton onClick={handleAddDomain} size="s">
                    Add Domain
                  </EuiButton>
                </EuiFlexItem>
              </EuiFlexGroup>
              
              <EuiSpacer size="m" />
              
              <EuiPanel style={{ maxHeight: '300px', overflowY: 'auto' }}>
                {domainList.length === 0 ? (
                  <EuiText color="subdued" textAlign="center">
                    <p>No domains added</p>
                  </EuiText>
                ) : (
                  <EuiFlexGroup direction="column" gutterSize="s">
                    {domainList.map((domain, index) => (
                      <EuiFlexItem key={index}>
                        <EuiFlexGroup alignItems="center" justifyContent="spaceBetween" responsive={false}>
                          <EuiFlexItem>
                            <EuiBadge color="hollow">{domain}</EuiBadge>
                          </EuiFlexItem>
                          <EuiFlexItem grow={false}>
                            <EuiButtonEmpty
                              onClick={() => handleRemoveDomain(domain)}
                              size="s"
                              color="danger"
                              iconType="cross"
                            >
                              Remove
                            </EuiButtonEmpty>
                          </EuiFlexItem>
                        </EuiFlexGroup>
                      </EuiFlexItem>
                    ))}
                  </EuiFlexGroup>
                )}
              </EuiPanel>
            </EuiFlexItem>
          </EuiFlexGroup>
        </EuiModalBody>

        <EuiModalFooter>
          <EuiButtonEmpty onClick={onClose}>Cancel</EuiButtonEmpty>
          <EuiButton
            onClick={handleSave}
            disabled={isSaving}
            isLoading={isSaving}
            fill
          >
            Save
          </EuiButton>
        </EuiModalFooter>
      </EuiModal>

      {/* Confirmation Modal */}
      <EuiConfirmModal
        title="Confirm Action"
        onCancel={handleCancelSave}
        onConfirm={handleConfirmSave}
        confirmDisabled={isSaving}
        isLoading={isSaving}
        cancelButtonText="Cancel"
        confirmButtonText="Confirm"
        defaultFocusedButton="confirm"
      >
        <p>
          {existingRule 
            ? 'Are you sure you want to update the existing allow list rule?' 
            : 'Are you sure you want to create a new allow list rule?'}
        </p>
      </EuiConfirmModal>
    </>
  );
};

export default AllowListModal;
