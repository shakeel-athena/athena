import React, { useState, useEffect, useRef, useCallback } from 'react';
import {
  EuiPopover,
  EuiPanel,
  EuiText,
  EuiSpacer,
  EuiFlexGroup,
  EuiFlexItem,
  EuiBadge,
  EuiLoadingSpinner,
  EuiButtonEmpty,
  EuiIcon,
  EuiLink,
  EuiCallOut
} from '@elastic/eui';
import { ipEnrichmentCache } from '../utils/ipEnrichmentCache';

const IPEnrichmentTooltip = ({
  ipAddress,
  children,
  placement = 'top',
  isPrivateIP = false
}) => {
  const [isPopoverOpen, setIsPopoverOpen] = useState(false);
  const [enrichmentData, setEnrichmentData] = useState(null);
  const [statusData, setStatusData] = useState(null);
  const [loading, setLoading] = useState(false);
  const [statusLoading, setStatusLoading] = useState(false);
  const [error, setError] = useState(null);
  const [isHoveringPopover, setIsHoveringPopover] = useState(false);
  const closeTimeoutRef = useRef(null);

  // Use refs to track fetch state without causing dependency issues
  const enrichmentFetchedRef = useRef(false);
  const statusFetchedRef = useRef(false);

  // Reset refs when IP changes
  useEffect(() => {
    enrichmentFetchedRef.current = false;
    statusFetchedRef.current = false;
  }, [ipAddress]);

  // Memoized fetch enrichment function
  const fetchEnrichment = useCallback(async () => {
    // Check shared cache first
    const cached = ipEnrichmentCache.getEnrichment(ipAddress);
    if (cached) {
      setEnrichmentData(cached);
      return;
    }

    // Check if there's already a pending request for this IP
    const pendingRequest = ipEnrichmentCache.getPendingEnrichmentRequest(ipAddress);
    if (pendingRequest) {
      // Wait for the pending request to complete
      try {
        const data = await pendingRequest;
        setEnrichmentData(data);
      } catch (err) {
        if (err.message !== 'PRIVATE_IP') {
          setError(err.message || 'Failed to fetch enrichment data');
        }
      }
      return;
    }

    // Create new request
    const requestPromise = (async () => {
      try {
        setLoading(true);
        setError(null);
        const response = await fetch(`/api/enrich-ip/${ipAddress}`);

        // Parse JSON response regardless of status
        const data = await response.json();

        if (!response.ok) {
          // Handle error responses
          throw new Error(data.error || `Failed to fetch: ${response.status}`);
        }

        // Store data for both public and private IPs
        // Private IPs will have internal_context but no external threat intel
        setEnrichmentData(data);

        // Cache the result in shared cache
        ipEnrichmentCache.setEnrichment(ipAddress, data);

        return data;
      } catch (err) {
        if (err.message !== 'PRIVATE_IP') {
          setError(err.message || 'Failed to fetch enrichment data');
        }
        throw err;
      } finally {
        setLoading(false);
      }
    })();

    // Track pending request
    ipEnrichmentCache.setPendingEnrichmentRequest(ipAddress, requestPromise);
  }, [ipAddress]);

  // Memoized fetch status function
  const fetchStatus = useCallback(async () => {
    // Check shared cache first
    const cached = ipEnrichmentCache.getStatus(ipAddress);
    if (cached) {
      setStatusData(cached);
      return;
    }

    // Check if there's already a pending request for this IP
    const pendingRequest = ipEnrichmentCache.getPendingStatusRequest(ipAddress);
    if (pendingRequest) {
      // Wait for the pending request to complete
      try {
        const data = await pendingRequest;
        setStatusData(data);
      } catch (err) {
        console.error('Failed to fetch IP status:', err);
      }
      return;
    }

    // Create new request
    const requestPromise = (async () => {
      try {
        setStatusLoading(true);
        const response = await fetch(`/api/enrich-ip/${ipAddress}/status`);
        const data = await response.json();

        if (response.ok) {
          setStatusData(data);

          // Cache the result in shared cache
          ipEnrichmentCache.setStatus(ipAddress, data);

          return data;
        }
      } catch (err) {
        console.error('Failed to fetch IP status:', err);
        throw err;
      } finally {
        setStatusLoading(false);
      }
    })();

    // Track pending request
    ipEnrichmentCache.setPendingStatusRequest(ipAddress, requestPromise);
  }, [ipAddress]);

  // Fetch data when popover opens (including for private IPs to get internal_context)
  useEffect(() => {
    if (isPopoverOpen) {
      if (!enrichmentFetchedRef.current && !enrichmentData && !loading && !error) {
        enrichmentFetchedRef.current = true;
        fetchEnrichment();
      }
      if (!statusFetchedRef.current && !statusData && !statusLoading) {
        statusFetchedRef.current = true;
        fetchStatus();
      }
    }
  }, [isPopoverOpen, enrichmentData, loading, error, statusData, statusLoading, fetchEnrichment, fetchStatus]);

  // Mouse event handlers with 300ms delay
  const handleMouseEnter = () => {
    if (closeTimeoutRef.current) {
      clearTimeout(closeTimeoutRef.current);
      closeTimeoutRef.current = null;
    }
    setIsPopoverOpen(true);
  };

  const handleMouseLeave = () => {
    closeTimeoutRef.current = setTimeout(() => {
      if (!isHoveringPopover) {
        setIsPopoverOpen(false);
      }
    }, 300);
  };

  const handlePopoverMouseEnter = () => {
    if (closeTimeoutRef.current) {
      clearTimeout(closeTimeoutRef.current);
      closeTimeoutRef.current = null;
    }
    setIsHoveringPopover(true);
    setIsPopoverOpen(true);
  };

  const handlePopoverMouseLeave = () => {
    setIsHoveringPopover(false);
    closeTimeoutRef.current = setTimeout(() => {
      setIsPopoverOpen(false);
    }, 300);
  };

  // Cleanup
  useEffect(() => {
    return () => {
      if (closeTimeoutRef.current) {
        clearTimeout(closeTimeoutRef.current);
      }
    };
  }, []);

  // Helper functions
  const getCountryFlag = (countryCode) => {
    if (!countryCode || countryCode.length !== 2) return '🌐';

    const codePoints = countryCode
      .toUpperCase()
      .split('')
      .map(char => 127397 + char.charCodeAt());
    return String.fromCodePoint(...codePoints);
  };

  const getThreatLevel = (score) => {
    if (score >= 90) return {
      color: 'danger',
      label: 'CRITICAL THREAT',
      icon: 'alert'
    };
    if (score >= 75) return {
      color: 'danger',
      label: 'HIGH RISK',
      icon: 'warning'
    };
    if (score >= 50) return {
      color: 'warning',
      label: 'MEDIUM RISK',
      icon: 'partial'
    };
    if (score >= 25) return {
      color: '#FF9830',
      label: 'LOW RISK',
      icon: 'questionInCircle'
    };
    return {
      color: 'success',
      label: 'CLEAN',
      icon: 'check'
    };
  };

  const getPanelColor = (riskLevel) => {
    switch(riskLevel) {
      case 'CRITICAL': return 'danger';
      case 'HIGH': return 'warning';
      case 'MEDIUM': return 'primary';
      default: return 'subdued';
    }
  };

  const getProgressBarColor = (score) => {
    if (score > 75) return '#BD271E';
    if (score > 50) return '#F5A700';
    if (score > 25) return '#FEC514';
    return '#54B399';
  };

  // Loading state
  const LoadingState = () => (
    <EuiPanel paddingSize="m" style={{ minWidth: '300px', textAlign: 'center' }}>
      <EuiLoadingSpinner size="l" />
      <EuiSpacer size="s" />
      <EuiText size="s" color="subdued">Loading threat intelligence...</EuiText>
    </EuiPanel>
  );

  // Error state
  const ErrorState = ({ error, onRetry }) => (
    <EuiPanel paddingSize="m" style={{ minWidth: '300px' }}>
      <EuiFlexGroup direction="column" alignItems="center" gutterSize="s">
        <EuiFlexItem>
          <EuiIcon type="alert" color="danger" size="l" />
        </EuiFlexItem>
        <EuiFlexItem>
          <EuiText size="s" color="danger" textAlign="center">
            <strong>Failed to load data</strong>
          </EuiText>
        </EuiFlexItem>
        <EuiFlexItem>
          <EuiText size="xs" color="subdued" textAlign="center">
            {error}
          </EuiText>
        </EuiFlexItem>
        <EuiFlexItem>
          <EuiButtonEmpty size="s" onClick={onRetry} iconType="refresh">
            Retry
          </EuiButtonEmpty>
        </EuiFlexItem>
      </EuiFlexGroup>
    </EuiPanel>
  );

  // Private IP notice
  const PrivateIPNotice = () => (
    <EuiPanel paddingSize="m" style={{ minWidth: '300px' }}>
      <EuiFlexGroup direction="column" alignItems="center" gutterSize="s">
        <EuiFlexItem>
          <EuiIcon type="lock" color="subdued" size="l" />
        </EuiFlexItem>
        <EuiFlexItem>
          <EuiText size="s" color="subdued" textAlign="center">
            <strong>Private IP Address</strong>
          </EuiText>
        </EuiFlexItem>
        <EuiFlexItem>
          <EuiText size="xs" color="subdued" textAlign="center">
            Threat intelligence not available for private IPs
          </EuiText>
        </EuiFlexItem>
      </EuiFlexGroup>
    </EuiPanel>
  );

  // Main content renderer
  const renderContent = () => {
    if (loading) return <LoadingState />;
    if (error) return <ErrorState error={error} onRetry={fetchEnrichment} />;
    if (!enrichmentData) return null;

    const geo = enrichmentData.geolocation || {};
    const threat = enrichmentData.threat_intelligence || {};
    const isPrivate = enrichmentData.is_private === true;
    const countryFlag = getCountryFlag(geo.country_code);
    const threatLevel = getThreatLevel(threat.abuseipdb_score || 0);

    return (
      <EuiPanel paddingSize="m" style={{ minWidth: '350px', maxWidth: '400px' }}>
        {/* Header Section */}
        <EuiFlexGroup alignItems="center" gutterSize="s" responsive={false}>
          <EuiFlexItem grow={false}>
            <EuiText size="m">
              <span style={{ fontSize: '20px' }}>{isPrivate ? '🔒' : countryFlag}</span>
            </EuiText>
          </EuiFlexItem>
          <EuiFlexItem>
            <EuiText size="m">
              <strong style={{ fontFamily: 'monospace' }}>{ipAddress}</strong>
            </EuiText>
            {geo.country_name && (
              <EuiText size="xs" color="subdued">
                {geo.city ? `${geo.city}, ` : ''}{geo.country_name}
              </EuiText>
            )}
          </EuiFlexItem>
        </EuiFlexGroup>

        <EuiSpacer size="m" />

        {/* 2. Current Status Section - Always visible */}
        {statusData && (
          <>
            <EuiPanel color="primary" paddingSize="s" style={{ border: '1px solid #0077CC' }}>
              <EuiText size="xs">
                <strong>🔒 Current Status</strong>
              </EuiText>
              <EuiSpacer size="xs" />

              {/* Firewall and WAF Status - Same Row */}
              <EuiFlexGroup gutterSize="m" responsive={false}>
                {/* Firewall */}
                <EuiFlexItem>
                  <EuiFlexGroup alignItems="center" gutterSize="xs" responsive={false}>
                    <EuiFlexItem grow={false}>
                      <EuiIcon type="securitySignal" size="m" />
                    </EuiFlexItem>
                    <EuiFlexItem>
                      <EuiText size="xs">
                        <strong>Firewall:</strong>
                      </EuiText>
                    </EuiFlexItem>
                    <EuiFlexItem grow={false}>
                      {statusData.firewall_blocked ? (
                        <EuiBadge color="success">BLOCKED ✓</EuiBadge>
                      ) : (
                        <EuiBadge color="hollow">Not Blocked</EuiBadge>
                      )}
                    </EuiFlexItem>
                  </EuiFlexGroup>
                </EuiFlexItem>

                {/* WAF */}
                <EuiFlexItem>
                  <EuiFlexGroup alignItems="center" gutterSize="xs" responsive={false}>
                    <EuiFlexItem grow={false}>
                      <EuiIcon type="globe" size="m" />
                    </EuiFlexItem>
                    <EuiFlexItem>
                      <EuiText size="xs">
                        <strong>WAF:</strong>
                      </EuiText>
                    </EuiFlexItem>
                    <EuiFlexItem grow={false}>
                      {statusData.waf_blocked ? (
                        <EuiBadge color="success">BLOCKED ✓</EuiBadge>
                      ) : (
                        <EuiBadge color="hollow">Not Blocked</EuiBadge>
                      )}
                    </EuiFlexItem>
                  </EuiFlexGroup>
                </EuiFlexItem>
              </EuiFlexGroup>

              {/* Additional Firewall Details (if blocked) */}
              {statusData.firewall_blocked && (statusData.firewall_blocked_since || statusData.firewall_reason) && (
                <>
                  <EuiSpacer size="xs" />
                  {statusData.firewall_blocked_since && (
                    <EuiText size="xs" color="subdued">
                      Since {new Date(statusData.firewall_blocked_since).toLocaleString()}
                    </EuiText>
                  )}
                  {statusData.firewall_reason && (
                    <EuiText size="xs" color="subdued">
                      Reason: {statusData.firewall_reason}
                    </EuiText>
                  )}
                </>
              )}

              {/* Mute Rules */}
              {statusData.mute_rules && statusData.mute_rules.length > 0 && (
                <>
                  <EuiSpacer size="s" />
                  <EuiCallOut size="s" color="warning">
                    <EuiText size="xs">
                      <strong>🔇 {statusData.mute_rules.length} active mute rule(s)</strong>
                    </EuiText>
                    <EuiSpacer size="xs" />
                    <EuiText size="xs">
                      Future alerts matching these conditions will be suppressed
                    </EuiText>
                    {statusData.mute_rules[0] && (
                      <EuiText size="xs" color="subdued">
                        {statusData.mute_rules[0].reason}
                      </EuiText>
                    )}
                  </EuiCallOut>
                </>
              )}

              {/* Alert Count */}
              {statusData.times_seen_in_alerts > 0 && (
                <>
                  <EuiSpacer size="xs" />
                  <EuiText size="xs" color="subdued">
                    📊 Seen in {statusData.times_seen_in_alerts} alerts
                  </EuiText>
                </>
              )}
            </EuiPanel>
            <EuiSpacer size="s" />
          </>
        )}

        {/* 3. Cloud Provider Badge - Always visible if applicable */}
        {!isPrivate && enrichmentData.cloud_provider && (
          <>
            <EuiBadge
              color="primary"
              iconType="logoCloud"
              style={{ width: '100%', textAlign: 'center' }}
            >
              ☁️ {enrichmentData.cloud_provider.provider}
              {enrichmentData.cloud_provider.confidence === 'high' && ' ✓'}
            </EuiBadge>
            <EuiSpacer size="s" />
          </>
        )}

        {/* 4. Risk Assessment (Composite Score) - Always visible, compact */}
        {!isPrivate && enrichmentData.composite_score && (
          <>
            <EuiPanel
              color={getPanelColor(enrichmentData.composite_score.risk_level)}
              paddingSize="s"
            >
              <EuiFlexGroup alignItems="center" gutterSize="s" responsive={false}>
                <EuiFlexItem grow={false}>
                  <EuiIcon type="alert" size="m" />
                </EuiFlexItem>
                <EuiFlexItem>
                  <EuiText size="s">
                    <strong>{enrichmentData.composite_score.risk_level} RISK</strong>
                  </EuiText>
                  <EuiText size="xs" color="subdued">
                    Composite: {enrichmentData.composite_score.composite_score}/100
                  </EuiText>
                </EuiFlexItem>
              </EuiFlexGroup>

              <EuiSpacer size="xs" />

              <EuiText size="xs">
                {enrichmentData.composite_score.reasoning}
              </EuiText>

              <EuiSpacer size="xs" />

              {/* Expandable Source Breakdown */}
              <details open style={{cursor: 'pointer'}}>
                <summary style={{fontSize: '11px', color: '#69707D'}}>
                  Source Breakdown ({Math.round(enrichmentData.composite_score.confidence * 100)}% confidence)
                </summary>
                <div style={{marginTop: '8px'}}>
                  {Object.entries(enrichmentData.composite_score.component_scores).map(([source, score]) => (
                    <div key={source} style={{marginBottom: '4px'}}>
                      <EuiText size="xs" style={{textTransform: 'capitalize'}}>
                        {source}: {Math.round(score)}/100
                      </EuiText>
                      <div style={{
                        width: '100%',
                        height: '4px',
                        backgroundColor: '#E0E0E0',
                        borderRadius: '2px',
                        overflow: 'hidden'
                      }}>
                        <div style={{
                          width: `${score}%`,
                          height: '100%',
                          backgroundColor: getProgressBarColor(score),
                          transition: 'width 0.3s ease'
                        }} />
                      </div>
                    </div>
                  ))}
                </div>
              </details>
            </EuiPanel>
            <EuiSpacer size="s" />
          </>
        )}

        {/* Private IP Notice */}
        {isPrivate && (
          <>
            <EuiPanel color="subdued" paddingSize="s">
              <EuiText size="xs" color="subdued" textAlign="center">
                <EuiIcon type="lock" size="s" /> Private IP - External threat intel unavailable
              </EuiText>
            </EuiPanel>
            <EuiSpacer size="s" />
          </>
        )}

        {/* 5. Internal Alert History - Expanded if alerts > 0 */}
        {enrichmentData.internal_context && enrichmentData.internal_context.total_alerts > 0 && (
          <>
            <EuiPanel color="subdued" paddingSize="s">
              <EuiText size="xs">
                <strong>📊 Internal Alert History</strong>
              </EuiText>
              <EuiSpacer size="xs" />

              <EuiFlexGroup gutterSize="s" responsive={false}>
                <EuiFlexItem>
                  <EuiBadge color="primary">
                    {enrichmentData.internal_context.total_alerts} alerts
                  </EuiBadge>
                </EuiFlexItem>
                {enrichmentData.internal_context.affected_hosts_count > 0 && (
                  <EuiFlexItem grow={false}>
                    <EuiBadge color="hollow">
                      {enrichmentData.internal_context.affected_hosts_count} hosts
                    </EuiBadge>
                  </EuiFlexItem>
                )}
              </EuiFlexGroup>

              <EuiSpacer size="xs" />

              {enrichmentData.internal_context.first_seen && (
                <EuiText size="xs" color="subdued">
                  First seen: {new Date(enrichmentData.internal_context.first_seen).toLocaleString()}
                </EuiText>
              )}

              {enrichmentData.internal_context.last_seen && (
                <EuiText size="xs" color="subdued">
                  Last seen: {new Date(enrichmentData.internal_context.last_seen).toLocaleString()}
                </EuiText>
              )}

              {/* Severity breakdown */}
              {enrichmentData.internal_context.severity_counts && (
                <>
                  <EuiSpacer size="xs" />
                  <EuiFlexGroup gutterSize="xs" wrap>
                    {enrichmentData.internal_context.severity_counts.critical > 0 && (
                      <EuiFlexItem grow={false}>
                        <EuiBadge color="danger" style={{fontSize: '10px'}}>
                          Critical: {enrichmentData.internal_context.severity_counts.critical}
                        </EuiBadge>
                      </EuiFlexItem>
                    )}
                    {enrichmentData.internal_context.severity_counts.high > 0 && (
                      <EuiFlexItem grow={false}>
                        <EuiBadge color="#BD271E" style={{fontSize: '10px'}}>
                          High: {enrichmentData.internal_context.severity_counts.high}
                        </EuiBadge>
                      </EuiFlexItem>
                    )}
                    {enrichmentData.internal_context.severity_counts.medium > 0 && (
                      <EuiFlexItem grow={false}>
                        <EuiBadge color="warning" style={{fontSize: '10px'}}>
                          Medium: {enrichmentData.internal_context.severity_counts.medium}
                        </EuiBadge>
                      </EuiFlexItem>
                    )}
                    {enrichmentData.internal_context.severity_counts.low > 0 && (
                      <EuiFlexItem grow={false}>
                        <EuiBadge color="hollow" style={{fontSize: '10px'}}>
                          Low: {enrichmentData.internal_context.severity_counts.low}
                        </EuiBadge>
                      </EuiFlexItem>
                    )}
                  </EuiFlexGroup>
                </>
              )}

              {/* Top alert types */}
              {enrichmentData.internal_context.top_alert_types && enrichmentData.internal_context.top_alert_types.length > 0 && (
                <>
                  <EuiSpacer size="xs" />
                  <details style={{cursor: 'pointer'}}>
                    <summary style={{fontSize: '11px', color: '#69707D'}}>
                      Top Alert Types
                    </summary>
                    <div style={{marginTop: '4px'}}>
                      {enrichmentData.internal_context.top_alert_types.map((alertType, idx) => (
                        <EuiText key={idx} size="xs" style={{marginBottom: '2px'}}>
                          • {alertType.type} ({alertType.count})
                        </EuiText>
                      ))}
                    </div>
                  </details>
                </>
              )}
            </EuiPanel>
            <EuiSpacer size="s" />
          </>
        )}

        {/* 7. Threat Intelligence - Collapsed by default */}
        {!isPrivate && (threat.abuseipdb_score !== undefined || enrichmentData.virustotal || enrichmentData.greynoise) && (
          <>
            <details style={{cursor: 'pointer', marginBottom: '8px'}}>
              <summary style={{fontSize: '12px', fontWeight: '600', padding: '4px 0', color: '#fff'}}>
                🔍 Threat Intelligence
              </summary>
              <div style={{marginTop: '8px', paddingLeft: '4px'}}>

                {/* AbuseIPDB */}
                {threat.abuseipdb_score !== undefined && (
                  <>
                    <EuiFlexGroup direction="column" gutterSize="s">
              <EuiFlexItem>
                <EuiFlexGroup alignItems="center" gutterSize="s" responsive={false}>
                  <EuiFlexItem grow={false}>
                    <EuiIcon type={threatLevel.icon} color={threatLevel.color} />
                  </EuiFlexItem>
                  <EuiFlexItem>
                    <EuiLink
                      href={`https://www.abuseipdb.com/check/${ipAddress}`}
                      target="_blank"
                      external
                      style={{ fontSize: '11px' }}
                    >
                      AbuseIPDB Score
                    </EuiLink>
                  </EuiFlexItem>
                  <EuiFlexItem grow={false}>
                    <EuiBadge color={threatLevel.color}>
                      <strong>{threat.abuseipdb_score || 0}/100</strong>
                    </EuiBadge>
                  </EuiFlexItem>
                </EuiFlexGroup>
              </EuiFlexItem>

              {threat.abuseipdb_score > 0 && (
                <EuiFlexItem>
                  <EuiBadge
                    color={threatLevel.color}
                    style={{ width: '100%', textAlign: 'center' }}
                  >
                    {threatLevel.label}
                  </EuiBadge>
                </EuiFlexItem>
              )}

              {threat.total_reports > 0 && (
                <EuiFlexItem>
                  <EuiText size="xs" color="subdued">
                    📊 Reported {threat.total_reports} times
                  </EuiText>
                </EuiFlexItem>
              )}

              {threat.is_tor && (
                <EuiFlexItem>
                  <EuiBadge color="danger" iconType="securitySignal">
                    Tor Exit Node
                  </EuiBadge>
                </EuiFlexItem>
              )}

              {threat.is_whitelisted && (
                <EuiFlexItem>
                  <EuiBadge color="success" iconType="check">
                    Whitelisted
                  </EuiBadge>
                </EuiFlexItem>
              )}
            </EuiFlexGroup>
            <EuiSpacer size="s" />
          </>
        )}

        {/* VirusTotal Section - Only for public IPs */}
        {!isPrivate && enrichmentData.virustotal && enrichmentData.virustotal.vt_score > 0 && (
          <>
            <EuiText size="xs">
              <strong>🛡️ </strong>
              <EuiLink
                href={`https://www.virustotal.com/gui/ip-address/${ipAddress}`}
                target="_blank"
                external
                style={{ fontSize: '11px' }}
              >
                VirusTotal
              </EuiLink>
              {': '}
              {enrichmentData.virustotal.malicious}/{enrichmentData.virustotal.total_vendors} vendors flagged
              {enrichmentData.virustotal.suspicious > 0 &&
                ` (${enrichmentData.virustotal.suspicious} suspicious)`}
            </EuiText>
            <EuiSpacer size="xs" />
          </>
        )}

        {/* GreyNoise Section - Only for public IPs */}
        {!isPrivate && enrichmentData.greynoise && (
          <>
            <EuiText size="xs">
              <strong>🔍 </strong>
              <EuiLink
                href={enrichmentData.greynoise.link || `https://viz.greynoise.io/ip/${ipAddress}`}
                target="_blank"
                external
                style={{ fontSize: '11px' }}
              >
                GreyNoise
              </EuiLink>
            </EuiText>

            {enrichmentData.greynoise.riot && (
              <EuiBadge color="success" iconType="check" style={{marginTop: '4px'}}>
                Benign Service - {enrichmentData.greynoise.name}
              </EuiBadge>
            )}

            {enrichmentData.greynoise.noise && !enrichmentData.greynoise.riot && (
              <EuiBadge color="warning" iconType="alert" style={{marginTop: '4px'}}>
                Internet Noise - {enrichmentData.greynoise.classification}
              </EuiBadge>
            )}

            {!enrichmentData.greynoise.noise && !enrichmentData.greynoise.riot && (
              <EuiText size="xs" color="subdued" style={{marginTop: '4px'}}>
                Not classified as internet noise
              </EuiText>
            )}

            {enrichmentData.greynoise.name && (
              <EuiText size="xs" color="subdued" style={{marginTop: '4px'}}>
                {enrichmentData.greynoise.name}
              </EuiText>
            )}
            <EuiSpacer size="s" />
          </>
        )}

        {/* AlienVault OTX / Threat Campaigns */}
        {!isPrivate && enrichmentData.otx && enrichmentData.otx.pulse_count > 0 && (
          <>
            <EuiText size="xs">
              <strong>🎯 </strong>
              <EuiLink
                href={`https://otx.alienvault.com/indicator/ip/${ipAddress}`}
                target="_blank"
                external
                style={{ fontSize: '11px' }}
              >
                Threat Campaigns
              </EuiLink>
              {': '}{enrichmentData.otx.pulse_count} pulse(s)
            </EuiText>

            {enrichmentData.otx.pulses && enrichmentData.otx.pulses.length > 0 && (
              <EuiFlexGroup gutterSize="xs" wrap style={{marginTop: '4px'}}>
                {enrichmentData.otx.pulses.map((pulse, idx) => (
                  <EuiFlexItem grow={false} key={idx}>
                    <EuiBadge
                      color="warning"
                      style={{fontSize: '10px', cursor: 'pointer'}}
                      onClick={() => window.open(`https://otx.alienvault.com/pulse/${pulse.id}`, '_blank')}
                      onClickAriaLabel={`View ${pulse.name} on AlienVault OTX`}
                    >
                      {pulse.name.length > 30
                        ? pulse.name.substring(0, 30) + '...'
                        : pulse.name}
                    </EuiBadge>
                  </EuiFlexItem>
                ))}
              </EuiFlexGroup>
            )}

            {enrichmentData.otx.malware_families &&
             enrichmentData.otx.malware_families.length > 0 && (
              <EuiText size="xs" color="danger" style={{marginTop: '4px'}}>
                Malware: {enrichmentData.otx.malware_families.join(', ')}
              </EuiText>
            )}
            <EuiSpacer size="s" />
          </>
        )}

              </div>
            </details>
            <EuiSpacer size="s" />
          </>
        )}

        {/* 8. Passive DNS - Collapsed by default */}
        {!isPrivate && enrichmentData.passive_dns && enrichmentData.passive_dns.total_domains > 0 && (
          <>
            <details style={{cursor: 'pointer', marginBottom: '8px'}}>
              <summary style={{fontSize: '12px', fontWeight: '600', padding: '4px 0', color: '#fff'}}>
                🌐 Passive DNS ({enrichmentData.passive_dns.total_domains} domains)
              </summary>
              <div style={{marginTop: '8px', paddingLeft: '4px'}}>

            {enrichmentData.passive_dns.domains && enrichmentData.passive_dns.domains.length > 0 && (
              <div style={{marginTop: '4px', maxHeight: '120px', overflowY: 'auto'}}>
                {enrichmentData.passive_dns.domains.map((domain, idx) => (
                  <div key={idx} style={{marginBottom: '4px'}}>
                    <EuiText size="xs">
                      🔗 {domain.domain}
                    </EuiText>
                    {domain.last_resolved && (
                      <EuiText size="xs" color="subdued" style={{marginLeft: '16px'}}>
                        Last: {new Date(domain.last_resolved).toLocaleDateString()}
                      </EuiText>
                    )}
                  </div>
                ))}
              </div>
            )}

              </div>
            </details>
            <EuiSpacer size="s" />
          </>
        )}

        {/* 6. Related IoCs Section - Expanded if found */}
        {enrichmentData.related_iocs && enrichmentData.related_iocs.total_related_ips > 0 && (
          <>
            <EuiPanel color="warning" paddingSize="s">
              <EuiText size="xs">
                <strong>🔗 Related IoCs</strong>
              </EuiText>
              <EuiSpacer size="xs" />
              <EuiText size="xs" color="subdued">
                {enrichmentData.related_iocs.total_related_ips} IP(s) share similar attack patterns
              </EuiText>

              {enrichmentData.related_iocs.related_ips && enrichmentData.related_iocs.related_ips.length > 0 && (
                <details style={{cursor: 'pointer', marginTop: '8px'}}>
                  <summary style={{fontSize: '11px', color: '#69707D'}}>
                    View Related IPs
                  </summary>
                  <div style={{marginTop: '8px', maxHeight: '150px', overflowY: 'auto'}}>
                    {enrichmentData.related_iocs.related_ips.map((relatedIP, idx) => (
                      <div key={idx} style={{marginBottom: '8px', paddingBottom: '8px', borderBottom: '1px solid #D3DAE6'}}>
                        <EuiText size="xs">
                          <strong style={{fontFamily: 'monospace'}}>{relatedIP.ip_address}</strong>
                        </EuiText>
                        <EuiText size="xs" color="subdued">
                          {relatedIP.shared_signatures} shared signature(s), {relatedIP.alert_count} alerts
                        </EuiText>
                        {relatedIP.signatures && relatedIP.signatures.length > 0 && (
                          <EuiText size="xs" color="subdued" style={{marginTop: '2px'}}>
                            • {relatedIP.signatures[0]}
                            {relatedIP.signatures.length > 1 && ` (+${relatedIP.signatures.length - 1} more)`}
                          </EuiText>
                        )}
                      </div>
                    ))}
                  </div>
                </details>
              )}
            </EuiPanel>
            <EuiSpacer size="s" />
          </>
        )}

        {/* Network Information Section */}
        {(geo.isp || geo.asn) && (
          <>
            <EuiText size="xs" color="subdued">
              <strong>Network Information</strong>
            </EuiText>
            <EuiSpacer size="xs" />

            {geo.isp && (
              <EuiText size="xs">
                🏢 ISP: {geo.isp}
              </EuiText>
            )}

            {geo.asn && (
              <EuiText size="xs" color="subdued">
                🔢 ASN: {geo.asn}
              </EuiText>
            )}
            <EuiSpacer size="s" />
          </>
        )}

        {/* 10. WHOIS - Collapsed by default */}
        {!isPrivate && enrichmentData.whois && (
          <>
            <details style={{cursor: 'pointer', marginBottom: '8px'}}>
              <summary style={{fontSize: '12px', fontWeight: '600', padding: '4px 0', color: '#fff'}}>
                📋 WHOIS Information
              </summary>
              <div style={{marginTop: '8px', paddingLeft: '4px'}}>
                {enrichmentData.whois.asn && (
                  <EuiText size="xs">
                    ASN: {enrichmentData.whois.asn}
                  </EuiText>
                )}

                {enrichmentData.whois.asn_description && (
                  <EuiText size="xs" color="subdued">
                    {enrichmentData.whois.asn_description}
                  </EuiText>
                )}

                {enrichmentData.whois.network_name && (
                  <EuiText size="xs">
                    Network: {enrichmentData.whois.network_name}
                  </EuiText>
                )}

                {enrichmentData.whois.registrant && (
                  <EuiText size="xs">
                    Registrant: {enrichmentData.whois.registrant}
                  </EuiText>
                )}

                {enrichmentData.whois.abuse_contacts && enrichmentData.whois.abuse_contacts.length > 0 && (
                  <EuiText size="xs">
                    Abuse: {enrichmentData.whois.abuse_contacts.join(', ')}
                  </EuiText>
                )}
              </div>
            </details>
            <EuiSpacer size="s" />
          </>
        )}

        {/* Cached indicator */}
        {enrichmentData.cached && (
          <EuiText size="xs" color="subdued" textAlign="right">
            ⚡ Cached
          </EuiText>
        )}
      </EuiPanel>
    );
  };

  // Trigger button
  const button = (
    <span
      onMouseEnter={handleMouseEnter}
      onMouseLeave={handleMouseLeave}
      style={{
        cursor: 'help',
        textDecoration: 'underline',
        textDecorationStyle: 'dotted',
        textDecorationColor: '#69707D',
        fontFamily: 'monospace',
        fontSize: '11px'
      }}
    >
      {children || ipAddress}
    </span>
  );

  return (
    <EuiPopover
      button={button}
      isOpen={isPopoverOpen}
      closePopover={() => setIsPopoverOpen(false)}
      anchorPosition={placement === 'right' ? 'rightCenter' : 'downCenter'}
      panelPaddingSize="none"
      hasArrow={false}
      ownFocus={false}
      panelProps={{
        onMouseEnter: handlePopoverMouseEnter,
        onMouseLeave: handlePopoverMouseLeave
      }}
    >
      {renderContent()}
    </EuiPopover>
  );
};

export default IPEnrichmentTooltip;
