import { useState } from 'react';
import { X, VolumeX, Info } from 'lucide-react';
import { toast } from 'react-hot-toast';
import axios from 'axios';

// API Base URL - MUST be configured via environment variable for production
const RESPONSE_BACKEND_URL = process.env.REACT_APP_API_BASE_URL || process.env.REACT_APP_RESPONSE_BACKEND_URL;

const MuteAlertModal = ({ isOpen, onClose, event, onMuteSuccess }) => {
  const [selectedOptions, setSelectedOptions] = useState([]);
  const [classification, setClassification] = useState('false_positive');
  const [reason, setReason] = useState('');
  const [duration, setDuration] = useState('168'); // Default: 7 days
  const [customDuration, setCustomDuration] = useState('');
  const [scope, setScope] = useState('global');
  const [loading, setLoading] = useState(false);
  const [cidrErrors, setCidrErrors] = useState({});
  const [showTierHelp, setShowTierHelp] = useState(false);
  const [conflicts, setConflicts] = useState(null);
  const [showConflictModal, setShowConflictModal] = useState(false);

  if (!isOpen || !event) return null;

  // Determine which mute options are available based on event source
  const isWazuh = event.source === 'wazuh';
  const isSuricata = event.source === 'suricata';

  // Validate CIDR notation
  const validateCIDR = (cidr) => {
    if (!cidr || !cidr.trim()) {
      return null; // Empty is ok if optional
    }

    cidr = cidr.trim();

    // Must contain a slash
    if (!cidr.includes('/')) {
      return 'CIDR notation must include a prefix length (e.g., 192.168.1.0/24)';
    }

    const [ipPart, prefixPart] = cidr.split('/');
    const prefix = parseInt(prefixPart);

    // Validate IPv4 CIDR
    const ipv4Regex = /^(\d{1,3}\.){3}\d{1,3}$/;
    if (ipv4Regex.test(ipPart)) {
      const octets = ipPart.split('.').map(Number);
      if (octets.some(octet => octet < 0 || octet > 255)) {
        return 'Invalid IPv4 address';
      }
      if (isNaN(prefix) || prefix < 0 || prefix > 32) {
        return 'IPv4 prefix length must be between 0 and 32';
      }
      if (prefix < 8) {
        return `Warning: /${prefix} is very broad (${Math.pow(2, 32 - prefix)} addresses)`;
      }
      return null; // Valid
    }

    // Validate IPv6 CIDR (basic check)
    if (ipPart.includes(':')) {
      if (isNaN(prefix) || prefix < 0 || prefix > 128) {
        return 'IPv6 prefix length must be between 0 and 128';
      }
      return null; // Valid
    }

    return 'Invalid IP address format';
  };

  // Handle CIDR input change
  const handleCIDRChange = (optionId, value) => {
    const error = validateCIDR(value);
    setCidrErrors(prev => ({
      ...prev,
      [optionId]: error
    }));
  };

  // Available mute options based on source
  const muteOptions = [
    // Common to both
    { id: 'signature_id', label: 'Signature/Rule ID', value: event.signature_id || event.rule_id, available: true },
    { id: 'severity', label: 'Severity Level', value: event.normalized_severity, available: true },
    { id: 'category', label: 'Category', value: event.category || event.rule_description, available: true },

    // IP-based (Suricata only or both)
    { id: 'source_ip', label: 'Source IP (exact)', value: event.src_ip, available: !!event.src_ip },
    { id: 'source_ip_cidr', label: 'Source IP CIDR (e.g., 10.0.0.0/24)', value: '', available: !!event.src_ip, isInput: true },
    { id: 'dest_ip', label: 'Destination IP (exact)', value: event.dest_ip, available: !!event.dest_ip },
    { id: 'dest_ip_cidr', label: 'Destination IP CIDR', value: '', available: !!event.dest_ip, isInput: true },

    // Source-specific
    { id: 'agent_name', label: 'Agent Name', value: event.agent_name, available: isWazuh && !!event.agent_name },
    { id: 'sensor_hostname', label: 'Sensor Hostname', value: event.raw?.node?.hostname, available: isSuricata && !!event.raw?.node?.hostname },
  ];

  const availableOptions = muteOptions.filter(opt => opt.available);

  const handleOptionToggle = (optionId) => {
    setSelectedOptions(prev => {
      if (prev.includes(optionId)) {
        return prev.filter(id => id !== optionId);
      } else {
        return [...prev, optionId];
      }
    });
  };

  // Determine suppression tier based on selected conditions AND alert source
  const getSuppressionTierInfo = () => {
    if (selectedOptions.length === 0) {
      return null;
    }

    const hasSignatureOrRuleId = selectedOptions.includes('signature_id');
    const hasSourceIp = selectedOptions.includes('source_ip') || selectedOptions.includes('source_ip_cidr');

    // For Wazuh: rule_id and source_ip are Tier 2 (Wazuh Manager level)
    // For Suricata: signature_id and source_ip are Tier 3 (Suricata IDS level)
    const hasSourceLevelSupport = isWazuh
      ? (hasSignatureOrRuleId || hasSourceIp)  // Wazuh supports rule_id and IP
      : (hasSignatureOrRuleId || hasSourceIp); // Suricata supports signature_id and IP

    const hasApiOnlyConditions = selectedOptions.some(opt =>
      !['signature_id', 'source_ip', 'source_ip_cidr'].includes(opt)
    );

    return {
      hasSignatureOrRuleId,
      hasSourceIp,
      hasSourceLevelSupport,
      hasApiOnlyConditions,
      isWazuh,
      isSuricata
    };
  };

  // Component to display suppression tier warning/info
  const SuppressionTierInfo = () => {
    const tierInfo = getSuppressionTierInfo();

    if (!tierInfo) return null;

    const { hasSignatureOrRuleId, hasSourceIp, hasSourceLevelSupport, hasApiOnlyConditions, isWazuh, isSuricata } = tierInfo;

    // Determine message type and content
    let icon = 'ℹ️';
    let title = '';
    let message = '';
    let backgroundColor = '#1e3a5f';
    let borderColor = '#3b82f6';

    if (hasSourceLevelSupport && !hasApiOnlyConditions) {
      // ✅ Source-level suppression (best case)
      icon = '✅';
      backgroundColor = '#065f46';
      borderColor = '#10b981';

      if (isWazuh) {
        // Wazuh suppression (Tier 2)
        if (hasSignatureOrRuleId && hasSourceIp) {
          title = 'Suppressed at Wazuh Manager Level (Tier 2)';
          message = `Wazuh will suppress these alerts using both rule override (Rule ID ${event.rule_id}) and IP whitelist (${event.src_ip}). Alerts will NOT reach Elasticsearch.`;
        } else if (hasSignatureOrRuleId) {
          title = 'Suppressed at Wazuh Manager Level (Tier 2)';
          message = `Wazuh will suppress Rule ID ${event.rule_id} alerts using rule override (level=0). These alerts will NOT reach Elasticsearch.`;
        } else if (hasSourceIp) {
          title = 'Suppressed at Wazuh Manager Level (Tier 2)';
          message = `Wazuh will ignore alerts from IP ${event.src_ip} using CDB whitelist. These alerts will NOT reach Elasticsearch.`;
        }
      } else if (isSuricata) {
        // Suricata suppression (Tier 3)
        if (hasSignatureOrRuleId && hasSourceIp) {
          title = 'Suppressed at Suricata IDS Level (Tier 3)';
          message = `Suricata will suppress Signature ID ${event.signature_id} from IP ${event.src_ip}. Alerts will NOT be sent to Elasticsearch.`;
        } else if (hasSignatureOrRuleId) {
          title = 'Suppressed at Suricata IDS Level (Tier 3)';
          message = `Suricata will suppress all alerts with Signature ID ${event.signature_id}. These alerts will NOT be sent to Elasticsearch.`;
        } else if (hasSourceIp) {
          title = 'Suppressed at Suricata IDS Level (Tier 3)';
          message = `Suricata will suppress alerts from IP ${event.src_ip}. These alerts will NOT be sent to Elasticsearch.`;
        }
      }
    } else if (hasSourceLevelSupport && hasApiOnlyConditions) {
      // ⚠️ Mixed: Some at source, some at API
      icon = '⚠️';
      backgroundColor = '#78350f';
      borderColor = '#f59e0b';
      title = 'Mixed Suppression Levels';

      const sourceTier = isWazuh ? 'Wazuh Manager (Tier 2)' : 'Suricata IDS (Tier 3)';
      const supportedConditions = [];
      if (hasSignatureOrRuleId) supportedConditions.push(isWazuh ? 'rule_id' : 'signature_id');
      if (hasSourceIp) supportedConditions.push('source_ip');

      message = `Some conditions will be suppressed at ${sourceTier} (${supportedConditions.join(', ')}), while others (severity, category, etc.) will only be filtered at the API level (Tier 4). Alerts matching ONLY the API-level conditions will still be stored in Elasticsearch.`;
    } else {
      // ⚠️ API-level only (alerts still stored)
      icon = '⚠️';
      backgroundColor = '#78350f';
      borderColor = '#f59e0b';
      title = 'API-Level Filtering Only (Tier 4)';

      if (isWazuh) {
        message = 'These conditions cannot be suppressed at Wazuh Manager level. Alerts will still be sent to Elasticsearch and stored, but will be hidden from the UI. To prevent alerts from reaching Elasticsearch, use Rule ID or Source IP conditions.';
      } else {
        message = 'These conditions cannot be suppressed at Suricata IDS level. Alerts will still be sent to Elasticsearch and stored, but will be hidden from the UI. To prevent alerts from reaching Elasticsearch, use Signature ID or Source IP conditions.';
      }
    }

    return (
      <div style={{
        backgroundColor,
        border: `1px solid ${borderColor}`,
        borderRadius: '8px',
        padding: '14px 16px',
        marginTop: '16px'
      }}>
        <div style={{ display: 'flex', alignItems: 'start', gap: '12px' }}>
          <span style={{ fontSize: '18px', lineHeight: 1 }}>{icon}</span>
          <div style={{ flex: 1 }}>
            <div style={{ fontSize: '14px', fontWeight: '600', color: '#fff', marginBottom: '6px' }}>
              {title}
            </div>
            <div style={{ fontSize: '13px', color: 'rgba(255, 255, 255, 0.9)', lineHeight: '1.6' }}>
              {message}
            </div>
          </div>
        </div>
      </div>
    );
  };

  // Optional: Collapsible tier explanation
  const TierExplanation = () => (
    <div style={{ marginTop: '12px' }}>
      <button
        type="button"
        onClick={() => setShowTierHelp(!showTierHelp)}
        style={{
          backgroundColor: 'transparent',
          border: 'none',
          color: '#60a5fa',
          fontSize: '13px',
          cursor: 'pointer',
          padding: '4px 0',
          textDecoration: 'underline'
        }}
      >
        {showTierHelp ? '▼' : '▶'} Learn about suppression tiers
      </button>

      {showTierHelp && (
        <div style={{
          fontSize: '13px',
          color: '#9ca3af',
          marginTop: '8px',
          paddingLeft: '16px',
          lineHeight: '1.8'
        }}>
          <div><strong style={{ color: '#fff' }}>Tier 3 (Suricata IDS):</strong> Suppresses alerts at the IDS sensor level. Most efficient - alerts never reach Elasticsearch. Supports signature_id and source_ip.</div>
          <div style={{ marginTop: '8px' }}><strong style={{ color: '#fff' }}>Tier 2 (Wazuh Manager):</strong> Suppresses alerts at the Wazuh manager level. Prevents alerts from reaching Elasticsearch. Supports rule_id (XML overrides) and source_ip (CDB whitelist).</div>
          <div style={{ marginTop: '8px' }}><strong style={{ color: '#fff' }}>Tier 4 (API Filter):</strong> Filters alerts when displaying in the UI. Alerts are still stored in Elasticsearch but hidden from view. Supports all condition types (severity, category, agent_name, etc.).</div>
        </div>
      )}
    </div>
  );

  const handleSubmit = async () => {
    // Validation
    if (selectedOptions.length === 0) {
      toast.error('Please select at least one mute condition');
      return;
    }

    if (!reason.trim()) {
      toast.error('Please provide a reason for muting this alert');
      return;
    }

    // Check for CIDR validation errors (exclude warnings)
    const hasErrors = Object.entries(cidrErrors).some(([key, error]) => {
      return selectedOptions.includes(key) && error && !error.startsWith('Warning');
    });

    if (hasErrors) {
      toast.error('Please fix CIDR notation errors before submitting');
      return;
    }

    setLoading(true);

    try {
      // Build conditions object
      const conditions = {};

      selectedOptions.forEach(optionId => {
        const option = muteOptions.find(opt => opt.id === optionId);

        if (optionId === 'signature_id') {
          if (isSuricata) {
            conditions.signature_id = String(event.signature_id);
          } else if (isWazuh) {
            conditions.rule_id = String(event.rule_id);
          }
        } else if (optionId === 'source_ip_cidr' || optionId === 'dest_ip_cidr') {
          // Get CIDR value from input field
          const cidrInput = document.getElementById(`input-${optionId}`);
          if (cidrInput && cidrInput.value) {
            conditions[optionId] = cidrInput.value;
          }
        } else if (option && option.value) {
          conditions[optionId] = option.value;
        }
      });

      // Calculate duration in hours
      let durationHours = null;
      if (duration === 'custom' && customDuration) {
        durationHours = parseInt(customDuration);
      } else if (duration !== 'permanent') {
        durationHours = parseInt(duration);
      }

      // Get current user
      const currentUser = localStorage.getItem('username') || 'analyst';

      // Create mute rule
      const response = await axios.post(`${RESPONSE_BACKEND_URL}/api/mute/rules`, {
        conditions,
        classification,
        reason: reason.trim(),
        analyst: currentUser,
        duration_hours: durationHours,
        source_type: event.source,
        original_alert_id: event.id,
        scope
      });

      if (response.data.success) {
        // Check if there are conflict warnings
        if (response.data.data.conflicts && response.data.data.conflicts.length > 0) {
          setConflicts(response.data.data.conflicts);
          setShowConflictModal(true);
          setLoading(false);
          return; // Don't close modal yet, show conflicts first
        }

        toast.success('Alert muted successfully');

        if (onMuteSuccess) {
          onMuteSuccess(event.id);  // Pass alert ID for client-side filtering
        }

        onClose();
      } else {
        toast.error(response.data.error || 'Failed to create mute rule');
      }
    } catch (error) {
      console.error('Error creating mute rule:', error);
      toast.error(error.response?.data?.error || 'Failed to mute alert');
    } finally {
      setLoading(false);
    }
  };

  const classifications = [
    { value: 'false_positive', label: 'False Positive', description: 'Incorrect detection, not a real threat' },
    { value: 'noisy_signature', label: 'Noisy Signature', description: 'Too many alerts, signature needs tuning' }
  ];

  const durations = [
    { value: '1', label: '1 Hour' },
    { value: '24', label: '24 Hours (1 Day)' },
    { value: '168', label: '7 Days (1 Week)' },
    { value: '720', label: '30 Days (1 Month)' },
    { value: 'custom', label: 'Custom Hours' },
    { value: 'permanent', label: 'Permanent' }
  ];


  return (
    <div style={{
      position: 'fixed',
      top: 0,
      left: 0,
      right: 0,
      bottom: 0,
      zIndex: 9999,
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center'
    }}>
      {/* Backdrop */}
      <div
        onClick={onClose}
        style={{
          position: 'absolute',
          top: 0,
          left: 0,
          right: 0,
          bottom: 0,
          backgroundColor: 'rgba(0, 0, 0, 0.7)',
          zIndex: 1
        }}
      />

      {/* Modal */}
      <div style={{
        position: 'relative',
        zIndex: 2,
        backgroundColor: '#1a1d29',
        borderRadius: '12px',
        border: '1px solid #2d3142',
        maxWidth: '700px',
        width: '90%',
        maxHeight: '90vh',
        overflow: 'auto',
        boxShadow: '0 20px 60px rgba(0, 0, 0, 0.5)'
      }}>
        {/* Header */}
        <div style={{
          position: 'sticky',
          top: 0,
          backgroundColor: '#1a1d29',
          borderBottom: '1px solid #2d3142',
          padding: '20px 24px',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'space-between',
          zIndex: 3
        }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
            <div style={{
              padding: '8px',
              backgroundColor: 'rgba(59, 130, 246, 0.2)',
              borderRadius: '8px'
            }}>
              <VolumeX size={24} color="#60a5fa" />
            </div>
            <div>
              <h3 style={{ fontSize: '20px', fontWeight: '600', color: '#fff', margin: 0 }}>Mute Alert</h3>
              <p style={{ fontSize: '14px', color: '#9ca3af', margin: '4px 0 0 0' }}>
                {event.source === 'wazuh' ? 'Wazuh' : 'Suricata'} Alert
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            style={{
              padding: '6px',
              backgroundColor: 'transparent',
              border: 'none',
              borderRadius: '6px',
              cursor: 'pointer',
              color: '#9ca3af'
            }}
            onMouseOver={(e) => e.currentTarget.style.backgroundColor = '#2d3142'}
            onMouseOut={(e) => e.currentTarget.style.backgroundColor = 'transparent'}
          >
            <X size={20} />
          </button>
        </div>

        <div style={{ padding: '24px' }}>
          {/* Alert Summary */}
          <div style={{
            backgroundColor: 'rgba(45, 49, 66, 0.5)',
            borderRadius: '8px',
            padding: '16px',
            border: '1px solid #2d3142',
            marginBottom: '24px'
          }}>
            <h4 style={{ fontSize: '14px', fontWeight: '500', color: '#9ca3af', margin: '0 0 8px 0' }}>
              Alert Details
            </h4>
            <div style={{ fontSize: '14px' }}>
              <p style={{ color: '#fff', margin: '0 0 8px 0' }}>
                {event.signature || event.rule_description}
              </p>
              <div style={{ display: 'flex', gap: '16px', color: '#9ca3af', flexWrap: 'wrap' }}>
                <span>Severity: <span style={{ color: '#fff' }}>{event.normalized_severity}</span></span>
                {event.src_ip && <span>Source: <span style={{ color: '#fff' }}>{event.src_ip}</span></span>}
                {event.dest_ip && <span>Dest: <span style={{ color: '#fff' }}>{event.dest_ip}</span></span>}
              </div>
            </div>
          </div>

          {/* Mute Conditions */}
          <div style={{ marginBottom: '24px' }}>
            <h4 style={{ fontSize: '14px', fontWeight: '500', color: '#fff', marginBottom: '12px' }}>
              Mute Conditions (Select one or more)
            </h4>
            <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
              {availableOptions.map(option => (
                <div key={option.id} style={{ display: 'flex', alignItems: 'start', gap: '12px' }}>
                  <input
                    type="checkbox"
                    id={option.id}
                    checked={selectedOptions.includes(option.id)}
                    onChange={() => handleOptionToggle(option.id)}
                    style={{
                      marginTop: '4px',
                      width: '16px',
                      height: '16px',
                      cursor: 'pointer'
                    }}
                  />
                  <label htmlFor={option.id} style={{ flex: 1, fontSize: '14px', cursor: 'pointer' }}>
                    <span style={{ color: '#fff', display: 'block', marginBottom: '4px' }}>{option.label}</span>
                    {option.isInput ? (
                      <>
                        <input
                          id={`input-${option.id}`}
                          type="text"
                          placeholder={option.label}
                          disabled={!selectedOptions.includes(option.id)}
                          onBlur={(e) => handleCIDRChange(option.id, e.target.value)}
                          onChange={(e) => handleCIDRChange(option.id, e.target.value)}
                          style={{
                            width: '100%',
                            padding: '6px 12px',
                            backgroundColor: '#2d3142',
                            border: cidrErrors[option.id] ? '1px solid #ef4444' : '1px solid #3f4456',
                            color: '#fff',
                            borderRadius: '6px',
                            fontSize: '14px',
                            opacity: selectedOptions.includes(option.id) ? 1 : 0.5
                          }}
                        />
                        {cidrErrors[option.id] && selectedOptions.includes(option.id) && (
                          <span style={{
                            display: 'block',
                            color: cidrErrors[option.id].startsWith('Warning') ? '#fbbf24' : '#ef4444',
                            fontSize: '12px',
                            marginTop: '4px'
                          }}>
                            {cidrErrors[option.id]}
                          </span>
                        )}
                      </>
                    ) : (
                      <span style={{ display: 'block', color: '#9ca3af' }}>{option.value}</span>
                    )}
                  </label>
                </div>
              ))}
            </div>
            <p style={{ fontSize: '12px', color: '#9ca3af', marginTop: '8px' }}>
              Multiple conditions use AND logic (all must match)
            </p>

            {/* Suppression Tier Warning/Info */}
            <SuppressionTierInfo />
            <TierExplanation />
          </div>

          {/* Classification */}
          <div style={{ marginBottom: '24px' }}>
            <label style={{ display: 'block', fontSize: '14px', fontWeight: '500', color: '#fff', marginBottom: '8px' }}>
              Classification (Why are you muting this?)
            </label>
            <select
              value={classification}
              onChange={(e) => setClassification(e.target.value)}
              style={{
                width: '100%',
                padding: '8px 12px',
                backgroundColor: '#2d3142',
                border: '1px solid #3f4456',
                color: '#fff',
                borderRadius: '6px',
                fontSize: '14px'
              }}
            >
              {classifications.map(cls => (
                <option key={cls.value} value={cls.value}>{cls.label}</option>
              ))}
            </select>
            <p style={{ fontSize: '12px', color: '#9ca3af', marginTop: '4px' }}>
              {classifications.find(c => c.value === classification)?.description}
            </p>
          </div>

          {/* Reason */}
          <div style={{ marginBottom: '24px' }}>
            <label style={{ display: 'block', fontSize: '14px', fontWeight: '500', color: '#fff', marginBottom: '8px' }}>
              Reason <span style={{ color: '#ef4444' }}>*</span>
            </label>
            <textarea
              value={reason}
              onChange={(e) => setReason(e.target.value)}
              placeholder="Explain why this alert should be muted (required for audit trail)..."
              rows={3}
              style={{
                width: '100%',
                padding: '8px 12px',
                backgroundColor: '#2d3142',
                border: '1px solid #3f4456',
                color: '#fff',
                borderRadius: '6px',
                fontSize: '14px',
                resize: 'vertical',
                fontFamily: 'inherit'
              }}
            />
          </div>

          {/* Duration */}
          <div style={{ marginBottom: '24px' }}>
            <label style={{ display: 'block', fontSize: '14px', fontWeight: '500', color: '#fff', marginBottom: '8px' }}>
              Duration
            </label>
            <select
              value={duration}
              onChange={(e) => setDuration(e.target.value)}
              style={{
                width: '100%',
                padding: '8px 12px',
                backgroundColor: '#2d3142',
                border: '1px solid #3f4456',
                color: '#fff',
                borderRadius: '6px',
                fontSize: '14px',
                marginBottom: '8px'
              }}
            >
              {durations.map(dur => (
                <option key={dur.value} value={dur.value}>{dur.label}</option>
              ))}
            </select>

            {duration === 'custom' && (
              <input
                type="number"
                value={customDuration}
                onChange={(e) => setCustomDuration(e.target.value)}
                placeholder="Enter hours"
                min="1"
                style={{
                  width: '100%',
                  padding: '8px 12px',
                  backgroundColor: '#2d3142',
                  border: '1px solid #3f4456',
                  color: '#fff',
                  borderRadius: '6px',
                  fontSize: '14px'
                }}
              />
            )}
          </div>

          {/* Scope */}
          <div style={{ marginBottom: '24px' }}>
            <label style={{ display: 'block', fontSize: '14px', fontWeight: '500', color: '#fff', marginBottom: '8px' }}>
              Scope
            </label>
            <select
              value={scope}
              onChange={(e) => setScope(e.target.value)}
              style={{
                width: '100%',
                padding: '8px 12px',
                backgroundColor: '#2d3142',
                border: '1px solid #3f4456',
                color: '#fff',
                borderRadius: '6px',
                fontSize: '14px'
              }}
            >
              <option value="global">Global (All analysts)</option>
              <option value="team">Team (My team only)</option>
              <option value="personal">Personal (Only me)</option>
            </select>
          </div>

          {/* Info */}
          <div style={{
            backgroundColor: 'rgba(59, 130, 246, 0.1)',
            border: '1px solid rgba(59, 130, 246, 0.3)',
            borderRadius: '8px',
            padding: '12px',
            display: 'flex',
            alignItems: 'start',
            gap: '8px',
            marginBottom: '24px'
          }}>
            <Info size={20} color="#60a5fa" style={{ flexShrink: 0, marginTop: '2px' }} />
            <div style={{ fontSize: '12px', color: '#93c5fd' }}>
              <p style={{ margin: '0 0 4px 0' }}>All mute actions are logged for compliance (SOC 2, ISO 27001)</p>
              <p style={{ margin: 0 }}>Mute rules can be reviewed and deleted from the Mute Management page</p>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div style={{
          position: 'sticky',
          bottom: 0,
          backgroundColor: '#1a1d29',
          borderTop: '1px solid #2d3142',
          padding: '16px 24px',
          display: 'flex',
          gap: '12px',
          justifyContent: 'flex-end',
          zIndex: 3
        }}>
          <button
            onClick={onClose}
            disabled={loading}
            style={{
              padding: '8px 16px',
              backgroundColor: '#2d3142',
              color: '#fff',
              border: 'none',
              borderRadius: '6px',
              fontSize: '14px',
              cursor: loading ? 'not-allowed' : 'pointer',
              opacity: loading ? 0.5 : 1
            }}
            onMouseOver={(e) => !loading && (e.currentTarget.style.backgroundColor = '#3f4456')}
            onMouseOut={(e) => !loading && (e.currentTarget.style.backgroundColor = '#2d3142')}
          >
            Cancel
          </button>
          <button
            onClick={handleSubmit}
            disabled={loading || selectedOptions.length === 0 || !reason.trim()}
            style={{
              padding: '8px 16px',
              backgroundColor: '#3b82f6',
              color: '#fff',
              border: 'none',
              borderRadius: '6px',
              fontSize: '14px',
              cursor: (loading || selectedOptions.length === 0 || !reason.trim()) ? 'not-allowed' : 'pointer',
              opacity: (loading || selectedOptions.length === 0 || !reason.trim()) ? 0.5 : 1,
              display: 'flex',
              alignItems: 'center',
              gap: '8px'
            }}
            onMouseOver={(e) => !(loading || selectedOptions.length === 0 || !reason.trim()) && (e.currentTarget.style.backgroundColor = '#2563eb')}
            onMouseOut={(e) => !(loading || selectedOptions.length === 0 || !reason.trim()) && (e.currentTarget.style.backgroundColor = '#3b82f6')}
          >
            {loading ? (
              <>
                <div style={{
                  width: '16px',
                  height: '16px',
                  border: '2px solid #fff',
                  borderTopColor: 'transparent',
                  borderRadius: '50%',
                  animation: 'spin 1s linear infinite'
                }} />
                <span>Creating...</span>
              </>
            ) : (
              <>
                <VolumeX size={16} />
                <span>Create Mute Rule</span>
              </>
            )}
          </button>
        </div>

        {/* Conflict Warning Modal */}
        {showConflictModal && conflicts && (
          <div style={{
            position: 'fixed',
            top: 0,
            left: 0,
            right: 0,
            bottom: 0,
            backgroundColor: 'rgba(0, 0, 0, 0.75)',
            display: 'flex',
            justifyContent: 'center',
            alignItems: 'center',
            zIndex: 10001
          }}>
            <div style={{
              backgroundColor: '#1e293b',
              borderRadius: '12px',
              padding: '28px',
              maxWidth: '600px',
              width: '90%',
              maxHeight: '80vh',
              overflowY: 'auto',
              border: '1px solid #f59e0b'
            }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: '12px', marginBottom: '20px' }}>
                <span style={{ fontSize: '32px' }}>⚠️</span>
                <h3 style={{ margin: 0, fontSize: '20px', color: '#fff' }}>
                  Similar Mute Rules Detected
                </h3>
              </div>

              <div style={{ marginBottom: '20px', color: '#cbd5e1', fontSize: '14px', lineHeight: '1.6' }}>
                The mute rule was created successfully, but {conflicts.length} similar rule{conflicts.length > 1 ? 's' : ''} already exist{conflicts.length === 1 ? 's' : ''}.
                This might indicate redundancy.
              </div>

              <div style={{ marginBottom: '24px' }}>
                {conflicts.map((conflict, index) => (
                  <div key={index} style={{
                    backgroundColor: '#0f172a',
                    border: '1px solid #334155',
                    borderRadius: '8px',
                    padding: '16px',
                    marginBottom: '12px'
                  }}>
                    <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '8px' }}>
                      <span style={{
                        backgroundColor: conflict.type === 'exact' ? '#dc2626' : '#f59e0b',
                        color: '#fff',
                        padding: '4px 10px',
                        borderRadius: '4px',
                        fontSize: '12px',
                        fontWeight: '600',
                        textTransform: 'uppercase'
                      }}>
                        {conflict.type.replace(/_/g, ' ')}
                      </span>
                      <span style={{ color: '#94a3b8', fontSize: '13px' }}>
                        Rule ID: {conflict.rule_id.substring(0, 8)}...
                      </span>
                    </div>

                    <div style={{ fontSize: '14px', color: '#e2e8f0', marginBottom: '12px' }}>
                      {conflict.message}
                    </div>

                    <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '12px', fontSize: '13px' }}>
                      <div>
                        <span style={{ color: '#94a3b8' }}>Created by:</span>{' '}
                        <span style={{ color: '#fff', fontWeight: '500' }}>{conflict.created_by}</span>
                      </div>
                      <div>
                        <span style={{ color: '#94a3b8' }}>Created:</span>{' '}
                        <span style={{ color: '#fff' }}>{conflict.created_at}</span>
                      </div>
                      <div>
                        <span style={{ color: '#94a3b8' }}>Scope:</span>{' '}
                        <span style={{ color: '#fff', textTransform: 'capitalize' }}>{conflict.scope}</span>
                      </div>
                      <div>
                        <span style={{ color: '#94a3b8' }}>Expires:</span>{' '}
                        <span style={{ color: '#fff' }}>{conflict.expires}</span>
                      </div>
                    </div>

                    {conflict.existing_conditions && (
                      <div style={{ marginTop: '12px', paddingTop: '12px', borderTop: '1px solid #334155' }}>
                        <div style={{ color: '#94a3b8', fontSize: '12px', marginBottom: '6px' }}>
                          Existing Conditions:
                        </div>
                        <pre style={{
                          backgroundColor: '#020617',
                          padding: '10px',
                          borderRadius: '4px',
                          fontSize: '12px',
                          color: '#94a3b8',
                          margin: 0,
                          overflowX: 'auto'
                        }}>
                          {JSON.stringify(conflict.existing_conditions, null, 2)}
                        </pre>
                      </div>
                    )}
                  </div>
                ))}
              </div>

              <div style={{
                backgroundColor: '#0f172a',
                border: '1px solid #3b82f6',
                borderRadius: '8px',
                padding: '14px',
                marginBottom: '24px'
              }}>
                <div style={{ fontSize: '13px', color: '#cbd5e1', lineHeight: '1.6' }}>
                  <strong style={{ color: '#60a5fa' }}>Recommendation:</strong> Review existing rules to determine if this new rule is necessary.
                  You may want to extend an existing rule's expiration instead of creating a duplicate.
                </div>
              </div>

              <div style={{ display: 'flex', gap: '12px', justifyContent: 'flex-end' }}>
                <button
                  onClick={() => {
                    setShowConflictModal(false);
                    setConflicts(null);
                    // Close main modal and refresh
                    toast.success('Mute rule created successfully (with warnings)');
                    if (onMuteSuccess) {
                      onMuteSuccess(event.id);
                    }
                    onClose();
                  }}
                  style={{
                    padding: '10px 20px',
                    backgroundColor: '#3b82f6',
                    color: '#fff',
                    border: 'none',
                    borderRadius: '6px',
                    fontSize: '14px',
                    cursor: 'pointer',
                    fontWeight: '500'
                  }}
                  onMouseOver={(e) => e.currentTarget.style.backgroundColor = '#2563eb'}
                  onMouseOut={(e) => e.currentTarget.style.backgroundColor = '#3b82f6'}
                >
                  Understood
                </button>
              </div>
            </div>
          </div>
        )}

        <style>{`
          @keyframes spin {
            to { transform: rotate(360deg); }
          }
        `}</style>
      </div>
    </div>
  );
};

export default MuteAlertModal;
