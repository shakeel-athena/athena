import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { 
  getWAFLinuxVulnRules, 
  updateWAFLinuxVulnRuleAction,
  resetWAFLinuxVulnRule,
  createWAFLinuxVulnAllowList,
  getRuleMapping,
  getAllowListData
} from '../services/api';
import { X, Shield, Edit, RefreshCw } from 'lucide-react';
import AllowListModal from './AllowListModal';

const WAFLinuxVulnModal = ({ isOpen, onClose, signatureId, signatureName }) => {
  const [loadingRules, setLoadingRules] = useState({});
  const [allowListModal, setAllowListModal] = useState({ isOpen: false, ruleName: null });
  const queryClient = useQueryClient();

  // Fetch WAF Linux Vulnerability rules
  const {
    data: rulesData,
    isLoading,
    error,
    refetch
  } = useQuery({
    queryKey: ['waf-linux-vuln-rules'],
    queryFn: getWAFLinuxVulnRules,
    enabled: isOpen,
    refetchInterval: 10000 // Refresh every 10 seconds
  });

  // Update rule action mutation
  const updateRuleMutation = useMutation({
    mutationFn: ({ ruleName, action }) => updateWAFLinuxVulnRuleAction(ruleName, action),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['waf-linux-vuln-rules'] });
    },
    onError: (error) => {
      console.error('Failed to update rule action:', error);
    }
  });

  // Reset rule mutation
  const resetRuleMutation = useMutation({
    mutationFn: (ruleName) => resetWAFLinuxVulnRule(ruleName),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['waf-linux-vuln-rules'] });
    },
    onError: (error) => {
      console.error('Failed to reset rule:', error);
    }
  });

  const handleBypassRule = async (ruleName) => {
    setLoadingRules(prev => ({ ...prev, [ruleName]: true }));
    try {
      await updateRuleMutation.mutateAsync({ ruleName, action: 'Count' });
    } finally {
      setLoadingRules(prev => ({ ...prev, [ruleName]: false }));
    }
  };

  const handleResetRule = async (ruleName) => {
    setLoadingRules(prev => ({ ...prev, [ruleName]: true }));
    try {
      await resetRuleMutation.mutateAsync(ruleName);
    } finally {
      setLoadingRules(prev => ({ ...prev, [ruleName]: false }));
    }
  };

  const handleOpenAllowList = (ruleName) => {
    setAllowListModal({ isOpen: true, ruleName });
  };

  const handleCloseAllowList = () => {
    setAllowListModal({ isOpen: false, ruleName: null });
  };

  const handleSaveAllowList = async (ruleGroup, ruleName, ipList, domainList, existingRule) => {
    try {
      await createWAFLinuxVulnAllowList(ruleName, ipList, domainList);
      queryClient.invalidateQueries({ queryKey: ['waf-linux-vuln-rules'] });
    } catch (error) {
      console.error('Failed to save allow list:', error);
      throw error;
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
      <div className="bg-dark-800 rounded-xl border border-dark-700 max-w-4xl w-full mx-4 max-h-[95vh] overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between p-6 border-b border-dark-700">
          <div className="flex items-center space-x-3">
            <Shield className="w-6 h-6 text-primary-400" />
            <div>
              <h2 className="text-xl font-semibold text-white">WAF Linux Vulnerability Protection</h2>
              <p className="text-sm text-gray-400">{signatureName}</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 hover:bg-dark-700 rounded-lg transition-colors"
          >
            <X className="w-5 h-5 text-gray-400" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 overflow-y-auto max-h-[calc(95vh-140px)]">
          {isLoading ? (
            <div className="text-center py-12">
              <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary-400 mx-auto mb-4"></div>
              <h3 className="text-lg font-medium text-white mb-2">Loading Rules...</h3>
              <p className="text-gray-400">Fetching WAF Linux Vulnerability rules</p>
            </div>
          ) : error ? (
            <div className="text-center py-12">
              <div className="text-red-400 text-lg mb-4">Error Loading Rules</div>
              <p className="text-gray-400 mb-4">{error.message}</p>
              <button
                onClick={() => refetch()}
                className="flex items-center justify-center mx-auto px-4 py-2 bg-primary-600 text-white rounded-lg hover:bg-primary-700 transition-colors"
              >
                <RefreshCw className="w-4 h-4 mr-2" />
                Retry
              </button>
            </div>
          ) : rulesData?.rules ? (
            <div className="space-y-4">
              <div className="flex items-center justify-between mb-6">
                <div>
                  <h3 className="text-lg font-semibold text-white">Individual Rules</h3>
                  <p className="text-sm text-gray-400">
                    Total Rules: {Object.keys(rulesData.rules).length}
                  </p>
                </div>
              </div>
              
              {Object.values(rulesData.rules).map((rule) => (
                <div key={rule.name} className="bg-dark-700 rounded-lg p-4 border border-dark-600">
                  <div className="flex items-center justify-between">
                    <div className="flex-1">
                      <div className="flex items-center space-x-3 mb-2">
                        <h4 className="font-medium text-white">{rule.display_name}</h4>
                        <span className={`px-2 py-1 text-xs rounded-full ${
                          rule.current_action === 'Block' 
                            ? 'bg-red-900 text-red-300' 
                            : rule.current_action === 'Count'
                            ? 'bg-yellow-900 text-yellow-300'
                            : 'bg-green-900 text-green-300'
                        }`}>
                          {rule.current_action}
                        </span>
                      </div>
                      <p className="text-sm text-gray-400 mb-3">{rule.description}</p>
                      <div className="text-xs text-gray-500">
                        Default Action: {rule.default_action}
                      </div>
                    </div>
                    
                    <div className="flex items-center space-x-2 ml-4">
                      {rule.current_action !== 'Count' ? (
                        <button
                          onClick={() => handleBypassRule(rule.name)}
                          disabled={loadingRules[rule.name]}
                          className="flex items-center justify-center px-3 py-1.5 bg-green-600 text-white text-sm rounded-lg hover:bg-green-700 disabled:opacity-50 disabled:cursor-not-allowed transition-colors w-24"
                        >
                          {loadingRules[rule.name] ? (
                            <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white"></div>
                          ) : null}
                          <span>Bypass</span>
                        </button>
                      ) : (
                        <button
                          onClick={() => handleResetRule(rule.name)}
                          disabled={loadingRules[rule.name]}
                          className="flex items-center justify-center px-3 py-1.5 bg-gray-600 text-white text-sm rounded-lg hover:bg-gray-700 disabled:opacity-50 disabled:cursor-not-allowed transition-colors w-24"
                        >
                          {loadingRules[rule.name] ? (
                            <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white"></div>
                          ) : null}
                          <span>Reset</span>
                        </button>
                      )}
                      <button
                        onClick={() => handleOpenAllowList(rule.name)}
                        disabled={rule.current_action !== 'Count'}
                        className={`flex items-center justify-center px-3 py-1.5 text-white text-sm rounded-lg transition-colors w-24 ${
                          rule.current_action !== 'Count' 
                            ? 'bg-gray-400 cursor-not-allowed' 
                            : 'bg-blue-600 hover:bg-blue-700'
                        }`}
                      >
                        <Edit className="w-4 h-4 mr-1" />
                        <span>Allow</span>
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="text-center py-12">
              <div className="text-gray-400 text-lg mb-4">No Rules Found</div>
              <p className="text-gray-400">No Linux Vulnerability rules were found in the Web ACL</p>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="flex items-center justify-end space-x-3 p-6 border-t border-dark-700 bg-dark-700">
          <button
            onClick={onClose}
            className="px-4 py-2 text-gray-300 bg-dark-600 border border-dark-500 rounded-lg hover:bg-dark-500 transition-colors"
          >
            Close
          </button>
        </div>
      </div>

      {/* Allow List Modal */}
      <AllowListModal
        isOpen={allowListModal.isOpen}
        onClose={handleCloseAllowList}
        onSave={handleSaveAllowList}
        ruleName={allowListModal.ruleName}
        ruleGroup="linux-vuln"
      />
    </div>
  );
};

export default WAFLinuxVulnModal;
