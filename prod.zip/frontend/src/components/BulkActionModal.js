import React, { useState } from 'react';
import {
  EuiModal,
  EuiModalHeader,
  EuiModalHeaderTitle,
  EuiModalBody,
  EuiModalFooter,
  EuiButton,
  EuiButtonEmpty,
  EuiFormRow,
  EuiSelect,
  EuiTextArea,
  EuiCallOut,
  EuiSpacer,
  EuiText,
  EuiProgress
} from '@elastic/eui';
import toast from 'react-hot-toast';
import { bulkBlockIPs, bulkMuteAlerts } from '../services/api';

const BulkActionModal = ({ isOpen, onClose, selectedAlerts, actionType, onSuccess }) => {
  const [threatType, setThreatType] = useState('suspicious_activity');
  const [classification, setClassification] = useState('false_positive');
  const [reason, setReason] = useState('');
  const [durationHours, setDurationHours] = useState('168');
  const [loading, setLoading] = useState(false);
  const [progress, setProgress] = useState(null);

  const threatTypes = [
    { value: 'malware_c2', text: 'Malware C2 Communication' },
    { value: 'brute_force', text: 'Brute Force Attack' },
    { value: 'port_scan', text: 'Port Scanning' },
    { value: 'exploit_attempt', text: 'Exploit Attempt' },
    { value: 'ddos_source', text: 'DDoS Source' },
    { value: 'botnet', text: 'Botnet Activity' },
    { value: 'phishing', text: 'Phishing Source' },
    { value: 'data_exfiltration', text: 'Data Exfiltration' },
    { value: 'suspicious_activity', text: 'Suspicious Activity' },
    { value: 'other', text: 'Other' }
  ];

  const classifications = [
    { value: 'false_positive', text: 'False Positive' },
    { value: 'benign_positive', text: 'Benign Positive (Expected Activity)' },
    { value: 'noisy_signature', text: 'Noisy Signature' },
    { value: 'maintenance_window', text: 'Maintenance Window' },
    { value: 'business_approved', text: 'Business Approved Activity' }
  ];

  const durations = [
    { value: '1', text: '1 Hour' },
    { value: '24', text: '1 Day' },
    { value: '168', text: '1 Week (168 hours)' },
    { value: '720', text: '1 Month (30 days)' },
    { value: '8760', text: '1 Year' }
  ];

  const handleSubmit = async () => {
    if (!reason.trim()) {
      toast.error('Please provide a reason for this bulk action');
      return;
    }

    setLoading(true);
    setProgress({ current: 0, total: selectedAlerts.length, status: 'starting' });

    try {
      const analyst = localStorage.getItem('username') || 'admin';

      let result;
      if (actionType === 'block') {
        setProgress({ current: 0, total: selectedAlerts.length, status: 'blocking' });
        result = await bulkBlockIPs(selectedAlerts, analyst, threatType, reason);
      } else if (actionType === 'mute') {
        setProgress({ current: 0, total: selectedAlerts.length, status: 'muting' });
        result = await bulkMuteAlerts(
          selectedAlerts,
          analyst,
          classification,
          reason,
          parseInt(durationHours)
        );
      }

      const data = result?.data || result;

      // Show detailed results
      const successCount = data.blocked || data.muted || 0;
      const failedCount = data.failed || 0;
      const skippedCount = data.skipped || 0;

      if (successCount > 0) {
        toast.success(
          `Bulk action completed: ${successCount} succeeded, ${failedCount} failed, ${skippedCount} skipped`,
          { duration: 5000 }
        );
      } else {
        toast.error(`Bulk action failed: ${failedCount} errors`);
      }

      setProgress({ current: selectedAlerts.length, total: selectedAlerts.length, status: 'complete' });

      // Wait a moment to show completion
      setTimeout(() => {
        onSuccess(data);
        onClose();
      }, 1000);

    } catch (error) {
      console.error('Bulk action error:', error);
      toast.error(`Bulk action failed: ${error.message || 'Unknown error'}`);
      setProgress(null);
    } finally {
      setLoading(false);
    }
  };

  if (!isOpen) return null;

  const getTitle = () => {
    if (actionType === 'block') {
      return `Block ${selectedAlerts.length} IP${selectedAlerts.length > 1 ? 's' : ''}`;
    } else if (actionType === 'mute') {
      return `Mute ${selectedAlerts.length} Alert${selectedAlerts.length > 1 ? 's' : ''}`;
    }
    return 'Bulk Action';
  };

  return (
    <EuiModal onClose={onClose} maxWidth={600}>
      <EuiModalHeader>
        <EuiModalHeaderTitle>{getTitle()}</EuiModalHeaderTitle>
      </EuiModalHeader>

      <EuiModalBody>
        <EuiCallOut
          title={`You are about to ${actionType} ${selectedAlerts.length} alert${selectedAlerts.length > 1 ? 's' : ''}`}
          color="warning"
          iconType="alert"
        >
          <p>
            This action will be applied to all selected alerts. Make sure you have reviewed the selection.
          </p>
        </EuiCallOut>

        <EuiSpacer />

        {actionType === 'block' && (
          <EuiFormRow label="Threat Type" helpText="Classification for all blocked IPs">
            <EuiSelect
              value={threatType}
              onChange={(e) => setThreatType(e.target.value)}
              options={threatTypes}
              disabled={loading}
            />
          </EuiFormRow>
        )}

        {actionType === 'mute' && (
          <>
            <EuiFormRow label="Classification" helpText="Why are these alerts being muted?">
              <EuiSelect
                value={classification}
                onChange={(e) => setClassification(e.target.value)}
                options={classifications}
                disabled={loading}
              />
            </EuiFormRow>

            <EuiFormRow label="Duration" helpText="How long to mute these alerts">
              <EuiSelect
                value={durationHours}
                onChange={(e) => setDurationHours(e.target.value)}
                options={durations}
                disabled={loading}
              />
            </EuiFormRow>
          </>
        )}

        <EuiFormRow
          label="Reason"
          helpText="Explain why you are performing this bulk action (required for audit trail)"
        >
          <EuiTextArea
            value={reason}
            onChange={(e) => setReason(e.target.value)}
            rows={4}
            placeholder={`Example: Bulk ${actionType} during active incident - confirmed ${actionType === 'block' ? 'malicious activity' : 'false positives'} from security scan`}
            disabled={loading}
            required
          />
        </EuiFormRow>

        {progress && (
          <>
            <EuiSpacer />
            <EuiProgress
              value={progress.current}
              max={progress.total}
              color="success"
              size="m"
            />
            <EuiSpacer size="s" />
            <EuiText size="s" textAlign="center">
              {progress.status === 'starting' && 'Starting bulk action...'}
              {progress.status === 'blocking' && `Blocking IPs... (${progress.current}/${progress.total})`}
              {progress.status === 'muting' && `Muting alerts... (${progress.current}/${progress.total})`}
              {progress.status === 'complete' && `Complete! (${progress.current}/${progress.total})`}
            </EuiText>
          </>
        )}
      </EuiModalBody>

      <EuiModalFooter>
        <EuiButtonEmpty onClick={onClose} disabled={loading}>
          Cancel
        </EuiButtonEmpty>

        <EuiButton
          onClick={handleSubmit}
          fill
          color={actionType === 'block' ? 'danger' : 'primary'}
          disabled={loading || !reason.trim()}
          isLoading={loading}
        >
          {actionType === 'block' ? '🚫 Block All' : '🔇 Mute All'}
        </EuiButton>
      </EuiModalFooter>
    </EuiModal>
  );
};

export default BulkActionModal;
