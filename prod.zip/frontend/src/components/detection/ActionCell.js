import React, { memo } from 'react';
import {
  EuiFlexGroup,
  EuiFlexItem,
  EuiButtonIcon
} from '@elastic/eui';

/**
 * Action cell component for the events table
 * Handles expand/collapse and mute actions
 * Memoized to prevent unnecessary re-renders
 */
const ActionCell = memo(({
  itemId,
  isExpanded,
  isMuted,
  onToggleExpand,
  onMute
}) => {
  const handleToggle = () => {
    onToggleExpand(itemId);
  };

  const handleMute = (e) => {
    e.stopPropagation();
    onMute(e, itemId);
  };

  return (
    <EuiFlexGroup gutterSize="xs" responsive={false}>
      <EuiFlexItem grow={false}>
        <EuiButtonIcon
          iconType={isExpanded ? 'arrowUp' : 'arrowDown'}
          aria-label="Toggle details"
          onClick={handleToggle}
          color="text"
        />
      </EuiFlexItem>
      <EuiFlexItem grow={false}>
        <EuiButtonIcon
          iconType="bellSlash"
          aria-label="Mute alert"
          onClick={handleMute}
          color={isMuted ? 'danger' : 'text'}
        />
      </EuiFlexItem>
    </EuiFlexGroup>
  );
}, (prevProps, nextProps) => {
  // Only re-render if these specific props change
  return (
    prevProps.itemId === nextProps.itemId &&
    prevProps.isExpanded === nextProps.isExpanded &&
    prevProps.isMuted === nextProps.isMuted
  );
});

ActionCell.displayName = 'ActionCell';

export default ActionCell;
