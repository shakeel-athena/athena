import React, { memo } from 'react';
import {
  EuiPanel,
  EuiFlexGroup,
  EuiFlexItem,
  EuiTitle,
  EuiSpacer,
  EuiDescriptionList,
  EuiDescriptionListTitle,
  EuiDescriptionListDescription,
  EuiText,
  EuiBadge,
  EuiLink,
  EuiButton,
  EuiCodeBlock,
  EuiIcon
} from '@elastic/eui';
import IPEnrichmentTooltip from '../IPEnrichmentTooltip';

/**
 * Expanded row component for Wazuh (Host) alerts
 * Displays detailed information about a Wazuh security event
 */
const WazuhExpandedRow = memo(({
  event,
  onSearchByRule,
  onBlockIP,
  getSeverityColor
}) => {
  const rawRule = event.raw?.rule || {};
  const rawAgent = event.raw?.agent || {};
  const rawManager = event.raw?.manager || {};
  const rawDecoder = event.raw?.decoder || {};

  return (
    <EuiPanel color="subdued" paddingSize="m">
      <EuiFlexGroup>
        {/* Column 1: Event Details */}
        <EuiFlexItem>
          <EuiTitle size="xs"><h4>Host Event Details</h4></EuiTitle>
          <EuiSpacer size="s" />
          <EuiDescriptionList compressed>
            <EuiDescriptionListTitle>Agent</EuiDescriptionListTitle>
            <EuiDescriptionListDescription>
              <strong>{event.agent_name || rawAgent.name || 'Unknown'}</strong>
              <EuiText size="xs" color="subdued">
                ID: {event.agent_id || rawAgent.id || 'N/A'}
              </EuiText>
            </EuiDescriptionListDescription>

            <EuiDescriptionListTitle>Rule</EuiDescriptionListTitle>
            <EuiDescriptionListDescription>
              <EuiLink onClick={() => onSearchByRule(event.rule_id || rawRule.id)}>
                {event.rule_id || rawRule.id || 'N/A'}
              </EuiLink>
              <EuiText size="xs" color="subdued">
                Level {event.rule_level || rawRule.level || 0}
              </EuiText>
            </EuiDescriptionListDescription>

            <EuiDescriptionListTitle>Fired Times</EuiDescriptionListTitle>
            <EuiDescriptionListDescription>
              {rawRule.firedtimes || 0} times
            </EuiDescriptionListDescription>

            <EuiDescriptionListTitle>Decoder</EuiDescriptionListTitle>
            <EuiDescriptionListDescription>
              <EuiBadge>{event.decoder_name || rawDecoder.name || 'N/A'}</EuiBadge>
            </EuiDescriptionListDescription>

            <EuiDescriptionListTitle>Location</EuiDescriptionListTitle>
            <EuiDescriptionListDescription>
              <code style={{ fontSize: '11px' }}>
                {event.location || 'N/A'}
              </code>
            </EuiDescriptionListDescription>

            <EuiDescriptionListTitle>Manager</EuiDescriptionListTitle>
            <EuiDescriptionListDescription>
              {rawManager.name || 'N/A'}
            </EuiDescriptionListDescription>
          </EuiDescriptionList>
        </EuiFlexItem>

        {/* Column 2: Classification */}
        <EuiFlexItem>
          <EuiTitle size="xs"><h4>Classification</h4></EuiTitle>
          <EuiSpacer size="s" />
          <EuiDescriptionList compressed>
            <EuiDescriptionListTitle>Groups</EuiDescriptionListTitle>
            <EuiDescriptionListDescription>
              <EuiFlexGroup gutterSize="xs" wrap>
                {rawRule.groups && rawRule.groups.length > 0 ? (
                  rawRule.groups.map((group, idx) => (
                    <EuiFlexItem grow={false} key={idx}>
                      <EuiBadge color="default">{group}</EuiBadge>
                    </EuiFlexItem>
                  ))
                ) : (
                  <span>None</span>
                )}
              </EuiFlexGroup>
            </EuiDescriptionListDescription>

            <EuiDescriptionListTitle>Severity</EuiDescriptionListTitle>
            <EuiDescriptionListDescription>
              Raw: L{event.rule_level || rawRule.level || 0} →
              <EuiBadge color={getSeverityColor(event.normalized_severity)}>
                {event.normalized_severity}
              </EuiBadge>
            </EuiDescriptionListDescription>
          </EuiDescriptionList>
        </EuiFlexItem>

        {/* Column 3: Compliance */}
        <EuiFlexItem>
          <EuiTitle size="xs"><h4>Compliance</h4></EuiTitle>
          <EuiSpacer size="s" />
          <EuiDescriptionList compressed>
            {rawRule.pci_dss && rawRule.pci_dss.length > 0 && (
              <>
                <EuiDescriptionListTitle>
                  <EuiIcon type="document" /> PCI-DSS
                </EuiDescriptionListTitle>
                <EuiDescriptionListDescription>
                  {rawRule.pci_dss.join(', ')}
                </EuiDescriptionListDescription>
              </>
            )}

            {rawRule.gdpr && rawRule.gdpr.length > 0 && (
              <>
                <EuiDescriptionListTitle>
                  <EuiIcon type="shield" /> GDPR
                </EuiDescriptionListTitle>
                <EuiDescriptionListDescription>
                  {rawRule.gdpr.join(', ')}
                </EuiDescriptionListDescription>
              </>
            )}

            {rawRule.hipaa && rawRule.hipaa.length > 0 && (
              <>
                <EuiDescriptionListTitle>
                  <EuiIcon type="cut" /> HIPAA
                </EuiDescriptionListTitle>
                <EuiDescriptionListDescription>
                  {rawRule.hipaa.join(', ')}
                </EuiDescriptionListDescription>
              </>
            )}

            {rawRule.nist_800_53 && rawRule.nist_800_53.length > 0 && (
              <>
                <EuiDescriptionListTitle>
                  <EuiIcon type="document" /> NIST 800-53
                </EuiDescriptionListTitle>
                <EuiDescriptionListDescription>
                  {rawRule.nist_800_53.join(', ')}
                </EuiDescriptionListDescription>
              </>
            )}
          </EuiDescriptionList>
        </EuiFlexItem>
      </EuiFlexGroup>

      {/* Network Information (if available) */}
      {(event.src_ip || event.dest_ip) && (
        <>
          <EuiSpacer size="m" />
          <EuiTitle size="xxs"><h5>Network Information</h5></EuiTitle>
          <EuiSpacer size="s" />
          <EuiDescriptionList compressed>
            {event.src_ip && event.src_ip !== 'Unknown' && (
              <>
                <EuiDescriptionListTitle>Source</EuiDescriptionListTitle>
                <EuiDescriptionListDescription>
                  <IPEnrichmentTooltip ipAddress={event.src_ip} placement="right">
                    <code style={{ fontSize: '11px' }}>
                      {event.src_ip}{event.src_port ? `:${event.src_port}` : ''}
                    </code>
                  </IPEnrichmentTooltip>
                </EuiDescriptionListDescription>
              </>
            )}
            {event.dest_ip && event.dest_ip !== 'Unknown' && (
              <>
                <EuiDescriptionListTitle>Destination</EuiDescriptionListTitle>
                <EuiDescriptionListDescription>
                  <IPEnrichmentTooltip ipAddress={event.dest_ip} placement="right">
                    <code style={{ fontSize: '11px' }}>
                      {event.dest_ip}{event.dest_port ? `:${event.dest_port}` : ''}
                    </code>
                  </IPEnrichmentTooltip>
                </EuiDescriptionListDescription>
              </>
            )}
          </EuiDescriptionList>
        </>
      )}

      {/* Additional Data (SCA, Policy, etc.) */}
      {event.data && Object.keys(event.data).length > 0 && (
        <>
          <EuiSpacer size="m" />
          <EuiTitle size="xxs"><h5>Additional Data</h5></EuiTitle>
          <EuiSpacer size="s" />
          {event.data.sca && (
            <EuiDescriptionList compressed>
              <EuiDescriptionListTitle>Security Configuration Assessment</EuiDescriptionListTitle>
              <EuiDescriptionListDescription>
                <EuiText size="xs">
                  <strong>{event.data.sca.policy}</strong>
                  <br />
                  Score: <EuiBadge color={event.data.sca.score >= 70 ? 'success' : event.data.sca.score >= 50 ? 'warning' : 'danger'}>
                    {event.data.sca.score}%
                  </EuiBadge>
                  {' '}
                  ({event.data.sca.passed} passed, {event.data.sca.failed} failed, {event.data.sca.invalid} invalid)
                  <br />
                  <EuiText size="xs" color="subdued">
                    {event.data.sca.description}
                  </EuiText>
                </EuiText>
              </EuiDescriptionListDescription>
            </EuiDescriptionList>
          )}
          {!event.data.sca && (
            <EuiCodeBlock language="json" fontSize="s" paddingSize="s" isCopyable>
              {JSON.stringify(event.data, null, 2)}
            </EuiCodeBlock>
          )}
        </>
      )}

      {/* Full Log */}
      <EuiSpacer size="m" />
      <EuiTitle size="xxs"><h5>Full Log</h5></EuiTitle>
      <EuiCodeBlock language={event.full_log && event.full_log.trim() ? "text" : "json"} fontSize="s" paddingSize="s" isCopyable>
        {event.full_log && event.full_log.trim()
          ? event.full_log
          : JSON.stringify(event.raw, null, 2)}
      </EuiCodeBlock>

      {/* Quick Actions */}
      <EuiSpacer size="m" />
      <EuiFlexGroup gutterSize="s">
        {/* Block IP Button for Wazuh alerts */}
        {event.src_ip && event.src_ip !== 'Unknown' && (
          <EuiFlexItem grow={false}>
            <EuiButton
              size="s"
              color="danger"
              iconType="cross"
              onClick={() => onBlockIP(event)}
            >
              Block IP ({event.src_ip})
            </EuiButton>
          </EuiFlexItem>
        )}
        <EuiFlexItem grow={false}>
          <EuiButton size="s" iconType="search">
            Find Similar (Rule {event.rule_id || rawRule.id})
          </EuiButton>
        </EuiFlexItem>
      </EuiFlexGroup>
    </EuiPanel>
  );
}, (prevProps, nextProps) => {
  // Custom comparison - only re-render if the event ID changes
  return prevProps.event.id === nextProps.event.id;
});

WazuhExpandedRow.displayName = 'WazuhExpandedRow';

export default WazuhExpandedRow;
