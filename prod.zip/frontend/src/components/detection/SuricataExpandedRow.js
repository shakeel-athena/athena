import React, { memo } from 'react';
import {
  EuiPanel,
  EuiFlexGroup,
  EuiFlexItem,
  EuiTitle,
  EuiSpacer,
  EuiDescriptionList,
  EuiDescriptionListTitle,
  EuiDescriptionListDescription,
  EuiText,
  EuiBadge,
  EuiLink,
  EuiButton
} from '@elastic/eui';

/**
 * Expanded row component for Suricata (Network) alerts
 * Displays detailed information about a Suricata network security event
 */
const SuricataExpandedRow = memo(({
  event,
  onSearchBySignature,
  onBlockIP,
  getSeverityColor
}) => {
  const rawAlert = event.raw?.alert || {};
  const rawEvent = event.raw?.event || {};
  const rawNode = event.raw?.node || {};

  return (
    <EuiPanel color="subdued" paddingSize="m">
      <EuiFlexGroup>
        {/* Column 1: Alert Details */}
        <EuiFlexItem>
          <EuiTitle size="xs"><h4>Network Alert Details</h4></EuiTitle>
          <EuiSpacer size="s" />
          <EuiDescriptionList compressed>
            <EuiDescriptionListTitle>Signature</EuiDescriptionListTitle>
            <EuiDescriptionListDescription>
              <strong>{event.signature || rawAlert.signature || 'Unknown'}</strong>
            </EuiDescriptionListDescription>

            <EuiDescriptionListTitle>Signature ID</EuiDescriptionListTitle>
            <EuiDescriptionListDescription>
              <EuiLink onClick={() => onSearchBySignature(event.signature_id || rawAlert.signature_id)}>
                {event.signature_id || rawAlert.signature_id || 'N/A'}
              </EuiLink>
              <EuiText size="xs" color="subdued">
                GID: {rawAlert.gid || 'N/A'} | Rev: {rawAlert.rev || 'N/A'}
              </EuiText>
            </EuiDescriptionListDescription>

            <EuiDescriptionListTitle>Category</EuiDescriptionListTitle>
            <EuiDescriptionListDescription>
              <EuiBadge color="accent">
                {event.category || rawAlert.category || 'Unknown'}
              </EuiBadge>
            </EuiDescriptionListDescription>

            <EuiDescriptionListTitle>Action</EuiDescriptionListTitle>
            <EuiDescriptionListDescription>
              <EuiBadge color={event.action === 'blocked' || rawAlert.action === 'blocked' ? 'danger' : 'default'}>
                {(event.action || rawAlert.action) === 'blocked' ? 'Blocked' : 'Allowed'}
              </EuiBadge>
            </EuiDescriptionListDescription>

            <EuiDescriptionListTitle>Severity</EuiDescriptionListTitle>
            <EuiDescriptionListDescription>
              Raw: S{event.severity || rawAlert.severity || 0} →
              <EuiBadge color={getSeverityColor(event.normalized_severity)}>
                {event.normalized_severity}
              </EuiBadge>
            </EuiDescriptionListDescription>
          </EuiDescriptionList>
        </EuiFlexItem>

        {/* Column 2: Network Details */}
        <EuiFlexItem>
          <EuiTitle size="xs"><h4>Network Details</h4></EuiTitle>
          <EuiSpacer size="s" />
          <EuiDescriptionList compressed>
            {event.src_ip && event.src_ip !== 'Unknown' && (
              <>
                <EuiDescriptionListTitle>Source</EuiDescriptionListTitle>
                <EuiDescriptionListDescription>
                  <code>{event.src_ip}:{event.src_port || '?'}</code>
                </EuiDescriptionListDescription>
              </>
            )}

            {event.dest_ip && event.dest_ip !== 'Unknown' && (
              <>
                <EuiDescriptionListTitle>Destination</EuiDescriptionListTitle>
                <EuiDescriptionListDescription>
                  <code>{event.dest_ip}:{event.dest_port || '?'}</code>
                </EuiDescriptionListDescription>
              </>
            )}

            {event.protocol && event.protocol !== 'Unknown' && (
              <>
                <EuiDescriptionListTitle>Protocol</EuiDescriptionListTitle>
                <EuiDescriptionListDescription>
                  <EuiBadge>{event.protocol}</EuiBadge>
                </EuiDescriptionListDescription>
              </>
            )}

            <EuiDescriptionListTitle>Interface</EuiDescriptionListTitle>
            <EuiDescriptionListDescription>
              {event.raw?.in_iface || 'N/A'}
            </EuiDescriptionListDescription>

            <EuiDescriptionListTitle>Packet Source</EuiDescriptionListTitle>
            <EuiDescriptionListDescription>
              {event.raw?.pkt_src || 'N/A'}
            </EuiDescriptionListDescription>

            <EuiDescriptionListTitle>TCP Flags</EuiDescriptionListTitle>
            <EuiDescriptionListDescription>
              {event.raw?.tcp_flags || 'none'}
            </EuiDescriptionListDescription>
          </EuiDescriptionList>
        </EuiFlexItem>

        {/* Column 3: Sensor Info */}
        <EuiFlexItem>
          <EuiTitle size="xs"><h4>Sensor Info</h4></EuiTitle>
          <EuiSpacer size="s" />
          <EuiDescriptionList compressed>
            <EuiDescriptionListTitle>Sensor Hostname</EuiDescriptionListTitle>
            <EuiDescriptionListDescription>
              <strong>{rawNode.hostname || rawEvent.host || 'Unknown'}</strong>
            </EuiDescriptionListDescription>

            <EuiDescriptionListTitle>Event Type</EuiDescriptionListTitle>
            <EuiDescriptionListDescription>
              {rawEvent.type || 'N/A'}
            </EuiDescriptionListDescription>

            <EuiDescriptionListTitle>Event Subtype</EuiDescriptionListTitle>
            <EuiDescriptionListDescription>
              <EuiBadge>{rawEvent.subtype || 'N/A'}</EuiBadge>
            </EuiDescriptionListDescription>
          </EuiDescriptionList>
        </EuiFlexItem>
      </EuiFlexGroup>

      {/* Flow Statistics (if available) */}
      {event.raw?.flow && (
        <>
          <EuiSpacer size="m" />
          <EuiTitle size="xxs"><h5>Flow Statistics</h5></EuiTitle>
          <EuiSpacer size="s" />
          <EuiFlexGroup>
            <EuiFlexItem>
              <EuiDescriptionList compressed>
                <EuiDescriptionListTitle>Total Packets</EuiDescriptionListTitle>
                <EuiDescriptionListDescription>
                  {event.raw.flow.pkts || 0} packets
                  ({event.raw.flow.pkts_toserver || 0} → server, {event.raw.flow.pkts_toclient || 0} ← client)
                </EuiDescriptionListDescription>
              </EuiDescriptionList>
            </EuiFlexItem>
            <EuiFlexItem>
              <EuiDescriptionList compressed>
                <EuiDescriptionListTitle>Total Bytes</EuiDescriptionListTitle>
                <EuiDescriptionListDescription>
                  {event.raw.flow.bytes || 0} bytes
                  ({event.raw.flow.bytes_toserver || 0} → server, {event.raw.flow.bytes_toclient || 0} ← client)
                </EuiDescriptionListDescription>
              </EuiDescriptionList>
            </EuiFlexItem>
            {event.raw.flow.start && (
              <EuiFlexItem>
                <EuiDescriptionList compressed>
                  <EuiDescriptionListTitle>Flow Start</EuiDescriptionListTitle>
                  <EuiDescriptionListDescription>
                    {new Date(event.raw.flow.start).toLocaleString()}
                  </EuiDescriptionListDescription>
                </EuiDescriptionList>
              </EuiFlexItem>
            )}
          </EuiFlexGroup>
        </>
      )}

      {/* TLS Information (if available) */}
      {event.raw?.tls && (
        <>
          <EuiSpacer size="m" />
          <EuiTitle size="xxs"><h5>TLS Information</h5></EuiTitle>
          <EuiSpacer size="s" />
          <EuiDescriptionList compressed>
            {event.raw.tls.version && (
              <>
                <EuiDescriptionListTitle>TLS Version</EuiDescriptionListTitle>
                <EuiDescriptionListDescription>
                  <EuiBadge>{event.raw.tls.version}</EuiBadge>
                </EuiDescriptionListDescription>
              </>
            )}
            {event.raw.tls.subject && (
              <>
                <EuiDescriptionListTitle>Certificate Subject</EuiDescriptionListTitle>
                <EuiDescriptionListDescription>
                  <code style={{ fontSize: '11px' }}>{event.raw.tls.subject}</code>
                </EuiDescriptionListDescription>
              </>
            )}
            {event.raw.tls.issuerdn && (
              <>
                <EuiDescriptionListTitle>Issuer</EuiDescriptionListTitle>
                <EuiDescriptionListDescription>
                  <code style={{ fontSize: '11px' }}>{event.raw.tls.issuerdn}</code>
                </EuiDescriptionListDescription>
              </>
            )}
            {event.raw.tls.ja3 && Object.keys(event.raw.tls.ja3).length > 0 && (
              <>
                <EuiDescriptionListTitle>JA3 Fingerprint</EuiDescriptionListTitle>
                <EuiDescriptionListDescription>
                  <code style={{ fontSize: '10px' }}>{event.raw.tls.ja3.hash || 'N/A'}</code>
                </EuiDescriptionListDescription>
              </>
            )}
          </EuiDescriptionList>
        </>
      )}

      {/* Application Protocol (if available) */}
      {event.raw?.app_proto && event.raw.app_proto !== 'failed' && (
        <>
          <EuiSpacer size="m" />
          <EuiTitle size="xxs"><h5>Application Protocol</h5></EuiTitle>
          <EuiSpacer size="s" />
          <EuiBadge color="primary">{event.raw.app_proto.toUpperCase()}</EuiBadge>
        </>
      )}

      {/* Quick Actions */}
      <EuiSpacer size="m" />
      <EuiFlexGroup gutterSize="s">
        {event.src_ip && event.src_ip !== 'Unknown' && (
          <EuiFlexItem grow={false}>
            <EuiButton
              size="s"
              color="danger"
              iconType="cross"
              onClick={() => onBlockIP(event)}
            >
              Block IP ({event.src_ip})
            </EuiButton>
          </EuiFlexItem>
        )}
        <EuiFlexItem grow={false}>
          <EuiButton size="s" iconType="search">
            Hunt Similar (SID {event.signature_id || rawAlert.signature_id})
          </EuiButton>
        </EuiFlexItem>
      </EuiFlexGroup>
    </EuiPanel>
  );
}, (prevProps, nextProps) => {
  // Custom comparison - only re-render if the event ID changes
  return prevProps.event.id === nextProps.event.id;
});

SuricataExpandedRow.displayName = 'SuricataExpandedRow';

export default SuricataExpandedRow;
