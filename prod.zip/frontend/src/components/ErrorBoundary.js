import React from 'react';
import { AlertTriangle } from 'lucide-react';

class ErrorBoundary extends React.Component {
  constructor(props) {
    super(props);
    this.state = { hasError: false, error: null, errorInfo: null };
  }

  static getDerivedStateFromError(error) {
    // Update state so the next render will show the fallback UI
    return { hasError: true };
  }

  componentDidCatch(error, errorInfo) {
    // Log the error to console for debugging
    console.error('ErrorBoundary caught an error:', error, errorInfo);
    
    // Store error info for display
    this.setState({
      error: error,
      errorInfo: errorInfo
    });

    // Check if it's a theme-related error
    if (error.message && error.message.includes('Cannot read properties of undefined')) {
      console.warn('Theme-related error detected. This is likely due to missing theme context.');
    }
  }

  render() {
    if (this.state.hasError) {
      // Check if it's a theme-related error and show a specific message
      const isThemeError = this.state.error?.message?.includes('Cannot read properties of undefined') &&
                          (this.state.error?.message?.includes('down') || 
                           this.state.error?.message?.includes('create'));

      return (
        <div className="min-h-96 flex items-center justify-center bg-dark-800 border border-dark-700 rounded-lg">
          <div className="text-center p-8 max-w-md">
            <div className="flex justify-center mb-4">
              <AlertTriangle className="w-12 h-12 text-warning" />
            </div>
            <h2 className="text-xl font-semibold text-white mb-2">
              {isThemeError ? 'Styling Error' : 'Something went wrong'}
            </h2>
            <p className="text-dark-400 mb-4">
              {isThemeError 
                ? 'There was an issue with the component styling. The application is trying to fix this automatically.'
                : 'An unexpected error occurred while rendering this component.'
              }
            </p>
            {isThemeError && (
              <div className="bg-dark-700 rounded-lg p-4 mb-4 text-left">
                <p className="text-sm text-dark-300 mb-2">
                  <strong>Technical Details:</strong> Theme context error detected
                </p>
                <p className="text-xs text-dark-400">
                  This error occurs when components try to access theme properties that aren't available. 
                  The development team has been notified and is working on a fix.
                </p>
              </div>
            )}
            <button
              onClick={() => {
                this.setState({ hasError: false, error: null, errorInfo: null });
                // Force a re-render
                window.location.reload();
              }}
              className="btn-primary"
            >
              Reload Page
            </button>
            {process.env.NODE_ENV === 'development' && (
              <details className="mt-4 text-left">
                <summary className="text-sm text-dark-400 cursor-pointer hover:text-white">
                  Error Details (Development Only)
                </summary>
                <pre className="mt-2 p-4 bg-dark-900 rounded text-xs text-red-400 overflow-auto">
                  {this.state.error && this.state.error.toString()}
                  <br />
                  {this.state.errorInfo?.componentStack || 'No component stack available'}
                </pre>
              </details>
            )}
          </div>
        </div>
      );
    }

    return this.props.children;
  }
}

export default ErrorBoundary;
