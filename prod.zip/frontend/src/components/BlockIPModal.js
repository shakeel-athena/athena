import React, { useState, useEffect } from 'react';
import toast from 'react-hot-toast';
import { blockIPFromAlert } from '../services/api';

const BlockIPModal = ({ isOpen, onClose, event, onBlockSuccess }) => {
  const [threatType, setThreatType] = useState('other');
  const [reason, setReason] = useState('');
  const [direction, setDirection] = useState('both');
  const [duration, setDuration] = useState('permanent');
  const [customHours, setCustomHours] = useState('');
  const [loading, setLoading] = useState(false);

  // Threat type options
  const threatTypes = [
    { value: 'malware_c2', label: 'Malware C2 Communication' },
    { value: 'brute_force', label: 'Brute Force Attack' },
    { value: 'port_scan', label: 'Port Scanning' },
    { value: 'exploit_attempt', label: 'Exploit Attempt' },
    { value: 'ddos_source', label: 'DDoS Source' },
    { value: 'botnet', label: 'Botnet Activity' },
    { value: 'phishing', label: 'Phishing Source' },
    { value: 'data_exfiltration', label: 'Data Exfiltration' },
    { value: 'suspicious_activity', label: 'Suspicious Activity' },
    { value: 'other', label: 'Other' }
  ];

  // Direction options
  const directions = [
    { value: 'inbound', label: 'Block Inbound Only' },
    { value: 'outbound', label: 'Block Outbound Only' },
    { value: 'both', label: 'Block Both Directions' }
  ];

  // Extract IP from event
  const getIPFromEvent = () => {
    if (!event) return null;

    // Both Suricata and Wazuh now have normalized src_ip at top level
    return event.src_ip || null;
  };

  // Pre-fill reason from alert
  useEffect(() => {
    if (event && isOpen) {
      const alertDesc = event.source === 'suricata'
        ? event.signature
        : event.rule_description;
      setReason(`Blocked from ${event.source} alert: ${alertDesc}`);
    }
  }, [event, isOpen]);

  const handleSubmit = async (e) => {
    e.preventDefault();

    const ip = getIPFromEvent();
    if (!ip || ip === 'Unknown') {
      toast.error('No valid IP address to block');
      return;
    }

    if (!reason.trim()) {
      toast.error('Please provide a reason for blocking this IP');
      return;
    }

    setLoading(true);

    try {
      // Calculate expiration hours
      let expiresInHours = null;
      if (duration === 'custom' && customHours) {
        expiresInHours = parseInt(customHours);
      } else if (duration !== 'permanent') {
        expiresInHours = parseInt(duration);
      }

      const response = await blockIPFromAlert(ip, {
        alert_id: event.id,
        alert_source: event.source,
        alert_severity: event.normalized_severity,
        threat_type: threatType,
        reason: reason.trim(),
        direction,
        analyst: localStorage.getItem('username') || 'admin',
        expires_in_hours: expiresInHours
      });

      // Show dual-layer blocking status with distinct states
      const wafEnforced = response?.data?.waf_enforced || false;
      const wafError = response?.data?.waf_error;

      if (wafEnforced) {
        // ✅ SUCCESS: Both layers blocked (green)
        toast.success(
          `✅ IP ${ip} blocked at BOTH layers\n` +
          `🛡️ Network Firewall: Active\n` +
          `🔐 WAF: Active`,
          {
            duration: 5000,
            icon: '✅',
            style: {
              background: '#065f46',
              color: '#fff',
              border: '2px solid #10b981'
            }
          }
        );
      } else if (!wafEnforced && !wafError) {
        // ✅ PARTIAL SUCCESS: Only network firewall (no WAF attempted)
        toast.success(
          `✅ IP ${ip} blocked at Network Firewall\n` +
          `🛡️ Network Firewall: Active\n` +
          `ℹ️ WAF: Not configured`,
          {
            duration: 4000,
            icon: '✅'
          }
        );
      } else {
        // ⚠️ WARNING: Network firewall succeeded, WAF failed (orange)
        toast(
          `⚠️ IP ${ip} partially blocked\n` +
          `🛡️ Network Firewall: Active ✅\n` +
          `🔐 WAF: Failed ❌\n` +
          `Error: ${wafError}`,
          {
            duration: 7000,
            icon: '⚠️',
            style: {
              background: '#92400e',
              color: '#fff',
              border: '2px solid #f59e0b'
            }
          }
        );
      }

      onBlockSuccess();
      onClose();
    } catch (error) {
      console.error('Block IP error:', error);
      toast.error(`Failed to block IP: ${error.response?.data?.message || error.message}`);
    } finally {
      setLoading(false);
    }
  };

  if (!isOpen || !event) return null;

  const ip = getIPFromEvent();

  return (
    <div style={{
      position: 'fixed',
      top: 0,
      left: 0,
      right: 0,
      bottom: 0,
      backgroundColor: 'rgba(0, 0, 0, 0.75)',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      zIndex: 10000
    }}>
      <div style={{
        backgroundColor: '#1a1a1a',
        borderRadius: '8px',
        padding: '24px',
        maxWidth: '600px',
        width: '90%',
        maxHeight: '90vh',
        overflow: 'auto',
        border: '1px solid #333',
        boxShadow: '0 4px 20px rgba(0,0,0,0.5)'
      }}>
        {/* Header */}
        <h2 style={{
          color: '#fff',
          marginTop: 0,
          marginBottom: '20px',
          fontSize: '20px',
          fontWeight: '600'
        }}>
          🚫 Block IP Address from Alert
        </h2>

        {/* Alert Context */}
        <div style={{
          backgroundColor: '#2a2a2a',
          padding: '16px',
          borderRadius: '6px',
          marginBottom: '24px',
          border: '1px solid #3a3a3a'
        }}>
          <h3 style={{
            color: '#fff',
            fontSize: '14px',
            marginTop: 0,
            marginBottom: '12px',
            fontWeight: '600'
          }}>
            Alert Details:
          </h3>
          <div style={{ color: '#ccc', fontSize: '13px', lineHeight: '1.8' }}>
            <div><strong style={{ color: '#fff' }}>Source:</strong> {event.source}</div>
            <div><strong style={{ color: '#fff' }}>Severity:</strong> {event.normalized_severity}</div>
            <div>
              <strong style={{ color: '#fff' }}>Alert:</strong>{' '}
              {event.source === 'suricata' ? event.signature : event.rule_description}
            </div>
            <div>
              <strong style={{ color: '#fff' }}>IP to Block:</strong>{' '}
              <span style={{
                color: '#ff6b6b',
                fontWeight: 'bold',
                fontFamily: 'monospace',
                fontSize: '14px'
              }}>
                {ip || 'Unknown'}
              </span>
            </div>
          </div>
        </div>

        <form onSubmit={handleSubmit}>
          {/* Threat Type */}
          <div style={{ marginBottom: '20px' }}>
            <label style={{
              color: '#fff',
              display: 'block',
              marginBottom: '8px',
              fontSize: '14px',
              fontWeight: '500'
            }}>
              Threat Type:
            </label>
            <select
              value={threatType}
              onChange={(e) => setThreatType(e.target.value)}
              style={{
                width: '100%',
                padding: '10px',
                backgroundColor: '#2a2a2a',
                color: '#fff',
                border: '1px solid #444',
                borderRadius: '4px',
                fontSize: '14px'
              }}
            >
              {threatTypes.map(type => (
                <option key={type.value} value={type.value}>
                  {type.label}
                </option>
              ))}
            </select>
          </div>

          {/* Direction */}
          <div style={{ marginBottom: '20px' }}>
            <label style={{
              color: '#fff',
              display: 'block',
              marginBottom: '8px',
              fontSize: '14px',
              fontWeight: '500'
            }}>
              Block Direction:
            </label>
            <select
              value={direction}
              onChange={(e) => setDirection(e.target.value)}
              style={{
                width: '100%',
                padding: '10px',
                backgroundColor: '#2a2a2a',
                color: '#fff',
                border: '1px solid #444',
                borderRadius: '4px',
                fontSize: '14px'
              }}
            >
              {directions.map(dir => (
                <option key={dir.value} value={dir.value}>
                  {dir.label}
                </option>
              ))}
            </select>
          </div>

          {/* Duration */}
          <div style={{ marginBottom: '20px' }}>
            <label style={{
              color: '#fff',
              display: 'block',
              marginBottom: '8px',
              fontSize: '14px',
              fontWeight: '500'
            }}>
              Block Duration:
            </label>
            <select
              value={duration}
              onChange={(e) => setDuration(e.target.value)}
              style={{
                width: '100%',
                padding: '10px',
                backgroundColor: '#2a2a2a',
                color: '#fff',
                border: '1px solid #444',
                borderRadius: '4px',
                fontSize: '14px',
                marginBottom: duration === 'custom' ? '12px' : '0'
              }}
            >
              <option value="1">1 Hour</option>
              <option value="24">24 Hours (1 Day)</option>
              <option value="168">7 Days (1 Week)</option>
              <option value="720">30 Days (1 Month)</option>
              <option value="2160">90 Days (3 Months)</option>
              <option value="custom">Custom Hours</option>
              <option value="permanent">Permanent</option>
            </select>

            {duration === 'custom' && (
              <input
                type="number"
                value={customHours}
                onChange={(e) => setCustomHours(e.target.value)}
                placeholder="Enter hours"
                min="1"
                style={{
                  width: '100%',
                  padding: '10px',
                  backgroundColor: '#2a2a2a',
                  color: '#fff',
                  border: '1px solid #444',
                  borderRadius: '4px',
                  fontSize: '14px'
                }}
              />
            )}
            <p style={{ color: '#888', fontSize: '12px', marginTop: '6px', marginBottom: 0 }}>
              {duration === 'permanent'
                ? 'Block will remain until manually removed'
                : `Block will auto-expire after ${duration === 'custom' ? customHours || '?' : duration} hours`}
            </p>
          </div>

          {/* Reason */}
          <div style={{ marginBottom: '20px' }}>
            <label style={{
              color: '#fff',
              display: 'block',
              marginBottom: '8px',
              fontSize: '14px',
              fontWeight: '500'
            }}>
              Reason: <span style={{ color: '#ff6b6b' }}>*</span>
            </label>
            <textarea
              value={reason}
              onChange={(e) => setReason(e.target.value)}
              required
              rows={3}
              placeholder="Why are you blocking this IP address?"
              style={{
                width: '100%',
                padding: '10px',
                backgroundColor: '#2a2a2a',
                color: '#fff',
                border: '1px solid #444',
                borderRadius: '4px',
                resize: 'vertical',
                fontSize: '14px',
                fontFamily: 'inherit'
              }}
            />
          </div>

          {/* Warning - Dual-Layer Blocking */}
          <div style={{
            backgroundColor: '#4a3000',
            padding: '14px',
            borderRadius: '6px',
            marginBottom: '24px',
            border: '1px solid #ffa500'
          }}>
            <div style={{
              color: '#ffa500',
              fontSize: '13px',
              lineHeight: '1.8'
            }}>
              <strong>⚠️  Warning:</strong> This will block the IP at <strong>TWO layers</strong>:
              <div style={{ marginTop: '8px', marginLeft: '20px' }}>
                <div style={{ marginBottom: '4px' }}>
                  ✓ <strong>Network Firewall</strong> (Layer 3/4) - Blocks ALL traffic (TCP/UDP/ICMP)
                </div>
                <div>
                  ✓ <strong>Web Application Firewall</strong> (Layer 7) - Blocks HTTP/HTTPS requests
                </div>
              </div>
              <div style={{ marginTop: '8px' }}>
                All traffic from/to this IP will be blocked <strong>immediately</strong> and permanently until manually unblocked.
              </div>
            </div>
          </div>

          {/* Buttons */}
          <div style={{
            display: 'flex',
            gap: '12px',
            justifyContent: 'flex-end'
          }}>
            <button
              type="button"
              onClick={onClose}
              disabled={loading}
              style={{
                padding: '10px 24px',
                backgroundColor: '#444',
                color: '#fff',
                border: 'none',
                borderRadius: '4px',
                cursor: loading ? 'not-allowed' : 'pointer',
                opacity: loading ? 0.5 : 1,
                fontSize: '14px',
                fontWeight: '500',
                transition: 'background-color 0.2s'
              }}
              onMouseEnter={(e) => {
                if (!loading) e.target.style.backgroundColor = '#555';
              }}
              onMouseLeave={(e) => {
                e.target.style.backgroundColor = '#444';
              }}
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={loading || !reason.trim()}
              style={{
                padding: '10px 24px',
                backgroundColor: '#d32f2f',
                color: '#fff',
                border: 'none',
                borderRadius: '4px',
                cursor: (loading || !reason.trim()) ? 'not-allowed' : 'pointer',
                opacity: (loading || !reason.trim()) ? 0.5 : 1,
                fontSize: '14px',
                fontWeight: '500',
                transition: 'background-color 0.2s'
              }}
              onMouseEnter={(e) => {
                if (!loading && reason.trim()) {
                  e.target.style.backgroundColor = '#b71c1c';
                }
              }}
              onMouseLeave={(e) => {
                e.target.style.backgroundColor = '#d32f2f';
              }}
            >
              {loading ? 'Blocking...' : '🚫 Block IP Now'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default BlockIPModal;
