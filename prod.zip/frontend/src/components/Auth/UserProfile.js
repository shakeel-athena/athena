import { useState } from 'react';
import {
  EuiPopover,
  EuiButton,
  EuiPanel,
  EuiFlexGroup,
  EuiFlexItem,
  EuiAvatar,
  EuiText,
  EuiBadge,
  EuiSpacer,
  EuiHorizontalRule,
  EuiButtonEmpty,
  EuiIcon,
} from '@elastic/eui';
import { LogOut } from 'lucide-react';
import { useAuth } from '../../contexts/AuthContext';

/**
 * UserProfile component - Displays user information and logout option
 * Typically placed in the header/navigation bar
 */
const UserProfile = () => {
  const { user, roles, logout, authenticated } = useAuth();
  const [isPopoverOpen, setIsPopoverOpen] = useState(false);

  if (!authenticated || !user) {
    return null;
  }

  const togglePopover = () => setIsPopoverOpen(!isPopoverOpen);
  const closePopover = () => setIsPopoverOpen(false);

  const button = (
    <EuiButton
      onClick={togglePopover}
      iconType="arrowDown"
      iconSide="right"
      size="s"
      fill={false}
      style={{
        backgroundColor: 'rgba(30, 41, 59, 0.8)',
        border: '1px solid rgba(59, 130, 246, 0.3)',
        color: '#fff',
      }}
    >
      <EuiFlexGroup gutterSize="s" alignItems="center" responsive={false}>
        <EuiFlexItem grow={false}>
          <EuiAvatar
            name={user.fullName || user.username}
            size="s"
            color="#3b82f6"
            initialsLength={2}
          />
        </EuiFlexItem>
        <EuiFlexItem grow={false} className="user-profile-name">
          <EuiText size="s" style={{ color: '#fff' }}>
            <strong>{user.fullName || user.username}</strong>
          </EuiText>
        </EuiFlexItem>
      </EuiFlexGroup>
    </EuiButton>
  );

  return (
    <EuiPopover
      button={button}
      isOpen={isPopoverOpen}
      closePopover={closePopover}
      anchorPosition="downRight"
      panelPaddingSize="none"
      hasArrow={false}
    >
      <EuiPanel
        style={{
          width: '320px',
          maxWidth: '90vw',
          backgroundColor: 'rgba(30, 41, 59, 0.95)',
          border: '1px solid rgba(59, 130, 246, 0.3)',
          boxShadow: '0 12px 24px rgba(0, 0, 0, 0.4)',
        }}
      >
        {/* User Info Section */}
        <div style={{ padding: '16px' }}>
          <EuiFlexGroup gutterSize="m" alignItems="center" responsive={false}>
            <EuiFlexItem grow={false}>
              <EuiAvatar
                name={user.fullName || user.username}
                size="l"
                color="#3b82f6"
                initialsLength={2}
              />
            </EuiFlexItem>
            <EuiFlexItem>
              <EuiText size="s">
                <strong style={{ color: '#fff' }}>{user.fullName || user.username}</strong>
              </EuiText>
              <EuiText size="xs" color="subdued">
                {user.email}
              </EuiText>
            </EuiFlexItem>
          </EuiFlexGroup>

          {/* Roles */}
          {roles.length > 0 && (
            <>
              <EuiSpacer size="m" />
              <EuiFlexGroup gutterSize="xs" alignItems="center" responsive={false}>
                <EuiFlexItem grow={false}>
                  <EuiIcon type="shield" size="s" color="subdued" />
                </EuiFlexItem>
                <EuiFlexItem grow={false}>
                  <EuiText size="xs" color="subdued">
                    Assigned Roles
                  </EuiText>
                </EuiFlexItem>
              </EuiFlexGroup>
              <EuiSpacer size="xs" />
              <EuiFlexGroup gutterSize="xs" wrap responsive={false}>
                {roles.map((role) => (
                  <EuiFlexItem grow={false} key={role}>
                    <EuiBadge
                      color="#3b82f6"
                      style={{
                        backgroundColor: 'rgba(59, 130, 246, 0.2)',
                        color: '#93c5fd',
                      }}
                    >
                      {role}
                    </EuiBadge>
                  </EuiFlexItem>
                ))}
              </EuiFlexGroup>
            </>
          )}
        </div>

        <EuiHorizontalRule margin="none" style={{ backgroundColor: 'rgba(59, 130, 246, 0.2)' }} />

        {/* User Details */}
        <div style={{ padding: '16px' }}>
          <EuiFlexGroup direction="column" gutterSize="s" responsive={false}>
            <EuiFlexItem>
              <EuiFlexGroup justifyContent="spaceBetween" responsive={false}>
                <EuiFlexItem grow={false}>
                  <EuiText size="xs" color="subdued">
                    Username
                  </EuiText>
                </EuiFlexItem>
                <EuiFlexItem grow={false}>
                  <EuiText size="xs" style={{ color: '#fff' }}>
                    <strong>{user.username}</strong>
                  </EuiText>
                </EuiFlexItem>
              </EuiFlexGroup>
            </EuiFlexItem>

            {user.firstName && (
              <EuiFlexItem>
                <EuiFlexGroup justifyContent="spaceBetween" responsive={false}>
                  <EuiFlexItem grow={false}>
                    <EuiText size="xs" color="subdued">
                      First Name
                    </EuiText>
                  </EuiFlexItem>
                  <EuiFlexItem grow={false}>
                    <EuiText size="xs" style={{ color: '#fff' }}>
                      <strong>{user.firstName}</strong>
                    </EuiText>
                  </EuiFlexItem>
                </EuiFlexGroup>
              </EuiFlexItem>
            )}

            {user.lastName && (
              <EuiFlexItem>
                <EuiFlexGroup justifyContent="spaceBetween" responsive={false}>
                  <EuiFlexItem grow={false}>
                    <EuiText size="xs" color="subdued">
                      Last Name
                    </EuiText>
                  </EuiFlexItem>
                  <EuiFlexItem grow={false}>
                    <EuiText size="xs" style={{ color: '#fff' }}>
                      <strong>{user.lastName}</strong>
                    </EuiText>
                  </EuiFlexItem>
                </EuiFlexGroup>
              </EuiFlexItem>
            )}

            <EuiFlexItem>
              <EuiFlexGroup justifyContent="spaceBetween" responsive={false}>
                <EuiFlexItem grow={false}>
                  <EuiText size="xs" color="subdued">
                    Email Status
                  </EuiText>
                </EuiFlexItem>
                <EuiFlexItem grow={false}>
                  <EuiText
                    size="xs"
                    style={{
                      color: user.emailVerified ? '#4ade80' : '#fbbf24',
                    }}
                  >
                    <strong>{user.emailVerified ? 'Verified' : 'Not Verified'}</strong>
                  </EuiText>
                </EuiFlexItem>
              </EuiFlexGroup>
            </EuiFlexItem>
          </EuiFlexGroup>
        </div>

        <EuiHorizontalRule margin="none" style={{ backgroundColor: 'rgba(59, 130, 246, 0.2)' }} />

        {/* Actions */}
        <div style={{ padding: '8px' }}>
          <EuiButtonEmpty
            onClick={() => {
              logout();
              closePopover();
            }}
            color="danger"
            iconType={() => <LogOut size={16} />}
            style={{ width: '100%', justifyContent: 'flex-start' }}
            size="s"
          >
            Sign Out
          </EuiButtonEmpty>
        </div>
      </EuiPanel>
    </EuiPopover>
  );
};

export default UserProfile;
