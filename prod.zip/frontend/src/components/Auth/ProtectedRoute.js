import React, { useRef, useEffect } from 'react';
import { Navigate, useLocation } from 'react-router-dom';
import { useAuth } from '../../contexts/AuthContext';

/**
 * Check if the current URL contains OAuth callback parameters
 * This indicates Keycloak is processing an authentication callback
 */
const isOAuthCallbackInProgress = () => {
  const hash = window.location.hash;
  return hash.includes('state=') || hash.includes('code=') || hash.includes('session_state=');
};

/**
 * ProtectedRoute component that requires authentication and optionally specific roles
 *
 * @param {object} props
 * @param {React.ReactNode} props.children - Child components to render if authorized
 * @param {string[]} props.roles - Optional array of roles required to access the route
 * @param {boolean} props.requireAll - If true, user must have ALL specified roles. If false, ANY role is sufficient
 * @param {string} props.redirectTo - Custom redirect path (defaults to /unauthorized)
 */
const ProtectedRoute = ({
  children,
  roles = [],
  requireAll = false,
  redirectTo = '/unauthorized'
}) => {
  const { initialized, authenticated, hasAnyRole, hasAllRoles, login } = useAuth();
  const location = useLocation();
  const loginAttemptedRef = useRef(false);

  // Reset login attempted flag when location changes or user becomes authenticated
  useEffect(() => {
    if (authenticated) {
      loginAttemptedRef.current = false;
    }
  }, [authenticated, location.pathname]);

  // Show loading while Keycloak initializes
  if (!initialized) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-900">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-500 mx-auto mb-4"></div>
          <p className="text-gray-400">Initializing authentication...</p>
        </div>
      </div>
    );
  }

  // Check if OAuth callback is being processed - wait for it to complete
  if (isOAuthCallbackInProgress()) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-900">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-500 mx-auto mb-4"></div>
          <p className="text-gray-400">Completing authentication...</p>
        </div>
      </div>
    );
  }

  // Redirect to login if not authenticated (with guard against duplicate calls)
  if (!authenticated) {
    if (!loginAttemptedRef.current) {
      loginAttemptedRef.current = true;
      // Pass the current location to preserve redirect after login
      login(location.pathname + location.search);
    }
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-900">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-500 mx-auto mb-4"></div>
          <p className="text-gray-400">Redirecting to login...</p>
        </div>
      </div>
    );
  }

  // Check role requirements if specified
  if (roles.length > 0) {
    const hasRequiredRoles = requireAll
      ? hasAllRoles(roles)
      : hasAnyRole(roles);

    if (!hasRequiredRoles) {
      return <Navigate to={redirectTo} state={{ from: location }} replace />;
    }
  }

  // User is authenticated and authorized
  return children;
};

export default ProtectedRoute;
