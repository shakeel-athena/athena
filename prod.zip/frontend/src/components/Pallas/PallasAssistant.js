import React, { useState, useRef, useEffect } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import {
    MessageCircle,
    X,
    Send,
    Sparkles,
    AlertTriangle,
    Shield,
    Search,
    Activity,
    ChevronRight
} from 'lucide-react';

// Page context suggestions - updated for current routes
const PAGE_SUGGESTIONS = {
    '/': ['Show alert summary', 'What needs attention?', 'Navigate to alerts'],
    '/dashboard': ['Explain analytics', 'Show critical alerts', 'What are the trends?'],
    '/alerts': ['Filter high severity', 'How to mute alerts?', 'Export alerts'],
    '/responses': ['View response history', 'Check active responses', 'Show blocked IPs'],
    '/policies': ['Create new policy', 'Review policy status', 'How policies work?'],
    '/intelligence': ['View threat intel', 'Search indicators', 'Latest threats'],
    '/audit': ['View audit logs', 'Filter by user', 'Export audit trail'],
    '/rules': ['View detection rules', 'How rules work?', 'Filter by severity'],
    '/firewall': ['Add firewall rule', 'Show active rules', 'Block an IP'],
    '/waf-signatures': ['View WAF rules', 'Add signature', 'Test WAF rule'],
    '/security/firewall-waf': ['Show blocked IPs', 'Add WAF rule', 'Review recent blocks'],
    '/detection/events': ['Search events', 'Filter by source', 'Show anomalies'],
    '/detection/promachos': ['Run threat hunt', 'Analyze patterns', 'Generate hypothesis'],
    '/detection/network-topology': ['Explain topology', 'Show threat actors', 'Focus on high risk'],
    '/detection/wazuh-rules': ['View Wazuh rules', 'Filter by level', 'Search rules'],
    '/detection/configuration': ['View config', 'Update settings', 'Check integrations'],
    '/threat-intelligence/datasets': ['View datasets', 'Import IOCs', 'Search indicators'],
    '/active-response': ['View responses', 'Block IP', 'Isolate host'],
    '/active-response/advanced': ['Advanced options', 'Custom response', 'View logs'],
    '/system-health': ['Check health', 'Agent status', 'View metrics'],
    '/admin/users': ['Manage users', 'Add new user', 'View permissions'],
    '/admin/roles': ['Manage roles', 'Create role', 'Assign permissions'],
    '/admin/mute-rules': ['View mute rules', 'Add mute rule', 'Expire old rules'],
    '/admin/blocked-ips': ['View blocked IPs', 'Unblock IP', 'Export list'],
    '/admin/agent-control': ['Agent health', 'Find offline agents', 'Deploy config'],
    default: ['How can I help?', 'Navigate to...', 'Search alerts']
};

// Get suggestions for current page
const getSuggestions = (pathname) => {
    return PAGE_SUGGESTIONS[pathname] || PAGE_SUGGESTIONS.default;
};

// Get page name from path
const getPageName = (pathname) => {
    const names = {
        '/': 'Home',
        '/dashboard': 'Analytics',
        '/alerts': 'Alerts',
        '/responses': 'Responses',
        '/policies': 'Policies',
        '/intelligence': 'Intelligence',
        '/audit': 'Audit Logs',
        '/rules': 'Rules',
        '/firewall': 'Firewall',
        '/waf-signatures': 'WAF Signatures',
        '/security/firewall-waf': 'Firewall & WAF',
        '/detection/events': 'Security Events',
        '/detection/promachos': 'AI Threat Hunting',
        '/detection/network-topology': 'Network Topology',
        '/detection/wazuh-rules': 'Wazuh Rules',
        '/detection/configuration': 'Configuration',
        '/threat-intelligence/datasets': 'Threat Datasets',
        '/active-response': 'Active Response',
        '/active-response/advanced': 'Advanced Response',
        '/system-health': 'System Health',
        '/admin/users': 'User Management',
        '/admin/roles': 'Role Management',
        '/admin/mute-rules': 'Mute Rules',
        '/admin/blocked-ips': 'Blocked IPs',
        '/admin/agent-control': 'Agent Control'
    };
    return names[pathname] || 'Athena';
};

const PallasAssistant = () => {
    const [isOpen, setIsOpen] = useState(false);
    const [messages, setMessages] = useState([
        {
            id: 1,
            type: 'assistant',
            content: "Hello! I'm Pallas, your security operations assistant. How can I help you today?",
            timestamp: new Date()
        }
    ]);
    const [inputValue, setInputValue] = useState('');
    const [isTyping, setIsTyping] = useState(false);
    const messagesEndRef = useRef(null);
    const inputRef = useRef(null);
    const location = useLocation();
    const navigate = useNavigate();

    // Scroll to bottom when messages change
    useEffect(() => {
        messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
    }, [messages]);

    // Focus input when opening
    useEffect(() => {
        if (isOpen) {
            setTimeout(() => inputRef.current?.focus(), 100);
        }
    }, [isOpen]);

    const handleSend = () => {
        if (!inputValue.trim()) return;

        // Add user message
        const userMessage = {
            id: Date.now(),
            type: 'user',
            content: inputValue,
            timestamp: new Date()
        };
        setMessages(prev => [...prev, userMessage]);
        const query = inputValue;
        setInputValue('');

        // Simulate AI response
        setIsTyping(true);
        setTimeout(() => {
            const response = getAIResponse(query, location.pathname, navigate);
            const assistantResponse = {
                id: Date.now() + 1,
                type: 'assistant',
                content: response.message,
                timestamp: new Date()
            };
            setMessages(prev => [...prev, assistantResponse]);
            setIsTyping(false);

            // Handle navigation if needed
            if (response.navigate) {
                setTimeout(() => navigate(response.navigate), 500);
            }
        }, 600 + Math.random() * 400);
    };

    const handleSuggestionClick = (suggestion) => {
        setInputValue(suggestion);
        setTimeout(() => {
            const input = inputRef.current;
            if (input) {
                const event = { key: 'Enter', shiftKey: false, preventDefault: () => {} };
                handleKeyPress(event);
            }
        }, 100);
    };

    const handleKeyPress = (e) => {
        if (e.key === 'Enter' && !e.shiftKey) {
            e.preventDefault();
            handleSend();
        }
    };

    const suggestions = getSuggestions(location.pathname);
    const pageName = getPageName(location.pathname);

    return (
        <>
            {/* Floating Button */}
            <button
                onClick={() => setIsOpen(!isOpen)}
                style={{
                    position: 'fixed',
                    bottom: '24px',
                    right: '24px',
                    width: '56px',
                    height: '56px',
                    borderRadius: '50%',
                    background: isOpen
                        ? 'linear-gradient(135deg, #6366F1 0%, #8B5CF6 100%)'
                        : 'linear-gradient(135deg, #3B82F6 0%, #8B5CF6 100%)',
                    border: 'none',
                    cursor: 'pointer',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    boxShadow: isOpen
                        ? '0 8px 32px rgba(99, 102, 241, 0.4)'
                        : '0 8px 32px rgba(59, 130, 246, 0.4)',
                    transition: 'all 0.3s ease',
                    zIndex: 1000,
                    animation: !isOpen ? 'pallasPulse 2s infinite' : 'none'
                }}
                title="Ask Pallas"
            >
                {isOpen ? (
                    <X size={24} color="#fff" />
                ) : (
                    <Sparkles size={24} color="#fff" />
                )}
            </button>

            {/* Chat Panel */}
            {isOpen && (
                <div
                    style={{
                        position: 'fixed',
                        bottom: '92px',
                        right: '24px',
                        width: '380px',
                        height: '520px',
                        background: 'linear-gradient(180deg, #0F172A 0%, #1E293B 100%)',
                        borderRadius: '16px',
                        border: '1px solid rgba(99, 102, 241, 0.3)',
                        boxShadow: '0 24px 48px rgba(0, 0, 0, 0.5), 0 0 0 1px rgba(255,255,255,0.05)',
                        display: 'flex',
                        flexDirection: 'column',
                        overflow: 'hidden',
                        zIndex: 999,
                        animation: 'pallasSlideUp 0.3s ease'
                    }}
                >
                    {/* Header */}
                    <div style={{
                        padding: '16px 20px',
                        background: 'linear-gradient(135deg, rgba(99, 102, 241, 0.2) 0%, rgba(139, 92, 246, 0.15) 100%)',
                        borderBottom: '1px solid rgba(99, 102, 241, 0.2)',
                        display: 'flex',
                        alignItems: 'center',
                        gap: '12px'
                    }}>
                        <div style={{
                            width: '40px',
                            height: '40px',
                            borderRadius: '10px',
                            background: 'linear-gradient(135deg, #6366F1 0%, #8B5CF6 100%)',
                            display: 'flex',
                            alignItems: 'center',
                            justifyContent: 'center'
                        }}>
                            <Sparkles size={22} color="#fff" />
                        </div>
                        <div>
                            <div style={{ color: '#F1F5F9', fontWeight: 600, fontSize: '15px' }}>
                                Pallas
                            </div>
                            <div style={{ color: '#94A3B8', fontSize: '12px' }}>
                                Security Assistant • {pageName}
                            </div>
                        </div>
                    </div>

                    {/* Messages Area */}
                    <div style={{
                        flex: 1,
                        overflowY: 'auto',
                        padding: '16px',
                        display: 'flex',
                        flexDirection: 'column',
                        gap: '12px'
                    }}>
                        {messages.map(msg => (
                            <div
                                key={msg.id}
                                style={{
                                    display: 'flex',
                                    justifyContent: msg.type === 'user' ? 'flex-end' : 'flex-start'
                                }}
                            >
                                <div style={{
                                    maxWidth: '85%',
                                    padding: '10px 14px',
                                    borderRadius: msg.type === 'user'
                                        ? '14px 14px 4px 14px'
                                        : '14px 14px 14px 4px',
                                    background: msg.type === 'user'
                                        ? 'linear-gradient(135deg, #3B82F6 0%, #6366F1 100%)'
                                        : 'rgba(51, 65, 85, 0.6)',
                                    color: '#F1F5F9',
                                    fontSize: '14px',
                                    lineHeight: '1.5'
                                }}>
                                    {msg.content}
                                </div>
                            </div>
                        ))}

                        {isTyping && (
                            <div style={{ display: 'flex', justifyContent: 'flex-start' }}>
                                <div style={{
                                    padding: '12px 16px',
                                    borderRadius: '14px 14px 14px 4px',
                                    background: 'rgba(51, 65, 85, 0.6)',
                                    display: 'flex',
                                    gap: '4px'
                                }}>
                                    <span className="pallas-typing-dot" style={{ animationDelay: '0ms' }}>•</span>
                                    <span className="pallas-typing-dot" style={{ animationDelay: '150ms' }}>•</span>
                                    <span className="pallas-typing-dot" style={{ animationDelay: '300ms' }}>•</span>
                                </div>
                            </div>
                        )}
                        <div ref={messagesEndRef} />
                    </div>

                    {/* Quick Suggestions */}
                    <div style={{
                        padding: '8px 16px',
                        borderTop: '1px solid rgba(51, 65, 85, 0.5)',
                        display: 'flex',
                        gap: '8px',
                        overflowX: 'auto',
                        flexShrink: 0
                    }}>
                        {suggestions.map((suggestion, i) => (
                            <button
                                key={i}
                                onClick={() => handleSuggestionClick(suggestion)}
                                style={{
                                    padding: '6px 12px',
                                    borderRadius: '16px',
                                    border: '1px solid rgba(99, 102, 241, 0.3)',
                                    background: 'rgba(99, 102, 241, 0.1)',
                                    color: '#A5B4FC',
                                    fontSize: '12px',
                                    cursor: 'pointer',
                                    whiteSpace: 'nowrap',
                                    transition: 'all 0.2s'
                                }}
                                onMouseOver={(e) => {
                                    e.target.style.background = 'rgba(99, 102, 241, 0.25)';
                                }}
                                onMouseOut={(e) => {
                                    e.target.style.background = 'rgba(99, 102, 241, 0.1)';
                                }}
                            >
                                {suggestion}
                            </button>
                        ))}
                    </div>

                    {/* Input Area */}
                    <div style={{
                        padding: '12px 16px',
                        borderTop: '1px solid rgba(51, 65, 85, 0.5)',
                        display: 'flex',
                        gap: '10px'
                    }}>
                        <input
                            ref={inputRef}
                            type="text"
                            value={inputValue}
                            onChange={(e) => setInputValue(e.target.value)}
                            onKeyPress={handleKeyPress}
                            placeholder="Ask Pallas anything..."
                            style={{
                                flex: 1,
                                padding: '10px 14px',
                                borderRadius: '10px',
                                border: '1px solid rgba(99, 102, 241, 0.3)',
                                background: 'rgba(15, 23, 42, 0.8)',
                                color: '#F1F5F9',
                                fontSize: '14px',
                                outline: 'none'
                            }}
                        />
                        <button
                            onClick={handleSend}
                            disabled={!inputValue.trim()}
                            style={{
                                width: '40px',
                                height: '40px',
                                borderRadius: '10px',
                                border: 'none',
                                background: inputValue.trim()
                                    ? 'linear-gradient(135deg, #3B82F6 0%, #6366F1 100%)'
                                    : 'rgba(51, 65, 85, 0.5)',
                                cursor: inputValue.trim() ? 'pointer' : 'default',
                                display: 'flex',
                                alignItems: 'center',
                                justifyContent: 'center',
                                transition: 'all 0.2s'
                            }}
                        >
                            <Send size={18} color={inputValue.trim() ? '#fff' : '#64748B'} />
                        </button>
                    </div>
                </div>
            )}

            {/* CSS for animations */}
            <style>{`
                @keyframes pallasPulse {
                    0%, 100% { transform: scale(1); }
                    50% { transform: scale(1.05); }
                }
                @keyframes pallasSlideUp {
                    from { opacity: 0; transform: translateY(20px); }
                    to { opacity: 1; transform: translateY(0); }
                }
                .pallas-typing-dot {
                    color: #94A3B8;
                    animation: pallasTypingBounce 1s infinite;
                }
                @keyframes pallasTypingBounce {
                    0%, 100% { opacity: 0.3; }
                    50% { opacity: 1; }
                }
            `}</style>
        </>
    );
};

// AI response generator with navigation support
const getAIResponse = (query, pathname, navigate) => {
    const q = query.toLowerCase();

    // Navigation intents
    if (q.includes('navigate') || q.includes('go to') || q.includes('show me') || q.includes('open')) {
        if (q.includes('alert')) {
            return { message: "Taking you to the Alerts page...", navigate: '/alerts' };
        }
        if (q.includes('dashboard') || q.includes('analytics')) {
            return { message: "Opening the Analytics dashboard...", navigate: '/dashboard' };
        }
        if (q.includes('topology') || q.includes('network')) {
            return { message: "Opening Network Topology...", navigate: '/detection/network-topology' };
        }
        if (q.includes('threat') && q.includes('hunt')) {
            return { message: "Opening AI Threat Hunting...", navigate: '/detection/promachos' };
        }
        if (q.includes('firewall')) {
            return { message: "Opening Firewall settings...", navigate: '/firewall' };
        }
        if (q.includes('response')) {
            return { message: "Opening Active Response...", navigate: '/active-response' };
        }
        if (q.includes('health') || q.includes('status')) {
            return { message: "Opening System Health...", navigate: '/system-health' };
        }
        if (q.includes('user')) {
            return { message: "Opening User Management...", navigate: '/admin/users' };
        }
        if (q.includes('blocked') || q.includes('block')) {
            return { message: "Opening Blocked IPs...", navigate: '/admin/blocked-ips' };
        }
    }

    // Help intents
    if (q.includes('help') || q.includes('how')) {
        if (q.includes('block')) {
            return {
                message: "To block an IP:\n1. Go to Alerts or Active Response\n2. Click on an alert with the IP\n3. Use the 'Block IP' button\n\nOr navigate to Firewall for manual entry.",
                navigate: null
            };
        }
        if (q.includes('mute')) {
            return {
                message: "To mute an alert:\n1. Click on any alert\n2. Select 'Mute'\n3. Choose duration and reason\n\nYou can also manage mute rules in Admin > Mute Rules.",
                navigate: null
            };
        }
        if (q.includes('export')) {
            return {
                message: "Most tables support export. Look for the 'Export' button or download icon in the top-right of each panel. You can export as CSV or JSON.",
                navigate: null
            };
        }
        if (q.includes('topology')) {
            return {
                message: "Network Topology shows your Protected Zone (agents) and Threat Zone (threat actors). Click nodes to see details, use layout toggle for different views.",
                navigate: null
            };
        }
    }

    // Status queries
    if (q.includes('attention') || q.includes('critical') || q.includes('urgent')) {
        return {
            message: "Check the Alerts page filtered by 'Critical' severity for immediate action items. Would you like me to take you there?",
            navigate: null
        };
    }

    if (q.includes('health') || q.includes('status')) {
        return {
            message: "Visit System Health for agent status and metrics, or check the Analytics dashboard for overall security posture.",
            navigate: null
        };
    }

    // Page-specific context
    if (pathname.includes('network-topology')) {
        return {
            message: "You're viewing Network Topology. The Protected Zone shows your agents, and Threat Zone shows detected threats. Click on any node to see details and take action.",
            navigate: null
        };
    }

    if (pathname.includes('promachos')) {
        return {
            message: "AI Threat Hunting helps you proactively search for threats. Use natural language queries to analyze patterns and detect anomalies.",
            navigate: null
        };
    }

    if (pathname.includes('alerts')) {
        return {
            message: "You're on the Alerts page. Use filters to narrow down by severity, source, or time range. Click any alert for details and response options.",
            navigate: null
        };
    }

    if (pathname.includes('active-response')) {
        return {
            message: "Active Response allows you to block IPs, isolate hosts, or run custom scripts. All actions are logged for audit purposes.",
            navigate: null
        };
    }

    // Default responses
    const defaults = [
        "I can help with security operations, navigation, and explaining features. What would you like to know?",
        "I'm here to assist with your security workflow. Ask me about alerts, threats, or how to use any feature.",
        "Try asking me to navigate somewhere, explain a feature, or help with a security task."
    ];

    return {
        message: defaults[Math.floor(Math.random() * defaults.length)],
        navigate: null
    };
};

export default PallasAssistant;
