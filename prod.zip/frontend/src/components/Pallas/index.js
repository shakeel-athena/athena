export { default as PallasAssistant } from './PallasAssistant';
export { default } from './PallasAssistant';
