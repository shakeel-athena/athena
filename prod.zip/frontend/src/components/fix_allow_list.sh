#!/bin/bash

# Function to fix Allow List button in a file
fix_allow_list_button() {
    local file="$1"
    echo "Fixing $file..."
    
    # Create a backup
    cp "$file" "${file}.backup"
    
    # Replace the button with the disabled version
    sed -i 's/className="flex items-center justify-center px-3 py-1.5 bg-blue-600 text-white text-sm rounded-lg hover:bg-blue-700 transition-colors w-24"/disabled={rule.current_action === '\''Count'\''}\n                        className={`flex items-center justify-center px-3 py-1.5 text-white text-sm rounded-lg transition-colors w-24 ${\n                          rule.current_action === '\''Count'\'' \n                            ? '\''bg-gray-400 cursor-not-allowed'\'' \n                            : '\''bg-blue-600 hover:bg-blue-700'\''\n                        }`}/' "$file"
}

# Fix all WAF modal files
for file in WAFIPReputationModal.js WAFAnonymousIPModal.js WAFLinuxVulnModal.js WAFUnixVulnModal.js WAFCommonAttackModal.js; do
    if [ -f "$file" ]; then
        fix_allow_list_button "$file"
    fi
done

echo "Done!"
