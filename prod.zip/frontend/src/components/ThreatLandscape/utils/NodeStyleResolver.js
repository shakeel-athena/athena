/**
 * NodeStyleResolver
 * Utility helpers for segment detection in 2D topology views.
 */

const DEFAULT_SEGMENT = 'Unknown Network';

const isValidIpv4Octet = (value) => {
  const num = Number(value);
  return Number.isInteger(num) && num >= 0 && num <= 255;
};

const isIpv4 = (ip) => {
  const parts = String(ip || '').trim().split('.');
  if (parts.length !== 4) return false;
  return parts.every(isValidIpv4Octet);
};

const isSubnet = (value) => {
  const parts = String(value || '').trim().split('/');
  if (parts.length !== 2) return false;
  const mask = Number(parts[1]);
  return isIpv4(parts[0]) && Number.isInteger(mask) && mask >= 0 && mask <= 32;
};

const ipToSubnet = (ip) => {
  if (!isIpv4(ip)) return null;
  if (ip === '0.0.0.0') return null;
  const parts = ip.split('.');
  return `${parts[0]}.${parts[1]}.${parts[2]}.0/24`;
};

/**
 * Detect the network segment a node belongs to.
 * Uses subnet/IP-based segmentation (no SIEM grouping).
 */
export function getNodeSegment(node) {
  if (!node) return DEFAULT_SEGMENT;

  if (node.subnet && isSubnet(node.subnet)) return node.subnet;

  const ip = String(node.ip || '').trim();
  const subnet = ipToSubnet(ip);
  if (subnet) return subnet;

  if (ip.includes(':')) return 'IPv6 Network';

  return DEFAULT_SEGMENT;
}
