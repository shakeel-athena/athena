import React, { useMemo, useRef, useState, useImperativeHandle, useEffect, forwardRef } from 'react';
import { getNodeSegment } from './utils/NodeStyleResolver';
import { getIconForRole, getIconForOS, ExternalThreatIcon, InternalThreatIcon } from './NodeIcons';
import * as d3 from 'd3';
import { buildLayout as buildNewLayout, extractNodesForLayout, calculateThreatLevel } from './layouts';

// --- ZONE-BASED SIDEBAR (Left) - Matching Canvas Layout ---
import { FaChevronRight, FaChevronDown, FaShieldHalved, FaSkullCrossbones, FaMagnifyingGlass } from 'react-icons/fa6';

const ZoneSidebar = ({ nodes, selectedNodeId, onSelectNode, onFocusNode }) => {
  const [expandedSections, setExpandedSections] = useState({
    protected: true,
    threat: true,
  });
  const [expandedSubGroups, setExpandedSubGroups] = useState({});
  const [searchQuery, setSearchQuery] = useState('');

  const toggleSection = (sectionId) => {
    setExpandedSections(prev => ({
      ...prev,
      [sectionId]: !prev[sectionId]
    }));
  };

  const toggleSubGroup = (groupId) => {
    setExpandedSubGroups(prev => ({
      ...prev,
      [groupId]: prev[groupId] === false ? true : false
    }));
  };

  // Classify node into zone: protected (agents) or threat (external threats)
  const getNodeZone = (node) => {
    if (!node) return 'unknown';
    if (node.isRegistered === true) return 'protected';
    if (node.isThreatActor || node.isHighRiskHost) return 'threat';
    return 'unknown'; // Hidden nodes that don't fit either zone
  };

  // Get agent connection status
  const getAgentStatus = (node) => {
    if (!node) return 'unknown';
    if (!node.isRegistered) return 'external';
    const status = String(node.status || '').toLowerCase();
    if (status === 'active' || status === 'connected' || status === 'online') return 'active';
    if (status === 'disconnected' || status === 'offline') return 'disconnected';
    if (status === 'never_connected' || status === 'pending') return 'never_connected';
    return node.isActive ? 'active' : 'inactive';
  };

  // Get threat severity for external nodes
  const getThreatSeverity = (node) => {
    if (!node) return 'low';
    const riskScore = Number(node.riskScore || 0);
    const alertCount = Number(node.alertCount || 0);
    if (node.critical || riskScore >= 70 || alertCount >= 5) return 'critical';
    if (riskScore >= 40 || alertCount >= 2) return 'high';
    return 'medium';
  };

  const getSeverity = (node) => {
    if (!node) return 'normal';
    const riskScore = Number(node.riskScore || 0);
    const alertCount = Number(node.alertCount || 0);
    if (node.critical || riskScore >= 70 || alertCount >= 5) return 'critical';
    if (riskScore >= 40 || alertCount > 0) return 'warning';
    return 'normal';
  };

  // Status colors
  const getStatusColor = (status) => {
    switch (status) {
      case 'active': return '#10B981';
      case 'disconnected': return '#F59E0B';
      case 'never_connected': return '#6B7280';
      default: return '#6B7280';
    }
  };

  // Threat severity colors
  const getThreatColor = (severity) => {
    switch (severity) {
      case 'critical': return '#EF4444';
      case 'high': return '#F97316';
      case 'medium': return '#F59E0B';
      default: return '#64748B';
    }
  };

  // Severity dot colors
  const getSeverityColor = (severity) => {
    switch (severity) {
      case 'critical': return '#EF4444';
      case 'warning': return '#F59E0B';
      default: return '#10B981';
    }
  };

  // Render SVG icon for node
  const renderNodeIcon = (node) => {
    // Check if this is a threat actor first
    const isThreatActor = node.isThreatActor || node.isHighRiskHost || (!node.isRegistered && (node.criticalCount > 0 || node.highCount > 0));

    if (isThreatActor) {
      // Use threat-specific icons
      const isExternal = node.isThreatActor && !node.isInternal;
      const ThreatIcon = isExternal ? ExternalThreatIcon : InternalThreatIcon; // Skull for external attackers, broken shield for compromised internal

      return (
        <svg width="16" height="16" viewBox="0 0 24 24" style={{ flexShrink: 0 }}>
          <ThreatIcon x={12} y={12} size={10} color="currentColor" />
        </svg>
      );
    }

    // For protected zone nodes (agents), use role/OS icons
    const role = node.role || 'endpoint';
    const roleLower = String(role).toLowerCase();
    const isGenericRole = roleLower.includes('endpoint') ||
                          roleLower.includes('desktop') ||
                          roleLower.includes('workstation') ||
                          roleLower.includes('pc') ||
                          roleLower === 'unknown' ||
                          !role;

    const RoleIcon = getIconForRole(role);
    const OSIcon = getIconForOS(node.os);
    const Icon = (isGenericRole && OSIcon) ? OSIcon : RoleIcon;

    return (
      <svg width="16" height="16" viewBox="0 0 24 24" style={{ flexShrink: 0 }}>
        <Icon x={12} y={12} size={10} color="currentColor" />
      </svg>
    );
  };

  // Separate nodes into zones
  const allNodes = nodes || [];

  // Filter by search query
  const filteredNodes = searchQuery.trim()
    ? allNodes.filter(node => {
        const query = searchQuery.toLowerCase();
        return (node.label || '').toLowerCase().includes(query) ||
               (node.id || '').toLowerCase().includes(query) ||
               (node.ip || '').toLowerCase().includes(query);
      })
    : allNodes;

  // Protected Zone: Registered agents
  const protectedNodes = filteredNodes.filter(n => getNodeZone(n) === 'protected');

  // Threat Zone: Threat actors and high-risk hosts
  const threatNodes = filteredNodes.filter(n => getNodeZone(n) === 'threat');

  // Group protected nodes by status
  const protectedByStatus = {
    active: protectedNodes.filter(n => getAgentStatus(n) === 'active'),
    disconnected: protectedNodes.filter(n => getAgentStatus(n) === 'disconnected'),
    never_connected: protectedNodes.filter(n => getAgentStatus(n) === 'never_connected' || getAgentStatus(n) === 'inactive'),
  };

  // Group threat nodes by severity
  const threatBySeverity = {
    critical: threatNodes.filter(n => getThreatSeverity(n) === 'critical'),
    high: threatNodes.filter(n => getThreatSeverity(n) === 'high'),
    medium: threatNodes.filter(n => getThreatSeverity(n) === 'medium'),
  };

  // Render a node item
  const renderNodeItem = (node, zone) => {
    const isSelected = selectedNodeId === node.id;
    const agentStatus = getAgentStatus(node);
    const severity = getSeverity(node);
    const threatSeverity = getThreatSeverity(node);

    return (
      <div
        key={node.id}
        onClick={() => {
          onSelectNode && onSelectNode(node);
          onFocusNode && onFocusNode(node.id);
        }}
        style={{
          display: 'flex',
          alignItems: 'center',
          gap: '10px',
          padding: '8px 16px 8px 48px',
          cursor: 'pointer',
          color: isSelected ? '#60A5FA' : '#94A3B8',
          fontSize: '12px',
          background: isSelected ? 'rgba(96, 165, 250, 0.1)' : 'transparent',
          borderLeft: isSelected ? '3px solid #60A5FA' : '3px solid transparent',
          transition: 'all 0.15s ease',
        }}
        onMouseEnter={(e) => {
          if (!isSelected) {
            e.currentTarget.style.background = 'rgba(255,255,255,0.03)';
            e.currentTarget.style.color = '#CBD5E1';
          }
        }}
        onMouseLeave={(e) => {
          if (!isSelected) {
            e.currentTarget.style.background = 'transparent';
            e.currentTarget.style.color = '#94A3B8';
          }
        }}
      >
        {/* Status/Severity Indicator */}
        <span
          style={{
            width: '8px',
            height: '8px',
            borderRadius: '50%',
            background: zone === 'protected' ? getSeverityColor(severity) : getThreatColor(threatSeverity),
            border: zone === 'protected' ? `2px solid ${getStatusColor(agentStatus)}` : 'none',
            flexShrink: 0,
            boxShadow: zone === 'threat' ? `0 0 4px ${getThreatColor(threatSeverity)}40` : 'none',
          }}
        />

        {/* Node Icon */}
        {renderNodeIcon(node)}

        {/* Node Label */}
        <span style={{
          flex: 1,
          overflow: 'hidden',
          textOverflow: 'ellipsis',
          whiteSpace: 'nowrap',
        }}>
          {node.label || node.ip || node.id}
        </span>

        {/* Alert count badge for threats */}
        {zone === 'threat' && (node.alertCount || 0) > 0 && (
          <span style={{
            background: getThreatColor(threatSeverity),
            color: '#fff',
            borderRadius: '8px',
            padding: '1px 6px',
            fontSize: '10px',
            fontWeight: 600,
          }}>
            {node.alertCount}
          </span>
        )}

        {/* Disconnected indicator for agents */}
        {zone === 'protected' && agentStatus === 'disconnected' && (
          <span style={{
            fontSize: '9px',
            color: '#F59E0B',
            fontWeight: 600,
          }}>OFF</span>
        )}
      </div>
    );
  };

  // Render sub-group header
  const renderSubGroup = (id, label, nodes, color, zone) => {
    if (nodes.length === 0) return null;
    const isExpanded = expandedSubGroups[id] !== false;

    return (
      <div key={id}>
        <div
          onClick={() => toggleSubGroup(id)}
          style={{
            display: 'flex',
            alignItems: 'center',
            gap: '8px',
            padding: '8px 16px 8px 32px',
            cursor: 'pointer',
            color: '#94A3B8',
            fontSize: '11px',
            fontWeight: 500,
            transition: 'background 0.15s ease',
          }}
          onMouseEnter={(e) => e.currentTarget.style.background = 'rgba(255,255,255,0.02)'}
          onMouseLeave={(e) => e.currentTarget.style.background = 'transparent'}
        >
          <span style={{ color: '#64748B', fontSize: '8px', width: '10px' }}>
            {isExpanded ? <FaChevronDown size={8} /> : <FaChevronRight size={8} />}
          </span>
          <span style={{
            width: '6px',
            height: '6px',
            borderRadius: '50%',
            background: color,
          }} />
          <span style={{ flex: 1 }}>{label}</span>
          <span style={{
            background: 'rgba(255,255,255,0.1)',
            color: '#64748B',
            borderRadius: '8px',
            padding: '1px 6px',
            fontSize: '10px',
            fontWeight: 600,
          }}>
            {nodes.length}
          </span>
        </div>
        {isExpanded && nodes.map(node => renderNodeItem(node, zone))}
      </div>
    );
  };

  return (
    <div style={{
      position: 'absolute',
      top: 0,
      left: 0,
      width: '250px',
      height: '100%',
      background: '#1D2631',
      borderRight: '1px solid rgba(255, 255, 255, 0.08)',
      zIndex: 20,
      overflowY: 'auto',
      fontFamily: 'Inter, -apple-system, BlinkMacSystemFont, sans-serif',
      display: 'flex',
      flexDirection: 'column',
    }}>
      {/* Header with Search */}
      <div style={{
        padding: '16px',
        borderBottom: '1px solid rgba(255, 255, 255, 0.06)',
      }}>
        <div style={{
          fontSize: '11px',
          fontWeight: 600,
          color: '#64748B',
          textTransform: 'uppercase',
          letterSpacing: '0.5px',
          marginBottom: '12px',
        }}>
          Network Zones
        </div>
        {/* Search Input */}
        <div style={{
          position: 'relative',
          display: 'flex',
          alignItems: 'center',
        }}>
          <FaMagnifyingGlass
            size={12}
            style={{
              position: 'absolute',
              left: '10px',
              color: '#64748B',
              pointerEvents: 'none',
            }}
          />
          <input
            type="text"
            placeholder="Search nodes..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            style={{
              width: '100%',
              padding: '8px 10px 8px 32px',
              background: 'rgba(255,255,255,0.05)',
              border: '1px solid rgba(255,255,255,0.1)',
              borderRadius: '6px',
              color: '#E2E8F0',
              fontSize: '12px',
              outline: 'none',
              transition: 'border-color 0.2s ease',
            }}
            onFocus={(e) => e.target.style.borderColor = 'rgba(96, 165, 250, 0.5)'}
            onBlur={(e) => e.target.style.borderColor = 'rgba(255,255,255,0.1)'}
          />
        </div>
      </div>

      {/* Zone Sections */}
      <div style={{ flex: 1, overflowY: 'auto', padding: '8px 0' }}>
        {/* Protected Zone Section */}
        <div>
          <div
            onClick={() => toggleSection('protected')}
            style={{
              display: 'flex',
              alignItems: 'center',
              gap: '10px',
              padding: '12px 16px',
              cursor: 'pointer',
              color: '#E2E8F0',
              fontSize: '13px',
              fontWeight: 600,
              transition: 'background 0.15s ease',
              borderLeft: '3px solid #10B981',
              background: 'rgba(16, 185, 129, 0.05)',
            }}
            onMouseEnter={(e) => e.currentTarget.style.background = 'rgba(16, 185, 129, 0.1)'}
            onMouseLeave={(e) => e.currentTarget.style.background = 'rgba(16, 185, 129, 0.05)'}
          >
            <span style={{ color: '#64748B', fontSize: '10px', width: '12px' }}>
              {expandedSections.protected ? <FaChevronDown size={10} /> : <FaChevronRight size={10} />}
            </span>
            <FaShieldHalved size={14} color="#10B981" />
            <span style={{ flex: 1 }}>Protected Zone</span>
            <span style={{
              background: 'rgba(16, 185, 129, 0.2)',
              color: '#10B981',
              borderRadius: '10px',
              padding: '2px 8px',
              fontSize: '11px',
              fontWeight: 600,
            }}>
              {protectedNodes.length}
            </span>
          </div>

          {expandedSections.protected && (
            <div style={{ paddingBottom: '8px' }}>
              {renderSubGroup('active', 'Active', protectedByStatus.active, '#10B981', 'protected')}
              {renderSubGroup('disconnected', 'Disconnected', protectedByStatus.disconnected, '#F59E0B', 'protected')}
              {renderSubGroup('never_connected', 'Never Connected', protectedByStatus.never_connected, '#6B7280', 'protected')}
              {protectedNodes.length === 0 && (
                <div style={{
                  padding: '12px 16px 12px 48px',
                  color: '#64748B',
                  fontSize: '11px',
                  fontStyle: 'italic',
                }}>
                  No agents found
                </div>
              )}
            </div>
          )}
        </div>

        {/* Threat Zone Section */}
        <div style={{ marginTop: '4px' }}>
          <div
            onClick={() => toggleSection('threat')}
            style={{
              display: 'flex',
              alignItems: 'center',
              gap: '10px',
              padding: '12px 16px',
              cursor: 'pointer',
              color: '#E2E8F0',
              fontSize: '13px',
              fontWeight: 600,
              transition: 'background 0.15s ease',
              borderLeft: '3px solid #EF4444',
              background: 'rgba(239, 68, 68, 0.05)',
            }}
            onMouseEnter={(e) => e.currentTarget.style.background = 'rgba(239, 68, 68, 0.1)'}
            onMouseLeave={(e) => e.currentTarget.style.background = 'rgba(239, 68, 68, 0.05)'}
          >
            <span style={{ color: '#64748B', fontSize: '10px', width: '12px' }}>
              {expandedSections.threat ? <FaChevronDown size={10} /> : <FaChevronRight size={10} />}
            </span>
            <FaSkullCrossbones size={14} color="#EF4444" />
            <span style={{ flex: 1 }}>Threat Zone</span>
            <span style={{
              background: threatNodes.length > 0 ? 'rgba(239, 68, 68, 0.2)' : 'rgba(100, 116, 139, 0.2)',
              color: threatNodes.length > 0 ? '#EF4444' : '#64748B',
              borderRadius: '10px',
              padding: '2px 8px',
              fontSize: '11px',
              fontWeight: 600,
            }}>
              {threatNodes.length}
            </span>
          </div>

          {expandedSections.threat && (
            <div style={{ paddingBottom: '8px' }}>
              {renderSubGroup('critical', 'Critical', threatBySeverity.critical, '#EF4444', 'threat')}
              {renderSubGroup('high', 'High Risk', threatBySeverity.high, '#F97316', 'threat')}
              {renderSubGroup('medium', 'Suspicious', threatBySeverity.medium, '#F59E0B', 'threat')}
              {threatNodes.length === 0 && (
                <div style={{
                  padding: '12px 16px 12px 48px',
                  color: '#64748B',
                  fontSize: '11px',
                  fontStyle: 'italic',
                }}>
                  No threats detected
                </div>
              )}
            </div>
          )}
        </div>
      </div>

      {/* Footer Summary */}
      <div style={{
        padding: '12px 16px',
        borderTop: '1px solid rgba(255, 255, 255, 0.06)',
        background: 'rgba(0,0,0,0.2)',
        display: 'flex',
        justifyContent: 'space-between',
        fontSize: '10px',
        color: '#64748B',
      }}>
        <span>Total: {filteredNodes.length} nodes</span>
        {searchQuery && (
          <span
            onClick={() => setSearchQuery('')}
            style={{ cursor: 'pointer', color: '#60A5FA' }}
          >
            Clear search
          </span>
        )}
      </div>
    </div>
  );
};

// --- ZONE STATS BAR (Top) - Zone-Aligned Statistics ---
const ZoneStatsBar = ({ nodes }) => {
  // Calculate stats from nodes
  const stats = useMemo(() => {
    const allNodes = nodes || [];

    // Protected Zone: Registered agents
    const protectedNodes = allNodes.filter(n => n.isRegistered === true);
    const activeAgents = protectedNodes.filter(n => {
      const status = String(n.status || '').toLowerCase();
      return status === 'active' || status === 'connected' || status === 'online' || n.isActive;
    }).length;
    const disconnectedAgents = protectedNodes.filter(n => {
      const status = String(n.status || '').toLowerCase();
      return status === 'disconnected' || status === 'offline';
    }).length;
    const neverConnected = protectedNodes.length - activeAgents - disconnectedAgents;

    // Threat Zone: External threats and internal high-risk
    const threatNodes = allNodes.filter(n => n.isThreatActor || n.isHighRiskHost);
    const externalThreats = threatNodes.filter(n => !n.isInternal && n.isThreatActor).length;
    const internalHighRisk = threatNodes.filter(n => n.isInternal || n.isHighRiskHost).length;

    // Alert counts from protected zone
    const protectedAlerts = protectedNodes.reduce((sum, n) => sum + (n.alertCount || 0), 0);
    const protectedCritical = protectedNodes.reduce((sum, n) => sum + (n.criticalCount || 0), 0);
    const protectedHigh = protectedNodes.reduce((sum, n) => sum + (n.highCount || 0), 0);

    // Threat alert counts
    const threatAlerts = threatNodes.reduce((sum, n) => sum + (n.alertCount || 0), 0);
    const threatCritical = threatNodes.reduce((sum, n) => sum + (n.criticalCount || 0), 0);

    // Calculate risk score
    const riskScore = Math.min(100,
      (externalThreats * 20) +
      (internalHighRisk * 10) +
      (threatCritical * 5) +
      (protectedCritical * 3) +
      (disconnectedAgents * 5)
    );

    const riskLevel = riskScore >= 80 ? 'CRITICAL' :
                      riskScore >= 60 ? 'ELEVATED' :
                      riskScore >= 40 ? 'GUARDED' : 'LOW';

    return {
      // Protected Zone
      totalAgents: protectedNodes.length,
      activeAgents,
      disconnectedAgents,
      neverConnected,
      protectedAlerts,
      protectedCritical,
      protectedHigh,
      // Threat Zone
      totalThreats: threatNodes.length,
      externalThreats,
      internalHighRisk,
      threatAlerts,
      threatCritical,
      // Risk
      riskScore,
      riskLevel,
    };
  }, [nodes]);

  const getRiskColor = (level) => {
    switch (level) {
      case 'CRITICAL': return '#EF4444';
      case 'ELEVATED': return '#F97316';
      case 'GUARDED': return '#F59E0B';
      default: return '#10B981';
    }
  };

  const riskColor = getRiskColor(stats.riskLevel);

  return (
    <div style={{
      position: 'absolute',
      top: '16px',
      left: '270px',
      right: '180px',
      display: 'flex',
      gap: '16px',
      zIndex: 15,
      pointerEvents: 'auto',
    }}>
      {/* Protected Zone Card */}
      <div style={{
        flex: 1,
        background: 'rgba(15, 23, 42, 0.95)',
        borderRadius: '12px',
        padding: '14px 18px',
        borderLeft: '4px solid #10B981',
        border: '1px solid rgba(16, 185, 129, 0.3)',
        backdropFilter: 'blur(8px)',
        boxShadow: '0 4px 16px rgba(0,0,0,0.3)',
      }}>
        <div style={{
          display: 'flex',
          alignItems: 'center',
          gap: '8px',
          marginBottom: '10px',
        }}>
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none">
            <path d="M12 2L4 6v6c0 5.5 3.5 10.7 8 12 4.5-1.3 8-6.5 8-12V6l-8-4z" fill="#10B981" fillOpacity="0.2" stroke="#10B981" strokeWidth="2"/>
          </svg>
          <span style={{ fontSize: '11px', fontWeight: 600, color: '#10B981', textTransform: 'uppercase', letterSpacing: '0.5px' }}>
            Protected Zone
          </span>
        </div>

        <div style={{ display: 'flex', alignItems: 'baseline', gap: '12px' }}>
          <span style={{ fontSize: '28px', fontWeight: 700, color: '#F8FAFC', fontFamily: 'Inter, sans-serif' }}>
            {stats.totalAgents}
          </span>
          <span style={{ fontSize: '12px', color: '#94A3B8' }}>agents</span>
        </div>

        <div style={{ display: 'flex', gap: '16px', marginTop: '8px' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '6px' }}>
            <span style={{
              width: '8px',
              height: '8px',
              borderRadius: '50%',
              background: '#10B981',
              boxShadow: '0 0 6px rgba(16, 185, 129, 0.6)',
            }} />
            <span style={{ fontSize: '12px', color: '#10B981', fontWeight: 500 }}>{stats.activeAgents} Active</span>
          </div>
          {stats.disconnectedAgents > 0 && (
            <div style={{ display: 'flex', alignItems: 'center', gap: '6px' }}>
              <span style={{
                width: '8px',
                height: '8px',
                borderRadius: '50%',
                background: '#F59E0B',
                boxShadow: '0 0 6px rgba(245, 158, 11, 0.6)',
              }} />
              <span style={{ fontSize: '12px', color: '#F59E0B', fontWeight: 500 }}>{stats.disconnectedAgents} Disconnected</span>
            </div>
          )}
          {stats.neverConnected > 0 && (
            <div style={{ display: 'flex', alignItems: 'center', gap: '6px' }}>
              <span style={{
                width: '8px',
                height: '8px',
                borderRadius: '50%',
                background: '#6B7280',
              }} />
              <span style={{ fontSize: '12px', color: '#6B7280', fontWeight: 500 }}>{stats.neverConnected} Pending</span>
            </div>
          )}
        </div>

        {/* Alert summary */}
        <div style={{
          marginTop: '10px',
          paddingTop: '10px',
          borderTop: '1px solid rgba(255,255,255,0.08)',
          display: 'flex',
          gap: '12px',
          fontSize: '11px',
        }}>
          <span style={{ color: '#94A3B8' }}>{stats.protectedAlerts} alerts</span>
          {stats.protectedCritical > 0 && (
            <span style={{ color: '#EF4444', fontWeight: 600 }}>{stats.protectedCritical} critical</span>
          )}
          {stats.protectedHigh > 0 && (
            <span style={{ color: '#F97316', fontWeight: 500 }}>{stats.protectedHigh} high</span>
          )}
        </div>
      </div>

      {/* Threat Zone Card */}
      <div style={{
        flex: 1,
        background: 'rgba(15, 23, 42, 0.95)',
        borderRadius: '12px',
        padding: '14px 18px',
        borderLeft: '4px solid #EF4444',
        border: '1px solid rgba(239, 68, 68, 0.3)',
        backdropFilter: 'blur(8px)',
        boxShadow: '0 4px 16px rgba(0,0,0,0.3)',
      }}>
        <div style={{
          display: 'flex',
          alignItems: 'center',
          gap: '8px',
          marginBottom: '10px',
        }}>
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none">
            <path d="M12 2L2 22h20L12 2z" fill="#EF4444" fillOpacity="0.2" stroke="#EF4444" strokeWidth="2"/>
            <path d="M12 9v4M12 17h.01" stroke="#EF4444" strokeWidth="2" strokeLinecap="round"/>
          </svg>
          <span style={{ fontSize: '11px', fontWeight: 600, color: '#EF4444', textTransform: 'uppercase', letterSpacing: '0.5px' }}>
            Threat Zone
          </span>
        </div>

        <div style={{ display: 'flex', alignItems: 'baseline', gap: '12px' }}>
          <span style={{
            fontSize: '28px',
            fontWeight: 700,
            color: stats.totalThreats > 0 ? '#EF4444' : '#F8FAFC',
            fontFamily: 'Inter, sans-serif'
          }}>
            {stats.totalThreats}
          </span>
          <span style={{ fontSize: '12px', color: '#94A3B8' }}>threats</span>
        </div>

        <div style={{ display: 'flex', gap: '16px', marginTop: '8px' }}>
          {stats.externalThreats > 0 && (
            <div style={{ display: 'flex', alignItems: 'center', gap: '6px' }}>
              <span style={{
                width: '8px',
                height: '8px',
                borderRadius: '50%',
                background: '#EF4444',
                boxShadow: '0 0 6px rgba(239, 68, 68, 0.6)',
              }} />
              <span style={{ fontSize: '12px', color: '#EF4444', fontWeight: 500 }}>{stats.externalThreats} External</span>
            </div>
          )}
          {stats.internalHighRisk > 0 && (
            <div style={{ display: 'flex', alignItems: 'center', gap: '6px' }}>
              <span style={{
                width: '8px',
                height: '8px',
                borderRadius: '50%',
                background: '#F97316',
                boxShadow: '0 0 6px rgba(249, 115, 22, 0.6)',
              }} />
              <span style={{ fontSize: '12px', color: '#F97316', fontWeight: 500 }}>{stats.internalHighRisk} Internal</span>
            </div>
          )}
          {stats.totalThreats === 0 && (
            <span style={{ fontSize: '12px', color: '#10B981', fontWeight: 500 }}>No active threats</span>
          )}
        </div>

        {/* Threat details */}
        <div style={{
          marginTop: '10px',
          paddingTop: '10px',
          borderTop: '1px solid rgba(255,255,255,0.08)',
          display: 'flex',
          gap: '12px',
          fontSize: '11px',
        }}>
          <span style={{ color: '#94A3B8' }}>{stats.threatAlerts} alerts</span>
          {stats.threatCritical > 0 && (
            <span style={{ color: '#EF4444', fontWeight: 600 }}>{stats.threatCritical} critical</span>
          )}
        </div>
      </div>

      {/* Risk Score Card */}
      <div style={{
        width: '180px',
        background: 'rgba(15, 23, 42, 0.95)',
        borderRadius: '12px',
        padding: '14px 18px',
        borderLeft: `4px solid ${riskColor}`,
        border: `1px solid ${riskColor}40`,
        backdropFilter: 'blur(8px)',
        boxShadow: '0 4px 16px rgba(0,0,0,0.3)',
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
        justifyContent: 'center',
      }}>
        <span style={{ fontSize: '11px', fontWeight: 600, color: '#94A3B8', textTransform: 'uppercase', letterSpacing: '0.5px', marginBottom: '8px' }}>
          Risk Score
        </span>

        {/* Circular Gauge */}
        <div style={{ position: 'relative', width: '64px', height: '64px' }}>
          <svg width="64" height="64" viewBox="0 0 64 64">
            {/* Background circle */}
            <circle
              cx="32"
              cy="32"
              r="28"
              fill="none"
              stroke="rgba(255,255,255,0.1)"
              strokeWidth="6"
            />
            {/* Progress arc */}
            <circle
              cx="32"
              cy="32"
              r="28"
              fill="none"
              stroke={riskColor}
              strokeWidth="6"
              strokeLinecap="round"
              strokeDasharray={`${(stats.riskScore / 100) * 176} 176`}
              transform="rotate(-90 32 32)"
              style={{
                filter: `drop-shadow(0 0 8px ${riskColor}60)`,
                transition: 'stroke-dasharray 0.5s ease',
              }}
            />
          </svg>
          {/* Score text */}
          <div style={{
            position: 'absolute',
            top: '50%',
            left: '50%',
            transform: 'translate(-50%, -50%)',
            textAlign: 'center',
          }}>
            <span style={{
              fontSize: '18px',
              fontWeight: 700,
              color: riskColor,
              fontFamily: 'Inter, sans-serif',
            }}>
              {stats.riskScore}
            </span>
          </div>
        </div>

        {/* Risk Level Label */}
        <span style={{
          marginTop: '8px',
          fontSize: '12px',
          fontWeight: 700,
          color: riskColor,
          textTransform: 'uppercase',
          letterSpacing: '0.5px',
        }}>
          {stats.riskLevel}
        </span>
      </div>
    </div>
  );
};

// --- LEGEND COMPONENT (Bottom-Right) ---
const Legend = () => {
  // Role-based icons
  const roleItems = [
    { label: 'NETWORK', role: 'network' },
  ];

  // OS-specific icons
  const osItems = [
    { label: 'WINDOWS', os: 'windows' },
    { label: 'MACOS', os: 'macos' },
    { label: 'LINUX', os: 'linux' },
  ];

  const renderLegendItem = (label, Icon) => (
    <div key={label} style={{
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'flex-end',
      gap: '10px',
      color: '#E3E8F2',
    }}>
      <span style={{
        fontSize: '11px',
        fontWeight: 400,
        letterSpacing: '0.5px',
        textTransform: 'uppercase',
        textShadow: '0 1px 2px rgba(0,0,0,0.8)'
      }}>
        {label}
      </span>
      <svg width="22" height="22" viewBox="0 0 24 24" style={{ background: '#2A3F5E', borderRadius: '4px' }}>
        <Icon x={12} y={12} size={12} color="#ffffff" />
      </svg>
    </div>
  );

  return (
    <div style={{
      position: 'absolute',
      bottom: '24px',
      right: '24px',
      width: '140px',
      display: 'flex',
      flexDirection: 'column',
      gap: '6px',
      pointerEvents: 'none',
      zIndex: 10
    }}>
      {/* Role Icons */}
      {roleItems.map((item) => {
        const Icon = getIconForRole(item.role);
        return renderLegendItem(item.label, Icon);
      })}

      {/* Separator */}
      <div style={{ height: '1px', background: 'rgba(255,255,255,0.1)', margin: '4px 0' }} />

      {/* OS Icons */}
      {osItems.map((item) => {
        const Icon = getIconForOS(item.os);
        return Icon ? renderLegendItem(item.label, Icon) : null;
      })}

      {/* Separator */}
      <div style={{ height: '1px', background: 'rgba(255,255,255,0.1)', margin: '4px 0' }} />

      {/* Agent Status Legend */}
      <div style={{ fontSize: '10px', color: '#94A3B8', marginBottom: '2px', textAlign: 'right' }}>STATUS</div>
      {[
        { label: 'Active', color: '#10B981', description: 'Agent connected and reporting' },
        { label: 'Disconnected', color: '#F59E0B', description: 'Agent offline or unreachable' },
        { label: 'External', color: '#64748B', description: 'Unregistered external host' },
      ].map(({ label, color, description }) => (
        <div
          key={label}
          title={description}
          style={{
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'flex-end',
            gap: '8px',
            color: '#E3E8F2',
          }}
        >
          <span style={{
            fontSize: '10px',
            fontWeight: 400,
            letterSpacing: '0.3px',
            textTransform: 'uppercase',
          }}>
            {label}
          </span>
          <div style={{
            width: '18px',
            height: '18px',
            borderRadius: '50%',
            border: `2px solid ${color}`,
            background: 'rgba(30, 41, 59, 0.8)',
            boxShadow: `0 0 6px ${color}40`,
          }} />
        </div>
      ))}
    </div>
  );
};

// --- MINIMAP COMPONENT (Bottom-Left) - Interactive Navigation ---
const MiniMap = ({ width, height, positions, systemCenter, segments, transform, onNavigate, containerWidth, containerHeight }) => {
  const mapWidth = 180;
  const mapHeight = 140;
  const padding = 10;

  // Calculate bounds of all nodes
  const nodePositions = positions ? Array.from(positions.entries()) : [];
  if (!nodePositions.length) return null;

  const xs = nodePositions.map(([, p]) => p.x);
  const ys = nodePositions.map(([, p]) => p.y);
  const minX = Math.min(...xs) - 50;
  const maxX = Math.max(...xs) + 50;
  const minY = Math.min(...ys) - 50;
  const maxY = Math.max(...ys) + 50;
  const dataWidth = maxX - minX;
  const dataHeight = maxY - minY;

  const scale = Math.min(
    (mapWidth - padding * 2) / dataWidth,
    (mapHeight - padding * 2) / dataHeight
  );

  const offsetX = (mapWidth - dataWidth * scale) / 2 - minX * scale;
  const offsetY = (mapHeight - dataHeight * scale) / 2 - minY * scale;

  // Calculate actual viewport rectangle based on current transform
  // The viewport shows what's currently visible in the main canvas
  const effectiveContainerWidth = containerWidth || 1200;
  const effectiveContainerHeight = containerHeight || 800;

  // Viewport in world coordinates (accounting for current transform)
  const viewportWorldWidth = effectiveContainerWidth / transform.k;
  const viewportWorldHeight = effectiveContainerHeight / transform.k;
  const viewportWorldX = -transform.x / transform.k;
  const viewportWorldY = -transform.y / transform.k;

  // Convert to minimap coordinates
  const viewportMinimapX = viewportWorldX * scale + offsetX;
  const viewportMinimapY = viewportWorldY * scale + offsetY;
  const viewportMinimapWidth = viewportWorldWidth * scale;
  const viewportMinimapHeight = viewportWorldHeight * scale;

  // Handle click on minimap to navigate
  const handleMinimapClick = (e) => {
    if (!onNavigate) return;

    const rect = e.currentTarget.getBoundingClientRect();
    const clickX = e.clientX - rect.left;
    const clickY = e.clientY - rect.top;

    // Convert minimap click to world coordinates
    const worldX = (clickX - offsetX) / scale;
    const worldY = (clickY - offsetY) / scale;

    // Navigate to center on this point
    onNavigate(worldX, worldY);
  };

  // Get node color based on severity
  const getNodeColor = (nodeId) => {
    // Default blue for agents, could be enhanced to show severity
    return '#60A5FA';
  };

  return (
    <div style={{
      position: 'absolute',
      bottom: '20px',
      left: '270px',
      width: `${mapWidth}px`,
      height: `${mapHeight}px`,
      background: 'rgba(10, 15, 20, 0.92)',
      border: '1px solid rgba(100, 116, 139, 0.4)',
      borderRadius: '8px',
      overflow: 'hidden',
      zIndex: 10,
      cursor: 'crosshair',
      boxShadow: '0 4px 12px rgba(0,0,0,0.3)'
    }}
    onClick={handleMinimapClick}
    title="Click to navigate"
    >
      {/* Header label */}
      <div style={{
        position: 'absolute',
        top: '4px',
        left: '8px',
        fontSize: '9px',
        fontWeight: 600,
        color: '#64748B',
        textTransform: 'uppercase',
        letterSpacing: '0.5px',
        pointerEvents: 'none',
        zIndex: 2
      }}>
        Overview
      </div>

      <svg width="100%" height="100%" style={{ marginTop: '2px' }}>
        {/* Background gradient */}
        <defs>
          <radialGradient id="minimapGlow" cx="50%" cy="50%" r="50%">
            <stop offset="0%" stopColor="#DC2626" stopOpacity="0.12" />
            <stop offset="100%" stopColor="#DC2626" stopOpacity="0" />
          </radialGradient>
        </defs>
        <rect width="100%" height="100%" fill="url(#minimapGlow)" />

        {/* Nodes */}
        {nodePositions.map(([nodeId, pos]) => (
          <circle
            key={`mini-${nodeId}`}
            cx={pos.x * scale + offsetX}
            cy={pos.y * scale + offsetY}
            r={3}
            fill={getNodeColor(nodeId)}
            opacity={0.75}
          />
        ))}

        {/* Viewport rectangle - shows current view area */}
        <rect
          x={viewportMinimapX}
          y={viewportMinimapY}
          width={Math.max(viewportMinimapWidth, 20)}
          height={Math.max(viewportMinimapHeight, 15)}
          fill="rgba(244, 114, 182, 0.1)"
          stroke="#F472B6"
          strokeWidth={2}
          rx={2}
          opacity={0.9}
        />

        {/* Center crosshair in viewport */}
        <line
          x1={viewportMinimapX + viewportMinimapWidth / 2 - 6}
          y1={viewportMinimapY + viewportMinimapHeight / 2}
          x2={viewportMinimapX + viewportMinimapWidth / 2 + 6}
          y2={viewportMinimapY + viewportMinimapHeight / 2}
          stroke="#F472B6"
          strokeWidth={1.5}
          opacity={0.8}
        />
        <line
          x1={viewportMinimapX + viewportMinimapWidth / 2}
          y1={viewportMinimapY + viewportMinimapHeight / 2 - 6}
          x2={viewportMinimapX + viewportMinimapWidth / 2}
          y2={viewportMinimapY + viewportMinimapHeight / 2 + 6}
          stroke="#F472B6"
          strokeWidth={1.5}
          opacity={0.8}
        />
      </svg>
    </div>
  );
};

const BACKGROUND_COLOR = '#050505';
const EDGE_COLOR = 'rgba(96, 165, 250, 0.85)';
const EDGE_DASH = '2 4';
const ICON_COLOR = '#E2E8F0';

const SEGMENT_LABEL_COLOR = 'rgba(226, 232, 240, 0.88)';
const SEGMENT_LABEL_MUTED = 'rgba(148, 163, 184, 0.8)';
const SEGMENT_LABEL_OFFSET = 32;
const SEGMENT_PALETTE = [
  '#60A5FA',
  '#34D399',
  '#FBBF24',
  '#F97316',
  '#A78BFA',
  '#F87171',
];

const SYSTEM_BASE_WIDTH = 1100;
const SYSTEM_BASE_HEIGHT = 720;
const SYSTEM_SCALE_MIN = 1;
const SYSTEM_SCALE_MAX = 1.6;
const HUB_SEED_RADIUS_RATIO = 0.16;
const ARC_RADIUS_RATIO = 0.18;
const ARC_SPAN_DEGREES = 210;

const NODE_STYLES = {
  normal: {
    fill: '#10B981',
    stroke: '#34D399',
    glow: 'rgba(16, 185, 129, 0.55)',
    radius: 16,
    baseRadius: 16,
  },
  warning: {
    fill: '#F59E0B',
    stroke: '#FBBF24',
    glow: 'rgba(245, 158, 11, 0.55)',
    radius: 18,
    baseRadius: 18,
  },
  critical: {
    fill: '#DC2626',
    stroke: '#F87171',
    glow: 'rgba(239, 68, 68, 0.65)',
    radius: 20,
    baseRadius: 20,
  },
};

// Helper to calculate dynamic node radius based on risk score
const getNodeRadius = (node, baseRadius) => {
  const riskScore = Number(node.riskScore || 0);
  // Scale radius: 0-29 risk = base, 30-69 = base+3, 70-100 = base+6
  if (riskScore >= 70) return baseRadius + 6;
  if (riskScore >= 30) return baseRadius + 3;
  return baseRadius;
};









































const HUB_STYLE = {
  fill: '#FBBF24',        // Yellow for segment hubs
  stroke: '#FDE68A',
  glow: 'rgba(251, 191, 36, 0.75)',
  radius: 23,
};

// SIEM Hub Styles for new layouts
const SIEM_HUB_STYLES = {
  normal: {
    fill: '#10B981',      // Green - healthy
    stroke: '#34D399',
    glow: 'rgba(16, 185, 129, 0.6)',
  },
  warning: {
    fill: '#F59E0B',      // Amber - warning
    stroke: '#FBBF24',
    glow: 'rgba(245, 158, 11, 0.6)',
  },
  critical: {
    fill: '#DC2626',      // Red - critical
    stroke: '#F87171',
    glow: 'rgba(239, 68, 68, 0.7)',
  },
  radius: 20,  // Smaller hub for better proportions
};

const SEVERITY_RANK = {
  critical: 0,
  warning: 1,
  normal: 2,
};

const hashString = (value) => {
  let hash = 0;
  for (let i = 0; i < value.length; i += 1) {
    hash = value.charCodeAt(i) + ((hash << 5) - hash);
  }
  return Math.abs(hash);
};

const slugify = (value) =>
  String(value || '')
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/(^-|-$)/g, '');

const getSeverity = (node) => {
  if (!node) return 'normal';
  const riskScore = Number(node.riskScore || 0);
  const alertCount = Number(node.alertCount || 0);
  if (node.critical || riskScore >= 70 || alertCount >= 5) return 'critical';
  if (riskScore >= 40 || alertCount > 0) return 'warning';
  return 'normal';
};

const pickHubNode = (nodes) => {
  if (!nodes.length) return null;
  const siemNode = nodes.find((node) => String(node.role || '').toLowerCase() === 'siem');
  if (siemNode) return siemNode;

  const sorted = [...nodes].sort((a, b) => {
    const severityDelta = SEVERITY_RANK[getSeverity(a)] - SEVERITY_RANK[getSeverity(b)];
    if (severityDelta !== 0) return severityDelta;
    const alertDelta = (a.alertCount || 0) - (b.alertCount || 0);
    if (alertDelta !== 0) return alertDelta;
    return String(a.label || a.id || '').localeCompare(String(b.label || b.id || ''));
  });

  return sorted[0];
};

const sortNodesForArc = (nodes) =>
  [...nodes].sort((a, b) => {
    const severityDelta = SEVERITY_RANK[getSeverity(a)] - SEVERITY_RANK[getSeverity(b)];
    if (severityDelta !== 0) return severityDelta;
    const alertDelta = (b.alertCount || 0) - (a.alertCount || 0);
    if (alertDelta !== 0) return alertDelta;
    return String(a.label || a.id || '').localeCompare(String(b.label || b.id || ''));
  });

const buildLayout = (topology) => {
  const rawNodes = (topology?.nodes || []).filter(
    (node) => node && node.id && node.type !== 'cluster' && node.type !== 'segment-diamond'
  );

  if (rawNodes.length === 0) {
    return {
      segments: [],
      nodeSegmentLookup: new Map(),
      positions: new Map(),
      width: 0,
      height: 0,
      systemCenter: { x: 0, y: 0 },
      simNodes: [],
      simLinks: [],
    };
  }

  const segmentMap = new Map();
  const nodeSegmentLookup = new Map();

  rawNodes.forEach((node) => {
    const label = getNodeSegment(node) || 'Default Network';
    const segmentId = slugify(label) || 'default-network';

    if (!segmentMap.has(segmentId)) {
      segmentMap.set(segmentId, {
        id: segmentId,
        label,
        nodes: [],
        nodesCount: 0,
        alertCount: 0,
        criticalCount: 0,
        highCount: 0,
        riskScore: 0,
      });
    }

    const segment = segmentMap.get(segmentId);
    segment.nodes.push(node);
    segment.nodesCount += 1;
    segment.alertCount += node.alertCount || 0;
    segment.riskScore += Number(node.riskScore || 0);

    const severity = getSeverity(node);
    if (severity === 'critical') {
      segment.criticalCount += 1;
    } else if ((node.alertCount || 0) > 0) {
      segment.highCount += 1;
    }

    nodeSegmentLookup.set(node.id, segmentId);
  });

  let segments = Array.from(segmentMap.values()).map((segment) => {
    const orderedNodes = sortNodesForArc(segment.nodes);
    const colorKey = String(segment.id || segment.label);

    // Create a synthetic segment hub node (yellow) that represents the network segment
    const segmentHub = {
      id: `segment-hub-${segment.id}`,
      label: segment.label,  // Shows subnet like "172.16.50.0/24"
      type: 'segment-hub',   // Special type for segment hubs
      isSegmentHub: true,
      role: 'network',       // Network icon
      nodesCount: segment.nodesCount,
      alertCount: segment.alertCount,
      criticalCount: segment.criticalCount,
      highCount: segment.highCount,
    };

    return {
      ...segment,
      hub: segmentHub,
      nodes: orderedNodes,   // All nodes are now spokes connected to the segment hub
      color: SEGMENT_PALETTE[hashString(colorKey) % SEGMENT_PALETTE.length],
      riskScore: segment.nodesCount > 0 ? Math.round(segment.riskScore / segment.nodesCount) : 0,
    };
  });

  segments.sort((a, b) => b.nodesCount - a.nodesCount || a.label.localeCompare(b.label));

  const nodeCount = rawNodes.length;
  const scale = Math.min(
    SYSTEM_SCALE_MAX,
    Math.max(SYSTEM_SCALE_MIN, Math.sqrt(nodeCount / 26))
  );
  const width = SYSTEM_BASE_WIDTH * scale;
  const height = SYSTEM_BASE_HEIGHT * scale;
  const systemCenter = { x: width / 2, y: height / 2 + 10 };

  const hubSeedRadius = Math.min(width, height) * HUB_SEED_RADIUS_RATIO;
  const arcRadius = Math.min(width, height) * ARC_RADIUS_RATIO;

  const positions = new Map();

  segments = segments.map((segment) => {
    const angleDeg = hashString(segment.id) % 360;
    const angleRad = (angleDeg * Math.PI) / 180;
    const radialSeed = hubSeedRadius * (0.65 + ((hashString(`${segment.id}-r`) % 35) / 100));
    const center = {
      x: systemCenter.x + radialSeed * Math.cos(angleRad),
      y: systemCenter.y + radialSeed * Math.sin(angleRad),
    };

    if (segment.hub?.id) {
      positions.set(segment.hub.id, { x: center.x, y: center.y });
    }

    const arcStart = angleDeg - ARC_SPAN_DEGREES / 2;
    const arcEnd = angleDeg + ARC_SPAN_DEGREES / 2;
    const arcNodes = segment.nodes;
    const step = arcNodes.length > 1 ? (arcEnd - arcStart) / (arcNodes.length - 1) : 0;

    arcNodes.forEach((node, idx) => {
      const nodeAngle = arcStart + step * idx;
      const nodeRad = (nodeAngle * Math.PI) / 180;
      const jitter = (hashString(`${node.id}-j`) % 10) - 5;
      const radius = arcRadius + jitter;
      positions.set(node.id, {
        x: center.x + radius * Math.cos(nodeRad),
        y: center.y + radius * Math.sin(nodeRad),
      });
    });

    return {
      ...segment,
      center,
      angleRad,
      arcRadius,
    };
  });

  const simNodes = [];
  const simLinks = [];
  const simNodeIds = new Set();

  segments.forEach((segment) => {
    const hub = segment.hub;
    if (hub?.id && !simNodeIds.has(hub.id)) {
      const hubPosition = positions.get(hub.id);
      simNodes.push({
        id: hub.id,
        segmentId: segment.id,
        isHub: true,
        severity: getSeverity(hub),
        x: hubPosition?.x ?? segment.center.x,
        y: hubPosition?.y ?? segment.center.y,
        initX: hubPosition?.x ?? segment.center.x,
        initY: hubPosition?.y ?? segment.center.y,
      });
      simNodeIds.add(hub.id);
    }

    segment.nodes.forEach((node) => {
      if (!node?.id || simNodeIds.has(node.id)) return;
      const nodePosition = positions.get(node.id);
      const initX = nodePosition?.x ?? segment.center.x;
      const initY = nodePosition?.y ?? segment.center.y;
      simNodes.push({
        id: node.id,
        segmentId: segment.id,
        isHub: false,
        severity: getSeverity(node),
        x: initX,
        y: initY,
        initX,
        initY,
      });
      simNodeIds.add(node.id);
    });

    if (hub?.id) {
      segment.nodes.forEach((node) => {
        if (!node?.id) return;
        simLinks.push({ source: hub.id, target: node.id, kind: 'segment' });
      });
    }
  });

  const hubIds = segments.map((segment) => segment.hub?.id).filter(Boolean);
  hubIds.forEach((hubId, idx) => {
    const nextId = hubIds[(idx + 1) % hubIds.length];
    if (nextId && nextId !== hubId) {
      simLinks.push({ source: hubId, target: nextId, kind: 'hub' });
    }
  });

  return {
    segments,
    nodeSegmentLookup,
    positions,
    width,
    height,
    systemCenter,
    simNodes,
    simLinks,
  };
};

const MonitorIcon = ({ x, y, size }) => {
  const screenWidth = size * 0.9;
  const screenHeight = size * 0.52;
  const screenX = x - screenWidth / 2;
  const screenY = y - screenHeight / 2 - size * 0.08;
  const dotSize = size * 0.12;
  const dotGap = size * 0.14;
  const dotY = screenY + screenHeight * 0.35 - dotSize / 2;

  return (
    <g>
      <rect
        x={screenX}
        y={screenY}
        width={screenWidth}
        height={screenHeight}
        rx={3}
        fill="none"
        stroke={ICON_COLOR}
        strokeWidth={1.4}
      />
      {[-1, 0, 1].map((offset) => (
        <rect
          key={offset}
          x={x + offset * dotGap - dotSize / 2}
          y={dotY}
          width={dotSize}
          height={dotSize}
          rx={1}
          fill={ICON_COLOR}
        />
      ))}
      <line
        x1={x}
        y1={screenY + screenHeight + size * 0.12}
        x2={x}
        y2={screenY + screenHeight + size * 0.28}
        stroke={ICON_COLOR}
        strokeWidth={1.4}
        strokeLinecap="round"
      />
      <line
        x1={x - size * 0.18}
        y1={screenY + screenHeight + size * 0.28}
        x2={x + size * 0.18}
        y2={screenY + screenHeight + size * 0.28}
        stroke={ICON_COLOR}
        strokeWidth={1.4}
        strokeLinecap="round"
      />
    </g>
  );
};

const NetworkTopology2D = forwardRef(({
  topology,
  onSelectNode,
  selectedNodeId,
  onNodeContextMenu,
  viewMode = 'split',
  onViewModeChange,
  showUnregistered = true,
  onShowUnregisteredChange,
  onRefresh,
  onSaveLayout,
  hasUnsavedChanges = false,
  saving = false,
}, ref) => {
  const svgRef = useRef(null);
  const containerRef = useRef(null);
  const zoomRef = useRef(null);
  const [hoveredNodeId, setHoveredNodeId] = useState(null);
  const [hoveredSegmentId, setHoveredSegmentId] = useState(null);
  const animationFrameRef = useRef(null);

  // Focus state: 'agents' (Protected Zone) or 'external' (Threat Zone)
  // Default to null - will be set after fit-to-view
  const [focusedCluster, setFocusedCluster] = useState(null);

  // Transform state for pan/zoom
  const [transform, setTransform] = useState({ x: 0, y: 0, k: 1 });

  // Track if user is actively panning (for center indicator)
  const [isPanning, setIsPanning] = useState(false);
  const panTimeoutRef = useRef(null);

  // Container dimensions for responsive calculations
  const [containerDimensions, setContainerDimensions] = useState({ width: 1200, height: 800 });

  // Track if initial fit-to-view has been done
  const initialFitDone = useRef(false);

  // Track container resize for responsive behavior
  useEffect(() => {
    if (!containerRef.current) return;

    const resizeObserver = new ResizeObserver((entries) => {
      for (const entry of entries) {
        const { width, height } = entry.contentRect;
        setContainerDimensions({ width, height });
      }
    });

    resizeObserver.observe(containerRef.current);

    return () => resizeObserver.disconnect();
  }, []);

  // Use new layout system when viewMode is 'split' or 'concentric'
  const useNewLayout = viewMode === 'split' || viewMode === 'concentric';

  // Legacy layout for backwards compatibility (segment-based)
  const legacyLayoutResult = useMemo(() => {
    if (useNewLayout) return null;
    return buildLayout(topology);
  }, [topology, useNewLayout]);

  // New layout system (split/concentric)
  const newLayoutResult = useMemo(() => {
    if (!useNewLayout) return null;

    const nodes = extractNodesForLayout(topology);
    if (nodes.length === 0) return null;

    // Calculate dimensions
    const nodeCount = nodes.length;
    const scale = Math.min(
      SYSTEM_SCALE_MAX,
      Math.max(SYSTEM_SCALE_MIN, Math.sqrt(nodeCount / 26))
    );
    const width = SYSTEM_BASE_WIDTH * scale;
    const height = SYSTEM_BASE_HEIGHT * scale;

    const layoutResult = buildNewLayout(viewMode, nodes, { width, height });
    const threatLevel = calculateThreatLevel(nodes);

    return {
      ...layoutResult,
      width,
      height,
      nodes,
      threatLevel,
      systemCenter: { x: width / 2, y: height / 2 }
    };
  }, [topology, viewMode, useNewLayout]);

  // Combined layout data
  const {
    segments,
    nodeSegmentLookup,
    positions: initialPositions,
    width,
    height,
    systemCenter,
    simNodes,
    simLinks,
  } = useMemo(() => {
    if (useNewLayout && newLayoutResult) {
      // Build segments for sidebar from nodes
      const segmentMap = new Map();
      const nodeLookup = new Map();

      newLayoutResult.nodes.forEach((node) => {
        const label = getNodeSegment(node) || 'Default Network';
        const segmentId = label.toLowerCase().replace(/[^a-z0-9]+/g, '-');

        if (!segmentMap.has(segmentId)) {
          segmentMap.set(segmentId, {
            id: segmentId,
            label,
            nodes: [],
            nodesCount: 0,
            alertCount: 0,
            criticalCount: 0,
            highCount: 0,
            riskScore: 0,
          });
        }

        const segment = segmentMap.get(segmentId);
        segment.nodes.push(node);
        segment.nodesCount += 1;
        segment.alertCount += node.alertCount || 0;
        segment.riskScore += Number(node.riskScore || 0);

        const severity = getSeverity(node);
        if (severity === 'critical') segment.criticalCount += 1;
        else if ((node.alertCount || 0) > 0) segment.highCount += 1;

        nodeLookup.set(node.id, segmentId);
      });

      const segments = Array.from(segmentMap.values()).map(seg => ({
        ...seg,
        riskScore: seg.nodesCount > 0 ? Math.round(seg.riskScore / seg.nodesCount) : 0,
      }));
      segments.sort((a, b) => b.nodesCount - a.nodesCount);

      return {
        segments,
        nodeSegmentLookup: nodeLookup,
        positions: newLayoutResult.positions,
        width: newLayoutResult.width,
        height: newLayoutResult.height,
        systemCenter: newLayoutResult.systemCenter,
        simNodes: [],
        simLinks: [],
      };
    }

    // Legacy layout
    return legacyLayoutResult || {
      segments: [],
      nodeSegmentLookup: new Map(),
      positions: new Map(),
      width: 0,
      height: 0,
      systemCenter: { x: 0, y: 0 },
      simNodes: [],
      simLinks: [],
    };
  }, [useNewLayout, newLayoutResult, legacyLayoutResult]);

  const [positions, setPositions] = useState(() => initialPositions);

  const selectedSegmentId = useMemo(() => {
    if (!selectedNodeId) return null;
    const segmentMatch = segments.find((segment) => segment.id === selectedNodeId);
    if (segmentMatch) return segmentMatch.id;
    return nodeSegmentLookup.get(selectedNodeId) || null;
  }, [selectedNodeId, segments, nodeSegmentLookup]);

  const derivedHoveredSegmentId = hoveredNodeId ? nodeSegmentLookup.get(hoveredNodeId) : null;
  const activeSegmentId = hoveredSegmentId || derivedHoveredSegmentId;

  useEffect(() => {
    // For new layouts (split/concentric), use static positions - no D3 simulation
    if (useNewLayout) {
      setPositions(initialPositions);
      return undefined;
    }

    // Legacy layout with D3 simulation
    if (!simNodes.length) {
      setPositions(initialPositions);
      return undefined;
    }

    setPositions(initialPositions);

    const nodes = simNodes.map((node) => ({ ...node }));
    const links = simLinks.map((link) => ({ ...link }));

    const simulation = d3.forceSimulation(nodes)
      .alpha(0.9)
      .alphaDecay(0.04)
      .velocityDecay(0.25)
      .force('center', d3.forceCenter(systemCenter.x, systemCenter.y))
      .force('link', d3.forceLink(links)
        .id((d) => d.id)
        .distance((link) => (link.kind === 'hub' ? 150 : 62))
        .strength((link) => (link.kind === 'hub' ? 0.08 : 0.65)))
      .force('charge', d3.forceManyBody().strength((node) => (node.isHub ? -180 : -70)))
      .force('collide', d3.forceCollide((node) => {
        if (node.isHub) return HUB_STYLE.radius + 18;
        const style = NODE_STYLES[node.severity] || NODE_STYLES.normal;
        return style.radius + 10;
      }).iterations(2))
      .force('anchorX', d3.forceX((node) => node.initX).strength((node) => (node.isHub ? 0.06 : 0.03)))
      .force('anchorY', d3.forceY((node) => node.initY).strength((node) => (node.isHub ? 0.06 : 0.03)));

    const updatePositions = () => {
      animationFrameRef.current = null;
      const nextPositions = new Map();
      nodes.forEach((node) => {
        nextPositions.set(node.id, { x: node.x, y: node.y });
      });
      setPositions(nextPositions);
    };

    const onTick = () => {
      if (animationFrameRef.current) return;
      animationFrameRef.current = requestAnimationFrame(updatePositions);
    };

    simulation.on('tick', onTick);
    updatePositions();

    return () => {
      simulation.stop();
      simulation.on('tick', null);
      if (animationFrameRef.current) {
        cancelAnimationFrame(animationFrameRef.current);
        animationFrameRef.current = null;
      }
    };
  }, [useNewLayout, simNodes, simLinks, initialPositions, systemCenter]);

  // Calculate focus transform for a specific cluster (vertical layout: top/bottom)
  const calculateFocusTransform = (cluster, containerWidth, containerHeight) => {
    if (!useNewLayout || viewMode !== 'split' || !newLayoutResult?.hubs) {
      return { x: 0, y: 0, k: 1 };
    }

    const hubData = cluster === 'agents' ? newLayoutResult.hubs.agents : newLayoutResult.hubs.external;
    if (!hubData) return { x: 0, y: 0, k: 1 };

    // Scale for focus - slightly zoomed for better visibility
    const focusScale = 1.2;
    const targetX = hubData.position.x;
    const targetY = hubData.position.y;

    // Calculate translation to position the focused hub
    // Account for sidebar width (250px) - shift center to the right
    const sidebarOffset = 125;
    const centerX = (containerWidth + sidebarOffset) / 2;
    // Position toward top instead of center (35% from top)
    const centerY = containerHeight * 0.35;

    const translateX = centerX - targetX * focusScale;
    const translateY = centerY - targetY * focusScale;

    return { x: translateX, y: translateY, k: focusScale };
  };

  // Calculate fit-to-view transform to show all nodes
  const calculateFitToViewTransform = (containerWidth, containerHeight, nodePositions) => {
    if (!nodePositions || nodePositions.size === 0) {
      return { x: 0, y: 0, k: 1 };
    }

    const posArray = Array.from(nodePositions.values());
    const xs = posArray.map(p => p.x);
    const ys = posArray.map(p => p.y);

    const minX = Math.min(...xs);
    const maxX = Math.max(...xs);
    const minY = Math.min(...ys);
    const maxY = Math.max(...ys);

    const contentWidth = maxX - minX;
    const contentHeight = maxY - minY;

    // Add padding (15% on each side)
    const paddingX = contentWidth * 0.15;
    const paddingY = contentHeight * 0.15;

    const totalWidth = contentWidth + paddingX * 2;
    const totalHeight = contentHeight + paddingY * 2;

    // Account for sidebar (250px) and some margin
    const availableWidth = containerWidth - 280;
    const availableHeight = containerHeight - 40;

    // Calculate scale to fit all content
    const scaleX = availableWidth / totalWidth;
    const scaleY = availableHeight / totalHeight;
    const fitScale = Math.min(scaleX, scaleY, 1.5); // Cap at 1.5x

    // Calculate center of content
    const centerX = (minX + maxX) / 2;
    const centerY = (minY + maxY) / 2;

    // Calculate translation to center content (accounting for sidebar offset)
    const sidebarOffset = 140; // Half of sidebar width
    const translateX = (containerWidth + sidebarOffset) / 2 - centerX * fitScale;
    const translateY = containerHeight / 2 - centerY * fitScale;

    return { x: translateX, y: translateY, k: fitScale };
  };

  // D3 Zoom behavior setup
  useEffect(() => {
    if (!svgRef.current || !containerRef.current) return;

    const svg = d3.select(svgRef.current);
    const container = containerRef.current;
    const containerWidth = container.clientWidth || 1200;
    const containerHeight = container.clientHeight || 800;

    // Update container dimensions state
    setContainerDimensions({ width: containerWidth, height: containerHeight });

    // Create zoom behavior
    const zoomBehavior = d3.zoom()
      .scaleExtent([0.3, 3])
      .on('start', () => {
        setIsPanning(true);
        // Clear any existing timeout
        if (panTimeoutRef.current) {
          clearTimeout(panTimeoutRef.current);
        }
      })
      .on('zoom', (event) => {
        setTransform({
          x: event.transform.x,
          y: event.transform.y,
          k: event.transform.k
        });
      })
      .on('end', () => {
        // Hide panning indicator after a short delay
        panTimeoutRef.current = setTimeout(() => {
          setIsPanning(false);
        }, 1000);
      });

    // Store zoom behavior reference
    zoomRef.current = zoomBehavior;

    // Apply zoom behavior to SVG
    svg.call(zoomBehavior);

    // Set initial fit-to-view (show all zones) on first load
    if (!initialFitDone.current && positions && positions.size > 0) {
      const fitTransform = calculateFitToViewTransform(containerWidth, containerHeight, positions);
      svg.call(
        zoomBehavior.transform,
        d3.zoomIdentity.translate(fitTransform.x, fitTransform.y).scale(fitTransform.k)
      );
      initialFitDone.current = true;
    }

    // Cleanup
    return () => {
      svg.on('.zoom', null);
      if (panTimeoutRef.current) {
        clearTimeout(panTimeoutRef.current);
      }
    };
  }, [useNewLayout, viewMode, positions, width, height]);

  // Handle focus cluster change with smooth transition
  const handleFocusCluster = (cluster) => {
    if (!svgRef.current || !containerRef.current || !zoomRef.current) return;
    if (cluster === focusedCluster) return;

    const svg = d3.select(svgRef.current);
    const container = containerRef.current;
    const containerWidth = container.clientWidth || 1200;
    const containerHeight = container.clientHeight || 800;

    setFocusedCluster(cluster);

    // Calculate new transform for the focused cluster
    const newTransform = calculateFocusTransform(cluster, containerWidth, containerHeight);

    // Smooth transition to the new focus
    svg.transition()
      .duration(750)
      .ease(d3.easeCubicInOut)
      .call(
        zoomRef.current.transform,
        d3.zoomIdentity.translate(newTransform.x, newTransform.y).scale(newTransform.k)
      );
  };

  // Navigate to a specific world coordinate (used by minimap)
  const navigateToWorldPoint = (worldX, worldY) => {
    if (!svgRef.current || !zoomRef.current || !containerRef.current) return;

    const svg = d3.select(svgRef.current);
    const container = containerRef.current;
    const containerWidth = container.clientWidth || 1200;
    const containerHeight = container.clientHeight || 800;

    // Account for sidebar offset
    const sidebarOffset = 140;
    const centerX = (containerWidth + sidebarOffset) / 2;
    const centerY = containerHeight / 2;

    // Calculate translation to center on this point at current zoom
    const currentScale = transform.k;
    const translateX = centerX - worldX * currentScale;
    const translateY = centerY - worldY * currentScale;

    // Animate to new position
    svg.transition()
      .duration(400)
      .ease(d3.easeCubicOut)
      .call(
        zoomRef.current.transform,
        d3.zoomIdentity.translate(translateX, translateY).scale(currentScale)
      );
  };

  // Focus on a specific node with smooth centering animation
  const focusOnNodeWithCenter = (nodeId, zoomLevel = null) => {
    if (!svgRef.current || !zoomRef.current || !containerRef.current) return;

    const nodePosition = positions.get(nodeId);
    if (!nodePosition) return;

    const svg = d3.select(svgRef.current);
    const container = containerRef.current;
    const containerWidth = container.clientWidth || 1200;
    const containerHeight = container.clientHeight || 800;

    // Account for sidebar offset
    const sidebarOffset = 140;
    const centerX = (containerWidth + sidebarOffset) / 2;
    const centerY = containerHeight / 2;

    // Use specified zoom or current zoom (with minimum of 1.0 for good visibility)
    const targetScale = zoomLevel || Math.max(transform.k, 1.0);

    // Calculate translation to center on this node
    const translateX = centerX - nodePosition.x * targetScale;
    const translateY = centerY - nodePosition.y * targetScale;

    // Highlight the node
    setHoveredNodeId(nodeId);

    // Animate to center on node
    svg.transition()
      .duration(600)
      .ease(d3.easeCubicInOut)
      .call(
        zoomRef.current.transform,
        d3.zoomIdentity.translate(translateX, translateY).scale(targetScale)
      );
  };

  useImperativeHandle(ref, () => ({
    zoomIn: () => {
      if (!svgRef.current || !zoomRef.current) return;
      const svg = d3.select(svgRef.current);
      svg.transition().duration(300).call(zoomRef.current.scaleBy, 1.3);
    },
    zoomOut: () => {
      if (!svgRef.current || !zoomRef.current) return;
      const svg = d3.select(svgRef.current);
      svg.transition().duration(300).call(zoomRef.current.scaleBy, 0.7);
    },
    fitToView: () => {
      if (!svgRef.current || !zoomRef.current || !containerRef.current) return;
      const svg = d3.select(svgRef.current);
      const container = containerRef.current;
      const containerWidth = container.clientWidth || 1200;
      const containerHeight = container.clientHeight || 800;

      // Calculate proper fit-to-view transform
      const fitTransform = calculateFitToViewTransform(containerWidth, containerHeight, positions);

      svg.transition()
        .duration(500)
        .ease(d3.easeCubicOut)
        .call(
          zoomRef.current.transform,
          d3.zoomIdentity.translate(fitTransform.x, fitTransform.y).scale(fitTransform.k)
        );
    },
    focusOnProtectedZone: () => handleFocusCluster('agents'),
    focusOnThreatZone: () => handleFocusCluster('external'),
    focusOnNode: (nodeId) => focusOnNodeWithCenter(nodeId),
    navigateToPoint: navigateToWorldPoint,
    exportToPNG: () => {
      if (!svgRef.current) return;
      const svgElement = svgRef.current;
      const serializer = new XMLSerializer();
      const svgMarkup = serializer.serializeToString(svgElement);
      const blob = new Blob([svgMarkup], { type: 'image/svg+xml;charset=utf-8' });
      const url = URL.createObjectURL(blob);
      const image = new Image();

      image.onload = () => {
        const canvas = document.createElement('canvas');
        canvas.width = svgElement.viewBox.baseVal.width || svgElement.clientWidth;
        canvas.height = svgElement.viewBox.baseVal.height || svgElement.clientHeight;
        const ctx = canvas.getContext('2d');
        ctx.fillStyle = BACKGROUND_COLOR;
        ctx.fillRect(0, 0, canvas.width, canvas.height);
        ctx.drawImage(image, 0, 0, canvas.width, canvas.height);
        const png = canvas.toDataURL('image/png');

        const link = document.createElement('a');
        link.download = `threat-topology-${new Date().toISOString().split('T')[0]}.png`;
        link.href = png;
        link.click();

        URL.revokeObjectURL(url);
      };

      image.src = url;
    },
  }));

  if ((!segments.length && !useNewLayout) || !width || !height) {
    return <div style={{ width: '100%', height: '100%', background: BACKGROUND_COLOR }} />;
  }

  // Render SIEM Hub for new layouts
  const renderSiemHub = (hubData, threatLevel = 'normal', onClickHandler = null) => {
    if (!hubData) return null;

    const position = positions.get(hubData.id);
    if (!position) return null;

    const style = SIEM_HUB_STYLES[threatLevel] || SIEM_HUB_STYLES.normal;
    const radius = SIEM_HUB_STYLES.radius;
    const isHovered = hoveredNodeId === hubData.id;
    const isFocused = (hubData.cluster === focusedCluster) ||
                      (hubData.id === 'siem-hub-agents' && focusedCluster === 'agents') ||
                      (hubData.id === 'siem-hub-external' && focusedCluster === 'external');
    const displayRadius = radius * (isHovered ? 1.15 : isFocused ? 1.05 : 0.9);

    return (
      <g
        key={hubData.id}
        onMouseEnter={() => setHoveredNodeId(hubData.id)}
        onMouseLeave={() => setHoveredNodeId(null)}
        onClick={onClickHandler}
        style={{ cursor: 'pointer' }}
      >
        {/* Outer glow ring */}
        <circle
          cx={position.x}
          cy={position.y}
          r={displayRadius + 8}
          fill="none"
          stroke={style.stroke}
          strokeWidth={2}
          opacity={0.3}
          strokeDasharray="4 4"
        />
        {/* Main hub circle */}
        <circle
          cx={position.x}
          cy={position.y}
          r={displayRadius}
          fill={style.fill}
          stroke={style.stroke}
          strokeWidth={3}
          style={{ filter: `drop-shadow(0 0 16px ${style.glow})` }}
        />
        {/* SIEM icon (shield-like) */}
        <text
          x={position.x}
          y={position.y + 5}
          fontSize={16}
          fontWeight={700}
          fill="#FFFFFF"
          textAnchor="middle"
          style={{ textShadow: '0 1px 2px rgba(0,0,0,0.5)' }}
        >
          ◈
        </text>
        {/* Label below hub */}
        <text
          x={position.x}
          y={position.y + displayRadius + 20}
          fontSize={12}
          fontWeight={600}
          fill={style.stroke}
          textAnchor="middle"
          style={{ textShadow: '0 1px 3px rgba(0,0,0,0.8)' }}
        >
          {hubData.label}
        </text>
        {/* Node count */}
        <text
          x={position.x}
          y={position.y + displayRadius + 34}
          fontSize={10}
          fill="#94A3B8"
          textAnchor="middle"
        >
          {hubData.nodeCount || hubData.agentCount || 0} nodes
        </text>
        {/* Click hint for unfocused hub */}
        {!isFocused && onClickHandler && (
          <text
            x={position.x}
            y={position.y + displayRadius + 48}
            fontSize={9}
            fill="#64748B"
            textAnchor="middle"
            opacity={isHovered ? 1 : 0.6}
          >
            Click to focus
          </text>
        )}
      </g>
    );
  };

  // Render spokes (dashed lines from hub to nodes)
  const renderSpokes = (spokes) => {
    if (!spokes || !spokes.length) return null;

    return spokes.map((spoke, idx) => {
      const sourcePos = positions.get(spoke.sourceId);
      const targetPos = positions.get(spoke.targetId);

      if (!sourcePos || !targetPos) return null;

      const isAgentCluster = spoke.cluster === 'agents' || spoke.ring === 'inner';
      const spokeColor = isAgentCluster
        ? 'rgba(16, 185, 129, 0.5)'  // Green for agents
        : 'rgba(239, 68, 68, 0.4)';  // Red for external

      return (
        <line
          key={`spoke-${idx}`}
          x1={sourcePos.x}
          y1={sourcePos.y}
          x2={targetPos.x}
          y2={targetPos.y}
          stroke={spokeColor}
          strokeWidth={1.2}
          strokeDasharray="4 6"
          strokeLinecap="round"
          opacity={0.7}
        />
      );
    });
  };

  // Render ring labels for concentric view
  const renderRingLabels = () => {
    if (viewMode !== 'concentric' || !newLayoutResult?.rings) return null;

    const { inner, outer } = newLayoutResult.rings;

    return (
      <>
        {/* Inner ring label - above inner ring with extra offset */}
        <text
          x={systemCenter.x}
          y={systemCenter.y - inner.radius - 27}
          fontSize={11}
          fontWeight={600}
          fill="#10B981"
          textAnchor="middle"
          style={{ textShadow: '0 0 8px rgba(0,0,0,0.9), 0 0 4px rgba(0,0,0,1)' }}
        >
          AGENTS ({inner.nodes.length})
        </text>
        {/* Outer ring label - above outer ring with extra offset */}
        <text
          x={systemCenter.x}
          y={systemCenter.y - outer.radius - 38}
          fontSize={11}
          fontWeight={600}
          fill="#F87171"
          textAnchor="middle"
          style={{ textShadow: '0 0 8px rgba(0,0,0,0.9), 0 0 4px rgba(0,0,0,1)' }}
        >
          EXTERNAL ({outer.nodes.length})
        </text>
      </>
    );
  };

  const renderNode = (node, isHub = false) => {
    const severity = getSeverity(node);
    const baseStyle = isHub ? HUB_STYLE : NODE_STYLES[severity];
    const isSelected = selectedNodeId === node.id;
    const isHovered = hoveredNodeId === node.id;
    const nodeSegmentId = nodeSegmentLookup.get(node.id);
    const isSegmentSelected = selectedSegmentId && nodeSegmentId === selectedSegmentId;
    const isSegmentActive = activeSegmentId && nodeSegmentId === activeSegmentId;

    // Dynamic radius based on risk score for non-hub nodes
    const dynamicRadius = isHub
      ? baseStyle.radius
      : getNodeRadius(node, baseStyle.baseRadius || baseStyle.radius);
    const radius = dynamicRadius * (isHovered ? 1.08 : isSegmentSelected || isSegmentActive ? 1.05 : 1);

    const strokeWidth = isHub ? 3 : isSelected || isSegmentSelected || isSegmentActive ? 3 : 2;
    const fill = isSelected && !isHub ? baseStyle.stroke : baseStyle.fill;
    const position = positions.get(node.id) || initialPositions.get(node.id);
    const isCritical = severity === 'critical';

    if (!position) return null;

    // For segment hub nodes (yellow), always use the network icon and show subnet label
    if (node.isSegmentHub || node.type === 'segment-hub') {
      const NetworkIcon = getIconForRole('network');
      return (
        <g
          key={node.id}
          onMouseEnter={() => setHoveredNodeId(node.id)}
          onMouseLeave={() => setHoveredNodeId(null)}
          onClick={() => onSelectNode && onSelectNode({
            id: node.id,
            label: node.label,
            type: 'segment',
            nodesCount: node.nodesCount,
            criticalCount: node.criticalCount,
            highCount: node.highCount,
            alertCount: node.alertCount,
            riskScore: 0,
          })}
          style={{ cursor: 'pointer' }}
        >
          {/* Segment hub circle (yellow) */}
          <circle
            cx={position.x}
            cy={position.y}
            r={radius}
            fill={HUB_STYLE.fill}
            stroke={HUB_STYLE.stroke}
            strokeWidth={3}
            style={{ filter: `drop-shadow(0 0 12px ${HUB_STYLE.glow})` }}
          />
          {/* Network icon */}
          <NetworkIcon x={position.x} y={position.y} size={radius * 0.65} color="#1E293B" />
          {/* Subnet label below hub - shows on hover */}
          {isHovered && (
            <text
              x={position.x}
              y={position.y + radius + 16}
              fontSize={11}
              fontWeight={600}
              fill="#FBBF24"
              textAnchor="middle"
              style={{
                textShadow: '0 1px 3px rgba(0,0,0,0.8)',
                pointerEvents: 'none'
              }}
            >
              {node.label}
            </text>
          )}
        </g>
      );
    }

    // Check if this is a threat actor - use threat-specific icons
    const isThreatActor = node.isThreatActor || node.isHighRiskHost || (!node.isRegistered && (node.criticalCount > 0 || node.highCount > 0));

    let MainIcon;

    if (isThreatActor) {
      // Threat Zone nodes - use threat icons
      const isExternal = node.isThreatActor && !node.isInternal;
      MainIcon = isExternal ? ExternalThreatIcon : InternalThreatIcon; // Skull for external attackers, broken shield for compromised internal
    } else {
      // Protected Zone nodes (agents) - prefer OS icon for generic roles
      const role = node.role || 'endpoint';
      const roleLower = String(role).toLowerCase();
      const isGenericRole = roleLower.includes('endpoint') ||
                            roleLower.includes('desktop') ||
                            roleLower.includes('workstation') ||
                            roleLower.includes('pc') ||
                            roleLower === 'unknown' ||
                            !role;

      const RoleIcon = getIconForRole(role);
      const OSIcon = getIconForOS(node.os);

      // Prefer OS icon for generic roles if available, otherwise use role icon
      MainIcon = (isGenericRole && OSIcon) ? OSIcon : RoleIcon;
    }

    // Get agent status for border color
    const agentStatus = (() => {
      if (!node.isRegistered) return 'external';
      const status = String(node.status || '').toLowerCase();
      if (status === 'active' || status === 'connected' || status === 'online') return 'active';
      if (status === 'disconnected' || status === 'offline') return 'disconnected';
      if (status === 'never_connected' || status === 'pending') return 'never_connected';
      return node.isActive ? 'active' : 'inactive';
    })();

    const statusBorderColor = {
      active: '#10B981',      // Green
      disconnected: '#F59E0B', // Amber
      never_connected: '#6B7280', // Gray
      external: '#64748B',    // Slate
      inactive: '#6B7280',    // Gray
    }[agentStatus] || '#6B7280';

    return (
      <g
        key={node.id}
        onMouseEnter={() => setHoveredNodeId(node.id)}
        onMouseLeave={() => setHoveredNodeId(null)}
        onClick={() => {
          // Select the node
          onSelectNode && onSelectNode(node);
          // Center on the clicked node with smooth animation
          focusOnNodeWithCenter(node.id);
        }}
        onContextMenu={(e) => onNodeContextMenu && onNodeContextMenu(node, e)}
        style={{ cursor: 'pointer' }}
      >
{/* Critical indicator glow (static, no animation) */}
        {/* Status ring - shows agent connection status */}
        <circle
          cx={position.x}
          cy={position.y}
          r={radius + 3}
          fill="none"
          stroke={statusBorderColor}
          strokeWidth={2}
          opacity={agentStatus === 'disconnected' ? 1 : 0.7}
          strokeDasharray={agentStatus === 'disconnected' ? '4,2' : 'none'}
        />
        {/* Main node circle */}
        <circle
          cx={position.x}
          cy={position.y}
          r={radius}
          fill={fill}
          stroke={baseStyle.stroke}
          strokeWidth={strokeWidth}
          style={{ filter: `drop-shadow(0 0 ${isCritical ? 14 : 10}px ${baseStyle.glow})` }}
        />
        <MainIcon x={position.x} y={position.y} size={radius * 0.7} color="#FFFFFF" />

        {/* Tooltip is rendered separately in a top layer for proper z-index */}
      </g>
    );
  };

  // Render HTML tooltip for hovered node - positioned absolutely with high z-index
  const renderHoveredNodeTooltipHTML = () => {
    if (!hoveredNodeId) return null;

    // Find the hovered node
    const allNodes = useNewLayout && newLayoutResult?.nodes ? newLayoutResult.nodes : [];
    const node = allNodes.find(n => n.id === hoveredNodeId);
    if (!node) return null;

    const position = newLayoutResult?.positions?.get(node.id);
    if (!position) return null;

    const severity = getSeverity(node);
    const baseStyle = NODE_STYLES[severity];
    const radius = getNodeRadius(node, baseStyle.baseRadius || baseStyle.radius) * 1.08;

    // Determine if this is a Protected Zone or Threat Zone node
    const isProtectedZone = node.isRegistered === true;
    const criticalCount = node.criticalCount || 0;
    const highCount = node.highCount || 0;
    const mediumCount = node.mediumCount || 0;
    const lowCount = node.lowCount || 0;
    const alertCount = node.alertCount || 0;
    const isThreatZone = node.isThreatActor || node.isHighRiskHost || (!node.isRegistered && (criticalCount > 0 || highCount > 0));

    // Get agent status for protected zone nodes
    const agentStatus = node.isRegistered
      ? (node.isActive || node.status === 'active' ? 'active' : 'disconnected')
      : 'external';

    // Count how many hosts this threat IP is targeting (from edges)
    const targetingCount = isThreatZone && topology?.edges
      ? topology.edges.filter(e => e.source === node.id || e.target === node.id).length
      : 0;

    // Format OS display
    const osDisplay = node.os
      ? (node.os.toLowerCase().includes('windows') ? 'Windows' :
         node.os.toLowerCase().includes('linux') ? 'Linux' :
         node.os.toLowerCase().includes('mac') || node.os.toLowerCase().includes('darwin') ? 'macOS' :
         node.os)
      : 'Unknown';

    // Check if has alerts (include Medium for Protected Zone visibility)
    const hasAlerts = criticalCount > 0 || highCount > 0 || mediumCount > 0 || alertCount > 0;

    // Calculate screen position from world position using current transform
    const screenX = position.x * transform.k + transform.x;
    const screenY = position.y * transform.k + transform.y;
    const scaledRadius = radius * transform.k;

    // Tooltip dimensions for boundary detection
    const tooltipHeight = 160; // Approximate tooltip height
    const tooltipTopPosition = screenY - scaledRadius - 12 - tooltipHeight;

    // Check if tooltip would go above the container - if so, show below the node
    const showBelow = tooltipTopPosition < 10;

    // Border color based on zone
    const borderColor = isProtectedZone
      ? (agentStatus === 'active' ? '#10B981' : '#F59E0B')
      : '#EF4444';

    const tooltipStyle = {
      position: 'absolute',
      left: `${screenX}px`,
      top: showBelow
        ? `${screenY + scaledRadius + 12}px`  // Position below node
        : `${screenY - scaledRadius - 12}px`, // Position above node
      transform: showBelow
        ? 'translate(-50%, 0%)'   // Anchor at top
        : 'translate(-50%, -100%)', // Anchor at bottom
      width: '200px',
      background: 'rgba(15, 23, 42, 0.98)',
      border: `1.5px solid ${borderColor}`,
      borderRadius: '10px',
      padding: '12px 14px',
      zIndex: 100,
      pointerEvents: 'none',
      boxShadow: '0 6px 24px rgba(0,0,0,0.6)',
      fontFamily: 'Inter, -apple-system, sans-serif',
    };

    if (isProtectedZone) {
      // Protected Zone Node Tooltip (Agent)
      return (
        <div style={tooltipStyle}>
          {/* Header row with icon and hostname */}
          <div style={{ display: 'flex', alignItems: 'center', gap: '8px', marginBottom: '8px' }}>
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#94A3B8" strokeWidth="2">
              <rect x="2" y="3" width="20" height="14" rx="2" />
              <line x1="8" y1="21" x2="16" y2="21" />
              <line x1="12" y1="17" x2="12" y2="21" />
            </svg>
            <span style={{ fontSize: '12px', fontWeight: 700, color: '#F8FAFC' }}>
              {String(node.label || node.id || '').substring(0, 18)}
            </span>
          </div>

          {/* Divider line */}
          <div style={{ height: '1px', background: 'rgba(148, 163, 184, 0.3)', margin: '8px 0' }} />

          {/* IP and OS row */}
          <div style={{ fontSize: '11px', color: '#94A3B8', marginBottom: '8px' }}>
            {node.ip || 'No IP'}  •  {osDisplay}
          </div>

          {/* Status indicator */}
          <div style={{ display: 'flex', alignItems: 'center', gap: '8px', marginBottom: '10px' }}>
            <span style={{
              width: '8px',
              height: '8px',
              borderRadius: '50%',
              background: agentStatus === 'active' ? '#10B981' : '#F59E0B',
              boxShadow: `0 0 6px ${agentStatus === 'active' ? 'rgba(16, 185, 129, 0.6)' : 'rgba(245, 158, 11, 0.6)'}`,
            }} />
            <span style={{ fontSize: '11px', fontWeight: 600, color: agentStatus === 'active' ? '#10B981' : '#F59E0B' }}>
              {agentStatus === 'active' ? 'Active' : 'Disconnected'}
            </span>
          </div>

          {/* Alert counts row - Show Critical, High, and Medium for Protected Zone */}
          <div style={{ display: 'flex', flexDirection: 'column', gap: '4px' }}>
            {hasAlerts ? (
              <>
                {/* High/Critical alerts - primary indicators */}
                {(criticalCount > 0 || highCount > 0) && (
                  <div style={{ display: 'flex', alignItems: 'center', gap: '6px' }}>
                    <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="#EF4444" strokeWidth="2">
                      <path d="M12 2L2 22h20L12 2z" />
                      <line x1="12" y1="9" x2="12" y2="13" />
                      <circle cx="12" cy="17" r="1" fill="#EF4444" />
                    </svg>
                    <span style={{ fontSize: '11px', fontWeight: 600 }}>
                      {criticalCount > 0 && <span style={{ color: '#EF4444' }}>{criticalCount} Critical</span>}
                      {criticalCount > 0 && highCount > 0 && <span style={{ color: '#64748B' }}>  •  </span>}
                      {highCount > 0 && <span style={{ color: '#F97316' }}>{highCount} High</span>}
                    </span>
                  </div>
                )}
                {/* Medium alerts - additional context for Protected Zone */}
                {mediumCount > 0 && (
                  <div style={{ display: 'flex', alignItems: 'center', gap: '6px', paddingLeft: '18px' }}>
                    <span style={{ fontSize: '10px', fontWeight: 500, color: '#94A3B8' }}>
                      {mediumCount} Medium
                    </span>
                  </div>
                )}
              </>
            ) : (
              <div style={{ display: 'flex', alignItems: 'center', gap: '6px' }}>
                <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="#10B981" strokeWidth="2">
                  <circle cx="12" cy="12" r="10" />
                  <path d="M9 12l2 2 4-4" />
                </svg>
                <span style={{ fontSize: '11px', color: '#10B981', fontWeight: 500 }}>No alerts</span>
              </div>
            )}
          </div>
        </div>
      );
    } else if (isThreatZone) {
      // Threat Zone Node Tooltip (External/Internal Threat)
      const isInternal = node.isHighRiskHost && !node.isThreatActor;

      return (
        <div style={{ ...tooltipStyle, border: '1.5px solid #EF4444' }}>
          {/* Header row with warning icon and IP */}
          <div style={{ display: 'flex', alignItems: 'center', gap: '8px', marginBottom: '8px' }}>
            <svg width="14" height="14" viewBox="0 0 24 24" fill="rgba(239, 68, 68, 0.2)" stroke="#EF4444" strokeWidth="2">
              <path d="M12 2L2 22h20L12 2z" />
              <line x1="12" y1="9" x2="12" y2="13" />
              <circle cx="12" cy="17" r="1" fill="#EF4444" />
            </svg>
            <span style={{ fontSize: '12px', fontWeight: 700, color: '#EF4444' }}>
              {node.ip || node.label || node.id}
            </span>
          </div>

          {/* Divider line */}
          <div style={{ height: '1px', background: 'rgba(239, 68, 68, 0.3)', margin: '8px 0' }} />

          {/* Location/Type row */}
          <div style={{ display: 'flex', alignItems: 'center', gap: '8px', marginBottom: '8px' }}>
            {isInternal ? (
              <>
                <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="#F97316" strokeWidth="2">
                  <rect x="3" y="3" width="18" height="18" rx="2" />
                  <line x1="3" y1="9" x2="21" y2="9" />
                  <line x1="9" y1="21" x2="9" y2="9" />
                </svg>
                <span style={{ fontSize: '11px', color: '#F97316', fontWeight: 500 }}>Internal High-Risk Host</span>
              </>
            ) : (
              <>
                <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="#EF4444" strokeWidth="1.5">
                  <circle cx="12" cy="12" r="10" />
                  <line x1="2" y1="12" x2="22" y2="12" />
                  <path d="M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z" />
                </svg>
                <span style={{ fontSize: '11px', color: '#94A3B8' }}>External Threat Actor</span>
              </>
            )}
          </div>

          {/* Targeting count row */}
          <div style={{ display: 'flex', alignItems: 'center', gap: '8px', marginBottom: '10px' }}>
            <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="#64748B" strokeWidth="2">
              <path d="M10 13a5 5 0 0 0 7.54.54l3-3a5 5 0 0 0-7.07-7.07l-1.72 1.71" />
              <path d="M14 11a5 5 0 0 0-7.54-.54l-3 3a5 5 0 0 0 7.07 7.07l1.71-1.71" />
            </svg>
            <span style={{ fontSize: '11px', color: '#94A3B8' }}>
              Targeting <span style={{ color: '#F8FAFC', fontWeight: 600 }}>{targetingCount}</span> {targetingCount === 1 ? 'host' : 'hosts'}
            </span>
          </div>

          {/* Alert counts row */}
          <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
            <span style={{
              width: '8px',
              height: '8px',
              borderRadius: '50%',
              background: '#EF4444',
              boxShadow: '0 0 6px rgba(239, 68, 68, 0.6)',
            }} />
            <span style={{ fontSize: '11px', fontWeight: 600 }}>
              {criticalCount > 0 && <span style={{ color: '#EF4444' }}>{criticalCount} Critical</span>}
              {criticalCount > 0 && highCount > 0 && <span style={{ color: '#64748B' }}>  •  </span>}
              {highCount > 0 && <span style={{ color: '#F97316' }}>{highCount} High</span>}
              {criticalCount === 0 && highCount === 0 && (
                <span style={{ color: '#94A3B8' }}>{alertCount} alerts</span>
              )}
            </span>
          </div>
        </div>
      );
    } else {
      // Fallback for unclassified nodes (basic tooltip)
      return (
        <div style={{ ...tooltipStyle, border: '1.5px solid rgba(100, 116, 139, 0.5)' }}>
          <div style={{ fontSize: '12px', fontWeight: 700, color: '#F8FAFC', marginBottom: '8px' }}>
            {String(node.label || node.id || '').substring(0, 20)}
          </div>
          <div style={{ fontSize: '11px', color: '#94A3B8' }}>
            {node.ip || 'No IP'}
          </div>
        </div>
      );
    }
  };

  return (
    <div
      ref={containerRef}
      style={{
        position: 'relative',
        width: '100%',
        height: '100%',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        background: BACKGROUND_COLOR,
        overflow: 'hidden',
      }}
    >
      <ZoneSidebar
        nodes={useNewLayout && newLayoutResult?.nodes ? newLayoutResult.nodes : []}
        selectedNodeId={selectedNodeId}
        onSelectNode={onSelectNode}
        onFocusNode={focusOnNodeWithCenter}
      />
      <MiniMap
        width={width}
        height={height}
        positions={positions}
        systemCenter={systemCenter}
        segments={segments}
        transform={transform}
        onNavigate={navigateToWorldPoint}
        containerWidth={containerDimensions.width}
        containerHeight={containerDimensions.height}
      />
      <Legend />

      {/* Floating Mini Toolbar - Top center */}
      <div style={{
        position: 'absolute',
        top: '16px',
        left: '50%',
        transform: 'translateX(calc(-50% + 125px))', // Offset for sidebar
        background: 'rgba(15, 23, 42, 0.95)',
        border: '1px solid rgba(100, 116, 139, 0.3)',
        borderRadius: '10px',
        padding: '8px 12px',
        zIndex: 15,
        display: 'flex',
        alignItems: 'center',
        gap: '6px',
        fontFamily: 'Inter, -apple-system, sans-serif',
        backdropFilter: 'blur(8px)',
        boxShadow: '0 4px 16px rgba(0,0,0,0.3)',
      }}>
        {/* Show Unregistered Toggle */}
        <button
          onClick={() => onShowUnregisteredChange && onShowUnregisteredChange(!showUnregistered)}
          title={showUnregistered ? 'Hide external nodes' : 'Show external nodes'}
          style={{
            display: 'flex',
            alignItems: 'center',
            gap: '6px',
            padding: '6px 10px',
            borderRadius: '6px',
            border: 'none',
            background: showUnregistered ? 'rgba(16, 185, 129, 0.2)' : 'rgba(100, 116, 139, 0.2)',
            color: showUnregistered ? '#10B981' : '#64748B',
            fontSize: '11px',
            fontWeight: 600,
            cursor: 'pointer',
            transition: 'all 0.2s ease',
          }}
        >
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
            {showUnregistered ? (
              <path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z M12 9a3 3 0 100 6 3 3 0 000-6z" />
            ) : (
              <path d="M17.94 17.94A10.07 10.07 0 0112 20c-7 0-11-8-11-8a18.45 18.45 0 015.06-5.94M9.9 4.24A9.12 9.12 0 0112 4c7 0 11 8 11 8a18.5 18.5 0 01-2.16 3.19m-6.72-1.07a3 3 0 11-4.24-4.24 M1 1l22 22" />
            )}
          </svg>
          <span style={{
            width: '6px',
            height: '6px',
            borderRadius: '50%',
            background: showUnregistered ? '#10B981' : '#64748B',
          }} />
        </button>

        {/* Divider */}
        <div style={{ width: '1px', height: '20px', background: 'rgba(100, 116, 139, 0.3)' }} />

        {/* View Mode Toggle */}
        <div style={{
          display: 'flex',
          background: 'rgba(100, 116, 139, 0.15)',
          borderRadius: '6px',
          padding: '2px',
        }}>
          <button
            onClick={() => onViewModeChange && onViewModeChange('split')}
            title="Split Layout"
            style={{
              padding: '5px 8px',
              borderRadius: '4px',
              border: 'none',
              background: viewMode === 'split' ? 'rgba(96, 165, 250, 0.3)' : 'transparent',
              color: viewMode === 'split' ? '#60A5FA' : '#64748B',
              cursor: 'pointer',
              display: 'flex',
              alignItems: 'center',
              transition: 'all 0.2s ease',
            }}
          >
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              <rect x="3" y="3" width="7" height="7" rx="1" />
              <rect x="14" y="3" width="7" height="7" rx="1" />
              <rect x="3" y="14" width="7" height="7" rx="1" />
              <rect x="14" y="14" width="7" height="7" rx="1" />
            </svg>
          </button>
          <button
            onClick={() => onViewModeChange && onViewModeChange('concentric')}
            title="Concentric Layout"
            style={{
              padding: '5px 8px',
              borderRadius: '4px',
              border: 'none',
              background: viewMode === 'concentric' ? 'rgba(96, 165, 250, 0.3)' : 'transparent',
              color: viewMode === 'concentric' ? '#60A5FA' : '#64748B',
              cursor: 'pointer',
              display: 'flex',
              alignItems: 'center',
              transition: 'all 0.2s ease',
            }}
          >
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              <circle cx="12" cy="12" r="3" />
              <circle cx="12" cy="12" r="7" />
              <circle cx="12" cy="12" r="10" />
            </svg>
          </button>
        </div>

        {/* Divider */}
        <div style={{ width: '1px', height: '20px', background: 'rgba(100, 116, 139, 0.3)' }} />

        {/* Zoom Controls */}
        <div style={{ display: 'flex', alignItems: 'center', gap: '2px' }}>
          <button
            onClick={() => onRefresh && onRefresh()}
            title="Refresh data"
            style={{
              padding: '6px',
              borderRadius: '4px',
              border: 'none',
              background: 'transparent',
              color: '#94A3B8',
              cursor: 'pointer',
              display: 'flex',
              alignItems: 'center',
              transition: 'all 0.2s ease',
            }}
            onMouseEnter={(e) => e.currentTarget.style.background = 'rgba(100, 116, 139, 0.2)'}
            onMouseLeave={(e) => e.currentTarget.style.background = 'transparent'}
          >
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              <path d="M23 4v6h-6M1 20v-6h6M3.51 9a9 9 0 0114.85-3.36L23 10M1 14l4.64 4.36A9 9 0 0020.49 15" />
            </svg>
          </button>
          <button
            onClick={() => zoomRef.current && svgRef.current && d3.select(svgRef.current).transition().duration(300).call(zoomRef.current.scaleBy, 1.3)}
            title="Zoom in"
            style={{
              padding: '6px',
              borderRadius: '4px',
              border: 'none',
              background: 'transparent',
              color: '#94A3B8',
              cursor: 'pointer',
              display: 'flex',
              alignItems: 'center',
              transition: 'all 0.2s ease',
            }}
            onMouseEnter={(e) => e.currentTarget.style.background = 'rgba(100, 116, 139, 0.2)'}
            onMouseLeave={(e) => e.currentTarget.style.background = 'transparent'}
          >
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              <circle cx="11" cy="11" r="8" />
              <path d="M21 21l-4.35-4.35M11 8v6M8 11h6" />
            </svg>
          </button>
          <button
            onClick={() => zoomRef.current && svgRef.current && d3.select(svgRef.current).transition().duration(300).call(zoomRef.current.scaleBy, 0.7)}
            title="Zoom out"
            style={{
              padding: '6px',
              borderRadius: '4px',
              border: 'none',
              background: 'transparent',
              color: '#94A3B8',
              cursor: 'pointer',
              display: 'flex',
              alignItems: 'center',
              transition: 'all 0.2s ease',
            }}
            onMouseEnter={(e) => e.currentTarget.style.background = 'rgba(100, 116, 139, 0.2)'}
            onMouseLeave={(e) => e.currentTarget.style.background = 'transparent'}
          >
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              <circle cx="11" cy="11" r="8" />
              <path d="M21 21l-4.35-4.35M8 11h6" />
            </svg>
          </button>
          <button
            onClick={() => {
              if (typeof calculateFitToViewTransform === 'function') {
                const fitTransform = calculateFitToViewTransform();
                if (fitTransform && zoomRef.current && svgRef.current) {
                  d3.select(svgRef.current)
                    .transition()
                    .duration(500)
                    .call(zoomRef.current.transform, d3.zoomIdentity.translate(fitTransform.x, fitTransform.y).scale(fitTransform.k));
                }
              }
            }}
            title="Fit to view"
            style={{
              padding: '6px',
              borderRadius: '4px',
              border: 'none',
              background: 'transparent',
              color: '#94A3B8',
              cursor: 'pointer',
              display: 'flex',
              alignItems: 'center',
              transition: 'all 0.2s ease',
            }}
            onMouseEnter={(e) => e.currentTarget.style.background = 'rgba(100, 116, 139, 0.2)'}
            onMouseLeave={(e) => e.currentTarget.style.background = 'transparent'}
          >
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              <path d="M8 3H5a2 2 0 00-2 2v3m18 0V5a2 2 0 00-2-2h-3m0 18h3a2 2 0 002-2v-3M3 16v3a2 2 0 002 2h3" />
            </svg>
          </button>
        </div>

        {/* Divider */}
        <div style={{ width: '1px', height: '20px', background: 'rgba(100, 116, 139, 0.3)' }} />

        {/* Save Button */}
        <button
          onClick={() => onSaveLayout && onSaveLayout()}
          title={hasUnsavedChanges ? 'Save layout changes' : 'Layout saved'}
          disabled={saving}
          style={{
            padding: '6px 10px',
            borderRadius: '6px',
            border: 'none',
            background: hasUnsavedChanges ? 'rgba(96, 165, 250, 0.2)' : 'transparent',
            color: hasUnsavedChanges ? '#60A5FA' : '#64748B',
            cursor: saving ? 'wait' : 'pointer',
            display: 'flex',
            alignItems: 'center',
            gap: '4px',
            fontSize: '11px',
            fontWeight: 600,
            transition: 'all 0.2s ease',
            opacity: saving ? 0.6 : 1,
          }}
          onMouseEnter={(e) => !saving && (e.currentTarget.style.background = hasUnsavedChanges ? 'rgba(96, 165, 250, 0.3)' : 'rgba(100, 116, 139, 0.2)')}
          onMouseLeave={(e) => e.currentTarget.style.background = hasUnsavedChanges ? 'rgba(96, 165, 250, 0.2)' : 'transparent'}
        >
          {saving ? (
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" style={{ animation: 'spin 1s linear infinite' }}>
              <circle cx="12" cy="12" r="10" strokeDasharray="32" strokeDashoffset="12" />
            </svg>
          ) : (
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              <path d="M19 21H5a2 2 0 01-2-2V5a2 2 0 012-2h11l5 5v11a2 2 0 01-2 2z" />
              <polyline points="17,21 17,13 7,13 7,21" />
              <polyline points="7,3 7,8 15,8" />
            </svg>
          )}
        </button>

        {/* Zoom Level */}
        <div style={{
          padding: '4px 8px',
          borderRadius: '4px',
          background: 'rgba(100, 116, 139, 0.15)',
          fontSize: '11px',
          color: '#94A3B8',
          fontWeight: 600,
          minWidth: '42px',
          textAlign: 'center',
        }}>
          {Math.round(transform.k * 100)}%
        </div>
      </div>

      {/* Focus Zone Buttons - Left side of canvas (Split View only) */}
      {viewMode === 'split' && (
        <div style={{
          position: 'absolute',
          left: '270px',
          top: '50%',
          transform: 'translateY(-50%)',
          display: 'flex',
          flexDirection: 'column',
          gap: '8px',
          zIndex: 15,
        }}>
          <button
            onClick={() => handleFocusCluster('agents')}
            title="Focus Protected Zone"
            style={{
              padding: '10px 12px',
              borderRadius: '8px',
              border: focusedCluster === 'agents' ? '2px solid #10B981' : '1px solid rgba(255,255,255,0.15)',
              background: focusedCluster === 'agents' ? 'rgba(16, 185, 129, 0.2)' : 'rgba(15, 23, 42, 0.9)',
              color: focusedCluster === 'agents' ? '#10B981' : '#94A3B8',
              cursor: 'pointer',
              display: 'flex',
              alignItems: 'center',
              gap: '8px',
              fontSize: '11px',
              fontWeight: 600,
              transition: 'all 0.2s ease',
              backdropFilter: 'blur(8px)',
              boxShadow: '0 2px 8px rgba(0,0,0,0.3)',
            }}
          >
            <span style={{
              width: '8px',
              height: '8px',
              borderRadius: '50%',
              background: '#10B981',
              boxShadow: focusedCluster === 'agents' ? '0 0 8px rgba(16, 185, 129, 0.6)' : 'none',
            }} />
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              <path d="M12 2L4 6v6c0 5.5 3.5 10.7 8 12 4.5-1.3 8-6.5 8-12V6l-8-4z" />
            </svg>
            Protected
          </button>
          <button
            onClick={() => handleFocusCluster('external')}
            title="Focus Threat Zone"
            style={{
              padding: '10px 12px',
              borderRadius: '8px',
              border: focusedCluster === 'external' ? '2px solid #EF4444' : '1px solid rgba(255,255,255,0.15)',
              background: focusedCluster === 'external' ? 'rgba(239, 68, 68, 0.2)' : 'rgba(15, 23, 42, 0.9)',
              color: focusedCluster === 'external' ? '#EF4444' : '#94A3B8',
              cursor: 'pointer',
              display: 'flex',
              alignItems: 'center',
              gap: '8px',
              fontSize: '11px',
              fontWeight: 600,
              transition: 'all 0.2s ease',
              backdropFilter: 'blur(8px)',
              boxShadow: '0 2px 8px rgba(0,0,0,0.3)',
            }}
          >
            <span style={{
              width: '8px',
              height: '8px',
              borderRadius: '50%',
              background: '#EF4444',
              boxShadow: focusedCluster === 'external' ? '0 0 8px rgba(239, 68, 68, 0.6)' : 'none',
            }} />
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              <path d="M12 2L2 22h20L12 2z" />
              <path d="M12 9v4M12 17h.01" />
            </svg>
            Threat
          </button>
        </div>
      )}

      {/* Center Crosshair Indicator - Shows during pan/zoom */}
      {isPanning && (
        <div style={{
          position: 'absolute',
          top: '50%',
          left: 'calc(50% + 125px)', // Offset for sidebar
          transform: 'translate(-50%, -50%)',
          pointerEvents: 'none',
          zIndex: 5,
          opacity: 0.6,
        }}>
          {/* Horizontal line */}
          <div style={{
            position: 'absolute',
            width: '40px',
            height: '2px',
            background: 'linear-gradient(90deg, transparent, #F472B6, transparent)',
            top: '50%',
            left: '50%',
            transform: 'translate(-50%, -50%)',
          }} />
          {/* Vertical line */}
          <div style={{
            position: 'absolute',
            width: '2px',
            height: '40px',
            background: 'linear-gradient(180deg, transparent, #F472B6, transparent)',
            top: '50%',
            left: '50%',
            transform: 'translate(-50%, -50%)',
          }} />
          {/* Center dot */}
          <div style={{
            position: 'absolute',
            width: '6px',
            height: '6px',
            borderRadius: '50%',
            background: '#F472B6',
            top: '50%',
            left: '50%',
            transform: 'translate(-50%, -50%)',
            boxShadow: '0 0 8px rgba(244, 114, 182, 0.6)',
          }} />
        </div>
      )}

      <div
        style={{
          width: '100%',
          height: '100%',
          maxWidth: '1280px',
          maxHeight: '880px',
        }}
      >
        <svg
          ref={svgRef}
          width="100%"
          height="100%"
          viewBox={`0 0 ${width} ${height}`}
          xmlns="http://www.w3.org/2000/svg"
          style={{ display: 'block', cursor: 'grab' }}
        >
          {/* Main transform group for pan/zoom */}
          <g transform={`translate(${transform.x}, ${transform.y}) scale(${transform.k})`}>
            {/* New Layout Rendering (Split/Concentric) */}
            {useNewLayout && newLayoutResult && (
              <g>
                {/* Render cluster glow backgrounds first (behind everything) */}
                {viewMode === 'split' && newLayoutResult.clusters && (
                  <>
                    {/* Zone glows - subtle red radial gradient */}
                    <defs>
                      <radialGradient id="protectedZoneGlow" cx="50%" cy="50%" r="50%">
                        <stop offset="0%" stopColor="#DC2626" stopOpacity="0.05" />
                        <stop offset="50%" stopColor="#DC2626" stopOpacity="0.02" />
                        <stop offset="80%" stopColor="#DC2626" stopOpacity="0.01" />
                        <stop offset="100%" stopColor="#DC2626" stopOpacity="0" />
                      </radialGradient>
                      <radialGradient id="threatZoneGlow" cx="50%" cy="50%" r="50%">
                        <stop offset="0%" stopColor="#DC2626" stopOpacity="0.06" />
                        <stop offset="50%" stopColor="#DC2626" stopOpacity="0.025" />
                        <stop offset="80%" stopColor="#DC2626" stopOpacity="0.01" />
                        <stop offset="100%" stopColor="#DC2626" stopOpacity="0" />
                      </radialGradient>
                    </defs>
                    {/* Protected Zone background circle */}
                    <circle
                      cx={newLayoutResult.clusters.agents.center.x}
                      cy={newLayoutResult.clusters.agents.center.y}
                      r={newLayoutResult.clusters.agents.glowRadius || 200}
                      fill="url(#protectedZoneGlow)"
                    />
                    {/* Threat Zone background circle */}
                    <circle
                      cx={newLayoutResult.clusters.external.center.x}
                      cy={newLayoutResult.clusters.external.center.y}
                      r={newLayoutResult.clusters.external.glowRadius || 200}
                      fill="url(#threatZoneGlow)"
                    />
                  </>
                )}

                {/* Concentric view glow background - subtle like split view */}
                {viewMode === 'concentric' && newLayoutResult.center && (
                  <>
                    <defs>
                      <radialGradient id="concentricGlow" cx="50%" cy="50%" r="50%">
                        <stop offset="0%" stopColor="#DC2626" stopOpacity="0.06" />
                        <stop offset="50%" stopColor="#DC2626" stopOpacity="0.025" />
                        <stop offset="80%" stopColor="#DC2626" stopOpacity="0.01" />
                        <stop offset="100%" stopColor="#DC2626" stopOpacity="0" />
                      </radialGradient>
                    </defs>
                    <circle
                      cx={newLayoutResult.center.x}
                      cy={newLayoutResult.center.y}
                      r={newLayoutResult.glowRadius || 250}
                      fill="url(#concentricGlow)"
                    />
                  </>
                )}

                {/* Render spokes (behind nodes) */}
                {renderSpokes(newLayoutResult.spokes)}

                {/* Render SIEM hubs with click-to-focus */}
                {viewMode === 'split' && newLayoutResult.hubs && (
                  <>
                    {renderSiemHub(newLayoutResult.hubs.agents, 'normal', () => handleFocusCluster('agents'))}
                    {renderSiemHub(newLayoutResult.hubs.external, newLayoutResult.threatLevel, () => handleFocusCluster('external'))}
                  </>
                )}
                {viewMode === 'concentric' && newLayoutResult.hub && (
                  renderSiemHub(newLayoutResult.hub, newLayoutResult.threatLevel)
                )}

                {/* Render all nodes */}
                {newLayoutResult.nodes.map((node) => renderNode(node, false))}

                {/* Render ring labels AFTER nodes so they appear on top */}
                {renderRingLabels()}
              </g>
            )}

          {/* Legacy Layout Rendering (Segment-based) */}
          {!useNewLayout && segments.map((segment) => {
            const isActive = segment.id === selectedSegmentId || segment.id === activeSegmentId;
            const labelColor = isActive ? SEGMENT_LABEL_COLOR : SEGMENT_LABEL_MUTED;
            const hubPosition = segment.hub ? (positions.get(segment.hub.id) || initialPositions.get(segment.hub.id)) : null;
            const labelAngle = hubPosition
              ? Math.atan2(hubPosition.y - systemCenter.y, hubPosition.x - systemCenter.x)
              : segment.angleRad;
            const labelOffset = (segment.arcRadius || 0) + SEGMENT_LABEL_OFFSET;
            const labelX = hubPosition
              ? hubPosition.x + labelOffset * Math.cos(labelAngle)
              : segment.center.x;
            const labelY = hubPosition
              ? hubPosition.y + labelOffset * Math.sin(labelAngle)
              : segment.center.y - labelOffset;

            return (
              <g
                key={`segment-${segment.id}`}
                onMouseEnter={() => setHoveredSegmentId(segment.id)}
                onMouseLeave={() => setHoveredSegmentId(null)}
              >
                <text
                  x={labelX}
                  y={labelY}
                  fontSize={12}
                  fontWeight={isActive ? 600 : 500}
                  fill={labelColor}
                  textAnchor="middle"
                  onClick={() => {
                    if (!onSelectNode) return;
                    onSelectNode({
                      id: segment.id,
                      label: segment.label,
                      type: 'segment',
                      nodesCount: segment.nodesCount,
                      criticalCount: segment.criticalCount,
                      highCount: segment.highCount,
                      alertCount: segment.alertCount,
                      riskScore: segment.riskScore,
                    });
                  }}
                  style={{ cursor: 'pointer' }}
                >
                  {segment.label}
                </text>
                {hubPosition && (
                  <g>
                    {segment.nodes.map((node) => {
                      const nodePosition = positions.get(node.id) || initialPositions.get(node.id);
                      if (!nodePosition) return null;
                      return (
                        <line
                          key={`edge-${segment.id}-${node.id}`}
                          x1={hubPosition.x}
                          y1={hubPosition.y}
                          x2={nodePosition.x}
                          y2={nodePosition.y}
                          stroke={EDGE_COLOR}
                          strokeWidth={1.4}
                          strokeDasharray={EDGE_DASH}
                          strokeLinecap="round"
                          opacity={0.9}
                        />
                      );
                    })}
                  </g>
                )}
                {segment.hub && renderNode(segment.hub, true)}
                {segment.nodes.map((node) => renderNode(node, false))}
              </g>
            );
          })}
          </g>
        </svg>
      </div>

      {/* HTML Tooltip - rendered outside SVG for proper z-index above floating toolbar */}
      {renderHoveredNodeTooltipHTML()}
    </div>
  );
});

export default NetworkTopology2D;
