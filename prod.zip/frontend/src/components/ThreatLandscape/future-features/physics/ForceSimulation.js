/**
 * ForceSimulation
 * Wrapper around D3 force simulation for network layout in 3D space
 */

import * as d3 from 'd3';
import { PHYSICS_CONFIG } from '../utils/constants';

/**
 * ForceSimulation class for managing D3 force-directed layout
 */
export class ForceSimulation {
    constructor(nodes, edges, config = {}) {
        this.config = { ...PHYSICS_CONFIG, ...config };
        this.nodes = nodes;
        this.edges = edges;
        this.simulation = null;
        this.isRunning = false;

        this.initialize();
    }

    /**
     * Initialize the D3 force simulation
     */
    initialize() {
        this.simulation = d3.forceSimulation(this.nodes)
            .alphaDecay(this.config.alphaDecay)
            .velocityDecay(this.config.velocityDecay)
            .force('charge', d3.forceManyBody()
                .strength(this.config.chargeStrength)
                .distanceMax(this.config.chargeDistanceMax)
            )
            .force('collide', d3.forceCollide()
                .radius(d => d.type === 'cluster'
                    ? this.config.collideRadiusCluster
                    : this.config.collideRadiusNormal
                )
                .iterations(this.config.collideIterations)
            )
            .force('link', d3.forceLink(this.edges)
                .id(d => d.id)
                .distance(this.config.linkDistance)
            )
            .force('center', d3.forceCenter(0, 0))
            .force('x', d3.forceX().strength(this.config.centerStrength))
            .force('y', d3.forceY().strength(this.config.centerStrength));

        this.isRunning = true;
    }

    /**
     * Advance the simulation by one tick
     * Call this in the animation loop
     */
    tick() {
        if (this.simulation && this.isRunning) {
            this.simulation.tick();
        }
    }

    /**
     * Start or restart the simulation
     */
    start() {
        if (this.simulation) {
            this.simulation.restart();
            this.isRunning = true;
        }
    }

    /**
     * Stop the simulation
     */
    stop() {
        if (this.simulation) {
            this.simulation.stop();
            this.isRunning = false;
        }
    }

    /**
     * Fix a node's position (for drag operations)
     * @param {string} nodeId
     * @param {Object} position - { x, y, z }
     */
    fixNode(nodeId, position) {
        const node = this.nodes.find(n => n.id === nodeId);
        if (node) {
            node.fx = position.x;
            node.fy = position.y;
            node.position_locked = true;
        }
    }

    /**
     * Unfix a node's position
     * @param {string} nodeId
     */
    unfixNode(nodeId) {
        const node = this.nodes.find(n => n.id === nodeId);
        if (node) {
            node.fx = null;
            node.fy = null;
            node.position_locked = false;
        }
    }

    /**
     * Reheat the simulation (after changes)
     * @param {number} alpha - Target alpha value (higher = more movement)
     */
    reheat(alpha = 0.3) {
        if (this.simulation) {
            this.simulation.alphaTarget(alpha).restart();
        }
    }

    /**
     * Cool down the simulation
     */
    coolDown() {
        if (this.simulation) {
            this.simulation.alphaTarget(0);
        }
    }

    /**
     * Update nodes and edges data
     * @param {Array} nodes
     * @param {Array} edges
     */
    updateData(nodes, edges) {
        this.nodes = nodes;
        this.edges = edges;

        if (this.simulation) {
            this.simulation.nodes(nodes);
            this.simulation.force('link').links(edges);
            this.reheat(0.3);
        }
    }

    /**
     * Get the current alpha value (simulation heat)
     * @returns {number}
     */
    getAlpha() {
        return this.simulation ? this.simulation.alpha() : 0;
    }

    /**
     * Check if simulation is still active
     * @returns {boolean}
     */
    isActive() {
        return this.getAlpha() > 0.001;
    }

    /**
     * Get current node positions
     * @returns {Array<{id, x, y}>}
     */
    getPositions() {
        return this.nodes.map(node => ({
            id: node.id,
            x: node.x,
            y: node.y,
        }));
    }

    /**
     * Dispose the simulation
     */
    dispose() {
        this.stop();
        this.simulation = null;
    }
}
