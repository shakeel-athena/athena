/**
 * ZoneRenderer
 * Handles creation of network segment zone visualizations
 * Creates floor planes and labels to delineate network segments
 */

import * as THREE from 'three';
import SpriteText from 'three-spritetext';
import { NETWORK_SEGMENTS } from '../utils/constants';
import { getNodeSegment, getNodeSegmentConfig } from '../utils/NodeStyleResolver';

/**
 * ZoneRenderer class for managing segment zone visualizations
 */
export class ZoneRenderer {
    constructor(scene, config = {}) {
        this.scene = scene;
        this.config = {
            yPosition: -28,
            padding: 40,
            planeOpacity: 0.12,
            borderOpacity: 0.5,
            labelYOffset: 8,
            labelZOffset: -15,
            ...config,
        };

        this.zoneMeshes = [];
        this.zoneLabels = [];
    }

    /**
     * Create segment zones from node positions
     * @param {Array} nodes - Array of node data with positions
     * @returns {Array} - Array of created zone objects
     */
    createSegmentZones(nodes) {
        this.dispose();

        // Group nodes by segment
        const segments = {};
        nodes.forEach(node => {
            const segment = getNodeSegment(node);
            if (!segments[segment]) {
                segments[segment] = [];
            }
            segments[segment].push(node);
        });

        // Create zone for each segment
        Object.entries(segments).forEach(([segmentKey, segmentNodes]) => {
            if (segmentNodes.length === 0) return;

            const config = getNodeSegmentConfig(segmentNodes[0]);
            const bounds = this.calculateBounds(segmentNodes);

            // Create floor plane
            const plane = this.createFloorPlane(bounds, config);
            this.zoneMeshes.push(plane);

            // Create border
            const border = this.createBorder(bounds, config);
            this.zoneMeshes.push(border);

            // Create label
            const label = this.createLabel(bounds, config);
            this.zoneLabels.push(label);
        });

        return this.zoneMeshes;
    }

    /**
     * Calculate bounding box for a set of nodes
     * @param {Array} nodes
     * @returns {Object} { minX, maxX, minZ, maxZ, centerX, centerZ, width, depth }
     */
    calculateBounds(nodes) {
        let minX = Infinity, maxX = -Infinity;
        let minZ = Infinity, maxZ = -Infinity;

        nodes.forEach(node => {
            minX = Math.min(minX, node.x - 20);
            maxX = Math.max(maxX, node.x + 20);
            minZ = Math.min(minZ, node.z - 20);
            maxZ = Math.max(maxZ, node.z + 20);
        });

        const width = maxX - minX + this.config.padding;
        const depth = maxZ - minZ + this.config.padding;
        const centerX = (minX + maxX) / 2;
        const centerZ = (minZ + maxZ) / 2;

        return { minX, maxX, minZ, maxZ, centerX, centerZ, width, depth };
    }

    /**
     * Create floor plane for a segment
     * @param {Object} bounds
     * @param {Object} config - Segment config from NETWORK_SEGMENTS
     * @returns {THREE.Mesh}
     */
    createFloorPlane(bounds, config) {
        const geometry = new THREE.PlaneGeometry(bounds.width, bounds.depth);
        const material = new THREE.MeshBasicMaterial({
            color: new THREE.Color(config.color),
            transparent: true,
            opacity: this.config.planeOpacity,
            side: THREE.DoubleSide,
        });

        const plane = new THREE.Mesh(geometry, material);
        plane.rotation.x = -Math.PI / 2;
        plane.position.set(bounds.centerX, this.config.yPosition, bounds.centerZ);

        this.scene.add(plane);
        return plane;
    }

    /**
     * Create border for a segment
     * @param {Object} bounds
     * @param {Object} config - Segment config
     * @returns {THREE.LineSegments}
     */
    createBorder(bounds, config) {
        const boxGeometry = new THREE.BoxGeometry(bounds.width, 2, bounds.depth);
        const edgesGeometry = new THREE.EdgesGeometry(boxGeometry);
        const material = new THREE.LineBasicMaterial({
            color: new THREE.Color(config.color),
            transparent: true,
            opacity: this.config.borderOpacity,
        });

        const border = new THREE.LineSegments(edgesGeometry, material);
        border.position.set(bounds.centerX, this.config.yPosition, bounds.centerZ);

        this.scene.add(border);
        boxGeometry.dispose(); // Only edges geometry is used

        return border;
    }

    /**
     * Create label for a segment
     * @param {Object} bounds
     * @param {Object} config - Segment config
     * @returns {SpriteText}
     */
    createLabel(bounds, config) {
        const label = new SpriteText(config.label, 4, config.color);
        label.position.set(
            bounds.centerX,
            this.config.yPosition + this.config.labelYOffset,
            bounds.minZ + this.config.labelZOffset
        );
        label.material.depthTest = false;
        label.fontWeight = 'bold';

        this.scene.add(label);
        return label;
    }

    /**
     * Update zones when node positions change
     * @param {Array} nodes - Updated node array with new positions
     */
    updateZones(nodes) {
        // For now, recreate zones on significant changes
        // A more optimized version could track and update individual zones
        this.createSegmentZones(nodes);
    }

    /**
     * Get all zone meshes
     * @returns {Array}
     */
    getZones() {
        return this.zoneMeshes;
    }

    /**
     * Dispose all resources
     */
    dispose() {
        this.zoneMeshes.forEach(mesh => {
            if (mesh.geometry) mesh.geometry.dispose();
            if (mesh.material) mesh.material.dispose();
            this.scene.remove(mesh);
        });
        this.zoneMeshes = [];

        this.zoneLabels.forEach(label => {
            if (label.material) label.material.dispose();
            this.scene.remove(label);
        });
        this.zoneLabels = [];
    }
}
