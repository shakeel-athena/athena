/**
 * NodeRenderer
 * Handles creation and management of network node visualizations
 * Uses InstancedMesh for performance with large numbers of nodes
 */

import * as THREE from 'three';
import SpriteText from 'three-spritetext';
import { NODE_CONFIG, UX_COLORS } from '../utils/constants';
import { createNodeTexture, clearTextureCache } from '../utils/TextureCache';
import {
    getNodeIconKey,
    getNodeSegment,
    isNodeCritical,
    getNodeScale,
    getNodeVisualStyle
} from '../utils/NodeStyleResolver';

/**
 * NodeRenderer class for managing network node visualizations
 */
export class NodeRenderer {
    constructor(scene, camera, config = {}) {
        this.scene = scene;
        this.camera = camera;
        this.config = { ...NODE_CONFIG, ...config };

        this.nodeMeshes = [];
        this.nodeLabels = [];
        this.alertRings = [];
        this.criticalNodes = [];

        // Flat, camera-facing geometry for UX-style nodes
        this.nodeGeometry = new THREE.CircleGeometry(
            this.config.baseRadius,
            this.config.segments
        );
    }

    /**
     * Create all node meshes from topology data
     * @param {Array} nodes - Array of node data objects
     * @returns {Array<THREE.Mesh>} - Array of created meshes
     */
    createNodes(nodes) {
        this.clearNodes(); // Clean up any existing nodes

        nodes.forEach(node => {
            const mesh = this.createNodeMesh(node);
            this.nodeMeshes.push(mesh);

            // Create label
            const label = this.createNodeLabel(node, mesh);
            this.nodeLabels.push(label);
            mesh.userData.label = label;

            // Create alert ring for critical nodes
            if (isNodeCritical(node)) {
                this.criticalNodes.push(mesh);
                const ring = this.createAlertRing(mesh);
                this.alertRings.push(ring);
                mesh.userData.alertRing = ring;
            }
        });

        return this.nodeMeshes;
    }

    /**
     * Create a single node mesh
     * @param {Object} node - Node data
     * @returns {THREE.Mesh}
     */
    createNodeMesh(node) {
        const style = getNodeVisualStyle(node);
        const iconKey = getNodeIconKey(node);
        const scale = getNodeScale(node, this.config);
        const texture = createNodeTexture(iconKey, style);

        const material = new THREE.MeshBasicMaterial({
            map: texture,
            transparent: true,
            alphaTest: 0.02,
            side: THREE.DoubleSide,
        });
        material.toneMapped = false;

        const mesh = new THREE.Mesh(this.nodeGeometry, material);

        // Set position
        mesh.position.set(
            node.x || (Math.random() - 0.5) * 100,
            node.y || (Math.random() - 0.5) * 30,
            node.z || (Math.random() - 0.5) * 100
        );
        mesh.scale.set(scale, scale, scale);
        mesh.quaternion.copy(this.camera.quaternion);

        // Store metadata
        mesh.userData = {
            id: node.id,
            node: node,
            baseScale: scale,
            baseOpacity: 1,
            style,
            iconKey,
            segment: getNodeSegment(node),
            subnet: node.subnet || null,
        };

        this.scene.add(mesh);
        return mesh;
    }

    /**
     * Create label for a node
     * @param {Object} node - Node data
     * @param {THREE.Mesh} mesh - Associated mesh
     * @returns {SpriteText}
     */
    createNodeLabel(node, mesh) {
        const labelText = node.label || node.name || node.ip || node.id;
        const maxLen = this.config.labelMaxLength;
        const shortLabel = labelText.length > maxLen
            ? labelText.substring(0, maxLen - 3) + '...'
            : labelText;

        const label = new SpriteText(shortLabel, 1.8, UX_COLORS.icon);
        label.position.set(
            mesh.position.x,
            mesh.position.y + this.config.labelOffset,
            mesh.position.z
        );
        label.material.depthTest = false;
        label.fontWeight = '500';

        this.scene.add(label);
        return label;
    }

    /**
     * Create alert ring for critical nodes
     * @param {THREE.Mesh} mesh - Node mesh
     * @returns {THREE.Mesh}
     */
    createAlertRing(mesh) {
        const ringGeometry = new THREE.PlaneGeometry(22, 22);
        const canvas = document.createElement('canvas');
        canvas.width = 64;
        canvas.height = 64;
        const ctx = canvas.getContext('2d');
        const ringColor = mesh.userData?.style?.stroke || UX_COLORS.node.critical.stroke;
        const color = new THREE.Color(ringColor);
        const rgb = `${Math.round(color.r * 255)}, ${Math.round(color.g * 255)}, ${Math.round(color.b * 255)}`;
        const gradient = ctx.createRadialGradient(32, 32, 8, 32, 32, 30);
        gradient.addColorStop(0, `rgba(${rgb}, 0.35)`);
        gradient.addColorStop(0.4, `rgba(${rgb}, 0.18)`);
        gradient.addColorStop(1, `rgba(${rgb}, 0)`);
        ctx.fillStyle = gradient;
        ctx.fillRect(0, 0, 64, 64);

        const texture = new THREE.CanvasTexture(canvas);
        const ringMaterial = new THREE.MeshBasicMaterial({
            map: texture,
            transparent: true,
            blending: THREE.AdditiveBlending,
            depthWrite: false,
            side: THREE.DoubleSide,
        });

        const ring = new THREE.Mesh(ringGeometry, ringMaterial);
        ring.position.copy(mesh.position);
        ring.lookAt(this.camera.position);

        this.scene.add(ring);
        return ring;
    }

    /**
     * Update node positions from physics simulation
     * @param {number} lerpFactor - Smoothing factor (0-1)
     */
    updatePositions(lerpFactor = 0.1) {
        this.nodeMeshes.forEach(mesh => {
            const nodeData = mesh.userData.node;

            // Skip if position is locked (dragged)
            if (nodeData.position_locked) return;

            // Smooth lerp for visual stability
            mesh.position.x += (nodeData.x - mesh.position.x) * lerpFactor;
            mesh.position.z += (nodeData.y - mesh.position.z) * lerpFactor;
            mesh.quaternion.copy(this.camera.quaternion);

            // Sync label position
            if (mesh.userData.label) {
                mesh.userData.label.position.set(
                    mesh.position.x,
                    mesh.position.y + this.config.labelOffset,
                    mesh.position.z
                );
            }

            // Sync alert ring position
            if (mesh.userData.alertRing) {
                mesh.userData.alertRing.position.copy(mesh.position);
                // Keep the glow plane facing the camera
                mesh.userData.alertRing.quaternion.copy(this.camera.quaternion);
            }
        });
    }

    /**
     * Animate critical nodes (pulsing effect)
     * @param {number} time - Elapsed time from clock
     */
    animateCriticalNodes(time) {
        this.criticalNodes.forEach(mesh => {
            // Subtle pulse on alert ring to match UX glow
            if (mesh.userData.alertRing) {
                const ringPulse = 1 + Math.sin(time * 2.5) * 0.08;
                mesh.userData.alertRing.scale.set(ringPulse, ringPulse, ringPulse);
                mesh.userData.alertRing.material.opacity = 0.35 + Math.sin(time * 3.5) * 0.1;
            }
        });
    }

    /**
     * Dim all nodes except the selected one (isolation mode)
     * @param {THREE.Mesh} selectedMesh
     */
    dimExcept(selectedMesh) {
        this.nodeMeshes.forEach(mesh => {
            if (mesh !== selectedMesh) {
                mesh.material.opacity = 0.2;
                mesh.userData.dimmed = true;
            } else {
                mesh.material.opacity = 1.0;
                mesh.userData.dimmed = false;
            }
        });
    }

    /**
     * Restore all nodes to normal appearance
     */
    restoreAll() {
        this.nodeMeshes.forEach(mesh => {
            mesh.material.opacity = mesh.userData.baseOpacity || 1;
            mesh.userData.dimmed = false;
        });
    }

    /**
     * Highlight selected node
     * @param {string} selectedNodeId
     * @param {THREE.Mesh} hoveredNode
     */
    highlightSelected(selectedNodeId, hoveredNode) {
        this.nodeMeshes.forEach(mesh => {
            const isSelected = mesh.userData.id === selectedNodeId;
            const isHovered = mesh === hoveredNode;
            const baseScale = mesh.userData.baseScale;
            const scale = baseScale * (isSelected ? 1.18 : isHovered ? 1.08 : 1);
            mesh.scale.set(scale, scale, scale);
        });
    }

    /**
     * Set hover state on a node
     * @param {THREE.Mesh} mesh
     * @param {boolean} isHovered
     */
    setHoverState(mesh, isHovered) {
        if (!mesh || mesh.userData.node.critical) return;
        mesh.userData.isHovered = isHovered;
    }

    /**
     * Get node mesh by ID
     * @param {string} nodeId
     * @returns {THREE.Mesh|undefined}
     */
    getNodeById(nodeId) {
        return this.nodeMeshes.find(m => m.userData.id === nodeId);
    }

    /**
     * Get all node meshes
     * @returns {Array<THREE.Mesh>}
     */
    getMeshes() {
        return this.nodeMeshes;
    }

    /**
     * Get critical nodes
     * @returns {Array<THREE.Mesh>}
     */
    getCriticalNodes() {
        return this.criticalNodes;
    }

    /**
     * Clear existing nodes without disposing shared geometry
     */
    clearNodes() {
        // Dispose node meshes
        this.nodeMeshes.forEach(mesh => {
            mesh.material.dispose();
            this.scene.remove(mesh);
        });
        this.nodeMeshes = [];

        // Dispose labels
        this.nodeLabels.forEach(label => {
            label.material.dispose();
            this.scene.remove(label);
        });
        this.nodeLabels = [];

        // Dispose alert rings
        this.alertRings.forEach(ring => {
            ring.geometry.dispose();
            ring.material.dispose();
            this.scene.remove(ring);
        });
        this.alertRings = [];
        this.criticalNodes = [];
    }

    /**
     * Dispose all resources
     */
    dispose() {
        this.clearNodes();

        // Dispose geometries
        this.nodeGeometry.dispose();

        clearTextureCache();
    }
}
