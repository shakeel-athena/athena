/**
 * EdgeRenderer
 * Handles creation and management of network edge (link) visualizations
 * Includes normal connections and attack line animations
 */

import * as THREE from 'three';
import { EDGE_STYLE, UX_COLORS } from '../utils/constants';

/**
 * EdgeRenderer class for managing network edge visualizations
 */
export class EdgeRenderer {
    constructor(scene, config = {}) {
        this.scene = scene;
        this.config = {
            normalColor: EDGE_STYLE.color,
            normalOpacity: EDGE_STYLE.opacity,
            diamondColor: EDGE_STYLE.color,
            diamondOpacity: EDGE_STYLE.opacity,
            shadowColor: EDGE_STYLE.shadowColor,
            shadowOpacity: EDGE_STYLE.shadowOpacity,
            attackColor: UX_COLORS.node.critical.stroke,
            attackOpacity: 0.9,
            dashSize: EDGE_STYLE.dashSize,
            gapSize: EDGE_STYLE.gapSize,
            originThreshold: 10, // Lines with both ends within this radius of (0,0,0) are filtered
            ...config,
        };

        // Keyed by Edge ID for stable tracking across frames
        this.edgeLines = new Map();
        this.edgeShadows = new Map();
        this.attackLines = new Map();
        this.attackShadows = new Map();
        this.diamondLines = new Map(); // Separate storage for diamond edges
        this.diamondShadows = new Map();
        this.lineGeometries = new Map();

        // Shared materials for different edge types
        this.normalMaterial = new THREE.LineDashedMaterial({
            color: new THREE.Color(this.config.normalColor),
            transparent: true,
            opacity: this.config.normalOpacity,
            dashSize: this.config.dashSize,
            gapSize: this.config.gapSize,
        });

        this.diamondMaterial = new THREE.LineDashedMaterial({
            color: new THREE.Color(this.config.diamondColor),
            transparent: true,
            opacity: this.config.diamondOpacity,
            dashSize: this.config.dashSize,
            gapSize: this.config.gapSize,
        });

        this.shadowMaterial = new THREE.LineDashedMaterial({
            color: new THREE.Color(this.config.shadowColor),
            transparent: true,
            opacity: this.config.shadowOpacity,
            dashSize: this.config.dashSize,
            gapSize: this.config.gapSize,
        });

        this.attackMaterial = new THREE.LineDashedMaterial({
            color: new THREE.Color(this.config.attackColor),
            transparent: true,
            opacity: this.config.attackOpacity,
            dashSize: this.config.dashSize,
            gapSize: this.config.gapSize,
        });

        this.attackShadowMaterial = new THREE.LineDashedMaterial({
            color: new THREE.Color(this.config.shadowColor),
            transparent: true,
            opacity: this.config.shadowOpacity,
            dashSize: this.config.dashSize,
            gapSize: this.config.gapSize,
        });
    }

    /**
     * Normalize D3-mutated edge endpoints (object or id)
     * @param {string|Object} nodeRef
     * @returns {string|number|undefined}
     */
    resolveNodeId(nodeRef) {
        if (nodeRef && typeof nodeRef === 'object') {
            return nodeRef.id;
        }
        return nodeRef;
    }

    /**
     * Create all edges from topology data
     * @param {Array} edges - Array of edge data { id, source, target, suspicious?, severity? }
     * @param {Function} getNodePosition - Function to get node position by ID
     * @returns {Object} { edges: Array, attackLines: Array }
     */
    createEdges(edges, getNodePosition) {
        this.dispose();

        edges.forEach(edge => {
            const sourceId = this.resolveNodeId(edge.source);
            const targetId = this.resolveNodeId(edge.target);
            const edgeId = edge.id || `edge-${sourceId}-${targetId}`;
            const sourcePos = getNodePosition(sourceId);
            const targetPos = getNodePosition(targetId);

            // Default to origin if position missing (to avoid math errors)
            const s = sourcePos || { x: 0, y: 0, z: 0 };
            const t = targetPos || { x: 0, y: 0, z: 0 };

            const isSuspicious = edge.suspicious ||
                edge.severity === 'high' ||
                edge.severity === 'critical';

            // Check if this is a diamond edge
            const isDiamondEdge = edgeId.includes('diamond-') &&
                (edgeId.includes('edge') || edgeId.includes('cluster'));

            if (isSuspicious) {
                // Noise filter: Don't create lines if both endpoints are basically at the origin
                const distS = Math.sqrt(s.x ** 2 + s.y ** 2 + s.z ** 2);
                const distT = Math.sqrt(t.x ** 2 + t.y ** 2 + t.z ** 2);

                if (distS < this.config.originThreshold && distT < this.config.originThreshold) {
                    return;
                }

                const attackLine = this.createAttackLine(edgeId, s, t);
                this.attackLines.set(edgeId, attackLine);
            } else {
                const line = this.createNormalEdge(edgeId, s, t, isDiamondEdge);
            }
        });

        return {
            edges: [...Array.from(this.edgeLines.values()), ...Array.from(this.diamondLines.values())],
            attackLines: Array.from(this.attackLines.values()),
        };
    }

    /**
     * Create a normal edge between two points
     * @param {string} edgeId
     * @param {Object} source - { x, y, z }
     * @param {Object} target - { x, y, z }
     * @returns {THREE.Line}
     */
    createNormalEdge(edgeId, source, target, isDiamondEdge = false) {
        const points = [
            new THREE.Vector3(source.x, source.y, source.z),
            new THREE.Vector3(target.x, target.y, target.z),
        ];

        const geometry = new THREE.BufferGeometry().setFromPoints(points);
        this.lineGeometries.set(edgeId, geometry);

        const material = isDiamondEdge ? this.diamondMaterial : this.normalMaterial;
        const line = new THREE.Line(geometry, material);
        line.userData.id = edgeId;
        line.userData.isDiamondEdge = isDiamondEdge;

        const shadowLine = new THREE.Line(geometry, this.shadowMaterial);
        shadowLine.renderOrder = -1;

        // Required for LineDashedMaterial to work
        line.computeLineDistances();
        shadowLine.computeLineDistances();

        this.scene.add(shadowLine);
        this.scene.add(line);

        if (isDiamondEdge) {
            this.diamondLines.set(edgeId, line);
            this.diamondShadows.set(edgeId, shadowLine);
        } else {
            this.edgeLines.set(edgeId, line);
            this.edgeShadows.set(edgeId, shadowLine);
        }

        return line;
    }

    /**
     * Create an attack line with jagged effect
     * @param {string} edgeId
     * @param {Object} source - { x, y, z }
     * @param {Object} target - { x, y, z }
     * @returns {THREE.Line}
     */
    createAttackLine(edgeId, source, target) {
        const points = [
            new THREE.Vector3(source.x, source.y, source.z),
            new THREE.Vector3(target.x, target.y, target.z),
        ];
        const geometry = new THREE.BufferGeometry().setFromPoints(points);
        this.lineGeometries.set(edgeId, geometry);

        const line = new THREE.Line(geometry, this.attackMaterial);
        line.userData.isAttackLine = true;
        line.userData.id = edgeId;
        line.computeLineDistances();

        const shadowLine = new THREE.Line(geometry, this.attackShadowMaterial);
        shadowLine.renderOrder = -1;
        shadowLine.computeLineDistances();

        this.scene.add(shadowLine);
        this.scene.add(line);
        this.attackShadows.set(edgeId, shadowLine);

        return line;
    }

    /**
     * Update edge positions when nodes move
     * @param {Array} edges - Original edge data
     * @param {Function} getNodePosition - Function to get current node position by ID
     */
    updatePositions(edges, getNodePosition) {
        edges.forEach(edge => {
            const sourceId = this.resolveNodeId(edge.source);
            const targetId = this.resolveNodeId(edge.target);
            const edgeId = edge.id || `edge-${sourceId}-${targetId}`;
            const s = getNodePosition(sourceId) || { x: 0, y: 0, z: 0 };
            const t = getNodePosition(targetId) || { x: 0, y: 0, z: 0 };

            const isSuspicious = edge.suspicious ||
                edge.severity === 'high' ||
                edge.severity === 'critical';

            if (isSuspicious) {
                // Update attack line positions
                const line = this.attackLines.get(edgeId);
                if (line) {
                    const positions = line.geometry.attributes.position.array;
                    positions[0] = s.x;
                    positions[1] = s.y;
                    positions[2] = s.z;
                    positions[3] = t.x;
                    positions[4] = t.y;
                    positions[5] = t.z;
                    line.geometry.attributes.position.needsUpdate = true;
                }
            } else {
                // Update normal line or diamond edge
                const line = this.edgeLines.get(edgeId) || this.diamondLines.get(edgeId);
                if (line) {
                    const positions = line.geometry.attributes.position.array;
                    positions[0] = s.x;
                    positions[1] = s.y;
                    positions[2] = s.z;
                    positions[3] = t.x;
                    positions[4] = t.y;
                    positions[5] = t.z;
                    line.geometry.attributes.position.needsUpdate = true;
                }
            }
        });
    }

    /**
     * Animate attack lines (flicker effect)
     * @param {number} time - Elapsed time from clock
     */
    animateAttackLines(time) {
        this.attackLines.forEach(line => {
            line.material.opacity = 0.65 + Math.sin(time * 3) * 0.15;
            const shadow = this.attackShadows.get(line.userData.id);
            if (shadow) {
                shadow.material.opacity = this.config.shadowOpacity;
            }
        });
    }

    /**
     * Get all edge lines
     * @returns {Array<THREE.Line>}
     */
    getEdges() {
        return Array.from(this.edgeLines.values());
    }

    /**
     * Get all attack lines
     * @returns {Array<THREE.Line>}
     */
    getAttackLines() {
        return Array.from(this.attackLines.values());
    }

    /**
     * Dispose all resources
     */
    dispose() {
        // Dispose edge lines
        this.edgeLines.forEach(line => {
            this.scene.remove(line);
        });
        this.edgeLines.clear();

        this.edgeShadows.forEach(line => {
            this.scene.remove(line);
        });
        this.edgeShadows.clear();

        // Dispose diamond lines
        if (this.diamondLines) {
            this.diamondLines.forEach(line => {
                this.scene.remove(line);
            });
            this.diamondLines.clear();
        }

        if (this.diamondShadows) {
            this.diamondShadows.forEach(line => {
                this.scene.remove(line);
            });
            this.diamondShadows.clear();
        }

        // Dispose attack lines and their materials
        this.attackLines.forEach(line => {
            this.scene.remove(line);
        });
        this.attackLines.clear();

        this.attackShadows.forEach(line => {
            this.scene.remove(line);
        });
        this.attackShadows.clear();

        // Dispose geometries
        this.lineGeometries.forEach(geometry => {
            geometry.dispose();
        });
        this.lineGeometries.clear();

        // Dispose materials
        if (this.normalMaterial) {
            this.normalMaterial.dispose();
        }
        if (this.diamondMaterial) {
            this.diamondMaterial.dispose();
        }
        if (this.shadowMaterial) {
            this.shadowMaterial.dispose();
        }
        if (this.attackMaterial) {
            this.attackMaterial.dispose();
        }
        if (this.attackShadowMaterial) {
            this.attackShadowMaterial.dispose();
        }
    }
}
