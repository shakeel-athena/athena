/**
 * TextureCache
 * Manages canvas texture creation and caching for node icons
 * Prevents re-creating textures on every render for performance
 */

import * as THREE from 'three';
import { UX_COLORS } from './constants';

// Cache for generated textures: key is `${iconKey}-${colorHex}-${isCritical}`
const textureCache = new Map();

function toHexColor(value) {
    if (typeof value === 'string') return value;
    if (typeof value === 'number') return `#${value.toString(16).padStart(6, '0')}`;
    return UX_COLORS.node.normal.fill;
}

function drawRoundedRect(ctx, x, y, width, height, radius) {
    const r = Math.min(radius, width / 2, height / 2);
    ctx.beginPath();
    ctx.moveTo(x + r, y);
    ctx.arcTo(x + width, y, x + width, y + height, r);
    ctx.arcTo(x + width, y + height, x, y + height, r);
    ctx.arcTo(x, y + height, x, y, r);
    ctx.arcTo(x, y, x + width, y, r);
    ctx.closePath();
}

function drawServerIcon(ctx, centerX, centerY, size) {
    const width = size;
    const height = size * 0.55;
    const left = centerX - width / 2;
    const top = centerY - height * 0.6;
    const corner = width * 0.08;

    drawRoundedRect(ctx, left, top, width, height, corner);
    ctx.fill();

    const baseWidth = width * 0.8;
    const baseHeight = height * 0.18;
    const baseLeft = centerX - baseWidth / 2;
    const baseTop = top + height + baseHeight * 0.6;
    drawRoundedRect(ctx, baseLeft, baseTop, baseWidth, baseHeight, baseHeight / 2);
    ctx.fill();

    const legWidth = width * 0.14;
    const legHeight = height * 0.28;
    const legTop = top + height + baseHeight * 0.05;
    drawRoundedRect(ctx, centerX - legWidth * 1.35, legTop, legWidth, legHeight, legWidth * 0.2);
    ctx.fill();
    drawRoundedRect(ctx, centerX + legWidth * 0.35, legTop, legWidth, legHeight, legWidth * 0.2);
    ctx.fill();

    const lightWidth = width * 0.16;
    const lightHeight = height * 0.2;
    const lightTop = top + height * 0.5;
    const gap = width * 0.18;
    [-1, 0, 1].forEach((i) => {
        const x = centerX + i * gap - lightWidth / 2;
        drawRoundedRect(ctx, x, lightTop, lightWidth, lightHeight, lightHeight / 2);
        ctx.fill();
    });
}

/**
 * Create a canvas texture matching the UX artifacts (flat circle + server icon)
 * @param {string} iconKey - Currently only 'server' is supported
 * @param {Object|number|string} style - Style object or legacy base color
 * @param {boolean} isCritical - Legacy flag (ignored for UX style)
 * @returns {THREE.CanvasTexture}
 */
export function createNodeTexture(iconKey, style, isCritical = false) {
    const legacyBaseColor = typeof style === 'number' || typeof style === 'string';
    const resolvedStyle = legacyBaseColor ? {
        fill: toHexColor(style),
        stroke: toHexColor(style),
        opacity: isCritical ? 1 : 0.6,
        iconColor: UX_COLORS.icon,
        shadowColor: 'rgba(0, 0, 0, 0.35)',
    } : {
        fill: style.fill || UX_COLORS.node.normal.fill,
        stroke: style.stroke || UX_COLORS.node.normal.stroke,
        opacity: typeof style.opacity === 'number' ? style.opacity : UX_COLORS.node.normal.opacity,
        iconColor: style.iconColor || UX_COLORS.icon,
        shadowColor: style.shadowColor || 'rgba(0, 0, 0, 0.35)',
    };

    // Check cache first
    const cacheKey = [
        iconKey,
        resolvedStyle.fill,
        resolvedStyle.stroke,
        resolvedStyle.opacity,
        resolvedStyle.iconColor,
    ].join('-');
    if (textureCache.has(cacheKey)) {
        return textureCache.get(cacheKey);
    }

    const canvas = document.createElement('canvas');
    const size = 128;
    canvas.width = size;
    canvas.height = size;
    const ctx = canvas.getContext('2d');

    // Convert hex color to RGB
    const center = size / 2;
    const radius = size * 0.32;

    // Soft shadow
    const shadowAlpha = Math.min(0.3, resolvedStyle.opacity * 0.4);
    ctx.save();
    ctx.shadowColor = resolvedStyle.shadowColor;
    ctx.shadowBlur = size * 0.08;
    ctx.fillStyle = resolvedStyle.fill;
    ctx.globalAlpha = shadowAlpha;
    ctx.beginPath();
    ctx.arc(center, center, radius, 0, Math.PI * 2);
    ctx.fill();
    ctx.restore();

    // Fill + stroke
    ctx.save();
    ctx.globalAlpha = resolvedStyle.opacity;
    ctx.fillStyle = resolvedStyle.fill;
    ctx.beginPath();
    ctx.arc(center, center, radius, 0, Math.PI * 2);
    ctx.fill();
    ctx.restore();

    ctx.strokeStyle = resolvedStyle.stroke;
    ctx.lineWidth = Math.max(2, size * 0.02);
    ctx.beginPath();
    ctx.arc(center, center, radius, 0, Math.PI * 2);
    ctx.stroke();

    // Draw the server icon
    ctx.fillStyle = resolvedStyle.iconColor;
    drawServerIcon(ctx, center, center, radius * 1.2);

    const texture = new THREE.CanvasTexture(canvas);
    texture.needsUpdate = true;

    // Store in cache
    textureCache.set(cacheKey, texture);

    return texture;
}

/**
 * Clear all cached textures (call on cleanup)
 */
export function clearTextureCache() {
    textureCache.forEach((texture) => {
        texture.dispose();
    });
    textureCache.clear();
}

/**
 * Get the current cache size (for debugging)
 * @returns {number}
 */
export function getTextureCacheSize() {
    return textureCache.size;
}

/**
 * TextureCache class for managing texture lifecycle
 * Alternative OOP interface if preferred
 */
export class TextureManager {
    constructor() {
        this.cache = new Map();
    }

    get(iconKey, baseColor, isCritical = false) {
        const style = typeof baseColor === 'object'
            ? baseColor
            : { fill: baseColor, stroke: baseColor, opacity: isCritical ? 1 : 0.6 };
        const cacheKey = `${iconKey}-${style.fill}-${style.stroke}-${style.opacity}`;
        if (this.cache.has(cacheKey)) {
            return this.cache.get(cacheKey);
        }

        const texture = createNodeTexture(iconKey, baseColor, isCritical);
        this.cache.set(cacheKey, texture);
        return texture;
    }

    dispose() {
        this.cache.forEach((texture) => {
            texture.dispose();
        });
        this.cache.clear();
    }

    get size() {
        return this.cache.size;
    }
}
