/**
 * NodeStyleResolver
 * Utility functions for determining node appearance based on OS, role, and network segment
 */

import { OS_COLORS, OS_ICON_KEYS, NETWORK_SEGMENTS, UX_COLORS } from './constants';

/**
 * Determine the OS/role key for a node based on its properties
 */
export function getNodeOSKey(node) {
    const os = (node.os || node.platform || '').toLowerCase();
    const name = (node.label || node.name || node.id || '').toLowerCase();

    // Check OS first (most reliable)
    if (os.includes('linux') || os.includes('ubuntu') || os.includes('centos') || os.includes('debian') || os.includes('rhel')) return 'linux';
    if (os.includes('windows') || os.includes('win')) return 'windows';
    if (os.includes('mac') || os.includes('darwin') || os.includes('macos')) return 'macos';

    // Check name patterns (fallback)
    if (name.includes('linux') || name.includes('ubuntu') || name.includes('centos')) return 'linux';
    if (name.includes('windows') || name.includes('win') || name.includes('wks')) return 'windows';
    if (name.includes('mac') || name.includes('darwin') || name.includes('mbp')) return 'macos';
    if (name.includes('firewall') || name.includes('fw') || name.includes('pfsense')) return 'firewall';
    if (name.includes('router') || name.includes('cisco') || name.includes('juniper')) return 'router';
    if (name.includes('db') || name.includes('database') || name.includes('mysql') || name.includes('postgres')) return 'database';
    if (name.includes('web') || name.includes('nginx') || name.includes('apache')) return 'web';
    if (name.includes('server') || name.includes('srv')) return 'server';
    if (name.includes('siem') || name.includes('wazuh') || name.includes('splunk')) return 'siem';

    // Fallback to role if available
    if (node.role && OS_ICON_KEYS[node.role]) return OS_ICON_KEYS[node.role];

    return 'endpoint';
}

/**
 * Get the hex color for a node based on its OS/role
 */
export function getNodeColor(node) {
    return getNodeVisualStyle(node).fill;
}

/**
 * Get the icon key for a node
 */
export function getNodeIconKey(node) {
    return 'server';
}

/**
 * Detect the network segment a node belongs to
 * TRULY DYNAMIC: Prioritizes literal zone/subnet from API data
 */
export function getNodeSegment(node) {
    // 1. Prioritize explicit zone/segment from API or grouping
    if (node.zone) return node.zone;
    if (node.segment) return node.segment;

    // 2. Fallback to subnet if available
    if (node.subnet) return node.subnet;

    // 3. Heuristic discovery for legacy data
    const ip = node.ip || '';
    if (ip.startsWith('10.0.0.') || ip.startsWith('10.0.5.') || ip.startsWith('10.0.1.')) return 'DMZ';
    if (ip.startsWith('192.168.1.') || ip.startsWith('10.1.') || ip.startsWith('192.168.0.')) return 'Internal Network';
    if (ip.startsWith('192.168.100.') || ip.startsWith('10.100.')) return 'Management';
    if (ip.startsWith('172.') || (!ip.startsWith('192.168.') && !ip.startsWith('10.') && ip !== '0.0.0.0')) return 'External';

    return 'Default Network';
}

/**
 * Helper to generate a deterministic color from a string
 */
function stringToColor(str) {
    let hash = 0;
    for (let i = 0; i < str.length; i++) {
        hash = str.charCodeAt(i) + ((hash << 5) - hash);
    }
    const c = (hash & 0x00FFFFFF).toString(16).toUpperCase();
    return '#' + '00000'.substring(0, 6 - c.length) + c;
}

/**
 * Get the segment configuration object
 * Generates dynamic config for unknown segments
 */
export function getNodeSegmentConfig(node) {
    const segmentLabel = getNodeSegment(node);
    const lowerLabel = segmentLabel.toLowerCase();

    // Check if we have a pre-defined theme for this label in constants
    for (const [key, config] of Object.entries(NETWORK_SEGMENTS)) {
        if (lowerLabel.includes(key.toLowerCase()) || config.label.toLowerCase() === lowerLabel) {
            return {
                ...config,
                label: config.label // Ensure we use the proper label
            };
        }
    }

    // Generate a dynamic configuration for unknown segments
    const baseColor = stringToColor(segmentLabel);
    return {
        label: segmentLabel,
        color: baseColor,
        bgColor: `${baseColor}22`, // Slightly more visible background
        borderColor: `${baseColor}66`, // ~40% opacity
        yOffset: 0
    };
}

/**
 * Determine if a node is critical
 */
export function isNodeCritical(node) {
    return node.critical || (node.riskScore && node.riskScore > 70);
}

/**
 * Determine if a node is a cluster
 */
export function isNodeCluster(node) {
    return node.type === 'cluster' || node.role === 'cluster';
}

/**
 * Determine if a node is a diamond
 */
export function isNodeDiamond(node) {
    return node.shape === 'diamond' || node.type === 'segment-diamond';
}

/**
 * Get UX-driven visual style for a node
 */
export function getNodeVisualStyle(node) {
    const riskScore = node.riskScore || 0;
    const alertCount = node.alertCount || 0;

    if (riskScore >= 90 || alertCount >= 10) {
        return UX_COLORS.node.severe;
    }

    if (node.critical || riskScore >= 70) {
        return UX_COLORS.node.critical;
    }

    if (isNodeCluster(node) || isNodeDiamond(node) || riskScore >= 50 || alertCount > 0) {
        return UX_COLORS.node.warning;
    }

    return UX_COLORS.node.normal;
}

/**
 * Get the scale factor for a node
 */
export function getNodeScale(node, config = { criticalScale: 1.4, clusterScale: 1.8, diamondScale: 1.5 }) {
    if (isNodeDiamond(node)) return config.diamondScale;
    if (isNodeCluster(node)) return config.clusterScale;
    if (isNodeCritical(node)) return config.criticalScale;
    return 1.0;
}
