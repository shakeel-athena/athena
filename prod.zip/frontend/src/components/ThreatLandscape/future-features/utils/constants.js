/**
 * NetworkTopology3D Constants
 * Centralized configuration for network visualization styling
 */
import { BRAND_COLORS, SEVERITY_COLORS } from '../../../../theme/colors';

// ============================================================================
// NETWORK SEGMENT CONFIGURATION
// Visual zones for different network areas (DMZ, Internal, etc.)
// ============================================================================
export const NETWORK_SEGMENTS = {
    dmz: {
        color: '#FF6B6B',
        bgColor: 'rgba(255, 107, 107, 0.08)',
        borderColor: 'rgba(255, 107, 107, 0.4)',
        label: 'DMZ',
        yOffset: 0,
    },
    internal: {
        color: '#4ECDC4',
        bgColor: 'rgba(78, 205, 196, 0.08)',
        borderColor: 'rgba(78, 205, 196, 0.4)',
        label: 'Internal Network',
        yOffset: 0,
    },
    management: {
        color: '#FFE66D',
        bgColor: 'rgba(255, 230, 109, 0.08)',
        borderColor: 'rgba(255, 230, 109, 0.4)',
        label: 'Management',
        yOffset: 0,
    },
    external: {
        color: '#95E1D3',
        bgColor: 'rgba(149, 225, 211, 0.08)',
        borderColor: 'rgba(149, 225, 211, 0.4)',
        label: 'External',
        yOffset: 0,
    },
    default: {
        color: '#A8DADC',
        bgColor: 'rgba(168, 218, 220, 0.06)',
        borderColor: 'rgba(168, 218, 220, 0.3)',
        label: 'Network',
        yOffset: 0,
    },
};

// ============================================================================
// OS-BASED COLOR MAPPING
// Softer, more readable colors for different operating systems and device types
// ============================================================================
export const OS_COLORS = {
    linux: 0x4ADE80,      // Neon Green
    windows: 0x60A5FA,    // Neon Blue
    macos: 0xC084FC,      // Neon Purple
    darwin: 0xC084FC,     // Alias for macOS
    network: 0xFB923C,    // Neon Orange
    iot: 0xFBBF24,        // Neon Yellow
    firewall: 0xF87171,   // Neon Red
    router: 0x818CF8,     // Neon Indigo
    database: 0x2DD4BF,   // Neon Teal
    server: 0x94A3B8,     // Steel Gray
    unknown: 0x94A3B8,    // Default gray
};

// ============================================================================
// OS ICON SVG PATHS
// Material Design-style icons for clean rendering on node textures
// ============================================================================
export const OS_ICON_PATHS = {
    linux: 'M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-1 17.93c-3.95-.49-7-3.85-7-7.93 0-.62.08-1.21.21-1.79L9 15v1c0 1.1.9 2 2 2v1.93zm6.9-2.54c-.26-.81-1-1.39-1.9-1.39h-1v-3c0-.55-.45-1-1-1H8v-2h2c.55 0 1-.45 1-1V7h2c1.1 0 2-.9 2-2v-.41c2.93 1.19 5 4.06 5 7.41 0 2.08-.8 3.97-2.1 5.39z',
    windows: 'M3 5.5l7.5-1v7H3v-6zm0 7h7.5v7L3 18.5v-6zm8.5-8.12L21 3v8.5h-9.5v-7.12zm0 8.12H21V21l-9.5-1.38v-7.12z',
    macos: 'M18.71 19.5c-.83 1.24-1.71 2.45-3.05 2.47-1.34.03-1.77-.79-3.29-.79-1.53 0-2 .77-3.27.82-1.31.05-2.3-1.32-3.14-2.53C4.25 17 2.94 12.45 4.7 9.39c.87-1.52 2.43-2.48 4.12-2.51 1.28-.02 2.5.87 3.29.87.78 0 2.26-1.07 3.81-.91.65.03 2.47.26 3.64 1.98-.09.06-2.17 1.28-2.15 3.81.03 3.02 2.65 4.03 2.68 4.04-.03.07-.42 1.44-1.38 2.83M13 3.5c.73-.83 1.94-1.46 2.94-1.5.13 1.17-.34 2.35-1.04 3.19-.69.85-1.83 1.51-2.95 1.42-.15-1.15.41-2.35 1.05-3.11z',
    firewall: 'M12 1L3 5v6c0 5.55 3.84 10.74 9 12 5.16-1.26 9-6.45 9-12V5l-9-4zm0 10.99h7c-.53 4.12-3.28 7.79-7 8.94V12H5V6.3l7-3.11v8.8z',
    router: 'M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-1 17.93c-3.95-.49-7-3.85-7-7.93 0-.62.08-1.21.21-1.79L9 15v1c0 1.1.9 2 2 2v1.93zm6.9-2.54c-.26-.81-1-1.39-1.9-1.39h-1v-3c0-.55-.45-1-1-1H8v-2h2c.55 0 1-.45 1-1V7h2c1.1 0 2-.9 2-2v-.41c2.93 1.19 5 4.06 5 7.41 0 2.08-.8 3.97-2.1 5.39z',
    database: 'M12 3C7.58 3 4 4.79 4 7v10c0 2.21 3.58 4 8 4s8-1.79 8-4V7c0-2.21-3.58-4-8-4zm0 2c3.87 0 6 1.5 6 2s-2.13 2-6 2-6-1.5-6-2 2.13-2 6-2zm6 12c0 .5-2.13 2-6 2s-6-1.5-6-2v-2.23c1.61.78 3.72 1.23 6 1.23s4.39-.45 6-1.23V17zm0-5c0 .5-2.13 2-6 2s-6-1.5-6-2V9.77c1.61.78 3.72 1.23 6 1.23s4.39-.45 6-1.23V12z',
    server: 'M4 1h16c1.1 0 2 .9 2 2v4c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V3c0-1.1.9-2 2-2zm0 8h16c1.1 0 2 .9 2 2v4c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2v-4c0-1.1.9-2 2-2zm0 8h16c1.1 0 2 .9 2 2v4c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2v-4c0-1.1.9-2 2-2zm2-12v2h2V5H6zm0 8v2h2v-2H6zm0 8v2h2v-2H6z',
    iot: 'M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm0 18c-4.42 0-8-3.58-8-8s3.58-8 8-8 8 3.58 8 8-3.58 8-8 8zm-5-9h2v2H7v-2zm4 0h2v2h-2v-2zm4 0h2v2h-2v-2z',
    endpoint: 'M21 2H3c-1.1 0-2 .9-2 2v12c0 1.1.9 2 2 2h7v2H8v2h8v-2h-2v-2h7c1.1 0 2-.9 2-2V4c0-1.1-.9-2-2-2zm0 14H3V4h18v12z',
    web: 'M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-1 17.93c-3.95-.49-7-3.85-7-7.93 0-.62.08-1.21.21-1.79L9 15v1c0 1.1.9 2 2 2v1.93zm6.9-2.54c-.26-.81-1-1.39-1.9-1.39h-1v-3c0-.55-.45-1-1-1H8v-2h2c.55 0 1-.45 1-1V7h2c1.1 0 2-.9 2-2v-.41c2.93 1.19 5 4.06 5 7.41 0 2.08-.8 3.97-2.1 5.39z',
    siem: 'M12 4.5C7 4.5 2.73 7.61 1 12c1.73 4.39 6 7.5 11 7.5s9.27-3.11 11-7.5c-1.73-4.39-6-7.5-11-7.5zM12 17c-2.76 0-5-2.24-5-5s2.24-5 5-5 5 2.24 5 5-2.24 5-5 5zm0-8c-1.66 0-3 1.34-3 3s1.34 3 3 3 3-1.34 3-3-1.34-3-3-3z',
    cluster: 'M12 2l-5.5 9h11L12 2zm0 3.84L13.93 9h-3.87L12 5.84zM17.5 13c-2.49 0-4.5 2.01-4.5 4.5s2.01 4.5 4.5 4.5 4.5-2.01 4.5-4.5-2.01-4.5-4.5-4.5zm0 7c-1.38 0-2.5-1.12-2.5-2.5s1.12-2.5 2.5-2.5 2.5 1.12 2.5 2.5-1.12 2.5-2.5 2.5zM3 21.5h8v-8H3v8zm2-6h4v4H5v-4z',
    unknown: 'M21 2H3c-1.1 0-2 .9-2 2v12c0 1.1.9 2 2 2h7v2H8v2h8v-2h-2v-2h7c1.1 0 2-.9 2-2V4c0-1.1-.9-2-2-2zm0 14H3V4h18v12z',
};

// ============================================================================
// OS ICON KEY MAPPING
// Maps OS/role identifiers to icon keys
// ============================================================================
export const OS_ICON_KEYS = {
    linux: 'linux',
    windows: 'windows',
    macos: 'macos',
    darwin: 'macos',
    network: 'router',
    iot: 'iot',
    firewall: 'firewall',
    router: 'router',
    database: 'database',
    web: 'web',
    siem: 'siem',
    server: 'server',
    endpoint: 'endpoint',
    external: 'web',
    cluster: 'cluster',
    unknown: 'endpoint',
};

// ============================================================================
// UX VISUAL STYLE TOKENS (from ux-artifacts)
// ============================================================================
export const UX_COLORS = {
    background: '#151519',
    edge: BRAND_COLORS.primary,
    edgeShadow: 'rgba(0, 0, 0, 0.2)',
    icon: '#CAD3E2',
    node: {
        normal: { fill: BRAND_COLORS.success, stroke: BRAND_COLORS.success, opacity: 0.6 },
        warning: { fill: SEVERITY_COLORS.high, stroke: SEVERITY_COLORS.medium, opacity: 0.6 },
        critical: { fill: '#C61E25', stroke: SEVERITY_COLORS.critical, opacity: 0.6 },
        severe: { fill: '#780000', stroke: '#F69104', opacity: 1 },
    },
};

export const EDGE_STYLE = {
    color: BRAND_COLORS.primary,
    opacity: 0.9,
    shadowColor: '#000000',
    shadowOpacity: 0.2,
    dashSize: 1,
    gapSize: 1,
};

// ============================================================================
// SCENE CONFIGURATION
// Default settings for Three.js scene
// ============================================================================
export const SCENE_CONFIG = {
    background: 0x151519, // UX artifact base background
    fogDensity: 0,
    starCount: 0,
    gridSize: 400,
    gridDivisions: 40,
    gridColor1: 0x1F2937,
    gridColor2: 0x0B0C10,
    gridYPosition: -30,
};

// ============================================================================
// CAMERA CONFIGURATION
// Default camera settings
// ============================================================================
export const CAMERA_CONFIG = {
    fov: 60,
    near: 0.1,
    far: 3000,
    initialPosition: { x: 0, y: 280, z: 0 }, // Higher top-down view
    minDistance: 30,
    maxDistance: 800,
    maxPolarAngle: Math.PI * 0.85,
    autoRotateSpeed: 0,
    dampingFactor: 0.08,
};

// ============================================================================
// NODE CONFIGURATION
// Default node rendering settings
// ============================================================================
export const NODE_CONFIG = {
    baseRadius: 3,
    segments: 24,
    criticalScale: 1.4,
    clusterScale: 1.8,
    diamondScale: 1.5,
    roughness: 0.4,
    metalness: 0.3,
    emissiveIntensityCritical: 0.6,
    emissiveIntensityNormal: 0.2,
    labelOffset: -6,
    labelMaxLength: 18,
};

// ============================================================================
// PHYSICS CONFIGURATION
// D3 force simulation settings
// ============================================================================
export const PHYSICS_CONFIG = {
    alphaDecay: 0.02,
    velocityDecay: 0.3,
    chargeStrength: -200, // Reduced repulsion force
    chargeDistanceMax: 300, // Reduced max distance for charge
    collideRadiusNormal: 8, // Reduced collision radius
    collideRadiusCluster: 15, // Reduced cluster collision radius
    collideIterations: 2,
    linkDistance: 60, // Shorter link distance
    centerStrength: 0.1, // Stronger centering force
};
