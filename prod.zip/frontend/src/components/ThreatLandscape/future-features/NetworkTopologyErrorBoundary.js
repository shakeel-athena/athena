import React from 'react';

/**
 * Specialized error boundary for NetworkTopology3D component
 * Specifically designed to handle and suppress ResizeObserver errors
 */
class NetworkTopologyErrorBoundary extends React.Component {
  constructor(props) {
    super(props);
    this.state = { hasError: false, error: null };
    this.retryTimeout = null;
  }

  static getDerivedStateFromError(error) {
    // Check if it's a ResizeObserver error
    const isResizeObserverError = error?.message?.includes('ResizeObserver loop completed with undelivered notifications');
    
    if (isResizeObserverError) {
      // Don't show error state for ResizeObserver errors
      return { hasError: false, error: null };
    }
    
    return { hasError: true, error };
  }

  componentDidCatch(error, errorInfo) {
    // Check if it's a ResizeObserver error
    const isResizeObserverError = error?.message?.includes('ResizeObserver loop completed with undelivered notifications');
    
    if (isResizeObserverError) {
      // Silently handle ResizeObserver errors and auto-recover
      console.log('🔧 ResizeObserver loop detected - auto-recovering...');
      
      // Clear any existing timeout
      if (this.retryTimeout) {
        clearTimeout(this.retryTimeout);
      }
      
      // Auto-recover after a short delay
      this.retryTimeout = setTimeout(() => {
        this.setState({ hasError: false, error: null });
      }, 100);
      
      return;
    }
    
    // Log other errors normally
    console.error('NetworkTopology3D Error:', error, errorInfo);
  }

  componentWillUnmount() {
    if (this.retryTimeout) {
      clearTimeout(this.retryTimeout);
    }
  }

  render() {
    if (this.state.hasError) {
      return (
        <div style={{
          display: 'flex',
          flexDirection: 'column',
          alignItems: 'center',
          justifyContent: 'center',
          height: '100%',
          background: '#030712',
          color: '#F1F5F9',
          padding: '20px',
          textAlign: 'center'
        }}>
          <h3>3D Visualization Error</h3>
          <p>The 3D network topology encountered an error.</p>
          <button
            onClick={() => this.setState({ hasError: false, error: null })}
            style={{
              padding: '10px 20px',
              background: '#3B82F6',
              color: 'white',
              border: 'none',
              borderRadius: '4px',
              cursor: 'pointer',
              marginTop: '10px'
            }}
          >
            Reload 3D View
          </button>
          {process.env.NODE_ENV === 'development' && (
            <details style={{ marginTop: '20px', textAlign: 'left' }}>
              <summary style={{ cursor: 'pointer', color: '#64748B' }}>
                Error Details
              </summary>
              <pre style={{
                background: '#1E293B',
                padding: '10px',
                borderRadius: '4px',
                marginTop: '10px',
                fontSize: '12px',
                color: '#EF4444',
                overflow: 'auto'
              }}>
                {this.state.error?.toString()}
              </pre>
            </details>
          )}
        </div>
      );
    }

    return this.props.children;
  }
}

export default NetworkTopologyErrorBoundary;