/**
 * Legend
 * Legend component showing OS types and network segments based on active data
 */

import React, { useMemo } from 'react';
import { OS_COLORS, NETWORK_SEGMENTS, UX_COLORS } from '../utils/constants';
import { getNodeOSKey, getNodeSegment, getNodeSegmentConfig } from '../utils/NodeStyleResolver';

/**
 * Standard labels for OS keys
 */
const OS_LABELS = {
    linux: 'Linux',
    windows: 'Windows',
    macos: 'macOS',
    firewall: 'Firewall',
    router: 'Router/Gateway',
    database: 'Database',
    web: 'Web Server',
    server: 'General Server',
    siem: 'SIEM/Manager',
    iot: 'IoT Device',
    endpoint: 'Workstation',
    unknown: 'Unknown'
};

/**
 * Legend component
 * @param {Object} props
 * @param {Array} props.nodes - Active nodes in the topology
 * @param {Function} props.onSelectSubnet - Callback when subnet is selected
 */
export function Legend({ nodes = [], onSelectSegment, onSelectSubnet }) {
    // ... same useMemo block ...
    // Dynamically calculate active OS types and Segments from nodes
    const { activeOSItems, activeSegments, activeSubnets } = useMemo(() => {
        const foundOSKeys = new Set();
        const foundSegmentKeys = new Set();
        const foundSubnetKeys = new Set();

        const filteredNodes = nodes.filter(node => {
            if (node.type === 'cluster' || node.shape === 'diamond' || node.type === 'segment-diamond') {
                return false;
            }

            if (typeof node.isActive === 'boolean') {
                return node.isActive;
            }

            return (node.alertCount || 0) > 0;
        });

        filteredNodes.forEach(node => {
            foundOSKeys.add(getNodeOSKey(node));
            foundSegmentKeys.add(getNodeSegment(node));
            if (node.subnet) {
                foundSubnetKeys.add(node.subnet);
            }
        });

        // Map keys to display objects
        const osItems = Array.from(foundOSKeys)
            .sort()
            .map(key => ({
                key,
                label: OS_LABELS[key] || key.charAt(0).toUpperCase() + key.slice(1),
                color: `#${(OS_COLORS[key] || OS_COLORS.unknown).toString(16).padStart(6, '0')}`
            }));

        const segmentItems = Array.from(foundSegmentKeys)
            .sort()
            .map(key => {
                const segmentNodes = filteredNodes.filter(n => getNodeSegment(n) === key);
                const config = getNodeSegmentConfig(segmentNodes[0] || { zone: key });
                return {
                    key,
                    count: segmentNodes.length,
                    ...config
                };
            });

        const subnetItems = Array.from(foundSubnetKeys)
            .sort()
            .map(key => {
                const subnetNodes = filteredNodes.filter(n => n.subnet === key);
                const config = getNodeSegmentConfig(subnetNodes[0] || { subnet: key, zone: key, segment: key });
                return {
                    key,
                    count: subnetNodes.length,
                    ...config
                };
            });

        return { activeOSItems: osItems, activeSegments: segmentItems, activeSubnets: subnetItems };
    }, [nodes]);

    if (!nodes || nodes.length === 0) return null;

    const showSegments = activeSegments.length > 0;
    const showSubnets = activeSubnets.length > 0 && !(
        showSegments &&
        activeSegments.length === activeSubnets.length &&
        activeSegments.every(segment => activeSubnets.some(subnet => subnet.key === segment.key))
    );

    return (
        <div style={{
            position: 'absolute',
            bottom: '20px',
            left: '20px',
            background: '#22232A',
            border: '1px solid #343741',
            borderRadius: '10px',
            padding: '14px 18px',
            color: UX_COLORS.icon,
            fontSize: '11px',
            backdropFilter: 'blur(10px)',
            maxWidth: '280px',
            zIndex: 100
        }}>
            {/* OS Types Section */}
            {activeOSItems.length > 0 && (
                <>
                    <div style={{
                        fontWeight: 'bold',
                        marginBottom: '10px',
                        color: UX_COLORS.edge,
                        fontSize: '12px'
                    }}>
                        Infrastructure Types
                    </div>
                    <div style={{
                        display: 'grid',
                        gridTemplateColumns: '1fr 1fr',
                        gap: '6px',
                        marginBottom: showSubnets || showSegments ? '14px' : '0'
                    }}>
                        {activeOSItems.map(item => (
                            <div
                                key={item.key}
                                style={{
                                    display: 'flex',
                                    alignItems: 'center',
                                    gap: '6px'
                                }}
                            >
                                <div style={{
                                    width: '12px',
                                    height: '12px',
                                    borderRadius: '50%',
                                    background: item.color
                                }} />
                                <span>{item.label}</span>
                            </div>
                        ))}
                    </div>
                </>
            )}

            {/* Subnets Section */}
            {showSubnets && (
                <div style={{
                    borderTop: activeOSItems.length > 0 ? '1px solid #343741' : 'none',
                    paddingTop: activeOSItems.length > 0 ? '12px' : '0',
                    marginTop: activeOSItems.length > 0 ? '4px' : '0',
                    marginBottom: showSegments ? '10px' : '0',
                }}>
                    <div style={{
                        fontWeight: 'bold',
                        marginBottom: '10px',
                        color: UX_COLORS.edge,
                        fontSize: '12px'
                    }}>
                        Subnets
                    </div>
                    <div style={{ display: 'grid', gap: '4px' }}>
                        {activeSubnets.map(item => (
                            <div
                                key={item.key}
                                onClick={() => onSelectSubnet && onSelectSubnet(item.key)}
                                style={{
                                    display: 'flex',
                                    alignItems: 'center',
                                    gap: '8px',
                                    padding: '4px 6px',
                                    borderRadius: '4px',
                                    cursor: 'pointer',
                                    transition: 'all 0.2s',
                                    userSelect: 'none'
                                }}
                                onMouseEnter={(e) => {
                                    e.currentTarget.style.background = 'rgba(255, 255, 255, 0.05)';
                                    e.currentTarget.style.transform = 'translateX(2px)';
                                }}
                                onMouseLeave={(e) => {
                                    e.currentTarget.style.background = 'transparent';
                                    e.currentTarget.style.transform = 'translateX(0)';
                                }}
                            >
                                <div style={{
                                    width: '18px',
                                    height: '8px',
                                    borderRadius: '2px',
                                    background: item.bgColor?.replace('0.08', '0.6') || item.color,
                                    border: `1px solid ${item.color}`,
                                }} />
                                <span style={{ fontSize: '11px', color: UX_COLORS.icon }}>{item.label || item.key}</span>
                                <span style={{ color: '#8E9FBC', marginLeft: 'auto', fontSize: '10px' }}>({item.count})</span>
                            </div>
                        ))}
                    </div>
                </div>
            )}

            {/* Network Segments Section */}
            {showSegments && (
                <div style={{
                    borderTop: activeOSItems.length > 0 || showSubnets ? '1px solid #343741' : 'none',
                    paddingTop: activeOSItems.length > 0 || showSubnets ? '12px' : '0',
                    marginTop: '4px',
                }}>
                    <div style={{
                        fontWeight: 'bold',
                        marginBottom: '10px',
                        color: UX_COLORS.edge,
                        fontSize: '12px'
                    }}>
                        Network Segments
                    </div>
                    <div style={{ display: 'grid', gap: '4px' }}>
                        {activeSegments.map(item => (
                            <div
                                key={item.key}
                                onClick={() => onSelectSegment && onSelectSegment(item.key)}
                                style={{
                                    display: 'flex',
                                    alignItems: 'center',
                                    gap: '8px',
                                    padding: '4px 6px',
                                    borderRadius: '4px',
                                    cursor: 'pointer',
                                    transition: 'all 0.2s',
                                    userSelect: 'none'
                                }}
                                onMouseEnter={(e) => {
                                    e.currentTarget.style.background = 'rgba(255, 255, 255, 0.05)';
                                    e.currentTarget.style.transform = 'translateX(2px)';
                                }}
                                onMouseLeave={(e) => {
                                    e.currentTarget.style.background = 'transparent';
                                    e.currentTarget.style.transform = 'translateX(0)';
                                }}
                            >
                                <div style={{
                                    width: '18px',
                                    height: '8px',
                                    borderRadius: '2px',
                                    background: item.bgColor?.replace('0.08', '0.6') || item.color,
                                    border: `1px solid ${item.color}`,
                                }} />
                                <span style={{ fontSize: '11px', color: UX_COLORS.icon }}>{item.label}</span>
                                <span style={{ color: '#8E9FBC', marginLeft: 'auto', fontSize: '10px' }}>({item.count})</span>
                            </div>
                        ))}
                    </div>
                </div>
            )}
        </div>
    );
}

export default Legend;
