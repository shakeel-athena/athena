/**
 * CameraHUD
 * Floating Heads-Up Display for camera controls and navigation
 */

import React, { useState } from 'react';
import { UX_COLORS } from '../utils/constants';

// Icons (SVG paths for lightweight usage)
const ICONS = {
    zoomIn: <path d="M12 5v14M5 12h14" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />,
    zoomOut: <path d="M5 12h14" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />,
    fit: <path d="M4 4h6v2H6v4H4V4zm10 0h6v6h-2V6h-4V4zm6 10h-2v4h-4v2h6v-6zM4 14h2v4h4v2H4v-6z" fill="currentColor" />,
    top: <path d="M12 4L4 8l8 4 8-4-8-4zm0 16l8-4-8-4-8 4 8 4z" fill="none" stroke="currentColor" strokeWidth="2" />,
    iso: <path d="M12 3L4 7.5v9L12 21l8-4.5v-9L12 3zm0 18v-9m0 0L4 7.5m8 4.5l8-4.5" stroke="currentColor" strokeWidth="2" fill="none" />,
};

const Button = ({ onClick, title, children, active }) => (
    <button
        onClick={onClick}
        title={title}
        style={{
            background: active ? 'rgba(56, 189, 248, 0.2)' : 'rgba(30, 41, 59, 0.8)',
            border: active ? `1px solid ${UX_COLORS.edge}` : '1px solid #334155',
            color: active ? UX_COLORS.edge : '#94A3B8',
            width: '32px',
            height: '32px',
            borderRadius: '6px',
            cursor: 'pointer',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            transition: 'all 0.2s',
            padding: '6px'
        }}
        onMouseEnter={(e) => {
            if (!active) {
                e.currentTarget.style.background = 'rgba(56, 189, 248, 0.1)';
                e.currentTarget.style.color = '#F1F5F9';
            }
        }}
        onMouseLeave={(e) => {
            if (!active) {
                e.currentTarget.style.background = 'rgba(30, 41, 59, 0.8)';
                e.currentTarget.style.color = '#94A3B8';
            }
        }}
    >
        <svg width="100%" height="100%" viewBox="0 0 24 24" fill="none">
            {children}
        </svg>
    </button>
);

export function CameraHUD({
    onZoomIn,
    onZoomOut,
    onFitToView,
    onSetView,
    activeSegments = [],
    onSelectSegment
}) {
    return (
        <div style={{
            position: 'absolute',
            top: '20px',
            right: '20px',
            display: 'flex',
            flexDirection: 'column',
            gap: '12px',
            zIndex: 100,
            alignItems: 'flex-end'
        }}>
            {/* View Presets Group */}
            <div style={{
                display: 'flex',
                gap: '8px',
                background: 'rgba(15, 23, 42, 0.6)',
                backdropFilter: 'blur(4px)',
                padding: '8px',
                borderRadius: '8px',
                border: '1px solid rgba(51, 65, 85, 0.5)'
            }}>
                <Button onClick={() => onSetView('TOP')} title="Top View">
                    {ICONS.top}
                </Button>
                <Button onClick={() => onSetView('ISO')} title="Isometric View">
                    {ICONS.iso}
                </Button>
                <div style={{ width: '1px', background: '#334155', margin: '0 4px' }} />
                <Button onClick={onFitToView} title="Fit to View">
                    {ICONS.fit}
                </Button>
            </div>

            {/* Zoom Controls */}
            <div style={{
                display: 'flex',
                flexDirection: 'column',
                gap: '8px',
                background: 'rgba(15, 23, 42, 0.6)',
                backdropFilter: 'blur(4px)',
                padding: '8px',
                borderRadius: '8px',
                border: '1px solid rgba(51, 65, 85, 0.5)'
            }}>
                <Button onClick={onZoomIn} title="Zoom In">
                    {ICONS.zoomIn}
                </Button>
                <Button onClick={onZoomOut} title="Zoom Out">
                    {ICONS.zoomOut}
                </Button>
            </div>

            {/* Segment Jump Menu */}
            {activeSegments.length > 0 && (
                <div style={{
                    marginTop: '8px',
                    background: 'rgba(15, 23, 42, 0.9)',
                    backdropFilter: 'blur(8px)',
                    borderRadius: '8px',
                    border: '1px solid rgba(51, 65, 85, 0.8)',
                    overflow: 'hidden',
                    display: 'flex',
                    flexDirection: 'column',
                    minWidth: '160px'
                }}>
                    <div style={{
                        padding: '8px 12px',
                        fontSize: '11px',
                        fontWeight: 'bold',
                        color: '#64748B',
                        borderBottom: '1px solid rgba(51, 65, 85, 0.5)',
                        textTransform: 'uppercase',
                        letterSpacing: '0.05em'
                    }}>
                        Jump to Zone
                    </div>
                    <div style={{ maxHeight: '200px', overflowY: 'auto' }}>
                        {activeSegments.map(seg => (
                            <div
                                key={seg.key}
                                onClick={() => onSelectSegment(seg.key)}
                                style={{
                                    padding: '8px 12px',
                                    fontSize: '12px',
                                    color: '#E2E8F0',
                                    cursor: 'pointer',
                                    transition: 'background 0.2s',
                                    display: 'flex',
                                    alignItems: 'center',
                                    gap: '8px'
                                }}
                                onMouseEnter={(e) => e.target.style.background = 'rgba(56, 189, 248, 0.1)'}
                                onMouseLeave={(e) => e.target.style.background = 'transparent'}
                            >
                                <div style={{
                                    width: '8px', height: '8px', borderRadius: '50%',
                                    background: seg.color
                                }} />
                                {seg.label}
                            </div>
                        ))}
                    </div>
                </div>
            )}
        </div>
    );
}

export default CameraHUD;
