/**
 * NodeHUD
 * Holographic HUD panel for selected node details (isolation mode)
 */

import React from 'react';
import { getNodeColor, getNodeSegmentConfig } from '../utils/NodeStyleResolver';
import { UX_COLORS } from '../utils/constants';

/**
 * Convert hex color number to CSS color string
 * @param {number} hex
 * @returns {string}
 */
function hexToColor(hex) {
    if (typeof hex === 'string') return hex;
    return `#${hex.toString(16).padStart(6, '0')}`;
}

/**
 * NodeHUD component - Detailed node information panel
 * @param {Object} props
 * @param {Object} props.node - Node data object
 * @param {Function} props.onExitFocus - Callback to exit focus/isolation mode
 */
export function NodeHUD({ node, onExitFocus }) {
    if (!node) return null;

    const nodeColor = hexToColor(getNodeColor(node));
    const segmentConfig = getNodeSegmentConfig(node);

    return (
        <div style={{
            position: 'absolute',
            top: '20px',
            right: '20px',
            background: 'linear-gradient(135deg, #1D1E24, #22232A)',
            border: '1px solid #343741',
            borderRadius: '12px',
            padding: '20px',
            color: UX_COLORS.icon,
            minWidth: '300px',
            backdropFilter: 'blur(10px)',
            boxShadow: '0 0 30px rgba(0, 0, 0, 0.4)',
        }}>
            {/* Header */}
            <div style={{
                fontSize: '18px',
                fontWeight: 'bold',
                marginBottom: '16px',
                color: UX_COLORS.edge,
                display: 'flex',
                alignItems: 'center',
                gap: '10px',
            }}>
                <div style={{
                    width: '14px',
                    height: '14px',
                    borderRadius: '50%',
                    background: nodeColor,
                    flexShrink: 0,
                }} />
                {node.label || node.name || node.id}
            </div>

            {/* Properties Grid */}
            <div style={{ display: 'grid', gap: '10px', fontSize: '13px' }}>
                <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                    <span style={{ color: '#8E9FBC' }}>IP Address:</span>
                    <span style={{ fontFamily: 'monospace' }}>{node.ip || 'N/A'}</span>
                </div>

                <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                    <span style={{ color: '#8E9FBC' }}>OS:</span>
                    <span>{node.os || node.platform || 'Unknown'}</span>
                </div>

                <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                    <span style={{ color: '#8E9FBC' }}>Segment:</span>
                    <span style={{
                        padding: '2px 8px',
                        borderRadius: '4px',
                        background: segmentConfig.bgColor,
                        color: segmentConfig.color,
                    }}>
                        {segmentConfig.label}
                    </span>
                </div>

                {node.alertCount > 0 && (
                    <div style={{
                        display: 'flex',
                        justifyContent: 'space-between',
                        color: '#F87171',
                    }}>
                        <span>Active Alerts:</span>
                        <span style={{ fontWeight: 'bold' }}>{node.alertCount}</span>
                    </div>
                )}

                {/* Risk Score Box */}
                <div style={{
                    marginTop: '8px',
                    padding: '12px',
                    background: node.riskScore > 50
                        ? 'rgba(246, 114, 106, 0.2)'
                        : 'rgba(36, 194, 146, 0.2)',
                    borderRadius: '8px',
                    textAlign: 'center',
                }}>
                    <div style={{ fontSize: '11px', color: '#8E9FBC', marginBottom: '4px' }}>
                        RISK SCORE
                    </div>
                    <div style={{
                        fontSize: '28px',
                        fontWeight: 'bold',
                        color: node.riskScore > 50 ? '#F6726A' : '#24C292',
                    }}>
                        {node.riskScore || 0}
                    </div>
                </div>
            </div>

            {/* Exit Button */}
            <button
                onClick={onExitFocus}
                style={{
                    marginTop: '16px',
                    width: '100%',
                    padding: '10px',
                    background: 'rgba(97, 162, 255, 0.12)',
                    border: '1px solid rgba(97, 162, 255, 0.35)',
                    borderRadius: '8px',
                    color: UX_COLORS.edge,
                    cursor: 'pointer',
                    transition: 'all 0.2s',
                    fontSize: '13px',
                    fontWeight: '500',
                }}
                onMouseEnter={(e) => {
                    e.target.style.background = 'rgba(97, 162, 255, 0.2)';
                }}
                onMouseLeave={(e) => {
                    e.target.style.background = 'rgba(97, 162, 255, 0.12)';
                }}
            >
                Exit Focus Mode
            </button>
        </div>
    );
}

export default NodeHUD;
