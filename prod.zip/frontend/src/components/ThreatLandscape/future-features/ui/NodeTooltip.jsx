/**
 * NodeTooltip
 * Hover tooltip component for displaying node information
 */

import React from 'react';
import { getNodeColor, getNodeSegmentConfig } from '../utils/NodeStyleResolver';
import { UX_COLORS } from '../utils/constants';

/**
 * Convert hex color number to CSS color string
 * @param {number} hex
 * @returns {string}
 */
function hexToColor(hex) {
    if (typeof hex === 'string') return hex;
    return `#${hex.toString(16).padStart(6, '0')}`;
}

/**
 * NodeTooltip component
 * @param {Object} props
 * @param {boolean} props.visible - Whether tooltip is visible
 * @param {number} props.x - Screen X position
 * @param {number} props.y - Screen Y position
 * @param {Object} props.node - Node data object
 */
export function NodeTooltip({ visible, x, y, node }) {
    if (!visible || !node) return null;

    const nodeColor = hexToColor(getNodeColor(node));
    const segmentConfig = getNodeSegmentConfig(node);

    return (
        <div style={{
            position: 'fixed',
            left: x + 15,
            top: y + 15,
            background: '#22232A',
            border: '1px solid #343741',
            borderRadius: '8px',
            padding: '12px',
            color: UX_COLORS.icon,
            fontSize: '12px',
            pointerEvents: 'none',
            zIndex: 1000,
            boxShadow: '0 8px 24px -6px rgba(0, 0, 0, 0.6)',
            minWidth: '200px',
            backdropFilter: 'blur(8px)',
        }}>
            {/* Header with color indicator */}
            <div style={{
                fontWeight: 'bold',
                marginBottom: '10px',
                fontSize: '14px',
                display: 'flex',
                alignItems: 'center',
                gap: '8px',
            }}>
                <div style={{
                    width: '10px',
                    height: '10px',
                    borderRadius: '50%',
                    background: nodeColor,
                    flexShrink: 0,
                }} />
                {node.label || node.name || node.id}
            </div>

            {/* Properties grid */}
            <div style={{ display: 'grid', gap: '6px' }}>
                <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                    <span style={{ color: '#8E9FBC' }}>IP:</span>
                    <span style={{ fontFamily: 'monospace' }}>{node.ip || 'N/A'}</span>
                </div>

                <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                    <span style={{ color: '#8E9FBC' }}>Role:</span>
                    <span style={{ textTransform: 'capitalize' }}>{node.role || 'Unknown'}</span>
                </div>

                <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                    <span style={{ color: '#8E9FBC' }}>Segment:</span>
                    <span style={{ color: segmentConfig.color }}>
                        {segmentConfig.label}
                    </span>
                </div>

                {node.alertCount > 0 && (
                    <div style={{
                        display: 'flex',
                        justifyContent: 'space-between',
                        color: '#F87171',
                    }}>
                        <span>Alerts:</span>
                        <span style={{ fontWeight: 'bold' }}>{node.alertCount}</span>
                    </div>
                )}

                {/* Risk Score */}
                <div style={{
                    marginTop: '8px',
                    padding: '8px',
                    background: node.riskScore > 50
                        ? 'rgba(246, 114, 106, 0.2)'
                        : 'rgba(36, 194, 146, 0.2)',
                    borderRadius: '6px',
                    display: 'flex',
                    justifyContent: 'space-between',
                    alignItems: 'center',
                }}>
                    <span style={{ color: '#8E9FBC', fontSize: '11px' }}>Risk Score</span>
                    <span style={{
                        fontWeight: 'bold',
                        color: node.riskScore > 50 ? '#F6726A' : '#24C292',
                        fontSize: '16px',
                    }}>
                        {node.riskScore || 0}
                    </span>
                </div>
            </div>
        </div>
    );
}

export default NodeTooltip;
