/**
 * NetworkTopology3D - Main Orchestrator
 * 
 * Modular 3D network topology visualization for cybersecurity monitoring.
 * This is a refactored version that uses extracted modules for:
 * - Scene management (core/SceneManager)
 * - Camera animations (core/CameraController)
 * - User interactions (core/InteractionManager)
 * - Node rendering (rendering/NodeRenderer)
 * - Edge rendering (rendering/EdgeRenderer)
 * - Zone rendering (rendering/ZoneRenderer)
 * - Physics simulation (physics/ForceSimulation)
 * - UI components (ui/*)
 */

import React, { useEffect, useRef, useState, useImperativeHandle, forwardRef, useCallback } from 'react';
import { useSafeResizeObserver } from '../../../hooks/useSafeResizeObserver';
import * as THREE from 'three';
import TWEEN from '@tweenjs/tween.js';

// Core modules
import { createScene, handleResize } from './core/SceneManager';
import { CameraController, exportToPNG } from './core/CameraController';
import { D3NavigationController } from './core/D3NavigationController';
import { InteractionManager } from './core/InteractionManager';
import { MiniMapController } from './core/MiniMapController';

// Rendering modules
import { NodeRenderer } from './rendering/NodeRenderer';
import { EdgeRenderer } from './rendering/EdgeRenderer';
import { ZoneRenderer } from './rendering/ZoneRenderer';

// Physics
import { ForceSimulation } from './physics/ForceSimulation';

// Utils
import { getNodeSegment } from './utils/NodeStyleResolver';

// UI Components
import { NodeTooltip, NodeHUD, Legend, CameraHUD } from './ui';

// ============================================================================
// MAIN COMPONENT
// ============================================================================

const NetworkTopology3D = forwardRef(({ topology, onSelectNode, selectedNodeId, onNodePositionChange }, ref) => {
    // Refs
    const mountRef = useRef(null);
    const sceneRef = useRef(null);
    const cameraRef = useRef(null);
    const controlsRef = useRef(null);
    const rendererRef = useRef(null);
    const animationIdRef = useRef(null);
    const pendingFocusRef = useRef(null);
    const activeSegmentRef = useRef(null);

    // Module refs
    const cameraControllerRef = useRef(null);
    const interactionRef = useRef(null);
    const nodeRendererRef = useRef(null);
    const edgeRendererRef = useRef(null);
    const simulationRef = useRef(null);
    const d3NavRef = useRef(null);
    const miniMapRef = useRef(null);

    // State
    const [tooltip, setTooltip] = useState({ visible: false, x: 0, y: 0, node: null });
    const [selectedNodeHUD, setSelectedNodeHUD] = useState(null);
    const [isolationMode, setIsolationMode] = useState(false);

    const getNodesForSelection = useCallback((type, key) => {
        const nodes = topology.nodes || [];
        if (type === 'segment') {
            return nodes.filter(node => getNodeSegment(node) === key);
        }
        if (type === 'subnet') {
            return nodes.filter(node => node.subnet === key);
        }
        return [];
    }, [topology.nodes]);

    const focusOnNodes = useCallback((nodes, options = {}) => {
        const camera = cameraRef.current;
        const controller = cameraControllerRef.current;
        if (!camera || !controller || nodes.length === 0) return false;

        const meshes = nodes
            .map(node => nodeRendererRef.current?.getNodeById(node.id))
            .filter(Boolean);

        if (meshes.length > 0) {
            if (meshes.length === 1) {
                controller.flyToNode(meshes[0]).then(() => d3NavRef.current?.sync());
            } else {
                controller.fitToView(meshes).then(() => d3NavRef.current?.sync());
            }
            if (controlsRef.current) controlsRef.current.autoRotate = false;
            return true;
        }

        const zoomScale = typeof options.zoomScale === 'number' ? options.zoomScale : 0.8;
        const box = new THREE.Box3();
        const tempPoint = new THREE.Vector3();
        let hasPoint = false;

        nodes.forEach(node => {
            const x = Number.isFinite(node.x) ? node.x : 0;
            const z = Number.isFinite(node.y) ? node.y : 0;
            tempPoint.set(x, 0, z);
            box.expandByPoint(tempPoint);
            hasPoint = true;
        });

        if (!hasPoint || box.isEmpty()) return false;

        const center = new THREE.Vector3();
        box.getCenter(center);
        const size = box.getSize(new THREE.Vector3());
        const maxDim = Math.max(size.x, size.y, size.z, 1);
        const fov = camera.fov * (Math.PI / 180);
        const distance = Math.abs(maxDim / Math.sin(fov / 2)) * zoomScale;

        const targetPosition = new THREE.Vector3(
            center.x + distance * 0.6,
            center.y + distance * 0.4,
            center.z + distance * 0.6
        );

        controller.flyToPosition(targetPosition, center).then(() => d3NavRef.current?.sync());
        if (controlsRef.current) controlsRef.current.autoRotate = false;
        return true;
    }, []);

    // Calculate active segments for HUD
    // This is a lightweight version of what Legend does, just for the dropdown
    const activeSegments = React.useMemo(() => {
        const segments = new Set();
        const result = [];

        topology.nodes.forEach(node => {
            if (node.type === 'cluster' || node.type === 'segment-diamond') return;
            const seg = getNodeSegment(node);
            if (!segments.has(seg)) {
                segments.add(seg);
                // Simple color derivation or lookup could go here, 
                // but for now we'll just push the key/label
                result.push({ key: seg, label: seg, color: '#38BDF8' });
            }
        });
        return result.sort((a, b) => a.label.localeCompare(b.label));
    }, [topology.nodes]);


    // Resize handling with enhanced error suppression
    const handleResizeCallback = useCallback((entries) => {
        try {
            if (!mountRef.current || !cameraRef.current || !rendererRef.current) return;

            const entry = entries[0];
            const width = entry ? entry.contentRect.width : mountRef.current.clientWidth;
            const height = entry ? entry.contentRect.height : mountRef.current.clientHeight;

            // Prevent resize loops by checking for actual size changes
            if (rendererRef.current.domElement.width === width &&
                rendererRef.current.domElement.height === height) {
                return;
            }

            handleResize(cameraRef.current, rendererRef.current, width, height);
        } catch (error) {
            // Silently suppress any ResizeObserver-related errors
            if (error.message && error.message.includes('ResizeObserver')) {
                return;
            }
            console.warn('Resize handling warning:', error);
        }
    }, []);

    const { observe, disconnect } = useSafeResizeObserver(handleResizeCallback);

    useEffect(() => {
        if (mountRef.current) {
            observe(mountRef.current);
        }
        return () => disconnect();
    }, [observe, disconnect]);

    // Expose camera control methods to parent
    useImperativeHandle(ref, () => ({
        zoomIn: () => cameraControllerRef.current?.zoomIn(),
        zoomOut: () => cameraControllerRef.current?.zoomOut(),
        fitToView: () => {
            const meshes = nodeRendererRef.current?.getMeshes() || [];
            cameraControllerRef.current?.fitToView(meshes);
        },
        focusOnNode: (nodeId) => {
            const mesh = nodeRendererRef.current?.getNodeById(nodeId);
            if (mesh) {
                cameraControllerRef.current?.flyToNode(mesh);
                setIsolationMode(true);
                setSelectedNodeHUD(mesh.userData.node);
                nodeRendererRef.current?.dimExcept(mesh);
            }
        },
        exportToPNG: () => {
            if (rendererRef.current) {
                exportToPNG(rendererRef.current);
            }
        },
        exitIsolation: () => {
            setIsolationMode(false);
            setSelectedNodeHUD(null);
            nodeRendererRef.current?.restoreAll();
        },
    }));

    // Exit isolation mode handler
    const handleExitFocus = useCallback(() => {
        setIsolationMode(false);
        setSelectedNodeHUD(null);
        nodeRendererRef.current?.restoreAll();
        if (controlsRef.current) controlsRef.current.autoRotate = true;
    }, []);

    // Handle segment selection from legend
    const handleSelectSegment = useCallback((segmentKey) => {
        if (!cameraControllerRef.current) return;

        // Exit isolation/HUD if active
        setIsolationMode(false);
        setSelectedNodeHUD(null);
        nodeRendererRef.current?.restoreAll();

        pendingFocusRef.current = { type: 'segment', key: segmentKey };

        const nodes = getNodesForSelection('segment', segmentKey);
        if (focusOnNodes(nodes)) {
            activeSegmentRef.current = segmentKey;
            pendingFocusRef.current = null;
        }
    }, [focusOnNodes, getNodesForSelection]);

    // Handle subnet selection from legend
    const handleSelectSubnet = useCallback((subnetKey) => {
        if (!cameraControllerRef.current) return;

        // Exit isolation/HUD if active
        setIsolationMode(false);
        setSelectedNodeHUD(null);
        nodeRendererRef.current?.restoreAll();

        pendingFocusRef.current = { type: 'subnet', key: subnetKey };
        activeSegmentRef.current = null;

        const nodes = getNodesForSelection('subnet', subnetKey);
        if (focusOnNodes(nodes, { zoomScale: 0.6 })) {
            pendingFocusRef.current = null;
        }
    }, [focusOnNodes, getNodesForSelection]);

    // Main effect - Scene setup
    useEffect(() => {
        if (!mountRef.current) return;

        // --- Initialize Scene ---
        // --- Initialize Scene ---
        const { scene, camera, renderer, controls, dispose: disposeScene } = createScene(mountRef.current, {
            enableZoom: false, // D3 handles zoom
            enablePan: false,  // D3 handles pan
        });

        sceneRef.current = scene;
        cameraRef.current = camera;
        rendererRef.current = renderer;
        controlsRef.current = controls;
        activeSegmentRef.current = null;

        const pickSegmentForFocus = () => {
            const nodeRenderer = nodeRendererRef.current;
            if (!nodeRenderer) return null;

            const segmentBounds = new Map();
            topology.nodes.forEach(node => {
                if (!node || node.type === 'cluster' || node.type === 'segment-diamond') return;
                const segment = getNodeSegment(node);
                if (!segment) return;

                const mesh = nodeRenderer.getNodeById(node.id);
                if (!mesh) return;

                let bounds = segmentBounds.get(segment);
                if (!bounds) {
                    bounds = new THREE.Box3();
                    segmentBounds.set(segment, bounds);
                }
                bounds.expandByPoint(mesh.position);
            });

            if (segmentBounds.size === 0) return null;

            const focusTarget = controls.target;
            let bestSegment = null;
            let bestDistance = Infinity;

            segmentBounds.forEach((bounds, segment) => {
                if (bounds.isEmpty()) return;
                const center = new THREE.Vector3();
                const size = new THREE.Vector3();
                bounds.getCenter(center);
                bounds.getSize(size);

                const radius = Math.max(size.x, size.z) * 0.6 + 10;
                const distance = Math.hypot(center.x - focusTarget.x, center.z - focusTarget.z);

                if (distance <= radius && distance < bestDistance) {
                    bestDistance = distance;
                    bestSegment = segment;
                }
            });

            return bestSegment;
        };

        const handleZoomEnd = (state) => {
            if (!state || isolationMode) return;
            if (!cameraControllerRef.current) return;

            const diveDistance = 200;
            const exitDistance = 260;

            if (state.distance <= diveDistance && !activeSegmentRef.current) {
                const segment = pickSegmentForFocus();
                if (!segment) return;

                const nodes = getNodesForSelection('segment', segment);
                if (focusOnNodes(nodes)) {
                    activeSegmentRef.current = segment;
                }
                return;
            }

            if (state.distance >= exitDistance && activeSegmentRef.current) {
                activeSegmentRef.current = null;
                const meshes = nodeRendererRef.current?.getMeshes() || [];
                if (meshes.length > 0) {
                    cameraControllerRef.current.fitToView(meshes).then(() => d3NavRef.current?.sync());
                }
            }
        };

        // --- Initialize D3 Navigation ---
        // MUST import D3NavigationController (adding import below)
        const d3Nav = new D3NavigationController(camera, renderer, controls, {
            onZoomEnd: handleZoomEnd,
        });
        d3Nav.initialize();
        d3NavRef.current = d3Nav;
        // Store ref if needed anywhere

        // --- Initialize MiniMap ---
        const miniMap = new MiniMapController(renderer, scene);
        miniMapRef.current = miniMap;

        // --- Initialize Camera Controller ---
        const cameraController = new CameraController(camera, controls);
        cameraControllerRef.current = cameraController;

        // --- Initialize Renderers ---
        const nodeRenderer = new NodeRenderer(scene, camera);
        nodeRendererRef.current = nodeRenderer;

        const edgeRenderer = new EdgeRenderer(scene);
        edgeRendererRef.current = edgeRenderer;

        const zoneRenderer = new ZoneRenderer(scene);

        // --- Create Nodes ---
        const nodeMeshes = nodeRenderer.createNodes(topology.nodes);

        if (pendingFocusRef.current) {
            const { type, key } = pendingFocusRef.current;
            const focusNodes = getNodesForSelection(type, key);
            if (focusOnNodes(focusNodes, type === 'subnet' ? { zoomScale: 0.6 } : undefined)) {
                pendingFocusRef.current = null;
            }
        }

        // --- Create Edges ---
        /*
        const getNodePosition = (nodeId) => {
            const id = nodeId?.id || nodeId;
            const mesh = nodeRenderer.getNodeById(id);
            return mesh ? mesh.position : null;
        };
        */
        edgeRenderer.createEdges(topology.edges, (id) => {
            const node = topology.nodes.find(n => n.id === id);
            return node ? { x: node.x, y: node.y, z: node.z } : null;
        });

        // --- Initialize Physics ---
        const simulation = new ForceSimulation(topology.nodes, topology.edges);
        simulationRef.current = simulation;

        // --- Initialize Interaction Manager ---
        const interaction = new InteractionManager(camera, renderer, controls);
        interaction.setNodeMeshes(nodeMeshes);
        interactionRef.current = interaction;

        // Setup hover callback
        interaction.setOnHover((mesh, screenPos) => {
            setTooltip({
                visible: true,
                x: screenPos.x,
                y: screenPos.y,
                node: mesh.userData.node,
            });
            nodeRenderer.setHoverState(mesh, true);
        });

        interaction.setOnHoverEnd((mesh) => {
            setTooltip(prev => ({ ...prev, visible: false }));
            nodeRenderer.setHoverState(mesh, false);
        });

        // Setup click callback
        interaction.setOnClick((mesh) => {
            if (mesh) {
                onSelectNode(mesh.userData.node);
                controls.autoRotate = false;
                cameraController.flyToNode(mesh);
                setIsolationMode(true);
                setSelectedNodeHUD(mesh.userData.node);
                nodeRenderer.dimExcept(mesh);
            } else if (!isolationMode) {
                onSelectNode(null);
                controls.autoRotate = true;
            }
        });

        // Setup drag callbacks
        interaction.setOnDragEnd((mesh) => {
            const nodeId = mesh.userData.id;
            const newPosition = {
                x: Math.round(mesh.position.x),
                y: Math.round(mesh.position.y),
                z: Math.round(mesh.position.z),
                position_locked: true,
            };

            mesh.userData.node.x = newPosition.x;
            mesh.userData.node.y = newPosition.y;
            mesh.userData.node.z = newPosition.z;

            if (onNodePositionChange) {
                onNodePositionChange(nodeId, newPosition);
            }

            // Reheat simulation
            simulation.reheat(0.3);
        });

        // --- Animation Loop ---
        const clock = new THREE.Clock();

        const animate = () => {
            animationIdRef.current = requestAnimationFrame(animate);

            const time = clock.getElapsedTime();

            // Update TWEEN animations
            TWEEN.update();

            // Update controls
            controls.update();

            // Physics simulation tick
            simulation.tick();

            // Sync node positions from physics
            nodeRenderer.updatePositions(0.1);

            // Update edge positions
            edgeRenderer.updatePositions(topology.edges, (id) => {
                const mesh = nodeRenderer.getNodeById(id);
                // Fallback to topology data if mesh not yet ready, or origin as last resort
                if (mesh) return mesh.position;
                const node = topology.nodes.find(n => n.id === id);
                if (node) return { x: node.x, y: node.z, z: node.y }; // Note: physics z/y swap
                return { x: 0, y: 0, z: 0 };
            });

            // Animate critical nodes
            nodeRenderer.animateCriticalNodes(time);

            // Animate attack lines
            edgeRenderer.animateAttackLines(time);

            // Update interaction raycasting
            interaction.update();

            // Update hover state
            const mousePos = interaction.getMousePosition();
            setTooltip(prev => ({ ...prev, x: mousePos.x, y: mousePos.y }));

            // Highlight selected node
            nodeRenderer.highlightSelected(selectedNodeId, interaction.getHoveredNode());

            // Render scene
            renderer.render(scene, camera);

            // Render MiniMap (Last pass)
            // Render MiniMap (Last pass)
            if (miniMapRef.current) {
                miniMapRef.current.render(camera);
            }
        };

        animate();

        // --- Cleanup ---
        return () => {
            cancelAnimationFrame(animationIdRef.current);
            interaction.dispose();
            nodeRenderer.dispose();
            edgeRenderer.dispose();
            zoneRenderer.dispose();
            simulation.dispose();
            d3Nav.dispose();
            d3NavRef.current = null;
            if (miniMapRef.current) miniMapRef.current.dispose();
            disposeScene();
        };
    }, [topology, onSelectNode, selectedNodeId, onNodePositionChange, isolationMode, focusOnNodes, getNodesForSelection]);

    return (
        <div
            className="network-topology-3d"
            style={{
                position: 'relative',
                width: '100%',
                height: '100%',
                contain: 'strict', // Absolute layout isolation to prevent resize loops
                overflow: 'hidden',
                background: '#151519',
            }}
        >
            <div ref={mountRef} style={{
                width: '100%',
                height: '100%',
                position: 'absolute', // Ensure it fills the 'strict' container
                top: 0,
                left: 0,
            }} />

            {/* Holographic HUD for selected node */}
            {selectedNodeHUD && isolationMode && (
                <NodeHUD node={selectedNodeHUD} onExitFocus={handleExitFocus} />
            )}

            {/* Tooltip */}
            {!isolationMode && (
                <NodeTooltip
                    visible={tooltip.visible}
                    x={tooltip.x}
                    y={tooltip.y}
                    node={tooltip.node}
                />
            )}

            {/* Camera Controls HUD */}
            <CameraHUD
                onZoomIn={() => cameraControllerRef.current?.zoomIn()}
                onZoomOut={() => cameraControllerRef.current?.zoomOut()}
                onFitToView={() => {
                    const meshes = nodeRendererRef.current?.getMeshes() || [];
                    cameraControllerRef.current?.fitToView(meshes);
                }}
                onSetView={(view) => cameraControllerRef.current?.setCameraView(view)}
                activeSegments={activeSegments}
                onSelectSegment={handleSelectSegment}
            />

            {/* Legend */}
            <Legend
                nodes={topology.nodes}
                onSelectSegment={handleSelectSegment}
                onSelectSubnet={handleSelectSubnet}
            />
        </div>
    );
});

NetworkTopology3D.displayName = 'NetworkTopology3D';

export default NetworkTopology3D;
