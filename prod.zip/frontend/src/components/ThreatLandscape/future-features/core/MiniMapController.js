/**
 * MiniMapController
 * Handles the rendering of a secondary top-down view (Mini-Map)
 * using viewport scissor testing.
 */

import * as THREE from 'three';

export class MiniMapController {
    constructor(renderer, scene, config = {}) {
        this.renderer = renderer;
        this.scene = scene;

        this.config = {
            size: 200, // Size in pixels
            padding: 20, // Padding from bottom-right
            zoom: 50, // Orthographic zoom level
            background: 0x000000,
            opacity: 0.8,
            border: 0x38BDF8, // Cyan border
            ...config
        };

        // Aspect ratio is 1:1 for the square map
        const frustumSize = 1000;
        this.camera = new THREE.OrthographicCamera(
            frustumSize / -2, frustumSize / 2,
            frustumSize / 2, frustumSize / -2,
            1, 5000
        );

        // Setup camera: Top-Down
        this.camera.position.set(0, 1000, 0);
        this.camera.lookAt(0, 0, 0);
        this.camera.up.set(0, 0, -1); // Orient 'Up' on screen to be -Z in world (standard map)

        // Helper to visualize the map border (optional, rendered in main scene? No, 2D overlay is better)
        // For now, Scissor box is implicitly the border.
    }

    /**
     * Render the Mini-Map
     * Assumes the main scene has already been rendered (renderer.autoClear = false ideal, but we manage clears)
     * @param {THREE.Camera} mainCamera - The main perspective camera (used for frustum viz later)
     */
    render(mainCamera) {
        // Current window size
        const width = this.renderer.domElement.width;
        const height = this.renderer.domElement.height;

        // Map Size
        const mapSize = this.config.size;

        // Viewport Position (Bottom-Right)
        const x = width - mapSize - this.config.padding;
        const y = this.config.padding; // glScissor uses bottom-left origin

        // Enable Scissor
        this.renderer.setScissorTest(true);
        this.renderer.setViewport(x, y, mapSize, mapSize);
        this.renderer.setScissor(x, y, mapSize, mapSize);

        // Clear depth for the map so it renders on top (if we wanted overlay behavior)
        // But since we are rendering to a specific corner, we just clear that corner's color/depth
        // Set background color for map
        const originalClearColor = new THREE.Color();
        this.renderer.getClearColor(originalClearColor);
        const originalClearAlpha = this.renderer.getClearAlpha();

        this.renderer.setClearColor(this.config.background, this.config.opacity);
        this.renderer.clear(); // Clear only the scissor region

        // Render Map
        this.renderer.render(this.scene, this.camera);

        // Restore State
        this.renderer.setScissorTest(false);
        this.renderer.setClearColor(originalClearColor, originalClearAlpha);

        // Restore full viewport
        // Note: The main loop typically resets viewport at start of frame, 
        // but it's good practice to leave renderer in clean state if we can.
        this.renderer.setViewport(0, 0, width, height);
    }

    update() {
        // Update camera position to follow target? 
        // Or static full map? currently static full map of 0,0 center.
    }

    dispose() {
        // Nothing to dispose generally unless we added helpers
    }
}
