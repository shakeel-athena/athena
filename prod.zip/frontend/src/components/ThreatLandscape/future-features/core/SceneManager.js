/**
 * SceneManager
 * Handles Three.js scene, camera, renderer, controls, and environment setup
 */

import * as THREE from 'three';
import { OrbitControls } from 'three/examples/jsm/controls/OrbitControls';
import { SCENE_CONFIG, CAMERA_CONFIG } from '../utils/constants';

/**
 * Create and configure the complete Three.js scene
 * @param {HTMLElement} container - DOM element to attach the renderer to
 * @param {Object} options - Override default configuration
 * @returns {Object} - { scene, camera, renderer, controls, dispose }
 */
export function createScene(container, options = {}) {
    const config = {
        ...SCENE_CONFIG,
        ...CAMERA_CONFIG,
        ...options,
    };

    // --- Scene Setup ---
    const scene = new THREE.Scene();
    scene.background = new THREE.Color(config.background);
    scene.fog = new THREE.FogExp2(config.background, config.fogDensity);

    // --- Camera ---
    const camera = new THREE.PerspectiveCamera(
        config.fov,
        container.clientWidth / container.clientHeight,
        config.near,
        config.far
    );
    camera.position.set(
        config.initialPosition.x,
        config.initialPosition.y,
        config.initialPosition.z
    );

    // --- Renderer ---
    const renderer = new THREE.WebGLRenderer({
        antialias: true,
        alpha: true,
        preserveDrawingBuffer: true,
        powerPreference: 'high-performance',
    });
    renderer.setSize(container.clientWidth, container.clientHeight);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.0; // Slightly lower for better neon pop
    container.appendChild(renderer.domElement);

    // --- Controls ---
    const controls = new OrbitControls(camera, renderer.domElement);
    controls.enableDamping = true;
    controls.dampingFactor = config.dampingFactor;
    controls.autoRotate = config.autoRotateSpeed > 0;
    controls.autoRotateSpeed = config.autoRotateSpeed;
    // Allow disabling native zoom/pan to let D3 take over
    controls.enableZoom = options.enableZoom !== undefined ? options.enableZoom : true;
    controls.enablePan = options.enablePan !== undefined ? options.enablePan : true;

    controls.minDistance = config.minDistance;
    controls.maxDistance = config.maxDistance;
    controls.maxPolarAngle = config.maxPolarAngle;
    controls.target.set(0, 0, 0);

    // --- Lighting ---
    setupLighting(scene);

    // --- Environment ---
    const environmentObjects = setupEnvironment(scene, config);

    // --- Cleanup function ---
    function dispose() {
        controls.dispose();

        // Dispose environment objects
        environmentObjects.forEach(obj => {
            if (obj.geometry) obj.geometry.dispose();
            if (obj.material) obj.material.dispose();
            scene.remove(obj);
        });

        // Remove renderer from DOM
        if (container.contains(renderer.domElement)) {
            container.removeChild(renderer.domElement);
        }
        renderer.dispose();
    }

    return {
        scene,
        camera,
        renderer,
        controls,
        dispose,
    };
}

/**
 * Setup scene lighting
 * @param {THREE.Scene} scene
 */
function setupLighting(scene) {
    // Dim ambient light to make neon glow pop
    const ambientLight = new THREE.AmbientLight(0x404040, 0.4);
    scene.add(ambientLight);

    // High contrast spotlight
    const spotLight = new THREE.SpotLight(0xffffff, 2.5);
    spotLight.position.set(0, 300, 0);
    spotLight.angle = Math.PI / 4;
    spotLight.penumbra = 0.8;
    scene.add(spotLight);

    // Subtle neon accent lights
    const cyanLight = new THREE.PointLight(0x38BDF8, 0.6);
    cyanLight.position.set(-150, 50, -150);
    scene.add(cyanLight);

    const magentaLight = new THREE.PointLight(0xEC4899, 0.4);
    magentaLight.position.set(150, 40, 150);
    scene.add(magentaLight);
}

/**
 * Setup environment objects (starfield, grid)
 * @param {THREE.Scene} scene
 * @param {Object} config
 * @returns {Array} - Array of created objects for cleanup
 */
function setupEnvironment(scene, config) {
    const objects = [];

    // --- Starfield Background ---
    const starsCount = config.starCount || 2000;
    if (starsCount > 0) {
        const starsGeometry = new THREE.BufferGeometry();
        const positions = new Float32Array(starsCount * 3);

        for (let i = 0; i < starsCount * 3; i += 3) {
            positions[i] = (Math.random() - 0.5) * 2000;
            positions[i + 1] = (Math.random() - 0.5) * 2000;
            positions[i + 2] = (Math.random() - 0.5) * 2000;
        }

        starsGeometry.setAttribute('position', new THREE.BufferAttribute(positions, 3));
        const starsMaterial = new THREE.PointsMaterial({
            color: 0x888888,
            size: 1,
            transparent: true,
            opacity: 0.6,
        });
        const stars = new THREE.Points(starsGeometry, starsMaterial);
        scene.add(stars);
        objects.push(stars);
    }


    return objects;
}

/**
 * Handle container resize
 * @param {THREE.PerspectiveCamera} camera
 * @param {THREE.WebGLRenderer} renderer
 * @param {number} width
 * @param {number} height
 */
export function handleResize(camera, renderer, width, height) {
    if (width === 0 || height === 0) return;

    camera.aspect = width / height;
    camera.updateProjectionMatrix();
    renderer.setSize(width, height);
}

/**
 * SceneManager class for OOP-style usage
 */
export class SceneManager {
    constructor(container, options = {}) {
        const result = createScene(container, options);
        this.scene = result.scene;
        this.camera = result.camera;
        this.renderer = result.renderer;
        this.controls = result.controls;
        this._dispose = result.dispose;
        this.container = container;
    }

    resize(width, height) {
        handleResize(this.camera, this.renderer, width, height);
    }

    render() {
        this.renderer.render(this.scene, this.camera);
    }

    update() {
        this.controls.update();
    }

    dispose() {
        this._dispose();
    }
}
