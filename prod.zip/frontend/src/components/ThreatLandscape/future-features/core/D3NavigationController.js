/**
 * D3NavigationController
 * Handles camera navigation using D3.js zoom behavior for map-like control
 * Bridges 2D D3 interactions with 3D Three.js camera
 */

import * as THREE from 'three';
import * as d3 from 'd3';

export class D3NavigationController {
    constructor(camera, renderer, controls, config = {}) {
        this.camera = camera;
        this.renderer = renderer;
        this.orbitControls = controls;

        this.config = {
            minScale: 1,
            maxScale: 50,
            minZoom: 10,
            maxZoom: 2000,
            diveThreshold: 200, // Zoom level to trigger dive behavior
            onZoom: null,
            onZoomStart: null,
            onZoomEnd: null,
            ...config
        };

        this.zoomBehavior = null;
        this.isActive = false;

        // Initial camera state
        this.initialDistance = camera.position.distanceTo(this.orbitControls.target);
        this.targetDistance = this.initialDistance;
        this.lastTransform = d3.zoomIdentity;
    }

    /**
     * Initialize D3 zoom behavior
     */
    initialize() {
        const canvas = this.renderer.domElement;

        this.zoomBehavior = d3.zoom()
            .scaleExtent([this.config.minScale, this.config.maxScale]) // Abstract scale factor
            .on('start', () => {
                this.isActive = true;
                document.body.style.cursor = 'move';
                if (this.config.onZoomStart) {
                    this.config.onZoomStart(this.getZoomState());
                }
            })
            .on('zoom', (event) => {
                this.handleZoom(event);
            })
            .on('end', () => {
                this.isActive = false;
                document.body.style.cursor = 'default';
                if (this.config.onZoomEnd) {
                    this.config.onZoomEnd(this.getZoomState());
                }
            });

        d3.select(canvas)
            .call(this.zoomBehavior)
            // Disable double-click zoom to prevent conflict
            .on('dblclick.zoom', null);

        // Set initial transform
        // We use an abstract scale where 1 = initial view
        d3.select(canvas).call(
            this.zoomBehavior.transform,
            d3.zoomIdentity
        );

        this.lastTransform = d3.zoomIdentity;
    }

    /**
     * Handle D3 zoom event
     * Bridges 2D zoom/pan to 3D camera movement
     */
    handleZoom(event) {
        if (!event.transform) return;

        const { k, x, y } = event.transform;
        const transform = event.transform;
        this.lastTransform = transform;

        // 1. Zoom Logic (Dolly)
        // Map D3 scale (k) to Camera distance
        // Higher k = Closer (Smaller distance)
        const newDistance = this.initialDistance / k;

        // Clamp zoom
        if (newDistance < this.config.minZoom || newDistance > this.config.maxZoom) return;

        // 2. Pan Logic/Zoom-to-Cursor
        // This is complex in 3D. We basically want the world point under the mouse 
        // to stay under the mouse.

        // We can approximate this by moving the camera on the X/Z plane (assuming Y is up in 3D world, 
        // but often Z is up in graphs... in this project Y is up, X/Z is the floor).

        // Standard D3 pan logic assumes 2D plane. 
        // In 3D isometric view, panning X/Y on screen maps to moving X/Z in world.

        // For now, let's implement a straightforward "Move Camera" approach based on deltas
        // If we want true "zoom to cursor", we need raycasting logic

        if (event.sourceEvent) {
            const { movementX, movementY } = event.sourceEvent;

            // If this is a mouse interaction
            if (movementX !== undefined) {
                // It's a drag/pan
                // Rotate movement vector by camera azimuth to pan relative to view
                const panSpeed = newDistance / 1000; // Scale pan speed with distance

                const forward = new THREE.Vector3();
                this.camera.getWorldDirection(forward);
                forward.y = 0;
                forward.normalize();

                const right = new THREE.Vector3();
                right.crossVectors(forward, this.camera.up);

                // Move camera opposite to drag
                this.camera.position.addScaledVector(right, -movementX * panSpeed);
                this.camera.position.addScaledVector(forward, movementY * panSpeed);

                // Also move the OrbitControls target to keep them in sync
                this.orbitControls.target.addScaledVector(right, -movementX * panSpeed);
                this.orbitControls.target.addScaledVector(forward, movementY * panSpeed);
            } else if (event.sourceEvent.type === 'wheel') {
                // It's a scroll/zoom
                // Zoom towards cursor logic
                const rect = this.renderer.domElement.getBoundingClientRect();
                const mouseX = ((event.sourceEvent.clientX - rect.left) / rect.width) * 2 - 1;
                const mouseY = -((event.sourceEvent.clientY - rect.top) / rect.height) * 2 + 1;

                const vector = new THREE.Vector3(mouseX, mouseY, 0.5);
                vector.unproject(this.camera);

                const dir = vector.sub(this.camera.position).normalize();
                const distance = (this.camera.position.y - newDistance) / dir.y; // Assuming Y is up-down axis for zoom

                // However, "Zoom" here is just changing Z/Y distance from target
                // Let's implement simpler dolly based on orbit controls
            }
        }

        // --- Simplified Robust Approach ---
        // Instead of manual math, let's leverage OrbitControls geometry but drive usage via D3

        // Use K to set distance
        // OrbitControls maintains distance to target.
        // We can just update the camera position relative to target to match new distance.
        const dir = new THREE.Vector3().subVectors(this.camera.position, this.orbitControls.target).normalize();
        this.camera.position.copy(this.orbitControls.target).add(dir.multiplyScalar(newDistance));

        if (this.config.onZoom) {
            this.config.onZoom(this.getZoomState());
        }
    }

    getZoomState() {
        const distance = this.camera.position.distanceTo(this.orbitControls.target);
        const k = this.lastTransform?.k || 1;
        return { k, distance };
    }

    sync() {
        if (!this.zoomBehavior) return;
        const distance = this.camera.position.distanceTo(this.orbitControls.target);
        const k = this.initialDistance / Math.max(distance, 1);
        const clampedK = Math.min(this.config.maxScale, Math.max(this.config.minScale, k));
        const nextTransform = d3.zoomIdentity.scale(clampedK);

        d3.select(this.renderer.domElement).call(
            this.zoomBehavior.transform,
            nextTransform
        );
        this.lastTransform = nextTransform;
    }

    dispose() {
        d3.select(this.renderer.domElement).on('.zoom', null);
        this.isActive = false;
    }
}
