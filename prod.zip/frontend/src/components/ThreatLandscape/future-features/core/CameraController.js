/**
 * CameraController
 * Handles camera animations, fly-to effects, zoom, and focus operations
 */

import * as THREE from 'three';
import TWEEN from '@tweenjs/tween.js';

/**
 * Animate camera to a target position with smooth easing
 * @param {THREE.PerspectiveCamera} camera
 * @param {OrbitControls} controls
 * @param {THREE.Vector3} targetPosition - Where the camera should move to
 * @param {THREE.Vector3} lookAt - What the camera should look at
 * @param {number} duration - Animation duration in milliseconds
 * @returns {Promise} - Resolves when animation completes
 */
export function flyToPosition(camera, controls, targetPosition, lookAt, duration = 1500) {
    return new Promise((resolve) => {
        controls.autoRotate = false;

        const startPos = {
            x: camera.position.x,
            y: camera.position.y,
            z: camera.position.z,
        };
        const startTarget = {
            x: controls.target.x,
            y: controls.target.y,
            z: controls.target.z,
        };

        // Animate camera position
        new TWEEN.Tween(startPos)
            .to({ x: targetPosition.x, y: targetPosition.y, z: targetPosition.z }, duration)
            .easing(TWEEN.Easing.Cubic.InOut)
            .onUpdate(() => {
                camera.position.set(startPos.x, startPos.y, startPos.z);
            })
            .start();

        // Animate camera target
        new TWEEN.Tween(startTarget)
            .to({ x: lookAt.x, y: lookAt.y, z: lookAt.z }, duration)
            .easing(TWEEN.Easing.Cubic.InOut)
            .onUpdate(() => {
                controls.target.set(startTarget.x, startTarget.y, startTarget.z);
                controls.update();
            })
            .onComplete(() => {
                resolve();
            })
            .start();
    });
}

/**
 * Fly camera to focus on a specific node mesh
 * @param {THREE.PerspectiveCamera} camera
 * @param {OrbitControls} controls
 * @param {THREE.Mesh} mesh - The node mesh to focus on
 * @param {number} duration - Animation duration in milliseconds
 * @returns {Promise}
 */
export function flyToNode(camera, controls, mesh, duration = 1500) {
    const nodePos = mesh.position.clone();
    const distRatio = 1.8;

    // Calculate position in front of node
    const cameraOffset = new THREE.Vector3(
        nodePos.x * distRatio + 20,
        nodePos.y + 15,
        nodePos.z * distRatio + 20
    );

    return flyToPosition(camera, controls, cameraOffset, nodePos, duration);
}

/**
 * Zoom in by moving camera forward
 * @param {THREE.PerspectiveCamera} camera
 * @param {OrbitControls} controls
 * @param {number} amount - Distance to zoom
 */
export function zoomIn(camera, controls, amount = 20) {
    const direction = new THREE.Vector3();
    camera.getWorldDirection(direction);
    camera.position.addScaledVector(direction, amount);
    controls.update();
}

/**
 * Zoom out by moving camera backward
 * @param {THREE.PerspectiveCamera} camera
 * @param {OrbitControls} controls
 * @param {number} amount - Distance to zoom
 */
export function zoomOut(camera, controls, amount = 20) {
    const direction = new THREE.Vector3();
    camera.getWorldDirection(direction);
    camera.position.addScaledVector(direction, -amount);
    controls.update();
}

/**
 * Fit all nodes in the camera view
 * @param {THREE.PerspectiveCamera} camera
 * @param {OrbitControls} controls
 * @param {Array<THREE.Mesh>} nodeMeshes - Array of node meshes
 * @param {number} duration - Animation duration in milliseconds
 * @returns {Promise}
 */
export function fitToView(camera, controls, nodeMeshes, duration = 1500) {
    if (nodeMeshes.length === 0) return Promise.resolve();

    // Calculate bounding box of all nodes
    const box = new THREE.Box3();
    nodeMeshes.forEach(mesh => {
        // CRITICAL: Ensure world matrix is up to date before calculating box
        // The physics engine updates positions, but the matrix might not be synced yet
        mesh.updateMatrixWorld(true);
        box.expandByObject(mesh);
    });

    const center = new THREE.Vector3();
    box.getCenter(center);

    const size = box.getSize(new THREE.Vector3());
    const maxDim = Math.max(size.x, size.y, size.z, 50); // Ensure minimum zoom distance
    const fov = camera.fov * (Math.PI / 180);
    const cameraDistance = Math.abs(maxDim / Math.sin(fov / 2)) * 0.8;

    const targetPosition = new THREE.Vector3(
        center.x + cameraDistance * 0.5,
        center.y + cameraDistance * 0.4,
        center.z + cameraDistance * 0.5
    );

    return flyToPosition(camera, controls, targetPosition, center, duration);
}

/**
 * Set camera to a specific preset view
 * @param {THREE.PerspectiveCamera} camera
 * @param {OrbitControls} controls
 * @param {string} viewType - 'TOP', 'SIDE', 'FRONT', 'ISO'
 * @param {number} duration
 */
export function setCameraView(camera, controls, viewType, duration = 1500) {
    const distance = controls.object.position.distanceTo(controls.target);
    const d = Math.max(distance, 100);

    let targetPos;

    switch (viewType) {
        case 'TOP':
            targetPos = new THREE.Vector3(0, d, 0); // Top-down
            break;
        case 'SIDE':
            targetPos = new THREE.Vector3(d, 0, 0); // Right side
            break;
        case 'FRONT':
            targetPos = new THREE.Vector3(0, 0, d); // Front
            break;
        case 'ISO':
        default:
            // Isometricish
            const iso = d / Math.sqrt(3);
            targetPos = new THREE.Vector3(iso, iso * 0.8, iso);
            break;
    }

    return flyToPosition(camera, controls, targetPos, controls.target, duration);
}

/**
 * Export the current view as PNG
 * @param {THREE.WebGLRenderer} renderer
 * @param {string} filename - Optional custom filename
 */
export function exportToPNG(renderer, filename) {
    const defaultFilename = `athena-holodeck-${new Date().toISOString().slice(0, 10)}.png`;
    const dataURL = renderer.domElement.toDataURL('image/png');
    const link = document.createElement('a');
    link.download = filename || defaultFilename;
    link.href = dataURL;
    link.click();
}

/**
 * CameraController class for OOP-style usage
 */
export class CameraController {
    constructor(camera, controls) {
        this.camera = camera;
        this.controls = controls;
    }

    flyToPosition(targetPosition, lookAt, duration = 1500) {
        return flyToPosition(this.camera, this.controls, targetPosition, lookAt, duration);
    }

    flyToNode(mesh, duration = 1500) {
        return flyToNode(this.camera, this.controls, mesh, duration);
    }

    zoomIn(amount = 20) {
        zoomIn(this.camera, this.controls, amount);
    }

    zoomOut(amount = 20) {
        zoomOut(this.camera, this.controls, amount);
    }

    fitToView(nodeMeshes, duration = 1500) {
        return fitToView(this.camera, this.controls, nodeMeshes, duration);
    }

    setCameraView(viewType, duration = 1500) {
        return setCameraView(this.camera, this.controls, viewType, duration);
    }

    setAutoRotate(enabled) {
        this.controls.autoRotate = enabled;
    }

    update() {
        this.controls.update();
    }
}
