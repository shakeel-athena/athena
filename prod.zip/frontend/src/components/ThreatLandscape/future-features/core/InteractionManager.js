/**
 * InteractionManager
 * Handles user interactions: raycasting, hover, click, and drag controls
 */

import * as THREE from 'three';
import { DragControls } from 'three/examples/jsm/controls/DragControls';

/**
 * InteractionManager class for handling 3D interactions
 */
export class InteractionManager {
    constructor(camera, renderer, orbitControls, config = {}) {
        this.camera = camera;
        this.renderer = renderer;
        this.orbitControls = orbitControls;
        this.config = {
            hoverThrottle: 16, // ~60fps
            ...config,
        };

        this.raycaster = new THREE.Raycaster();
        this.mouse = new THREE.Vector2();
        this.mouseScreen = { x: 0, y: 0 }; // Initialize with default values
        this.nodeMeshes = [];
        this.hoveredNode = null;
        this.dragControls = null;

        // Callbacks
        this.onHover = null;
        this.onHoverEnd = null;
        this.onClick = null;
        this.onDragStart = null;
        this.onDragEnd = null;

        // Bound event handlers
        this._onMouseMove = this._handleMouseMove.bind(this);
        this._onClick = this._handleClick.bind(this);

        this.setupEvents();
    }

    /**
     * Set the node meshes to interact with
     * @param {Array<THREE.Mesh>} meshes
     */
    setNodeMeshes(meshes) {
        this.nodeMeshes = meshes;
        this.setupDragControls();
    }

    /**
     * Setup event listeners
     */
    setupEvents() {
        this.renderer.domElement.addEventListener('mousemove', this._onMouseMove);
        this.renderer.domElement.addEventListener('click', this._onClick);
    }

    /**
     * Setup drag controls for node repositioning
     */
    setupDragControls() {
        if (this.dragControls) {
            this.dragControls.dispose();
        }

        if (this.nodeMeshes.length === 0) return;

        this.dragControls = new DragControls(
            this.nodeMeshes,
            this.camera,
            this.renderer.domElement
        );

        this.dragControls.addEventListener('dragstart', (event) => {
            this.orbitControls.enabled = false;
            this.orbitControls.autoRotate = false;
            document.body.style.cursor = 'grabbing';

            if (this.onDragStart) {
                this.onDragStart(event.object);
            }
        });

        this.dragControls.addEventListener('dragend', (event) => {
            this.orbitControls.enabled = true;
            document.body.style.cursor = 'default';

            if (this.onDragEnd) {
                this.onDragEnd(event.object);
            }
        });
    }

    /**
     * Handle mouse move for hover detection
     * @param {MouseEvent} event
     */
    _handleMouseMove(event) {
        const rect = this.renderer.domElement.getBoundingClientRect();
        this.mouse.x = ((event.clientX - rect.left) / rect.width) * 2 - 1;
        this.mouse.y = -((event.clientY - rect.top) / rect.height) * 2 + 1;

        // Store screen coordinates for tooltip positioning
        this.mouseScreen = { x: event.clientX, y: event.clientY };
    }

    /**
     * Handle click events
     * @param {MouseEvent} event
     */
    _handleClick(event) {
        if (this.onClick) {
            this.onClick(this.hoveredNode);
        }
    }

    /**
     * Update raycasting (call in animation loop)
     */
    update() {
        if (this.nodeMeshes.length === 0) return;

        this.raycaster.setFromCamera(this.mouse, this.camera);
        const intersects = this.raycaster.intersectObjects(this.nodeMeshes);

        if (intersects.length > 0) {
            const object = intersects[0].object;

            if (this.hoveredNode !== object) {
                // Hover ended on previous node
                if (this.hoveredNode && this.onHoverEnd) {
                    this.onHoverEnd(this.hoveredNode);
                }

                // New hover started
                this.hoveredNode = object;
                document.body.style.cursor = 'pointer';

                if (this.onHover) {
                    this.onHover(this.hoveredNode, this.mouseScreen);
                }
            }
        } else {
            if (this.hoveredNode) {
                if (this.onHoverEnd) {
                    this.onHoverEnd(this.hoveredNode);
                }
                this.hoveredNode = null;
                document.body.style.cursor = 'default';
            }
        }
    }

    /**
     * Get currently hovered node
     * @returns {THREE.Mesh|null}
     */
    getHoveredNode() {
        return this.hoveredNode;
    }

    /**
     * Get screen mouse position
     * @returns {{x: number, y: number}}
     */
    getMousePosition() {
        return this.mouseScreen || { x: 0, y: 0 };
    }

    /**
     * Set callback for hover events
     * @param {Function} callback - (mesh, screenPos) => void
     */
    setOnHover(callback) {
        this.onHover = callback;
    }

    /**
     * Set callback for hover end events
     * @param {Function} callback - (mesh) => void
     */
    setOnHoverEnd(callback) {
        this.onHoverEnd = callback;
    }

    /**
     * Set callback for click events
     * @param {Function} callback - (mesh) => void
     */
    setOnClick(callback) {
        this.onClick = callback;
    }

    /**
     * Set callback for drag start events
     * @param {Function} callback - (mesh) => void
     */
    setOnDragStart(callback) {
        this.onDragStart = callback;
    }

    /**
     * Set callback for drag end events
     * @param {Function} callback - (mesh) => void
     */
    setOnDragEnd(callback) {
        this.onDragEnd = callback;
    }

    /**
     * Dispose all resources and event listeners
     */
    dispose() {
        this.renderer.domElement.removeEventListener('mousemove', this._onMouseMove);
        this.renderer.domElement.removeEventListener('click', this._onClick);

        if (this.dragControls) {
            this.dragControls.dispose();
        }

        this.nodeMeshes = [];
        this.hoveredNode = null;
    }
}
