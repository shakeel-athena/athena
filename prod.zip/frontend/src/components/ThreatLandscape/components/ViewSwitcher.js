/**
 * ViewSwitcher Component
 * Toggle buttons for switching between Split and Concentric views
 */

import React from 'react';
import { EuiButtonGroup, EuiToolTip } from '@elastic/eui';

const VIEW_OPTIONS = [
  {
    id: 'split',
    label: 'Split View',
    iconType: 'visAreaStacked',
  },
  {
    id: 'concentric',
    label: 'Concentric',
    iconType: 'bullseye',
  }
];

const ViewSwitcher = ({ viewMode, onViewChange }) => {
  return (
    <EuiToolTip
      position="bottom"
      content={viewMode === 'split'
        ? 'Split View: Agents (left) vs External (right)'
        : 'Concentric View: Agents (inner) + External (outer)'}
    >
      <EuiButtonGroup
        legend="Topology view mode"
        options={VIEW_OPTIONS}
        idSelected={viewMode}
        onChange={onViewChange}
        buttonSize="compressed"
        isIconOnly
        color="text"
        css={{
          '.euiButtonGroupButton': {
            backgroundColor: 'rgba(30, 41, 59, 0.8)',
            border: '1px solid rgba(100, 116, 139, 0.3)',
            '&.euiButtonGroupButton-isSelected': {
              backgroundColor: 'rgba(96, 165, 250, 0.2)',
              borderColor: 'rgba(96, 165, 250, 0.5)',
            },
            '&:hover': {
              backgroundColor: 'rgba(51, 65, 85, 0.8)',
            }
          }
        }}
      />
    </EuiToolTip>
  );
};

export default ViewSwitcher;
