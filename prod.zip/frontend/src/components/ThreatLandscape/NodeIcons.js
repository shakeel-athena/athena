import React from 'react';
import {
    FaServer,
    FaDatabase,
    FaGlobe,
    FaPrint,
    FaLaptop,
    FaDesktop,
    FaNetworkWired,
    FaDiagramProject,
    FaQuestion,
    FaWindows,
    FaApple,
    FaLinux,
    FaUbuntu,
    FaCentos,
    FaRedhat,
    FaFedora,
    FaSuse,
    FaDebian,
    FaSkullCrossbones,
    FaShieldHalved
} from 'react-icons/fa6';

const ICON_SIZE = 20;

// Helper to center react-icon within SVG
const CenteredIcon = ({ Icon, size, color }) => (
    <Icon
        size={size}
        color={color}
        x={-size / 2}
        y={-size / 2}
    // react-icons render as <svg>. 
    // SVGs nested inside <g> at 0,0 by default. 
    // passing x/y as props works for react-icons/fa6 which usually spreads props to inner svg
    />
);

/* 
 * NOTE: react-icons/fa6 components render standard <svg> elements.
 * We can nest them directly inside our parent <g> or <svg>.
 * foreignObject is NOT required and causes casing warnings in React.
 */

export const ServerIcon = ({ x, y, size = ICON_SIZE, color }) => (
    <g transform={`translate(${x}, ${y})`}>
        <CenteredIcon Icon={FaServer} size={size} color={color} />
    </g>
);

export const DatabaseIcon = ({ x, y, size = ICON_SIZE, color }) => (
    <g transform={`translate(${x}, ${y})`}>
        <CenteredIcon Icon={FaDatabase} size={size} color={color} />
    </g>
);

export const WorldIcon = ({ x, y, size = ICON_SIZE, color }) => (
    <g transform={`translate(${x}, ${y})`}>
        <CenteredIcon Icon={FaGlobe} size={size} color={color} />
    </g>
);

export const PrinterIcon = ({ x, y, size = ICON_SIZE, color }) => (
    <g transform={`translate(${x}, ${y})`}>
        <CenteredIcon Icon={FaPrint} size={size} color={color} />
    </g>
);

export const LaptopIcon = ({ x, y, size = ICON_SIZE, color }) => (
    <g transform={`translate(${x}, ${y})`}>
        <CenteredIcon Icon={FaLaptop} size={size} color={color} />
    </g>
);

export const DesktopIcon = ({ x, y, size = ICON_SIZE, color }) => (
    <g transform={`translate(${x}, ${y})`}>
        <CenteredIcon Icon={FaDesktop} size={size} color={color} />
    </g>
);

export const SubnetIcon = ({ x, y, size = ICON_SIZE, color }) => (
    <g transform={`translate(${x}, ${y})`}>
        <CenteredIcon Icon={FaDiagramProject} size={size} color={color} />
    </g>
);

export const NetworkIcon = ({ x, y, size = ICON_SIZE, color }) => (
    <g transform={`translate(${x}, ${y})`}>
        <CenteredIcon Icon={FaNetworkWired} size={size} color={color} />
    </g>
);

export const DefaultIcon = ({ x, y, size = ICON_SIZE, color }) => (
    <g transform={`translate(${x}, ${y})`}>
        <CenteredIcon Icon={FaQuestion} size={size * 0.8} color={color} />
    </g>
);

// --- Threat Actor Icons ---
export const ExternalThreatIcon = ({ x, y, size = ICON_SIZE, color }) => (
    <g transform={`translate(${x}, ${y})`}>
        <CenteredIcon Icon={FaSkullCrossbones} size={size} color={color} />
    </g>
);

export const InternalThreatIcon = ({ x, y, size = ICON_SIZE, color }) => (
    <g transform={`translate(${x}, ${y})`}>
        <CenteredIcon Icon={FaShieldHalved} size={size} color={color} />
    </g>
);

export const getIconForRole = (role) => {
    const r = String(role || '').toLowerCase();

    if (r.includes('subnet')) return SubnetIcon;
    if (r.includes('network') || r.includes('firewall')) return NetworkIcon;
    if (r.includes('printer')) return PrinterIcon;
    if (r.includes('server') || r.includes('siem')) return ServerIcon;
    if (r.includes('website') || r.includes('web') || r.includes('http') || r.includes('external')) return WorldIcon;
    if (r.includes('desktop') || r.includes('workstation') || r.includes('pc') || r.includes('endpoint')) return DesktopIcon;
    if (r.includes('laptop')) return LaptopIcon;
    if (r.includes('database') || r.includes('db')) return DatabaseIcon;

    return DesktopIcon; // Default to desktop icon instead of question mark
};

// --- OS Icons ---
export const WindowsIcon = ({ x, y, size = ICON_SIZE, color }) => (
    <g transform={`translate(${x}, ${y})`}>
        <CenteredIcon Icon={FaWindows} size={size} color={color} />
    </g>
);

export const AppleIcon = ({ x, y, size = ICON_SIZE, color }) => (
    <g transform={`translate(${x}, ${y})`}>
        <CenteredIcon Icon={FaApple} size={size} color={color} />
    </g>
);

export const LinuxIcon = ({ x, y, size = ICON_SIZE, color }) => (
    <g transform={`translate(${x}, ${y})`}>
        <CenteredIcon Icon={FaLinux} size={size} color={color} />
    </g>
);

export const UbuntuIcon = ({ x, y, size = ICON_SIZE, color }) => (
    <g transform={`translate(${x}, ${y})`}>
        <CenteredIcon Icon={FaUbuntu} size={size} color={color} />
    </g>
);

export const CentosIcon = ({ x, y, size = ICON_SIZE, color }) => (
    <g transform={`translate(${x}, ${y})`}>
        <CenteredIcon Icon={FaCentos} size={size} color={color} />
    </g>
);

export const RedhatIcon = ({ x, y, size = ICON_SIZE, color }) => (
    <g transform={`translate(${x}, ${y})`}>
        <CenteredIcon Icon={FaRedhat} size={size} color={color} />
    </g>
);

export const FedoraIcon = ({ x, y, size = ICON_SIZE, color }) => (
    <g transform={`translate(${x}, ${y})`}>
        <CenteredIcon Icon={FaFedora} size={size} color={color} />
    </g>
);

export const SuseIcon = ({ x, y, size = ICON_SIZE, color }) => (
    <g transform={`translate(${x}, ${y})`}>
        <CenteredIcon Icon={FaSuse} size={size} color={color} />
    </g>
);

export const DebianIcon = ({ x, y, size = ICON_SIZE, color }) => (
    <g transform={`translate(${x}, ${y})`}>
        <CenteredIcon Icon={FaDebian} size={size} color={color} />
    </g>
);

/**
 * Returns the appropriate OS icon component based on the OS string
 * @param {string} os - The operating system name (e.g., "Windows 10", "Ubuntu 22.04", "macOS")
 * @returns {React.Component} - The icon component for the OS
 */
export const getIconForOS = (os) => {
    const o = String(os || '').toLowerCase();

    // Windows variants
    if (o.includes('windows') || o.includes('win32') || o.includes('win64')) return WindowsIcon;

    // macOS / Apple variants
    if (o.includes('macos') || o.includes('mac os') || o.includes('darwin') ||
        o.includes('osx') || o.includes('os x') || o.includes('apple')) return AppleIcon;

    // Linux distros (specific first)
    if (o.includes('ubuntu')) return UbuntuIcon;
    if (o.includes('centos')) return CentosIcon;
    if (o.includes('redhat') || o.includes('red hat') || o.includes('rhel')) return RedhatIcon;
    if (o.includes('fedora')) return FedoraIcon;
    if (o.includes('suse') || o.includes('opensuse')) return SuseIcon;
    if (o.includes('debian')) return DebianIcon;

    // Generic Linux
    if (o.includes('linux')) return LinuxIcon;

    // Default to generic Linux icon if unknown
    return null;
};
