import React, { useState, useMemo } from 'react';
import { EuiToolTip, EuiButtonGroup } from '@elastic/eui';

/**
 * MITRE ATT&CK Overlay Component
 * Visualizes attack tactics on the network topology
 */

// MITRE ATT&CK Tactics with colors
export const MITRE_TACTICS = {
  'reconnaissance': { name: 'Reconnaissance', color: '#9b59b6', id: 'TA0043' },
  'resource-development': { name: 'Resource Development', color: '#8e44ad', id: 'TA0042' },
  'initial-access': { name: 'Initial Access', color: '#e74c3c', id: 'TA0001' },
  'execution': { name: 'Execution', color: '#c0392b', id: 'TA0002' },
  'persistence': { name: 'Persistence', color: '#d35400', id: 'TA0003' },
  'privilege-escalation': { name: 'Privilege Escalation', color: '#e67e22', id: 'TA0004' },
  'defense-evasion': { name: 'Defense Evasion', color: '#f39c12', id: 'TA0005' },
  'credential-access': { name: 'Credential Access', color: '#f1c40f', id: 'TA0006' },
  'discovery': { name: 'Discovery', color: '#27ae60', id: 'TA0007' },
  'lateral-movement': { name: 'Lateral Movement', color: '#2ecc71', id: 'TA0008' },
  'collection': { name: 'Collection', color: '#1abc9c', id: 'TA0009' },
  'command-and-control': { name: 'Command & Control', color: '#16a085', id: 'TA0011' },
  'exfiltration': { name: 'Exfiltration', color: '#3498db', id: 'TA0010' },
  'impact': { name: 'Impact', color: '#2980b9', id: 'TA0040' }
};

// Common signature patterns mapped to MITRE tactics
const SIGNATURE_TACTIC_MAP = {
  // Reconnaissance
  'scan': 'reconnaissance',
  'probe': 'reconnaissance',
  'enumeration': 'reconnaissance',
  'nmap': 'reconnaissance',
  'port scan': 'reconnaissance',

  // Initial Access
  'exploit': 'initial-access',
  'phishing': 'initial-access',
  'spearphishing': 'initial-access',
  'drive-by': 'initial-access',
  'webshell': 'initial-access',

  // Execution
  'powershell': 'execution',
  'cmd': 'execution',
  'script': 'execution',
  'wscript': 'execution',
  'mshta': 'execution',

  // Persistence
  'registry': 'persistence',
  'scheduled task': 'persistence',
  'startup': 'persistence',
  'service': 'persistence',

  // Privilege Escalation
  'privilege': 'privilege-escalation',
  'sudo': 'privilege-escalation',
  'elevation': 'privilege-escalation',
  'uac bypass': 'privilege-escalation',

  // Defense Evasion
  'obfuscation': 'defense-evasion',
  'bypass': 'defense-evasion',
  'disable': 'defense-evasion',
  'clear log': 'defense-evasion',

  // Credential Access
  'credential': 'credential-access',
  'password': 'credential-access',
  'brute force': 'credential-access',
  'mimikatz': 'credential-access',
  'kerberos': 'credential-access',
  'ntlm': 'credential-access',
  'ssh': 'credential-access',
  'rdp': 'credential-access',

  // Discovery
  'discovery': 'discovery',
  'whoami': 'discovery',
  'systeminfo': 'discovery',
  'net user': 'discovery',

  // Lateral Movement
  'lateral': 'lateral-movement',
  'psexec': 'lateral-movement',
  'wmi': 'lateral-movement',
  'remote': 'lateral-movement',
  'smb': 'lateral-movement',

  // Collection
  'keylog': 'collection',
  'screenshot': 'collection',
  'clipboard': 'collection',
  'archive': 'collection',

  // Command & Control
  'c2': 'command-and-control',
  'beacon': 'command-and-control',
  'cobalt': 'command-and-control',
  'dns tunnel': 'command-and-control',
  'http tunnel': 'command-and-control',
  'malware': 'command-and-control',
  'trojan': 'command-and-control',
  'backdoor': 'command-and-control',
  'rat': 'command-and-control',

  // Exfiltration
  'exfil': 'exfiltration',
  'data transfer': 'exfiltration',
  'upload': 'exfiltration',

  // Impact
  'ransomware': 'impact',
  'wiper': 'impact',
  'destroy': 'impact',
  'encrypt': 'impact',
  'ddos': 'impact',
  'dos': 'impact'
};

/**
 * Map an incident/alert to MITRE tactics
 */
export const mapToMitreTactic = (incident) => {
  if (!incident) return null;

  const searchText = (
    (incident.title || '') +
    (incident.summary || '') +
    (incident.model || '') +
    (incident.category || '')
  ).toLowerCase();

  // Check for explicit MITRE references
  for (const [tacticKey, tactic] of Object.entries(MITRE_TACTICS)) {
    if (searchText.includes(tactic.id.toLowerCase()) ||
        searchText.includes(tacticKey.replace('-', ' '))) {
      return tacticKey;
    }
  }

  // Check signature patterns
  for (const [pattern, tactic] of Object.entries(SIGNATURE_TACTIC_MAP)) {
    if (searchText.includes(pattern)) {
      return tactic;
    }
  }

  return null;
};

/**
 * Get MITRE tactic color for a node based on its incidents
 */
export const getNodeMitreColor = (node, incidents) => {
  if (!node || !incidents?.length) return null;

  // Find incidents for this node
  const nodeIncidents = incidents.filter(inc =>
    inc.deviceId === node.id ||
    inc.title?.includes(node.label) ||
    inc.title?.includes(node.ip)
  );

  if (!nodeIncidents.length) return null;

  // Map all incidents to tactics
  const tactics = nodeIncidents
    .map(mapToMitreTactic)
    .filter(Boolean);

  if (!tactics.length) return null;

  // Priority order (later in kill chain = more severe)
  const tacticPriority = [
    'impact', 'exfiltration', 'command-and-control',
    'lateral-movement', 'collection', 'credential-access',
    'defense-evasion', 'privilege-escalation', 'persistence',
    'execution', 'initial-access', 'resource-development', 'reconnaissance'
  ];

  // Return highest priority tactic color
  for (const tactic of tacticPriority) {
    if (tactics.includes(tactic)) {
      return MITRE_TACTICS[tactic].color;
    }
  }

  return null;
};

/**
 * MITRE Overlay Legend Component
 */
const MitreOverlay = ({
  incidents = [],
  isEnabled = false,
  onToggle,
  selectedTactic = null,
  onTacticSelect
}) => {
  // Calculate tactic counts
  const tacticStats = useMemo(() => {
    const counts = {};

    incidents.forEach(inc => {
      const tactic = mapToMitreTactic(inc);
      if (tactic) {
        counts[tactic] = (counts[tactic] || 0) + 1;
      }
    });

    return Object.entries(MITRE_TACTICS)
      .map(([key, value]) => ({
        key,
        ...value,
        count: counts[key] || 0
      }))
      .filter(t => t.count > 0)
      .sort((a, b) => b.count - a.count);
  }, [incidents]);

  if (!isEnabled) {
    return (
      <button
        onClick={onToggle}
        style={{
          background: '#2d3142',
          border: '1px solid #3d4152',
          borderRadius: '6px',
          padding: '8px 12px',
          color: '#8e9fbc',
          fontSize: '12px',
          cursor: 'pointer',
          display: 'flex',
          alignItems: 'center',
          gap: '6px'
        }}
      >
        <span>ATT&CK</span>
        <span style={{
          background: '#1a1d29',
          padding: '2px 6px',
          borderRadius: '3px',
          fontSize: '10px'
        }}>
          OFF
        </span>
      </button>
    );
  }

  return (
    <div style={{
      background: '#1a1d29',
      borderRadius: '8px',
      border: '1px solid #2d3142',
      padding: '12px',
      minWidth: '200px'
    }}>
      {/* Header */}
      <div style={{
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'space-between',
        marginBottom: '12px'
      }}>
        <span style={{ color: '#fff', fontSize: '13px', fontWeight: 600 }}>
          MITRE ATT&CK
        </span>
        <button
          onClick={onToggle}
          style={{
            background: '#f6726a20',
            border: 'none',
            borderRadius: '4px',
            padding: '4px 8px',
            color: '#f6726a',
            fontSize: '10px',
            cursor: 'pointer'
          }}
        >
          Disable
        </button>
      </div>

      {/* Tactic List */}
      <div style={{ maxHeight: '300px', overflowY: 'auto' }}>
        {tacticStats.length === 0 ? (
          <div style={{ color: '#64748b', fontSize: '11px', textAlign: 'center', padding: '16px' }}>
            No MITRE tactics detected
          </div>
        ) : (
          tacticStats.map(tactic => (
            <EuiToolTip
              key={tactic.key}
              content={`${tactic.name} (${tactic.id}): ${tactic.count} alerts`}
              position="left"
            >
              <div
                onClick={() => onTacticSelect?.(selectedTactic === tactic.key ? null : tactic.key)}
                style={{
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'space-between',
                  padding: '8px',
                  marginBottom: '4px',
                  borderRadius: '4px',
                  cursor: 'pointer',
                  background: selectedTactic === tactic.key ? `${tactic.color}20` : 'transparent',
                  border: selectedTactic === tactic.key ? `1px solid ${tactic.color}` : '1px solid transparent',
                  transition: 'all 0.15s ease'
                }}
              >
                <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                  <div style={{
                    width: '12px',
                    height: '12px',
                    borderRadius: '3px',
                    background: tactic.color
                  }} />
                  <span style={{ color: '#fff', fontSize: '12px' }}>
                    {tactic.name}
                  </span>
                </div>
                <span style={{
                  background: '#2d3142',
                  color: '#8e9fbc',
                  padding: '2px 6px',
                  borderRadius: '10px',
                  fontSize: '10px',
                  fontWeight: 600
                }}>
                  {tactic.count}
                </span>
              </div>
            </EuiToolTip>
          ))
        )}
      </div>

      {/* Kill Chain Progress */}
      {tacticStats.length > 0 && (
        <div style={{
          marginTop: '12px',
          paddingTop: '12px',
          borderTop: '1px solid #2d3142'
        }}>
          <div style={{ color: '#8e9fbc', fontSize: '10px', marginBottom: '8px' }}>
            KILL CHAIN COVERAGE
          </div>
          <div style={{ display: 'flex', gap: '2px' }}>
            {Object.entries(MITRE_TACTICS).map(([key, tactic]) => {
              const hasAlerts = tacticStats.some(t => t.key === key);
              return (
                <EuiToolTip key={key} content={tactic.name} position="top">
                  <div style={{
                    flex: 1,
                    height: '6px',
                    background: hasAlerts ? tactic.color : '#2d3142',
                    borderRadius: '1px',
                    opacity: hasAlerts ? 1 : 0.3
                  }} />
                </EuiToolTip>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
};

export default MitreOverlay;
