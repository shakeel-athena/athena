import React, { useState, useCallback, useMemo, useRef, useEffect } from 'react';
import { EuiFieldSearch, EuiButtonIcon, EuiToolTip } from '@elastic/eui';

/**
 * IOC Search Bar Component
 * Enables searching for Indicators of Compromise across the topology
 * Supports IPs, hashes, domains, signatures, and CIDR ranges
 */
const IOCSearchBar = ({
  nodes = [],
  incidents = [],
  onSearchResults,
  onHighlightNodes,
  onNavigateToEvents
}) => {
  const [searchValue, setSearchValue] = useState('');
  const [isSearching, setIsSearching] = useState(false);
  const [results, setResults] = useState(null);
  const [showResults, setShowResults] = useState(false);
  const searchRef = useRef(null);

  // Click outside to close results
  useEffect(() => {
    const handleClickOutside = (e) => {
      if (searchRef.current && !searchRef.current.contains(e.target)) {
        setShowResults(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  // Detect IOC type from search value
  const detectIOCType = useCallback((value) => {
    if (!value) return null;

    const trimmed = value.trim();

    // CIDR notation (e.g., 192.168.1.0/24)
    if (/^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}\/\d{1,2}$/.test(trimmed)) {
      return 'cidr';
    }

    // IP address
    if (/^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$/.test(trimmed)) {
      return 'ip';
    }

    // Partial IP (subnet search)
    if (/^\d{1,3}\.\d{1,3}\.\d{1,3}\.?$/.test(trimmed) ||
        /^\d{1,3}\.\d{1,3}\.?$/.test(trimmed)) {
      return 'partial_ip';
    }

    // MD5 hash
    if (/^[a-fA-F0-9]{32}$/.test(trimmed)) {
      return 'md5';
    }

    // SHA1 hash
    if (/^[a-fA-F0-9]{40}$/.test(trimmed)) {
      return 'sha1';
    }

    // SHA256 hash
    if (/^[a-fA-F0-9]{64}$/.test(trimmed)) {
      return 'sha256';
    }

    // Domain
    if (/^[a-zA-Z0-9][a-zA-Z0-9-_.]+\.[a-zA-Z]{2,}$/.test(trimmed)) {
      return 'domain';
    }

    // Default to general search
    return 'text';
  }, []);

  // Check if IP is in CIDR range
  const isIPInCIDR = useCallback((ip, cidr) => {
    if (!ip || !cidr) return false;

    const [cidrIP, maskBits] = cidr.split('/');
    const mask = parseInt(maskBits, 10);

    const ipToInt = (ipStr) => {
      return ipStr.split('.').reduce((acc, octet) => (acc << 8) + parseInt(octet, 10), 0) >>> 0;
    };

    const ipInt = ipToInt(ip);
    const cidrInt = ipToInt(cidrIP);
    const maskInt = ~((1 << (32 - mask)) - 1) >>> 0;

    return (ipInt & maskInt) === (cidrInt & maskInt);
  }, []);

  // Execute search
  const executeSearch = useCallback(() => {
    if (!searchValue.trim()) {
      setResults(null);
      setShowResults(false);
      onHighlightNodes?.([]);
      return;
    }

    setIsSearching(true);
    const iocType = detectIOCType(searchValue);
    const searchLower = searchValue.toLowerCase().trim();

    let matchedNodes = [];
    let matchedIncidents = [];

    switch (iocType) {
      case 'ip':
        // Exact IP match
        matchedNodes = nodes.filter(n => n.ip === searchValue.trim());
        matchedIncidents = incidents.filter(inc =>
          inc.srcIP === searchValue.trim() ||
          inc.deviceId === searchValue.trim() ||
          inc.title?.includes(searchValue.trim())
        );
        break;

      case 'partial_ip':
        // Partial IP / subnet match
        matchedNodes = nodes.filter(n => n.ip?.startsWith(searchValue.trim()));
        matchedIncidents = incidents.filter(inc =>
          inc.srcIP?.startsWith(searchValue.trim()) ||
          inc.deviceId?.startsWith(searchValue.trim())
        );
        break;

      case 'cidr':
        // CIDR range match
        matchedNodes = nodes.filter(n => n.ip && isIPInCIDR(n.ip, searchValue.trim()));
        matchedIncidents = incidents.filter(inc =>
          (inc.srcIP && isIPInCIDR(inc.srcIP, searchValue.trim())) ||
          (inc.deviceId && isIPInCIDR(inc.deviceId, searchValue.trim()))
        );
        break;

      case 'md5':
      case 'sha1':
      case 'sha256':
        // Hash search - check in incident details
        matchedIncidents = incidents.filter(inc =>
          inc.summary?.toLowerCase().includes(searchLower) ||
          inc.title?.toLowerCase().includes(searchLower)
        );
        // Get related nodes
        matchedNodes = nodes.filter(n =>
          matchedIncidents.some(inc =>
            inc.deviceId === n.id || inc.title?.includes(n.ip)
          )
        );
        break;

      case 'domain':
        // Domain search
        matchedIncidents = incidents.filter(inc =>
          inc.summary?.toLowerCase().includes(searchLower) ||
          inc.title?.toLowerCase().includes(searchLower)
        );
        matchedNodes = nodes.filter(n =>
          n.label?.toLowerCase().includes(searchLower) ||
          matchedIncidents.some(inc =>
            inc.deviceId === n.id || inc.title?.includes(n.ip)
          )
        );
        break;

      default:
        // General text search
        matchedNodes = nodes.filter(n =>
          n.label?.toLowerCase().includes(searchLower) ||
          n.ip?.toLowerCase().includes(searchLower) ||
          n.id?.toLowerCase().includes(searchLower)
        );
        matchedIncidents = incidents.filter(inc =>
          inc.title?.toLowerCase().includes(searchLower) ||
          inc.model?.toLowerCase().includes(searchLower) ||
          inc.summary?.toLowerCase().includes(searchLower)
        );
        break;
    }

    const searchResults = {
      iocType,
      query: searchValue.trim(),
      nodes: matchedNodes,
      incidents: matchedIncidents,
      totalMatches: matchedNodes.length + matchedIncidents.length
    };

    setResults(searchResults);
    setShowResults(true);
    setIsSearching(false);

    // Highlight matched nodes on topology
    onHighlightNodes?.(matchedNodes.map(n => n.id));
    onSearchResults?.(searchResults);
  }, [searchValue, nodes, incidents, detectIOCType, isIPInCIDR, onHighlightNodes, onSearchResults]);

  // Handle Enter key
  const handleKeyDown = useCallback((e) => {
    if (e.key === 'Enter') {
      executeSearch();
    } else if (e.key === 'Escape') {
      setShowResults(false);
    }
  }, [executeSearch]);

  // Clear search
  const handleClear = useCallback(() => {
    setSearchValue('');
    setResults(null);
    setShowResults(false);
    onHighlightNodes?.([]);
  }, [onHighlightNodes]);

  // Get IOC type label
  const getIOCTypeLabel = (type) => {
    switch (type) {
      case 'ip': return 'IP Address';
      case 'partial_ip': return 'Subnet';
      case 'cidr': return 'CIDR Range';
      case 'md5': return 'MD5 Hash';
      case 'sha1': return 'SHA1 Hash';
      case 'sha256': return 'SHA256 Hash';
      case 'domain': return 'Domain';
      default: return 'Text';
    }
  };

  return (
    <div ref={searchRef} style={{ position: 'relative', minWidth: '280px' }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: '4px' }}>
        <EuiFieldSearch
          placeholder="Search IP, hash, domain, signature..."
          value={searchValue}
          onChange={(e) => setSearchValue(e.target.value)}
          onKeyDown={handleKeyDown}
          isClearable={false}
          compressed
          style={{ width: '250px' }}
        />
        <EuiToolTip content="Search IOC">
          <EuiButtonIcon
            iconType="search"
            aria-label="Search"
            onClick={executeSearch}
            color="primary"
            isLoading={isSearching}
          />
        </EuiToolTip>
        {searchValue && (
          <EuiButtonIcon
            iconType="cross"
            aria-label="Clear"
            onClick={handleClear}
            color="text"
          />
        )}
      </div>

      {/* Search Results Dropdown */}
      {showResults && results && (
        <div style={{
          position: 'absolute',
          top: '100%',
          left: 0,
          right: 0,
          marginTop: '4px',
          background: '#1a1d29',
          borderRadius: '6px',
          border: '1px solid #2d3142',
          boxShadow: '0 8px 24px rgba(0,0,0,0.4)',
          zIndex: 1000,
          maxHeight: '400px',
          overflow: 'hidden'
        }}>
          {/* Results Header */}
          <div style={{
            padding: '10px 12px',
            borderBottom: '1px solid #2d3142',
            display: 'flex',
            justifyContent: 'space-between',
            alignItems: 'center'
          }}>
            <div>
              <span style={{ color: '#fff', fontSize: '13px', fontWeight: 600 }}>
                {results.totalMatches} results
              </span>
              <span style={{
                marginLeft: '8px',
                background: '#2d3142',
                padding: '2px 6px',
                borderRadius: '3px',
                color: '#8e9fbc',
                fontSize: '10px'
              }}>
                {getIOCTypeLabel(results.iocType)}
              </span>
            </div>
            {results.totalMatches === 0 && (
              <button
                onClick={() => onNavigateToEvents?.(results.query)}
                style={{
                  background: '#60a5fa20',
                  border: 'none',
                  borderRadius: '4px',
                  padding: '4px 8px',
                  color: '#60a5fa',
                  fontSize: '11px',
                  cursor: 'pointer'
                }}
              >
                Search in Events
              </button>
            )}
          </div>

          {/* Results Content */}
          <div style={{ maxHeight: '350px', overflowY: 'auto' }}>
            {/* Node Results */}
            {results.nodes.length > 0 && (
              <div>
                <div style={{
                  padding: '8px 12px',
                  background: '#0f1117',
                  color: '#8e9fbc',
                  fontSize: '10px',
                  fontWeight: 600,
                  textTransform: 'uppercase'
                }}>
                  Nodes ({results.nodes.length})
                </div>
                {results.nodes.slice(0, 10).map(node => (
                  <div
                    key={node.id}
                    onClick={() => {
                      onHighlightNodes?.([node.id]);
                      setShowResults(false);
                    }}
                    style={{
                      padding: '10px 12px',
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'space-between',
                      cursor: 'pointer',
                      borderBottom: '1px solid #2d314220'
                    }}
                    onMouseEnter={(e) => e.currentTarget.style.background = '#2d3142'}
                    onMouseLeave={(e) => e.currentTarget.style.background = 'transparent'}
                  >
                    <div>
                      <div style={{ color: '#fff', fontSize: '12px' }}>{node.label}</div>
                      <div style={{ color: '#64748b', fontSize: '10px', fontFamily: 'monospace' }}>
                        {node.ip || 'No IP'}
                      </div>
                    </div>
                    {node.alertCount > 0 && (
                      <span style={{
                        background: '#f6726a20',
                        color: '#f6726a',
                        padding: '2px 6px',
                        borderRadius: '3px',
                        fontSize: '10px'
                      }}>
                        {node.alertCount} alerts
                      </span>
                    )}
                  </div>
                ))}
              </div>
            )}

            {/* Incident Results */}
            {results.incidents.length > 0 && (
              <div>
                <div style={{
                  padding: '8px 12px',
                  background: '#0f1117',
                  color: '#8e9fbc',
                  fontSize: '10px',
                  fontWeight: 600,
                  textTransform: 'uppercase'
                }}>
                  Incidents ({results.incidents.length})
                </div>
                {results.incidents.slice(0, 10).map((inc, idx) => (
                  <div
                    key={inc.id || idx}
                    onClick={() => onNavigateToEvents?.(results.query)}
                    style={{
                      padding: '10px 12px',
                      cursor: 'pointer',
                      borderBottom: '1px solid #2d314220'
                    }}
                    onMouseEnter={(e) => e.currentTarget.style.background = '#2d3142'}
                    onMouseLeave={(e) => e.currentTarget.style.background = 'transparent'}
                  >
                    <div style={{
                      color: '#fff',
                      fontSize: '12px',
                      overflow: 'hidden',
                      textOverflow: 'ellipsis',
                      whiteSpace: 'nowrap'
                    }}>
                      {inc.title}
                    </div>
                    <div style={{
                      display: 'flex',
                      alignItems: 'center',
                      gap: '8px',
                      marginTop: '4px'
                    }}>
                      <span style={{
                        fontSize: '10px',
                        padding: '2px 6px',
                        borderRadius: '3px',
                        background: inc.severity === 'Critical' ? '#f6726a20' :
                                   inc.severity === 'High' ? '#f5a62320' : '#2d3142',
                        color: inc.severity === 'Critical' ? '#f6726a' :
                               inc.severity === 'High' ? '#f5a623' : '#8e9fbc'
                      }}>
                        {inc.severity}
                      </span>
                      <span style={{ color: '#64748b', fontSize: '10px' }}>
                        {inc.since || new Date(inc.timestamp).toLocaleTimeString()}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            )}

            {/* No Results */}
            {results.totalMatches === 0 && (
              <div style={{
                padding: '24px',
                textAlign: 'center',
                color: '#64748b'
              }}>
                <div style={{ fontSize: '13px', marginBottom: '8px' }}>
                  No matches found in topology
                </div>
                <button
                  onClick={() => onNavigateToEvents?.(results.query)}
                  style={{
                    background: '#60a5fa',
                    border: 'none',
                    borderRadius: '4px',
                    padding: '8px 16px',
                    color: '#fff',
                    fontSize: '12px',
                    cursor: 'pointer'
                  }}
                >
                  Search in Events Page
                </button>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
};

export default IOCSearchBar;
