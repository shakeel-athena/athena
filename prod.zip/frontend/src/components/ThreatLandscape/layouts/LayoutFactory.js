/**
 * Layout Factory
 * Factory for switching between different layout algorithms
 */

import { buildSplitLayout } from './SplitLayout';
import { buildConcentricLayout } from './ConcentricLayout';

export const VIEW_MODES = {
  SPLIT: 'split',
  CONCENTRIC: 'concentric'
};

/**
 * Build layout based on view mode
 * @param {string} viewMode - 'split' or 'concentric'
 * @param {Array} nodes - All nodes to position
 * @param {Object} dimensions - { width, height }
 * @returns {Object} - Layout result with positions, hubs, etc.
 */
export function buildLayout(viewMode, nodes, dimensions) {
  switch (viewMode) {
    case VIEW_MODES.SPLIT:
      return buildSplitLayout(nodes, dimensions);
    case VIEW_MODES.CONCENTRIC:
      return buildConcentricLayout(nodes, dimensions);
    default:
      return buildSplitLayout(nodes, dimensions);
  }
}

/**
 * Get all nodes from topology for new layouts
 * Filters out old segment hub nodes
 */
export function extractNodesForLayout(topology) {
  if (!topology?.nodes) return [];

  const result = topology.nodes.filter(node =>
    node &&
    node.id &&
    node.type !== 'cluster' &&
    node.type !== 'segment-diamond' &&
    node.type !== 'segment-hub' &&
    !node.isSegmentHub
  );

  return result;
}

/**
 * Calculate overall threat level from nodes
 * Used to color the SIEM hub
 */
export function calculateThreatLevel(nodes) {
  if (!nodes || nodes.length === 0) return 'normal';

  const criticalCount = nodes.filter(n => {
    const riskScore = Number(n.riskScore || 0);
    const alertCount = Number(n.alertCount || 0);
    return n.critical || riskScore >= 70 || alertCount >= 5;
  }).length;

  const warningCount = nodes.filter(n => {
    const riskScore = Number(n.riskScore || 0);
    const alertCount = Number(n.alertCount || 0);
    return (!n.critical && riskScore >= 40 && riskScore < 70) || (alertCount > 0 && alertCount < 5);
  }).length;

  if (criticalCount > 0) return 'critical';
  if (warningCount > 0) return 'warning';
  return 'normal';
}

const LayoutFactory = {
  VIEW_MODES,
  buildLayout,
  extractNodesForLayout,
  calculateThreatLevel
};

export default LayoutFactory;
