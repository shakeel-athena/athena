/**
 * Concentric Layout - Two Rings Around Single SIEM Hub
 * Inner ring: Registered agents (Protected Zone)
 * Outer ring: External nodes (Threat Zone)
 */

/**
 * Helper to check if a node should be classified as internal/agent
 * Classification is based on isRegistered flag from topology data:
 * - isRegistered: true = Registered Wazuh agent (Protected Zone)
 */
function isInternalNode(node) {
  return node.isRegistered === true;
}

/**
 * Helper to check if a node is a threat actor (should appear in Threat Zone)
 * Only nodes explicitly marked as threat actors from the API are included
 */
function isThreatActorNode(node) {
  return node.isThreatActor === true || node.isHighRiskHost === true;
}

/**
 * Build concentric layout with two rings
 * @param {Array} nodes - All nodes to position
 * @param {Object} dimensions - { width, height }
 * @returns {Object} - { positions, hubs, rings }
 */
export function buildConcentricLayout(nodes, { width, height }) {
  const center = { x: width / 2, y: height / 2 };
  const positions = new Map();

  // Filter out segment-hub nodes (we'll use our own SIEM hub)
  const realNodes = nodes.filter(n => n.type !== 'segment-hub' && !n.isSegmentHub);

  // Separate agents from threat actors
  // Protected Zone: Registered agents
  // Threat Zone: Only nodes marked as threat actors or high-risk hosts (from threat-actors API)
  const agents = realNodes.filter(n => isInternalNode(n));
  const externals = realNodes.filter(n => !isInternalNode(n) && isThreatActorNode(n));

  // Ring radii - scaled based on container and node count (smaller to fit view)
  const baseRadius = Math.min(width, height) * 0.32;
  const innerRadius = baseRadius * 0.45;  // Agents (inner ring)
  const outerRadius = baseRadius * 0.85;  // External (outer ring)
  const glowRadius = outerRadius * 1.3;   // Glow background radius

  // Create single SIEM hub at center
  const hub = {
    id: 'siem-hub',
    label: 'SIEM',
    type: 'siem-hub',
    isSiemHub: true,
    agentCount: agents.length,
    externalCount: externals.length,
    position: center
  };

  // Position SIEM hub
  positions.set('siem-hub', {
    x: center.x,
    y: center.y,
    isHub: true
  });

  // Place agents in inner ring
  if (agents.length > 0) {
    const agentAngleStep = (2 * Math.PI) / agents.length;
    agents.forEach((node, idx) => {
      const angle = agentAngleStep * idx - Math.PI / 2;
      positions.set(node.id, {
        x: center.x + innerRadius * Math.cos(angle),
        y: center.y + innerRadius * Math.sin(angle),
        ring: 'inner',
        cluster: 'agents'
      });
    });
  }

  // Place external nodes in outer ring
  if (externals.length > 0) {
    const externalAngleStep = (2 * Math.PI) / externals.length;
    externals.forEach((node, idx) => {
      const angle = externalAngleStep * idx - Math.PI / 2;
      positions.set(node.id, {
        x: center.x + outerRadius * Math.cos(angle),
        y: center.y + outerRadius * Math.sin(angle),
        ring: 'outer',
        cluster: 'external'
      });
    });
  }

  // Create spoke lines data - all connect to single hub
  const spokes = [];

  // Spokes from hub to agents (inner ring)
  agents.forEach(node => {
    spokes.push({
      sourceId: 'siem-hub',
      targetId: node.id,
      ring: 'inner'
    });
  });

  // Spokes from hub to externals (outer ring)
  externals.forEach(node => {
    spokes.push({
      sourceId: 'siem-hub',
      targetId: node.id,
      ring: 'outer'
    });
  });

  return {
    positions,
    hub,
    spokes,
    glowRadius,
    center,
    rings: {
      inner: {
        center,
        radius: innerRadius,
        nodes: agents,
        label: 'Agents'
      },
      outer: {
        center,
        radius: outerRadius,
        nodes: externals,
        label: 'External'
      }
    },
    layoutType: 'concentric'
  };
}

export default buildConcentricLayout;
