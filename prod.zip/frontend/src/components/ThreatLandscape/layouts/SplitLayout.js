/**
 * Split Layout - Two Side-by-Side Clusters
 * Left cluster: SIEM hub + Agents ring (Protected Zone)
 * Right cluster: SIEM hub + External ring (Threat Zone)
 */

/**
 * Helper to check if a node should be classified as internal/agent
 * Classification is based on isRegistered flag from topology data:
 * - isRegistered: true = Registered Wazuh agent (Protected Zone)
 * - isRegistered: false/undefined = IP from alerts, not a registered agent (Threat Zone)
 */
function isInternalNode(node) {
  return node.isRegistered === true;
}

/**
 * Build split layout with two separate clusters
 * @param {Array} nodes - All nodes to position
 * @param {Object} dimensions - { width, height }
 * @returns {Object} - { positions, hubs, clusters }
 */
export function buildSplitLayout(nodes, { width, height }) {
  const positions = new Map();

  // Filter out segment-hub nodes (we'll use our own SIEM hubs)
  const realNodes = nodes.filter(n => n.type !== 'segment-hub' && !n.isSegmentHub);

  // Separate agents from threat actors
  // Protected Zone: Registered agents
  // Threat Zone: Only nodes marked as threat actors or high-risk hosts (from threat-actors API)
  const agents = realNodes.filter(n => isInternalNode(n));
  const externals = realNodes.filter(n => !isInternalNode(n) && (n.isThreatActor || n.isHighRiskHost));

  // Two cluster centers (top and bottom) - vertical layout
  // ~53% gap between zones for better separation
  const topCenter = { x: width * 0.5, y: height * 0.24 };       // Agents cluster (top center)
  const bottomCenter = { x: width * 0.5, y: height * 0.77 };    // External cluster (bottom center)

  // Calculate radius - larger for more distance between hub and nodes
  const maxRadius = Math.min(width * 0.18, height * 0.20);
  const agentRadius = agents.length > 12 ? maxRadius : maxRadius * 0.9;
  const externalRadius = externals.length > 12 ? maxRadius : maxRadius * 0.9;

  // Glow radius for the background circle (slightly larger than node ring)
  const glowRadius = maxRadius * 1.15;

  // Create SIEM hub nodes
  const hubs = {
    agents: {
      id: 'siem-hub-agents',
      label: 'Protected Zone',
      type: 'siem-hub',
      isSiemHub: true,
      cluster: 'agents',
      nodeCount: agents.length,
      position: topCenter
    },
    external: {
      id: 'siem-hub-external',
      label: 'Threat Zone',
      type: 'siem-hub',
      isSiemHub: true,
      cluster: 'external',
      nodeCount: externals.length,
      position: bottomCenter
    }
  };

  // Position SIEM hubs
  positions.set('siem-hub-agents', {
    x: topCenter.x,
    y: topCenter.y,
    isHub: true,
    cluster: 'agents'
  });
  positions.set('siem-hub-external', {
    x: bottomCenter.x,
    y: bottomCenter.y,
    isHub: true,
    cluster: 'external'
  });

  // Place agents in top cluster ring
  if (agents.length > 0) {
    const agentAngleStep = (2 * Math.PI) / agents.length;
    agents.forEach((node, idx) => {
      const angle = agentAngleStep * idx - Math.PI / 2;
      positions.set(node.id, {
        x: topCenter.x + agentRadius * Math.cos(angle),
        y: topCenter.y + agentRadius * Math.sin(angle),
        cluster: 'agents'
      });
    });
  }

  // Place external nodes in bottom cluster ring
  if (externals.length > 0) {
    const externalAngleStep = (2 * Math.PI) / externals.length;
    externals.forEach((node, idx) => {
      const angle = externalAngleStep * idx - Math.PI / 2;
      positions.set(node.id, {
        x: bottomCenter.x + externalRadius * Math.cos(angle),
        y: bottomCenter.y + externalRadius * Math.sin(angle),
        cluster: 'external'
      });
    });
  }

  // Create spoke lines data
  const spokes = [];

  // Spokes from agents hub to agents
  agents.forEach(node => {
    spokes.push({
      sourceId: 'siem-hub-agents',
      targetId: node.id,
      cluster: 'agents'
    });
  });

  // Spokes from external hub to externals
  externals.forEach(node => {
    spokes.push({
      sourceId: 'siem-hub-external',
      targetId: node.id,
      cluster: 'external'
    });
  });

  return {
    positions,
    hubs,
    spokes,
    clusters: {
      agents: {
        center: topCenter,
        radius: agentRadius,
        glowRadius: glowRadius,
        nodes: agents,
        label: 'Protected Zone'
      },
      external: {
        center: bottomCenter,
        radius: externalRadius,
        glowRadius: glowRadius,
        nodes: externals,
        label: 'Threat Zone'
      }
    },
    layoutType: 'split'
  };
}

export default buildSplitLayout;
