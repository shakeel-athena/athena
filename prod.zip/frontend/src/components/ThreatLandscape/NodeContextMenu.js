import React, { useCallback, useEffect, useRef } from 'react';
import { useNavigate } from 'react-router-dom';

/**
 * Context menu component for nodes in the Threat Landscape
 * Provides quick actions when right-clicking on a node
 */
const NodeContextMenu = ({
  isOpen,
  position,
  node,
  onClose,
  onBlockIP,
  onMuteAlerts,
  onFocusNode,
  onCopyIP
}) => {
  const menuRef = useRef(null);
  const navigate = useNavigate();

  // Close menu when clicking outside
  useEffect(() => {
    const handleClickOutside = (e) => {
      if (menuRef.current && !menuRef.current.contains(e.target)) {
        onClose();
      }
    };

    const handleEscape = (e) => {
      if (e.key === 'Escape') {
        onClose();
      }
    };

    if (isOpen) {
      document.addEventListener('mousedown', handleClickOutside);
      document.addEventListener('keydown', handleEscape);
    }

    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
      document.removeEventListener('keydown', handleEscape);
    };
  }, [isOpen, onClose]);

  // Helper: Check if IP is private
  const isPrivateIP = (ip) => {
    if (!ip || ip === 'Unknown') return true;
    return ip.startsWith('10.') ||
           ip.startsWith('192.168.') ||
           ip.startsWith('172.16.') ||
           ip.startsWith('172.17.') ||
           ip.startsWith('172.18.') ||
           ip.startsWith('172.19.') ||
           ip.startsWith('172.2') ||
           ip.startsWith('172.30.') ||
           ip.startsWith('172.31.') ||
           ip === '127.0.0.1' ||
           ip === 'localhost';
  };

  const handleCopyIP = useCallback(() => {
    if (node?.ip && node.ip !== 'Unknown') {
      navigator.clipboard.writeText(node.ip);
      onCopyIP?.(node.ip);
    }
    onClose();
  }, [node, onCopyIP, onClose]);

  const handleBlockIP = useCallback(() => {
    onBlockIP?.(node);
    onClose();
  }, [node, onBlockIP, onClose]);

  const handleMuteAlerts = useCallback(() => {
    onMuteAlerts?.(node);
    onClose();
  }, [node, onMuteAlerts, onClose]);

  const handleFocusNode = useCallback(() => {
    onFocusNode?.(node);
    onClose();
  }, [node, onFocusNode, onClose]);

  const handleViewAlerts = useCallback(() => {
    const agentName = node?.label || node?.id || '';
    navigate(`/detection/events?agent=${encodeURIComponent(agentName)}`);
    onClose();
  }, [node, navigate, onClose]);

  if (!isOpen || !node) return null;

  const canBlockIP = node.ip && node.ip !== 'Unknown' && !isPrivateIP(node.ip);
  const canMute = node.alertCount > 0;

  // Menu items configuration
  const menuItems = [
    {
      id: 'focus',
      label: 'Focus Node',
      icon: '🎯',
      onClick: handleFocusNode,
      disabled: false
    },
    {
      id: 'separator-1',
      type: 'separator'
    },
    {
      id: 'block',
      label: 'Block IP',
      icon: '🚫',
      onClick: handleBlockIP,
      disabled: !canBlockIP,
      danger: true
    },
    {
      id: 'mute',
      label: `Mute Alerts (${node.alertCount || 0})`,
      icon: '🔇',
      onClick: handleMuteAlerts,
      disabled: !canMute
    },
    {
      id: 'separator-2',
      type: 'separator'
    },
    {
      id: 'view-alerts',
      label: 'View in Events',
      icon: '📋',
      onClick: handleViewAlerts,
      disabled: false
    },
    {
      id: 'copy-ip',
      label: 'Copy IP Address',
      icon: '📋',
      onClick: handleCopyIP,
      disabled: !node.ip || node.ip === 'Unknown'
    }
  ];

  // Adjust position to keep menu within viewport
  const adjustedPosition = {
    x: Math.min(position.x, window.innerWidth - 200),
    y: Math.min(position.y, window.innerHeight - 300)
  };

  return (
    <div
      ref={menuRef}
      style={{
        position: 'fixed',
        left: adjustedPosition.x,
        top: adjustedPosition.y,
        backgroundColor: '#1a1d29',
        borderRadius: '8px',
        border: '1px solid #2d3142',
        boxShadow: '0 8px 32px rgba(0, 0, 0, 0.5)',
        zIndex: 10000,
        minWidth: '180px',
        overflow: 'hidden',
        fontFamily: 'Inter, -apple-system, BlinkMacSystemFont, sans-serif'
      }}
    >
      {/* Header with node info */}
      <div style={{
        padding: '12px 14px',
        borderBottom: '1px solid #2d3142',
        backgroundColor: '#0f1117'
      }}>
        <div style={{
          color: '#fff',
          fontWeight: 600,
          fontSize: '13px',
          marginBottom: '4px',
          overflow: 'hidden',
          textOverflow: 'ellipsis',
          whiteSpace: 'nowrap'
        }}>
          {node.label || node.id}
        </div>
        <div style={{
          color: '#8e9fbc',
          fontSize: '11px',
          display: 'flex',
          alignItems: 'center',
          gap: '8px'
        }}>
          <span style={{ fontFamily: 'monospace' }}>{node.ip || 'No IP'}</span>
          {node.alertCount > 0 && (
            <span style={{
              backgroundColor: '#f6726a20',
              color: '#f6726a',
              padding: '2px 6px',
              borderRadius: '3px',
              fontSize: '10px',
              fontWeight: 600
            }}>
              {node.alertCount} alerts
            </span>
          )}
        </div>
      </div>

      {/* Menu items */}
      <div style={{ padding: '6px 0' }}>
        {menuItems.map((item) => {
          if (item.type === 'separator') {
            return (
              <div
                key={item.id}
                style={{
                  height: '1px',
                  backgroundColor: '#2d3142',
                  margin: '6px 0'
                }}
              />
            );
          }

          return (
            <button
              key={item.id}
              onClick={item.onClick}
              disabled={item.disabled}
              style={{
                width: '100%',
                padding: '8px 14px',
                backgroundColor: 'transparent',
                border: 'none',
                color: item.disabled ? '#555' : (item.danger ? '#f6726a' : '#fff'),
                fontSize: '13px',
                textAlign: 'left',
                cursor: item.disabled ? 'not-allowed' : 'pointer',
                display: 'flex',
                alignItems: 'center',
                gap: '10px',
                transition: 'background-color 0.15s ease',
                opacity: item.disabled ? 0.5 : 1
              }}
              onMouseEnter={(e) => {
                if (!item.disabled) {
                  e.currentTarget.style.backgroundColor = '#2d3142';
                }
              }}
              onMouseLeave={(e) => {
                e.currentTarget.style.backgroundColor = 'transparent';
              }}
            >
              <span style={{ fontSize: '14px', width: '20px', textAlign: 'center' }}>
                {item.icon}
              </span>
              <span>{item.label}</span>
            </button>
          );
        })}
      </div>
    </div>
  );
};

export default NodeContextMenu;
