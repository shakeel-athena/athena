import React, { useState, useMemo } from 'react';
import { useNavigate } from 'react-router-dom';
import { EuiButtonIcon } from '@elastic/eui';

/**
 * PivotMenu Component
 * Provides threat hunting pivot capabilities from selected nodes
 */
const PivotMenu = ({
  node,
  topology,
  onPivotToIP,
  onPivotToSignature,
  onPivotToTimeline,
  onClose,
  isOpen,
  position
}) => {
  const navigate = useNavigate();
  const [activeSubmenu, setActiveSubmenu] = useState(null);

  // Find related IPs in the same subnet - use useMemo before early return
  const relatedIPs = useMemo(() => {
    if (!node?.ip || node.ip === 'Unknown') return [];

    const ipParts = node.ip.split('.');
    if (ipParts.length !== 4) return [];

    const subnet = `${ipParts[0]}.${ipParts[1]}.${ipParts[2]}`;

    return (topology?.nodes || [])
      .filter(n => n.ip && n.ip.startsWith(subnet) && n.id !== node.id)
      .slice(0, 10);
  }, [node, topology]);

  // Find nodes with similar alert patterns
  const similarNodes = useMemo(() => {
    if (!node?.alertCount) return [];

    const nodeIncidents = (topology?.incidents || []).filter(inc =>
      inc.deviceId === node.id || inc.title?.includes(node.ip)
    );

    const nodeSignatures = new Set(nodeIncidents.map(inc => inc.model || inc.title?.split(':')[0]));

    return (topology?.nodes || [])
      .filter(n => {
        if (n.id === node.id || !n.alertCount) return false;

        const nIncidents = (topology?.incidents || []).filter(inc =>
          inc.deviceId === n.id || inc.title?.includes(n.ip)
        );

        const nSignatures = new Set(nIncidents.map(inc => inc.model || inc.title?.split(':')[0]));

        // Check for common signatures
        return [...nodeSignatures].some(sig => nSignatures.has(sig));
      })
      .slice(0, 10);
  }, [node, topology]);

  // Get unique signatures for this node
  const signatures = useMemo(() => {
    if (!node) return [];

    const nodeIncidents = (topology?.incidents || []).filter(inc =>
      inc.deviceId === node.id ||
      inc.title?.includes(node.label) ||
      inc.title?.includes(node.ip)
    );

    const signatureMap = {};
    nodeIncidents.forEach(inc => {
      const sig = inc.model || inc.title?.split(':')[0] || 'Unknown';
      signatureMap[sig] = (signatureMap[sig] || 0) + 1;
    });

    return Object.entries(signatureMap)
      .map(([name, count]) => ({ name, count }))
      .sort((a, b) => b.count - a.count)
      .slice(0, 10);
  }, [node, topology]);

  // Early return AFTER all hooks
  if (!isOpen || !node) return null;

  // Pivot menu items
  const menuItems = [
    {
      id: 'related-ips',
      label: 'Related IPs',
      icon: '🔗',
      description: `${relatedIPs.length} IPs in same subnet`,
      hasSubmenu: relatedIPs.length > 0,
      disabled: relatedIPs.length === 0
    },
    {
      id: 'similar-alerts',
      label: 'Similar Alert Patterns',
      icon: '📊',
      description: `${similarNodes.length} nodes with similar alerts`,
      hasSubmenu: similarNodes.length > 0,
      disabled: similarNodes.length === 0
    },
    {
      id: 'signatures',
      label: 'Triggered Signatures',
      icon: '📜',
      description: `${signatures.length} unique signatures`,
      hasSubmenu: signatures.length > 0,
      disabled: signatures.length === 0
    },
    { type: 'separator' },
    {
      id: 'view-events',
      label: 'View in Events Page',
      icon: '📋',
      description: 'Open filtered events view',
      onClick: () => {
        navigate(`/detection/events?ip=${encodeURIComponent(node.ip || node.label)}`);
        onClose();
      }
    },
    {
      id: 'search-network',
      label: 'Search Network Traffic',
      icon: '🔍',
      description: 'Find related network flows',
      onClick: () => {
        navigate(`/detection/network?filter=${encodeURIComponent(node.ip || node.label)}`);
        onClose();
      }
    },
    {
      id: 'active-response',
      label: 'View in Active Response',
      icon: '🛡️',
      description: 'Check response actions',
      onClick: () => {
        navigate(`/active-response/dashboard?ip=${encodeURIComponent(node.ip || '')}`);
        onClose();
      }
    }
  ];

  // Render submenu items
  const renderSubmenu = () => {
    switch (activeSubmenu) {
      case 'related-ips':
        return (
          <div style={{
            position: 'absolute',
            left: '100%',
            top: 0,
            marginLeft: '4px',
            background: '#1a1d29',
            borderRadius: '6px',
            border: '1px solid #2d3142',
            padding: '8px 0',
            minWidth: '180px',
            maxHeight: '250px',
            overflowY: 'auto',
            boxShadow: '0 4px 16px rgba(0,0,0,0.3)'
          }}>
            <div style={{ padding: '8px 12px', color: '#8e9fbc', fontSize: '10px', borderBottom: '1px solid #2d3142' }}>
              SUBNET {node.ip?.split('.').slice(0, 3).join('.')}.x
            </div>
            {relatedIPs.map(ip => (
              <button
                key={ip.id}
                onClick={() => {
                  onPivotToIP?.(ip);
                  onClose();
                }}
                style={{
                  width: '100%',
                  padding: '8px 12px',
                  background: 'transparent',
                  border: 'none',
                  color: '#fff',
                  fontSize: '12px',
                  textAlign: 'left',
                  cursor: 'pointer',
                  display: 'flex',
                  justifyContent: 'space-between',
                  alignItems: 'center'
                }}
                onMouseEnter={(e) => e.target.style.background = '#2d3142'}
                onMouseLeave={(e) => e.target.style.background = 'transparent'}
              >
                <span style={{ fontFamily: 'monospace' }}>{ip.ip}</span>
                {ip.alertCount > 0 && (
                  <span style={{
                    background: '#f6726a20',
                    color: '#f6726a',
                    padding: '2px 6px',
                    borderRadius: '3px',
                    fontSize: '10px'
                  }}>
                    {ip.alertCount}
                  </span>
                )}
              </button>
            ))}
          </div>
        );

      case 'similar-alerts':
        return (
          <div style={{
            position: 'absolute',
            left: '100%',
            top: 0,
            marginLeft: '4px',
            background: '#1a1d29',
            borderRadius: '6px',
            border: '1px solid #2d3142',
            padding: '8px 0',
            minWidth: '200px',
            maxHeight: '250px',
            overflowY: 'auto',
            boxShadow: '0 4px 16px rgba(0,0,0,0.3)'
          }}>
            <div style={{ padding: '8px 12px', color: '#8e9fbc', fontSize: '10px', borderBottom: '1px solid #2d3142' }}>
              SIMILAR ALERT PATTERNS
            </div>
            {similarNodes.map(n => (
              <button
                key={n.id}
                onClick={() => {
                  onPivotToIP?.(n);
                  onClose();
                }}
                style={{
                  width: '100%',
                  padding: '8px 12px',
                  background: 'transparent',
                  border: 'none',
                  color: '#fff',
                  fontSize: '12px',
                  textAlign: 'left',
                  cursor: 'pointer',
                  display: 'flex',
                  justifyContent: 'space-between',
                  alignItems: 'center'
                }}
                onMouseEnter={(e) => e.target.style.background = '#2d3142'}
                onMouseLeave={(e) => e.target.style.background = 'transparent'}
              >
                <span>{n.label}</span>
                <span style={{ color: '#64748b', fontSize: '10px', fontFamily: 'monospace' }}>
                  {n.ip}
                </span>
              </button>
            ))}
          </div>
        );

      case 'signatures':
        return (
          <div style={{
            position: 'absolute',
            left: '100%',
            top: 0,
            marginLeft: '4px',
            background: '#1a1d29',
            borderRadius: '6px',
            border: '1px solid #2d3142',
            padding: '8px 0',
            minWidth: '250px',
            maxHeight: '300px',
            overflowY: 'auto',
            boxShadow: '0 4px 16px rgba(0,0,0,0.3)'
          }}>
            <div style={{ padding: '8px 12px', color: '#8e9fbc', fontSize: '10px', borderBottom: '1px solid #2d3142' }}>
              TRIGGERED SIGNATURES
            </div>
            {signatures.map((sig, idx) => (
              <button
                key={idx}
                onClick={() => {
                  onPivotToSignature?.(sig.name);
                  onClose();
                }}
                style={{
                  width: '100%',
                  padding: '8px 12px',
                  background: 'transparent',
                  border: 'none',
                  color: '#fff',
                  fontSize: '11px',
                  textAlign: 'left',
                  cursor: 'pointer',
                  display: 'flex',
                  justifyContent: 'space-between',
                  alignItems: 'center',
                  gap: '8px'
                }}
                onMouseEnter={(e) => e.target.style.background = '#2d3142'}
                onMouseLeave={(e) => e.target.style.background = 'transparent'}
              >
                <span style={{
                  overflow: 'hidden',
                  textOverflow: 'ellipsis',
                  whiteSpace: 'nowrap',
                  flex: 1
                }}>
                  {sig.name}
                </span>
                <span style={{
                  background: '#2d3142',
                  padding: '2px 6px',
                  borderRadius: '3px',
                  fontSize: '10px',
                  color: '#8e9fbc'
                }}>
                  {sig.count}x
                </span>
              </button>
            ))}
          </div>
        );

      default:
        return null;
    }
  };

  return (
    <div
      style={{
        position: 'fixed',
        left: position.x,
        top: position.y,
        background: '#1a1d29',
        borderRadius: '8px',
        border: '1px solid #2d3142',
        boxShadow: '0 8px 32px rgba(0, 0, 0, 0.5)',
        zIndex: 10001,
        minWidth: '220px'
      }}
      onMouseLeave={() => setActiveSubmenu(null)}
    >
      {/* Header */}
      <div style={{
        padding: '12px 14px',
        borderBottom: '1px solid #2d3142',
        display: 'flex',
        justifyContent: 'space-between',
        alignItems: 'center'
      }}>
        <div>
          <div style={{ color: '#fff', fontSize: '13px', fontWeight: 600 }}>
            Pivot from {node.label}
          </div>
          <div style={{ color: '#64748b', fontSize: '11px', fontFamily: 'monospace' }}>
            {node.ip || 'No IP'}
          </div>
        </div>
        <EuiButtonIcon
          iconType="cross"
          aria-label="Close"
          onClick={onClose}
          color="text"
          size="s"
        />
      </div>

      {/* Menu Items */}
      <div style={{ padding: '6px 0', position: 'relative' }}>
        {menuItems.map((item, idx) => {
          if (item.type === 'separator') {
            return (
              <div
                key={`sep-${idx}`}
                style={{
                  height: '1px',
                  background: '#2d3142',
                  margin: '6px 0'
                }}
              />
            );
          }

          return (
            <div
              key={item.id}
              onMouseEnter={() => item.hasSubmenu && setActiveSubmenu(item.id)}
              style={{ position: 'relative' }}
            >
              <button
                onClick={item.onClick}
                disabled={item.disabled}
                style={{
                  width: '100%',
                  padding: '10px 14px',
                  background: activeSubmenu === item.id ? '#2d3142' : 'transparent',
                  border: 'none',
                  color: item.disabled ? '#555' : '#fff',
                  fontSize: '13px',
                  textAlign: 'left',
                  cursor: item.disabled ? 'not-allowed' : 'pointer',
                  display: 'flex',
                  alignItems: 'center',
                  gap: '10px',
                  opacity: item.disabled ? 0.5 : 1
                }}
                onMouseEnter={(e) => {
                  if (!item.disabled && !item.hasSubmenu) {
                    e.currentTarget.style.background = '#2d3142';
                  }
                }}
                onMouseLeave={(e) => {
                  if (!item.hasSubmenu || activeSubmenu !== item.id) {
                    e.currentTarget.style.background = 'transparent';
                  }
                }}
              >
                <span style={{ fontSize: '14px', width: '20px', textAlign: 'center' }}>
                  {item.icon}
                </span>
                <div style={{ flex: 1 }}>
                  <div>{item.label}</div>
                  <div style={{ color: '#64748b', fontSize: '10px' }}>{item.description}</div>
                </div>
                {item.hasSubmenu && (
                  <span style={{ color: '#64748b' }}>▶</span>
                )}
              </button>

              {activeSubmenu === item.id && renderSubmenu()}
            </div>
          );
        })}
      </div>
    </div>
  );
};

export default PivotMenu;
