import React, { useState, useEffect } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import {
  EuiModal,
  EuiModalHeader,
  EuiModalHeaderTitle,
  EuiModalBody,
  EuiModalFooter,
  EuiButton,
  EuiButtonEmpty,
  EuiFieldSearch,
  EuiIcon,
  EuiFlexGroup,
  EuiFlexItem,
  EuiText,
  EuiTitle,
  EuiSpacer,
  EuiTabs,
  EuiTab,
  EuiCallOut,
  EuiLoadingSpinner,
  EuiDraggable,
  EuiDroppable,
  EuiPanel,
  EuiBadge,
  EuiToolTip,
} from '@elastic/eui';
import { toast } from 'react-hot-toast';
import { 
  getGeoCountries, 
  setGeoCountries
} from '../services/api';
import {
  ComposableMap,
  Geographies,
  Geography,
  ZoomableGroup
} from 'react-simple-maps';

// Complete Country data with names and codes
const COUNTRIES = [
  { code: 'AD', name: 'Andorra' },
  { code: 'AE', name: 'United Arab Emirates' },
  { code: 'AF', name: 'Afghanistan' },
  { code: 'AG', name: 'Antigua and Barbuda' },
  { code: 'AI', name: 'Anguilla' },
  { code: 'AL', name: 'Albania' },
  { code: 'AM', name: 'Armenia' },
  { code: 'AO', name: 'Angola' },
  { code: 'AQ', name: 'Antarctica' },
  { code: 'AR', name: 'Argentina' },
  { code: 'AS', name: 'American Samoa' },
  { code: 'AT', name: 'Austria' },
  { code: 'AU', name: 'Australia' },
  { code: 'AW', name: 'Aruba' },
  { code: 'AX', name: 'Åland Islands' },
  { code: 'AZ', name: 'Azerbaijan' },
  { code: 'BA', name: 'Bosnia and Herzegovina' },
  { code: 'BB', name: 'Barbados' },
  { code: 'BD', name: 'Bangladesh' },
  { code: 'BE', name: 'Belgium' },
  { code: 'BF', name: 'Burkina Faso' },
  { code: 'BG', name: 'Bulgaria' },
  { code: 'BH', name: 'Bahrain' },
  { code: 'BI', name: 'Burundi' },
  { code: 'BJ', name: 'Benin' },
  { code: 'BL', name: 'Saint Barthélemy' },
  { code: 'BM', name: 'Bermuda' },
  { code: 'BN', name: 'Brunei' },
  { code: 'BO', name: 'Bolivia' },
  { code: 'BQ', name: 'Caribbean Netherlands' },
  { code: 'BR', name: 'Brazil' },
  { code: 'BS', name: 'Bahamas' },
  { code: 'BT', name: 'Bhutan' },
  { code: 'BV', name: 'Bouvet Island' },
  { code: 'BW', name: 'Botswana' },
  { code: 'BY', name: 'Belarus' },
  { code: 'BZ', name: 'Belize' },
  { code: 'CA', name: 'Canada' },
  { code: 'CC', name: 'Cocos Islands' },
  { code: 'CD', name: 'Democratic Republic of the Congo' },
  { code: 'CF', name: 'Central African Republic' },
  { code: 'CG', name: 'Republic of the Congo' },
  { code: 'CH', name: 'Switzerland' },
  { code: 'CI', name: 'Côte d\'Ivoire' },
  { code: 'CK', name: 'Cook Islands' },
  { code: 'CL', name: 'Chile' },
  { code: 'CM', name: 'Cameroon' },
  { code: 'CN', name: 'China' },
  { code: 'CO', name: 'Colombia' },
  { code: 'CR', name: 'Costa Rica' },
  { code: 'CU', name: 'Cuba' },
  { code: 'CV', name: 'Cape Verde' },
  { code: 'CW', name: 'Curaçao' },
  { code: 'CX', name: 'Christmas Island' },
  { code: 'CY', name: 'Cyprus' },
  { code: 'CZ', name: 'Czech Republic' },
  { code: 'DE', name: 'Germany' },
  { code: 'DJ', name: 'Djibouti' },
  { code: 'DK', name: 'Denmark' },
  { code: 'DM', name: 'Dominica' },
  { code: 'DO', name: 'Dominican Republic' },
  { code: 'DZ', name: 'Algeria' },
  { code: 'EC', name: 'Ecuador' },
  { code: 'EE', name: 'Estonia' },
  { code: 'EG', name: 'Egypt' },
  { code: 'EH', name: 'Western Sahara' },
  { code: 'ER', name: 'Eritrea' },
  { code: 'ES', name: 'Spain' },
  { code: 'ET', name: 'Ethiopia' },
  { code: 'FI', name: 'Finland' },
  { code: 'FJ', name: 'Fiji' },
  { code: 'FK', name: 'Falkland Islands' },
  { code: 'FM', name: 'Micronesia' },
  { code: 'FO', name: 'Faroe Islands' },
  { code: 'FR', name: 'France' },
  { code: 'GA', name: 'Gabon' },
  { code: 'GB', name: 'United Kingdom' },
  { code: 'GD', name: 'Grenada' },
  { code: 'GE', name: 'Georgia' },
  { code: 'GF', name: 'French Guiana' },
  { code: 'GG', name: 'Guernsey' },
  { code: 'GH', name: 'Ghana' },
  { code: 'GI', name: 'Gibraltar' },
  { code: 'GL', name: 'Greenland' },
  { code: 'GM', name: 'Gambia' },
  { code: 'GN', name: 'Guinea' },
  { code: 'GP', name: 'Guadeloupe' },
  { code: 'GQ', name: 'Equatorial Guinea' },
  { code: 'GR', name: 'Greece' },
  { code: 'GS', name: 'South Georgia and the South Sandwich Islands' },
  { code: 'GT', name: 'Guatemala' },
  { code: 'GU', name: 'Guam' },
  { code: 'GW', name: 'Guinea-Bissau' },
  { code: 'GY', name: 'Guyana' },
  { code: 'HK', name: 'Hong Kong' },
  { code: 'HM', name: 'Heard Island and McDonald Islands' },
  { code: 'HN', name: 'Honduras' },
  { code: 'HR', name: 'Croatia' },
  { code: 'HT', name: 'Haiti' },
  { code: 'HU', name: 'Hungary' },
  { code: 'ID', name: 'Indonesia' },
  { code: 'IE', name: 'Ireland' },
  { code: 'IL', name: 'Israel' },
  { code: 'IM', name: 'Isle of Man' },
  { code: 'IN', name: 'India' },
  { code: 'IO', name: 'British Indian Ocean Territory' },
  { code: 'IQ', name: 'Iraq' },
  { code: 'IR', name: 'Iran' },
  { code: 'IS', name: 'Iceland' },
  { code: 'IT', name: 'Italy' },
  { code: 'JE', name: 'Jersey' },
  { code: 'JM', name: 'Jamaica' },
  { code: 'JO', name: 'Jordan' },
  { code: 'JP', name: 'Japan' },
  { code: 'KE', name: 'Kenya' },
  { code: 'KG', name: 'Kyrgyzstan' },
  { code: 'KH', name: 'Cambodia' },
  { code: 'KI', name: 'Kiribati' },
  { code: 'KM', name: 'Comoros' },
  { code: 'KN', name: 'Saint Kitts and Nevis' },
  { code: 'KP', name: 'North Korea' },
  { code: 'KR', name: 'South Korea' },
  { code: 'KW', name: 'Kuwait' },
  { code: 'KY', name: 'Cayman Islands' },
  { code: 'KZ', name: 'Kazakhstan' },
  { code: 'LA', name: 'Laos' },
  { code: 'LB', name: 'Lebanon' },
  { code: 'LC', name: 'Saint Lucia' },
  { code: 'LI', name: 'Liechtenstein' },
  { code: 'LK', name: 'Sri Lanka' },
  { code: 'LR', name: 'Liberia' },
  { code: 'LS', name: 'Lesotho' },
  { code: 'LT', name: 'Lithuania' },
  { code: 'LU', name: 'Luxembourg' },
  { code: 'LV', name: 'Latvia' },
  { code: 'LY', name: 'Libya' },
  { code: 'MA', name: 'Morocco' },
  { code: 'MC', name: 'Monaco' },
  { code: 'MD', name: 'Moldova' },
  { code: 'ME', name: 'Montenegro' },
  { code: 'MF', name: 'Saint Martin' },
  { code: 'MG', name: 'Madagascar' },
  { code: 'MH', name: 'Marshall Islands' },
  { code: 'MK', name: 'North Macedonia' },
  { code: 'ML', name: 'Mali' },
  { code: 'MM', name: 'Myanmar' },
  { code: 'MN', name: 'Mongolia' },
  { code: 'MO', name: 'Macao' },
  { code: 'MP', name: 'Northern Mariana Islands' },
  { code: 'MQ', name: 'Martinique' },
  { code: 'MR', name: 'Mauritania' },
  { code: 'MS', name: 'Montserrat' },
  { code: 'MT', name: 'Malta' },
  { code: 'MU', name: 'Mauritius' },
  { code: 'MV', name: 'Maldives' },
  { code: 'MW', name: 'Malawi' },
  { code: 'MX', name: 'Mexico' },
  { code: 'MY', name: 'Malaysia' },
  { code: 'MZ', name: 'Mozambique' },
  { code: 'NA', name: 'Namibia' },
  { code: 'NC', name: 'New Caledonia' },
  { code: 'NE', name: 'Niger' },
  { code: 'NF', name: 'Norfolk Island' },
  { code: 'NG', name: 'Nigeria' },
  { code: 'NI', name: 'Nicaragua' },
  { code: 'NL', name: 'Netherlands' },
  { code: 'NO', name: 'Norway' },
  { code: 'NP', name: 'Nepal' },
  { code: 'NR', name: 'Nauru' },
  { code: 'NU', name: 'Niue' },
  { code: 'NZ', name: 'New Zealand' },
  { code: 'OM', name: 'Oman' },
  { code: 'PA', name: 'Panama' },
  { code: 'PE', name: 'Peru' },
  { code: 'PF', name: 'French Polynesia' },
  { code: 'PG', name: 'Papua New Guinea' },
  { code: 'PH', name: 'Philippines' },
  { code: 'PK', name: 'Pakistan' },
  { code: 'PL', name: 'Poland' },
  { code: 'PM', name: 'Saint Pierre and Miquelon' },
  { code: 'PN', name: 'Pitcairn Islands' },
  { code: 'PR', name: 'Puerto Rico' },
  { code: 'PS', name: 'Palestine' },
  { code: 'PT', name: 'Portugal' },
  { code: 'PW', name: 'Palau' },
  { code: 'PY', name: 'Paraguay' },
  { code: 'QA', name: 'Qatar' },
  { code: 'RE', name: 'Réunion' },
  { code: 'RO', name: 'Romania' },
  { code: 'RS', name: 'Serbia' },
  { code: 'RU', name: 'Russia' },
  { code: 'RW', name: 'Rwanda' },
  { code: 'SA', name: 'Saudi Arabia' },
  { code: 'SB', name: 'Solomon Islands' },
  { code: 'SC', name: 'Seychelles' },
  { code: 'SD', name: 'Sudan' },
  { code: 'SE', name: 'Sweden' },
  { code: 'SG', name: 'Singapore' },
  { code: 'SH', name: 'Saint Helena' },
  { code: 'SI', name: 'Slovenia' },
  { code: 'SJ', name: 'Svalbard and Jan Mayen' },
  { code: 'SK', name: 'Slovakia' },
  { code: 'SL', name: 'Sierra Leone' },
  { code: 'SM', name: 'San Marino' },
  { code: 'SN', name: 'Senegal' },
  { code: 'SO', name: 'Somalia' },
  { code: 'SR', name: 'Suriname' },
  { code: 'SS', name: 'South Sudan' },
  { code: 'ST', name: 'São Tomé and Príncipe' },
  { code: 'SV', name: 'El Salvador' },
  { code: 'SX', name: 'Sint Maarten' },
  { code: 'SY', name: 'Syria' },
  { code: 'SZ', name: 'Eswatini' },
  { code: 'TC', name: 'Turks and Caicos Islands' },
  { code: 'TD', name: 'Chad' },
  { code: 'TF', name: 'French Southern Territories' },
  { code: 'TG', name: 'Togo' },
  { code: 'TH', name: 'Thailand' },
  { code: 'TJ', name: 'Tajikistan' },
  { code: 'TK', name: 'Tokelau' },
  { code: 'TL', name: 'Timor-Leste' },
  { code: 'TM', name: 'Turkmenistan' },
  { code: 'TN', name: 'Tunisia' },
  { code: 'TO', name: 'Tonga' },
  { code: 'TR', name: 'Turkey' },
  { code: 'TT', name: 'Trinidad and Tobago' },
  { code: 'TV', name: 'Tuvalu' },
  { code: 'TW', name: 'Taiwan' },
  { code: 'TZ', name: 'Tanzania' },
  { code: 'UA', name: 'Ukraine' },
  { code: 'UG', name: 'Uganda' },
  { code: 'UM', name: 'United States Minor Outlying Islands' },
  { code: 'US', name: 'United States' },
  { code: 'UY', name: 'Uruguay' },
  { code: 'UZ', name: 'Uzbekistan' },
  { code: 'VA', name: 'Vatican City' },
  { code: 'VC', name: 'Saint Vincent and the Grenadines' },
  { code: 'VE', name: 'Venezuela' },
  { code: 'VG', name: 'British Virgin Islands' },
  { code: 'VI', name: 'U.S. Virgin Islands' },
  { code: 'VN', name: 'Vietnam' },
  { code: 'VU', name: 'Vanuatu' },
  { code: 'WF', name: 'Wallis and Futuna' },
  { code: 'WS', name: 'Samoa' },
  { code: 'YE', name: 'Yemen' },
  { code: 'YT', name: 'Mayotte' },
  { code: 'ZA', name: 'South Africa' },
  { code: 'ZM', name: 'Zambia' },
  { code: 'ZW', name: 'Zimbabwe' }
];

// World map data URL - this is a reliable source for country boundaries
const geoUrl = "https://cdn.jsdelivr.net/npm/world-atlas@2/countries-50m.json";

// Real World Map Component with actual country boundaries
const RealWorldMap = ({ allowedCountries, blockedCountries }) => {
  const [hoveredCountry, setHoveredCountry] = useState(null);


  // Comprehensive country name to ISO2 code mapping
  const getCountryCodeByName = (countryName) => {
    if (!countryName) return null;
    
    const nameToCode = {
      // Major countries
      'United States': 'US', 'United States of America': 'US', 'USA': 'US',
      'Canada': 'CA',
      'Mexico': 'MX', 'United Mexican States': 'MX',
      'Brazil': 'BR', 'Federative Republic of Brazil': 'BR',
      'Argentina': 'AR', 'Argentine Republic': 'AR',
      'Chile': 'CL', 'Republic of Chile': 'CL',
      'Colombia': 'CO', 'Republic of Colombia': 'CO',
      'Peru': 'PE', 'Republic of Peru': 'PE',
      'Venezuela': 'VE', 'Bolivarian Republic of Venezuela': 'VE',
      'Ecuador': 'EC', 'Republic of Ecuador': 'EC',
      'Bolivia': 'BO', 'Plurinational State of Bolivia': 'BO',
      'Paraguay': 'PY', 'Republic of Paraguay': 'PY',
      'Uruguay': 'UY', 'Eastern Republic of Uruguay': 'UY',
      'Guyana': 'GY', 'Co-operative Republic of Guyana': 'GY',
      'Suriname': 'SR', 'Republic of Suriname': 'SR',
      'French Guiana': 'GF',
      
      // Europe + Arctic
      'United Kingdom': 'GB', 'Great Britain': 'GB', 'England': 'GB', 'Scotland': 'GB', 'Wales': 'GB',
      'France': 'FR', 'French Republic': 'FR',
      'Germany': 'DE', 'Federal Republic of Germany': 'DE',
      'Italy': 'IT', 'Italian Republic': 'IT',
      'Spain': 'ES', 'Kingdom of Spain': 'ES',
      'Portugal': 'PT', 'Portuguese Republic': 'PT',
      'Netherlands': 'NL', 'Kingdom of the Netherlands': 'NL',
      'Belgium': 'BE', 'Kingdom of Belgium': 'BE',
      'Switzerland': 'CH', 'Swiss Confederation': 'CH',
      'Austria': 'AT', 'Republic of Austria': 'AT',
      'Poland': 'PL', 'Republic of Poland': 'PL',
      'Czech Republic': 'CZ', 'Czechia': 'CZ',
      'Slovakia': 'SK', 'Slovak Republic': 'SK',
      'Hungary': 'HU', 'Republic of Hungary': 'HU',
      'Romania': 'RO',
      'Bulgaria': 'BG', 'Republic of Bulgaria': 'BG',
      'Greece': 'GR', 'Hellenic Republic': 'GR',
      'Croatia': 'HR', 'Republic of Croatia': 'HR',
      'Serbia': 'RS', 'Republic of Serbia': 'RS',
      'Bosnia and Herzegovina': 'BA',
      'Montenegro': 'ME',
      'Albania': 'AL', 'Republic of Albania': 'AL',
      'North Macedonia': 'MK', 'Macedonia': 'MK',
      'Slovenia': 'SI', 'Republic of Slovenia': 'SI',
      'Ukraine': 'UA',
      'Belarus': 'BY', 'Republic of Belarus': 'BY',
      'Moldova': 'MD', 'Republic of Moldova': 'MD',
      'Lithuania': 'LT', 'Republic of Lithuania': 'LT',
      'Latvia': 'LV', 'Republic of Latvia': 'LV',
      'Estonia': 'EE', 'Republic of Estonia': 'EE',
      'Finland': 'FI', 'Republic of Finland': 'FI',
      'Sweden': 'SE', 'Kingdom of Sweden': 'SE',
      'Norway': 'NO', 'Kingdom of Norway': 'NO',
      'Denmark': 'DK', 'Kingdom of Denmark': 'DK',
      'Iceland': 'IS', 'Republic of Iceland': 'IS',
      'Ireland': 'IE', 'Republic of Ireland': 'IE',
      'Greenland': 'GL', 'Kalaallit Nunaat': 'GL', // Added Greenland
      
      // Asia
      'China': 'CN', "People's Republic of China": 'CN',
      'India': 'IN', 'Republic of India': 'IN',
      'Japan': 'JP',
      'South Korea': 'KR', 'Republic of Korea': 'KR',
      'North Korea': 'KP', "Democratic People's Republic of Korea": 'KP', 'Korea, North': 'KP', // Added variations
      'Indonesia': 'ID', 'Republic of Indonesia': 'ID',
      'Thailand': 'TH', 'Kingdom of Thailand': 'TH',
      'Vietnam': 'VN', 'Socialist Republic of Vietnam': 'VN',
      'Philippines': 'PH', 'Republic of the Philippines': 'PH',
      'Malaysia': 'MY',
      'Singapore': 'SG', 'Republic of Singapore': 'SG',
      'Myanmar': 'MM', 'Republic of the Union of Myanmar': 'MM', 'Burma': 'MM',
      'Cambodia': 'KH', 'Kingdom of Cambodia': 'KH',
      'Laos': 'LA', "Lao People's Democratic Republic": 'LA',
      'Bangladesh': 'BD', "People's Republic of Bangladesh": 'BD',
      'Pakistan': 'PK', 'Islamic Republic of Pakistan': 'PK',
      'Afghanistan': 'AF', 'Islamic Republic of Afghanistan': 'AF',
      'Iran': 'IR', 'Islamic Republic of Iran': 'IR',
      'Iraq': 'IQ', 'Republic of Iraq': 'IQ',
      'Syria': 'SY', 'Syrian Arab Republic': 'SY',
      'Turkey': 'TR', 'Republic of Turkey': 'TR',
      'Saudi Arabia': 'SA', 'Kingdom of Saudi Arabia': 'SA',
      'United Arab Emirates': 'AE',
      'Kuwait': 'KW', 'State of Kuwait': 'KW',
      'Qatar': 'QA', 'State of Qatar': 'QA',
      'Bahrain': 'BH', 'Kingdom of Bahrain': 'BH',
      'Oman': 'OM', 'Sultanate of Oman': 'OM',
      'Yemen': 'YE', 'Republic of Yemen': 'YE',
      'Jordan': 'JO', 'Hashemite Kingdom of Jordan': 'JO',
      'Lebanon': 'LB', 'Lebanese Republic': 'LB',
      'Israel': 'IL', 'State of Israel': 'IL',
      'Palestine': 'PS', 'State of Palestine': 'PS',
      'Cyprus': 'CY', 'Republic of Cyprus': 'CY',
      'Georgia': 'GE',
      'Armenia': 'AM', 'Republic of Armenia': 'AM',
      'Azerbaijan': 'AZ', 'Republic of Azerbaijan': 'AZ',
      'Kazakhstan': 'KZ', 'Republic of Kazakhstan': 'KZ',
      'Uzbekistan': 'UZ', 'Republic of Uzbekistan': 'UZ',
      'Turkmenistan': 'TM',
      'Tajikistan': 'TJ', 'Republic of Tajikistan': 'TJ',
      'Kyrgyzstan': 'KG', 'Kyrgyz Republic': 'KG',
      'Mongolia': 'MN',
      'Nepal': 'NP', 'Federal Democratic Republic of Nepal': 'NP',
      'Bhutan': 'BT', 'Kingdom of Bhutan': 'BT',
      'Sri Lanka': 'LK', 'Democratic Socialist Republic of Sri Lanka': 'LK',
      'Maldives': 'MV', 'Republic of Maldives': 'MV',
      
      // Africa
      'Russia': 'RU', 'Russian Federation': 'RU',
      'Egypt': 'EG', 'Arab Republic of Egypt': 'EG',
      'Libya': 'LY', 'State of Libya': 'LY',
      'Tunisia': 'TN', 'Tunisian Republic': 'TN',
      'Algeria': 'DZ', "People's Democratic Republic of Algeria": 'DZ',
      'Morocco': 'MA', 'Kingdom of Morocco': 'MA',
      'Western Sahara': 'EH', 'Sahrawi Arab Democratic Republic': 'EH', 'W. Sahara': 'EH', // Added abbreviated form
      'Sudan': 'SD', 'Republic of the Sudan': 'SD',
      'South Sudan': 'SS', 'Republic of South Sudan': 'SS',
      'Ethiopia': 'ET', 'Federal Democratic Republic of Ethiopia': 'ET',
      'Eritrea': 'ER', 'State of Eritrea': 'ER', 'Eretria': 'ER', // Added Eritrea with typo variation
      'Kenya': 'KE', 'Republic of Kenya': 'KE',
      'Uganda': 'UG', 'Republic of Uganda': 'UG',
      'Tanzania': 'TZ', 'United Republic of Tanzania': 'TZ',
      'Somalia': 'SO', 'Federal Republic of Somalia': 'SO',
      'Somaliland': 'XS', // Somaliland (disputed territory)
      'Republic of Somaliland': 'XS',
      'Somali Land': 'XS',
      'SomaliLand': 'XS',
      'Somalia (Somaliland)': 'XS',
      'Northern Somalia': 'XS',
      'Hargeisa': 'XS', // Capital of Somaliland
      'Nigeria': 'NG', 'Federal Republic of Nigeria': 'NG',
      'Ghana': 'GH', 'Republic of Ghana': 'GH',
      'Ivory Coast': 'CI', "Côte d'Ivoire": 'CI', 'Republic of Côte d\'Ivoire': 'CI',
      'Liberia': 'LR', 'Republic of Liberia': 'LR', // Added Liberia
      'Sierra Leone': 'SL', 'Republic of Sierra Leone': 'SL', // Added Sierra Leone
      'Senegal': 'SN', 'Republic of Senegal': 'SN',
      'Mali': 'ML', 'Republic of Mali': 'ML',
      'Mauritania': 'MR', 'Islamic Republic of Mauritania': 'MR', // Added Mauritania
      'Burkina Faso': 'BF',
      'Benin': 'BJ', 'Republic of Benin': 'BJ', // Added Benin
      'Niger': 'NE', 'Republic of Niger': 'NE',
      'Chad': 'TD', 'Republic of Chad': 'TD',
      'Cameroon': 'CM', 'Republic of Cameroon': 'CM',
      'Central African Republic': 'CF', 'Central African Rep.': 'CF', // Added abbreviated form
      'Democratic Republic of the Congo': 'CD', 'Dem. Rep. Congo': 'CD', // Added abbreviated form
      'Republic of the Congo': 'CG',
      'Gabon': 'GA', 'Gabonese Republic': 'GA',
      'Equatorial Guinea': 'GQ', 'Republic of Equatorial Guinea': 'GQ',
      'South Africa': 'ZA', 'Republic of South Africa': 'ZA',
      'Namibia': 'NA', 'Republic of Namibia': 'NA',
      'Botswana': 'BW', 'Republic of Botswana': 'BW',
      'Zimbabwe': 'ZW', 'Republic of Zimbabwe': 'ZW',
      'Zambia': 'ZM', 'Republic of Zambia': 'ZM',
      'Malawi': 'MW', 'Republic of Malawi': 'MW',
      'Mozambique': 'MZ', 'Republic of Mozambique': 'MZ',
      'Madagascar': 'MG', 'Republic of Madagascar': 'MG',
      'Angola': 'AO', 'Republic of Angola': 'AO',
      
      // Oceania
      'Australia': 'AU', 'Commonwealth of Australia': 'AU',
      'New Zealand': 'NZ',
      'Papua New Guinea': 'PG', 'Independent State of Papua New Guinea': 'PG', // Added Papua New Guinea
      'Fiji': 'FJ', 'Republic of Fiji': 'FJ',
      
      // Caribbean & Central America
      'Cuba': 'CU', 'Republic of Cuba': 'CU',
      'Jamaica': 'JM',
      'Haiti': 'HT', 'Republic of Haiti': 'HT',
      'Dominican Republic': 'DO',
      'Puerto Rico': 'PR',
      'Trinidad and Tobago': 'TT', 'Republic of Trinidad and Tobago': 'TT',
      'Barbados': 'BB',
      'Guatemala': 'GT', 'Republic of Guatemala': 'GT',
      'Belize': 'BZ',
      'El Salvador': 'SV', 'Republic of El Salvador': 'SV',
      'Honduras': 'HN', 'Republic of Honduras': 'HN',
      'Nicaragua': 'NI', 'Republic of Nicaragua': 'NI',
      'Costa Rica': 'CR', 'Republic of Costa Rica': 'CR',
      'Panama': 'PA', 'Republic of Panama': 'PA',
      
      // Special territories and regions
      'Antarctica': 'AQ', // Added Antarctica
      'Svalbard and Jan Mayen': 'SJ',
      'Faroe Islands': 'FO',
      'Åland Islands': 'AX'
    };

    // Try exact match first
    if (nameToCode[countryName]) {
      return nameToCode[countryName];
    }

    // Try partial matches for countries with complex names
    for (const [name, code] of Object.entries(nameToCode)) {
      if (countryName.includes(name) || name.includes(countryName)) {
        return code;
      }
    }

    return null;
  };

  // Get proper country name for display
  const getCountryName = (geo) => {
    if (!geo || !geo.properties) return 'Unknown Country';
    
    const properties = geo.properties;
    
    // Try different name properties in order of preference
    const possibleNames = [
      properties.NAME_EN,
      properties.NAME,
      properties.ADMIN,
      properties.name,
      properties.admin,
      properties.NAME_LONG,
      properties.FORMAL_EN,
      properties.FORMAL_FR
    ].filter(Boolean);

    // Return the first non-empty name we find
    for (const name of possibleNames) {
      if (name && name.trim() && name !== 'Unknown' && name !== 'N/A') {
        return name.trim();
      }
    }

    console.log('⚠️ Could not determine country name for:', properties);
    return 'Unknown Country';
  };

  // Get country code from geography properties - comprehensive approach
  const getCountryCode = (geo) => {
    if (!geo || !geo.properties) {
      console.log('❌ No geo properties');
      return null;
    }

    const properties = geo.properties;
    
    // Log all properties for the first time we see them

    
    // Try different property names that might contain the country code
    const possibleCodes = [
      properties.ISO_A2,
      properties.ISO_A3, 
      properties.ADM0_A3,
      properties.ISO3,
      properties.ISO2,
      properties.SOV_A3,
      properties.ADM0_ISO,
      properties.BRK_A3,
      properties.iso_a2,
      properties.iso_a3,
      properties.adm0_a3,
      properties.country_code,
      properties.code,
      properties.CODE,
      properties.COUNTRY_CODE
    ].filter(code => code && code !== '-99' && code !== 'undefined' && code !== null);

    const countryName = getCountryName(geo);
    console.log(`🔍 Trying codes for ${countryName}:`, possibleCodes);

    // Return the first valid code we find
    for (const code of possibleCodes) {
      if (code && code.length >= 2) {
        const finalCode = code.length === 3 ? convertISO3ToISO2(code) : code.toUpperCase();
        console.log(`✅ Found code: ${finalCode} for ${countryName}`);
        return finalCode;
      }
    }

    // If no ISO codes found, try mapping by country name
    if (countryName && countryName !== 'Unknown Country') {
      const codeFromName = getCountryCodeByName(countryName);
      if (codeFromName) {
        console.log(`✅ Mapped by name: ${countryName} → ${codeFromName}`);
        return codeFromName;
      }
    }

    console.log('⚠️ Could not determine country code for:', {
      name: countryName,
      allNameProperties: {
        NAME: properties.NAME,
        NAME_EN: properties.NAME_EN,
        ADMIN: properties.ADMIN,
        NAME_LONG: properties.NAME_LONG
      },
      checkedProperties: Object.keys(properties).filter(key => 
        key.toLowerCase().includes('iso') || 
        key.toLowerCase().includes('code') || 
        key.toLowerCase().includes('name') ||
        key.toLowerCase().includes('admin')
      )
    });

    return null;
  };

  // Convert ISO3 (3-letter) to ISO2 (2-letter) codes
  const convertISO3ToISO2 = (iso3) => {
    const iso3ToIso2 = {
      'USA': 'US', 'CAN': 'CA', 'MEX': 'MX', 'BRA': 'BR', 'ARG': 'AR',
      'GBR': 'GB', 'FRA': 'FR', 'DEU': 'DE', 'ITA': 'IT', 'ESP': 'ES',
      'RUS': 'RU', 'CHN': 'CN', 'IND': 'IN', 'JPN': 'JP', 'AUS': 'AU',
      'KOR': 'KR', 'PRK': 'KP', 'IRN': 'IR', 'SYR': 'SY', 'AFG': 'AF',
      'SAU': 'SA', 'TUR': 'TR', 'EGY': 'EG', 'NGA': 'NG', 'ZAF': 'ZA',
      'UKR': 'UA', 'POL': 'PL', 'NLD': 'NL', 'BEL': 'BE', 'CHE': 'CH',
      'NOR': 'NO', 'SWE': 'SE', 'DNK': 'DK', 'FIN': 'FI', 'AUT': 'AT',
      'CZE': 'CZ', 'SVK': 'SK', 'HUN': 'HU', 'ROM': 'RO', 'BGR': 'BG',
      'GRC': 'GR', 'HRV': 'HR', 'SRB': 'RS', 'BIH': 'BA', 'MNE': 'ME',
      'ALB': 'AL', 'MKD': 'MK', 'SVN': 'SI', 'EST': 'EE', 'LVA': 'LV',
      'LTU': 'LT', 'BLR': 'BY', 'MDA': 'MD', 'ISL': 'IS', 'IRL': 'IE',
      'PRT': 'PT', 'AND': 'AD', 'MCO': 'MC', 'LIE': 'LI', 'SMR': 'SM',
      'VAT': 'VA', 'MLT': 'MT', 'CYP': 'CY'
    };
    return iso3ToIso2[iso3.toUpperCase()] || iso3.slice(0, 2);
  };

  // Get country color based on status
  const getCountryColor = (geo) => {
    const countryCode = getCountryCode(geo);
    const countryName = geo.properties.NAME_EN || geo.properties.NAME || geo.properties.ADMIN;
    
    if (!countryCode) {
      console.log('⚪ NO CODE:', countryName);
      return '#6B7280'; // Gray for unknown
    }
    
    if (allowedCountries.includes(countryCode)) {
      console.log('✅ ALLOWED:', countryCode, countryName);
      return '#22C55E'; // Green for allowed
    } else if (blockedCountries.includes(countryCode)) {
      console.log('🚫 BLOCKED:', countryCode, countryName);
      return '#EF4444'; // Red for blocked
    }
    
    console.log('⚪ NEUTRAL:', countryCode, countryName);
    return '#6B7280'; // Gray for neutral
  };

  const getCountryStatus = (geo) => {
    const countryCode = getCountryCode(geo);
    
    if (!countryCode) {
      return 'Unknown';
    }
    
    if (allowedCountries.includes(countryCode)) {
      return 'Allowed';
    } else if (blockedCountries.includes(countryCode)) {
      return 'Blocked';
    }
    return 'Neutral';
  };

  return (
    <div className="w-full h-full bg-black rounded-lg overflow-hidden relative">
      {/* Top Legend */}
      <div className="absolute top-4 left-4 bg-black bg-opacity-80 text-white p-3 rounded-lg text-sm z-10">
        <div className="flex items-center space-x-6">
          <div className="flex items-center space-x-2">
            <div className="w-4 h-4 bg-green-500 rounded"></div>
            <span className="text-green-400 font-medium">{allowedCountries.length} Allowed</span>
          </div>
          <div className="flex items-center space-x-2">
            <div className="w-4 h-4 bg-red-500 rounded"></div>
            <span className="text-red-400 font-medium">{blockedCountries.length} Blocked</span>
          </div>
        </div>
      </div>

      {/* Hover tooltip */}
      {hoveredCountry && (
        <div className="absolute top-4 right-4 bg-black bg-opacity-90 text-white p-3 rounded-lg text-sm z-10 shadow-lg">
          <div className="font-bold text-lg">{getCountryName(hoveredCountry)}</div>
          <div className={`font-medium mt-1 ${
            getCountryStatus(hoveredCountry) === 'Allowed' ? 'text-green-400' :
            getCountryStatus(hoveredCountry) === 'Blocked' ? 'text-red-400' : 'text-gray-400'
          }`}>
            Status: {getCountryStatus(hoveredCountry)}
          </div>
        </div>
      )}

      {/* World Map */}
      <ComposableMap
        projectionConfig={{
          scale: 185,
          center: [0, 10]
        }}
        width={1400}
        height={700}
        style={{ width: '100%', height: '100%' }}
      >
        <ZoomableGroup>
          <Geographies geography={geoUrl}>
            {({ geographies }) => {
              console.log('🗺️ Loaded', geographies.length, 'countries from world atlas');
              
              // Enhanced debugging: Log first few countries with all their properties
              if (geographies.length > 0) {
                console.log('🔍 FIRST COUNTRY FULL DATA:', geographies[0]);
                console.log('🔍 FIRST COUNTRY PROPERTIES:', geographies[0].properties);
                console.log('🔍 ALL PROPERTY KEYS:', Object.keys(geographies[0].properties));
                
                // Test a few countries
                for (let i = 0; i < Math.min(10, geographies.length); i++) {
                  const country = geographies[i];
                  const code = getCountryCode(country);
                  const name = country.properties.NAME || country.properties.NAME_EN || country.properties.ADMIN;
                  console.log(`🧪 Test ${i + 1}: ${name} → ${code || 'NULL'}`);
                }
              }
              
              return geographies.map((geo) => (
                <Geography
                  key={geo.rsmKey}
                  geography={geo}
                  fill={getCountryColor(geo)}
                  stroke="#1a1a1a"
                  strokeWidth={0.5}
                  onMouseEnter={() => {
                    setHoveredCountry(geo);
                  }}
                  onMouseLeave={() => {
                    setHoveredCountry(null);
                  }}
                  style={{
                    default: { outline: 'none' },
                    hover: { 
                      outline: 'none',
                      stroke: '#60A5FA',
                      strokeWidth: 2,
                      cursor: 'pointer'
                    },
                    pressed: { outline: 'none' }
                  }}
                />
              ));
            }}
          </Geographies>
        </ZoomableGroup>
      </ComposableMap>


    </div>
  );
};

// Simplified World Map Component as fallback
const SimpleWorldMap = ({ allowedCountries, blockedCountries }) => {
  const getCountryColor = (countryCode) => {
    if (allowedCountries.includes(countryCode)) {
      return '#22C55E'; // Green for allowed
    } else if (blockedCountries.includes(countryCode)) {
      return '#EF4444'; // Red for blocked
    }
    return '#6B7280'; // Gray for neutral
  };

  return (
    <div className="w-full h-full bg-dark-700 rounded-lg overflow-hidden flex items-center justify-center">
      <div className="text-center">
        <EuiIcon type="globe" size="xxl" className="text-primary-400" style={{ marginBottom: '16px' }} />
        <h3 className="text-lg font-semibold text-white mb-2">World Map Visualization</h3>
        <p className="text-dark-400 text-sm mb-4">
          Geographic visualization showing country restrictions
        </p>
        
        <div className="grid grid-cols-3 gap-4 text-sm">
          <div className="bg-success-900 border border-success-700 rounded-lg p-3">
            <div className="w-4 h-4 bg-green-500 rounded mx-auto mb-2"></div>
            <div className="text-success-300 font-medium">Allowed</div>
            <div className="text-success-400 text-lg font-bold">{allowedCountries.length}</div>
          </div>
          
          <div className="bg-threat-critical-900 border border-threat-critical-700 rounded-lg p-3">
            <div className="w-4 h-4 bg-red-500 rounded mx-auto mb-2"></div>
            <div className="text-threat-critical-300 font-medium">Blocked</div>
            <div className="text-threat-critical-400 text-lg font-bold">{blockedCountries.length}</div>
          </div>
          
          <div className="bg-dark-600 border border-dark-500 rounded-lg p-3">
            <div className="w-4 h-4 bg-gray-500 rounded mx-auto mb-2"></div>
            <div className="text-dark-300 font-medium">Neutral</div>
            <div className="text-dark-400 text-lg font-bold">{COUNTRIES.length - allowedCountries.length - blockedCountries.length}</div>
          </div>
        </div>
        
        <p className="text-dark-500 text-xs mt-4">
          Loading world map...
        </p>
      </div>
    </div>
  );
};

// Reliable SVG World Map Component
const ReliableWorldMap = ({ allowedCountries, blockedCountries }) => {
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    // Try to load the real world map first
    const timer = setTimeout(() => {
      setLoading(false);
    }, 2000);

    return () => clearTimeout(timer);
  }, []);

  if (loading) {
    return (
      <div className="w-full h-full flex items-center justify-center bg-dark-700 rounded-lg">
        <div className="text-center">
          <EuiLoadingSpinner size="l" style={{ marginBottom: '8px' }} />
          <p className="text-white">Loading real world map...</p>
        </div>
      </div>
    );
  }

  return <RealWorldMap allowedCountries={allowedCountries} blockedCountries={blockedCountries} />;
};

const GeoRestrictionsModal = ({ isOpen, onClose }) => {
  const [allowedCountries, setAllowedCountries] = useState([]);
  const [blockedCountries, setBlockedCountries] = useState([]);
  const [allowedSearchTerm, setAllowedSearchTerm] = useState('');
  const [blockedSearchTerm, setBlockedSearchTerm] = useState('');
  const [hasChanges, setHasChanges] = useState(false);
  const [draggedItem, setDraggedItem] = useState(null);
  const [activeTab, setActiveTab] = useState('lists');

  const queryClient = useQueryClient();

  const { data: geoData, isLoading, error, refetch } = useQuery({
    queryKey: ['geoCountries'],
    queryFn: getGeoCountries,
    enabled: isOpen,
    refetchInterval: 10000,
  });

  const setCountriesMutation = useMutation({
    mutationFn: setGeoCountries,
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['geoCountries'] });
      toast.success('Geo-restrictions updated successfully!');
      setHasChanges(false);
      onClose();
    },
    onError: (error) => {
      toast.error(`Failed to update geo-restrictions: ${error.message}`);
    },
  });

  useEffect(() => {
    console.log('🔄 Data update:', { geoData, isOpen });
    
    if (geoData?.data) {
      const allowed = geoData.data;
      const blocked = COUNTRIES.filter(country => !allowed.includes(country.code)).map(c => c.code);
      setAllowedCountries(allowed);
      setBlockedCountries(blocked);
      console.log('✅ Data from API:', { allowed: allowed.length, blocked: blocked.length });
    } else {
      // Test data with more countries for demonstration
      const testAllowed = ['US', 'CA', 'GB', 'DE', 'FR', 'AU', 'JP', 'KR', 'IT', 'ES'];
      const testBlocked = ['CN', 'RU', 'IR', 'SY', 'KP', 'CU', 'VE', 'BY', 'MM', 'AF'];
      const remaining = COUNTRIES.filter(c => !testAllowed.includes(c.code) && !testBlocked.includes(c.code)).map(c => c.code);
      
      setAllowedCountries(testAllowed);
      setBlockedCountries([...testBlocked, ...remaining]);
      console.log('🧪 TEST DATA SET:', { 
        allowed: testAllowed.length, 
        blocked: testBlocked.length + remaining.length,
        total: COUNTRIES.length 
      });
    }
  }, [geoData]);

  const filteredAllowedCountries = COUNTRIES.filter(country =>
    allowedCountries.includes(country.code) &&
    (country.name.toLowerCase().includes(allowedSearchTerm.toLowerCase()) ||
     country.code.toLowerCase().includes(allowedSearchTerm.toLowerCase()))
  );

  const filteredBlockedCountries = COUNTRIES.filter(country =>
    blockedCountries.includes(country.code) &&
    (country.name.toLowerCase().includes(blockedSearchTerm.toLowerCase()) ||
     country.code.toLowerCase().includes(blockedSearchTerm.toLowerCase()))
  );

  const moveToAllowed = (countryCode) => {
    const newBlocked = blockedCountries.filter(code => code !== countryCode);
    const newAllowed = [...allowedCountries, countryCode];
    setBlockedCountries(newBlocked);
    setAllowedCountries(newAllowed);
    setHasChanges(true);
    console.log('📝 MOVED TO ALLOWED:', countryCode);
  };

  const moveToBlocked = (countryCode) => {
    const newAllowed = allowedCountries.filter(code => code !== countryCode);
    const newBlocked = [...blockedCountries, countryCode];
    setAllowedCountries(newAllowed);
    setBlockedCountries(newBlocked);
    setHasChanges(true);
    console.log('📝 MOVED TO BLOCKED:', countryCode);
  };

  const handleDragStart = (e, countryCode, source) => {
    setDraggedItem({ countryCode, source });
    e.dataTransfer.effectAllowed = 'move';
  };

  const handleDragOver = (e) => {
    e.preventDefault();
    e.dataTransfer.dropEffect = 'move';
  };

  const handleDrop = (e, target) => {
    e.preventDefault();
    if (!draggedItem) return;

    const { countryCode, source } = draggedItem;
    
    if (source === 'allowed' && target === 'blocked') {
      moveToBlocked(countryCode);
    } else if (source === 'blocked' && target === 'allowed') {
      moveToAllowed(countryCode);
    }
    
    setDraggedItem(null);
  };

  const handleSave = () => {
    if (!hasChanges) {
      toast.info('No changes to save');
      return;
    }
    setCountriesMutation.mutate(allowedCountries);
  };

  const handleCancel = () => {
    if (hasChanges) {
      if (window.confirm('You have unsaved changes. Are you sure you want to close?')) {
        if (geoData?.data) {
          const allowed = geoData.data;
          const blocked = COUNTRIES.filter(country => !allowed.includes(country.code)).map(c => c.code);
          setAllowedCountries(allowed);
          setBlockedCountries(blocked);
        }
        setHasChanges(false);
        onClose();
      }
    } else {
      onClose();
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-dark-800 rounded-xl border border-dark-700 w-full max-w-7xl h-[90vh] flex flex-col">
        <div className="flex items-center justify-between p-6 border-b border-dark-700 flex-shrink-0">
          <div className="flex items-center space-x-3">
            <EuiIcon type="globe" size="m" color="primary" />
            <div>
              <h2 className="text-xl font-semibold text-white">Geo-Restrictions Configuration</h2>
              <p className="text-dark-400 text-sm">Manage allowed and blocked countries for network access</p>
            </div>
          </div>
          <button
            onClick={handleCancel}
            className="p-2 hover:bg-dark-700 rounded-lg transition-colors"
          >
            <EuiIcon type="cross" size="m" color="subdued" />
          </button>
        </div>

        <div className="flex border-b border-dark-700 flex-shrink-0">
          <button
            onClick={() => setActiveTab('lists')}
            className={`flex items-center space-x-2 px-6 py-3 text-sm font-medium transition-colors ${
              activeTab === 'lists'
                ? 'text-primary-400 border-b-2 border-primary-400 bg-dark-700'
                : 'text-dark-400 hover:text-white'
            }`}
          >
            <EuiIcon type="grab" size="s" />
            <span>Country Lists ({COUNTRIES.length} total)</span>
          </button>
          <button
            onClick={() => setActiveTab('map')}
            className={`flex items-center space-x-2 px-6 py-3 text-sm font-medium transition-colors ${
              activeTab === 'map'
                ? 'text-primary-400 border-b-2 border-primary-400 bg-dark-700'
                : 'text-dark-400 hover:text-white'
            }`}
          >
            <EuiIcon type="globe" size="s" />
            <span>World Map</span>
          </button>
        </div>

        <div className="flex-1 flex flex-col min-h-0 overflow-hidden">
          {isLoading ? (
            <div className="flex items-center justify-center h-64">
              <EuiLoadingSpinner size="m" />
              <span className="ml-3 text-dark-400">Loading geo-restrictions...</span>
            </div>
          ) : error ? (
            <div className="flex items-center justify-center h-64">
              <div className="text-center">
                <EuiIcon type="alert" size="xxl" color="danger" style={{ marginBottom: '16px' }} />
                <h3 className="text-lg font-medium text-white mb-2">Failed to load geo-restrictions</h3>
                <p className="text-dark-400 mb-4">Please check your connection and try again.</p>
                <button 
                  onClick={refetch}
                  className="px-4 py-2 bg-primary-600 text-white rounded-lg hover:bg-primary-700 transition-colors"
                >
                  Retry
                </button>
              </div>
            </div>
          ) : (
            <>
              {activeTab === 'lists' ? (
                <div className="flex-1 flex min-h-0">
                  <div className="flex-1 flex flex-col border-r border-dark-700">
                    <div className="p-4 border-b border-dark-700">
                      <div className="flex items-center justify-between mb-3">
                        <h3 className="text-lg font-semibold text-white flex items-center">
                          <EuiIcon type="check" size="m" color="success" style={{ marginRight: '8px' }} />
                          Allowed Countries
                        </h3>
                        <span className="text-2xl font-bold text-success-400">{allowedCountries.length}</span>
                      </div>
                      
                      <div className="relative">
                        <EuiIcon type="search" size="s" color="subdued" style={{ position: 'absolute', left: '12px', top: '50%', transform: 'translateY(-50%)' }} />
                        <input
                          type="text"
                          value={allowedSearchTerm}
                          onChange={(e) => setAllowedSearchTerm(e.target.value)}
                          placeholder="Search allowed countries..."
                          className="w-full pl-10 pr-4 py-2 bg-dark-600 text-white rounded-lg border border-dark-500 focus:outline-none focus:border-primary-500"
                        />
                      </div>
                    </div>

                    <div 
                      className="flex-1 overflow-y-auto p-4"
                      onDragOver={handleDragOver}
                      onDrop={(e) => handleDrop(e, 'allowed')}
                    >
                      <div className="space-y-2">
                        {filteredAllowedCountries.map(country => (
                          <div
                            key={country.code}
                            draggable
                            onDragStart={(e) => handleDragStart(e, country.code, 'allowed')}
                            className="flex items-center justify-between p-3 bg-success-900 border border-success-700 rounded-lg cursor-move hover:bg-success-800 transition-colors"
                          >
                            <div className="flex items-center space-x-3">
                              <EuiIcon type="grab" size="s" color="success" />
                              <div>
                                <div className="font-medium text-success-300">{country.name}</div>
                                <div className="text-sm text-success-400">{country.code}</div>
                              </div>
                            </div>
                            <button
                              onClick={() => moveToBlocked(country.code)}
                              className="p-1 hover:bg-success-700 rounded transition-colors"
                              title="Move to blocked"
                            >
                              <EuiIcon type="arrowRight" size="s" color="success" />
                            </button>
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>

                  <div className="flex-1 flex flex-col">
                    <div className="p-4 border-b border-dark-700">
                      <div className="flex items-center justify-between mb-3">
                        <h3 className="text-lg font-semibold text-white flex items-center">
                          <EuiIcon type="alert" size="m" color="danger" style={{ marginRight: '8px' }} />
                          Blocked Countries
                        </h3>
                        <span className="text-2xl font-bold text-threat-critical">{blockedCountries.length}</span>
                      </div>
                      
                      <div className="relative">
                        <EuiIcon type="search" size="s" color="subdued" style={{ position: 'absolute', left: '12px', top: '50%', transform: 'translateY(-50%)' }} />
                        <input
                          type="text"
                          value={blockedSearchTerm}
                          onChange={(e) => setBlockedSearchTerm(e.target.value)}
                          placeholder="Search blocked countries..."
                          className="w-full pl-10 pr-4 py-2 bg-dark-600 text-white rounded-lg border border-dark-500 focus:outline-none focus:border-primary-500"
                        />
                      </div>
                    </div>

                    <div 
                      className="flex-1 overflow-y-auto p-4"
                      onDragOver={handleDragOver}
                      onDrop={(e) => handleDrop(e, 'blocked')}
                    >
                      <div className="space-y-2">
                        {filteredBlockedCountries.map(country => (
                          <div
                            key={country.code}
                            draggable
                            onDragStart={(e) => handleDragStart(e, country.code, 'blocked')}
                            className="flex items-center justify-between p-3 bg-threat-critical-900 border border-threat-critical-700 rounded-lg cursor-move hover:bg-threat-critical-800 transition-colors"
                          >
                            <div className="flex items-center space-x-3">
                              <EuiIcon type="grab" size="s" color="danger" />
                              <div>
                                <div className="font-medium text-threat-critical-300">{country.name}</div>
                                <div className="text-sm text-threat-critical-400">{country.code}</div>
                              </div>
                            </div>
                            <button
                              onClick={() => moveToAllowed(country.code)}
                              className="p-1 hover:bg-threat-critical-700 rounded transition-colors"
                              title="Move to allowed"
                            >
                              <EuiIcon type="arrowLeft" size="s" color="danger" />
                            </button>
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>
                </div>
              ) : (
                <div className="flex-1 flex flex-col p-4 overflow-hidden">
                  <div className="mb-2 flex-shrink-0">
                    <h3 className="text-lg font-semibold text-white mb-1">World Map</h3>
                    <p className="text-dark-400 text-sm">
                      Real-time visualization of Firewall Geo Restrictions 
                    </p>
                  </div>
                  
                  <div className="flex-1 bg-dark-700 rounded-lg overflow-hidden" style={{ minHeight: '500px' }}>
                    <ReliableWorldMap 
                      allowedCountries={allowedCountries}
                      blockedCountries={blockedCountries}
                    />
                  </div>
                </div>
              )}
            </>
          )}
        </div>

        <div className="flex items-center justify-between p-6 border-t border-dark-700 flex-shrink-0">
          <div className="text-sm text-dark-400">
            {hasChanges && (
              <span className="text-warning-400">You have unsaved changes</span>
            )}
          </div>
          <div className="flex items-center space-x-3">
            <button
              onClick={handleCancel}
              className="px-4 py-2 bg-dark-600 text-white rounded-lg hover:bg-dark-500 transition-colors"
            >
              Cancel
            </button>
            <button
              onClick={handleSave}
              disabled={!hasChanges || setCountriesMutation.isLoading}
              className="flex items-center space-x-2 px-4 py-2 bg-primary-600 text-white rounded-lg hover:bg-primary-700 transition-colors disabled:opacity-50"
            >
              {setCountriesMutation.isLoading ? (
                <EuiLoadingSpinner size="s" />
              ) : (
                <EuiIcon type="save" size="s" />
              )}
              <span>Save Changes</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default GeoRestrictionsModal;
