import React, { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { 
  Shield, 
  Globe, 
  Ban, 
  Activity, 
  CheckCircle, 
  XCircle,
  RefreshCw,
  Edit,
  Power,
  AlertTriangle,
  Zap
} from 'lucide-react';
import { fetchPolicies, fetchWafConfiguration } from '../../services/api';

const RulesDisplay = () => {
  const [activeTab, setActiveTab] = useState('policy');

  // Fetch policies
  const { data: policies, isLoading: policiesLoading, error: policiesError, refetch: refetchPolicies } = useQuery({
    queryKey: ['policies'],
    queryFn: fetchPolicies,
    refetchInterval: 30000
  });

  // Fetch WAF configuration
  const { data: wafConfig, isLoading: wafLoading, error: wafError, refetch: refetchWaf } = useQuery({
    queryKey: ['wafConfig'],
    queryFn: fetchWafConfiguration,
    refetchInterval: 30000
  });

  const getSeverityColor = (severity) => {
    const colors = {
      critical: 'text-red-500 bg-red-500/10',
      high: 'text-orange-500 bg-orange-500/10',
      medium: 'text-yellow-500 bg-yellow-500/10',
      low: 'text-blue-500 bg-blue-500/10'
    };
    return colors[severity] || 'text-gray-500 bg-gray-500/10';
  };

  const getActionIcon = (provider, name) => {
    if (provider === 'waf') {
      if (name === 'block_ip') return <Ban className="w-4 h-4" />;
      if (name === 'challenge') return <Shield className="w-4 h-4" />;
      if (name === 'rate_limit') return <Zap className="w-4 h-4" />;
    }
    if (provider === 'firewall') {
      return <Globe className="w-4 h-4" />;
    }
    return <Shield className="w-4 h-4" />;
  };

  const renderPolicyRules = () => {
    if (policiesLoading) {
      return (
        <div className="flex items-center justify-center h-64">
          <RefreshCw className="w-8 h-8 animate-spin text-accent-blue" />
        </div>
      );
    }

    if (policiesError) {
      return (
        <div className="bg-red-500/10 border border-red-500/20 rounded-lg p-4">
          <p className="text-red-400">Failed to load policies: {policiesError.message}</p>
        </div>
      );
    }

    if (!policies?.rules || policies.rules.length === 0) {
      return (
        <div className="bg-dark-800 border border-dark-700 rounded-lg p-8 text-center">
          <Shield className="w-12 h-12 mx-auto mb-4 text-dark-400" />
          <p className="text-dark-300">No policy rules configured</p>
        </div>
      );
    }

    return (
      <div className="overflow-x-auto">
        <table className="w-full">
          <thead>
            <tr className="border-b border-dark-700">
              <th className="text-left py-3 px-4 text-xs font-medium text-dark-400 uppercase tracking-wider">Rule</th>
              <th className="text-left py-3 px-4 text-xs font-medium text-dark-400 uppercase tracking-wider">Type</th>
              <th className="text-left py-3 px-4 text-xs font-medium text-dark-400 uppercase tracking-wider">Severity</th>
              <th className="text-left py-3 px-4 text-xs font-medium text-dark-400 uppercase tracking-wider">Actions</th>
              <th className="text-left py-3 px-4 text-xs font-medium text-dark-400 uppercase tracking-wider">Status</th>
              <th className="text-left py-3 px-4 text-xs font-medium text-dark-400 uppercase tracking-wider">Stats</th>
              <th className="text-right py-3 px-4 text-xs font-medium text-dark-400 uppercase tracking-wider">Operations</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-dark-700">
            {policies.rules.map((rule) => (
              <tr key={rule.id} className="hover:bg-dark-800/50 transition-colors">
                <td className="py-4 px-4">
                  <div>
                    <p className="text-sm font-medium text-white">{rule.name}</p>
                    <p className="text-xs text-dark-400 mt-1">{rule.description}</p>
                  </div>
                </td>
                <td className="py-4 px-4">
                  <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-accent-blue/10 text-accent-blue">
                    {rule.when.type || 'any'}
                  </span>
                </td>
                <td className="py-4 px-4">
                  <div className="flex flex-wrap gap-1">
                    {rule.when.severity?.map(sev => (
                      <span key={sev} className={`inline-flex items-center px-2 py-0.5 rounded text-xs font-medium ${getSeverityColor(sev)}`}>
                        {sev}
                      </span>
                    ))}
                  </div>
                </td>
                <td className="py-4 px-4">
                  <div className="space-y-1">
                    {rule.then.actions.map((action, idx) => (
                      <div key={idx} className="flex items-center gap-2 text-xs text-dark-300">
                        {getActionIcon(action.provider, action.name)}
                        <span>{action.provider}:{action.name}</span>
                      </div>
                    ))}
                  </div>
                </td>
                <td className="py-4 px-4">
                  {rule.enabled ? (
                    <span className="inline-flex items-center gap-1 px-2 py-1 rounded-full text-xs font-medium bg-green-500/10 text-green-400">
                      <CheckCircle className="w-3 h-3" />
                      Enabled
                    </span>
                  ) : (
                    <span className="inline-flex items-center gap-1 px-2 py-1 rounded-full text-xs font-medium bg-dark-700 text-dark-400">
                      <XCircle className="w-3 h-3" />
                      Disabled
                    </span>
                  )}
                </td>
                <td className="py-4 px-4">
                  <div className="text-xs">
                    <p className="text-dark-300">
                      Success: <span className="text-white">{rule.success_rate?.toFixed(1) || 0}%</span>
                    </p>
                    <p className="text-dark-400">
                      {rule.trigger_count || 0} triggers
                    </p>
                  </div>
                </td>
                <td className="py-4 px-4 text-right">
                  <div className="flex items-center justify-end gap-2">
                    <button className="p-1 hover:bg-dark-700 rounded transition-colors">
                      <Edit className="w-4 h-4 text-dark-400" />
                    </button>
                    <button className="p-1 hover:bg-dark-700 rounded transition-colors">
                      <Power className="w-4 h-4 text-dark-400" />
                    </button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    );
  };

  const renderWafRules = () => {
    if (wafLoading) {
      return (
        <div className="flex items-center justify-center h-64">
          <RefreshCw className="w-8 h-8 animate-spin text-accent-blue" />
        </div>
      );
    }

    if (wafError) {
      return (
        <div className="bg-red-500/10 border border-red-500/20 rounded-lg p-4">
          <p className="text-red-400">Failed to load WAF configuration: {wafError.message}</p>
        </div>
      );
    }

    return (
      <div className="space-y-6">
        {/* Web ACLs */}
        <div className="bg-dark-800 rounded-lg border border-dark-700">
          <div className="px-6 py-4 border-b border-dark-700 flex items-center justify-between">
            <h3 className="text-lg font-semibold text-white">Web ACLs</h3>
            <button 
              onClick={refetchWaf}
              className="flex items-center gap-2 px-3 py-1 bg-dark-700 hover:bg-dark-600 rounded transition-colors"
            >
              <RefreshCw className="w-4 h-4" />
              <span className="text-sm">Refresh</span>
            </button>
          </div>
          <div className="p-6">
            {wafConfig?.web_acls?.length > 0 ? (
              <div className="space-y-3">
                {wafConfig.web_acls.map((acl) => (
                  <div key={acl.Id} className="flex items-center justify-between p-4 bg-dark-900 rounded-lg">
                    <div>
                      <p className="font-medium text-white">{acl.Name}</p>
                      <p className="text-xs text-dark-400 font-mono mt-1">{acl.Id}</p>
                    </div>
                    <button className="p-2 hover:bg-dark-800 rounded transition-colors">
                      <Edit className="w-4 h-4 text-dark-400" />
                    </button>
                  </div>
                ))}
              </div>
            ) : (
              <p className="text-dark-400 text-center py-8">No Web ACLs configured</p>
            )}
          </div>
        </div>

        {/* IP Sets */}
        <div className="bg-dark-800 rounded-lg border border-dark-700">
          <div className="px-6 py-4 border-b border-dark-700">
            <h3 className="text-lg font-semibold text-white">IP Sets</h3>
          </div>
          <div className="p-6">
            {wafConfig?.ip_sets?.length > 0 ? (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {wafConfig.ip_sets.map((ipSet) => (
                  <div key={ipSet.id} className="bg-dark-900 rounded-lg p-4">
                    <div className="flex items-center justify-between mb-3">
                      <h4 className="font-medium text-white">{ipSet.name}</h4>
                      <span className="text-xs text-dark-400">
                        {ipSet.addresses?.length || 0} IPs
                      </span>
                    </div>
                    <div className="space-y-2 max-h-32 overflow-y-auto">
                      {ipSet.addresses?.length > 0 ? (
                        ipSet.addresses.map((ip, idx) => (
                          <div key={idx} className="flex items-center justify-between py-1 text-xs">
                            <span className="font-mono text-dark-300">{ip}</span>
                            <button className="text-red-400 hover:text-red-300">
                              <XCircle className="w-3 h-3" />
                            </button>
                          </div>
                        ))
                      ) : (
                        <p className="text-dark-500 text-xs">No IPs in this set</p>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <p className="text-dark-400 text-center py-8">No IP Sets configured</p>
            )}
          </div>
        </div>
      </div>
    );
  };

  const renderFirewallRules = () => {
    const firewallActions = policies?.rules?.filter(rule => 
      rule.then.actions.some(action => action.provider === 'firewall')
    ) || [];

    if (firewallActions.length === 0) {
      return (
        <div className="bg-dark-800 border border-dark-700 rounded-lg p-8 text-center">
          <Globe className="w-12 h-12 mx-auto mb-4 text-dark-400" />
          <p className="text-dark-300">No firewall rules configured</p>
        </div>
      );
    }

    return (
      <div className="overflow-x-auto">
        <table className="w-full">
          <thead>
            <tr className="border-b border-dark-700">
              <th className="text-left py-3 px-4 text-xs font-medium text-dark-400 uppercase tracking-wider">Rule</th>
              <th className="text-left py-3 px-4 text-xs font-medium text-dark-400 uppercase tracking-wider">Action</th>
              <th className="text-left py-3 px-4 text-xs font-medium text-dark-400 uppercase tracking-wider">Target</th>
              <th className="text-left py-3 px-4 text-xs font-medium text-dark-400 uppercase tracking-wider">TTL</th>
              <th className="text-left py-3 px-4 text-xs font-medium text-dark-400 uppercase tracking-wider">Trigger</th>
              <th className="text-left py-3 px-4 text-xs font-medium text-dark-400 uppercase tracking-wider">Status</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-dark-700">
            {firewallActions.map((rule) => (
              rule.then.actions
                .filter(action => action.provider === 'firewall')
                .map((action, idx) => (
                  <tr key={`${rule.id}-${idx}`} className="hover:bg-dark-800/50 transition-colors">
                    <td className="py-4 px-4">
                      <p className="text-sm font-medium text-white">{rule.name}</p>
                    </td>
                    <td className="py-4 px-4">
                      <span className="inline-flex items-center gap-1 px-2 py-1 rounded text-xs font-medium bg-red-500/10 text-red-400">
                        <Ban className="w-3 h-3" />
                        {action.name}
                      </span>
                    </td>
                    <td className="py-4 px-4 text-sm text-dark-300">
                      {action.params.subnet_attr && `Subnet: ${action.params.subnet_attr}`}
                      {action.params.asn_attr && `ASN: ${action.params.asn_attr}`}
                    </td>
                    <td className="py-4 px-4 text-sm text-dark-300">
                      {action.params.ttl_s}s
                    </td>
                    <td className="py-4 px-4">
                      <div className="text-xs">
                        <p className="text-dark-300">Type: {rule.when.type}</p>
                        <p className="text-dark-400">Severity: {rule.when.severity?.join(', ')}</p>
                      </div>
                    </td>
                    <td className="py-4 px-4">
                      {rule.enabled ? (
                        <span className="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-green-500/10 text-green-400">
                          Active
                        </span>
                      ) : (
                        <span className="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-dark-700 text-dark-400">
                          Inactive
                        </span>
                      )}
                    </td>
                  </tr>
                ))
            ))}
          </tbody>
        </table>
      </div>
    );
  };

  return (
    <div className="p-6">
      <div className="flex items-center justify-between mb-6">
        <h1 className="text-2xl font-bold text-white">Security Rules Management</h1>
        <button 
          onClick={() => activeTab === 'policy' ? refetchPolicies() : refetchWaf()}
          className="flex items-center gap-2 px-4 py-2 bg-accent-blue hover:bg-accent-blue/80 rounded-lg transition-colors"
        >
          <RefreshCw className="w-4 h-4" />
          <span>Refresh</span>
        </button>
      </div>

      {/* Tabs */}
      <div className="border-b border-dark-700 mb-6">
        <nav className="-mb-px flex space-x-8">
          <button
            onClick={() => setActiveTab('policy')}
            className={`py-2 px-1 border-b-2 font-medium text-sm transition-colors ${
              activeTab === 'policy'
                ? 'border-accent-blue text-accent-blue'
                : 'border-transparent text-dark-400 hover:text-dark-300 hover:border-dark-600'
            }`}
          >
            Policy Rules
          </button>
          <button
            onClick={() => setActiveTab('waf')}
            className={`py-2 px-1 border-b-2 font-medium text-sm transition-colors ${
              activeTab === 'waf'
                ? 'border-accent-blue text-accent-blue'
                : 'border-transparent text-dark-400 hover:text-dark-300 hover:border-dark-600'
            }`}
          >
            WAF Rules
          </button>
          <button
            onClick={() => setActiveTab('firewall')}
            className={`py-2 px-1 border-b-2 font-medium text-sm transition-colors ${
              activeTab === 'firewall'
                ? 'border-accent-blue text-accent-blue'
                : 'border-transparent text-dark-400 hover:text-dark-300 hover:border-dark-600'
            }`}
          >
            Firewall Rules
          </button>
        </nav>
      </div>

      {/* Tab Content */}
      <div className="bg-dark-900 rounded-lg border border-dark-700">
        {activeTab === 'policy' && renderPolicyRules()}
        {activeTab === 'waf' && renderWafRules()}
        {activeTab === 'firewall' && renderFirewallRules()}
      </div>
    </div>
  );
};

export default RulesDisplay;