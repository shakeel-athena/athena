import React, { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { 
  Brain, 
  Search, 
  MapPin, 
  Shield, 
  AlertTriangle,
  Eye,
  ExternalLink,
  Clock
} from 'lucide-react';
import { formatDistanceToNow } from 'date-fns';
import { fetchThreatIntelligence, lookupIpReputation } from '../services/api';

const Intelligence = () => {
  const [searchIp, setSearchIp] = useState('');
  const [selectedIp, setSelectedIp] = useState(null);
  const [lookupResult, setLookupResult] = useState(null);

  const { data: intelligenceData, isLoading } = useQuery(
    'threatIntelligence',
    fetchThreatIntelligence,
    { refetchInterval: 300000 } // Refresh every 5 minutes
  );

  const handleIpLookup = async () => {
    if (!searchIp.trim()) return;
    
    try {
      const result = await lookupIpReputation(searchIp.trim());
      setLookupResult(result);
    } catch (error) {
      console.error('IP lookup failed:', error);
    }
  };


  const getRiskLevelBadge = (level) => {
    const badges = {
      critical: 'badge-critical',
      high: 'badge-high',
      medium: 'badge-medium',
      low: 'badge-low',
      unknown: 'badge-info',
    };
    return badges[level] || 'badge-info';
  };

  const getReputationScore = (score) => {
    if (score <= 20) return { color: 'text-threat-critical', label: 'Very High Risk' };
    if (score <= 40) return { color: 'text-threat-high', label: 'High Risk' };
    if (score <= 60) return { color: 'text-threat-medium', label: 'Medium Risk' };
    if (score <= 80) return { color: 'text-threat-low', label: 'Low Risk' };
    return { color: 'text-status-success', label: 'Clean' };
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="spinner w-8 h-8"></div>
        <span className="ml-3 text-dark-400">Loading threat intelligence...</span>
      </div>
    );
  }

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-white">Threat Intelligence</h1>
          <p className="text-dark-400 mt-1">IP reputation, threat feeds, and security intelligence</p>
        </div>
      </div>

      {/* IP Lookup */}
      <div className="card">
        <div className="card-header">
          <h3 className="text-lg font-semibold text-white flex items-center">
            <Search className="w-5 h-5 mr-2" />
            IP Reputation Lookup
          </h3>
        </div>
        <div className="card-content">
          <div className="flex space-x-4">
            <div className="flex-1">
              <input
                type="text"
                placeholder="Enter IP address (e.g., 192.168.1.1)"
                className="input"
                value={searchIp}
                onChange={(e) => setSearchIp(e.target.value)}
                onKeyPress={(e) => e.key === 'Enter' && handleIpLookup()}
              />
            </div>
            <button
              onClick={handleIpLookup}
              className="btn-primary flex items-center space-x-2"
            >
              <Search className="w-4 h-4" />
              <span>Lookup</span>
            </button>
          </div>
          
          {lookupResult && (
            <div className="mt-4 bg-dark-800 rounded-lg p-4 border border-dark-600">
              <div className="flex items-center justify-between mb-3">
                <h4 className="text-white font-medium">
                  Reputation for {lookupResult.ip}
                </h4>
                <span className={`badge ${getRiskLevelBadge(lookupResult.risk_level)}`}>
                  {lookupResult.risk_level.toUpperCase()}
                </span>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm">
                <div>
                  <span className="text-dark-400">Reputation Score:</span>
                  <div className={`text-lg font-bold ${getReputationScore(lookupResult.reputation_score)?.color || 'text-dark-400'}`}>
                    {lookupResult.reputation_score}/100
                  </div>
                  <div className="text-xs text-dark-400">
                    {getReputationScore(lookupResult.reputation_score)?.label || 'Unknown Risk'}
                  </div>
                </div>
                <div>
                  <span className="text-dark-400">ASN:</span>
                  <div className="text-white">{lookupResult.asn || 'Unknown'}</div>
                  <div className="text-xs text-dark-400">{lookupResult.asn_name || ''}</div>
                </div>
                <div>
                  <span className="text-dark-400">Location:</span>
                  <div className="text-white">
                    {lookupResult.city}, {lookupResult.country}
                  </div>
                </div>
              </div>
              
              {lookupResult.categories && lookupResult.categories.length > 0 && (
                <div className="mt-3">
                  <span className="text-dark-400 text-sm">Categories:</span>
                  <div className="flex flex-wrap gap-1 mt-1">
                    {lookupResult.categories.map((category, index) => (
                      <span key={index} className="badge-info text-xs">
                        {category.replace(/_/g, ' ')}
                      </span>
                    ))}
                  </div>
                </div>
              )}
            </div>
          )}
        </div>
      </div>

      {/* Intelligence Summary */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="card">
          <div className="card-content">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-dark-400">Total IPs Tracked</p>
                <p className="text-2xl font-bold text-white">
                  {intelligenceData?.summary?.total_ips || 0}
                </p>
              </div>
              <Brain className="w-8 h-8 text-accent-blue" />
            </div>
          </div>
        </div>

        <div className="card">
          <div className="card-content">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-dark-400">High Risk IPs</p>
                <p className="text-2xl font-bold text-threat-high">
                  {intelligenceData?.summary?.high_risk || 0}
                </p>
              </div>
              <AlertTriangle className="w-8 h-8 text-threat-high" />
            </div>
          </div>
        </div>

        <div className="card">
          <div className="card-content">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-dark-400">Critical Risk IPs</p>
                <p className="text-2xl font-bold text-threat-critical">
                  {intelligenceData?.summary?.critical_risk || 0}
                </p>
              </div>
              <Shield className="w-8 h-8 text-threat-critical" />
            </div>
          </div>
        </div>
      </div>

      {/* Threat Intelligence Table */}
      <div className="card">
        <div className="card-header">
          <h3 className="text-lg font-semibold text-white flex items-center">
            <Brain className="w-5 h-5 mr-2" />
            Known Threat IPs
          </h3>
        </div>
        
        <div className="overflow-x-auto">
          <table className="table">
            <thead>
              <tr>
                <th>IP Address</th>
                <th>Risk Level</th>
                <th>Score</th>
                <th>Location</th>
                <th>Categories</th>
                <th>Last Seen</th>
                <th>Feeds</th>
                <th></th>
              </tr>
            </thead>
            <tbody>
              {intelligenceData?.ip_reputation?.slice(0, 20).map((ip) => (
                <tr key={ip.ip}>
                  <td>
                    <span className="text-white font-mono">{ip.ip}</span>
                  </td>
                  <td>
                    <span className={`badge ${getRiskLevelBadge(ip.risk_level)}`}>
                      {ip.risk_level.toUpperCase()}
                    </span>
                  </td>
                  <td>
                    <div className={`font-medium ${getReputationScore(ip.reputation_score)?.color || 'text-dark-400'}`}>
                      {ip.reputation_score}/100
                    </div>
                  </td>
                  <td>
                    <div className="flex items-center space-x-1 text-sm">
                      <MapPin className="w-3 h-3 text-dark-400" />
                      <span className="text-white">{ip.city}, {ip.country}</span>
                    </div>
                    <div className="text-xs text-dark-400">{ip.asn_name}</div>
                  </td>
                  <td>
                    <div className="flex flex-wrap gap-1">
                      {ip.categories.slice(0, 2).map((category, index) => (
                        <span key={index} className="badge-info text-xs">
                          {category.replace(/_/g, ' ')}
                        </span>
                      ))}
                      {ip.categories.length > 2 && (
                        <span className="text-xs text-dark-400">
                          +{ip.categories.length - 2}
                        </span>
                      )}
                    </div>
                  </td>
                  <td>
                    <div className="flex items-center space-x-1 text-sm text-dark-400">
                      <Clock className="w-3 h-3" />
                      <span>
                        {formatDistanceToNow(new Date(ip.last_seen), { addSuffix: true })}
                      </span>
                    </div>
                  </td>
                  <td>
                    <div className="text-sm text-dark-300">
                      {ip.threat_feeds.length} sources
                    </div>
                  </td>
                  <td>
                    <button
                      onClick={() => setSelectedIp(ip)}
                      className="p-1 text-dark-400 hover:text-white transition-colors duration-150"
                      title="View details"
                    >
                      <Eye className="w-4 h-4" />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* IP Detail Modal */}
      {selectedIp && (
        <div className="fixed inset-0 z-50 overflow-y-auto">
          <div className="flex items-center justify-center min-h-screen px-4 pt-4 pb-20 text-center sm:block sm:p-0">
            <div className="fixed inset-0 transition-opacity bg-black bg-opacity-75" onClick={() => setSelectedIp(null)}></div>
            
            <div className="inline-block w-full max-w-4xl p-6 my-8 overflow-hidden text-left align-middle transition-all transform bg-dark-800 border border-dark-600 shadow-xl rounded-lg">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-lg font-medium text-white">
                  Threat Intelligence: {selectedIp.ip}
                </h3>
                <button
                  onClick={() => setSelectedIp(null)}
                  className="text-dark-400 hover:text-white"
                >
                  <ExternalLink className="w-5 h-5" />
                </button>
              </div>
              
              <div className="space-y-6">
                {/* Basic Info */}
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="text-sm text-dark-400">Risk Level</label>
                    <div className="mt-1">
                      <span className={`badge ${getRiskLevelBadge(selectedIp.risk_level)}`}>
                        {selectedIp.risk_level.toUpperCase()}
                      </span>
                    </div>
                  </div>
                  <div>
                    <label className="text-sm text-dark-400">Reputation Score</label>
                    <div className={`mt-1 text-lg font-bold ${getReputationScore(selectedIp.reputation_score)?.color || 'text-dark-400'}`}>
                      {selectedIp.reputation_score}/100
                    </div>
                  </div>
                </div>
                
                {/* Threat Feeds */}
                <div>
                  <label className="text-sm text-dark-400">Threat Intelligence Sources</label>
                  <div className="mt-2 space-y-2">
                    {selectedIp.threat_feeds.map((feed, index) => (
                      <div key={index} className="bg-dark-700 rounded p-3">
                        <div className="flex items-center justify-between">
                          <span className="text-white font-medium">{feed.source}</span>
                          <span className="text-sm text-dark-400">
                            Confidence: {feed.confidence}%
                          </span>
                        </div>
                        <div className="mt-1 flex flex-wrap gap-1">
                          {feed.categories.map((category, catIndex) => (
                            <span key={catIndex} className="badge-info text-xs">
                              {category}
                            </span>
                          ))}
                        </div>
                        <div className="text-xs text-dark-400 mt-1">
                          Last updated: {formatDistanceToNow(new Date(feed.last_updated), { addSuffix: true })}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
                
                {/* Attack Patterns */}
                {selectedIp.attack_patterns && selectedIp.attack_patterns.length > 0 && (
                  <div>
                    <label className="text-sm text-dark-400">Attack Patterns</label>
                    <div className="mt-2 space-y-2">
                      {selectedIp.attack_patterns.map((pattern, index) => (
                        <div key={index} className="bg-dark-700 rounded p-3">
                          <div className="flex items-center justify-between">
                            <span className="text-white font-medium capitalize">
                              {pattern.type.replace(/_/g, ' ')}
                            </span>
                            <span className="text-sm text-dark-400">
                              {pattern.frequency} attempts
                            </span>
                          </div>
                          <div className="text-sm text-dark-300 mt-1">
                            Success rate: {(pattern.success_rate * 100).toFixed(1)}%
                          </div>
                          {pattern.target_ports && (
                            <div className="text-xs text-dark-400 mt-1">
                              Target ports: {pattern.target_ports.join(', ')}
                            </div>
                          )}
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default Intelligence;
