import React, { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { 
  AlertTriangle, 
  Search, 
  RefreshCw, 
  Eye, 
  CheckCircle, 
  XCircle,
  Clock,
  MapPin
} from 'lucide-react';
import { formatDistanceToNow } from 'date-fns';
import { fetchAlerts, acknowledgeAlert, markFalsePositive } from '../services/api';
import { toast } from 'react-hot-toast';

const Alerts = () => {
  const [filters, setFilters] = useState({
    severity: '',
    type: '',
    timeRange: '24',
    search: ''
  });
  const [selectedAlert, setSelectedAlert] = useState(null);

  // FIXED: Updated to v5 object syntax
  const { data, isLoading, refetch } = useQuery({
    queryKey: ['alerts', filters],
    queryFn: () => fetchAlerts(filters),
    refetchInterval: 30000
  });

  const handleAcknowledge = async (alertId) => {
    try {
      await acknowledgeAlert(alertId);
      toast.success('Alert acknowledged');
      refetch();
    } catch (error) {
      toast.error('Failed to acknowledge alert');
    }
  };

  const handleFalsePositive = async (alertId) => {
    try {
      await markFalsePositive(alertId, 'Marked as false positive by analyst');
      toast.success('Alert marked as false positive');
      refetch();
    } catch (error) {
      toast.error('Failed to mark as false positive');
    }
  };

  const getSeverityBadge = (severity) => {
    const badges = {
      critical: 'badge-critical',
      high: 'badge-high',
      medium: 'badge-medium',
      low: 'badge-low',
    };
    return badges[severity] || 'badge-info';
  };


  return (
    <div className="space-y-6 animate-fade-in">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-white">Security Alerts</h1>
          <p className="text-dark-400 mt-1">Monitor and respond to security threats</p>
        </div>
        <div className="flex items-center space-x-3">
          <button
            onClick={() => refetch()}
            className="btn-secondary flex items-center space-x-2"
          >
            <RefreshCw className="w-4 h-4" />
            <span>Refresh</span>
          </button>
        </div>
      </div>

      {/* Filters */}
      <div className="card">
        <div className="card-content">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            {/* Search */}
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-dark-400" />
              <input
                type="text"
                placeholder="Search alerts..."
                className="input pl-10"
                value={filters.search}
                onChange={(e) => setFilters({ ...filters, search: e.target.value })}
              />
            </div>

            {/* Severity Filter */}
            <select
              className="input"
              value={filters.severity}
              onChange={(e) => setFilters({ ...filters, severity: e.target.value })}
            >
              <option value="">All Severities</option>
              <option value="critical">Critical</option>
              <option value="high">High</option>
              <option value="medium">Medium</option>
              <option value="low">Low</option>
            </select>

            {/* Type Filter */}
            <select
              className="input"
              value={filters.type}
              onChange={(e) => setFilters({ ...filters, type: e.target.value })}
            >
              <option value="">All Types</option>
              <option value="credential_stuffing">Credential Stuffing</option>
              <option value="sqli">SQL Injection</option>
              <option value="ddos_l3l4">DDoS</option>
              <option value="ioc_match">IOC Match</option>
              <option value="path_traversal">Path Traversal</option>
            </select>

            {/* Time Range */}
            <select
              className="input"
              value={filters.timeRange}
              onChange={(e) => setFilters({ ...filters, timeRange: e.target.value })}
            >
              <option value="1">Last Hour</option>
              <option value="24">Last 24 Hours</option>
              <option value="168">Last Week</option>
              <option value="720">Last Month</option>
            </select>
          </div>
        </div>
      </div>

      {/* Alerts Table */}
      <div className="card">
        <div className="card-header">
          <div className="flex items-center justify-between">
            <h3 className="text-lg font-semibold text-white flex items-center">
              <AlertTriangle className="w-5 h-5 mr-2" />
              Security Alerts
              {data && (
                <span className="ml-2 text-sm text-dark-400">
                  ({data.total} total)
                </span>
              )}
            </h3>
          </div>
        </div>
        
        <div className="overflow-x-auto">
          {isLoading ? (
            <div className="p-8 flex items-center justify-center">
              <div className="spinner w-6 h-6"></div>
              <span className="ml-2 text-dark-400">Loading alerts...</span>
            </div>
          ) : data?.alerts?.length === 0 ? (
            <div className="p-8 text-center text-dark-400">
              <AlertTriangle className="w-12 h-12 mx-auto mb-4 opacity-50" />
              <h3 className="text-lg font-medium text-white mb-2">No alerts found</h3>
              <p>Try adjusting your filters or check back later.</p>
            </div>
          ) : (
            <table className="table">
              <thead>
                <tr>
                  <th>Severity</th>
                  <th>Signature</th>
                  <th>Source</th>
                  <th>Destination</th>
                  <th>Type</th>
                  <th>Time</th>
                  <th>Actions</th>
                  <th></th>
                </tr>
              </thead>
              <tbody>
                {data?.alerts?.map((alert) => (
                  <tr key={alert.id}>
                    <td>
                      <span className={`badge ${getSeverityBadge(alert.severity)}`}>
                        {typeof alert.severity === 'string' ? alert.severity.toUpperCase() : String(alert.severity).toUpperCase()}
                      </span>
                    </td>
                    <td>
                      <div className="max-w-xs">
                        <p className="text-white font-medium truncate">
                          {alert.signature}
                        </p>
                        <p className="text-xs text-dark-400">
                          SID: {alert.sid}
                        </p>
                      </div>
                    </td>
                    <td>
                      <div className="flex items-center space-x-1 text-sm">
                        <MapPin className="w-3 h-3 text-dark-400" />
                        <span className="text-white font-mono">{alert.src_ip}</span>
                      </div>
                    </td>
                    <td>
                      <span className="text-white font-mono text-sm">{alert.dest_ip}</span>
                    </td>
                    <td>
                      <span className="text-dark-300 text-sm capitalize">
                        {alert.normalized_type?.replace(/_/g, ' ')}
                      </span>
                    </td>
                    <td>
                      <div className="flex items-center space-x-1 text-sm text-dark-400">
                        <Clock className="w-3 h-3" />
                        <span>
                          {formatDistanceToNow(new Date(alert.timestamp), { addSuffix: true })}
                        </span>
                      </div>
                    </td>
                    <td>
                      <div className="flex space-x-1">
                        {alert.actions?.slice(0, 2).map((action, index) => (
                          <span
                            key={index}
                            className="inline-flex items-center px-2 py-0.5 rounded text-xs bg-status-success/20 text-status-success border border-status-success/30"
                          >
                            {action.name}
                          </span>
                        ))}
                        {alert.actions?.length > 2 && (
                          <span className="text-xs text-dark-400">
                            +{alert.actions.length - 2}
                          </span>
                        )}
                      </div>
                    </td>
                    <td>
                      <div className="flex items-center space-x-2">
                        <button
                          onClick={() => setSelectedAlert(alert)}
                          className="p-1 text-dark-400 hover:text-white transition-colors duration-150"
                          title="View details"
                        >
                          <Eye className="w-4 h-4" />
                        </button>
                        <button
                          onClick={() => handleAcknowledge(alert.id)}
                          className="p-1 text-dark-400 hover:text-status-success transition-colors duration-150"
                          title="Acknowledge"
                        >
                          <CheckCircle className="w-4 h-4" />
                        </button>
                        <button
                          onClick={() => handleFalsePositive(alert.id)}
                          className="p-1 text-dark-400 hover:text-threat-critical transition-colors duration-150"
                          title="Mark as false positive"
                        >
                          <XCircle className="w-4 h-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>
      </div>

      {/* Alert Detail Modal */}
      {selectedAlert && (
        <div className="fixed inset-0 z-50 overflow-y-auto">
          <div className="flex items-center justify-center min-h-screen px-4 pt-4 pb-20 text-center sm:block sm:p-0">
            <div className="fixed inset-0 transition-opacity bg-black bg-opacity-75" onClick={() => setSelectedAlert(null)}></div>
            
            <div className="inline-block w-full max-w-2xl p-6 my-8 overflow-hidden text-left align-middle transition-all transform bg-dark-800 border border-dark-600 shadow-xl rounded-lg">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-lg font-medium text-white">Alert Details</h3>
                <button
                  onClick={() => setSelectedAlert(null)}
                  className="text-dark-400 hover:text-white"
                >
                  <XCircle className="w-5 h-5" />
                </button>
              </div>
              
              <div className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="text-sm text-dark-400">Severity</label>
                    <div className="mt-1">
                      <span className={`badge ${getSeverityBadge(selectedAlert.severity)}`}>
                        {typeof selectedAlert.severity === 'string' ? selectedAlert.severity.toUpperCase() : String(selectedAlert.severity).toUpperCase()}
                      </span>
                    </div>
                  </div>
                  <div>
                    <label className="text-sm text-dark-400">Confidence</label>
                    <div className="mt-1 text-white">
                      {(selectedAlert.confidence_score * 100).toFixed(1)}%
                    </div>
                  </div>
                </div>
                
                <div>
                  <label className="text-sm text-dark-400">Signature</label>
                  <div className="mt-1 text-white">{selectedAlert.signature}</div>
                </div>
                
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="text-sm text-dark-400">Source IP</label>
                    <div className="mt-1 text-white font-mono">{selectedAlert.src_ip}</div>
                  </div>
                  <div>
                    <label className="text-sm text-dark-400">Destination IP</label>
                    <div className="mt-1 text-white font-mono">{selectedAlert.dest_ip}</div>
                  </div>
                </div>
                
                {selectedAlert.actions && selectedAlert.actions.length > 0 && (
                  <div>
                    <label className="text-sm text-dark-400">Response Actions</label>
                    <div className="mt-1 space-y-2">
                      {selectedAlert.actions.map((action, index) => (
                        <div key={index} className="bg-dark-700 rounded p-3">
                          <div className="flex items-center justify-between">
                            <span className="text-white font-medium capitalize">
                              {action.name.replace(/_/g, ' ')}
                            </span>
                            <span className="text-sm text-dark-400 capitalize">
                              {action.provider}
                            </span>
                          </div>
                          {action.params && (
                            <div className="mt-2 text-sm text-dark-300">
                              {Object.entries(action.params).map(([key, value]) => (
                                <div key={key} className="flex justify-between">
                                  <span>{key}:</span>
                                  <span className="font-mono">{value}</span>
                                </div>
                              ))}
                            </div>
                          )}
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default Alerts;
