import React, { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { 
  FileText, 
  Edit, 
  Play, 
  Pause, 
  Plus, 
  Eye,
  CheckCircle,
  XCircle,
  AlertTriangle
} from 'lucide-react';
import { fetchPolicies, updatePolicy } from '../services/api';
import { toast } from 'react-hot-toast';

const Policies = () => {
  const [selectedRule, setSelectedRule] = useState(null);
  const [editingRule, setEditingRule] = useState(null);

  const { data: policyData, isLoading, refetch } = useQuery(
    'policies',
    fetchPolicies,
    { refetchInterval: 60000 }
  );

  const handleToggleRule = async (ruleId, enabled) => {
    try {
      // In a real implementation, this would update the specific rule
      await updatePolicy({ ruleId, enabled: !enabled });
      toast.success(`Rule ${enabled ? 'disabled' : 'enabled'} successfully`);
      refetch();
    } catch (error) {
      toast.error('Failed to update rule');
    }
  };

  const getSuccessRateColor = (rate) => {
    if (rate >= 98) return 'text-status-success';
    if (rate >= 95) return 'text-threat-medium';
    return 'text-threat-critical';
  };

  const getThreatTypeColor = (type) => {
    const colors = {
      credential_stuffing: 'text-accent-blue',
      sqli: 'text-threat-critical',
      ddos_l3l4: 'text-threat-medium',
      ioc_match: 'text-accent-purple',
      path_traversal: 'text-status-success',
    };
    return colors[type] || 'text-dark-400';
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="spinner w-8 h-8"></div>
        <span className="ml-3 text-dark-400">Loading policies...</span>
      </div>
    );
  }

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-white">Policy Management</h1>
          <p className="text-dark-400 mt-1">Configure automated response rules and policies</p>
        </div>
        <div className="flex items-center space-x-3">
          <button className="btn-secondary flex items-center space-x-2">
            <Plus className="w-4 h-4" />
            <span>New Rule</span>
          </button>
        </div>
      </div>

      {/* Policy Overview */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="card">
          <div className="card-content">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-dark-400">Active Rules</p>
                <p className="text-2xl font-bold text-white">
                  {policyData?.rules?.filter(r => r.enabled).length || 0}
                </p>
              </div>
              <FileText className="w-8 h-8 text-accent-blue" />
            </div>
          </div>
        </div>

        <div className="card">
          <div className="card-content">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-dark-400">Total Triggers (24h)</p>
                <p className="text-2xl font-bold text-white">
                  {policyData?.rules?.reduce((sum, rule) => sum + (rule.trigger_count || 0), 0) || 0}
                </p>
              </div>
              <AlertTriangle className="w-8 h-8 text-threat-medium" />
            </div>
          </div>
        </div>

        <div className="card">
          <div className="card-content">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-dark-400">Avg Success Rate</p>
                <p className="text-2xl font-bold text-status-success">
                  {policyData?.rules?.length > 0 
                    ? (policyData.rules.reduce((sum, rule) => sum + (rule.success_rate || 0), 0) / policyData.rules.length).toFixed(1)
                    : 0}%
                </p>
              </div>
              <CheckCircle className="w-8 h-8 text-status-success" />
            </div>
          </div>
        </div>
      </div>

      {/* Policy Rules */}
      <div className="card">
        <div className="card-header">
          <h3 className="text-lg font-semibold text-white flex items-center">
            <FileText className="w-5 h-5 mr-2" />
            Response Rules
          </h3>
        </div>
        
        <div className="divide-y divide-dark-700">
          {policyData?.rules?.map((rule) => (
            <div key={rule.id} className="p-6 hover:bg-dark-800/50 transition-colors duration-150">
              <div className="flex items-start justify-between">
                <div className="flex-1">
                  <div className="flex items-center space-x-3 mb-2">
                    <h4 className="text-lg font-medium text-white">{rule.name}</h4>
                    <div className="flex items-center space-x-2">
                      {rule.enabled ? (
                        <span className="badge-success">ENABLED</span>
                      ) : (
                        <span className="badge-error">DISABLED</span>
                      )}
                      <span className={`text-sm font-medium ${getThreatTypeColor(rule.when.type)}`}>
                        {rule.when.type?.replace(/_/g, ' ').toUpperCase()}
                      </span>
                    </div>
                  </div>
                  
                  <p className="text-dark-300 mb-3">{rule.description}</p>
                  
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm">
                    <div>
                      <span className="text-dark-400">Triggers (24h):</span>
                      <span className="ml-2 text-white font-medium">{rule.trigger_count || 0}</span>
                    </div>
                    <div>
                      <span className="text-dark-400">Success Rate:</span>
                      <span className={`ml-2 font-medium ${getSuccessRateColor(rule.success_rate || 0)}`}>
                        {rule.success_rate || 0}%
                      </span>
                    </div>
                    <div>
                      <span className="text-dark-400">Actions:</span>
                      <span className="ml-2 text-white font-medium">{rule.then.actions.length}</span>
                    </div>
                  </div>
                  
                  {/* Actions Preview */}
                  <div className="mt-3 flex flex-wrap gap-2">
                    {rule.then.actions.slice(0, 3).map((action, index) => (
                      <span
                        key={index}
                        className="inline-flex items-center px-2 py-1 rounded text-xs bg-dark-700 text-dark-300 border border-dark-600"
                      >
                        <span className="capitalize">{action.provider}</span>
                        <span className="mx-1">•</span>
                        <span className="capitalize">{action.name.replace(/_/g, ' ')}</span>
                      </span>
                    ))}
                    {rule.then.actions.length > 3 && (
                      <span className="text-xs text-dark-400">
                        +{rule.then.actions.length - 3} more
                      </span>
                    )}
                  </div>
                </div>
                
                <div className="flex items-center space-x-2 ml-4">
                  <button
                    onClick={() => setSelectedRule(rule)}
                    className="p-2 text-dark-400 hover:text-white transition-colors duration-150"
                    title="View details"
                  >
                    <Eye className="w-4 h-4" />
                  </button>
                  <button
                    onClick={() => setEditingRule(rule)}
                    className="p-2 text-dark-400 hover:text-white transition-colors duration-150"
                    title="Edit rule"
                  >
                    <Edit className="w-4 h-4" />
                  </button>
                  <button
                    onClick={() => handleToggleRule(rule.id, rule.enabled)}
                    className={`p-2 transition-colors duration-150 ${
                      rule.enabled 
                        ? 'text-status-success hover:text-green-400' 
                        : 'text-dark-400 hover:text-white'
                    }`}
                    title={rule.enabled ? 'Disable rule' : 'Enable rule'}
                  >
                    {rule.enabled ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Rule Detail Modal */}
      {selectedRule && (
        <div className="fixed inset-0 z-50 overflow-y-auto">
          <div className="flex items-center justify-center min-h-screen px-4 pt-4 pb-20 text-center sm:block sm:p-0">
            <div className="fixed inset-0 transition-opacity bg-black bg-opacity-75" onClick={() => setSelectedRule(null)}></div>
            
            <div className="inline-block w-full max-w-4xl p-6 my-8 overflow-hidden text-left align-middle transition-all transform bg-dark-800 border border-dark-600 shadow-xl rounded-lg">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-lg font-medium text-white">Rule Details: {selectedRule.name}</h3>
                <button
                  onClick={() => setSelectedRule(null)}
                  className="text-dark-400 hover:text-white"
                >
                  <XCircle className="w-5 h-5" />
                </button>
              </div>
              
              <div className="space-y-6">
                {/* Rule Configuration */}
                <div>
                  <h4 className="text-sm font-medium text-white mb-3">Trigger Conditions</h4>
                  <div className="bg-dark-700 rounded p-4">
                    <pre className="text-sm text-dark-300 font-mono">
                      {JSON.stringify(selectedRule.when, null, 2)}
                    </pre>
                  </div>
                </div>
                
                {/* Actions */}
                <div>
                  <h4 className="text-sm font-medium text-white mb-3">Response Actions</h4>
                  <div className="space-y-3">
                    {selectedRule.then.actions.map((action, index) => (
                      <div key={index} className="bg-dark-700 rounded p-4">
                        <div className="flex items-center justify-between mb-2">
                          <span className="text-white font-medium capitalize">
                            {action.name.replace(/_/g, ' ')}
                          </span>
                          <span className="text-sm text-dark-400 capitalize">
                            {action.provider}
                          </span>
                        </div>
                        <div className="text-sm text-dark-300">
                          <pre className="font-mono">
                            {JSON.stringify(action.params, null, 2)}
                          </pre>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
                
                {/* Statistics */}
                <div>
                  <h4 className="text-sm font-medium text-white mb-3">Performance Statistics</h4>
                  <div className="grid grid-cols-2 gap-4">
                    <div className="bg-dark-700 rounded p-4">
                      <div className="text-2xl font-bold text-white">{selectedRule.trigger_count || 0}</div>
                      <div className="text-sm text-dark-400">Total Triggers</div>
                    </div>
                    <div className="bg-dark-700 rounded p-4">
                      <div className={`text-2xl font-bold ${getSuccessRateColor(selectedRule.success_rate || 0)}`}>
                        {selectedRule.success_rate || 0}%
                      </div>
                      <div className="text-sm text-dark-400">Success Rate</div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default Policies;
