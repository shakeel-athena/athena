import React, { useState } from 'react';
import {
  EuiPage,
  EuiPageBody,
  EuiPageHeader,
  EuiSpacer,
  EuiFlexGroup,
  EuiFlexItem,
  EuiTabbedContent,
  EuiIcon
} from '@elastic/eui';
import { Shield, Activity, History, Settings } from 'lucide-react';
import ARStatistics from './components/ARStatistics';
import ActiveBlocksWidget from './components/ActiveBlocksWidget';
import AggregatedIncidentsWidget from './components/AggregatedIncidentsWidget';
import ARHistoryTable from './components/ARHistoryTable';
import ARWhitelistManager from './components/ARWhitelistManager';

/**
 * Active Response Dashboard
 *
 * Comprehensive monitoring and management dashboard for Wazuh Active Response.
 * Provides real-time visibility into AR blocks, statistics, manual actions, and whitelist management.
 */
const ActiveResponseDashboard = () => {
  const [refreshTrigger, setRefreshTrigger] = useState(0);

  // Trigger refresh across all components
  const handleRefresh = () => {
    setRefreshTrigger(prev => prev + 1);
  };

  const tabs = [
    {
      id: 'overview',
      name: 'Overview',
      content: (
        <div className="athena-animate-fade-in">
          <EuiSpacer size="l" />

          {/* Statistics Cards */}
          <ARStatistics refreshTrigger={refreshTrigger} />

          <EuiSpacer size="l" />

          {/* Aggregated Incidents */}
          <AggregatedIncidentsWidget refreshTrigger={refreshTrigger} onRefresh={handleRefresh} />
        </div>
      ),
    },
    {
      id: 'history',
      name: 'Block History',
      content: (
        <div className="athena-animate-fade-in">
          <EuiSpacer size="l" />
          <ARHistoryTable refreshTrigger={refreshTrigger} />
        </div>
      ),
    },
    {
      id: 'whitelist',
      name: 'Whitelist Management',
      content: (
        <div className="athena-animate-fade-in">
          <EuiSpacer size="l" />
          <ARWhitelistManager onWhitelistChange={handleRefresh} />
        </div>
      ),
    },
  ];

  return (
    <EuiPage paddingSize="none" className="athena-animate-fade-in">
      <EuiPageBody paddingSize="l">
        <EuiPageHeader
          pageTitle={
            <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
              <Shield size={32} color="#3b82f6" />
              <span>Active Response</span>
            </div>
          }
          description="Monitor and manage automated incident response blocks in real-time"
          rightSideItems={[
            <div style={{ color: '#94a3b8', fontSize: '14px' }}>
              <Activity size={16} style={{ display: 'inline', marginRight: '6px' }} />
              Live monitoring enabled
            </div>
          ]}
          bottomBorder
        />

        <EuiSpacer size="l" />

        <EuiTabbedContent
          tabs={tabs}
          initialSelectedTab={tabs[0]}
          autoFocus="selected"
          size="l"
        />
      </EuiPageBody>
    </EuiPage>
  );
};

export default ActiveResponseDashboard;
