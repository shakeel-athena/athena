import React, { useState, useEffect } from 'react';
import {
  EuiPanel,
  EuiTitle,
  EuiSpacer,
  EuiFlexGroup,
  EuiFlexItem,
  EuiText,
  EuiButton,
  EuiLoadingSpinner,
  EuiBadge,
  EuiEmptyPrompt,
  EuiButtonIcon,
  EuiToolTip,
  EuiAccordion,
  EuiHorizontalRule,
  EuiConfirmModal,
  EuiTextArea
} from '@elastic/eui';
import { Shield, RefreshCw, TrendingUp, Clock, Eye, Activity, Zap, XCircle } from 'lucide-react';
import axios from 'axios';
import toast from 'react-hot-toast';
import { useAuth } from '../../../contexts/AuthContext';
import ThreatScoreBadge from './ThreatScoreBadge';
import { MITRETechniquesList } from './MITREBadge';
import AttackTimelineModal from './AttackTimelineModal';
import IPIntelligenceModal from './IPIntelligenceModal';

// API Base URL - MUST be configured via environment variable for production
const API_BASE = process.env.REACT_APP_API_BASE_URL;

/**
 * Aggregated Incidents Widget
 *
 * Displays IP-aggregated incidents with threat scoring.
 * Solves the duplicate entries problem by grouping blocks from same IP.
 *
 * Features:
 * - Threat score-based prioritization
 * - MITRE ATT&CK mapping
 * - Attack timeline visualization
 * - IP intelligence integration
 * - Recommended actions
 */
const AggregatedIncidentsWidget = ({ refreshTrigger, onRefresh }) => {
  const { user } = useAuth(); // Get authenticated user from Keycloak
  const [incidents, setIncidents] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [selectedIP, setSelectedIP] = useState(null);
  const [selectedIncident, setSelectedIncident] = useState(null);
  const [showTimelineModal, setShowTimelineModal] = useState(false);
  const [showIntelligenceModal, setShowIntelligenceModal] = useState(false);
  const [showUnblockModal, setShowUnblockModal] = useState(false);
  const [unblockReason, setUnblockReason] = useState('');
  const [unblocking, setUnblocking] = useState(false);

  useEffect(() => {
    fetchIncidents();
    const interval = setInterval(fetchIncidents, 30000); // Refresh every 30 seconds
    return () => clearInterval(interval);
  }, [refreshTrigger]);

  const fetchIncidents = async () => {
    try {
      setLoading(true);
      setError(null);

      const response = await axios.get(
        `${API_BASE}/api/active-response/aggregated-incidents?hours=24`
      );

      setIncidents(response.data.incidents || []);
    } catch (err) {
      console.error('Error fetching aggregated incidents:', err);
      setError(err.response?.data?.error || 'Failed to load incidents');
    } finally {
      setLoading(false);
    }
  };

  const handleViewTimeline = (ipAddress) => {
    setSelectedIP(ipAddress);
    setShowTimelineModal(true);
  };

  const handleViewIntelligence = (ipAddress) => {
    setSelectedIP(ipAddress);
    setShowIntelligenceModal(true);
  };

  const handleUnblockClick = (incident) => {
    setSelectedIncident(incident);
    setShowUnblockModal(true);
  };

  const handleUnblockConfirm = async () => {
    if (!selectedIncident || !unblockReason.trim()) {
      toast.error('Please provide a reason for unblocking');
      return;
    }

    try {
      setUnblocking(true);

      // Extract agent ID from name format "agent_name(agent_id)"
      let agentId = 'all';
      if (selectedIncident.affected_agents && selectedIncident.affected_agents.length > 0) {
        const agentName = selectedIncident.affected_agents[0].name;
        const match = agentName.match(/\(([^)]+)\)/);
        if (match && match[1]) {
          agentId = match[1];
        }
      }

      const response = await axios.post(
        `${API_BASE}/api/active-response/unblock`,
        {
          ip_address: selectedIncident.ip_address,
          agent_id: agentId,
          reason: unblockReason,
          analyst: user?.username || user?.email || 'Unknown User'
        }
      );

      if (response.data.success) {
        toast.success(`Successfully unblocked ${selectedIncident.ip_address}`);

        // Close modal and reset state
        setShowUnblockModal(false);
        setUnblockReason('');
        setSelectedIncident(null);

        // Refresh incidents list
        fetchIncidents();

        // Trigger parent refresh if callback provided
        if (onRefresh) {
          onRefresh();
        }
      } else {
        toast.error(response.data.error || 'Failed to unblock IP');
      }
    } catch (err) {
      console.error('Error unblocking IP:', err);
      toast.error(err.response?.data?.error || 'Failed to unblock IP');
    } finally {
      setUnblocking(false);
    }
  };

  const handleUnblockCancel = () => {
    setShowUnblockModal(false);
    setUnblockReason('');
    setSelectedIncident(null);
  };

  const formatDuration = (minutes) => {
    if (minutes < 1) {
      return `${(minutes * 60).toFixed(0)} seconds`;
    } else if (minutes < 60) {
      return `${minutes.toFixed(1)} minutes`;
    } else {
      const hours = Math.floor(minutes / 60);
      const mins = Math.floor(minutes % 60);
      return `${hours}h ${mins}m`;
    }
  };

  if (loading && incidents.length === 0) {
    return (
      <EuiPanel className="athena-card" style={{ minHeight: '400px' }}>
        <EuiTitle size="s">
          <h3 style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
            <Shield size={20} color="#3b82f6" />
            Aggregated Incidents
          </h3>
        </EuiTitle>
        <EuiSpacer size="m" />
        <div style={{ textAlign: 'center', padding: '60px 20px' }}>
          <EuiLoadingSpinner size="xl" />
          <EuiSpacer size="m" />
          <EuiText color="subdued">Loading incidents...</EuiText>
        </div>
      </EuiPanel>
    );
  }

  return (
    <>
      <EuiPanel className="athena-card" style={{ minHeight: '400px' }}>
        <EuiFlexGroup justifyContent="spaceBetween" alignItems="center">
          <EuiFlexItem grow={false}>
            <EuiTitle size="s">
              <h3 style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                <TrendingUp size={20} color="#3b82f6" />
                Aggregated Incidents
                {incidents.length > 0 && (
                  <EuiBadge color="danger">{incidents.length}</EuiBadge>
                )}
              </h3>
            </EuiTitle>
          </EuiFlexItem>
          <EuiFlexItem grow={false}>
            <EuiButtonIcon
              iconType={() => <RefreshCw size={16} />}
              onClick={fetchIncidents}
              aria-label="Refresh"
              color="text"
            />
          </EuiFlexItem>
        </EuiFlexGroup>

        <EuiSpacer size="m" />

        {error && (
          <>
            <EuiText color="danger" size="s">{error}</EuiText>
            <EuiSpacer size="m" />
          </>
        )}

        {incidents.length === 0 ? (
          <EuiEmptyPrompt
            icon={<Shield size={48} color="#64748b" />}
            title={<h3>No Active Incidents</h3>}
            body={
              <EuiText color="subdued" size="s">
                All threats have been mitigated. Aggregated incidents will appear here when Active Response detects attacks.
              </EuiText>
            }
          />
        ) : (
          <div style={{ maxHeight: '600px', overflowY: 'auto' }}>
            <EuiFlexGroup direction="column" gutterSize="m">
              {incidents.map((incident, index) => (
                <EuiFlexItem key={index}>
                  <EuiPanel
                    color="subdued"
                    hasShadow={false}
                    style={{
                      border: `1px solid ${incident.color}`,
                      borderLeft: `4px solid ${incident.color}`
                    }}
                  >
                    {/* Incident Header */}
                    <EuiFlexGroup justifyContent="spaceBetween" alignItems="center">
                      <EuiFlexItem grow={false}>
                        <ThreatScoreBadge
                          score={incident.threat_score}
                          riskLevel={incident.risk_level}
                          showBreakdown={true}
                          breakdown={incident.score_breakdown}
                        />
                      </EuiFlexItem>
                    </EuiFlexGroup>

                    <EuiSpacer size="m" />

                    {/* IP Address and Agent */}
                    <EuiText size="s">
                      <div style={{ display: 'flex', alignItems: 'center', gap: '8px', marginBottom: '12px' }}>
                        <strong style={{ fontFamily: 'monospace', fontSize: '18px', color: '#f8fafc' }}>
                          {incident.ip_address}
                        </strong>
                        {incident.affected_agents && incident.affected_agents.length > 0 && (
                          <span style={{ color: '#94a3b8', fontSize: '14px' }}>
                            → {incident.affected_agents[0].name}
                          </span>
                        )}
                      </div>
                    </EuiText>

                    {/* Attack Summary */}
                    <EuiFlexGroup gutterSize="m" wrap>
                      <EuiFlexItem grow={false}>
                        <EuiToolTip content="Total blocks from this IP">
                          <div style={{ display: 'flex', alignItems: 'center', gap: '6px' }}>
                            <Shield size={14} color="#3b82f6" />
                            <span style={{ color: '#94a3b8', fontSize: '13px' }}>
                              <strong style={{ color: '#f8fafc' }}>{incident.block_count}</strong> blocks
                            </span>
                          </div>
                        </EuiToolTip>
                      </EuiFlexItem>

                      <EuiFlexItem grow={false}>
                        <EuiToolTip content="Attack speed">
                          <div style={{ display: 'flex', alignItems: 'center', gap: '6px' }}>
                            <Zap size={14} color="#eab308" />
                            <span style={{ color: '#94a3b8', fontSize: '13px' }}>
                              <strong style={{ color: '#f8fafc' }}>{incident.attack_velocity.toFixed(1)}</strong> events/min
                            </span>
                          </div>
                        </EuiToolTip>
                      </EuiFlexItem>

                      <EuiFlexItem grow={false}>
                        <EuiToolTip content="Attack duration">
                          <div style={{ display: 'flex', alignItems: 'center', gap: '6px' }}>
                            <Clock size={14} color="#8b5cf6" />
                            <span style={{ color: '#94a3b8', fontSize: '13px' }}>
                              <strong style={{ color: '#f8fafc' }}>{formatDuration(incident.duration_minutes)}</strong>
                            </span>
                          </div>
                        </EuiToolTip>
                      </EuiFlexItem>

                      {incident.attack_velocity > 100 && (
                        <EuiFlexItem grow={false}>
                          <EuiBadge color="danger" iconType="alert">
                            BURST ATTACK
                          </EuiBadge>
                        </EuiFlexItem>
                      )}
                    </EuiFlexGroup>

                    <EuiSpacer size="s" />

                    {/* MITRE Techniques */}
                    <div style={{ marginBottom: '12px' }}>
                      <EuiText size="xs" color="subdued">
                        <strong>MITRE Techniques:</strong>
                      </EuiText>
                      <EuiSpacer size="xs" />
                      <MITRETechniquesList techniques={incident.mitre_techniques} />
                    </div>

                    {/* Recommended Actions Accordion */}
                    <EuiAccordion
                      id={`actions-${index}`}
                      buttonContent={
                        <EuiText size="xs">
                          <strong>Recommended Actions ({incident.recommended_actions?.length || 0})</strong>
                        </EuiText>
                      }
                      paddingSize="s"
                    >
                      <div style={{ padding: '8px 0' }}>
                        {incident.recommended_actions && incident.recommended_actions.length > 0 ? (
                          incident.recommended_actions.slice(0, 3).map((action, actionIndex) => (
                            <div key={actionIndex} style={{ marginBottom: '6px' }}>
                              <EuiText size="xs">
                                <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                                  <span style={{ fontSize: '14px' }}>{action.icon}</span>
                                  <span>{action.action}</span>
                                </div>
                              </EuiText>
                            </div>
                          ))
                        ) : (
                          <EuiText size="xs" color="subdued">No recommendations</EuiText>
                        )}
                      </div>
                    </EuiAccordion>

                    <EuiSpacer size="m" />

                    {/* Action Buttons */}
                    <EuiFlexGroup gutterSize="s" wrap>
                      <EuiFlexItem grow={false}>
                        <EuiButton
                          size="s"
                          color="primary"
                          iconType={() => <Activity size={14} />}
                          onClick={() => handleViewTimeline(incident.ip_address)}
                        >
                          View Timeline
                        </EuiButton>
                      </EuiFlexItem>

                      <EuiFlexItem grow={false}>
                        <EuiButton
                          size="s"
                          color="text"
                          iconType={() => <Eye size={14} />}
                          onClick={() => handleViewIntelligence(incident.ip_address)}
                        >
                          IP Intelligence
                        </EuiButton>
                      </EuiFlexItem>

                      <EuiFlexItem grow={false}>
                        <EuiButton
                          size="s"
                          color="warning"
                          iconType={() => <XCircle size={14} />}
                          onClick={() => handleUnblockClick(incident)}
                        >
                          Unblock Now
                        </EuiButton>
                      </EuiFlexItem>

                      {incident.risk_level === 'Critical' || incident.risk_level === 'High' ? (
                        <EuiFlexItem grow={false}>
                          <EuiButton
                            size="s"
                            color="danger"
                            fill
                            iconType="alert"
                          >
                            Block Permanently
                          </EuiButton>
                        </EuiFlexItem>
                      ) : null}
                    </EuiFlexGroup>
                  </EuiPanel>
                </EuiFlexItem>
              ))}
            </EuiFlexGroup>
          </div>
        )}
      </EuiPanel>

      {/* Modals */}
      {showTimelineModal && selectedIP && (
        <AttackTimelineModal
          ipAddress={selectedIP}
          onClose={() => {
            setShowTimelineModal(false);
            setSelectedIP(null);
          }}
        />
      )}

      {showIntelligenceModal && selectedIP && (
        <IPIntelligenceModal
          ipAddress={selectedIP}
          onClose={() => {
            setShowIntelligenceModal(false);
            setSelectedIP(null);
          }}
        />
      )}

      {/* Unblock Confirmation Modal */}
      {showUnblockModal && selectedIncident && (
        <EuiConfirmModal
          title="Unblock IP Address"
          onCancel={handleUnblockCancel}
          onConfirm={handleUnblockConfirm}
          cancelButtonText="Cancel"
          confirmButtonText={unblocking ? 'Unblocking...' : 'Confirm Unblock'}
          buttonColor="warning"
          defaultFocusedButton="confirm"
          confirmButtonDisabled={unblocking || !unblockReason.trim()}
        >
          <EuiText>
            <p>
              <strong>Are you sure you want to unblock this IP address?</strong>
            </p>
            <p style={{ marginTop: '12px' }}>
              <strong>IP Address:</strong> {selectedIncident.ip_address}
            </p>
            <p>
              <strong>Agent:</strong>{' '}
              {selectedIncident.affected_agents && selectedIncident.affected_agents.length > 0
                ? selectedIncident.affected_agents[0].name
                : 'All agents'}
            </p>
            <p>
              <strong>Risk Level:</strong>{' '}
              <span style={{
                color: selectedIncident.risk_level === 'Critical' ? '#DC143C' :
                       selectedIncident.risk_level === 'High' ? '#FF6B6B' :
                       selectedIncident.risk_level === 'Medium' ? '#FFA500' : '#4CAF50'
              }}>
                {selectedIncident.risk_level}
              </span>{' '}
              ({selectedIncident.threat_score}/100)
            </p>
          </EuiText>

          <EuiSpacer size="m" />

          <EuiText>
            <p><strong>Reason for unblocking:</strong></p>
          </EuiText>

          <EuiSpacer size="s" />

          <EuiTextArea
            placeholder="Enter the reason for unblocking this IP (e.g., 'False positive - legitimate admin workstation', 'Customer IP incorrectly flagged')..."
            value={unblockReason}
            onChange={(e) => setUnblockReason(e.target.value)}
            rows={3}
            fullWidth
            disabled={unblocking}
          />

          <EuiSpacer size="s" />

          <EuiText size="xs" color="subdued">
            <p>
              This action will immediately remove the Active Response block from the firewall.
              The IP will be able to access the system again. This action will be logged for audit purposes.
            </p>
          </EuiText>
        </EuiConfirmModal>
      )}
    </>
  );
};

export default AggregatedIncidentsWidget;
