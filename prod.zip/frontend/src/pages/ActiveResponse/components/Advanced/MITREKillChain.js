import React, { useState, useEffect } from 'react';
import {
  EuiPanel,
  EuiTitle,
  EuiSpacer,
  EuiFlexGroup,
  EuiFlexItem,
  EuiText,
  EuiBadge,
  EuiIcon,
  EuiLoadingSpinner,
} from '@elastic/eui';
import axios from 'axios';

const MITREKillChain = ({ ipAddress }) => {
  const [timelineData, setTimelineData] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (ipAddress) {
      fetchAttackTimeline();
    }
  }, [ipAddress]);

  const fetchAttackTimeline = async () => {
    setLoading(true);
    try {
      const response = await axios.get(`/api/active-response/attack-timeline/${ipAddress}`);
      setTimelineData(response.data);
    } catch (error) {
      console.error('Error fetching attack timeline:', error);
    }
    setLoading(false);
  };

  const killChainStages = [
    { id: 1, name: 'Reconnaissance', icon: 'search' },
    { id: 2, name: 'Initial Access', icon: 'editorUnorderedList' },
    { id: 3, name: 'Execution', icon: 'play' },
    { id: 4, name: 'Persistence', icon: 'save' },
    { id: 5, name: 'Privilege Escalation', icon: 'arrowUp' },
    { id: 6, name: 'Defense Evasion', icon: 'eyeClosed' },
    { id: 7, name: 'Credential Access', icon: 'key' },
    { id: 8, name: 'Discovery', icon: 'eye' },
    { id: 9, name: 'Lateral Movement', icon: 'share' },
    { id: 10, name: 'Collection', icon: 'documents' },
    { id: 11, name: 'Exfiltration', icon: 'exportAction' },
    { id: 12, name: 'Impact', icon: 'alert' },
  ];

  // Determine which stages were detected
  const detectedStages = timelineData?.attack_chain?.map(stage => ({
    order: stage.order,
    tactics: stage.tactic_name,
    techniques: stage.techniques,
  })) || [];

  const isStageDetected = (stageId) => {
    return detectedStages.some(s => s.order === stageId);
  };

  const getStageColor = (stageId) => {
    if (isStageDetected(stageId)) return '#FF4444';
    return '#6B7280';
  };

  const getStageStatus = (stageId) => {
    if (isStageDetected(stageId)) return '✅ Detected';
    if (stageId <= 3) return '⏸️ Not Detected';
    return '⏸️ Not Reached';
  };

  if (loading) {
    return (
      <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center', height: '400px' }}>
        <EuiLoadingSpinner size="xl" />
      </div>
    );
  }

  return (
    <div>
      <EuiTitle size="m">
        <h2 style={{ color: '#FFFFFF', textAlign: 'center' }}>
          🎭 MITRE ATT&CK Kill Chain Progression
        </h2>
      </EuiTitle>

      <EuiSpacer size="l" />

      {/* Kill Chain Grid */}
      <div style={{
        display: 'grid',
        gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))',
        gap: '16px',
      }}>
        {killChainStages.map((stage) => {
          const detected = isStageDetected(stage.id);
          return (
            <EuiPanel
              key={stage.id}
              style={{
                background: detected ? 'rgba(255, 68, 68, 0.1)' : 'rgba(107, 114, 128, 0.1)',
                border: `2px solid ${getStageColor(stage.id)}`,
                padding: '16px',
                position: 'relative',
              }}
            >
              <EuiFlexGroup direction="column" gutterSize="s" alignItems="center">
                <EuiFlexItem>
                  <EuiBadge color={detected ? 'danger' : 'default'} style={{ fontSize: '12px' }}>
                    {stage.id}
                  </EuiBadge>
                </EuiFlexItem>
                <EuiFlexItem>
                  <EuiIcon
                    type={stage.icon}
                    size="xl"
                    style={{ color: getStageColor(stage.id) }}
                  />
                </EuiFlexItem>
                <EuiFlexItem>
                  <EuiText size="s" style={{ color: '#FFFFFF', textAlign: 'center', fontWeight: 'bold' }}>
                    {stage.name}
                  </EuiText>
                </EuiFlexItem>
                <EuiFlexItem>
                  <EuiText size="xs" style={{ color: '#94A3B8', textAlign: 'center' }}>
                    {getStageStatus(stage.id)}
                  </EuiText>
                </EuiFlexItem>
              </EuiFlexGroup>

              {detected && (
                <div style={{
                  position: 'absolute',
                  top: '8px',
                  right: '8px',
                }}>
                  <EuiBadge color="danger">ACTIVE</EuiBadge>
                </div>
              )}
            </EuiPanel>
          );
        })}
      </div>

      <EuiSpacer size="xl" />

      {/* Summary */}
      <EuiPanel color="danger" style={{ background: 'rgba(255, 68, 68, 0.1)', border: '1px solid #FF4444' }}>
        <EuiTitle size="xs">
          <h3 style={{ color: '#FFFFFF' }}>🛡️ Attack Summary</h3>
        </EuiTitle>
        <EuiSpacer size="m" />
        <EuiText size="s" style={{ color: '#FFFFFF' }}>
          <strong>Blocked At:</strong> Initial Access (Stage 2)
        </EuiText>
        <EuiSpacer size="xs" />
        <EuiText size="s" style={{ color: '#FFFFFF' }}>
          <strong>AR Response:</strong> firewall-drop
        </EuiText>
        <EuiSpacer size="xs" />
        <EuiText size="s" style={{ color: '#10B981' }}>
          <strong>Attack Stopped:</strong> ✅ YES
        </EuiText>
        <EuiSpacer size="xs" />
        <EuiText size="s" style={{ color: '#F59E0B' }}>
          <strong>Potential Damage Prevented:</strong> HIGH
        </EuiText>
      </EuiPanel>

      {/* MITRE Techniques */}
      {detectedStages.length > 0 && (
        <>
          <EuiSpacer size="l" />
          <EuiPanel color="subdued" style={{ background: '#0A0E27' }}>
            <EuiTitle size="xs">
              <h3 style={{ color: '#FFFFFF' }}>🎯 Detected MITRE ATT&CK Techniques</h3>
            </EuiTitle>
            <EuiSpacer size="m" />
            {detectedStages.map((stage, index) => (
              <div key={index} style={{ marginBottom: '12px' }}>
                <EuiBadge color="primary">Stage {stage.order}</EuiBadge>
                <EuiSpacer size="xs" />
                <EuiText size="s" style={{ color: '#FFFFFF' }}>
                  {stage.tactics}
                </EuiText>
                {stage.techniques?.map((tech, techIndex) => (
                  <EuiText key={techIndex} size="xs" style={{ color: '#94A3B8', marginLeft: '16px' }}>
                    • {tech.technique}: {tech.technique_name} ({tech.severity})
                  </EuiText>
                ))}
              </div>
            ))}
          </EuiPanel>
        </>
      )}
    </div>
  );
};

export default MITREKillChain;
