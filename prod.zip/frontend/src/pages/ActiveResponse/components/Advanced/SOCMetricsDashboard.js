import React from 'react';
import {
  EuiFlexGroup,
  EuiFlexItem,
  EuiPanel,
  EuiStat,
  EuiText,
  EuiIcon,
  EuiBadge,
  EuiHealth,
  EuiSpacer,
} from '@elastic/eui';
import { LineChart, Line, ResponsiveContainer } from 'recharts';
import { motion } from 'framer-motion';

const SOCMetricsDashboard = ({ stats, activeBlocks, aggregatedIncidents }) => {
  if (!stats) return null;

  // Calculate additional metrics
  const criticalBlocks = activeBlocks?.filter(b => b.threat_score >= 8).length || 0;
  const avgResponseTime = 1.2; // TODO: Calculate from actual data
  const mttr = 45; // Mean Time To Respond in seconds
  const autoBlockRate = 92; // Percentage of automatic blocks

  // Generate sparkline data (mock data for now)
  const generateSparklineData = (trend) => {
    const data = [];
    for (let i = 0; i < 24; i++) {
      data.push({
        time: i,
        value: Math.random() * 100 + (trend === 'up' ? i * 2 : trend === 'down' ? 100 - i * 2 : 50)
      });
    }
    return data;
  };

  const metrics = [
    {
      title: '🚨 Active Threats',
      value: stats.active_blocks_now || 0,
      subtitle: criticalBlocks > 0 ? `${criticalBlocks} CRITICAL` : 'Normal',
      trend: '+2 (15m)',
      trendDirection: 'up',
      color: criticalBlocks > 0 ? '#FF4444' : '#10B981',
      sparklineData: generateSparklineData('up'),
      icon: 'alert',
    },
    {
      title: '📊 Blocks (24h)',
      value: stats.blocks_today || 0,
      subtitle: 'This Week',
      trend: `-15% from avg`,
      trendDirection: 'down',
      color: '#3B82F6',
      sparklineData: generateSparklineData('down'),
      icon: 'crosshairs',
    },
    {
      title: '⚡ Response Time',
      value: `${avgResponseTime}s`,
      subtitle: 'Average',
      trend: '⬇️ -0.3s',
      trendDirection: 'down',
      color: '#10B981',
      sparklineData: generateSparklineData('down'),
      icon: 'clock',
    },
    {
      title: '🎯 MTTR',
      value: `${mttr}s`,
      subtitle: 'Mean Time To Respond',
      trend: '✅ 98% SLA',
      trendDirection: 'neutral',
      color: '#10B981',
      sparklineData: generateSparklineData('neutral'),
      icon: 'check',
    },
    {
      title: '🌍 Top Sources',
      value: stats.top_blocked_ips?.[0]?.count || 0,
      subtitle: stats.top_blocked_ips?.[0]?.ip || 'No data',
      trend: stats.top_blocked_ips?.[1] ? `+${stats.top_blocked_ips[1].count} more` : '',
      trendDirection: 'neutral',
      color: '#F59E0B',
      sparklineData: generateSparklineData('up'),
      icon: 'globe',
    },
    {
      title: '📈 Attack Velocity',
      value: '2.3',
      subtitle: 'events/min',
      trend: '↑ 150%',
      trendDirection: 'up',
      color: '#FF4444',
      sparklineData: generateSparklineData('up'),
      icon: 'visLine',
    },
    {
      title: '🎲 Threat Score',
      value: '8.7',
      subtitle: 'SEVERE',
      trend: '↑ HIGH',
      trendDirection: 'up',
      color: '#FF4444',
      sparklineData: generateSparklineData('up'),
      icon: 'warning',
    },
    {
      title: '🔄 Auto Block %',
      value: `${autoBlockRate}%`,
      subtitle: 'Success Rate',
      trend: '+5% this week',
      trendDirection: 'up',
      color: '#10B981',
      sparklineData: generateSparklineData('up'),
      icon: 'checkInCircleFilled',
    },
  ];

  return (
    <div style={{
      background: 'linear-gradient(90deg, #1E2749 0%, #2A3555 100%)',
      padding: '20px 24px',
      borderBottom: '1px solid #3B82F6',
    }}>
      <EuiFlexGroup gutterSize="m" wrap responsive={false}>
        {metrics.map((metric, index) => (
          <EuiFlexItem key={index} grow={1} style={{ minWidth: '180px' }}>
            <motion.div
              initial={{ opacity: 0, y: -10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.05, duration: 0.3 }}
            >
              <EuiPanel
                paddingSize="m"
                style={{
                  background: 'rgba(30, 39, 73, 0.6)',
                  border: `1px solid ${metric.color}20`,
                  borderLeft: `4px solid ${metric.color}`,
                  height: '100%',
                  position: 'relative',
                  overflow: 'hidden',
                }}
              >
                {/* Background Sparkline */}
                <div style={{
                  position: 'absolute',
                  bottom: 0,
                  right: 0,
                  width: '100%',
                  height: '60px',
                  opacity: 0.1,
                }}>
                  <ResponsiveContainer width="100%" height="100%">
                    <LineChart data={metric.sparklineData}>
                      <Line
                        type="monotone"
                        dataKey="value"
                        stroke={metric.color}
                        strokeWidth={2}
                        dot={false}
                      />
                    </LineChart>
                  </ResponsiveContainer>
                </div>

                {/* Content */}
                <div style={{ position: 'relative', zIndex: 1 }}>
                  <EuiFlexGroup gutterSize="s" alignItems="center" responsive={false}>
                    <EuiFlexItem grow={false}>
                      <EuiIcon
                        type={metric.icon}
                        size="l"
                        style={{ color: metric.color }}
                      />
                    </EuiFlexItem>
                    <EuiFlexItem>
                      <EuiText size="xs" style={{ color: '#94A3B8', fontWeight: 600 }}>
                        {metric.title}
                      </EuiText>
                    </EuiFlexItem>
                  </EuiFlexGroup>

                  <EuiSpacer size="s" />

                  <EuiText style={{
                    fontSize: '28px',
                    fontWeight: 'bold',
                    color: '#FFFFFF',
                    lineHeight: 1,
                  }}>
                    {metric.value}
                  </EuiText>

                  <EuiSpacer size="xs" />

                  <EuiText size="xs" style={{ color: '#64748B' }}>
                    {metric.subtitle}
                  </EuiText>

                  <EuiSpacer size="xs" />

                  <EuiBadge
                    color={
                      metric.trendDirection === 'up' && metric.color === '#FF4444'
                        ? 'danger'
                        : metric.trendDirection === 'up'
                        ? 'success'
                        : metric.trendDirection === 'down'
                        ? 'primary'
                        : 'default'
                    }
                    style={{
                      fontSize: '10px',
                      fontWeight: 600,
                    }}
                  >
                    {metric.trend}
                  </EuiBadge>
                </div>
              </EuiPanel>
            </motion.div>
          </EuiFlexItem>
        ))}
      </EuiFlexGroup>
    </div>
  );
};

export default SOCMetricsDashboard;
