import React from 'react';
import {
  EuiTitle,
  EuiSpacer,
  EuiPanel,
  EuiText,
  EuiBadge,
  EuiIcon,
  EuiButton,
  EuiFlexGroup,
  EuiFlexItem,
} from '@elastic/eui';
import { motion } from 'framer-motion';

const LiveAlertStream = ({ activeBlocks, onIPSelect }) => {
  const recentBlocks = activeBlocks?.slice(0, 5) || [];

  const getSeverityColor = (ruleId) => {
    if (ruleId === '651') return 'success';
    if (ruleId === '5710' || ruleId === '5763') return 'warning';
    return 'danger';
  };

  const getTimeAgo = (timestamp) => {
    const now = new Date();
    const blockTime = new Date(timestamp);
    const diffMs = now - blockTime;
    const diffMins = Math.floor(diffMs / 60000);

    if (diffMins < 1) return 'Just now';
    if (diffMins < 60) return `${diffMins}m ago`;
    const diffHours = Math.floor(diffMins / 60);
    return `${diffHours}h ago`;
  };

  return (
    <div>
      <EuiTitle size="xs">
        <h3 style={{ color: '#FFFFFF', display: 'flex', alignItems: 'center' }}>
          <EuiIcon type="bell" size="m" style={{ marginRight: '8px' }} />
          🚨 Live Alerts
        </h3>
      </EuiTitle>

      <EuiSpacer size="m" />

      {recentBlocks.length > 0 ? (
        recentBlocks.map((block, index) => (
          <motion.div
            key={index}
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: index * 0.1, duration: 0.3 }}
          >
            <EuiPanel
              color="subdued"
              style={{
                background: '#0A0E27',
                marginBottom: '8px',
                borderLeft: `3px solid ${getSeverityColor(block.triggered_by_rule) === 'danger' ? '#FF4444' : getSeverityColor(block.triggered_by_rule) === 'warning' ? '#F59E0B' : '#10B981'}`,
              }}
              paddingSize="s"
            >
              <EuiFlexGroup gutterSize="s" alignItems="center">
                <EuiFlexItem grow={false}>
                  <EuiBadge color={getSeverityColor(block.triggered_by_rule)}>
                    {block.triggered_by_rule}
                  </EuiBadge>
                </EuiFlexItem>
                <EuiFlexItem>
                  <EuiText size="xs" style={{ color: '#FFFFFF' }}>
                    {getTimeAgo(block.blocked_at)}
                  </EuiText>
                </EuiFlexItem>
              </EuiFlexGroup>

              <EuiSpacer size="xs" />

              <EuiText size="xs" style={{ color: '#94A3B8' }}>
                IP: <span style={{ color: '#FFFFFF', fontWeight: 'bold' }}>{block.ip_address}</span>
              </EuiText>

              <EuiText size="xs" style={{ color: '#94A3B8' }}>
                Agent: {block.agent_name}
              </EuiText>

              <EuiSpacer size="xs" />

              <EuiFlexGroup gutterSize="xs">
                <EuiFlexItem>
                  <EuiButton
                    size="xs"
                    fullWidth
                    onClick={() => onIPSelect(block.ip_address)}
                  >
                    View
                  </EuiButton>
                </EuiFlexItem>
              </EuiFlexGroup>
            </EuiPanel>
          </motion.div>
        ))
      ) : (
        <EuiText size="s" style={{ color: '#64748B', textAlign: 'center' }}>
          No recent alerts
        </EuiText>
      )}

      <EuiSpacer size="m" />

      <EuiButton size="s" fullWidth iconType="list">
        Show All
      </EuiButton>
    </div>
  );
};

export default LiveAlertStream;
