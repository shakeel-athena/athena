import React, { useState } from 'react';
import {
  EuiBasicTable,
  EuiBadge,
  EuiButton,
  EuiFlexGroup,
  EuiFlexItem,
  EuiHealth,
  EuiText,
  EuiButtonIcon,
  EuiToolTip,
} from '@elastic/eui';

const EnhancedBlockTable = ({ blocks, onIPSelect, selectedIP }) => {
  const [pageIndex, setPageIndex] = useState(0);
  const [pageSize, setPageSize] = useState(20);
  const [sortField, setSortField] = useState('blocked_at');
  const [sortDirection, setSortDirection] = useState('desc');

  const columns = [
    {
      field: 'blocked_at',
      name: 'Time',
      sortable: true,
      render: (blocked_at) => {
        const date = new Date(blocked_at);
        return (
          <EuiText size="s" style={{ whiteSpace: 'nowrap', fontSize: '12px' }}>
            {date.toLocaleDateString()} {date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
          </EuiText>
        );
      },
      width: '18%',
      truncateText: false,
      mobileOptions: {
        show: true,
        header: true,
      },
    },
    {
      field: 'ip_address',
      name: 'IP',
      sortable: true,
      width: '20%',
      render: (ip) => (
        <EuiButton
          size="s"
          onClick={() => onIPSelect(ip)}
          color={selectedIP === ip ? 'primary' : 'text'}
          fill={selectedIP === ip}
        >
          {ip}
        </EuiButton>
      ),
      mobileOptions: {
        show: true,
        header: true,
      },
    },
    {
      field: 'agent_name',
      name: 'Agent',
      sortable: true,
      width: '15%',
      truncateText: true,
      render: (name, item) => (
        <EuiText size="s" style={{ overflow: 'hidden', textOverflow: 'ellipsis' }}>
          {name || item.agent_id || 'N/A'}
        </EuiText>
      ),
      mobileOptions: {
        show: false,
      },
    },
    {
      field: 'triggered_by_rule',
      name: 'Rule',
      sortable: true,
      width: '20%',
      truncateText: true,
      render: (rule_id, item) => (
        <EuiToolTip content={item.rule_description || rule_id || 'Unknown'}>
          <div style={{ overflow: 'hidden', textOverflow: 'ellipsis' }}>
            <EuiBadge color="primary">
              {rule_id || 'Unknown'}
            </EuiBadge>
          </div>
        </EuiToolTip>
      ),
      mobileOptions: {
        show: true,
        header: false,
      },
    },
    {
      field: 'command',
      name: 'Status',
      sortable: true,
      width: '15%',
      align: 'center',
      render: (command) => (
        <EuiHealth color={command === 'add' ? 'success' : 'warning'}>
          {command === 'add' ? 'ACTIVE' : 'EXPIRED'}
        </EuiHealth>
      ),
      mobileOptions: {
        show: true,
        header: true,
      },
    },
    {
      name: 'Actions',
      width: '12%',
      align: 'center',
      render: (item) => (
        <EuiToolTip content="Unblock IP">
          <EuiButtonIcon
            iconType="cross"
            color="danger"
            aria-label="Unblock"
            onClick={(e) => {
              e.stopPropagation();
              console.log('Unblock IP:', item.ip_address);
            }}
          />
        </EuiToolTip>
      ),
      mobileOptions: {
        show: true,
        header: false,
      },
    },
  ];

  const onTableChange = ({ page = {}, sort = {} }) => {
    const { index: newPageIndex, size: newPageSize } = page;
    const { field: newSortField, direction: newSortDirection } = sort;

    setPageIndex(newPageIndex);
    setPageSize(newPageSize);
    setSortField(newSortField);
    setSortDirection(newSortDirection);
  };

  // Sort data
  const sortedBlocks = blocks ? [...blocks].sort((a, b) => {
    const aValue = a[sortField];
    const bValue = b[sortField];
    const direction = sortDirection === 'asc' ? 1 : -1;

    if (aValue < bValue) return -1 * direction;
    if (aValue > bValue) return 1 * direction;
    return 0;
  }) : [];

  // Paginate
  const startIndex = pageIndex * pageSize;
  const pageOfItems = sortedBlocks.slice(startIndex, startIndex + pageSize);

  const pagination = {
    pageIndex,
    pageSize,
    totalItemCount: sortedBlocks.length,
    pageSizeOptions: [10, 20, 50, 100],
  };

  const sorting = {
    sort: {
      field: sortField,
      direction: sortDirection,
    },
  };

  return (
    <div style={{ overflow: 'auto', width: '100%', maxWidth: '100%' }}>
      <EuiBasicTable
        items={pageOfItems}
        columns={columns}
        pagination={pagination}
        sorting={sorting}
        onChange={onTableChange}
        compressed
        responsive={true}
        hasActions={true}
        tableLayout="fixed"
      />
    </div>
  );
};

export default EnhancedBlockTable;
