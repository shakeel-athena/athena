import React from 'react';
import {
  EuiTitle,
  EuiSpacer,
  EuiText,
  EuiButtonGroup,
  EuiCheckboxGroup,
  EuiFlexGroup,
  EuiFlexItem,
  EuiButton,
  EuiIcon,
  EuiFieldSearch,
  EuiRangeSlider,
  EuiAccordion,
} from '@elastic/eui';

const AdvancedFilterPanel = ({ filters, onFilterChange, stats }) => {
  const timeRangeOptions = [
    { id: '1h', label: 'Last Hour' },
    { id: '24h', label: 'Last 24h' },
    { id: 'week', label: 'Last Week' },
  ];

  const severityOptions = [
    { id: 'critical', label: '🔴 Critical' },
    { id: 'high', label: '🟠 High' },
    { id: 'medium', label: '🟡 Medium' },
    { id: 'low', label: '🟢 Low' },
  ];

  const eventTypeOptions = [
    { id: 'port_scan', label: '🔍 Port Scan' },
    { id: 'ssh_brute_force', label: '🚪 SSH Brute Force' },
    { id: 'web_attack', label: '🌐 Web Attack' },
    { id: 'ar_block', label: '🛡️ AR Block' },
  ];

  return (
    <div>
      <EuiTitle size="xs">
        <h3 style={{ color: '#FFFFFF', display: 'flex', alignItems: 'center' }}>
          <EuiIcon type="filter" size="m" style={{ marginRight: '8px' }} />
          🔍 Filters
        </h3>
      </EuiTitle>

      <EuiSpacer size="m" />

      {/* Time Range */}
      <EuiAccordion
        id="time-range"
        buttonContent={<EuiText size="s" style={{ color: '#FFFFFF' }}>📅 Time Range</EuiText>}
        paddingSize="s"
        initialIsOpen={true}
      >
        <EuiButtonGroup
          legend="Time range"
          options={timeRangeOptions}
          idSelected={filters.timeRange}
          onChange={(id) => onFilterChange({ ...filters, timeRange: id })}
          buttonSize="compressed"
          isFullWidth
        />
      </EuiAccordion>

      <EuiSpacer size="m" />

      {/* Severity */}
      <EuiAccordion
        id="severity"
        buttonContent={<EuiText size="s" style={{ color: '#FFFFFF' }}>🚨 Severity</EuiText>}
        paddingSize="s"
        initialIsOpen={true}
      >
        <EuiCheckboxGroup
          options={severityOptions}
          idToSelectedMap={filters.severity.reduce((acc, s) => ({ ...acc, [s]: true }), {})}
          onChange={(id) => {
            const newSeverity = filters.severity.includes(id)
              ? filters.severity.filter(s => s !== id)
              : [...filters.severity, id];
            onFilterChange({ ...filters, severity: newSeverity });
          }}
          compressed
        />
      </EuiAccordion>

      <EuiSpacer size="m" />

      {/* Event Types */}
      <EuiAccordion
        id="event-types"
        buttonContent={<EuiText size="s" style={{ color: '#FFFFFF' }}>🎯 Event Types</EuiText>}
        paddingSize="s"
        initialIsOpen={true}
      >
        <EuiCheckboxGroup
          options={eventTypeOptions}
          idToSelectedMap={filters.eventTypes.reduce((acc, e) => ({ ...acc, [e]: true }), {})}
          onChange={(id) => {
            const newEventTypes = filters.eventTypes.includes(id)
              ? filters.eventTypes.filter(e => e !== id)
              : [...filters.eventTypes, id];
            onFilterChange({ ...filters, eventTypes: newEventTypes });
          }}
          compressed
        />
      </EuiAccordion>

      <EuiSpacer size="m" />

      {/* Threat Score */}
      <EuiAccordion
        id="threat-score"
        buttonContent={<EuiText size="s" style={{ color: '#FFFFFF' }}>📊 Threat Score</EuiText>}
        paddingSize="s"
        initialIsOpen={false}
      >
        <EuiText size="xs" style={{ color: '#94A3B8' }}>
          Minimum: {filters.minThreatScore}/10
        </EuiText>
        <EuiSpacer size="s" />
        <input
          type="range"
          min="0"
          max="10"
          step="0.5"
          value={filters.minThreatScore}
          onChange={(e) => onFilterChange({ ...filters, minThreatScore: parseFloat(e.target.value) })}
          style={{ width: '100%' }}
        />
      </EuiAccordion>

      <EuiSpacer size="m" />

      {/* Search */}
      <EuiFieldSearch
        placeholder="Search IP/Username..."
        fullWidth
        compressed
      />

      <EuiSpacer size="m" />

      {/* Actions */}
      <EuiFlexGroup gutterSize="s">
        <EuiFlexItem>
          <EuiButton size="s" fullWidth>
            Apply
          </EuiButton>
        </EuiFlexItem>
        <EuiFlexItem>
          <EuiButton size="s" fullWidth color="text">
            Reset
          </EuiButton>
        </EuiFlexItem>
      </EuiFlexGroup>

      <EuiSpacer size="l" />

      {/* Quick Stats */}
      <div style={{
        background: '#0A0E27',
        padding: '12px',
        borderRadius: '8px',
        border: '1px solid #3B82F6'
      }}>
        <EuiText size="xs" style={{ color: '#94A3B8', fontWeight: 600 }}>
          📊 QUICK STATS
        </EuiText>
        <EuiSpacer size="s" />
        <EuiFlexGroup direction="column" gutterSize="xs">
          <EuiFlexItem>
            <EuiText size="xs" style={{ color: '#FFFFFF' }}>
              Today: {stats?.blocks_today || 0}
            </EuiText>
          </EuiFlexItem>
          <EuiFlexItem>
            <EuiText size="xs" style={{ color: '#FFFFFF' }}>
              Week: {stats?.blocks_this_week || 0}
            </EuiText>
          </EuiFlexItem>
          <EuiFlexItem>
            <EuiText size="xs" style={{ color: '#FFFFFF' }}>
              Active: {stats?.active_blocks_now || 0}
            </EuiText>
          </EuiFlexItem>
        </EuiFlexGroup>
      </div>
    </div>
  );
};

export default AdvancedFilterPanel;
