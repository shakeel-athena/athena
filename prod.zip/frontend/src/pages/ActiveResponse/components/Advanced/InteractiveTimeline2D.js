import React, { useEffect, useRef, useState } from 'react';
import * as d3 from 'd3';
import {
  EuiPanel,
  EuiFlexGroup,
  EuiFlexItem,
  EuiButton,
  EuiButtonGroup,
  EuiRangeSlider,
  EuiText,
  EuiBadge,
  EuiIcon,
  EuiSpacer,
  EuiPopover,
  EuiDescriptionList,
} from '@elastic/eui';
import axios from 'axios';

const InteractiveTimeline2D = ({ incidents, blockHistory, selectedIP, onIPSelect, filters }) => {
  const svgRef = useRef();
  const containerRef = useRef();
  const [timelineData, setTimelineData] = useState([]);
  const [zoomLevel, setZoomLevel] = useState(1);
  const [viewRange, setViewRange] = useState('24h'); // '1h', '24h', 'week'
  const [selectedEvent, setSelectedEvent] = useState(null);
  const [isPopoverOpen, setIsPopoverOpen] = useState(false);
  const [dimensions, setDimensions] = useState({ width: 800, height: 600 });

  // Fetch timeline data for selected IP
  useEffect(() => {
    if (selectedIP) {
      fetchTimelineData(selectedIP);
    } else if (blockHistory && blockHistory.length > 0) {
      // Show overview timeline with all IPs
      processOverviewTimeline();
    }
  }, [selectedIP, blockHistory, filters]);

  const fetchTimelineData = async (ip) => {
    try {
      const response = await axios.get(`/api/active-response/attack-timeline/${ip}`);
      processTimelineData(response.data);
    } catch (error) {
      console.error('Error fetching timeline:', error);
    }
  };

  const processTimelineData = (data) => {
    if (!data || !data.timeline) return;

    const events = data.timeline.map((event, index) => ({
      id: index,
      timestamp: new Date(event.timestamp),
      type: getEventType(event),
      ruleId: event.rule_id,
      ruleDescription: event.rule_description,
      ipAddress: event.source_ip || data.ip_address,
      agentId: event.agent_id,
      agentName: event.agent_name,
      isAggregated: event.is_aggregated,
      aggregationCount: event.aggregation_count,
      aggregationTimestamps: event.aggregation_timestamps,
      mitreAttack: event.mitre_attack,
      severity: getSeverity(event),
      raw: event,
    }));

    setTimelineData(events);
  };

  const processOverviewTimeline = () => {
    const events = blockHistory.slice(0, 50).map((block, index) => ({
      id: index,
      timestamp: new Date(block.blocked_at),
      type: 'ar_block',
      ruleId: block.triggered_by_rule,
      ruleDescription: block.rule_description,
      ipAddress: block.ip_address,
      agentId: block.agent_id,
      agentName: block.agent_name,
      severity: 'high',
      raw: block,
    }));

    setTimelineData(events);
  };

  const getEventType = (event) => {
    if (event.rule_id === '651') return 'ar_block';
    if (event.rule_id === '5710' || event.rule_id === '5763') return 'ssh_attempt';
    if (event.rule_id === '5711' || event.rule_id === '5712') return 'port_scan';
    if (event.rule_id?.startsWith('31')) return 'web_attack';
    return 'other';
  };

  const getSeverity = (event) => {
    if (event.rule_id === '651') return 'critical';
    if (event.rule_level >= 10) return 'critical';
    if (event.rule_level >= 7) return 'high';
    if (event.rule_level >= 5) return 'medium';
    return 'low';
  };

  // D3 Timeline Rendering
  useEffect(() => {
    if (!timelineData || timelineData.length === 0 || !svgRef.current) return;

    renderTimeline();
  }, [timelineData, zoomLevel, dimensions]);

  // Handle window resize
  useEffect(() => {
    const handleResize = () => {
      if (containerRef.current) {
        setDimensions({
          width: containerRef.current.clientWidth,
          height: 500,
        });
      }
    };

    handleResize();
    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  const renderTimeline = () => {
    const svg = d3.select(svgRef.current);
    svg.selectAll('*').remove();

    const margin = { top: 40, right: 40, bottom: 60, left: 80 };
    const width = dimensions.width - margin.left - margin.right;
    const height = dimensions.height - margin.top - margin.bottom;

    const g = svg
      .attr('width', dimensions.width)
      .attr('height', dimensions.height)
      .append('g')
      .attr('transform', `translate(${margin.left},${margin.top})`);

    // Define event type colors
    const colorMap = {
      port_scan: '#3B82F6',      // Blue
      ssh_attempt: '#F59E0B',    // Yellow
      web_attack: '#EF4444',     // Red
      ar_block: '#10B981',       // Green
      other: '#6B7280',          // Gray
    };

    // Define event type swim lanes
    const swimLanes = ['port_scan', 'ssh_attempt', 'web_attack', 'ar_block', 'other'];
    const laneHeight = height / swimLanes.length;

    // Time scale
    const timeExtent = d3.extent(timelineData, d => d.timestamp);
    const xScale = d3.scaleTime()
      .domain(timeExtent)
      .range([0, width]);

    // Draw swim lanes
    swimLanes.forEach((lane, i) => {
      const y = i * laneHeight;

      // Lane background
      g.append('rect')
        .attr('x', 0)
        .attr('y', y)
        .attr('width', width)
        .attr('height', laneHeight)
        .attr('fill', i % 2 === 0 ? 'rgba(30, 39, 73, 0.3)' : 'rgba(30, 39, 73, 0.5)')
        .attr('stroke', '#3B82F6')
        .attr('stroke-width', 0.5);

      // Lane label
      g.append('text')
        .attr('x', -10)
        .attr('y', y + laneHeight / 2)
        .attr('dy', '0.35em')
        .attr('text-anchor', 'end')
        .attr('fill', '#94A3B8')
        .attr('font-size', '12px')
        .attr('font-weight', 'bold')
        .text(formatLaneLabel(lane));
    });

    // Draw events
    timelineData.forEach(event => {
      const laneIndex = swimLanes.indexOf(event.type);
      if (laneIndex === -1) return;

      const cx = xScale(event.timestamp);
      const cy = laneIndex * laneHeight + laneHeight / 2;
      const radius = event.isAggregated ? 12 : 8;

      // Event circle
      const eventGroup = g.append('g')
        .attr('class', 'event')
        .attr('cursor', 'pointer')
        .on('click', () => handleEventClick(event));

      // Glow effect for aggregated events
      if (event.isAggregated) {
        eventGroup.append('circle')
          .attr('cx', cx)
          .attr('cy', cy)
          .attr('r', radius + 5)
          .attr('fill', colorMap[event.type])
          .attr('opacity', 0.2)
          .append('animate')
          .attr('attributeName', 'r')
          .attr('values', `${radius + 5};${radius + 10};${radius + 5}`)
          .attr('dur', '2s')
          .attr('repeatCount', 'indefinite');
      }

      // Main circle
      eventGroup.append('circle')
        .attr('cx', cx)
        .attr('cy', cy)
        .attr('r', radius)
        .attr('fill', colorMap[event.type])
        .attr('stroke', '#FFFFFF')
        .attr('stroke-width', 2)
        .on('mouseover', function() {
          d3.select(this)
            .transition()
            .duration(200)
            .attr('r', radius * 1.5);
        })
        .on('mouseout', function() {
          d3.select(this)
            .transition()
            .duration(200)
            .attr('r', radius);
        });

      // Aggregation badge
      if (event.isAggregated) {
        eventGroup.append('text')
          .attr('x', cx)
          .attr('y', cy)
          .attr('dy', '0.35em')
          .attr('text-anchor', 'middle')
          .attr('fill', '#FFFFFF')
          .attr('font-size', '10px')
          .attr('font-weight', 'bold')
          .text(event.aggregationCount);
      }

      // Severity indicator (small dot)
      if (event.severity === 'critical') {
        eventGroup.append('circle')
          .attr('cx', cx + radius * 0.7)
          .attr('cy', cy - radius * 0.7)
          .attr('r', 4)
          .attr('fill', '#FF4444')
          .attr('stroke', '#FFFFFF')
          .attr('stroke-width', 1);
      }
    });

    // Draw correlation lines
    for (let i = 0; i < timelineData.length - 1; i++) {
      const curr = timelineData[i];
      const next = timelineData[i + 1];

      // Connect SSH attempts to AR blocks
      if (curr.type === 'ssh_attempt' && next.type === 'ar_block' && curr.ipAddress === next.ipAddress) {
        const currLane = swimLanes.indexOf(curr.type);
        const nextLane = swimLanes.indexOf(next.type);

        g.append('line')
          .attr('x1', xScale(curr.timestamp))
          .attr('y1', currLane * laneHeight + laneHeight / 2)
          .attr('x2', xScale(next.timestamp))
          .attr('y2', nextLane * laneHeight + laneHeight / 2)
          .attr('stroke', '#F59E0B')
          .attr('stroke-width', 2)
          .attr('stroke-dasharray', '5,5')
          .attr('opacity', 0.4);

        // Arrow marker
        g.append('polygon')
          .attr('points', '0,-5 10,0 0,5')
          .attr('fill', '#F59E0B')
          .attr('opacity', 0.6)
          .attr('transform', `translate(${xScale(next.timestamp)}, ${nextLane * laneHeight + laneHeight / 2}) rotate(${currLane < nextLane ? 90 : -90})`);
      }
    }

    // X-axis (time)
    const xAxis = d3.axisBottom(xScale)
      .ticks(8)
      .tickFormat(d3.timeFormat('%H:%M:%S'));

    g.append('g')
      .attr('transform', `translate(0,${height})`)
      .call(xAxis)
      .attr('color', '#94A3B8')
      .selectAll('text')
      .attr('fill', '#94A3B8')
      .attr('font-size', '12px');

    // Title
    g.append('text')
      .attr('x', width / 2)
      .attr('y', -20)
      .attr('text-anchor', 'middle')
      .attr('fill', '#FFFFFF')
      .attr('font-size', '16px')
      .attr('font-weight', 'bold')
      .text(selectedIP ? `Attack Timeline: ${selectedIP}` : 'Active Response Overview');
  };

  const formatLaneLabel = (lane) => {
    const labels = {
      port_scan: '🔍 Port Scan',
      ssh_attempt: '🚪 SSH',
      web_attack: '🌐 Web Attack',
      ar_block: '🛡️ AR Block',
      other: '📋 Other',
    };
    return labels[lane] || lane;
  };

  const handleEventClick = (event) => {
    setSelectedEvent(event);
    setIsPopoverOpen(true);
  };

  const closePopover = () => {
    setIsPopoverOpen(false);
  };

  const viewRangeOptions = [
    { id: '1h', label: 'Last Hour' },
    { id: '24h', label: 'Last 24 Hours' },
    { id: 'week', label: 'Last Week' },
  ];

  return (
    <div ref={containerRef}>
      {/* Controls */}
      <EuiFlexGroup gutterSize="s" alignItems="center" style={{ marginBottom: '16px' }}>
        <EuiFlexItem grow={false}>
          <EuiButtonGroup
            legend="Time range"
            options={viewRangeOptions}
            idSelected={viewRange}
            onChange={(id) => setViewRange(id)}
            buttonSize="compressed"
          />
        </EuiFlexItem>
        <EuiFlexItem>
          <EuiText size="s" style={{ color: '#94A3B8' }}>
            Zoom: {Math.round(zoomLevel * 100)}%
          </EuiText>
          <input
            type="range"
            min="0.5"
            max="3"
            step="0.1"
            value={zoomLevel}
            onChange={(e) => setZoomLevel(parseFloat(e.target.value))}
            style={{ width: '150px', marginLeft: '8px' }}
          />
        </EuiFlexItem>
        <EuiFlexItem grow={false}>
          <EuiBadge color="primary">
            {timelineData.length} Events
          </EuiBadge>
        </EuiFlexItem>
      </EuiFlexGroup>

      {/* Timeline SVG */}
      <div style={{
        background: 'rgba(10, 14, 39, 0.6)',
        border: '1px solid #3B82F6',
        borderRadius: '8px',
        overflow: 'auto',
      }}>
        <svg ref={svgRef}></svg>
      </div>

      {/* Event Details Popover */}
      {selectedEvent && (
        <div
          style={{
            position: 'fixed',
            top: '50%',
            left: '50%',
            transform: 'translate(-50%, -50%)',
            zIndex: 1000,
            display: isPopoverOpen ? 'block' : 'none',
          }}
        >
          <EuiPanel
            paddingSize="m"
            style={{
              background: '#1E2749',
              border: '2px solid #3B82F6',
              maxWidth: '400px',
            }}
          >
            <EuiFlexGroup justifyContent="spaceBetween">
              <EuiFlexItem>
                <EuiText size="s">
                  <h3 style={{ color: '#FFFFFF' }}>Event Details</h3>
                </EuiText>
              </EuiFlexItem>
              <EuiFlexItem grow={false}>
                <EuiButton size="xs" onClick={closePopover}>
                  Close
                </EuiButton>
              </EuiFlexItem>
            </EuiFlexGroup>

            <EuiSpacer size="m" />

            <EuiDescriptionList
              listItems={[
                { title: 'Time', description: selectedEvent.timestamp.toLocaleString() },
                { title: 'Type', description: <EuiBadge>{selectedEvent.type}</EuiBadge> },
                { title: 'IP Address', description: selectedEvent.ipAddress },
                { title: 'Rule', description: `${selectedEvent.ruleId}: ${selectedEvent.ruleDescription}` },
                { title: 'Agent', description: `${selectedEvent.agentName} (${selectedEvent.agentId})` },
                {
                  title: 'Severity',
                  description: (
                    <EuiBadge
                      color={
                        selectedEvent.severity === 'critical' ? 'danger' :
                        selectedEvent.severity === 'high' ? 'warning' :
                        selectedEvent.severity === 'medium' ? 'default' : 'success'
                      }
                    >
                      {selectedEvent.severity.toUpperCase()}
                    </EuiBadge>
                  )
                },
              ]}
              type="column"
              compressed
              style={{ color: '#FFFFFF' }}
            />

            {selectedEvent.isAggregated && (
              <>
                <EuiSpacer size="m" />
                <EuiBadge color="accent">
                  AGGREGATED ({selectedEvent.aggregationCount} events)
                </EuiBadge>
              </>
            )}
          </EuiPanel>
        </div>
      )}

      {/* Overlay backdrop for popover */}
      {isPopoverOpen && (
        <div
          onClick={closePopover}
          style={{
            position: 'fixed',
            top: 0,
            left: 0,
            right: 0,
            bottom: 0,
            background: 'rgba(0, 0, 0, 0.5)',
            zIndex: 999,
          }}
        />
      )}
    </div>
  );
};

export default InteractiveTimeline2D;
