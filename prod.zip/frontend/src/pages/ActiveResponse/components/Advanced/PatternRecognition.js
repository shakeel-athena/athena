import React from 'react';
import {
  EuiPanel,
  EuiTitle,
  EuiSpacer,
  EuiText,
  EuiBadge,
  EuiFlexGroup,
  EuiFlexItem,
  EuiProgress,
  EuiAccordion,
} from '@elastic/eui';

const PatternRecognition = ({ blockHistory, aggregatedIncidents }) => {
  // Mock pattern detection
  const patterns = [
    {
      id: 1,
      name: 'Coordinated SSH Scan',
      confidence: 94,
      ips: 12,
      timeWindow: '15 minutes',
      behavior: 'Sequential port 22 scanning',
      recommendation: 'Implement port knocking',
    },
    {
      id: 2,
      name: 'Low-and-Slow Attack',
      confidence: 76,
      duration: '6 hours',
      attemptsPerHour: '3-5',
      behavior: 'Below threshold attempts',
      recommendation: 'Lower threshold for this IP',
    },
  ];

  return (
    <EuiPanel
      color="subdued"
      style={{
        background: 'rgba(10, 14, 39, 0.8)',
        border: '1px solid #F59E0B',
      }}
    >
      <EuiTitle size="xs">
        <h3 style={{ color: '#FFFFFF' }}>
          🤖 Pattern Recognition (ML-Powered)
        </h3>
      </EuiTitle>

      <EuiSpacer size="m" />

      {patterns.map((pattern) => (
        <EuiAccordion
          key={pattern.id}
          id={`pattern-${pattern.id}`}
          buttonContent={
            <EuiFlexGroup gutterSize="s" alignItems="center">
              <EuiFlexItem grow={false}>
                <EuiBadge color={pattern.confidence >= 90 ? 'danger' : 'warning'}>
                  {pattern.confidence}%
                </EuiBadge>
              </EuiFlexItem>
              <EuiFlexItem>
                <EuiText size="s" style={{ color: '#FFFFFF' }}>
                  🎯 {pattern.name}
                </EuiText>
              </EuiFlexItem>
            </EuiFlexGroup>
          }
          paddingSize="m"
          style={{ marginBottom: '8px' }}
        >
          <EuiProgress
            value={pattern.confidence}
            max={100}
            color={pattern.confidence >= 90 ? 'danger' : 'warning'}
            size="s"
          />

          <EuiSpacer size="s" />

          <EuiText size="xs" style={{ color: '#94A3B8' }}>
            Behavior: {pattern.behavior}
          </EuiText>

          <EuiSpacer size="xs" />

          <EuiText size="xs" style={{ color: '#10B981' }}>
            💡 Recommendation: {pattern.recommendation}
          </EuiText>
        </EuiAccordion>
      ))}
    </EuiPanel>
  );
};

export default PatternRecognition;
