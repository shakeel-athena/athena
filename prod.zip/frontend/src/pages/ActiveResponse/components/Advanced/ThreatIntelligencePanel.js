import React, { useState, useEffect } from 'react';
import {
  EuiPanel,
  EuiTitle,
  EuiSpacer,
  EuiText,
  EuiBadge,
  EuiProgress,
  EuiFlexGroup,
  EuiFlexItem,
  EuiButton,
  EuiIcon,
  EuiHealth,
  EuiAccordion,
} from '@elastic/eui';
import { LineChart, Line, ResponsiveContainer } from 'recharts';
import axios from 'axios';

const ThreatIntelligencePanel = ({ selectedIP, onIPSelect, topBlockedIPs, activeBlocks }) => {
  const [threatData, setThreatData] = useState(null);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (selectedIP) {
      fetchThreatIntel(selectedIP);
    }
  }, [selectedIP]);

  const fetchThreatIntel = async (ip) => {
    setLoading(true);
    try {
      const response = await axios.get(`/api/active-response/ip-intelligence/${ip}`);
      setThreatData(response.data);
    } catch (error) {
      console.error('Error fetching threat intel:', error);
    }
    setLoading(false);
  };

  // Calculate threat score
  const calculateThreatScore = () => {
    if (!selectedIP || !activeBlocks) return 0;
    const ipBlocks = activeBlocks.filter(b => b.ip_address === selectedIP);
    const baseScore = Math.min(ipBlocks.length * 1.5, 10);
    return Math.round(baseScore * 10) / 10;
  };

  const threatScore = selectedIP ? calculateThreatScore() : 0;
  const getSeverityColor = (score) => {
    if (score >= 8) return '#FF4444';
    if (score >= 6) return '#F59E0B';
    if (score >= 4) return '#FFD600';
    return '#10B981';
  };

  const getSeverityLabel = (score) => {
    if (score >= 8) return 'SEVERE';
    if (score >= 6) return 'HIGH';
    if (score >= 4) return 'MEDIUM';
    return 'LOW';
  };

  // Generate mock history sparkline
  const generateHistoryData = () => {
    return Array.from({ length: 24 }, (_, i) => ({
      hour: i,
      events: Math.floor(Math.random() * 10) + (selectedIP ? 5 : 0)
    }));
  };

  return (
    <EuiPanel
      style={{
        background: '#1E2749',
        border: '1px solid #3B82F6',
        height: '100%',
        overflow: 'auto',
      }}
    >
      <EuiTitle size="xs">
        <h2 style={{ color: '#FFFFFF', display: 'flex', alignItems: 'center' }}>
          <EuiIcon type="aggregate" size="m" style={{ marginRight: '8px' }} />
          🎯 Threat Intelligence
        </h2>
      </EuiTitle>

      <EuiSpacer size="m" />

      {selectedIP ? (
        <>
          {/* Selected IP Analysis */}
          <EuiPanel color="subdued" style={{ background: '#0A0E27' }}>
            <EuiText size="s" style={{ color: '#94A3B8', fontWeight: 600 }}>
              Target IP
            </EuiText>
            <EuiText size="m" style={{ color: '#FFFFFF', fontWeight: 'bold' }}>
              {selectedIP}
            </EuiText>
          </EuiPanel>

          <EuiSpacer size="m" />

          {/* Threat Score */}
          <EuiPanel color="subdued" style={{ background: '#0A0E27' }}>
            <EuiText size="s" style={{ color: '#94A3B8' }}>
              🚨 THREAT SCORE
            </EuiText>
            <EuiSpacer size="s" />
            <EuiText
              size="l"
              style={{
                fontSize: '36px',
                fontWeight: 'bold',
                color: getSeverityColor(threatScore)
              }}
            >
              {threatScore}/10
            </EuiText>
            <EuiSpacer size="xs" />
            <EuiProgress
              value={threatScore * 10}
              max={100}
              color={getSeverityColor(threatScore)}
              size="m"
            />
            <EuiSpacer size="s" />
            <EuiBadge
              color={threatScore >= 8 ? 'danger' : threatScore >= 6 ? 'warning' : 'default'}
              style={{ fontSize: '14px', fontWeight: 'bold' }}
            >
              {getSeverityLabel(threatScore)}
            </EuiBadge>
          </EuiPanel>

          <EuiSpacer size="m" />

          {/* Risk Factors */}
          <EuiAccordion
            id="risk-factors"
            buttonContent={
              <EuiText size="s" style={{ color: '#FFFFFF', fontWeight: 600 }}>
                📊 Risk Factors
              </EuiText>
            }
            paddingSize="m"
            initialIsOpen={true}
          >
            <EuiFlexGroup direction="column" gutterSize="s">
              <EuiFlexItem>
                <EuiFlexGroup justifyContent="spaceBetween">
                  <EuiFlexItem>
                    <EuiText size="xs" style={{ color: '#94A3B8' }}>
                      ✅ Attack Frequency
                    </EuiText>
                  </EuiFlexItem>
                  <EuiFlexItem grow={false}>
                    <EuiBadge color="danger">9.2/10</EuiBadge>
                  </EuiFlexItem>
                </EuiFlexGroup>
              </EuiFlexItem>

              <EuiFlexItem>
                <EuiFlexGroup justifyContent="spaceBetween">
                  <EuiFlexItem>
                    <EuiText size="xs" style={{ color: '#94A3B8' }}>
                      ✅ Multiple Targets
                    </EuiText>
                  </EuiFlexItem>
                  <EuiFlexItem grow={false}>
                    <EuiBadge color="danger">9.0/10</EuiBadge>
                  </EuiFlexItem>
                </EuiFlexGroup>
              </EuiFlexItem>

              <EuiFlexItem>
                <EuiFlexGroup justifyContent="spaceBetween">
                  <EuiFlexItem>
                    <EuiText size="xs" style={{ color: '#94A3B8' }}>
                      ⚠️ Attack Sophistication
                    </EuiText>
                  </EuiFlexItem>
                  <EuiFlexItem grow={false}>
                    <EuiBadge color="warning">6.0/10</EuiBadge>
                  </EuiFlexItem>
                </EuiFlexGroup>
              </EuiFlexItem>
            </EuiFlexGroup>
          </EuiAccordion>

          <EuiSpacer size="m" />

          {/* Attack History */}
          <EuiPanel color="subdued" style={{ background: '#0A0E27' }}>
            <EuiText size="s" style={{ color: '#94A3B8' }}>
              📈 Attack History (24h)
            </EuiText>
            <EuiSpacer size="s" />
            <div style={{ height: '80px' }}>
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={generateHistoryData()}>
                  <Line
                    type="monotone"
                    dataKey="events"
                    stroke="#FF4444"
                    strokeWidth={2}
                    dot={false}
                  />
                </LineChart>
              </ResponsiveContainer>
            </div>
            <EuiSpacer size="s" />
            <EuiText size="xs" style={{ color: '#64748B' }}>
              Total Events: {activeBlocks.filter(b => b.ip_address === selectedIP).length}
            </EuiText>
          </EuiPanel>

          <EuiSpacer size="m" />

          {/* Actions */}
          <EuiFlexGroup direction="column" gutterSize="s">
            <EuiFlexItem>
              <EuiButton fullWidth size="s" color="danger" iconType="lock">
                🚫 Permanent Block
              </EuiButton>
            </EuiFlexItem>
            <EuiFlexItem>
              <EuiButton fullWidth size="s" iconType="list">
                📋 Add to Watchlist
              </EuiButton>
            </EuiFlexItem>
            <EuiFlexItem>
              <EuiButton fullWidth size="s" iconType="share">
                📤 Report to Threat Feeds
              </EuiButton>
            </EuiFlexItem>
          </EuiFlexGroup>
        </>
      ) : (
        <>
          {/* Top Blocked IPs */}
          <EuiText size="s" style={{ color: '#FFFFFF', fontWeight: 600 }}>
            🎯 Top Blocked IPs
          </EuiText>
          <EuiSpacer size="m" />
          {topBlockedIPs && topBlockedIPs.length > 0 ? (
            topBlockedIPs.slice(0, 5).map((item, index) => (
              <div key={index}>
                <EuiPanel
                  color="subdued"
                  style={{
                    background: '#0A0E27',
                    cursor: 'pointer',
                    marginBottom: '8px',
                  }}
                  onClick={() => onIPSelect(item.ip)}
                >
                  <EuiFlexGroup justifyContent="spaceBetween" alignItems="center">
                    <EuiFlexItem>
                      <EuiText size="s" style={{ color: '#FFFFFF', fontWeight: 'bold' }}>
                        {item.ip}
                      </EuiText>
                    </EuiFlexItem>
                    <EuiFlexItem grow={false}>
                      <EuiBadge color="danger">{item.count}</EuiBadge>
                    </EuiFlexItem>
                  </EuiFlexGroup>
                  <EuiSpacer size="xs" />
                  <EuiProgress
                    value={item.count}
                    max={Math.max(...topBlockedIPs.map(i => i.count))}
                    color="danger"
                    size="s"
                  />
                </EuiPanel>
              </div>
            ))
          ) : (
            <EuiText size="s" style={{ color: '#64748B', textAlign: 'center' }}>
              No blocked IPs
            </EuiText>
          )}

          <EuiSpacer size="l" />
          <EuiText size="xs" style={{ color: '#64748B', textAlign: 'center' }}>
            Click an IP to view threat intelligence
          </EuiText>
        </>
      )}
    </EuiPanel>
  );
};

export default ThreatIntelligencePanel;
