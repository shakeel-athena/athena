import React, { useState, useRef } from 'react';
import { useFrame } from '@react-three/fiber';
import { Html } from '@react-three/drei';
import * as THREE from 'three';

// Color mapping based on attack stage (from mitre_mapping.py)
const STAGE_COLORS = {
  reconnaissance: '#FFA500',    // Orange
  initial_access: '#FF6B6B',    // Red
  execution: '#DC143C',         // Crimson
  persistence: '#8B0000',       // Dark Red
  exploitation: '#FF0000',      // Bright Red
  credential_access: '#FF4500', // Orange-Red
  discovery: '#FFD700',         // Gold
  unknown: '#808080'            // Gray
};

/**
 * AttackEventNode - Individual 3D marker for an attack event
 *
 * Props:
 * - event: Timeline event object
 * - position: [x, y, z] coordinates in 3D space
 * - onClick: Callback when node is clicked
 */
const AttackEventNode = ({ event, position, onClick }) => {
  const meshRef = useRef();
  const [hovered, setHovered] = useState(false);
  const [clicked, setClicked] = useState(false);

  // Determine color based on attack stage
  const color = STAGE_COLORS[event.attack_stage] || STAGE_COLORS.unknown;

  // Scale based on severity
  const getSeverityScale = (severity) => {
    const scales = {
      Critical: 1.5,
      High: 1.2,
      Medium: 1.0,
      Low: 0.8
    };
    return scales[severity] || 1.0;
  };

  const scale = getSeverityScale(event.severity);

  // Animate on hover
  useFrame((state) => {
    if (meshRef.current) {
      if (hovered) {
        meshRef.current.rotation.y += 0.02;
        meshRef.current.scale.setScalar(scale * 1.2);
      } else {
        meshRef.current.rotation.y += 0.005;
        meshRef.current.scale.setScalar(scale);
      }
    }
  });

  const handleClick = () => {
    setClicked(!clicked);
    if (onClick) onClick(event);
  };

  return (
    <group position={position}>
      {/* Event Sphere */}
      <mesh
        ref={meshRef}
        onClick={handleClick}
        onPointerOver={() => setHovered(true)}
        onPointerOut={() => setHovered(false)}
      >
        <sphereGeometry args={[0.3, 32, 32]} />
        <meshStandardMaterial
          color={color}
          emissive={color}
          emissiveIntensity={hovered ? 0.6 : 0.3}
          metalness={0.5}
          roughness={0.3}
        />
      </mesh>

      {/* Tooltip on Hover */}
      {hovered && (
        <Html distanceFactor={10} position={[0, 0.5, 0]}>
          <div style={{
            background: 'rgba(0,0,0,0.9)',
            color: 'white',
            padding: '8px 12px',
            borderRadius: '4px',
            fontSize: '11px',
            border: `2px solid ${color}`,
            minWidth: '200px',
            pointerEvents: 'none'
          }}>
            <div style={{ fontWeight: 'bold', marginBottom: '4px' }}>
              {event.rule_description || `Rule ${event.rule_id}`}
            </div>
            <div style={{ fontSize: '10px', color: '#aaa' }}>
              {new Date(event.timestamp).toLocaleString()}
            </div>
            <div style={{ fontSize: '10px', marginTop: '4px' }}>
              Agent: {event.agent_name || event.agent_id}
            </div>
            {event.mitre_technique_name && (
              <div style={{ fontSize: '10px', color: color, marginTop: '4px' }}>
                {event.mitre_technique}: {event.mitre_technique_name}
              </div>
            )}
            <div style={{ fontSize: '10px', marginTop: '4px', fontWeight: 'bold' }}>
              Severity: {event.severity || 'Unknown'}
            </div>
          </div>
        </Html>
      )}

      {/* Glow Effect */}
      {hovered && (
        <mesh>
          <sphereGeometry args={[0.35, 32, 32]} />
          <meshBasicMaterial
            color={color}
            transparent
            opacity={0.2}
            side={THREE.BackSide}
          />
        </mesh>
      )}
    </group>
  );
};

export default AttackEventNode;
