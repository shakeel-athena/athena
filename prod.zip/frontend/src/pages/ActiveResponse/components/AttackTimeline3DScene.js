import React, { useMemo } from 'react';
import { Line } from '@react-three/drei';
import AttackEventNode from './AttackEventNode';

/**
 * AttackTimeline3DScene - 3D scene containing all attack events
 *
 * Axis mapping:
 * - X-axis: Time (earliest event at x=0, latest at x=max)
 * - Y-axis: Agent/Target (each unique agent gets a Y position)
 * - Z-axis: Severity/Attack Stage (higher severity = higher Z)
 */
const AttackTimeline3DScene = ({ timeline, attackChain, ipAddress }) => {
  // Calculate positions for all events
  const { events, agentPositions, connections } = useMemo(() => {
    if (!timeline || timeline.length === 0) {
      return { events: [], agentPositions: {}, connections: [] };
    }

    // 1. Get unique agents and assign Y positions
    const uniqueAgents = [...new Set(timeline.map(e => e.agent_id))];
    const agentPosMap = {};
    uniqueAgents.forEach((agentId, index) => {
      agentPosMap[agentId] = index * 2; // Space agents 2 units apart
    });

    // 2. Calculate time scale for X-axis
    const times = timeline.map(e => new Date(e.timestamp).getTime());
    const minTime = Math.min(...times);
    const maxTime = Math.max(...times);
    const timeRange = maxTime - minTime || 1; // Avoid division by zero

    // 3. Severity mapping for Z-axis
    const severityMap = {
      Critical: 4,
      High: 3,
      Medium: 2,
      Low: 1
    };

    // 4. Calculate position for each event
    const eventPositions = timeline.map((event, index) => {
      const eventTime = new Date(event.timestamp).getTime();
      const x = ((eventTime - minTime) / timeRange) * 10; // Scale to 0-10 range
      const y = agentPosMap[event.agent_id] || 0;
      const z = severityMap[event.severity] || 1;

      return {
        ...event,
        position: [x, y, z],
        index
      };
    });

    // 5. Create connections between sequential events
    const eventConnections = [];
    for (let i = 0; i < eventPositions.length - 1; i++) {
      eventConnections.push({
        start: eventPositions[i].position,
        end: eventPositions[i + 1].position,
        color: '#3b82f6'
      });
    }

    return {
      events: eventPositions,
      agentPositions: agentPosMap,
      connections: eventConnections
    };
  }, [timeline]);

  if (events.length === 0) {
    return null;
  }

  return (
    <group>
      {/* Render Event Nodes */}
      {events.map((event, index) => (
        <AttackEventNode
          key={index}
          event={event}
          position={event.position}
          onClick={(e) => console.log('Event clicked:', e)}
        />
      ))}

      {/* Render Connection Lines */}
      {connections.map((conn, index) => (
        <Line
          key={`conn-${index}`}
          points={[conn.start, conn.end]}
          color={conn.color}
          lineWidth={1.5}
          dashed={false}
          opacity={0.5}
        />
      ))}

      {/* Agent Planes (horizontal grid lines for each agent) */}
      {Object.entries(agentPositions).map(([agentId, yPos]) => (
        <mesh key={agentId} position={[5, yPos, 0]} rotation={[-Math.PI / 2, 0, 0]}>
          <planeGeometry args={[12, 8]} />
          <meshBasicMaterial color="#1a1a1a" transparent opacity={0.1} side={2} />
        </mesh>
      ))}
    </group>
  );
};

export default AttackTimeline3DScene;
