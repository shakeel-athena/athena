import React, { useState } from 'react';
import {
  EuiPanel,
  EuiTitle,
  EuiSpacer,
  EuiForm,
  EuiFormRow,
  EuiFieldText,
  EuiFieldNumber,
  EuiTextArea,
  EuiButton,
  EuiFlexGroup,
  EuiFlexItem,
  EuiText,
  EuiCallOut
} from '@elastic/eui';
import { Lock, AlertTriangle } from 'lucide-react';
import axios from 'axios';
import toast from 'react-hot-toast';

// API Base URL - MUST be configured via environment variable for production
const API_BASE = process.env.REACT_APP_API_BASE_URL;

/**
 * Manual Actions Panel
 *
 * Allows security analysts to manually trigger Active Response blocks
 * for confirmed threats or emergency situations.
 */
const ManualActionsPanel = ({ onActionComplete }) => {
  const [formData, setFormData] = useState({
    ip_address: '',
    agent_id: 'all',
    timeout_seconds: 3600,
    reason: ''
  });

  const [loading, setLoading] = useState(false);
  const [errors, setErrors] = useState({});

  const validateForm = () => {
    const newErrors = {};

    // Validate IP address (basic validation)
    if (!formData.ip_address) {
      newErrors.ip_address = 'IP address is required';
    } else if (!/^(\d{1,3}\.){3}\d{1,3}$/.test(formData.ip_address)) {
      newErrors.ip_address = 'Invalid IP address format';
    }

    // Validate timeout
    if (!formData.timeout_seconds || formData.timeout_seconds < 60) {
      newErrors.timeout_seconds = 'Timeout must be at least 60 seconds';
    } else if (formData.timeout_seconds > 14400) {
      newErrors.timeout_seconds = 'Timeout cannot exceed 4 hours (14400 seconds)';
    }

    // Validate reason
    if (!formData.reason || formData.reason.trim().length < 10) {
      newErrors.reason = 'Reason must be at least 10 characters';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    if (!validateForm()) {
      toast.error('Please fix form errors');
      return;
    }

    const confirmed = window.confirm(
      `Are you sure you want to manually block IP ${formData.ip_address}?\n\n` +
      `This action will:\n` +
      `- Block the IP on ${formData.agent_id === 'all' ? 'ALL agents' : `agent ${formData.agent_id}`}\n` +
      `- Duration: ${Math.floor(formData.timeout_seconds / 60)} minutes\n` +
      `- Reason: ${formData.reason}\n\n` +
      `This action will be logged for audit purposes.`
    );

    if (!confirmed) return;

    try {
      setLoading(true);

      await axios.post(`${API_BASE}/api/active-response/manual-block`, {
        ip_address: formData.ip_address,
        agent_id: formData.agent_id,
        timeout_seconds: parseInt(formData.timeout_seconds),
        reason: formData.reason.trim(),
        analyst: 'current-user' // TODO: Get from auth context
      });

      toast.success(`Successfully blocked ${formData.ip_address}`);

      // Reset form
      setFormData({
        ip_address: '',
        agent_id: 'all',
        timeout_seconds: 3600,
        reason: ''
      });

      // Trigger refresh in parent
      if (onActionComplete) {
        onActionComplete();
      }
    } catch (err) {
      console.error('Error blocking IP:', err);
      toast.error(err.response?.data?.error || 'Failed to block IP');
    } finally {
      setLoading(false);
    }
  };

  const handleChange = (field, value) => {
    setFormData(prev => ({ ...prev, [field]: value }));
    // Clear error for this field when user starts typing
    if (errors[field]) {
      setErrors(prev => ({ ...prev, [field]: null }));
    }
  };

  return (
    <EuiPanel className="athena-card" style={{ minHeight: '400px' }}>
      <EuiTitle size="s">
        <h3 style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
          <Lock size={20} color="#3b82f6" />
          Manual Block
        </h3>
      </EuiTitle>

      <EuiSpacer size="m" />

      <EuiCallOut
        title="Emergency Use Only"
        color="warning"
        iconType={() => <AlertTriangle size={16} />}
        size="s"
      >
        <EuiText size="xs">
          Manually block IPs only for confirmed threats or emergency situations.
          All actions are logged for audit.
        </EuiText>
      </EuiCallOut>

      <EuiSpacer size="l" />

      <EuiForm component="form" onSubmit={handleSubmit}>
        <EuiFormRow
          label="IP Address"
          isInvalid={!!errors.ip_address}
          error={errors.ip_address}
          fullWidth
        >
          <EuiFieldText
            placeholder="192.168.1.100"
            value={formData.ip_address}
            onChange={(e) => handleChange('ip_address', e.target.value)}
            isInvalid={!!errors.ip_address}
            fullWidth
          />
        </EuiFormRow>

        <EuiFormRow
          label="Target Agent"
          helpText="Use 'all' to block on all agents, or specific agent ID"
          fullWidth
        >
          <EuiFieldText
            value={formData.agent_id}
            onChange={(e) => handleChange('agent_id', e.target.value)}
            fullWidth
          />
        </EuiFormRow>

        <EuiFormRow
          label="Block Duration (seconds)"
          helpText="60 seconds to 14400 seconds (4 hours)"
          isInvalid={!!errors.timeout_seconds}
          error={errors.timeout_seconds}
          fullWidth
        >
          <EuiFieldNumber
            placeholder="3600"
            value={formData.timeout_seconds}
            onChange={(e) => handleChange('timeout_seconds', e.target.value)}
            isInvalid={!!errors.timeout_seconds}
            min={60}
            max={14400}
            step={60}
            fullWidth
          />
        </EuiFormRow>

        <EuiFormRow
          label="Reason for Manual Block"
          helpText="Provide detailed justification (minimum 10 characters)"
          isInvalid={!!errors.reason}
          error={errors.reason}
          fullWidth
        >
          <EuiTextArea
            placeholder="Example: Confirmed C2 communication detected via threat intelligence correlation. IOC matched in Wazuh logs."
            value={formData.reason}
            onChange={(e) => handleChange('reason', e.target.value)}
            isInvalid={!!errors.reason}
            rows={4}
            fullWidth
          />
        </EuiFormRow>

        <EuiSpacer size="l" />

        <EuiFlexGroup justifyContent="flexEnd">
          <EuiFlexItem grow={false}>
            <EuiButton
              fill
              color="danger"
              type="submit"
              isLoading={loading}
              iconType={() => <Lock size={14} />}
            >
              Block IP Address
            </EuiButton>
          </EuiFlexItem>
        </EuiFlexGroup>
      </EuiForm>
    </EuiPanel>
  );
};

export default ManualActionsPanel;
