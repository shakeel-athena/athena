import React, { useState, useEffect } from 'react';
import {
  EuiPanel,
  EuiTitle,
  EuiSpacer,
  EuiFlexGroup,
  EuiFlexItem,
  EuiText,
  EuiButton,
  EuiLoadingSpinner,
  EuiBadge,
  EuiEmptyPrompt,
  EuiButtonIcon,
  EuiToolTip
} from '@elastic/eui';
import { Shield, Clock, RefreshCw, XCircle } from 'lucide-react';
import axios from 'axios';
import toast from 'react-hot-toast';

// API Base URL - MUST be configured via environment variable for production
const API_BASE = process.env.REACT_APP_API_BASE_URL;

/**
 * Active Blocks Widget
 *
 * Displays currently active AR blocks with real-time countdown timers.
 * Allows manual unblock for emergency situations.
 */
const ActiveBlocksWidget = ({ refreshTrigger, onRefresh }) => {
  const [activeBlocks, setActiveBlocks] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [unblockingIp, setUnblockingIp] = useState(null);

  useEffect(() => {
    fetchActiveBlocks();
    const interval = setInterval(fetchActiveBlocks, 30000); // Refresh every 30 seconds
    return () => clearInterval(interval);
  }, [refreshTrigger]);

  const fetchActiveBlocks = async () => {
    try {
      setLoading(true);
      setError(null);

      const response = await axios.get(`${API_BASE}/api/active-response/blocks/active`);
      setActiveBlocks(response.data.active_blocks || []);
    } catch (err) {
      console.error('Error fetching active blocks:', err);
      setError(err.response?.data?.error || 'Failed to load active blocks');
    } finally {
      setLoading(false);
    }
  };

  const handleUnblock = async (block) => {
    const confirmed = window.confirm(
      `Are you sure you want to unblock IP ${block.ip_address}?\n\n` +
      `Agent: ${block.agent_name}\n` +
      `Time remaining: ${formatTimeRemaining(block.time_remaining_seconds)}\n\n` +
      `Please provide a reason in the next prompt.`
    );

    if (!confirmed) return;

    const reason = window.prompt('Reason for manual unblock:');
    if (!reason || reason.trim() === '') {
      toast.error('Unblock cancelled: Reason is required');
      return;
    }

    try {
      setUnblockingIp(block.ip_address);

      await axios.post(`${API_BASE}/api/active-response/unblock`, {
        ip_address: block.ip_address,
        agent_id: block.agent_id,
        reason: reason.trim(),
        analyst: 'current-user' // TODO: Get from auth context
      });

      toast.success(`Successfully unblocked ${block.ip_address}`);
      fetchActiveBlocks();
      if (onRefresh) onRefresh();
    } catch (err) {
      console.error('Error unblocking IP:', err);
      toast.error(err.response?.data?.error || 'Failed to unblock IP');
    } finally {
      setUnblockingIp(null);
    }
  };

  const formatTimeRemaining = (seconds) => {
    if (seconds <= 0) return 'Expired';

    const hours = Math.floor(seconds / 3600);
    const minutes = Math.floor((seconds % 3600) / 60);
    const secs = seconds % 60;

    if (hours > 0) {
      return `${hours}h ${minutes}m ${secs}s`;
    } else if (minutes > 0) {
      return `${minutes}m ${secs}s`;
    } else {
      return `${secs}s`;
    }
  };

  const getRuleColor = (ruleId) => {
    // SSH brute force
    if (ruleId === '5763') return '#dc2626'; // red
    // Web attacks
    if (ruleId === '31103') return '#ea580c'; // orange
    // Port scanning
    if (['5710', '5711', '5712'].includes(ruleId)) return '#eab308'; // yellow
    return '#3b82f6'; // blue default
  };

  if (loading && activeBlocks.length === 0) {
    return (
      <EuiPanel className="athena-card" style={{ minHeight: '400px' }}>
        <EuiTitle size="s">
          <h3 style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
            <Shield size={20} color="#3b82f6" />
            Active Blocks
          </h3>
        </EuiTitle>
        <EuiSpacer size="m" />
        <div style={{ textAlign: 'center', padding: '60px 20px' }}>
          <EuiLoadingSpinner size="xl" />
          <EuiSpacer size="m" />
          <EuiText color="subdued">Loading active blocks...</EuiText>
        </div>
      </EuiPanel>
    );
  }

  return (
    <EuiPanel className="athena-card" style={{ minHeight: '400px' }}>
      <EuiFlexGroup justifyContent="spaceBetween" alignItems="center">
        <EuiFlexItem grow={false}>
          <EuiTitle size="s">
            <h3 style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
              <Shield size={20} color="#3b82f6" />
              Active Blocks
              {activeBlocks.length > 0 && (
                <EuiBadge color="danger">{activeBlocks.length}</EuiBadge>
              )}
            </h3>
          </EuiTitle>
        </EuiFlexItem>
        <EuiFlexItem grow={false}>
          <EuiButtonIcon
            iconType={() => <RefreshCw size={16} />}
            onClick={fetchActiveBlocks}
            aria-label="Refresh"
            color="text"
          />
        </EuiFlexItem>
      </EuiFlexGroup>

      <EuiSpacer size="m" />

      {error && (
        <>
          <EuiText color="danger" size="s">{error}</EuiText>
          <EuiSpacer size="m" />
        </>
      )}

      {activeBlocks.length === 0 ? (
        <EuiEmptyPrompt
          icon={<Shield size={48} color="#64748b" />}
          title={<h3>No Active Blocks</h3>}
          body={
            <EuiText color="subdued" size="s">
              All IPs are currently unblocked. Active Response blocks will appear here when triggered.
            </EuiText>
          }
        />
      ) : (
        <div style={{ maxHeight: '500px', overflowY: 'auto' }}>
          <EuiFlexGroup direction="column" gutterSize="m">
            {activeBlocks.map((block, index) => (
              <EuiFlexItem key={index}>
                <EuiPanel
                  color="subdued"
                  hasShadow={false}
                  style={{
                    border: `1px solid ${getRuleColor(block.triggered_by_rule)}`,
                    borderLeft: `4px solid ${getRuleColor(block.triggered_by_rule)}`
                  }}
                >
                  <EuiFlexGroup justifyContent="spaceBetween" alignItems="flexStart">
                    <EuiFlexItem>
                      <EuiText size="s">
                        <div style={{ display: 'flex', alignItems: 'center', gap: '8px', marginBottom: '8px' }}>
                          <strong style={{ fontFamily: 'monospace', fontSize: '16px', color: '#f8fafc' }}>
                            {block.ip_address}
                          </strong>
                          <EuiBadge color="hollow">{block.command}</EuiBadge>
                        </div>

                        <div style={{ color: '#94a3b8', fontSize: '13px', marginBottom: '4px' }}>
                          <strong>Agent:</strong> {block.agent_name} ({block.agent_id})
                        </div>

                        <div style={{ color: '#94a3b8', fontSize: '13px', marginBottom: '4px' }}>
                          <strong>Reason:</strong> {block.rule_description}
                        </div>

                        <div style={{ display: 'flex', alignItems: 'center', gap: '6px', marginTop: '8px' }}>
                          <Clock size={14} color="#3b82f6" />
                          <span style={{ color: '#3b82f6', fontSize: '13px', fontWeight: 'bold' }}>
                            {formatTimeRemaining(block.time_remaining_seconds)}
                          </span>
                          <span style={{ color: '#64748b', fontSize: '12px' }}>
                            remaining
                          </span>
                        </div>
                      </EuiText>
                    </EuiFlexItem>

                    <EuiFlexItem grow={false}>
                      <EuiToolTip content="Manually unblock this IP">
                        <EuiButton
                          size="s"
                          color="danger"
                          iconType={() => <XCircle size={14} />}
                          onClick={() => handleUnblock(block)}
                          isLoading={unblockingIp === block.ip_address}
                          disabled={unblockingIp !== null}
                        >
                          Unblock
                        </EuiButton>
                      </EuiToolTip>
                    </EuiFlexItem>
                  </EuiFlexGroup>
                </EuiPanel>
              </EuiFlexItem>
            ))}
          </EuiFlexGroup>
        </div>
      )}
    </EuiPanel>
  );
};

export default ActiveBlocksWidget;
