import React, { useState, useEffect } from 'react';
import {
  EuiPanel,
  EuiFlexGroup,
  EuiFlexItem,
  EuiTitle,
  EuiSpacer,
  EuiDescriptionList,
  EuiDescriptionListTitle,
  EuiDescriptionListDescription,
  EuiBadge,
  EuiText,
  EuiIcon,
  EuiLink,
  EuiCode
} from '@elastic/eui';
import axios from 'axios';

// API Base URL - MUST be configured via environment variable for production
const API_BASE = process.env.REACT_APP_API_BASE_URL;

/**
 * ARBlockExpandedRow - Expandable row details for Block History table
 * Shows compliance mappings, enforcement status, threat intel, and audit trail
 */
const ARBlockExpandedRow = ({ entry }) => {
  const [ipIntel, setIpIntel] = useState(null);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    // Fetch IP intelligence for block actions
    if (entry.action_type === 'block') {
      fetchIPIntelligence();
    }
  }, [entry.ip_address]);

  const fetchIPIntelligence = async () => {
    try {
      setLoading(true);
      const response = await axios.get(`${API_BASE}/api/ip-intelligence/${entry.ip_address}`);
      setIpIntel(response.data);
    } catch (err) {
      console.error('Error fetching IP intelligence:', err);
      setIpIntel(null);
    } finally {
      setLoading(false);
    }
  };

  const getComplianceMappings = (ruleId) => {
    // Rule compliance mappings based on common Wazuh rules
    const complianceMap = {
      '5763': { // SSH brute force
        pci_dss: ['2.2.4', '8.1.5', '8.2.3'],
        gdpr: ['IV_35.7.d', 'IV_32.2'],
        hipaa: ['164.312(a)(2)(I)', '164.312(b)'],
        nist_800_53: ['AC.7', 'AU.14', 'SI.4']
      },
      '5710': { // Port scanning
        pci_dss: ['11.4'],
        gdpr: ['IV_35.7.d'],
        hipaa: ['164.312(b)'],
        nist_800_53: ['SI.4']
      },
      '5711': { // Nmap scan
        pci_dss: ['11.4'],
        gdpr: ['IV_35.7.d'],
        hipaa: ['164.312(b)'],
        nist_800_53: ['SI.4']
      },
      '31103': { // Web attacks
        pci_dss: ['6.5.1', '6.5.7', '6.6'],
        gdpr: ['IV_35.7.d', 'IV_32.2'],
        hipaa: ['164.312(a)(1)'],
        nist_800_53: ['SI.10', 'SI.11']
      },
      '5503': { // Multiple failed logins
        pci_dss: ['8.1.5', '8.2.3'],
        gdpr: ['IV_35.7.d'],
        hipaa: ['164.312(a)(2)(I)'],
        nist_800_53: ['AC.7']
      }
    };
    return complianceMap[ruleId] || {};
  };

  const getMITREMapping = (ruleId) => {
    // MITRE ATT&CK mapping for common rules
    const mitreMap = {
      '5763': { technique: 'T1110.001', techniqueName: 'Brute Force: Password Guessing', tactic: 'TA0006', tacticName: 'Credential Access' },
      '5710': { technique: 'T1046', techniqueName: 'Network Service Scanning', tactic: 'TA0007', tacticName: 'Discovery' },
      '5711': { technique: 'T1046', techniqueName: 'Network Service Scanning', tactic: 'TA0007', tacticName: 'Discovery' },
      '31103': { technique: 'T1190', techniqueName: 'Exploit Public-Facing Application', tactic: 'TA0001', tacticName: 'Initial Access' },
      '5503': { technique: 'T1110', techniqueName: 'Brute Force', tactic: 'TA0006', tacticName: 'Credential Access' }
    };
    return mitreMap[ruleId] || null;
  };

  const formatDuration = (seconds) => {
    if (!seconds) return 'N/A';
    const minutes = Math.floor(seconds / 60);
    const hours = Math.floor(minutes / 60);
    if (hours > 0) {
      return `${hours}h ${minutes % 60}m`;
    }
    return `${minutes}m`;
  };

  const compliance = getComplianceMappings(entry.triggered_by_rule);
  const mitreMapping = getMITREMapping(entry.triggered_by_rule);

  return (
    <EuiPanel color="subdued" paddingSize="m" style={{ marginTop: '8px' }}>
      <EuiFlexGroup>
        {/* Column 1: Rule Compliance */}
        <EuiFlexItem>
          <EuiTitle size="xs">
            <h4>📋 Rule Compliance</h4>
          </EuiTitle>
          <EuiSpacer size="s" />

          {entry.triggered_by_rule ? (
            <EuiDescriptionList compressed>
              <EuiDescriptionListTitle>Rule ID</EuiDescriptionListTitle>
              <EuiDescriptionListDescription>
                <EuiBadge color="primary">{entry.triggered_by_rule}</EuiBadge>
              </EuiDescriptionListDescription>

              {compliance.pci_dss && (
                <>
                  <EuiDescriptionListTitle>
                    <EuiIcon type="documentEdit" size="s" /> PCI-DSS
                  </EuiDescriptionListTitle>
                  <EuiDescriptionListDescription>
                    {compliance.pci_dss.map(req => (
                      <EuiBadge key={req} color="hollow" style={{ margin: '2px' }}>
                        {req}
                      </EuiBadge>
                    ))}
                  </EuiDescriptionListDescription>
                </>
              )}

              {compliance.gdpr && (
                <>
                  <EuiDescriptionListTitle>
                    <EuiIcon type="documentation" size="s" /> GDPR
                  </EuiDescriptionListTitle>
                  <EuiDescriptionListDescription>
                    {compliance.gdpr.map(req => (
                      <EuiBadge key={req} color="hollow" style={{ margin: '2px' }}>
                        {req}
                      </EuiBadge>
                    ))}
                  </EuiDescriptionListDescription>
                </>
              )}

              {compliance.hipaa && (
                <>
                  <EuiDescriptionListTitle>
                    <EuiIcon type="documentation" size="s" /> HIPAA
                  </EuiDescriptionListTitle>
                  <EuiDescriptionListDescription>
                    {compliance.hipaa.map(req => (
                      <EuiBadge key={req} color="hollow" style={{ margin: '2px' }}>
                        {req}
                      </EuiBadge>
                    ))}
                  </EuiDescriptionListDescription>
                </>
              )}

              {compliance.nist_800_53 && (
                <>
                  <EuiDescriptionListTitle>
                    <EuiIcon type="documentation" size="s" /> NIST 800-53
                  </EuiDescriptionListTitle>
                  <EuiDescriptionListDescription>
                    {compliance.nist_800_53.map(req => (
                      <EuiBadge key={req} color="hollow" style={{ margin: '2px' }}>
                        {req}
                      </EuiBadge>
                    ))}
                  </EuiDescriptionListDescription>
                </>
              )}
            </EuiDescriptionList>
          ) : (
            <EuiText size="s" color="subdued">No rule information available</EuiText>
          )}
        </EuiFlexItem>

        {/* Column 2: Enforcement Status */}
        <EuiFlexItem>
          <EuiTitle size="xs">
            <h4>🛡️ Enforcement Status</h4>
          </EuiTitle>
          <EuiSpacer size="s" />

          <EuiFlexGroup direction="column" gutterSize="s">
            <EuiFlexItem>
              <EuiBadge color={entry.command === 'firewall-drop' || entry.command === 'win-firewall-drop' ? 'success' : 'hollow'}>
                {entry.command === 'firewall-drop' && '🔥 iptables: BLOCKED'}
                {entry.command === 'win-firewall-drop' && '🪟 Windows Firewall: BLOCKED'}
                {entry.command === 'disable-account' && '🔒 Account: DISABLED'}
                {!entry.command && 'Status: N/A'}
              </EuiBadge>
            </EuiFlexItem>

            {entry.duration_seconds && (
              <EuiFlexItem>
                <EuiDescriptionList compressed>
                  <EuiDescriptionListTitle>Duration</EuiDescriptionListTitle>
                  <EuiDescriptionListDescription>
                    {formatDuration(entry.duration_seconds)}
                  </EuiDescriptionListDescription>
                </EuiDescriptionList>
              </EuiFlexItem>
            )}

            {entry.status && (
              <EuiFlexItem>
                <EuiDescriptionList compressed>
                  <EuiDescriptionListTitle>Current Status</EuiDescriptionListTitle>
                  <EuiDescriptionListDescription>
                    <EuiBadge color={
                      entry.status === 'active' ? 'danger' :
                      entry.status === 'expired' ? 'default' :
                      'success'
                    }>
                      {entry.status.toUpperCase()}
                    </EuiBadge>
                  </EuiDescriptionListDescription>
                </EuiDescriptionList>
              </EuiFlexItem>
            )}
          </EuiFlexGroup>
        </EuiFlexItem>

        {/* Column 3: Threat Intelligence */}
        <EuiFlexItem>
          <EuiTitle size="xs">
            <h4>🔍 Threat Intelligence</h4>
          </EuiTitle>
          <EuiSpacer size="s" />

          <EuiFlexGroup direction="column" gutterSize="s">
            {/* MITRE ATT&CK Mapping */}
            {mitreMapping && (
              <EuiFlexItem>
                <EuiDescriptionList compressed>
                  <EuiDescriptionListTitle>MITRE ATT&CK</EuiDescriptionListTitle>
                  <EuiDescriptionListDescription>
                    <EuiLink
                      href={`https://attack.mitre.org/techniques/${mitreMapping.technique}/`}
                      target="_blank"
                      external
                    >
                      <EuiBadge color="warning">
                        {mitreMapping.technique}
                      </EuiBadge>
                    </EuiLink>
                    <EuiText size="xs" color="subdued" style={{ marginTop: '4px' }}>
                      {mitreMapping.techniqueName}
                    </EuiText>
                    <EuiText size="xs" color="subdued">
                      Tactic: {mitreMapping.tacticName}
                    </EuiText>
                  </EuiDescriptionListDescription>
                </EuiDescriptionList>
              </EuiFlexItem>
            )}

            {/* IP Reputation */}
            {ipIntel && ipIntel.abuseipdb && (
              <EuiFlexItem>
                <EuiDescriptionList compressed>
                  <EuiDescriptionListTitle>AbuseIPDB Score</EuiDescriptionListTitle>
                  <EuiDescriptionListDescription>
                    <EuiBadge color={
                      ipIntel.abuseipdb.abuseConfidenceScore >= 75 ? 'danger' :
                      ipIntel.abuseipdb.abuseConfidenceScore >= 50 ? 'warning' :
                      'success'
                    }>
                      {ipIntel.abuseipdb.abuseConfidenceScore}/100
                    </EuiBadge>
                    <EuiText size="xs" color="subdued" style={{ marginTop: '4px' }}>
                      Reports: {ipIntel.abuseipdb.totalReports || 0}
                    </EuiText>
                  </EuiDescriptionListDescription>
                </EuiDescriptionList>
              </EuiFlexItem>
            )}

            {/* Threat Type */}
            {entry.reason && (
              <EuiFlexItem>
                <EuiDescriptionList compressed>
                  <EuiDescriptionListTitle>Threat Type</EuiDescriptionListTitle>
                  <EuiDescriptionListDescription>
                    <EuiText size="s">
                      {entry.reason.includes('SSH') && '🔐 SSH Brute Force'}
                      {entry.reason.includes('Port scanning') && '🔍 Port Scanning'}
                      {entry.reason.includes('Web') && '🌐 Web Attack'}
                      {entry.reason.includes('login') && '🚪 Failed Login'}
                      {!entry.reason.includes('SSH') && !entry.reason.includes('Port') &&
                       !entry.reason.includes('Web') && !entry.reason.includes('login') &&
                       'Unknown'}
                    </EuiText>
                  </EuiDescriptionListDescription>
                </EuiDescriptionList>
              </EuiFlexItem>
            )}
          </EuiFlexGroup>
        </EuiFlexItem>
      </EuiFlexGroup>

      <EuiSpacer size="m" />

      {/* Audit Trail Section */}
      <EuiPanel color="transparent" paddingSize="s" hasBorder>
        <EuiTitle size="xxs">
          <h5>📝 Audit Trail Details</h5>
        </EuiTitle>
        <EuiSpacer size="s" />

        <EuiFlexGroup>
          <EuiFlexItem grow={2}>
            <EuiDescriptionList compressed>
              <EuiDescriptionListTitle>Performed By</EuiDescriptionListTitle>
              <EuiDescriptionListDescription>
                <strong>{entry.performed_by}</strong> ({entry.performed_via})
              </EuiDescriptionListDescription>

              <EuiDescriptionListTitle>Timestamp</EuiDescriptionListTitle>
              <EuiDescriptionListDescription>
                <EuiCode>{new Date(entry.timestamp).toLocaleString()}</EuiCode>
              </EuiDescriptionListDescription>

              {entry.trigger_count && entry.trigger_count > 1 && (
                <>
                  <EuiDescriptionListTitle>Trigger Events</EuiDescriptionListTitle>
                  <EuiDescriptionListDescription>
                    <EuiBadge color="warning" iconType="alert">
                      Triggered by {entry.trigger_count} rapid-fire events
                    </EuiBadge>
                    {entry.trigger_timestamps && (
                      <>
                        <EuiSpacer size="xs" />
                        <EuiText size="xs" color="subdued">
                          {entry.trigger_timestamps.map((ts, idx) => (
                            <div key={idx}>
                              Event {idx + 1}: {new Date(ts).toLocaleString()}
                            </div>
                          ))}
                        </EuiText>
                      </>
                    )}
                  </EuiDescriptionListDescription>
                </>
              )}
            </EuiDescriptionList>
          </EuiFlexItem>

          <EuiFlexItem grow={3}>
            <EuiDescriptionList compressed>
              <EuiDescriptionListTitle>Reason</EuiDescriptionListTitle>
              <EuiDescriptionListDescription>
                {entry.reason}
              </EuiDescriptionListDescription>

              {entry.agent_name && (
                <>
                  <EuiDescriptionListTitle>Target Agent</EuiDescriptionListTitle>
                  <EuiDescriptionListDescription>
                    {entry.agent_name} (ID: {entry.agent_id})
                  </EuiDescriptionListDescription>
                </>
              )}
            </EuiDescriptionList>
          </EuiFlexItem>
        </EuiFlexGroup>
      </EuiPanel>
    </EuiPanel>
  );
};

export default ARBlockExpandedRow;
