import React, { useState, useEffect } from 'react';
import {
  EuiModal,
  EuiModalHeader,
  EuiModalHeaderTitle,
  EuiModalBody,
  EuiModalFooter,
  EuiButton,
  EuiSteps,
  EuiText,
  EuiLoadingSpinner,
  EuiCallOut,
  EuiSpacer,
  EuiFlexGroup,
  EuiFlexItem,
  EuiBadge,
  EuiButtonGroup
} from '@elastic/eui';
import { Clock, AlertTriangle, Target, Activity, Box, List } from 'lucide-react';
import axios from 'axios';
import MITREBadge, { AttackKillChain } from './MITREBadge';
import SimpleTimeline2D from './SimpleTimeline2D';

// API Base URL - MUST be configured via environment variable for production
const API_BASE = process.env.REACT_APP_API_BASE_URL;

/**
 * Attack Timeline Modal Component
 *
 * Displays chronological attack progression with MITRE ATT&CK mapping
 * Shows complete attack chain from reconnaissance to blocking
 */
const AttackTimelineModal = ({ ipAddress, onClose }) => {
  const [timeline, setTimeline] = useState([]);
  const [attackChain, setAttackChain] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [metadata, setMetadata] = useState({});
  const [viewMode, setViewMode] = useState('graphical'); // 'graphical' or 'detailed'

  useEffect(() => {
    if (ipAddress) {
      fetchTimeline();
    }
  }, [ipAddress]);

  const fetchTimeline = async () => {
    try {
      setLoading(true);
      setError(null);

      const response = await axios.get(
        `${API_BASE}/api/active-response/attack-timeline/${ipAddress}?hours=24`
      );

      setTimeline(response.data.timeline || []);
      setAttackChain(response.data.attack_chain || []);
      setMetadata({
        duration: response.data.duration_minutes,
        totalEvents: response.data.total_events,
        firstSeen: response.data.first_seen,
        lastSeen: response.data.last_seen
      });
    } catch (err) {
      console.error('Error fetching attack timeline:', err);
      setError(err.response?.data?.error || 'Failed to load attack timeline');
    } finally {
      setLoading(false);
    }
  };

  // Get attack stage color
  const getStageColor = (color) => {
    return color || '#3b82f6';
  };

  // Format timestamp
  const formatTime = (timestamp) => {
    if (!timestamp) return 'Unknown';
    const date = new Date(timestamp);
    return date.toLocaleTimeString('en-US', {
      hour12: true,
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit'
    });
  };

  // Get event type display name
  const getEventTypeDisplay = (eventType) => {
    const typeMap = {
      'ssh_attempt': 'SSH Attempt',
      'port_scan': 'Port Scan',
      'rdp_attempt': 'RDP Attempt',
      'web_attack': 'Web Attack',
      'failed_login': 'Failed Login',
      'ar_block': 'AR Block',
      'unknown': 'Unknown Event'
    };
    return typeMap[eventType] || eventType;
  };

  // Build timeline steps for EUI
  const timelineSteps = timeline.map((event, index) => {
    // Determine icon and status based on event type
    let stepStatus = 'complete';
    if (event.triggered_block) {
      stepStatus = 'warning';
    } else if (event.event_type === 'ar_block') {
      stepStatus = 'danger';
    }

    return {
      title: (
        <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
          <Clock size={14} color={getStageColor(event.stage_color)} />
          <span>{formatTime(event.timestamp)}</span>
        </div>
      ),
      children: (
        <div style={{ paddingLeft: '8px', borderLeft: `3px solid ${getStageColor(event.stage_color)}`, paddingTop: '8px', paddingBottom: '16px' }}>
          <EuiFlexGroup direction="column" gutterSize="s">
            <EuiFlexItem>
              <EuiFlexGroup gutterSize="s" alignItems="center" wrap>
                <EuiFlexItem grow={false}>
                  <EuiText size="s">
                    <strong>{event.rule_description}</strong>
                  </EuiText>
                </EuiFlexItem>

                {/* Show TRIGGERED AR BLOCK badge for events that triggered AR */}
                {event.triggered_block && (
                  <EuiFlexItem grow={false}>
                    <EuiBadge color="danger" iconType="lock">
                      TRIGGERED AR BLOCK
                    </EuiBadge>
                  </EuiFlexItem>
                )}

                {/* Show BLOCK APPLIED badge for AR block events */}
                {event.event_type === 'ar_block' && (
                  <EuiFlexItem grow={false}>
                    <EuiBadge color="primary" iconType="checkInCircleFilled">
                      BLOCK APPLIED
                    </EuiBadge>
                  </EuiFlexItem>
                )}

                {/* Show AGGREGATED badge for AR blocks with multiple triggers */}
                {event.is_aggregated && event.aggregation_count > 1 && (
                  <EuiFlexItem grow={false}>
                    <EuiBadge color="warning" iconType="merge">
                      AGGREGATED ({event.aggregation_count} rapid-fire blocks)
                    </EuiBadge>
                  </EuiFlexItem>
                )}
              </EuiFlexGroup>
            </EuiFlexItem>

            <EuiFlexItem>
              <EuiFlexGroup gutterSize="s" wrap>
                <EuiFlexItem grow={false}>
                  <EuiBadge color="hollow">
                    Rule {event.rule_id}
                  </EuiBadge>
                </EuiFlexItem>

                {/* Event Type Badge */}
                {event.event_type && (
                  <EuiFlexItem grow={false}>
                    <EuiBadge color="default">
                      {getEventTypeDisplay(event.event_type)}
                    </EuiBadge>
                  </EuiFlexItem>
                )}

                <EuiFlexItem grow={false}>
                  <MITREBadge
                    technique={event.mitre_technique}
                    techniqueName={event.mitre_technique_name}
                    tactic={event.mitre_tactic}
                    tacticName={event.mitre_tactic_name}
                    severity={event.severity}
                  />
                </EuiFlexItem>

                <EuiFlexItem grow={false}>
                  <EuiBadge
                    style={{
                      backgroundColor: getStageColor(event.stage_color) + '20',
                      color: getStageColor(event.stage_color),
                      border: `1px solid ${getStageColor(event.stage_color)}`
                    }}
                  >
                    {event.attack_stage}
                  </EuiBadge>
                </EuiFlexItem>
              </EuiFlexGroup>
            </EuiFlexItem>

            <EuiFlexItem>
              <EuiText size="xs" color="subdued">
                <div>Agent: {event.agent_name} ({event.agent_id})</div>
                {event.command && <div>Command: {event.command}</div>}
                {event.triggered_rule && event.event_type === 'ar_block' && (
                  <div>Triggered by Rule: {event.triggered_rule}</div>
                )}
                {/* Show aggregation timestamps for aggregated AR blocks */}
                {event.is_aggregated && event.aggregation_timestamps && event.aggregation_timestamps.length > 1 && (
                  <div style={{ marginTop: '4px' }}>
                    <strong>AR Block Triggers:</strong>
                    {event.aggregation_timestamps.map((ts, idx) => (
                      <div key={idx} style={{ marginLeft: '8px' }}>
                        • Block {idx + 1}: {new Date(ts).toLocaleTimeString()}
                      </div>
                    ))}
                  </div>
                )}
              </EuiText>
            </EuiFlexItem>
          </EuiFlexGroup>
        </div>
      ),
      status: stepStatus
    };
  });

  return (
    <EuiModal onClose={onClose} maxWidth={800}>
      <EuiModalHeader>
        <EuiModalHeaderTitle>
          <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
            <Activity size={24} color="#3b82f6" />
            <span>Attack Timeline: {ipAddress}</span>
          </div>
        </EuiModalHeaderTitle>
      </EuiModalHeader>

      <EuiModalBody>
        {loading ? (
          <div style={{ textAlign: 'center', padding: '40px 20px' }}>
            <EuiLoadingSpinner size="xl" />
            <EuiSpacer size="m" />
            <EuiText color="subdued">Loading attack timeline...</EuiText>
          </div>
        ) : error ? (
          <EuiCallOut title="Error" color="danger" iconType="alert">
            {error}
          </EuiCallOut>
        ) : timeline.length === 0 ? (
          <EuiCallOut title="No Timeline Data" iconType="iInCircle">
            No attack timeline data found for this IP address in the last 24 hours.
          </EuiCallOut>
        ) : (
          <>
            {/* Attack Metadata */}
            <EuiCallOut title="Attack Summary" iconType="iInCircle" color="primary">
              <EuiFlexGroup gutterSize="m" wrap>
                <EuiFlexItem grow={false}>
                  <EuiText size="s">
                    <strong>Total Events:</strong> {metadata.totalEvents}
                  </EuiText>
                </EuiFlexItem>
                <EuiFlexItem grow={false}>
                  <EuiText size="s">
                    <strong>Duration:</strong> {metadata.duration?.toFixed(2)} minutes
                  </EuiText>
                </EuiFlexItem>
                <EuiFlexItem grow={false}>
                  <EuiText size="s">
                    <strong>First Seen:</strong> {formatTime(metadata.firstSeen)}
                  </EuiText>
                </EuiFlexItem>
                <EuiFlexItem grow={false}>
                  <EuiText size="s">
                    <strong>Last Seen:</strong> {formatTime(metadata.lastSeen)}
                  </EuiText>
                </EuiFlexItem>
              </EuiFlexGroup>
            </EuiCallOut>

            <EuiSpacer size="l" />

            {/* View Mode Toggle */}
            <EuiButtonGroup
              legend="Timeline view mode"
              options={[
                { id: 'graphical', label: 'Graphical Timeline' },
                { id: 'detailed', label: 'Detailed List' },
              ]}
              idSelected={viewMode}
              onChange={(id) => setViewMode(id)}
              buttonSize="compressed"
              color="primary"
            />

            <EuiSpacer size="l" />

            {/* Attack Kill Chain */}
            {attackChain.length > 0 && (
              <>
                <AttackKillChain killChain={attackChain} />
                <EuiSpacer size="l" />
              </>
            )}

            {/* Timeline Views */}
            {viewMode === 'graphical' ? (
              <SimpleTimeline2D timeline={timeline} />
            ) : (
              <div style={{ maxHeight: '500px', overflowY: 'auto', paddingRight: '8px' }}>
                <EuiSteps steps={timelineSteps} />
              </div>
            )}
          </>
        )}
      </EuiModalBody>

      <EuiModalFooter>
        <EuiButton onClick={onClose} fill>
          Close
        </EuiButton>
      </EuiModalFooter>
    </EuiModal>
  );
};

export default AttackTimelineModal;
