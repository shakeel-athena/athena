import React, { useState, useEffect } from 'react';
import {
  EuiFlexGroup,
  EuiFlexItem,
  EuiStat,
  EuiPanel,
  EuiLoadingSpinner,
  EuiText,
  EuiSpacer,
  EuiTitle
} from '@elastic/eui';
import { Shield, TrendingUp, AlertCircle, Activity } from 'lucide-react';
import axios from 'axios';

// API Base URL - MUST be configured via environment variable for production
const API_BASE = process.env.REACT_APP_API_BASE_URL;

/**
 * AR Statistics Component
 *
 * Displays key Active Response metrics in card format:
 * - Blocks today
 * - Blocks this week
 * - Currently active blocks
 * - Top blocked IPs
 */
const ARStatistics = ({ refreshTrigger }) => {
  const [stats, setStats] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    fetchStats();
  }, [refreshTrigger]);

  const fetchStats = async () => {
    try {
      setLoading(true);
      setError(null);

      const response = await axios.get(`${API_BASE}/api/active-response/stats`);
      setStats(response.data);
    } catch (err) {
      console.error('Error fetching AR statistics:', err);
      setError(err.response?.data?.error || 'Failed to load statistics');
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <EuiPanel className="athena-card">
        <div style={{ textAlign: 'center', padding: '40px' }}>
          <EuiLoadingSpinner size="xl" />
          <EuiSpacer size="m" />
          <EuiText color="subdued">Loading statistics...</EuiText>
        </div>
      </EuiPanel>
    );
  }

  if (error) {
    return (
      <EuiPanel className="athena-card" color="danger">
        <EuiText color="danger">
          <AlertCircle size={20} style={{ display: 'inline', marginRight: '8px' }} />
          {error}
        </EuiText>
      </EuiPanel>
    );
  }

  return (
    <>
      <EuiFlexGroup gutterSize="l" responsive={false}>
        {/* Blocks Today */}
        <EuiFlexItem>
          <EuiPanel className="athena-card athena-hover-glow-blue">
            <EuiStat
              title={stats?.blocks_today || 0}
              description="Blocks Today"
              titleColor="primary"
              textAlign="center"
              icon={
                <div style={{ color: '#3b82f6', marginBottom: '8px' }}>
                  <Shield size={32} />
                </div>
              }
            />
          </EuiPanel>
        </EuiFlexItem>

        {/* Blocks This Week */}
        <EuiFlexItem>
          <EuiPanel className="athena-card athena-hover-glow-blue">
            <EuiStat
              title={stats?.blocks_this_week || 0}
              description="Blocks This Week"
              titleColor="success"
              textAlign="center"
              icon={
                <div style={{ color: '#16a34a', marginBottom: '8px' }}>
                  <TrendingUp size={32} />
                </div>
              }
            />
          </EuiPanel>
        </EuiFlexItem>

        {/* Active Blocks Now */}
        <EuiFlexItem>
          <EuiPanel className="athena-card athena-hover-glow-blue">
            <EuiStat
              title={stats?.active_blocks_now || 0}
              description="Currently Active"
              titleColor={stats?.active_blocks_now > 0 ? 'danger' : 'subdued'}
              textAlign="center"
              icon={
                <div style={{ color: stats?.active_blocks_now > 0 ? '#dc2626' : '#64748b', marginBottom: '8px' }}>
                  <Activity size={32} />
                </div>
              }
            />
          </EuiPanel>
        </EuiFlexItem>
      </EuiFlexGroup>

      <EuiSpacer size="l" />

      {/* Top Blocked IPs */}
      {stats?.top_blocked_ips && stats.top_blocked_ips.length > 0 && (
        <EuiPanel className="athena-card">
          <EuiTitle size="s">
            <h3 style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
              <AlertCircle size={20} color="#3b82f6" />
              Top Blocked IPs (Last 7 Days)
            </h3>
          </EuiTitle>
          <EuiSpacer size="m" />
          <EuiFlexGroup direction="column" gutterSize="s">
            {stats.top_blocked_ips.slice(0, 5).map((item, index) => (
              <EuiFlexItem key={index}>
                <EuiFlexGroup justifyContent="spaceBetween" alignItems="center">
                  <EuiFlexItem grow={false}>
                    <EuiText size="s" style={{ fontFamily: 'monospace', color: '#f8fafc' }}>
                      {item.ip}
                    </EuiText>
                  </EuiFlexItem>
                  <EuiFlexItem grow={false}>
                    <span className="athena-badge-critical" style={{ padding: '4px 12px', borderRadius: '12px', fontSize: '12px' }}>
                      {item.count} blocks
                    </span>
                  </EuiFlexItem>
                </EuiFlexGroup>
              </EuiFlexItem>
            ))}
          </EuiFlexGroup>
        </EuiPanel>
      )}

      {/* Top Targeted Agents */}
      {stats?.top_targeted_agents && stats.top_targeted_agents.length > 0 && (
        <>
          <EuiSpacer size="l" />
          <EuiPanel className="athena-card">
            <EuiTitle size="s">
              <h3 style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                <Shield size={20} color="#3b82f6" />
                Most Targeted Agents (Last 7 Days)
              </h3>
            </EuiTitle>
            <EuiSpacer size="m" />
            <EuiFlexGroup direction="column" gutterSize="s">
              {stats.top_targeted_agents.slice(0, 5).map((item, index) => (
                <EuiFlexItem key={index}>
                  <EuiFlexGroup justifyContent="spaceBetween" alignItems="center">
                    <EuiFlexItem grow={false}>
                      <EuiText size="s" style={{ color: '#f8fafc' }}>
                        <strong>{item.agent_name}</strong> ({item.agent_id})
                      </EuiText>
                    </EuiFlexItem>
                    <EuiFlexItem grow={false}>
                      <span className="athena-badge-high" style={{ padding: '4px 12px', borderRadius: '12px', fontSize: '12px' }}>
                        {item.count} blocks
                      </span>
                    </EuiFlexItem>
                  </EuiFlexGroup>
                </EuiFlexItem>
              ))}
            </EuiFlexGroup>
          </EuiPanel>
        </>
      )}
    </>
  );
};

export default ARStatistics;
