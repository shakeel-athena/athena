import React from 'react';
import {
  EuiText,
  EuiBadge,
  EuiFlexGroup,
  EuiFlexItem,
  EuiSpacer,
  EuiPanel,
} from '@elastic/eui';
import { Clock } from 'lucide-react';

/**
 * Simple 2D Timeline Component
 *
 * Clean horizontal timeline visualization for attack progression
 * Shows events in chronological order with visual timeline bar
 */
const SimpleTimeline2D = ({ timeline }) => {
  if (!timeline || timeline.length === 0) {
    return (
      <EuiText size="s" color="subdued" textAlign="center">
        No timeline events to display
      </EuiText>
    );
  }

  // Get time range
  const timestamps = timeline.map(e => new Date(e.timestamp).getTime());
  const minTime = Math.min(...timestamps);
  const maxTime = Math.max(...timestamps);
  const timeRange = maxTime - minTime || 1;

  // Calculate position percentage for each event
  const getPositionPercent = (timestamp) => {
    const eventTime = new Date(timestamp).getTime();
    return ((eventTime - minTime) / timeRange) * 100;
  };

  // Get event color based on type
  const getEventColor = (event) => {
    if (event.event_type === 'ar_block') return '#10B981'; // Green
    if (event.triggered_block) return '#EF4444'; // Red
    if (event.event_type === 'ssh_attempt') return '#F59E0B'; // Yellow
    if (event.event_type === 'port_scan') return '#3B82F6'; // Blue
    return '#6B7280'; // Gray
  };

  // Format time
  const formatTime = (timestamp) => {
    const date = new Date(timestamp);
    return date.toLocaleTimeString('en-US', {
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit',
      hour12: false
    });
  };

  return (
    <div>
      {/* Timeline Header */}
      <EuiFlexGroup justifyContent="spaceBetween" alignItems="center" gutterSize="s">
        <EuiFlexItem grow={false}>
          <EuiText size="xs" color="subdued">
            <Clock size={14} style={{ display: 'inline', marginRight: '4px' }} />
            {formatTime(timeline[0].timestamp)}
          </EuiText>
        </EuiFlexItem>
        <EuiFlexItem grow={false}>
          <EuiText size="xs" color="subdued">
            Duration: {((maxTime - minTime) / 60000).toFixed(1)} min
          </EuiText>
        </EuiFlexItem>
        <EuiFlexItem grow={false}>
          <EuiText size="xs" color="subdued">
            {formatTime(timeline[timeline.length - 1].timestamp)}
          </EuiText>
        </EuiFlexItem>
      </EuiFlexGroup>

      <EuiSpacer size="m" />

      {/* Timeline Visualization */}
      <div style={{ position: 'relative', height: '120px', marginBottom: '20px' }}>
        {/* Timeline Bar */}
        <div
          style={{
            position: 'absolute',
            top: '50%',
            left: '0',
            right: '0',
            height: '2px',
            background: 'linear-gradient(to right, #3B82F6, #10B981)',
            transform: 'translateY(-50%)',
          }}
        />

        {/* Events */}
        {timeline.map((event, index) => {
          const positionPercent = getPositionPercent(event.timestamp);
          const color = getEventColor(event);
          const isTop = index % 2 === 0;

          return (
            <div
              key={index}
              style={{
                position: 'absolute',
                left: `${positionPercent}%`,
                top: isTop ? '10px' : 'auto',
                bottom: isTop ? 'auto' : '10px',
                transform: 'translateX(-50%)',
                zIndex: 10,
              }}
            >
              {/* Connector Line */}
              <div
                style={{
                  position: 'absolute',
                  left: '50%',
                  top: isTop ? '100%' : 'auto',
                  bottom: isTop ? 'auto' : '100%',
                  width: '2px',
                  height: '20px',
                  background: color,
                  transform: 'translateX(-50%)',
                }}
              />

              {/* Event Marker */}
              <div
                style={{
                  width: '16px',
                  height: '16px',
                  borderRadius: '50%',
                  background: color,
                  border: '3px solid rgba(15, 23, 42, 0.9)',
                  cursor: 'pointer',
                  boxShadow: `0 0 10px ${color}`,
                  position: 'relative',
                }}
                title={`${event.rule_description} - ${formatTime(event.timestamp)}`}
              >
                {event.event_type === 'ar_block' && (
                  <div
                    style={{
                      position: 'absolute',
                      top: '-2px',
                      right: '-2px',
                      width: '8px',
                      height: '8px',
                      borderRadius: '50%',
                      background: '#fff',
                      fontSize: '8px',
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'center',
                    }}
                  >
                    🛡️
                  </div>
                )}
              </div>
            </div>
          );
        })}
      </div>

      <EuiSpacer size="l" />

      {/* Event Details List */}
      <div style={{ maxHeight: '400px', overflowY: 'auto' }}>
        {timeline.map((event, index) => (
          <EuiPanel
            key={index}
            color="subdued"
            paddingSize="s"
            style={{
              marginBottom: '8px',
              borderLeft: `4px solid ${getEventColor(event)}`,
            }}
          >
            <EuiFlexGroup gutterSize="s" alignItems="center" wrap>
              <EuiFlexItem grow={false}>
                <EuiText size="xs" style={{ fontFamily: 'monospace', color: '#94A3B8' }}>
                  {formatTime(event.timestamp)}
                </EuiText>
              </EuiFlexItem>

              <EuiFlexItem grow={false}>
                <EuiBadge color="hollow">
                  Rule {event.rule_id}
                </EuiBadge>
              </EuiFlexItem>

              <EuiFlexItem>
                <EuiText size="s">
                  <strong>{event.rule_description}</strong>
                </EuiText>
              </EuiFlexItem>

              {event.triggered_block && (
                <EuiFlexItem grow={false}>
                  <EuiBadge color="danger" iconType="lock">
                    TRIGGERED BLOCK
                  </EuiBadge>
                </EuiFlexItem>
              )}

              {event.event_type === 'ar_block' && (
                <EuiFlexItem grow={false}>
                  <EuiBadge color="success" iconType="checkInCircleFilled">
                    BLOCK APPLIED
                  </EuiBadge>
                </EuiFlexItem>
              )}

              {event.is_aggregated && event.aggregation_count > 1 && (
                <EuiFlexItem grow={false}>
                  <EuiBadge color="warning" iconType="merge">
                    x{event.aggregation_count}
                  </EuiBadge>
                </EuiFlexItem>
              )}
            </EuiFlexGroup>

            <EuiSpacer size="xs" />

            <EuiFlexGroup gutterSize="xs" wrap>
              {event.mitre_technique && (
                <EuiFlexItem grow={false}>
                  <EuiBadge
                    color="primary"
                    style={{ fontSize: '10px' }}
                  >
                    {event.mitre_technique}: {event.mitre_technique_name}
                  </EuiBadge>
                </EuiFlexItem>
              )}

              <EuiFlexItem grow={false}>
                <EuiBadge
                  style={{
                    fontSize: '10px',
                    backgroundColor: getEventColor(event) + '20',
                    color: getEventColor(event),
                    border: `1px solid ${getEventColor(event)}`,
                  }}
                >
                  {event.attack_stage}
                </EuiBadge>
              </EuiFlexItem>
            </EuiFlexGroup>

            <EuiSpacer size="xs" />

            <EuiText size="xs" color="subdued">
              Agent: {event.agent_name} ({event.agent_id})
            </EuiText>
          </EuiPanel>
        ))}
      </div>

      {/* Legend */}
      <EuiSpacer size="m" />
      <EuiFlexGroup gutterSize="s" wrap>
        <EuiFlexItem grow={false}>
          <EuiFlexGroup gutterSize="xs" alignItems="center">
            <EuiFlexItem grow={false}>
              <div style={{ width: '12px', height: '12px', borderRadius: '50%', background: '#3B82F6' }} />
            </EuiFlexItem>
            <EuiFlexItem grow={false}>
              <EuiText size="xs">Port Scan</EuiText>
            </EuiFlexItem>
          </EuiFlexGroup>
        </EuiFlexItem>

        <EuiFlexItem grow={false}>
          <EuiFlexGroup gutterSize="xs" alignItems="center">
            <EuiFlexItem grow={false}>
              <div style={{ width: '12px', height: '12px', borderRadius: '50%', background: '#F59E0B' }} />
            </EuiFlexItem>
            <EuiFlexItem grow={false}>
              <EuiText size="xs">SSH Attempt</EuiText>
            </EuiFlexItem>
          </EuiFlexGroup>
        </EuiFlexItem>

        <EuiFlexItem grow={false}>
          <EuiFlexGroup gutterSize="xs" alignItems="center">
            <EuiFlexItem grow={false}>
              <div style={{ width: '12px', height: '12px', borderRadius: '50%', background: '#EF4444' }} />
            </EuiFlexItem>
            <EuiFlexItem grow={false}>
              <EuiText size="xs">Triggered Block</EuiText>
            </EuiFlexItem>
          </EuiFlexGroup>
        </EuiFlexItem>

        <EuiFlexItem grow={false}>
          <EuiFlexGroup gutterSize="xs" alignItems="center">
            <EuiFlexItem grow={false}>
              <div style={{ width: '12px', height: '12px', borderRadius: '50%', background: '#10B981' }} />
            </EuiFlexItem>
            <EuiFlexItem grow={false}>
              <EuiText size="xs">AR Block Applied</EuiText>
            </EuiFlexItem>
          </EuiFlexGroup>
        </EuiFlexItem>
      </EuiFlexGroup>
    </div>
  );
};

export default SimpleTimeline2D;
