import React from 'react';
import { EuiBadge, EuiToolTip, EuiText, EuiFlexGroup, EuiFlexItem } from '@elastic/eui';
import { Target, Shield, AlertTriangle } from 'lucide-react';

/**
 * MITRE ATT&CK Technique Badge Component
 *
 * Displays MITRE technique with tooltip containing detailed information
 */
const MITREBadge = ({ technique, techniqueName, tactic, tacticName, severity = 'Medium', size = 's' }) => {
  // Severity colors
  const getSeverityColor = () => {
    switch (severity) {
      case 'Critical':
        return 'danger';
      case 'High':
        return 'danger';
      case 'Medium':
        return 'warning';
      case 'Low':
        return 'success';
      default:
        return 'primary';
    }
  };

  // Tooltip content with MITRE details
  const tooltipContent = (
    <div style={{ minWidth: '280px' }}>
      <EuiText size="xs">
        <div style={{ marginBottom: '8px' }}>
          <strong style={{ fontSize: '13px', color: '#3b82f6' }}>
            {technique} - {techniqueName}
          </strong>
        </div>

        <div style={{ marginBottom: '8px', color: '#94a3b8' }}>
          <strong>Tactic:</strong> {tacticName} ({tactic})
        </div>

        <div style={{ marginBottom: '8px', color: '#94a3b8' }}>
          <strong>Severity:</strong> {severity}
        </div>

        <hr style={{ margin: '8px 0', border: 'none', borderTop: '1px solid #334155' }} />

        <div style={{ fontSize: '10px', color: '#64748b' }}>
          Click to view full details on MITRE ATT&CK Navigator
        </div>
      </EuiText>
    </div>
  );

  // Link to MITRE ATT&CK website
  const handleClick = () => {
    window.open(
      `https://attack.mitre.org/techniques/${technique.replace('.', '/')}`,
      '_blank',
      'noopener,noreferrer'
    );
  };

  return (
    <EuiToolTip content={tooltipContent}>
      <EuiBadge
        color={getSeverityColor()}
        iconType={() => <Target size={12} />}
        onClick={handleClick}
        onClickAriaLabel={`View ${technique} on MITRE ATT&CK`}
        style={{ cursor: 'pointer', fontSize: size === 'l' ? '13px' : '11px' }}
      >
        {technique}
      </EuiBadge>
    </EuiToolTip>
  );
};

/**
 * Multiple MITRE Techniques Display
 */
export const MITRETechniquesList = ({ techniques = [] }) => {
  if (!techniques || techniques.length === 0) {
    return (
      <EuiText size="xs" color="subdued">
        No MITRE techniques identified
      </EuiText>
    );
  }

  return (
    <EuiFlexGroup gutterSize="xs" wrap responsive={false}>
      {techniques.map((tech, index) => (
        <EuiFlexItem grow={false} key={index}>
          <MITREBadge
            technique={tech.technique}
            techniqueName={tech.technique_name}
            tactic={tech.tactic}
            tacticName={tech.tactic_name}
            severity={tech.severity}
          />
        </EuiFlexItem>
      ))}
    </EuiFlexGroup>
  );
};

/**
 * Attack Kill Chain Visualization
 */
export const AttackKillChain = ({ killChain = [] }) => {
  if (!killChain || killChain.length === 0) {
    return null;
  }

  // Sort by order
  const sortedChain = [...killChain].sort((a, b) => a.order - b.order);

  return (
    <div>
      <EuiText size="xs">
        <strong>Attack Chain Progression:</strong>
      </EuiText>
      <div style={{ marginTop: '8px', display: 'flex', alignItems: 'center', gap: '8px', flexWrap: 'wrap' }}>
        {sortedChain.map((stage, index) => (
          <React.Fragment key={index}>
            <EuiToolTip
              content={
                <div>
                  <div><strong>{stage.tactic_name}</strong></div>
                  <div style={{ fontSize: '10px', color: '#94a3b8', marginTop: '4px' }}>
                    {stage.techniques.map(t => t.technique).join(', ')}
                  </div>
                </div>
              }
            >
              <EuiBadge
                color="primary"
                style={{
                  padding: '6px 12px',
                  fontSize: '11px',
                  cursor: 'help'
                }}
              >
                <Shield size={12} style={{ marginRight: '4px', display: 'inline' }} />
                {stage.tactic_name}
              </EuiBadge>
            </EuiToolTip>
            {index < sortedChain.length - 1 && (
              <span style={{ color: '#64748b', fontSize: '14px' }}>→</span>
            )}
          </React.Fragment>
        ))}
      </div>
    </div>
  );
};

export default MITREBadge;
