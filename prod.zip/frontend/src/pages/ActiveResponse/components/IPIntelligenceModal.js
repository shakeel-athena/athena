import React, { useState, useEffect } from 'react';
import {
  EuiModal,
  EuiModalHeader,
  EuiModalHeaderTitle,
  EuiModalBody,
  EuiModalFooter,
  EuiButton,
  EuiText,
  EuiLoadingSpinner,
  EuiCallOut,
  EuiSpacer,
  EuiFlexGroup,
  EuiFlexItem,
  EuiBadge,
  EuiPanel,
  EuiDescriptionList,
  EuiAccordion,
  EuiListGroup,
  EuiListGroupItem
} from '@elastic/eui';
import { Globe, Shield, TrendingUp, MapPin, Clock, Activity } from 'lucide-react';
import axios from 'axios';
import ThreatScoreBadge from './ThreatScoreBadge';
import { MITRETechniquesList } from './MITREBadge';

// API Base URL - MUST be configured via environment variable for production
const API_BASE = process.env.REACT_APP_API_BASE_URL;

/**
 * IP Intelligence Modal Component
 *
 * Displays comprehensive IP threat profile including:
 * - Threat score and risk level
 * - IP reputation (AbuseIPDB)
 * - MITRE techniques observed
 * - Recommended actions
 * - Attack timeline summary
 */
const IPIntelligenceModal = ({ ipAddress, onClose }) => {
  const [intelligence, setIntelligence] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    if (ipAddress) {
      fetchIntelligence();
    }
  }, [ipAddress]);

  const fetchIntelligence = async () => {
    try {
      setLoading(true);
      setError(null);

      const response = await axios.get(
        `${API_BASE}/api/active-response/ip-intelligence/${ipAddress}?hours=24`
      );

      setIntelligence(response.data);
    } catch (err) {
      console.error('Error fetching IP intelligence:', err);
      setError(err.response?.data?.error || 'Failed to load IP intelligence');
    } finally {
      setLoading(false);
    }
  };

  const formatTime = (timestamp) => {
    if (!timestamp) return 'Unknown';
    const date = new Date(timestamp);
    return date.toLocaleString('en-US', {
      month: 'short',
      day: 'numeric',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit',
      hour12: true
    });
  };

  return (
    <EuiModal onClose={onClose} maxWidth={900}>
      <EuiModalHeader>
        <EuiModalHeaderTitle>
          <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
            <Globe size={24} color="#3b82f6" />
            <span>IP Intelligence: {ipAddress}</span>
          </div>
        </EuiModalHeaderTitle>
      </EuiModalHeader>

      <EuiModalBody>
        {loading ? (
          <div style={{ textAlign: 'center', padding: '40px 20px' }}>
            <EuiLoadingSpinner size="xl" />
            <EuiSpacer size="m" />
            <EuiText color="subdued">Loading IP intelligence...</EuiText>
          </div>
        ) : error ? (
          <EuiCallOut title="Error" color="danger" iconType="alert">
            {error}
          </EuiCallOut>
        ) : !intelligence ? (
          <EuiCallOut title="No Data" iconType="iInCircle">
            No intelligence data found for this IP address.
          </EuiCallOut>
        ) : (
          <div style={{ maxHeight: '600px', overflowY: 'auto', paddingRight: '8px' }}>
            {/* Threat Score Section */}
            <EuiPanel color="primary" hasShadow={false}>
              <EuiFlexGroup alignItems="center" justifyContent="spaceBetween">
                <EuiFlexItem grow={false}>
                  <EuiText>
                    <h3>Threat Assessment</h3>
                  </EuiText>
                </EuiFlexItem>
                <EuiFlexItem grow={false}>
                  <ThreatScoreBadge
                    score={intelligence.threat_score}
                    riskLevel={intelligence.risk_level}
                    size="l"
                    showBreakdown={true}
                    breakdown={intelligence.score_breakdown}
                  />
                </EuiFlexItem>
              </EuiFlexGroup>
            </EuiPanel>

            <EuiSpacer size="l" />

            {/* Attack Summary */}
            <EuiPanel>
              <EuiText>
                <h4 style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                  <Activity size={18} />
                  Attack Summary
                </h4>
              </EuiText>
              <EuiSpacer size="m" />

              <EuiDescriptionList
                type="column"
                listItems={[
                  {
                    title: 'Total Blocks',
                    description: <strong>{intelligence.total_blocks}</strong>
                  },
                  {
                    title: 'Unique Rules Triggered',
                    description: <strong>{intelligence.unique_rules}</strong>
                  },
                  {
                    title: 'Attack Velocity',
                    description: <strong>{intelligence.attack_velocity} events/min</strong>
                  },
                  {
                    title: 'Attack Duration',
                    description: <strong>{intelligence.duration_minutes?.toFixed(2)} minutes</strong>
                  },
                  {
                    title: 'First Seen',
                    description: formatTime(intelligence.first_seen)
                  },
                  {
                    title: 'Last Seen',
                    description: formatTime(intelligence.last_seen)
                  }
                ]}
              />
            </EuiPanel>

            <EuiSpacer size="m" />

            {/* IP Reputation */}
            {intelligence.reputation && (
              <>
                <EuiPanel>
                  <EuiText>
                    <h4 style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                      <Shield size={18} />
                      IP Reputation (AbuseIPDB)
                    </h4>
                  </EuiText>
                  <EuiSpacer size="m" />

                  <EuiDescriptionList
                    type="column"
                    listItems={[
                      {
                        title: 'Confidence Score',
                        description: (
                          <div>
                            <strong>{intelligence.reputation.confidence_score}/100</strong>
                            {intelligence.reputation.confidence_score > 50 && (
                              <EuiBadge color="danger" style={{ marginLeft: '8px' }}>
                                Known Malicious
                              </EuiBadge>
                            )}
                          </div>
                        )
                      },
                      {
                        title: 'Total Reports',
                        description: intelligence.reputation.total_reports || 0
                      },
                      {
                        title: 'Country',
                        description: intelligence.reputation.country_code || 'Unknown'
                      },
                      {
                        title: 'Usage Type',
                        description: intelligence.reputation.usage_type || 'Unknown'
                      },
                      {
                        title: 'ISP',
                        description: intelligence.reputation.isp || 'Unknown'
                      },
                      {
                        title: 'Status',
                        description: intelligence.reputation.is_whitelisted ? (
                          <EuiBadge color="success">Whitelisted</EuiBadge>
                        ) : intelligence.reputation.is_tor ? (
                          <EuiBadge color="warning">TOR Exit Node</EuiBadge>
                        ) : (
                          <EuiBadge color="hollow">Normal</EuiBadge>
                        )
                      }
                    ]}
                  />
                </EuiPanel>

                <EuiSpacer size="m" />
              </>
            )}

            {/* MITRE Techniques */}
            <EuiAccordion
              id="mitre-techniques"
              buttonContent={
                <EuiText>
                  <strong>MITRE ATT&CK Techniques ({intelligence.mitre_techniques?.length || 0})</strong>
                </EuiText>
              }
              initialIsOpen={true}
            >
              <EuiSpacer size="s" />
              {intelligence.mitre_techniques && intelligence.mitre_techniques.length > 0 ? (
                <MITRETechniquesList techniques={intelligence.mitre_techniques} />
              ) : (
                <EuiText size="s" color="subdued">No MITRE techniques identified</EuiText>
              )}
            </EuiAccordion>

            <EuiSpacer size="m" />

            {/* Affected Agents */}
            <EuiAccordion
              id="affected-agents"
              buttonContent={
                <EuiText>
                  <strong>Affected Agents ({intelligence.affected_agents?.length || 0})</strong>
                </EuiText>
              }
              initialIsOpen={false}
            >
              <EuiSpacer size="s" />
              {intelligence.affected_agents && intelligence.affected_agents.length > 0 ? (
                <div>
                  {intelligence.affected_agents.map((agent, index) => (
                    <div key={index} style={{ padding: '8px 0', borderBottom: '1px solid #1e293b' }}>
                      <EuiText size="s">
                        <strong>{agent.name}</strong>
                        <span style={{ marginLeft: '8px', color: '#64748b' }}>
                          ({agent.count} blocks)
                        </span>
                      </EuiText>
                    </div>
                  ))}
                </div>
              ) : (
                <EuiText size="s" color="subdued">No affected agents</EuiText>
              )}
            </EuiAccordion>

            <EuiSpacer size="m" />

            {/* Recommended Actions */}
            <EuiAccordion
              id="recommended-actions"
              buttonContent={
                <EuiText>
                  <strong>Recommended Actions ({intelligence.recommended_actions?.length || 0})</strong>
                </EuiText>
              }
              initialIsOpen={true}
            >
              <EuiSpacer size="s" />
              {intelligence.recommended_actions && intelligence.recommended_actions.length > 0 ? (
                <EuiListGroup flush={false}>
                  {intelligence.recommended_actions.map((action, index) => (
                    <EuiListGroupItem
                      key={index}
                      label={
                        <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                          <span style={{ fontSize: '16px' }}>{action.icon}</span>
                          <span>{action.action}</span>
                        </div>
                      }
                      extraAction={{
                        color: action.automated ? 'primary' : 'text',
                        iconType: action.automated ? 'play' : 'documentEdit',
                        'aria-label': action.automated ? 'Automated' : 'Manual',
                        title: action.automated ? 'Automated action' : 'Manual action required'
                      }}
                      wrapText
                    />
                  ))}
                </EuiListGroup>
              ) : (
                <EuiText size="s" color="subdued">No recommended actions</EuiText>
              )}
            </EuiAccordion>
          </div>
        )}
      </EuiModalBody>

      <EuiModalFooter>
        <EuiButton onClick={onClose} fill>
          Close
        </EuiButton>
      </EuiModalFooter>
    </EuiModal>
  );
};

export default IPIntelligenceModal;
