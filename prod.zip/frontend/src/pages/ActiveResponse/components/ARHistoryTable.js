import React, { useState, useEffect, useCallback, useMemo } from 'react';
import {
  EuiPanel,
  EuiTitle,
  EuiSpacer,
  EuiBasicTable,
  EuiFlexGroup,
  EuiFlexItem,
  EuiFieldSearch,
  EuiSelect,
  EuiBadge,
  EuiText,
  EuiButtonIcon,
  EuiToolTip
} from '@elastic/eui';
import { History, RefreshCw, Download } from 'lucide-react';
import { apiRequest } from '../../../services/apiClient';
import toast from 'react-hot-toast';
import ARBlockExpandedRow from './ARBlockExpandedRow';

// API Base URL - MUST be configured via environment variable for production
const API_BASE = process.env.REACT_APP_API_BASE_URL;

/**
 * AR History Table
 *
 * Displays paginated history of Active Response blocks with filtering capabilities.
 */
const ARHistoryTable = ({ refreshTrigger }) => {
  const [auditTrail, setAuditTrail] = useState([]);
  const [loading, setLoading] = useState(false);
  const [pageIndex, setPageIndex] = useState(0);
  const [pageSize, setPageSize] = useState(20);
  const [totalCount, setTotalCount] = useState(0);
  const [searchText, setSearchText] = useState('');
  const [daysFilter, setDaysFilter] = useState('7');
  const [actionTypeFilter, setActionTypeFilter] = useState('all');
  const [expandedRows, setExpandedRows] = useState(new Set());

  useEffect(() => {
    fetchHistory();
  }, [pageIndex, pageSize, daysFilter, actionTypeFilter, refreshTrigger]);

  const fetchHistory = async () => {
    try {
      setLoading(true);

      const params = new URLSearchParams({
        page: pageIndex + 1,
        page_size: pageSize,
        days: daysFilter,
        action_type: actionTypeFilter
      });

      if (searchText) {
        params.append('ip_address', searchText);
      }

      const url = `${API_BASE}/api/active-response/audit-trail?${params.toString()}`;
      const data = await apiRequest(url, { method: 'GET' });

      setAuditTrail(data?.audit_trail || []);
      setTotalCount(data?.total || 0);
    } catch (err) {
      console.error('Error fetching AR audit trail:', err);
      toast.error('Failed to load audit trail');
    } finally {
      setLoading(false);
    }
  };

  const handleSearch = () => {
    setPageIndex(0); // Reset to first page
    fetchHistory();
  };

  const handleExport = () => {
    // Convert audit trail to CSV
    const headers = ['Timestamp', 'Action Type', 'IP Address', 'Agent', 'Performed By', 'Via', 'Reason', 'Rule', 'Status'];
    const csvData = auditTrail.map(entry => [
      new Date(entry.timestamp).toLocaleString(),
      entry.action_type.toUpperCase(),
      entry.ip_address,
      `${entry.agent_name} (${entry.agent_id})`,
      entry.performed_by,
      entry.performed_via,
      entry.reason,
      entry.triggered_by_rule || 'N/A',
      entry.status
    ]);

    const csvContent = [
      headers.join(','),
      ...csvData.map(row => row.map(cell => `"${cell}"`).join(','))
    ].join('\n');

    const blob = new Blob([csvContent], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `ar-audit-trail-${new Date().toISOString().split('T')[0]}.csv`;
    link.click();
    URL.revokeObjectURL(url);

    toast.success('Audit trail exported to CSV');
  };

  const getRuleBadgeColor = (ruleId) => {
    if (ruleId === '5763') return 'danger'; // SSH brute force
    if (ruleId === '31103') return 'warning'; // Web attacks
    if (['5710', '5711', '5712'].includes(ruleId)) return '#eab308'; // Port scans
    return 'default';
  };

  const getActionBadgeConfig = (actionType) => {
    const configs = {
      block: { color: 'danger', label: 'BLOCK' },
      unblock: { color: 'success', label: 'UNBLOCK' },
      expired: { color: 'default', label: 'EXPIRED' }
    };
    return configs[actionType] || { color: 'default', label: actionType.toUpperCase() };
  };

  const toggleExpandRow = useCallback((id) => {
    setExpandedRows(prev => {
      const newSet = new Set(prev);
      if (newSet.has(id)) {
        newSet.delete(id);
      } else {
        newSet.add(id);
      }
      return newSet;
    });
  }, []);

  const itemIdToExpandedRowMap = useMemo(() => {
    const map = {};
    auditTrail.forEach((entry) => {
      if (expandedRows.has(entry.id)) {
        map[entry.id] = <ARBlockExpandedRow entry={entry} />;
      }
    });
    return map;
  }, [auditTrail, expandedRows]);

  const columns = [
    {
      name: '',
      render: (item) => (
        <EuiButtonIcon
          iconType={expandedRows.has(item.id) ? 'arrowUp' : 'arrowDown'}
          aria-label="Toggle row details"
          onClick={() => toggleExpandRow(item.id)}
          color="text"
        />
      ),
      width: '5%',
      align: 'right',
      mobileOptions: {
        show: true,
        header: false
      }
    },
    {
      field: 'timestamp',
      name: 'Time',
      truncateText: false,
      render: (timestamp) => (
        <EuiText size="s" style={{ fontFamily: 'monospace', whiteSpace: 'nowrap', fontSize: '12px' }}>
          {new Date(timestamp).toLocaleDateString()}<br />
          {new Date(timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
        </EuiText>
      ),
      width: '15%',
      mobileOptions: {
        show: true,
        header: true
      }
    },
    {
      field: 'action_type',
      name: 'Action',
      render: (actionType) => {
        const config = getActionBadgeConfig(actionType);
        return (
          <EuiBadge color={config.color}>
            {config.label}
          </EuiBadge>
        );
      },
      width: '10%',
      mobileOptions: {
        show: true,
        header: true
      }
    },
    {
      field: 'ip_address',
      name: 'IP',
      truncateText: false,
      render: (ip) => (
        <EuiText size="s" style={{ fontFamily: 'monospace', fontWeight: 'bold' }}>
          {ip}
        </EuiText>
      ),
      width: '12%',
      mobileOptions: {
        show: true,
        header: true
      }
    },
    {
      field: 'agent_name',
      name: 'Agent',
      truncateText: true,
      render: (agent_name, item) => (
        <EuiToolTip content={`${agent_name} (${item.agent_id})`}>
          <EuiText size="s" style={{ overflow: 'hidden', textOverflow: 'ellipsis' }}>
            {agent_name}
          </EuiText>
        </EuiToolTip>
      ),
      width: '13%',
      mobileOptions: {
        show: false
      }
    },
    {
      field: 'performed_by',
      name: 'Performed By',
      truncateText: true,
      render: (performed_by, item) => (
        <EuiToolTip content={`${performed_by} (${item.performed_via})`}>
          <div style={{ overflow: 'hidden', textOverflow: 'ellipsis' }}>
            <EuiText size="s" style={{ fontWeight: 'bold' }}>
              {performed_by}
            </EuiText>
          </div>
        </EuiToolTip>
      ),
      width: '13%',
      mobileOptions: {
        show: true,
        header: false
      }
    },
    {
      field: 'reason',
      name: 'Reason/Rule',
      truncateText: true,
      render: (reason) => (
        <EuiToolTip content={reason}>
          <EuiText size="s" color="subdued" style={{ overflow: 'hidden', textOverflow: 'ellipsis' }}>
            {reason}
          </EuiText>
        </EuiToolTip>
      ),
      width: '22%',
      mobileOptions: {
        show: true,
        header: false
      }
    },
    {
      field: 'status',
      name: 'Status',
      render: (status) => {
        const colors = {
          active: 'primary',
          expired: 'default',
          completed: 'success'
        };
        return (
          <EuiBadge color={colors[status] || 'default'}>
            {status}
          </EuiBadge>
        );
      },
      width: '10%',
      mobileOptions: {
        show: true,
        header: true
      }
    }
  ];

  const pagination = {
    pageIndex,
    pageSize,
    totalItemCount: totalCount,
    pageSizeOptions: [10, 20, 50, 100]
  };

  const onTableChange = ({ page }) => {
    if (page) {
      setPageIndex(page.index);
      setPageSize(page.size);
    }
  };

  return (
    <EuiPanel className="athena-card">
      <EuiFlexGroup justifyContent="spaceBetween" alignItems="center">
        <EuiFlexItem grow={false}>
          <EuiTitle size="s">
            <h3 style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
              <History size={20} color="#3b82f6" />
              Audit Trail
            </h3>
          </EuiTitle>
        </EuiFlexItem>
        <EuiFlexItem grow={false}>
          <EuiFlexGroup gutterSize="s">
            <EuiFlexItem grow={false}>
              <EuiToolTip content="Export to CSV">
                <EuiButtonIcon
                  iconType={() => <Download size={16} />}
                  onClick={handleExport}
                  aria-label="Export"
                  color="text"
                  disabled={auditTrail.length === 0}
                />
              </EuiToolTip>
            </EuiFlexItem>
            <EuiFlexItem grow={false}>
              <EuiButtonIcon
                iconType={() => <RefreshCw size={16} />}
                onClick={fetchHistory}
                aria-label="Refresh"
                color="text"
              />
            </EuiFlexItem>
          </EuiFlexGroup>
        </EuiFlexItem>
      </EuiFlexGroup>

      <EuiSpacer size="m" />

      {/* Filters */}
      <EuiFlexGroup gutterSize="m">
        <EuiFlexItem grow={5}>
          <EuiFieldSearch
            placeholder="Search by IP address..."
            value={searchText}
            onChange={(e) => setSearchText(e.target.value)}
            onSearch={handleSearch}
            isClearable
            fullWidth
          />
        </EuiFlexItem>
        <EuiFlexItem grow={3}>
          <EuiSelect
            options={[
              { value: 'all', text: 'All Actions' },
              { value: 'block', text: 'Blocks Only' },
              { value: 'unblock', text: 'Unblocks Only' },
              { value: 'expired', text: 'Expirations Only' }
            ]}
            value={actionTypeFilter}
            onChange={(e) => {
              setActionTypeFilter(e.target.value);
              setPageIndex(0);
            }}
            fullWidth
            prepend="Action Type"
          />
        </EuiFlexItem>
        <EuiFlexItem grow={2}>
          <EuiSelect
            options={[
              { value: '1', text: 'Last 24 hours' },
              { value: '7', text: 'Last 7 days' },
              { value: '30', text: 'Last 30 days' },
              { value: '90', text: 'Last 90 days' }
            ]}
            value={daysFilter}
            onChange={(e) => {
              setDaysFilter(e.target.value);
              setPageIndex(0);
            }}
            fullWidth
          />
        </EuiFlexItem>
      </EuiFlexGroup>

      <EuiSpacer size="m" />

      {/* Table */}
      <div style={{ overflow: 'auto', width: '100%', maxWidth: '100%' }}>
        <EuiBasicTable
          items={auditTrail}
          columns={columns}
          itemId="id"
          itemIdToExpandedRowMap={itemIdToExpandedRowMap}
          isExpandable={true}
          pagination={pagination}
          onChange={onTableChange}
          loading={loading}
          noItemsMessage={
            loading ? 'Loading audit trail...' : 'No audit trail entries found for the selected filters'
          }
          tableLayout="fixed"
          responsive={true}
          hasActions={false}
        />
      </div>
    </EuiPanel>
  );
};

export default ARHistoryTable;
