import React, { useState, useEffect } from 'react';
import {
  EuiPanel,
  EuiTitle,
  EuiSpacer,
  EuiBasicTable,
  EuiButton,
  EuiModal,
  EuiModalHeader,
  EuiModalHeaderTitle,
  EuiModalBody,
  EuiModalFooter,
  EuiForm,
  EuiFormRow,
  EuiFieldText,
  EuiTextArea,
  EuiSelect,
  EuiFlexGroup,
  EuiFlexItem,
  EuiBadge,
  EuiText,
  EuiButtonIcon,
  EuiToolTip,
  EuiConfirmModal
} from '@elastic/eui';
import { Shield, Plus, Trash2, RefreshCw } from 'lucide-react';
import axios from 'axios';
import toast from 'react-hot-toast';

// API Base URL - MUST be configured via environment variable for production
const API_BASE = process.env.REACT_APP_API_BASE_URL;

/**
 * AR Whitelist Manager
 *
 * Manage IPs that should never be blocked by Active Response.
 * Rebuilt with proper EUI theme matching.
 */
const ARWhitelistManager = ({ onWhitelistChange }) => {
  const [whitelist, setWhitelist] = useState([]);
  const [loading, setLoading] = useState(false);
  const [isAddModalVisible, setIsAddModalVisible] = useState(false);
  const [deleteModalItem, setDeleteModalItem] = useState(null);
  const [formData, setFormData] = useState({
    ip_address: '',
    ip_type: 'single',
    description: ''
  });
  const [formErrors, setFormErrors] = useState({});
  const [submitting, setSubmitting] = useState(false);

  useEffect(() => {
    fetchWhitelist();
  }, []);

  const fetchWhitelist = async () => {
    try {
      setLoading(true);
      const response = await axios.get(`${API_BASE}/api/active-response/whitelist`);
      setWhitelist(response.data.whitelist || []);
    } catch (err) {
      console.error('Error fetching whitelist:', err);
      toast.error('Failed to load whitelist');
    } finally {
      setLoading(false);
    }
  };

  const validateForm = () => {
    const errors = {};

    if (!formData.ip_address) {
      errors.ip_address = 'IP address or CIDR is required';
    } else if (formData.ip_type === 'single') {
      if (!/^(\d{1,3}\.){3}\d{1,3}$/.test(formData.ip_address)) {
        errors.ip_address = 'Invalid IP address format';
      }
    } else if (formData.ip_type === 'cidr') {
      if (!/^(\d{1,3}\.){3}\d{1,3}\/\d{1,2}$/.test(formData.ip_address)) {
        errors.ip_address = 'Invalid CIDR format (e.g., 192.168.0.0/24)';
      }
    }

    if (!formData.description || formData.description.trim().length < 5) {
      errors.description = 'Description must be at least 5 characters';
    }

    setFormErrors(errors);
    return Object.keys(errors).length === 0;
  };

  const handleAddWhitelist = async () => {
    if (!validateForm()) {
      toast.error('Please fix form errors');
      return;
    }

    try {
      setSubmitting(true);

      await axios.post(`${API_BASE}/api/active-response/whitelist`, {
        ip_address: formData.ip_address.trim(),
        ip_type: formData.ip_type,
        description: formData.description.trim(),
        created_by: 'current-user' // TODO: Get from auth context
      });

      toast.success('Whitelist entry added successfully');
      setIsAddModalVisible(false);
      setFormData({ ip_address: '', ip_type: 'single', description: '' });
      setFormErrors({});
      fetchWhitelist();

      if (onWhitelistChange) {
        onWhitelistChange();
      }
    } catch (err) {
      console.error('Error adding whitelist:', err);
      toast.error(err.response?.data?.error || 'Failed to add whitelist entry');
    } finally {
      setSubmitting(false);
    }
  };

  const handleDeleteWhitelist = async (id) => {
    try {
      await axios.delete(`${API_BASE}/api/active-response/whitelist/${id}`);
      toast.success('Whitelist entry removed');
      setDeleteModalItem(null);
      fetchWhitelist();

      if (onWhitelistChange) {
        onWhitelistChange();
      }
    } catch (err) {
      console.error('Error deleting whitelist:', err);
      toast.error('Failed to remove whitelist entry');
    }
  };

  const getStatusBadge = (status) => {
    const statusConfig = {
      approved: { color: 'success', label: 'Approved' },
      pending: { color: 'warning', label: 'Pending' },
      rejected: { color: 'danger', label: 'Rejected' }
    };

    const config = statusConfig[status] || statusConfig.pending;

    return <EuiBadge color={config.color}>{config.label}</EuiBadge>;
  };

  const columns = [
    {
      field: 'ip_address',
      name: 'IP Address / CIDR',
      truncateText: false,
      render: (ip, item) => (
        <EuiText size="s" style={{ fontFamily: 'monospace', fontWeight: 'bold' }}>
          {ip}
          {item.ip_type === 'cidr' && (
            <EuiBadge color="hollow" style={{ marginLeft: '8px' }}>CIDR</EuiBadge>
          )}
        </EuiText>
      ),
      width: '250px'
    },
    {
      field: 'description',
      name: 'Description',
      truncateText: true,
      render: (desc) => (
        <EuiText size="s" color="subdued">{desc}</EuiText>
      )
    },
    {
      field: 'approval_status',
      name: 'Status',
      render: (status) => getStatusBadge(status),
      width: '120px'
    },
    {
      field: 'created_by',
      name: 'Created By',
      truncateText: true,
      render: (created_by) => (
        <EuiText size="s">{created_by}</EuiText>
      ),
      width: '150px'
    },
    {
      name: 'Actions',
      actions: [
        {
          render: (item) => (
            <EuiToolTip content="Remove from whitelist">
              <EuiButtonIcon
                iconType={() => <Trash2 size={16} />}
                onClick={() => setDeleteModalItem(item)}
                aria-label="Delete"
                color="danger"
              />
            </EuiToolTip>
          )
        }
      ],
      width: '80px'
    }
  ];

  return (
    <>
      <EuiPanel className="athena-card">
        <EuiFlexGroup justifyContent="spaceBetween" alignItems="center">
          <EuiFlexItem grow={false}>
            <EuiTitle size="s">
              <h3 style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                <Shield size={20} color="#3b82f6" />
                Whitelist Management
                <EuiBadge color="primary">{whitelist.length}</EuiBadge>
              </h3>
            </EuiTitle>
          </EuiFlexItem>
          <EuiFlexItem grow={false}>
            <EuiFlexGroup gutterSize="s">
              <EuiFlexItem grow={false}>
                <EuiButton
                  fill
                  iconType={() => <Plus size={14} />}
                  onClick={() => setIsAddModalVisible(true)}
                  color="primary"
                >
                  Add IP
                </EuiButton>
              </EuiFlexItem>
              <EuiFlexItem grow={false}>
                <EuiButtonIcon
                  iconType={() => <RefreshCw size={16} />}
                  onClick={fetchWhitelist}
                  aria-label="Refresh"
                  color="text"
                />
              </EuiFlexItem>
            </EuiFlexGroup>
          </EuiFlexItem>
        </EuiFlexGroup>

        <EuiSpacer size="m" />

        <EuiText size="s" color="subdued" style={{ marginBottom: '16px' }}>
          IPs and networks in this list will never be blocked by Active Response.
          Use this for critical infrastructure and trusted systems.
        </EuiText>

        <EuiBasicTable
          items={whitelist}
          columns={columns}
          loading={loading}
          noItemsMessage={
            loading ? 'Loading whitelist...' : 'No whitelist entries found. Add IPs to protect them from AR blocks.'
          }
          tableLayout="auto"
        />
      </EuiPanel>

      {/* Add Modal */}
      {isAddModalVisible && (
        <EuiModal onClose={() => setIsAddModalVisible(false)}>
          <EuiModalHeader>
            <EuiModalHeaderTitle>Add IP to Whitelist</EuiModalHeaderTitle>
          </EuiModalHeader>

          <EuiModalBody>
            <EuiForm>
              <EuiFormRow
                label="IP Type"
                fullWidth
              >
                <EuiSelect
                  options={[
                    { value: 'single', text: 'Single IP Address' },
                    { value: 'cidr', text: 'CIDR Network' }
                  ]}
                  value={formData.ip_type}
                  onChange={(e) => setFormData(prev => ({ ...prev, ip_type: e.target.value }))}
                  fullWidth
                />
              </EuiFormRow>

              <EuiFormRow
                label={formData.ip_type === 'single' ? 'IP Address' : 'CIDR Network'}
                helpText={formData.ip_type === 'single' ? 'Example: 192.168.1.100' : 'Example: 192.168.0.0/24'}
                isInvalid={!!formErrors.ip_address}
                error={formErrors.ip_address}
                fullWidth
              >
                <EuiFieldText
                  placeholder={formData.ip_type === 'single' ? '192.168.1.100' : '192.168.0.0/24'}
                  value={formData.ip_address}
                  onChange={(e) => {
                    setFormData(prev => ({ ...prev, ip_address: e.target.value }));
                    setFormErrors(prev => ({ ...prev, ip_address: null }));
                  }}
                  isInvalid={!!formErrors.ip_address}
                  fullWidth
                />
              </EuiFormRow>

              <EuiFormRow
                label="Description"
                helpText="Explain why this IP/network should be whitelisted"
                isInvalid={!!formErrors.description}
                error={formErrors.description}
                fullWidth
              >
                <EuiTextArea
                  placeholder="Example: Wazuh Manager - Critical infrastructure that must never be blocked"
                  value={formData.description}
                  onChange={(e) => {
                    setFormData(prev => ({ ...prev, description: e.target.value }));
                    setFormErrors(prev => ({ ...prev, description: null }));
                  }}
                  isInvalid={!!formErrors.description}
                  rows={3}
                  fullWidth
                />
              </EuiFormRow>
            </EuiForm>
          </EuiModalBody>

          <EuiModalFooter>
            <EuiButton onClick={() => setIsAddModalVisible(false)}>
              Cancel
            </EuiButton>
            <EuiButton
              fill
              onClick={handleAddWhitelist}
              isLoading={submitting}
              color="primary"
            >
              Add to Whitelist
            </EuiButton>
          </EuiModalFooter>
        </EuiModal>
      )}

      {/* Delete Confirmation Modal */}
      {deleteModalItem && (
        <EuiConfirmModal
          title="Remove from Whitelist"
          onCancel={() => setDeleteModalItem(null)}
          onConfirm={() => handleDeleteWhitelist(deleteModalItem.id)}
          cancelButtonText="Cancel"
          confirmButtonText="Remove"
          buttonColor="danger"
        >
          <p>
            Are you sure you want to remove <strong>{deleteModalItem.ip_address}</strong> from the whitelist?
          </p>
          <p style={{ color: '#dc2626', marginTop: '8px' }}>
            This IP will be subject to Active Response blocks if it triggers security alerts.
          </p>
        </EuiConfirmModal>
      )}
    </>
  );
};

export default ARWhitelistManager;
