import React from 'react';
import { EuiBadge, EuiToolTip, EuiText } from '@elastic/eui';
import { AlertTriangle, Shield, AlertCircle, Info } from 'lucide-react';

/**
 * Threat Score Badge Component
 *
 * Displays threat score (0-100) with color-coded risk level
 * Based on industry-standard risk classification
 */
const ThreatScoreBadge = ({ score, riskLevel, size = 's', showBreakdown = false, breakdown = {} }) => {
  // Risk level configuration
  const getRiskConfig = (risk) => {
    const configs = {
      Critical: {
        color: '#DC143C',  // Crimson
        icon: AlertTriangle,
        badge: 'danger',
        bgColor: 'rgba(220, 20, 60, 0.1)'
      },
      High: {
        color: '#FF6B6B',  // Red
        icon: AlertCircle,
        badge: 'danger',
        bgColor: 'rgba(255, 107, 107, 0.1)'
      },
      Medium: {
        color: '#FFA500',  // Orange
        icon: Shield,
        badge: 'warning',
        bgColor: 'rgba(255, 165, 0, 0.1)'
      },
      Low: {
        color: '#4CAF50',  // Green
        icon: Info,
        badge: 'success',
        bgColor: 'rgba(76, 175, 80, 0.1)'
      }
    };

    return configs[risk] || configs.Low;
  };

  const config = getRiskConfig(riskLevel);
  const Icon = config.icon;

  // Tooltip content with score breakdown
  const tooltipContent = (
    <div style={{ minWidth: '200px' }}>
      <EuiText size="xs">
        <div style={{ marginBottom: '8px' }}>
          <strong style={{ fontSize: '14px' }}>Threat Score: {score}/100</strong>
        </div>
        <div style={{ marginBottom: '8px', color: '#94a3b8' }}>
          Risk Level: <strong style={{ color: config.color }}>{riskLevel}</strong>
        </div>

        {showBreakdown && breakdown && (
          <>
            <hr style={{ margin: '8px 0', border: 'none', borderTop: '1px solid #334155' }} />
            <div style={{ fontSize: '11px', color: '#94a3b8' }}>
              <div><strong>Score Breakdown:</strong></div>
              <div style={{ marginTop: '4px' }}>
                Frequency: {breakdown.frequency || 0}/40
              </div>
              <div>
                Severity: {breakdown.severity || 0}/30
              </div>
              <div>
                Reputation: {breakdown.reputation || 0}/20
              </div>
              <div>
                Velocity: {breakdown.velocity || 0}/10
              </div>
            </div>
          </>
        )}

        <hr style={{ margin: '8px 0', border: 'none', borderTop: '1px solid #334155' }} />

        <div style={{ fontSize: '10px', color: '#64748b' }}>
          <div><strong>Risk Classification:</strong></div>
          <div>Critical: ≥80 | High: 60-79</div>
          <div>Medium: 40-59 | Low: &lt;40</div>
        </div>
      </EuiText>
    </div>
  );

  return (
    <EuiToolTip content={tooltipContent} position="top">
      <div
        style={{
          display: 'inline-flex',
          alignItems: 'center',
          gap: '6px',
          padding: size === 'l' ? '8px 14px' : '4px 10px',
          borderRadius: '6px',
          backgroundColor: config.bgColor,
          border: `1px solid ${config.color}`,
          cursor: 'help'
        }}
      >
        <Icon size={size === 'l' ? 18 : 14} color={config.color} />
        <span
          style={{
            color: config.color,
            fontWeight: 'bold',
            fontSize: size === 'l' ? '16px' : '13px'
          }}
        >
          {riskLevel} | {score}/100
        </span>
      </div>
    </EuiToolTip>
  );
};

/**
 * Simple Risk Badge (without score)
 */
export const RiskBadge = ({ riskLevel }) => {
  const getColor = () => {
    if (riskLevel === 'Critical') return 'danger';
    if (riskLevel === 'High') return 'danger';
    if (riskLevel === 'Medium') return 'warning';
    return 'success';
  };

  return (
    <EuiBadge color={getColor()}>
      {riskLevel}
    </EuiBadge>
  );
};

export default ThreatScoreBadge;
