import React, { Suspense, useState, useEffect } from 'react';
import { EuiText, EuiCallOut, EuiSpacer } from '@elastic/eui';

// Lazy load Three.js components to handle compatibility
let Canvas, OrbitControls, Grid, Text, PerspectiveCamera, AttackTimeline3DScene;
let threeJsAvailable = false;

try {
  const fiber = require('@react-three/fiber');
  const drei = require('@react-three/drei');
  Canvas = fiber.Canvas;
  OrbitControls = drei.OrbitControls;
  Grid = drei.Grid;
  Text = drei.Text;
  PerspectiveCamera = drei.PerspectiveCamera;
  AttackTimeline3DScene = require('./AttackTimeline3DScene').default;
  threeJsAvailable = true;
} catch (error) {
  console.warn('Three.js not available, falling back to 2D view:', error);
  threeJsAvailable = false;
}

/**
 * AttackTimeline3D - 3D visualization of attack timeline events
 *
 * Uses Three.js to render attack events in 3D space:
 * - X-axis: Time (chronological)
 * - Y-axis: Agents/Targets
 * - Z-axis: Severity/Attack Stage
 */
const AttackTimeline3D = ({ timeline, attackChain, ipAddress }) => {
  // Check if Three.js is available
  if (!threeJsAvailable) {
    return (
      <div style={{ padding: '20px' }}>
        <EuiCallOut
          title="3D Visualization Not Available"
          color="warning"
          iconType="alert"
        >
          <p>
            The 3D visualization requires React 19 or newer. Your current React version (18.3.1) is not compatible.
          </p>
          <EuiSpacer size="s" />
          <p>
            <strong>To enable 3D visualization:</strong>
          </p>
          <ul>
            <li>Upgrade React to version 19+, or</li>
            <li>Use the 2D Timeline view (toggle above)</li>
          </ul>
        </EuiCallOut>
      </div>
    );
  }

  if (!timeline || timeline.length === 0) {
    return (
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', height: '500px' }}>
        <EuiText color="subdued">No timeline data available</EuiText>
      </div>
    );
  }

  return (
    <div style={{ height: '600px', width: '100%', backgroundColor: '#1a1a1a', borderRadius: '8px' }}>
      <Canvas>
        <PerspectiveCamera makeDefault position={[15, 10, 15]} fov={60} />

        {/* Lighting */}
        <ambientLight intensity={0.4} />
        <pointLight position={[10, 10, 10]} intensity={0.6} />
        <pointLight position={[-10, -10, -10]} intensity={0.3} />

        {/* Grid */}
        <Grid
          args={[20, 20]}
          cellSize={1}
          cellThickness={0.5}
          cellColor="#333333"
          sectionSize={5}
          sectionThickness={1}
          sectionColor="#555555"
          fadeDistance={30}
          fadeStrength={1}
          followCamera={false}
          infiniteGrid={false}
        />

        {/* Axis Labels */}
        <Suspense fallback={null}>
          <Text position={[12, -1, 0]} fontSize={0.5} color="#3b82f6">
            Time →
          </Text>
          <Text position={[-1, 5, 0]} fontSize={0.5} color="#10b981">
            Agents
          </Text>
          <Text position={[0, 0, 6]} fontSize={0.5} color="#f59e0b">
            Severity
          </Text>
        </Suspense>

        {/* 3D Scene with Events */}
        <Suspense fallback={null}>
          <AttackTimeline3DScene
            timeline={timeline}
            attackChain={attackChain}
            ipAddress={ipAddress}
          />
        </Suspense>

        {/* Camera Controls */}
        <OrbitControls
          enableDamping
          dampingFactor={0.05}
          rotateSpeed={0.5}
          zoomSpeed={0.8}
          panSpeed={0.5}
          minDistance={5}
          maxDistance={50}
        />
      </Canvas>

      {/* Instructions Overlay */}
      <div style={{
        position: 'absolute',
        bottom: '20px',
        left: '20px',
        backgroundColor: 'rgba(0,0,0,0.7)',
        color: 'white',
        padding: '12px',
        borderRadius: '4px',
        fontSize: '12px',
        zIndex: 10
      }}>
        <div>🖱️ <strong>Left Click + Drag:</strong> Rotate</div>
        <div>🔍 <strong>Scroll:</strong> Zoom</div>
        <div>🤚 <strong>Right Click + Drag:</strong> Pan</div>
      </div>
    </div>
  );
};

export default AttackTimeline3D;
