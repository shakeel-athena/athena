import React, { useState, useEffect } from 'react';
import {
  EuiPage,
  EuiPageBody,
  EuiPageHeader,
  EuiPageHeaderSection,
  EuiTitle,
  EuiFlexGroup,
  EuiFlexItem,
  EuiPanel,
  EuiSpacer,
  EuiButton,
  EuiButtonIcon,
  EuiHealth,
  EuiLoadingSpinner,
  EuiBadge,
  EuiIcon,
  EuiText,
} from '@elastic/eui';
import { motion } from 'framer-motion';
import { apiRequest } from '../../services/apiClient';
import toast from 'react-hot-toast';

// Import advanced components
import SOCMetricsDashboard from './components/Advanced/SOCMetricsDashboard';
import InteractiveTimeline2D from './components/Advanced/InteractiveTimeline2D';
import ThreatIntelligencePanel from './components/Advanced/ThreatIntelligencePanel';
import MITREKillChain from './components/Advanced/MITREKillChain';
import AdvancedFilterPanel from './components/Advanced/AdvancedFilterPanel';
import LiveAlertStream from './components/Advanced/LiveAlertStream';
import PatternRecognition from './components/Advanced/PatternRecognition';
import EnhancedBlockTable from './components/Advanced/EnhancedBlockTable';

// API Base URL - MUST be configured via environment variable for production
const RESPONSE_BACKEND_URL = process.env.REACT_APP_API_BASE_URL || process.env.REACT_APP_RESPONSE_BACKEND_URL;

// Configuration constants
const DEFAULT_REFRESH_INTERVAL = 5000; // 5 seconds
const DEFAULT_HISTORY_LIMIT = 100;
const DEFAULT_FILTERS = {
  timeRange: '24h',
  severity: ['critical', 'high', 'medium'],
  eventTypes: ['port_scan', 'ssh_brute_force', 'web_attack', 'ar_block'],
  minThreatScore: 0,
};

const ActiveResponseAdvanced = () => {
  // State management
  const [stats, setStats] = useState(null);
  const [activeBlocks, setActiveBlocks] = useState([]);
  const [blockHistory, setBlockHistory] = useState([]);
  const [aggregatedIncidents, setAggregatedIncidents] = useState([]);
  const [selectedIP, setSelectedIP] = useState(null);
  const [loading, setLoading] = useState(true);
  const [refreshInterval, setRefreshInterval] = useState(DEFAULT_REFRESH_INTERVAL);
  const [filters, setFilters] = useState(DEFAULT_FILTERS);
  const [viewMode, setViewMode] = useState('timeline'); // 'timeline' | 'table' | 'killchain'

  // Fetch data functions
  const fetchStats = async () => {
    try {
      const url = `${RESPONSE_BACKEND_URL}/api/active-response/stats`;
      const data = await apiRequest(url, { method: 'GET' });
      setStats(data || null);
    } catch (error) {
      console.error('Error fetching stats:', error);
      toast.error('Failed to fetch Active Response statistics');
    }
  };

  const fetchActiveBlocks = async () => {
    try {
      const url = `${RESPONSE_BACKEND_URL}/api/active-response/blocks/active`;
      const data = await apiRequest(url, { method: 'GET' });
      setActiveBlocks(data?.active_blocks || []);
    } catch (error) {
      console.error('Error fetching active blocks:', error);
      toast.error('Failed to fetch active blocks');
    }
  };

  const fetchBlockHistory = async () => {
    try {
      const url = `${RESPONSE_BACKEND_URL}/api/active-response/blocks/history?limit=${DEFAULT_HISTORY_LIMIT}`;
      const data = await apiRequest(url, { method: 'GET' });
      setBlockHistory(data?.blocks || []);
    } catch (error) {
      console.error('Error fetching block history:', error);
      toast.error('Failed to fetch block history');
    }
  };

  const fetchAggregatedIncidents = async () => {
    try {
      const url = `${RESPONSE_BACKEND_URL}/api/active-response/aggregated-incidents`;
      const data = await apiRequest(url, { method: 'GET' });
      setAggregatedIncidents(data?.incidents || []);
    } catch (error) {
      console.error('Error fetching aggregated incidents:', error);
      toast.error('Failed to fetch aggregated incidents');
    }
  };

  const fetchAllData = async () => {
    setLoading(true);
    await Promise.all([
      fetchStats(),
      fetchActiveBlocks(),
      fetchBlockHistory(),
      fetchAggregatedIncidents(),
    ]);
    setLoading(false);
  };

  // Initial load and auto-refresh
  useEffect(() => {
    fetchAllData();
    const interval = setInterval(fetchAllData, refreshInterval);
    return () => clearInterval(interval);
  }, [refreshInterval]);

  // Handle IP selection for detailed view
  const handleIPSelect = (ip) => {
    setSelectedIP(ip);
  };

  if (loading && !stats) {
    return (
      <EuiPage>
        <EuiPageBody style={{ display: 'flex', justifyContent: 'center', alignItems: 'center', height: '80vh' }}>
          <EuiLoadingSpinner size="xl" />
          <EuiSpacer size="m" />
          <EuiText>Loading SOC Dashboard...</EuiText>
        </EuiPageBody>
      </EuiPage>
    );
  }

  return (
    <div className="athena-gradient-bg" style={{ minHeight: '100vh', padding: '0' }}>
      {/* Header */}
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
      >
        <EuiPageHeader className="athena-page-header">
          <EuiPageHeaderSection>
            <EuiFlexGroup alignItems="center" gutterSize="m">
              <EuiFlexItem grow={false}>
                <EuiIcon type="securityApp" size="xl" color="primary" />
              </EuiFlexItem>
              <EuiFlexItem grow={false}>
                <EuiTitle size="l">
                  <h1>ATHENA SOC - Active Response</h1>
                </EuiTitle>
              </EuiFlexItem>
              <EuiFlexItem grow={false}>
                <EuiBadge color="success">
                  <EuiHealth color="success" style={{ display: 'inline' }}>
                    OPERATIONAL
                  </EuiHealth>
                </EuiBadge>
              </EuiFlexItem>
            </EuiFlexGroup>
          </EuiPageHeaderSection>
          <EuiPageHeaderSection>
            <EuiFlexGroup gutterSize="s">
              <EuiFlexItem grow={false}>
                <EuiText size="xs" color="subdued">
                  Last Updated: {new Date().toLocaleTimeString()}
                </EuiText>
              </EuiFlexItem>
              <EuiFlexItem grow={false}>
                <EuiButtonIcon
                  iconType="refresh"
                  onClick={fetchAllData}
                  aria-label="Refresh"
                  color="primary"
                />
              </EuiFlexItem>
              <EuiFlexItem grow={false}>
                <EuiButtonIcon
                  iconType="gear"
                  aria-label="Settings"
                  color="primary"
                />
              </EuiFlexItem>
            </EuiFlexGroup>
          </EuiPageHeaderSection>
        </EuiPageHeader>
      </motion.div>

      {/* Top Metrics Bar */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.2, duration: 0.5 }}
      >
        <SOCMetricsDashboard
          stats={stats}
          activeBlocks={activeBlocks}
          aggregatedIncidents={aggregatedIncidents}
        />
      </motion.div>

      <EuiSpacer size="l" />

      {/* Main Dashboard - Three Column Layout */}
      <EuiPageBody style={{ padding: '0 24px' }}>
        <EuiFlexGroup gutterSize="l" style={{ height: 'calc(100vh - 250px)' }}>

          {/* LEFT SIDEBAR - Filters & Quick Actions */}
          <EuiFlexItem grow={2} style={{ maxWidth: '280px' }}>
            <motion.div
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.3, duration: 0.5 }}
            >
              <EuiPanel
                className="athena-panel-primary"
                style={{ height: '100%', overflow: 'auto' }}
              >
                <AdvancedFilterPanel
                  filters={filters}
                  onFilterChange={setFilters}
                  stats={stats}
                />

                <EuiSpacer size="l" />

                <LiveAlertStream
                  activeBlocks={activeBlocks}
                  onIPSelect={handleIPSelect}
                />
              </EuiPanel>
            </motion.div>
          </EuiFlexItem>

          {/* CENTER - Main Visualization Area */}
          <EuiFlexItem grow={7}>
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.4, duration: 0.5 }}
            >
              <EuiPanel
                className="athena-panel-primary"
                style={{ height: '100%', display: 'flex', flexDirection: 'column' }}
              >
                {/* View Mode Selector */}
                <EuiFlexGroup gutterSize="s" justifyContent="spaceBetween" style={{ marginBottom: '16px' }}>
                  <EuiFlexItem>
                    <EuiFlexGroup gutterSize="s">
                      <EuiFlexItem grow={false}>
                        <EuiButton
                          size="s"
                          fill={viewMode === 'timeline'}
                          onClick={() => setViewMode('timeline')}
                          color={viewMode === 'timeline' ? 'primary' : 'text'}
                          iconType="timeline"
                        >
                          Timeline
                        </EuiButton>
                      </EuiFlexItem>
                      <EuiFlexItem grow={false}>
                        <EuiButton
                          size="s"
                          fill={viewMode === 'table'}
                          onClick={() => setViewMode('table')}
                          color={viewMode === 'table' ? 'primary' : 'text'}
                          iconType="tableDensityNormal"
                        >
                          Table
                        </EuiButton>
                      </EuiFlexItem>
                      <EuiFlexItem grow={false}>
                        <EuiButton
                          size="s"
                          fill={viewMode === 'killchain'}
                          onClick={() => setViewMode('killchain')}
                          color={viewMode === 'killchain' ? 'primary' : 'text'}
                          iconType="visTagCloud"
                        >
                          Kill Chain
                        </EuiButton>
                      </EuiFlexItem>
                    </EuiFlexGroup>
                  </EuiFlexItem>
                  <EuiFlexItem grow={false}>
                    <EuiButton size="s" iconType="exportAction">
                      Export
                    </EuiButton>
                  </EuiFlexItem>
                </EuiFlexGroup>

                {/* Main Content Area */}
                <div style={{ flex: 1, overflow: 'auto' }}>
                  {viewMode === 'timeline' && (
                    <InteractiveTimeline2D
                      incidents={aggregatedIncidents}
                      blockHistory={blockHistory}
                      selectedIP={selectedIP}
                      onIPSelect={handleIPSelect}
                      filters={filters}
                    />
                  )}

                  {viewMode === 'table' && (
                    <EnhancedBlockTable
                      blocks={blockHistory}
                      onIPSelect={handleIPSelect}
                      selectedIP={selectedIP}
                    />
                  )}

                  {viewMode === 'killchain' && selectedIP && (
                    <MITREKillChain
                      ipAddress={selectedIP}
                    />
                  )}

                  {viewMode === 'killchain' && !selectedIP && (
                    <div style={{
                      display: 'flex',
                      justifyContent: 'center',
                      alignItems: 'center',
                      height: '100%'
                    }}>
                      <EuiText color="subdued">
                        <p>Select an IP address to view MITRE ATT&CK kill chain</p>
                      </EuiText>
                    </div>
                  )}
                </div>

                {/* Pattern Recognition Section */}
                {viewMode === 'timeline' && (
                  <>
                    <EuiSpacer size="l" />
                    <PatternRecognition
                      blockHistory={blockHistory}
                      aggregatedIncidents={aggregatedIncidents}
                    />
                  </>
                )}
              </EuiPanel>
            </motion.div>
          </EuiFlexItem>

          {/* RIGHT SIDEBAR - Threat Intelligence */}
          <EuiFlexItem grow={3} style={{ maxWidth: '380px' }}>
            <motion.div
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.5, duration: 0.5 }}
            >
              <ThreatIntelligencePanel
                selectedIP={selectedIP}
                onIPSelect={handleIPSelect}
                topBlockedIPs={stats?.top_blocked_ips || []}
                activeBlocks={activeBlocks}
              />
            </motion.div>
          </EuiFlexItem>
        </EuiFlexGroup>
      </EuiPageBody>
    </div>
  );
};

export default ActiveResponseAdvanced;
