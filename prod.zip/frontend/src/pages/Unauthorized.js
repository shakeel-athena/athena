import React from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { ShieldAlert, Home, ArrowLeft } from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';

const Unauthorized = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const { user, roles, logout } = useAuth();

  const from = location.state?.from?.pathname || '/';

  return (
    <div className="min-h-screen bg-gray-900 flex items-center justify-center px-4">
      <div className="max-w-2xl w-full">
        <div className="bg-gray-800 rounded-lg shadow-xl border border-gray-700 p-8">
          {/* Icon */}
          <div className="flex justify-center mb-6">
            <div className="bg-red-500/10 p-4 rounded-full">
              <ShieldAlert className="h-16 w-16 text-red-500" />
            </div>
          </div>

          {/* Title */}
          <h1 className="text-3xl font-bold text-center text-white mb-4">
            Access Denied
          </h1>

          {/* Message */}
          <div className="text-center mb-8">
            <p className="text-gray-300 mb-4">
              You don't have permission to access this resource.
            </p>
            <p className="text-gray-400 text-sm">
              The page you're trying to access requires specific roles that your account doesn't have.
            </p>
          </div>

          {/* User Info */}
          {user && (
            <div className="bg-gray-900 rounded-lg p-4 mb-6 border border-gray-700">
              <h2 className="text-sm font-semibold text-gray-400 mb-3">
                Current User Information
              </h2>
              <div className="space-y-2 text-sm">
                <div className="flex justify-between">
                  <span className="text-gray-400">Username:</span>
                  <span className="text-white font-medium">{user.username}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-400">Email:</span>
                  <span className="text-white font-medium">{user.email}</span>
                </div>
                <div className="flex justify-between items-start">
                  <span className="text-gray-400">Roles:</span>
                  <div className="flex flex-wrap gap-2 justify-end max-w-xs">
                    {roles.length > 0 ? (
                      roles.map(role => (
                        <span
                          key={role}
                          className="px-2 py-1 bg-blue-500/20 text-blue-300 text-xs rounded-full"
                        >
                          {role}
                        </span>
                      ))
                    ) : (
                      <span className="text-gray-500 text-xs">No roles assigned</span>
                    )}
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Attempted Path */}
          {from !== '/' && (
            <div className="bg-gray-900 rounded-lg p-4 mb-6 border border-gray-700">
              <h2 className="text-sm font-semibold text-gray-400 mb-2">
                Attempted Access
              </h2>
              <code className="text-xs text-blue-300 break-all">
                {from}
              </code>
            </div>
          )}

          {/* Actions */}
          <div className="flex flex-col sm:flex-row gap-3">
            <button
              onClick={() => navigate(-1)}
              className="flex-1 flex items-center justify-center gap-2 px-4 py-3 bg-gray-700 hover:bg-gray-600 text-white rounded-lg transition-colors"
            >
              <ArrowLeft className="h-4 w-4" />
              Go Back
            </button>
            <button
              onClick={() => navigate('/')}
              className="flex-1 flex items-center justify-center gap-2 px-4 py-3 bg-blue-600 hover:bg-blue-700 text-white rounded-lg transition-colors"
            >
              <Home className="h-4 w-4" />
              Go to Dashboard
            </button>
          </div>

          {/* Logout Option */}
          <div className="mt-6 pt-6 border-t border-gray-700 text-center">
            <p className="text-gray-400 text-sm mb-3">
              Need access? Contact your system administrator or try logging in with a different account.
            </p>
            <button
              onClick={logout}
              className="text-red-400 hover:text-red-300 text-sm font-medium transition-colors"
            >
              Sign out
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Unauthorized;
