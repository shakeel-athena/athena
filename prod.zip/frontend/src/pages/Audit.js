import React, { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { 
  ClipboardList, 
  Filter, 
  Search, 
  Eye, 
  Download,
  Clock,
  User,
  Activity
} from 'lucide-react';
import { formatDistanceToNow } from 'date-fns';
import { fetchAuditTrail } from '../services/api';

const Audit = () => {
  const [filters, setFilters] = useState({
    event_type: '',
    user: '',
    timeRange: '24'
  });
  const [selectedEntry, setSelectedEntry] = useState(null);

  const { data, isLoading } = useQuery(
    ['auditTrail', filters],
    () => fetchAuditTrail(filters),
    { refetchInterval: 60000 }
  );

  const getEventTypeIcon = (eventType) => {
    const icons = {
      alert_processed: Activity,
      action_executed: Activity,
      action_failed: Activity,
      policy_updated: ClipboardList,
      manual_action: User,
      system_health: Activity,
    };
    const Icon = icons[eventType] || Activity;
    return <Icon className="w-4 h-4" />;
  };

  const getEventTypeColor = (eventType) => {
    const colors = {
      alert_processed: 'text-accent-blue',
      action_executed: 'text-status-success',
      action_failed: 'text-status-error',
      policy_updated: 'text-accent-purple',
      manual_action: 'text-threat-medium',
      system_health: 'text-accent-green',
    };
    return colors[eventType] || 'text-dark-400';
  };

  const getRiskLevelBadge = (riskLevel) => {
    const badges = {
      low: 'badge-low',
      medium: 'badge-medium',
      high: 'badge-high',
      critical: 'badge-critical',
    };
    return badges[riskLevel] || 'badge-info';
  };

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-white">Audit Trail</h1>
          <p className="text-dark-400 mt-1">Complete audit log of system activities and decisions</p>
        </div>
        <div className="flex items-center space-x-3">
          <button className="btn-secondary flex items-center space-x-2">
            <Download className="w-4 h-4" />
            <span>Export</span>
          </button>
        </div>
      </div>

      {/* Filters */}
      <div className="card">
        <div className="card-content">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {/* Event Type Filter */}
            <select
              className="input"
              value={filters.event_type}
              onChange={(e) => setFilters({ ...filters, event_type: e.target.value })}
            >
              <option value="">All Event Types</option>
              <option value="alert_processed">Alert Processed</option>
              <option value="action_executed">Action Executed</option>
              <option value="action_failed">Action Failed</option>
              <option value="policy_updated">Policy Updated</option>
              <option value="manual_action">Manual Action</option>
              <option value="system_health">System Health</option>
            </select>

            {/* User Filter */}
            <select
              className="input"
              value={filters.user}
              onChange={(e) => setFilters({ ...filters, user: e.target.value })}
            >
              <option value="">All Users</option>
              <option value="system">System</option>
              <option value="admin@company.com">Admin</option>
              <option value="soc-analyst@company.com">SOC Analyst</option>
              <option value="security-manager@company.com">Security Manager</option>
            </select>

            {/* Time Range */}
            <select
              className="input"
              value={filters.timeRange}
              onChange={(e) => setFilters({ ...filters, timeRange: e.target.value })}
            >
              <option value="1">Last Hour</option>
              <option value="24">Last 24 Hours</option>
              <option value="168">Last Week</option>
              <option value="720">Last Month</option>
            </select>
          </div>
        </div>
      </div>

      {/* Audit Trail */}
      <div className="card">
        <div className="card-header">
          <h3 className="text-lg font-semibold text-white flex items-center">
            <ClipboardList className="w-5 h-5 mr-2" />
            Audit Entries
            {data && (
              <span className="ml-2 text-sm text-dark-400">
                ({data.total} total)
              </span>
            )}
          </h3>
        </div>
        
        <div className="divide-y divide-dark-700">
          {isLoading ? (
            <div className="p-8 flex items-center justify-center">
              <div className="spinner w-6 h-6"></div>
              <span className="ml-2 text-dark-400">Loading audit trail...</span>
            </div>
          ) : data?.entries?.length === 0 ? (
            <div className="p-8 text-center text-dark-400">
              <ClipboardList className="w-12 h-12 mx-auto mb-4 opacity-50" />
              <h3 className="text-lg font-medium text-white mb-2">No audit entries found</h3>
              <p>Try adjusting your filters or check back later.</p>
            </div>
          ) : (
            data?.entries?.map((entry) => (
              <div key={entry.id} className="p-4 hover:bg-dark-800/50 transition-colors duration-150">
                <div className="flex items-start space-x-4">
                  <div className={`p-2 rounded-lg bg-dark-800 ${getEventTypeColor(entry.event_type)}`}>
                    {getEventTypeIcon(entry.event_type)}
                  </div>
                  
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center space-x-2 mb-1">
                      <h4 className="text-sm font-medium text-white capitalize">
                        {entry.event_type.replace(/_/g, ' ')}
                      </h4>
                      {entry.risk_level && (
                        <span className={`badge ${getRiskLevelBadge(entry.risk_level)}`}>
                          {entry.risk_level.toUpperCase()}
                        </span>
                      )}
                      {entry.dry_run && (
                        <span className="badge-info">DRY RUN</span>
                      )}
                    </div>
                    
                    <div className="flex items-center space-x-4 text-xs text-dark-400 mb-2">
                      <span className="flex items-center">
                        <User className="w-3 h-3 mr-1" />
                        {entry.user}
                      </span>
                      <span className="flex items-center">
                        <Clock className="w-3 h-3 mr-1" />
                        {formatDistanceToNow(new Date(entry.timestamp), { addSuffix: true })}
                      </span>
                      <span>{entry.source}</span>
                    </div>
                    
                    {/* Event-specific details */}
                    <div className="text-sm text-dark-300">
                      {entry.event_type === 'alert_processed' && entry.details && (
                        <div>
                          Alert from {entry.details.src_ip} → {entry.details.dest_ip} 
                          ({entry.details.normalized_type?.replace(/_/g, ' ')})
                          {entry.actions_generated && (
                            <span className="ml-2 text-status-success">
                              → {entry.actions_generated} actions generated
                            </span>
                          )}
                        </div>
                      )}
                      
                      {entry.event_type === 'action_executed' && entry.details && (
                        <div>
                          {entry.details.provider} {entry.details.action_name.replace(/_/g, ' ')}
                          {entry.details.target_ip && ` on ${entry.details.target_ip}`}
                          {entry.details.target_route && ` for ${entry.details.target_route}`}
                          <span className={`ml-2 ${
                            entry.details.execution_status === 'success' 
                              ? 'text-status-success' 
                              : 'text-status-error'
                          }`}>
                            ({entry.details.execution_status})
                          </span>
                        </div>
                      )}
                      
                      {entry.event_type === 'policy_updated' && entry.details && (
                        <div>
                          Policy version {entry.details.policy_version} updated
                          {entry.details.changes && entry.details.changes.length > 0 && (
                            <span className="ml-2">
                              ({entry.details.changes.length} changes)
                            </span>
                          )}
                        </div>
                      )}
                      
                      {entry.event_type === 'manual_action' && entry.details && (
                        <div>
                          {entry.details.action_type.replace(/_/g, ' ')} 
                          {entry.details.target_ip && ` for ${entry.details.target_ip}`}
                          {entry.details.reason && (
                            <div className="text-xs text-dark-400 mt-1">
                              Reason: {entry.details.reason}
                            </div>
                          )}
                        </div>
                      )}
                      
                      {entry.event_type === 'system_health' && entry.details && (
                        <div>
                          {entry.details.component} status: {entry.details.status}
                          {entry.details.metrics && (
                            <span className="ml-2 text-dark-400">
                              ({entry.details.metrics.alerts_processed_last_hour} alerts/hr)
                            </span>
                          )}
                        </div>
                      )}
                    </div>
                    
                    {entry.escalation_required && (
                      <div className="mt-2 text-xs text-threat-critical">
                        ⚠ Escalation required
                      </div>
                    )}
                  </div>
                  
                  <div className="flex-shrink-0">
                    <button
                      onClick={() => setSelectedEntry(entry)}
                      className="p-1 text-dark-400 hover:text-white transition-colors duration-150"
                      title="View details"
                    >
                      <Eye className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              </div>
            ))
          )}
        </div>
      </div>

      {/* Entry Detail Modal */}
      {selectedEntry && (
        <div className="fixed inset-0 z-50 overflow-y-auto">
          <div className="flex items-center justify-center min-h-screen px-4 pt-4 pb-20 text-center sm:block sm:p-0">
            <div className="fixed inset-0 transition-opacity bg-black bg-opacity-75" onClick={() => setSelectedEntry(null)}></div>
            
            <div className="inline-block w-full max-w-3xl p-6 my-8 overflow-hidden text-left align-middle transition-all transform bg-dark-800 border border-dark-600 shadow-xl rounded-lg">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-lg font-medium text-white">
                  Audit Entry Details
                </h3>
                <button
                  onClick={() => setSelectedEntry(null)}
                  className="text-dark-400 hover:text-white"
                >
                  <Eye className="w-5 h-5" />
                </button>
              </div>
              
              <div className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="text-sm text-dark-400">Event Type</label>
                    <div className="mt-1 text-white capitalize">
                      {selectedEntry.event_type.replace(/_/g, ' ')}
                    </div>
                  </div>
                  <div>
                    <label className="text-sm text-dark-400">User</label>
                    <div className="mt-1 text-white">{selectedEntry.user}</div>
                  </div>
                </div>
                
                <div>
                  <label className="text-sm text-dark-400">Timestamp</label>
                  <div className="mt-1 text-white">
                    {new Date(selectedEntry.timestamp).toLocaleString()}
                  </div>
                </div>
                
                <div>
                  <label className="text-sm text-dark-400">Details</label>
                  <div className="mt-1 bg-dark-700 rounded p-3">
                    <pre className="text-sm text-dark-300 font-mono whitespace-pre-wrap">
                      {JSON.stringify(selectedEntry.details, null, 2)}
                    </pre>
                  </div>
                </div>
                
                {selectedEntry.approval_required && (
                  <div>
                    <label className="text-sm text-dark-400">Approval</label>
                    <div className="mt-1">
                      <span className="badge-info">Approval Required</span>
                      {selectedEntry.approved_by && (
                        <span className="ml-2 text-sm text-dark-300">
                          Approved by: {selectedEntry.approved_by}
                        </span>
                      )}
                    </div>
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default Audit;
