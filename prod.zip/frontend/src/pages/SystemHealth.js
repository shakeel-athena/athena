import React, { useState, useEffect, useCallback } from 'react';
import { PieChart, Pie, Cell, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import {
  EuiPanel,
  EuiFlexGroup,
  EuiFlexItem,
  EuiText,
  EuiTitle,
  EuiBadge,
  EuiLoadingSpinner,
  EuiSpacer,
  EuiIcon,
  EuiStat,
} from '@elastic/eui';

const COLORS = {
  success: '#10b981',
  warning: '#f59e0b',
  danger: '#ef4444',
  primary: '#3b82f6',
  secondary: '#8b5cf6',
};

// API Base URL - MUST be configured via environment variable for production
const API_BASE_URL = process.env.REACT_APP_API_URL || (process.env.REACT_APP_API_BASE_URL && `${process.env.REACT_APP_API_BASE_URL}/api`);

const SystemHealth = () => {
  const [metrics, setMetrics] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [lastUpdate, setLastUpdate] = useState(null);

  const fetchSystemHealth = useCallback(async () => {
    try {
      setLoading(true);
      console.log('[SystemHealth] Fetching system health metrics...');

      const response = await fetch(`${API_BASE_URL}/system-health`);

      if (!response.ok) {
        throw new Error(`HTTP ${response.status}: ${response.statusText}`);
      }

      const result = await response.json();

      if (result.success && result.data) {
        setMetrics(result.data);
        setLastUpdate(new Date());
        setError(null);
        console.log('[SystemHealth] Metrics loaded:', result.data);
      } else {
        throw new Error(result.error || 'Failed to fetch system health');
      }
    } catch (err) {
      console.error('[SystemHealth] Error:', err);
      setError(err.message);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchSystemHealth();

    // Auto-refresh every 30 seconds
    const interval = setInterval(fetchSystemHealth, 30000);

    return () => clearInterval(interval);
  }, [fetchSystemHealth]);

  const getCpuColor = (percent) => {
    if (percent < 50) return COLORS.success;
    if (percent < 80) return COLORS.warning;
    return COLORS.danger;
  };

  const getMemoryColor = (percent) => {
    if (percent < 60) return COLORS.success;
    if (percent < 85) return COLORS.warning;
    return COLORS.danger;
  };

  const getDiskColor = (percent) => {
    if (percent < 70) return COLORS.success;
    if (percent < 90) return COLORS.warning;
    return COLORS.danger;
  };

  const formatUptime = (days) => {
    if (days < 1) {
      const hours = Math.floor(days * 24);
      return `${hours} hours`;
    }
    return `${days} days`;
  };

  const formatBytes = (gb) => {
    if (gb >= 1024) {
      return `${(gb / 1024).toFixed(2)} TB`;
    }
    return `${gb.toFixed(2)} GB`;
  };

  if (loading && !metrics) {
    return (
      <EuiFlexGroup alignItems="center" justifyContent="center" style={{ minHeight: '400px' }}>
        <EuiFlexItem grow={false}>
          <EuiLoadingSpinner size="xl" />
          <EuiSpacer size="m" />
          <EuiText>Loading system health metrics...</EuiText>
        </EuiFlexItem>
      </EuiFlexGroup>
    );
  }

  if (error && !metrics) {
    return (
      <EuiPanel color="danger">
        <EuiText color="danger">
          <h3>Error Loading System Health</h3>
          <p>{error}</p>
        </EuiText>
      </EuiPanel>
    );
  }

  const { cpu, memory, disk, network, updates, system_info, fim } = metrics || {};

  // Prepare chart data
  const cpuData = cpu?.per_cpu_percent?.map((percent, index) => ({
    name: `CPU ${index + 1}`,
    usage: Math.round(percent)
  })) || [];

  const memoryData = [
    { name: 'Used', value: memory?.used_gb || 0, color: COLORS.primary },
    { name: 'Available', value: memory?.available_gb || 0, color: COLORS.success }
  ];

  return (
    <div style={{ padding: '24px', backgroundColor: '#1a1b1c', minHeight: '100vh' }}>
      <EuiPanel paddingSize="l" hasShadow={false}>
        {/* Header */}
        <EuiFlexGroup alignItems="center" justifyContent="spaceBetween">
          <EuiFlexItem>
            <EuiFlexGroup alignItems="center" gutterSize="s">
              <EuiFlexItem grow={false}>
                <EuiIcon type="compute" size="xxl" color="#3b82f6" />
              </EuiFlexItem>
              <EuiFlexItem>
                <EuiTitle size="l">
                  <h1>System Analytics</h1>
                </EuiTitle>
                <EuiText size="s" color="subdued">
                  Real-time monitoring of {system_info?.hostname || 'Local Machine'}
                </EuiText>
              </EuiFlexItem>
            </EuiFlexGroup>
          </EuiFlexItem>
          <EuiFlexItem grow={false}>
            <EuiFlexGroup direction="column" gutterSize="xs" alignItems="flexEnd">
              <EuiFlexItem>
                <EuiBadge color="success">Live</EuiBadge>
              </EuiFlexItem>
              {lastUpdate && (
                <EuiFlexItem>
                  <EuiText size="xs" color="subdued">
                    Updated: {lastUpdate.toLocaleTimeString()}
                  </EuiText>
                </EuiFlexItem>
              )}
            </EuiFlexGroup>
          </EuiFlexItem>
        </EuiFlexGroup>

        <EuiSpacer size="l" />

        {/* System Info Cards */}
        <EuiFlexGroup gutterSize="l" wrap>
          <EuiFlexItem style={{ minWidth: '250px' }}>
            <EuiPanel color="subdued" paddingSize="m" hasBorder>
              <EuiStat
                title={system_info?.platform || 'N/A'}
                description="Operating System"
                titleSize="s"
                textAlign="center"
              >
                <EuiIcon type="desktop" size="m" color="#3b82f6" />
              </EuiStat>
            </EuiPanel>
          </EuiFlexItem>

          <EuiFlexItem style={{ minWidth: '250px' }}>
            <EuiPanel color="subdued" paddingSize="m" hasBorder>
              <EuiStat
                title={formatUptime(system_info?.uptime_days || 0)}
                description="System Uptime"
                titleSize="s"
                textAlign="center"
              >
                <EuiIcon type="clock" size="m" color="#10b981" />
              </EuiStat>
            </EuiPanel>
          </EuiFlexItem>

          <EuiFlexItem style={{ minWidth: '250px' }}>
            <EuiPanel color="subdued" paddingSize="m" hasBorder>
              <EuiStat
                title={updates?.count || 0}
                description="Pending OS Updates"
                titleSize="s"
                titleColor={updates?.count > 0 ? 'warning' : 'success'}
                textAlign="center"
              >
                <EuiIcon type="package" size="m" color={updates?.count > 0 ? '#f59e0b' : '#10b981'} />
              </EuiStat>
            </EuiPanel>
          </EuiFlexItem>
        </EuiFlexGroup>

        <EuiSpacer size="l" />

        {/* Disk Storage Section */}
        <EuiPanel color="subdued" paddingSize="l" hasBorder>
          <EuiFlexGroup alignItems="center" gutterSize="s">
            <EuiFlexItem grow={false}>
              <EuiIcon type="storage" size="m" color="#8b5cf6" />
            </EuiFlexItem>
            <EuiFlexItem>
              <EuiTitle size="s"><h3>Disk Storage</h3></EuiTitle>
            </EuiFlexItem>
          </EuiFlexGroup>
          <EuiSpacer size="m" />

          {(() => {
            const totalUsed = disk?.partitions?.reduce((sum, p) => sum + p.used_gb, 0) || 0;
            const totalCapacity = disk?.partitions?.reduce((sum, p) => sum + p.total_gb, 0) || 0;
            const totalFree = totalCapacity - totalUsed;
            const overallPercent = totalCapacity > 0 ? (totalUsed / totalCapacity) * 100 : 0;

            const overallDiskData = [
              { name: 'Used', value: totalUsed, color: getDiskColor(overallPercent) },
              { name: 'Free', value: totalFree, color: '#10b981' }
            ];

            return (
              <EuiFlexGroup alignItems="center" justifyContent="center">
                <EuiFlexItem grow={false}>
                  <div style={{ position: 'relative' }}>
                    <ResponsiveContainer width={300} height={300}>
                      <PieChart>
                        <Pie
                          data={overallDiskData}
                          cx="50%"
                          cy="50%"
                          innerRadius={90}
                          outerRadius={130}
                          paddingAngle={2}
                          dataKey="value"
                        >
                          {overallDiskData.map((entry, index) => (
                            <Cell key={`cell-${index}`} fill={entry.color} />
                          ))}
                        </Pie>
                        <Tooltip
                          formatter={(value) => [`${formatBytes(value)}`, '']}
                          contentStyle={{ backgroundColor: '#1f2937', border: '1px solid #374151' }}
                        />
                      </PieChart>
                    </ResponsiveContainer>

                    <div style={{
                      position: 'absolute',
                      top: '50%',
                      left: '50%',
                      transform: 'translate(-50%, -50%)',
                      textAlign: 'center',
                      pointerEvents: 'none'
                    }}>
                      <h2 style={{ fontSize: '42px', color: getDiskColor(overallPercent), margin: 0 }}>
                        {overallPercent.toFixed(1)}%
                      </h2>
                      <EuiText size="s" color="subdued">Used</EuiText>
                      <EuiText size="xs" color="subdued">
                        {disk?.partitions?.length || 0} Partition{disk?.partitions?.length !== 1 ? 's' : ''}
                      </EuiText>
                    </div>
                  </div>
                </EuiFlexItem>
              </EuiFlexGroup>
            );
          })()}

          <EuiSpacer size="m" />
          <EuiFlexGroup justifyContent="spaceAround">
            <EuiFlexItem>
              <EuiText textAlign="center">
                <strong style={{
                  fontSize: '24px', color: getDiskColor(
                    disk?.partitions ? ((disk.partitions.reduce((sum, p) => sum + p.used_gb, 0) /
                      disk.partitions.reduce((sum, p) => sum + p.total_gb, 0)) * 100) : 0
                  )
                }}>
                  {formatBytes(disk?.partitions?.reduce((sum, p) => sum + p.used_gb, 0) || 0)}
                </strong>
                <br />
                <EuiText size="s" color="subdued">Used</EuiText>
              </EuiText>
            </EuiFlexItem>
            <EuiFlexItem>
              <EuiText textAlign="center">
                <strong style={{ fontSize: '24px' }}>
                  {formatBytes(disk?.partitions?.reduce((sum, p) => sum + p.total_gb, 0) || 0)}
                </strong>
                <br />
                <EuiText size="s" color="subdued">Total</EuiText>
              </EuiText>
            </EuiFlexItem>
            <EuiFlexItem>
              <EuiText textAlign="center">
                <strong style={{ fontSize: '24px', color: '#10b981' }}>
                  {formatBytes(disk?.partitions?.reduce((sum, p) => sum + p.free_gb, 0) || 0)}
                </strong>
                <br />
                <EuiText size="s" color="subdued">Free</EuiText>
              </EuiText>
            </EuiFlexItem>
          </EuiFlexGroup>
        </EuiPanel>

        <EuiSpacer size="l" />

        {/* CPU and Memory Section */}
        <EuiFlexGroup gutterSize="l" wrap>
          <EuiFlexItem>
            <EuiPanel color="subdued" paddingSize="l" hasBorder>
              <EuiFlexGroup alignItems="center" gutterSize="s">
                <EuiFlexItem grow={false}>
                  <EuiIcon type="visGauge" size="m" color="#3b82f6" />
                </EuiFlexItem>
                <EuiFlexItem>
                  <EuiTitle size="s"><h3>CPU Utilization</h3></EuiTitle>
                </EuiFlexItem>
              </EuiFlexGroup>
              <EuiSpacer size="m" />

              <EuiFlexGroup alignItems="center">
                <EuiFlexItem grow={false} style={{ minWidth: '120px' }}>
                  <EuiText textAlign="center">
                    <h2 style={{ fontSize: '48px', color: getCpuColor(cpu?.overall_percent || 0) }}>
                      {Math.round(cpu?.overall_percent || 0)}%
                    </h2>
                    <EuiText size="s" color="subdued">{cpu?.cpu_count || 0} Cores</EuiText>
                  </EuiText>
                </EuiFlexItem>

                <EuiFlexItem>
                  <ResponsiveContainer width="100%" height={200}>
                    <BarChart data={cpuData}>
                      <CartesianGrid strokeDasharray="3 3" opacity={0.1} />
                      <XAxis dataKey="name" fontSize={10} />
                      <YAxis domain={[0, 100]} fontSize={10} />
                      <Tooltip
                        contentStyle={{ backgroundColor: '#1f2937', border: '1px solid #374151' }}
                        formatter={(value) => [`${value}%`, 'Usage']}
                      />
                      <Bar dataKey="usage" fill={COLORS.primary} radius={[4, 4, 0, 0]} />
                    </BarChart>
                  </ResponsiveContainer>
                </EuiFlexItem>
              </EuiFlexGroup>

              {cpu?.frequency_mhz && (
                <>
                  <EuiSpacer size="s" />
                  <EuiText size="xs" color="subdued" textAlign="center">
                    Current Frequency: {cpu.frequency_mhz.toFixed(0)} MHz
                  </EuiText>
                </>
              )}
            </EuiPanel>
          </EuiFlexItem>

          {/* Memory Section */}
          <EuiFlexItem>
            <EuiPanel color="subdued" paddingSize="l" hasBorder>
              <EuiFlexGroup alignItems="center" gutterSize="s">
                <EuiFlexItem grow={false}>
                  <EuiIcon type="memory" size="m" color="#10b981" />
                </EuiFlexItem>
                <EuiFlexItem>
                  <EuiTitle size="s"><h3>Memory Usage</h3></EuiTitle>
                </EuiFlexItem>
              </EuiFlexGroup>
              <EuiSpacer size="m" />

              <EuiFlexGroup alignItems="center" justifyContent="center">
                <EuiFlexItem grow={false}>
                  <div style={{ position: 'relative' }}>
                    <ResponsiveContainer width={250} height={250}>
                      <PieChart>
                        <Pie
                          data={memoryData}
                          cx="50%"
                          cy="50%"
                          innerRadius={70}
                          outerRadius={100}
                          paddingAngle={2}
                          dataKey="value"
                        >
                          {memoryData.map((entry, index) => (
                            <Cell key={`cell-${index}`} fill={entry.color} />
                          ))}
                        </Pie>
                        <Tooltip
                          formatter={(value) => [`${value.toFixed(2)} GB`, '']}
                          contentStyle={{ backgroundColor: '#1f2937', border: '1px solid #374151' }}
                        />
                      </PieChart>
                    </ResponsiveContainer>
                    <div style={{
                      position: 'absolute',
                      top: '50%',
                      left: '50%',
                      transform: 'translate(-50%, -50%)',
                      textAlign: 'center',
                      pointerEvents: 'none'
                    }}>
                      <h2 style={{ fontSize: '36px', color: getMemoryColor(memory?.percent || 0), margin: 0 }}>
                        {Math.round(memory?.percent || 0)}%
                      </h2>
                      <EuiText size="xs" color="subdued">Used</EuiText>
                    </div>
                  </div>
                </EuiFlexItem>
              </EuiFlexGroup>

              <EuiSpacer size="m" />
              <EuiFlexGroup justifyContent="spaceAround">
                <EuiFlexItem>
                  <EuiText textAlign="center">
                    <strong>{formatBytes(memory?.used_gb || 0)}</strong>
                    <br />
                    <EuiText size="xs" color="subdued">Used</EuiText>
                  </EuiText>
                </EuiFlexItem>
                <EuiFlexItem>
                  <EuiText textAlign="center">
                    <strong>{formatBytes(memory?.total_gb || 0)}</strong>
                    <br />
                    <EuiText size="xs" color="subdued">Total</EuiText>
                  </EuiText>
                </EuiFlexItem>
                <EuiFlexItem>
                  <EuiText textAlign="center">
                    <strong>{formatBytes(memory?.available_gb || 0)}</strong>
                    <br />
                    <EuiText size="xs" color="subdued">Available</EuiText>
                  </EuiText>
                </EuiFlexItem>
              </EuiFlexGroup>
            </EuiPanel>
          </EuiFlexItem>
        </EuiFlexGroup>

        <EuiSpacer size="l" />

        {/* Network Stats & FIM */}
        <EuiFlexGroup gutterSize="l" wrap>
          <EuiFlexItem>
            <EuiPanel color="subdued" paddingSize="l" hasBorder>
              <EuiFlexGroup alignItems="center" gutterSize="s">
                <EuiFlexItem grow={false}>
                  <EuiIcon type="globe" size="m" color="#06b6d4" />
                </EuiFlexItem>
                <EuiFlexItem>
                  <EuiTitle size="s"><h3>Network I/O</h3></EuiTitle>
                </EuiFlexItem>
              </EuiFlexGroup>
              <EuiSpacer size="m" />

              <EuiFlexGroup justifyContent="spaceAround" wrap>
                <EuiFlexItem style={{ minWidth: '150px' }}>
                  <EuiFlexGroup alignItems="center" gutterSize="m">
                    <EuiFlexItem grow={false}>
                      <EuiIcon type="arrowDown" color="success" size="l" />
                    </EuiFlexItem>
                    <EuiFlexItem>
                      <EuiText size="s" color="subdued">Received</EuiText>
                      <EuiText size="m"><strong>{formatBytes(network?.bytes_recv_gb || 0)}</strong></EuiText>
                    </EuiFlexItem>
                  </EuiFlexGroup>
                </EuiFlexItem>

                <EuiFlexItem style={{ minWidth: '150px' }}>
                  <EuiFlexGroup alignItems="center" gutterSize="m">
                    <EuiFlexItem grow={false}>
                      <EuiIcon type="arrowUp" color="primary" size="l" />
                    </EuiFlexItem>
                    <EuiFlexItem>
                      <EuiText size="s" color="subdued">Sent</EuiText>
                      <EuiText size="m"><strong>{formatBytes(network?.bytes_sent_gb || 0)}</strong></EuiText>
                    </EuiFlexItem>
                  </EuiFlexGroup>
                </EuiFlexItem>

                {(network?.errors_in + network?.errors_out > 0) && (
                  <EuiFlexItem style={{ minWidth: '150px' }}>
                    <EuiFlexGroup alignItems="center" gutterSize="m">
                      <EuiFlexItem grow={false}>
                        <EuiIcon type="alert" color="warning" size="l" />
                      </EuiFlexItem>
                      <EuiFlexItem>
                        <EuiText size="s" color="subdued">Errors</EuiText>
                        <EuiText size="m"><strong>{network.errors_in + network.errors_out}</strong></EuiText>
                      </EuiFlexItem>
                    </EuiFlexGroup>
                  </EuiFlexItem>
                )}
              </EuiFlexGroup>
            </EuiPanel>
          </EuiFlexItem>

          {/* File Integrity Monitoring */}
          <EuiFlexItem>
            <EuiPanel color="subdued" paddingSize="l" hasBorder>
              <EuiFlexGroup alignItems="center" gutterSize="s">
                <EuiFlexItem grow={false}>
                  <EuiIcon type="documentation" size="m" color="#8b5cf6" />
                </EuiFlexItem>
                <EuiFlexItem>
                  <EuiTitle size="s"><h3>File Integrity (30d)</h3></EuiTitle>
                </EuiFlexItem>
              </EuiFlexGroup>
              <EuiSpacer size="m" />

              {fim ? (
                <EuiFlexGroup direction="column" gutterSize="s">
                  <EuiFlexItem>
                    <EuiFlexGroup justifyContent="spaceBetween" alignItems="center">
                      <EuiFlexItem grow={false}>
                        <EuiFlexGroup alignItems="center" gutterSize="s">
                          <EuiFlexItem grow={false}>
                            <EuiIcon type="documentEdit" color="primary" />
                          </EuiFlexItem>
                          <EuiFlexItem>
                            <EuiText size="s">Modified</EuiText>
                          </EuiFlexItem>
                        </EuiFlexGroup>
                      </EuiFlexItem>
                      <EuiFlexItem grow={false}>
                        <EuiBadge color="primary">{fim.by_event_type?.modified || 0}</EuiBadge>
                      </EuiFlexItem>
                    </EuiFlexGroup>
                  </EuiFlexItem>

                  <EuiFlexItem>
                    <EuiFlexGroup justifyContent="spaceBetween" alignItems="center">
                      <EuiFlexItem grow={false}>
                        <EuiFlexGroup alignItems="center" gutterSize="s">
                          <EuiFlexItem grow={false}>
                            <EuiIcon type="plusInCircle" color="primary" />
                          </EuiFlexItem>
                          <EuiFlexItem>
                            <EuiText size="s">Added</EuiText>
                          </EuiFlexItem>
                        </EuiFlexGroup>
                      </EuiFlexItem>
                      <EuiFlexItem grow={false}>
                        <EuiBadge color="primary">{fim.by_event_type?.added || 0}</EuiBadge>
                      </EuiFlexItem>
                    </EuiFlexGroup>
                  </EuiFlexItem>

                  <EuiFlexItem>
                    <EuiFlexGroup justifyContent="spaceBetween" alignItems="center">
                      <EuiFlexItem grow={false}>
                        <EuiFlexGroup alignItems="center" gutterSize="s">
                          <EuiFlexItem grow={false}>
                            <EuiIcon type="trash" color="primary" />
                          </EuiFlexItem>
                          <EuiFlexItem>
                            <EuiText size="s">Deleted</EuiText>
                          </EuiFlexItem>
                        </EuiFlexGroup>
                      </EuiFlexItem>
                      <EuiFlexItem grow={false}>
                        <EuiBadge color="primary">{fim.by_event_type?.deleted || 0}</EuiBadge>
                      </EuiFlexItem>
                    </EuiFlexGroup>
                  </EuiFlexItem>

                  <EuiSpacer size="s" />
                  <EuiFlexItem>
                    <EuiText textAlign="center" size="s" color="subdued">
                      Total Changes: <strong>{fim.total || 0}</strong>
                    </EuiText>
                  </EuiFlexItem>
                </EuiFlexGroup>
              ) : (
                <EuiText color="subdued" textAlign="center" size="s">
                  <p>FIM data not available</p>
                  <EuiText size="xs">Ensure Wazuh FIM is enabled</EuiText>
                </EuiText>
              )}
            </EuiPanel>
          </EuiFlexItem>
        </EuiFlexGroup>
      </EuiPanel>
    </div>
  );
};

export default SystemHealth;
