import React, { useEffect, useState } from 'react';
import { RefreshCw, Database, Filter, ChevronDown, ChevronRight } from 'lucide-react';
import axios from 'axios';

const PromachosIndexer = () => {
  const [source, setSource] = useState('all');
  const [page, setPage] = useState(1);
  const [rowsPerPage] = useState(50);
  const [total, setTotal] = useState(0);
  const [items, setItems] = useState([]);
  const [loading, setLoading] = useState(false);
  const [expandedRow, setExpandedRow] = useState(null);
  const offset = (page - 1) * rowsPerPage;

  const transformWazuhAlerts = (alerts) => {
    return (alerts || []).map(alert => ({
      time: new Date(alert.timestamp).getTime() / 1000,
      source: 'Wazuh',
      name: alert.rule?.description || `Rule ${alert.rule?.id}` || 'N/A',
      ip: alert.agent?.ip || alert.data?.srcip || alert.data?.src_ip || 'N/A',
      host: alert.agent?.name || alert.manager?.name || 'N/A',
      severity: alert.rule?.level || 0,
      category: alert.rule?.groups?.join(', ') || 'N/A',
      raw: alert
    }));
  };

  const transformSuricataAlerts = (alerts) => {
    return (alerts || []).map(alert => ({
      time: new Date(alert['@timestamp'] || alert.timestamp).getTime() / 1000,
      source: 'Suricata',
      name: alert.alert?.signature || alert.alert?.category || 'N/A',
      ip: alert.src_ip || alert.source?.ip || 'N/A',
      host: alert.dest_ip || alert.host?.hostname || alert.host || 'N/A',
      severity: alert.alert?.severity || 0,
      category: alert.alert?.category || 'N/A',
      raw: alert
    }));
  };

  const fetchData = async () => {
    setLoading(true);
    try {
      const limit = rowsPerPage;
      const offset = (page - 1) * rowsPerPage;
      const src = source || 'all';
      const params = new URLSearchParams({
        source: src,
        limit: String(limit),
        offset: String(offset)
      });
      const resp = await axios.get(`http://localhost:5001/api/promachos-indexer/events?${params.toString()}`);
      const itemsResp = resp.data.items || [];
      setItems(itemsResp.map(e => ({
        time: e.time,
        source: e.source,
        name: e.name,
        ip: e.ip,
        host: e.host,
        severity: 0,
        category: e.source,
        raw: e
      })));
      setTotal(resp.data.totalItems || itemsResp.length);
    } catch (e) {
      console.error('Failed to fetch Promachos events:', e);
      setItems([]);
      setTotal(0);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
  }, [source, page]);

  const totalPages = Math.max(1, Math.ceil(total / rowsPerPage));

  const getSeverityColor = (severity) => {
    if (severity === 0 || severity === 'N/A') return 'bg-gray-500/20 text-gray-400';
    if (severity <= 3) return 'bg-green-500/20 text-green-400';
    if (severity <= 7) return 'bg-yellow-500/20 text-yellow-400';
    return 'bg-red-500/20 text-red-400';
  };

  const formatTimestamp = (timestamp) => {
    try {
      return new Date(timestamp * 1000).toLocaleString();
    } catch {
      return 'Invalid Date';
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-3">
          <div className="w-10 h-10 bg-accent-purple/20 rounded-lg flex items-center justify-center">
            <Database className="w-6 h-6 text-accent-purple" />
          </div>
          <div>
            <h1 className="text-2xl font-bold text-white">Promachos Indexer</h1>
            <p className="text-dark-400">Real-time security event indexing from Elasticsearch</p>
          </div>
        </div>
      </div>

      <div className="card p-4">
        <div className="flex items-center space-x-4">
          <div className="flex items-center space-x-2">
            <Filter className="w-5 h-5 text-dark-400" />
            <span className="text-sm font-medium text-dark-300">Source:</span>
          </div>
          <div className="flex space-x-2">
            {['all', 'wazuh', 'suricata'].map((s) => (
              <button
                key={s}
                onClick={() => { setSource(s); setPage(1); setExpandedRow(null); }}
                className={`px-4 py-2 rounded-md text-sm font-medium transition-colors ${
                  source === s
                    ? 'bg-accent-purple text-white'
                    : 'bg-dark-800 text-dark-300 hover:bg-dark-700 hover:text-white'
                }`}
              >
                {s.charAt(0).toUpperCase() + s.slice(1)}
              </button>
            ))}
          </div>
          <button
            onClick={() => { setPage(1); setExpandedRow(null); fetchData(); }}
            disabled={loading}
            className="ml-auto px-4 py-2 bg-accent-blue text-white rounded-md hover:bg-accent-blue/80 transition-colors disabled:opacity-50 disabled:cursor-not-allowed flex items-center space-x-2"
          >
            <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} />
            <span>Refresh</span>
          </button>
        </div>
      </div>

      <div className="card overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-dark-800 border-b border-dark-700">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-dark-300 uppercase tracking-wider w-8">

                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-dark-300 uppercase tracking-wider">
                  Time
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-dark-300 uppercase tracking-wider">
                  Source
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-dark-300 uppercase tracking-wider">
                  Event Name
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-dark-300 uppercase tracking-wider">
                  Severity
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-dark-300 uppercase tracking-wider">
                  Source IP
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-dark-300 uppercase tracking-wider">
                  Host/Dest
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-dark-300 uppercase tracking-wider">
                  Category
                </th>
              </tr>
            </thead>
            <tbody className="divide-y divide-dark-700">
              {items.map((item, idx) => (
                <React.Fragment key={idx}>
                  <tr
                    onClick={() => setExpandedRow(expandedRow === idx ? null : idx)}
                    className="hover:bg-dark-800/50 transition-colors cursor-pointer"
                  >
                    <td className="px-6 py-4 whitespace-nowrap text-dark-300">
                      {expandedRow === idx ? (
                        <ChevronDown className="w-4 h-4" />
                      ) : (
                        <ChevronRight className="w-4 h-4" />
                      )}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-dark-300">
                      {formatTimestamp(item.time)}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <span className={`px-2 py-1 text-xs font-medium rounded-full ${
                        item.source === 'Suricata' ? 'bg-blue-500/20 text-blue-400' :
                        item.source === 'Wazuh' ? 'bg-green-500/20 text-green-400' :
                        'bg-purple-500/20 text-purple-400'
                      }`}>
                        {item.source}
                      </span>
                    </td>
                    <td className="px-6 py-4 text-sm text-dark-300 max-w-md truncate" title={item.name}>
                      {item.name}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <span className={`px-2 py-1 text-xs font-semibold rounded ${getSeverityColor(item.severity)}`}>
                        {item.severity !== 0 ? `Level ${item.severity}` : 'N/A'}
                      </span>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm font-mono text-dark-300">
                      {item.ip}
                    </td>
                    <td className="px-6 py-4 text-sm text-dark-300">
                      {item.host}
                    </td>
                    <td className="px-6 py-4 text-sm text-dark-300 max-w-xs truncate" title={item.category}>
                      {item.category}
                    </td>
                  </tr>
                  {expandedRow === idx && (
                    <tr className="bg-dark-900">
                      <td colSpan="8" className="px-6 py-4">
                        <div className="space-y-2">
                          <div className="flex items-center space-x-2 mb-3">
                            <div className="w-2 h-2 bg-accent-blue rounded-full"></div>
                            <span className="text-sm font-semibold text-white">Raw Event Data (JSON)</span>
                          </div>
                          <pre className="bg-dark-950 p-4 rounded-lg overflow-auto max-h-96 text-xs text-green-400 border border-dark-700">
                            {JSON.stringify(item.raw, null, 2)}
                          </pre>
                        </div>
                      </td>
                    </tr>
                  )}
                </React.Fragment>
              ))}
              {!loading && items.length === 0 && (
                <tr>
                  <td colSpan="8" className="px-6 py-8 text-center text-dark-400">
                    No events found. Try changing the source filter or date range.
                  </td>
                </tr>
              )}
              {loading && (
                <tr>
                  <td colSpan="8" className="px-6 py-8 text-center text-dark-400">
                    <RefreshCw className="w-6 h-6 animate-spin mx-auto mb-2" />
                    <div>Loading events from Elasticsearch...</div>
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>

        <div className="bg-dark-800 px-6 py-4 flex items-center justify-between border-t border-dark-700">
          <div className="text-sm text-dark-300">
            Total: <span className="font-medium text-white">{total.toLocaleString()}</span> events
            <span className="text-dark-500 ml-2">({items.length} shown)</span>
          </div>
          <div className="flex items-center space-x-2">
            <button
              onClick={() => { setPage(Math.max(1, page - 1)); setExpandedRow(null); }}
              disabled={page === 1 || loading}
              className="px-3 py-1 bg-dark-700 text-dark-300 rounded-md hover:bg-dark-600 hover:text-white transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
            >
              Previous
            </button>
            <span className="text-sm text-dark-300">
              Page <span className="font-medium text-white">{page}</span> of <span className="font-medium text-white">{totalPages}</span>
            </span>
            <button
              onClick={() => { setPage(Math.min(totalPages, page + 1)); setExpandedRow(null); }}
              disabled={page === totalPages || loading}
              className="px-3 py-1 bg-dark-700 text-dark-300 rounded-md hover:bg-dark-600 hover:text-white transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
            >
              Next
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default PromachosIndexer;
