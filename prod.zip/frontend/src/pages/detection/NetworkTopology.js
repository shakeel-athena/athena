import { useState, useEffect, useMemo, useRef, useCallback } from 'react';
import {
  EuiPage,
  EuiFlexGroup,
  EuiFlexItem,
  EuiTitle,
  EuiText,
  EuiSpacer,
  EuiSelect,
  EuiErrorBoundary,
  EuiBadge,
  EuiLoadingSpinner,
  EuiEmptyPrompt,
  EuiButton,
  EuiFieldSearch,
  EuiStat,
  EuiToolTip,
  EuiSwitch,
  EuiDescriptionList,
  EuiHealth,
  EuiProgress,
  EuiButtonIcon,
  EuiIcon,
  EuiSuperSelect,
} from '@elastic/eui';
import { Toaster } from 'react-hot-toast';
import { appendIconComponentCache } from '@elastic/eui/es/components/icon/icon';
import { icon as iconDot } from '@elastic/eui/es/components/icon/assets/dot';
import { icon as iconEye } from '@elastic/eui/es/components/icon/assets/eye';
import { icon as iconCross } from '@elastic/eui/es/components/icon/assets/cross';
import { icon as iconRefresh } from '@elastic/eui/es/components/icon/assets/refresh';
import { icon as iconMagnifyWithPlus } from '@elastic/eui/es/components/icon/assets/magnifyWithPlus';
import { icon as iconMagnifyWithMinus } from '@elastic/eui/es/components/icon/assets/magnifyWithMinus';
import { icon as iconExpand } from '@elastic/eui/es/components/icon/assets/expand';
import { icon as iconDownload } from '@elastic/eui/es/components/icon/assets/download';
import { icon as iconSave } from '@elastic/eui/es/components/icon/assets/save';
import { icon as iconSearch } from '@elastic/eui/es/components/icon/assets/search';
import { icon as iconLock } from '@elastic/eui/es/components/icon/assets/lock';
import { icon as iconBellSlash } from '@elastic/eui/es/components/icon/assets/bellSlash';
import { icon as iconClock } from '@elastic/eui/es/components/icon/assets/clock';

import { useNavigate } from 'react-router-dom';
import { Network } from 'lucide-react';
import {
  fetchUnifiedAlerts,
  fetchAgents,
  fetchTopologyNodes,
  bulkUpdateTopologyNodes,
  updateNodePosition,
  fetchTopologyThreatActors
} from '../../services/detectionApi';
import NetworkTopology2D from '../../components/ThreatLandscape/NetworkTopology2D';
import { getIconForRole } from '../../components/ThreatLandscape/NodeIcons';
import { getNodeSegment } from '../../components/ThreatLandscape/utils/NodeStyleResolver';
// Response Action Modals
import MuteAlertModal from '../../components/MuteAlertModal';
import BlockIPModal from '../../components/BlockIPModal';
// IP Enrichment for Threat Intelligence
import IPEnrichmentTooltip from '../../components/IPEnrichmentTooltip';
// Node Context Menu for right-click actions
import NodeContextMenu from '../../components/ThreatLandscape/NodeContextMenu';
// Alert Correlation (kept for future use)
// import CorrelationBadge, { correlateIncidents } from '../../components/ThreatLandscape/CorrelationBadge';
// MITRE ATT&CK Overlay
import MitreOverlay, { getNodeMitreColor } from '../../components/ThreatLandscape/MitreOverlay';
// Pivot Menu for Hunting
import PivotMenu from '../../components/ThreatLandscape/PivotMenu';
// IOC Search Bar
import IOCSearchBar from '../../components/ThreatLandscape/IOCSearchBar';
// View Switcher for split/concentric layouts
import ViewSwitcher from '../../components/ThreatLandscape/components/ViewSwitcher';

// Pre-cache icons to avoid ChunkLoadError in proxy environments
appendIconComponentCache({
  dot: iconDot,
  eye: iconEye,
  cross: iconCross,
  refresh: iconRefresh,
  magnifyWithPlus: iconMagnifyWithPlus,
  magnifyWithMinus: iconMagnifyWithMinus,
  expand: iconExpand,
  download: iconDownload,
  save: iconSave,
  search: iconSearch,
  lock: iconLock,
  bellSlash: iconBellSlash,
  clock: iconClock,
});

// Agelia Design System colors (from Figma)
const AGELIA_COLORS = {
  background: '#07101f',       // var(--bg-1) - Deep Navy
  panel: '#111c2c',            // var(--bg-3) - Panel background
  panelDark: '#0b1628',        // var(--bg-6) - Darker panel
  border: '#1d2a3e',           // var(--primary-5) - Border color
  borderLight: '#343741',      // var(--primary-4) - Lighter border
  text: '#ffffff',             // var(--text-1) - Primary text
  textSecondary: '#8e9fbc',    // var(--primary-2) - Secondary text
  textMuted: '#cad3e2',        // var(--primary-1) - Muted text
  primary: '#61a2ff',          // var(--primary-3) - Primary blue
  success: '#24c292',          // var(--accent-1) - Success green
  successLight: '#7de2d1',     // var(--accent-2) - Light cyan
  danger: '#f6726a',           // var(--error-1) - Danger coral
  warning: '#dc6a13',          // var(--error-3) - Warning orange
  warningYellow: '#fec514',    // var(--severity-medium) - Yellow
  accent: '#16c5c0',           // var(--accent-4) - Cyan accent
  accentGlow: 'rgba(22, 197, 192, 0.5)',
  dangerGlow: 'rgba(246, 114, 106, 0.5)',
  warningGlow: 'rgba(220, 106, 19, 0.5)',
  successGlow: 'rgba(36, 194, 146, 0.5)',
  primaryGlow: 'rgba(97, 162, 255, 0.5)',
};


const ThreatLandscape = () => {
  const navigate = useNavigate();
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [timeRange, setTimeRange] = useState('7d');
  const [searchTerm, setSearchTerm] = useState('');
  const [topologyData, setTopologyData] = useState({ nodes: [], edges: [], incidents: [] });
  const [persistedPositions, setPersistedPositions] = useState({});
  const [hasUnsavedChanges, setHasUnsavedChanges] = useState(false);
  const [selectedNode, setSelectedNode] = useState(null);
  const [agentDetailOpen, setAgentDetailOpen] = useState(false);
  const topology2DRef = useRef(null);

  const [showUnregisteredNodes, setShowUnregisteredNodes] = useState(true);

  // Modal state for response actions
  const [muteModal, setMuteModal] = useState({ isOpen: false, event: null });
  const [blockIPModal, setBlockIPModal] = useState({ isOpen: false, event: null });

  // Auto-refresh state
  const [autoRefresh, setAutoRefresh] = useState(false);
  const [refreshInterval, setRefreshInterval] = useState(30000); // Default: 30 seconds

  // Store alerts for the selected node
  const [nodeAlerts, setNodeAlerts] = useState([]);

  // Context menu state for right-click actions
  const [contextMenu, setContextMenu] = useState({
    isOpen: false,
    position: { x: 0, y: 0 },
    node: null
  });

  // MITRE ATT&CK overlay state
  const [mitreEnabled, setMitreEnabled] = useState(false);
  const [selectedMitreTactic, setSelectedMitreTactic] = useState(null);

  // Pivot menu state
  const [pivotMenu, setPivotMenu] = useState({
    isOpen: false,
    position: { x: 0, y: 0 },
    node: null
  });

  // Highlighted nodes from search
  const [highlightedNodes, setHighlightedNodes] = useState([]);

  // Topology view mode (split or concentric) with localStorage persistence
  const [viewMode, setViewMode] = useState(() => {
    const saved = localStorage.getItem('threatTopology_viewMode');
    return saved || 'split';
  });

  // Persist view mode changes
  const handleViewModeChange = useCallback((newMode) => {
    setViewMode(newMode);
    localStorage.setItem('threatTopology_viewMode', newMode);
  }, []);

  const stats = useMemo(() => {
    const nodes = topologyData.nodes || [];
    const incidents = topologyData.incidents || [];

    // Separate registered agents from threat actors
    const registeredAgents = nodes.filter(n => n.isRegistered && n.type !== 'cluster' && n.type !== 'segment-diamond' && n.type !== 'segment');
    const threatActorNodes = nodes.filter(n => n.isThreatActor || n.isHighRiskHost);

    // Further separate external threat actors from internal high-risk hosts
    const externalThreatActors = threatActorNodes.filter(n => !n.isInternal);
    const internalHighRiskHosts = threatActorNodes.filter(n => n.isInternal);

    // Total Agents = only registered Wazuh agents
    const totalEndpoints = registeredAgents.length;

    // Active Threats = threat actors + high-risk hosts (filtered from API)
    const activeThreats = threatActorNodes.length;

    // Count critical alerts and high alerts separately
    const criticalAlerts = incidents.filter(inc => inc.severity === 'Critical').length;
    const highAlerts = incidents.filter(inc => inc.severity === 'High').length;
    const highCriticalAlerts = criticalAlerts + highAlerts;

    // Count unique SIEM sources
    const siemSources = [...new Set(incidents.map(inc => inc.source).filter(Boolean))].length;

    // Agent health metrics - based on actual connection status, not alert activity
    const activeAgents = registeredAgents.filter(n => {
      const status = String(n.status || '').toLowerCase();
      return status === 'active' || status === 'connected' || status === 'online';
    }).length;
    const disconnectedAgents = registeredAgents.filter(n => {
      const status = String(n.status || '').toLowerCase();
      return status === 'disconnected' || status === 'offline';
    }).length;
    const neverConnectedAgents = registeredAgents.filter(n => {
      const status = String(n.status || '').toLowerCase();
      return status === 'never_connected' || status === 'pending';
    }).length;

    // Calculate overall Risk Score
    // Components:
    // - External threat actors: 20 points each (max contribution)
    // - Internal high-risk hosts: 10 points each
    // - High/Critical alerts: 2 points each
    // - Disconnected agents: 5 points each (reduced visibility = risk)
    const riskScore = Math.min(100,
      (externalThreatActors.length * 20) +
      (internalHighRiskHosts.length * 10) +
      (highCriticalAlerts * 2) +
      (disconnectedAgents * 5)
    );

    const riskLevel = riskScore >= 80 ? 'CRITICAL' :
                      riskScore >= 60 ? 'ELEVATED' :
                      riskScore >= 40 ? 'GUARDED' : 'LOW';

    // Find top threat actor (highest alert count)
    const topThreatActor = threatActorNodes.length > 0
      ? threatActorNodes.reduce((top, current) =>
          (current.alertCount || 0) > (top.alertCount || 0) ? current : top
        , threatActorNodes[0])
      : null;

    // Get last alert time from incidents
    const lastAlertTime = incidents.length > 0
      ? incidents.reduce((latest, inc) => {
          const incTime = inc.timestamp ? new Date(inc.timestamp) : null;
          if (!incTime) return latest;
          if (!latest) return incTime;
          return incTime > latest ? incTime : latest;
        }, null)
      : null;

    // Format last alert as relative time
    const formatRelativeTime = (date) => {
      if (!date) return null;
      const now = new Date();
      const diffMs = now - date;
      const diffMins = Math.floor(diffMs / 60000);
      const diffHours = Math.floor(diffMs / 3600000);
      const diffDays = Math.floor(diffMs / 86400000);

      if (diffMins < 1) return 'Just now';
      if (diffMins < 60) return `${diffMins}m ago`;
      if (diffHours < 24) return `${diffHours}h ago`;
      return `${diffDays}d ago`;
    };

    // Data source health - check if we have alerts from each source
    const wazuhAlerts = incidents.filter(inc => inc.model === 'SIEM Rule').length;
    const suricataAlerts = incidents.filter(inc => inc.model === 'NIDS Signature').length;
    const dataSourceHealth = {
      wazuh: wazuhAlerts > 0,
      suricata: suricataAlerts > 0,
      wazuhCount: wazuhAlerts,
      suricataCount: suricataAlerts,
    };

    // Extract top attack categories from incidents (based on titles/signatures)
    const attackCategories = {};
    incidents.forEach(inc => {
      const title = inc.title || '';
      // Simple categorization based on common keywords
      if (title.match(/brute.*force|authentication.*failed|login.*attempt/i)) {
        attackCategories['Brute Force'] = (attackCategories['Brute Force'] || 0) + 1;
      } else if (title.match(/malware|trojan|virus|ransomware/i)) {
        attackCategories['Malware'] = (attackCategories['Malware'] || 0) + 1;
      } else if (title.match(/scan|reconnaissance|probe/i)) {
        attackCategories['Scanning'] = (attackCategories['Scanning'] || 0) + 1;
      } else if (title.match(/exploit|vulnerability|cve/i)) {
        attackCategories['Exploitation'] = (attackCategories['Exploitation'] || 0) + 1;
      } else if (title.match(/ddos|dos|flood/i)) {
        attackCategories['DoS'] = (attackCategories['DoS'] || 0) + 1;
      } else if (title.match(/injection|xss|sqli|command/i)) {
        attackCategories['Injection'] = (attackCategories['Injection'] || 0) + 1;
      } else {
        attackCategories['Other'] = (attackCategories['Other'] || 0) + 1;
      }
    });

    // Get top 3 attack categories
    const topAttackCategories = Object.entries(attackCategories)
      .sort((a, b) => b[1] - a[1])
      .slice(0, 3)
      .map(([category, count]) => ({ category, count }));

    return {
      totalEndpoints,
      activeThreats,
      externalThreatActors: externalThreatActors.length,
      internalHighRiskHosts: internalHighRiskHosts.length,
      criticalAlerts,
      highAlerts,
      highCriticalAlerts,
      siemSources,
      activeAgents,
      disconnectedAgents,
      neverConnectedAgents,
      riskScore,
      riskLevel,
      externalIPs: threatActorNodes.length, // For backward compatibility
      registeredCount: registeredAgents.length,
      // New stats
      topThreatActor: topThreatActor ? {
        ip: topThreatActor.ip || topThreatActor.label || topThreatActor.id,
        alertCount: topThreatActor.alertCount || 0,
        isInternal: topThreatActor.isInternal || false,
      } : null,
      lastAlertTime: formatRelativeTime(lastAlertTime),
      lastAlertTimestamp: lastAlertTime,
      dataSourceHealth,
      topAttackCategories,
      totalAlerts: incidents.length,
    };
  }, [topologyData]);

  const categoryCounts = useMemo(() => {
    const counts = { desktop: 0, server: 0, database: 0, website: 0, laptop: 0, printer: 0, network: 0 };
    (topologyData.nodes || []).forEach(n => {
      const r = String(n.role || '').toLowerCase();
      if (r.includes('server') || r.includes('siem')) counts.server++;
      else if (r.includes('database') || r.includes('db')) counts.database++;
      else if (r.includes('website') || r.includes('web')) counts.website++;
      else if (r.includes('desktop') || r.includes('workstation')) counts.desktop++;
      else if (r.includes('laptop')) counts.laptop++;
      else if (r.includes('printer')) counts.printer++;
      else counts.network++;
    });
    return counts;
  }, [topologyData.nodes]);

  const isSegmentSelection = selectedNode?.type === 'segment';
  const showAgentFlyout = agentDetailOpen && selectedNode && !isSegmentSelection;

  // Track if initial load has happened
  const initialLoadDone = useRef(false);
  const persistedPositionsRef = useRef({});

  // Consolidated load function to handle sequence correctly
  const fetchAndInitializeTopology = useCallback(async () => {
    setLoading(true);
    try {
      // 1. Load persisted positions FIRST
      const positions = await fetchTopologyNodes();
      persistedPositionsRef.current = positions;
      setPersistedPositions(positions);

      // 2. Then load alert data, PASSING the positions to ensure they are used immediately
      await loadData(positions);
    } catch (err) {
      console.error('Failed to initialize topology:', err);
      // Fallback to trying just loadData if fetchTopologyNodes fails
      loadData({});
    } finally {
      setLoading(false);
      initialLoadDone.current = true;
    }
  }, [timeRange, showUnregisteredNodes, searchTerm]);

  // Load data only on mount or when filters change
  useEffect(() => {
    fetchAndInitializeTopology();
  }, [fetchAndInitializeTopology]);

  // Reload when user explicitly changes time range or view mode
  const handleTimeRangeChange = (newRange) => {
    initialLoadDone.current = false;  // Allow reload
    setTimeRange(newRange);
  };

  // Auto-refresh effect
  useEffect(() => {
    if (!autoRefresh) return;

    // Pause auto-refresh if user is interacting with nodes
    if (selectedNode || hasUnsavedChanges) return;

    const interval = setInterval(() => {
      loadData(persistedPositionsRef.current);
    }, refreshInterval);

    return () => clearInterval(interval);
  }, [autoRefresh, refreshInterval, selectedNode, hasUnsavedChanges]);

  // Save current topology layout
  const saveTopologyLayout = useCallback(async () => {
    if (!topologyData.nodes?.length) return;

    setSaving(true);
    try {
      const nodesToSave = {};
      topologyData.nodes.forEach(node => {
        nodesToSave[node.id] = {
          label: node.label,
          ip: node.ip,
          role: node.role,
          x: Math.round(node.x),
          y: Math.round(node.y),
          z: Math.round(node.z),
          cluster_id: node.cluster,
          node_type: node.type || 'agent',
          position_locked: true
        };
      });

      const success = await bulkUpdateTopologyNodes(nodesToSave);
      if (success) {
        setPersistedPositions(nodesToSave);
        setHasUnsavedChanges(false);
      }
    } catch (err) {
      console.error('Failed to save topology layout:', err);
    } finally {
      setSaving(false);
    }
  }, [topologyData.nodes]);

  const handleSelectNode = useCallback((node) => {
    setSelectedNode(node);
    setAgentDetailOpen(Boolean(node && node.type !== 'segment'));
  }, []);

  useEffect(() => {
    if (!selectedNode || selectedNode.type === 'segment') {
      setAgentDetailOpen(false);
    }
  }, [selectedNode]);

  // Handle node position change (from drag in 3D view)
  const handleNodePositionChange = useCallback(async (nodeId, position) => {
    // Update local state immediately for responsiveness
    setTopologyData(prev => ({
      ...prev,
      nodes: prev.nodes.map(n =>
        n.id === nodeId ? { ...n, ...position } : n
      )
    }));

    // CRITICAL: Update persistedPositions state so subsequent filters don't revert this change
    setPersistedPositions(prev => ({
      ...prev,
      [nodeId]: {
        ...(prev[nodeId] || {}),
        ...position,
        position_locked: true
      }
    }));

    setHasUnsavedChanges(true);

    // Persist to backend
    await updateNodePosition(nodeId, position);
  }, []);

  const loadData = async (currentPersistedPositions = persistedPositions) => {
    setLoading(true);

    try {
      // Fetch all data in parallel for better performance
      const [agentsResult, alertsResponse, threatActorsResult] = await Promise.all([
        // 1. Try to fetch registered agents (optional - may not exist)
        fetchAgents().catch(() => []),

        // 2. Fetch Alerts (Primary Data Source) - time range is the filter
        fetchUnifiedAlerts({
          time_range: timeRange,
          return_total: true,
        }),

        // 3. Fetch Threat Actors (External IPs + Internal High-Risk Hosts)
        fetchTopologyThreatActors({
          time_range: timeRange,
          limit: 20,
          min_severity: 'High',  // Include High and Critical severity alerts only
          include_internal: true  // Include internal IPs that aren't registered agents
        }).catch(() => ({ threat_actors: [], total_filtered: 0, showing: 0 }))
      ]);

      const agentsList = agentsResult || [];
      const alerts = alertsResponse.alerts || [];
      const agentStats = alertsResponse.statistics?.by_agent || [];
      const threatActorsData = threatActorsResult || { threat_actors: [], total_filtered: 0, showing: 0 };

      // --- Transform Data into Topology ---
      const nodesMap = new Map();
      const edges = [];
      const incidents = [];

      // Helper to determine role based on Figma categories
      const getRole = (name) => {
        const lowerName = name.toLowerCase();
        if (lowerName.includes('server')) return 'server';
        if (lowerName.includes('db') || lowerName.includes('database')) return 'database';
        if (lowerName.includes('web') || lowerName.includes('nginx') || lowerName.includes('website')) return 'website';
        if (lowerName.includes('firewall')) return 'firewall';
        if (lowerName.includes('laptop')) return 'laptop';
        if (lowerName.includes('printer')) return 'printer';
        if (lowerName.includes('desktop') || lowerName.includes('pc') || lowerName.includes('workstation')) return 'desktop';
        return 'endpoint';
      };

      const isAgentActive = (status) => {
        const normalized = String(status || '').toLowerCase();
        return normalized === 'active' || normalized === 'connected' || normalized === 'online';
      };

      // Helper to get position (use persisted if available, otherwise random)
      const getPosition = (nodeId) => {
        const persisted = currentPersistedPositions[nodeId];
        if (persisted && typeof persisted.x === 'number') {
          return {
            x: persisted.x,
            y: persisted.y,
            z: persisted.z,
            position_locked: persisted.position_locked || false
          };
        }
        // Random position for new nodes - reduced spread for tighter layout
        const spread = 60;
        return {
          x: (Math.random() - 0.5) * spread,
          y: (Math.random() - 0.5) * (spread / 3), // Keep vertical spread lower
          z: (Math.random() - 0.5) * spread,
          position_locked: false
        };
      };

      // 1. Populate Nodes from Registered Agents (Primary Source)
      // Create lookup maps for robust matching
      const agentsByNameLower = new Map(); // lowercase name -> node ID
      const agentsByIP = new Map();        // IP address -> node ID

      agentsList.forEach(agent => {
        const agentId = agent.id || agent.name; // Prefer ID, fallback to name
        if (nodesMap.has(agentId)) return;

        const position = getPosition(agentId);
        const persisted = currentPersistedPositions[agentId] || {};

        nodesMap.set(agentId, {
          id: agentId,
          label: agent.name || agentId,
          ip: agent.ip || '0.0.0.0',
          role: persisted.role || getRole(agent.name || ''),
          critical: false,
          riskScore: 0,
          subnet: (agent.ip || '0.0.0.0').split('.').slice(0, 3).join('.') + '.0/24',
          os: agent.os || 'Unknown',
          status: agent.status || 'active',
          isActive: isAgentActive(agent.status),
          alertCount: 0,
          isRegistered: true, // Mark as registered agent
          cluster: persisted.cluster_id,
          x: position.x,
          y: position.y,
          z: position.z,
          position_locked: position.position_locked,
        });

        // Build lookup indexes for matching alerts
        if (agent.name) {
          agentsByNameLower.set(String(agent.name).toLowerCase(), agentId);
        }
        if (agent.ip && agent.ip !== '0.0.0.0') {
          agentsByIP.set(agent.ip, agentId);
        }
      });

      // 2. Enrich Nodes with Alert Statistics
      const getSeverityCount = (stat, key) => Number(stat[key] ?? stat[key.toLowerCase()] ?? 0);

      agentStats.forEach(stat => {
        let node = null;

        // Try multiple matching strategies to find registered agent
        const statAgentLower = String(stat.agent || '').toLowerCase();
        const statAgentIP = stat.agent_ip || '';

        // Strategy 1: Exact match on label
        for (const [_, n] of nodesMap) {
          if (n.label === stat.agent) {
            node = n;
            break;
          }
        }

        // Strategy 2: Case-insensitive match on name
        if (!node && agentsByNameLower.has(statAgentLower)) {
          const matchedId = agentsByNameLower.get(statAgentLower);
          node = nodesMap.get(matchedId);
        }

        // Strategy 3: Match by IP address
        if (!node && statAgentIP && agentsByIP.has(statAgentIP)) {
          const matchedId = agentsByIP.get(statAgentIP);
          node = nodesMap.get(matchedId);
        }

        // Strategy 4: Check if stat has agent_id that matches nodesMap key directly
        if (!node && stat.agent_id && nodesMap.has(stat.agent_id)) {
          node = nodesMap.get(stat.agent_id);
        }

        // If not found in registered agents, create a "derived" node
        if (!node) {
          const agentId = stat.agent;
          // Skip if already exists as a derived node
          if (nodesMap.has(agentId)) {
            node = nodesMap.get(agentId);
          } else {
            const position = getPosition(agentId);
            node = {
              id: agentId,
              label: stat.agent,
              ip: stat.agent_ip || '0.0.0.0',
              role: getRole(stat.agent),
              critical: false,
              riskScore: 0,
              subnet: (stat.agent_ip || '0.0.0.0').split('.').slice(0, 3).join('.') + '.0/24',
              os: stat.agent_os || 'Unknown',
              alertCount: 0,
              isActive: false,
              isRegistered: false, // Derived from alerts, not in registered agents list
              x: position.x,
              y: position.y,
              z: position.z,
              position_locked: position.position_locked,
            };
            nodesMap.set(agentId, node);
          }
        }

        const criticalCount = getSeverityCount(stat, 'Critical');
        const highCount = getSeverityCount(stat, 'High');
        const mediumCount = getSeverityCount(stat, 'Medium');
        const lowCount = getSeverityCount(stat, 'Low');
        // Only count High and Critical alerts to match min_severity: 'High' configuration
        const alertCount = criticalCount + highCount;

        node.alertCount = alertCount;
        node.criticalCount = criticalCount;
        node.highCount = highCount;
        node.mediumCount = mediumCount;
        node.lowCount = lowCount;
        // Note: isActive should only reflect actual agent connection status, not alert presence

        // Enhanced Risk Scoring Algorithm
        // Only considers High and Critical alerts to match min_severity: 'High' configuration
        // Components:
        // 1. Severity Weight (60%) - Critical alerts weigh heaviest
        // 2. Alert Volume (30%) - More alerts = higher risk
        // 3. Multi-severity Penalty (10%) - Both Critical and High indicates persistent attack

        let riskScore = 0;

        // 1. Severity Weight (60% of score) - only High and Critical
        const severityScore = (criticalCount * 30) + (highCount * 15);
        riskScore += Math.min(severityScore, 60);

        // 2. Alert Volume (30% of score) - logarithmic scale to prevent explosion
        if (alertCount > 0) {
          const volumeScore = Math.min(30, Math.log10(alertCount + 1) * 20);
          riskScore += volumeScore;
        }

        // 3. Multi-severity Penalty (10% of score) - has both Critical and High alerts
        if (criticalCount > 0 && highCount > 0) {
          riskScore += 10;
        }

        // 4. Critical threshold escalation - if any critical, minimum score of 50
        if (criticalCount > 0 && riskScore < 50) {
          riskScore = 50;
        }

        node.riskScore = Math.min(100, Math.round(riskScore));

        if (criticalCount > 0 || highCount > 0) {
          node.critical = true;
        }
      });

      // 3. Process Alerts for Edges and Incidents
      alerts.forEach(alert => {
        const severity = alert.normalized_severity || 'Low';

        if (alert.source === 'suricata' && alert.src_ip && alert.dest_ip) {
          const srcId = alert.src_ip;
          const destId = alert.dest_ip;

          if (!nodesMap.has(srcId)) {
            const pos = getPosition(srcId);
            nodesMap.set(srcId, {
              id: srcId, label: srcId, ip: srcId, role: 'external', critical: false, riskScore: 0,
              isRegistered: false,
              x: pos.x * 5, y: pos.y * 5, z: pos.z * 5
            });
          }
          if (!nodesMap.has(destId)) {
            const pos = getPosition(destId);
            nodesMap.set(destId, {
              id: destId, label: destId, ip: destId, role: 'external', critical: false, riskScore: 0,
              isRegistered: false,
              x: pos.x * 5, y: pos.y * 5, z: pos.z * 5
            });
          }

          edges.push({
            id: `edge-suricata-${alert.id}`,
            source: srcId,
            target: destId,
            protocol: alert.proto || 'TCP',
            bytes: 0, // Not always available in alerts
            suspicious: severity === 'Critical' || severity === 'High',
            severity: severity.toLowerCase(),
            type: 'suricata',
            signature: alert.signature
          });
        }

        // Create edges for Wazuh alerts with IP data
        if (alert.source === 'wazuh') {
          const srcIp = alert.src_ip || alert.data?.srcip || alert.agent_ip;
          const destIp = alert.dest_ip || alert.data?.dstip;

          // Only create edge if we have both source and destination IPs
          if (srcIp && destIp && srcIp !== destIp) {
            // Ensure source node exists
            if (!nodesMap.has(srcIp)) {
              const pos = getPosition(srcIp);
              nodesMap.set(srcIp, {
                id: srcIp, label: srcIp, ip: srcIp, role: 'external', critical: false, riskScore: 0,
                isRegistered: false,
                x: pos.x * 5, y: pos.y * 5, z: pos.z * 5
              });
            }
            // Ensure destination node exists
            if (!nodesMap.has(destIp)) {
              const pos = getPosition(destIp);
              nodesMap.set(destIp, {
                id: destIp, label: destIp, ip: destIp, role: 'external', critical: false, riskScore: 0,
                isRegistered: false,
                x: pos.x * 5, y: pos.y * 5, z: pos.z * 5
              });
            }

            edges.push({
              id: `edge-wazuh-${alert.id}`,
              source: srcIp,
              target: destIp,
              protocol: alert.data?.protocol || 'N/A',
              bytes: 0,
              suspicious: severity === 'Critical' || severity === 'High',
              severity: severity.toLowerCase(),
              type: 'wazuh',
              ruleDescription: alert.rule_description
            });
          }
        }

        // --- Enrich ALL nodes with alert counts (including external IPs) ---
        // Count alerts where this IP appears as source or destination
        const srcIp = alert.src_ip || alert.agent_ip || alert.data?.srcip;
        const destIp = alert.dest_ip || alert.data?.dstip;

        // Enrich source node
        if (srcIp && nodesMap.has(srcIp)) {
          const srcNode = nodesMap.get(srcIp);
          // Only count High and Critical alerts to match min_severity configuration
          if (severity === 'Critical' || severity === 'High') {
            srcNode.alertCount = (srcNode.alertCount || 0) + 1;
          }
          if (severity === 'Critical') srcNode.criticalCount = (srcNode.criticalCount || 0) + 1;
          else if (severity === 'High') srcNode.highCount = (srcNode.highCount || 0) + 1;
          else if (severity === 'Medium') srcNode.mediumCount = (srcNode.mediumCount || 0) + 1;
          else srcNode.lowCount = (srcNode.lowCount || 0) + 1;
        }

        // Enrich destination node (if different from source)
        if (destIp && destIp !== srcIp && nodesMap.has(destIp)) {
          const destNode = nodesMap.get(destIp);
          // Only count High and Critical alerts to match min_severity configuration
          if (severity === 'Critical' || severity === 'High') {
            destNode.alertCount = (destNode.alertCount || 0) + 1;
          }
          if (severity === 'Critical') destNode.criticalCount = (destNode.criticalCount || 0) + 1;
          else if (severity === 'High') destNode.highCount = (destNode.highCount || 0) + 1;
          else if (severity === 'Medium') destNode.mediumCount = (destNode.mediumCount || 0) + 1;
          else destNode.lowCount = (destNode.lowCount || 0) + 1;
        }

        // --- Process Incidents ---
        if (severity === 'Critical' || severity === 'High') {
          // Find which node this incident belongs to
          const agentName = alert.agent_name || alert.agent?.name;
          const agentIp = alert.agent_ip || alert.agent?.ip || alert.src_ip;

          let deviceId = agentIp; // Default to IP

          // Try to match with existing node
          for (const [id, node] of nodesMap) {
            if (node.label === agentName || node.ip === agentIp) {
              deviceId = id;
              break;
            }
          }

          incidents.push({
            id: alert.id,
            deviceId: deviceId,
            title: alert.rule_description || alert.signature || 'Security Alert',
            severity: severity,
            model: alert.source === 'wazuh' ? 'SIEM Rule' : 'NIDS Signature',
            summary: alert.full_log || alert.description || 'No details available',
            timestamp: alert.timestamp,
            since: new Date(alert.timestamp).toLocaleTimeString()
          });
        }
      });

      // --- Final Risk Score Calculation for ALL Nodes ---
      // This ensures external IP nodes also get proper risk scores
      nodesMap.forEach((node) => {
        const criticalCount = node.criticalCount || 0;
        const highCount = node.highCount || 0;
        const mediumCount = node.mediumCount || 0;
        const lowCount = node.lowCount || 0;
        const alertCount = node.alertCount || 0;

        // Initialize counts if not set
        node.criticalCount = criticalCount;
        node.highCount = highCount;
        node.mediumCount = mediumCount;
        node.lowCount = lowCount;

        // Skip if already has a calculated risk score from agentStats
        if (node.riskScore > 0) return;

        // Calculate risk score for nodes without one
        let riskScore = 0;

        // 1. Severity Weight (50% of score)
        const severityScore = (criticalCount * 20) + (highCount * 10) + (mediumCount * 4) + (lowCount * 1);
        riskScore += Math.min(severityScore, 50);

        // 2. Alert Volume (25% of score)
        if (alertCount > 0) {
          const volumeScore = Math.min(25, Math.log10(alertCount + 1) * 15);
          riskScore += volumeScore;
        }

        // 3. Diversity Penalty (15% of score)
        const severityLevelsHit = [criticalCount, highCount, mediumCount, lowCount].filter(c => c > 0).length;
        if (severityLevelsHit > 1) {
          riskScore += Math.min(15, severityLevelsHit * 5);
        }

        // 4. Critical threshold escalation
        if (criticalCount > 0 && riskScore < 50) {
          riskScore = 50;
        }

        node.riskScore = Math.min(100, Math.round(riskScore));

        // Mark as critical if has critical/high alerts
        if (criticalCount > 0 || highCount > 0) {
          node.critical = true;
        }

        // Mark as active if has alerts
        node.isActive = node.isActive || alertCount > 0;
      });

      // --- Add/Update Threat Actor Nodes from API ---
      // These are pre-filtered external IPs and internal high-risk hosts
      const threatActors = threatActorsData.threat_actors || [];

      // Build a lookup of registered agents by IP for cross-referencing
      const registeredAgentsByIP = new Map();
      nodesMap.forEach((node, nodeId) => {
        if (node.isRegistered && node.ip) {
          registeredAgentsByIP.set(node.ip, { nodeId, node });
        }
      });

      threatActors.forEach((ta) => {
        let existingNode = nodesMap.get(ta.ip);

        // Also check if a registered agent exists with this IP (stored under different key)
        const registeredMatch = registeredAgentsByIP.get(ta.ip);
        if (registeredMatch) {
          // Update the registered agent with alert data instead of creating a threat node
          const regNode = registeredMatch.node;
          regNode.alertCount = ta.alert_count || 0;
          regNode.criticalCount = ta.critical_count || 0;
          regNode.highCount = ta.high_count || 0;
          regNode.riskScore = Math.max(regNode.riskScore || 0, ta.risk_score || 0);
          regNode.critical = regNode.critical || ta.critical_count > 0;
          regNode.isActive = true;
          regNode.signatures = ta.signatures || [];
          regNode.targets = ta.targets || [];
          // Keep isRegistered=true, don't mark as threat actor
          return; // Skip creating a separate threat node
        }

        // Skip only if this is a REGISTERED agent (don't mark agents as threats)
        if (existingNode && existingNode.isRegistered) {
          return;
        }

        const position = getPosition(ta.ip);

        // If node exists (from alert processing), UPDATE it with threat actor properties
        const threatNode = {
          ...(existingNode || {}),
          id: ta.ip,
          label: ta.ip,
          ip: ta.ip,
          role: ta.is_internal ? 'high-risk-host' : 'threat-actor',
          critical: ta.critical_count > 0,
          riskScore: ta.risk_score,
          alertCount: ta.alert_count,
          criticalCount: ta.critical_count,
          highCount: ta.high_count,
          signatures: ta.signatures || [],
          targets: ta.targets || [],
          firstSeen: ta.first_seen,
          lastSeen: ta.last_seen,
          isRegistered: false,
          isThreatActor: !ta.is_internal,
          isHighRiskHost: ta.is_internal,
          isInternal: ta.is_internal,
          isActive: true,
          x: existingNode?.x ?? position.x,
          y: existingNode?.y ?? position.y,
          z: existingNode?.z ?? position.z,
          position_locked: existingNode?.position_locked ?? position.position_locked
        };

        nodesMap.set(ta.ip, threatNode);
      });

      // --- Apply View Mode Transformations ---
      let finalNodes = Array.from(nodesMap.values());
      let finalEdges = edges;

      // Security View: SIEM-centric radial layout
      const siemNode = finalNodes.find(n => n.role === 'siem');
      if (siemNode) {
        const endpoints = finalNodes.filter(n => n.role !== 'siem' && n.role !== 'external');
        const radius = 30; // Reduced radius for security view

        endpoints.forEach((node, idx) => {
          // Skip nodes with locked positions
          if (node.position_locked) return;

          const angle = (idx / endpoints.length) * Math.PI * 2;
          // Use deterministic elevation based on node id hash instead of random
          const hashCode = node.id.split('').reduce((a, b) => ((a << 5) - a) + b.charCodeAt(0), 0);
          const elevation = ((hashCode % 100) / 100 - 0.5) * 20;

          node.x = radius * Math.cos(angle);
          node.y = elevation;
          node.z = radius * Math.sin(angle);
        });
      }

      // Filter unregistered nodes if toggle is off
      if (!showUnregisteredNodes) {
        finalNodes = finalNodes.filter(node =>
          node.isRegistered ||
          node.type === 'cluster' ||
          node.type === 'segment-diamond' ||
          node.role === 'siem'
        );

        // Filter edges
        const nodeIds = new Set(finalNodes.map(n => n.id));
        finalEdges = finalEdges.filter(edge =>
          nodeIds.has(edge.source) && nodeIds.has(edge.target)
        );
      }

      // Show all nodes (active or not) - removed aggressive active-only filter
      // Nodes are already filtered by registration status above if needed

      // Apply search filter
      if (searchTerm) {
        const lowerSearchTerm = searchTerm.toLowerCase();
        finalNodes = finalNodes.filter(node =>
          node.label?.toLowerCase().includes(lowerSearchTerm) ||
          node.ip?.toLowerCase().includes(lowerSearchTerm) ||
          node.role?.toLowerCase().includes(lowerSearchTerm)
        );

        // Filter edges to only include those connected to remaining nodes
        const nodeIds = new Set(finalNodes.map(n => n.id));
        finalEdges = finalEdges.filter(edge =>
          nodeIds.has(edge.source) && nodeIds.has(edge.target)
        );
      }

      setTopologyData({
        nodes: finalNodes,
        edges: finalEdges,
        incidents: incidents
      });

    } catch (err) {
      console.error('Failed to load data:', err);
    } finally {
      setLoading(false);
    }
  };

  const timeRangeOptions = [
    { value: '1h', text: 'Last 1 Hour' },
    { value: '2h', text: 'Last 2 Hours' },
    { value: '24h', text: 'Last 24 Hours' },
    { value: '7d', text: 'Last 1 Week' },
    { value: '30d', text: 'Last 30 Days' },
  ];

  // Determine overall threat level
  const threatLevel = useMemo(() => {
    if (stats.criticalEndpoints > 0) return { label: 'CRITICAL', color: AGELIA_COLORS.danger, glow: AGELIA_COLORS.dangerGlow };
    if (stats.totalAlerts > 10) return { label: 'ELEVATED', color: AGELIA_COLORS.warning, glow: AGELIA_COLORS.warningGlow };
    if (stats.totalAlerts > 0) return { label: 'GUARDED', color: AGELIA_COLORS.primary, glow: AGELIA_COLORS.primaryGlow };
    return { label: 'NORMAL', color: AGELIA_COLORS.success, glow: AGELIA_COLORS.successGlow };
  }, [stats]);
  const getRiskColor = (score) => {
    if (score >= 70) return 'danger';
    if (score >= 40) return 'warning';
    return 'success';
  };

  const getRiskLabel = (score) => {
    if (score >= 70) return 'Critical';
    if (score >= 40) return 'Elevated';
    if (score > 0) return 'Guarded';
    return 'Normal';
  };

  const getAlertColor = (count) => (count > 0 ? 'danger' : 'success');

  // Helper: Check if IP is private
  const isPrivateIP = (ip) => {
    if (!ip || ip === 'Unknown') return true;
    return ip.startsWith('10.') ||
           ip.startsWith('192.168.') ||
           ip.startsWith('172.16.') ||
           ip.startsWith('172.17.') ||
           ip.startsWith('172.18.') ||
           ip.startsWith('172.19.') ||
           ip.startsWith('172.2') ||
           ip.startsWith('172.30.') ||
           ip.startsWith('172.31.') ||
           ip === '127.0.0.1' ||
           ip === 'localhost';
  };

  // Helper: Create mock event object from node for modals
  const createEventFromNode = useCallback((node) => {
    if (!node) return null;

    // Find incidents related to this node
    const nodeIncidents = topologyData.incidents?.filter(inc =>
      inc.deviceId === node.id ||
      inc.title?.includes(node.label) ||
      inc.title?.includes(node.ip)
    ) || [];

    // Determine source based on node data
    const hasWazuhIncident = nodeIncidents.some(inc => inc.model?.includes('SIEM'));
    const source = hasWazuhIncident ? 'wazuh' : 'suricata';

    return {
      id: `node-${node.id}-${Date.now()}`,
      source: source,
      src_ip: node.ip || 'Unknown',
      dest_ip: node.ip || 'Unknown',
      agent_name: node.label,
      signature: nodeIncidents[0]?.title || `Alerts from ${node.label}`,
      rule_description: nodeIncidents[0]?.title || `Security alerts detected on ${node.label}`,
      rule_id: nodeIncidents[0]?.id || 'topology-action',
      signature_id: nodeIncidents[0]?.id || 'topology-action',
      normalized_severity: node.riskScore >= 70 ? 'Critical' :
                          node.riskScore >= 40 ? 'High' :
                          node.riskScore > 0 ? 'Medium' : 'Low',
      category: node.role || 'endpoint',
      timestamp: new Date().toISOString(),
      full_log: `Node: ${node.label} | IP: ${node.ip} | Risk Score: ${node.riskScore} | Alerts: ${node.alertCount}`
    };
  }, [topologyData.incidents]);

  // Handler: Open Block IP Modal
  const handleOpenBlockIPModal = useCallback((node) => {
    if (!node || !node.ip || node.ip === 'Unknown') {
      return;
    }
    const event = createEventFromNode(node);
    setBlockIPModal({ isOpen: true, event });
  }, [createEventFromNode]);

  // Handler: Close Block IP Modal
  const handleCloseBlockIPModal = useCallback(() => {
    setBlockIPModal({ isOpen: false, event: null });
  }, []);

  // Handler: Block IP Success
  const handleBlockIPSuccess = useCallback(() => {
    // Refresh data after blocking
    loadData(persistedPositionsRef.current);
    setBlockIPModal({ isOpen: false, event: null });
  }, []);

  // Handler: Open Mute Modal
  const handleOpenMuteModal = useCallback((node) => {
    if (!node) return;
    const event = createEventFromNode(node);
    setMuteModal({ isOpen: true, event });
  }, [createEventFromNode]);

  // Handler: Close Mute Modal
  const handleCloseMuteModal = useCallback(() => {
    setMuteModal({ isOpen: false, event: null });
  }, []);

  // Handler: Mute Success
  const handleMuteSuccess = useCallback(() => {
    // Refresh data after muting
    loadData(persistedPositionsRef.current);
    setMuteModal({ isOpen: false, event: null });
  }, []);

  // Handler: Open context menu (from canvas right-click)
  const handleContextMenu = useCallback((node, event) => {
    event.preventDefault();
    setContextMenu({
      isOpen: true,
      position: { x: event.clientX, y: event.clientY },
      node: node
    });
  }, []);

  // Handler: Close context menu
  const handleCloseContextMenu = useCallback(() => {
    setContextMenu(prev => ({ ...prev, isOpen: false }));
  }, []);

  // Handler: Copy IP from context menu
  const handleCopyIP = useCallback((ip) => {
    // IP is copied via the context menu component
  }, []);

  // Handler: Focus node from context menu
  const handleFocusNodeFromMenu = useCallback((node) => {
    if (node && topology2DRef.current) {
      topology2DRef.current.focusOnNode(node.id);
      setSelectedNode(node);
      setAgentDetailOpen(true);
    }
  }, []);

  // Handler: Toggle MITRE overlay
  const handleToggleMitre = useCallback(() => {
    setMitreEnabled(prev => !prev);
    if (mitreEnabled) {
      setSelectedMitreTactic(null);
    }
  }, [mitreEnabled]);

  // Handler: Open pivot menu
  const handleOpenPivotMenu = useCallback((node, event) => {
    setPivotMenu({
      isOpen: true,
      position: { x: event.clientX, y: event.clientY },
      node: node
    });
  }, []);

  // Handler: Close pivot menu
  const handleClosePivotMenu = useCallback(() => {
    setPivotMenu(prev => ({ ...prev, isOpen: false }));
  }, []);

  // Handler: Pivot to IP
  const handlePivotToIP = useCallback((node) => {
    if (node && topology2DRef.current) {
      topology2DRef.current.focusOnNode(node.id);
      setSelectedNode(node);
      setAgentDetailOpen(true);
    }
  }, []);

  // Handler: Pivot to signature - highlight all nodes with that signature
  const handlePivotToSignature = useCallback((signature) => {
    const matchingNodes = topologyData.nodes.filter(n => {
      const nodeIncidents = topologyData.incidents.filter(inc =>
        inc.deviceId === n.id || inc.title?.includes(n.ip)
      );
      return nodeIncidents.some(inc => inc.model?.includes(signature) || inc.title?.includes(signature));
    });
    setHighlightedNodes(matchingNodes.map(n => n.id));
  }, [topologyData]);

  // Handler: Navigate to events page with search
  const handleNavigateToEvents = useCallback((query) => {
    navigate(`/detection/events?search=${encodeURIComponent(query)}`);
  }, [navigate]);

  // Handler: Highlight nodes from IOC search
  const handleHighlightNodes = useCallback((nodeIds) => {
    setHighlightedNodes(nodeIds);
    // Focus on first match if any
    if (nodeIds.length > 0 && topology2DRef.current) {
      topology2DRef.current.focusOnNode(nodeIds[0]);
    }
  }, []);

  // Helper to format agent status for display
  const getStatusDisplay = (node) => {
    if (!node.isRegistered) return { label: 'External', color: '#64748B' };
    const status = String(node.status || '').toLowerCase();
    if (status === 'active' || status === 'connected' || status === 'online') {
      return { label: 'Active', color: '#10B981' };
    }
    if (status === 'disconnected' || status === 'offline') {
      return { label: 'Disconnected', color: '#F59E0B' };
    }
    if (status === 'never_connected' || status === 'pending') {
      return { label: 'Never Connected', color: '#6B7280' };
    }
    return { label: status || 'Unknown', color: '#64748B' };
  };

  const buildAgentDetailItems = (node) => {
    const statusInfo = getStatusDisplay(node);
    return [
      { title: 'Agent ID', description: node.id || node.label || 'Unknown' },
      { title: 'Status', description: statusInfo.label, color: statusInfo.color },
      { title: 'Role', description: node.role || 'Unknown' },
      { title: 'Operating System', description: node.os || 'Unknown' },
      { title: 'IP Address', description: node.ip || 'Unknown' },
      { title: 'Network Segment', description: getNodeSegment(node) },
      { title: 'Registration', description: node.isRegistered ? 'Registered' : 'Derived' },
    ];
  };

  const selectedRiskScore = selectedNode ? Math.min(100, Number(selectedNode.riskScore || 0)) : 0;
  const selectedAlertCount = selectedNode ? Number(selectedNode.alertCount || 0) : 0;
  const selectedAlertGauge = Math.min(100, selectedAlertCount * 12);
  const selectedRiskLabel = getRiskLabel(selectedRiskScore);
  const selectedAccent = selectedRiskScore >= 70
    ? AGELIA_COLORS.danger
    : selectedRiskScore >= 40
      ? AGELIA_COLORS.warning
      : AGELIA_COLORS.primary;
  const selectedInitial = selectedNode
    ? String(selectedNode.label || selectedNode.id || '?').charAt(0).toUpperCase()
    : '?';

  return (
    <EuiErrorBoundary>
      <EuiPage paddingSize="none" style={{ background: AGELIA_COLORS.background, minHeight: '100vh', display: 'flex', flexDirection: 'column' }}>

        {/* Header Bar */}
        <div style={{
          height: '56px',
          background: AGELIA_COLORS.panel,
          borderBottom: `1px solid ${AGELIA_COLORS.border}`,
          display: 'flex',
          alignItems: 'center',
          padding: '0 24px',
          justifyContent: 'space-between',
          zIndex: 10
        }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
            <Network size={22} color={AGELIA_COLORS.accent} />
            <h1 style={{ color: AGELIA_COLORS.text, fontSize: '16px', fontWeight: 600, margin: 0, fontFamily: 'Inter, sans-serif' }}>Threat Topology</h1>
          </div>

          <div style={{ display: 'flex', alignItems: 'center', gap: '16px' }}>
            {/* Auto-Refresh Controls */}
            <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
              <EuiToolTip content={autoRefresh ? `Auto-refreshing every ${refreshInterval / 1000}s` : 'Enable auto-refresh'}>
                <EuiSwitch
                  label=""
                  checked={autoRefresh}
                  onChange={(e) => setAutoRefresh(e.target.checked)}
                  compressed
                />
              </EuiToolTip>
              {autoRefresh && (
                <EuiSelect
                  options={[
                    { value: '15000', text: '15s' },
                    { value: '30000', text: '30s' },
                    { value: '60000', text: '60s' },
                  ]}
                  value={String(refreshInterval)}
                  onChange={(e) => setRefreshInterval(Number(e.target.value))}
                  compressed
                  style={{ width: '70px' }}
                />
              )}
              <EuiIcon type={iconClock} color={autoRefresh ? AGELIA_COLORS.success : AGELIA_COLORS.textSecondary} />
            </div>

            {/* Time Range Selector */}
            <EuiSelect
              options={timeRangeOptions}
              value={timeRange}
              onChange={(e) => handleTimeRangeChange(e.target.value)}
              compressed
              style={{ width: '150px' }}
            />
          </div>
        </div>

        {/* Zone-Aligned Stats Bar */}
        <div style={{
          background: AGELIA_COLORS.background,
          padding: '16px 24px',
          display: 'flex',
          gap: '16px',
          borderBottom: `1px solid ${AGELIA_COLORS.border}`,
        }}>
          {/* Protected Zone Card */}
          <div style={{
            flex: 1,
            background: AGELIA_COLORS.panel,
            borderRadius: '12px',
            padding: '14px 18px',
            borderLeft: '4px solid #10B981',
            border: '1px solid rgba(16, 185, 129, 0.2)',
          }}>
            <div style={{
              display: 'flex',
              alignItems: 'center',
              gap: '8px',
              marginBottom: '8px',
            }}>
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none">
                <path d="M12 2L4 6v6c0 5.5 3.5 10.7 8 12 4.5-1.3 8-6.5 8-12V6l-8-4z" fill="#10B981" fillOpacity="0.2" stroke="#10B981" strokeWidth="2"/>
              </svg>
              <span style={{ fontSize: '11px', fontWeight: 600, color: '#10B981', textTransform: 'uppercase', letterSpacing: '0.5px' }}>
                Protected Zone
              </span>
            </div>

            <div style={{ display: 'flex', alignItems: 'baseline', gap: '12px' }}>
              <span style={{ fontSize: '28px', fontWeight: 700, color: AGELIA_COLORS.text, fontFamily: 'Inter, sans-serif' }}>
                {stats.totalEndpoints}
              </span>
              <span style={{ fontSize: '12px', color: AGELIA_COLORS.textSecondary }}>agents</span>
            </div>

            <div style={{ display: 'flex', gap: '16px', marginTop: '8px' }}>
              <EuiToolTip position="top" content={`${stats.activeAgents} agents actively connected and reporting`}>
                <div style={{ display: 'flex', alignItems: 'center', gap: '6px', cursor: 'help' }}>
                  <span style={{
                    width: '8px',
                    height: '8px',
                    borderRadius: '50%',
                    background: '#10B981',
                    boxShadow: '0 0 6px rgba(16, 185, 129, 0.6)',
                  }} />
                  <span style={{ fontSize: '12px', color: '#10B981', fontWeight: 500 }}>{stats.activeAgents} Active</span>
                </div>
              </EuiToolTip>
              {stats.disconnectedAgents > 0 && (
                <EuiToolTip position="top" content={`${stats.disconnectedAgents} agents disconnected or offline`}>
                  <div style={{ display: 'flex', alignItems: 'center', gap: '6px', cursor: 'help' }}>
                    <span style={{
                      width: '8px',
                      height: '8px',
                      borderRadius: '50%',
                      background: '#F59E0B',
                      boxShadow: '0 0 6px rgba(245, 158, 11, 0.6)',
                    }} />
                    <span style={{ fontSize: '12px', color: '#F59E0B', fontWeight: 500 }}>{stats.disconnectedAgents} Disconnected</span>
                  </div>
                </EuiToolTip>
              )}
              {stats.neverConnectedAgents > 0 && (
                <EuiToolTip position="top" content={`${stats.neverConnectedAgents} agents registered but never connected`}>
                  <div style={{ display: 'flex', alignItems: 'center', gap: '6px', cursor: 'help' }}>
                    <span style={{
                      width: '8px',
                      height: '8px',
                      borderRadius: '50%',
                      background: '#6B7280',
                      border: '1px dashed #9CA3AF',
                    }} />
                    <span style={{ fontSize: '12px', color: '#6B7280', fontWeight: 500 }}>{stats.neverConnectedAgents} Pending</span>
                  </div>
                </EuiToolTip>
              )}
            </div>

            {/* Alert summary */}
            <div style={{
              marginTop: '10px',
              paddingTop: '10px',
              borderTop: '1px solid rgba(255,255,255,0.08)',
              display: 'flex',
              gap: '12px',
              fontSize: '11px',
            }}>
              <span style={{ color: AGELIA_COLORS.textSecondary }}>{stats.highCriticalAlerts} alerts</span>
              {stats.criticalAlerts > 0 && (
                <span style={{ color: '#EF4444', fontWeight: 600 }}>{stats.criticalAlerts} critical</span>
              )}
              {stats.highAlerts > 0 && (
                <span style={{ color: '#F97316', fontWeight: 500 }}>{stats.highAlerts} high</span>
              )}
            </div>
          </div>

          {/* Threat Zone Card */}
          <div style={{
            flex: 1,
            background: AGELIA_COLORS.panel,
            borderRadius: '12px',
            padding: '14px 18px',
            borderLeft: '4px solid #EF4444',
            border: '1px solid rgba(239, 68, 68, 0.2)',
          }}>
            <div style={{
              display: 'flex',
              alignItems: 'center',
              gap: '8px',
              marginBottom: '8px',
            }}>
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none">
                <path d="M12 2L2 22h20L12 2z" fill="#EF4444" fillOpacity="0.2" stroke="#EF4444" strokeWidth="2"/>
                <path d="M12 9v4M12 17h.01" stroke="#EF4444" strokeWidth="2" strokeLinecap="round"/>
              </svg>
              <span style={{ fontSize: '11px', fontWeight: 600, color: '#EF4444', textTransform: 'uppercase', letterSpacing: '0.5px' }}>
                Threat Zone
              </span>
            </div>

            <div style={{ display: 'flex', alignItems: 'baseline', gap: '12px' }}>
              <span style={{
                fontSize: '28px',
                fontWeight: 700,
                color: stats.activeThreats > 0 ? '#EF4444' : AGELIA_COLORS.text,
                fontFamily: 'Inter, sans-serif'
              }}>
                {stats.activeThreats}
              </span>
              <span style={{ fontSize: '12px', color: AGELIA_COLORS.textSecondary }}>threats</span>
            </div>

            <div style={{ display: 'flex', gap: '16px', marginTop: '8px', flexWrap: 'wrap' }}>
              {stats.activeThreats > 0 ? (
                <>
                  <EuiToolTip position="top" content={`${stats.externalThreatActors} external threat actors (public IPs attacking your network)`}>
                    <div style={{ display: 'flex', alignItems: 'center', gap: '6px', cursor: 'help' }}>
                      <span style={{
                        width: '8px',
                        height: '8px',
                        borderRadius: '50%',
                        background: stats.externalThreatActors > 0 ? '#EF4444' : '#4B5563',
                        boxShadow: stats.externalThreatActors > 0 ? '0 0 6px rgba(239, 68, 68, 0.6)' : 'none',
                      }} />
                      <span style={{ fontSize: '12px', color: stats.externalThreatActors > 0 ? '#EF4444' : '#6B7280', fontWeight: 500 }}>
                        {stats.externalThreatActors} External
                      </span>
                    </div>
                  </EuiToolTip>
                  <EuiToolTip position="top" content={`${stats.internalHighRiskHosts} internal high-risk hosts (private IPs not registered as agents)`}>
                    <div style={{ display: 'flex', alignItems: 'center', gap: '6px', cursor: 'help' }}>
                      <span style={{
                        width: '8px',
                        height: '8px',
                        borderRadius: '50%',
                        background: stats.internalHighRiskHosts > 0 ? '#F97316' : '#4B5563',
                        boxShadow: stats.internalHighRiskHosts > 0 ? '0 0 6px rgba(249, 115, 22, 0.6)' : 'none',
                      }} />
                      <span style={{ fontSize: '12px', color: stats.internalHighRiskHosts > 0 ? '#F97316' : '#6B7280', fontWeight: 500 }}>
                        {stats.internalHighRiskHosts} Internal
                      </span>
                    </div>
                  </EuiToolTip>
                </>
              ) : (
                <span style={{ fontSize: '12px', color: '#10B981', fontWeight: 500 }}>No active threats</span>
              )}
            </div>

            {/* Top threat actor and last alert time */}
            <div style={{
              marginTop: '10px',
              paddingTop: '10px',
              borderTop: '1px solid rgba(255,255,255,0.08)',
              fontSize: '11px',
            }}>
              {stats.topThreatActor ? (
                <div style={{ display: 'flex', flexDirection: 'column', gap: '4px' }}>
                  <EuiToolTip position="top" content={`Top threat actor by alert count: ${stats.topThreatActor.alertCount} alerts`}>
                    <div style={{ display: 'flex', alignItems: 'center', gap: '6px', cursor: 'help' }}>
                      <span style={{ color: AGELIA_COLORS.textSecondary }}>Top:</span>
                      <span style={{
                        color: '#EF4444',
                        fontWeight: 600,
                        fontFamily: 'monospace',
                        fontSize: '11px',
                      }}>
                        {stats.topThreatActor.ip}
                      </span>
                      <span style={{
                        background: 'rgba(239, 68, 68, 0.2)',
                        color: '#EF4444',
                        padding: '1px 6px',
                        borderRadius: '10px',
                        fontSize: '10px',
                        fontWeight: 600,
                      }}>
                        {stats.topThreatActor.alertCount}
                      </span>
                    </div>
                  </EuiToolTip>
                  {stats.lastAlertTime && (
                    <div style={{ display: 'flex', alignItems: 'center', gap: '6px' }}>
                      <span style={{ color: AGELIA_COLORS.textSecondary }}>Last seen:</span>
                      <span style={{ color: '#F97316', fontWeight: 500 }}>{stats.lastAlertTime}</span>
                    </div>
                  )}
                </div>
              ) : (
                <span style={{ color: AGELIA_COLORS.textSecondary }}>{stats.externalIPs} threat IPs detected</span>
              )}
            </div>
          </div>

          {/* Attack Intelligence Card */}
          <div style={{
            flex: 1.2,
            background: AGELIA_COLORS.panel,
            borderRadius: '12px',
            padding: '14px 18px',
            borderLeft: '4px solid #8B5CF6',
            border: '1px solid rgba(139, 92, 246, 0.2)',
          }}>
            <div style={{
              display: 'flex',
              alignItems: 'center',
              gap: '8px',
              marginBottom: '8px',
            }}>
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none">
                <circle cx="12" cy="12" r="10" fill="#8B5CF6" fillOpacity="0.2" stroke="#8B5CF6" strokeWidth="2"/>
                <circle cx="12" cy="12" r="3" fill="#8B5CF6"/>
                <path d="M12 2v4M12 18v4M2 12h4M18 12h4" stroke="#8B5CF6" strokeWidth="2" strokeLinecap="round"/>
              </svg>
              <span style={{ fontSize: '11px', fontWeight: 600, color: '#8B5CF6', textTransform: 'uppercase', letterSpacing: '0.5px' }}>
                Attack Intelligence
              </span>
            </div>

            <div style={{ display: 'flex', alignItems: 'baseline', gap: '12px' }}>
              <span style={{ fontSize: '28px', fontWeight: 700, color: AGELIA_COLORS.text, fontFamily: 'Inter, sans-serif' }}>
                {stats.totalAlerts}
              </span>
              <span style={{ fontSize: '12px', color: AGELIA_COLORS.textSecondary }}>total alerts</span>
            </div>

            {/* Data Sources Health */}
            <div style={{ display: 'flex', gap: '16px', marginTop: '8px' }}>
              <EuiToolTip position="top" content={`${stats.dataSourceHealth.wazuhCount} alerts from Wazuh SIEM`}>
                <div style={{ display: 'flex', alignItems: 'center', gap: '6px', cursor: 'help' }}>
                  <span style={{
                    fontSize: '12px',
                    color: stats.dataSourceHealth.wazuh ? '#10B981' : '#6B7280',
                    fontWeight: 500
                  }}>
                    {stats.dataSourceHealth.wazuh ? '✓' : '○'} Wazuh
                  </span>
                  <span style={{
                    fontSize: '11px',
                    color: stats.dataSourceHealth.wazuh ? '#10B981' : '#4B5563',
                    fontWeight: 600
                  }}>
                    {stats.dataSourceHealth.wazuhCount}
                  </span>
                </div>
              </EuiToolTip>
              <EuiToolTip position="top" content={`${stats.dataSourceHealth.suricataCount} alerts from Suricata NIDS`}>
                <div style={{ display: 'flex', alignItems: 'center', gap: '6px', cursor: 'help' }}>
                  <span style={{
                    fontSize: '12px',
                    color: stats.dataSourceHealth.suricata ? '#10B981' : '#6B7280',
                    fontWeight: 500
                  }}>
                    {stats.dataSourceHealth.suricata ? '✓' : '○'} Suricata
                  </span>
                  <span style={{
                    fontSize: '11px',
                    color: stats.dataSourceHealth.suricata ? '#10B981' : '#4B5563',
                    fontWeight: 600
                  }}>
                    {stats.dataSourceHealth.suricataCount}
                  </span>
                </div>
              </EuiToolTip>
            </div>

            {/* Top Attack Categories */}
            <div style={{
              marginTop: '10px',
              paddingTop: '10px',
              borderTop: '1px solid rgba(255,255,255,0.08)',
              fontSize: '11px',
            }}>
              {stats.topAttackCategories && stats.topAttackCategories.length > 0 ? (
                <div style={{ display: 'flex', flexDirection: 'column', gap: '4px' }}>
                  <span style={{ color: AGELIA_COLORS.textSecondary, fontSize: '10px', marginBottom: '2px' }}>Top Attack Types:</span>
                  {stats.topAttackCategories.map((cat, idx) => (
                    <div key={idx} style={{ display: 'flex', alignItems: 'center', gap: '6px' }}>
                      <span style={{
                        width: '4px',
                        height: '4px',
                        borderRadius: '50%',
                        background: idx === 0 ? '#8B5CF6' : idx === 1 ? '#A78BFA' : '#C4B5FD',
                      }} />
                      <span style={{ color: AGELIA_COLORS.text, fontSize: '11px', fontWeight: 500 }}>
                        {cat.category}
                      </span>
                      <span style={{
                        background: 'rgba(139, 92, 246, 0.2)',
                        color: '#8B5CF6',
                        padding: '1px 6px',
                        borderRadius: '10px',
                        fontSize: '10px',
                        fontWeight: 600,
                        marginLeft: 'auto'
                      }}>
                        {cat.count}
                      </span>
                    </div>
                  ))}
                </div>
              ) : (
                <span style={{ color: AGELIA_COLORS.textSecondary }}>No attack data</span>
              )}
            </div>
          </div>

          {/* Risk Score Card */}
          <div style={{
            width: '180px',
            background: AGELIA_COLORS.panel,
            borderRadius: '12px',
            padding: '14px 18px',
            borderLeft: `4px solid ${stats.riskScore >= 80 ? '#EF4444' : stats.riskScore >= 60 ? '#F97316' : stats.riskScore >= 40 ? '#F59E0B' : '#10B981'}`,
            border: `1px solid ${stats.riskScore >= 80 ? 'rgba(239, 68, 68, 0.2)' : stats.riskScore >= 60 ? 'rgba(249, 115, 22, 0.2)' : stats.riskScore >= 40 ? 'rgba(245, 158, 11, 0.2)' : 'rgba(16, 185, 129, 0.2)'}`,
            display: 'flex',
            flexDirection: 'column',
            alignItems: 'center',
            justifyContent: 'center',
          }}>
            <span style={{ fontSize: '11px', fontWeight: 600, color: AGELIA_COLORS.textSecondary, textTransform: 'uppercase', letterSpacing: '0.5px', marginBottom: '8px' }}>
              Risk Score
            </span>

            {/* Circular Gauge */}
            <div style={{ position: 'relative', width: '64px', height: '64px' }}>
              <svg width="64" height="64" viewBox="0 0 64 64">
                {/* Background circle */}
                <circle
                  cx="32"
                  cy="32"
                  r="28"
                  fill="none"
                  stroke="rgba(255,255,255,0.1)"
                  strokeWidth="6"
                />
                {/* Progress arc */}
                <circle
                  cx="32"
                  cy="32"
                  r="28"
                  fill="none"
                  stroke={stats.riskScore >= 80 ? '#EF4444' : stats.riskScore >= 60 ? '#F97316' : stats.riskScore >= 40 ? '#F59E0B' : '#10B981'}
                  strokeWidth="6"
                  strokeLinecap="round"
                  strokeDasharray={`${(stats.riskScore / 100) * 176} 176`}
                  transform="rotate(-90 32 32)"
                  style={{
                    filter: `drop-shadow(0 0 8px ${stats.riskScore >= 80 ? 'rgba(239, 68, 68, 0.6)' : stats.riskScore >= 60 ? 'rgba(249, 115, 22, 0.6)' : stats.riskScore >= 40 ? 'rgba(245, 158, 11, 0.6)' : 'rgba(16, 185, 129, 0.6)'})`,
                    transition: 'stroke-dasharray 0.5s ease',
                  }}
                />
              </svg>
              {/* Score text */}
              <div style={{
                position: 'absolute',
                top: '50%',
                left: '50%',
                transform: 'translate(-50%, -50%)',
                textAlign: 'center',
              }}>
                <span style={{
                  fontSize: '18px',
                  fontWeight: 700,
                  color: stats.riskScore >= 80 ? '#EF4444' : stats.riskScore >= 60 ? '#F97316' : stats.riskScore >= 40 ? '#F59E0B' : '#10B981',
                  fontFamily: 'Inter, sans-serif',
                }}>
                  {stats.riskScore}
                </span>
              </div>
            </div>

            {/* Risk Level Label */}
            <span style={{
              marginTop: '8px',
              fontSize: '12px',
              fontWeight: 700,
              color: stats.riskScore >= 80 ? '#EF4444' : stats.riskScore >= 60 ? '#F97316' : stats.riskScore >= 40 ? '#F59E0B' : '#10B981',
              textTransform: 'uppercase',
              letterSpacing: '0.5px',
            }}>
              {stats.riskLevel}
            </span>
          </div>
        </div>

        {/* Main Content Area */}
        <div style={{ flex: 1, position: 'relative', overflow: 'hidden' }}>

          {/* Topology Canvas */}
          <div style={{ flex: 1, position: 'relative' }}>
            {loading && (
              <div style={{
                position: 'absolute', top: '50%', left: '50%', transform: 'translate(-50%, -50%)',
                zIndex: 20, color: '#fff', display: 'flex', flexDirection: 'column', alignItems: 'center'
              }}>
                <EuiLoadingSpinner size="xl" />
                <EuiSpacer />
                <EuiText>Loading Network Topology...</EuiText>
              </div>
            )}

            {!loading && topologyData.nodes.length === 0 ? (
              <div style={{
                position: 'absolute', top: '50%', left: '50%', transform: 'translate(-50%, -50%)',
                zIndex: 20
              }}>
                <EuiEmptyPrompt
                  icon={<Network size={48} color="#64748B" />}
                  title={<h2>No Network Data Found</h2>}
                  body={<p>No alerts or network flows detected in the selected time range.</p>}
                  actions={<EuiButton color="primary" fill onClick={loadData}>Refresh Data</EuiButton>}
                />
              </div>
            ) : (
              <NetworkTopology2D
                ref={topology2DRef}
                topology={topologyData}
                onSelectNode={handleSelectNode}
                selectedNodeId={selectedNode?.id}
                onNodeContextMenu={handleContextMenu}
                viewMode={viewMode}
                onViewModeChange={handleViewModeChange}
                showUnregistered={showUnregisteredNodes}
                onShowUnregisteredChange={(value) => {
                  setShowUnregisteredNodes(value);
                  initialLoadDone.current = false;
                }}
                onRefresh={() => loadData(persistedPositionsRef.current)}
                onSaveLayout={saveTopologyLayout}
                hasUnsavedChanges={hasUnsavedChanges}
                saving={saving}
              />
            )}

          {/* Floating Agent Detail Flyout - appears over topology when node selected */}
          {showAgentFlyout && selectedNode && (
            <div
              style={{
                position: 'absolute',
                top: '24px',
                right: '24px',
                width: '360px',
                maxWidth: '90%',
                zIndex: 15,
              }}
            >
              <div
                style={{
                  position: 'relative',
                  padding: '16px',
                  borderRadius: '18px',
                  border: '1px solid rgba(148, 163, 184, 0.3)',
                  background: 'linear-gradient(145deg, rgba(15, 23, 42, 0.96), rgba(2, 6, 23, 0.94))',
                  boxShadow: '0 22px 50px rgba(2, 6, 23, 0.65), 0 0 30px rgba(56, 189, 248, 0.12)',
                  backdropFilter: 'blur(10px)',
                }}
              >
                <div
                  style={{
                    position: 'absolute',
                    inset: 0,
                    borderRadius: '18px',
                    background: 'radial-gradient(circle at 15% 20%, rgba(56, 189, 248, 0.14), transparent 55%), radial-gradient(circle at 85% 0%, rgba(168, 85, 247, 0.14), transparent 50%)',
                    pointerEvents: 'none',
                  }}
                />
                <div
                  style={{
                    position: 'absolute',
                    top: 0,
                    left: 0,
                    right: 0,
                    height: '3px',
                    borderRadius: '18px 18px 0 0',
                    background: 'linear-gradient(90deg, rgba(56, 189, 248, 0.9), rgba(168, 85, 247, 0.75), rgba(236, 72, 153, 0.7))',
                  }}
                />
                <div style={{ position: 'relative', zIndex: 1 }}>
                  <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: '12px' }}>
                    <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
                      <div
                        style={{
                          width: '52px',
                          height: '52px',
                          borderRadius: '16px',
                          background: `linear-gradient(135deg, ${selectedAccent}40, ${selectedAccent}10)`,
                          border: `1px solid ${selectedAccent}80`,
                          boxShadow: `0 0 18px ${selectedAccent}55`,
                          display: 'flex',
                          alignItems: 'center',
                          justifyContent: 'center',
                          color: '#F8FAFC',
                          fontWeight: 700,
                          fontSize: '20px',
                        }}
                      >
                        {selectedInitial}
                      </div>
                      <div>
                        <div style={{ color: '#F8FAFC', fontSize: '15px', fontWeight: 700 }}>
                          {selectedNode.label || selectedNode.id}
                        </div>
                        <div style={{ color: '#94A3B8', fontSize: '12px' }}>
                          {String(selectedNode.role || 'Endpoint').toUpperCase()} -{' '}
                          {selectedNode.ip && selectedNode.ip !== 'Unknown' ? (
                            <IPEnrichmentTooltip ipAddress={selectedNode.ip} isPrivateIP={isPrivateIP(selectedNode.ip)}>
                              <span style={{ color: '#60a5fa', cursor: 'pointer' }}>{selectedNode.ip}</span>
                            </IPEnrichmentTooltip>
                          ) : (
                            'Unknown IP'
                          )}
                        </div>
                      </div>
                    </div>
                    <EuiButtonIcon
                      iconType={iconCross}
                      aria-label="Close agent details"
                      onClick={() => setAgentDetailOpen(false)}
                      color="text"
                    />
                  </div>

                  <div style={{ display: 'flex', alignItems: 'center', gap: '8px', flexWrap: 'wrap', marginTop: '12px' }}>
                    <EuiBadge color={getRiskColor(selectedRiskScore)}>{selectedRiskLabel}</EuiBadge>
                    <EuiBadge color={getAlertColor(selectedAlertCount)}>{selectedAlertCount} alerts</EuiBadge>
                    <EuiBadge color={selectedNode.isRegistered ? 'primary' : 'hollow'}>
                      {selectedNode.isRegistered ? 'Registered' : 'External'}
                    </EuiBadge>
                    {(() => {
                      const statusInfo = getStatusDisplay(selectedNode);
                      const healthColor = statusInfo.label === 'Active' ? 'success'
                        : statusInfo.label === 'Disconnected' ? 'warning'
                        : statusInfo.label === 'External' ? 'subdued'
                        : 'subdued';
                      return (
                        <EuiHealth color={healthColor}>
                          {statusInfo.label}
                        </EuiHealth>
                      );
                    })()}
                  </div>

                  <EuiSpacer size="s" />

                  <div>
                    <div style={{ fontSize: '11px', color: '#94A3B8', marginBottom: '4px' }}>Risk Score</div>
                    <EuiProgress value={selectedRiskScore} max={100} color={getRiskColor(selectedRiskScore)} size="s" />
                    <div style={{ fontSize: '11px', color: '#94A3B8', marginTop: '10px', marginBottom: '4px' }}>Alert Activity</div>
                    <EuiProgress value={selectedAlertGauge} max={100} color={getAlertColor(selectedAlertCount)} size="s" />
                  </div>

                  <EuiSpacer size="s" />

                  <EuiDescriptionList
                    listItems={buildAgentDetailItems(selectedNode)}
                    type="column"
                    compressed
                  />

                  <EuiSpacer size="s" />

                  {/* Quick Actions - Response */}
                  <div style={{
                    marginTop: '12px',
                    paddingTop: '12px',
                    borderTop: '1px solid rgba(148, 163, 184, 0.2)'
                  }}>
                    <div style={{ fontSize: '11px', color: '#94A3B8', marginBottom: '8px', fontWeight: 600 }}>
                      QUICK ACTIONS
                    </div>
                    <div style={{ display: 'flex', gap: '8px', flexWrap: 'wrap' }}>
                      <EuiButton
                        size="s"
                        color="danger"
                        iconType={iconLock}
                        onClick={() => handleOpenBlockIPModal(selectedNode)}
                        disabled={!selectedNode.ip || selectedNode.ip === 'Unknown' || isPrivateIP(selectedNode.ip)}
                      >
                        Block IP
                      </EuiButton>
                      <EuiButton
                        size="s"
                        iconType={iconBellSlash}
                        onClick={() => handleOpenMuteModal(selectedNode)}
                        disabled={!selectedNode.alertCount || selectedNode.alertCount === 0}
                      >
                        Mute ({selectedNode.alertCount || 0})
                      </EuiButton>
                    </div>
                  </div>

                  <EuiSpacer size="s" />

                  {/* Navigation Actions */}
                  <div style={{ display: 'flex', gap: '8px', flexWrap: 'wrap' }}>
                    <EuiButton
                      size="s"
                      color="primary"
                      iconType={iconSearch}
                      onClick={() => navigate(`/detection/events?agent=${encodeURIComponent(String(selectedNode.label || selectedNode.id || ''))}`)}
                    >
                      View Alerts
                    </EuiButton>
                    <EuiButton
                      size="s"
                      iconType={iconEye}
                      onClick={() => topology2DRef.current?.focusOnNode(selectedNode.id)}
                    >
                      Focus Node
                    </EuiButton>
                  </div>
                </div>
              </div>
            </div>
          )}
          </div>
        </div>

      </EuiPage>

      {/* Pivot Menu for Hunting */}
      {pivotMenu.isOpen && (
        <PivotMenu
          node={pivotMenu.node}
          topology={topologyData}
          isOpen={pivotMenu.isOpen}
          position={pivotMenu.position}
          onClose={handleClosePivotMenu}
          onPivotToIP={handlePivotToIP}
          onPivotToSignature={handlePivotToSignature}
        />
      )}

      {/* Response Action Modals */}
      <BlockIPModal
        isOpen={blockIPModal.isOpen}
        onClose={handleCloseBlockIPModal}
        event={blockIPModal.event}
        onBlockSuccess={handleBlockIPSuccess}
      />

      <MuteAlertModal
        isOpen={muteModal.isOpen}
        onClose={handleCloseMuteModal}
        event={muteModal.event}
        onMuteSuccess={handleMuteSuccess}
      />

      {/* Node Context Menu */}
      <NodeContextMenu
        isOpen={contextMenu.isOpen}
        position={contextMenu.position}
        node={contextMenu.node}
        onClose={handleCloseContextMenu}
        onBlockIP={handleOpenBlockIPModal}
        onMuteAlerts={handleOpenMuteModal}
        onFocusNode={handleFocusNodeFromMenu}
        onCopyIP={handleCopyIP}
      />

      {/* Toast notifications */}
      <Toaster position="top-right" />
    </EuiErrorBoundary>
  );
};

const DetailItem = ({ label, value, highlight }) => (
  <div style={{ background: '#0b1628', padding: '10px 12px', borderRadius: '6px' }}>
    <div style={{ fontSize: '10px', color: '#8e9fbc', marginBottom: '4px', textTransform: 'uppercase' }}>{label}</div>
    <div style={{ fontSize: '14px', color: highlight ? '#f6726a' : '#ffffff', fontWeight: 500 }}>
      {value !== undefined && value !== null && value !== '' ? value : 'N/A'}
    </div>
  </div>
);

export default ThreatLandscape;
