import React, { useState, useEffect, useMemo, useCallback, useRef } from 'react';
import { useLocation } from 'react-router-dom';
import {
  EuiPage,
  EuiPageBody,
  EuiPageHeader,
  EuiFlexGroup,
  EuiFlexItem,
  EuiPanel,
  EuiStat,
  EuiButton,
  EuiButtonEmpty,
  EuiFieldSearch,
  EuiSelect,
  EuiSwitch,
  EuiBasicTable,
  EuiText,
  EuiSpacer,
  EuiEmptyPrompt,
  EuiLoadingSpinner,
  EuiBadge,
  EuiToolTip,
  EuiSuperDatePicker
} from '@elastic/eui';
import { Shield, VolumeX } from 'lucide-react';
import { fetchUnifiedAlerts } from '../../services/detectionApi';
import toast from 'react-hot-toast';
import MuteAlertModal from '../../components/MuteAlertModal';
import BlockIPModal from '../../components/BlockIPModal';
import BulkActionModal from '../../components/BulkActionModal';
import IPEnrichmentTooltip from '../../components/IPEnrichmentTooltip';
import WazuhExpandedRow from '../../components/detection/WazuhExpandedRow';
import SuricataExpandedRow from '../../components/detection/SuricataExpandedRow';
import ActionCell from '../../components/detection/ActionCell';

const Events = () => {
  const location = useLocation();

  const [events, setEvents] = useState([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [searchInput, setSearchInput] = useState(''); // Separate state for input to enable debouncing
  const [severityFilter, setSeverityFilter] = useState('all');
  const [sourceFilter, setSourceFilter] = useState('all');
  // Time range state for EuiSuperDatePicker (supports custom dates)
  const [timeRangeStart, setTimeRangeStart] = useState('now-24h');
  const [timeRangeEnd, setTimeRangeEnd] = useState('now');
  const [autoRefresh, setAutoRefresh] = useState(true);
  const [mutedAlerts, setMutedAlerts] = useState(new Set());
  const [expandedRows, setExpandedRows] = useState(new Set());
  const [muteModal, setMuteModal] = useState({ show: false, event: null });
  const [blockIPModal, setBlockIPModal] = useState({ show: false, event: null });

  // Bulk action state
  const [selectedItems, setSelectedItems] = useState([]);
  const [bulkActionModal, setBulkActionModal] = useState({ show: false, actionType: null });

  // Pagination & Sorting state
  const [pageIndex, setPageIndex] = useState(0);
  const [totalCount, setTotalCount] = useState(0);
  const [pageSize, setPageSize] = useState(20); // Reduced from 50 for better pagination performance
  const [sortField, setSortField] = useState('timestamp');
  const [sortDirection, setSortDirection] = useState('desc');
  const pageSizeOptions = [20, 50, 100];

  // Refresh trigger to force data re-fetch after actions
  const [refreshTrigger, setRefreshTrigger] = useState(0);

  const [statistics, setStatistics] = useState({
    by_severity: { Critical: 0, High: 0, Medium: 0, Low: 0 },
    by_source: { wazuh: 0, suricata: 0 }
  });

  // Debounce timer ref
  const searchDebounceTimer = useRef(null);

  // Check for alert query parameter on mount
  useEffect(() => {
    const params = new URLSearchParams(location.search);
    const alertId = params.get('alert');
    if (alertId) {
      // Set search term to the alert ID to filter results
      setSearchTerm(alertId);
      setSearchInput(alertId);
      // Show notification that we're filtering by alert
      toast.success(`Filtering by alert: ${alertId}`, { duration: 3000 });
    }
  }, [location.search]);

  // Helper: Get relative time (memoized)
  const getRelativeTime = useCallback((dateString) => {
    const date = new Date(dateString);
    const now = new Date();
    const diffMs = now - date;
    const diffMins = Math.floor(diffMs / 60000);
    const diffHours = Math.floor(diffMs / 3600000);
    const diffDays = Math.floor(diffMs / 86400000);

    if (diffMins < 1) return 'Just now';
    if (diffMins < 60) return `${diffMins}m ago`;
    if (diffHours < 24) return `${diffHours}h ago`;
    return `${diffDays}d ago`;
  }, []);

  // Helper: Get severity color (memoized)
  const getSeverityColor = useCallback((severity) => {
    const normalized = severity?.toLowerCase() || 'low';
    const colors = {
      critical: 'danger',
      high: 'warning',
      medium: '#FF9830', // Orange color instead of yellow
      low: 'primary'
    };
    return colors[normalized] || 'default';
  }, []);

  // Toggle expanded row (memoized)
  const toggleExpandRow = useCallback((id) => {
    setExpandedRows(prev => {
      const newSet = new Set(prev);
      if (newSet.has(id)) {
        newSet.delete(id);
      } else {
        newSet.add(id);
      }
      return newSet;
    });
  }, []);

  // Handle mute - open modal (memoized)
  const handleMute = useCallback((e, alertId) => {
    e.stopPropagation();
    const event = events.find(ev => ev.id === alertId);
    if (event) {
      setMuteModal({ show: true, event: event });
    }
  }, [events]);

  // Handle mute success callback (memoized)
  const handleMuteSuccess = useCallback((mutedAlertId) => {
    // Add to client-side muted set for immediate UI update
    if (mutedAlertId) {
      setMutedAlerts(prev => {
        const newSet = new Set(prev);
        newSet.add(mutedAlertId);
        return newSet;
      });
    }

    // Refresh alerts after mute rule is created
    setRefreshTrigger(prev => prev + 1);
  }, []);

  // Handle block IP - open modal (memoized)
  const handleBlockIP = useCallback((event) => {
    // Check if event has valid IP
    let hasIP = false;

    // Both Suricata and Wazuh now have normalized src_ip field at top level
    if (event.src_ip && event.src_ip !== 'Unknown') {
      hasIP = true;
    }

    if (!hasIP) {
      toast.error('No valid IP address found in this alert');
      return;
    }

    setBlockIPModal({ show: true, event: event });
  }, []);

  // Handle block IP success callback (memoized)
  const handleBlockSuccess = useCallback(() => {
    // Refresh alerts after IP is blocked
    setBlockIPModal({ show: false, event: null });
    // Trigger re-fetch
    setRefreshTrigger(prev => prev + 1);
  }, []);

  // Bulk action handlers (memoized)
  const handleBulkBlock = useCallback(() => {
    if (selectedItems.length === 0) {
      toast.error('Please select at least one alert');
      return;
    }
    setBulkActionModal({ show: true, actionType: 'block' });
  }, [selectedItems.length]);

  const handleBulkMute = useCallback(() => {
    if (selectedItems.length === 0) {
      toast.error('Please select at least one alert');
      return;
    }
    setBulkActionModal({ show: true, actionType: 'mute' });
  }, [selectedItems.length]);

  const handleBulkActionSuccess = useCallback((result) => {
    // Clear selection
    setSelectedItems([]);
    // Close modal
    setBulkActionModal({ show: false, actionType: null });
    // Trigger re-fetch
    setRefreshTrigger(prev => prev + 1);
  }, []);

  const onSelectionChange = useCallback((selected) => {
    setSelectedItems(selected);
  }, []);

  // Search by rule (memoized)
  const searchByRule = useCallback((ruleId) => {
    const searchQuery = `rule:${ruleId}`;
    setSearchTerm(searchQuery);
    setSearchInput(searchQuery);
    setSourceFilter('wazuh');
    setPageIndex(0);
  }, []);

  // Search by signature (memoized)
  const searchBySignature = useCallback((sigId) => {
    const searchQuery = `sid:${sigId}`;
    setSearchTerm(searchQuery);
    setSearchInput(searchQuery);
    setSourceFilter('suricata');
    setPageIndex(0);
  }, []);

  // Helper: Convert EuiSuperDatePicker date math to simple time range format
  // e.g., 'now-24h' -> '24h', 'now-7d' -> '7d'
  const convertDateMathToTimeRange = useCallback((start, end) => {
    // If end is 'now' and start is in date math format 'now-Xh' or 'now-Xd'
    if (end === 'now' && start && start.startsWith('now-')) {
      return start.replace('now-', '');
    }
    // For custom date ranges, calculate hours between start and end
    try {
      const startDate = new Date(start);
      const endDate = new Date(end);
      if (!isNaN(startDate.getTime()) && !isNaN(endDate.getTime())) {
        const diffHours = Math.ceil((endDate - startDate) / (1000 * 60 * 60));
        return `${diffHours}h`;
      }
    } catch (e) {
      // Fall back to 24h if parsing fails
    }
    return '24h';
  }, []);

  // Fetch events from response backend (memoized with all dependencies)
  const fetchEvents = useCallback(async () => {
    try {
      setLoading(true);

      const offset = pageIndex * pageSize;

      // Convert SuperDatePicker format to API format
      const timeRangeValue = convertDateMathToTimeRange(timeRangeStart, timeRangeEnd);

      const filters = {
        time_range: timeRangeValue,
        limit: pageSize,
        offset: offset,
        return_total: true
      };

      if (severityFilter !== 'all') {
        filters.severity = severityFilter.charAt(0).toUpperCase() + severityFilter.slice(1);
      }

      if (sourceFilter !== 'all') {
        filters.source = sourceFilter;
      }

      if (searchTerm) {
        filters.search = searchTerm;
      }

      // Add sorting parameters for backend (server-side sorting for large datasets)
      if (sortField) {
        filters.sort_field = sortField;
        filters.sort_direction = sortDirection;
      }

      const response = await fetchUnifiedAlerts(filters);

      const data = response.alerts || [];
      const total = response.total || data.length;
      const stats = response.statistics || { by_severity: {}, by_source: {} };

      setTotalCount(total);
      setStatistics(stats);

      // Keep raw data structure from backend
      const transformedEvents = data.map((event, index) => ({
        id: event.id || event._id || `event-${offset + index}`,
        ...event  // Keep all original fields
      }));

      setEvents(transformedEvents);

    } catch (error) {
      console.error('Error fetching events:', error);
      toast.error('Failed to fetch events: ' + error.message);
    } finally {
      setLoading(false);
    }
  }, [timeRangeStart, timeRangeEnd, convertDateMathToTimeRange, severityFilter, sourceFilter, searchTerm, pageIndex, pageSize, sortField, sortDirection, refreshTrigger]);

  // Debounced search handler
  const handleSearchInputChange = useCallback((e) => {
    const value = e.target.value;
    setSearchInput(value);

    // Clear existing timer
    if (searchDebounceTimer.current) {
      clearTimeout(searchDebounceTimer.current);
    }

    // Set new timer for 500ms debounce
    searchDebounceTimer.current = setTimeout(() => {
      setSearchTerm(value);
      setPageIndex(0); // Reset to first page on search
    }, 500);
  }, []);

  // Clear search
  const handleSearchClear = useCallback(() => {
    setSearchInput('');
    setSearchTerm('');
    setPageIndex(0);
  }, []);

  // Manual search trigger (when user clicks search button or presses enter)
  const handleSearch = useCallback(() => {
    setSearchTerm(searchInput);
    setPageIndex(0);
  }, [searchInput]);

  // Enhanced filter handlers that reset pagination
  const handleSeverityChange = useCallback((e) => {
    setSeverityFilter(e.target.value);
    setPageIndex(0); // Reset to first page
  }, []);

  const handleSourceChange = useCallback((e) => {
    setSourceFilter(e.target.value);
    setPageIndex(0); // Reset to first page
  }, []);

  // Handle EuiSuperDatePicker time range change
  const handleTimeRangeChange = useCallback(({ start, end }) => {
    setTimeRangeStart(start);
    setTimeRangeEnd(end);
    setPageIndex(0); // Reset to first page
  }, []);

  // Enhanced table change handler with sorting support
  const onTableChange = useCallback(({ page = {}, sort = {} }) => {
    const { index: pageIndexNew, size: pageSizeNew } = page;

    if (pageIndexNew !== undefined) setPageIndex(pageIndexNew);
    if (pageSizeNew !== undefined) setPageSize(pageSizeNew);

    // Handle sorting (client-side for now, backend support can be added later)
    if (sort.field !== undefined) {
      setSortField(sort.field);
      setSortDirection(sort.direction);
    }
  }, []);

  // Fetch events when filters, pagination, or dependencies change
  useEffect(() => {
    fetchEvents();
  }, [fetchEvents]);

  // Cleanup debounce timer on unmount
  useEffect(() => {
    return () => {
      if (searchDebounceTimer.current) {
        clearTimeout(searchDebounceTimer.current);
      }
    };
  }, []);

  // Optimized auto-refresh: pause when user is actively interacting
  useEffect(() => {
    if (!autoRefresh) return;

    // Don't refresh if:
    // - User has expanded rows
    // - User has selected items
    // - Modal is open
    // - Currently loading
    const shouldPauseRefresh =
      expandedRows.size > 0 ||
      selectedItems.length > 0 ||
      muteModal.show ||
      blockIPModal.show ||
      bulkActionModal.show ||
      loading;

    if (shouldPauseRefresh) {
      return; // Don't set up interval if user is interacting
    }

    const interval = setInterval(() => {
      fetchEvents();
    }, 60000); // 60 seconds

    return () => clearInterval(interval);
  }, [autoRefresh, fetchEvents, expandedRows.size, selectedItems.length, muteModal.show, blockIPModal.show, bulkActionModal.show, loading]);

  // Client-side filtering for muted alerts
  const filteredEvents = useMemo(() => {
    let filtered = events;

    // Filter out muted alerts (client-side only state)
    if (mutedAlerts.size > 0) {
      filtered = filtered.filter((event) => !mutedAlerts.has(event.id));
    }

    // Note: Search, severity, and source filtering is handled by the backend
    // We only apply client-side muted alerts filtering here
    // Sorting is also handled by the backend for large datasets

    return filtered;
  }, [events, mutedAlerts]);

  // Memoized column definitions
  const columns = useMemo(() => [
    {
      field: 'normalized_severity',
      name: 'Sev',
      render: (severity) => {
        const config = {
          'Critical': { color: 'danger', label: 'C', tooltip: 'Critical' },
          'High': { color: 'warning', label: 'H', tooltip: 'High' },
          'Medium': { color: '#FF9830', label: 'M', tooltip: 'Medium' },
          'Low': { color: 'primary', label: 'L', tooltip: 'Low' }
        };

        const sev = severity || 'Low';
        const cfg = config[sev] || config['Low'];

        return (
          <EuiToolTip content={cfg.tooltip}>
            <EuiBadge color={cfg.color} style={{ minWidth: '28px', textAlign: 'center' }}>
              {cfg.label}
            </EuiBadge>
          </EuiToolTip>
        );
      },
      width: '50px',
      sortable: true
    },
    {
      field: 'timestamp',
      name: 'Time',
      render: (timestamp, item) => {
        // Both sources use 'timestamp' field at top level
        const actualTime = timestamp || item.timestamp;

        if (!actualTime) {
          return <EuiText size="xs" color="subdued">Unknown</EuiText>;
        }

        const date = new Date(actualTime);

        // Check if date is valid
        if (isNaN(date.getTime())) {
          return <EuiText size="xs" color="subdued">Invalid Date</EuiText>;
        }

        const relative = getRelativeTime(actualTime);
        const time = date.toLocaleTimeString('en-US', {
          hour: '2-digit',
          minute: '2-digit'
        });

        return (
          <EuiToolTip content={date.toLocaleString()}>
            <div>
              <EuiText size="s">{relative}</EuiText>
              <EuiText size="xs" color="subdued">{time}</EuiText>
            </div>
          </EuiToolTip>
        );
      },
      width: '110px',
      sortable: true
    },
    {
      field: 'source',
      name: 'Type',
      render: (source) => {
        if (source === 'wazuh') {
          return (
            <EuiToolTip content="Host (Wazuh)">
              <EuiBadge color="#00BFB3" iconType="desktop">
                Host
              </EuiBadge>
            </EuiToolTip>
          );
        } else {
          return (
            <EuiToolTip content="Network (Suricata)">
              <EuiBadge color="#7B61FF" iconType="globe">
                Net
              </EuiBadge>
            </EuiToolTip>
          );
        }
      },
      width: '80px',
      sortable: true
    },
    {
      name: 'Event',
      render: (item) => {
        let description, eventId;

        if (item.source === 'wazuh') {
          description = item.rule_description || 'Unknown Event';
          eventId = `Rule ${item.rule_id || 'N/A'}`;
        } else {
          description = item.signature || 'Unknown Alert';
          eventId = `SID ${item.signature_id || 'N/A'}`;
        }

        return (
          <EuiToolTip content={description}>
            <div>
              <EuiText size="s">
                <strong>{description}</strong>
              </EuiText>
              <EuiText size="xs" color="subdued">
                {eventId}
              </EuiText>
            </div>
          </EuiToolTip>
        );
      },
      truncateText: true,
      width: '240px'
    },
    {
      name: 'Src IP',
      render: (item) => {
        // Both Suricata and Wazuh now have normalized src_ip at top level
        const srcIp = item.src_ip;

        if (srcIp && srcIp !== 'Unknown') {
          return (
            <IPEnrichmentTooltip ipAddress={srcIp} placement="right">
              <EuiText size="xs" style={{ fontFamily: 'monospace', fontSize: '11px' }}>
                {srcIp}
              </EuiText>
            </IPEnrichmentTooltip>
          );
        }

        return <EuiText size="xs" color="subdued">—</EuiText>;
      },
      width: '115px'
    },
    {
      name: 'Dst IP',
      render: (item) => {
        // Both Suricata and Wazuh now have normalized dest_ip at top level
        const destIp = item.dest_ip;

        if (destIp && destIp !== 'Unknown') {
          return (
            <IPEnrichmentTooltip ipAddress={destIp} placement="right">
              <EuiText size="xs" style={{ fontFamily: 'monospace', fontSize: '11px' }}>
                {destIp}
              </EuiText>
            </IPEnrichmentTooltip>
          );
        }

        return <EuiText size="xs" color="subdued">—</EuiText>;
      },
      width: '115px'
    },
    {
      name: (
        <EuiToolTip content="Agent Name (Wazuh) or Sensor Hostname (Suricata)">
          <span>Agent/Sensor</span>
        </EuiToolTip>
      ),
      render: (item) => {
        if (item.source === 'wazuh') {
          const agentName = item.agent_name || 'Unknown';
          const agentId = item.agent_id || 'N/A';

          return (
            <EuiToolTip content={`${agentName} (ID: ${agentId})`}>
              <div style={{
                maxWidth: '130px',
                overflow: 'hidden',
                textOverflow: 'ellipsis',
                whiteSpace: 'nowrap'
              }}>
                <EuiBadge color="hollow" iconType="compute">
                  {agentName}
                </EuiBadge>
              </div>
            </EuiToolTip>
          );
        } else {
          // For Suricata: show sensor hostname
          const sensor = item.raw?.node?.hostname || item.raw?.event?.host || 'Unknown';
          return (
            <EuiToolTip content={sensor}>
              <div style={{
                maxWidth: '130px',
                overflow: 'hidden',
                textOverflow: 'ellipsis',
                whiteSpace: 'nowrap'
              }}>
                <EuiBadge color="hollow" iconType="globe">
                  {sensor}
                </EuiBadge>
              </div>
            </EuiToolTip>
          );
        }
      },
      width: '140px'
    },
    {
      name: 'Category',
      render: (item) => {
        let category, color;

        if (item.source === 'wazuh') {
          const groups = item.raw?.rule?.groups || [];
          category = groups[0] || 'system';
          const groupColors = {
            'authentication': 'primary',
            'web': 'success',
            'syslog': 'default',
            'firewall': 'danger',
            'linuxkernel': 'warning'
          };
          color = groupColors[category] || 'default';
        } else {
          category = item.category || 'Unknown';
          color = '#6092C0'; // Blue-gray instead of pink
        }

        return (
          <div style={{
            wordWrap: 'break-word',
            whiteSpace: 'normal',
            overflow: 'hidden',
            maxWidth: '130px'
          }}>
            <EuiBadge color={color}>
              {category}
            </EuiBadge>
          </div>
        );
      },
      truncateText: false,
      width: '130px'
    },
    {
      name: 'Impact',
      render: (item) => {
        let rawValue, label, tooltip;

        if (item.source === 'wazuh') {
          rawValue = item.rule_level || 0;
          label = `L${rawValue}`;
          tooltip = `Wazuh Level: ${rawValue}/15`;
        } else {
          rawValue = item.severity || 0;
          label = `S${rawValue}`;
          tooltip = `Suricata Severity: ${rawValue}/4`;
        }

        return (
          <EuiToolTip content={tooltip}>
            <EuiBadge color="default" style={{ minWidth: '32px' }}>{label}</EuiBadge>
          </EuiToolTip>
        );
      },
      width: '55px'
    },
    {
      name: '',
      render: (item) => (
        <ActionCell
          itemId={item.id}
          isExpanded={expandedRows.has(item.id)}
          isMuted={mutedAlerts.has(item.id)}
          onToggleExpand={toggleExpandRow}
          onMute={handleMute}
        />
      ),
      width: '80px',
      align: 'right'
    }
  ], [getRelativeTime, expandedRows, mutedAlerts, toggleExpandRow, handleMute]);

  // Build expanded row map (memoized) - using imported components
  const itemIdToExpandedRowMap = useMemo(() => {
    const map = {};
    // Only iterate over expanded rows instead of all events
    expandedRows.forEach((id) => {
      const item = filteredEvents.find(e => e.id === id);
      if (item) {
        map[id] = item.source === 'wazuh' ? (
          <WazuhExpandedRow
            key={id}
            event={item}
            onSearchByRule={searchByRule}
            onBlockIP={handleBlockIP}
            getSeverityColor={getSeverityColor}
          />
        ) : (
          <SuricataExpandedRow
            key={id}
            event={item}
            onSearchBySignature={searchBySignature}
            onBlockIP={handleBlockIP}
            getSeverityColor={getSeverityColor}
          />
        );
      }
    });
    return map;
  }, [filteredEvents, expandedRows, searchByRule, searchBySignature, handleBlockIP, getSeverityColor]);

  const severityOptions = [
    { value: 'all', text: 'All Severities' },
    { value: 'critical', text: '🔴 Critical' },
    { value: 'high', text: '🟠 High' },
    { value: 'medium', text: '🟡 Medium' },
    { value: 'low', text: '🔵 Low' }
  ];

  const sourceOptions = [
    { value: 'all', text: 'All Sources' },
    { value: 'wazuh', text: '🖥️ Host (Wazuh)' },
    { value: 'suricata', text: '🌐 Network (Suricata)' }
  ];

  // Commonly used time ranges for EuiSuperDatePicker (relative ranges - always from "now")
  const commonlyUsedRanges = [
    { start: 'now-15m', end: 'now', label: 'Last 15 minutes' },
    { start: 'now-1h', end: 'now', label: 'Last 1 hour' },
    { start: 'now-6h', end: 'now', label: 'Last 6 hours' },
    { start: 'now-12h', end: 'now', label: 'Last 12 hours' },
    { start: 'now-24h', end: 'now', label: 'Last 24 hours' },
    { start: 'now-3d', end: 'now', label: 'Last 3 days' },
    { start: 'now-7d', end: 'now', label: 'Last 7 days' },
    { start: 'now-14d', end: 'now', label: 'Last 14 days' },
    { start: 'now-30d', end: 'now', label: 'Last 30 days' },
    { start: 'now-90d', end: 'now', label: 'Last 90 days' }
  ];

  return (
    <EuiPage paddingSize="none">
      <EuiPageBody panelled>
        {/* Page Header */}
        <EuiPageHeader
          pageTitle={
            <EuiFlexGroup gutterSize="s" alignItems="center" responsive={false}>
              <EuiFlexItem grow={false}>
                <Shield style={{ width: '28px', height: '28px', color: '#3b82f6' }} />
              </EuiFlexItem>
              <EuiFlexItem>Security Events</EuiFlexItem>
            </EuiFlexGroup>
          }
          description="Unified Wazuh (Host) + Suricata (Network) security events with normalized severity"
          rightSideItems={[
            mutedAlerts.size > 0 && (
              <EuiPanel key="muted-badge" color="subdued" paddingSize="s">
                <EuiFlexGroup gutterSize="s" alignItems="center" responsive={false}>
                  <EuiFlexItem grow={false}>
                    <VolumeX style={{ width: '16px', height: '16px' }} />
                  </EuiFlexItem>
                  <EuiFlexItem>
                    <EuiText size="s">{mutedAlerts.size} muted</EuiText>
                  </EuiFlexItem>
                  <EuiFlexItem grow={false}>
                    <EuiButtonEmpty size="xs" onClick={() => setMutedAlerts(new Set())}>
                      Clear
                    </EuiButtonEmpty>
                  </EuiFlexItem>
                </EuiFlexGroup>
              </EuiPanel>
            ),
            <EuiSwitch
              key="auto-refresh"
              label="Auto-refresh"
              checked={autoRefresh}
              onChange={(e) => setAutoRefresh(e.target.checked)}
            />,
            <EuiButton
              key="refresh"
              onClick={() => {
                setPageIndex(0);
                fetchEvents();
              }}
              isLoading={loading}
              iconType="refresh"
              fill
            >
              Refresh
            </EuiButton>
          ].filter(Boolean)}
        />

        <EuiSpacer size="l" />

        {/* Bulk Action Toolbar */}
        {selectedItems.length > 0 && (
          <>
            <EuiPanel color="primary" hasBorder paddingSize="m">
              <EuiFlexGroup alignItems="center" justifyContent="spaceBetween">
                <EuiFlexItem grow={false}>
                  <EuiText>
                    <strong>{selectedItems.length} alert{selectedItems.length > 1 ? 's' : ''} selected</strong>
                  </EuiText>
                </EuiFlexItem>
                <EuiFlexItem grow={false}>
                  <EuiFlexGroup gutterSize="s">
                    <EuiFlexItem grow={false}>
                      <EuiButton
                        color="danger"
                        iconType="securitySignalDetected"
                        onClick={handleBulkBlock}
                        size="s"
                      >
                        Block {selectedItems.length} IP{selectedItems.length > 1 ? 's' : ''}
                      </EuiButton>
                    </EuiFlexItem>
                    <EuiFlexItem grow={false}>
                      <EuiButton
                        color="primary"
                        iconType="bellSlash"
                        onClick={handleBulkMute}
                        size="s"
                      >
                        Mute {selectedItems.length} Alert{selectedItems.length > 1 ? 's' : ''}
                      </EuiButton>
                    </EuiFlexItem>
                    <EuiFlexItem grow={false}>
                      <EuiButtonEmpty
                        color="text"
                        onClick={() => setSelectedItems([])}
                        size="s"
                      >
                        Clear Selection
                      </EuiButtonEmpty>
                    </EuiFlexItem>
                  </EuiFlexGroup>
                </EuiFlexItem>
              </EuiFlexGroup>
            </EuiPanel>
            <EuiSpacer size="m" />
          </>
        )}

        {/* Filters */}
        <EuiPanel hasBorder paddingSize="m">
          <EuiFlexGroup gutterSize="m">
            <EuiFlexItem>
              <EuiFieldSearch
                placeholder="Search events, IPs, signatures... (auto-search after 500ms)"
                value={searchInput}
                onChange={handleSearchInputChange}
                onSearch={handleSearch}
                onClear={handleSearchClear}
                isClearable
                fullWidth
                isLoading={loading && searchInput !== searchTerm}
              />
            </EuiFlexItem>
            <EuiFlexItem grow={false} style={{ minWidth: '180px' }}>
              <EuiSelect
                options={severityOptions}
                value={severityFilter}
                onChange={handleSeverityChange}
                fullWidth
              />
            </EuiFlexItem>
            <EuiFlexItem grow={false} style={{ minWidth: '180px' }}>
              <EuiSelect
                options={sourceOptions}
                value={sourceFilter}
                onChange={handleSourceChange}
                fullWidth
              />
            </EuiFlexItem>
            <EuiFlexItem grow={false} style={{ minWidth: '280px' }}>
              <EuiSuperDatePicker
                start={timeRangeStart}
                end={timeRangeEnd}
                onTimeChange={handleTimeRangeChange}
                isPaused={true}
                showUpdateButton={false}
                isQuickSelectOnly={false}
                commonlyUsedRanges={commonlyUsedRanges}
              />
            </EuiFlexItem>
            <EuiFlexItem grow={false}>
              <EuiButton
                onClick={handleSearch}
                isLoading={loading}
                iconType="search"
                fill
              >
                Search
              </EuiButton>
            </EuiFlexItem>
          </EuiFlexGroup>
        </EuiPanel>

        <EuiSpacer size="l" />

        {/* Statistics */}
        <EuiFlexGroup gutterSize="l">
          <EuiFlexItem>
            <EuiPanel hasBorder paddingSize="l">
              <EuiStat
                title={totalCount.toLocaleString()}
                description="Total Events"
                titleColor="primary"
                titleSize="l"
                textAlign="left"
              >
                <EuiText size="xs" color="success">
                  🖥️ {statistics.by_source?.wazuh || 0} | 🌐 {statistics.by_source?.suricata || 0}
                </EuiText>
              </EuiStat>
            </EuiPanel>
          </EuiFlexItem>
          <EuiFlexItem>
            <EuiPanel hasBorder paddingSize="l">
              <EuiStat
                title={(statistics.by_severity?.Critical || 0).toString()}
                description="Critical"
                titleColor="danger"
                titleSize="l"
                textAlign="left"
              />
            </EuiPanel>
          </EuiFlexItem>
          <EuiFlexItem>
            <EuiPanel hasBorder paddingSize="l">
              <EuiStat
                title={(statistics.by_severity?.High || 0).toString()}
                description="High"
                titleColor="warning"
                titleSize="l"
                textAlign="left"
              />
            </EuiPanel>
          </EuiFlexItem>
          <EuiFlexItem>
            <EuiPanel hasBorder paddingSize="l">
              <EuiStat
                title={(statistics.by_severity?.Medium || 0).toString()}
                description="Medium"
                titleColor="#FEC514"
                titleSize="l"
                textAlign="left"
              />
            </EuiPanel>
          </EuiFlexItem>
          <EuiFlexItem>
            <EuiPanel hasBorder paddingSize="l">
              <EuiStat
                title={(statistics.by_severity?.Low || 0).toString()}
                description="Low"
                titleColor="primary"
                titleSize="l"
                textAlign="left"
              />
            </EuiPanel>
          </EuiFlexItem>
        </EuiFlexGroup>

        <EuiSpacer size="l" />

        {/* Events Table */}
        <EuiPanel hasBorder paddingSize="none">
          {loading && events.length === 0 ? (
            <EuiEmptyPrompt
              icon={<EuiLoadingSpinner size="xl" />}
              title={<h2>Loading events...</h2>}
              body={<p>Fetching security events from Elasticsearch</p>}
            />
          ) : filteredEvents.length === 0 ? (
            <EuiEmptyPrompt
              icon={<Shield style={{ width: '64px', height: '64px', opacity: 0.3 }} />}
              title={<h2>No events found</h2>}
              body={
                <p>
                  Try adjusting your filters or search criteria.
                  <br />
                  Make sure both backends are running and data is available.
                </p>
              }
              actions={
                <EuiButton
                  color="primary"
                  fill
                  onClick={() => {
                    setSeverityFilter('all');
                    setSourceFilter('all');
                    setSearchTerm('');
                    setSearchInput('');
                    setPageIndex(0);
                  }}
                >
                  Clear Filters
                </EuiButton>
              }
            />
          ) : (
            <EuiBasicTable
              items={filteredEvents}
              columns={columns}
              itemId="id"
              itemIdToExpandedRowMap={itemIdToExpandedRowMap}
              isExpandable={true}
              hasActions={true}
              responsive={true}
              pagination={{
                pageIndex: pageIndex,
                pageSize: pageSize,
                totalItemCount: totalCount,
                pageSizeOptions: pageSizeOptions,
                showPerPageOptions: true
              }}
              sorting={{
                sort: {
                  field: sortField,
                  direction: sortDirection
                },
                enableAllColumns: true
              }}
              onChange={onTableChange}
              loading={loading}
              selection={{
                selectable: () => true,
                onSelectionChange: onSelectionChange,
                selected: selectedItems
              }}
              isSelectable={true}
            />
          )}
        </EuiPanel>
      </EuiPageBody>

      {/* Mute Alert Modal */}
      <MuteAlertModal
        isOpen={muteModal.show}
        onClose={() => setMuteModal({ show: false, event: null })}
        event={muteModal.event}
        onMuteSuccess={handleMuteSuccess}
      />

      {/* Block IP Modal */}
      <BlockIPModal
        isOpen={blockIPModal.show}
        onClose={() => setBlockIPModal({ show: false, event: null })}
        event={blockIPModal.event}
        onBlockSuccess={handleBlockSuccess}
      />

      {/* Bulk Action Modal */}
      <BulkActionModal
        isOpen={bulkActionModal.show}
        onClose={() => setBulkActionModal({ show: false, actionType: null })}
        selectedAlerts={selectedItems}
        actionType={bulkActionModal.actionType}
        onSuccess={handleBulkActionSuccess}
      />
    </EuiPage>
  );
};

export default Events;
