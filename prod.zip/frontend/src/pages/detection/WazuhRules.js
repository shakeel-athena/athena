import React, { useState, useEffect } from 'react';
import { FileText, Search, Shield, AlertTriangle, RefreshCw } from 'lucide-react';
import { fetchWazuhAlerts } from '../../services/detectionApi';
import toast from 'react-hot-toast';

const WazuhRules = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const [levelFilter, setLevelFilter] = useState('all');
  const [rules, setRules] = useState([]);
  const [loading, setLoading] = useState(true);

  // Fetch actual Wazuh alerts and extract unique rules
  const fetchRules = async () => {
    try {
      setLoading(true);
      const response = await fetchWazuhAlerts({ limit: 1000 });
      const alerts = response.alerts || response.data || response || [];

      // Extract unique rules from alerts
      const rulesMap = new Map();
      alerts.forEach(alert => {
        const rule = alert.rule;
        if (rule && rule.id) {
          if (!rulesMap.has(rule.id)) {
            rulesMap.set(rule.id, {
              id: rule.id,
              level: rule.level || 0,
              description: rule.description || 'No description',
              groups: rule.groups || [],
              mitre_tactic: alert.rule?.mitre?.tactic || [],
              mitre_technique: alert.rule?.mitre?.technique || [],
            });
          }
        }
      });

      setRules(Array.from(rulesMap.values()));
    } catch (error) {
      console.error('Error fetching Wazuh rules:', error);
      toast.error('Failed to fetch Wazuh rules: ' + error.message);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchRules();
  }, []);

  const filteredRules = rules.filter(rule => {
    const matchesSearch = !searchTerm ||
      rule.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
      rule.id.includes(searchTerm);

    const matchesLevel = levelFilter === 'all' ||
      (levelFilter === 'critical' && rule.level >= 10) ||
      (levelFilter === 'high' && rule.level >= 7 && rule.level < 10) ||
      (levelFilter === 'medium' && rule.level >= 4 && rule.level < 7) ||
      (levelFilter === 'low' && rule.level < 4);

    return matchesSearch && matchesLevel;
  });

  const getLevelColor = (level) => {
    if (level >= 10) return 'text-red-400 bg-red-500/20';
    if (level >= 7) return 'text-orange-400 bg-orange-500/20';
    if (level >= 4) return 'text-yellow-400 bg-yellow-500/20';
    return 'text-blue-400 bg-blue-500/20';
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-3">
          <div className="w-10 h-10 bg-accent-green/20 rounded-lg flex items-center justify-center">
            <FileText className="w-6 h-6 text-accent-green" />
          </div>
          <div>
            <h1 className="text-2xl font-bold text-white">Wazuh Rules</h1>
            <p className="text-dark-400">Security detection rules from live alerts</p>
          </div>
        </div>

        <button
          onClick={fetchRules}
          disabled={loading}
          className="px-4 py-2 bg-accent-blue text-white rounded-md hover:bg-accent-blue/80 transition-colors flex items-center space-x-2 disabled:opacity-50"
        >
          <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} />
          <span>Refresh</span>
        </button>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="card p-6">
          <div className="text-dark-400 text-sm mb-1">Total Rules</div>
          <div className="text-3xl font-bold text-white">{loading ? '-' : rules.length}</div>
        </div>
        <div className="card p-6">
          <div className="text-dark-400 text-sm mb-1">Critical</div>
          <div className="text-3xl font-bold text-red-400">
            {loading ? '-' : rules.filter(r => r.level >= 10).length}
          </div>
        </div>
        <div className="card p-6">
          <div className="text-dark-400 text-sm mb-1">High</div>
          <div className="text-3xl font-bold text-orange-400">
            {loading ? '-' : rules.filter(r => r.level >= 7 && r.level < 10).length}
          </div>
        </div>
        <div className="card p-6">
          <div className="text-dark-400 text-sm mb-1">Medium/Low</div>
          <div className="text-3xl font-bold text-yellow-400">
            {loading ? '-' : rules.filter(r => r.level < 7).length}
          </div>
        </div>
      </div>

      {/* Filters */}
      <div className="card p-4">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-dark-400" />
            <input
              type="text"
              placeholder="Search rules..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-10 pr-4 py-2 bg-dark-700 border border-dark-600 rounded-md text-white placeholder-dark-400 focus:outline-none focus:ring-2 focus:ring-accent-blue"
            />
          </div>

          <select
            value={levelFilter}
            onChange={(e) => setLevelFilter(e.target.value)}
            className="px-4 py-2 bg-dark-700 border border-dark-600 rounded-md text-white focus:outline-none focus:ring-2 focus:ring-accent-blue"
          >
            <option value="all">All Levels</option>
            <option value="critical">Critical (≥10)</option>
            <option value="high">High (7-9)</option>
            <option value="medium">Medium (4-6)</option>
            <option value="low">Low (&lt;4)</option>
          </select>
        </div>
      </div>

      {/* Rules Table */}
      <div className="card">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-dark-800 border-b border-dark-700">
              <tr>
                <th className="px-4 py-3 text-left text-xs font-medium text-dark-300 uppercase">Rule ID</th>
                <th className="px-4 py-3 text-left text-xs font-medium text-dark-300 uppercase">Level</th>
                <th className="px-4 py-3 text-left text-xs font-medium text-dark-300 uppercase">Description</th>
                <th className="px-4 py-3 text-left text-xs font-medium text-dark-300 uppercase">Groups</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-dark-700">
              {loading ? (
                <tr>
                  <td colSpan="4" className="px-4 py-8 text-center text-dark-400">
                    <RefreshCw className="w-6 h-6 animate-spin mx-auto mb-2" />
                    Loading rules...
                  </td>
                </tr>
              ) : filteredRules.length === 0 ? (
                <tr>
                  <td colSpan="4" className="px-4 py-8 text-center text-dark-400">
                    No rules found
                  </td>
                </tr>
              ) : (
                filteredRules.map((rule) => (
                  <tr key={rule.id} className="hover:bg-dark-800 transition-colors">
                    <td className="px-4 py-3">
                      <span className="px-2 py-1 text-xs bg-dark-700 text-dark-300 rounded font-mono">
                        {rule.id}
                      </span>
                    </td>
                    <td className="px-4 py-3">
                      <span className={`px-2 py-1 text-xs rounded font-semibold ${getLevelColor(rule.level)}`}>
                        {rule.level}
                      </span>
                    </td>
                    <td className="px-4 py-3 text-sm text-white">{rule.description}</td>
                    <td className="px-4 py-3">
                      <div className="flex flex-wrap gap-1">
                        {rule.groups.slice(0, 3).map((group, idx) => (
                          <span key={idx} className="px-2 py-1 text-xs bg-accent-blue/20 text-accent-blue border border-accent-blue/30 rounded">
                            {group}
                          </span>
                        ))}
                        {rule.groups.length > 3 && (
                          <span className="px-2 py-1 text-xs text-dark-400">
                            +{rule.groups.length - 3} more
                          </span>
                        )}
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default WazuhRules;
