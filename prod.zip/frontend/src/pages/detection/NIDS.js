import React, { useState, useEffect, useCallback, useMemo } from 'react';
import {
  EuiPage,
  EuiPageBody,
  EuiTabs,
  EuiTab,
  EuiFlexGroup,
  EuiFlexItem,
  EuiPanel,
  EuiLoadingSpinner,
  EuiText,
  EuiSelect,
  EuiButton,
  EuiButtonEmpty,
  EuiBasicTable,
  EuiBadge,
  EuiCallOut,
  EuiProgress,
  EuiIcon,
  EuiFieldSearch,
  EuiSuperDatePicker
} from '@elastic/eui';
import {
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer,
  PieChart, Pie, Cell
} from 'recharts';
import {
  fetchNIDSOverview,
  fetchNIDSEvents,
  fetchNIDSTimeline,
  fetchNIDSNetworkAnalysis,
  fetchNIDSFilters
} from '../../services/detectionApi';

// Enhanced theme system using CSS variables - matching plugin design
const THEME_COLORS = {
  background: 'var(--euiPageBackgroundColor, #1a1b20)',
  cardBackground: 'var(--euiColorEmptyShade, #1d1e24)',
  cardBorder: 'var(--euiColorLightShade, #343741)',
  headerBackground: 'var(--euiColorLightestShade, #25262e)',

  text: {
    primary: 'var(--euiColorFullShade, #dfe5ef)',
    secondary: 'var(--euiColorDarkShade, #98a2b3)',
    muted: 'var(--euiColorMediumShade, #69707d)',
    accent: 'var(--euiColorPrimary, #36a2ef)',
    error: 'var(--euiColorDanger, #f66)',
  },

  shadows: {
    card: '0 4px 12px rgba(0, 0, 0, 0.15), 0 2px 6px rgba(0, 0, 0, 0.10)',
    cardHover: '0 8px 25px rgba(0, 0, 0, 0.20), 0 4px 12px rgba(0, 0, 0, 0.15)',
  },

  borderRadius: '8px'
};

// Severity configuration - matching plugin colors
const SEVERITY_CONFIG = {
  '1': { label: 'ALERT', color: '#ef4444', bgColor: 'rgba(239, 68, 68, 0.1)' },
  '2': { label: 'CRITICAL', color: '#dc2626', bgColor: 'rgba(220, 38, 38, 0.1)' },
  '3': { label: 'WARNING', color: '#f59e0b', bgColor: 'rgba(245, 158, 11, 0.1)' },
  '4': { label: 'NOTICE', color: '#3b82f6', bgColor: 'rgba(59, 130, 246, 0.1)' },
  '5+': { label: 'OTHERS', color: '#8b5cf6', bgColor: 'rgba(139, 92, 246, 0.1)' }
};

// Badge style configuration - minimalistic colors for table
const BADGE_STYLES = {
  category: {
    background: 'rgba(0, 191, 179, 0.15)',
    color: '#00d4c8',
    border: '1px solid rgba(0, 191, 179, 0.3)'
  },
  severity: {
    '1': { background: 'rgba(239, 68, 68, 0.2)', color: '#ff6b6b', border: '1px solid rgba(239, 68, 68, 0.4)' },
    '2': { background: 'rgba(236, 72, 153, 0.2)', color: '#f472b6', border: '1px solid rgba(236, 72, 153, 0.4)' },
    '3': { background: 'rgba(245, 158, 11, 0.2)', color: '#fbbf24', border: '1px solid rgba(245, 158, 11, 0.4)' },
    '4': { background: 'rgba(59, 130, 246, 0.2)', color: '#60a5fa', border: '1px solid rgba(59, 130, 246, 0.4)' },
    '5+': { background: 'rgba(139, 92, 246, 0.2)', color: '#a78bfa', border: '1px solid rgba(139, 92, 246, 0.4)' }
  },
  action: {
    allowed: { background: 'rgba(34, 197, 94, 0.15)', color: '#4ade80', border: '1px solid rgba(34, 197, 94, 0.3)' },
    blocked: { background: 'rgba(239, 68, 68, 0.15)', color: '#f87171', border: '1px solid rgba(239, 68, 68, 0.3)' }
  },
  protocol: {
    background: 'rgba(148, 163, 184, 0.15)',
    color: '#94a3b8',
    border: '1px solid rgba(148, 163, 184, 0.3)'
  }
};

// Time range presets
const TIME_RANGE_OPTIONS = [
  { value: 'now-15m', text: 'Last 15 minutes' },
  { value: 'now-1h', text: 'Last 1 hour' },
  { value: 'now-24h', text: 'Last 24 hours' },
  { value: 'now-7d', text: 'Last 7 days' },
  { value: 'now-30d', text: 'Last 30 days' },
  { value: 'now-90d', text: 'Last 90 days' }
];

// Chart colors for distribution - enhanced vibrant palette matching plugin
const CHART_COLORS = [
  '#00bfb3', '#f5a623', '#7b61ff', '#ff6b6b', '#54d62c',
  '#00b8d9', '#ff9f43', '#a855f7', '#f97316', '#22c55e',
  '#0ea5e9', '#ec4899', '#8b5cf6', '#14b8a6', '#f59e0b'
];

// Section Header Component - matching plugin design
const SectionHeader = ({ icon, title, subtitle }) => (
  <div style={{
    display: 'flex',
    alignItems: 'center',
    gap: '12px',
    marginBottom: '22px',
    marginTop: '22px',
    paddingLeft: '4px'
  }}>
    <EuiIcon type={icon} size="l" color={THEME_COLORS.text.accent} />
    <span style={{
      color: THEME_COLORS.text.primary,
      fontSize: '18px',
      fontWeight: '600'
    }}>
      {title}
    </span>
    {subtitle && (
      <span style={{
        fontSize: '12px',
        color: THEME_COLORS.text.muted,
        fontWeight: '400',
        marginLeft: '8px',
        padding: '4px 8px',
        backgroundColor: THEME_COLORS.cardBackground,
        borderRadius: '6px',
        border: `1px solid ${THEME_COLORS.cardBorder}`
      }}>
        {subtitle}
      </span>
    )}
  </div>
);

// Enhanced Severity Card Component - minimalistic transparent background
const SeverityCard = ({ severity, data, onClick }) => {
  const config = SEVERITY_CONFIG[severity] || SEVERITY_CONFIG['5+'];
  const badgeStyle = BADGE_STYLES.severity[severity] || BADGE_STYLES.severity['5+'];
  const count = data?.count || 0;
  const [isHovered, setIsHovered] = useState(false);

  return (
    <div
      style={{
        backgroundColor: badgeStyle.background,
        borderRadius: THEME_COLORS.borderRadius,
        padding: '16px 20px',
        textAlign: 'left',
        minHeight: '100px',
        display: 'flex',
        flexDirection: 'column',
        justifyContent: 'space-between',
        boxShadow: 'none',
        transition: 'all 0.2s ease',
        cursor: 'pointer',
        position: 'relative',
        overflow: 'hidden',
        transform: isHovered ? 'translateY(-2px)' : 'translateY(0)',
        border: isHovered ? `1px solid ${badgeStyle.color}` : badgeStyle.border
      }}
      onClick={() => onClick(severity)}
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
    >
      {/* Accent Bar - Left side */}
      <div style={{
        position: 'absolute',
        top: '0',
        left: '0',
        width: '3px',
        height: '100%',
        backgroundColor: badgeStyle.color
      }} />

      {/* Header with Label */}
      <div style={{
        fontSize: '11px',
        fontWeight: '600',
        color: badgeStyle.color,
        textTransform: 'uppercase',
        letterSpacing: '0.5px',
        paddingLeft: '8px',
        marginBottom: '8px',
        opacity: 0.9
      }}>
        {config.label}
      </div>

      {/* Count Display */}
      <div style={{
        fontSize: '32px',
        fontWeight: '700',
        color: badgeStyle.color,
        lineHeight: '1',
        paddingLeft: '8px',
        marginBottom: '8px'
      }}>
        {count.toLocaleString()}
      </div>

      {/* Level Indicator */}
      <div style={{
        fontSize: '10px',
        color: badgeStyle.color,
        fontWeight: '500',
        paddingLeft: '8px',
        opacity: 0.7
      }}>
        {severity === '5+' ? 'Level 5+' : `Level ${severity}`}
      </div>
    </div>
  );
};

// Stacked Bar Timeline Chart - matching plugin design with click functionality
const StackedTimelineChart = ({ data, severityData, loading, isDarkTheme, timeRange, onTimeSlotClick }) => {
  const [hoveredIndex, setHoveredIndex] = useState(null);

  if (loading) {
    return (
      <EuiPanel color="subdued" paddingSize="l" hasBorder style={{ height: 450, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
        <EuiLoadingSpinner size="xl" />
      </EuiPanel>
    );
  }

  // Calculate appropriate date format based on time range
  const getDateFormat = (timestamp, range) => {
    const date = new Date(timestamp);

    // Parse time range to determine format
    if (range?.includes('15m') || range?.includes('1h')) {
      // Short ranges: show time only (HH:mm)
      return date.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit', hour12: false });
    } else if (range?.includes('24h')) {
      // 24h: show time with hour
      return date.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit', hour12: false });
    } else if (range?.includes('7d')) {
      // Week: show day and time
      return date.toLocaleDateString('en-US', { weekday: 'short', hour: '2-digit', minute: '2-digit', hour12: false });
    } else if (range?.includes('30d')) {
      // Month: show month and day
      return date.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
    } else if (range?.includes('90d')) {
      // 3 months: show month and day
      return date.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
    } else {
      // Default: month and day
      return date.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
    }
  };

  // Calculate interval description based on time range
  const getIntervalDescription = (range) => {
    if (range?.includes('15m')) return '5 min intervals';
    if (range?.includes('1h')) return '5 min intervals';
    if (range?.includes('24h')) return '1 hour intervals';
    if (range?.includes('7d')) return '1 day intervals';
    if (range?.includes('30d')) return '1 day intervals';
    if (range?.includes('90d')) return '1 day intervals';
    return 'auto intervals';
  };

  // Process timeline data for stacked bars - use actual per-bucket severity data
  const chartData = (data || []).map((item, index) => {
    const bySeverity = item.bySeverity || {};

    // Calculate "others" as sum of severities >= 5
    const othersCount = Object.entries(bySeverity)
      .filter(([k]) => parseInt(k) >= 5)
      .reduce((sum, [, v]) => sum + v, 0);

    return {
      index,
      date: getDateFormat(item.timestamp, timeRange),
      timestamp: item.timestamp,
      timestampEnd: data[index + 1]?.timestamp || null, // Next bucket's start is this bucket's end
      total: item.count,
      // Use actual per-bucket severity counts
      alert: bySeverity['1'] || 0,
      critical: bySeverity['2'] || 0,
      warning: bySeverity['3'] || 0,
      notice: bySeverity['4'] || 0,
      others: othersCount
    };
  });

  // Calculate totals for legend from actual timeline data
  const totalAlerts = chartData.reduce((sum, d) => sum + d.total, 0);
  const activePeriods = chartData.filter(d => d.total > 0).length;
  const quietPeriods = chartData.filter(d => d.total === 0).length;

  // Severity totals for legend - calculated from actual timeline data
  const severityTotals = {
    alert: chartData.reduce((sum, d) => sum + d.alert, 0),
    critical: chartData.reduce((sum, d) => sum + d.critical, 0),
    warning: chartData.reduce((sum, d) => sum + d.warning, 0),
    notice: chartData.reduce((sum, d) => sum + d.notice, 0),
    others: chartData.reduce((sum, d) => sum + d.others, 0)
  };

  // Handle bar click - navigate to events for that time slot
  const handleBarClick = (data) => {
    if (data && data.activePayload && data.activePayload.length > 0) {
      const payload = data.activePayload[0].payload;
      if (payload.timestamp && onTimeSlotClick) {
        onTimeSlotClick(payload.timestamp, payload.timestampEnd);
      }
    }
  };

  return (
    <EuiPanel color="subdued" paddingSize="none" hasBorder style={{ overflow: 'hidden' }}>
      {/* Header */}
      <div style={{ padding: '16px 20px', borderBottom: `1px solid ${THEME_COLORS.cardBorder}` }}>
        <div style={{ fontWeight: '600', fontSize: '14px', color: THEME_COLORS.text.primary }}>
          NIDS Alert Timeline
        </div>
        <div style={{ fontSize: '12px', color: THEME_COLORS.text.muted, marginTop: '4px' }}>
          {totalAlerts.toLocaleString()} total alerts • {activePeriods} active periods • {quietPeriods} quiet • {getIntervalDescription(timeRange)}
        </div>
      </div>

      <div style={{ display: 'flex' }}>
        {/* Chart Area */}
        <div style={{ flex: 1, padding: '20px' }}>
          <ResponsiveContainer width="100%" height={350}>
            <BarChart
              data={chartData}
              barCategoryGap="20%"
              onClick={handleBarClick}
              style={{ cursor: 'pointer' }}
            >
              <CartesianGrid strokeDasharray="3 3" stroke={THEME_COLORS.cardBorder} opacity={0.5} />
              <XAxis
                dataKey="date"
                tick={{ fontSize: 10, fill: THEME_COLORS.text.muted }}
                stroke={THEME_COLORS.cardBorder}
                axisLine={{ stroke: THEME_COLORS.cardBorder }}
                interval="preserveStartEnd"
                angle={chartData.length > 15 ? -45 : 0}
                textAnchor={chartData.length > 15 ? 'end' : 'middle'}
                height={chartData.length > 15 ? 60 : 30}
              />
              <YAxis
                tick={{ fontSize: 11, fill: THEME_COLORS.text.muted }}
                stroke={THEME_COLORS.cardBorder}
                axisLine={{ stroke: THEME_COLORS.cardBorder }}
              />
              <Tooltip
                contentStyle={{
                  backgroundColor: THEME_COLORS.cardBackground,
                  border: `1px solid ${THEME_COLORS.cardBorder}`,
                  borderRadius: '6px',
                  boxShadow: '0 4px 12px rgba(0, 0, 0, 0.3)'
                }}
                itemStyle={{
                  color: '#ffffff'
                }}
                labelStyle={{
                  color: '#ffffff',
                  fontWeight: '600',
                  marginBottom: '4px'
                }}
                formatter={(value, name) => [value.toLocaleString(), name.charAt(0).toUpperCase() + name.slice(1)]}
                labelFormatter={(label, payload) => {
                  if (payload && payload[0]?.payload?.timestamp) {
                    const date = new Date(payload[0].payload.timestamp);
                    return date.toLocaleString('en-US', {
                      month: 'short',
                      day: 'numeric',
                      hour: '2-digit',
                      minute: '2-digit',
                      hour12: false
                    });
                  }
                  return label;
                }}
              />
              <Bar
                dataKey="alert"
                stackId="severity"
                fill="#ef4444"
                name="Alert"
                onMouseEnter={(_, index) => setHoveredIndex(index)}
                onMouseLeave={() => setHoveredIndex(null)}
              />
              <Bar
                dataKey="critical"
                stackId="severity"
                fill="#dc2626"
                name="Critical"
                onMouseEnter={(_, index) => setHoveredIndex(index)}
                onMouseLeave={() => setHoveredIndex(null)}
              />
              <Bar
                dataKey="warning"
                stackId="severity"
                fill="#f59e0b"
                name="Warning"
                onMouseEnter={(_, index) => setHoveredIndex(index)}
                onMouseLeave={() => setHoveredIndex(null)}
              />
              <Bar
                dataKey="notice"
                stackId="severity"
                fill="#3b82f6"
                name="Notice"
                onMouseEnter={(_, index) => setHoveredIndex(index)}
                onMouseLeave={() => setHoveredIndex(null)}
              />
              <Bar
                dataKey="others"
                stackId="severity"
                fill="#8b5cf6"
                name="Others"
                onMouseEnter={(_, index) => setHoveredIndex(index)}
                onMouseLeave={() => setHoveredIndex(null)}
              />
            </BarChart>
          </ResponsiveContainer>
        </div>

        {/* Legend Panel - Right Side */}
        <div style={{
          width: '160px',
          borderLeft: `1px solid ${THEME_COLORS.cardBorder}`,
          padding: '20px 16px',
          backgroundColor: isDarkTheme ? 'rgba(0,0,0,0.2)' : 'rgba(0,0,0,0.05)'
        }}>
          <div style={{
            fontSize: '13px',
            fontWeight: '600',
            color: THEME_COLORS.text.primary,
            marginBottom: '16px'
          }}>
            Total Events
          </div>

          {/* Legend Items */}
          {[
            { key: 'alert', label: 'Alert', color: '#ef4444', count: severityTotals.alert },
            { key: 'critical', label: 'Critical', color: '#dc2626', count: severityTotals.critical },
            { key: 'warning', label: 'Warning', color: '#f59e0b', count: severityTotals.warning },
            { key: 'notice', label: 'Notice', color: '#3b82f6', count: severityTotals.notice },
            { key: 'others', label: 'Others', color: '#8b5cf6', count: severityTotals.others }
          ].map(item => (
            <div key={item.key} style={{
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'space-between',
              marginBottom: '12px'
            }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                <div style={{
                  width: '10px',
                  height: '10px',
                  borderRadius: '2px',
                  backgroundColor: item.color
                }} />
                <span style={{ fontSize: '12px', color: THEME_COLORS.text.secondary }}>
                  {item.label}
                </span>
              </div>
              <span style={{ fontSize: '12px', fontWeight: '600', color: THEME_COLORS.text.primary }}>
                {item.count.toLocaleString()}
              </span>
            </div>
          ))}

          {/* Click hint */}
          <div style={{
            marginTop: '16px',
            paddingTop: '12px',
            borderTop: `1px solid ${THEME_COLORS.cardBorder}`,
            fontSize: '10px',
            color: THEME_COLORS.text.muted,
            textAlign: 'center'
          }}>
            Click bar to view events
          </div>
        </div>
      </div>
    </EuiPanel>
  );
};

// Enhanced Donut Chart Component - matching plugin design with progress bars in legend
const EnhancedDonutChart = ({ title, subtitle, data, loading, onItemClick, isDarkTheme, centerLabel }) => {
  const [hoveredIndex, setHoveredIndex] = useState(null);

  if (loading) {
    return (
      <EuiPanel color="subdued" paddingSize="l" hasBorder style={{ height: 480, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
        <EuiLoadingSpinner size="l" />
      </EuiPanel>
    );
  }

  const chartData = (data || []).slice(0, 12).map((item, index) => ({
    name: item.key?.length > 25 ? item.key.substring(0, 25) + '...' : item.key,
    fullName: item.key,
    value: item.count,
    color: CHART_COLORS[index % CHART_COLORS.length]
  }));

  const total = chartData.reduce((sum, item) => sum + item.value, 0);
  const itemCount = (data || []).length;

  return (
    <EuiPanel color="subdued" paddingSize="none" hasBorder style={{ overflow: 'hidden', height: 480 }}>
      {/* Header with subtitle */}
      <div style={{ padding: '16px 20px', borderBottom: `1px solid ${THEME_COLORS.cardBorder}` }}>
        <div style={{ fontWeight: '600', fontSize: '14px', color: THEME_COLORS.text.primary }}>
          {title}
        </div>
        <div style={{ fontSize: '12px', color: THEME_COLORS.text.muted, marginTop: '4px' }}>
          {itemCount} {subtitle || 'items'} • {total.toLocaleString()} total alerts
        </div>
      </div>

      <div style={{ display: 'flex', height: 'calc(100% - 65px)' }}>
        {/* Chart Area with center content */}
        <div style={{ flex: '1', padding: '20px', display: 'flex', alignItems: 'center', justifyContent: 'center', position: 'relative' }}>
          <ResponsiveContainer width="100%" height={320}>
            <PieChart>
              <Pie
                data={chartData}
                cx="50%"
                cy="50%"
                innerRadius={80}
                outerRadius={120}
                dataKey="value"
                onMouseEnter={(_, index) => setHoveredIndex(index)}
                onMouseLeave={() => setHoveredIndex(null)}
                onClick={(data) => onItemClick && onItemClick(data.fullName)}
                style={{ cursor: 'pointer' }}
              >
                {chartData.map((entry, index) => (
                  <Cell
                    key={`cell-${index}`}
                    fill={entry.color}
                    stroke={hoveredIndex === index ? '#fff' : 'transparent'}
                    strokeWidth={hoveredIndex === index ? 3 : 0}
                  />
                ))}
              </Pie>
              <Tooltip
                formatter={(value) => value.toLocaleString()}
                contentStyle={{
                  backgroundColor: THEME_COLORS.cardBackground,
                  border: `1px solid ${THEME_COLORS.cardBorder}`,
                  borderRadius: '6px',
                  boxShadow: '0 4px 12px rgba(0, 0, 0, 0.3)'
                }}
                itemStyle={{
                  color: '#ffffff'
                }}
                labelStyle={{
                  color: '#ffffff',
                  fontWeight: '600'
                }}
              />
            </PieChart>
          </ResponsiveContainer>

          {/* Center Content */}
          <div style={{
            position: 'absolute',
            top: '50%',
            left: '50%',
            transform: 'translate(-50%, -50%)',
            textAlign: 'center',
            pointerEvents: 'none'
          }}>
            <div style={{
              fontSize: '28px',
              fontWeight: '700',
              color: THEME_COLORS.text.primary
            }}>
              {hoveredIndex !== null ? chartData[hoveredIndex]?.value.toLocaleString() : total.toLocaleString()}
            </div>
            <div style={{
              fontSize: '11px',
              color: THEME_COLORS.text.muted,
              marginTop: '4px'
            }}>
              {hoveredIndex !== null ? chartData[hoveredIndex]?.name : 'Total Alerts'}
            </div>
            <div style={{
              fontSize: '10px',
              color: THEME_COLORS.text.muted
            }}>
              {centerLabel || 'All Items'}
            </div>
          </div>
        </div>

        {/* Legend Area with progress bars */}
        <div style={{
          width: '200px',
          borderLeft: `1px solid ${THEME_COLORS.cardBorder}`,
          padding: '12px',
          overflowY: 'auto',
          maxHeight: '400px'
        }}>
          {chartData.map((entry, index) => {
            const percentage = total > 0 ? (entry.value / total) * 100 : 0;
            return (
              <div
                key={index}
                style={{
                  padding: '8px',
                  borderRadius: '4px',
                  cursor: 'pointer',
                  backgroundColor: hoveredIndex === index ? 'rgba(255,255,255,0.05)' : 'transparent',
                  transition: 'background-color 0.2s',
                  marginBottom: '4px'
                }}
                onMouseEnter={() => setHoveredIndex(index)}
                onMouseLeave={() => setHoveredIndex(null)}
                onClick={() => onItemClick && onItemClick(entry.fullName)}
              >
                <div style={{ display: 'flex', alignItems: 'center', gap: '8px', marginBottom: '4px' }}>
                  <div style={{
                    width: '10px',
                    height: '10px',
                    borderRadius: '50%',
                    backgroundColor: entry.color,
                    flexShrink: 0
                  }} />
                  <div style={{
                    fontSize: '11px',
                    color: THEME_COLORS.text.primary,
                    whiteSpace: 'nowrap',
                    overflow: 'hidden',
                    textOverflow: 'ellipsis',
                    flex: 1
                  }}>
                    {entry.name}
                  </div>
                </div>
                <div style={{ display: 'flex', alignItems: 'center', gap: '8px', paddingLeft: '18px' }}>
                  <span style={{ fontSize: '11px', fontWeight: '600', color: THEME_COLORS.text.primary, minWidth: '45px' }}>
                    {entry.value.toLocaleString()}
                  </span>
                  {/* Progress Bar */}
                  <div style={{
                    flex: 1,
                    height: '4px',
                    backgroundColor: isDarkTheme ? 'rgba(255,255,255,0.1)' : 'rgba(0,0,0,0.1)',
                    borderRadius: '2px',
                    overflow: 'hidden'
                  }}>
                    <div style={{
                      width: `${percentage}%`,
                      height: '100%',
                      backgroundColor: entry.color,
                      borderRadius: '2px'
                    }} />
                  </div>
                  <span style={{ fontSize: '10px', color: THEME_COLORS.text.muted, minWidth: '35px', textAlign: 'right' }}>
                    {percentage.toFixed(1)}%
                  </span>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </EuiPanel>
  );
};

// Network Analysis Donut Chart - matching plugin design
const NetworkDonutChart = ({ title, subtitle, data, dataKey, loading, onItemClick, isDarkTheme, centerLabel }) => {
  const [hoveredIndex, setHoveredIndex] = useState(null);

  if (loading) {
    return (
      <EuiPanel color="subdued" paddingSize="l" hasBorder style={{ height: 480, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
        <EuiLoadingSpinner size="l" />
      </EuiPanel>
    );
  }

  const chartData = (data || []).slice(0, 12).map((item, index) => ({
    name: item[dataKey]?.length > 20 ? item[dataKey].substring(0, 20) + '...' : item[dataKey],
    fullName: item[dataKey],
    value: item.count,
    color: CHART_COLORS[index % CHART_COLORS.length]
  }));

  const total = chartData.reduce((sum, item) => sum + item.value, 0);
  const itemCount = (data || []).length;

  return (
    <EuiPanel color="subdued" paddingSize="none" hasBorder style={{ overflow: 'hidden', height: 480 }}>
      {/* Header with subtitle */}
      <div style={{ padding: '16px 20px', borderBottom: `1px solid ${THEME_COLORS.cardBorder}` }}>
        <div style={{ fontWeight: '600', fontSize: '14px', color: THEME_COLORS.text.primary }}>
          {title}
        </div>
        <div style={{ fontSize: '12px', color: THEME_COLORS.text.muted, marginTop: '4px' }}>
          {itemCount} {subtitle || 'hosts'} • {total.toLocaleString()} total alerts
        </div>
      </div>

      <div style={{ display: 'flex', height: 'calc(100% - 65px)' }}>
        {/* Chart Area */}
        <div style={{ flex: '1', padding: '20px', display: 'flex', alignItems: 'center', justifyContent: 'center', position: 'relative' }}>
          <ResponsiveContainer width="100%" height={320}>
            <PieChart>
              <Pie
                data={chartData}
                cx="50%"
                cy="50%"
                innerRadius={70}
                outerRadius={110}
                dataKey="value"
                onMouseEnter={(_, index) => setHoveredIndex(index)}
                onMouseLeave={() => setHoveredIndex(null)}
                onClick={(data) => onItemClick && onItemClick(data.fullName)}
                style={{ cursor: 'pointer' }}
              >
                {chartData.map((entry, index) => (
                  <Cell
                    key={`cell-${index}`}
                    fill={entry.color}
                    stroke={hoveredIndex === index ? '#fff' : 'transparent'}
                    strokeWidth={hoveredIndex === index ? 3 : 0}
                  />
                ))}
              </Pie>
              <Tooltip
                formatter={(value) => value.toLocaleString()}
                contentStyle={{
                  backgroundColor: THEME_COLORS.cardBackground,
                  border: `1px solid ${THEME_COLORS.cardBorder}`,
                  borderRadius: '6px',
                  boxShadow: '0 4px 12px rgba(0, 0, 0, 0.3)'
                }}
                itemStyle={{
                  color: '#ffffff'
                }}
                labelStyle={{
                  color: '#ffffff',
                  fontWeight: '600'
                }}
              />
            </PieChart>
          </ResponsiveContainer>

          {/* Center Content */}
          <div style={{
            position: 'absolute',
            top: '50%',
            left: '50%',
            transform: 'translate(-50%, -50%)',
            textAlign: 'center',
            pointerEvents: 'none'
          }}>
            <div style={{
              fontSize: '26px',
              fontWeight: '700',
              color: THEME_COLORS.text.primary
            }}>
              {hoveredIndex !== null ? chartData[hoveredIndex]?.value.toLocaleString() : total.toLocaleString()}
            </div>
            <div style={{
              fontSize: '10px',
              color: THEME_COLORS.text.muted,
              marginTop: '4px'
            }}>
              {hoveredIndex !== null ? chartData[hoveredIndex]?.name : 'Total Alerts'}
            </div>
            <div style={{
              fontSize: '9px',
              color: THEME_COLORS.text.muted
            }}>
              {centerLabel || 'All Hosts'}
            </div>
          </div>
        </div>

        {/* Legend Area with progress bars */}
        <div style={{
          width: '180px',
          borderLeft: `1px solid ${THEME_COLORS.cardBorder}`,
          padding: '12px',
          overflowY: 'auto',
          maxHeight: '400px'
        }}>
          {chartData.map((entry, index) => {
            const percentage = total > 0 ? (entry.value / total) * 100 : 0;
            return (
              <div
                key={index}
                style={{
                  padding: '6px',
                  borderRadius: '4px',
                  cursor: 'pointer',
                  backgroundColor: hoveredIndex === index ? 'rgba(255,255,255,0.05)' : 'transparent',
                  transition: 'background-color 0.2s',
                  marginBottom: '2px'
                }}
                onMouseEnter={() => setHoveredIndex(index)}
                onMouseLeave={() => setHoveredIndex(null)}
                onClick={() => onItemClick && onItemClick(entry.fullName)}
              >
                <div style={{ display: 'flex', alignItems: 'center', gap: '6px', marginBottom: '3px' }}>
                  <div style={{
                    width: '8px',
                    height: '8px',
                    borderRadius: '50%',
                    backgroundColor: entry.color,
                    flexShrink: 0
                  }} />
                  <div style={{
                    fontSize: '10px',
                    color: THEME_COLORS.text.primary,
                    whiteSpace: 'nowrap',
                    overflow: 'hidden',
                    textOverflow: 'ellipsis',
                    flex: 1
                  }}>
                    {entry.name}
                  </div>
                </div>
                <div style={{ display: 'flex', alignItems: 'center', gap: '6px', paddingLeft: '14px' }}>
                  <span style={{ fontSize: '10px', fontWeight: '600', color: THEME_COLORS.text.primary, minWidth: '40px' }}>
                    {entry.value.toLocaleString()}
                  </span>
                  {/* Progress Bar */}
                  <div style={{
                    flex: 1,
                    height: '3px',
                    backgroundColor: isDarkTheme ? 'rgba(255,255,255,0.1)' : 'rgba(0,0,0,0.1)',
                    borderRadius: '2px',
                    overflow: 'hidden'
                  }}>
                    <div style={{
                      width: `${percentage}%`,
                      height: '100%',
                      backgroundColor: entry.color,
                      borderRadius: '2px'
                    }} />
                  </div>
                  <span style={{ fontSize: '9px', color: THEME_COLORS.text.muted, minWidth: '32px', textAlign: 'right' }}>
                    {percentage.toFixed(1)}%
                  </span>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </EuiPanel>
  );
};

// Detail Section Component for expanded rows
const DetailSection = ({ title, children, icon }) => (
  <div style={{
    backgroundColor: 'rgba(0, 0, 0, 0.15)',
    borderRadius: '6px',
    marginBottom: '12px',
    overflow: 'hidden'
  }}>
    <div style={{
      padding: '10px 14px',
      backgroundColor: 'rgba(0, 0, 0, 0.2)',
      borderBottom: '1px solid rgba(255, 255, 255, 0.1)',
      display: 'flex',
      alignItems: 'center',
      gap: '8px'
    }}>
      <EuiIcon type={icon || 'document'} size="s" color="#36a2ef" />
      <span style={{
        fontSize: '12px',
        fontWeight: '600',
        color: '#dfe5ef',
        textTransform: 'uppercase',
        letterSpacing: '0.5px'
      }}>
        {title}
      </span>
    </div>
    <div style={{ padding: '12px 14px' }}>
      {children}
    </div>
  </div>
);

// Detail Item Component for key-value pairs
const DetailItem = ({ label, value, isCode = false, fullWidth = false }) => (
  <div style={{
    marginBottom: '8px',
    ...(fullWidth ? { gridColumn: '1 / -1' } : {})
  }}>
    <div style={{
      fontSize: '10px',
      fontWeight: '500',
      color: '#98a2b3',
      textTransform: 'uppercase',
      letterSpacing: '0.3px',
      marginBottom: '3px'
    }}>
      {label}
    </div>
    <div style={{
      fontSize: '13px',
      color: '#dfe5ef',
      fontWeight: '400',
      ...(isCode ? {
        fontFamily: 'monospace',
        backgroundColor: 'rgba(0, 0, 0, 0.2)',
        padding: '4px 8px',
        borderRadius: '4px',
        fontSize: '12px'
      } : {})
    }}>
      {value || 'N/A'}
    </div>
  </div>
);

// Expanded Event Details Component - matching original plugin design
const ExpandedEventDetails = ({ event }) => {
  // Helper to format timestamp
  const formatTimestamp = (ts) => {
    if (!ts) return 'N/A';
    const date = new Date(ts);
    return date.toLocaleString('en-US', {
      year: 'numeric',
      month: 'short',
      day: '2-digit',
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit',
      hour12: false
    });
  };

  // Helper to format bytes
  const formatBytes = (bytes) => {
    if (!bytes || bytes === 0) return '0 B';
    const k = 1024;
    const sizes = ['B', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  };

  return (
    <div style={{
      padding: '16px',
      backgroundColor: '#1d1e24',
      borderRadius: '8px',
      margin: '8px 0'
    }}>
      {/* Row 1: Alert Info, Network Info, System & Debug */}
      <div style={{
        display: 'grid',
        gridTemplateColumns: 'repeat(3, 1fr)',
        gap: '16px',
        marginBottom: '16px'
      }}>
        {/* ALERT INFORMATION */}
        <DetailSection title="Alert Information" icon="bell">
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '8px' }}>
            <DetailItem label="Signature ID" value={event.signatureId} isCode />
            <DetailItem label="Revision" value={event.rev || event.revision} />
            <DetailItem label="Severity" value={`Level ${event.severity}`} />
            <DetailItem label="GID" value={event.gid} />
            <DetailItem label="Category" value={event.category} />
            <DetailItem label="Action" value={event.action || 'allowed'} />
          </div>
        </DetailSection>

        {/* NETWORK INFORMATION */}
        <DetailSection title="Network Information" icon="globe">
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '8px' }}>
            <DetailItem label="Source IP" value={event.srcIp} isCode />
            <DetailItem label="Dest IP" value={event.destIp} isCode />
            <DetailItem label="Protocol" value={event.proto || event.appProto} />
            <DetailItem label="Interface" value={event.inIface} />
            <DetailItem label="VLAN" value={Array.isArray(event.vlan) ? event.vlan.join(', ') : event.vlan} />
            <DetailItem label="Community ID" value={event.communityId} isCode />
          </div>
        </DetailSection>

        {/* SYSTEM & DEBUG */}
        <DetailSection title="System & Debug" icon="gear">
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '8px' }}>
            <DetailItem label="Timestamp" value={formatTimestamp(event.timestamp)} />
            <DetailItem label="Flow ID" value={event.flowId} isCode />
            <DetailItem label="PCAP Count" value={event.pcapCnt} />
            <DetailItem label="TX ID" value={event.txId} />
            <DetailItem label="Event Type" value={event.eventType || 'alert'} />
            <DetailItem label="Index" value={event._index} />
          </div>
        </DetailSection>
      </div>

      {/* Row 2: Network Details, Port Info, Autonomous Systems */}
      <div style={{
        display: 'grid',
        gridTemplateColumns: 'repeat(3, 1fr)',
        gap: '16px',
        marginBottom: '16px'
      }}>
        {/* NETWORK DETAILS */}
        <DetailSection title="Network Details" icon="node">
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '8px' }}>
            <DetailItem label="Source Hostname" value={event.srcHostname || event.src?.hostname} />
            <DetailItem label="Dest Hostname" value={event.destHostname || event.dest?.hostname} />
            <DetailItem label="App Protocol" value={event.appProto} />
            <DetailItem label="Direction" value={event.flowDirection || event.direction} />
            <DetailItem label="ICMP Type" value={event.icmpType} />
            <DetailItem label="ICMP Code" value={event.icmpCode} />
          </div>
        </DetailSection>

        {/* PORT INFORMATION */}
        <DetailSection title="Port Information" icon="inputOutput">
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '8px' }}>
            <DetailItem label="Source Port" value={event.srcPort} isCode />
            <DetailItem label="Dest Port" value={event.destPort} isCode />
            <DetailItem label="Service" value={event.serviceName || event.service} />
            <DetailItem label="Transport" value={event.proto} />
          </div>
        </DetailSection>

        {/* AUTONOMOUS SYSTEMS */}
        <DetailSection title="Autonomous Systems" icon="visMapRegion">
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '8px' }}>
            <DetailItem label="Source ASN" value={event.srcAsn || event.src?.as?.number} />
            <DetailItem label="Dest ASN" value={event.destAsn || event.dest?.as?.number} />
            <DetailItem label="Source Org" value={event.srcAsOrg || event.src?.as?.organization?.name} />
            <DetailItem label="Dest Org" value={event.destAsOrg || event.dest?.as?.organization?.name} />
            <DetailItem label="Source Country" value={event.srcGeoCountry || event.src?.geo?.country_name} />
            <DetailItem label="Dest Country" value={event.destGeoCountry || event.dest?.geo?.country_name} />
          </div>
        </DetailSection>
      </div>

      {/* Row 3: Client Info, Server Info, Flow Statistics */}
      <div style={{
        display: 'grid',
        gridTemplateColumns: 'repeat(3, 1fr)',
        gap: '16px',
        marginBottom: '16px'
      }}>
        {/* CLIENT INFORMATION */}
        <DetailSection title="Client Information" icon="user">
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '8px' }}>
            <DetailItem label="IP" value={event.srcIp || event.client?.ip} isCode />
            <DetailItem label="Port" value={event.srcPort || event.client?.port} />
            <DetailItem label="MAC" value={event.srcMac || event.client?.mac} isCode />
            <DetailItem label="Packets" value={event.flowPktsToclient || event.flow?.pkts_toclient} />
            <DetailItem label="Bytes" value={formatBytes(event.flowBytesToclient || event.flow?.bytes_toclient)} />
          </div>
        </DetailSection>

        {/* SERVER INFORMATION */}
        <DetailSection title="Server Information" icon="database">
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '8px' }}>
            <DetailItem label="IP" value={event.destIp || event.server?.ip} isCode />
            <DetailItem label="Port" value={event.destPort || event.server?.port} />
            <DetailItem label="MAC" value={event.destMac || event.server?.mac} isCode />
            <DetailItem label="Packets" value={event.flowPktsToserver || event.flow?.pkts_toserver} />
            <DetailItem label="Bytes" value={formatBytes(event.flowBytesToserver || event.flow?.bytes_toserver)} />
          </div>
        </DetailSection>

        {/* FLOW STATISTICS */}
        <DetailSection title="Flow Statistics" icon="visLine">
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '8px' }}>
            <DetailItem label="Flow Start" value={formatTimestamp(event.flowStart || event.flow?.start)} />
            <DetailItem label="Flow End" value={formatTimestamp(event.flowEnd || event.flow?.end)} />
            <DetailItem label="Age" value={event.flowAge ? `${event.flowAge}s` : 'N/A'} />
            <DetailItem label="State" value={event.flowState || event.flow?.state} />
            <DetailItem label="Reason" value={event.flowReason || event.flow?.reason} />
            <DetailItem label="Alerted" value={event.flowAlerted ? 'Yes' : 'No'} />
          </div>
        </DetailSection>
      </div>

      {/* Row 4: Tunnel Info, Tags, Full Signature */}
      <div style={{
        display: 'grid',
        gridTemplateColumns: '1fr 1fr 2fr',
        gap: '16px'
      }}>
        {/* TUNNEL INFORMATION */}
        <DetailSection title="Tunnel Information" icon="layers">
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '8px' }}>
            <DetailItem label="Tunnel Type" value={event.tunnelType || event.tunnel?.type} />
            <DetailItem label="Tunnel Depth" value={event.tunnelDepth || event.tunnel?.depth} />
            <DetailItem label="Parent ID" value={event.tunnelParentId || event.tunnel?.parent_id} />
          </div>
        </DetailSection>

        {/* TAGS */}
        <DetailSection title="Tags" icon="tag">
          <div style={{ display: 'flex', flexWrap: 'wrap', gap: '6px' }}>
            {(event.tags || []).length > 0 ? (
              event.tags.map((tag, idx) => (
                <EuiBadge key={idx} color="hollow">{tag}</EuiBadge>
              ))
            ) : (
              <span style={{ color: '#69707d', fontSize: '12px' }}>No tags</span>
            )}
          </div>
        </DetailSection>

        {/* FULL SIGNATURE */}
        <DetailSection title="Full Signature" icon="securitySignal">
          <div style={{
            backgroundColor: 'rgba(0, 0, 0, 0.2)',
            padding: '12px',
            borderRadius: '4px',
            fontFamily: 'monospace',
            fontSize: '12px',
            color: '#dfe5ef',
            wordBreak: 'break-word',
            lineHeight: '1.6',
            maxHeight: '100px',
            overflowY: 'auto'
          }}>
            {event.signature || event.alert?.signature || 'N/A'}
          </div>
          {event.metadata && (
            <div style={{ marginTop: '8px' }}>
              <DetailItem label="Metadata" value={
                typeof event.metadata === 'object'
                  ? JSON.stringify(event.metadata, null, 2)
                  : event.metadata
              } isCode fullWidth />
            </div>
          )}
        </DetailSection>
      </div>
    </div>
  );
};

// Events Table Component
const EventsTable = ({ events, loading, pagination, onTableChange, expandedRowIds, toggleRowExpansion }) => {
  const getSeverityBadge = (severity) => {
    const config = SEVERITY_CONFIG[String(severity)] || SEVERITY_CONFIG['5+'];
    const badgeStyle = BADGE_STYLES.severity[String(severity)] || BADGE_STYLES.severity['5+'];
    return (
      <span
        style={{
          display: 'inline-block',
          background: badgeStyle.background,
          color: badgeStyle.color,
          border: badgeStyle.border,
          fontWeight: '600',
          padding: '3px 8px',
          fontSize: '10px',
          borderRadius: '4px',
          textTransform: 'uppercase',
          letterSpacing: '0.3px'
        }}
      >
        {config.label}
      </span>
    );
  };

  const getActionBadge = (action) => {
    const actionLower = (action || 'allowed').toLowerCase();
    const isBlocked = actionLower === 'blocked' || actionLower === 'drop' || actionLower === 'reject';
    const badgeStyle = isBlocked ? BADGE_STYLES.action.blocked : BADGE_STYLES.action.allowed;
    return (
      <span
        style={{
          display: 'inline-block',
          background: badgeStyle.background,
          color: badgeStyle.color,
          border: badgeStyle.border,
          fontWeight: '500',
          padding: '3px 8px',
          fontSize: '10px',
          borderRadius: '4px'
        }}
      >
        {action || 'allowed'}
      </span>
    );
  };

  const columns = [
    {
      field: 'timestamp',
      name: 'TIMESTAMP',
      sortable: true,
      width: '160px',
      render: (timestamp) => (
        <span style={{ fontSize: '12px', color: '#98a2b3' }}>
          {new Date(timestamp).toLocaleString('en-US', {
            month: 'short',
            day: '2-digit',
            hour: '2-digit',
            minute: '2-digit',
            second: '2-digit',
            hour12: false
          })}
        </span>
      )
    },
    {
      field: 'srcIp',
      name: 'SOURCE IP',
      width: '130px',
      render: (ip) => (
        <code style={{
          fontSize: '12px',
          backgroundColor: 'rgba(0, 0, 0, 0.2)',
          padding: '3px 6px',
          borderRadius: '3px'
        }}>
          {ip || 'N/A'}
        </code>
      )
    },
    {
      field: 'destIp',
      name: 'DEST IP',
      width: '130px',
      render: (ip) => (
        <code style={{
          fontSize: '12px',
          backgroundColor: 'rgba(0, 0, 0, 0.2)',
          padding: '3px 6px',
          borderRadius: '3px'
        }}>
          {ip || 'N/A'}
        </code>
      )
    },
    {
      field: 'signature',
      name: 'SIGNATURE',
      truncateText: true,
      render: (sig) => (
        <span style={{ fontSize: '12px' }} title={sig}>
          {sig?.length > 60 ? sig.substring(0, 60) + '...' : sig || 'N/A'}
        </span>
      )
    },
    {
      field: 'category',
      name: 'CATEGORY',
      sortable: true,
      width: '180px',
      render: (cat) => (
        <span
          style={{
            display: 'inline-block',
            background: BADGE_STYLES.category.background,
            color: BADGE_STYLES.category.color,
            border: BADGE_STYLES.category.border,
            fontWeight: '500',
            padding: '3px 8px',
            fontSize: '10px',
            borderRadius: '4px',
            maxWidth: '160px',
            overflow: 'hidden',
            textOverflow: 'ellipsis',
            whiteSpace: 'nowrap'
          }}
          title={cat}
        >
          {cat || 'N/A'}
        </span>
      )
    },
    {
      field: 'severity',
      name: 'SEVERITY',
      sortable: true,
      width: '100px',
      render: getSeverityBadge
    },
    {
      field: 'action',
      name: 'ACTION',
      width: '90px',
      render: getActionBadge
    },
    {
      field: 'appProto',
      name: 'PROTOCOL',
      width: '90px',
      render: (proto) => proto ? (
        <span
          style={{
            display: 'inline-block',
            background: BADGE_STYLES.protocol.background,
            color: BADGE_STYLES.protocol.color,
            border: BADGE_STYLES.protocol.border,
            fontWeight: '500',
            padding: '3px 8px',
            fontSize: '10px',
            borderRadius: '4px',
            textTransform: 'uppercase'
          }}
        >
          {proto}
        </span>
      ) : '-'
    }
  ];

  const itemIdToExpandedRowMap = useMemo(() => {
    const map = {};
    events.forEach(event => {
      if (expandedRowIds.includes(event.id)) {
        map[event.id] = <ExpandedEventDetails event={event} />;
      }
    });
    return map;
  }, [events, expandedRowIds]);

  return (
    <EuiBasicTable
      items={events}
      columns={columns}
      itemId="id"
      loading={loading}
      pagination={pagination}
      onChange={onTableChange}
      isExpandable={true}
      itemIdToExpandedRowMap={itemIdToExpandedRowMap}
      rowProps={(item) => ({
        onClick: () => toggleRowExpansion(item.id),
        style: { cursor: 'pointer' }
      })}
      tableLayout="auto"
    />
  );
};

// Main NIDS Dashboard Component
const NIDSDashboard = () => {
  // State
  const [activeTab, setActiveTab] = useState('overview');
  // Time range state for EuiSuperDatePicker (supports custom dates)
  const [timeRangeStart, setTimeRangeStart] = useState('now-24h');
  const [timeRangeEnd, setTimeRangeEnd] = useState('now');
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  // Theme detection state
  const [isDarkTheme, setIsDarkTheme] = useState(true);

  useEffect(() => {
    const checkTheme = () => {
      const isDark = document.body.classList.contains('euiTheme-dark') ||
                     document.documentElement.getAttribute('data-theme') === 'dark' ||
                     !document.body.classList.contains('euiTheme-light');
      setIsDarkTheme(isDark);
    };
    checkTheme();
    const observer = new MutationObserver(checkTheme);
    observer.observe(document.body, { attributes: true, attributeFilter: ['class'] });
    observer.observe(document.documentElement, { attributes: true, attributeFilter: ['data-theme'] });
    return () => observer.disconnect();
  }, []);

  // Data state
  const [overviewData, setOverviewData] = useState(null);
  const [networkData, setNetworkData] = useState(null);
  const [timelineData, setTimelineData] = useState(null); // Separate timeline with per-bucket severity
  const [eventsData, setEventsData] = useState({ events: [], total: 0 });
  const [filterOptions, setFilterOptions] = useState(null);

  // Filter state
  const [filters, setFilters] = useState({
    category: '',
    signature: '',
    severity: '',
    srcIp: '',
    destIp: '',
    serviceName: '',
    search: ''
  });
  const [activeSeverityFilter, setActiveSeverityFilter] = useState(null);

  // Time slot filter state (for timeline click)
  const [timeSlotFilter, setTimeSlotFilter] = useState(null); // { start: ISO, end: ISO, label: string }

  // Pagination state
  const [pagination, setPagination] = useState({
    pageIndex: 0,
    pageSize: 20
  });

  // Expanded rows state
  const [expandedRowIds, setExpandedRowIds] = useState([]);

  // Build current filters object for API calls
  const currentFilters = useMemo(() => ({
    category: filters.category || undefined,
    signature: filters.signature || undefined,
    severity: activeSeverityFilter || filters.severity || undefined,
    srcIp: filters.srcIp || undefined,
    destIp: filters.destIp || undefined,
    serviceName: filters.serviceName || undefined
  }), [filters, activeSeverityFilter]);

  // Fetch overview data
  const fetchOverviewData = useCallback(async () => {
    try {
      setLoading(true);

      // Use time slot filter if set, otherwise use the general time range
      const startParam = timeSlotFilter ? timeSlotFilter.start : timeRangeStart;
      const endParam = timeSlotFilter ? timeSlotFilter.end : timeRangeEnd;

      const [overview, network, filterOpts, timeline] = await Promise.all([
        fetchNIDSOverview(startParam, endParam, currentFilters),
        fetchNIDSNetworkAnalysis(startParam, endParam, 15, currentFilters),
        fetchNIDSFilters(startParam, endParam),
        fetchNIDSTimeline({ start: startParam, end: endParam, interval: 'auto' })
      ]);

      // Debug logging to trace data flow
      console.log('NIDS Debug - Overview response:', {
        totalAlerts: overview?.totalAlerts,
        severityBreakdown: overview?.severityBreakdown,
        topCategories: overview?.topCategories?.length,
        topSignatures: overview?.topSignatures?.length
      });
      console.log('NIDS Debug - Timeline response:', {
        dataLength: timeline?.data?.length,
        sampleBucket: timeline?.data?.[0]
      });

      setOverviewData(overview);
      setNetworkData(network);
      setFilterOptions(filterOpts);
      setTimelineData(timeline);
      setError(null);
    } catch (err) {
      console.error('Error fetching overview:', err);
      setError(err.message);
    } finally {
      setLoading(false);
    }
  }, [timeRangeStart, timeRangeEnd, currentFilters, timeSlotFilter]);

  // Fetch events data
  const fetchEventsData = useCallback(async () => {
    try {
      setLoading(true);

      // Use time slot filter if set, otherwise use the general time range
      const startParam = timeSlotFilter ? timeSlotFilter.start : timeRangeStart;
      const endParam = timeSlotFilter ? timeSlotFilter.end : timeRangeEnd;

      const result = await fetchNIDSEvents({
        start: startParam,
        end: endParam,
        limit: pagination.pageSize,
        offset: pagination.pageIndex * pagination.pageSize,
        category: filters.category || undefined,
        signature: filters.signature || undefined,
        severity: activeSeverityFilter || filters.severity || undefined,
        srcIp: filters.srcIp || undefined,
        destIp: filters.destIp || undefined,
        serviceName: filters.serviceName || undefined,
        search: filters.search || undefined
      });

      setEventsData(result);
      setError(null);
    } catch (err) {
      console.error('Error fetching events:', err);
      setError(err.message);
    } finally {
      setLoading(false);
    }
  }, [timeRangeStart, timeRangeEnd, pagination, filters, activeSeverityFilter, timeSlotFilter]);

  // Main tab change effect
  useEffect(() => {
    if (activeTab === 'overview') {
      fetchOverviewData();
    } else {
      fetchEventsData();
    }
  }, [activeTab, fetchOverviewData, fetchEventsData]);

  // Additional effect to refetch data when filters change
  useEffect(() => {
    if (activeTab === 'events') {
      fetchEventsData();
    } else if (activeTab === 'overview') {
      fetchOverviewData();
    }
  }, [filters, activeSeverityFilter, timeSlotFilter]); // eslint-disable-line react-hooks/exhaustive-deps

  // Effect to refetch events when pagination changes on events tab
  useEffect(() => {
    if (activeTab === 'events') {
      fetchEventsData();
    }
  }, [pagination.pageIndex, pagination.pageSize]); // eslint-disable-line react-hooks/exhaustive-deps

  // Handlers
  const handleTimeRangeChange = ({ start, end }) => {
    setTimeRangeStart(start);
    setTimeRangeEnd(end);
    setTimeSlotFilter(null); // Clear any time slot filter when changing range
    setPagination({ ...pagination, pageIndex: 0 });
  };

  const handleSeverityCardClick = (severity) => {
    if (activeSeverityFilter === severity) {
      setActiveSeverityFilter(null);
    } else {
      setActiveSeverityFilter(severity);
      setActiveTab('events');
    }
    setPagination({ ...pagination, pageIndex: 0 });
  };

  const handleCategoryClick = (category) => {
    setFilters({ ...filters, category });
    setActiveTab('events');
    setPagination({ ...pagination, pageIndex: 0 });
  };

  const handleSignatureClick = (signature) => {
    setFilters({ ...filters, signature });
    setActiveTab('events');
    setPagination({ ...pagination, pageIndex: 0 });
  };

  const handleNetworkClick = (value, filterType) => {
    // Set the appropriate filter based on click type
    const newFilters = { ...filters };

    if (filterType === 'srcIp') {
      newFilters.srcIp = value;
    } else if (filterType === 'destIp') {
      newFilters.destIp = value;
    } else if (filterType === 'serviceName') {
      newFilters.serviceName = value;
    }

    setFilters(newFilters);
    setActiveTab('events');
    setPagination({ ...pagination, pageIndex: 0 });
  };

  // Handle timeline chart bar click - navigate to events for that time slot
  const handleTimeSlotClick = (startTimestamp, endTimestamp) => {
    // Convert timestamps to time range filter format
    const start = new Date(startTimestamp);

    // If we have an end timestamp, use it; otherwise calculate based on current interval
    let end;
    if (endTimestamp) {
      end = new Date(endTimestamp);
    } else {
      // Estimate the interval based on current time range setting
      const intervalMs = getIntervalMs(timeRangeStart);
      end = new Date(start.getTime() + intervalMs);
    }

    // Format label for display
    const label = start.toLocaleString('en-US', {
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
      hour12: false
    });

    // Set the time slot filter with absolute timestamps
    setTimeSlotFilter({
      start: start.toISOString(),
      end: end.toISOString(),
      label: label
    });

    // Switch to events tab
    setActiveTab('events');
    setPagination({ ...pagination, pageIndex: 0 });
  };

  // Helper to get interval in milliseconds based on time range
  const getIntervalMs = (range) => {
    if (range?.includes('15m') || range?.includes('1h')) {
      return 5 * 60 * 1000; // 5 minutes
    } else if (range?.includes('24h')) {
      return 60 * 60 * 1000; // 1 hour
    } else {
      return 24 * 60 * 60 * 1000; // 1 day
    }
  };

  const handleTableChange = ({ page }) => {
    setPagination({
      pageIndex: page.index,
      pageSize: page.size
    });
  };

  const toggleRowExpansion = (id) => {
    setExpandedRowIds(prev =>
      prev.includes(id) ? prev.filter(i => i !== id) : [...prev, id]
    );
  };

  const handleClearFilters = () => {
    setFilters({ category: '', signature: '', severity: '', srcIp: '', destIp: '', serviceName: '', search: '' });
    setActiveSeverityFilter(null);
    setTimeSlotFilter(null);
    setPagination({ ...pagination, pageIndex: 0 });
  };

  const handleRefresh = () => {
    if (activeTab === 'overview') {
      fetchOverviewData();
    } else {
      fetchEventsData();
    }
  };

  // Build severity data for cards - use overview data, fallback to timeline data
  const severityCardData = useMemo(() => {
    // First try overview data
    const overviewSeverity = overviewData?.severityBreakdown || [];
    const hasOverviewData = overviewSeverity.some(item => item.count > 0);

    if (hasOverviewData) {
      const data = {};
      overviewSeverity.forEach(item => {
        data[item.key] = {
          count: item.count,
          percentage: item.percentage
        };
      });
      return data;
    }

    // Fallback: calculate from timeline data (more reliable as it has per-bucket severity)
    if (timelineData?.data?.length > 0) {
      const totals = { '1': 0, '2': 0, '3': 0, '4': 0, '5+': 0 };

      timelineData.data.forEach(bucket => {
        const bySeverity = bucket.bySeverity || {};
        totals['1'] += bySeverity['1'] || 0;
        totals['2'] += bySeverity['2'] || 0;
        totals['3'] += bySeverity['3'] || 0;
        totals['4'] += bySeverity['4'] || 0;
        // Sum severity 5+ into others
        Object.entries(bySeverity).forEach(([key, val]) => {
          if (parseInt(key) >= 5) totals['5+'] += val;
        });
      });

      const total = Object.values(totals).reduce((sum, c) => sum + c, 0);
      const data = {};
      Object.entries(totals).forEach(([key, count]) => {
        data[key] = {
          count,
          percentage: total > 0 ? Math.round(count / total * 1000) / 10 : 0
        };
      });
      return data;
    }

    return {};
  }, [overviewData, timelineData]);

  // Active filters count
  const activeFiltersCount = [
    filters.category,
    filters.signature,
    filters.severity,
    filters.srcIp,
    filters.destIp,
    filters.serviceName,
    filters.search,
    activeSeverityFilter,
    timeSlotFilter
  ].filter(Boolean).length;

  return (
    <div style={{
      width: '100%',
      minHeight: '100vh',
      backgroundColor: THEME_COLORS.background,
      padding: '0'
    }}>
      {/* Enhanced Header Bar - matching plugin design */}
      <div style={{
        backgroundColor: THEME_COLORS.headerBackground,
        borderBottom: `1px solid ${THEME_COLORS.cardBorder}`,
        padding: '16px 24px',
        boxShadow: '0 2px 8px rgba(0, 0, 0, 0.12)'
      }}>
        {/* Page Title */}
        <div style={{
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'space-between',
          marginBottom: '16px'
        }}>
          <div>
            <h1 style={{
              color: THEME_COLORS.text.primary,
              fontSize: '22px',
              fontWeight: '600',
              margin: '0',
              display: 'flex',
              alignItems: 'center',
              gap: '10px'
            }}>
              <EuiIcon type="securitySignal" size="l" color={THEME_COLORS.text.accent} />
              NIDS summary overview
            </h1>
            <p style={{
              color: THEME_COLORS.text.secondary,
              fontSize: '13px',
              margin: '4px 0 0 0'
            }}>
              Real-time network intrusion detection and analysis
            </p>
          </div>
        </div>

        {/* Filter Controls - Full-width single-line design */}
        <EuiPanel color="subdued" paddingSize="m" hasBorder>
          <div style={{
            display: 'flex',
            alignItems: 'center',
            gap: '12px',
            flexWrap: 'nowrap',
            overflow: 'hidden'
          }}>
            {/* Time Range - SuperDatePicker with custom date support */}
            <div style={{ flexShrink: 0, width: '280px' }}>
              <EuiSuperDatePicker
                start={timeRangeStart}
                end={timeRangeEnd}
                onTimeChange={handleTimeRangeChange}
                isPaused={true}
                showUpdateButton={false}
                isQuickSelectOnly={false}
                commonlyUsedRanges={[
                  { start: 'now-15m', end: 'now', label: 'Last 15 minutes' },
                  { start: 'now-1h', end: 'now', label: 'Last 1 hour' },
                  { start: 'now-6h', end: 'now', label: 'Last 6 hours' },
                  { start: 'now-12h', end: 'now', label: 'Last 12 hours' },
                  { start: 'now-24h', end: 'now', label: 'Last 24 hours' },
                  { start: 'now-3d', end: 'now', label: 'Last 3 days' },
                  { start: 'now-7d', end: 'now', label: 'Last 7 days' },
                  { start: 'now-14d', end: 'now', label: 'Last 14 days' },
                  { start: 'now-30d', end: 'now', label: 'Last 30 days' },
                  { start: 'now-90d', end: 'now', label: 'Last 90 days' }
                ]}
                compressed
                width="full"
              />
            </div>

            {/* Separator */}
            <div style={{ borderLeft: `1px solid ${THEME_COLORS.cardBorder}`, height: '32px' }} />

            {/* Category Filter */}
            <div style={{ display: 'flex', alignItems: 'center', gap: '6px', flexShrink: 0 }}>
              <EuiIcon type="tag" size="s" color={THEME_COLORS.text.muted} />
              <EuiSelect
                options={[
                  { value: '', text: 'All Categories' },
                  ...(filterOptions?.categories || []).map(c => ({
                    value: c.value,
                    text: c.label?.length > 20 ? c.label.substring(0, 20) + '...' : c.label
                  }))
                ]}
                value={filters.category}
                onChange={(e) => {
                  setFilters({ ...filters, category: e.target.value });
                  setPagination({ ...pagination, pageIndex: 0 });
                }}
                compressed
                style={{ width: '150px' }}
                aria-label="Category"
              />
            </div>

            {/* Signature Filter */}
            <div style={{ display: 'flex', alignItems: 'center', gap: '6px', flexShrink: 0 }}>
              <EuiIcon type="document" size="s" color={THEME_COLORS.text.muted} />
              <EuiSelect
                options={[
                  { value: '', text: 'All Signatures' },
                  ...(filterOptions?.signatures || []).slice(0, 50).map(s => ({
                    value: s.value,
                    text: s.label?.length > 25 ? s.label.substring(0, 25) + '...' : s.label
                  }))
                ]}
                value={filters.signature}
                onChange={(e) => {
                  setFilters({ ...filters, signature: e.target.value });
                  setPagination({ ...pagination, pageIndex: 0 });
                }}
                compressed
                style={{ width: '180px' }}
                aria-label="Signature"
              />
            </div>

            {/* Severity Filter */}
            <div style={{ display: 'flex', alignItems: 'center', gap: '6px', flexShrink: 0 }}>
              <EuiIcon type="alert" size="s" color={THEME_COLORS.text.muted} />
              <EuiSelect
                options={[
                  { value: '', text: 'All Severities' },
                  { value: '1', text: 'Alert' },
                  { value: '2', text: 'Critical' },
                  { value: '3', text: 'Warning' },
                  { value: '4', text: 'Notice' },
                  { value: '5+', text: 'Others (5+)' }
                ]}
                value={activeSeverityFilter || filters.severity}
                onChange={(e) => {
                  setActiveSeverityFilter(null);
                  setFilters({ ...filters, severity: e.target.value });
                  setPagination({ ...pagination, pageIndex: 0 });
                }}
                compressed
                style={{ width: '120px' }}
                aria-label="Severity"
              />
            </div>

            {/* Spacer - pushes buttons to the right */}
            <div style={{ flex: 1, minWidth: '8px' }} />

            {/* Action Buttons */}
            <div style={{ display: 'flex', gap: '8px', flexShrink: 0 }}>
              <EuiButtonEmpty
                size="s"
                onClick={handleClearFilters}
                iconType="cross"
                disabled={activeFiltersCount === 0}
              >
                Clear
              </EuiButtonEmpty>

              <EuiButton
                onClick={handleRefresh}
                isLoading={loading}
                iconType="refresh"
                size="s"
                fill
              >
                Refresh
              </EuiButton>
            </div>
          </div>
        </EuiPanel>
      </div>

      {/* Tab Navigation */}
      <div style={{ padding: '0 24px' }}>
        <EuiTabs style={{ marginBottom: '0' }}>
          <EuiTab
            onClick={() => setActiveTab('overview')}
            isSelected={activeTab === 'overview'}
          >
            <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
              <EuiIcon
                type="visArea"
                size="m"
                color={activeTab === 'overview' ? THEME_COLORS.text.accent : THEME_COLORS.text.muted}
              />
              <span>Overview</span>
            </div>
          </EuiTab>
          <EuiTab
            onClick={() => setActiveTab('events')}
            isSelected={activeTab === 'events'}
          >
            <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
              <EuiIcon
                type="list"
                size="m"
                color={activeTab === 'events' ? THEME_COLORS.text.accent : THEME_COLORS.text.muted}
              />
              <span>Events</span>
              {activeFiltersCount > 0 && (
                <EuiBadge color="primary">{activeFiltersCount}</EuiBadge>
              )}
            </div>
          </EuiTab>
        </EuiTabs>
      </div>

      {/* Loading Progress */}
      {loading && (
        <div style={{ margin: '0 24px 16px 24px' }}>
          <EuiProgress size="xs" color="primary" />
        </div>
      )}

      {/* Error Display */}
      {error && (
        <div style={{ margin: '24px' }}>
          <EuiCallOut title="Error loading data" color="danger" iconType="alert">
            {error}
          </EuiCallOut>
        </div>
      )}

      {/* Tab Content */}
      <div style={{ backgroundColor: THEME_COLORS.background }}>
        {/* Overview Tab Content */}
        {activeTab === 'overview' && (
          <div style={{ padding: '24px' }}>
            {/* Severity Cards Grid */}
            <div style={{ marginBottom: '32px' }}>
              <SectionHeader
                icon="visGauge"
                title="Alert Severity Distribution"
                subtitle="1=Alert, 2=Critical, 3=Warning, 4=Notice, 5+=Others"
              />

              <div style={{
                display: 'grid',
                gridTemplateColumns: 'repeat(5, 1fr)',
                gap: '16px'
              }}>
                {['1', '2', '3', '4', '5+'].map(sev => (
                  <SeverityCard
                    key={sev}
                    severity={sev}
                    data={severityCardData[sev]}
                    onClick={handleSeverityCardClick}
                  />
                ))}
              </div>
            </div>

            {/* Timeline Chart - Stacked Bar */}
            <div style={{ marginBottom: '32px' }}>
              <SectionHeader icon="visLine" title="Alert Timeline Analysis" />
              <StackedTimelineChart
                data={timelineData?.data}
                severityData={severityCardData}
                loading={loading}
                isDarkTheme={isDarkTheme}
                timeRange={timeRangeStart}
                onTimeSlotClick={handleTimeSlotClick}
              />
            </div>

            {/* Distribution Charts */}
            <div style={{ marginBottom: '32px' }}>
              <SectionHeader icon="visPie" title="Alert Distribution Analysis" />

              <div style={{
                display: 'grid',
                gridTemplateColumns: 'repeat(2, 1fr)',
                gap: '24px'
              }}>
                {/* Categories Chart */}
                <EnhancedDonutChart
                  title="Alert Categories"
                  subtitle="categories"
                  data={overviewData?.topCategories}
                  loading={loading}
                  onItemClick={handleCategoryClick}
                  isDarkTheme={isDarkTheme}
                  centerLabel="All Categories"
                />

                {/* Signatures Chart */}
                <EnhancedDonutChart
                  title="Alert Signatures"
                  subtitle="signatures"
                  data={overviewData?.topSignatures}
                  loading={loading}
                  onItemClick={handleSignatureClick}
                  isDarkTheme={isDarkTheme}
                  centerLabel="All Signatures"
                />
              </div>
            </div>

            {/* Network Analysis */}
            <div style={{ marginBottom: '32px' }}>
              <SectionHeader icon="globe" title="Network Analysis" />

              {/* First Row - Source and Destination */}
              <div style={{
                display: 'grid',
                gridTemplateColumns: 'repeat(2, 1fr)',
                gap: '24px',
                marginBottom: '24px'
              }}>
                <NetworkDonutChart
                  title="Source Hostnames"
                  subtitle="client hosts"
                  data={networkData?.topSourceIPs}
                  dataKey="ip"
                  loading={loading}
                  onItemClick={(ip) => handleNetworkClick(ip, 'srcIp')}
                  isDarkTheme={isDarkTheme}
                  centerLabel="All Client Hosts"
                />

                <NetworkDonutChart
                  title="Destination IPs"
                  subtitle="server hosts"
                  data={networkData?.topDestIPs}
                  dataKey="ip"
                  loading={loading}
                  onItemClick={(ip) => handleNetworkClick(ip, 'destIp')}
                  isDarkTheme={isDarkTheme}
                  centerLabel="All Server Hosts"
                />
              </div>

         
            </div>
          </div>
        )}

        {/* Events Tab Content */}
        {activeTab === 'events' && (
          <div style={{ padding: '24px' }}>
            <div style={{
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'space-between',
              marginBottom: '24px'
            }}>
              <SectionHeader icon="list" title="Security Events & Logs" />
            </div>

            {/* Active Filters Display */}
            {activeFiltersCount > 0 && (
              <div style={{
                marginBottom: '16px',
                padding: '12px 16px',
                backgroundColor: 'rgba(0, 123, 255, 0.1)',
                border: '1px solid rgba(0, 123, 255, 0.3)',
                borderRadius: THEME_COLORS.borderRadius,
                display: 'flex',
                alignItems: 'center',
                gap: '8px',
                flexWrap: 'wrap'
              }}>
                <EuiIcon type="filter" size="s" color={THEME_COLORS.text.accent} />
                <span style={{ color: THEME_COLORS.text.primary, fontSize: '14px', fontWeight: '500' }}>
                  Active Filters:
                </span>
                {activeSeverityFilter && (
                  <EuiBadge
                    color={SEVERITY_CONFIG[activeSeverityFilter]?.color || 'default'}
                    iconType="cross"
                    iconSide="right"
                    iconOnClick={() => setActiveSeverityFilter(null)}
                    iconOnClickAriaLabel="Remove"
                  >
                    Severity: {SEVERITY_CONFIG[activeSeverityFilter]?.label}
                  </EuiBadge>
                )}
                {filters.category && (
                  <EuiBadge
                    color="accent"
                    iconType="cross"
                    iconSide="right"
                    iconOnClick={() => setFilters({ ...filters, category: '' })}
                    iconOnClickAriaLabel="Remove"
                  >
                    {filters.category}
                  </EuiBadge>
                )}
                {filters.signature && (
                  <EuiBadge
                    iconType="cross"
                    iconSide="right"
                    iconOnClick={() => setFilters({ ...filters, signature: '' })}
                    iconOnClickAriaLabel="Remove"
                  >
                    {filters.signature.length > 25 ? filters.signature.substring(0, 25) + '...' : filters.signature}
                  </EuiBadge>
                )}
                {filters.srcIp && (
                  <EuiBadge
                    color="primary"
                    iconType="cross"
                    iconSide="right"
                    iconOnClick={() => setFilters({ ...filters, srcIp: '' })}
                    iconOnClickAriaLabel="Remove"
                  >
                    Source: {filters.srcIp}
                  </EuiBadge>
                )}
                {filters.destIp && (
                  <EuiBadge
                    color="warning"
                    iconType="cross"
                    iconSide="right"
                    iconOnClick={() => setFilters({ ...filters, destIp: '' })}
                    iconOnClickAriaLabel="Remove"
                  >
                    Dest: {filters.destIp}
                  </EuiBadge>
                )}
                {filters.serviceName && (
                  <EuiBadge
                    color="hollow"
                    iconType="cross"
                    iconSide="right"
                    iconOnClick={() => setFilters({ ...filters, serviceName: '' })}
                    iconOnClickAriaLabel="Remove"
                  >
                    Service: {filters.serviceName}
                  </EuiBadge>
                )}
                {timeSlotFilter && (
                  <EuiBadge
                    color="success"
                    iconType="cross"
                    iconSide="right"
                    iconOnClick={() => setTimeSlotFilter(null)}
                    iconOnClickAriaLabel="Remove"
                  >
                    Time Slot: {timeSlotFilter.label}
                  </EuiBadge>
                )}
              </div>
            )}

            {/* Search Bar */}
            <div style={{
              marginBottom: '16px',
              backgroundColor: THEME_COLORS.cardBackground,
              borderRadius: THEME_COLORS.borderRadius,
              border: `1px solid ${THEME_COLORS.cardBorder}`,
              padding: '12px 16px'
            }}>
              <EuiFlexGroup alignItems="center" gutterSize="m">
                <EuiFlexItem>
                  <EuiFieldSearch
                    placeholder="Search signatures, IPs, categories..."
                    value={filters.search}
                    onChange={(e) => setFilters({ ...filters, search: e.target.value })}
                    onSearch={() => {
                      setPagination({ ...pagination, pageIndex: 0 });
                      fetchEventsData();
                    }}
                    fullWidth
                  />
                </EuiFlexItem>
                <EuiFlexItem grow={false}>
                  <EuiText size="s">
                    <strong>{eventsData.total?.toLocaleString() || 0}</strong> events found
                  </EuiText>
                </EuiFlexItem>
              </EuiFlexGroup>
            </div>

            {/* Events Table */}
            <div style={{
              backgroundColor: THEME_COLORS.cardBackground,
              borderRadius: THEME_COLORS.borderRadius,
              border: `1px solid ${THEME_COLORS.cardBorder}`,
              boxShadow: THEME_COLORS.shadows.card,
              overflow: 'hidden'
            }}>
              <EventsTable
                events={eventsData.events || []}
                loading={loading}
                pagination={{
                  pageIndex: pagination.pageIndex,
                  pageSize: pagination.pageSize,
                  totalItemCount: eventsData.total || 0,
                  pageSizeOptions: [10, 20, 50, 100]
                }}
                onTableChange={handleTableChange}
                expandedRowIds={expandedRowIds}
                toggleRowExpansion={toggleRowExpansion}
              />
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default NIDSDashboard;
