import React, { useState } from 'react';
import { Settings, Save, RotateCcw, Database, Server, Bell } from 'lucide-react';
import toast from 'react-hot-toast';

const SystemConfiguration = () => {
  const [config, setConfig] = useState({
    // Detection Settings
    autoRefresh: true,
    refreshInterval: 10,
    maxEventsPerPage: 100,
    alertThreshold: 7,

    // Database Settings
    neo4jUrl: 'http://localhost:7474',
    neo4jUser: 'neo4j',
    postgresHost: 'localhost',
    postgresPort: 5432,
    postgresDb: 'threats',

    // Backend Settings
    detectionBackendUrl: 'http://localhost:5001',
    responseBackendUrl: 'http://localhost:5000',

    // Notification Settings
    enableEmailAlerts: false,
    emailRecipients: '',
    enableSlackAlerts: false,
    slackWebhook: '',

    // Performance Settings
    cacheEnabled: true,
    cacheTTL: 300,
    maxConcurrentQueries: 5,
  });

  const handleChange = (field, value) => {
    setConfig(prev => ({ ...prev, [field]: value }));
  };

  const handleSave = () => {
    toast.success('Configuration saved successfully');
    // TODO: Save to backend
  };

  const handleReset = () => {
    toast.success('Configuration reset to defaults');
    // TODO: Reset to defaults
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-3">
          <div className="w-10 h-10 bg-accent-purple/20 rounded-lg flex items-center justify-center">
            <Settings className="w-6 h-6 text-accent-purple" />
          </div>
          <div>
            <h1 className="text-2xl font-bold text-white">System Configuration</h1>
            <p className="text-dark-400">Detection and response system settings</p>
          </div>
        </div>

        <div className="flex gap-3">
          <button
            onClick={handleReset}
            className="px-4 py-2 bg-dark-700 text-white rounded-md hover:bg-dark-600 transition-colors flex items-center space-x-2"
          >
            <RotateCcw className="w-4 h-4" />
            <span>Reset</span>
          </button>
          <button
            onClick={handleSave}
            className="px-4 py-2 bg-accent-blue text-white rounded-md hover:bg-accent-blue/80 transition-colors flex items-center space-x-2"
          >
            <Save className="w-4 h-4" />
            <span>Save Changes</span>
          </button>
        </div>
      </div>

      {/* Detection Settings */}
      <div className="card p-6">
        <div className="flex items-center gap-2 mb-4">
          <Server className="w-5 h-5 text-accent-blue" />
          <h2 className="text-lg font-semibold text-white">Detection Settings</h2>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div>
            <label className="block text-sm text-dark-300 mb-2">
              <input
                type="checkbox"
                checked={config.autoRefresh}
                onChange={(e) => handleChange('autoRefresh', e.target.checked)}
                className="mr-2 rounded border-dark-600 bg-dark-700 text-accent-blue"
              />
              Auto-refresh Events
            </label>
          </div>

          <div>
            <label className="block text-sm text-dark-300 mb-2">Refresh Interval (seconds)</label>
            <input
              type="number"
              value={config.refreshInterval}
              onChange={(e) => handleChange('refreshInterval', parseInt(e.target.value))}
              className="w-full px-4 py-2 bg-dark-700 border border-dark-600 rounded-md text-white focus:outline-none focus:ring-2 focus:ring-accent-blue"
            />
          </div>

          <div>
            <label className="block text-sm text-dark-300 mb-2">Max Events Per Page</label>
            <input
              type="number"
              value={config.maxEventsPerPage}
              onChange={(e) => handleChange('maxEventsPerPage', parseInt(e.target.value))}
              className="w-full px-4 py-2 bg-dark-700 border border-dark-600 rounded-md text-white focus:outline-none focus:ring-2 focus:ring-accent-blue"
            />
          </div>

          <div>
            <label className="block text-sm text-dark-300 mb-2">Alert Threshold Level</label>
            <input
              type="number"
              value={config.alertThreshold}
              onChange={(e) => handleChange('alertThreshold', parseInt(e.target.value))}
              min="1"
              max="15"
              className="w-full px-4 py-2 bg-dark-700 border border-dark-600 rounded-md text-white focus:outline-none focus:ring-2 focus:ring-accent-blue"
            />
          </div>
        </div>
      </div>

      {/* Database Settings */}
      <div className="card p-6">
        <div className="flex items-center gap-2 mb-4">
          <Database className="w-5 h-5 text-accent-purple" />
          <h2 className="text-lg font-semibold text-white">Database Settings</h2>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div>
            <label className="block text-sm text-dark-300 mb-2">Neo4j URL</label>
            <input
              type="text"
              value={config.neo4jUrl}
              onChange={(e) => handleChange('neo4jUrl', e.target.value)}
              className="w-full px-4 py-2 bg-dark-700 border border-dark-600 rounded-md text-white focus:outline-none focus:ring-2 focus:ring-accent-blue"
            />
          </div>

          <div>
            <label className="block text-sm text-dark-300 mb-2">Neo4j User</label>
            <input
              type="text"
              value={config.neo4jUser}
              onChange={(e) => handleChange('neo4jUser', e.target.value)}
              className="w-full px-4 py-2 bg-dark-700 border border-dark-600 rounded-md text-white focus:outline-none focus:ring-2 focus:ring-accent-blue"
            />
          </div>

          <div>
            <label className="block text-sm text-dark-300 mb-2">PostgreSQL Host</label>
            <input
              type="text"
              value={config.postgresHost}
              onChange={(e) => handleChange('postgresHost', e.target.value)}
              className="w-full px-4 py-2 bg-dark-700 border border-dark-600 rounded-md text-white focus:outline-none focus:ring-2 focus:ring-accent-blue"
            />
          </div>

          <div>
            <label className="block text-sm text-dark-300 mb-2">PostgreSQL Port</label>
            <input
              type="number"
              value={config.postgresPort}
              onChange={(e) => handleChange('postgresPort', parseInt(e.target.value))}
              className="w-full px-4 py-2 bg-dark-700 border border-dark-600 rounded-md text-white focus:outline-none focus:ring-2 focus:ring-accent-blue"
            />
          </div>
        </div>
      </div>

      {/* Backend Settings */}
      <div className="card p-6">
        <div className="flex items-center gap-2 mb-4">
          <Server className="w-5 h-5 text-accent-green" />
          <h2 className="text-lg font-semibold text-white">Backend Settings</h2>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div>
            <label className="block text-sm text-dark-300 mb-2">Detection Backend URL</label>
            <input
              type="text"
              value={config.detectionBackendUrl}
              onChange={(e) => handleChange('detectionBackendUrl', e.target.value)}
              className="w-full px-4 py-2 bg-dark-700 border border-dark-600 rounded-md text-white focus:outline-none focus:ring-2 focus:ring-accent-blue"
            />
          </div>

          <div>
            <label className="block text-sm text-dark-300 mb-2">Response Backend URL</label>
            <input
              type="text"
              value={config.responseBackendUrl}
              onChange={(e) => handleChange('responseBackendUrl', e.target.value)}
              className="w-full px-4 py-2 bg-dark-700 border border-dark-600 rounded-md text-white focus:outline-none focus:ring-2 focus:ring-accent-blue"
            />
          </div>
        </div>
      </div>

      {/* Notification Settings */}
      <div className="card p-6">
        <div className="flex items-center gap-2 mb-4">
          <Bell className="w-5 h-5 text-accent-blue" />
          <h2 className="text-lg font-semibold text-white">Notification Settings</h2>
        </div>

        <div className="space-y-6">
          <div>
            <label className="block text-sm text-dark-300 mb-2">
              <input
                type="checkbox"
                checked={config.enableEmailAlerts}
                onChange={(e) => handleChange('enableEmailAlerts', e.target.checked)}
                className="mr-2 rounded border-dark-600 bg-dark-700 text-accent-blue"
              />
              Enable Email Alerts
            </label>
            {config.enableEmailAlerts && (
              <input
                type="text"
                value={config.emailRecipients}
                onChange={(e) => handleChange('emailRecipients', e.target.value)}
                placeholder="email1@example.com, email2@example.com"
                className="w-full mt-2 px-4 py-2 bg-dark-700 border border-dark-600 rounded-md text-white focus:outline-none focus:ring-2 focus:ring-accent-blue"
              />
            )}
          </div>

          <div>
            <label className="block text-sm text-dark-300 mb-2">
              <input
                type="checkbox"
                checked={config.enableSlackAlerts}
                onChange={(e) => handleChange('enableSlackAlerts', e.target.checked)}
                className="mr-2 rounded border-dark-600 bg-dark-700 text-accent-blue"
              />
              Enable Slack Alerts
            </label>
            {config.enableSlackAlerts && (
              <input
                type="text"
                value={config.slackWebhook}
                onChange={(e) => handleChange('slackWebhook', e.target.value)}
                placeholder="https://hooks.slack.com/services/..."
                className="w-full mt-2 px-4 py-2 bg-dark-700 border border-dark-600 rounded-md text-white focus:outline-none focus:ring-2 focus:ring-accent-blue"
              />
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default SystemConfiguration;
