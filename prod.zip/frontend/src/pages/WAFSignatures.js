import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import {
  EuiPage,
  EuiPageBody,
  EuiPageHeader,
  EuiPanel,
  EuiFlexGroup,
  EuiFlexItem,
  EuiText,
  EuiTitle,
  EuiButton,
  EuiBadge,
  EuiLoadingSpinner,
  EuiEmptyPrompt,
  EuiSpacer,
  EuiIcon
} from '@elastic/eui';
import { toast } from 'react-hot-toast';
import {
  getSignatureStatus,
  toggleSignature
} from '../services/api';
import ConfirmationModal from '../components/ConfirmationModal';
import WAFGeoRestrictionsModal from '../components/WAFGeoRestrictionsModal';
import WAFIPReputationModal from '../components/WAFIPReputationModal';
import WAFCommonAttackModal from '../components/WAFCommonAttackModal';
import WAFAnonymousIPModal from '../components/WAFAnonymousIPModal';
import WAFLinuxVulnModal from '../components/WAFLinuxVulnModal';
import WAFUnixVulnModal from '../components/WAFUnixVulnModal';
import WAFKnownBadInputsModal from '../components/WAFKnownBadInputsModal';

const WAFSignatures = () => {
  const queryClient = useQueryClient();

  const [loadingSignatureId, setLoadingSignatureId] = useState(null);
  const [confirmationModal, setConfirmationModal] = useState({
    isOpen: false,
    signatureId: null,
    signatureName: ''
  });
  const [geoRestrictionsModal, setGeoRestrictionsModal] = useState({
    isOpen: false,
    signatureId: null,
    signatureName: ''
  });
  const [wafGeoRestrictionsModal, setWafGeoRestrictionsModal] = useState({
    isOpen: false,
    signatureId: null,
    signatureName: ''
  });
  const [wafIPReputationModal, setWafIPReputationModal] = useState({
    isOpen: false,
    signatureId: null,
    signatureName: ''
  });
  const [wafCommonAttackModal, setWafCommonAttackModal] = useState({
    isOpen: false,
    signatureId: null,
    signatureName: ''
  });
  const [wafAnonymousIPModal, setWafAnonymousIPModal] = useState({
    isOpen: false,
    signatureId: null,
    signatureName: ''
  });
  const [wafLinuxVulnModal, setWafLinuxVulnModal] = useState({
    isOpen: false,
    signatureId: null,
    signatureName: ''
  });
  const [wafUnixVulnModal, setWafUnixVulnModal] = useState({
    isOpen: false,
    signatureId: null,
    signatureName: ''
  });
  const [wafKnownBadInputsModal, setWafKnownBadInputsModal] = useState({
    isOpen: false,
    signatureId: null,
    signatureName: ''
  });

  const { data: signatureStatus, isLoading, error } = useQuery({
    queryKey: ['signatureStatus'],
    queryFn: getSignatureStatus,
    refetchInterval: 10000,
  });

  const toggleSignatureMutation = useMutation({
    mutationFn: ({ signatureId }) => toggleSignature(signatureId),
    onSuccess: () => {
      setLoadingSignatureId(null);
      queryClient.invalidateQueries({ queryKey: ['signatureStatus'] });
      toast.success('Signature status updated successfully');
    },
    onError: (error) => {
      setLoadingSignatureId(null);
      console.error('Failed to toggle signature:', error);
      toast.error('Failed to update signature status');
    }
  });

  const handleToggleSignature = (signatureId) => {
    const signatures = signatureStatus || {};
    const signature = signatures[signatureId];

    if (signature?.active) {
      setConfirmationModal({
        isOpen: true,
        signatureId: signatureId,
        signatureName: signature?.display_name || signature?.name
      });
    } else {
      proceedWithToggle(signatureId);
    }
  };

  const proceedWithToggle = (signatureId) => {
    setLoadingSignatureId(signatureId);
    toggleSignatureMutation.mutate({ signatureId });
  };

  const handleConfirmToggle = () => {
    proceedWithToggle(confirmationModal.signatureId);
    setConfirmationModal({ isOpen: false, signatureId: null, signatureName: '' });
  };

  const handleCancelToggle = () => {
    setConfirmationModal({ isOpen: false, signatureId: null, signatureName: '' });
  };

  const handleManageSignature = (signatureId) => {
    const signatures = signatureStatus || {};
    const signature = signatures[signatureId];

    if ((signature?.name?.toLowerCase().includes("ip") && signature?.name?.toLowerCase().includes("reputation")) ||
        (signature?.display_name?.toLowerCase().includes("ip") && signature?.display_name?.toLowerCase().includes("reputation")) ||
        signature?.name?.toLowerCase().includes("awsmanagedipreputationlist") ||
        signature?.display_name?.toLowerCase().includes("aws managed ip reputation")) {
      setWafIPReputationModal({
        isOpen: true,
        signatureId: signatureId,
        signatureName: signature?.display_name || signature?.name
      });
      return;
    }

    if (signature?.name?.toLowerCase().includes("common") ||
        signature?.display_name?.toLowerCase().includes("common") ||
        signature?.name?.toLowerCase().includes("awsmanagedrulescommonruleset") ||
        signature?.display_name?.toLowerCase().includes("common attack")) {
      setWafCommonAttackModal({
        isOpen: true,
        signatureId: signatureId,
        signatureName: signature?.display_name || signature?.name
      });
      return;
    }

    if (signature?.name?.toLowerCase().includes("anonymous") ||
        signature?.display_name?.toLowerCase().includes("anonymous") ||
        signature?.name?.toLowerCase().includes("awsmanagedrulesanonymousiplist") ||
        signature?.display_name?.toLowerCase().includes("anonymous ip")) {
      setWafAnonymousIPModal({
        isOpen: true,
        signatureId: signatureId,
        signatureName: signature?.display_name || signature?.name
      });
      return;
    }

    if (signature?.name?.toLowerCase().includes("linux") ||
        signature?.display_name?.toLowerCase().includes("linux") ||
        signature?.name?.toLowerCase().includes("awsmanagedruleslinuxruleset") ||
        signature?.display_name?.toLowerCase().includes("linux vulnerability")) {
      setWafLinuxVulnModal({
        isOpen: true,
        signatureId: signatureId,
        signatureName: signature?.display_name || signature?.name
      });
      return;
    }

    if (signature?.name?.toLowerCase().includes("unix") ||
        signature?.display_name?.toLowerCase().includes("unix") ||
        signature?.name?.toLowerCase().includes("awsmanagedrulesunixruleset") ||
        signature?.display_name?.toLowerCase().includes("unix vulnerability")) {
      setWafUnixVulnModal({
        isOpen: true,
        signatureId: signatureId,
        signatureName: signature?.display_name || signature?.name
      });
      return;
    }

    if (signature?.name?.toLowerCase().includes("known") ||
        signature?.display_name?.toLowerCase().includes("known") ||
        signature?.name?.toLowerCase().includes("awsmanagedrulesknownbadinputsruleset") ||
        signature?.display_name?.toLowerCase().includes("known bad input")) {
      setWafKnownBadInputsModal({
        isOpen: true,
        signatureId: signatureId,
        signatureName: signature?.display_name || signature?.name
      });
      return;
    }

    if (signature?.name?.toLowerCase().includes("geo") ||
        signature?.display_name?.toLowerCase().includes("geo") ||
        signature?.name?.toLowerCase().includes("geographic") ||
        signature?.display_name?.toLowerCase().includes("geographic")) {
      setWafGeoRestrictionsModal({
        isOpen: true,
        signatureId: signatureId,
        signatureName: signature?.display_name || signature?.name
      });
      return;
    }

    toast(`Manage settings for "${signature?.display_name || signature?.name}" - Coming soon!`);
    console.log('Manage signature:', signatureId, signature);
  };

  const handleCloseGeoRestrictions = () => {
    setGeoRestrictionsModal({ isOpen: false, signatureId: null, signatureName: '' });
  };

  const handleCloseWafGeoRestrictions = () => {
    setWafGeoRestrictionsModal({ isOpen: false, signatureId: null, signatureName: '' });
  };

  const handleCloseWafIPReputation = () => {
    setWafIPReputationModal({ isOpen: false, signatureId: null, signatureName: '' });
  };

  const handleCloseWafCommonAttack = () => {
    setWafCommonAttackModal({ isOpen: false, signatureId: null, signatureName: '' });
  };

  const handleCloseWafAnonymousIP = () => {
    setWafAnonymousIPModal({ isOpen: false, signatureId: null, signatureName: '' });
  };

  const handleCloseWafLinuxVuln = () => {
    setWafLinuxVulnModal({ isOpen: false, signatureId: null, signatureName: '' });
  };

  const handleCloseWafUnixVuln = () => {
    setWafUnixVulnModal({ isOpen: false, signatureId: null, signatureName: '' });
  };

  const handleCloseWafKnownBadInputs = () => {
    setWafKnownBadInputsModal({ isOpen: false, signatureId: null, signatureName: '' });
  };

  const getSignatureTypeColor = (type) => {
    switch (type) {
      case 'MANAGED':
      case 'AWS_MANAGED':
        return 'primary';
      case 'CUSTOM':
        return 'success';
      default:
        return 'default';
    }
  };

  const getSignatureTypeIcon = (type) => {
    return 'shield';
  };

  if (isLoading) {
    return (
      <EuiPage paddingSize="none">
        <EuiPageBody panelled>
          <EuiEmptyPrompt
            icon={<EuiLoadingSpinner size="xl" />}
            title={<h2>Loading signature status...</h2>}
            body={
              <EuiText size="s" color="subdued">
                Fetching WAF signature configurations
              </EuiText>
            }
          />
        </EuiPageBody>
      </EuiPage>
    );
  }

  if (error) {
    return (
      <EuiPage paddingSize="none">
        <EuiPageBody panelled>
          <EuiEmptyPrompt
            icon={<EuiIcon type="alert" size="xxl" color="danger" />}
            title={<h2>Failed to load signature status</h2>}
            body={
              <EuiText size="s" color="subdued">
                Unable to fetch WAF signature data. Please try again.
              </EuiText>
            }
          />
        </EuiPageBody>
      </EuiPage>
    );
  }

  const signatures = signatureStatus || {};

  return (
    <>
      <EuiPage paddingSize="none">
        <EuiPageBody panelled>
          {/* Page Header */}
          <EuiPageHeader
            pageTitle={
              <EuiFlexGroup gutterSize="s" alignItems="center" responsive={false}>
                <EuiFlexItem grow={false}>
                  <EuiIcon type="shield" size="l" color="primary" />
                </EuiFlexItem>
                <EuiFlexItem>WAF Signatures</EuiFlexItem>
              </EuiFlexGroup>
            }
            description="Manage and configure WAF signature rules"
          />

          <EuiSpacer size="l" />

          {/* Signatures List */}
          {Object.keys(signatures).length > 0 ? (
            <EuiFlexGroup direction="column" gutterSize="m">
              {Object.entries(signatures).map(([signatureId, signature]) => (
                <EuiFlexItem key={signatureId}>
                  <EuiPanel hasBorder paddingSize="l">
                    <EuiFlexGroup alignItems="center" justifyContent="spaceBetween" responsive={false}>
                      {/* Signature Info */}
                      <EuiFlexItem>
                        <EuiFlexGroup direction="column" gutterSize="xs">
                          <EuiFlexItem>
                            <EuiFlexGroup gutterSize="m" alignItems="center" responsive={false} wrap>
                              <EuiFlexItem grow={false}>
                                <EuiTitle size="xs">
                                  <h4>{signature.display_name || signature.name}</h4>
                                </EuiTitle>
                              </EuiFlexItem>
                              <EuiFlexItem grow={false}>
                                <EuiBadge
                                  color={getSignatureTypeColor(signature.type)}
                                  iconType={getSignatureTypeIcon(signature.type)}
                                >
                                  {signature.type}
                                </EuiBadge>
                              </EuiFlexItem>
                              <EuiFlexItem grow={false}>
                                <EuiBadge color={signature.active ? 'success' : 'default'}>
                                  {signature.active ? 'Active' : 'Inactive'}
                                </EuiBadge>
                              </EuiFlexItem>
                            </EuiFlexGroup>
                          </EuiFlexItem>
                          <EuiFlexItem>
                            <EuiText size="s" color="subdued">
                              {signature.description}
                            </EuiText>
                          </EuiFlexItem>
                        </EuiFlexGroup>
                      </EuiFlexItem>

                      {/* Action Buttons */}
                      <EuiFlexItem grow={false}>
                        <EuiFlexGroup gutterSize="m" responsive={false}>
                          <EuiFlexItem grow={false}>
                            <EuiButton
                              iconType="gear"
                              onClick={() => handleManageSignature(signatureId)}
                              color="text"
                              size="s"
                            >
                              Manage
                            </EuiButton>
                          </EuiFlexItem>
                          <EuiFlexItem grow={false}>
                            <EuiButton
                              onClick={() => handleToggleSignature(signatureId)}
                              isLoading={loadingSignatureId === signatureId}
                              color={signature.active ? 'danger' : 'success'}
                              fill
                              size="s"
                              style={{ minWidth: '80px' }}
                            >
                              {signature.active ? 'Remove' : 'Add'}
                            </EuiButton>
                          </EuiFlexItem>
                        </EuiFlexGroup>
                      </EuiFlexItem>
                    </EuiFlexGroup>
                  </EuiPanel>
                </EuiFlexItem>
              ))}
            </EuiFlexGroup>
          ) : (
            <EuiEmptyPrompt
              icon={<EuiIcon type="shield" size="xxl" color="subdued" />}
              title={<h2>No signatures found</h2>}
              body={
                <EuiText size="s" color="subdued">
                  No WAF signatures are currently configured.
                </EuiText>
              }
            />
          )}
        </EuiPageBody>
      </EuiPage>

      {/* Modals */}
      <ConfirmationModal
        isOpen={confirmationModal.isOpen}
        onClose={handleCancelToggle}
        onConfirm={handleConfirmToggle}
        title="Remove Signature"
        message={`Are you sure you want to remove "${confirmationModal.signatureName}"?`}
      />

      <WAFGeoRestrictionsModal
        isOpen={geoRestrictionsModal.isOpen}
        onClose={handleCloseGeoRestrictions}
        signatureId={geoRestrictionsModal.signatureId}
        signatureName={geoRestrictionsModal.signatureName}
      />

      <WAFGeoRestrictionsModal
        isOpen={wafGeoRestrictionsModal.isOpen}
        onClose={handleCloseWafGeoRestrictions}
        signatureId={wafGeoRestrictionsModal.signatureId}
        signatureName={wafGeoRestrictionsModal.signatureName}
      />

      <WAFIPReputationModal
        isOpen={wafIPReputationModal.isOpen}
        onClose={handleCloseWafIPReputation}
        signatureId={wafIPReputationModal.signatureId}
        signatureName={wafIPReputationModal.signatureName}
      />

      <WAFCommonAttackModal
        isOpen={wafCommonAttackModal.isOpen}
        onClose={handleCloseWafCommonAttack}
        signatureId={wafCommonAttackModal.signatureId}
        signatureName={wafCommonAttackModal.signatureName}
      />

      <WAFAnonymousIPModal
        isOpen={wafAnonymousIPModal.isOpen}
        onClose={handleCloseWafAnonymousIP}
        signatureId={wafAnonymousIPModal.signatureId}
        signatureName={wafAnonymousIPModal.signatureName}
      />

      <WAFLinuxVulnModal
        isOpen={wafLinuxVulnModal.isOpen}
        onClose={handleCloseWafLinuxVuln}
        signatureId={wafLinuxVulnModal.signatureId}
        signatureName={wafLinuxVulnModal.signatureName}
      />

      <WAFUnixVulnModal
        isOpen={wafUnixVulnModal.isOpen}
        onClose={handleCloseWafUnixVuln}
        signatureId={wafUnixVulnModal.signatureId}
        signatureName={wafUnixVulnModal.signatureName}
      />

      <WAFKnownBadInputsModal
        isOpen={wafKnownBadInputsModal.isOpen}
        onClose={handleCloseWafKnownBadInputs}
        signatureId={wafKnownBadInputsModal.signatureId}
        signatureName={wafKnownBadInputsModal.signatureName}
      />
    </>
  );
};

export default WAFSignatures;
