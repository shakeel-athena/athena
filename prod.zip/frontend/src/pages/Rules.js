import React from 'react';
import RulesDisplay from '../components/Rules/RulesDisplay';

function Rules() {
  return <RulesDisplay />;
}

export default Rules;