import React, { useState } from 'react';
import {
  EuiPage,
  EuiPageBody,
  EuiPageHeader,
  EuiPageHeaderSection,
  EuiTitle,
  EuiTabbedContent,
  EuiSpacer,
  EuiText,
  EuiIcon,
  EuiFlexGroup,
  EuiFlexItem,
  EuiBadge,
} from '@elastic/eui';

// Tab Components (to be implemented)
import UnifiedBlockedIPsTab from './tabs/UnifiedBlockedIPsTab';
import NetworkFirewallTab from './tabs/NetworkFirewallTab';
import WAFManagementTab from './tabs/WAFManagementTab';

/**
 * Unified Firewall & WAF Management Page
 *
 * This page consolidates all firewall and WAF management into a single interface:
 * - Tab 1: Unified Blocked IPs (Manual, Alert-based, WAF blocks)
 * - Tab 2: Network Firewall Management (Allow/Block lists, Geo-restrictions)
 * - Tab 3: WAF Management (Signatures, IP sets, Rules)
 */
const FirewallWAFUnified = () => {
  const [selectedTabId, setSelectedTabId] = useState('blocked-ips');

  const tabs = [
    {
      id: 'blocked-ips',
      name: (
        <EuiFlexGroup gutterSize="s" alignItems="center" responsive={false}>
          <EuiFlexItem grow={false}>
            <EuiIcon type="cross" />
          </EuiFlexItem>
          <EuiFlexItem grow={false}>
            Blocked IPs
          </EuiFlexItem>
          <EuiFlexItem grow={false}>
            <EuiBadge color="danger">Unified View</EuiBadge>
          </EuiFlexItem>
        </EuiFlexGroup>
      ),
      content: (
        <>
          <EuiSpacer size="m" />
          <EuiText color="subdued" size="s">
            <p>
              View all blocked IPs from Network Firewall, WAF, and Alert-based blocks in one place.
              Filter by layer (NFW/WAF/Both), source (Manual/Alert), and threat type.
            </p>
          </EuiText>
          <EuiSpacer size="l" />
          <UnifiedBlockedIPsTab />
        </>
      ),
    },
    {
      id: 'network-firewall',
      name: (
        <EuiFlexGroup gutterSize="s" alignItems="center" responsive={false}>
          <EuiFlexItem grow={false}>
            <EuiIcon type="shield" />
          </EuiFlexItem>
          <EuiFlexItem grow={false}>
            Network Firewall
          </EuiFlexItem>
        </EuiFlexGroup>
      ),
      content: (
        <>
          <EuiSpacer size="m" />
          <EuiText color="subdued" size="s">
            <p>
              Manage Network Firewall (Layer 3/4) allow and block lists.
              Drag-and-drop IPs between lists, add bulk IPs, and configure geo-restrictions.
            </p>
          </EuiText>
          <EuiSpacer size="l" />
          <NetworkFirewallTab />
        </>
      ),
    },
    {
      id: 'waf-management',
      name: (
        <EuiFlexGroup gutterSize="s" alignItems="center" responsive={false}>
          <EuiFlexItem grow={false}>
            <EuiIcon type="securityApp" />
          </EuiFlexItem>
          <EuiFlexItem grow={false}>
            WAF Management
          </EuiFlexItem>
        </EuiFlexGroup>
      ),
      content: (
        <>
          <EuiSpacer size="m" />
          <EuiText color="subdued" size="s">
            <p>
              Manage Web Application Firewall (Layer 7) signatures, rules, and IP sets.
              View WAF blocked IPs, configure IP reputation rules, and manage geo-blocking.
            </p>
          </EuiText>
          <EuiSpacer size="l" />
          <WAFManagementTab />
        </>
      ),
    },
  ];

  return (
    <EuiPage restrictWidth={false}>
      <EuiPageBody>
        <EuiPageHeader>
          <EuiPageHeaderSection>
            <EuiFlexGroup alignItems="center" gutterSize="m">
              <EuiFlexItem grow={false}>
                <EuiIcon type="securityApp" size="xl" />
              </EuiFlexItem>
              <EuiFlexItem>
                <EuiTitle size="l">
                  <h1>Firewall & WAF Management</h1>
                </EuiTitle>
              </EuiFlexItem>
            </EuiFlexGroup>
          </EuiPageHeaderSection>
        </EuiPageHeader>

        <EuiSpacer size="l" />

        <EuiTabbedContent
          tabs={tabs}
          selectedTab={tabs.find(tab => tab.id === selectedTabId)}
          onTabClick={(selectedTab) => setSelectedTabId(selectedTab.id)}
          size="l"
        />
      </EuiPageBody>
    </EuiPage>
  );
};

export default FirewallWAFUnified;
