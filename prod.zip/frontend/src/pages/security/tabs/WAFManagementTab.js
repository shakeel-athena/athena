import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import {
  EuiPanel,
  EuiFlexGroup,
  EuiFlexItem,
  EuiStat,
  EuiButton,
  EuiSpacer,
  EuiBasicTable,
  EuiFieldSearch,
  EuiModal,
  EuiModalHeader,
  EuiModalHeaderTitle,
  EuiModalBody,
  EuiModalFooter,
  EuiForm,
  EuiFormRow,
  EuiFieldText,
  EuiTextArea,
  EuiButtonEmpty,
  EuiText,
  EuiCallOut,
  EuiLoadingSpinner,
  EuiEmptyPrompt,
  EuiBadge,
  EuiConfirmModal,
  EuiCheckbox,
} from '@elastic/eui';
import {
  listWAFIPSets,
  getWAFIPSet,
  addIPToWAFSet,
  removeIPFromWAFSet,
  unblockIPFromAlert,
} from '../../../services/api';
import toast from 'react-hot-toast';

/**
 * WAF Management Tab
 *
 * Manage Web Application Firewall (Layer 7):
 * - WAF Blocked IPs management
 */
const WAFManagementTab = () => {
  return (
    <>
      <EuiSpacer />
      <WAFBlockedIPsView />
    </>
  );
};

/**
 * WAF Blocked IPs View (NEW - CRITICAL FEATURE)
 *
 * Shows IPs blocked in WAF IP sets with add/remove functionality
 */
const WAFBlockedIPsView = () => {
  const queryClient = useQueryClient();

  // State
  const [selectedIPSet, setSelectedIPSet] = useState('Blocked');
  const [searchTerm, setSearchTerm] = useState('');
  const [showAddModal, setShowAddModal] = useState(false);
  const [showRemoveModal, setShowRemoveModal] = useState(null);
  const [newIP, setNewIP] = useState('');
  const [reason, setReason] = useState('');
  const [page, setPage] = useState(1);
  const [alsoUnblockNFW, setAlsoUnblockNFW] = useState(true); // Also unblock from Network Firewall
  const pageSize = 100;

  // Fetch IP sets list
  const { data: ipSetsData } = useQuery({
    queryKey: ['waf-ip-sets'],
    queryFn: () => listWAFIPSets(),
  });

  // Fetch specific IP set
  const { data: ipSetData, isLoading, refetch } = useQuery({
    queryKey: ['waf-ip-set', selectedIPSet, page],
    queryFn: () => getWAFIPSet(selectedIPSet, page, pageSize),
    refetchInterval: 10000, // Refresh every 10 seconds
  });

  // Add IP mutation
  const addIPMutation = useMutation({
    mutationFn: ({ ip, reason }) => {
      const analyst = localStorage.getItem('username') || 'admin';
      return addIPToWAFSet(selectedIPSet, ip, reason, analyst);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['waf-ip-set', selectedIPSet] });
      queryClient.invalidateQueries({ queryKey: ['waf-ip-sets'] });
      setShowAddModal(false);
      setNewIP('');
      setReason('');
    },
  });

  // Remove IP mutation with optional cross-layer unblocking
  const removeIPMutation = useMutation({
    mutationFn: async ({ ip, reason, unblockFromNFW }) => {
      const analyst = localStorage.getItem('username') || 'admin';
      const results = { waf: null, nfw: null };

      // Remove from WAF
      try {
        await removeIPFromWAFSet(selectedIPSet, ip, reason, analyst);
        results.waf = 'success';
      } catch (err) {
        results.waf = err.message;
        throw err; // Re-throw to trigger error handling
      }

      // Also unblock from Network Firewall if requested
      if (unblockFromNFW) {
        try {
          await unblockIPFromAlert(ip.split('/')[0], analyst);
          results.nfw = 'success';
        } catch (err) {
          results.nfw = err.message;
          // Don't throw - WAF succeeded, NFW is optional
        }
      }

      return results;
    },
    onSuccess: (results) => {
      queryClient.invalidateQueries({ queryKey: ['waf-ip-set', selectedIPSet] });
      queryClient.invalidateQueries({ queryKey: ['waf-ip-sets'] });
      queryClient.invalidateQueries({ queryKey: ['firewall-ip-sets'] });
      queryClient.invalidateQueries({ queryKey: ['alert-blocked-ips'] });

      if (results.nfw === 'success') {
        toast.success('IP removed from both WAF and Network Firewall');
      } else if (results.nfw) {
        toast('IP removed from WAF. Network Firewall removal failed: ' + results.nfw, { icon: '⚠️' });
      } else {
        toast.success('IP removed from WAF');
      }

      setShowRemoveModal(null);
      setAlsoUnblockNFW(true); // Reset checkbox
    },
  });

  // Filter IPs by search
  const filteredIPs = (ipSetData?.addresses || []).filter(ip =>
    ip.toLowerCase().includes(searchTerm.toLowerCase())
  );

  // Table columns
  const columns = [
    {
      field: 'ip',
      name: 'IP Address / CIDR',
      width: '200px',
      render: (ip) => <strong>{ip}</strong>,
    },
    {
      name: 'Version',
      width: '100px',
      render: (item) => {
        const isIPv6 = item.ip.includes(':');
        return (
          <EuiBadge color={isIPv6 ? 'primary' : 'success'}>
            {isIPv6 ? 'IPv6' : 'IPv4'}
          </EuiBadge>
        );
      },
    },
    {
      name: 'Actions',
      width: '120px',
      actions: [
        {
          name: 'Remove',
          description: 'Remove this IP from WAF',
          icon: 'trash',
          type: 'icon',
          color: 'danger',
          onClick: (item) => setShowRemoveModal(item.ip),
        },
      ],
    },
  ];

  // Prepare table items
  const tableItems = filteredIPs.map(ip => ({ ip }));

  // Pagination
  const pagination = {
    pageIndex: page - 1,
    pageSize: pageSize,
    totalItemCount: ipSetData?.ip_count || 0,
    pageSizeOptions: [50, 100, 200],
  };

  const onTableChange = ({ page = {} }) => {
    const { index } = page;
    setPage(index + 1);
  };

  if (isLoading) {
    return (
      <EuiFlexGroup justifyContent="center" alignItems="center" style={{ minHeight: 400 }}>
        <EuiFlexItem grow={false}>
          <EuiLoadingSpinner size="xl" />
        </EuiFlexItem>
      </EuiFlexGroup>
    );
  }

  return (
    <>
      {/* Statistics */}
      <EuiFlexGroup>
        <EuiFlexItem>
          <EuiPanel>
            <EuiStat
              title={ipSetData?.ip_count || 0}
              description={`IPs in "${selectedIPSet}" IP Set`}
              titleColor="danger"
              textAlign="center"
            />
          </EuiPanel>
        </EuiFlexItem>
        <EuiFlexItem>
          <EuiPanel>
            <EuiStat
              title={ipSetsData?.length || 0}
              description="Total WAF IP Sets"
              titleColor="primary"
              textAlign="center"
            />
          </EuiPanel>
        </EuiFlexItem>
        <EuiFlexItem>
          <EuiPanel>
            <EuiStat
              title={filteredIPs.length}
              description="Filtered IPs"
              titleColor="subdued"
              textAlign="center"
            />
          </EuiPanel>
        </EuiFlexItem>
      </EuiFlexGroup>

      <EuiSpacer />

      {/* Info callout */}
      <EuiCallOut
        title="WAF IP Set Management"
        color="primary"
        iconType="iInCircle"
      >
        <p>
          This view shows IPs blocked at the WAF (Layer 7 - Application Layer).
          IPs added here will be blocked by AWS WAF before reaching your application.
          For dual-layer protection, also add IPs to Network Firewall (Layer 3/4).
        </p>
      </EuiCallOut>

      <EuiSpacer />

      {/* Actions and Search */}
      <EuiFlexGroup>
        <EuiFlexItem>
          <EuiFieldSearch
            placeholder="Search IPs..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            isClearable
            fullWidth
          />
        </EuiFlexItem>
        <EuiFlexItem grow={false}>
          <EuiButton
            fill
            iconType="plus"
            onClick={() => setShowAddModal(true)}
          >
            Add IP to WAF
          </EuiButton>
        </EuiFlexItem>
        <EuiFlexItem grow={false}>
          <EuiButton
            iconType="refresh"
            onClick={() => refetch()}
          >
            Refresh
          </EuiButton>
        </EuiFlexItem>
      </EuiFlexGroup>

      <EuiSpacer />

      {/* Table */}
      {tableItems.length === 0 ? (
        <EuiEmptyPrompt
          iconType="crossInACircleFilled"
          iconColor="subdued"
          title={<h3>No IPs in WAF IP Set</h3>}
          body={
            <p>
              The "{selectedIPSet}" IP set is empty. Add IPs to block them at the WAF layer.
            </p>
          }
          actions={
            <EuiButton fill onClick={() => setShowAddModal(true)}>
              Add IP to WAF
            </EuiButton>
          }
        />
      ) : (
        <EuiBasicTable
          items={tableItems}
          columns={columns}
          pagination={pagination}
          onChange={onTableChange}
          hasActions={true}
        />
      )}

      {/* Add IP Modal */}
      {showAddModal && (
        <EuiModal onClose={() => setShowAddModal(false)} maxWidth={600}>
          <EuiModalHeader>
            <EuiModalHeaderTitle>Add IP to WAF IP Set</EuiModalHeaderTitle>
          </EuiModalHeader>

          <EuiModalBody>
            <EuiForm>
              <EuiFormRow
                label="IP Address or CIDR"
                helpText="Example: 192.168.1.100 or 10.0.0.0/24"
              >
                <EuiFieldText
                  placeholder="Enter IP address"
                  value={newIP}
                  onChange={(e) => setNewIP(e.target.value)}
                />
              </EuiFormRow>

              <EuiFormRow label="Reason (optional)" helpText="Why are you blocking this IP?">
                <EuiTextArea
                  placeholder="E.g., Malicious activity detected, brute force attack, etc."
                  value={reason}
                  onChange={(e) => setReason(e.target.value)}
                  rows={3}
                />
              </EuiFormRow>
            </EuiForm>
          </EuiModalBody>

          <EuiModalFooter>
            <EuiButtonEmpty onClick={() => setShowAddModal(false)}>
              Cancel
            </EuiButtonEmpty>
            <EuiButton
              fill
              onClick={() => addIPMutation.mutate({ ip: newIP, reason })}
              isLoading={addIPMutation.isLoading}
              disabled={!newIP.trim()}
            >
              Add IP
            </EuiButton>
          </EuiModalFooter>
        </EuiModal>
      )}

      {/* Remove IP Confirmation Modal */}
      {showRemoveModal && (
        <EuiConfirmModal
          title={`Remove IP ${showRemoveModal}?`}
          onCancel={() => {
            setShowRemoveModal(null);
            setAlsoUnblockNFW(true);
          }}
          onConfirm={() => removeIPMutation.mutate({
            ip: showRemoveModal,
            reason: 'Manual removal',
            unblockFromNFW: alsoUnblockNFW
          })}
          cancelButtonText="Cancel"
          confirmButtonText={alsoUnblockNFW ? "Remove from Both Layers" : "Remove from WAF Only"}
          buttonColor="danger"
          defaultFocusedButton="confirm"
          isLoading={removeIPMutation.isLoading}
        >
          <EuiText>
            <p>
              Are you sure you want to remove <strong>{showRemoveModal}</strong> from the WAF IP set?
            </p>
          </EuiText>
          <EuiSpacer size="m" />
          <EuiCheckbox
            id="also-unblock-nfw"
            label="Also unblock from Network Firewall (Layer 3/4)"
            checked={alsoUnblockNFW}
            onChange={(e) => setAlsoUnblockNFW(e.target.checked)}
          />
          <EuiSpacer size="s" />
          <EuiText color="subdued" size="xs">
            {alsoUnblockNFW
              ? "IP will be unblocked from both WAF (Layer 7) and Network Firewall (Layer 3/4)"
              : "IP will only be removed from WAF. It may still be blocked at Network Firewall."}
          </EuiText>
        </EuiConfirmModal>
      )}
    </>
  );
};

export default WAFManagementTab;
