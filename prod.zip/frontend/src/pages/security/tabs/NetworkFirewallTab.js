import React, { useState, useEffect } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import {
  EuiFlexGroup,
  EuiFlexItem,
  EuiPanel,
  EuiTitle,
  EuiSpacer,
  EuiButton,
  EuiTextArea,
  EuiBadge,
  EuiText,
  EuiToolTip,
  EuiIcon,
  EuiLoadingSpinner,
  EuiCallOut,
  EuiButtonEmpty,
} from '@elastic/eui';
import { DragDropContext, Droppable, Draggable } from 'react-beautiful-dnd';
import axios from 'axios';
import {
  fetchAllIpSets,
  addToAllowList,
  addToBlockList,
  removeFromAllowList,
  removeFromBlockList,
  transferIp,
  getWAFIPSet,
  addIPToWAFSet,
} from '../../../services/api';
import toast from 'react-hot-toast';

/**
 * Network Firewall Management Tab
 *
 * Manage Network Firewall (Layer 3/4) allow and block lists
 * with drag-and-drop functionality and dual-layer status indicators
 */
const NetworkFirewallTab = () => {
  const queryClient = useQueryClient();

  // State
  const [allowListInput, setAllowListInput] = useState('');
  const [blockListInput, setBlockListInput] = useState('');
  const [selectedAllowIPs, setSelectedAllowIPs] = useState([]);
  const [selectedBlockIPs, setSelectedBlockIPs] = useState([]);
  const [syncingToWAF, setSyncingToWAF] = useState(false);

  // Fetch Network Firewall IP sets
  const { data: firewallData, isLoading, refetch } = useQuery({
    queryKey: ['firewall-ip-sets'],
    queryFn: fetchAllIpSets,
    refetchInterval: 10000, // Refresh every 10 seconds
  });

  // Fetch WAF blocked IPs to show dual-layer status
  const { data: wafData } = useQuery({
    queryKey: ['waf-ip-set-for-status'],
    queryFn: () => getWAFIPSet('Blocked', 1, 5000),
    refetchInterval: 10000,
  });

  // Create a Set of WAF-blocked IPs for quick lookup
  const wafBlockedIPs = new Set(
    wafData?.data?.addresses?.map(ip => ip.split('/')[0]) || []
  );

  // Helper function to check if IP is also in WAF
  const isInWAF = (ip) => {
    const cleanIP = ip.split('/')[0];
    return wafBlockedIPs.has(cleanIP);
  };

  // Mutations
  const addToAllowMutation = useMutation({
    mutationFn: addToAllowList,
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['firewall-ip-sets'] });
      setAllowListInput('');
    },
  });

  const addToBlockMutation = useMutation({
    mutationFn: addToBlockList,
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['firewall-ip-sets'] });
      setBlockListInput('');
    },
  });

  const removeFromAllowMutation = useMutation({
    mutationFn: removeFromAllowList,
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['firewall-ip-sets'] });
      setSelectedAllowIPs([]);
    },
  });

  const removeFromBlockMutation = useMutation({
    mutationFn: removeFromBlockList,
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['firewall-ip-sets'] });
      setSelectedBlockIPs([]);
    },
  });

  const transferMutation = useMutation({
    mutationFn: ({ ip, from_list, to_list }) => transferIp(ip, from_list, to_list),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['firewall-ip-sets'] });
    },
  });

  // Handle drag and drop
  const onDragEnd = (result) => {
    const { source, destination, draggableId } = result;

    if (!destination) return;
    if (source.droppableId === destination.droppableId) return;

    const ip = draggableId;
    const from_list = source.droppableId;
    const to_list = destination.droppableId;

    transferMutation.mutate({ ip, from_list, to_list });
  };

  // Handle add IPs
  const handleAddToAllow = () => {
    const ips = allowListInput
      .split(/[,\n]/)
      .map(ip => ip.trim())
      .filter(ip => ip);
    if (ips.length > 0) {
      addToAllowMutation.mutate({ ips });
    }
  };

  const handleAddToBlock = () => {
    const ips = blockListInput
      .split(/[,\n]/)
      .map(ip => ip.trim())
      .filter(ip => ip);
    if (ips.length > 0) {
      addToBlockMutation.mutate({ ips });
    }
  };

  // Handle remove selected
  const handleRemoveFromAllow = () => {
    if (selectedAllowIPs.length > 0) {
      removeFromAllowMutation.mutate({ ips: selectedAllowIPs });
    }
  };

  const handleRemoveFromBlock = () => {
    if (selectedBlockIPs.length > 0) {
      removeFromBlockMutation.mutate({ ips: selectedBlockIPs });
    }
  };

  // Handle adding all NFW-only blocked IPs to WAF for dual-layer protection
  const handleAddAllToWAF = async () => {
    if (blockListWithoutWAF.length === 0) return;

    setSyncingToWAF(true);
    const analyst = localStorage.getItem('username') || 'admin';
    let successCount = 0;
    let failCount = 0;

    try {
      for (const ipCidr of blockListWithoutWAF) {
        const ip = ipCidr.split('/')[0]; // Extract IP from CIDR
        try {
          await addIPToWAFSet('Blocked', ip, 'Synced from Network Firewall for dual-layer protection', analyst);
          successCount++;
        } catch (err) {
          console.error(`Failed to add ${ip} to WAF:`, err);
          failCount++;
        }
      }

      // Refresh WAF data
      queryClient.invalidateQueries({ queryKey: ['waf-ip-set-for-status'] });

      if (failCount === 0) {
        toast.success(`Successfully added ${successCount} IPs to WAF for dual-layer protection`);
      } else {
        toast(`Added ${successCount} IPs to WAF. ${failCount} failed.`, { icon: '⚠️' });
      }
    } catch (err) {
      toast.error('Failed to sync IPs to WAF');
      console.error('Sync to WAF error:', err);
    } finally {
      setSyncingToWAF(false);
    }
  };

  // Render IP item with dual-layer status
  const renderIPItem = (ip, index, listType, selectedIPs, setSelectedIPs) => {
    const inWAF = isInWAF(ip);
    const isSelected = selectedIPs.includes(ip);

    return (
      <Draggable key={ip} draggableId={ip} index={index}>
        {(provided, snapshot) => (
          <div
            ref={provided.innerRef}
            {...provided.draggableProps}
            {...provided.dragHandleProps}
            style={{
              userSelect: 'none',
              padding: '8px 12px',
              margin: '0 0 8px 0',
              minHeight: '40px',
              backgroundColor: snapshot.isDragging ? 'rgba(0, 0, 0, 0.4)' : 'rgba(0, 0, 0, 0.3)',
              border: `2px solid ${isSelected ? '#006BB4' : 'rgba(255, 255, 255, 0.1)'}`,
              borderRadius: '6px',
              boxShadow: '0 2px 8px rgba(0, 0, 0, 0.15)',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'space-between',
              cursor: 'grab',
              ...provided.draggableProps.style,
            }}
            onClick={() => {
              if (isSelected) {
                setSelectedIPs(selectedIPs.filter(selectedIP => selectedIP !== ip));
              } else {
                setSelectedIPs([...selectedIPs, ip]);
              }
            }}
          >
            <EuiFlexGroup alignItems="center" gutterSize="s" responsive={false}>
              <EuiFlexItem grow={false}>
                <EuiIcon type={isSelected ? 'check' : 'grab'} size="m" />
              </EuiFlexItem>
              <EuiFlexItem>
                <strong style={{ color: '#FFFFFF' }}>{ip}</strong>
              </EuiFlexItem>
              {listType === 'block' && inWAF && (
                <EuiFlexItem grow={false}>
                  <EuiToolTip content="Also blocked in WAF (Layer 7) - Dual-layer protection active">
                    <EuiBadge color="success" iconType="check">
                      Dual Layer
                    </EuiBadge>
                  </EuiToolTip>
                </EuiFlexItem>
              )}
              {listType === 'block' && !inWAF && (
                <EuiFlexItem grow={false}>
                  <EuiToolTip content="Only blocked at Network Firewall (Layer 3/4). Consider adding to WAF for dual-layer protection.">
                    <EuiBadge color="warning" iconType="alert">
                      NFW Only
                    </EuiBadge>
                  </EuiToolTip>
                </EuiFlexItem>
              )}
            </EuiFlexGroup>
          </div>
        )}
      </Draggable>
    );
  };

  if (isLoading) {
    return (
      <EuiFlexGroup justifyContent="center" alignItems="center" style={{ minHeight: 400 }}>
        <EuiFlexItem grow={false}>
          <EuiLoadingSpinner size="xl" />
        </EuiFlexItem>
      </EuiFlexGroup>
    );
  }

  const allowList = firewallData?.allow_list || [];
  const blockList = firewallData?.block_list || [];
  const blockListWithoutWAF = blockList.filter(ip => !isInWAF(ip));

  return (
    <>
      {/* Warning if many blocks are not dual-layer */}
      {blockListWithoutWAF.length > 0 && (
        <>
          <EuiCallOut
            title={`${blockListWithoutWAF.length} of ${blockList.length} blocked IPs are not in WAF`}
            color="warning"
            iconType="alert"
          >
            <p>
              For defense-in-depth, consider adding these IPs to WAF (Layer 7) as well.
              Dual-layer blocking provides better protection against sophisticated attacks.
            </p>
            <EuiSpacer size="s" />
            <EuiButton
              size="s"
              color="warning"
              onClick={handleAddAllToWAF}
              isLoading={syncingToWAF}
              disabled={syncingToWAF}
            >
              {syncingToWAF ? 'Adding to WAF...' : `Add All ${blockListWithoutWAF.length} to WAF`}
            </EuiButton>
          </EuiCallOut>
          <EuiSpacer />
        </>
      )}

      <DragDropContext onDragEnd={onDragEnd}>
        <EuiFlexGroup>
          {/* Allow List */}
          <EuiFlexItem>
            <EuiPanel>
              <EuiFlexGroup alignItems="center" gutterSize="s">
                <EuiFlexItem>
                  <EuiTitle size="s">
                    <h3>
                      <EuiIcon type="check" color="success" /> Allow List
                    </h3>
                  </EuiTitle>
                </EuiFlexItem>
                <EuiFlexItem grow={false}>
                  <EuiBadge color="success">{allowList.length}</EuiBadge>
                </EuiFlexItem>
              </EuiFlexGroup>

              <EuiSpacer size="m" />

              <EuiTextArea
                placeholder="Enter IPs to allow (comma or newline separated)&#10;Example: 192.168.1.100, 10.0.0.0/24"
                value={allowListInput}
                onChange={(e) => setAllowListInput(e.target.value)}
                rows={3}
              />

              <EuiSpacer size="s" />

              <EuiFlexGroup gutterSize="s">
                <EuiFlexItem>
                  <EuiButton
                    fill
                    color="success"
                    onClick={handleAddToAllow}
                    isLoading={addToAllowMutation.isLoading}
                    disabled={!allowListInput.trim()}
                    fullWidth
                  >
                    Add to Allow List
                  </EuiButton>
                </EuiFlexItem>
                {selectedAllowIPs.length > 0 && (
                  <EuiFlexItem>
                    <EuiButton
                      color="danger"
                      onClick={handleRemoveFromAllow}
                      isLoading={removeFromAllowMutation.isLoading}
                      fullWidth
                    >
                      Remove ({selectedAllowIPs.length})
                    </EuiButton>
                  </EuiFlexItem>
                )}
              </EuiFlexGroup>

              <EuiSpacer />

              <div style={{ maxHeight: '500px', overflowY: 'auto' }}>
                <Droppable droppableId="allow">
                  {(provided, snapshot) => (
                    <div
                      {...provided.droppableProps}
                      ref={provided.innerRef}
                      style={{
                        background: snapshot.isDraggingOver ? '#E6F7FF' : 'transparent',
                        padding: '8px',
                        minHeight: '100px',
                        borderRadius: '6px',
                      }}
                    >
                      {allowList.length === 0 ? (
                        <EuiText color="subdued" textAlign="center">
                          <p>No IPs in allow list</p>
                        </EuiText>
                      ) : (
                        allowList.map((ip, index) =>
                          renderIPItem(ip, index, 'allow', selectedAllowIPs, setSelectedAllowIPs)
                        )
                      )}
                      {provided.placeholder}
                    </div>
                  )}
                </Droppable>
              </div>
            </EuiPanel>
          </EuiFlexItem>

          {/* Block List */}
          <EuiFlexItem>
            <EuiPanel>
              <EuiFlexGroup alignItems="center" gutterSize="s">
                <EuiFlexItem>
                  <EuiTitle size="s">
                    <h3>
                      <EuiIcon type="cross" color="danger" /> Block List
                    </h3>
                  </EuiTitle>
                </EuiFlexItem>
                <EuiFlexItem grow={false}>
                  <EuiBadge color="danger">{blockList.length}</EuiBadge>
                </EuiFlexItem>
              </EuiFlexGroup>

              <EuiSpacer size="m" />

              <EuiTextArea
                placeholder="Enter IPs to block (comma or newline separated)&#10;Example: 192.168.1.100, 10.0.0.0/24"
                value={blockListInput}
                onChange={(e) => setBlockListInput(e.target.value)}
                rows={3}
              />

              <EuiSpacer size="s" />

              <EuiFlexGroup gutterSize="s">
                <EuiFlexItem>
                  <EuiButton
                    fill
                    color="danger"
                    onClick={handleAddToBlock}
                    isLoading={addToBlockMutation.isLoading}
                    disabled={!blockListInput.trim()}
                    fullWidth
                  >
                    Add to Block List
                  </EuiButton>
                </EuiFlexItem>
                {selectedBlockIPs.length > 0 && (
                  <EuiFlexItem>
                    <EuiButton
                      color="primary"
                      onClick={handleRemoveFromBlock}
                      isLoading={removeFromBlockMutation.isLoading}
                      fullWidth
                    >
                      Remove ({selectedBlockIPs.length})
                    </EuiButton>
                  </EuiFlexItem>
                )}
              </EuiFlexGroup>

              <EuiSpacer />

              <div style={{ maxHeight: '500px', overflowY: 'auto' }}>
                <Droppable droppableId="block">
                  {(provided, snapshot) => (
                    <div
                      {...provided.droppableProps}
                      ref={provided.innerRef}
                      style={{
                        background: snapshot.isDraggingOver ? '#FFE6E6' : 'transparent',
                        padding: '8px',
                        minHeight: '100px',
                        borderRadius: '6px',
                      }}
                    >
                      {blockList.length === 0 ? (
                        <EuiText color="subdued" textAlign="center">
                          <p>No IPs in block list</p>
                        </EuiText>
                      ) : (
                        blockList.map((ip, index) =>
                          renderIPItem(ip, index, 'block', selectedBlockIPs, setSelectedBlockIPs)
                        )
                      )}
                      {provided.placeholder}
                    </div>
                  )}
                </Droppable>
              </div>
            </EuiPanel>
          </EuiFlexItem>
        </EuiFlexGroup>
      </DragDropContext>

      <EuiSpacer />

      <EuiText color="subdued" size="s">
        <p>
          <EuiIcon type="iInCircle" /> <strong>Tip:</strong> Drag and drop IPs between allow and block lists.
          Click to select multiple IPs for bulk removal.
          {blockListWithoutWAF.length > 0 && (
            <> IPs marked with <EuiBadge color="warning" iconType="alert">NFW Only</EuiBadge> are not in WAF for dual-layer protection.</>
          )}
        </p>
      </EuiText>
    </>
  );
};

export default NetworkFirewallTab;
