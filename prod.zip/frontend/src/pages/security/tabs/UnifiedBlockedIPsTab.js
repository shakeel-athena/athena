import React, { useState, useMemo } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import {
  EuiBasicTable,
  EuiFlexGroup,
  EuiFlexItem,
  EuiStat,
  EuiPanel,
  EuiSpacer,
  EuiBadge,
  EuiHealth,
  EuiButton,
  EuiButtonIcon,
  EuiFieldSearch,
  EuiSelect,
  EuiToolTip,
  EuiText,
  EuiCallOut,
  EuiLoadingSpinner,
  EuiEmptyPrompt,
  EuiConfirmModal,
} from '@elastic/eui';
import axios from 'axios';
import {
  getBlockedIPsFromAlerts,
  getWAFIPSet,
  unblockIPFromAlert,
  removeIPFromWAFSet,
} from '../../../services/api';

/**
 * Unified Blocked IPs Tab
 *
 * Shows ALL blocked IPs from all sources:
 * - Network Firewall (manual blocks)
 * - WAF IP sets (manual WAF blocks)
 * - Alert-based blocks (dual-layer tracking)
 */
const UnifiedBlockedIPsTab = () => {
  const queryClient = useQueryClient();

  // State
  const [searchTerm, setSearchTerm] = useState('');
  const [layerFilter, setLayerFilter] = useState('all');
  const [sourceFilter, setSourceFilter] = useState('all');
  const [threatTypeFilter, setThreatTypeFilter] = useState('all');
  const [unblockModalIP, setUnblockModalIP] = useState(null);
  const [unblockLayer, setUnblockLayer] = useState('both');

  // Pagination
  const [pageIndex, setPageIndex] = useState(0);
  const [pageSize, setPageSize] = useState(25);

  // Fetch data from all sources
  const { data: alertBlocks, isLoading: alertLoading } = useQuery({
    queryKey: ['alert-blocked-ips'],
    queryFn: () => getBlockedIPsFromAlerts({ active_only: true }),
    refetchInterval: 30000, // Refresh every 30 seconds
  });

  const { data: wafBlocks, isLoading: wafLoading } = useQuery({
    queryKey: ['waf-blocked-ips'],
    queryFn: () => getWAFIPSet('Blocked', 1, 5000), // Get all IPs from WAF
    refetchInterval: 30000,
  });

  // Merge blocked IPs from all sources
  const unifiedBlocks = useMemo(() => {
    if (!alertBlocks && !wafBlocks) return [];

    const ipMap = new Map();

    // Process alert-based blocks (these have dual-layer tracking)
    if (alertBlocks) {
      alertBlocks.forEach(ip => {
        ipMap.set(ip.ip_address, {
          ip: ip.ip_address,
          ip_cidr: ip.ip_cidr || `${ip.ip_address}/32`,
          layer: getLayerBadge(ip.aws_enforced, ip.waf_enforced),
          source: 'alert',
          threat_type: ip.threat_type || 'unknown',
          severity: ip.alert_severity || 'N/A',
          analyst: ip.added_by || 'system',
          added_date: ip.added_at ? new Date(ip.added_at) : new Date(),
          reason: ip.reason || 'Blocked from alert',
          nfw_enforced: ip.aws_enforced,
          waf_enforced: ip.waf_enforced,
          waf_error: ip.waf_error,
          metadata_id: ip.id,
          alert_source: ip.alert_source,
        });
      });
    }

    // Process WAF-only blocks (IPs in WAF but not in alert blocks)
    if (wafBlocks?.addresses) {
      wafBlocks.addresses.forEach(ipCidr => {
        const ip = ipCidr.split('/')[0];
        if (!ipMap.has(ip)) {
          ipMap.set(ip, {
            ip: ip,
            ip_cidr: ipCidr,
            layer: 'waf',
            source: 'manual',
            threat_type: 'manual',
            severity: 'N/A',
            analyst: 'manual',
            added_date: new Date(),
            reason: 'Manually added to WAF',
            nfw_enforced: false,
            waf_enforced: true,
            waf_error: null,
            metadata_id: null,
            alert_source: null,
          });
        }
      });
    }

    return Array.from(ipMap.values());
  }, [alertBlocks, wafBlocks]);

  // Get unique threat types for filter
  const threatTypes = useMemo(() => {
    const types = new Set(['all']);
    unifiedBlocks.forEach(ip => types.add(ip.threat_type));
    return Array.from(types);
  }, [unifiedBlocks]);

  // Filter and search
  const filteredBlocks = useMemo(() => {
    let filtered = unifiedBlocks;

    // Search filter
    if (searchTerm) {
      const term = searchTerm.toLowerCase();
      filtered = filtered.filter(ip =>
        ip.ip.toLowerCase().includes(term) ||
        ip.reason.toLowerCase().includes(term) ||
        ip.analyst.toLowerCase().includes(term)
      );
    }

    // Layer filter
    if (layerFilter !== 'all') {
      filtered = filtered.filter(ip => ip.layer === layerFilter);
    }

    // Source filter
    if (sourceFilter !== 'all') {
      filtered = filtered.filter(ip => ip.source === sourceFilter);
    }

    // Threat type filter
    if (threatTypeFilter !== 'all') {
      filtered = filtered.filter(ip => ip.threat_type === threatTypeFilter);
    }

    return filtered;
  }, [unifiedBlocks, searchTerm, layerFilter, sourceFilter, threatTypeFilter]);

  // Statistics
  const stats = useMemo(() => {
    const total = unifiedBlocks.length;
    const nfwOnly = unifiedBlocks.filter(ip => ip.layer === 'nfw').length;
    const wafOnly = unifiedBlocks.filter(ip => ip.layer === 'waf').length;
    const bothLayers = unifiedBlocks.filter(ip => ip.layer === 'both').length;
    const alertBased = unifiedBlocks.filter(ip => ip.source === 'alert').length;
    const manual = unifiedBlocks.filter(ip => ip.source === 'manual').length;

    return { total, nfwOnly, wafOnly, bothLayers, alertBased, manual };
  }, [unifiedBlocks]);

  // Unblock mutation
  const unblockMutation = useMutation({
    mutationFn: async ({ ip, layer }) => {
      const results = { nfw: null, waf: null };

      const analyst = localStorage.getItem('username') || 'admin';

      // Unblock from Network Firewall (via alert-based endpoint)
      if (layer === 'both' || layer === 'nfw') {
        try {
          await unblockIPFromAlert(ip, analyst);
          results.nfw = 'success';
        } catch (err) {
          results.nfw = err.message;
        }
      }

      // Unblock from WAF
      if (layer === 'both' || layer === 'waf') {
        try {
          await removeIPFromWAFSet('Blocked', ip, 'Manual unblock', analyst);
          results.waf = 'success';
        } catch (err) {
          results.waf = err.message;
        }
      }

      return results;
    },
    onSuccess: () => {
      // Refetch data
      queryClient.invalidateQueries({ queryKey: ['alert-blocked-ips'] });
      queryClient.invalidateQueries({ queryKey: ['waf-blocked-ips'] });
      setUnblockModalIP(null);
    },
  });

  // Helper function to determine layer badge
  function getLayerBadge(nfw, waf) {
    if (nfw && waf) return 'both';
    if (nfw) return 'nfw';
    if (waf) return 'waf';
    return 'none';
  }

  // Render layer badge
  const renderLayerBadge = (layer) => {
    switch (layer) {
      case 'both':
        return (
          <EuiToolTip content="Blocked at Network Firewall (Layer 3/4) and WAF (Layer 7)">
            <EuiBadge color="success" iconType="check">
              Both Layers
            </EuiBadge>
          </EuiToolTip>
        );
      case 'nfw':
        return (
          <EuiToolTip content="Blocked at Network Firewall only (Layer 3/4)">
            <EuiBadge color="warning" iconType="alert">
              NFW Only
            </EuiBadge>
          </EuiToolTip>
        );
      case 'waf':
        return (
          <EuiToolTip content="Blocked at WAF only (Layer 7)">
            <EuiBadge color="primary">WAF Only</EuiBadge>
          </EuiToolTip>
        );
      default:
        return <EuiBadge color="danger">Not Blocked</EuiBadge>;
    }
  };

  // Table columns
  const columns = [
    {
      field: 'ip',
      name: 'IP Address',
      width: '140px',
      render: (ip) => <strong>{ip}</strong>,
    },
    {
      field: 'layer',
      name: 'Layer',
      width: '140px',
      render: renderLayerBadge,
    },
    {
      field: 'source',
      name: 'Source',
      width: '100px',
      render: (source) => (
        <EuiBadge color={source === 'alert' ? 'danger' : 'default'}>
          {source === 'alert' ? 'Alert' : 'Manual'}
        </EuiBadge>
      ),
    },
    {
      field: 'threat_type',
      name: 'Threat Type',
      width: '140px',
      render: (type) => <EuiText size="s">{type || 'N/A'}</EuiText>,
    },
    {
      field: 'severity',
      name: 'Severity',
      width: '100px',
      render: (severity) => {
        const color =
          severity === 'Critical' ? 'danger' :
          severity === 'High' ? 'warning' :
          severity === 'Medium' ? 'primary' : 'subdued';
        return <EuiHealth color={color}>{severity}</EuiHealth>;
      },
    },
    {
      field: 'analyst',
      name: 'Analyst',
      width: '120px',
      truncateText: true,
    },
    {
      field: 'added_date',
      name: 'Added',
      width: '120px',
      dataType: 'date',
      render: (date) => new Date(date).toLocaleDateString(),
    },
    {
      field: 'reason',
      name: 'Reason',
      truncateText: true,
      render: (reason) => (
        <EuiToolTip content={reason}>
          <EuiText size="s">{reason}</EuiText>
        </EuiToolTip>
      ),
    },
    {
      name: 'Actions',
      width: '80px',
      actions: [
        {
          name: 'Unblock',
          description: 'Unblock this IP',
          icon: 'cross',
          type: 'icon',
          color: 'danger',
          onClick: (item) => {
            setUnblockModalIP(item);
            setUnblockLayer(item.layer === 'both' ? 'both' : item.layer);
          },
        },
      ],
    },
  ];

  // Pagination
  const paginatedItems = filteredBlocks.slice(
    pageIndex * pageSize,
    (pageIndex + 1) * pageSize
  );

  const pagination = {
    pageIndex,
    pageSize,
    totalItemCount: filteredBlocks.length,
    pageSizeOptions: [10, 25, 50, 100],
    showPerPageOptions: true,
  };

  const onTableChange = ({ page = {} }) => {
    const { index: pageIndex, size: pageSize } = page;
    setPageIndex(pageIndex);
    setPageSize(pageSize);
  };

  // Loading state
  if (alertLoading || wafLoading) {
    return (
      <EuiFlexGroup justifyContent="center" alignItems="center" style={{ minHeight: 400 }}>
        <EuiFlexItem grow={false}>
          <EuiLoadingSpinner size="xl" />
        </EuiFlexItem>
      </EuiFlexGroup>
    );
  }

  // Empty state
  if (unifiedBlocks.length === 0) {
    return (
      <EuiEmptyPrompt
        iconType="crossInACircleFilled"
        iconColor="subdued"
        title={<h2>No Blocked IPs</h2>}
        body={
          <p>
            There are currently no blocked IPs in Network Firewall or WAF.
            <br />
            Block IPs from the detection/events page or add them manually.
          </p>
        }
      />
    );
  }

  return (
    <>
      {/* Statistics Cards */}
      <EuiFlexGroup>
        <EuiFlexItem>
          <EuiPanel>
            <EuiStat
              title={stats.total}
              description="Total Blocked IPs"
              titleColor="danger"
              textAlign="center"
            />
          </EuiPanel>
        </EuiFlexItem>
        <EuiFlexItem>
          <EuiPanel>
            <EuiStat
              title={stats.bothLayers}
              description="Both Layers"
              titleColor="success"
              textAlign="center"
            />
          </EuiPanel>
        </EuiFlexItem>
        <EuiFlexItem>
          <EuiPanel>
            <EuiStat
              title={stats.nfwOnly}
              description="NFW Only"
              titleColor="warning"
              textAlign="center"
            />
          </EuiPanel>
        </EuiFlexItem>
        <EuiFlexItem>
          <EuiPanel>
            <EuiStat
              title={stats.wafOnly}
              description="WAF Only"
              titleColor="primary"
              textAlign="center"
            />
          </EuiPanel>
        </EuiFlexItem>
        <EuiFlexItem>
          <EuiPanel>
            <EuiStat
              title={stats.alertBased}
              description="Alert-Based"
              titleColor="danger"
              textAlign="center"
            />
          </EuiPanel>
        </EuiFlexItem>
        <EuiFlexItem>
          <EuiPanel>
            <EuiStat
              title={stats.manual}
              description="Manual"
              titleColor="subdued"
              textAlign="center"
            />
          </EuiPanel>
        </EuiFlexItem>
      </EuiFlexGroup>

      <EuiSpacer />

      {/* Warning if many IPs are not dual-layer */}
      {stats.nfwOnly > 0 && (
        <EuiCallOut
          title={`${stats.nfwOnly} IPs are only blocked at Network Firewall (Layer 3/4)`}
          color="warning"
          iconType="alert"
        >
          <p>
            For defense-in-depth, consider adding these IPs to WAF (Layer 7) as well.
            Dual-layer blocking provides better protection against sophisticated attacks.
          </p>
        </EuiCallOut>
      )}

      <EuiSpacer />

      {/* Filters and Search */}
      <EuiFlexGroup>
        <EuiFlexItem grow={2}>
          <EuiFieldSearch
            placeholder="Search by IP, reason, or analyst..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            isClearable
            fullWidth
          />
        </EuiFlexItem>
        <EuiFlexItem grow={1}>
          <EuiSelect
            options={[
              { value: 'all', text: 'All Layers' },
              { value: 'both', text: 'Both Layers' },
              { value: 'nfw', text: 'NFW Only' },
              { value: 'waf', text: 'WAF Only' },
            ]}
            value={layerFilter}
            onChange={(e) => setLayerFilter(e.target.value)}
            fullWidth
          />
        </EuiFlexItem>
        <EuiFlexItem grow={1}>
          <EuiSelect
            options={[
              { value: 'all', text: 'All Sources' },
              { value: 'alert', text: 'Alert-Based' },
              { value: 'manual', text: 'Manual' },
            ]}
            value={sourceFilter}
            onChange={(e) => setSourceFilter(e.target.value)}
            fullWidth
          />
        </EuiFlexItem>
        <EuiFlexItem grow={1}>
          <EuiSelect
            options={threatTypes.map(type => ({ value: type, text: type }))}
            value={threatTypeFilter}
            onChange={(e) => setThreatTypeFilter(e.target.value)}
            fullWidth
          />
        </EuiFlexItem>
      </EuiFlexGroup>

      <EuiSpacer />

      {/* Table */}
      <EuiBasicTable
        items={paginatedItems}
        columns={columns}
        pagination={pagination}
        onChange={onTableChange}
        hasActions={true}
        responsive={true}
      />

      {/* Unblock Confirmation Modal */}
      {unblockModalIP && (
        <EuiConfirmModal
          title={`Unblock IP ${unblockModalIP.ip}?`}
          onCancel={() => setUnblockModalIP(null)}
          onConfirm={() => unblockMutation.mutate({ ip: unblockModalIP.ip, layer: unblockLayer })}
          cancelButtonText="Cancel"
          confirmButtonText="Unblock"
          buttonColor="danger"
          defaultFocusedButton="confirm"
        >
          <EuiText>
            <p>
              <strong>IP:</strong> {unblockModalIP.ip}
              <br />
              <strong>Currently blocked at:</strong> {renderLayerBadge(unblockModalIP.layer)}
              <br />
              <strong>Reason:</strong> {unblockModalIP.reason}
            </p>
            <EuiSpacer />
            <p>Select which layer(s) to unblock from:</p>
            <EuiSelect
              options={[
                ...(unblockModalIP.layer === 'both' || unblockModalIP.layer === 'nfw'
                  ? [{ value: 'nfw', text: 'Network Firewall only' }]
                  : []),
                ...(unblockModalIP.layer === 'both' || unblockModalIP.layer === 'waf'
                  ? [{ value: 'waf', text: 'WAF only' }]
                  : []),
                ...(unblockModalIP.layer === 'both'
                  ? [{ value: 'both', text: 'Both layers' }]
                  : []),
              ]}
              value={unblockLayer}
              onChange={(e) => setUnblockLayer(e.target.value)}
            />
          </EuiText>
        </EuiConfirmModal>
      )}
    </>
  );
};

export default UnifiedBlockedIPsTab;
