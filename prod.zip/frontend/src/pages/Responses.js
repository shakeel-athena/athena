import React, { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { 
  Shield, 
  Play, 
  Pause, 
  CheckCircle, 
  XCircle, 
  Clock,
  Filter,
  Plus,
  Eye
} from 'lucide-react';
import { formatDistanceToNow } from 'date-fns';
import { fetchResponseActions, executeManualAction } from '../services/api';
import { toast } from 'react-hot-toast';

const Responses = () => {
  const [filters, setFilters] = useState({
    provider: '',
    status: '',
    timeRange: '24'
  });
  const [showManualAction, setShowManualAction] = useState(false);
  const [selectedAction, setSelectedAction] = useState(null);

  const { data, isLoading, refetch } = useQuery(
    ['responseActions', filters],
    () => fetchResponseActions(filters),
    { refetchInterval: 30000 }
  );

  const getStatusIcon = (status) => {
    switch (status) {
      case 'success':
        return <CheckCircle className="w-4 h-4 text-status-success" />;
      case 'failed':
        return <XCircle className="w-4 h-4 text-status-error" />;
      case 'pending':
        return <Clock className="w-4 h-4 text-status-warning" />;
      default:
        return <Clock className="w-4 h-4 text-dark-400" />;
    }
  };

  const getStatusBadge = (status) => {
    const badges = {
      success: 'badge-success',
      failed: 'badge-error',
      pending: 'badge-info',
    };
    return badges[status] || 'badge-info';
  };

  const getProviderColor = (provider) => {
    const colors = {
      waf: 'text-accent-blue',
      firewall: 'text-accent-purple',
    };
    return colors[provider] || 'text-dark-400';
  };

  const handleManualAction = async (actionData) => {
    try {
      await executeManualAction(actionData);
      toast.success('Manual action executed successfully');
      setShowManualAction(false);
      refetch();
    } catch (error) {
      toast.error('Failed to execute manual action');
    }
  };

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-white">Response Actions</h1>
          <p className="text-dark-400 mt-1">Monitor and manage automated security responses</p>
        </div>
        <div className="flex items-center space-x-3">
          <button
            onClick={() => setShowManualAction(true)}
            className="btn-primary flex items-center space-x-2"
          >
            <Plus className="w-4 h-4" />
            <span>Manual Action</span>
          </button>
        </div>
      </div>

      {/* Filters */}
      <div className="card">
        <div className="card-content">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {/* Provider Filter */}
            <select
              className="input"
              value={filters.provider}
              onChange={(e) => setFilters({ ...filters, provider: e.target.value })}
            >
              <option value="">All Providers</option>
              <option value="waf">WAF</option>
              <option value="firewall">Firewall</option>
            </select>

            {/* Status Filter */}
            <select
              className="input"
              value={filters.status}
              onChange={(e) => setFilters({ ...filters, status: e.target.value })}
            >
              <option value="">All Statuses</option>
              <option value="success">Success</option>
              <option value="failed">Failed</option>
              <option value="pending">Pending</option>
            </select>

            {/* Time Range */}
            <select
              className="input"
              value={filters.timeRange}
              onChange={(e) => setFilters({ ...filters, timeRange: e.target.value })}
            >
              <option value="1">Last Hour</option>
              <option value="24">Last 24 Hours</option>
              <option value="168">Last Week</option>
            </select>
          </div>
        </div>
      </div>

      {/* Actions Table */}
      <div className="card">
        <div className="card-header">
          <h3 className="text-lg font-semibold text-white flex items-center">
            <Shield className="w-5 h-5 mr-2" />
            Response Actions
            {data && (
              <span className="ml-2 text-sm text-dark-400">
                ({data.total} total)
              </span>
            )}
          </h3>
        </div>
        
        <div className="overflow-x-auto">
          {isLoading ? (
            <div className="p-8 flex items-center justify-center">
              <div className="spinner w-6 h-6"></div>
              <span className="ml-2 text-dark-400">Loading actions...</span>
            </div>
          ) : data?.actions?.length === 0 ? (
            <div className="p-8 text-center text-dark-400">
              <Shield className="w-12 h-12 mx-auto mb-4 opacity-50" />
              <h3 className="text-lg font-medium text-white mb-2">No actions found</h3>
              <p>Try adjusting your filters or check back later.</p>
            </div>
          ) : (
            <table className="table">
              <thead>
                <tr>
                  <th>Status</th>
                  <th>Action</th>
                  <th>Provider</th>
                  <th>Target</th>
                  <th>Execution Time</th>
                  <th>Expires</th>
                  <th>Time</th>
                  <th></th>
                </tr>
              </thead>
              <tbody>
                {data?.actions?.map((action) => (
                  <tr key={action.id}>
                    <td>
                      <div className="flex items-center space-x-2">
                        {getStatusIcon(action.execution_status)}
                        <span className={`badge ${getStatusBadge(action.execution_status)}`}>
                          {action.execution_status.toUpperCase()}
                        </span>
                      </div>
                    </td>
                    <td>
                      <span className="text-white font-medium capitalize">
                        {action.action_name.replace(/_/g, ' ')}
                      </span>
                    </td>
                    <td>
                      <span className={`capitalize font-medium ${getProviderColor(action.provider)}`}>
                        {action.provider}
                      </span>
                    </td>
                    <td>
                      <div className="text-sm">
                        {action.parameters.ip && (
                          <div className="text-white font-mono">{action.parameters.ip}</div>
                        )}
                        {action.parameters.subnet && (
                          <div className="text-white font-mono">{action.parameters.subnet}</div>
                        )}
                        {action.parameters.route && (
                          <div className="text-dark-300">{action.parameters.route}</div>
                        )}
                        {action.parameters.asn && (
                          <div className="text-dark-300">{action.parameters.asn}</div>
                        )}
                      </div>
                    </td>
                    <td>
                      <span className="text-sm text-dark-300">
                        {action.execution_time_ms}ms
                      </span>
                    </td>
                    <td>
                      {action.expires_at ? (
                        <span className="text-sm text-dark-300">
                          {formatDistanceToNow(new Date(action.expires_at), { addSuffix: true })}
                        </span>
                      ) : (
                        <span className="text-sm text-dark-500">-</span>
                      )}
                    </td>
                    <td>
                      <span className="text-sm text-dark-400">
                        {formatDistanceToNow(new Date(action.timestamp), { addSuffix: true })}
                      </span>
                    </td>
                    <td>
                      <button
                        onClick={() => setSelectedAction(action)}
                        className="p-1 text-dark-400 hover:text-white transition-colors duration-150"
                        title="View details"
                      >
                        <Eye className="w-4 h-4" />
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>
      </div>

      {/* Manual Action Modal */}
      {showManualAction && (
        <div className="fixed inset-0 z-50 overflow-y-auto">
          <div className="flex items-center justify-center min-h-screen px-4 pt-4 pb-20 text-center sm:block sm:p-0">
            <div className="fixed inset-0 transition-opacity bg-black bg-opacity-75" onClick={() => setShowManualAction(false)}></div>
            
            <div className="inline-block w-full max-w-md p-6 my-8 overflow-hidden text-left align-middle transition-all transform bg-dark-800 border border-dark-600 shadow-xl rounded-lg">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-lg font-medium text-white">Execute Manual Action</h3>
                <button
                  onClick={() => setShowManualAction(false)}
                  className="text-dark-400 hover:text-white"
                >
                  <XCircle className="w-5 h-5" />
                </button>
              </div>
              
              <form onSubmit={(e) => {
                e.preventDefault();
                const formData = new FormData(e.target);
                handleManualAction({
                  provider: formData.get('provider'),
                  action: formData.get('action'),
                  target: formData.get('target'),
                  ttl: parseInt(formData.get('ttl')),
                  reason: formData.get('reason')
                });
              }}>
                <div className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium text-dark-300 mb-1">
                      Provider
                    </label>
                    <select name="provider" className="input" required>
                      <option value="">Select provider</option>
                      <option value="waf">WAF</option>
                      <option value="firewall">Firewall</option>
                    </select>
                  </div>
                  
                  <div>
                    <label className="block text-sm font-medium text-dark-300 mb-1">
                      Action
                    </label>
                    <select name="action" className="input" required>
                      <option value="">Select action</option>
                      <option value="block_ip">Block IP</option>
                      <option value="unblock_ip">Unblock IP</option>
                      <option value="rate_limit">Rate Limit</option>
                      <option value="challenge">Challenge</option>
                    </select>
                  </div>
                  
                  <div>
                    <label className="block text-sm font-medium text-dark-300 mb-1">
                      Target (IP, subnet, etc.)
                    </label>
                    <input
                      type="text"
                      name="target"
                      className="input"
                      placeholder="e.g., 192.168.1.100"
                      required
                    />
                  </div>
                  
                  <div>
                    <label className="block text-sm font-medium text-dark-300 mb-1">
                      TTL (seconds)
                    </label>
                    <input
                      type="number"
                      name="ttl"
                      className="input"
                      placeholder="3600"
                      min="60"
                      max="86400"
                      defaultValue="3600"
                    />
                  </div>
                  
                  <div>
                    <label className="block text-sm font-medium text-dark-300 mb-1">
                      Reason
                    </label>
                    <textarea
                      name="reason"
                      className="input"
                      rows="3"
                      placeholder="Reason for manual action..."
                      required
                    />
                  </div>
                </div>
                
                <div className="mt-6 flex justify-end space-x-3">
                  <button
                    type="button"
                    onClick={() => setShowManualAction(false)}
                    className="btn-secondary"
                  >
                    Cancel
                  </button>
                  <button type="submit" className="btn-primary">
                    Execute Action
                  </button>
                </div>
              </form>
            </div>
          </div>
        </div>
      )}

      {/* Action Detail Modal */}
      {selectedAction && (
        <div className="fixed inset-0 z-50 overflow-y-auto">
          <div className="flex items-center justify-center min-h-screen px-4 pt-4 pb-20 text-center sm:block sm:p-0">
            <div className="fixed inset-0 transition-opacity bg-black bg-opacity-75" onClick={() => setSelectedAction(null)}></div>
            
            <div className="inline-block w-full max-w-2xl p-6 my-8 overflow-hidden text-left align-middle transition-all transform bg-dark-800 border border-dark-600 shadow-xl rounded-lg">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-lg font-medium text-white">Action Details</h3>
                <button
                  onClick={() => setSelectedAction(null)}
                  className="text-dark-400 hover:text-white"
                >
                  <XCircle className="w-5 h-5" />
                </button>
              </div>
              
              <div className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="text-sm text-dark-400">Status</label>
                    <div className="mt-1 flex items-center space-x-2">
                      {getStatusIcon(selectedAction.execution_status)}
                      <span className={`badge ${getStatusBadge(selectedAction.execution_status)}`}>
                        {selectedAction.execution_status.toUpperCase()}
                      </span>
                    </div>
                  </div>
                  <div>
                    <label className="text-sm text-dark-400">Execution Time</label>
                    <div className="mt-1 text-white">{selectedAction.execution_time_ms}ms</div>
                  </div>
                </div>
                
                <div>
                  <label className="text-sm text-dark-400">Action</label>
                  <div className="mt-1 text-white capitalize">
                    {selectedAction.action_name.replace(/_/g, ' ')}
                  </div>
                </div>
                
                <div>
                  <label className="text-sm text-dark-400">Parameters</label>
                  <div className="mt-1 bg-dark-700 rounded p-3">
                    <pre className="text-sm text-dark-300 font-mono">
                      {JSON.stringify(selectedAction.parameters, null, 2)}
                    </pre>
                  </div>
                </div>
                
                {selectedAction.result && (
                  <div>
                    <label className="text-sm text-dark-400">Result</label>
                    <div className="mt-1 bg-dark-700 rounded p-3">
                      <pre className="text-sm text-dark-300 font-mono">
                        {JSON.stringify(selectedAction.result, null, 2)}
                      </pre>
                    </div>
                  </div>
                )}
                
                {selectedAction.error && (
                  <div>
                    <label className="text-sm text-dark-400">Error</label>
                    <div className="mt-1 bg-threat-critical/10 border border-threat-critical/30 rounded p-3">
                      <p className="text-threat-critical text-sm">
                        {selectedAction.error.message}
                      </p>
                      <p className="text-dark-400 text-xs mt-1">
                        Code: {selectedAction.error.code}
                      </p>
                    </div>
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default Responses;
