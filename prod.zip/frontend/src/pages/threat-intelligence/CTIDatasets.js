import React, { useState, useEffect } from 'react';
import {
  EuiPage,
  EuiPageBody,
  EuiPageHeader,
  EuiPanel,
  EuiFlexGroup,
  EuiFlexItem,
  EuiText,
  EuiTitle,
  EuiCard,
  EuiBadge,
  EuiBasicTable,
  EuiCallOut,
  EuiProgress,
  EuiButtonIcon,
  EuiToolTip,
  EuiTabbedContent,
  EuiSpacer,
  EuiLoadingSpinner,
  EuiEmptyPrompt,
  EuiButton,
  EuiStat,
  EuiHorizontalRule
} from '@elastic/eui';
import {
  Shield,
  Bug,
  AlertTriangle,
  Target,
  Activity,
  RefreshCw,
  ExternalLink,
  Database,
  Users,
  Lock
} from 'lucide-react';
import ctiService from '../../services/detection/ctiService';

function CTIDatasets() {
  const [selectedTabId, setSelectedTabId] = useState('tactics');
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  // State for different datasets
  const [status, setStatus] = useState(null);
  const [tactics, setTactics] = useState([]);
  const [techniques, setTechniques] = useState([]);
  const [cves, setCVEs] = useState([]);
  const [kevs, setKEVs] = useState([]);
  const [campaigns, setCampaigns] = useState([]);
  const [malware, setMalware] = useState([]);
  const [syncStatus, setSyncStatus] = useState(null);

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    setLoading(true);
    setError(null);

    try {
      // Load all data in parallel
      const [
        statusData,
        tacticsData,
        techniquesData,
        cvesData,
        kevsData,
        campaignsData,
        malwareData,
        syncData
      ] = await Promise.all([
        ctiService.getStatus(),
        ctiService.getTactics(),
        ctiService.getTechniques({ limit: 10 }),
        ctiService.getCVEs({ limit: 10 }),
        ctiService.getKEVs({ limit: 10 }),
        ctiService.getCampaigns(),
        ctiService.getMalware({ limit: 10 }),
        ctiService.getSyncStatus()
      ]);

      setStatus(statusData);
      setTactics(tacticsData);
      setTechniques(techniquesData.data);
      setCVEs(cvesData.data);
      setKEVs(kevsData.data);
      setCampaigns(campaignsData);
      setMalware(malwareData.data);
      setSyncStatus(syncData);
    } catch (err) {
      console.error('Error loading CTI data:', err);
      setError('Failed to load CTI data. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  const getSeverityColor = (severity) => {
    const colors = {
      CRITICAL: 'danger',
      HIGH: 'warning',
      MEDIUM: 'primary',
      LOW: 'success',
      critical: 'danger',
      high: 'warning',
      medium: 'primary',
      low: 'success'
    };
    return colors[severity] || 'default';
  };

  const getSyncStatusColor = (status) => {
    const colors = {
      synced: 'success',
      syncing: 'warning',
      error: 'danger',
      pending: 'primary'
    };
    return colors[status] || 'default';
  };

  // Tactics table columns
  const tacticsColumns = [
    {
      field: 'mitre_id',
      name: 'ID',
      width: '120px',
      render: (value) => (
        <EuiBadge color="hollow" style={{ fontFamily: 'monospace' }}>
          {value}
        </EuiBadge>
      )
    },
    {
      field: 'name',
      name: 'Name',
      render: (value) => (
        <EuiText size="s">
          <strong>{value}</strong>
        </EuiText>
      )
    },
    {
      field: 'description',
      name: 'Description',
      render: (value) => (
        <EuiText size="s" color="subdued">
          {value}
        </EuiText>
      )
    },
    {
      field: 'technique_count',
      name: 'Techniques',
      align: 'right',
      width: '120px',
      render: (value) => <EuiBadge color="primary">{value}</EuiBadge>
    },
    {
      name: 'Actions',
      align: 'right',
      width: '80px',
      render: (item) => (
        <EuiToolTip content="View on MITRE ATT&CK">
          <EuiButtonIcon
            iconType="popout"
            onClick={() => window.open(item.url, '_blank')}
            aria-label="View on MITRE ATT&CK"
            color="primary"
          />
        </EuiToolTip>
      )
    }
  ];

  // Techniques table columns
  const techniquesColumns = [
    {
      field: 'mitre_id',
      name: 'ID',
      width: '120px',
      render: (value) => (
        <EuiBadge color="hollow" style={{ fontFamily: 'monospace' }}>
          {value}
        </EuiBadge>
      )
    },
    {
      field: 'name',
      name: 'Name'
    },
    {
      field: 'tactic_name',
      name: 'Tactic',
      render: (value) => <EuiBadge>{value}</EuiBadge>
    },
    {
      field: 'detection_count',
      name: 'Detections',
      align: 'right',
      width: '120px',
      render: (value) => <EuiBadge color="primary">{value}</EuiBadge>
    },
    {
      field: 'severity',
      name: 'Severity',
      align: 'right',
      width: '120px',
      render: (value) => (
        <EuiBadge color={getSeverityColor(value)}>
          {value?.toUpperCase()}
        </EuiBadge>
      )
    }
  ];

  // CVE table columns
  const cveColumns = [
    {
      field: 'cve_id',
      name: 'CVE ID',
      width: '150px',
      render: (value) => (
        <EuiBadge
          color="warning"
          style={{
            fontFamily: 'monospace',
            backgroundColor: 'rgba(245, 167, 0, 0.2)',
            borderColor: 'rgba(245, 167, 0, 0.3)'
          }}
        >
          {value}
        </EuiBadge>
      )
    },
    {
      field: 'name',
      name: 'Name',
      render: (value, item) => (
        <EuiFlexGroup direction="column" gutterSize="xs">
          <EuiFlexItem>
            <EuiText size="s">
              <strong>{value}</strong>
            </EuiText>
          </EuiFlexItem>
          <EuiFlexItem>
            <EuiText size="xs" color="subdued">
              {item.description?.substring(0, 100)}...
            </EuiText>
          </EuiFlexItem>
        </EuiFlexGroup>
      )
    },
    {
      field: 'cvss_score',
      name: 'CVSS Score',
      align: 'center',
      width: '100px',
      render: (value) => (
        <EuiText size="m">
          <strong style={{ color: value >= 9 ? '#ef4444' : value >= 7 ? '#f59e0b' : '#3b82f6' }}>
            {value}
          </strong>
        </EuiText>
      )
    },
    {
      field: 'cvss_severity',
      name: 'Severity',
      width: '120px',
      render: (value) => (
        <EuiBadge color={getSeverityColor(value)}>
          {value?.toUpperCase()}
        </EuiBadge>
      )
    },
    {
      field: 'published_date',
      name: 'Published',
      width: '120px',
      render: (value) => (
        <EuiText size="xs">{new Date(value).toLocaleDateString()}</EuiText>
      )
    },
    {
      name: 'Status',
      width: '150px',
      render: (item) => (
        <EuiFlexGroup gutterSize="xs" wrap>
          {item.is_kev && (
            <EuiFlexItem grow={false}>
              <EuiBadge color="danger">KEV</EuiBadge>
            </EuiFlexItem>
          )}
          {item.exploited_in_wild && (
            <EuiFlexItem grow={false}>
              <EuiBadge color="warning">Exploited</EuiBadge>
            </EuiFlexItem>
          )}
        </EuiFlexGroup>
      )
    }
  ];

  if (loading) {
    return (
      <EuiPage paddingSize="none">
        <EuiPageBody panelled>
          <EuiEmptyPrompt
            icon={<EuiLoadingSpinner size="xl" />}
            title={<h2>Loading CTI Datasets</h2>}
            body={
              <EuiText size="s" color="subdued">
                Fetching threat intelligence data from multiple sources...
              </EuiText>
            }
          />
        </EuiPageBody>
      </EuiPage>
    );
  }

  const tabs = [
    {
      id: 'tactics',
      name: (
        <EuiFlexGroup gutterSize="s" alignItems="center" responsive={false}>
          <EuiFlexItem grow={false}>
            <Target style={{ width: '16px', height: '16px' }} />
          </EuiFlexItem>
          <EuiFlexItem>Tactics & Techniques</EuiFlexItem>
        </EuiFlexGroup>
      ),
      content: (
        <EuiFlexGroup direction="column" gutterSize="l">
          <EuiFlexItem>
            <EuiPanel hasBorder>
              <EuiFlexGroup alignItems="center" gutterSize="s" responsive={false}>
                <EuiFlexItem grow={false}>
                  <Shield style={{ width: '20px', height: '20px', color: '#8b5cf6' }} />
                </EuiFlexItem>
                <EuiFlexItem>
                  <EuiTitle size="s">
                    <h3>MITRE ATT&CK Tactics ({tactics.length})</h3>
                  </EuiTitle>
                </EuiFlexItem>
              </EuiFlexGroup>
              <EuiSpacer size="m" />
              <EuiBasicTable items={tactics} columns={tacticsColumns} />
            </EuiPanel>
          </EuiFlexItem>

          <EuiFlexItem>
            <EuiPanel hasBorder>
              <EuiFlexGroup alignItems="center" gutterSize="s" responsive={false}>
                <EuiFlexItem grow={false}>
                  <Activity style={{ width: '20px', height: '20px', color: '#3b82f6' }} />
                </EuiFlexItem>
                <EuiFlexItem>
                  <EuiTitle size="s">
                    <h3>Recent Techniques</h3>
                  </EuiTitle>
                </EuiFlexItem>
              </EuiFlexGroup>
              <EuiSpacer size="m" />
              <EuiBasicTable items={techniques} columns={techniquesColumns} />
            </EuiPanel>
          </EuiFlexItem>
        </EuiFlexGroup>
      )
    },
    {
      id: 'cves',
      name: (
        <EuiFlexGroup gutterSize="s" alignItems="center" responsive={false}>
          <EuiFlexItem grow={false}>
            <Bug style={{ width: '16px', height: '16px' }} />
          </EuiFlexItem>
          <EuiFlexItem>Vulnerabilities (CVE)</EuiFlexItem>
        </EuiFlexGroup>
      ),
      content: (
        <EuiPanel hasBorder>
          <EuiFlexGroup alignItems="center" gutterSize="s" responsive={false}>
            <EuiFlexItem grow={false}>
              <Bug style={{ width: '20px', height: '20px', color: '#f59e0b' }} />
            </EuiFlexItem>
            <EuiFlexItem>
              <EuiTitle size="s">
                <h3>Common Vulnerabilities and Exposures (CVEs)</h3>
              </EuiTitle>
            </EuiFlexItem>
          </EuiFlexGroup>
          <EuiSpacer size="m" />
          <EuiBasicTable items={cves} columns={cveColumns} />
        </EuiPanel>
      )
    },
    {
      id: 'kevs',
      name: (
        <EuiFlexGroup gutterSize="s" alignItems="center" responsive={false}>
          <EuiFlexItem grow={false}>
            <AlertTriangle style={{ width: '16px', height: '16px' }} />
          </EuiFlexItem>
          <EuiFlexItem>Known Exploits (KEV)</EuiFlexItem>
        </EuiFlexGroup>
      ),
      content: (
        <EuiFlexGroup direction="column" gutterSize="l">
          <EuiFlexItem>
            <EuiCallOut
              title="Active Exploitation Warning"
              color="warning"
              iconType="warning"
            >
              These vulnerabilities are actively exploited in the wild and require immediate
              attention. Prioritize patching these CVEs according to CISA guidance.
            </EuiCallOut>
          </EuiFlexItem>

          <EuiFlexItem>
            <EuiPanel hasBorder>
              <EuiFlexGroup alignItems="center" gutterSize="s" responsive={false}>
                <EuiFlexItem grow={false}>
                  <AlertTriangle style={{ width: '20px', height: '20px', color: '#ef4444' }} />
                </EuiFlexItem>
                <EuiFlexItem>
                  <EuiTitle size="s">
                    <h3>CISA Known Exploited Vulnerabilities (KEV)</h3>
                  </EuiTitle>
                </EuiFlexItem>
              </EuiFlexGroup>
              <EuiSpacer size="m" />
              <EuiBasicTable
                items={kevs}
                columns={[
                  {
                    field: 'cve_id',
                    name: 'CVE ID',
                    width: '150px',
                    render: (value) => (
                      <EuiBadge
                        color="danger"
                        style={{ fontFamily: 'monospace' }}
                      >
                        {value}
                      </EuiBadge>
                    )
                  },
                  {
                    field: 'vendor_project',
                    name: 'Vendor/Product',
                    render: (value, item) => (
                      <EuiFlexGroup direction="column" gutterSize="xs">
                        <EuiFlexItem>
                          <EuiText size="s">
                            <strong>{value}</strong>
                          </EuiText>
                        </EuiFlexItem>
                        <EuiFlexItem>
                          <EuiText size="xs" color="subdued">
                            {item.product}
                          </EuiText>
                        </EuiFlexItem>
                      </EuiFlexGroup>
                    )
                  },
                  {
                    field: 'vulnerability_name',
                    name: 'Vulnerability Name',
                    render: (value, item) => (
                      <EuiFlexGroup direction="column" gutterSize="xs">
                        <EuiFlexItem>
                          <EuiText size="s">{value}</EuiText>
                        </EuiFlexItem>
                        <EuiFlexItem>
                          <EuiText size="xs" color="subdued">
                            {item.short_description}
                          </EuiText>
                        </EuiFlexItem>
                      </EuiFlexGroup>
                    )
                  },
                  {
                    field: 'date_added',
                    name: 'Date Added',
                    width: '120px',
                    render: (value) => (
                      <EuiText size="xs">
                        {new Date(value).toLocaleDateString()}
                      </EuiText>
                    )
                  },
                  {
                    field: 'due_date',
                    name: 'Due Date',
                    width: '120px',
                    render: (value) => (
                      <EuiBadge color="warning">
                        {new Date(value).toLocaleDateString()}
                      </EuiBadge>
                    )
                  }
                ]}
              />
            </EuiPanel>
          </EuiFlexItem>
        </EuiFlexGroup>
      )
    },
    {
      id: 'campaigns',
      name: (
        <EuiFlexGroup gutterSize="s" alignItems="center" responsive={false}>
          <EuiFlexItem grow={false}>
            <Users style={{ width: '16px', height: '16px' }} />
          </EuiFlexItem>
          <EuiFlexItem>Campaigns</EuiFlexItem>
        </EuiFlexGroup>
      ),
      content: (
        <EuiFlexGroup direction="column" gutterSize="l">
          <EuiFlexItem>
            <EuiFlexGroup alignItems="center" gutterSize="s" responsive={false}>
              <EuiFlexItem grow={false}>
                <Users style={{ width: '24px', height: '24px', color: '#8b5cf6' }} />
              </EuiFlexItem>
              <EuiFlexItem>
                <EuiTitle size="s">
                  <h3>Threat Campaigns</h3>
                </EuiTitle>
              </EuiFlexItem>
            </EuiFlexGroup>
          </EuiFlexItem>

          <EuiFlexItem>
            <EuiFlexGroup gutterSize="l" wrap>
              {campaigns.map((campaign) => (
                <EuiFlexItem key={campaign.stix_id} style={{ minWidth: '400px', maxWidth: '500px' }}>
                  <EuiCard
                    hasBorder
                    title={campaign.name}
                    description=""
                    paddingSize="l"
                  >
                    <EuiFlexGroup gutterSize="s" wrap>
                      <EuiFlexItem grow={false}>
                        <EuiBadge color="hollow">{campaign.mitre_id}</EuiBadge>
                      </EuiFlexItem>
                    </EuiFlexGroup>

                    <EuiSpacer size="s" />

                    <EuiText size="xs" color="subdued">
                      {campaign.description}
                    </EuiText>

                    <EuiSpacer size="s" />

                    <EuiFlexGroup gutterSize="s" alignItems="center">
                      <EuiFlexItem grow={false}>
                        <EuiText size="xs" color="subdued">
                          Active Period:
                        </EuiText>
                      </EuiFlexItem>
                      <EuiFlexItem>
                        <EuiText size="xs">
                          {new Date(campaign.first_seen).toLocaleDateString()} -{' '}
                          {new Date(campaign.last_seen).toLocaleDateString()}
                        </EuiText>
                      </EuiFlexItem>
                    </EuiFlexGroup>

                    <EuiSpacer size="m" />
                    <EuiHorizontalRule margin="none" />
                    <EuiSpacer size="m" />

                    <EuiText size="xs">
                      <strong>Associated Techniques:</strong>
                    </EuiText>
                    <EuiSpacer size="xs" />
                    <EuiFlexGroup gutterSize="xs" wrap>
                      {campaign.techniques_used.map((tech) => (
                        <EuiFlexItem grow={false} key={tech}>
                          <EuiBadge color="hollow">{tech}</EuiBadge>
                        </EuiFlexItem>
                      ))}
                    </EuiFlexGroup>
                  </EuiCard>
                </EuiFlexItem>
              ))}
            </EuiFlexGroup>
          </EuiFlexItem>
        </EuiFlexGroup>
      )
    },
    {
      id: 'malware',
      name: (
        <EuiFlexGroup gutterSize="s" alignItems="center" responsive={false}>
          <EuiFlexItem grow={false}>
            <Lock style={{ width: '16px', height: '16px' }} />
          </EuiFlexItem>
          <EuiFlexItem>Malware</EuiFlexItem>
        </EuiFlexGroup>
      ),
      content: (
        <EuiFlexGroup direction="column" gutterSize="l">
          <EuiFlexItem>
            <EuiFlexGroup alignItems="center" gutterSize="s" responsive={false}>
              <EuiFlexItem grow={false}>
                <Lock style={{ width: '24px', height: '24px', color: '#ef4444' }} />
              </EuiFlexItem>
              <EuiFlexItem>
                <EuiTitle size="s">
                  <h3>Malware & Tools</h3>
                </EuiTitle>
              </EuiFlexItem>
            </EuiFlexGroup>
          </EuiFlexItem>

          <EuiFlexItem>
            <EuiFlexGroup gutterSize="l" wrap>
              {malware.map((mal) => (
                <EuiFlexItem key={mal.stix_id} style={{ minWidth: '400px', maxWidth: '500px' }}>
                  <EuiCard hasBorder title={mal.name} description="" paddingSize="l">
                    <EuiFlexGroup gutterSize="s" wrap>
                      <EuiFlexItem grow={false}>
                        <EuiBadge color="hollow">{mal.mitre_id}</EuiBadge>
                      </EuiFlexItem>
                      <EuiFlexItem grow={false}>
                        <EuiBadge color="warning">{mal.type}</EuiBadge>
                      </EuiFlexItem>
                    </EuiFlexGroup>

                    <EuiSpacer size="s" />

                    <EuiText size="xs" color="subdued">
                      {mal.description}
                    </EuiText>

                    <EuiSpacer size="m" />
                    <EuiHorizontalRule margin="none" />
                    <EuiSpacer size="m" />

                    <EuiText size="xs">
                      <strong>Target Platforms:</strong>
                    </EuiText>
                    <EuiSpacer size="xs" />
                    <EuiFlexGroup gutterSize="xs" wrap>
                      {mal.platforms.map((platform) => (
                        <EuiFlexItem grow={false} key={platform}>
                          <EuiBadge>{platform}</EuiBadge>
                        </EuiFlexItem>
                      ))}
                    </EuiFlexGroup>

                    <EuiSpacer size="m" />

                    <EuiText size="xs">
                      <strong>Techniques Used:</strong>
                    </EuiText>
                    <EuiSpacer size="xs" />
                    <EuiFlexGroup gutterSize="xs" wrap>
                      {mal.techniques_used.map((tech) => (
                        <EuiFlexItem grow={false} key={tech}>
                          <EuiBadge color="hollow">{tech}</EuiBadge>
                        </EuiFlexItem>
                      ))}
                    </EuiFlexGroup>
                  </EuiCard>
                </EuiFlexItem>
              ))}
            </EuiFlexGroup>
          </EuiFlexItem>
        </EuiFlexGroup>
      )
    }
  ];

  return (
    <EuiPage paddingSize="none">
      <EuiPageBody panelled>
        {/* Page Header */}
        <EuiPageHeader
          pageTitle={
            <EuiFlexGroup gutterSize="s" alignItems="center" responsive={false}>
              <EuiFlexItem grow={false}>
                <Database style={{ width: '28px', height: '28px', color: '#3b82f6' }} />
              </EuiFlexItem>
              <EuiFlexItem>CTI Datasets</EuiFlexItem>
            </EuiFlexGroup>
          }
          description="Cyber Threat Intelligence datasets from MITRE ATT&CK, CVE, CISA KEV, and other sources"
          rightSideItems={[
            <EuiButton
              iconType="refresh"
              onClick={loadData}
              color="primary"
              size="s"
            >
              Refresh Data
            </EuiButton>
          ]}
        />

        <EuiSpacer size="l" />

        {/* Error Message */}
        {error && (
          <>
            <EuiCallOut title="Error Loading Data" color="danger" iconType="warning">
              {error}
            </EuiCallOut>
            <EuiSpacer size="l" />
          </>
        )}

        {/* Status Overview Cards */}
        {status && (
          <>
            <EuiFlexGroup gutterSize="l" wrap>
              <EuiFlexItem style={{ minWidth: '250px' }}>
                <EuiPanel hasBorder paddingSize="l">
                  <EuiFlexGroup alignItems="center" gutterSize="s" responsive={false}>
                    <EuiFlexItem grow={false}>
                      <div
                        style={{
                          width: '48px',
                          height: '48px',
                          background: 'linear-gradient(135deg, rgba(139, 92, 246, 0.2), rgba(139, 92, 246, 0.1))',
                          borderRadius: '12px',
                          display: 'flex',
                          alignItems: 'center',
                          justifyContent: 'center',
                          border: '1px solid rgba(139, 92, 246, 0.4)'
                        }}
                      >
                        <Shield style={{ width: '24px', height: '24px', color: '#8b5cf6' }} />
                      </div>
                    </EuiFlexItem>
                    <EuiFlexItem>
                      <EuiText size="xs" color="subdued">
                        MITRE ATT&CK
                      </EuiText>
                      <EuiTitle size="m">
                        <h3>{status.datasets.techniques}</h3>
                      </EuiTitle>
                      <EuiText size="xs" color="subdued">
                        Techniques
                      </EuiText>
                    </EuiFlexItem>
                  </EuiFlexGroup>
                  <EuiSpacer size="s" />
                  <EuiBadge color="hollow">{status.datasets.tactics} Tactics</EuiBadge>
                </EuiPanel>
              </EuiFlexItem>

              <EuiFlexItem style={{ minWidth: '250px' }}>
                <EuiPanel hasBorder paddingSize="l">
                  <EuiFlexGroup alignItems="center" gutterSize="s" responsive={false}>
                    <EuiFlexItem grow={false}>
                      <div
                        style={{
                          width: '48px',
                          height: '48px',
                          background: 'linear-gradient(135deg, rgba(245, 167, 0, 0.2), rgba(245, 167, 0, 0.1))',
                          borderRadius: '12px',
                          display: 'flex',
                          alignItems: 'center',
                          justifyContent: 'center',
                          border: '1px solid rgba(245, 167, 0, 0.4)'
                        }}
                      >
                        <Bug style={{ width: '24px', height: '24px', color: '#f59e0b' }} />
                      </div>
                    </EuiFlexItem>
                    <EuiFlexItem>
                      <EuiText size="xs" color="subdued">
                        Vulnerabilities
                      </EuiText>
                      <EuiTitle size="m">
                        <h3>{status.datasets.cve.toLocaleString()}</h3>
                      </EuiTitle>
                      <EuiText size="xs" color="subdued">
                        Total CVEs
                      </EuiText>
                    </EuiFlexItem>
                  </EuiFlexGroup>
                  <EuiSpacer size="s" />
                  <EuiBadge color="danger">{status.datasets.kev} KEV</EuiBadge>
                </EuiPanel>
              </EuiFlexItem>

              <EuiFlexItem style={{ minWidth: '250px' }}>
                <EuiPanel hasBorder paddingSize="l">
                  <EuiFlexGroup alignItems="center" gutterSize="s" responsive={false}>
                    <EuiFlexItem grow={false}>
                      <div
                        style={{
                          width: '48px',
                          height: '48px',
                          background: 'linear-gradient(135deg, rgba(59, 130, 246, 0.2), rgba(59, 130, 246, 0.1))',
                          borderRadius: '12px',
                          display: 'flex',
                          alignItems: 'center',
                          justifyContent: 'center',
                          border: '1px solid rgba(59, 130, 246, 0.4)'
                        }}
                      >
                        <Target style={{ width: '24px', height: '24px', color: '#3b82f6' }} />
                      </div>
                    </EuiFlexItem>
                    <EuiFlexItem>
                      <EuiText size="xs" color="subdued">
                        Attack Patterns
                      </EuiText>
                      <EuiTitle size="m">
                        <h3>{status.datasets.capec}</h3>
                      </EuiTitle>
                      <EuiText size="xs" color="subdued">
                        CAPEC Patterns
                      </EuiText>
                    </EuiFlexItem>
                  </EuiFlexGroup>
                  <EuiSpacer size="s" />
                  <EuiBadge color="hollow">{status.datasets.cwe} Weaknesses</EuiBadge>
                </EuiPanel>
              </EuiFlexItem>

              <EuiFlexItem style={{ minWidth: '250px' }}>
                <EuiPanel hasBorder paddingSize="l">
                  <EuiFlexGroup alignItems="center" gutterSize="s" responsive={false}>
                    <EuiFlexItem grow={false}>
                      <div
                        style={{
                          width: '48px',
                          height: '48px',
                          background: 'linear-gradient(135deg, rgba(239, 68, 68, 0.2), rgba(239, 68, 68, 0.1))',
                          borderRadius: '12px',
                          display: 'flex',
                          alignItems: 'center',
                          justifyContent: 'center',
                          border: '1px solid rgba(239, 68, 68, 0.4)'
                        }}
                      >
                        <Users style={{ width: '24px', height: '24px', color: '#ef4444' }} />
                      </div>
                    </EuiFlexItem>
                    <EuiFlexItem>
                      <EuiText size="xs" color="subdued">
                        Threat Actors
                      </EuiText>
                      <EuiTitle size="m">
                        <h3>{status.datasets.campaigns}</h3>
                      </EuiTitle>
                      <EuiText size="xs" color="subdued">
                        Campaigns
                      </EuiText>
                    </EuiFlexItem>
                  </EuiFlexGroup>
                  <EuiSpacer size="s" />
                  <EuiBadge color="warning">{status.datasets.malware} Malware</EuiBadge>
                </EuiPanel>
              </EuiFlexItem>
            </EuiFlexGroup>

            <EuiSpacer size="l" />
          </>
        )}

        {/* Sync Status */}
        {syncStatus && (
          <>
            <EuiPanel hasBorder>
              <EuiFlexGroup alignItems="center" gutterSize="s" responsive={false}>
                <EuiFlexItem grow={false}>
                  <RefreshCw style={{ width: '20px', height: '20px', color: '#3b82f6' }} />
                </EuiFlexItem>
                <EuiFlexItem>
                  <EuiTitle size="xs">
                    <h4>Dataset Synchronization Status</h4>
                  </EuiTitle>
                </EuiFlexItem>
              </EuiFlexGroup>

              <EuiSpacer size="m" />

              <EuiFlexGroup gutterSize="l" wrap>
                {Object.entries(syncStatus).map(([dataset, info]) => (
                  <EuiFlexItem key={dataset} style={{ minWidth: '200px' }}>
                    <EuiFlexGroup
                      direction="column"
                      gutterSize="s"
                      style={{
                        padding: '12px',
                        borderRadius: '8px',
                        backgroundColor: 'rgba(30, 41, 59, 0.5)'
                      }}
                    >
                      <EuiFlexItem>
                        <EuiFlexGroup justifyContent="spaceBetween" alignItems="center" gutterSize="s">
                          <EuiFlexItem>
                            <EuiText size="xs">
                              <strong>{dataset.replace('_', ' ').toUpperCase()}</strong>
                            </EuiText>
                          </EuiFlexItem>
                          <EuiFlexItem grow={false}>
                            <EuiBadge color={getSyncStatusColor(info.status)}>
                              {info.status}
                            </EuiBadge>
                          </EuiFlexItem>
                        </EuiFlexGroup>
                      </EuiFlexItem>

                      {info.status === 'syncing' && (
                        <EuiFlexItem>
                          <EuiProgress
                            value={info.progress || 0}
                            max={100}
                            size="s"
                            color="primary"
                          />
                          <EuiSpacer size="xs" />
                          <EuiText size="xs" color="subdued">
                            {info.records_processed?.toLocaleString()} /{' '}
                            {info.total_records?.toLocaleString()}
                          </EuiText>
                        </EuiFlexItem>
                      )}

                      {info.last_sync && (
                        <EuiFlexItem>
                          <EuiText size="xs" color="subdued">
                            Last: {new Date(info.last_sync).toLocaleString()}
                          </EuiText>
                        </EuiFlexItem>
                      )}
                    </EuiFlexGroup>
                  </EuiFlexItem>
                ))}
              </EuiFlexGroup>
            </EuiPanel>

            <EuiSpacer size="l" />
          </>
        )}

        {/* Tabs for Different Datasets */}
        <EuiTabbedContent
          tabs={tabs}
          selectedTab={tabs.find((tab) => tab.id === selectedTabId)}
          onTabClick={(tab) => setSelectedTabId(tab.id)}
        />
      </EuiPageBody>
    </EuiPage>
  );
}

export default CTIDatasets;
