import React, { useState, useEffect } from 'react';
import {
  EuiPage,
  EuiPageBody,
  EuiPageHeader,
  EuiBasicTable,
  EuiPanel,
  EuiButton,
  EuiButtonIcon,
  EuiFieldSearch,
  EuiSelect,
  EuiBadge,
  EuiSpacer,
  EuiFlexGroup,
  EuiFlexItem,
  EuiStat,
  EuiHealth,
  EuiText,
  EuiCallOut,
  EuiConfirmModal,
  EuiLoadingSpinner
} from '@elastic/eui';
import axios from 'axios';
import toast from 'react-hot-toast';
import { Shield, AlertTriangle } from 'lucide-react';

// API Base URL - MUST be configured via environment variable for production
const RESPONSE_BACKEND_URL = process.env.REACT_APP_API_BASE_URL || process.env.REACT_APP_RESPONSE_BACKEND_URL;

const MuteManagement = () => {
  const [rules, setRules] = useState([]);
  const [loading, setLoading] = useState(true);
  const [selectedRules, setSelectedRules] = useState([]);
  const [stats, setStats] = useState({});
  const [searchTerm, setSearchTerm] = useState('');
  const [filterActive, setFilterActive] = useState('active');
  const [filterClassification, setFilterClassification] = useState('all');
  const [expandedRows, setExpandedRows] = useState({});
  const [deleteModalVisible, setDeleteModalVisible] = useState(false);
  const [rulesToDelete, setRulesToDelete] = useState([]);

  useEffect(() => {
    fetchRules();
    fetchStats();
    // Refresh every 30 seconds
    const interval = setInterval(() => {
      fetchRules();
      fetchStats();
    }, 30000);
    return () => clearInterval(interval);
  }, [filterActive]);

  const fetchRules = async () => {
    try {
      setLoading(true);
      const response = await axios.get(`${RESPONSE_BACKEND_URL}/api/mute/rules`, {
        params: { active_only: filterActive === 'active' }
      });

      if (response.data.success) {
        setRules(response.data.data.rules || []);
      }
    } catch (error) {
      console.error('Failed to fetch mute rules:', error);
      toast.error('Failed to fetch mute rules');
    } finally {
      setLoading(false);
    }
  };

  const fetchStats = async () => {
    try {
      const response = await axios.get(`${RESPONSE_BACKEND_URL}/api/mute/rules/stats`);
      if (response.data.success) {
        setStats(response.data.data);
      }
    } catch (error) {
      console.error('Failed to fetch stats:', error);
    }
  };

  const handleDeleteRule = async (ruleId) => {
    try {
      const analyst = localStorage.getItem('username') || 'admin';
      const response = await axios.delete(`${RESPONSE_BACKEND_URL}/api/mute/rules/${ruleId}`, {
        params: { analyst }
      });

      if (response.data.success) {
        toast.success('Mute rule deleted successfully');
        fetchRules();
        fetchStats();
        setSelectedRules(selectedRules.filter(id => id !== ruleId));
      }
    } catch (error) {
      console.error('Failed to delete rule:', error);
      toast.error(`Failed to delete rule: ${error.response?.data?.error || error.message}`);
    }
  };

  const handleBulkDelete = async () => {
    try {
      const analyst = localStorage.getItem('username') || 'admin';
      const response = await axios.post(`${RESPONSE_BACKEND_URL}/api/mute/rules/bulk-delete`, {
        rule_ids: rulesToDelete,
        analyst: analyst
      });

      if (response.data.success) {
        toast.success(`Deleted ${response.data.data.deleted_count} mute rules`);
        setSelectedRules([]);
        setRulesToDelete([]);
        setDeleteModalVisible(false);
        fetchRules();
        fetchStats();
      }
    } catch (error) {
      console.error('Failed to bulk delete:', error);
      toast.error(`Failed to delete rules: ${error.response?.data?.error || error.message}`);
    }
  };

  const confirmBulkDelete = () => {
    setRulesToDelete(selectedRules);
    setDeleteModalVisible(true);
  };

  const toggleRowExpansion = (ruleId) => {
    setExpandedRows(prev => ({
      ...prev,
      [ruleId]: !prev[ruleId]
    }));
  };

  const getClassificationColor = (classification) => {
    const colors = {
      'false_positive': 'warning',
      'benign_positive': 'success',
      'noisy_signature': 'primary',
      'maintenance': 'accent',
      'business_approved': 'default'
    };
    return colors[classification] || 'default';
  };

  const getApprovalStatusColor = (status) => {
    const colors = {
      'auto_approved': 'success',
      'approved': 'success',
      'pending_approval': 'warning',
      'rejected': 'danger'
    };
    return colors[status] || 'subdued';
  };

  const formatConditions = (conditions) => {
    if (!conditions) return 'N/A';
    const keys = Object.keys(conditions);
    if (keys.length === 0) return 'None';

    return (
      <div style={{ display: 'flex', flexWrap: 'wrap', gap: '4px' }}>
        {keys.slice(0, 3).map(key => (
          <EuiBadge key={key} color="hollow" style={{ fontSize: '11px' }}>
            {key.replace(/_/g, ' ')}: {String(conditions[key]).substring(0, 20)}
            {String(conditions[key]).length > 20 ? '...' : ''}
          </EuiBadge>
        ))}
        {keys.length > 3 && (
          <EuiBadge color="subdued" style={{ fontSize: '11px' }}>
            +{keys.length - 3} more
          </EuiBadge>
        )}
      </div>
    );
  };

  const formatExpiration = (expiresAt) => {
    if (!expiresAt) {
      return <EuiBadge color="success">Permanent</EuiBadge>;
    }

    const expiresDate = new Date(expiresAt);
    const now = new Date();
    const hoursUntil = (expiresDate - now) / (1000 * 60 * 60);

    if (hoursUntil < 0) {
      return <EuiBadge color="danger" iconType="alert">Expired</EuiBadge>;
    }
    if (hoursUntil < 24) {
      return <EuiBadge color="warning" iconType="clock">Expires in {Math.round(hoursUntil)}h</EuiBadge>;
    }

    const daysUntil = Math.round(hoursUntil / 24);
    return <EuiText size="s">{daysUntil} days</EuiText>;
  };

  const renderExpandedRow = (rule) => {
    return (
      <EuiPanel paddingSize="m" color="subdued">
        <EuiFlexGroup direction="column" gutterSize="m">
          <EuiFlexItem>
            <EuiText size="s">
              <strong>Full Conditions:</strong>
            </EuiText>
            <EuiPanel paddingSize="s" hasBorder style={{ marginTop: '8px' }}>
              <pre style={{ fontSize: '12px', margin: 0, whiteSpace: 'pre-wrap' }}>
                {JSON.stringify(rule.conditions, null, 2)}
              </pre>
            </EuiPanel>
          </EuiFlexItem>

          <EuiFlexItem>
            <EuiText size="s">
              <strong>Reason:</strong> {rule.reason}
            </EuiText>
          </EuiFlexItem>

          <EuiFlexItem>
            <EuiFlexGroup gutterSize="l">
              <EuiFlexItem grow={false}>
                <EuiText size="s">
                  <strong>Source Type:</strong> {rule.source_type || 'both'}
                </EuiText>
              </EuiFlexItem>
              <EuiFlexItem grow={false}>
                <EuiText size="s">
                  <strong>Scope:</strong> {rule.scope || 'global'}
                </EuiText>
              </EuiFlexItem>
              <EuiFlexItem grow={false}>
                <EuiText size="s">
                  <strong>Approval Status:</strong>{' '}
                  <EuiBadge color={getApprovalStatusColor(rule.approval_status)}>
                    {rule.approval_status}
                  </EuiBadge>
                </EuiText>
              </EuiFlexItem>
            </EuiFlexGroup>
          </EuiFlexItem>

          {rule.hit_count > 0 && (
            <EuiFlexItem>
              <EuiFlexGroup gutterSize="l">
                <EuiFlexItem grow={false}>
                  <EuiText size="s">
                    <strong>First Match:</strong> {rule.first_matched_at ? new Date(rule.first_matched_at).toLocaleString() : 'Never'}
                  </EuiText>
                </EuiFlexItem>
                <EuiFlexItem grow={false}>
                  <EuiText size="s">
                    <strong>Last Match:</strong> {rule.last_matched_at ? new Date(rule.last_matched_at).toLocaleString() : 'Never'}
                  </EuiText>
                </EuiFlexItem>
              </EuiFlexGroup>
            </EuiFlexItem>
          )}

          {rule.original_alert_id && (
            <EuiFlexItem>
              <EuiText size="s">
                <strong>Original Alert ID:</strong> {rule.original_alert_id}
              </EuiText>
            </EuiFlexItem>
          )}
        </EuiFlexGroup>
      </EuiPanel>
    );
  };

  const columns = [
    {
      field: 'checkbox',
      name: '',
      width: '40px',
      render: (_, rule) => (
        <input
          type="checkbox"
          checked={selectedRules.includes(rule.id)}
          onChange={(e) => {
            e.stopPropagation();
            setSelectedRules(prev =>
              prev.includes(rule.id)
                ? prev.filter(id => id !== rule.id)
                : [...prev, rule.id]
            );
          }}
        />
      )
    },
    {
      field: 'expand',
      name: '',
      width: '40px',
      render: (_, rule) => (
        <EuiButtonIcon
          iconType={expandedRows[rule.id] ? 'arrowDown' : 'arrowRight'}
          aria-label="Expand row"
          onClick={() => toggleRowExpansion(rule.id)}
        />
      )
    },
    {
      field: 'conditions',
      name: 'Conditions',
      width: '280px',
      render: (conditions) => formatConditions(conditions)
    },
    {
      field: 'classification',
      name: 'Classification',
      width: '150px',
      render: (classification) => (
        <EuiBadge color={getClassificationColor(classification)}>
          {classification?.replace(/_/g, ' ') || 'N/A'}
        </EuiBadge>
      )
    },
    {
      field: 'created_by',
      name: 'Created By',
      width: '120px',
      truncateText: true
    },
    {
      field: 'created_at',
      name: 'Created',
      width: '140px',
      render: (created_at) => created_at ? new Date(created_at).toLocaleDateString() : 'N/A'
    },
    {
      field: 'expires_at',
      name: 'Expires',
      width: '130px',
      render: (expires_at) => formatExpiration(expires_at)
    },
    {
      field: 'hit_count',
      name: 'Hits',
      width: '80px',
      align: 'center',
      render: (hit_count) => {
        const count = hit_count || 0;
        return (
          <EuiBadge color={count === 0 ? 'subdued' : count > 100 ? 'success' : 'primary'}>
            {count}
          </EuiBadge>
        );
      }
    },
    {
      field: 'active',
      name: 'Status',
      width: '90px',
      render: (active) => (
        <EuiHealth color={active ? 'success' : 'subdued'}>
          {active ? 'Active' : 'Inactive'}
        </EuiHealth>
      )
    },
    {
      name: 'Actions',
      width: '80px',
      render: (rule) => (
        <EuiButtonIcon
          iconType="trash"
          color="danger"
          aria-label="Delete rule"
          onClick={(e) => {
            e.stopPropagation();
            if (window.confirm(`Delete mute rule created by ${rule.created_by}?`)) {
              handleDeleteRule(rule.id);
            }
          }}
        />
      )
    }
  ];

  const filteredRules = rules.filter(rule => {
    const matchesSearch =
      rule.reason?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      rule.created_by?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      JSON.stringify(rule.conditions).toLowerCase().includes(searchTerm.toLowerCase());

    const matchesClassification =
      filterClassification === 'all' || rule.classification === filterClassification;

    return matchesSearch && matchesClassification;
  });

  // Create expanded row map with actual content
  const expandedRowMap = {};
  filteredRules.forEach(rule => {
    if (expandedRows[rule.id]) {
      expandedRowMap[rule.id] = renderExpandedRow(rule);
    }
  });

  return (
    <EuiPage paddingSize="l">
      <EuiPageBody>
        <EuiPageHeader
          pageTitle={
            <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
              <Shield size={32} style={{ color: '#006BB4' }} />
              Mute Rules Management
            </div>
          }
          description="View and manage all mute rules across Wazuh and Suricata alerts"
          rightSideItems={[
            <EuiButton
              key="refresh"
              onClick={() => {
                fetchRules();
                fetchStats();
              }}
              iconType="refresh"
              isLoading={loading}
            >
              Refresh
            </EuiButton>
          ]}
        />

        <EuiSpacer size="l" />

        {/* Statistics Cards */}
        <EuiFlexGroup gutterSize="l">
          <EuiFlexItem>
            <EuiPanel hasBorder>
              <EuiStat
                title={stats.active_rules || 0}
                description="Active Rules"
                titleColor="primary"
                titleSize="l"
                isLoading={!stats.active_rules && loading}
              />
            </EuiPanel>
          </EuiFlexItem>
          <EuiFlexItem>
            <EuiPanel hasBorder>
              <EuiStat
                title={stats.expiring_soon || 0}
                description="Expiring Soon (<24h)"
                titleColor="warning"
                titleSize="l"
                isLoading={!stats.expiring_soon && loading}
              />
            </EuiPanel>
          </EuiFlexItem>
          <EuiFlexItem>
            <EuiPanel hasBorder>
              <EuiStat
                title={stats.unused_rules || 0}
                description="Unused Rules (0 hits)"
                titleColor="subdued"
                titleSize="l"
                isLoading={!stats.unused_rules && loading}
              />
            </EuiPanel>
          </EuiFlexItem>
          <EuiFlexItem>
            <EuiPanel hasBorder>
              <EuiStat
                title={(stats.total_hits || 0).toLocaleString()}
                description="Total Hits"
                titleColor="success"
                titleSize="l"
                isLoading={!stats.total_hits && loading}
              />
            </EuiPanel>
          </EuiFlexItem>
        </EuiFlexGroup>

        <EuiSpacer size="l" />

        {/* Warning for Unused Rules */}
        {stats.unused_rules > 0 && (
          <>
            <EuiCallOut
              title={`${stats.unused_rules} unused mute rules detected`}
              color="warning"
              iconType="alert"
            >
              <p>
                These rules have never matched any alerts (hit_count = 0). Consider reviewing and deleting them to improve performance.
              </p>
            </EuiCallOut>
            <EuiSpacer size="m" />
          </>
        )}

        {/* Filters and Search */}
        <EuiPanel hasBorder paddingSize="m">
          <EuiFlexGroup gutterSize="m" alignItems="center">
            <EuiFlexItem>
              <EuiFieldSearch
                placeholder="Search by reason, analyst, or conditions..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                fullWidth
                isClearable
              />
            </EuiFlexItem>
            <EuiFlexItem grow={false} style={{ minWidth: '180px' }}>
              <EuiSelect
                options={[
                  { value: 'active', text: 'Active Only' },
                  { value: 'all', text: 'All Rules' }
                ]}
                value={filterActive}
                onChange={(e) => setFilterActive(e.target.value)}
                fullWidth
              />
            </EuiFlexItem>
            <EuiFlexItem grow={false} style={{ minWidth: '200px' }}>
              <EuiSelect
                options={[
                  { value: 'all', text: 'All Classifications' },
                  { value: 'false_positive', text: 'False Positive' },
                  { value: 'benign_positive', text: 'Benign Positive' },
                  { value: 'noisy_signature', text: 'Noisy Signature' },
                  { value: 'maintenance', text: 'Maintenance' },
                  { value: 'business_approved', text: 'Business Approved' }
                ]}
                value={filterClassification}
                onChange={(e) => setFilterClassification(e.target.value)}
                fullWidth
              />
            </EuiFlexItem>
            {selectedRules.length > 0 && (
              <EuiFlexItem grow={false}>
                <EuiButton
                  color="danger"
                  iconType="trash"
                  onClick={confirmBulkDelete}
                >
                  Delete {selectedRules.length} Selected
                </EuiButton>
              </EuiFlexItem>
            )}
          </EuiFlexGroup>
        </EuiPanel>

        <EuiSpacer size="l" />

        {/* Mute Rules Table */}
        <EuiPanel hasBorder paddingSize="none">
          <EuiBasicTable
            items={filteredRules}
            columns={columns}
            loading={loading}
            hasActions={true}
            responsive={true}
            itemId="id"
            itemIdToExpandedRowMap={expandedRowMap}
            noItemsMessage={
              loading ? (
                <div style={{ padding: '40px', textAlign: 'center' }}>
                  <EuiLoadingSpinner size="xl" />
                  <EuiSpacer size="m" />
                  <EuiText color="subdued">Loading mute rules...</EuiText>
                </div>
              ) : (
                <div style={{ padding: '40px', textAlign: 'center' }}>
                  <AlertTriangle size={48} style={{ color: '#98A2B3', marginBottom: '16px' }} />
                  <EuiText color="subdued">
                    <h3>No mute rules found</h3>
                    <p>Create mute rules from the Security Events page by clicking the "Mute" button on any alert.</p>
                  </EuiText>
                </div>
              )
            }
          />
        </EuiPanel>

        {/* Bulk Delete Confirmation Modal */}
        {deleteModalVisible && (
          <EuiConfirmModal
            title="Delete Multiple Mute Rules"
            onCancel={() => {
              setDeleteModalVisible(false);
              setRulesToDelete([]);
            }}
            onConfirm={handleBulkDelete}
            cancelButtonText="Cancel"
            confirmButtonText="Delete"
            buttonColor="danger"
            defaultFocusedButton="cancel"
          >
            <p>
              Are you sure you want to delete <strong>{rulesToDelete.length}</strong> mute rule{rulesToDelete.length > 1 ? 's' : ''}?
            </p>
            <p>This action cannot be undone. The rules will be deactivated and logged in the audit trail.</p>
          </EuiConfirmModal>
        )}
      </EuiPageBody>
    </EuiPage>
  );
};

export default MuteManagement;
