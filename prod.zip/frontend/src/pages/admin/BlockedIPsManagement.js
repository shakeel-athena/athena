import React, { useState, useEffect } from 'react';
import {
  EuiPage,
  EuiPageBody,
  EuiPageHeader,
  EuiBasicTable,
  EuiPanel,
  EuiButton,
  EuiButtonIcon,
  EuiFieldSearch,
  EuiSelect,
  EuiBadge,
  EuiHealth,
  EuiSpacer,
  EuiFlexGroup,
  EuiFlexItem,
  EuiStat,
  EuiCallOut,
  EuiConfirmModal,
  EuiLink,
  EuiText,
  EuiToolTip,
  EuiLoadingSpinner
} from '@elastic/eui';
import toast from 'react-hot-toast';
import { Shield, AlertTriangle, ExternalLink } from 'lucide-react';
import { apiRequest } from '../../services/apiClient';

// API Base URL - MUST be configured via environment variable for production
const RESPONSE_BACKEND_URL = process.env.REACT_APP_API_BASE_URL || process.env.REACT_APP_RESPONSE_BACKEND_URL;

const BlockedIPsManagement = () => {
  const [blockedIPs, setBlockedIPs] = useState([]);
  const [loading, setLoading] = useState(true);
  const [stats, setStats] = useState({});
  const [searchTerm, setSearchTerm] = useState('');
  const [threatTypeFilter, setThreatTypeFilter] = useState('all');
  const [awsStatusFilter, setAwsStatusFilter] = useState('all');
  const [selectedIPs, setSelectedIPs] = useState([]);
  const [expandedRows, setExpandedRows] = useState({});
  const [unblockModalVisible, setUnblockModalVisible] = useState(false);
  const [ipsToUnblock, setIpsToUnblock] = useState([]);
  const [unblockReason, setUnblockReason] = useState('');

  useEffect(() => {
    fetchBlockedIPs();
    fetchStats();
    // Auto-refresh every 30 seconds
    const interval = setInterval(() => {
      fetchBlockedIPs();
      fetchStats();
    }, 30000);
    return () => clearInterval(interval);
  }, [threatTypeFilter, awsStatusFilter]);

  const fetchBlockedIPs = async () => {
    try {
      setLoading(true);
      const params = new URLSearchParams({
        active_only: 'true'
      });

      if (threatTypeFilter !== 'all') {
        params.append('threat_type', threatTypeFilter);
      }

      const url = `${RESPONSE_BACKEND_URL}/api/firewall/blocked-ips?${params.toString()}`;
      // apiRequest automatically extracts the 'data' property, so response is the data array directly
      let ips = await apiRequest(url, { method: 'GET' });

      // Ensure ips is an array
      if (!Array.isArray(ips)) {
        ips = [];
      }

      // Apply AWS status filter
      if (awsStatusFilter !== 'all') {
        if (awsStatusFilter === 'enforced') {
          ips = ips.filter(ip => ip.aws_enforced === true);
        } else if (awsStatusFilter === 'pending') {
          ips = ips.filter(ip => ip.aws_enforced === false && !ip.aws_enforcement_error);
        } else if (awsStatusFilter === 'failed') {
          ips = ips.filter(ip => ip.aws_enforcement_error);
        }
      }

      setBlockedIPs(ips);
    } catch (error) {
      console.error('Failed to fetch blocked IPs:', error);
      toast.error('Failed to fetch blocked IPs');
    } finally {
      setLoading(false);
    }
  };

  const fetchStats = async () => {
    try {
      const url = `${RESPONSE_BACKEND_URL}/api/firewall/blocked-ips/stats`;
      // apiRequest automatically extracts the 'data' property
      const stats = await apiRequest(url, { method: 'GET' });
      setStats(stats || {});
    } catch (error) {
      console.error('Failed to fetch stats:', error);
    }
  };

  const handleUnblockSingle = (ip) => {
    setIpsToUnblock([ip.id]);
    setUnblockReason('');
    setUnblockModalVisible(true);
  };

  const handleBulkUnblock = async () => {
    if (!unblockReason.trim()) {
      toast.error('Please provide a reason for unblocking');
      return;
    }

    try {
      const analyst = localStorage.getItem('username') || 'admin';
      const url = `${RESPONSE_BACKEND_URL}/api/firewall/blocked-ips/bulk-unblock`;
      // apiRequest automatically extracts the 'data' property
      const result = await apiRequest(url, {
        method: 'POST',
        body: JSON.stringify({
          ip_ids: ipsToUnblock,
          analyst: analyst,
          reason: unblockReason
        })
      });

      // If no error was thrown, the operation was successful
      toast.success(`Unblocked ${result.unblocked_count || ipsToUnblock.length} IP addresses`);
      if (result.aws_removal_failed && result.aws_removal_failed > 0) {
        toast.error(`${result.aws_removal_failed} IPs failed AWS removal`);
      }

      setSelectedIPs([]);
      setIpsToUnblock([]);
      setUnblockModalVisible(false);
      setUnblockReason('');
      fetchBlockedIPs();
      fetchStats();
    } catch (error) {
      console.error('Failed to bulk unblock:', error);
      toast.error(`Failed to unblock IPs: ${error.message || 'Unknown error'}`);
    }
  };

  const confirmBulkUnblock = () => {
    setIpsToUnblock(selectedIPs);
    setUnblockReason('');
    setUnblockModalVisible(true);
  };

  const toggleRowExpansion = (ipId) => {
    setExpandedRows(prev => ({
      ...prev,
      [ipId]: !prev[ipId]
    }));
  };

  const getThreatTypeColor = (threatType) => {
    const colors = {
      'malware_c2': 'danger',
      'brute_force': 'warning',
      'port_scan': 'primary',
      'exploit_attempt': 'danger',
      'ddos_source': 'danger',
      'botnet': 'danger',
      'phishing': 'warning',
      'data_exfiltration': 'danger',
      'suspicious_activity': 'accent',
      'other': 'default'
    };
    return colors[threatType] || 'default';
  };

  const getSeverityColor = (severity) => {
    const colors = {
      'Critical': 'danger',
      'High': 'warning',
      'Medium': 'primary',
      'Low': 'default'
    };
    return colors[severity] || 'default';
  };

  const getAwsStatusDisplay = (ip) => {
    // Determine status for both layers
    const nfwEnforced = ip.aws_enforced;
    const wafEnforced = ip.waf_enforced;

    // Both layers successful
    if (nfwEnforced && wafEnforced) {
      return (
        <EuiToolTip content="Blocked at Network Firewall (Layer 3/4) and WAF (Layer 7)">
          <EuiHealth color="success">Both Layers</EuiHealth>
        </EuiToolTip>
      );
    }

    // Only Network Firewall
    if (nfwEnforced && !wafEnforced) {
      const tooltip = ip.waf_error
        ? `Network Firewall only. WAF failed: ${ip.waf_error}`
        : 'Blocked at Network Firewall only';
      return (
        <EuiToolTip content={tooltip}>
          <EuiHealth color="warning">NFW Only</EuiHealth>
        </EuiToolTip>
      );
    }

    // Network Firewall failed
    if (ip.aws_enforcement_error) {
      return (
        <EuiToolTip content={ip.aws_enforcement_error}>
          <EuiHealth color="danger">Failed</EuiHealth>
        </EuiToolTip>
      );
    }

    // Pending
    return <EuiHealth color="warning">Pending</EuiHealth>;
  };

  const renderExpandedRow = (ip) => {
    return (
      <EuiPanel paddingSize="m" color="subdued">
        <EuiFlexGroup direction="column" gutterSize="m">
          <EuiFlexItem>
            <EuiText size="s">
              <strong>Reason:</strong> {ip.reason || 'No reason provided'}
            </EuiText>
          </EuiFlexItem>

          <EuiFlexItem>
            <EuiText size="s">
              <strong>IP CIDR:</strong> {ip.ip_cidr || `${ip.ip_address}/32`}
            </EuiText>
          </EuiFlexItem>

          {ip.notes && (
            <EuiFlexItem>
              <EuiText size="s">
                <strong>Notes:</strong> {ip.notes}
              </EuiText>
            </EuiFlexItem>
          )}

          {/* Dual-Layer Blocking Status */}
          <EuiFlexItem>
            <EuiPanel color="primary" paddingSize="s">
              <EuiText size="s">
                <strong>🛡️ Dual-Layer Blocking Status</strong>
              </EuiText>
              <EuiSpacer size="s" />
              <EuiFlexGroup gutterSize="m" direction="column">
                <EuiFlexItem>
                  <EuiFlexGroup gutterSize="s" alignItems="center">
                    <EuiFlexItem grow={false}>
                      <div style={{ width: '200px' }}>
                        <EuiText size="s">Network Firewall (Layer 3/4):</EuiText>
                      </div>
                    </EuiFlexItem>
                    <EuiFlexItem>
                      {ip.aws_enforced ? (
                        <EuiHealth color="success">Blocked</EuiHealth>
                      ) : (
                        <EuiHealth color="danger">Not Blocked</EuiHealth>
                      )}
                    </EuiFlexItem>
                  </EuiFlexGroup>
                </EuiFlexItem>
                <EuiFlexItem>
                  <EuiFlexGroup gutterSize="s" alignItems="center">
                    <EuiFlexItem grow={false}>
                      <div style={{ width: '200px' }}>
                        <EuiText size="s">WAF (Layer 7):</EuiText>
                      </div>
                    </EuiFlexItem>
                    <EuiFlexItem>
                      {ip.waf_enforced ? (
                        <EuiHealth color="success">Blocked</EuiHealth>
                      ) : ip.waf_error ? (
                        <EuiToolTip content={ip.waf_error}>
                          <EuiHealth color="danger">Failed</EuiHealth>
                        </EuiToolTip>
                      ) : (
                        <EuiHealth color="subdued">Not Blocked</EuiHealth>
                      )}
                    </EuiFlexItem>
                  </EuiFlexGroup>
                </EuiFlexItem>
                {ip.waf_ip_set && (
                  <EuiFlexItem>
                    <EuiText size="xs" color="subdued">
                      <strong>WAF IP Set:</strong> {ip.waf_ip_set}
                    </EuiText>
                  </EuiFlexItem>
                )}
              </EuiFlexGroup>
            </EuiPanel>
          </EuiFlexItem>

          <EuiFlexItem>
            <EuiFlexGroup gutterSize="l">
              {ip.aws_rule_group && (
                <EuiFlexItem>
                  <EuiText size="s">
                    <strong>AWS Rule Group:</strong> {ip.aws_rule_group}
                  </EuiText>
                </EuiFlexItem>
              )}
              {ip.aws_region && (
                <EuiFlexItem>
                  <EuiText size="s">
                    <strong>AWS Region:</strong> {ip.aws_region}
                  </EuiText>
                </EuiFlexItem>
              )}
              {ip.aws_enforced_at && (
                <EuiFlexItem>
                  <EuiText size="s">
                    <strong>AWS Enforced:</strong>{' '}
                    {new Date(ip.aws_enforced_at).toLocaleString()}
                  </EuiText>
                </EuiFlexItem>
              )}
            </EuiFlexGroup>
          </EuiFlexItem>

          {ip.last_seen_in_alert && (
            <EuiFlexItem>
              <EuiText size="s">
                <strong>Last Seen in Alert:</strong>{' '}
                {new Date(ip.last_seen_in_alert).toLocaleString()}
              </EuiText>
            </EuiFlexItem>
          )}

          {ip.aws_enforcement_error && (
            <EuiFlexItem>
              <EuiCallOut title="Network Firewall Enforcement Error" color="danger" iconType="alert" size="s">
                <EuiText size="s">{ip.aws_enforcement_error}</EuiText>
              </EuiCallOut>
            </EuiFlexItem>
          )}

          {ip.waf_error && (
            <EuiFlexItem>
              <EuiCallOut title="WAF Enforcement Error" color="warning" iconType="alert" size="s">
                <EuiText size="s">{ip.waf_error}</EuiText>
                <EuiSpacer size="xs" />
                <EuiText size="xs" color="subdued">
                  Note: IP is still blocked at Network Firewall layer
                </EuiText>
              </EuiCallOut>
            </EuiFlexItem>
          )}

          {ip.expires_at && (
            <EuiFlexItem>
              <EuiText size="s">
                <strong>Expires:</strong> {new Date(ip.expires_at).toLocaleString()}
              </EuiText>
            </EuiFlexItem>
          )}
        </EuiFlexGroup>
      </EuiPanel>
    );
  };

  const columns = [
    {
      field: 'checkbox',
      name: '',
      width: '32px',
      render: (_, ip) => (
        <input
          type="checkbox"
          checked={selectedIPs.includes(ip.id)}
          onChange={(e) => {
            e.stopPropagation();
            setSelectedIPs(prev =>
              prev.includes(ip.id)
                ? prev.filter(id => id !== ip.id)
                : [...prev, ip.id]
            );
          }}
        />
      )
    },
    {
      field: 'expand',
      name: '',
      width: '32px',
      render: (_, ip) => (
        <EuiButtonIcon
          iconType={expandedRows[ip.id] ? 'arrowDown' : 'arrowRight'}
          aria-label="Expand row"
          onClick={() => toggleRowExpansion(ip.id)}
        />
      )
    },
    {
      field: 'ip_address',
      name: 'IP Address',
      width: '135px',
      truncateText: true,
      render: (ip) => (
        <span style={{ fontFamily: 'monospace', fontWeight: 'bold', color: '#ff6b6b' }}>
          {ip}
        </span>
      )
    },
    {
      field: 'threat_type',
      name: 'Threat Type',
      width: '140px',
      truncateText: true,
      render: (type) => (
        <EuiBadge color={getThreatTypeColor(type)}>
          {type?.replace(/_/g, ' ') || 'Unknown'}
        </EuiBadge>
      )
    },
    {
      field: 'alert_source',
      name: 'Source',
      width: '90px',
      render: (source) => (
        source ? (
          <EuiBadge color={source === 'suricata' ? 'primary' : 'accent'}>
            {source}
          </EuiBadge>
        ) : <span style={{ color: '#999' }}>Manual</span>
      )
    },
    {
      field: 'alert_severity',
      name: 'Severity',
      width: '85px',
      render: (severity) => {
        return severity ? (
          <EuiBadge color={getSeverityColor(severity)}>{severity}</EuiBadge>
        ) : <span>-</span>;
      }
    },
    {
      field: 'added_by',
      name: 'Analyst',
      width: '100px',
      truncateText: true
    },
    {
      field: 'added_at',
      name: 'Added',
      width: '95px',
      render: (timestamp) => timestamp ? new Date(timestamp).toLocaleDateString() : '-'
    },
    {
      field: 'aws_enforced',
      name: 'Enforcement',
      width: '130px',
      render: (_, ip) => getAwsStatusDisplay(ip)
    },
    {
      field: 'times_seen_in_alerts',
      name: 'Seen',
      width: '70px',
      align: 'center',
      render: (count) => (
        <EuiBadge color={count > 100 ? 'danger' : count > 10 ? 'warning' : 'default'}>
          {count || 0}
        </EuiBadge>
      )
    },
    {
      field: 'original_alert_id',
      name: 'Alert',
      width: '60px',
      render: (alertId) => {
        if (!alertId) return <span>-</span>;
        return (
          <EuiLink
            href={`/detection/events?alert=${alertId}`}
            target="_blank"
            external
          >
            <ExternalLink size={16} />
          </EuiLink>
        );
      }
    },
    {
      name: 'Actions',
      width: '90px',
      render: (ip) => (
        <EuiButton
          size="s"
          color="primary"
          onClick={(e) => {
            e.stopPropagation();
            handleUnblockSingle(ip);
          }}
        >
          Unblock
        </EuiButton>
      )
    }
  ];

  const filteredIPs = blockedIPs.filter(ip => {
    const matchesSearch =
      ip.ip_address?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      ip.reason?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      ip.added_by?.toLowerCase().includes(searchTerm.toLowerCase());

    return matchesSearch;
  });

  // Create expanded row map with actual content
  const expandedRowMap = {};
  filteredIPs.forEach(ip => {
    if (expandedRows[ip.id]) {
      expandedRowMap[ip.id] = renderExpandedRow(ip);
    }
  });

  return (
    <EuiPage paddingSize="l">
      <EuiPageBody>
        <EuiPageHeader
          pageTitle={
            <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
              <Shield size={32} style={{ color: '#d32f2f' }} />
              Blocked IPs Management
            </div>
          }
          description="View and manage all blocked IP addresses with dual-layer enforcement (Network Firewall + WAF)"
          rightSideItems={[
            <EuiButton
              key="refresh"
              onClick={() => {
                fetchBlockedIPs();
                fetchStats();
              }}
              iconType="refresh"
              isLoading={loading}
            >
              Refresh
            </EuiButton>
          ]}
        />

        <EuiSpacer size="l" />

        {/* Statistics Cards */}
        <EuiFlexGroup gutterSize="l">
          <EuiFlexItem>
            <EuiPanel hasBorder>
              <EuiStat
                title={stats.total_blocked || 0}
                description="Total Blocked IPs"
                titleColor="danger"
                titleSize="l"
                isLoading={!stats.total_blocked && loading}
              />
            </EuiPanel>
          </EuiFlexItem>
          <EuiFlexItem>
            <EuiPanel hasBorder>
              <EuiStat
                title={stats.aws_enforced || 0}
                description="AWS Enforced"
                titleColor="success"
                titleSize="l"
                isLoading={!stats.aws_enforced && loading}
              />
            </EuiPanel>
          </EuiFlexItem>
          <EuiFlexItem>
            <EuiPanel hasBorder>
              <EuiStat
                title={stats.aws_pending || 0}
                description="AWS Pending"
                titleColor="warning"
                titleSize="l"
                isLoading={!stats.aws_pending && loading}
              />
            </EuiPanel>
          </EuiFlexItem>
          <EuiFlexItem>
            <EuiPanel hasBorder>
              <EuiStat
                title={stats.aws_failed || 0}
                description="AWS Failed"
                titleColor="danger"
                titleSize="l"
                isLoading={!stats.aws_failed && loading}
              />
            </EuiPanel>
          </EuiFlexItem>
        </EuiFlexGroup>

        <EuiSpacer size="l" />

        {/* Warning for AWS Failed */}
        {stats.aws_failed > 0 && (
          <>
            <EuiCallOut
              title={`${stats.aws_failed} IPs failed AWS enforcement`}
              color="danger"
              iconType="alert"
            >
              <p>
                These IPs are blocked in the database but NOT enforced in AWS Network Firewall.
                Check the error details in expandable rows.
              </p>
            </EuiCallOut>
            <EuiSpacer size="m" />
          </>
        )}

        {/* Filters */}
        <EuiPanel hasBorder paddingSize="m">
          <EuiFlexGroup gutterSize="m" alignItems="center">
            <EuiFlexItem>
              <EuiFieldSearch
                placeholder="Search by IP address, reason, or analyst..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                fullWidth
                isClearable
              />
            </EuiFlexItem>
            <EuiFlexItem grow={false} style={{ minWidth: '200px' }}>
              <EuiSelect
                options={[
                  { value: 'all', text: 'All Threat Types' },
                  { value: 'malware_c2', text: 'Malware C2' },
                  { value: 'brute_force', text: 'Brute Force' },
                  { value: 'port_scan', text: 'Port Scan' },
                  { value: 'exploit_attempt', text: 'Exploit Attempt' },
                  { value: 'ddos_source', text: 'DDoS Source' },
                  { value: 'botnet', text: 'Botnet' },
                  { value: 'phishing', text: 'Phishing' },
                  { value: 'data_exfiltration', text: 'Data Exfiltration' },
                  { value: 'suspicious_activity', text: 'Suspicious Activity' },
                  { value: 'other', text: 'Other' }
                ]}
                value={threatTypeFilter}
                onChange={(e) => setThreatTypeFilter(e.target.value)}
                fullWidth
              />
            </EuiFlexItem>
            <EuiFlexItem grow={false} style={{ minWidth: '180px' }}>
              <EuiSelect
                options={[
                  { value: 'all', text: 'All AWS Status' },
                  { value: 'enforced', text: 'Enforced' },
                  { value: 'pending', text: 'Pending' },
                  { value: 'failed', text: 'Failed' }
                ]}
                value={awsStatusFilter}
                onChange={(e) => setAwsStatusFilter(e.target.value)}
                fullWidth
              />
            </EuiFlexItem>
            {selectedIPs.length > 0 && (
              <EuiFlexItem grow={false}>
                <EuiButton
                  color="primary"
                  iconType="trash"
                  onClick={confirmBulkUnblock}
                >
                  Unblock {selectedIPs.length} Selected
                </EuiButton>
              </EuiFlexItem>
            )}
          </EuiFlexGroup>
        </EuiPanel>

        <EuiSpacer size="l" />

        {/* Blocked IPs Table */}
        <EuiPanel hasBorder paddingSize="none">
          <EuiBasicTable
            items={filteredIPs}
            columns={columns}
            loading={loading}
            hasActions={true}
            responsive={true}
            itemId="id"
            itemIdToExpandedRowMap={expandedRowMap}
            noItemsMessage={
              loading ? (
                <div style={{ padding: '40px', textAlign: 'center' }}>
                  <EuiLoadingSpinner size="xl" />
                  <EuiSpacer size="m" />
                  <EuiText color="subdued">Loading blocked IPs...</EuiText>
                </div>
              ) : (
                <div style={{ padding: '40px', textAlign: 'center' }}>
                  <AlertTriangle size={48} style={{ color: '#98A2B3', marginBottom: '16px' }} />
                  <EuiText color="subdued">
                    <h3>No blocked IPs found</h3>
                    <p>Block IPs from the Security Events page by clicking the "Block IP" button on any alert.</p>
                  </EuiText>
                </div>
              )
            }
          />
        </EuiPanel>

        {/* Unblock Confirmation Modal */}
        {unblockModalVisible && (
          <EuiConfirmModal
            title="Unblock IP Addresses"
            onCancel={() => {
              setUnblockModalVisible(false);
              setIpsToUnblock([]);
              setUnblockReason('');
            }}
            onConfirm={handleBulkUnblock}
            cancelButtonText="Cancel"
            confirmButtonText="Unblock"
            buttonColor="primary"
            defaultFocusedButton="cancel"
          >
            <EuiText>
              <p>
                Are you sure you want to unblock <strong>{ipsToUnblock.length}</strong> IP address{ipsToUnblock.length > 1 ? 'es' : ''}?
              </p>
              <p>This will remove the IP(s) from AWS Network Firewall BLOCK_NET list.</p>
            </EuiText>

            <EuiSpacer size="m" />

            <div>
              <label style={{
                display: 'block',
                marginBottom: '8px',
                fontWeight: '500',
                fontSize: '14px'
              }}>
                Reason for unblocking: <span style={{ color: '#d32f2f' }}>*</span>
              </label>
              <textarea
                value={unblockReason}
                onChange={(e) => setUnblockReason(e.target.value)}
                required
                rows={3}
                placeholder="Why are you unblocking these IPs? (e.g., False positive, Internal scanner, etc.)"
                style={{
                  width: '100%',
                  padding: '10px',
                  border: '1px solid #ccc',
                  borderRadius: '4px',
                  resize: 'vertical',
                  fontSize: '14px',
                  fontFamily: 'inherit'
                }}
              />
            </div>
          </EuiConfirmModal>
        )}
      </EuiPageBody>
    </EuiPage>
  );
};

export default BlockedIPsManagement;
