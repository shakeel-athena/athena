import { useState, useEffect } from 'react';
import {
  EuiPage,
  EuiPageBody,
  EuiPageHeader,
  EuiPanel,
  EuiFlexGroup,
  EuiFlexItem,
  EuiText,
  EuiTitle,
  EuiBadge,
  EuiButton,
  EuiButtonIcon,
  EuiFieldSearch,
  EuiModal,
  EuiModalHeader,
  EuiModalHeaderTitle,
  EuiModalBody,
  EuiModalFooter,
  EuiForm,
  EuiFormRow,
  EuiFieldText,
  EuiFieldPassword,
  EuiSwitch,
  EuiCheckboxGroup,
  EuiSpacer,
  EuiLoadingSpinner,
  EuiEmptyPrompt,
  EuiCallOut,
  EuiIcon
} from '@elastic/eui';
import { Users, UserPlus, Shield, Trash2, AlertTriangle } from 'lucide-react';
import {
  getUsers,
  getUserRoles,
  assignRolesToUser,
  removeRoleFromUser,
  toggleUserAdmin,
  getRoles,
  createUser,
  deleteUser,
  resetUserPassword,
  toggleUserStatus
} from '../../services/rbacApi';
import { toast } from 'react-hot-toast';

const UserManagement = () => {
  const [users, setUsers] = useState([]);
  const [roles, setRoles] = useState([]);
  const [loading, setLoading] = useState(true);
  const [selectedUser, setSelectedUser] = useState(null);
  const [userRoles, setUserRoles] = useState([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [showRoleModal, setShowRoleModal] = useState(false);
  const [selectedRoles, setSelectedRoles] = useState([]);
  const [actionLoading, setActionLoading] = useState(false);

  // Create User Modal State
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [newUser, setNewUser] = useState({
    username: '',
    email: '',
    first_name: '',
    last_name: '',
    password: '',
    is_admin: false,
    role_ids: []
  });
  const [formErrors, setFormErrors] = useState({});

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    try {
      setLoading(true);
      const [usersData, rolesData] = await Promise.all([
        getUsers(),
        getRoles()
      ]);
      setUsers(usersData.users || []);
      setRoles(rolesData.roles || []);
    } catch (err) {
      toast.error(`Failed to load data: ${err.message}`);
    } finally {
      setLoading(false);
    }
  };

  const handleSelectUser = async (user) => {
    try {
      setSelectedUser(user);
      const rolesData = await getUserRoles(user.id);
      setUserRoles(rolesData.roles || []);
      setSelectedRoles(rolesData.roles?.map(r => r.id) || []);
    } catch (err) {
      toast.error(`Failed to load user roles: ${err.message}`);
    }
  };

  const handleToggleAdmin = async (user) => {
    try {
      setActionLoading(true);
      await toggleUserAdmin(user.id, !user.is_admin);
      toast.success(`${user.username} is now ${!user.is_admin ? 'an admin' : 'a regular user'}`);
      await loadData();
      if (selectedUser?.id === user.id) {
        handleSelectUser({ ...user, is_admin: !user.is_admin });
      }
    } catch (err) {
      toast.error(`Failed to toggle admin status: ${err.message}`);
    } finally {
      setActionLoading(false);
    }
  };

  const handleDeleteUser = async (user) => {
    const confirmed = window.confirm(
      `Are you sure you want to delete user "${user.username}"?\n\nThis will:\n- Remove the user from Keycloak\n- Remove the user from the database\n- Remove all role assignments\n\nThis action CANNOT be undone!`
    );

    if (!confirmed) return;

    try {
      setActionLoading(true);
      await deleteUser(user.id);
      toast.success(`User "${user.username}" deleted successfully`);
      await loadData();

      if (selectedUser?.id === user.id) {
        setSelectedUser(null);
        setUserRoles([]);
      }
    } catch (err) {
      toast.error(`Failed to delete user: ${err.message}`);
    } finally {
      setActionLoading(false);
    }
  };

  const handleOpenRoleModal = () => {
    setShowRoleModal(true);
  };

  const handleCloseRoleModal = () => {
    setShowRoleModal(false);
  };

  const handleToggleRole = (roleId) => {
    setSelectedRoles(prev =>
      prev.includes(roleId)
        ? prev.filter(id => id !== roleId)
        : [...prev, roleId]
    );
  };

  const handleSaveRoles = async () => {
    if (!selectedUser) return;

    try {
      setActionLoading(true);
      const currentRoleIds = userRoles.map(r => r.id);
      const toAdd = selectedRoles.filter(id => !currentRoleIds.includes(id));
      const toRemove = currentRoleIds.filter(id => !selectedRoles.includes(id));

      if (toAdd.length > 0) {
        await assignRolesToUser(selectedUser.id, toAdd);
      }

      for (const roleId of toRemove) {
        await removeRoleFromUser(selectedUser.id, roleId);
      }

      toast.success('Roles updated successfully');
      const rolesData = await getUserRoles(selectedUser.id);
      setUserRoles(rolesData.roles || []);
      setShowRoleModal(false);
    } catch (err) {
      toast.error(`Failed to update roles: ${err.message}`);
    } finally {
      setActionLoading(false);
    }
  };

  const handleRemoveRole = async (roleId) => {
    if (!selectedUser) return;
    try {
      setActionLoading(true);
      await removeRoleFromUser(selectedUser.id, roleId);
      toast.success('Role removed');
      handleSelectUser(selectedUser);
    } catch (err) {
      toast.error(`Failed to remove role: ${err.message}`);
    } finally {
      setActionLoading(false);
    }
  };

  const handleOpenCreateModal = () => {
    setShowCreateModal(true);
    setNewUser({
      username: '',
      email: '',
      first_name: '',
      last_name: '',
      password: '',
      is_admin: false,
      role_ids: []
    });
    setFormErrors({});
  };

  const handleCloseCreateModal = () => {
    setShowCreateModal(false);
  };

  const validateForm = () => {
    const errors = {};

    if (!newUser.username.trim()) {
      errors.username = 'Username is required';
    } else if (!/^[a-zA-Z0-9._-]+$/.test(newUser.username)) {
      errors.username = 'Username can only contain letters, numbers, dots, hyphens, and underscores';
    }

    if (!newUser.email.trim()) {
      errors.email = 'Email is required';
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(newUser.email)) {
      errors.email = 'Invalid email format';
    }

    if (!newUser.first_name.trim()) {
      errors.first_name = 'First name is required';
    }

    if (!newUser.last_name.trim()) {
      errors.last_name = 'Last name is required';
    }

    if (!newUser.password) {
      errors.password = 'Password is required';
    } else if (newUser.password.length < 8) {
      errors.password = 'Password must be at least 8 characters';
    } else if (!/[A-Z]/.test(newUser.password)) {
      errors.password = 'Password must contain at least one uppercase letter';
    } else if (!/[a-z]/.test(newUser.password)) {
      errors.password = 'Password must contain at least one lowercase letter';
    } else if (!/[0-9]/.test(newUser.password)) {
      errors.password = 'Password must contain at least one number';
    }

    setFormErrors(errors);
    return Object.keys(errors).length === 0;
  };

  const handleCreateUser = async () => {
    if (!validateForm()) {
      toast.error('Please fix form errors');
      return;
    }

    try {
      setActionLoading(true);
      const result = await createUser(newUser);
      toast.success(`User ${result.user.username} created successfully!`);
      await loadData();
      handleCloseCreateModal();
    } catch (err) {
      toast.error(`Failed to create user: ${err.message}`);
    } finally {
      setActionLoading(false);
    }
  };

  const handleToggleNewUserRole = (roleId) => {
    setNewUser(prev => ({
      ...prev,
      role_ids: prev.role_ids.includes(roleId)
        ? prev.role_ids.filter(id => id !== roleId)
        : [...prev.role_ids, roleId]
    }));
  };

  const filteredUsers = users.filter(user =>
    user.username?.toLowerCase().includes(searchTerm.toLowerCase()) ||
    user.email?.toLowerCase().includes(searchTerm.toLowerCase()) ||
    user.full_name?.toLowerCase().includes(searchTerm.toLowerCase())
  );

  if (loading) {
    return (
      <EuiFlexGroup alignItems="center" justifyContent="center" style={{ minHeight: '400px' }}>
        <EuiFlexItem grow={false}>
          <EuiLoadingSpinner size="xl" />
          <EuiSpacer size="m" />
          <EuiText color="subdued">Loading users...</EuiText>
        </EuiFlexItem>
      </EuiFlexGroup>
    );
  }

  return (
    <EuiPage paddingSize="none">
      <EuiPageBody>
        {/* Header */}
        <EuiPageHeader
          pageTitle={
            <EuiFlexGroup alignItems="center" gutterSize="s">
              <EuiFlexItem grow={false}>
                <Users style={{ width: '32px', height: '32px', color: '#3b82f6' }} />
              </EuiFlexItem>
              <EuiFlexItem>
                <EuiTitle size="l">
                  <h1>User Management</h1>
                </EuiTitle>
              </EuiFlexItem>
            </EuiFlexGroup>
          }
          description="Manage user roles and permissions"
          rightSideItems={[
            <EuiButton
              key="create"
              fill
              iconType={UserPlus}
              onClick={handleOpenCreateModal}
            >
              Create User
            </EuiButton>
          ]}
        />

        <EuiSpacer size="l" />

        {/* Content */}
        <EuiFlexGroup gutterSize="l">
          {/* User List Panel */}
          <EuiFlexItem grow={1} style={{ maxWidth: '400px' }}>
            <EuiPanel hasBorder paddingSize="none">
              <EuiPanel color="subdued" paddingSize="m">
                <EuiFieldSearch
                  placeholder="Search users..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  fullWidth
                />
                <EuiSpacer size="s" />
                <EuiText size="s" color="subdued">
                  {filteredUsers.length} user{filteredUsers.length !== 1 ? 's' : ''}
                </EuiText>
              </EuiPanel>

              <div style={{ maxHeight: '600px', overflowY: 'auto' }}>
                {filteredUsers.map(user => (
                  <EuiPanel
                    key={user.id}
                    hasShadow={false}
                    color={selectedUser?.id === user.id ? 'primary' : 'transparent'}
                    paddingSize="m"
                    style={{ cursor: 'pointer', borderLeft: selectedUser?.id === user.id ? '4px solid #3b82f6' : 'none' }}
                    onClick={() => handleSelectUser(user)}
                  >
                    <EuiFlexGroup alignItems="center" justifyContent="spaceBetween" gutterSize="s">
                      <EuiFlexItem>
                        <EuiFlexGroup alignItems="center" gutterSize="s" wrap>
                          <EuiFlexItem grow={false}>
                            <EuiText size="s">
                              <strong>{user.username}</strong>
                            </EuiText>
                          </EuiFlexItem>
                          {user.is_admin && (
                            <EuiFlexItem grow={false}>
                              <EuiBadge color="danger">Admin</EuiBadge>
                            </EuiFlexItem>
                          )}
                        </EuiFlexGroup>
                        <EuiText size="xs" color="subdued">{user.email}</EuiText>
                        {user.role_count > 0 && (
                          <EuiText size="xs" color="subdued" style={{ marginTop: '4px' }}>
                            {user.role_count} role{user.role_count !== 1 ? 's' : ''}
                          </EuiText>
                        )}
                      </EuiFlexItem>
                    </EuiFlexGroup>
                  </EuiPanel>
                ))}

                {filteredUsers.length === 0 && (
                  <EuiEmptyPrompt
                    icon={<Users style={{ width: '64px', height: '64px', opacity: 0.3 }} />}
                    title={<h3>No users found</h3>}
                  />
                )}
              </div>
            </EuiPanel>
          </EuiFlexItem>

          {/* User Details Panel */}
          <EuiFlexItem grow={2}>
            <EuiPanel hasBorder>
              {selectedUser ? (
                <>
                  <EuiFlexGroup alignItems="center" justifyContent="spaceBetween">
                    <EuiFlexItem>
                      <EuiTitle size="m">
                        <h2>User Details</h2>
                      </EuiTitle>
                    </EuiFlexItem>
                    <EuiFlexItem grow={false}>
                      <EuiFlexGroup gutterSize="s">
                        <EuiFlexItem grow={false}>
                          <EuiButton
                            iconType={Shield}
                            color={selectedUser.is_admin ? 'danger' : 'primary'}
                            onClick={() => handleToggleAdmin(selectedUser)}
                            isLoading={actionLoading}
                          >
                            {selectedUser.is_admin ? 'Remove Admin' : 'Make Admin'}
                          </EuiButton>
                        </EuiFlexItem>
                        <EuiFlexItem grow={false}>
                          <EuiButton
                            iconType={Trash2}
                            color="danger"
                            onClick={() => handleDeleteUser(selectedUser)}
                            isLoading={actionLoading}
                          >
                            Delete User
                          </EuiButton>
                        </EuiFlexItem>
                      </EuiFlexGroup>
                    </EuiFlexItem>
                  </EuiFlexGroup>

                  <EuiSpacer size="l" />

                  {/* User Info */}
                  <EuiFlexGroup gutterSize="l" wrap>
                    <EuiFlexItem style={{ minWidth: '45%' }}>
                      <EuiText size="xs" color="subdued">
                        <strong>USERNAME</strong>
                      </EuiText>
                      <EuiText size="s">{selectedUser.username}</EuiText>
                    </EuiFlexItem>
                    <EuiFlexItem style={{ minWidth: '45%' }}>
                      <EuiText size="xs" color="subdued">
                        <strong>EMAIL</strong>
                      </EuiText>
                      <EuiText size="s">{selectedUser.email}</EuiText>
                    </EuiFlexItem>
                    <EuiFlexItem style={{ minWidth: '45%' }}>
                      <EuiText size="xs" color="subdued">
                        <strong>FULL NAME</strong>
                      </EuiText>
                      <EuiText size="s">{selectedUser.full_name || 'N/A'}</EuiText>
                    </EuiFlexItem>
                    <EuiFlexItem style={{ minWidth: '45%' }}>
                      <EuiText size="xs" color="subdued">
                        <strong>SOURCE</strong>
                      </EuiText>
                      <EuiText size="s">{selectedUser.source || 'Keycloak'}</EuiText>
                    </EuiFlexItem>
                    <EuiFlexItem style={{ minWidth: '45%' }}>
                      <EuiText size="xs" color="subdued">
                        <strong>ADMIN STATUS</strong>
                      </EuiText>
                      <EuiBadge color={selectedUser.is_admin ? 'danger' : 'success'}>
                        {selectedUser.is_admin ? 'System Admin' : 'Regular User'}
                      </EuiBadge>
                    </EuiFlexItem>
                    <EuiFlexItem style={{ minWidth: '45%' }}>
                      <EuiText size="xs" color="subdued">
                        <strong>LAST LOGIN</strong>
                      </EuiText>
                      <EuiText size="s">
                        {selectedUser.last_login ? new Date(selectedUser.last_login).toLocaleString() : 'Never'}
                      </EuiText>
                    </EuiFlexItem>
                  </EuiFlexGroup>

                  <EuiSpacer size="xl" />

                  {/* Roles Section */}
                  {selectedUser.is_admin && (
                    <>
                      <EuiCallOut
                        title="System Administrator"
                        color="warning"
                        iconType={AlertTriangle}
                      >
                        <p>
                          This user has full access to all pages and features. Role assignments are optional and do not restrict admin access.
                        </p>
                      </EuiCallOut>
                      <EuiSpacer size="m" />
                    </>
                  )}

                  <EuiFlexGroup alignItems="center" justifyContent="spaceBetween">
                    <EuiFlexItem>
                      <EuiTitle size="s">
                        <h3>Assigned Roles ({userRoles.length})</h3>
                      </EuiTitle>
                      {selectedUser.is_admin && (
                        <EuiText size="xs" color="subdued">(Optional for admins)</EuiText>
                      )}
                    </EuiFlexItem>
                    <EuiFlexItem grow={false}>
                      <EuiButton
                        iconType={UserPlus}
                        onClick={handleOpenRoleModal}
                        isLoading={actionLoading}
                      >
                        Manage Roles
                      </EuiButton>
                    </EuiFlexItem>
                  </EuiFlexGroup>

                  <EuiSpacer size="m" />

                  {userRoles.length > 0 ? (
                    <EuiFlexGroup direction="column" gutterSize="s">
                      {userRoles.map(role => (
                        <EuiFlexItem key={role.id}>
                          <EuiPanel color="subdued" hasShadow={false} paddingSize="m">
                            <EuiFlexGroup alignItems="center" justifyContent="spaceBetween">
                              <EuiFlexItem>
                                <EuiText size="s">
                                  <strong>{role.display_name || role.role_name}</strong>
                                </EuiText>
                                <EuiText size="xs" color="subdued">
                                  {role.description || 'No description'}
                                </EuiText>
                              </EuiFlexItem>
                              <EuiFlexItem grow={false}>
                                <EuiButtonIcon
                                  iconType="cross"
                                  color="danger"
                                  aria-label="Remove role"
                                  onClick={() => handleRemoveRole(role.id)}
                                  isDisabled={actionLoading}
                                />
                              </EuiFlexItem>
                            </EuiFlexGroup>
                          </EuiPanel>
                        </EuiFlexItem>
                      ))}
                    </EuiFlexGroup>
                  ) : (
                    <EuiEmptyPrompt
                      iconType="users"
                      title={<h4>No roles assigned</h4>}
                      body={
                        <p>
                          {selectedUser.is_admin
                            ? 'As a system administrator, this user has full access to all pages and features.'
                            : 'User has no page access.'}
                        </p>
                      }
                    />
                  )}
                </>
              ) : (
                <EuiEmptyPrompt
                  icon={<Users style={{ width: '64px', height: '64px', opacity: 0.3 }} />}
                  title={<h3>Select a user to view details</h3>}
                />
              )}
            </EuiPanel>
          </EuiFlexItem>
        </EuiFlexGroup>

        {/* Role Assignment Modal */}
        {showRoleModal && selectedUser && (
          <EuiModal onClose={handleCloseRoleModal} style={{ minWidth: '600px' }}>
            <EuiModalHeader>
              <EuiModalHeaderTitle>Assign Roles to {selectedUser.username}</EuiModalHeaderTitle>
            </EuiModalHeader>

            <EuiModalBody>
              <EuiFlexGroup direction="column" gutterSize="s">
                {roles.map(role => (
                  <EuiFlexItem key={role.id}>
                    <EuiPanel color="subdued" paddingSize="m" hasShadow={false}>
                      <EuiFlexGroup alignItems="center" gutterSize="m">
                        <EuiFlexItem grow={false}>
                          <EuiSwitch
                            checked={selectedRoles.includes(role.id)}
                            onChange={() => handleToggleRole(role.id)}
                            compressed
                          />
                        </EuiFlexItem>
                        <EuiFlexItem>
                          <EuiText size="s">
                            <strong>{role.display_name || role.role_name}</strong>
                          </EuiText>
                          <EuiText size="xs" color="subdued">
                            {role.description || 'No description'}
                          </EuiText>
                        </EuiFlexItem>
                      </EuiFlexGroup>
                    </EuiPanel>
                  </EuiFlexItem>
                ))}
              </EuiFlexGroup>
            </EuiModalBody>

            <EuiModalFooter>
              <EuiButton onClick={handleCloseRoleModal} isDisabled={actionLoading}>
                Cancel
              </EuiButton>
              <EuiButton fill onClick={handleSaveRoles} isLoading={actionLoading}>
                Save Roles
              </EuiButton>
            </EuiModalFooter>
          </EuiModal>
        )}

        {/* Create User Modal */}
        {showCreateModal && (
          <EuiModal onClose={handleCloseCreateModal} style={{ minWidth: '700px' }}>
            <EuiModalHeader>
              <EuiModalHeaderTitle>
                <EuiFlexGroup alignItems="center" gutterSize="s">
                  <EuiFlexItem grow={false}>
                    <UserPlus style={{ width: '24px', height: '24px', color: '#3b82f6' }} />
                  </EuiFlexItem>
                  <EuiFlexItem>Create New User</EuiFlexItem>
                </EuiFlexGroup>
              </EuiModalHeaderTitle>
            </EuiModalHeader>

            <EuiModalBody>
              <EuiForm>
                <EuiTitle size="xs">
                  <h4>User Details</h4>
                </EuiTitle>
                <EuiSpacer size="m" />

                <EuiFlexGroup gutterSize="m">
                  <EuiFlexItem>
                    <EuiFormRow
                      label="Username"
                      isInvalid={!!formErrors.username}
                      error={formErrors.username}
                    >
                      <EuiFieldText
                        value={newUser.username}
                        onChange={(e) => setNewUser({ ...newUser, username: e.target.value })}
                        placeholder="john.doe"
                        isInvalid={!!formErrors.username}
                      />
                    </EuiFormRow>
                  </EuiFlexItem>
                  <EuiFlexItem>
                    <EuiFormRow
                      label="Email"
                      isInvalid={!!formErrors.email}
                      error={formErrors.email}
                    >
                      <EuiFieldText
                        type="email"
                        value={newUser.email}
                        onChange={(e) => setNewUser({ ...newUser, email: e.target.value })}
                        placeholder="john.doe@company.com"
                        isInvalid={!!formErrors.email}
                      />
                    </EuiFormRow>
                  </EuiFlexItem>
                </EuiFlexGroup>

                <EuiFlexGroup gutterSize="m">
                  <EuiFlexItem>
                    <EuiFormRow
                      label="First Name"
                      isInvalid={!!formErrors.first_name}
                      error={formErrors.first_name}
                    >
                      <EuiFieldText
                        value={newUser.first_name}
                        onChange={(e) => setNewUser({ ...newUser, first_name: e.target.value })}
                        placeholder="John"
                        isInvalid={!!formErrors.first_name}
                      />
                    </EuiFormRow>
                  </EuiFlexItem>
                  <EuiFlexItem>
                    <EuiFormRow
                      label="Last Name"
                      isInvalid={!!formErrors.last_name}
                      error={formErrors.last_name}
                    >
                      <EuiFieldText
                        value={newUser.last_name}
                        onChange={(e) => setNewUser({ ...newUser, last_name: e.target.value })}
                        placeholder="Doe"
                        isInvalid={!!formErrors.last_name}
                      />
                    </EuiFormRow>
                  </EuiFlexItem>
                </EuiFlexGroup>

                <EuiFormRow
                  label="Password"
                  helpText="Min 8 characters, 1 uppercase, 1 lowercase, 1 number"
                  isInvalid={!!formErrors.password}
                  error={formErrors.password}
                >
                  <EuiFieldPassword
                    type="dual"
                    value={newUser.password}
                    onChange={(e) => setNewUser({ ...newUser, password: e.target.value })}
                    placeholder="Min 8 chars, 1 upper, 1 lower, 1 number"
                    isInvalid={!!formErrors.password}
                  />
                </EuiFormRow>

                <EuiFormRow>
                  <EuiSwitch
                    label="System Administrator"
                    checked={newUser.is_admin}
                    onChange={(e) => setNewUser({ ...newUser, is_admin: e.target.checked })}
                  />
                </EuiFormRow>

                <EuiSpacer size="l" />

                <EuiTitle size="xs">
                  <h4>Assign Roles (Optional)</h4>
                </EuiTitle>
                <EuiSpacer size="m" />

                <div style={{ maxHeight: '250px', overflowY: 'auto' }}>
                  <EuiFlexGroup direction="column" gutterSize="s">
                    {roles.map(role => (
                      <EuiFlexItem key={role.id}>
                        <EuiPanel color="subdued" paddingSize="m" hasShadow={false}>
                          <EuiFlexGroup alignItems="center" gutterSize="m">
                            <EuiFlexItem grow={false}>
                              <EuiSwitch
                                checked={newUser.role_ids.includes(role.id)}
                                onChange={() => handleToggleNewUserRole(role.id)}
                                compressed
                              />
                            </EuiFlexItem>
                            <EuiFlexItem>
                              <EuiText size="s">
                                <strong>{role.display_name || role.role_name}</strong>
                              </EuiText>
                              <EuiText size="xs" color="subdued">
                                {role.description || 'No description'}
                              </EuiText>
                            </EuiFlexItem>
                          </EuiFlexGroup>
                        </EuiPanel>
                      </EuiFlexItem>
                    ))}
                  </EuiFlexGroup>
                </div>
              </EuiForm>
            </EuiModalBody>

            <EuiModalFooter>
              <EuiButton onClick={handleCloseCreateModal} isDisabled={actionLoading}>
                Cancel
              </EuiButton>
              <EuiButton fill onClick={handleCreateUser} isLoading={actionLoading}>
                Create User
              </EuiButton>
            </EuiModalFooter>
          </EuiModal>
        )}
      </EuiPageBody>
    </EuiPage>
  );
};

export default UserManagement;
