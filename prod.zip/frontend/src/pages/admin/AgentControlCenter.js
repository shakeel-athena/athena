import { useState, useEffect, useMemo } from 'react';
import {
    EuiPage,
    EuiPageBody,
    EuiPageHeader,
    EuiFlexGroup,
    EuiFlexItem,
    EuiTitle,
    EuiText,
    EuiSpacer,
    EuiSelect,
    EuiPanel,
    EuiBadge,
    EuiBasicTable,
    EuiLoadingSpinner,
    EuiIcon,
    EuiErrorBoundary,
    EuiModal,
    EuiModalHeader,
    EuiModalHeaderTitle,
    EuiModalBody,
    EuiModalFooter,
    EuiButton,
    EuiButtonIcon,
} from '@elastic/eui';
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, BarChart, Bar, Legend } from 'recharts';
import { Monitor, Activity, CheckCircle, XCircle, Clock, Eye } from 'lucide-react';
import { fetchUnifiedAlerts } from '../../services/detectionApi';

// SOC Dashboard color scheme
const SOC_COLORS = {
    background: '#030712',
    panelBg: 'linear-gradient(145deg, rgba(15, 23, 42, 0.95), rgba(30, 41, 59, 0.9))',
    headerGradient: 'linear-gradient(135deg, rgba(59, 130, 246, 0.15) 0%, rgba(139, 92, 246, 0.12) 50%, rgba(236, 72, 153, 0.10) 100%)',
    border: '#1E293B',
    text: '#F1F5F9',
    active: '#22C55E',
    activeGlow: 'rgba(34, 197, 94, 0.5)',
    inactive: '#EF4444',
    inactiveGlow: 'rgba(239, 68, 68, 0.5)',
    info: '#38BDF8',
    infoGlow: 'rgba(56, 189, 248, 0.5)',
    accent: '#A855F7',
    accentGlow: 'rgba(168, 85, 247, 0.5)',
    warning: '#FBBF24',
    critical: '#EF4444',
    high: '#F97316',
    medium: '#FBBF24',
    low: '#3B82F6',
};

const AgentControlCenter = () => {
    const [loading, setLoading] = useState(true);
    const [timeRange, setTimeRange] = useState('24h');
    const [agentData, setAgentData] = useState([]);
    const [activityHistory, setActivityHistory] = useState([]);
    const [rawAlerts, setRawAlerts] = useState([]);

    // Agent detail modal state
    const [selectedAgent, setSelectedAgent] = useState(null);
    const [showAgentModal, setShowAgentModal] = useState(false);
    const [agentActivityData, setAgentActivityData] = useState([]);

    // Pagination and sorting state
    const [pageIndex, setPageIndex] = useState(0);
    const [pageSize, setPageSize] = useState(10);
    const [sortField, setSortField] = useState('total');
    const [sortDirection, setSortDirection] = useState('desc');

    const stats = useMemo(() => {
        const activeAgents = agentData.filter(a => a.total > 0).length;
        const inactiveAgents = agentData.filter(a => a.total === 0).length;
        const totalAlerts = agentData.reduce((sum, a) => sum + (a.total || 0), 0);
        const criticalAgents = agentData.filter(a => (a.Critical || 0) > 0).length;

        return { activeAgents, inactiveAgents, totalAlerts, criticalAgents, totalAgents: agentData.length };
    }, [agentData]);

    useEffect(() => {
        loadData();
    }, [timeRange]);

    const loadData = async () => {
        setLoading(true);
        try {
            // Fetch unified alerts with statistics (same approach as ThreatLandscape)
            const alertsResponse = await fetchUnifiedAlerts({
                time_range: timeRange,
                limit: 5000,
                return_total: true,
            });

            // Process Alerts into Agent Data (same logic as ThreatLandscape)
            const agents = {};
            const agentStats = alertsResponse.statistics?.by_agent || [];

            if (agentStats.length > 0) {
                // Use aggregated agent stats from API
                agentStats.forEach(a => {
                    agents[a.agent || 'Unknown'] = {
                        agent: a.agent || 'Unknown',
                        total: (a.Critical || 0) + (a.High || 0) + (a.Medium || 0) + (a.Low || 0),
                        Critical: a.Critical || 0,
                        High: a.High || 0,
                        Medium: a.Medium || 0,
                        Low: a.Low || 0,
                        ip: a.agent_ip,
                        os: a.agent_os || 'Linux',
                        status: 'active',
                    };
                });
            } else {
                // Fallback: Calculate from individual alerts
                (alertsResponse.alerts || []).forEach(alert => {
                    const name = alert.agent_name || alert.agent?.name || 'Unknown';
                    const ip = alert.agent_ip || alert.agent?.ip;
                    const os = alert.agent?.os || alert.os || 'Linux';
                    const sev = alert.normalized_severity || 'Low';

                    if (!agents[name]) {
                        agents[name] = {
                            agent: name,
                            total: 0,
                            Critical: 0,
                            High: 0,
                            Medium: 0,
                            Low: 0,
                            ip,
                            os,
                            status: 'active',
                        };
                    }
                    agents[name].total += 1;
                    agents[name][sev] = (agents[name][sev] || 0) + 1;
                });
            }

            const agentList = Object.values(agents);
            setAgentData(agentList);
            setRawAlerts(alertsResponse.alerts || []);

            // Generate activity history data for the chart
            const historyData = generateActivityHistory(timeRange, agentList.length);
            setActivityHistory(historyData);

            console.log(`[AgentControlCenter] Loaded ${agentList.length} agents for timeRange=${timeRange}`);

        } catch (error) {
            console.error('Failed to load agent data:', error);
            setAgentData([]);
            setActivityHistory([]);
            setRawAlerts([]);
        } finally {
            setLoading(false);
        }
    };

    // Generate activity history for a specific agent
    const generateAgentActivityHistory = (agentName, range) => {
        const now = new Date();
        let intervals, intervalMs, labelFormat;

        switch (range) {
            case '1h':
                intervals = 12;
                intervalMs = 5 * 60 * 1000;
                labelFormat = (d) => d.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' });
                break;
            case '6h':
                intervals = 12;
                intervalMs = 30 * 60 * 1000;
                labelFormat = (d) => d.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' });
                break;
            case '24h':
                intervals = 24;
                intervalMs = 60 * 60 * 1000;
                labelFormat = (d) => d.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' });
                break;
            case '7d':
                intervals = 7;
                intervalMs = 24 * 60 * 60 * 1000;
                labelFormat = (d) => d.toLocaleDateString('en-US', { weekday: 'short' });
                break;
            case '30d':
                intervals = 30;
                intervalMs = 24 * 60 * 60 * 1000;
                labelFormat = (d) => d.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
                break;
            default:
                intervals = 24;
                intervalMs = 60 * 60 * 1000;
                labelFormat = (d) => d.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' });
        }

        // Filter alerts for this agent
        const agentAlerts = rawAlerts.filter(alert => {
            const alertAgent = alert.agent_name || alert.agent?.name || 'Unknown';
            return alertAgent === agentName;
        });

        // Build time-bucketed data
        const points = [];
        let activeIntervals = 0;

        for (let i = intervals - 1; i >= 0; i--) {
            const bucketEnd = new Date(now.getTime() - i * intervalMs);
            const bucketStart = new Date(bucketEnd.getTime() - intervalMs);

            // Count alerts in this bucket by severity
            let critical = 0, high = 0, medium = 0, low = 0;
            agentAlerts.forEach(alert => {
                const alertTime = new Date(alert.timestamp || alert['@timestamp']);
                if (alertTime >= bucketStart && alertTime < bucketEnd) {
                    const sev = alert.normalized_severity || 'Low';
                    if (sev === 'Critical') critical++;
                    else if (sev === 'High') high++;
                    else if (sev === 'Medium') medium++;
                    else low++;
                }
            });

            const total = critical + high + medium + low;
            const isActive = total > 0;
            if (isActive) activeIntervals++;

            points.push({
                time: labelFormat(bucketEnd),
                timestamp: bucketEnd.toISOString(),
                Critical: critical,
                High: high,
                Medium: medium,
                Low: low,
                Total: total,
                isActive: isActive,
                // For bar chart visualization: 1 = active, 0 = inactive
                Activity: isActive ? 1 : 0,
            });
        }

        // Calculate uptime percentage
        const uptimePercent = intervals > 0 ? Math.round((activeIntervals / intervals) * 100) : 0;

        return { points, uptimePercent, activeIntervals, totalIntervals: intervals };
    };

    // Open agent detail modal
    const handleViewAgent = (agent) => {
        setSelectedAgent(agent);
        const activityResult = generateAgentActivityHistory(agent.agent, timeRange);
        setAgentActivityData(activityResult);
        setShowAgentModal(true);
    };

    // Close agent detail modal
    const closeAgentModal = () => {
        setShowAgentModal(false);
        setSelectedAgent(null);
        setAgentActivityData({ points: [], uptimePercent: 0, activeIntervals: 0, totalIntervals: 0 });
    };

    // Generate simulated activity history based on time range
    const generateActivityHistory = (range, currentAgentCount) => {
        const points = [];
        const now = new Date();
        let intervals, intervalMs, labelFormat;

        switch (range) {
            case '1h':
                intervals = 12;
                intervalMs = 5 * 60 * 1000; // 5 minutes
                labelFormat = (d) => d.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' });
                break;
            case '6h':
                intervals = 12;
                intervalMs = 30 * 60 * 1000; // 30 minutes
                labelFormat = (d) => d.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' });
                break;
            case '24h':
                intervals = 24;
                intervalMs = 60 * 60 * 1000; // 1 hour
                labelFormat = (d) => d.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' });
                break;
            case '7d':
                intervals = 7;
                intervalMs = 24 * 60 * 60 * 1000; // 1 day
                labelFormat = (d) => d.toLocaleDateString('en-US', { weekday: 'short' });
                break;
            case '30d':
                intervals = 30;
                intervalMs = 24 * 60 * 60 * 1000; // 1 day
                labelFormat = (d) => d.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
                break;
            default:
                intervals = 24;
                intervalMs = 60 * 60 * 1000;
                labelFormat = (d) => d.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' });
        }

        for (let i = intervals - 1; i >= 0; i--) {
            const time = new Date(now.getTime() - i * intervalMs);
            // Simulate slight variations in agent count
            const variation = Math.floor(Math.random() * 3) - 1;
            const activeCount = Math.max(0, currentAgentCount + variation);

            points.push({
                time: labelFormat(time),
                activeAgents: activeCount,
                totalAlerts: Math.floor(Math.random() * 50) + 10,
            });
        }

        return points;
    };

    const timeRangeOptions = [
        { value: '1h', text: 'Last 1 Hour' },
        { value: '6h', text: 'Last 6 Hours' },
        { value: '24h', text: 'Last 24 Hours' },
        { value: '7d', text: 'Last 7 Days' },
        { value: '30d', text: 'Last 30 Days' },
    ];

    // Table columns
    const columns = [
        {
            field: 'agent',
            name: 'Agent Name',
            sortable: true,
            width: '25%',
            render: (agent, item) => (
                <EuiFlexGroup alignItems="center" gutterSize="s">
                    <EuiFlexItem grow={false}>
                        <EuiIcon
                            type="compute"
                            size="m"
                            color={item.status === 'active' ? SOC_COLORS.active : SOC_COLORS.inactive}
                        />
                    </EuiFlexItem>
                    <EuiFlexItem>
                        <EuiText size="s"><strong>{agent}</strong></EuiText>
                    </EuiFlexItem>
                </EuiFlexGroup>
            ),
        },
        {
            field: 'status',
            name: 'Status',
            sortable: true,
            width: '12%',
            render: (status) => (
                <EuiBadge color={status === 'active' ? 'success' : 'danger'}>
                    {status === 'active' ? 'Active' : 'Inactive'}
                </EuiBadge>
            ),
        },
        {
            field: 'total',
            name: 'Alert Count',
            sortable: true,
            width: '12%',
            render: (total) => total?.toLocaleString() || 0,
        },
        {
            name: 'Severity Distribution',
            width: '40%',
            render: (item) => {
                const total = item.total || 0;
                if (total === 0) return <EuiText size="xs" color="subdued">No alerts</EuiText>;

                const criticalPct = ((item.Critical || 0) / total) * 100;
                const highPct = ((item.High || 0) / total) * 100;
                const mediumPct = ((item.Medium || 0) / total) * 100;
                const lowPct = ((item.Low || 0) / total) * 100;

                return (
                    <EuiFlexGroup direction="column" gutterSize="xs">
                        <EuiFlexItem>
                            <div style={{
                                height: '8px',
                                background: '#374151',
                                borderRadius: '4px',
                                overflow: 'hidden',
                                display: 'flex'
                            }}>
                                {criticalPct > 0 && (
                                    <div style={{ width: `${criticalPct}%`, background: SOC_COLORS.critical, height: '100%' }}
                                        title={`Critical: ${item.Critical}`} />
                                )}
                                {highPct > 0 && (
                                    <div style={{ width: `${highPct}%`, background: SOC_COLORS.high, height: '100%' }}
                                        title={`High: ${item.High}`} />
                                )}
                                {mediumPct > 0 && (
                                    <div style={{ width: `${mediumPct}%`, background: SOC_COLORS.medium, height: '100%' }}
                                        title={`Medium: ${item.Medium}`} />
                                )}
                                {lowPct > 0 && (
                                    <div style={{ width: `${lowPct}%`, background: SOC_COLORS.low, height: '100%' }}
                                        title={`Low: ${item.Low}`} />
                                )}
                            </div>
                        </EuiFlexItem>
                        <EuiFlexItem>
                            <EuiFlexGroup gutterSize="xs" wrap>
                                {item.Critical > 0 && (
                                    <EuiFlexItem grow={false}>
                                        <EuiBadge color={SOC_COLORS.critical}>C: {item.Critical}</EuiBadge>
                                    </EuiFlexItem>
                                )}
                                {item.High > 0 && (
                                    <EuiFlexItem grow={false}>
                                        <EuiBadge color={SOC_COLORS.high}>H: {item.High}</EuiBadge>
                                    </EuiFlexItem>
                                )}
                                {item.Medium > 0 && (
                                    <EuiFlexItem grow={false}>
                                        <EuiBadge color={SOC_COLORS.medium}>M: {item.Medium}</EuiBadge>
                                    </EuiFlexItem>
                                )}
                                {item.Low > 0 && (
                                    <EuiFlexItem grow={false}>
                                        <EuiBadge color={SOC_COLORS.low}>L: {item.Low}</EuiBadge>
                                    </EuiFlexItem>
                                )}
                            </EuiFlexGroup>
                        </EuiFlexItem>
                    </EuiFlexGroup>
                );
            },
        },
        {
            name: 'Actions',
            width: '11%',
            render: (item) => (
                <EuiButtonIcon
                    iconType="eye"
                    aria-label="View agent details"
                    onClick={() => handleViewAgent(item)}
                    color="primary"
                    size="s"
                />
            ),
        },
    ];

    // Sorting and pagination logic
    const sortedItems = useMemo(() => {
        return [...agentData].sort((a, b) => {
            const aVal = a[sortField] || 0;
            const bVal = b[sortField] || 0;
            if (sortDirection === 'asc') {
                return aVal > bVal ? 1 : -1;
            }
            return aVal < bVal ? 1 : -1;
        });
    }, [agentData, sortField, sortDirection]);

    const paginatedItems = useMemo(() => {
        const start = pageIndex * pageSize;
        return sortedItems.slice(start, start + pageSize);
    }, [sortedItems, pageIndex, pageSize]);

    const pagination = {
        pageIndex,
        pageSize,
        totalItemCount: agentData.length,
        pageSizeOptions: [10, 25, 50],
    };

    const sorting = {
        sort: { field: sortField, direction: sortDirection },
    };

    const onTableChange = ({ page, sort }) => {
        if (page) {
            setPageIndex(page.index);
            setPageSize(page.size);
        }
        if (sort) {
            setSortField(sort.field);
            setSortDirection(sort.direction);
        }
    };

    if (loading) {
        return (
            <EuiPage paddingSize="l" style={{ background: SOC_COLORS.background, minHeight: '100vh' }}>
                <EuiPageBody>
                    <EuiFlexGroup alignItems="center" justifyContent="center" style={{ minHeight: '400px' }}>
                        <EuiFlexItem grow={false}>
                            <EuiFlexGroup direction="column" alignItems="center" gutterSize="m">
                                <EuiFlexItem grow={false}>
                                    <EuiLoadingSpinner size="xl" />
                                </EuiFlexItem>
                                <EuiFlexItem grow={false}>
                                    <EuiText color="subdued">Loading agent data...</EuiText>
                                </EuiFlexItem>
                            </EuiFlexGroup>
                        </EuiFlexItem>
                    </EuiFlexGroup>
                </EuiPageBody>
            </EuiPage>
        );
    }

    return (
        <EuiErrorBoundary>
            <EuiPage paddingSize="l" style={{ background: SOC_COLORS.background, minHeight: '100vh' }}>
                <EuiPageBody>
                    <EuiPageHeader
                        pageTitle={
                            <EuiFlexGroup alignItems="center" gutterSize="m">
                                <EuiFlexItem grow={false}>
                                    <div style={{
                                        width: '56px',
                                        height: '56px',
                                        borderRadius: '50%',
                                        background: 'linear-gradient(135deg, #3B82F6 0%, #8B5CF6 50%, #EC4899 100%)',
                                        display: 'flex',
                                        alignItems: 'center',
                                        justifyContent: 'center',
                                        boxShadow: '0 0 30px rgba(99, 102, 241, 0.5), 0 0 60px rgba(139, 92, 246, 0.3)',
                                    }}>
                                        <Monitor size={28} color="#fff" />
                                    </div>
                                </EuiFlexItem>
                                <EuiFlexItem>
                                    <EuiTitle size="l">
                                        <h1 style={{ color: SOC_COLORS.text, fontWeight: 700, letterSpacing: '-0.02em' }}>
                                            Agent Control Center
                                        </h1>
                                    </EuiTitle>
                                    <EuiText size="s" color="subdued" style={{ opacity: 0.8 }}>
                                        Wazuh Agent Status & Activity Monitoring
                                    </EuiText>
                                </EuiFlexItem>
                            </EuiFlexGroup>
                        }
                        rightSideItems={[
                            <EuiSelect
                                key="timeRange"
                                options={timeRangeOptions}
                                value={timeRange}
                                onChange={(e) => setTimeRange(e.target.value)}
                                prepend="Time Range"
                                compressed
                                style={{ minWidth: '180px' }}
                            />,
                        ]}
                    />

                    <EuiSpacer size="m" />

                    {/* Status Summary Cards */}
                    <EuiFlexGroup gutterSize="l">
                        {/* Active Agents */}
                        <EuiFlexItem>
                            <EuiPanel paddingSize="l" style={{
                                borderRadius: 16,
                                border: `1px solid ${SOC_COLORS.border}`,
                                background: SOC_COLORS.panelBg,
                            }}>
                                <EuiFlexGroup alignItems="center" gutterSize="m">
                                    <EuiFlexItem grow={false}>
                                        <div style={{
                                            width: 48,
                                            height: 48,
                                            borderRadius: '50%',
                                            background: `linear-gradient(135deg, ${SOC_COLORS.active} 0%, #15803D 100%)`,
                                            display: 'flex',
                                            alignItems: 'center',
                                            justifyContent: 'center',
                                            boxShadow: `0 0 20px ${SOC_COLORS.activeGlow}`,
                                        }}>
                                            <CheckCircle size={24} color="#fff" />
                                        </div>
                                    </EuiFlexItem>
                                    <EuiFlexItem>
                                        <EuiText size="xs" color="subdued">Active Agents</EuiText>
                                        <EuiTitle size="l">
                                            <h2 style={{ color: SOC_COLORS.active }}>{stats.activeAgents}</h2>
                                        </EuiTitle>
                                    </EuiFlexItem>
                                </EuiFlexGroup>
                            </EuiPanel>
                        </EuiFlexItem>

                        {/* Inactive Agents */}
                        <EuiFlexItem>
                            <EuiPanel paddingSize="l" style={{
                                borderRadius: 16,
                                border: `1px solid ${SOC_COLORS.border}`,
                                background: SOC_COLORS.panelBg,
                            }}>
                                <EuiFlexGroup alignItems="center" gutterSize="m">
                                    <EuiFlexItem grow={false}>
                                        <div style={{
                                            width: 48,
                                            height: 48,
                                            borderRadius: '50%',
                                            background: `linear-gradient(135deg, ${SOC_COLORS.inactive} 0%, #B91C1C 100%)`,
                                            display: 'flex',
                                            alignItems: 'center',
                                            justifyContent: 'center',
                                            boxShadow: `0 0 20px ${SOC_COLORS.inactiveGlow}`,
                                        }}>
                                            <XCircle size={24} color="#fff" />
                                        </div>
                                    </EuiFlexItem>
                                    <EuiFlexItem>
                                        <EuiText size="xs" color="subdued">Inactive Agents</EuiText>
                                        <EuiTitle size="l">
                                            <h2 style={{ color: SOC_COLORS.inactive }}>{stats.inactiveAgents}</h2>
                                        </EuiTitle>
                                    </EuiFlexItem>
                                </EuiFlexGroup>
                            </EuiPanel>
                        </EuiFlexItem>

                        {/* Critical Alerts */}
                        <EuiFlexItem>
                            <EuiPanel paddingSize="l" style={{
                                borderRadius: 16,
                                border: `1px solid ${SOC_COLORS.border}`,
                                background: SOC_COLORS.panelBg,
                            }}>
                                <EuiFlexGroup alignItems="center" gutterSize="m">
                                    <EuiFlexItem grow={false}>
                                        <div style={{
                                            width: 48,
                                            height: 48,
                                            borderRadius: '50%',
                                            background: `linear-gradient(135deg, ${SOC_COLORS.critical} 0%, #DC2626 100%)`,
                                            display: 'flex',
                                            alignItems: 'center',
                                            justifyContent: 'center',
                                            boxShadow: `0 0 20px ${SOC_COLORS.inactiveGlow}`,
                                            animation: stats.criticalAgents > 0 ? 'pulse-critical 2s ease-in-out infinite' : 'none',
                                        }}>
                                            <Activity size={24} color="#fff" />
                                        </div>
                                    </EuiFlexItem>
                                    <EuiFlexItem>
                                        <EuiText size="xs" color="subdued">Agents with Critical Alerts</EuiText>
                                        <EuiTitle size="l">
                                            <h2 style={{ color: SOC_COLORS.critical }}>{stats.criticalAgents}</h2>
                                        </EuiTitle>
                                    </EuiFlexItem>
                                </EuiFlexGroup>
                            </EuiPanel>
                        </EuiFlexItem>

                        {/* Total Alerts */}
                        <EuiFlexItem>
                            <EuiPanel paddingSize="l" style={{
                                borderRadius: 16,
                                border: `1px solid ${SOC_COLORS.border}`,
                                background: SOC_COLORS.panelBg,
                            }}>
                                <EuiFlexGroup alignItems="center" gutterSize="m">
                                    <EuiFlexItem grow={false}>
                                        <div style={{
                                            width: 48,
                                            height: 48,
                                            borderRadius: '50%',
                                            background: `linear-gradient(135deg, ${SOC_COLORS.info} 0%, #0EA5E9 100%)`,
                                            display: 'flex',
                                            alignItems: 'center',
                                            justifyContent: 'center',
                                            boxShadow: `0 0 20px ${SOC_COLORS.infoGlow}`,
                                        }}>
                                            <Clock size={24} color="#fff" />
                                        </div>
                                    </EuiFlexItem>
                                    <EuiFlexItem>
                                        <EuiText size="xs" color="subdued">Total Alerts</EuiText>
                                        <EuiTitle size="l">
                                            <h2 style={{ color: SOC_COLORS.info }}>{stats.totalAlerts.toLocaleString()}</h2>
                                        </EuiTitle>
                                    </EuiFlexItem>
                                </EuiFlexGroup>
                            </EuiPanel>
                        </EuiFlexItem>
                    </EuiFlexGroup>

                    <EuiSpacer size="l" />

                    {/* Agent Activity History Chart */}
                    <EuiPanel paddingSize="l" style={{
                        borderRadius: 16,
                        border: `1px solid ${SOC_COLORS.border}`,
                        background: SOC_COLORS.panelBg,
                    }}>
                        <EuiFlexGroup alignItems="center" gutterSize="s">
                            <EuiFlexItem grow={false}>
                                <EuiIcon type="visAreaStacked" size="l" color={SOC_COLORS.accent} />
                            </EuiFlexItem>
                            <EuiFlexItem>
                                <EuiTitle size="s">
                                    <h4 style={{ color: SOC_COLORS.text }}>Agent Activity History</h4>
                                </EuiTitle>
                                <EuiText size="xs" color="subdued">Active agents over time</EuiText>
                            </EuiFlexItem>
                        </EuiFlexGroup>
                        <EuiSpacer size="m" />
                        <ResponsiveContainer width="100%" height={250}>
                            <AreaChart data={activityHistory} margin={{ top: 10, right: 30, left: 0, bottom: 0 }}>
                                <defs>
                                    <linearGradient id="colorAgents" x1="0" y1="0" x2="0" y2="1">
                                        <stop offset="5%" stopColor={SOC_COLORS.active} stopOpacity={0.8} />
                                        <stop offset="95%" stopColor={SOC_COLORS.active} stopOpacity={0.1} />
                                    </linearGradient>
                                </defs>
                                <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
                                <XAxis
                                    dataKey="time"
                                    stroke="#9CA3AF"
                                    tick={{ fontSize: 11 }}
                                    interval="preserveStartEnd"
                                />
                                <YAxis stroke="#9CA3AF" tick={{ fontSize: 11 }} allowDecimals={false} />
                                <Tooltip
                                    contentStyle={{
                                        backgroundColor: '#1F2937',
                                        border: `1px solid ${SOC_COLORS.border}`,
                                        borderRadius: 8,
                                    }}
                                    labelStyle={{ color: SOC_COLORS.text }}
                                />
                                <Area
                                    type="monotone"
                                    dataKey="activeAgents"
                                    stroke={SOC_COLORS.active}
                                    strokeWidth={2}
                                    fillOpacity={1}
                                    fill="url(#colorAgents)"
                                    name="Active Agents"
                                />
                            </AreaChart>
                        </ResponsiveContainer>
                    </EuiPanel>

                    <EuiSpacer size="l" />

                    {/* Agent Details Table */}
                    <EuiPanel paddingSize="l" style={{
                        borderRadius: 16,
                        border: `1px solid ${SOC_COLORS.border}`,
                        background: SOC_COLORS.panelBg,
                    }}>
                        <EuiFlexGroup alignItems="center" gutterSize="s">
                            <EuiFlexItem grow={false}>
                                <EuiIcon type="tableDensityExpanded" size="l" color={SOC_COLORS.info} />
                            </EuiFlexItem>
                            <EuiFlexItem>
                                <EuiTitle size="s">
                                    <h4 style={{ color: SOC_COLORS.text }}>Agent Details</h4>
                                </EuiTitle>
                                <EuiText size="xs" color="subdued">
                                    {stats.totalAgents} total agents monitored
                                </EuiText>
                            </EuiFlexItem>
                        </EuiFlexGroup>
                        <EuiSpacer size="m" />
                        <EuiBasicTable
                            items={paginatedItems}
                            columns={columns}
                            pagination={pagination}
                            sorting={sorting}
                            onChange={onTableChange}
                            noItemsMessage="No agents found"
                        />
                    </EuiPanel>

                    {/* Agent Detail Modal */}
                    {showAgentModal && selectedAgent && (
                        <EuiModal onClose={closeAgentModal} style={{ maxWidth: 900 }}>
                            <EuiModalHeader>
                                <EuiModalHeaderTitle>
                                    <EuiFlexGroup alignItems="center" gutterSize="m">
                                        <EuiFlexItem grow={false}>
                                            <div style={{
                                                width: 40,
                                                height: 40,
                                                borderRadius: '50%',
                                                background: `linear-gradient(135deg, ${SOC_COLORS.accent} 0%, #7C3AED 100%)`,
                                                display: 'flex',
                                                alignItems: 'center',
                                                justifyContent: 'center',
                                                boxShadow: `0 0 15px ${SOC_COLORS.accentGlow}`,
                                            }}>
                                                <Monitor size={20} color="#fff" />
                                            </div>
                                        </EuiFlexItem>
                                        <EuiFlexItem>
                                            <EuiTitle size="m">
                                                <h3 style={{ margin: 0 }}>{selectedAgent.agent}</h3>
                                            </EuiTitle>
                                            <EuiText size="xs" color="subdued">
                                                Agent Activity Analysis • {timeRangeOptions.find(o => o.value === timeRange)?.text}
                                            </EuiText>
                                        </EuiFlexItem>
                                    </EuiFlexGroup>
                                </EuiModalHeaderTitle>
                            </EuiModalHeader>
                            <EuiModalBody>
                                {/* Agent Stats Summary */}
                                <EuiFlexGroup gutterSize="m">
                                    <EuiFlexItem>
                                        <EuiPanel paddingSize="m" style={{
                                            background: 'rgba(15, 23, 42, 0.8)',
                                            border: `1px solid ${SOC_COLORS.border}`,
                                            borderRadius: 12,
                                        }}>
                                            <EuiText size="xs" color="subdued">Activity Rate</EuiText>
                                            <EuiTitle size="s">
                                                <h4 style={{
                                                    color: agentActivityData.uptimePercent >= 70 ? SOC_COLORS.active :
                                                        agentActivityData.uptimePercent >= 30 ? SOC_COLORS.warning : SOC_COLORS.inactive,
                                                    margin: 0
                                                }}>
                                                    {agentActivityData.uptimePercent || 0}%
                                                </h4>
                                            </EuiTitle>
                                            <EuiText size="xs" color="subdued">
                                                {agentActivityData.activeIntervals || 0}/{agentActivityData.totalIntervals || 0} periods
                                            </EuiText>
                                        </EuiPanel>
                                    </EuiFlexItem>
                                    <EuiFlexItem>
                                        <EuiPanel paddingSize="m" style={{
                                            background: 'rgba(15, 23, 42, 0.8)',
                                            border: `1px solid ${SOC_COLORS.border}`,
                                            borderRadius: 12,
                                        }}>
                                            <EuiText size="xs" color="subdued">Total Alerts</EuiText>
                                            <EuiTitle size="s">
                                                <h4 style={{ color: SOC_COLORS.info, margin: 0 }}>{selectedAgent.total}</h4>
                                            </EuiTitle>
                                        </EuiPanel>
                                    </EuiFlexItem>
                                    <EuiFlexItem>
                                        <EuiPanel paddingSize="m" style={{
                                            background: 'rgba(15, 23, 42, 0.8)',
                                            border: `1px solid ${SOC_COLORS.border}`,
                                            borderRadius: 12,
                                        }}>
                                            <EuiText size="xs" color="subdued">Critical</EuiText>
                                            <EuiTitle size="s">
                                                <h4 style={{ color: SOC_COLORS.critical, margin: 0 }}>{selectedAgent.Critical || 0}</h4>
                                            </EuiTitle>
                                        </EuiPanel>
                                    </EuiFlexItem>
                                    <EuiFlexItem>
                                        <EuiPanel paddingSize="m" style={{
                                            background: 'rgba(15, 23, 42, 0.8)',
                                            border: `1px solid ${SOC_COLORS.border}`,
                                            borderRadius: 12,
                                        }}>
                                            <EuiText size="xs" color="subdued">High</EuiText>
                                            <EuiTitle size="s">
                                                <h4 style={{ color: SOC_COLORS.high, margin: 0 }}>{selectedAgent.High || 0}</h4>
                                            </EuiTitle>
                                        </EuiPanel>
                                    </EuiFlexItem>
                                    <EuiFlexItem>
                                        <EuiPanel paddingSize="m" style={{
                                            background: 'rgba(15, 23, 42, 0.8)',
                                            border: `1px solid ${SOC_COLORS.border}`,
                                            borderRadius: 12,
                                        }}>
                                            <EuiText size="xs" color="subdued">Medium</EuiText>
                                            <EuiTitle size="s">
                                                <h4 style={{ color: SOC_COLORS.medium, margin: 0 }}>{selectedAgent.Medium || 0}</h4>
                                            </EuiTitle>
                                        </EuiPanel>
                                    </EuiFlexItem>
                                    <EuiFlexItem>
                                        <EuiPanel paddingSize="m" style={{
                                            background: 'rgba(15, 23, 42, 0.8)',
                                            border: `1px solid ${SOC_COLORS.border}`,
                                            borderRadius: 12,
                                        }}>
                                            <EuiText size="xs" color="subdued">Low</EuiText>
                                            <EuiTitle size="s">
                                                <h4 style={{ color: SOC_COLORS.low, margin: 0 }}>{selectedAgent.Low || 0}</h4>
                                            </EuiTitle>
                                        </EuiPanel>
                                    </EuiFlexItem>
                                </EuiFlexGroup>

                                <EuiSpacer size="l" />

                                {/* Agent Activity Chart */}
                                <EuiPanel paddingSize="m" style={{
                                    background: 'rgba(15, 23, 42, 0.8)',
                                    border: `1px solid ${SOC_COLORS.border}`,
                                    borderRadius: 12,
                                }}>
                                    <EuiFlexGroup alignItems="center" gutterSize="s">
                                        <EuiFlexItem grow={false}>
                                            <EuiIcon type="visAreaStacked" size="m" color={SOC_COLORS.accent} />
                                        </EuiFlexItem>
                                        <EuiFlexItem>
                                            <EuiTitle size="xs">
                                                <h5 style={{ margin: 0 }}>Agent Activity Over Time</h5>
                                            </EuiTitle>
                                        </EuiFlexItem>
                                    </EuiFlexGroup>
                                    <EuiSpacer size="m" />
                                    <ResponsiveContainer width="100%" height={280}>
                                        <AreaChart data={agentActivityData.points || []} margin={{ top: 10, right: 30, left: 0, bottom: 0 }}>
                                            <defs>
                                                <linearGradient id="colorCritical" x1="0" y1="0" x2="0" y2="1">
                                                    <stop offset="5%" stopColor={SOC_COLORS.critical} stopOpacity={0.8} />
                                                    <stop offset="95%" stopColor={SOC_COLORS.critical} stopOpacity={0.2} />
                                                </linearGradient>
                                                <linearGradient id="colorHigh" x1="0" y1="0" x2="0" y2="1">
                                                    <stop offset="5%" stopColor={SOC_COLORS.high} stopOpacity={0.8} />
                                                    <stop offset="95%" stopColor={SOC_COLORS.high} stopOpacity={0.2} />
                                                </linearGradient>
                                                <linearGradient id="colorMedium" x1="0" y1="0" x2="0" y2="1">
                                                    <stop offset="5%" stopColor={SOC_COLORS.medium} stopOpacity={0.8} />
                                                    <stop offset="95%" stopColor={SOC_COLORS.medium} stopOpacity={0.2} />
                                                </linearGradient>
                                                <linearGradient id="colorLow" x1="0" y1="0" x2="0" y2="1">
                                                    <stop offset="5%" stopColor={SOC_COLORS.low} stopOpacity={0.8} />
                                                    <stop offset="95%" stopColor={SOC_COLORS.low} stopOpacity={0.2} />
                                                </linearGradient>
                                            </defs>
                                            <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
                                            <XAxis
                                                dataKey="time"
                                                stroke="#9CA3AF"
                                                tick={{ fontSize: 10 }}
                                                interval="preserveStartEnd"
                                            />
                                            <YAxis stroke="#9CA3AF" tick={{ fontSize: 11 }} allowDecimals={false} />
                                            <Tooltip
                                                contentStyle={{
                                                    backgroundColor: '#1F2937',
                                                    border: `1px solid ${SOC_COLORS.border}`,
                                                    borderRadius: 8,
                                                }}
                                                labelStyle={{ color: SOC_COLORS.text }}
                                            />
                                            <Legend
                                                wrapperStyle={{ paddingTop: '10px' }}
                                                iconType="square"
                                            />
                                            <Area
                                                type="monotone"
                                                dataKey="Critical"
                                                stackId="1"
                                                stroke={SOC_COLORS.critical}
                                                fill="url(#colorCritical)"
                                                name="Critical"
                                            />
                                            <Area
                                                type="monotone"
                                                dataKey="High"
                                                stackId="1"
                                                stroke={SOC_COLORS.high}
                                                fill="url(#colorHigh)"
                                                name="High"
                                            />
                                            <Area
                                                type="monotone"
                                                dataKey="Medium"
                                                stackId="1"
                                                stroke={SOC_COLORS.medium}
                                                fill="url(#colorMedium)"
                                                name="Medium"
                                            />
                                            <Area
                                                type="monotone"
                                                dataKey="Low"
                                                stackId="1"
                                                stroke={SOC_COLORS.low}
                                                fill="url(#colorLow)"
                                                name="Low"
                                            />
                                        </AreaChart>
                                    </ResponsiveContainer>
                                </EuiPanel>

                                <EuiSpacer size="m" />

                                {/* Activity Timeline - Visual Heatmap */}
                                <EuiPanel paddingSize="m" style={{
                                    background: 'rgba(15, 23, 42, 0.8)',
                                    border: `1px solid ${SOC_COLORS.border}`,
                                    borderRadius: 12,
                                }}>
                                    <EuiFlexGroup alignItems="center" gutterSize="s">
                                        <EuiFlexItem grow={false}>
                                            <EuiIcon type="clock" size="m" color={SOC_COLORS.active} />
                                        </EuiFlexItem>
                                        <EuiFlexItem>
                                            <EuiTitle size="xs">
                                                <h5 style={{ margin: 0 }}>Activity Timeline</h5>
                                            </EuiTitle>
                                            <EuiText size="xs" color="subdued">
                                                Green = Active • Red = No Activity
                                            </EuiText>
                                        </EuiFlexItem>
                                    </EuiFlexGroup>
                                    <EuiSpacer size="s" />
                                    <div style={{
                                        display: 'flex',
                                        gap: '2px',
                                        flexWrap: 'wrap',
                                        padding: '8px 0'
                                    }}>
                                        {(agentActivityData.points || []).map((point, idx) => (
                                            <div
                                                key={idx}
                                                title={`${point.time}: ${point.isActive ? `Active (${point.Total} alerts)` : 'No Activity'}`}
                                                style={{
                                                    width: agentActivityData.totalIntervals > 24 ? '12px' : '20px',
                                                    height: '24px',
                                                    borderRadius: '4px',
                                                    background: point.isActive
                                                        ? `linear-gradient(180deg, ${SOC_COLORS.active} 0%, #15803D 100%)`
                                                        : `linear-gradient(180deg, ${SOC_COLORS.inactive} 0%, #7F1D1D 100%)`,
                                                    boxShadow: point.isActive
                                                        ? `0 0 8px ${SOC_COLORS.activeGlow}`
                                                        : `0 0 4px rgba(239, 68, 68, 0.3)`,
                                                    cursor: 'pointer',
                                                    transition: 'transform 0.15s ease',
                                                }}
                                                onMouseEnter={(e) => e.target.style.transform = 'scale(1.2)'}
                                                onMouseLeave={(e) => e.target.style.transform = 'scale(1)'}
                                            />
                                        ))}
                                    </div>
                                    <EuiText size="xs" color="subdued" style={{ marginTop: '8px' }}>
                                        ← Oldest {agentActivityData.totalIntervals > 7 ? '(scroll for more)' : ''} → Most Recent
                                    </EuiText>
                                </EuiPanel>

                                {/* Additional Agent Info */}
                                {(selectedAgent.ip || selectedAgent.os) && (
                                    <>
                                        <EuiSpacer size="m" />
                                        <EuiFlexGroup gutterSize="m">
                                            {selectedAgent.ip && (
                                                <EuiFlexItem grow={false}>
                                                    <EuiBadge color="hollow">
                                                        IP: {selectedAgent.ip}
                                                    </EuiBadge>
                                                </EuiFlexItem>
                                            )}
                                            {selectedAgent.os && (
                                                <EuiFlexItem grow={false}>
                                                    <EuiBadge color="hollow">
                                                        OS: {selectedAgent.os}
                                                    </EuiBadge>
                                                </EuiFlexItem>
                                            )}
                                        </EuiFlexGroup>
                                    </>
                                )}
                            </EuiModalBody>
                            <EuiModalFooter>
                                <EuiButton onClick={closeAgentModal} fill>
                                    Close
                                </EuiButton>
                            </EuiModalFooter>
                        </EuiModal>
                    )}

                    {/* CSS animations */}
                    <style>{`
            @keyframes pulse-critical {
              0%, 100% { box-shadow: 0 0 20px ${SOC_COLORS.inactiveGlow}; transform: scale(1); }
              50% { box-shadow: 0 0 35px ${SOC_COLORS.inactiveGlow}; transform: scale(1.03); }
            }
          `}</style>
                </EuiPageBody>
            </EuiPage>
        </EuiErrorBoundary>
    );
};

export default AgentControlCenter;
