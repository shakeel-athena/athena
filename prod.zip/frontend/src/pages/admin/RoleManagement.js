import { useState, useEffect } from 'react';
import {
  EuiPage,
  EuiPageBody,
  EuiPageHeader,
  EuiPanel,
  EuiFlexGroup,
  EuiFlexItem,
  EuiText,
  EuiTitle,
  EuiBadge,
  EuiButton,
  EuiButtonIcon,
  EuiModal,
  EuiModalHeader,
  EuiModalHeaderTitle,
  EuiModalBody,
  EuiModalFooter,
  EuiForm,
  EuiFormRow,
  EuiFieldText,
  EuiFieldNumber,
  EuiTextArea,
  EuiSwitch,
  EuiSpacer,
  EuiLoadingSpinner,
  EuiEmptyPrompt,
  EuiCallOut,
  EuiCard,
  EuiIcon,
  EuiProgress
} from '@elastic/eui';
import { ShieldCheck, Plus, Edit2, Trash2, Copy, Shield, Lock, Eye } from 'lucide-react';
import {
  getRoles,
  createRole,
  updateRole,
  deleteRole,
  getRolePages,
  assignPagesToRole,
  getPages,
  cloneRole
} from '../../services/rbacApi';
import { toast } from 'react-hot-toast';

const RoleManagement = () => {
  const [roles, setRoles] = useState([]);
  const [pages, setPages] = useState([]);
  const [loading, setLoading] = useState(true);
  const [selectedRole, setSelectedRole] = useState(null);
  const [rolePages, setRolePages] = useState([]);
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [showEditModal, setShowEditModal] = useState(false);
  const [showPermissionsModal, setShowPermissionsModal] = useState(false);
  const [showCloneModal, setShowCloneModal] = useState(false);
  const [formData, setFormData] = useState({
    role_name: '',
    display_name: '',
    description: '',
    priority: 0
  });
  const [cloneFormData, setCloneFormData] = useState({
    new_role_name: '',
    new_display_name: '',
    new_description: '',
    copy_permissions: true
  });
  const [selectedPermissions, setSelectedPermissions] = useState({});
  const [actionLoading, setActionLoading] = useState(false);

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    try {
      setLoading(true);
      const [rolesData, pagesData] = await Promise.all([
        getRoles(),
        getPages()
      ]);
      setRoles(rolesData.roles || []);
      setPages(pagesData.pages || []);
    } catch (err) {
      toast.error(`Failed to load data: ${err.message}`);
    } finally {
      setLoading(false);
    }
  };

  const handleSelectRole = async (role) => {
    try {
      setSelectedRole(role);
      const rolePagesData = await getRolePages(role.id);
      setRolePages(rolePagesData.pages || []);
    } catch (err) {
      toast.error(`Failed to load role pages: ${err.message}`);
    }
  };

  const handleCreateRole = async (e) => {
    e.preventDefault();
    try {
      setActionLoading(true);
      await createRole(formData);
      toast.success('Role created successfully');
      await loadData();
      setShowCreateModal(false);
      resetForm();
    } catch (err) {
      toast.error(`Failed to create role: ${err.message}`);
    } finally {
      setActionLoading(false);
    }
  };

  const handleUpdateRole = async (e) => {
    e.preventDefault();
    if (!selectedRole) return;

    try {
      setActionLoading(true);
      await updateRole(selectedRole.id, formData);
      toast.success('Role updated successfully');
      await loadData();
      setShowEditModal(false);
      handleSelectRole({ ...selectedRole, ...formData });
      resetForm();
    } catch (err) {
      toast.error(`Failed to update role: ${err.message}`);
    } finally {
      setActionLoading(false);
    }
  };

  const handleDeleteRole = async (roleId) => {
    if (!window.confirm('Are you sure you want to delete this role?')) return;

    try {
      setActionLoading(true);
      await deleteRole(roleId);
      toast.success('Role deleted successfully');
      await loadData();
      if (selectedRole?.id === roleId) {
        setSelectedRole(null);
        setRolePages([]);
      }
    } catch (err) {
      toast.error(`Failed to delete role: ${err.message}`);
    } finally {
      setActionLoading(false);
    }
  };

  const handleOpenCreateModal = () => {
    resetForm();
    setShowCreateModal(true);
  };

  const handleOpenEditModal = () => {
    if (!selectedRole) return;
    setFormData({
      role_name: selectedRole.role_name,
      display_name: selectedRole.display_name || '',
      description: selectedRole.description || '',
      priority: selectedRole.priority || 0
    });
    setShowEditModal(true);
  };

  const handleOpenPermissionsModal = () => {
    if (!selectedRole) return;

    const permMap = {};
    rolePages.forEach(page => {
      permMap[page.page_id] = {
        can_view: page.can_view,
        can_edit: page.can_edit
      };
    });
    setSelectedPermissions(permMap);
    setShowPermissionsModal(true);
  };

  const handleTogglePermission = (pageId, permType) => {
    setSelectedPermissions(prev => ({
      ...prev,
      [pageId]: {
        can_view: prev[pageId]?.can_view || false,
        can_edit: prev[pageId]?.can_edit || false,
        [permType]: !(prev[pageId]?.[permType] || false)
      }
    }));
  };

  const handleSavePermissions = async () => {
    if (!selectedRole) return;

    try {
      setActionLoading(true);
      const pages = Object.entries(selectedPermissions)
        .filter(([, perms]) => perms.can_view || perms.can_edit)
        .map(([pageId, perms]) => ({
          page_id: parseInt(pageId),
          can_view: perms.can_view,
          can_edit: perms.can_edit
        }));

      await assignPagesToRole(selectedRole.id, pages);
      toast.success('Permissions updated successfully');
      const rolePagesData = await getRolePages(selectedRole.id);
      setRolePages(rolePagesData.pages || []);
      setShowPermissionsModal(false);
    } catch (err) {
      toast.error(`Failed to update permissions: ${err.message}`);
    } finally {
      setActionLoading(false);
    }
  };

  const handleOpenCloneModal = () => {
    if (!selectedRole) return;
    setCloneFormData({
      new_role_name: `${selectedRole.role_name}-copy`,
      new_display_name: `${selectedRole.display_name || selectedRole.role_name} (Copy)`,
      new_description: `Cloned from ${selectedRole.display_name || selectedRole.role_name}`,
      copy_permissions: true
    });
    setShowCloneModal(true);
  };

  const handleCloneRole = async () => {
    if (!selectedRole) return;

    try {
      setActionLoading(true);
      const result = await cloneRole(selectedRole.id, cloneFormData);
      toast.success(`Role cloned successfully! ${result.permissions_copied} permissions copied.`);
      await loadData();
      setShowCloneModal(false);
    } catch (err) {
      toast.error(`Failed to clone role: ${err.message}`);
    } finally {
      setActionLoading(false);
    }
  };

  const resetForm = () => {
    setFormData({
      role_name: '',
      display_name: '',
      description: '',
      priority: 0
    });
  };

  const groupPagesByCategory = () => {
    const grouped = {};
    pages.forEach(page => {
      const cat = page.category || 'Other';
      if (!grouped[cat]) {
        grouped[cat] = [];
      }
      grouped[cat].push(page);
    });
    return grouped;
  };

  if (loading) {
    return (
      <EuiFlexGroup alignItems="center" justifyContent="center" style={{ minHeight: '400px' }}>
        <EuiFlexItem grow={false}>
          <EuiLoadingSpinner size="xl" />
          <EuiSpacer size="m" />
          <EuiText color="subdued">Loading roles...</EuiText>
        </EuiFlexItem>
      </EuiFlexGroup>
    );
  }

  const groupedPages = groupPagesByCategory();

  // Calculate permission stats for selected role
  const permissionStats = rolePages.length > 0 ? {
    total: rolePages.length,
    viewOnly: rolePages.filter(p => p.can_view && !p.can_edit).length,
    editAccess: rolePages.filter(p => p.can_edit).length,
    percentage: Math.round((rolePages.length / pages.length) * 100)
  } : null;

  return (
    <EuiPage paddingSize="none">
      <EuiPageBody>
        {/* Header */}
        <EuiPageHeader
          pageTitle={
            <EuiFlexGroup alignItems="center" gutterSize="s">
              <EuiFlexItem grow={false}>
                <ShieldCheck style={{ width: '32px', height: '32px', color: '#8b5cf6' }} />
              </EuiFlexItem>
              <EuiFlexItem>
                <EuiTitle size="l">
                  <h1>Role Management</h1>
                </EuiTitle>
              </EuiFlexItem>
            </EuiFlexGroup>
          }
          description="Create and manage access roles with granular permissions"
          rightSideItems={[
            <EuiButton
              key="create"
              fill
              iconType={Plus}
              onClick={handleOpenCreateModal}
              color="accent"
            >
              Create New Role
            </EuiButton>
          ]}
        />

        <EuiSpacer size="l" />

        {/* Content */}
        <EuiFlexGroup gutterSize="l">
          {/* Roles Grid */}
          <EuiFlexItem grow={1} style={{ maxWidth: '450px' }}>
            <EuiPanel hasBorder>
              <EuiFlexGroup alignItems="center" justifyContent="spaceBetween">
                <EuiFlexItem>
                  <EuiTitle size="s">
                    <h3>Roles ({roles.length})</h3>
                  </EuiTitle>
                </EuiFlexItem>
                <EuiFlexItem grow={false}>
                  <EuiBadge color="accent">{roles.length} total</EuiBadge>
                </EuiFlexItem>
              </EuiFlexGroup>

              <EuiSpacer size="m" />

              <div style={{ maxHeight: '650px', overflowY: 'auto' }}>
                <EuiFlexGroup direction="column" gutterSize="s">
                  {roles.map(role => (
                    <EuiFlexItem key={role.id}>
                      <EuiPanel
                        color={selectedRole?.id === role.id ? 'primary' : 'subdued'}
                        hasShadow={selectedRole?.id === role.id}
                        paddingSize="m"
                        style={{ cursor: 'pointer', border: selectedRole?.id === role.id ? '2px solid #8b5cf6' : 'none' }}
                        onClick={() => handleSelectRole(role)}
                      >
                        <EuiFlexGroup gutterSize="m" alignItems="center">
                          <EuiFlexItem grow={false}>
                            <Shield style={{ width: '32px', height: '32px', color: selectedRole?.id === role.id ? '#8b5cf6' : '#64748b' }} />
                          </EuiFlexItem>
                          <EuiFlexItem>
                            <EuiText size="s">
                              <strong>{role.display_name || role.role_name}</strong>
                            </EuiText>
                            <EuiText size="xs" color="subdued" style={{ marginTop: '4px' }}>
                              {role.description || 'No description'}
                            </EuiText>
                            <EuiSpacer size="s" />
                            <EuiFlexGroup alignItems="center" justifyContent="flexStart" gutterSize="s">
                              <EuiFlexItem grow={false}>
                                <EuiBadge color="hollow">Priority: {role.priority || 0}</EuiBadge>
                              </EuiFlexItem>
                              <EuiFlexItem grow={false}>
                                <EuiText size="xs" color="subdued">
                                  {new Date(role.created_at).toLocaleDateString()}
                                </EuiText>
                              </EuiFlexItem>
                            </EuiFlexGroup>
                          </EuiFlexItem>
                        </EuiFlexGroup>
                      </EuiPanel>
                    </EuiFlexItem>
                  ))}

                  {roles.length === 0 && (
                    <EuiFlexItem>
                      <EuiEmptyPrompt
                        icon={<ShieldCheck style={{ width: '64px', height: '64px', opacity: 0.3 }} />}
                        title={<h3>No roles created yet</h3>}
                        body={<p>Create your first role to get started with access control.</p>}
                        actions={
                          <EuiButton fill iconType={Plus} onClick={handleOpenCreateModal}>
                            Create First Role
                          </EuiButton>
                        }
                      />
                    </EuiFlexItem>
                  )}
                </EuiFlexGroup>
              </div>
            </EuiPanel>
          </EuiFlexItem>

          {/* Role Details Panel */}
          <EuiFlexItem grow={2}>
            <EuiPanel hasBorder>
              {selectedRole ? (
                <>
                  {/* Header with Actions */}
                  <EuiFlexGroup alignItems="center" justifyContent="spaceBetween">
                    <EuiFlexItem>
                      <EuiFlexGroup alignItems="center" gutterSize="m">
                        <EuiFlexItem grow={false}>
                          <Shield style={{ width: '40px', height: '40px', color: '#8b5cf6' }} />
                        </EuiFlexItem>
                        <EuiFlexItem>
                          <EuiTitle size="m">
                            <h2>{selectedRole.display_name || selectedRole.role_name}</h2>
                          </EuiTitle>
                          <EuiText size="s" color="subdued">
                            {selectedRole.description || 'No description'}
                          </EuiText>
                        </EuiFlexItem>
                      </EuiFlexGroup>
                    </EuiFlexItem>
                    <EuiFlexItem grow={false}>
                      <EuiFlexGroup gutterSize="s">
                        <EuiFlexItem grow={false}>
                          <EuiButton
                            iconType={Edit2}
                            onClick={handleOpenEditModal}
                            isDisabled={actionLoading}
                          >
                            Edit
                          </EuiButton>
                        </EuiFlexItem>
                        <EuiFlexItem grow={false}>
                          <EuiButton
                            iconType={Copy}
                            color="success"
                            onClick={handleOpenCloneModal}
                            isDisabled={actionLoading}
                          >
                            Clone
                          </EuiButton>
                        </EuiFlexItem>
                        <EuiFlexItem grow={false}>
                          <EuiButton
                            iconType={Trash2}
                            color="danger"
                            onClick={() => handleDeleteRole(selectedRole.id)}
                            isDisabled={actionLoading}
                          >
                            Delete
                          </EuiButton>
                        </EuiFlexItem>
                      </EuiFlexGroup>
                    </EuiFlexItem>
                  </EuiFlexGroup>

                  <EuiSpacer size="l" />

                  {/* Role Info Cards */}
                  <EuiFlexGroup gutterSize="m" wrap>
                    <EuiFlexItem style={{ minWidth: '200px' }}>
                      <EuiPanel color="subdued" hasShadow={false}>
                        <EuiFlexGroup alignItems="center" gutterSize="s">
                          <EuiFlexItem grow={false}>
                            <Lock style={{ width: '20px', height: '20px', color: '#3b82f6' }} />
                          </EuiFlexItem>
                          <EuiFlexItem>
                            <EuiText size="xs" color="subdued">ROLE NAME</EuiText>
                            <EuiText size="s">
                              <code>{selectedRole.role_name}</code>
                            </EuiText>
                          </EuiFlexItem>
                        </EuiFlexGroup>
                      </EuiPanel>
                    </EuiFlexItem>

                    <EuiFlexItem style={{ minWidth: '200px' }}>
                      <EuiPanel color="subdued" hasShadow={false}>
                        <EuiFlexGroup alignItems="center" gutterSize="s">
                          <EuiFlexItem grow={false}>
                            <Shield style={{ width: '20px', height: '20px', color: '#8b5cf6' }} />
                          </EuiFlexItem>
                          <EuiFlexItem>
                            <EuiText size="xs" color="subdued">PRIORITY</EuiText>
                            <EuiText size="s">
                              <strong>{selectedRole.priority || 0}</strong>
                            </EuiText>
                          </EuiFlexItem>
                        </EuiFlexGroup>
                      </EuiPanel>
                    </EuiFlexItem>

                    <EuiFlexItem style={{ minWidth: '200px' }}>
                      <EuiPanel color="subdued" hasShadow={false}>
                        <EuiFlexGroup alignItems="center" gutterSize="s">
                          <EuiFlexItem grow={false}>
                            <Eye style={{ width: '20px', height: '20px', color: '#10b981' }} />
                          </EuiFlexItem>
                          <EuiFlexItem>
                            <EuiText size="xs" color="subdued">CREATED</EuiText>
                            <EuiText size="s">
                              {new Date(selectedRole.created_at).toLocaleDateString()}
                            </EuiText>
                          </EuiFlexItem>
                        </EuiFlexGroup>
                      </EuiPanel>
                    </EuiFlexItem>
                  </EuiFlexGroup>

                  <EuiSpacer size="xl" />

                  {/* Permissions Section */}
                  <EuiFlexGroup alignItems="center" justifyContent="spaceBetween">
                    <EuiFlexItem>
                      <EuiTitle size="s">
                        <h3>Page Permissions</h3>
                      </EuiTitle>
                    </EuiFlexItem>
                    <EuiFlexItem grow={false}>
                      <EuiButton
                        iconType="gear"
                        fill
                        onClick={handleOpenPermissionsModal}
                        isDisabled={actionLoading}
                      >
                        Manage Permissions
                      </EuiButton>
                    </EuiFlexItem>
                  </EuiFlexGroup>

                  <EuiSpacer size="m" />

                  {/* Permission Stats */}
                  {permissionStats && (
                    <>
                      <EuiPanel color="primary" hasShadow={false}>
                        <EuiFlexGroup gutterSize="l" wrap>
                          <EuiFlexItem style={{ minWidth: '150px' }}>
                            <EuiText size="xs" color="subdued">TOTAL PAGES</EuiText>
                            <EuiText size="l">
                              <strong>{permissionStats.total}</strong>
                            </EuiText>
                          </EuiFlexItem>
                          <EuiFlexItem style={{ minWidth: '150px' }}>
                            <EuiText size="xs" color="subdued">VIEW ONLY</EuiText>
                            <EuiText size="l">
                              <strong>{permissionStats.viewOnly}</strong>
                            </EuiText>
                          </EuiFlexItem>
                          <EuiFlexItem style={{ minWidth: '150px' }}>
                            <EuiText size="xs" color="subdued">EDIT ACCESS</EuiText>
                            <EuiText size="l">
                              <strong>{permissionStats.editAccess}</strong>
                            </EuiText>
                          </EuiFlexItem>
                          <EuiFlexItem style={{ minWidth: '200px' }}>
                            <EuiText size="xs" color="subdued">COVERAGE</EuiText>
                            <EuiProgress
                              value={permissionStats.percentage}
                              max={100}
                              color="success"
                              size="m"
                            />
                            <EuiText size="xs" color="subdued" style={{ marginTop: '4px' }}>
                              {permissionStats.percentage}% of all pages
                            </EuiText>
                          </EuiFlexItem>
                        </EuiFlexGroup>
                      </EuiPanel>
                      <EuiSpacer size="m" />
                    </>
                  )}

                  {/* Permissions List */}
                  {rolePages.length > 0 ? (
                    <div style={{ maxHeight: '400px', overflowY: 'auto' }}>
                      <EuiFlexGroup direction="column" gutterSize="s">
                        {rolePages.map(page => (
                          <EuiFlexItem key={page.page_id}>
                            <EuiPanel color="subdued" hasShadow={false} paddingSize="m">
                              <EuiFlexGroup alignItems="center" justifyContent="spaceBetween">
                                <EuiFlexItem>
                                  <EuiText size="s">
                                    <code>{page.page_path}</code>
                                  </EuiText>
                                  {page.page_category && (
                                    <EuiBadge color="hollow" style={{ marginTop: '4px' }}>
                                      {page.page_category}
                                    </EuiBadge>
                                  )}
                                </EuiFlexItem>
                                <EuiFlexItem grow={false}>
                                  <EuiFlexGroup gutterSize="m">
                                    <EuiFlexItem grow={false}>
                                      {page.can_view && (
                                        <EuiBadge color="success">View</EuiBadge>
                                      )}
                                    </EuiFlexItem>
                                    <EuiFlexItem grow={false}>
                                      {page.can_edit && (
                                        <EuiBadge color="primary">Edit</EuiBadge>
                                      )}
                                    </EuiFlexItem>
                                  </EuiFlexGroup>
                                </EuiFlexItem>
                              </EuiFlexGroup>
                            </EuiPanel>
                          </EuiFlexItem>
                        ))}
                      </EuiFlexGroup>
                    </div>
                  ) : (
                    <EuiEmptyPrompt
                      iconType="lock"
                      title={<h4>No permissions assigned</h4>}
                      body={<p>This role has no page access permissions configured.</p>}
                      actions={
                        <EuiButton fill onClick={handleOpenPermissionsModal}>
                          Assign Permissions
                        </EuiButton>
                      }
                    />
                  )}
                </>
              ) : (
                <EuiEmptyPrompt
                  icon={<ShieldCheck style={{ width: '64px', height: '64px', opacity: 0.3 }} />}
                  title={<h3>Select a role to view details</h3>}
                  body={<p>Choose a role from the list to manage its permissions and settings.</p>}
                />
              )}
            </EuiPanel>
          </EuiFlexItem>
        </EuiFlexGroup>

        {/* Create Role Modal */}
        {showCreateModal && (
          <EuiModal onClose={() => setShowCreateModal(false)} style={{ minWidth: '600px' }}>
            <EuiModalHeader>
              <EuiModalHeaderTitle>Create New Role</EuiModalHeaderTitle>
            </EuiModalHeader>

            <EuiModalBody>
              <EuiForm component="form" onSubmit={handleCreateRole}>
                <EuiFormRow label="Role Name" helpText="Lowercase with hyphens (e.g., security-analyst)">
                  <EuiFieldText
                    value={formData.role_name}
                    onChange={(e) => setFormData({ ...formData, role_name: e.target.value })}
                    placeholder="e.g., security-analyst"
                    pattern="[a-z0-9-]+"
                    required
                  />
                </EuiFormRow>

                <EuiFormRow label="Display Name">
                  <EuiFieldText
                    value={formData.display_name}
                    onChange={(e) => setFormData({ ...formData, display_name: e.target.value })}
                    placeholder="e.g., Security Analyst"
                    required
                  />
                </EuiFormRow>

                <EuiFormRow label="Description">
                  <EuiTextArea
                    value={formData.description}
                    onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                    placeholder="Brief description of this role"
                    rows={3}
                  />
                </EuiFormRow>

                <EuiFormRow label="Priority" helpText="Higher values = more important">
                  <EuiFieldNumber
                    value={formData.priority}
                    onChange={(e) => setFormData({ ...formData, priority: parseInt(e.target.value) || 0 })}
                    min={0}
                    max={100}
                  />
                </EuiFormRow>
              </EuiForm>
            </EuiModalBody>

            <EuiModalFooter>
              <EuiButton onClick={() => setShowCreateModal(false)} isDisabled={actionLoading}>
                Cancel
              </EuiButton>
              <EuiButton fill onClick={handleCreateRole} isLoading={actionLoading}>
                Create Role
              </EuiButton>
            </EuiModalFooter>
          </EuiModal>
        )}

        {/* Edit Role Modal */}
        {showEditModal && (
          <EuiModal onClose={() => setShowEditModal(false)} style={{ minWidth: '600px' }}>
            <EuiModalHeader>
              <EuiModalHeaderTitle>Edit Role</EuiModalHeaderTitle>
            </EuiModalHeader>

            <EuiModalBody>
              <EuiForm component="form" onSubmit={handleUpdateRole}>
                <EuiFormRow label="Role Name" helpText="Cannot be changed">
                  <EuiFieldText
                    value={formData.role_name}
                    disabled
                  />
                </EuiFormRow>

                <EuiFormRow label="Display Name">
                  <EuiFieldText
                    value={formData.display_name}
                    onChange={(e) => setFormData({ ...formData, display_name: e.target.value })}
                    required
                  />
                </EuiFormRow>

                <EuiFormRow label="Description">
                  <EuiTextArea
                    value={formData.description}
                    onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                    rows={3}
                  />
                </EuiFormRow>

                <EuiFormRow label="Priority">
                  <EuiFieldNumber
                    value={formData.priority}
                    onChange={(e) => setFormData({ ...formData, priority: parseInt(e.target.value) || 0 })}
                    min={0}
                    max={100}
                  />
                </EuiFormRow>
              </EuiForm>
            </EuiModalBody>

            <EuiModalFooter>
              <EuiButton onClick={() => setShowEditModal(false)} isDisabled={actionLoading}>
                Cancel
              </EuiButton>
              <EuiButton fill onClick={handleUpdateRole} isLoading={actionLoading}>
                Update Role
              </EuiButton>
            </EuiModalFooter>
          </EuiModal>
        )}

        {/* Clone Role Modal */}
        {showCloneModal && (
          <EuiModal onClose={() => setShowCloneModal(false)} style={{ minWidth: '600px' }}>
            <EuiModalHeader>
              <EuiModalHeaderTitle>Clone Role: {selectedRole?.display_name}</EuiModalHeaderTitle>
            </EuiModalHeader>

            <EuiModalBody>
              <EuiCallOut
                title="Clone Role"
                color="primary"
                iconType={Copy}
              >
                <p>
                  This will create a copy of <strong>{selectedRole?.display_name}</strong> with all its permissions.
                </p>
              </EuiCallOut>

              <EuiSpacer size="m" />

              <EuiForm>
                <EuiFormRow label="New Role Name" helpText="Use lowercase with hyphens">
                  <EuiFieldText
                    value={cloneFormData.new_role_name}
                    onChange={(e) => setCloneFormData({ ...cloneFormData, new_role_name: e.target.value })}
                    placeholder="e.g., junior-analyst-v2"
                    required
                  />
                </EuiFormRow>

                <EuiFormRow label="New Display Name">
                  <EuiFieldText
                    value={cloneFormData.new_display_name}
                    onChange={(e) => setCloneFormData({ ...cloneFormData, new_display_name: e.target.value })}
                    placeholder="e.g., Junior Analyst V2"
                    required
                  />
                </EuiFormRow>

                <EuiFormRow label="Description">
                  <EuiTextArea
                    value={cloneFormData.new_description}
                    onChange={(e) => setCloneFormData({ ...cloneFormData, new_description: e.target.value })}
                    rows={3}
                    placeholder="Describe this role..."
                  />
                </EuiFormRow>

                <EuiFormRow>
                  <EuiSwitch
                    label={`Copy all page permissions from the source role (${rolePages.length} permissions)`}
                    checked={cloneFormData.copy_permissions}
                    onChange={(e) => setCloneFormData({ ...cloneFormData, copy_permissions: e.target.checked })}
                  />
                </EuiFormRow>
              </EuiForm>
            </EuiModalBody>

            <EuiModalFooter>
              <EuiButton onClick={() => setShowCloneModal(false)} isDisabled={actionLoading}>
                Cancel
              </EuiButton>
              <EuiButton
                fill
                iconType={Copy}
                color="success"
                onClick={handleCloneRole}
                isLoading={actionLoading}
                isDisabled={!cloneFormData.new_role_name || !cloneFormData.new_display_name}
              >
                Clone Role
              </EuiButton>
            </EuiModalFooter>
          </EuiModal>
        )}

        {/* Permissions Modal */}
        {showPermissionsModal && (
          <EuiModal onClose={() => setShowPermissionsModal(false)} style={{ minWidth: '800px', maxWidth: '90vw' }}>
            <EuiModalHeader>
              <EuiModalHeaderTitle>
                Manage Permissions for {selectedRole?.display_name}
              </EuiModalHeaderTitle>
            </EuiModalHeader>

            <EuiModalBody>
              <EuiFlexGroup direction="column" gutterSize="m">
                {Object.entries(groupedPages).map(([category, categoryPages]) => (
                  <EuiFlexItem key={category}>
                    <EuiPanel color="subdued" hasShadow={false}>
                      <EuiTitle size="xs">
                        <h4>{category}</h4>
                      </EuiTitle>
                      <EuiSpacer size="s" />
                      <EuiFlexGroup direction="column" gutterSize="xs">
                        {categoryPages.map(page => (
                          <EuiFlexItem key={page.id}>
                            <EuiPanel color="transparent" hasShadow={false} paddingSize="s">
                              <EuiFlexGroup alignItems="center" justifyContent="spaceBetween">
                                <EuiFlexItem>
                                  <EuiText size="s">{page.page_name}</EuiText>
                                  <EuiText size="xs" color="subdued">
                                    <code>{page.page_path}</code>
                                  </EuiText>
                                </EuiFlexItem>
                                <EuiFlexItem grow={false}>
                                  <EuiFlexGroup gutterSize="m">
                                    <EuiFlexItem grow={false}>
                                      <EuiSwitch
                                        label="View"
                                        checked={selectedPermissions[page.id]?.can_view || false}
                                        onChange={() => handleTogglePermission(page.id, 'can_view')}
                                        compressed
                                      />
                                    </EuiFlexItem>
                                    <EuiFlexItem grow={false}>
                                      <EuiSwitch
                                        label="Edit"
                                        checked={selectedPermissions[page.id]?.can_edit || false}
                                        onChange={() => handleTogglePermission(page.id, 'can_edit')}
                                        compressed
                                      />
                                    </EuiFlexItem>
                                  </EuiFlexGroup>
                                </EuiFlexItem>
                              </EuiFlexGroup>
                            </EuiPanel>
                          </EuiFlexItem>
                        ))}
                      </EuiFlexGroup>
                    </EuiPanel>
                  </EuiFlexItem>
                ))}
              </EuiFlexGroup>
            </EuiModalBody>

            <EuiModalFooter>
              <EuiButton onClick={() => setShowPermissionsModal(false)} isDisabled={actionLoading}>
                Cancel
              </EuiButton>
              <EuiButton fill iconType="save" onClick={handleSavePermissions} isLoading={actionLoading}>
                Save Permissions
              </EuiButton>
            </EuiModalFooter>
          </EuiModal>
        )}
      </EuiPageBody>
    </EuiPage>
  );
};

export default RoleManagement;
