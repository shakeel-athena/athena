import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import {
  EuiPage,
  EuiPageBody,
  EuiPageHeader,
  EuiFlexGroup,
  EuiFlexItem,
  EuiPanel,
  EuiStat,
  EuiButton,
  EuiButtonEmpty,
  EuiFieldText,
  EuiFormRow,
  EuiCheckbox,
  EuiText,
  EuiSpacer,
  EuiEmptyPrompt,
  EuiLoadingSpinner,
  EuiBadge,
  EuiIcon,
  EuiTitle,
  EuiCallOut,
  EuiTextColor
} from '@elastic/eui';
import GeoRestrictionsModal from '../components/GeoRestrictionsModal';
import {
  Shield,
  Plus,
  Trash2,
  AlertTriangle,
  CheckCircle,
  XCircle,
  RefreshCw,
  Globe,
  MapPin,
  Lock
} from 'lucide-react';
import { toast } from 'react-hot-toast';
import {
  fetchAllIpSets,
  addToAllowList,
  addToBlockList,
  removeFromAllowList,
  removeFromBlockList,
  transferIp
} from '../services/api';

// Drag and Drop imports
import {
  DndContext,
  DragOverlay,
  PointerSensor,
  KeyboardSensor,
  useSensor,
  useSensors,
  useDraggable,
  useDroppable,
  closestCenter
} from '@dnd-kit/core';
import { restrictToWindowEdges } from '@dnd-kit/modifiers';
import { GripVertical } from 'lucide-react';

// Draggable IP Item Component
const DraggableIpItem = ({
  ip,
  isAllow,
  isSelected,
  onToggleSelection,
  index
}) => {
  const {
    attributes,
    listeners,
    setNodeRef,
    transform,
    isDragging,
  } = useDraggable({
    id: `${isAllow ? 'allow' : 'block'}-${ip}`,
    data: {
      ip,
      sourceList: isAllow ? 'allow' : 'block'
    }
  });

  const style = transform ? {
    transform: `translate3d(${transform.x}px, ${transform.y}px, 0)`,
  } : undefined;

  return (
    <div
      ref={setNodeRef}
      style={style}
    >
      <EuiPanel
        paddingSize="s"
        hasBorder
        style={{
          marginBottom: '8px',
          opacity: isDragging ? 0 : 1
        }}
      >
        <EuiFlexGroup alignItems="center" gutterSize="s" responsive={false}>
          <EuiFlexItem grow={false} style={{ width: '40px' }}>
            <EuiCheckbox
              id={`checkbox-${isAllow ? 'allow' : 'block'}-${index}`}
              checked={isSelected}
              onChange={() => onToggleSelection(ip)}
            />
          </EuiFlexItem>
          <EuiFlexItem>
            <EuiText size="s" style={{ fontFamily: 'monospace' }}>
              {ip}
            </EuiText>
          </EuiFlexItem>
          <EuiFlexItem grow={false} style={{ width: '100px' }}>
            <EuiBadge color={isAllow ? 'success' : 'danger'}>
              {isAllow ? 'Allowed' : 'Blocked'}
            </EuiBadge>
          </EuiFlexItem>
          <EuiFlexItem
            grow={false}
            style={{ width: '32px', cursor: 'grab' }}
            {...listeners}
            {...attributes}
          >
            <GripVertical style={{ width: '16px', height: '16px', color: '#69707D' }} />
          </EuiFlexItem>
        </EuiFlexGroup>
      </EuiPanel>
    </div>
  );
};

// Droppable List Container Component
const DroppableListContainer = ({
  id,
  children,
  style = {}
}) => {
  const { isOver, setNodeRef } = useDroppable({
    id: id,
  });

  return (
    <div
      ref={setNodeRef}
      style={{
        ...style,
        backgroundColor: isOver ? 'rgba(0, 119, 204, 0.1)' : 'transparent',
        border: isOver ? '2px solid #0077cc' : '2px solid transparent',
        borderRadius: '8px',
        transition: 'all 0.2s',
        padding: '8px'
      }}
    >
      {children}
    </div>
  );
};

const Firewall = () => {
  const [selectedAllowIps, setSelectedAllowIps] = useState([]);
  const [selectedBlockIps, setSelectedBlockIps] = useState([]);
  const [newAllowIp, setNewAllowIp] = useState('');
  const [newBlockIp, setNewBlockIp] = useState('');
  const [isAddingToAllow, setIsAddingToAllow] = useState(false);
  const [isAddingToBlock, setIsAddingToBlock] = useState(false);
  const [isGeoModalOpen, setIsGeoModalOpen] = useState(false);

  // Drag and drop state
  const [activeId, setActiveId] = useState(null);
  const [draggedItem, setDraggedItem] = useState(null);

  const queryClient = useQueryClient();

  // Fetch IP sets data
  const { data: ipSetsData, isLoading, error, refetch } = useQuery({
    queryKey: ['ipSets'],
    queryFn: fetchAllIpSets,
    refetchInterval: 10000,
  });

  // Mutations for adding/removing IPs
  const addToAllowMutation = useMutation({
    mutationFn: addToAllowList,
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['ipSets'] });
      toast.success('Successfully added IP(s) to allow list');
      setNewAllowIp('');
      setIsAddingToAllow(false);
    },
    onError: (error) => {
      toast.error(`Failed to add to allow list: ${error.message}`);
    },
  });

  const addToBlockMutation = useMutation({
    mutationFn: addToBlockList,
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['ipSets'] });
      toast.success('Successfully added IP(s) to block list');
      setNewBlockIp('');
      setIsAddingToBlock(false);
    },
    onError: (error) => {
      toast.error(`Failed to add to block list: ${error.message}`);
    },
  });

  const removeFromAllowMutation = useMutation({
    mutationFn: removeFromAllowList,
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['ipSets'] });
      toast.success('Successfully removed IP(s) from allow list');
      setSelectedAllowIps([]);
    },
    onError: (error) => {
      toast.error(`Failed to remove from allow list: ${error.message}`);
    },
  });

  const removeFromBlockMutation = useMutation({
    mutationFn: removeFromBlockList,
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['ipSets'] });
      toast.success('Successfully removed IP(s) from block list');
      setSelectedBlockIps([]);
    },
    onError: (error) => {
      toast.error(`Failed to remove from block list: ${error.message}`);
    },
  });

  // Transfer IP mutation
  const transferIpMutation = useMutation({
    mutationFn: ({ ip, fromList, toList }) => transferIp(ip, fromList, toList),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['ipSets'] });
      toast.success('Successfully transferred IP between lists');
    },
    onError: (error) => {
      queryClient.invalidateQueries({ queryKey: ['ipSets'] });
      toast.error(`Failed to transfer IP: ${error.message}`);
    },
  });

  // Drag and drop sensors
  const sensors = useSensors(
    useSensor(PointerSensor, {
      activationConstraint: {
        distance: 8,
      },
    }),
    useSensor(KeyboardSensor)
  );

  // Drag and drop handlers
  const handleDragStart = (event) => {
    const { active } = event;
    setActiveId(active.id);
    setDraggedItem(active.data.current);
  };

  const handleDragEnd = (event) => {
    const { active, over } = event;

    setActiveId(null);
    setDraggedItem(null);

    if (!over || active.id === over.id) {
      return;
    }

    const draggedData = active.data.current;
    const sourceList = draggedData?.sourceList;
    const targetList = over.id === 'allow-drop-zone' ? 'allow' : 'block';

    if (sourceList && sourceList !== targetList) {
      queryClient.setQueryData({ queryKey: ['ipSets'] }, (oldData) => {
        if (!oldData) return oldData;

        const newData = { ...oldData };
        const allowList = [...(newData.data?.allow_list || [])];
        const blockList = [...(newData.data?.block_list || [])];

        if (sourceList === 'allow') {
          const index = allowList.indexOf(draggedData.ip);
          if (index > -1) allowList.splice(index, 1);
        } else {
          const index = blockList.indexOf(draggedData.ip);
          if (index > -1) blockList.splice(index, 1);
        }

        if (targetList === 'allow') {
          allowList.push(draggedData.ip);
        } else {
          blockList.push(draggedData.ip);
        }

        newData.data = {
          ...newData.data,
          allow_list: allowList,
          block_list: blockList
        };

        return newData;
      });

      transferIpMutation.mutate({
        ip: draggedData.ip,
        fromList: sourceList,
        toList: targetList
      });
    }
  };

  // Helper functions
  const validateIp = (ip) => {
    const ipRegex = /^(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)(?:\/(?:[0-9]|[1-2][0-9]|3[0-2]))?$/;
    return ipRegex.test(ip.trim());
  };

  const handleAddToAllow = () => {
    const ips = newAllowIp.split(',').map(ip => ip.trim()).filter(ip => ip);
    const invalidIps = ips.filter(ip => !validateIp(ip));

    if (invalidIps.length > 0) {
      toast.error(`Invalid IP address(es): ${invalidIps.join(', ')}`);
      return;
    }

    if (ips.length === 0) {
      toast.error('Please enter at least one IP address');
      return;
    }

    addToAllowMutation.mutate(ips);
  };

  const handleAddToBlock = () => {
    const ips = newBlockIp.split(',').map(ip => ip.trim()).filter(ip => ip);
    const invalidIps = ips.filter(ip => !validateIp(ip));

    if (invalidIps.length > 0) {
      toast.error(`Invalid IP address(es): ${invalidIps.join(', ')}`);
      return;
    }

    if (ips.length === 0) {
      toast.error('Please enter at least one IP address');
      return;
    }

    addToBlockMutation.mutate(ips);
  };

  const handleRemoveFromAllow = () => {
    if (selectedAllowIps.length === 0) {
      toast.error('Please select IPs to remove');
      return;
    }
    removeFromAllowMutation.mutate(selectedAllowIps);
  };

  const handleRemoveFromBlock = () => {
    if (selectedBlockIps.length === 0) {
      toast.error('Please select IPs to remove');
      return;
    }
    removeFromBlockMutation.mutate(selectedBlockIps);
  };

  const toggleAllowIpSelection = (ip) => {
    setSelectedAllowIps(prev =>
      prev.includes(ip)
        ? prev.filter(selected => selected !== ip)
        : [...prev, ip]
    );
  };

  const toggleBlockIpSelection = (ip) => {
    setSelectedBlockIps(prev =>
      prev.includes(ip)
        ? prev.filter(selected => selected !== ip)
        : [...prev, ip]
    );
  };

  if (isLoading) {
    return (
      <EuiPage paddingSize="none">
        <EuiPageBody panelled>
          <EuiEmptyPrompt
            icon={<EuiLoadingSpinner size="xl" />}
            title={<h2>Loading firewall configuration...</h2>}
            body={<EuiText size="s" color="subdued">Fetching IP sets and firewall rules</EuiText>}
          />
        </EuiPageBody>
      </EuiPage>
    );
  }

  if (error) {
    return (
      <EuiPage paddingSize="none">
        <EuiPageBody panelled>
          <EuiEmptyPrompt
            icon={<AlertTriangle style={{ width: '48px', height: '48px', color: '#BD271E' }} />}
            title={<h2>Failed to load firewall data</h2>}
            body={
              <EuiText size="s" color="subdued">
                Please check your connection and try again.
              </EuiText>
            }
            actions={
              <EuiButton onClick={refetch} color="primary" fill iconType="refresh">
                Retry
              </EuiButton>
            }
          />
        </EuiPageBody>
      </EuiPage>
    );
  }

  const allowList = ipSetsData?.allow_list || [];
  const blockList = ipSetsData?.block_list || [];

  return (
    <DndContext
      sensors={sensors}
      onDragStart={handleDragStart}
      onDragEnd={handleDragEnd}
      modifiers={[restrictToWindowEdges]}
      collisionDetection={closestCenter}
    >
      <EuiPage paddingSize="none">
        <EuiPageBody panelled>
          {/* Page Header */}
          <EuiPageHeader
            pageTitle={
              <EuiFlexGroup gutterSize="s" alignItems="center" responsive={false}>
                <EuiFlexItem grow={false}>
                  <Shield style={{ width: '28px', height: '28px', color: '#3b82f6' }} />
                </EuiFlexItem>
                <EuiFlexItem>Firewall Management</EuiFlexItem>
              </EuiFlexGroup>
            }
            description="Manage IP addresses and configure firewall rules"
            rightSideItems={[
              <EuiButton
                key="geo-restrictions"
                onClick={() => setIsGeoModalOpen(true)}
                iconType="globe"
                fill
              >
                Geo Restrictions
              </EuiButton>
            ]}
          />

          <EuiSpacer size="l" />

          {/* Summary Stats */}
          <EuiFlexGroup gutterSize="l">
            <EuiFlexItem>
              <EuiPanel hasBorder paddingSize="l">
                <EuiFlexGroup alignItems="center" gutterSize="m" responsive={false}>
                  <EuiFlexItem grow={false}>
                    <div style={{
                      width: '48px',
                      height: '48px',
                      background: 'linear-gradient(135deg, rgba(0, 191, 179, 0.2), rgba(0, 191, 179, 0.1))',
                      borderRadius: '12px',
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'center',
                      border: '1px solid rgba(0, 191, 179, 0.4)'
                    }}>
                      <CheckCircle style={{ width: '24px', height: '24px', color: '#00bfb3' }} />
                    </div>
                  </EuiFlexItem>
                  <EuiFlexItem>
                    <EuiStat
                      title={allowList.length.toString()}
                      description="Allow List"
                      titleColor="success"
                      titleSize="l"
                      textAlign="left"
                    >
                      <EuiText size="s" color="subdued">Permitted IP addresses</EuiText>
                    </EuiStat>
                  </EuiFlexItem>
                </EuiFlexGroup>
              </EuiPanel>
            </EuiFlexItem>

            <EuiFlexItem>
              <EuiPanel hasBorder paddingSize="l">
                <EuiFlexGroup alignItems="center" gutterSize="m" responsive={false}>
                  <EuiFlexItem grow={false}>
                    <div style={{
                      width: '48px',
                      height: '48px',
                      background: 'linear-gradient(135deg, rgba(189, 39, 30, 0.2), rgba(189, 39, 30, 0.1))',
                      borderRadius: '12px',
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'center',
                      border: '1px solid rgba(189, 39, 30, 0.4)'
                    }}>
                      <XCircle style={{ width: '24px', height: '24px', color: '#BD271E' }} />
                    </div>
                  </EuiFlexItem>
                  <EuiFlexItem>
                    <EuiStat
                      title={blockList.length.toString()}
                      description="Block List"
                      titleColor="danger"
                      titleSize="l"
                      textAlign="left"
                    >
                      <EuiText size="s" color="subdued">Blocked IP addresses</EuiText>
                    </EuiStat>
                  </EuiFlexItem>
                </EuiFlexGroup>
              </EuiPanel>
            </EuiFlexItem>
          </EuiFlexGroup>

          <EuiSpacer size="l" />

          {/* IP Lists - Two Column Layout */}
          <EuiFlexGroup gutterSize="l" alignItems="flexStart">

            {/* Allow List Section */}
            <EuiFlexItem>
              <EuiPanel hasBorder paddingSize="none">
                {/* Header */}
                <div style={{ padding: '16px', borderBottom: '1px solid #D3DAE6' }}>
                  <EuiFlexGroup alignItems="center" justifyContent="spaceBetween" responsive={false}>
                    <EuiFlexItem grow={false}>
                      <EuiFlexGroup gutterSize="s" alignItems="center" responsive={false}>
                        <EuiFlexItem grow={false}>
                          <CheckCircle style={{ width: '20px', height: '20px', color: '#00bfb3' }} />
                        </EuiFlexItem>
                        <EuiFlexItem>
                          <EuiTitle size="s">
                            <h3>Allow List</h3>
                          </EuiTitle>
                        </EuiFlexItem>
                      </EuiFlexGroup>
                    </EuiFlexItem>
                    <EuiFlexItem grow={false}>
                      <EuiFlexGroup gutterSize="s" responsive={false}>
                        {selectedAllowIps.length > 0 && (
                          <EuiFlexItem grow={false}>
                            <EuiButton
                              onClick={handleRemoveFromAllow}
                              isLoading={removeFromAllowMutation.isLoading}
                              color="danger"
                              size="s"
                            >
                              <Trash2 style={{ width: '14px', height: '14px', marginRight: '6px' }} />
                              Remove ({selectedAllowIps.length})
                            </EuiButton>
                          </EuiFlexItem>
                        )}
                        <EuiFlexItem grow={false}>
                          <EuiButton
                            onClick={() => setIsAddingToAllow(!isAddingToAllow)}
                            color="success"
                            fill
                            size="s"
                          >
                            <Plus style={{ width: '14px', height: '14px', marginRight: '6px' }} />
                            Add IP
                          </EuiButton>
                        </EuiFlexItem>
                      </EuiFlexGroup>
                    </EuiFlexItem>
                  </EuiFlexGroup>
                </div>

                {/* Add IP Form */}
                {isAddingToAllow && (
                  <div style={{ padding: '16px', backgroundColor: '#F5F7FA', borderBottom: '1px solid #D3DAE6' }}>
                    <EuiFormRow
                      label="IP Address(es)"
                      helpText="Enter IP address(es) separated by commas (e.g., 192.168.1.1, 10.0.0.0/24)"
                      fullWidth
                    >
                      <EuiFieldText
                        value={newAllowIp}
                        onChange={(e) => setNewAllowIp(e.target.value)}
                        placeholder="192.168.1.1, 10.0.0.0/24"
                        fullWidth
                      />
                    </EuiFormRow>
                    <EuiSpacer size="m" />
                    <EuiFlexGroup gutterSize="s" responsive={false}>
                      <EuiFlexItem grow={false}>
                        <EuiButton
                          onClick={handleAddToAllow}
                          isLoading={addToAllowMutation.isLoading}
                          isDisabled={!newAllowIp.trim()}
                          color="success"
                          fill
                          size="s"
                        >
                          Add
                        </EuiButton>
                      </EuiFlexItem>
                      <EuiFlexItem grow={false}>
                        <EuiButtonEmpty
                          onClick={() => setIsAddingToAllow(false)}
                          size="s"
                        >
                          Cancel
                        </EuiButtonEmpty>
                      </EuiFlexItem>
                    </EuiFlexGroup>
                  </div>
                )}

                {/* List Content */}
                <div style={{ padding: '16px' }}>
                  {allowList.length === 0 ? (
                    <EuiEmptyPrompt
                      icon={<Globe style={{ width: '48px', height: '48px', color: '#69707D', opacity: 0.5 }} />}
                      title={<h3>No IP addresses in allow list</h3>}
                      body={<EuiText size="s" color="subdued">Add IP addresses to permit network access</EuiText>}
                    />
                  ) : (
                    <div>
                      {/* Header Row */}
                      <EuiPanel color="subdued" paddingSize="s" style={{ marginBottom: '8px' }}>
                        <EuiFlexGroup alignItems="center" gutterSize="s" responsive={false}>
                          <EuiFlexItem grow={false} style={{ width: '40px' }}>
                            <EuiCheckbox
                              id="select-all-allow"
                              checked={selectedAllowIps.length === allowList.length && allowList.length > 0}
                              onChange={(e) => {
                                if (e.target.checked) {
                                  setSelectedAllowIps([...allowList]);
                                } else {
                                  setSelectedAllowIps([]);
                                }
                              }}
                            />
                          </EuiFlexItem>
                          <EuiFlexItem>
                            <EuiText size="s"><strong>IP Address</strong></EuiText>
                          </EuiFlexItem>
                          <EuiFlexItem grow={false} style={{ width: '100px' }}>
                            <EuiText size="s"><strong>Status</strong></EuiText>
                          </EuiFlexItem>
                          <EuiFlexItem grow={false} style={{ width: '32px' }} />
                        </EuiFlexGroup>
                      </EuiPanel>

                      {/* Scrollable List */}
                      <DroppableListContainer
                        id="allow-drop-zone"
                        style={{ maxHeight: '500px', overflowY: 'auto' }}
                      >
                        {allowList.map((ip, index) => (
                          <DraggableIpItem
                            key={index}
                            ip={ip}
                            isAllow={true}
                            isSelected={selectedAllowIps.includes(ip)}
                            onToggleSelection={toggleAllowIpSelection}
                            index={index}
                          />
                        ))}

                        {allowList.length > 10 && (
                          <EuiText size="xs" textAlign="center" color="subdued" style={{ paddingTop: '8px' }}>
                            {allowList.length} total IP addresses
                          </EuiText>
                        )}
                      </DroppableListContainer>
                    </div>
                  )}
                </div>
              </EuiPanel>
            </EuiFlexItem>

            {/* Block List Section */}
            <EuiFlexItem>
              <EuiPanel hasBorder paddingSize="none">
                {/* Header */}
                <div style={{ padding: '16px', borderBottom: '1px solid #D3DAE6' }}>
                  <EuiFlexGroup alignItems="center" justifyContent="spaceBetween" responsive={false}>
                    <EuiFlexItem grow={false}>
                      <EuiFlexGroup gutterSize="s" alignItems="center" responsive={false}>
                        <EuiFlexItem grow={false}>
                          <XCircle style={{ width: '20px', height: '20px', color: '#BD271E' }} />
                        </EuiFlexItem>
                        <EuiFlexItem>
                          <EuiTitle size="s">
                            <h3>Block List</h3>
                          </EuiTitle>
                        </EuiFlexItem>
                      </EuiFlexGroup>
                    </EuiFlexItem>
                    <EuiFlexItem grow={false}>
                      <EuiFlexGroup gutterSize="s" responsive={false}>
                        {selectedBlockIps.length > 0 && (
                          <EuiFlexItem grow={false}>
                            <EuiButton
                              onClick={handleRemoveFromBlock}
                              isLoading={removeFromBlockMutation.isLoading}
                              color="danger"
                              size="s"
                            >
                              <Trash2 style={{ width: '14px', height: '14px', marginRight: '6px' }} />
                              Remove ({selectedBlockIps.length})
                            </EuiButton>
                          </EuiFlexItem>
                        )}
                        <EuiFlexItem grow={false}>
                          <EuiButton
                            onClick={() => setIsAddingToBlock(!isAddingToBlock)}
                            color="success"
                            fill
                            size="s"
                          >
                            <Plus style={{ width: '14px', height: '14px', marginRight: '6px' }} />
                            Add IP
                          </EuiButton>
                        </EuiFlexItem>
                      </EuiFlexGroup>
                    </EuiFlexItem>
                  </EuiFlexGroup>
                </div>

                {/* Add IP Form */}
                {isAddingToBlock && (
                  <div style={{ padding: '16px', backgroundColor: '#F5F7FA', borderBottom: '1px solid #D3DAE6' }}>
                    <EuiFormRow
                      label="IP Address(es)"
                      helpText="Enter IP address(es) separated by commas (e.g., 192.168.1.1, 10.0.0.0/24)"
                      fullWidth
                    >
                      <EuiFieldText
                        value={newBlockIp}
                        onChange={(e) => setNewBlockIp(e.target.value)}
                        placeholder="192.168.1.1, 10.0.0.0/24"
                        fullWidth
                      />
                    </EuiFormRow>
                    <EuiSpacer size="m" />
                    <EuiFlexGroup gutterSize="s" responsive={false}>
                      <EuiFlexItem grow={false}>
                        <EuiButton
                          onClick={handleAddToBlock}
                          isLoading={addToBlockMutation.isLoading}
                          isDisabled={!newBlockIp.trim()}
                          color="success"
                          fill
                          size="s"
                        >
                          Add
                        </EuiButton>
                      </EuiFlexItem>
                      <EuiFlexItem grow={false}>
                        <EuiButtonEmpty
                          onClick={() => setIsAddingToBlock(false)}
                          size="s"
                        >
                          Cancel
                        </EuiButtonEmpty>
                      </EuiFlexItem>
                    </EuiFlexGroup>
                  </div>
                )}

                {/* List Content */}
                <div style={{ padding: '16px' }}>
                  {blockList.length === 0 ? (
                    <EuiEmptyPrompt
                      icon={<Lock style={{ width: '48px', height: '48px', color: '#69707D', opacity: 0.5 }} />}
                      title={<h3>No IP addresses in block list</h3>}
                      body={<EuiText size="s" color="subdued">Add IP addresses to deny network access</EuiText>}
                    />
                  ) : (
                    <div>
                      {/* Header Row */}
                      <EuiPanel color="subdued" paddingSize="s" style={{ marginBottom: '8px' }}>
                        <EuiFlexGroup alignItems="center" gutterSize="s" responsive={false}>
                          <EuiFlexItem grow={false} style={{ width: '40px' }}>
                            <EuiCheckbox
                              id="select-all-block"
                              checked={selectedBlockIps.length === blockList.length && blockList.length > 0}
                              onChange={(e) => {
                                if (e.target.checked) {
                                  setSelectedBlockIps([...blockList]);
                                } else {
                                  setSelectedBlockIps([]);
                                }
                              }}
                            />
                          </EuiFlexItem>
                          <EuiFlexItem>
                            <EuiText size="s"><strong>IP Address</strong></EuiText>
                          </EuiFlexItem>
                          <EuiFlexItem grow={false} style={{ width: '100px' }}>
                            <EuiText size="s"><strong>Status</strong></EuiText>
                          </EuiFlexItem>
                          <EuiFlexItem grow={false} style={{ width: '32px' }} />
                        </EuiFlexGroup>
                      </EuiPanel>

                      {/* Scrollable List */}
                      <DroppableListContainer
                        id="block-drop-zone"
                        style={{ maxHeight: '500px', overflowY: 'auto' }}
                      >
                        {blockList.map((ip, index) => (
                          <DraggableIpItem
                            key={index}
                            ip={ip}
                            isAllow={false}
                            isSelected={selectedBlockIps.includes(ip)}
                            onToggleSelection={toggleBlockIpSelection}
                            index={index}
                          />
                        ))}

                        {blockList.length > 10 && (
                          <EuiText size="xs" textAlign="center" color="subdued" style={{ paddingTop: '8px' }}>
                            {blockList.length} total IP addresses
                          </EuiText>
                        )}
                      </DroppableListContainer>
                    </div>
                  )}
                </div>
              </EuiPanel>
            </EuiFlexItem>
          </EuiFlexGroup>

          {/* Geo Restrictions Modal */}
          <GeoRestrictionsModal
            isOpen={isGeoModalOpen}
            onClose={() => setIsGeoModalOpen(false)}
          />

          {/* Drag Overlay */}
          <DragOverlay>
            {activeId && draggedItem ? (
              <EuiPanel paddingSize="s" hasBorder style={{ opacity: 0.9, boxShadow: '0 4px 12px rgba(0,0,0,0.15)' }}>
                <EuiFlexGroup alignItems="center" gutterSize="s" responsive={false}>
                  <EuiFlexItem grow={false} style={{ width: '40px' }}>
                    <EuiCheckbox id="drag-overlay-checkbox" checked readOnly />
                  </EuiFlexItem>
                  <EuiFlexItem>
                    <EuiText size="s" style={{ fontFamily: 'monospace' }}>
                      {draggedItem.ip}
                    </EuiText>
                  </EuiFlexItem>
                  <EuiFlexItem grow={false} style={{ width: '100px' }}>
                    <EuiBadge color={draggedItem.sourceList === 'allow' ? 'success' : 'danger'}>
                      {draggedItem.sourceList === 'allow' ? 'Allowed' : 'Blocked'}
                    </EuiBadge>
                  </EuiFlexItem>
                  <EuiFlexItem grow={false} style={{ width: '32px' }}>
                    <GripVertical style={{ width: '16px', height: '16px', color: '#0077cc' }} />
                  </EuiFlexItem>
                </EuiFlexGroup>
              </EuiPanel>
            ) : null}
          </DragOverlay>
        </EuiPageBody>
      </EuiPage>
    </DndContext>
  );
};

export default Firewall;
