import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useQuery } from '@tanstack/react-query';
import {
  EuiFlexGroup,
  EuiFlexItem,
  EuiPanel,
  EuiTitle,
  EuiText,
  EuiSelect,
  EuiButton,
  EuiLoadingSpinner,
  EuiIcon
} from '@elastic/eui';
import RecentAlertsUnified from '../components/Dashboard/RecentAlertsUnified';
import ResponseActions from '../components/Dashboard/ResponseActions';
import AlertsSummaryCard from '../components/Dashboard/AlertsSummaryCard';
import { fetchDashboardData } from '../services/api';
import { fetchUnifiedAlerts } from '../services/detectionApi';
import { toast } from 'react-hot-toast';

const UnifiedDashboard = () => {
  const navigate = useNavigate();
  const [timeRange, setTimeRange] = useState('24h');
  const [sourceFilter, setSourceFilter] = useState(null); // null = all, 'wazuh' or 'suricata'
  const [detectionStats, setDetectionStats] = useState(null);
  const [overallStats, setOverallStats] = useState(null); // Always shows overall totals (all sources)
  const [detectionAlerts, setDetectionAlerts] = useState([]);
  const [detectionLoading, setDetectionLoading] = useState(false);


  // Fetch Response Dashboard Data
  const { data: responseDashboard, isLoading: responseLoading, refetch: refetchResponse } = useQuery(
    {
      queryKey: ['responseDashboardData'],
      queryFn: fetchDashboardData,
      refetchInterval: 30000, // Refresh every 30 seconds
    }
  );

  // Fetch Detection Dashboard Data with real-time alerts
  const fetchDetectionData = async (source = null) => {
    try {
      setDetectionLoading(true);
      
      // Determine limit based on time range - longer ranges need more alerts
      // to ensure we get high-severity events and accurate signature stats
      const getLimitForTimeRange = (range) => {
        const rangeMap = {
          '1h': 50,
          '6h': 100,
          '24h': 200,
          '7d': 500,
          '30d': 1000, // Fetch 1000 alerts for 30 days to get high-severity events
        };
        return rangeMap[range] || 200;
      };
      
      const alertLimit = getLimitForTimeRange(timeRange);
      
      // Fetch filtered alerts with statistics
      const unifiedResponse = await fetchUnifiedAlerts({
        time_range: timeRange,
        limit: alertLimit, // Dynamic limit based on time range
        source: source, // Filter by source if specified
        return_total: true,
      });

      // unifiedResponse is already the 'data' object (fetchUnifiedAlerts returns json.data)
      if (unifiedResponse && unifiedResponse.alerts) {
        // Set statistics from unified alerts response (filtered based on source)
        setDetectionStats({
          total_alerts: unifiedResponse.total || unifiedResponse.metadata?.total_alerts || 0,
          by_severity: unifiedResponse.statistics?.by_severity || {},
          by_source: unifiedResponse.statistics?.by_source || {},
          by_category: unifiedResponse.statistics?.by_category || {},
        });

        // Set recent alerts (filtered)
        setDetectionAlerts(unifiedResponse.alerts || []);
      }
    } catch (error) {
      console.error('Error fetching detection data:', error);
      toast.error('Failed to fetch detection data');
    } finally {
      setDetectionLoading(false);
    }
  };

  React.useEffect(() => {
    fetchDetectionData(sourceFilter);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [timeRange, sourceFilter]);
  
  // Fetch overall stats when timeRange changes (but not when sourceFilter changes)
  React.useEffect(() => {
    const fetchOverallStats = async () => {
      try {
        const getLimitForTimeRange = (range) => {
          const rangeMap = {
            '1h': 50,
            '6h': 100,
            '24h': 200,
            '7d': 500,
            '30d': 1000,
          };
          return rangeMap[range] || 200;
        };
        
        const alertLimit = getLimitForTimeRange(timeRange);
        const overallResponse = await fetchUnifiedAlerts({
          time_range: timeRange,
          limit: alertLimit,
          source: null, // Always fetch all sources for overall stats
          return_total: true,
        });
        
        if (overallResponse) {
          setOverallStats({
            total_alerts: overallResponse.total || overallResponse.metadata?.total_alerts || 0,
            by_source: overallResponse.statistics?.by_source || {},
          });
        }
      } catch (error) {
        console.error('Error fetching overall stats:', error);
      }
    };
    
    fetchOverallStats();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [timeRange]);

  const handleRefresh = () => {
    refetchResponse();
    fetchDetectionData(sourceFilter);
  };

  const handleSourceFilter = (source) => {
    setSourceFilter(source);
  };

  if (responseLoading && detectionLoading) {
    return (
      <EuiFlexGroup justifyContent="center" alignItems="center" style={{ height: '256px' }}>
        <EuiFlexItem grow={false}>
          <EuiLoadingSpinner size="l" />
        </EuiFlexItem>
        <EuiFlexItem grow={false}>
          <EuiText color="subdued">
            <p>Loading dashboard...</p>
          </EuiText>
        </EuiFlexItem>
      </EuiFlexGroup>
    );
  }

  const responseData = responseDashboard || {};
  const { response_actions = {} } = responseData;

  return (
    <div className="athena-space-y-6 athena-animate-fade-in" style={{ paddingBottom: '24px' }}>
      {/* Header */}
      <EuiPanel>
        <EuiFlexGroup justifyContent="spaceBetween" alignItems="center" responsive={true} gutterSize="m">
          <EuiFlexItem>
            <EuiFlexGroup alignItems="center" gutterSize="m" responsive={false}>
              <EuiFlexItem grow={false}>
                <div className="athena-glass-strong p-3" style={{ borderRadius: '8px' }}>
                  <EuiIcon type="securitySignal" size="l" color="primary" />
                </div>
              </EuiFlexItem>
              <EuiFlexItem>
                <EuiTitle size="m">
                  <h1>Security Dashboard</h1>
                </EuiTitle>
                <EuiText color="subdued" size="s">
                  <p>Comprehensive security monitoring and threat detection</p>
                </EuiText>
              </EuiFlexItem>
            </EuiFlexGroup>
          </EuiFlexItem>
          <EuiFlexItem grow={false}>
            <EuiFlexGroup gutterSize="s" responsive={false}>
              <EuiFlexItem grow={false}>
                <EuiSelect
                  value={timeRange}
                  onChange={(e) => setTimeRange(e.target.value)}
                  options={[
                    { value: '1h', text: 'Last 1 Hour' },
                    { value: '6h', text: 'Last 6 Hours' },
                    { value: '24h', text: 'Last 24 Hours' },
                    { value: '7d', text: 'Last 7 Days' },
                    { value: '30d', text: 'Last 30 Days' },
                  ]}
                  compressed
                />
              </EuiFlexItem>
              <EuiFlexItem grow={false}>
                <EuiButton
                  onClick={handleRefresh}
                  isLoading={responseLoading || detectionLoading}
                  iconType="refresh"
                  size="m"
                >
                  Refresh
                </EuiButton>
              </EuiFlexItem>
            </EuiFlexGroup>
          </EuiFlexItem>
        </EuiFlexGroup>
      </EuiPanel>

      {/* Dashboard Content */}
      <div className="athena-space-y-6">
          {/* Alerts Summary Card */}
          <AlertsSummaryCard
            stats={detectionStats}
            overallStats={overallStats}
            loading={detectionLoading}
            alerts={detectionAlerts}
            sourceFilter={sourceFilter}
            onSourceFilter={handleSourceFilter}
          />

          {/* Recent Activity Section */}
          <div className="athena-space-y-4">
            {/* Section Header */}
            <EuiFlexGroup justifyContent="spaceBetween" alignItems="center">
              <EuiFlexItem>
                <EuiFlexGroup alignItems="center" gutterSize="m">
                  <EuiFlexItem grow={false}>
                    <div className="athena-glass p-2" style={{ borderRadius: '6px' }}>
                      <EuiIcon type="pulse" size="m" color="secondary" />
                    </div>
                  </EuiFlexItem>
                  <EuiFlexItem>
                    <EuiTitle size="s">
                      <h2>Recent Activity</h2>
                    </EuiTitle>
                    <EuiText color="subdued" size="xs">
                      <p>Live security events and automated responses</p>
                    </EuiText>
                  </EuiFlexItem>
                </EuiFlexGroup>
              </EuiFlexItem>
            </EuiFlexGroup>

            {/* Combined Activity Tables Row */}
            <EuiFlexGroup responsive={true} gutterSize="l">
              <EuiFlexItem>
                <EuiPanel
                  className="athena-hover-glow-blue clickable-dashboard-panel"
                  style={{
                    minHeight: '400px',
                    display: 'flex',
                    flexDirection: 'column'
                  }}
                  onClick={() => navigate('/detection/events')}
                >
                  <div className="athena-card-header" style={{ borderBottom: '1px solid #475569', marginBottom: '16px' }}>
                    <EuiFlexGroup justifyContent="spaceBetween" alignItems="center" responsive={false}>
                      <EuiFlexItem>
                        <EuiFlexGroup alignItems="center" gutterSize="s" responsive={false}>
                          <EuiFlexItem grow={false}>
                            <div className="athena-badge-warning" style={{ padding: '6px', borderRadius: '4px' }}>
                              <EuiIcon type="warning" size="s" />
                            </div>
                          </EuiFlexItem>
                          <EuiFlexItem>
                            <EuiTitle size="xs">
                              <h3>Recent Security Alerts</h3>
                            </EuiTitle>
                            <EuiText color="subdued" size="xs">
                              <p>Real-time alerts from all sources</p>
                            </EuiText>
                          </EuiFlexItem>
                        </EuiFlexGroup>
                      </EuiFlexItem>
                      {detectionAlerts.length > 0 && (
                        <EuiFlexItem grow={false}>
                          <div className="athena-badge-info">
                            {detectionAlerts.length}
                          </div>
                        </EuiFlexItem>
                      )}
                      <EuiFlexItem grow={false}>
                        <EuiIcon type="arrowRight" size="m" color="subdued" />
                      </EuiFlexItem>
                    </EuiFlexGroup>
                  </div>
                  <div style={{ flex: 1, padding: 0 }}>
                    <RecentAlertsUnified alerts={detectionAlerts} loading={detectionLoading} />
                  </div>
                </EuiPanel>
              </EuiFlexItem>

              <EuiFlexItem>
                <EuiPanel
                  className="athena-hover-glow-green"
                  style={{
                    minHeight: '400px',
                    display: 'flex',
                    flexDirection: 'column'
                  }}
                >
                  <div className="athena-card-header" style={{ borderBottom: '1px solid #475569', marginBottom: '16px' }}>
                    <EuiFlexGroup justifyContent="spaceBetween" alignItems="center" responsive={false}>
                      <EuiFlexItem>
                        <EuiFlexGroup alignItems="center" gutterSize="s" responsive={false}>
                          <EuiFlexItem grow={false}>
                            <div className="athena-badge-success" style={{ padding: '6px', borderRadius: '4px' }}>
                              <EuiIcon type="check" size="s" />
                            </div>
                          </EuiFlexItem>
                          <EuiFlexItem>
                            <EuiTitle size="xs">
                              <h3>Active Response Actions</h3>
                            </EuiTitle>
                            <EuiText color="subdued" size="xs">
                              <p>Automated security responses</p>
                            </EuiText>
                          </EuiFlexItem>
                        </EuiFlexGroup>
                      </EuiFlexItem>
                      {response_actions?.by_action_type?.length > 0 && (
                        <EuiFlexItem grow={false}>
                          <div className="athena-badge-info">
                            {response_actions.by_action_type.length}
                          </div>
                        </EuiFlexItem>
                      )}
                    </EuiFlexGroup>
                  </div>
                  <div style={{ flex: 1, padding: 0 }}>
                    <ResponseActions data={response_actions?.by_action_type || []} />
                  </div>
                </EuiPanel>
              </EuiFlexItem>
            </EuiFlexGroup>
          </div>
        </div>
    </div>
  );
};

export default UnifiedDashboard;
