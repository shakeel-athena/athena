import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { ReactKeycloakProvider } from '@react-keycloak/web';
import { Toaster } from 'react-hot-toast';
import { EuiProvider } from '@elastic/eui';
import { themeConfig } from './config/euiTheme';
import keycloak, { keycloakInitOptions } from './config/keycloak';
import { AuthProvider } from './contexts/AuthContext';
import ProtectedRoute from './components/Auth/ProtectedRoute';
import ErrorBoundary from './components/ErrorBoundary';
import Layout from './components/Layout/Layout';
import UnifiedDashboard from './pages/UnifiedDashboard';
import Alerts from './pages/Alerts';
import Responses from './pages/Responses';
import Policies from './pages/Policies';
import Intelligence from './pages/Intelligence';
import Audit from './pages/Audit';
import Rules from './pages/Rules';
import Firewall from './pages/Firewall';
import WAFSignatures from './pages/WAFSignatures';
import FirewallWAFUnified from './pages/security/FirewallWAFUnified';
import Unauthorized from './pages/Unauthorized';
// Detection Module Pages
import PromachosIndexer from './pages/detection/PromachosIndexer';
import ThreatLandscape from './pages/detection/NetworkTopology';
import Events from './pages/detection/Events';
import WazuhRules from './pages/detection/WazuhRules';
import SystemConfiguration from './pages/detection/SystemConfiguration';
import NIDS from './pages/detection/NIDS';
// Threat Intelligence Pages
import CTIDatasets from './pages/threat-intelligence/CTIDatasets';
// Admin Pages
import UserManagement from './pages/admin/UserManagement';
import RoleManagement from './pages/admin/RoleManagement';
import MuteManagement from './pages/admin/MuteManagement';
import BlockedIPsManagement from './pages/admin/BlockedIPsManagement';
import AgentControlCenter from './pages/admin/AgentControlCenter';
// Active Response Pages
import ActiveResponseDashboard from './pages/ActiveResponse/Dashboard';
import ActiveResponseAdvanced from './pages/ActiveResponse/ActiveResponseAdvanced';
// System Health
import SystemHealth from './pages/SystemHealth';
import './index.css';
import './styles/enhanced-theme.css';
import './styles/dashboard-enhancements.css';

// Create a client for React Query
const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      refetchOnWindowFocus: false,
      retry: 1,
      staleTime: 30000, // 30 seconds
    },
  },
});

// Loading component for Keycloak initialization
const KeycloakLoadingComponent = () => (
  <div className="min-h-screen flex items-center justify-center bg-gray-900">
    <div className="text-center">
      <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-500 mx-auto mb-4"></div>
      <p className="text-gray-400">Initializing authentication...</p>
    </div>
  </div>
);

// Event handler for Keycloak events
const handleKeycloakEvent = (event, error) => {
  if (process.env.NODE_ENV === 'development') {
    console.log('Keycloak event:', event, error);
  }
};

// Token handler for Keycloak token updates
const handleKeycloakTokens = (tokens) => {
  if (process.env.NODE_ENV === 'development') {
    console.log('Keycloak tokens updated');
  }
};


function App() {
  return (
    <ReactKeycloakProvider
      authClient={keycloak}
      initOptions={keycloakInitOptions}
      LoadingComponent={<KeycloakLoadingComponent />}
      onEvent={handleKeycloakEvent}
      onTokens={handleKeycloakTokens}
    >
      <AuthProvider>
        <QueryClientProvider client={queryClient}>
          <EuiProvider {...themeConfig}>
              <Router>
                <div className="App min-h-screen">
                <Layout>
                <ErrorBoundary>
                  <Routes>
                  {/* Public Routes */}
                  <Route path="/unauthorized" element={<Unauthorized />} />

                  {/* Protected Response Module Routes */}
                  <Route path="/" element={
                    <ProtectedRoute>
                      <UnifiedDashboard />
                    </ProtectedRoute>
                  } />
                  <Route path="/dashboard" element={
                    <ProtectedRoute>
                      <UnifiedDashboard />
                    </ProtectedRoute>
                  } />
                  <Route path="/alerts" element={
                    <ProtectedRoute roles={['admin', 'security-analyst', 'incident-responder']}>
                      <Alerts />
                    </ProtectedRoute>
                  } />
                  <Route path="/responses" element={
                    <ProtectedRoute roles={['admin', 'security-analyst', 'incident-responder']}>
                      <Responses />
                    </ProtectedRoute>
                  } />
                  <Route path="/policies" element={
                    <ProtectedRoute roles={['admin', 'security-analyst']}>
                      <Policies />
                    </ProtectedRoute>
                  } />
                  <Route path="/intelligence" element={
                    <ProtectedRoute roles={['admin', 'security-analyst', 'security-viewer']}>
                      <Intelligence />
                    </ProtectedRoute>
                  } />
                  <Route path="/audit" element={
                    <ProtectedRoute roles={['admin', 'auditor']}>
                      <Audit />
                    </ProtectedRoute>
                  } />
                  <Route path="/rules" element={
                    <ProtectedRoute roles={['admin', 'waf-manager']}>
                      <Rules />
                    </ProtectedRoute>
                  } />
                  <Route path="/firewall" element={
                    <ProtectedRoute roles={['admin', 'waf-manager']}>
                      <Firewall />
                    </ProtectedRoute>
                  } />
                  <Route path="/waf-signatures" element={
                    <ProtectedRoute roles={['admin', 'waf-manager']}>
                      <WAFSignatures />
                    </ProtectedRoute>
                  } />
                  <Route path="/security/firewall-waf" element={
                    <ProtectedRoute roles={['admin', 'waf-manager', 'security-analyst']}>
                      <FirewallWAFUnified />
                    </ProtectedRoute>
                  } />

                  {/* Protected Detection Module Routes */}
                  <Route path="/detection/events" element={
                    <ProtectedRoute roles={['admin', 'security-analyst', 'security-viewer']}>
                      <Events />
                    </ProtectedRoute>
                  } />
                  <Route path="/detection/nids" element={
                    <ProtectedRoute roles={['admin', 'security-analyst', 'security-viewer']}>
                      <NIDS />
                    </ProtectedRoute>
                  } />
                  <Route path="/detection/promachos" element={
                    <ProtectedRoute roles={['admin', 'security-analyst', 'security-viewer']}>
                      <PromachosIndexer />
                    </ProtectedRoute>
                  } />
                  <Route path="/detection/network-topology" element={
                    <ProtectedRoute roles={['admin', 'security-analyst', 'security-viewer']}>
                      <ThreatLandscape />
                    </ProtectedRoute>
                  } />
                  <Route path="/detection/wazuh-rules" element={
                    <ProtectedRoute roles={['admin', 'security-analyst', 'security-viewer']}>
                      <WazuhRules />
                    </ProtectedRoute>
                  } />
                  <Route path="/detection/configuration" element={
                    <ProtectedRoute roles={['admin']}>
                      <SystemConfiguration />
                    </ProtectedRoute>
                  } />

                  {/* Protected Threat Intelligence Routes */}
                  <Route path="/threat-intelligence/datasets" element={
                    <ProtectedRoute roles={['admin', 'security-analyst', 'security-viewer']}>
                      <CTIDatasets />
                    </ProtectedRoute>
                  } />

                  {/* Protected Active Response Routes */}
                  <Route path="/active-response" element={
                    <ProtectedRoute roles={['admin', 'security-analyst', 'incident-responder']} pagePath="/active-response">
                      <ActiveResponseDashboard />
                    </ProtectedRoute>
                  } />
                  <Route path="/active-response/advanced" element={
                    <ProtectedRoute roles={['admin', 'security-analyst', 'incident-responder']} pagePath="/active-response/advanced">
                      <ActiveResponseAdvanced />
                    </ProtectedRoute>
                  } />

                  {/* System Health Route */}
                  <Route path="/system-health" element={
                    <ProtectedRoute roles={['admin', 'security-analyst', 'security-viewer']}>
                      <SystemHealth />
                    </ProtectedRoute>
                  } />

                  {/* Admin Routes - RBAC Management */}
                  <Route path="/admin/users" element={
                    <ProtectedRoute roles={['admin']} pagePath="/admin/users">
                      <UserManagement />
                    </ProtectedRoute>
                  } />
                  <Route path="/admin/roles" element={
                    <ProtectedRoute roles={['admin']} pagePath="/admin/roles">
                      <RoleManagement />
                    </ProtectedRoute>
                  } />
                  <Route path="/admin/mute-rules" element={
                    <ProtectedRoute roles={['admin']} pagePath="/admin/mute-rules">
                      <MuteManagement />
                    </ProtectedRoute>
                  } />
                  <Route path="/admin/blocked-ips" element={
                    <ProtectedRoute roles={['admin']} pagePath="/admin/blocked-ips">
                      <BlockedIPsManagement />
                    </ProtectedRoute>
                  } />
                  <Route path="/admin/agent-control" element={
                    <ProtectedRoute roles={['admin', 'security-analyst']} pagePath="/admin/agent-control">
                      <AgentControlCenter />
                    </ProtectedRoute>
                  } />
                  </Routes>
                </ErrorBoundary>
                </Layout>
                <Toaster
                  position="top-right"
                  toastOptions={{
                    duration: 4000,
                    style: {
                      background: '#1e293b',
                      color: '#f8fafc',
                      border: '1px solid #475569',
                    },
                    success: {
                      iconTheme: {
                        primary: '#16a34a',
                        secondary: '#f8fafc',
                      },
                    },
                    error: {
                      iconTheme: {
                        primary: '#dc2626',
                        secondary: '#f8fafc',
                      },
                    },
                  }}
                />
                </div>
              </Router>
            </EuiProvider>
        </QueryClientProvider>
      </AuthProvider>
    </ReactKeycloakProvider>
  );
}

export default App;
