import React from 'react';
import ReactDOM from 'react-dom/client';
import App from './App';

const root = ReactDOM.createRoot(document.getElementById('root'));

// Note: React.StrictMode is temporarily disabled because it causes Keycloak
// to initialize twice in development mode, which throws an error.
// Keycloak doesn't support multiple initializations.
// You can enable StrictMode for other components, but not at the root level with Keycloak.
root.render(<App />);
