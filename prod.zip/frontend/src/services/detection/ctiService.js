import axios from 'axios';

// Detection API base URL for CTI data
const API_BASE_URL = (process.env.REACT_APP_DETECTION_API || 'http://localhost:5001') + '/api';

class CTIService {
  get apiClient() {
    const client = axios.create({
      baseURL: API_BASE_URL,
      timeout: 30000,
      headers: { 'Content-Type': 'application/json' },
    });

    client.interceptors.request.use((config) => {
      const token = localStorage.getItem('token');
      if (token) config.headers.Authorization = `Bearer ${token}`;
      return config;
    });

    return client;
  }

  /**
   * Get CTI database status and statistics
   */
  async getStatus() {
    const resp = await this.apiClient.get('/cti/status');
    return resp.data?.data || {};
  }

  /**
   * Get MITRE ATT&CK tactics
   */
  async getTactics() {
    const resp = await this.apiClient.get('/cti/tactics');
    return resp.data?.data || [];
  }

  /**
   * Get techniques by tactic
   */
  async getTechniquesByTactic(tacticId) {
    const resp = await this.apiClient.get(`/cti/tactics/${tacticId}/techniques`);
    return resp.data?.data || [];
  }

  /**
   * Get all techniques with pagination and search
   */
  async getTechniques(options = {}) {
    const { limit = 20, offset = 0, search = '' } = options;
    const resp = await this.apiClient.get('/cti/techniques', {
      params: { limit, offset, search }
    });
    return {
      data: resp.data?.data || [],
      total: resp.data?.total || 0
    };
  }

  /**
   * Get CVE vulnerabilities
   */
  async getCVEs(options = {}) {
    const { limit = 20, offset = 0, severity = null } = options;
    const params = { limit, offset };
    if (severity) params.severity = severity;

    const resp = await this.apiClient.get('/cti/cves', { params });
    return {
      data: resp.data?.data || [],
      total: resp.data?.total || 0
    };
  }

  /**
   * Get Known Exploited Vulnerabilities (KEV)
   */
  async getKEVs(options = {}) {
    const { limit = 20, offset = 0 } = options;
    const resp = await this.apiClient.get('/cti/kev', {
      params: { limit, offset }
    });
    return {
      data: resp.data?.data || [],
      total: resp.data?.total || 0
    };
  }

  /**
   * Get threat campaigns
   */
  async getCampaigns() {
    const resp = await this.apiClient.get('/cti/campaigns');
    return resp.data?.data || [];
  }

  /**
   * Get malware information
   */
  async getMalware(options = {}) {
    const { limit = 20, offset = 0 } = options;
    const resp = await this.apiClient.get('/cti/malware', {
      params: { limit, offset }
    });
    return {
      data: resp.data?.data || [],
      total: resp.data?.total || 0
    };
  }

  /**
   * Get dataset sync status
   */
  async getSyncStatus() {
    const resp = await this.apiClient.get('/cti/sync-status');
    return resp.data?.data || {};
  }
}

const ctiService = new CTIService();
export default ctiService;
export { ctiService };
