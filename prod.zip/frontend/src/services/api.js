// API service for communicating with the backend Flask server
import { apiRequest as makeAuthenticatedRequest } from './apiClient';

// Backend API URL - update this to match your backend server
const API_BASE_URL = process.env.REACT_APP_API_URL || 'http://localhost:5000/api';

// Helper function to make API requests with JWT authentication
const apiRequest = async (endpoint, options = {}) => {
  const url = `${API_BASE_URL}${endpoint}`;
  return makeAuthenticatedRequest(url, options);
};

// Dashboard API
export const fetchDashboardData = async () => {
  return await apiRequest('/dashboard');
};

// Alerts API
export const fetchAlerts = async (filters = {}) => {
  const params = new URLSearchParams();
  
  if (filters.severity) params.append('severity', filters.severity);
  if (filters.type) params.append('type', filters.type);
  if (filters.timeRange) params.append('timeRange', filters.timeRange);
  if (filters.search) params.append('search', filters.search);
  
  return await apiRequest(`/alerts?${params.toString()}`);
};

export const fetchAlertById = async (id) => {
  return await apiRequest(`/alerts/${id}`);
};

export const acknowledgeAlert = async (id) => {
  return await apiRequest(`/alerts/${id}/acknowledge`, {
    method: 'POST',
  });
};

export const markFalsePositive = async (id, reason) => {
  return await apiRequest(`/alerts/${id}/false-positive`, {
    method: 'POST',
    body: JSON.stringify({ reason }),
  });
};

// Response Actions API
export const fetchResponseActions = async (filters = {}) => {
  const params = new URLSearchParams();
  
  if (filters.provider) params.append('provider', filters.provider);
  if (filters.status) params.append('status', filters.status);
  if (filters.timeRange) params.append('timeRange', filters.timeRange);
  
  return await apiRequest(`/actions?${params.toString()}`);
};

export const executeManualAction = async (actionData) => {
  return await apiRequest('/actions/execute', {
    method: 'POST',
    body: JSON.stringify(actionData),
  });
};

// WAF Configuration API
export const fetchWafConfiguration = async (scope = 'REGIONAL') => {
  const s = typeof scope === 'string' ? scope : (scope && scope.value ? scope.value : 'REGIONAL');
  return await apiRequest(`/waf/configuration?scope=${encodeURIComponent(s)}`);
};

export const updateWafRule = async (ruleData) => {
  return await apiRequest('/waf/rules', {
    method: 'PUT',
    body: JSON.stringify(ruleData),
  });
};

export const addIpToBlocklist = async (ip, ttl = 3600, ipSetName = 'Blocked', scope = 'REGIONAL') => {
  return await apiRequest('/waf/ip-blocklist', {
    method: 'POST',
    body: JSON.stringify({ ip, ttl, ip_set_name: ipSetName, scope }),
  });
};

export const removeIpFromBlocklist = async (ip, ipSetName = 'Blocked', scope = 'REGIONAL') => {
  const params = new URLSearchParams({ ip_set_name: ipSetName, scope });
  return await apiRequest(`/waf/ip-blocklist/${ip}?${params.toString()}`, {
    method: 'DELETE',
  });
};

// Policy Management API
export const fetchPolicies = async () => {
  return await apiRequest('/policies');
};

export const updatePolicy = async (policyData) => {
  return await apiRequest('/policies', {
    method: 'PUT',
    body: JSON.stringify(policyData),
  });
};

// Threat Intelligence API
export const fetchThreatIntelligence = async () => {
  return await apiRequest('/threat-intelligence');
};

export const lookupIpReputation = async (ip) => {
  return await apiRequest(`/threat-intelligence/ip/${ip}`);
};

// Audit Trail API
export const fetchAuditTrail = async (filters = {}) => {
  const params = new URLSearchParams();
  
  if (filters.event_type) params.append('event_type', filters.event_type);
  if (filters.user) params.append('user', filters.user);
  if (filters.timeRange) params.append('timeRange', filters.timeRange);
  
  return await apiRequest(`/audit?${params.toString()}`);
};

// System Health API
export const fetchSystemHealth = async () => {
  return await apiRequest('/health');
};

// Process EVE events
export const processEveEvents = async (eveJson) => {
  return await apiRequest('/process-events', {
    method: 'POST',
    body: JSON.stringify({ eve_json: eveJson }),
  });
};

// Execute geo-blocking actions
export const executeGeoBlocking = async (action, countries, webAclName, ruleName = null, scope = 'REGIONAL') => {
  return await executeManualAction({
    type: 'geo_block',
    params: {
      action,
      countries,
      web_acl_name: webAclName,
      rule_name: ruleName,
      scope,
    },
  });
};

// Firewall IP Blocking API (using our new Flask API on port 5001)
const FIREWALL_API_BASE_URL = process.env.REACT_APP_FIREWALL_API_URL || 'http://localhost:5000/api/firewall';

const firewallApiRequest = async (endpoint, options = {}) => {
  const url = `${FIREWALL_API_BASE_URL}${endpoint}`;
  return makeAuthenticatedRequest(url, options);
};

// Get all IP sets (both allow and block)
export const fetchAllIpSets = async () => {
  return await firewallApiRequest('/ip-sets');
};

// Get allow list
export const fetchAllowList = async () => {
  return await firewallApiRequest('/allow-list');
};

// Get block list
export const fetchBlockList = async () => {
  return await firewallApiRequest('/block-list');
};

// Add IPs to allow list
export const addToAllowList = async (ips) => {
  return await firewallApiRequest('/allow-list', {
    method: 'POST',
    body: JSON.stringify({ ips }),
  });
};

// Add IPs to block list
export const addToBlockList = async (ips) => {
  return await firewallApiRequest('/block-list', {
    method: 'POST',
    body: JSON.stringify({ ips }),
  });
};

// Remove IPs from allow list
export const removeFromAllowList = async (ips) => {
  return await firewallApiRequest('/allow-list', {
    method: 'DELETE',
    body: JSON.stringify({ ips }),
  });
};

// Remove IPs from block list
export const removeFromBlockList = async (ips) => {
  return await firewallApiRequest('/block-list', {
    method: 'DELETE',
    body: JSON.stringify({ ips }),
  });
};

// Transfer IP between lists
export const transferIp = async (ip, fromList, toList) => {
  return await firewallApiRequest('/transfer-ip', {
    method: 'POST',
    body: JSON.stringify({ 
      ip: ip, 
      from: fromList, 
      to: toList 
    }),
  });
};

// WAF Signature Management API
const WAF_SIGNATURE_API_BASE_URL = process.env.REACT_APP_WAF_SIGNATURE_API_URL || 'http://localhost:5000/api/waf-signatures';

// Helper function to make WAF signature API requests
const wafSignatureApiRequest = async (endpoint, options = {}) => {
  const url = `${WAF_SIGNATURE_API_BASE_URL}${endpoint}`;
  return makeAuthenticatedRequest(url, options);
};

// Get all available signatures (custom and AWS managed)
export const getAvailableSignatures = async () => {
  return await wafSignatureApiRequest('/available');
};

// Get only custom signatures
export const getCustomSignatures = async () => {
  return await wafSignatureApiRequest('/custom');
};

// Get only AWS managed signatures
export const getAwsManagedSignatures = async () => {
  return await wafSignatureApiRequest('/aws-managed');
};

// Get signature status (active/inactive for all signatures)
export const getSignatureStatus = async () => {
  return await wafSignatureApiRequest('/status');
};

// Get currently active signatures
export const getActiveSignatures = async () => {
  return await wafSignatureApiRequest('/active');
};

// Add a signature to the Web ACL
export const addSignature = async (signatureId) => {
  return await wafSignatureApiRequest('/add', {
    method: 'POST',
    body: JSON.stringify({ signature_id: signatureId }),
  });
};

// Remove a signature from the Web ACL
export const removeSignature = async (signatureId) => {
  return await wafSignatureApiRequest('/remove', {
    method: 'POST',
    body: JSON.stringify({ signature_id: signatureId }),
  });
};

// Toggle a signature (add if inactive, remove if active)
export const toggleSignature = async (signatureId) => {
  return await wafSignatureApiRequest('/toggle', {
    method: 'POST',
    body: JSON.stringify({ signature_id: signatureId }),
  });
};

// Add multiple signatures
export const addMultipleSignatures = async (signatureIds) => {
  return await wafSignatureApiRequest('/add-multiple', {
    method: 'POST',
    body: JSON.stringify({ signature_ids: signatureIds }),
  });
};

// Remove multiple signatures
export const removeMultipleSignatures = async (signatureIds) => {
  return await wafSignatureApiRequest('/remove-multiple', {
    method: 'POST',
    body: JSON.stringify({ signature_ids: signatureIds }),
  });
};

// Add all available signatures
export const addAllSignatures = async () => {
  return await wafSignatureApiRequest('/add-all', {
    method: 'POST',
  });
};

// Remove all signatures
export const removeAllSignatures = async () => {
  return await wafSignatureApiRequest('/remove-all', {
    method: 'POST',
  });
};


// Geo-restrictions Management API
const GEO_RESTRICTIONS_API_BASE_URL = process.env.REACT_APP_GEO_RESTRICTIONS_API_URL || 'http://localhost:5000/api/geo-restrictions';

// Helper function to make geo-restrictions API requests
const geoRestrictionsApiRequest = async (endpoint, options = {}) => {
  const url = `${GEO_RESTRICTIONS_API_BASE_URL}${endpoint}`;
  return makeAuthenticatedRequest(url, options);
};

// Get current allowed countries
export const getGeoCountries = async () => {
  return await geoRestrictionsApiRequest('/countries');
};

// Add countries to the allowed list
export const addGeoCountries = async (countries) => {
  return await geoRestrictionsApiRequest('/countries', {
    method: 'POST',
    body: JSON.stringify({ countries }),
  });
};

// Remove countries from the allowed list
export const removeGeoCountries = async (countries) => {
  return await geoRestrictionsApiRequest('/countries', {
    method: 'DELETE',
    body: JSON.stringify({ countries }),
  });
};

// Set the complete list of allowed countries (replaces existing list)
export const setGeoCountries = async (countries) => {
  return await geoRestrictionsApiRequest('/countries', {
    method: 'PUT',
    body: JSON.stringify({ countries }),
  });
};

// Validate country codes
export const validateGeoCountries = async (countries) => {
  return await geoRestrictionsApiRequest('/validate', {
    method: 'POST',
    body: JSON.stringify({ countries }),
  });
};


// WAF Signature Configuration API functions
// Get signature configuration including geo restrictions
export const getSignatureConfig = async (signatureId) => {
  return await wafSignatureApiRequest(`/config/${signatureId}`);
};

// Update signature geo restrictions
export const updateSignatureGeoRestrictions = async (signatureId, allowedCountries) => {
  return await wafSignatureApiRequest(`/config/${signatureId}/geo-restrictions`, {
    method: 'POST',
    body: JSON.stringify({ allowed_countries: allowedCountries }),
  });
};

// WAF Geo Restrictions API functions
export const getWAFGeoRestrictionsRule = async () => {
  return await apiRequest(`/waf-geo-restrictions/countries`);
};

export const updateWAFGeoRestrictionsRule = async (allowedCountries) => {
  return await apiRequest(`/waf-geo-restrictions/countries`, {
    method: 'POST',
    body: JSON.stringify({ allowed_countries: allowedCountries }),
  });
};

// WAF IP Reputation Management API functions
export const getWAFIPReputationRules = async () => {
  return await apiRequest(`/waf-ip-reputation/rules`);
};

export const updateWAFIPReputationRuleAction = async (ruleName, action) => {
  return await apiRequest(`/waf-ip-reputation/rules/${ruleName}/action`, {
    method: 'PUT',
    body: JSON.stringify({ action }),
  });
};

export const updateWAFIPReputationRulesActions = async (ruleActions) => {
  return await apiRequest(`/waf-ip-reputation/rules/actions`, {
    method: 'PUT',
    body: JSON.stringify({ rule_actions: ruleActions }),
  });
};

export const resetWAFIPReputationRule = async (ruleName) => {
  return await apiRequest(`/waf-ip-reputation/rules/${ruleName}/reset`, {
    method: 'POST',
  });
};

export const resetAllWAFIPReputationRules = async () => {
  return await apiRequest(`/waf-ip-reputation/rules/reset-all`, {
    method: 'POST',
  });
};


// WAF Common Attack Protection API functions
export const getWAFCommonAttackRules = async () => {
  return await apiRequest(`/waf-common-attack/rules`);
};

export const updateWAFCommonAttackRuleAction = async (ruleName, action) => {
  return await apiRequest(`/waf-common-attack/rules/${ruleName}/action`, {
    method: 'PUT',
    body: JSON.stringify({ action }),
  });
};

export const resetWAFCommonAttackRule = async (ruleName) => {
  return await apiRequest(`/waf-common-attack/rules/${ruleName}/reset`, {
    method: 'POST',
  });
};

export const createWAFCommonAttackAllowList = async (ruleName, ips, domains) => {
  return await apiRequest(`/waf-common-attack/rules/${ruleName}/allow-list`, {
    method: 'POST',
    body: JSON.stringify({ ip_list: ips, domain_list: domains }),
  });
};

// WAF Anonymous IP Protection API functions
export const getWAFAnonymousIPRules = async () => {
  return await apiRequest(`/waf-anonymous-ip/rules`);
};

export const updateWAFAnonymousIPRuleAction = async (ruleName, action) => {
  return await apiRequest(`/waf-anonymous-ip/rules/${ruleName}/action`, {
    method: 'PUT',
    body: JSON.stringify({ action }),
  });
};

export const resetWAFAnonymousIPRule = async (ruleName) => {
  return await apiRequest(`/waf-anonymous-ip/rules/${ruleName}/reset`, {
    method: 'POST',
  });
};

export const createWAFAnonymousIPAllowList = async (ruleName, ips, domains) => {
  return await apiRequest(`/waf-anonymous-ip/rules/${ruleName}/allow-list`, {
    method: 'POST',
    body: JSON.stringify({ ip_list: ips, domain_list: domains }),
  });
};

// WAF Linux Vulnerability Protection API functions
export const getWAFLinuxVulnRules = async () => {
  return await apiRequest(`/waf-linux-vuln/rules`);
};

export const updateWAFLinuxVulnRuleAction = async (ruleName, action) => {
  return await apiRequest(`/waf-linux-vuln/rules/${ruleName}/action`, {
    method: 'PUT',
    body: JSON.stringify({ action }),
  });
};

export const resetWAFLinuxVulnRule = async (ruleName) => {
  return await apiRequest(`/waf-linux-vuln/rules/${ruleName}/reset`, {
    method: 'POST',
  });
};

export const createWAFLinuxVulnAllowList = async (ruleName, ips, domains) => {
  return await apiRequest(`/waf-linux-vuln/rules/${ruleName}/allow-list`, {
    method: 'POST',
    body: JSON.stringify({ ip_list: ips, domain_list: domains }),
  });
};

// WAF Unix Vulnerability Protection API functions
export const getWAFUnixVulnRules = async () => {
  return await apiRequest(`/waf-unix-vuln/rules`);
};

export const updateWAFUnixVulnRuleAction = async (ruleName, action) => {
  return await apiRequest(`/waf-unix-vuln/rules/${ruleName}/action`, {
    method: 'PUT',
    body: JSON.stringify({ action }),
  });
};

export const resetWAFUnixVulnRule = async (ruleName) => {
  return await apiRequest(`/waf-unix-vuln/rules/${ruleName}/reset`, {
    method: 'POST',
  });
};

export const createWAFUnixVulnAllowList = async (ruleName, ips, domains) => {
  return await apiRequest(`/waf-unix-vuln/rules/${ruleName}/allow-list`, {
    method: 'POST',
    body: JSON.stringify({ ip_list: ips, domain_list: domains }),
  });
};

// WAF Known Bad Inputs API functions
export const getWAFKnownBadInputsRules = async () => {
  return await apiRequest(`/waf-known-bad-inputs/rules`);
};

export const updateWAFKnownBadInputsRuleAction = async (ruleName, action) => {
  return await apiRequest(`/waf-known-bad-inputs/rules/${ruleName}/action`, {
    method: 'PUT',
    body: JSON.stringify({ action }),
  });
};

export const resetWAFKnownBadInputsRule = async (ruleName) => {
  return await apiRequest(`/waf-known-bad-inputs/rules/${ruleName}/reset`, {
    method: 'POST',
  });
};

export const createWAFKnownBadInputsAllowList = async (ruleName, ips, domains) => {
  return await apiRequest(`/waf-known-bad-inputs/rules/${ruleName}/allow-list`, {
    method: 'POST',
    body: JSON.stringify({ ip_list: ips, domain_list: domains }),
  });
};


export const createWAFIPReputationAllowList = async (ruleName, ips, domains) => {
  return await apiRequest(`/waf-ip-reputation/rules/${ruleName}/allow-list`, {
    method: 'POST',
    body: JSON.stringify({ ip_list: ips, domain_list: domains }),
  });
};

// Rule Mapping API functions
export const getRuleMapping = async (ruleGroup, ruleName) => {
  return await apiRequest(`/waf-rule-mappings/${ruleGroup}/${ruleName}`);
};

export const getAllowListData = async (ruleGroup, ruleName) => {
  return await apiRequest(`/waf-${ruleGroup}/rules/${ruleName}/allow-list-data`);
};

// ============================================================================
// Firewall Alert-Based IP Blocking API Functions
// ============================================================================

// Block IP from security alert with audit trail
export const blockIPFromAlert = async (ip, alertData) => {
  return await apiRequest('/firewall/block-from-alert', {
    method: 'POST',
    body: JSON.stringify({
      ip,
      alert_id: alertData.alert_id,
      alert_source: alertData.alert_source,
      alert_severity: alertData.alert_severity,
      threat_type: alertData.threat_type,
      reason: alertData.reason,
      direction: alertData.direction,
      analyst: alertData.analyst
    })
  });
};

// Multi-layer IP blocking (Wazuh AR + Firewall + WAF)
export const blockIPMultiLayer = async (payload) => {
  return await apiRequest('/block-ip-multi-layer', {
    method: 'POST',
    body: JSON.stringify(payload)
  });
};

// Get blocked IPs from alerts (with metadata)
export const getBlockedIPsFromAlerts = async (filters = {}) => {
  const params = new URLSearchParams();
  if (filters.threat_type) params.append('threat_type', filters.threat_type);
  if (filters.alert_source) params.append('alert_source', filters.alert_source);
  if (filters.analyst) params.append('analyst', filters.analyst);
  if (filters.active_only !== undefined) {
    params.append('active_only', filters.active_only.toString());
  }

  return await apiRequest(`/firewall/blocked-ips?${params.toString()}`);
};

// Unblock IP (simple, no reason required)
export const unblockIPFromAlert = async (ip, analyst) => {
  return await apiRequest('/firewall/blocked-ips/unblock', {
    method: 'POST',
    body: JSON.stringify({ ip, analyst })
  });
};

// ============================================================================
// Bulk Actions API
// ============================================================================

// Bulk block IPs from multiple alerts
export const bulkBlockIPs = async (alerts, analyst, threatType, reason) => {
  return await apiRequest('/alerts/bulk-block-ips', {
    method: 'POST',
    body: JSON.stringify({
      alerts,
      analyst,
      threat_type: threatType,
      reason
    })
  });
};

// Bulk mute alerts
export const bulkMuteAlerts = async (alerts, analyst, classification, reason, durationHours) => {
  return await apiRequest('/alerts/bulk-mute', {
    method: 'POST',
    body: JSON.stringify({
      alerts,
      analyst,
      classification,
      reason,
      duration_hours: durationHours
    })
  });
};

// ============================================================================
// WAF IP Sets Management API (NEW)
// ============================================================================

/**
 * List all WAF IP sets
 * @param {string} scope - REGIONAL or CLOUDFRONT (default: REGIONAL)
 * @returns {Promise<Array>} Array of IP sets with their details
 */
export const listWAFIPSets = async (scope = 'REGIONAL') => {
  return await apiRequest(`/waf/ip-sets?scope=${scope}`);
};

/**
 * Get IPs in a specific WAF IP set
 * @param {string} ipSetName - Name of the IP set (e.g., "Blocked")
 * @param {number} page - Page number for pagination (default: 1)
 * @param {number} perPage - IPs per page (default: 100)
 * @param {string} scope - REGIONAL or CLOUDFRONT (default: REGIONAL)
 * @returns {Promise<Object>} IP set data with addresses and pagination
 */
export const getWAFIPSet = async (ipSetName, page = 1, perPage = 100, scope = 'REGIONAL') => {
  return await apiRequest(`/waf/ip-sets/${ipSetName}?page=${page}&per_page=${perPage}&scope=${scope}`);
};

/**
 * Add an IP to a WAF IP set
 * @param {string} ipSetName - Name of the IP set (e.g., "Blocked")
 * @param {string} ip - IP address to add
 * @param {string} reason - Reason for adding (optional)
 * @param {string} analyst - Analyst name (optional)
 * @param {string} scope - REGIONAL or CLOUDFRONT (default: REGIONAL)
 * @returns {Promise<Object>} Result of the add operation
 */
export const addIPToWAFSet = async (ipSetName, ip, reason = null, analyst = null, scope = 'REGIONAL') => {
  return await apiRequest(`/waf/ip-sets/${ipSetName}/ips`, {
    method: 'POST',
    body: JSON.stringify({
      ip,
      reason,
      analyst,
      scope
    })
  });
};

/**
 * Remove an IP from a WAF IP set
 * @param {string} ipSetName - Name of the IP set (e.g., "Blocked")
 * @param {string} ip - IP address to remove
 * @param {string} reason - Reason for removal (optional)
 * @param {string} analyst - Analyst name (optional)
 * @param {string} scope - REGIONAL or CLOUDFRONT (default: REGIONAL)
 * @returns {Promise<Object>} Result of the remove operation
 */
export const removeIPFromWAFSet = async (ipSetName, ip, reason = null, analyst = null, scope = 'REGIONAL') => {
  return await apiRequest(`/waf/ip-sets/${ipSetName}/ips`, {
    method: 'DELETE',
    body: JSON.stringify({
      ip,
      reason,
      analyst,
      scope
    })
  });
};
