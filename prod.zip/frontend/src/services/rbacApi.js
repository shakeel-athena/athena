// RBAC API service for admin operations
import { getKeycloakInstance } from '../config/keycloak';

// API Base URL - MUST be configured via environment variable for production
const API_BASE_URL = process.env.REACT_APP_API_BASE_URL || process.env.REACT_APP_RESPONSE_API_URL;

/**
 * Get access token from Keycloak with enhanced error handling
 */
const getAccessToken = async () => {
  try {
    const keycloak = getKeycloakInstance();
    
    // Ensure Keycloak is properly initialized
    if (!keycloak.authenticated && !keycloak.didInitialize) {
      console.log('Keycloak not initialized in rbacApi, initializing...');
      // We need to import initKeycloak here to avoid circular dependencies
      const { initKeycloak } = await import('../config/keycloak');
      await initKeycloak();
    }

    if (!keycloak.authenticated) {
      console.warn('User not authenticated in rbacApi');
      return null;
    }

    // Check if token needs refresh
    try {
      const isTokenExpired = keycloak.isTokenExpired(30);
      if (isTokenExpired) {
        console.log('Token expired in rbacApi, refreshing...');
        await keycloak.updateToken(30);
      }
    } catch (refreshError) {
      console.error('Failed to refresh token in rbacApi:', refreshError);
      await keycloak.login({
        redirectUri: window.location.origin + window.location.pathname
      });
      return null;
    }

    return keycloak.token;
  } catch (error) {
    console.error('Error getting access token in rbacApi:', error);
    return null;
  }
};

/**
 * Helper function to make API requests with authentication
 */
const apiRequest = async (endpoint, options = {}) => {
  const url = `${API_BASE_URL}${endpoint}`;
  const token = await getAccessToken();

  const response = await fetch(url, {
    ...options,
    headers: {
      'Content-Type': 'application/json',
      ...(token && { 'Authorization': `Bearer ${token}` }),
      ...options.headers,
    },
  });

  if (response.status === 401) {
    throw new Error('Authentication required');
  }

  if (!response.ok) {
    const error = await response.json().catch(() => ({ message: response.statusText }));
    throw new Error(error.message || `HTTP ${response.status}`);
  }

  return response.json();
};

// ============================================================================
// USER MANAGEMENT
// ============================================================================

/**
 * Get all users with optional filtering
 */
export const getUsers = async (params = {}) => {
  const queryString = new URLSearchParams(params).toString();
  return apiRequest(`/api/admin/users${queryString ? `?${queryString}` : ''}`);
};

/**
 * Get user by ID
 */
export const getUserById = async (userId) => {
  return apiRequest(`/api/admin/users/${userId}`);
};

/**
 * Create new user in both Keycloak and database
 */
export const createUser = async (userData) => {
  return apiRequest('/api/admin/users', {
    method: 'POST',
    body: JSON.stringify(userData),
  });
};

/**
 * Update user details
 */
export const updateUser = async (userId, userData) => {
  return apiRequest(`/api/admin/users/${userId}`, {
    method: 'PUT',
    body: JSON.stringify(userData),
  });
};

/**
 * Delete user from both Keycloak and database
 */
export const deleteUser = async (userId) => {
  return apiRequest(`/api/admin/users/${userId}`, {
    method: 'DELETE',
  });
};

/**
 * Reset user password
 */
export const resetUserPassword = async (userId, newPassword) => {
  return apiRequest(`/api/admin/users/${userId}/password`, {
    method: 'PUT',
    body: JSON.stringify({ new_password: newPassword }),
  });
};

/**
 * Toggle user account status (enable/disable)
 */
export const toggleUserStatus = async (userId, isActive) => {
  return apiRequest(`/api/admin/users/${userId}/toggle-status`, {
    method: 'PUT',
    body: JSON.stringify({ is_active: isActive }),
  });
};

/**
 * Get user's roles
 */
export const getUserRoles = async (userId) => {
  return apiRequest(`/api/admin/users/${userId}/roles`);
};

/**
 * Assign roles to user
 */
export const assignRolesToUser = async (userId, roleIds) => {
  return apiRequest(`/api/admin/users/${userId}/roles`, {
    method: 'POST',
    body: JSON.stringify({ role_ids: roleIds }),
  });
};

/**
 * Remove role from user
 */
export const removeRoleFromUser = async (userId, roleId) => {
  return apiRequest(`/api/admin/users/${userId}/roles/${roleId}`, {
    method: 'DELETE',
  });
};

/**
 * Toggle user admin status
 */
export const toggleUserAdmin = async (userId, isAdmin) => {
  return apiRequest(`/api/admin/users/${userId}/admin`, {
    method: 'PUT',
    body: JSON.stringify({ is_admin: isAdmin }),
  });
};

/**
 * Get user's accessible pages
 */
export const getUserPages = async (userId) => {
  return apiRequest(`/api/admin/users/${userId}/pages`);
};

// ============================================================================
// ROLE MANAGEMENT
// ============================================================================

/**
 * Get all roles
 */
export const getRoles = async () => {
  return apiRequest('/api/admin/roles');
};

/**
 * Get role by ID
 */
export const getRoleById = async (roleId) => {
  return apiRequest(`/api/admin/roles/${roleId}`);
};

/**
 * Create new role
 */
export const createRole = async (roleData) => {
  return apiRequest('/api/admin/roles', {
    method: 'POST',
    body: JSON.stringify(roleData),
  });
};

/**
 * Update role
 */
export const updateRole = async (roleId, roleData) => {
  return apiRequest(`/api/admin/roles/${roleId}`, {
    method: 'PUT',
    body: JSON.stringify(roleData),
  });
};

/**
 * Delete role
 */
export const deleteRole = async (roleId) => {
  return apiRequest(`/api/admin/roles/${roleId}`, {
    method: 'DELETE',
  });
};

/**
 * Get role's assigned pages
 */
export const getRolePages = async (roleId) => {
  return apiRequest(`/api/admin/roles/${roleId}/pages`);
};

/**
 * Assign pages to role
 */
export const assignPagesToRole = async (roleId, pages) => {
  return apiRequest(`/api/admin/roles/${roleId}/pages`, {
    method: 'POST',
    body: JSON.stringify({ pages }),
  });
};

/**
 * Remove page from role
 */
export const removePageFromRole = async (roleId, pageId) => {
  return apiRequest(`/api/admin/roles/${roleId}/pages/${pageId}`, {
    method: 'DELETE',
  });
};

/**
 * Clone role with all permissions
 */
export const cloneRole = async (roleId, cloneData) => {
  return apiRequest(`/api/admin/roles/${roleId}/clone`, {
    method: 'POST',
    body: JSON.stringify(cloneData),
  });
};

// ============================================================================
// PAGE QUERIES (Read-only for Role Management)
// ============================================================================

/**
 * Get all pages (read-only for role assignment)
 */
export const getPages = async () => {
  return apiRequest('/api/admin/pages');
};

/**
 * Get page categories (read-only for role assignment)
 */
export const getPageCategories = async () => {
  return apiRequest('/api/admin/pages/categories');
};

// ============================================================================
// USER PAGES (Non-Admin Endpoint)
// ============================================================================

/**
 * Get current user's accessible pages
 */
export const getCurrentUserPages = async () => {
  return apiRequest('/api/user/pages');
};

const rbacApi = {
  // User Management
  getUsers,
  getUserById,
  createUser,
  updateUser,
  deleteUser,
  resetUserPassword,
  toggleUserStatus,
  getUserRoles,
  assignRolesToUser,
  removeRoleFromUser,
  toggleUserAdmin,
  getUserPages,

  // Role Management
  getRoles,
  getRoleById,
  createRole,
  updateRole,
  deleteRole,
  getRolePages,
  assignPagesToRole,
  removePageFromRole,

  // Role Operations
  cloneRole,

  // Page Queries (read-only for role assignment)
  getPages,
  getPageCategories,

  // User Pages
  getCurrentUserPages,
};

export default rbacApi;
