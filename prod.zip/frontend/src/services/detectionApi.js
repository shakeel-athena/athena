// Detection API Service
// Connects to the Response Backend running on port 5000

// Response Backend Alerts API (for Wazuh & Suricata unified alerts)
// MUST be configured via environment variable for production
const RESPONSE_API_BASE_URL = process.env.REACT_APP_API_URL || (process.env.REACT_APP_API_BASE_URL && `${process.env.REACT_APP_API_BASE_URL}/api`);

// Helper to convert time range to hours
const convertTimeRangeToHours = (timeRange) => {
  if (timeRange === 'all') {
    return 0; // 0 means no time filter - query ALL alerts
  }
  const rangeMap = {
    '1h': 1,
    '6h': 6,
    '12h': 12,
    '24h': 24,
    '7d': 168,
    '30d': 720
  };
  return rangeMap[timeRange] || 24;
};

// ==================== WAZUH ALERTS API ====================

// Get Wazuh alerts from Response Backend
export const fetchWazuhAlerts = async (filters = {}) => {
  const params = new URLSearchParams();

  if (filters.rule_level) params.append('rule_level', filters.rule_level);
  if (filters.limit) params.append('limit', filters.limit || 100);

  // Convert time_range to hours
  const timeRangeHours = filters.time_range ? convertTimeRangeToHours(filters.time_range) : 24;
  params.append('time_range_hours', timeRangeHours);

  const url = `${RESPONSE_API_BASE_URL}/alerts/wazuh?${params.toString()}`;
  const response = await fetch(url);

  if (!response.ok) {
    throw new Error(`Failed to fetch Wazuh alerts: ${response.statusText}`);
  }

  const json = await response.json();
  return json.data || json;
};

// ==================== SURICATA ALERTS API ====================

// Get Suricata alerts from Response Backend
export const fetchSuricataAlerts = async (filters = {}) => {
  const params = new URLSearchParams();

  if (filters.severity) params.append('severity', filters.severity);
  if (filters.limit) params.append('limit', filters.limit || 100);

  // Convert time_range to hours
  const timeRangeHours = filters.time_range ? convertTimeRangeToHours(filters.time_range) : 24;
  params.append('time_range_hours', timeRangeHours);

  const url = `${RESPONSE_API_BASE_URL}/alerts/suricata?${params.toString()}`;
  const response = await fetch(url);

  if (!response.ok) {
    throw new Error(`Failed to fetch Suricata alerts: ${response.statusText}`);
  }

  const json = await response.json();
  return json.data || json;
};

// ==================== UNIFIED ALERTS API ====================

// Get unified alerts (Wazuh + Suricata combined) from Response Backend
export const fetchUnifiedAlerts = async (filters = {}) => {
  const params = new URLSearchParams();

  if (filters.severity) params.append('severity', filters.severity);
  if (filters.source) params.append('source', filters.source);
  if (filters.limit) params.append('limit', filters.limit || 100);
  if (filters.offset) params.append('offset', filters.offset);
  if (filters.search) params.append('search', filters.search);
  if (filters.return_total) params.append('return_total', 'true');

  // Sort parameters - default to newest first
  const sortField = filters.sort_field || 'timestamp';
  const sortDirection = filters.sort_direction || 'desc';
  params.append('sort_field', sortField);
  params.append('sort_direction', sortDirection);

  // Convert time_range to hours
  const timeRangeHours = filters.time_range ? convertTimeRangeToHours(filters.time_range) : 24;
  params.append('time_range_hours', timeRangeHours);

  // Get analyst from localStorage for mute rule filtering
  const analyst = localStorage.getItem('username') || 'unknown';
  params.append('analyst', analyst);

  const url = `${RESPONSE_API_BASE_URL}/alerts?${params.toString()}`;
  const response = await fetch(url);

  if (!response.ok) {
    throw new Error(`Failed to fetch unified alerts: ${response.statusText}`);
  }

  const json = await response.json();
  return json.data || json;
};

// Get agents list from Response Backend
export const fetchAgents = async () => {
  try {
    const url = `${RESPONSE_API_BASE_URL}/alerts/agents`;
    const response = await fetch(url);
    if (!response.ok) {
      throw new Error(`Failed to fetch agents: ${response.status}`);
    }
    const json = await response.json();
    // API returns {data: {agents: [...], summary: {...}, count: N}}
    return json.data?.agents || [];
  } catch (error) {
    console.error('Error fetching agents:', error);
    return [];
  }
};

// ==================== TOPOLOGY THREAT ACTORS API ====================

// Get threat actors for Network Topology visualization
export const fetchTopologyThreatActors = async (params = {}) => {
  try {
    const {
      time_range = '24h',
      limit = 20,
      min_severity = 'High',
      include_internal = false
    } = params;

    const queryParams = new URLSearchParams({
      time_range,
      limit: String(limit),
      min_severity,
      include_internal: String(include_internal)
    });

    const url = `${RESPONSE_API_BASE_URL}/topology/threat-actors?${queryParams.toString()}`;
    const response = await fetch(url);

    if (!response.ok) {
      throw new Error(`Failed to fetch threat actors: ${response.status}`);
    }

    const json = await response.json();
    return json.data || json;
  } catch (error) {
    console.error('Error fetching threat actors:', error);
    return {
      threat_actors: [],
      total_filtered: 0,
      showing: 0,
      error: error.message
    };
  }
};

// ==================== NETWORK TOPOLOGY API ====================

/**
 * Get all persisted topology nodes with their positions
 * @returns {Promise<Object>} Map of node_id -> node data
 */
export const fetchTopologyNodes = async () => {
  try {
    const url = `${RESPONSE_API_BASE_URL}/topology/nodes`;
    const response = await fetch(url);
    if (!response.ok) {
      throw new Error(`Failed to fetch topology nodes: ${response.status}`);
    }
    const json = await response.json();
    return json.data || {};
  } catch (error) {
    console.error('Error fetching topology nodes:', error);
    return {};
  }
};

/**
 * Get the full topology (nodes + clusters)
 * @returns {Promise<Object>} { nodes: {}, clusters: {} }
 */
export const fetchFullTopology = async () => {
  try {
    const url = `${RESPONSE_API_BASE_URL}/topology/`;
    const response = await fetch(url);
    if (!response.ok) {
      throw new Error(`Failed to fetch full topology: ${response.status}`);
    }
    const json = await response.json();
    return json.data || { nodes: {}, clusters: {} };
  } catch (error) {
    console.error('Error fetching full topology:', error);
    return { nodes: {}, clusters: {} };
  }
};

/**
 * Update a single node's position (called on drag-end)
 * @param {string} nodeId - The node ID
 * @param {Object} position - { x, y, z, position_locked }
 * @returns {Promise<boolean>} Success status
 */
export const updateNodePosition = async (nodeId, position) => {
  try {
    const safeNodeId = encodeURIComponent(nodeId);
    const url = `${RESPONSE_API_BASE_URL}/topology/nodes/${safeNodeId}/position`;
    const response = await fetch(url, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(position),
    });
    return response.ok;
  } catch (error) {
    console.error(`Error updating position for node ${nodeId}:`, error);
    return false;
  }
};

/**
 * Update a single node's properties
 * @param {string} nodeId - The node ID
 * @param {Object} data - Node properties to update
 * @returns {Promise<boolean>} Success status
 */
export const updateTopologyNode = async (nodeId, data) => {
  try {
    const safeNodeId = encodeURIComponent(nodeId);
    const url = `${RESPONSE_API_BASE_URL}/topology/nodes/${safeNodeId}`;
    const response = await fetch(url, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data),
    });
    return response.ok;
  } catch (error) {
    console.error(`Error updating node ${nodeId}:`, error);
    return false;
  }
};

/**
 * Bulk update multiple nodes (called on layout save)
 * @param {Object} nodes - Map of node_id -> node data
 * @returns {Promise<boolean>} Success status
 */
export const bulkUpdateTopologyNodes = async (nodes) => {
  try {
    const url = `${RESPONSE_API_BASE_URL}/topology/nodes/bulk`;
    const response = await fetch(url, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ nodes }),
    });
    return response.ok;
  } catch (error) {
    console.error('Error bulk updating topology nodes:', error);
    return false;
  }
};

// ==================== NIDS DASHBOARD API ====================

/**
 * Get NIDS dashboard overview data
 * @param {string} start - Start time (e.g., 'now-24h')
 * @param {string} end - End time (e.g., 'now')
 * @param {Object} filters - Optional filters
 * @returns {Promise<Object>} Dashboard overview data
 */
export const fetchNIDSOverview = async (start = 'now-24h', end = 'now', filters = {}) => {
  try {
    const params = new URLSearchParams({ start, end });

    // Add optional filters
    if (filters.category) params.append('category', filters.category);
    if (filters.signature) params.append('signature', filters.signature);
    if (filters.severity) params.append('severity', filters.severity);
    if (filters.srcIp) params.append('srcIp', filters.srcIp);
    if (filters.destIp) params.append('destIp', filters.destIp);
    if (filters.serviceName) params.append('serviceName', filters.serviceName);

    const url = `${RESPONSE_API_BASE_URL}/nids/overview?${params.toString()}`;
    const response = await fetch(url);

    if (!response.ok) {
      throw new Error(`Failed to fetch NIDS overview: ${response.statusText}`);
    }

    const json = await response.json();
    return json.data || json;
  } catch (error) {
    console.error('Error fetching NIDS overview:', error);
    throw error;
  }
};

/**
 * Get NIDS timeline data for charts
 * @param {Object} params - Query parameters
 * @returns {Promise<Object>} Timeline data
 */
export const fetchNIDSTimeline = async (params = {}) => {
  try {
    const {
      start = 'now-24h',
      end = 'now',
      interval = 'auto',
      category,
      signature,
      severity
    } = params;

    const queryParams = new URLSearchParams({ start, end, interval });
    if (category) queryParams.append('category', category);
    if (signature) queryParams.append('signature', signature);
    if (severity) queryParams.append('severity', severity);

    const url = `${RESPONSE_API_BASE_URL}/nids/timeline?${queryParams.toString()}`;
    const response = await fetch(url);

    if (!response.ok) {
      throw new Error(`Failed to fetch NIDS timeline: ${response.statusText}`);
    }

    const json = await response.json();
    return json.data || json;
  } catch (error) {
    console.error('Error fetching NIDS timeline:', error);
    throw error;
  }
};

/**
 * Get NIDS network analysis data
 * @param {string} start - Start time
 * @param {string} end - End time
 * @param {number} limit - Number of top items
 * @param {Object} filters - Optional filters
 * @returns {Promise<Object>} Network analysis data
 */
export const fetchNIDSNetworkAnalysis = async (start = 'now-24h', end = 'now', limit = 10, filters = {}) => {
  try {
    const params = new URLSearchParams({ start, end, limit: String(limit) });

    // Add optional filters
    if (filters.category) params.append('category', filters.category);
    if (filters.signature) params.append('signature', filters.signature);
    if (filters.severity) params.append('severity', filters.severity);
    if (filters.srcIp) params.append('srcIp', filters.srcIp);
    if (filters.destIp) params.append('destIp', filters.destIp);
    if (filters.serviceName) params.append('serviceName', filters.serviceName);

    const url = `${RESPONSE_API_BASE_URL}/nids/network-analysis?${params.toString()}`;
    const response = await fetch(url);

    if (!response.ok) {
      throw new Error(`Failed to fetch network analysis: ${response.statusText}`);
    }

    const json = await response.json();
    return json.data || json;
  } catch (error) {
    console.error('Error fetching network analysis:', error);
    throw error;
  }
};

/**
 * Get NIDS events with filtering and pagination
 * @param {Object} params - Query parameters
 * @returns {Promise<Object>} Events data with pagination
 */
export const fetchNIDSEvents = async (params = {}) => {
  try {
    const {
      start = 'now-24h',
      end = 'now',
      limit = 20,
      offset = 0,
      category,
      signature,
      severity,
      srcIp,
      destIp,
      serviceName,
      search,
      sortField = 'timestamp',
      sortDirection = 'desc'
    } = params;

    const queryParams = new URLSearchParams({
      start,
      end,
      limit: String(limit),
      offset: String(offset),
      sortField,
      sortDirection
    });

    if (category) queryParams.append('category', category);
    if (signature) queryParams.append('signature', signature);
    if (severity) queryParams.append('severity', severity);
    if (srcIp) queryParams.append('srcIp', srcIp);
    if (destIp) queryParams.append('destIp', destIp);
    if (serviceName) queryParams.append('serviceName', serviceName);
    if (search) queryParams.append('search', search);

    const url = `${RESPONSE_API_BASE_URL}/nids/events?${queryParams.toString()}`;
    const response = await fetch(url);

    if (!response.ok) {
      throw new Error(`Failed to fetch NIDS events: ${response.statusText}`);
    }

    const json = await response.json();
    return json.data || json;
  } catch (error) {
    console.error('Error fetching NIDS events:', error);
    throw error;
  }
};

/**
 * Get NIDS filter options
 * @param {string} start - Start time
 * @param {string} end - End time
 * @returns {Promise<Object>} Available filter options
 */
export const fetchNIDSFilters = async (start = 'now-24h', end = 'now') => {
  try {
    const params = new URLSearchParams({ start, end });
    const url = `${RESPONSE_API_BASE_URL}/nids/filters?${params.toString()}`;
    const response = await fetch(url);

    if (!response.ok) {
      throw new Error(`Failed to fetch NIDS filters: ${response.statusText}`);
    }

    const json = await response.json();
    return json.data || json;
  } catch (error) {
    console.error('Error fetching NIDS filters:', error);
    throw error;
  }
};

/**
 * Get NIDS event details by ID
 * @param {string} eventId - Event document ID
 * @returns {Promise<Object>} Event details
 */
export const fetchNIDSEventById = async (eventId) => {
  try {
    const url = `${RESPONSE_API_BASE_URL}/nids/events/${encodeURIComponent(eventId)}`;
    const response = await fetch(url);

    if (!response.ok) {
      throw new Error(`Failed to fetch event details: ${response.statusText}`);
    }

    const json = await response.json();
    return json.data || json;
  } catch (error) {
    console.error('Error fetching event details:', error);
    throw error;
  }
};
