/**
 * API Client with Keycloak JWT Token Injection
 *
 * This module wraps all API calls to automatically inject the JWT bearer token
 * from Keycloak into the Authorization header.
 */

import { getKeycloakInstance, initKeycloak } from '../config/keycloak';

/**
 * Get the current access token from Keycloak with enhanced error handling
 * @returns {Promise<string|null>} Access token or null if not authenticated
 */
const getAccessToken = async () => {
  try {
    // Ensure Keycloak is initialized before making requests
    const keycloak = getKeycloakInstance();
    
    // Check if Keycloak is initialized, if not, initialize it
    if (!keycloak.authenticated && !keycloak.didInitialize) {
      console.log('Keycloak not initialized, initializing now...');
      await initKeycloak();
    }

    if (!keycloak.authenticated) {
      console.warn('User not authenticated');
      return null;
    }

    // Check if token needs refresh (less than 30 seconds until expiry)
    try {
      const isTokenExpired = keycloak.isTokenExpired(30);
      if (isTokenExpired) {
        console.log('Token expired, refreshing...');
        const refreshed = await keycloak.updateToken(30);
        if (refreshed) {
          console.log('Token was refreshed successfully');
        }
      }
    } catch (refreshError) {
      console.error('Failed to refresh token:', refreshError);
      // Token refresh failed - return null and let ProtectedRoute handle re-authentication
      // Don't trigger login from API layer to avoid redirect loops
      return null;
    }

    return keycloak.token;
  } catch (error) {
    console.error('Error getting access token:', error);
    // Try to initialize Keycloak if it failed
    try {
      await initKeycloak();
      const keycloak = getKeycloakInstance();
      return keycloak.authenticated ? keycloak.token : null;
    } catch (initError) {
      console.error('Critical: Failed to initialize Keycloak:', initError);
      return null;
    }
  }
};

/**
 * Enhanced fetch wrapper that automatically adds JWT token
 * @param {string} url - URL to fetch
 * @param {object} options - Fetch options
 * @returns {Promise<Response>} Fetch response
 */
export const authenticatedFetch = async (url, options = {}) => {
  const token = await getAccessToken();

  const headers = {
    ...options.headers,
  };

  // Add Authorization header if token is available
  if (token) {
    headers['Authorization'] = `Bearer ${token}`;
  }

  return fetch(url, {
    ...options,
    headers,
  });
};

/**
 * Helper function to make authenticated API requests with JSON handling
 * @param {string} url - Full URL or endpoint
 * @param {object} options - Fetch options
 * @returns {Promise<any>} Parsed JSON response
 */
export const apiRequest = async (url, options = {}) => {
  const response = await authenticatedFetch(url, {
    ...options,
    headers: {
      'Content-Type': 'application/json',
      ...options.headers,
    },
  });

  if (!response.ok) {
    const error = await response.json().catch(() => ({
      error: 'Request failed',
      status: response.status,
      statusText: response.statusText
    }));

    // Handle 401 Unauthorized
    if (response.status === 401) {
      console.error('Unauthorized access - token may have expired');
      // Don't trigger login from API layer to avoid redirect loops
      // The ProtectedRoute will handle re-authentication on the next render
      const authError = new Error('Authentication required');
      authError.status = 401;
      throw authError;
    }

    // Handle 403 Forbidden
    if (response.status === 403) {
      throw new Error('Access denied - insufficient permissions');
    }

    throw new Error(error.error || error.message || `Request failed with status ${response.status}`);
  }

  const json = await response.json();
  return (json && typeof json === 'object' && Object.prototype.hasOwnProperty.call(json, 'data'))
    ? json.data
    : json;
};

/**
 * Create an API client for a specific base URL
 * @param {string} baseUrl - Base URL for the API
 * @returns {object} API client with common HTTP methods
 */
export const createApiClient = (baseUrl) => {
  return {
    get: async (endpoint, options = {}) => {
      return apiRequest(`${baseUrl}${endpoint}`, {
        method: 'GET',
        ...options,
      });
    },

    post: async (endpoint, data, options = {}) => {
      return apiRequest(`${baseUrl}${endpoint}`, {
        method: 'POST',
        body: JSON.stringify(data),
        ...options,
      });
    },

    put: async (endpoint, data, options = {}) => {
      return apiRequest(`${baseUrl}${endpoint}`, {
        method: 'PUT',
        body: JSON.stringify(data),
        ...options,
      });
    },

    patch: async (endpoint, data, options = {}) => {
      return apiRequest(`${baseUrl}${endpoint}`, {
        method: 'PATCH',
        body: JSON.stringify(data),
        ...options,
      });
    },

    delete: async (endpoint, options = {}) => {
      return apiRequest(`${baseUrl}${endpoint}`, {
        method: 'DELETE',
        ...options,
      });
    },
  };
};

// Export default clients for backend services
export const responseApiClient = createApiClient(
  process.env.REACT_APP_API_URL || 'http://localhost:5000/api'
);

export const detectionApiClient = createApiClient(
  process.env.REACT_APP_DETECTION_API_URL || 'http://localhost:5001/api'
);

const apiClient = {
  authenticatedFetch,
  apiRequest,
  createApiClient,
  responseApiClient,
  detectionApiClient,
};

export default apiClient;
