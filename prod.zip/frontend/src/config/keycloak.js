import Keycloak from 'keycloak-js';

// Keycloak client configuration
const keycloakConfig = {
  url: process.env.REACT_APP_KEYCLOAK_URL || 'http://localhost:8080',
  realm: process.env.REACT_APP_KEYCLOAK_REALM || 'athena-security',
  clientId: process.env.REACT_APP_KEYCLOAK_CLIENT_ID || 'athena-frontend',
};

// Singleton instance to prevent double initialization in React StrictMode
let keycloakInstance = null;
let isInitializing = false;
let isInitialized = false;

// Enhanced Keycloak initialization with proper timing management
const getKeycloakInstance = () => {
  if (!keycloakInstance) {
    keycloakInstance = new Keycloak(keycloakConfig);

    // Override the init method to prevent double initialization with better timing
    const originalInit = keycloakInstance.init.bind(keycloakInstance);
    keycloakInstance.init = function(...args) {
      if (isInitialized) {
        console.warn('Keycloak already initialized, skipping duplicate initialization');
        return Promise.resolve(keycloakInstance.authenticated || false);
      }
      if (isInitializing) {
        console.warn('Keycloak initialization already in progress');
        return new Promise((resolve, reject) => {
          const checkInitialized = setInterval(() => {
            if (isInitialized) {
              clearInterval(checkInitialized);
              resolve(keycloakInstance.authenticated || false);
            }
          }, 50);
          // Add timeout to prevent infinite waiting
          setTimeout(() => {
            clearInterval(checkInitialized);
            reject(new Error('Keycloak initialization timeout'));
          }, 10000);
        });
      }
      isInitializing = true;
      return originalInit(...args).then((authenticated) => {
        isInitialized = true;
        isInitializing = false;
        console.log('Keycloak initialization completed:', { authenticated, initialized: isInitialized });
        return authenticated;
      }).catch((error) => {
        isInitializing = false;
        console.error('Keycloak initialization failed:', error);
        throw error;
      });
    };
  }
  return keycloakInstance;
};

// Enhanced initialization function with proper async/await support
export const initKeycloak = (customOptions = {}) => {
  return new Promise((resolve, reject) => {
    const keycloak = getKeycloakInstance();
    
    if (isInitialized) {
      resolve(keycloak);
      return;
    }

    const initOptions = {
      ...keycloakInitOptions,
      ...customOptions,
      promiseType: 'native',
      flow: 'standard',
      enableLogging: process.env.NODE_ENV === 'development',
      checkLoginIframe: false,
    };

    keycloak.init(initOptions)
      .then(authenticated => {
        if (authenticated) {
          console.log('Keycloak authentication successful');
          resolve(keycloak);
        } else {
          console.warn('Keycloak authentication failed - user not authenticated');
          reject(new Error('Keycloak authentication failed - user not authenticated'));
        }
      })
      .catch(error => {
        console.error('Keycloak initialization error:', error);
        reject(error);
      });
  });
};

// Create Keycloak instance (singleton)
const keycloak = getKeycloakInstance();

// Keycloak initialization options
export const keycloakInitOptions = {
  // Check SSO status without forcing login
  onLoad: 'check-sso',

  // Use PKCE for enhanced security (required for public clients)
  pkceMethod: 'S256',

  // Silent check SSO using iframe (disabled due to CSP restrictions)
  // silentCheckSsoRedirectUri: window.location.origin + '/silent-check-sso.html',

  // Check login iframe settings (disabled due to CSP restrictions)
  checkLoginIframe: false,

  // Enable token refresh
  enableLogging: process.env.NODE_ENV === 'development',
};

// Export both the instance and the getter function
export { getKeycloakInstance };
export default keycloak;
