// Simple theme configuration for EUI provider
export const themeConfig = {
  // Enable dark mode by default
  colorMode: 'dark',
  // Custom modifications for security theme
  modifications: {
    colors: {
      // Dark theme colors inspired by Wazuh SOC
      BODY: '#0f172a',
      TEXT: '#f8fafc',
      TEXT_SUBDUED: '#94a3b8',
      ACCENT_TEXT: '#3b82f6',
      // Security-themed colors
      DANGER: '#dc2626',
      WARNING: '#eab308',
      SUCCESS: '#16a34a',
      PRIMARY: '#3b82f6',
      // Background colors
      BACKGROUND_BASE_COLOR: '#1e293b',
      BACKGROUND_APP_COLOR: '#0f172a',
      BACKGROUND_DISABLED_COLOR: '#334155',
      // Border colors
      BORDER_COLOR: '#475569',
      BORDER_DISABLED_COLOR: '#64748b',
      // Additional EUI required colors
      SHADE_0: '#0f172a',
      SHADE_1: '#1e293b',
      SHADE_2: '#334155',
      SHADE_3: '#475569',
      SHADE_4: '#64748b',
      SHADE_5: '#94a3b8',
      SHADE_6: '#cbd5e1',
      SHADE_7: '#e2e8f0',
      SHADE_8: '#f8fafc',
      // Text colors
      TEXT_TITLE: '#f8fafc',
      TEXT_DEFAULT: '#e2e8f0',
      // TEXT_SUBDUED defined above
      TEXT_DISABLED: '#64748b',
      TEXT_INVERTIBLE: '#0f172a',
      TEXT_HINT: '#64748b',
      TEXT_GHOST: '#475569',
      // Accent colors
      ACCENT_PRIMARY: '#3b82f6',
      ACCENT_PRIMARY_TEXT: '#ffffff',
      ACCENT_SECONDARY: '#8b5cf6',
      ACCENT_SECONDARY_TEXT: '#ffffff',
      ACCENT_SUCCESS: '#16a34a',
      ACCENT_SUCCESS_TEXT: '#ffffff',
      ACCENT_WARNING: '#eab308',
      ACCENT_WARNING_TEXT: '#000000',
      ACCENT_DANGER: '#dc2626',
      ACCENT_DANGER_TEXT: '#ffffff',
    },
    // Add font configuration
    font: {
      family: "'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', 'Roboto', 'Oxygen', 'Ubuntu', 'Cantarell', 'Fira Sans', 'Droid Sans', 'Helvetica Neue', sans-serif",
      scale: {
        xs: '0.75rem',
        s: '0.875rem',
        m: '1rem',
        l: '1.125rem',
        xl: '1.25rem',
        '2xl': '1.5rem',
        '3xl': '1.875rem',
        '4xl': '2.25rem',
        '5xl': '3rem',
      },
      weight: {
        light: 300,
        regular: 400,
        medium: 500,
        semiBold: 600,
        bold: 700,
      },
    },
    // Add size configuration
    size: {
      xs: '4px',
      s: '8px',
      m: '16px',
      l: '24px',
      xl: '32px',
      xxl: '48px',
    },
    // Add border radius configuration
    border: {
      radius: {
        small: '2px',
        medium: '4px',
        large: '8px',
      },
      width: {
        thin: '1px',
        medium: '2px',
        thick: '4px',
      },
    },
    // Add shadow configuration
    shadow: {
      small: '0 1px 2px 0 rgba(0, 0, 0, 0.05)',
      medium: '0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -1px rgba(0, 0, 0, 0.06)',
      large: '0 10px 15px -3px rgba(0, 0, 0, 0.1), 0 4px 6px -2px rgba(0, 0, 0, 0.05)',
    },
  },
  // Add breakpoint configuration to prevent EUI theme errors
  breakpoint: {
    xs: 0,
    sm: 576,
    md: 768,
    lg: 992,
    xl: 1200,
    xxl: 1400,
  },
};
