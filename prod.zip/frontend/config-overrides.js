const webpack = require('webpack');

module.exports = function override(config, env) {
  // Suppress source map warnings from @react-keycloak packages
  config.ignoreWarnings = [
    {
      module: /@react-keycloak/,
      message: /Failed to parse source map/,
    },
    function (warning) {
      return (
        warning.module &&
        warning.module.resource &&
        warning.module.resource.includes('node_modules/@react-keycloak') &&
        warning.message &&
        warning.message.includes('source map')
      );
    },
  ];

  // Add fallback for missing source maps
  config.resolve.fallback = {
    ...config.resolve.fallback,
    "fs": false,
    "path": false,
    "os": false
  };

  // Fix Emotion CSS prop issues with EUI
  config.resolve.alias = {
    ...config.resolve.alias,
    '@emotion/styled': require.resolve('@emotion/styled'),
    '@emotion/react': require.resolve('@emotion/react'),
  };

  // Ensure Emotion is properly transpiled
  config.module.rules.push({
    test: /\.js$/,
    include: /node_modules\/(@elastic\/eui|@emotion)/,
    use: {
      loader: 'babel-loader',
      options: {
        presets: ['@babel/preset-env', '@babel/preset-react'],
        plugins: ['@emotion/babel-plugin'],
      },
    },
  });

  return config;
};

module.exports.devServer = function(configFunction) {
  return function(proxy, allowedHost) {
    const config = configFunction(proxy, allowedHost);

    // Fix allowedHosts configuration
    config.allowedHosts = 'all';

    return config;
  };
};
