"""
Database ORM Models

This module contains all SQLAlchemy ORM models for the Athena
Network Response Management system.
"""

from datetime import datetime
from sqlalchemy import Column, Integer, String, DateTime, Text, JSON, Index, Boolean, ForeignKey
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.orm import relationship
from database.connection import Base


class BlockedIP(Base):
    """
    Model for storing blocked IP addresses
    
    Attributes:
        id: Primary key
        created_date: Timestamp when the IP was blocked
        ip: The IP address (IPv4 or IPv6)
        module: The module that blocked the IP (e.g., 'WAF', 'Firewall', 'Manual')
    """
    __tablename__ = 'blocked_ips'
    
    id = Column(Integer, primary_key=True, autoincrement=True)
    created_date = Column(DateTime, default=datetime.utcnow, nullable=False, index=True)
    ip = Column(String(45), nullable=False, index=True)  # IPv4 (15 chars) or IPv6 (45 chars)
    module = Column(String(100), nullable=False, index=True)
    
    # Add composite index for common queries
    __table_args__ = (
        Index('idx_ip_module', 'ip', 'module'),
        Index('idx_module_created', 'module', 'created_date'),
    )
    
    def __repr__(self):
        return f"<BlockedIP(id={self.id}, ip={self.ip}, module={self.module}, created={self.created_date})>"
    
    def to_dict(self):
        """Convert model to dictionary"""
        return {
            'id': self.id,
            'created_date': self.created_date.isoformat() if self.created_date else None,
            'ip': self.ip,
            'module': self.module
        }

class SecurityAlert(Base):
    """
    Model for storing security alerts
    
    Optional model for future use
    """
    __tablename__ = 'security_alerts'
    
    id = Column(Integer, primary_key=True, autoincrement=True)
    timestamp = Column(DateTime, default=datetime.utcnow, nullable=False, index=True)
    alert_type = Column(String(100), nullable=False, index=True)
    severity = Column(String(20), nullable=False, index=True)
    source_ip = Column(String(45), nullable=True)
    destination_ip = Column(String(45), nullable=True)
    description = Column(Text, nullable=True)
    alert_metadata = Column(JSON, nullable=True)
    status = Column(String(20), default='pending', nullable=False, index=True)
    
    def __repr__(self):
        return f"<SecurityAlert(id={self.id}, type={self.alert_type}, severity={self.severity})>"
    
    def to_dict(self):
        """Convert model to dictionary"""
        return {
            'id': self.id,
            'timestamp': self.timestamp.isoformat() if self.timestamp else None,
            'alert_type': self.alert_type,
            'severity': self.severity,
            'source_ip': self.source_ip,
            'destination_ip': self.destination_ip,
            'description': self.description,
            'alert_metadata': self.alert_metadata,
            'status': self.status
        } 
           
class ResponseAction(Base):
    """
    Model for storing response actions
    
    Optional model for future use
    """
    __tablename__ = 'response_actions'
    
    id = Column(Integer, primary_key=True, autoincrement=True)
    alert_id = Column(Integer, nullable=True, index=True)
    timestamp = Column(DateTime, default=datetime.utcnow, nullable=False, index=True)
    action_type = Column(String(100), nullable=False, index=True)
    target = Column(String(255), nullable=True)
    status = Column(String(20), default='pending', nullable=False, index=True)
    result = Column(JSON, nullable=True)
    
    def __repr__(self):
        return f"<ResponseAction(id={self.id}, type={self.action_type}, status={self.status})>"
    
    def to_dict(self):
        """Convert model to dictionary"""
        return {
            'id': self.id,
            'alert_id': self.alert_id,
            'timestamp': self.timestamp.isoformat() if self.timestamp else None,
            'action_type': self.action_type,
            'target': self.target,
            'status': self.status,
            'result': self.result
        }


# =============================================================================
# RBAC (Role-Based Access Control) Models
# =============================================================================

class User(Base):
    """
    Model for user accounts synchronized with Keycloak

    Attributes:
        id: Primary key
        keycloak_user_id: UUID from Keycloak (sub claim in JWT)
        username: Login username (unique)
        email: Email address (unique)
        full_name: Full display name
        is_admin: System admin flag (bypasses all RBAC checks)
        is_active: Account enabled/disabled status
        created_at: Account creation timestamp
        updated_at: Last update timestamp
    """
    __tablename__ = 'users'

    id = Column(Integer, primary_key=True, autoincrement=True)
    keycloak_user_id = Column(UUID(as_uuid=True), unique=True, nullable=False, index=True)
    username = Column(String(255), unique=True, nullable=False, index=True)
    email = Column(String(255), unique=True, nullable=False, index=True)
    full_name = Column(String(255), nullable=True)
    is_admin = Column(Boolean, default=False, nullable=False, index=True)
    is_active = Column(Boolean, default=True, nullable=False, index=True)
    created_at = Column(DateTime, default=datetime.utcnow, nullable=False)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow, nullable=False)

    # Relationships
    roles = relationship('UserRole', back_populates='user', cascade='all, delete-orphan')
    created_roles = relationship('Role', back_populates='creator', foreign_keys='Role.created_by')

    def __repr__(self):
        return f"<User(id={self.id}, username={self.username}, email={self.email}, is_admin={self.is_admin})>"

    def to_dict(self):
        """Convert model to dictionary"""
        return {
            'id': self.id,
            'keycloak_user_id': str(self.keycloak_user_id),
            'username': self.username,
            'email': self.email,
            'full_name': self.full_name,
            'is_admin': self.is_admin,
            'is_active': self.is_active,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'updated_at': self.updated_at.isoformat() if self.updated_at else None
        }


class Role(Base):
    """
    Model for role definitions

    Attributes:
        id: Primary key
        role_name: Unique identifier (e.g., 'security-analyst')
        display_name: Friendly name for UI
        description: Role description
        is_system_role: Protected system roles cannot be deleted
        priority: Higher = more privileged (for UI sorting)
        created_at: Creation timestamp
        updated_at: Last update timestamp
        created_by: Foreign key to user who created this role
    """
    __tablename__ = 'roles'

    id = Column(Integer, primary_key=True, autoincrement=True)
    role_name = Column(String(255), unique=True, nullable=False, index=True)
    display_name = Column(String(255), nullable=False)
    description = Column(Text, nullable=True)
    is_system_role = Column(Boolean, default=False, nullable=False)
    priority = Column(Integer, default=0, nullable=False, index=True)
    created_at = Column(DateTime, default=datetime.utcnow, nullable=False)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow, nullable=False)
    created_by = Column(Integer, ForeignKey('users.id', ondelete='SET NULL'), nullable=True)

    # Relationships
    creator = relationship('User', back_populates='created_roles', foreign_keys=[created_by])
    user_assignments = relationship('UserRole', back_populates='role', cascade='all, delete-orphan')
    page_permissions = relationship('RolePage', back_populates='role', cascade='all, delete-orphan')

    def __repr__(self):
        return f"<Role(id={self.id}, role_name={self.role_name}, display_name={self.display_name})>"

    def to_dict(self):
        """Convert model to dictionary"""
        return {
            'id': self.id,
            'role_name': self.role_name,
            'display_name': self.display_name,
            'description': self.description,
            'is_system_role': self.is_system_role,
            'priority': self.priority,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'updated_at': self.updated_at.isoformat() if self.updated_at else None,
            'created_by': self.created_by
        }


class Page(Base):
    """
    Model for application pages/features

    Attributes:
        id: Primary key
        page_path: URL path (e.g., '/dashboard')
        page_name: Display name for UI
        page_category: Category for grouping
        description: Page description
        icon: Icon name for UI rendering
        display_order: Sort order in menus
        parent_page_id: Parent page for nested navigation
        is_active: Page enabled/disabled
        created_at: Creation timestamp
        updated_at: Last update timestamp
    """
    __tablename__ = 'pages'

    id = Column(Integer, primary_key=True, autoincrement=True)
    page_path = Column(String(255), unique=True, nullable=False, index=True)
    page_name = Column(String(255), nullable=False)
    page_category = Column(String(100), nullable=True, index=True)
    description = Column(Text, nullable=True)
    icon = Column(String(50), nullable=True)
    display_order = Column(Integer, default=0, nullable=False)
    parent_page_id = Column(Integer, ForeignKey('pages.id', ondelete='SET NULL'), nullable=True, index=True)
    is_active = Column(Boolean, default=True, nullable=False, index=True)
    created_at = Column(DateTime, default=datetime.utcnow, nullable=False)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow, nullable=False)

    # Relationships
    role_permissions = relationship('RolePage', back_populates='page', cascade='all, delete-orphan')
    parent = relationship('Page', remote_side=[id], backref='children')

    def __repr__(self):
        return f"<Page(id={self.id}, page_path={self.page_path}, page_name={self.page_name})>"

    def to_dict(self):
        """Convert model to dictionary"""
        return {
            'id': self.id,
            'page_path': self.page_path,
            'page_name': self.page_name,
            'page_category': self.page_category,
            'description': self.description,
            'icon': self.icon,
            'display_order': self.display_order,
            'parent_page_id': self.parent_page_id,
            'is_active': self.is_active,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'updated_at': self.updated_at.isoformat() if self.updated_at else None
        }


class UserRole(Base):
    """
    Model for user-to-role assignments (many-to-many)

    Attributes:
        id: Primary key
        user_id: Foreign key to users table
        role_id: Foreign key to roles table
        assigned_by: Foreign key to user who assigned this role
        assigned_at: Assignment timestamp
        expires_at: Optional expiration date (NULL = never expires)
    """
    __tablename__ = 'user_roles'

    __table_args__ = (
        Index('idx_user_roles_user', 'user_id'),
        Index('idx_user_roles_role', 'role_id'),
        Index('idx_user_roles_expires', 'expires_at'),
    )

    id = Column(Integer, primary_key=True, autoincrement=True)
    user_id = Column(Integer, ForeignKey('users.id', ondelete='CASCADE'), nullable=False)
    role_id = Column(Integer, ForeignKey('roles.id', ondelete='CASCADE'), nullable=False)
    assigned_by = Column(Integer, ForeignKey('users.id', ondelete='SET NULL'), nullable=True)
    assigned_at = Column(DateTime, default=datetime.utcnow, nullable=False)
    expires_at = Column(DateTime, nullable=True)

    # Relationships
    user = relationship('User', back_populates='roles', foreign_keys=[user_id])
    role = relationship('Role', back_populates='user_assignments')

    def __repr__(self):
        return f"<UserRole(id={self.id}, user_id={self.user_id}, role_id={self.role_id})>"

    def to_dict(self):
        """Convert model to dictionary"""
        return {
            'id': self.id,
            'user_id': self.user_id,
            'role_id': self.role_id,
            'assigned_by': self.assigned_by,
            'assigned_at': self.assigned_at.isoformat() if self.assigned_at else None,
            'expires_at': self.expires_at.isoformat() if self.expires_at else None
        }


class RolePage(Base):
    """
    Model for role-to-page permission mappings (many-to-many)

    Attributes:
        id: Primary key
        role_id: Foreign key to roles table
        page_id: Foreign key to pages table
        can_view: Permission to view the page
        can_edit: Permission to edit/modify content
        created_at: Permission granted timestamp
    """
    __tablename__ = 'role_pages'

    __table_args__ = (
        Index('idx_role_pages_role', 'role_id'),
        Index('idx_role_pages_page', 'page_id'),
        Index('idx_role_pages_view', 'can_view'),
        Index('idx_role_pages_edit', 'can_edit'),
    )

    id = Column(Integer, primary_key=True, autoincrement=True)
    role_id = Column(Integer, ForeignKey('roles.id', ondelete='CASCADE'), nullable=False)
    page_id = Column(Integer, ForeignKey('pages.id', ondelete='CASCADE'), nullable=False)
    can_view = Column(Boolean, default=True, nullable=False)
    can_edit = Column(Boolean, default=False, nullable=False)
    created_at = Column(DateTime, default=datetime.utcnow, nullable=False)

    # Relationships
    role = relationship('Role', back_populates='page_permissions')
    page = relationship('Page', back_populates='role_permissions')

    def __repr__(self):
        return f"<RolePage(id={self.id}, role_id={self.role_id}, page_id={self.page_id}, view={self.can_view}, edit={self.can_edit})>"

    def to_dict(self):
        """Convert model to dictionary"""
        return {
            'id': self.id,
            'role_id': self.role_id,
            'page_id': self.page_id,
            'can_view': self.can_view,
            'can_edit': self.can_edit,
            'created_at': self.created_at.isoformat() if self.created_at else None
        }


class AuditLog(Base):
    """
    Model for audit trail of all access attempts and actions

    Attributes:
        id: Primary key
        user_id: Foreign key to users table (nullable for anonymous access)
        username: Denormalized username for reporting
        action: Action type (e.g., 'page_access', 'user_created')
        page_path: What was accessed (if applicable)
        result: Outcome ('allowed' or 'denied')
        reason: Reason for denial (if applicable)
        ip_address: Client IP address
        user_agent: Browser/client user agent
        request_method: HTTP method (GET, POST, etc.)
        request_path: Full request path
        created_at: Event timestamp
    """
    __tablename__ = 'audit_log'

    __table_args__ = (
        Index('idx_audit_user', 'user_id'),
        Index('idx_audit_username', 'username'),
        Index('idx_audit_action', 'action'),
        Index('idx_audit_result', 'result'),
        Index('idx_audit_created', 'created_at'),
    )

    id = Column(Integer, primary_key=True, autoincrement=True)
    user_id = Column(Integer, ForeignKey('users.id', ondelete='SET NULL'), nullable=True)
    username = Column(String(255), nullable=True)
    action = Column(String(100), nullable=False)
    page_path = Column(String(255), nullable=True)
    result = Column(String(50), nullable=False)
    reason = Column(Text, nullable=True)
    ip_address = Column(String(45), nullable=True)
    user_agent = Column(Text, nullable=True)
    request_method = Column(String(10), nullable=True)
    request_path = Column(String(255), nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow, nullable=False, index=True)

    def __repr__(self):
        return f"<AuditLog(id={self.id}, action={self.action}, result={self.result}, username={self.username})>"

    def to_dict(self):
        """Convert model to dictionary"""
        return {
            'id': self.id,
            'user_id': self.user_id,
            'username': self.username,
            'action': self.action,
            'page_path': self.page_path,
            'result': self.result,
            'reason': self.reason,
            'ip_address': self.ip_address,
            'user_agent': self.user_agent,
            'request_method': self.request_method,
            'request_path': self.request_path,
            'created_at': self.created_at.isoformat() if self.created_at else None
        }

