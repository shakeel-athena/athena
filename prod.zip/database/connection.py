"""
Database Connection Module

This module provides database connection management utilities for the Athena
Network Response Management system. It includes connection pooling, session
management, and error handling.
"""

import logging
from contextlib import contextmanager
from typing import Optional

from sqlalchemy import create_engine, event, exc, pool, text
from sqlalchemy.orm import sessionmaker, scoped_session, Session
from sqlalchemy.ext.declarative import declarative_base

from database.config import DatabaseConfig

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

# Create declarative base for ORM models
Base = declarative_base()


class DatabaseConnection:
    """
    Database connection manager with connection pooling and session management
    """
    
    def __init__(self, config: Optional[DatabaseConfig] = None):
        """
        Initialize database connection manager
        
        Args:
            config: DatabaseConfig instance (uses default if not provided)
        """
        self.config = config or DatabaseConfig()
        self.engine = None
        self.session_factory = None
        self.scoped_session_factory = None
        self._initialized = False
    
    def initialize(self):
        """
        Initialize database engine and session factories
        
        Raises:
            Exception: If database initialization fails
        """
        if self._initialized:
            logger.warning("Database connection already initialized")
            return
        
        try:
            # Validate configuration
            is_valid, message = self.config.validate_config()
            if not is_valid:
                raise ValueError(f"Invalid database configuration: {message}")
            
            # Create engine with connection pooling
            self.engine = create_engine(
                self.config.DATABASE_URI,
                poolclass=pool.QueuePool,
                pool_size=self.config.SQLALCHEMY_POOL_SIZE,
                max_overflow=self.config.SQLALCHEMY_MAX_OVERFLOW,
                pool_timeout=self.config.SQLALCHEMY_POOL_TIMEOUT,
                pool_recycle=self.config.SQLALCHEMY_POOL_RECYCLE,
                pool_pre_ping=True,  # Verify connections before using them
                echo=self.config.SQLALCHEMY_ECHO,
                connect_args={
                    'connect_timeout': self.config.CONNECT_TIMEOUT,
                    'options': f'-c statement_timeout={self.config.STATEMENT_TIMEOUT}'
                }
            )
            
            # Set up event listeners
            self._setup_event_listeners()
            
            # Create session factories
            self.session_factory = sessionmaker(
                bind=self.engine,
                autocommit=False,
                autoflush=False,
                expire_on_commit=False
            )
            
            self.scoped_session_factory = scoped_session(self.session_factory)
            
            self._initialized = True
            logger.info("Database connection initialized successfully")
            
        except Exception as e:
            logger.error(f"Failed to initialize database connection: {str(e)}")
            raise
    
    def _setup_event_listeners(self):
        """Set up SQLAlchemy event listeners for connection management"""
        
        @event.listens_for(self.engine, "connect")
        def receive_connect(dbapi_conn, connection_record):
            """Log new database connections"""
            logger.debug("New database connection established")
        
        @event.listens_for(self.engine, "checkout")
        def receive_checkout(dbapi_conn, connection_record, connection_proxy):
            """Log connection checkouts from pool"""
            logger.debug("Connection checked out from pool")
        
        @event.listens_for(self.engine, "checkin")
        def receive_checkin(dbapi_conn, connection_record):
            """Log connection returns to pool"""
            logger.debug("Connection returned to pool")
    
    def get_session(self) -> Session:
        """
        Get a new database session
        
        Returns:
            Session: SQLAlchemy session object
            
        Raises:
            RuntimeError: If database connection is not initialized
        """
        if not self._initialized:
            raise RuntimeError("Database connection not initialized. Call initialize() first.")
        
        return self.scoped_session_factory()
    
    @contextmanager
    def session_scope(self):
        """
        Provide a transactional scope for database operations
        
        Usage:
            with db.session_scope() as session:
                # Your database operations here
                session.add(obj)
        
        Yields:
            Session: Database session with automatic commit/rollback
        """
        if not self._initialized:
            raise RuntimeError("Database connection not initialized. Call initialize() first.")
        
        session = self.scoped_session_factory()
        try:
            yield session
            session.commit()
        except exc.SQLAlchemyError as e:
            session.rollback()
            logger.error(f"Database error occurred: {str(e)}")
            raise
        except Exception as e:
            session.rollback()
            logger.error(f"Unexpected error occurred: {str(e)}")
            raise
        finally:
            session.close()
    
    def test_connection(self) -> bool:
        """
        Test database connection
        
        Returns:
            bool: True if connection successful, False otherwise
        """
        if not self._initialized:
            logger.error("Database connection not initialized")
            return False
        
        try:
            with self.engine.connect() as connection:
                connection.execute(text("SELECT 1"))
            logger.info("Database connection test successful")
            return True
        except Exception as e:
            logger.error(f"Database connection test failed: {str(e)}")
            return False
    
    def close(self):
        """Close database connection and cleanup resources"""
        if self._initialized:
            try:
                self.scoped_session_factory.remove()
                self.engine.dispose()
                self._initialized = False
                logger.info("Database connection closed successfully")
            except Exception as e:
                logger.error(f"Error closing database connection: {str(e)}")
                raise
    
    def create_all_tables(self):
        """
        Create all database tables defined in ORM models
        
        Note: This should be used carefully, preferably with migrations
        """
        if not self._initialized:
            raise RuntimeError("Database connection not initialized. Call initialize() first.")
        
        try:
            Base.metadata.create_all(self.engine)
            logger.info("Database tables created successfully")
        except Exception as e:
            logger.error(f"Error creating database tables: {str(e)}")
            raise
    
    def drop_all_tables(self):
        """
        Drop all database tables
        
        Warning: This is a destructive operation! Use with extreme caution.
        """
        if not self._initialized:
            raise RuntimeError("Database connection not initialized. Call initialize() first.")
        
        try:
            Base.metadata.drop_all(self.engine)
            logger.warning("All database tables dropped")
        except Exception as e:
            logger.error(f"Error dropping database tables: {str(e)}")
            raise


# Global database connection instance
db = DatabaseConnection()


# Convenience functions for easy import
def init_db(config: Optional[DatabaseConfig] = None):
    """
    Initialize the global database connection
    
    Args:
        config: Optional DatabaseConfig instance
    """
    global db
    if config:
        db = DatabaseConnection(config)
    db.initialize()


def get_db_session() -> Session:
    """
    Get a database session from the global connection
    
    Returns:
        Session: SQLAlchemy session object
    """
    return db.get_session()


def get_session_scope():
    """
    Get a session scope context manager
    
    Returns:
        Context manager for database sessions
    """
    return db.session_scope()


def close_db():
    """Close the global database connection"""
    db.close()


def test_db_connection() -> bool:
    """
    Test the global database connection
    
    Returns:
        bool: True if connection successful, False otherwise
    """
    return db.test_connection()

