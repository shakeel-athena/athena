"""
Athena Network Response Management - Database Package

This package provides database configuration, connection management, and
ORM models for the Athena security response system.

Usage:
    from database import init_db, get_session_scope
    
    # Initialize database
    init_db()
    
    # Use database session
    with get_session_scope() as session:
        # Your database operations here
        pass
"""

from database.config import DatabaseConfig, config
from database.connection import (
    Base,
    DatabaseConnection,
    db,
    init_db,
    get_db_session,
    get_session_scope,
    close_db,
    test_db_connection
)

__all__ = [
    # Config
    'DatabaseConfig',
    'config',
    
    # Connection
    'Base',
    'DatabaseConnection',
    'db',
    'init_db',
    'get_db_session',
    'get_session_scope',
    'close_db',
    'test_db_connection',
]

__version__ = '1.0.0'

