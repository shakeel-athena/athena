-- ============================================
-- MIGRATION: Update Pages for v1.1
-- Description: Add new pages, deactivate removed pages, update categories
-- Run this on existing databases to sync pages with App.js routes
-- ============================================

-- ============================================
-- ADD NEW PAGES
-- ============================================

-- Detection Module - New pages
INSERT INTO pages (page_path, page_name, page_category, description, display_order, icon) VALUES
('/detection/network-topology', 'Network Topology', 'Detection', 'Visualize network topology and threat landscape', 10, 'graphApp'),
('/detection/nids', 'NIDS Dashboard', 'Detection', 'Network Intrusion Detection System dashboard with alerts and analytics', 11, 'securitySignalDetected'),
('/detection/events', 'Alert Events', 'Detection', 'View and manage security alerts from NIDS and EDR sources', 12, 'securityApp'),
('/detection/promachos', 'Promachos Indexer', 'Detection', 'Promachos security indexer and analysis', 14, 'search'),
('/detection/configuration', 'System Configuration', 'Detection', 'Configure detection system settings', 15, 'settings')
ON CONFLICT (page_path) DO UPDATE SET
    page_name = EXCLUDED.page_name,
    page_category = EXCLUDED.page_category,
    description = EXCLUDED.description,
    display_order = EXCLUDED.display_order,
    icon = EXCLUDED.icon,
    is_active = TRUE;

-- Response Module - New pages
INSERT INTO pages (page_path, page_name, page_category, description, display_order, icon) VALUES
('/security/firewall-waf', 'Unified Blocking', 'Response', 'Unified view of Firewall and WAF blocked IPs', 20, 'securityApp'),
('/rules', 'WAF Custom Rules', 'Response', 'Manage custom WAF rules', 23, 'file-text')
ON CONFLICT (page_path) DO UPDATE SET
    page_name = EXCLUDED.page_name,
    page_category = EXCLUDED.page_category,
    description = EXCLUDED.description,
    display_order = EXCLUDED.display_order,
    icon = EXCLUDED.icon,
    is_active = TRUE;

-- Active Response Module - New pages
INSERT INTO pages (page_path, page_name, page_category, description, display_order, icon) VALUES
('/active-response', 'Response Dashboard', 'Active Response', 'Active response dashboard and history', 30, 'dashboardApp'),
('/active-response/advanced', 'Advanced Response', 'Active Response', 'Advanced active response configuration', 31, 'settings')
ON CONFLICT (page_path) DO UPDATE SET
    page_name = EXCLUDED.page_name,
    page_category = EXCLUDED.page_category,
    description = EXCLUDED.description,
    display_order = EXCLUDED.display_order,
    icon = EXCLUDED.icon,
    is_active = TRUE;

-- Threat Intelligence - Update path
INSERT INTO pages (page_path, page_name, page_category, description, display_order, icon) VALUES
('/threat-intelligence/datasets', 'CTI Datasets', 'Intelligence', 'Cyber threat intelligence datasets and indicators', 40, 'database')
ON CONFLICT (page_path) DO UPDATE SET
    page_name = EXCLUDED.page_name,
    page_category = EXCLUDED.page_category,
    description = EXCLUDED.description,
    display_order = EXCLUDED.display_order,
    icon = EXCLUDED.icon,
    is_active = TRUE;

-- System Monitoring - New page
INSERT INTO pages (page_path, page_name, page_category, description, display_order, icon) VALUES
('/system-health', 'System Health', 'System', 'Monitor system health and service status', 50, 'compute')
ON CONFLICT (page_path) DO UPDATE SET
    page_name = EXCLUDED.page_name,
    page_category = EXCLUDED.page_category,
    description = EXCLUDED.description,
    display_order = EXCLUDED.display_order,
    icon = EXCLUDED.icon,
    is_active = TRUE;

-- Admin Module - New pages
INSERT INTO pages (page_path, page_name, page_category, description, display_order, icon) VALUES
('/admin/agent-control', 'Wazuh Agents', 'Admin', 'Monitor and manage Wazuh agent status and activity', 60, 'compute'),
('/admin/mute-rules', 'Mute Rules', 'Admin', 'Manage alert muting rules for false positives', 61, 'bellSlash'),
('/admin/blocked-ips', 'Blocked IPs', 'Admin', 'Manage blocked IP addresses across firewall and WAF', 62, 'securitySignalResolved')
ON CONFLICT (page_path) DO UPDATE SET
    page_name = EXCLUDED.page_name,
    page_category = EXCLUDED.page_category,
    description = EXCLUDED.description,
    display_order = EXCLUDED.display_order,
    icon = EXCLUDED.icon,
    is_active = TRUE;

-- ============================================
-- UPDATE EXISTING PAGES (name/category changes)
-- ============================================

UPDATE pages SET
    page_name = 'Overview',
    description = 'Main dashboard with system overview and key metrics'
WHERE page_path = '/dashboard';

UPDATE pages SET
    page_name = 'Linux Firewall',
    description = 'Manage Linux firewall rules and configurations'
WHERE page_path = '/firewall';

UPDATE pages SET
    page_name = 'WAF Rules',
    description = 'Manage WAF signatures and attack protection rules'
WHERE page_path = '/waf-signatures';

UPDATE pages SET
    page_name = 'Users',
    description = 'Manage user accounts and access'
WHERE page_path = '/admin/users';

UPDATE pages SET
    page_name = 'Roles & Permissions',
    description = 'Create and manage roles and permissions'
WHERE page_path = '/admin/roles';

-- ============================================
-- DEACTIVATE REMOVED PAGES
-- ============================================

UPDATE pages SET is_active = FALSE WHERE page_path IN (
    '/detection/suricata-rules',
    '/detection/normalization',
    '/detection/analytics',
    '/detection/unified',
    '/detection/datasets',
    '/firewall/block-list',
    '/firewall/allow-list',
    '/waf',
    '/incidents',
    '/agents',
    '/agents/status',
    '/analytics',
    '/analytics/attack-graph',
    '/analytics/stats',
    '/admin/wazuh-integration',
    '/admin/system-config',
    '/control-panel',
    '/settings'
);

-- ============================================
-- ADD NEW ROLES IF NOT EXISTS
-- ============================================

INSERT INTO roles (role_name, display_name, description, is_system_role, priority)
VALUES
    ('incident-responder', 'Incident Responder', 'Can manage active response actions and incident handling', FALSE, 40),
    ('waf-manager', 'WAF Manager', 'Can manage WAF rules, firewall configurations, and network security', FALSE, 45),
    ('auditor', 'Auditor', 'View-only access to audit logs and compliance reports', FALSE, 20)
ON CONFLICT (role_name) DO NOTHING;

-- ============================================
-- UPDATE ROLE PERMISSIONS FOR NEW PAGES
-- ============================================

-- Add new pages to system-admin role
INSERT INTO role_pages (role_id, page_id, can_view, can_edit)
SELECT
    (SELECT id FROM roles WHERE role_name = 'system-admin'),
    p.id,
    TRUE,
    TRUE
FROM pages p
WHERE p.is_active = TRUE
  AND p.page_path != '/unauthorized'
  AND NOT EXISTS (
      SELECT 1 FROM role_pages rp
      WHERE rp.role_id = (SELECT id FROM roles WHERE role_name = 'system-admin')
        AND rp.page_id = p.id
  );

-- Add new pages to security-analyst role
INSERT INTO role_pages (role_id, page_id, can_view, can_edit)
SELECT
    (SELECT id FROM roles WHERE role_name = 'security-analyst'),
    p.id,
    TRUE,
    CASE
        WHEN p.page_category IN ('Detection', 'Response', 'Active Response', 'Intelligence') THEN TRUE
        WHEN p.page_path IN ('/admin/agent-control', '/admin/mute-rules', '/admin/blocked-ips') THEN TRUE
        ELSE FALSE
    END
FROM pages p
WHERE p.is_active = TRUE
  AND p.page_path IN (
      '/detection/network-topology', '/detection/nids', '/detection/events',
      '/detection/promachos', '/detection/configuration',
      '/security/firewall-waf', '/rules',
      '/active-response', '/active-response/advanced',
      '/threat-intelligence/datasets', '/system-health',
      '/admin/agent-control', '/admin/mute-rules', '/admin/blocked-ips'
  )
  AND NOT EXISTS (
      SELECT 1 FROM role_pages rp
      WHERE rp.role_id = (SELECT id FROM roles WHERE role_name = 'security-analyst')
        AND rp.page_id = p.id
  );

-- Add new pages to security-viewer role (view only)
INSERT INTO role_pages (role_id, page_id, can_view, can_edit)
SELECT
    (SELECT id FROM roles WHERE role_name = 'security-viewer'),
    p.id,
    TRUE,
    FALSE
FROM pages p
WHERE p.is_active = TRUE
  AND p.page_path IN (
      '/detection/network-topology', '/detection/nids', '/detection/events',
      '/security/firewall-waf', '/threat-intelligence/datasets', '/system-health'
  )
  AND NOT EXISTS (
      SELECT 1 FROM role_pages rp
      WHERE rp.role_id = (SELECT id FROM roles WHERE role_name = 'security-viewer')
        AND rp.page_id = p.id
  );

-- ============================================
-- REMOVE PERMISSIONS FOR DEACTIVATED PAGES
-- ============================================

DELETE FROM role_pages
WHERE page_id IN (SELECT id FROM pages WHERE is_active = FALSE);

-- ============================================
-- VERIFICATION
-- ============================================

DO $$
DECLARE
    active_count INT;
    inactive_count INT;
    new_pages INT;
BEGIN
    SELECT COUNT(*) INTO active_count FROM pages WHERE is_active = TRUE;
    SELECT COUNT(*) INTO inactive_count FROM pages WHERE is_active = FALSE;

    RAISE NOTICE '✅ Migration Complete';
    RAISE NOTICE 'Active Pages: %', active_count;
    RAISE NOTICE 'Inactive Pages: %', inactive_count;
END $$;

-- Show final page summary
SELECT
    page_category,
    COUNT(*) as page_count,
    string_agg(page_name, ', ' ORDER BY display_order) as pages
FROM pages
WHERE is_active = TRUE
GROUP BY page_category
ORDER BY MIN(display_order);

-- ============================================
-- MIGRATION COMPLETE
-- ============================================
