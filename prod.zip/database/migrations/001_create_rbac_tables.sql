-- Migration: Create RBAC Tables
-- Description: Creates tables for Role-Based Access Control system
-- Author: Athena Security Platform Team
-- Date: 2025-11-04

-- ============================================================================
-- TABLE: users
-- Description: User accounts synchronized with Keycloak
-- ============================================================================
CREATE TABLE IF NOT EXISTS users (
    id SERIAL PRIMARY KEY,
    keycloak_user_id UUID UNIQUE NOT NULL,  -- Links to Keycloak user (sub claim)
    username VARCHAR(255) UNIQUE NOT NULL,
    email VARCHAR(255) UNIQUE NOT NULL,
    full_name VARCHAR(255),
    is_admin BOOLEAN DEFAULT FALSE,          -- System admin flag (bypasses all RBAC)
    is_active BOOLEAN DEFAULT TRUE,          -- Account enabled/disabled
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_users_keycloak_id ON users(keycloak_user_id);
CREATE INDEX idx_users_username ON users(username);
CREATE INDEX idx_users_email ON users(email);
CREATE INDEX idx_users_is_active ON users(is_active);

COMMENT ON TABLE users IS 'User accounts synchronized from Keycloak';
COMMENT ON COLUMN users.keycloak_user_id IS 'UUID from Keycloak (sub claim in JWT)';
COMMENT ON COLUMN users.is_admin IS 'System admin flag - bypasses all RBAC permission checks';
COMMENT ON COLUMN users.is_active IS 'Account status - disabled users cannot access system';

-- ============================================================================
-- TABLE: roles
-- Description: Role definitions for RBAC
-- ============================================================================
CREATE TABLE IF NOT EXISTS roles (
    id SERIAL PRIMARY KEY,
    role_name VARCHAR(255) UNIQUE NOT NULL,  -- Unique identifier (e.g., 'security-analyst')
    display_name VARCHAR(255) NOT NULL,       -- Friendly name for UI (e.g., 'Security Analyst')
    description TEXT,
    is_system_role BOOLEAN DEFAULT FALSE,     -- Protected system roles cannot be deleted
    priority INTEGER DEFAULT 0,               -- Higher priority = more privileged (for UI sorting)
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_by INTEGER REFERENCES users(id) ON DELETE SET NULL
);

CREATE INDEX idx_roles_name ON roles(role_name);
CREATE INDEX idx_roles_priority ON roles(priority);

COMMENT ON TABLE roles IS 'Role definitions for RBAC system';
COMMENT ON COLUMN roles.role_name IS 'Unique identifier used in code (lowercase-with-hyphens)';
COMMENT ON COLUMN roles.display_name IS 'Human-readable name shown in UI';
COMMENT ON COLUMN roles.is_system_role IS 'System roles are protected from deletion';
COMMENT ON COLUMN roles.priority IS 'Higher number = more privileged (used for UI sorting)';

-- ============================================================================
-- TABLE: pages
-- Description: Application pages/features that can be accessed
-- ============================================================================
CREATE TABLE IF NOT EXISTS pages (
    id SERIAL PRIMARY KEY,
    page_path VARCHAR(255) UNIQUE NOT NULL,  -- URL path (e.g., '/dashboard', '/admin/users')
    page_name VARCHAR(255) NOT NULL,          -- Display name for UI
    page_category VARCHAR(100),               -- Category for grouping (e.g., 'Admin', 'Detection')
    description TEXT,
    icon VARCHAR(50),                         -- Icon name for UI rendering
    display_order INTEGER DEFAULT 0,          -- Sort order in menus
    parent_page_id INTEGER REFERENCES pages(id) ON DELETE SET NULL,  -- For nested pages
    is_active BOOLEAN DEFAULT TRUE,           -- Inactive pages are hidden
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_pages_path ON pages(page_path);
CREATE INDEX idx_pages_category ON pages(page_category);
CREATE INDEX idx_pages_parent ON pages(parent_page_id);
CREATE INDEX idx_pages_is_active ON pages(is_active);

COMMENT ON TABLE pages IS 'Application pages and features that can be accessed';
COMMENT ON COLUMN pages.page_path IS 'URL path used in routing (must match frontend routes)';
COMMENT ON COLUMN pages.page_category IS 'Grouping category for sidebar navigation';
COMMENT ON COLUMN pages.parent_page_id IS 'Parent page ID for nested navigation structure';

-- ============================================================================
-- TABLE: role_pages
-- Description: Many-to-many mapping between roles and pages with permissions
-- ============================================================================
CREATE TABLE IF NOT EXISTS role_pages (
    id SERIAL PRIMARY KEY,
    role_id INTEGER NOT NULL REFERENCES roles(id) ON DELETE CASCADE,
    page_id INTEGER NOT NULL REFERENCES pages(id) ON DELETE CASCADE,
    can_view BOOLEAN DEFAULT TRUE,            -- Permission to view the page
    can_edit BOOLEAN DEFAULT FALSE,           -- Permission to edit/modify content
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(role_id, page_id)                  -- One permission entry per role-page pair
);

CREATE INDEX idx_role_pages_role ON role_pages(role_id);
CREATE INDEX idx_role_pages_page ON role_pages(page_id);
CREATE INDEX idx_role_pages_view ON role_pages(can_view);
CREATE INDEX idx_role_pages_edit ON role_pages(can_edit);

COMMENT ON TABLE role_pages IS 'Role-to-page permission mappings (many-to-many)';
COMMENT ON COLUMN role_pages.can_view IS 'Permission to view/access the page';
COMMENT ON COLUMN role_pages.can_edit IS 'Permission to edit/modify content on the page';

-- ============================================================================
-- TABLE: user_roles
-- Description: Many-to-many mapping between users and roles
-- ============================================================================
CREATE TABLE IF NOT EXISTS user_roles (
    id SERIAL PRIMARY KEY,
    user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    role_id INTEGER NOT NULL REFERENCES roles(id) ON DELETE CASCADE,
    assigned_by INTEGER REFERENCES users(id) ON DELETE SET NULL,  -- Who assigned this role
    assigned_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    expires_at TIMESTAMP,                     -- Optional expiration (NULL = never expires)
    UNIQUE(user_id, role_id)                  -- User cannot have same role assigned twice
);

CREATE INDEX idx_user_roles_user ON user_roles(user_id);
CREATE INDEX idx_user_roles_role ON user_roles(role_id);
CREATE INDEX idx_user_roles_expires ON user_roles(expires_at);

COMMENT ON TABLE user_roles IS 'User-to-role assignments (many-to-many)';
COMMENT ON COLUMN user_roles.assigned_by IS 'User ID of admin who assigned this role';
COMMENT ON COLUMN user_roles.expires_at IS 'Optional expiration date for temporary access';

-- ============================================================================
-- TABLE: audit_log
-- Description: Audit trail of all access attempts and administrative actions
-- ============================================================================
CREATE TABLE IF NOT EXISTS audit_log (
    id SERIAL PRIMARY KEY,
    user_id INTEGER REFERENCES users(id) ON DELETE SET NULL,
    username VARCHAR(255),                    -- Denormalized for reporting (in case user deleted)
    action VARCHAR(100) NOT NULL,             -- Action type (e.g., 'page_access', 'user_created')
    page_path VARCHAR(255),                   -- What was accessed (if applicable)
    result VARCHAR(50) NOT NULL,              -- 'allowed' or 'denied'
    reason TEXT,                              -- Reason for denial (if applicable)
    ip_address VARCHAR(45),                   -- Client IP address (IPv4 or IPv6)
    user_agent TEXT,                          -- Browser/client user agent string
    request_method VARCHAR(10),               -- HTTP method (GET, POST, PUT, DELETE)
    request_path VARCHAR(255),                -- Full request path
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_audit_user ON audit_log(user_id);
CREATE INDEX idx_audit_action ON audit_log(action);
CREATE INDEX idx_audit_result ON audit_log(result);
CREATE INDEX idx_audit_created ON audit_log(created_at);
CREATE INDEX idx_audit_username ON audit_log(username);

COMMENT ON TABLE audit_log IS 'Immutable audit trail of all access attempts and actions';
COMMENT ON COLUMN audit_log.action IS 'Type of action (page_access, user_created, etc.)';
COMMENT ON COLUMN audit_log.result IS 'Outcome of action: allowed or denied';
COMMENT ON COLUMN audit_log.reason IS 'Explanation for denial (e.g., insufficient permissions)';

-- ============================================================================
-- TRIGGER: Update updated_at timestamp
-- Description: Automatically updates updated_at column on row modification
-- ============================================================================
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Apply trigger to tables with updated_at column
CREATE TRIGGER update_users_updated_at BEFORE UPDATE ON users
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_roles_updated_at BEFORE UPDATE ON roles
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_pages_updated_at BEFORE UPDATE ON pages
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

-- ============================================================================
-- END OF MIGRATION
-- ============================================================================
