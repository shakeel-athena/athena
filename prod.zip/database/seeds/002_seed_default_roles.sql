-- ============================================
-- SEED: Default Roles
-- Version: 1.1 (Updated to match App.js routes)
-- Description: Create basic system roles with common permission sets
-- Last Updated: 2025-01-11
-- Note: This is optional. Admins can create custom roles via UI.
-- ============================================

-- ============================================
-- CREATE DEFAULT ROLES
-- ============================================

-- System Administrator (Full Access)
INSERT INTO roles (role_name, display_name, description, is_system_role, priority)
VALUES (
    'system-admin',
    'System Administrator',
    'Full access to all system features including user and role management',
    TRUE,
    100
) ON CONFLICT (role_name) DO UPDATE SET
    display_name = EXCLUDED.display_name,
    description = EXCLUDED.description;

-- Security Analyst (Most Features with Edit)
INSERT INTO roles (role_name, display_name, description, is_system_role, priority)
VALUES (
    'security-analyst',
    'Security Analyst',
    'Can manage security alerts, incidents, response actions, and view all dashboards',
    FALSE,
    50
) ON CONFLICT (role_name) DO UPDATE SET
    display_name = EXCLUDED.display_name,
    description = EXCLUDED.description;

-- Security Viewer (Read-Only)
INSERT INTO roles (role_name, display_name, description, is_system_role, priority)
VALUES (
    'security-viewer',
    'Security Viewer',
    'Read-only access to dashboards, alerts, and reports',
    FALSE,
    10
) ON CONFLICT (role_name) DO UPDATE SET
    display_name = EXCLUDED.display_name,
    description = EXCLUDED.description;

-- Incident Responder (Response-focused)
INSERT INTO roles (role_name, display_name, description, is_system_role, priority)
VALUES (
    'incident-responder',
    'Incident Responder',
    'Can manage active response actions and incident handling',
    FALSE,
    40
) ON CONFLICT (role_name) DO UPDATE SET
    display_name = EXCLUDED.display_name,
    description = EXCLUDED.description;

-- WAF Manager (Network Security focused)
INSERT INTO roles (role_name, display_name, description, is_system_role, priority)
VALUES (
    'waf-manager',
    'WAF Manager',
    'Can manage WAF rules, firewall configurations, and network security',
    FALSE,
    45
) ON CONFLICT (role_name) DO UPDATE SET
    display_name = EXCLUDED.display_name,
    description = EXCLUDED.description;

-- Auditor (Audit-focused)
INSERT INTO roles (role_name, display_name, description, is_system_role, priority)
VALUES (
    'auditor',
    'Auditor',
    'View-only access to audit logs and compliance reports',
    FALSE,
    20
) ON CONFLICT (role_name) DO UPDATE SET
    display_name = EXCLUDED.display_name,
    description = EXCLUDED.description;

-- ============================================
-- ASSIGN PAGES TO SYSTEM ADMINISTRATOR
-- (All active pages with edit access)
-- ============================================
INSERT INTO role_pages (role_id, page_id, can_view, can_edit)
SELECT
    (SELECT id FROM roles WHERE role_name = 'system-admin'),
    id,
    TRUE,
    TRUE
FROM pages
WHERE is_active = TRUE AND page_path != '/unauthorized'
ON CONFLICT (role_id, page_id) DO UPDATE SET can_view = TRUE, can_edit = TRUE;

-- ============================================
-- ASSIGN PAGES TO SECURITY ANALYST
-- (Most pages with edit where appropriate)
-- ============================================
INSERT INTO role_pages (role_id, page_id, can_view, can_edit)
SELECT
    (SELECT id FROM roles WHERE role_name = 'security-analyst'),
    id,
    TRUE,
    CASE
        -- Can edit detection and response pages
        WHEN page_category IN ('Detection', 'Response', 'Active Response', 'Intelligence') THEN TRUE
        -- Can edit agent control but not user/role management
        WHEN page_path = '/admin/agent-control' THEN TRUE
        WHEN page_path = '/admin/mute-rules' THEN TRUE
        WHEN page_path = '/admin/blocked-ips' THEN TRUE
        -- Cannot edit admin core pages
        WHEN page_path IN ('/admin/users', '/admin/roles') THEN FALSE
        -- View-only for system and audit
        ELSE FALSE
    END
FROM pages
WHERE is_active = TRUE AND page_path IN (
    -- Core
    '/dashboard',
    -- Detection
    '/detection/network-topology',
    '/detection/nids',
    '/detection/events',
    '/detection/wazuh-rules',
    '/detection/promachos',
    '/detection/configuration',
    -- Response
    '/security/firewall-waf',
    '/firewall',
    '/waf-signatures',
    '/rules',
    '/responses',
    '/policies',
    '/alerts',
    -- Active Response
    '/active-response',
    '/active-response/advanced',
    -- Intelligence
    '/threat-intelligence/datasets',
    '/intelligence',
    -- System
    '/system-health',
    -- Admin (limited)
    '/admin/agent-control',
    '/admin/mute-rules',
    '/admin/blocked-ips',
    '/audit'
)
ON CONFLICT (role_id, page_id) DO UPDATE SET
    can_view = EXCLUDED.can_view,
    can_edit = EXCLUDED.can_edit;

-- ============================================
-- ASSIGN PAGES TO SECURITY VIEWER
-- (Read-only access to most pages)
-- ============================================
INSERT INTO role_pages (role_id, page_id, can_view, can_edit)
SELECT
    (SELECT id FROM roles WHERE role_name = 'security-viewer'),
    id,
    TRUE,
    FALSE  -- All read-only
FROM pages
WHERE is_active = TRUE AND page_path IN (
    -- Core
    '/dashboard',
    -- Detection (view only)
    '/detection/network-topology',
    '/detection/nids',
    '/detection/events',
    '/detection/wazuh-rules',
    -- Response (view only)
    '/security/firewall-waf',
    '/firewall',
    '/waf-signatures',
    '/responses',
    '/alerts',
    -- Intelligence
    '/threat-intelligence/datasets',
    '/intelligence',
    -- System
    '/system-health'
)
ON CONFLICT (role_id, page_id) DO UPDATE SET
    can_view = TRUE,
    can_edit = FALSE;

-- ============================================
-- ASSIGN PAGES TO INCIDENT RESPONDER
-- (Response-focused with edit access)
-- ============================================
INSERT INTO role_pages (role_id, page_id, can_view, can_edit)
SELECT
    (SELECT id FROM roles WHERE role_name = 'incident-responder'),
    id,
    TRUE,
    CASE
        -- Can edit response-related pages
        WHEN page_category IN ('Response', 'Active Response') THEN TRUE
        WHEN page_path = '/detection/events' THEN TRUE
        WHEN page_path = '/admin/blocked-ips' THEN TRUE
        ELSE FALSE
    END
FROM pages
WHERE is_active = TRUE AND page_path IN (
    -- Core
    '/dashboard',
    -- Detection (limited)
    '/detection/events',
    '/detection/nids',
    -- Response (edit)
    '/responses',
    '/alerts',
    '/security/firewall-waf',
    '/firewall',
    -- Active Response (edit)
    '/active-response',
    '/active-response/advanced',
    -- Admin (limited)
    '/admin/blocked-ips'
)
ON CONFLICT (role_id, page_id) DO UPDATE SET
    can_view = EXCLUDED.can_view,
    can_edit = EXCLUDED.can_edit;

-- ============================================
-- ASSIGN PAGES TO WAF MANAGER
-- (Network security focused with edit)
-- ============================================
INSERT INTO role_pages (role_id, page_id, can_view, can_edit)
SELECT
    (SELECT id FROM roles WHERE role_name = 'waf-manager'),
    id,
    TRUE,
    CASE
        -- Can edit WAF and firewall pages
        WHEN page_path IN ('/security/firewall-waf', '/firewall', '/waf-signatures', '/rules', '/policies') THEN TRUE
        WHEN page_path = '/admin/blocked-ips' THEN TRUE
        ELSE FALSE
    END
FROM pages
WHERE is_active = TRUE AND page_path IN (
    -- Core
    '/dashboard',
    -- Response (edit WAF/Firewall)
    '/security/firewall-waf',
    '/firewall',
    '/waf-signatures',
    '/rules',
    '/policies',
    '/responses',
    -- Admin
    '/admin/blocked-ips',
    -- View-only
    '/detection/events',
    '/alerts'
)
ON CONFLICT (role_id, page_id) DO UPDATE SET
    can_view = EXCLUDED.can_view,
    can_edit = EXCLUDED.can_edit;

-- ============================================
-- ASSIGN PAGES TO AUDITOR
-- (Audit and compliance view-only)
-- ============================================
INSERT INTO role_pages (role_id, page_id, can_view, can_edit)
SELECT
    (SELECT id FROM roles WHERE role_name = 'auditor'),
    id,
    TRUE,
    FALSE  -- All read-only
FROM pages
WHERE is_active = TRUE AND page_path IN (
    '/dashboard',
    '/audit',
    '/detection/events',
    '/responses',
    '/admin/blocked-ips',
    '/admin/mute-rules'
)
ON CONFLICT (role_id, page_id) DO UPDATE SET
    can_view = TRUE,
    can_edit = FALSE;

-- ============================================
-- VERIFICATION & SUMMARY
-- ============================================

DO $$
DECLARE
    role_count INT;
BEGIN
    SELECT COUNT(*) INTO role_count FROM roles;

    RAISE NOTICE '✅ Default Roles Created Successfully';
    RAISE NOTICE 'Total Roles: %', role_count;
    RAISE NOTICE '';
    RAISE NOTICE 'Role Permissions Summary:';
END $$;

-- Show role permissions breakdown
SELECT
    r.role_name,
    r.display_name,
    r.priority,
    COUNT(DISTINCT rp.page_id) as total_pages,
    COUNT(DISTINCT rp.page_id) FILTER (WHERE rp.can_edit = TRUE) as editable_pages,
    COUNT(DISTINCT rp.page_id) FILTER (WHERE rp.can_edit = FALSE) as readonly_pages
FROM roles r
LEFT JOIN role_pages rp ON r.id = rp.role_id
GROUP BY r.id, r.role_name, r.display_name, r.priority
ORDER BY r.priority DESC;

-- Show pages by role and category
SELECT
    r.role_name,
    p.page_category,
    COUNT(*) as page_count,
    COUNT(*) FILTER (WHERE rp.can_edit = TRUE) as editable
FROM roles r
JOIN role_pages rp ON r.id = rp.role_id
JOIN pages p ON rp.page_id = p.id
WHERE p.is_active = TRUE
GROUP BY r.role_name, p.page_category
ORDER BY r.role_name, p.page_category;

-- ============================================
-- SEED COMPLETE
-- ============================================
