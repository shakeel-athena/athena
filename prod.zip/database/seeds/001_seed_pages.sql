-- ============================================
-- SEED: Application Pages
-- Version: 1.1 (Updated to match App.js routes)
-- Description: Pre-populate all pages/features in the Athena application
-- Last Updated: 2025-01-11
-- ============================================

-- Clear existing pages (only in dev/testing)
-- TRUNCATE TABLE pages CASCADE;

-- ============================================
-- CORE PAGES
-- ============================================
INSERT INTO pages (page_path, page_name, page_category, description, display_order, icon) VALUES
('/dashboard', 'Overview', 'Core', 'Main dashboard with system overview and key metrics', 1, 'dashboard')
ON CONFLICT (page_path) DO UPDATE SET page_name = EXCLUDED.page_name, description = EXCLUDED.description;

-- ============================================
-- DETECTION MODULE (Dashboard & Analytics section in sidebar)
-- ============================================
INSERT INTO pages (page_path, page_name, page_category, description, display_order, icon) VALUES
('/detection/network-topology', 'Network Topology', 'Detection', 'Visualize network topology and threat landscape', 10, 'graphApp'),
('/detection/nids', 'NIDS Dashboard', 'Detection', 'Network Intrusion Detection System dashboard with alerts and analytics', 11, 'securitySignalDetected'),
('/detection/events', 'Alert Events', 'Detection', 'View and manage security alerts from NIDS and EDR sources', 12, 'securityApp'),
('/detection/wazuh-rules', 'Wazuh Rules', 'Detection', 'Manage Wazuh detection rules and configurations', 13, 'file-text'),
('/detection/promachos', 'Promachos Indexer', 'Detection', 'Promachos security indexer and analysis', 14, 'search'),
('/detection/configuration', 'System Configuration', 'Detection', 'Configure detection system settings', 15, 'settings')
ON CONFLICT (page_path) DO UPDATE SET page_name = EXCLUDED.page_name, description = EXCLUDED.description;

-- ============================================
-- RESPONSE MODULE (Network Management section in sidebar)
-- ============================================
INSERT INTO pages (page_path, page_name, page_category, description, display_order, icon) VALUES
('/security/firewall-waf', 'Unified Blocking', 'Response', 'Unified view of Firewall and WAF blocked IPs', 20, 'securityApp'),
('/firewall', 'Linux Firewall', 'Response', 'Manage Linux firewall rules and configurations', 21, 'lock'),
('/waf-signatures', 'WAF Rules', 'Response', 'Manage WAF signatures and attack protection rules', 22, 'securityApp'),
('/rules', 'WAF Custom Rules', 'Response', 'Manage custom WAF rules', 23, 'file-text'),
('/responses', 'Response Actions', 'Response', 'View and manage automated response actions', 24, 'zap'),
('/policies', 'Security Policies', 'Response', 'Manage security policies and rules', 25, 'file-text'),
('/alerts', 'Security Alerts', 'Response', 'Legacy alerts view', 26, 'alert')
ON CONFLICT (page_path) DO UPDATE SET page_name = EXCLUDED.page_name, description = EXCLUDED.description;

-- ============================================
-- ACTIVE RESPONSE
-- ============================================
INSERT INTO pages (page_path, page_name, page_category, description, display_order, icon) VALUES
('/active-response', 'Response Dashboard', 'Active Response', 'Active response dashboard and history', 30, 'dashboardApp'),
('/active-response/advanced', 'Advanced Response', 'Active Response', 'Advanced active response configuration', 31, 'settings')
ON CONFLICT (page_path) DO UPDATE SET page_name = EXCLUDED.page_name, description = EXCLUDED.description;

-- ============================================
-- THREAT INTELLIGENCE
-- ============================================
INSERT INTO pages (page_path, page_name, page_category, description, display_order, icon) VALUES
('/threat-intelligence/datasets', 'CTI Datasets', 'Intelligence', 'Cyber threat intelligence datasets and indicators', 40, 'database'),
('/intelligence', 'Threat Intelligence', 'Intelligence', 'View threat intelligence feeds and indicators', 41, 'globe')
ON CONFLICT (page_path) DO UPDATE SET page_name = EXCLUDED.page_name, description = EXCLUDED.description;

-- ============================================
-- SYSTEM MONITORING
-- ============================================
INSERT INTO pages (page_path, page_name, page_category, description, display_order, icon) VALUES
('/system-health', 'System Health', 'System', 'Monitor system health and service status', 50, 'compute')
ON CONFLICT (page_path) DO UPDATE SET page_name = EXCLUDED.page_name, description = EXCLUDED.description;

-- ============================================
-- ADMINISTRATION (Alert Management + Admin sections in sidebar)
-- ============================================
INSERT INTO pages (page_path, page_name, page_category, description, display_order, icon) VALUES
('/admin/agent-control', 'Wazuh Agents', 'Admin', 'Monitor and manage Wazuh agent status and activity', 60, 'compute'),
('/admin/mute-rules', 'Mute Rules', 'Admin', 'Manage alert muting rules for false positives', 61, 'bellSlash'),
('/admin/blocked-ips', 'Blocked IPs', 'Admin', 'Manage blocked IP addresses across firewall and WAF', 62, 'securitySignalResolved'),
('/admin/users', 'Users', 'Admin', 'Manage user accounts and access', 63, 'users'),
('/admin/roles', 'Roles & Permissions', 'Admin', 'Create and manage roles and permissions', 64, 'shield'),
('/audit', 'Audit Logs', 'Admin', 'View system audit logs and access history', 65, 'file-text')
ON CONFLICT (page_path) DO UPDATE SET page_name = EXCLUDED.page_name, description = EXCLUDED.description;

-- ============================================
-- SYSTEM PAGES (Special)
-- ============================================
INSERT INTO pages (page_path, page_name, page_category, description, display_order, icon) VALUES
('/unauthorized', 'Unauthorized Access', 'System', 'Access denied page (public)', 999, 'x-octagon')
ON CONFLICT (page_path) DO UPDATE SET page_name = EXCLUDED.page_name, description = EXCLUDED.description;

-- ============================================
-- REMOVE OBSOLETE PAGES (pages no longer in App.js)
-- ============================================
UPDATE pages SET is_active = FALSE WHERE page_path IN (
    '/detection/suricata-rules',
    '/detection/normalization',
    '/detection/analytics',
    '/detection/unified',
    '/detection/datasets',
    '/firewall/block-list',
    '/firewall/allow-list',
    '/waf',
    '/incidents',
    '/agents',
    '/agents/status',
    '/analytics',
    '/analytics/attack-graph',
    '/analytics/stats',
    '/admin/wazuh-integration',
    '/admin/system-config',
    '/control-panel',
    '/settings'
);

-- ============================================
-- UPDATE PARENT-CHILD RELATIONSHIPS
-- ============================================

-- Detection sub-pages under Network Topology
UPDATE pages SET parent_page_id = (SELECT id FROM pages WHERE page_path = '/detection/network-topology')
WHERE page_path IN ('/detection/nids', '/detection/events');

-- WAF sub-pages under firewall
UPDATE pages SET parent_page_id = (SELECT id FROM pages WHERE page_path = '/firewall')
WHERE page_path IN ('/waf-signatures', '/rules');

-- Active Response sub-pages
UPDATE pages SET parent_page_id = (SELECT id FROM pages WHERE page_path = '/active-response')
WHERE page_path IN ('/active-response/advanced');

-- Admin sub-pages (user/role management under admin)
UPDATE pages SET parent_page_id = NULL
WHERE page_path LIKE '/admin/%';

-- ============================================
-- VERIFICATION
-- ============================================

DO $$
DECLARE
    active_count INT;
    inactive_count INT;
    category_count INT;
BEGIN
    SELECT COUNT(*) INTO active_count FROM pages WHERE is_active = TRUE;
    SELECT COUNT(*) INTO inactive_count FROM pages WHERE is_active = FALSE;
    SELECT COUNT(DISTINCT page_category) INTO category_count FROM pages WHERE is_active = TRUE;

    RAISE NOTICE '✅ Pages Seeded Successfully';
    RAISE NOTICE 'Active Pages: %', active_count;
    RAISE NOTICE 'Inactive Pages: %', inactive_count;
    RAISE NOTICE 'Categories: %', category_count;
END $$;

-- Show breakdown by category (active pages only)
SELECT
    page_category,
    COUNT(*) as page_count,
    string_agg(page_name, ', ' ORDER BY display_order) as pages
FROM pages
WHERE is_active = TRUE
GROUP BY page_category
ORDER BY MIN(display_order);

-- ============================================
-- SEED COMPLETE
-- ============================================
