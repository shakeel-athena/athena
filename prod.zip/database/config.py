"""
Database Configuration Module

This module contains all database configuration settings for the Athena
Network Response Management system. It supports both environment-based
configuration and default values.
"""

import os
import urllib.parse
from dotenv import load_dotenv

# Load environment variables from .env file if it exists
load_dotenv(dotenv_path=os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), '.env'))


class DatabaseConfig:
    """Database configuration class"""
    
    # PostgreSQL Configuration - Support both POSTGRES_* and DB_* for compatibility
    DB_USER = os.getenv('POSTGRES_USER') or os.getenv('DB_USER', 'athena')
    DB_PASSWORD = os.getenv('POSTGRES_PASSWORD') or os.getenv('DB_PASSWORD', 'athena123')
    DB_HOST = os.getenv('POSTGRES_HOST') or os.getenv('DB_HOST', 'localhost')
    DB_PORT = os.getenv('POSTGRES_PORT') or os.getenv('DB_PORT', '5432')
    DB_NAME = os.getenv('POSTGRES_DB') or os.getenv('DB_NAME', 'athena_db')
    
    # Connection string for PostgreSQL with proper URL encoding for special characters
    if os.getenv('DATABASE_URI'):
        DATABASE_URI = os.getenv('DATABASE_URI')
    else:
        # URL encode the password to handle special characters
        encoded_password = urllib.parse.quote_plus(str(DB_PASSWORD))
        encoded_user = urllib.parse.quote_plus(str(DB_USER))
        DATABASE_URI = f'postgresql://{encoded_user}:{encoded_password}@{DB_HOST}:{DB_PORT}/{DB_NAME}'
    
    # SQLAlchemy Configuration
    SQLALCHEMY_DATABASE_URI = DATABASE_URI
    SQLALCHEMY_TRACK_MODIFICATIONS = False
    SQLALCHEMY_ECHO = os.getenv('SQLALCHEMY_ECHO', 'False').lower() == 'true'
    
    # Connection Pool Settings
    SQLALCHEMY_POOL_SIZE = int(os.getenv('SQLALCHEMY_POOL_SIZE', '10'))
    SQLALCHEMY_POOL_TIMEOUT = int(os.getenv('SQLALCHEMY_POOL_TIMEOUT', '30'))
    SQLALCHEMY_POOL_RECYCLE = int(os.getenv('SQLALCHEMY_POOL_RECYCLE', '3600'))
    SQLALCHEMY_MAX_OVERFLOW = int(os.getenv('SQLALCHEMY_MAX_OVERFLOW', '20'))
    
    # Database Connection Settings
    CONNECT_TIMEOUT = int(os.getenv('DB_CONNECT_TIMEOUT', '10'))
    STATEMENT_TIMEOUT = int(os.getenv('DB_STATEMENT_TIMEOUT', '30000'))  # milliseconds
    
    @classmethod
    def get_connection_string(cls):
        """
        Get the database connection string
        
        Returns:
            str: PostgreSQL connection string
        """
        return cls.DATABASE_URI
    
    @classmethod
    def get_sqlalchemy_config(cls):
        """
        Get SQLAlchemy configuration dictionary
        
        Returns:
            dict: Configuration dictionary for SQLAlchemy
        """
        return {
            'SQLALCHEMY_DATABASE_URI': cls.SQLALCHEMY_DATABASE_URI,
            'SQLALCHEMY_TRACK_MODIFICATIONS': cls.SQLALCHEMY_TRACK_MODIFICATIONS,
            'SQLALCHEMY_ECHO': cls.SQLALCHEMY_ECHO,
            'SQLALCHEMY_POOL_SIZE': cls.SQLALCHEMY_POOL_SIZE,
            'SQLALCHEMY_POOL_TIMEOUT': cls.SQLALCHEMY_POOL_TIMEOUT,
            'SQLALCHEMY_POOL_RECYCLE': cls.SQLALCHEMY_POOL_RECYCLE,
            'SQLALCHEMY_MAX_OVERFLOW': cls.SQLALCHEMY_MAX_OVERFLOW,
        }
    
    @classmethod
    def validate_config(cls):
        """
        Validate database configuration
        
        Returns:
            tuple: (is_valid, error_message)
        """
        required_fields = ['DB_USER', 'DB_PASSWORD', 'DB_HOST', 'DB_PORT', 'DB_NAME']
        missing_fields = []
        
        for field in required_fields:
            if not getattr(cls, field):
                missing_fields.append(field)
        
        if missing_fields:
            return False, f"Missing required configuration: {', '.join(missing_fields)}"
        
        return True, "Configuration is valid"


# Create a global config instance
config = DatabaseConfig()
