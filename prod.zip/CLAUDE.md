# Athena Security Platform - Development Guidelines

## Project Structure

```
├── frontend/                 # React frontend application
├── backend/response/         # Flask backend API
├── deployment/               # Production deployment scripts & configs
├── scripts/                  # Development & testing scripts
│   ├── testing/              # All test_*.py files
│   ├── utilities/            # Verification, check, cleanup scripts
│   └── integration/          # Integration setup scripts
├── database/                 # SQL migrations and seeds
├── docs/                     # Documentation files
└── CLAUDE.md                 # This file - AI assistant instructions
```

---

## File Placement Rules

### Test Scripts
- **Location:** `scripts/testing/`
- **Naming:** `test_<feature_name>.py`
- **Never place test files in:** `backend/response/src/`, `frontend/src/`, or root directory

### Utility Scripts
- **Location:** `scripts/utilities/`
- **Examples:** `verify_*.py`, `check_*.py`, `cleanup_*.py`, `setup_*.py`
- **Purpose:** One-time setup, verification, database utilities

### Integration Scripts
- **Location:** `scripts/integration/`
- **Purpose:** Scripts that configure external systems (Wazuh, Suricata, etc.)

### Documentation
- **Location:** `docs/`
- **Formats:** Markdown (.md) preferred, HTML for reports
- **Never create:** README files in subdirectories unless explicitly requested

### Database Files
- **Migrations:** `database/migrations/` - numbered `001_`, `002_`, etc.
- **Seeds:** `database/seeds/` - initial data files
- **Combined:** `deployment/database/init-database.sql` - for production deployment

---

## Code Organization

### Frontend (React)
```
frontend/src/
├── components/          # Reusable UI components
│   └── Layout/          # Sidebar, Navbar, Layout wrapper
├── pages/               # Route pages
│   ├── admin/           # Admin pages (users, roles, etc.)
│   ├── detection/       # Detection module pages
│   ├── security/        # Security pages (firewall, WAF)
│   ├── threat-intelligence/
│   └── ActiveResponse/
├── services/            # API service files
├── contexts/            # React contexts
├── config/              # Configuration files
└── styles/              # CSS files
```

### Backend (Flask)
```
backend/response/src/
├── api/                 # API route blueprints
│   ├── alerts/
│   ├── firewall/
│   ├── rbac/
│   └── ...
├── services/            # Business logic services
├── models/              # Database models
└── utils/               # Utility functions
```

---

## Adding New Features

### New Frontend Page
1. Create page component in `frontend/src/pages/<module>/`
2. Add route in `frontend/src/App.js`
3. Add sidebar link in `frontend/src/components/Layout/Sidebar.js`
4. Add API service functions in `frontend/src/services/`

### New Backend Endpoint
1. Create/update routes in `backend/response/src/api/<module>/routes.py`
2. Add business logic in `backend/response/src/services/`
3. Register blueprint in `backend/response/src/app_factory.py` (if new module)

### New Database Table
1. Create migration in `database/migrations/XXX_<description>.sql`
2. Update `deployment/database/init-database.sql`
3. Add seed data in `database/seeds/` if needed

---

## Coding Standards

### Python (Backend)
- Use Flask blueprints for API organization
- Services handle business logic, routes handle HTTP
- Use environment variables for configuration (see `.env.example`)
- Log important operations for audit trail

### JavaScript/React (Frontend)
- Use functional components with hooks
- Use React Query for API calls
- Use Elastic UI (EUI) components
- Protected routes use `<ProtectedRoute roles={[...]}>` wrapper

### API Conventions
- Base URL: `/api/`
- RESTful naming: `/api/alerts`, `/api/users`, etc.
- Return format: `{ success: bool, data: any, message?: string }`

---

## Environment Configuration

### Backend (.env)
Required variables:
- `POSTGRES_*` - Database connection
- `KEYCLOAK_*` - Authentication
- `ELASTICSEARCH_*` - Alert data source
- `WAZUH_*` - Active response integration

### Frontend (.env.production)
- `REACT_APP_API_URL` - Backend API URL
- `REACT_APP_KEYCLOAK_*` - Keycloak configuration

---

## Deployment

### Production Deployment Files
All deployment resources are in `deployment/`:
- `scripts/install.sh` - System prerequisites
- `scripts/deploy.sh` - Application deployment
- `scripts/backup.sh` - Database backup
- `config/` - Service configuration templates

### Do Not Commit
- `.env` files with real credentials
- `*.log` files
- `node_modules/`, `venv/`, `__pycache__/`
- Backup files (`*.backup`, `*.bak`)

---

## Quick Reference

| Task | Location |
|------|----------|
| Add test script | `scripts/testing/test_<name>.py` |
| Add utility script | `scripts/utilities/<name>.py` |
| Add documentation | `docs/<name>.md` |
| Add frontend page | `frontend/src/pages/<module>/` |
| Add backend endpoint | `backend/response/src/api/<module>/` |
| Add database migration | `database/migrations/` |
| Update deployment | `deployment/` |

---

## Git Workflow

- **Main branch:** `main`
- **Release branch:** `ageleia_release_v1.0`
- Commit messages: Use conventional format (feat:, fix:, docs:, etc.)
- Never commit secrets or credentials
