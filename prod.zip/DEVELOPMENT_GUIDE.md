# Athena Platform Development Guide

## Overview

**Athena** is a comprehensive Security Operations Center (SOC) platform that combines automated threat response, detection analytics, and cyber threat intelligence into a unified security operations interface.

### Key Capabilities
- **Unified Alerts**: Combined Wazuh + Suricata alerts in one dashboard
- **IP Enrichment**: Threat intelligence from AbuseIPDB, VirusTotal, OTX
- **Alert Suppression**: Mute noisy/false-positive alerts at source
- **Active Response**: Host isolation via Wazuh Manager
- **AWS Integration**: Network Firewall and WAF rule management
- **Network Topology**: 2D/3D threat visualization
- **RBAC**: Role-based access control via Keycloak

### Technology Stack
- **Backend**: Python (Flask) on port 5000
- **Frontend**: React 18 + Elastic UI (EUI)
- **Database**: PostgreSQL 15+
- **Search**: Elasticsearch 7.17+ (Wazuh Indexer)
- **Auth**: Keycloak 24+
- **IDS**: Wazuh 4.14+ / Suricata

---

## Architecture

```
┌─────────────────────────────────────────────────────────────┐
│                     React Frontend                          │
│                       Port 3000                             │
│  ┌───────────────────────────────────────────────────────┐ │
│  │   Dashboard │ Events │ Topology │ Active Response    │ │
│  │   Firewall  │ WAF    │ Admin    │ Mute Rules        │ │
│  └──────────────────────┬────────────────────────────────┘ │
└──────────────────────────┼──────────────────────────────────┘
                           │
                           ▼
             ┌─────────────────────────┐
             │   Response Backend      │
             │    (Flask/Python)       │
             │      Port 5000          │
             └───────────┬─────────────┘
                         │
         ┌───────────────┼───────────────┐
         ▼               ▼               ▼
  ┌─────────────┐ ┌─────────────┐ ┌─────────────┐
  │ PostgreSQL  │ │Elasticsearch│ │   AWS       │
  │   :5432     │ │   :9220     │ │ WAF/Firewall│
  └─────────────┘ └─────────────┘ └─────────────┘
```

---

## Getting Started

### Prerequisites
- Python 3.9+
- Node.js 16+
- PostgreSQL 15+
- Elasticsearch 7.17+ (or Wazuh Indexer)

### 1. Clone and Configure

```bash
git clone <repository-url>
cd athena
cp .env.example .env
# Edit .env with your configuration
```

### 2. Install Backend

```bash
cd backend/response
pip install -r requirements.txt
```

### 3. Install Frontend

```bash
cd frontend
npm install
```

### 4. Start Services

**Backend:**
```bash
cd backend/response
python src/app_factory.py
```

**Frontend:**
```bash
cd frontend
npm start
```

---

## Project Structure

```
athena/
├── frontend/                 # React application
│   ├── src/
│   │   ├── pages/           # Page components
│   │   │   ├── UnifiedDashboard.js
│   │   │   ├── detection/
│   │   │   │   ├── Events.js
│   │   │   │   └── NetworkTopology.js
│   │   │   ├── security/
│   │   │   │   └── FirewallWAFUnified.js
│   │   │   └── admin/
│   │   │       ├── Users.js
│   │   │       └── MuteRules.js
│   │   ├── components/
│   │   │   ├── Layout/
│   │   │   ├── Dashboard/
│   │   │   └── ThreatLandscape/
│   │   └── services/
│   │       ├── api.js
│   │       ├── rbacApi.js
│   │       └── detectionApi.js
│   └── package.json
│
├── backend/response/        # Flask API
│   ├── src/
│   │   ├── app_factory.py   # Main entry point
│   │   ├── api/             # API blueprints
│   │   │   ├── alerts/
│   │   │   ├── waf/
│   │   │   ├── firewall/
│   │   │   ├── mute/
│   │   │   ├── active_response/
│   │   │   └── admin/
│   │   ├── services/        # Business logic
│   │   └── core/            # Infrastructure
│   └── requirements.txt
│
├── database/               # Schema and migrations
│   ├── migrations/
│   └── seeds/
│
├── scripts/               # Utility scripts
│   └── start_all.py
│
└── docs/                  # Documentation
    ├── README.md
    ├── 01-getting-started.md
    └── features/
```

---

## Backend Development

### Entry Point
```bash
cd backend/response
python src/app_factory.py
```

### API Blueprints

| Blueprint | Prefix | Purpose |
|-----------|--------|---------|
| `alerts_bp` | `/api/alerts` | Alert CRUD |
| `waf_bp` | `/api/waf*` | AWS WAF |
| `firewall_bp` | `/api/firewall` | Network Firewall |
| `mute_bp` | `/api/mute` | Alert suppression |
| `active_response_bp` | `/api/active-response` | Host isolation |
| `admin_bp` | `/api/admin` | User/role management |

### Adding New Endpoints

1. Create blueprint in `src/api/<module>/routes.py`
2. Register in `src/app_factory.py`
3. Add to `src/api/__init__.py`

---

## Frontend Development

### Entry Point
```bash
cd frontend
npm start
```

### Key Files

| File | Purpose |
|------|---------|
| `src/App.js` | Routes and providers |
| `src/components/Layout/Sidebar.js` | Navigation |
| `src/services/api.js` | Backend API calls |
| `src/services/rbacApi.js` | RBAC API |

### Adding New Pages

1. Create page component in `src/pages/`
2. Add route in `src/App.js`
3. Add navigation in `src/components/Layout/Sidebar.js`
4. Add page to database for RBAC

---

## Testing

### Backend Tests
```bash
cd backend/response
pytest tests/
```

### Frontend Tests
```bash
cd frontend
npm test
```

---

## Common Tasks

### Start All Services
```bash
cd scripts
python start_all.py
```

### Check API Health
```bash
curl http://localhost:5000/health
curl http://localhost:5000/api/health/comprehensive
```

### Access Keycloak Admin
- URL: http://localhost:8080
- Username: admin
- Password: admin

---

## Troubleshooting

### Backend won't start
1. Check PostgreSQL is running
2. Verify `.env` configuration
3. Check port 5000 is available

### Frontend won't start
1. Run `npm install`
2. Check port 3000 is available
3. Verify backend URL in proxy config

### Database issues
1. Check connection string in `.env`
2. Verify user permissions
3. Run migrations if needed

---

## Documentation

| Document | Description |
|----------|-------------|
| [Getting Started](docs/01-getting-started.md) | Initial setup |
| [Backend Architecture](docs/05-backend-architecture.md) | API structure |
| [Starting Services](docs/06-starting-services.md) | Service startup |
| [API Reference](docs/07-api-reference.md) | Endpoint documentation |
