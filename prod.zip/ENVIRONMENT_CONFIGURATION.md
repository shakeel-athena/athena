# Environment Configuration Guide

## Overview

Configuration management for Athena Security Platform across development, staging, and production environments.

## Configuration Sources

```
┌─────────────────────────────────────────────────────────────┐
│                    Configuration Sources                     │
│                   (Priority: Bottom → Top)                   │
├─────────────────────────────────────────────────────────────┤
│  1. Default Values (in code)                                 │
│     ↓                                                        │
│  2. .env.example (template/documentation)                    │
│     ↓                                                        │
│  3. .env (local development)                                 │
│     ↓                                                        │
│  4. Environment Variables (runtime override)                 │
│     ↓                                                        │
│  5. AWS Secrets Manager (production)                         │
└─────────────────────────────────────────────────────────────┘
```

## Environment Variables

### Database Configuration

```env
POSTGRES_HOST=localhost
POSTGRES_PORT=5432
POSTGRES_DB=athena_db
POSTGRES_USER=athena_user
POSTGRES_PASSWORD=athena_pass
```

### Elasticsearch Configuration

```env
ELASTICSEARCH_HOST=localhost
ELASTICSEARCH_PORT=9220
ELASTICSEARCH_USER=admin
ELASTICSEARCH_PASSWORD=your-password
ELASTICSEARCH_VERIFY_SSL=false
ELASTICSEARCH_TIMEOUT=30

# Index patterns
WAZUH_INDEX=wazuh-alerts-*
SURICATA_INDEX=suricata-*
```

### Keycloak Configuration

```env
KEYCLOAK_URL=http://localhost:8080
KEYCLOAK_REALM=athena-security
KEYCLOAK_CLIENT_ID=athena-backend
KEYCLOAK_CLIENT_SECRET=your-secret
KEYCLOAK_ADMIN_USER=admin
KEYCLOAK_ADMIN_PASSWORD=admin
```

### AWS Configuration

```env
AWS_PROFILE=your-profile
AWS_REGION=us-east-2
AWS_SCOPE=REGIONAL

# Network Firewall
FIREWALL_RULE_GROUP=allow-ingress

# WAF
WAF_WEB_ACL=your-web-acl
WAF_BLOCKLIST_NAME=Blocked
```

### Wazuh Manager Configuration

```env
WAZUH_MANAGER_HOST=172.16.1.93
WAZUH_API_URL=https://172.16.1.93:55000
WAZUH_API_USER=wazuh
WAZUH_API_PASSWORD=wazuh
WAZUH_API_VERIFY_SSL=false

# SSH for Active Response
WAZUH_SSH_USER=your-ssh-user
WAZUH_SSH_PASSWORD=your-ssh-password
```

### Threat Intelligence APIs

```env
ABUSEIPDB_API_KEY=your-api-key
VIRUSTOTAL_API_KEY=your-api-key
OTX_API_KEY=your-api-key
```

### Application Settings

```env
FLASK_ENV=development
FLASK_HOST=0.0.0.0
FLASK_PORT=5000
DEBUG=true
LOG_LEVEL=INFO
SECRET_KEY=your-secret-key

CORS_ORIGINS=http://localhost:3000,http://127.0.0.1:3000
RATELIMIT_ENABLED=false
DEFAULT_PAGE_SIZE=50
MAX_PAGE_SIZE=50000
```

## Development Environment

```bash
# Copy template
cp .env.example .env

# Edit with development values
nano .env
```

**Typical development settings:**
- `DEBUG=true`
- `LOG_LEVEL=DEBUG`
- `FLASK_ENV=development`
- Local PostgreSQL
- Local/VPN Elasticsearch

## Production Environment

**Key differences:**
- `DEBUG=false`
- `LOG_LEVEL=INFO`
- `FLASK_ENV=production`
- Strong `SECRET_KEY`
- AWS RDS for database
- AWS Secrets Manager for credentials
- SSL verification enabled

### AWS Secrets Manager

Load secrets automatically:
```bash
cd scripts
python load_secrets_from_aws.py
```

## File Structure

```
athena/
├── .env.example          # Template with all variables
├── .env                  # Local development (gitignored)
├── backend/response/
│   └── src/config/
│       └── environment_config.py  # Configuration loader
└── scripts/
    └── load_secrets_from_aws.py   # AWS secrets loader
```

## Quick Reference

### Minimum Required Variables

```env
# Database
POSTGRES_HOST=localhost
POSTGRES_PORT=5432
POSTGRES_DB=athena_db
POSTGRES_USER=athena_user
POSTGRES_PASSWORD=athena_pass

# Elasticsearch
ELASTICSEARCH_HOST=localhost
ELASTICSEARCH_PORT=9220

# Keycloak
KEYCLOAK_URL=http://localhost:8080
KEYCLOAK_REALM=athena-security
```

### Service Ports

| Service | Port |
|---------|------|
| Frontend | 3000 |
| Backend | 5000 |
| PostgreSQL | 5432 |
| Elasticsearch | 9220 |
| Keycloak | 8080 |

## Troubleshooting

### Environment Variables Not Loading

1. Check `.env` file exists in project root
2. Verify no syntax errors (no spaces around `=`)
3. Restart backend after changes

### AWS Credentials Issues

```bash
# Verify profile exists
aws configure list-profiles

# Test credentials
aws sts get-caller-identity --profile your-profile

# Refresh SSO if needed
aws sso login --profile your-profile
```

### Database Connection Failed

1. Check `POSTGRES_*` variables
2. Verify PostgreSQL is running
3. Test connection string manually
