#!/bin/bash
# Setup script for Filebeat configuration

set -e

echo "=== Filebeat Setup for Suricata Pipeline ==="
echo ""

# Check if running as root
if [ "$EUID" -ne 0 ]; then 
    echo "Please run as root (use sudo)"
    exit 1
fi

# Check if Filebeat is installed
if ! command -v filebeat &> /dev/null; then
    echo "Filebeat is not installed. Installing..."
    
    # Detect OS
    if [ -f /etc/os-release ]; then
        . /etc/os-release
        OS=$ID
    else
        echo "Cannot detect OS. Please install Filebeat manually."
        exit 1
    fi
    
    if [ "$OS" = "ubuntu" ] || [ "$OS" = "debian" ]; then
        echo "Installing Filebeat on Ubuntu/Debian..."
        wget -qO - https://artifacts.elastic.co/GPG-KEY-elasticsearch | apt-key add -
        apt-get install apt-transport-https -y
        echo "deb https://artifacts.elastic.co/packages/8.x/apt stable main" | tee /etc/apt/sources.list.d/elastic-8.x.list
        apt-get update && apt-get install filebeat -y
    else
        echo "Please install Filebeat manually from: https://www.elastic.co/downloads/beats/filebeat"
        exit 1
    fi
else
    echo "✓ Filebeat is already installed"
fi

# Backup existing config
if [ -f /etc/filebeat/filebeat.yml ]; then
    echo "Backing up existing filebeat.yml..."
    cp /etc/filebeat/filebeat.yml /etc/filebeat/filebeat.yml.backup.$(date +%Y%m%d_%H%M%S)
fi

# Get script directory
SCRIPT_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"

# Copy configuration
echo "Copying Filebeat configuration..."
cp "$SCRIPT_DIR/filebeat/filebeat.yml" /etc/filebeat/filebeat.yml

# Set correct permissions
chmod 600 /etc/filebeat/filebeat.yml
chown root:root /etc/filebeat/filebeat.yml

# Test configuration
echo "Testing Filebeat configuration..."
filebeat test config -c /etc/filebeat/filebeat.yml

# Test output (check if Logstash is reachable)
echo "Testing Filebeat output connection..."
filebeat test output -c /etc/filebeat/filebeat.yml || {
    echo "⚠ Warning: Could not connect to Logstash at localhost:5045"
    echo "   Make sure Logstash is running: docker-compose up -d logstash"
}

# Check if Suricata log file exists
if [ ! -f /var/log/suricata/eve.json ]; then
    echo "⚠ Warning: /var/log/suricata/eve.json does not exist"
    echo "   Make sure Suricata is installed and generating alerts"
else
    echo "✓ Suricata log file found"
    # Check permissions
    if [ ! -r /var/log/suricata/eve.json ]; then
        echo "⚠ Warning: Cannot read /var/log/suricata/eve.json"
        echo "   Attempting to fix permissions..."
        chmod 644 /var/log/suricata/eve.json || {
            echo "   Failed to fix permissions. You may need to do this manually."
        }
    fi
fi

echo ""
echo "=== Setup Complete ==="
echo ""
echo "Next steps:"
echo "1. Review configuration: sudo nano /etc/filebeat/filebeat.yml"
echo "2. Enable and start Filebeat:"
echo "   sudo systemctl enable filebeat"
echo "   sudo systemctl start filebeat"
echo "3. Check status: sudo systemctl status filebeat"
echo "4. View logs: sudo tail -f /var/log/filebeat/filebeat"


