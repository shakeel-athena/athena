#!/bin/bash
# Verification script for Suricata pipeline

echo "=== Suricata Pipeline Verification ==="
echo ""

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# Check Docker services
echo "1. Checking Docker services..."
if docker ps | grep -q suricata-elasticsearch; then
    echo -e "${GREEN}✓${NC} Elasticsearch container is running"
else
    echo -e "${RED}✗${NC} Elasticsearch container is not running"
fi

if docker ps | grep -q suricata-logstash; then
    echo -e "${GREEN}✓${NC} Logstash container is running"
else
    echo -e "${RED}✗${NC} Logstash container is not running"
fi

if docker ps | grep -q suricata-kibana; then
    echo -e "${GREEN}✓${NC} Kibana container is running"
else
    echo -e "${RED}✗${NC} Kibana container is not running"
fi

echo ""

# Check Elasticsearch
echo "2. Checking Elasticsearch..."
if curl -s http://localhost:9220 > /dev/null; then
    echo -e "${GREEN}✓${NC} Elasticsearch is responding"
    CLUSTER_HEALTH=$(curl -s http://localhost:9220/_cluster/health | grep -o '"status":"[^"]*"' | cut -d'"' -f4)
    echo "   Cluster status: $CLUSTER_HEALTH"
else
    echo -e "${RED}✗${NC} Elasticsearch is not responding"
fi

# Check indices
INDICES=$(curl -s http://localhost:9220/_cat/indices/suricata-alerts-* 2>/dev/null | wc -l)
if [ "$INDICES" -gt 0 ]; then
    echo -e "${GREEN}✓${NC} Suricata alert indices exist"
    echo "   Indices:"
    curl -s http://localhost:9220/_cat/indices/suricata-alerts-*?v 2>/dev/null | tail -n +2
else
    echo -e "${YELLOW}⚠${NC} No Suricata alert indices found yet"
fi

echo ""

# Check Logstash
echo "3. Checking Logstash..."
if docker exec suricata-logstash curl -s http://localhost:9600 > /dev/null 2>&1; then
    echo -e "${GREEN}✓${NC} Logstash API is responding"
    LOGSTASH_STATUS=$(docker exec suricata-logstash curl -s http://localhost:9600/_node/stats 2>/dev/null | grep -o '"events":{"in":[0-9]*' | grep -o '[0-9]*' | head -1)
    if [ ! -z "$LOGSTASH_STATUS" ]; then
        echo "   Events processed: $LOGSTASH_STATUS"
    fi
else
    echo -e "${RED}✗${NC} Logstash API not responding"
fi

# Check if Logstash is listening on port 5045
if docker exec suricata-logstash netstat -tlnp 2>/dev/null | grep -q 5045; then
    echo -e "${GREEN}✓${NC} Logstash is listening on port 5045"
else
    echo -e "${RED}✗${NC} Logstash is not listening on port 5045"
fi

echo ""

# Check Filebeat
echo "4. Checking Filebeat..."
if systemctl is-active --quiet filebeat 2>/dev/null; then
    echo -e "${GREEN}✓${NC} Filebeat service is running"
elif docker ps | grep -q filebeat; then
    echo -e "${GREEN}✓${NC} Filebeat container is running"
else
    echo -e "${YELLOW}⚠${NC} Filebeat is not running"
    echo "   Install and start: sudo ./setup-filebeat.sh"
fi

echo ""

# Check Suricata log
echo "5. Checking Suricata..."
if [ -f /var/log/suricata/eve.json ]; then
    echo -e "${GREEN}✓${NC} Suricata log file exists"
    FILE_SIZE=$(stat -f%z /var/log/suricata/eve.json 2>/dev/null || stat -c%s /var/log/suricata/eve.json 2>/dev/null)
    if [ "$FILE_SIZE" -gt 0 ]; then
        echo "   File size: $(numfmt --to=iec-i --suffix=B $FILE_SIZE 2>/dev/null || echo "$FILE_SIZE bytes")"
        ALERT_COUNT=$(grep -c '"event_type":"alert"' /var/log/suricata/eve.json 2>/dev/null || echo "0")
        echo "   Alert events in log: $ALERT_COUNT"
    else
        echo -e "${YELLOW}⚠${NC} Log file is empty"
    fi
    
    if [ -r /var/log/suricata/eve.json ]; then
        echo -e "${GREEN}✓${NC} Log file is readable"
    else
        echo -e "${RED}✗${NC} Log file is not readable (check permissions)"
    fi
else
    echo -e "${RED}✗${NC} Suricata log file not found: /var/log/suricata/eve.json"
fi

echo ""

# Check data flow
echo "6. Checking data flow..."
RECENT_ALERTS=$(curl -s "http://localhost:9220/suricata-alerts-*/_search?size=1&sort=@timestamp:desc" 2>/dev/null | grep -o '_id' | wc -l)
if [ "$RECENT_ALERTS" -gt 0 ]; then
    echo -e "${GREEN}✓${NC} Data is flowing to Elasticsearch"
    
    # Get most recent alert timestamp
    RECENT=$(curl -s "http://localhost:9220/suricata-alerts-*/_search?size=1&sort=@timestamp:desc&_source=@timestamp" 2>/dev/null)
    TIMESTAMP=$(echo "$RECENT" | grep -o '"@timestamp":"[^"]*"' | head -1 | cut -d'"' -f4)
    if [ ! -z "$TIMESTAMP" ]; then
        echo "   Most recent alert: $TIMESTAMP"
    fi
else
    echo -e "${YELLOW}⚠${NC} No data in Elasticsearch yet"
    echo "   Wait a few minutes for Filebeat to send data"
fi

echo ""
echo "=== Verification Complete ==="
echo ""
echo "Access points:"
echo "  - Elasticsearch: http://localhost:9220"
echo "  - Kibana: http://localhost:5621"
echo "  - Query alerts: curl 'http://localhost:9220/suricata-alerts-*/_search?pretty'"



