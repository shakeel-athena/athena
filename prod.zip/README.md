# Athena Security Platform

A comprehensive Security Operations Center (SOC) platform for automated threat detection, response, and network defense.

## Overview

Athena combines real-time security monitoring with automated response capabilities, integrating with Wazuh, Suricata, AWS WAF/Firewall, and threat intelligence APIs.

## Architecture

```
Frontend (React:3000) ──> Backend (Flask:5000) ──> PostgreSQL
                              │
                              ├── Elasticsearch (Wazuh/Suricata Alerts)
                              ├── AWS WAF / Network Firewall
                              ├── Keycloak (Authentication)
                              └── Wazuh Manager (Active Response)
```

## Quick Start

### Prerequisites

- Python 3.9+
- Node.js 16+
- PostgreSQL 15+
- Elasticsearch 7.17+ (or Wazuh Indexer)
- Keycloak 24+

### 1. Start Backend

```bash
cd backend/response
python src/app.py
```
Backend runs on: http://localhost:5000

### 2. Start Frontend

```bash
cd frontend
npm install
npm start
```
Frontend runs on: http://localhost:3000

### 3. Verify Services

```bash
curl http://localhost:5000/health
curl http://localhost:5000/api/health/comprehensive
```

## Key Features

| Feature | Description |
|---------|-------------|
| **Unified Alerts** | View Wazuh + Suricata alerts in one dashboard |
| **IP Enrichment** | Threat intel from AbuseIPDB, VirusTotal, OTX |
| **Alert Suppression** | Mute noisy alerts at source (Wazuh/Suricata) |
| **Active Response** | Host isolation via Wazuh Manager |
| **AWS Integration** | Network Firewall and WAF rule management |
| **Network Topology** | 2D/3D threat visualization |
| **RBAC** | Role-based access control via Keycloak |

## Technology Stack

| Component | Technology |
|-----------|------------|
| Frontend | React 18, Elastic UI (EUI) |
| Backend | Flask/Python 3.12 |
| Database | PostgreSQL 15+ |
| Search | Elasticsearch 7.17+ |
| Auth | Keycloak 24+ |
| IDS | Wazuh 4.14+ / Suricata |

## Documentation

See [docs/README.md](docs/README.md) for complete documentation:

- [Getting Started](docs/01-getting-started.md)
- [Backend Architecture](docs/05-backend-architecture.md)
- [Starting Services](docs/06-starting-services.md)
- [API Reference](docs/07-api-reference.md)

### Feature Documentation

- [Alert Suppression](docs/features/ALERT-SUPPRESSION.md)
- [IP Enrichment](docs/features/IP-ENRICHMENT.md)
- [Active Response](docs/features/ACTIVE-RESPONSE.md)
- [Firewall & WAF](docs/features/FIREWALL-WAF.md)
- [Network Topology](docs/features/NETWORK-TOPOLOGY.md)

## Environment Configuration

Copy `.env.example` to `.env` and configure:

```bash
# Database
POSTGRES_HOST=localhost
POSTGRES_PORT=5432
POSTGRES_DB=athena_db

# Elasticsearch
ELASTICSEARCH_HOST=localhost
ELASTICSEARCH_PORT=9220

# Keycloak
KEYCLOAK_URL=http://localhost:8080
KEYCLOAK_REALM=athena-security

# AWS (optional)
AWS_PROFILE=your-profile
AWS_REGION=us-east-2
```

## Project Structure

```
athena/
├── frontend/                 # React application
│   ├── src/pages/           # Page components
│   ├── src/components/      # Reusable components
│   └── src/services/        # API services
├── backend/response/        # Flask API
│   ├── src/api/            # API blueprints
│   ├── src/services/       # Business logic
│   └── src/core/           # Infrastructure
├── database/               # Schema and migrations
├── scripts/               # Utility scripts
└── docs/                  # Documentation
```

## License

Proprietary - All rights reserved
