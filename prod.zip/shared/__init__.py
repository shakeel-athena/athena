"""
Athena Shared Infrastructure Module

This module provides shared infrastructure services used across all Athena components:
- Database connection management
- AWS client factory and management
- Configuration management
- Authentication and authorization
- Structured logging
- Event bus for inter-component communication
"""

__version__ = "1.0.0"
