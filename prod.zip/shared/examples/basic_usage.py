"""
Athena Shared Infrastructure - Basic Usage Examples

This file demonstrates how to use the shared infrastructure components.
"""

import sys
import logging
from pathlib import Path

# Add shared module to path
project_root = Path(__file__).parent.parent.parent
sys.path.insert(0, str(project_root))

from shared.infrastructure.database import DatabaseConnectionManager, DatabaseConfig
from shared.infrastructure.aws import AWSClientFactory
from shared.infrastructure.config import ConfigurationManager

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)


def example_configuration():
    """Example: Using Configuration Manager"""
    logger.info("=== Configuration Manager Example ===")

    config = ConfigurationManager()

    # Get configuration values
    db_host = config.get('DB_HOST', 'localhost')
    db_port = config.get_int('DB_PORT', 5432)
    debug = config.get_bool('DEBUG', False)

    logger.info(f"Database Host: {db_host}")
    logger.info(f"Database Port: {db_port}")
    logger.info(f"Debug Mode: {debug}")

    # Get predefined configurations
    db_config = config.get_database_config()
    logger.info(f"Database Config: {db_config['database']}@{db_config['host']}")

    aws_config = config.get_aws_config()
    logger.info(f"AWS Region: {aws_config['region']}")

    # Environment detection
    logger.info(f"Environment: {config.get_environment()}")
    logger.info(f"Is Production: {config.is_production()}")


def example_database():
    """Example: Using Database Connection Manager"""
    logger.info("\n=== Database Connection Manager Example ===")

    # Create database configuration
    config = DatabaseConfig()
    logger.info(f"Database Config: {config}")

    # Validate configuration
    is_valid, error = config.validate()
    if not is_valid:
        logger.error(f"Invalid configuration: {error}")
        return

    # Initialize database manager
    db_manager = DatabaseConnectionManager(config)

    try:
        db_manager.initialize()
        logger.info("Database connection manager initialized")

        # Test connection
        if db_manager.test_connection():
            logger.info("✓ Database connection test successful")
        else:
            logger.error("✗ Database connection test failed")
            return

        # Get pool statistics
        stats = db_manager.get_pool_stats()
        logger.info(f"Pool Stats: SQLAlchemy={stats['sqlalchemy']['available']}, "
                   f"psycopg2={stats['psycopg2']['available']}")

        # Example: Using session scope (SQLAlchemy)
        if stats['sqlalchemy']['available']:
            with db_manager.session_scope() as session:
                # Your database operations here
                logger.info("Session scope ready for database operations")

        # Example: Using connection scope (psycopg2)
        if stats['psycopg2']['available']:
            with db_manager.connection_scope() as conn:
                cursor = conn.execute("SELECT 1 as test")
                result = cursor.fetchone()
                logger.info(f"psycopg2 test query result: {result}")

    except Exception as e:
        logger.error(f"Database error: {e}")

    finally:
        # Cleanup
        db_manager.close()
        logger.info("Database connections closed")


def example_aws():
    """Example: Using AWS Client Factory"""
    logger.info("\n=== AWS Client Factory Example ===")

    try:
        # Create AWS factory
        aws_factory = AWSClientFactory()
        logger.info(f"AWS Factory: {aws_factory}")

        # Validate credentials
        creds = aws_factory.validate_credentials()
        logger.info(f"✓ AWS Credentials Valid")
        logger.info(f"  Account ID: {creds['account_id']}")
        logger.info(f"  ARN: {creds['arn']}")
        logger.info(f"  Region: {creds['region']}")

        # Health check
        health = aws_factory.health_check()
        if health['healthy']:
            logger.info(f"✓ AWS Health Check: {health['message']}")
        else:
            logger.error(f"✗ AWS Health Check Failed: {health.get('error')}")
            return

        # Get service clients
        logger.info("\nGetting AWS service clients...")

        waf_client = aws_factory.get_waf_client()
        logger.info(f"✓ WAF Client: {waf_client}")

        firewall_client = aws_factory.get_network_firewall_client()
        logger.info(f"✓ Network Firewall Client: {firewall_client}")

        ec2_client = aws_factory.get_ec2_client()
        logger.info(f"✓ EC2 Client: {ec2_client}")

        # Example: List WAF Web ACLs
        logger.info("\nListing WAF Web ACLs...")
        response = waf_client.list_web_acls(Scope='REGIONAL')
        logger.info(f"Found {len(response.get('WebACLs', []))} WAF Web ACLs")

    except Exception as e:
        logger.error(f"AWS error: {e}")
        logger.info("Note: AWS credentials may not be configured in this environment")


def example_integrated():
    """Example: Using all components together"""
    logger.info("\n=== Integrated Example ===")

    # Initialize all components
    config = ConfigurationManager()
    aws_factory = AWSClientFactory()

    db_config = DatabaseConfig()
    db_manager = DatabaseConnectionManager(db_config)
    db_manager.initialize()

    try:
        logger.info("All infrastructure components initialized")

        # Example: Service that uses all components
        class ExampleService:
            def __init__(self, db_manager, aws_factory, config):
                self.db = db_manager
                self.aws = aws_factory
                self.config = config

            def get_system_info(self):
                """Get system information from all components"""
                info = {
                    'environment': self.config.get_environment(),
                    'database': {
                        'connected': self.db.test_connection(),
                        'stats': self.db.get_pool_stats()
                    },
                    'aws': self.aws.health_check()
                }
                return info

        # Use the service
        service = ExampleService(db_manager, aws_factory, config)
        system_info = service.get_system_info()

        logger.info("System Information:")
        logger.info(f"  Environment: {system_info['environment']}")
        logger.info(f"  Database Connected: {system_info['database']['connected']}")
        logger.info(f"  AWS Healthy: {system_info['aws']['healthy']}")

    finally:
        db_manager.close()


if __name__ == '__main__':
    logger.info("Athena Shared Infrastructure Examples\n")

    # Run examples
    example_configuration()
    example_database()
    example_aws()
    example_integrated()

    logger.info("\n=== Examples Complete ===")
