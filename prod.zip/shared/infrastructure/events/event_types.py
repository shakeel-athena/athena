"""Event type definitions"""

from enum import Enum


class EventType(Enum):
    # Alert events
    ALERT_RECEIVED = "alert.received"
    ALERT_PROCESSED = "alert.processed"
    ALERT_ESCALATED = "alert.escalated"

    # Response events
    RESPONSE_ACTION_STARTED = "response.action.started"
    RESPONSE_ACTION_COMPLETED = "response.action.completed"
    RESPONSE_ACTION_FAILED = "response.action.failed"

    # Firewall events
    FIREWALL_IP_BLOCKED = "firewall.ip.blocked"
    FIREWALL_IP_UNBLOCKED = "firewall.ip.unblocked"
    FIREWALL_RULE_UPDATED = "firewall.rule.updated"

    # WAF events
    WAF_IP_BLOCKED = "waf.ip.blocked"
    WAF_SIGNATURE_ADDED = "waf.signature.added"
    WAF_SIGNATURE_REMOVED = "waf.signature.removed"

    # Threat intelligence events
    THREAT_INTEL_UPDATED = "threat.intel.updated"
    THREAT_DETECTED = "threat.detected"

    # System events
    SYSTEM_HEALTH_CHECK = "system.health.check"
    SYSTEM_ERROR = "system.error"
