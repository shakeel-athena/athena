"""Event handlers"""

import logging
from typing import Dict, Any
from .event_bus import Event

logger = logging.getLogger(__name__)


class BaseEventHandler:
    def __init__(self):
        self.logger = logging.getLogger(self.__class__.__name__)

    async def handle(self, event: Event):
        raise NotImplementedError


class AlertEventHandler(BaseEventHandler):
    def __init__(self, db_manager, aws_factory):
        super().__init__()
        self.db_manager = db_manager
        self.aws_factory = aws_factory

    async def handle(self, event: Event):
        alert_data = event.data
        self.logger.info(f"Handling alert: {alert_data.get('id')}")

        severity = alert_data.get('severity', 'LOW')
        if severity == 'CRITICAL':
            await self._handle_critical_alert(alert_data)

    async def _handle_critical_alert(self, alert_data: Dict[str, Any]):
        self.logger.warning(f"Critical alert: {alert_data.get('id')}")


class ResponseActionHandler(BaseEventHandler):
    def __init__(self, db_manager):
        super().__init__()
        self.db_manager = db_manager

    async def handle(self, event: Event):
        action_data = event.data
        self.logger.info(f"Logging response action: {action_data.get('action_type')}")

        try:
            with self.db_manager.connection_scope() as conn:
                conn.execute(
                    "INSERT INTO response_actions (action_type, target, status, timestamp) VALUES (%s, %s, %s, %s)",
                    (action_data.get('action_type'), action_data.get('target'), 'completed', event.timestamp)
                )
        except Exception as e:
            self.logger.error(f"Failed to log response action: {e}")
