"""Event Bus for inter-component communication"""

import asyncio
import logging
from typing import Dict, List, Callable, Any, Optional
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
import uuid

logger = logging.getLogger(__name__)


class EventPriority(Enum):
    LOW = 0
    NORMAL = 1
    HIGH = 2
    CRITICAL = 3


@dataclass
class Event:
    type: str
    data: Dict[str, Any]
    source: str
    timestamp: datetime = field(default_factory=datetime.utcnow)
    correlation_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    priority: EventPriority = EventPriority.NORMAL
    metadata: Dict[str, Any] = field(default_factory=dict)


class EventBus:
    def __init__(self):
        self._handlers: Dict[str, List[Callable]] = {}
        self._middleware: List[Callable] = []
        self._running = False

    def subscribe(self, event_type: str, handler: Callable):
        if event_type not in self._handlers:
            self._handlers[event_type] = []
        self._handlers[event_type].append(handler)
        logger.info(f"Handler subscribed to {event_type}")

    def unsubscribe(self, event_type: str, handler: Callable):
        if event_type in self._handlers:
            self._handlers[event_type].remove(handler)

    def add_middleware(self, middleware: Callable):
        self._middleware.append(middleware)

    async def publish(self, event: Event):
        logger.debug(f"Publishing event: {event.type} from {event.source}")

        for middleware in self._middleware:
            event = await middleware(event) if asyncio.iscoroutinefunction(middleware) else middleware(event)
            if not event:
                return

        handlers = self._handlers.get(event.type, [])
        if handlers:
            tasks = []
            for handler in handlers:
                if asyncio.iscoroutinefunction(handler):
                    tasks.append(handler(event))
                else:
                    tasks.append(asyncio.to_thread(handler, event))

            results = await asyncio.gather(*tasks, return_exceptions=True)
            for result in results:
                if isinstance(result, Exception):
                    logger.error(f"Handler error: {result}")

    async def publish_alert(self, alert_data: Dict[str, Any], source: str, priority: EventPriority = EventPriority.NORMAL):
        event = Event(
            type="ALERT_RECEIVED",
            data=alert_data,
            source=source,
            priority=priority
        )
        await self.publish(event)

    async def publish_response_action(self, action_data: Dict[str, Any], source: str):
        event = Event(
            type="RESPONSE_ACTION",
            data=action_data,
            source=source
        )
        await self.publish(event)


_global_event_bus: Optional[EventBus] = None


def get_event_bus() -> EventBus:
    global _global_event_bus
    if _global_event_bus is None:
        _global_event_bus = EventBus()
    return _global_event_bus
