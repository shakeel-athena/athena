"""
Database Exception Classes

Custom exceptions for database operations.
"""


class DatabaseError(Exception):
    """Base exception for database errors"""
    pass


class ConnectionError(DatabaseError):
    """Exception raised for connection-related errors"""
    pass


class QueryError(DatabaseError):
    """Exception raised for query execution errors"""
    pass


class ConfigurationError(DatabaseError):
    """Exception raised for configuration errors"""
    pass


class PoolExhaustedError(DatabaseError):
    """Exception raised when connection pool is exhausted"""
    pass
