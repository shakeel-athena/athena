"""
Database Connection Manager

Centralized database connection management with support for both
SQLAlchemy (ORM) and psycopg2 (raw SQL) connections.
"""

import logging
from contextlib import contextmanager
from typing import Optional, Any

import psycopg2
from psycopg2 import pool as psycopg2_pool
from psycopg2.extras import RealDictCursor
from sqlalchemy import create_engine, event, exc, pool, text
from sqlalchemy.orm import sessionmaker, scoped_session, Session
from sqlalchemy.ext.declarative import declarative_base

from .config import DatabaseConfig
from .exceptions import DatabaseError, ConnectionError, QueryError, PoolExhaustedError

logger = logging.getLogger(__name__)

# Create declarative base for ORM models
Base = declarative_base()


class DatabaseWrapper:
    """
    Wrapper around psycopg2 connection providing a consistent interface.
    Compatible with existing RBAC and legacy code expectations.
    """

    def __init__(self, conn):
        """
        Initialize database wrapper.

        Args:
            conn: psycopg2 connection object
        """
        self.conn = conn
        self.cursor_factory = RealDictCursor

    def execute(self, query: str, params: Optional[tuple] = None):
        """
        Execute query and return cursor with RealDictCursor.

        Args:
            query: SQL query string
            params: Query parameters

        Returns:
            Cursor with results
        """
        cursor = self.conn.cursor(cursor_factory=RealDictCursor)
        if params:
            cursor.execute(query, params)
        else:
            cursor.execute(query)
        return cursor

    def commit(self):
        """Commit transaction"""
        self.conn.commit()

    def rollback(self):
        """Rollback transaction"""
        self.conn.rollback()

    def close(self):
        """Close connection"""
        self.conn.close()


class DatabaseConnectionManager:
    """
    Unified database connection manager supporting both SQLAlchemy and psycopg2.

    Provides:
    - SQLAlchemy session management for ORM operations
    - psycopg2 connection pooling for raw SQL operations
    - Automatic fallback between connection methods
    - Health checks and connection monitoring
    """

    def __init__(self, config: Optional[DatabaseConfig] = None):
        """
        Initialize database connection manager.

        Args:
            config: DatabaseConfig instance (creates default if not provided)
        """
        self.config = config or DatabaseConfig()

        # SQLAlchemy components
        self.engine: Optional[Any] = None
        self.session_factory: Optional[sessionmaker] = None
        self.scoped_session_factory: Optional[scoped_session] = None

        # psycopg2 components
        self._psycopg2_pool: Optional[psycopg2_pool.ThreadedConnectionPool] = None

        # State tracking
        self._initialized = False
        self._sqlalchemy_available = False
        self._psycopg2_available = False

        logger.info(f"DatabaseConnectionManager created with config: {self.config}")

    def initialize(self):
        """
        Initialize database connections.

        Attempts to initialize both SQLAlchemy and psycopg2 pools.
        At least one must succeed for initialization to complete.

        Raises:
            ConnectionError: If both connection methods fail
        """
        if self._initialized:
            logger.warning("Database connection manager already initialized")
            return

        # Validate configuration
        is_valid, error_message = self.config.validate()
        if not is_valid:
            raise ConnectionError(f"Invalid database configuration: {error_message}")

        # Try to initialize SQLAlchemy
        try:
            self._initialize_sqlalchemy()
            self._sqlalchemy_available = True
            logger.info("SQLAlchemy connection pool initialized successfully")
        except Exception as e:
            logger.warning(f"Failed to initialize SQLAlchemy pool: {e}")
            self._sqlalchemy_available = False

        # Try to initialize psycopg2 pool
        try:
            self._initialize_psycopg2()
            self._psycopg2_available = True
            logger.info("psycopg2 connection pool initialized successfully")
        except Exception as e:
            logger.warning(f"Failed to initialize psycopg2 pool: {e}")
            self._psycopg2_available = False

        # At least one connection method must work
        if not self._sqlalchemy_available and not self._psycopg2_available:
            raise ConnectionError("Failed to initialize any database connection method")

        self._initialized = True
        logger.info(f"Database connection manager initialized (SQLAlchemy: {self._sqlalchemy_available}, "
                   f"psycopg2: {self._psycopg2_available})")

    def _initialize_sqlalchemy(self):
        """Initialize SQLAlchemy engine and session factories"""
        try:
            # Get SQLAlchemy configuration
            sqlalchemy_config = self.config.get_sqlalchemy_config()

            # Create engine
            self.engine = create_engine(
                self.config.get_database_uri(),
                poolclass=pool.QueuePool,
                **{k: v for k, v in sqlalchemy_config.items() if k != 'poolclass'}
            )

            # Set up event listeners for monitoring
            self._setup_event_listeners()

            # Create session factories
            self.session_factory = sessionmaker(
                bind=self.engine,
                autocommit=False,
                autoflush=False,
                expire_on_commit=False
            )

            self.scoped_session_factory = scoped_session(self.session_factory)

            logger.debug("SQLAlchemy engine and session factories created")

        except Exception as e:
            logger.error(f"Error initializing SQLAlchemy: {e}")
            raise

    def _initialize_psycopg2(self):
        """Initialize psycopg2 connection pool"""
        try:
            params = self.config.get_psycopg2_params()

            self._psycopg2_pool = psycopg2_pool.ThreadedConnectionPool(
                minconn=self.config.min_connections,
                maxconn=self.config.max_connections,
                **params
            )

            logger.debug(f"psycopg2 pool created (min={self.config.min_connections}, "
                        f"max={self.config.max_connections})")

        except Exception as e:
            logger.error(f"Error initializing psycopg2 pool: {e}")
            raise

    def _setup_event_listeners(self):
        """Set up SQLAlchemy event listeners for connection monitoring"""
        if not self.engine:
            return

        @event.listens_for(self.engine, "connect")
        def receive_connect(dbapi_conn, connection_record):
            """Log new database connections"""
            logger.debug("New SQLAlchemy database connection established")

        @event.listens_for(self.engine, "checkout")
        def receive_checkout(dbapi_conn, connection_record, connection_proxy):
            """Log connection checkouts from pool"""
            logger.debug("Connection checked out from SQLAlchemy pool")

        @event.listens_for(self.engine, "checkin")
        def receive_checkin(dbapi_conn, connection_record):
            """Log connection returns to pool"""
            logger.debug("Connection returned to SQLAlchemy pool")

    def get_session(self) -> Session:
        """
        Get a new SQLAlchemy database session.

        Returns:
            Session: SQLAlchemy session object

        Raises:
            RuntimeError: If manager not initialized or SQLAlchemy unavailable
        """
        if not self._initialized:
            raise RuntimeError("Database connection manager not initialized. Call initialize() first.")

        if not self._sqlalchemy_available:
            raise RuntimeError("SQLAlchemy connection not available")

        return self.scoped_session_factory()

    @contextmanager
    def session_scope(self):
        """
        Provide a transactional scope for SQLAlchemy operations.

        Usage:
            with db.session_scope() as session:
                session.add(obj)
                # Transaction commits automatically

        Yields:
            Session: Database session with automatic commit/rollback
        """
        if not self._initialized:
            raise RuntimeError("Database connection manager not initialized. Call initialize() first.")

        if not self._sqlalchemy_available:
            raise RuntimeError("SQLAlchemy connection not available")

        session = self.scoped_session_factory()
        try:
            yield session
            session.commit()
        except exc.SQLAlchemyError as e:
            session.rollback()
            logger.error(f"Database error in session scope: {e}")
            raise QueryError(f"Database error: {e}") from e
        except Exception as e:
            session.rollback()
            logger.error(f"Unexpected error in session scope: {e}")
            raise
        finally:
            session.close()

    def get_connection(self) -> DatabaseWrapper:
        """
        Get a psycopg2 connection from the pool (wrapped for compatibility).

        Returns:
            DatabaseWrapper: Wrapped psycopg2 connection

        Raises:
            RuntimeError: If manager not initialized or psycopg2 unavailable
            PoolExhaustedError: If no connections available
        """
        if not self._initialized:
            raise RuntimeError("Database connection manager not initialized. Call initialize() first.")

        if not self._psycopg2_available:
            raise RuntimeError("psycopg2 connection not available")

        try:
            conn = self._psycopg2_pool.getconn()
            return DatabaseWrapper(conn)
        except psycopg2_pool.PoolError as e:
            logger.error(f"Failed to get connection from pool: {e}")
            raise PoolExhaustedError("Connection pool exhausted") from e
        except Exception as e:
            logger.error(f"Error getting database connection: {e}")
            raise ConnectionError(f"Failed to get connection: {e}") from e

    def return_connection(self, wrapped_conn: DatabaseWrapper):
        """
        Return a psycopg2 connection to the pool.

        Args:
            wrapped_conn: DatabaseWrapper instance to return
        """
        if not self._psycopg2_available or not self._psycopg2_pool:
            logger.warning("Cannot return connection - psycopg2 pool not available")
            return

        try:
            self._psycopg2_pool.putconn(wrapped_conn.conn)
            logger.debug("Connection returned to psycopg2 pool")
        except Exception as e:
            logger.error(f"Error returning connection to pool: {e}")

    @contextmanager
    def connection_scope(self):
        """
        Provide a context manager for psycopg2 connections.

        Usage:
            with db.connection_scope() as conn:
                cursor = conn.execute("SELECT * FROM table")

        Yields:
            DatabaseWrapper: Wrapped connection that auto-returns to pool
        """
        conn = self.get_connection()
        try:
            yield conn
            conn.commit()
        except Exception as e:
            conn.rollback()
            logger.error(f"Error in connection scope: {e}")
            raise
        finally:
            self.return_connection(conn)

    def test_connection(self) -> bool:
        """
        Test database connection.

        Returns:
            bool: True if connection successful, False otherwise
        """
        if not self._initialized:
            logger.error("Database connection manager not initialized")
            return False

        # Try SQLAlchemy first
        if self._sqlalchemy_available:
            try:
                with self.engine.connect() as connection:
                    connection.execute(text("SELECT 1"))
                logger.info("SQLAlchemy database connection test successful")
                return True
            except Exception as e:
                logger.error(f"SQLAlchemy connection test failed: {e}")

        # Try psycopg2 fallback
        if self._psycopg2_available:
            try:
                with self.connection_scope() as conn:
                    cursor = conn.execute("SELECT 1")
                    cursor.close()
                logger.info("psycopg2 database connection test successful")
                return True
            except Exception as e:
                logger.error(f"psycopg2 connection test failed: {e}")

        return False

    def get_pool_stats(self) -> dict:
        """
        Get connection pool statistics.

        Returns:
            dict: Pool statistics
        """
        stats = {
            'initialized': self._initialized,
            'sqlalchemy': {
                'available': self._sqlalchemy_available,
                'pool_size': self.config.pool_size,
                'max_overflow': self.config.max_overflow,
                'pool_timeout': self.config.pool_timeout,
            },
            'psycopg2': {
                'available': self._psycopg2_available,
                'min_connections': self.config.min_connections,
                'max_connections': self.config.max_connections,
            }
        }

        # Add actual pool stats if available
        if self._psycopg2_available and self._psycopg2_pool:
            try:
                stats['psycopg2']['current_connections'] = len(self._psycopg2_pool._pool)
                stats['psycopg2']['available_connections'] = self._psycopg2_pool._pool.qsize()
            except Exception as e:
                logger.debug(f"Could not get psycopg2 pool stats: {e}")

        return stats

    def close(self):
        """Close all database connections and cleanup resources"""
        if not self._initialized:
            logger.warning("Database connection manager not initialized, nothing to close")
            return

        try:
            # Close SQLAlchemy connections
            if self._sqlalchemy_available and self.scoped_session_factory:
                self.scoped_session_factory.remove()
                self.engine.dispose()
                logger.info("SQLAlchemy connections closed")

            # Close psycopg2 pool
            if self._psycopg2_available and self._psycopg2_pool:
                self._psycopg2_pool.closeall()
                logger.info("psycopg2 connection pool closed")

            self._initialized = False
            self._sqlalchemy_available = False
            self._psycopg2_available = False

            logger.info("Database connection manager closed successfully")

        except Exception as e:
            logger.error(f"Error closing database connections: {e}")
            raise DatabaseError(f"Failed to close connections: {e}") from e

    def create_all_tables(self):
        """
        Create all database tables defined in ORM models.

        Note: Use migrations for production. This is mainly for development/testing.
        """
        if not self._initialized or not self._sqlalchemy_available:
            raise RuntimeError("SQLAlchemy connection not available for table creation")

        try:
            Base.metadata.create_all(self.engine)
            logger.info("Database tables created successfully")
        except Exception as e:
            logger.error(f"Error creating database tables: {e}")
            raise DatabaseError(f"Failed to create tables: {e}") from e

    def __repr__(self) -> str:
        """String representation"""
        return (f"DatabaseConnectionManager(initialized={self._initialized}, "
                f"sqlalchemy={self._sqlalchemy_available}, "
                f"psycopg2={self._psycopg2_available})")
