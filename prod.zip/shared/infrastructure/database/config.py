"""
Database Configuration

Centralized database configuration management supporting multiple
environment variable naming conventions (POSTGRES_*, DB_*).
"""

import os
import urllib.parse
from dataclasses import dataclass, field
from typing import Optional
from dotenv import load_dotenv

from .exceptions import ConfigurationError


# Load environment variables
load_dotenv()


@dataclass
class DatabaseConfig:
    """
    Database configuration with support for both POSTGRES_* and DB_* environment variables.

    Attributes:
        user: Database user
        password: Database password
        host: Database host
        port: Database port
        database: Database name
        pool_size: Connection pool size
        max_overflow: Maximum overflow connections
        pool_timeout: Pool timeout in seconds
        pool_recycle: Pool recycle time in seconds
        connect_timeout: Connection timeout in seconds
        statement_timeout: Statement timeout in milliseconds
        echo: Enable SQL echo (debug mode)
    """

    user: str = field(default_factory=lambda: os.getenv('POSTGRES_USER') or os.getenv('DB_USER', 'athena'))
    password: str = field(default_factory=lambda: os.getenv('POSTGRES_PASSWORD') or os.getenv('DB_PASSWORD', 'athena123'))
    host: str = field(default_factory=lambda: os.getenv('POSTGRES_HOST') or os.getenv('DB_HOST', 'localhost'))
    port: str = field(default_factory=lambda: os.getenv('POSTGRES_PORT') or os.getenv('DB_PORT', '5432'))
    database: str = field(default_factory=lambda: os.getenv('POSTGRES_DB') or os.getenv('DB_NAME', 'athena_db'))

    # Connection pool settings
    pool_size: int = field(default_factory=lambda: int(os.getenv('DB_POOL_SIZE', '10')))
    max_overflow: int = field(default_factory=lambda: int(os.getenv('DB_MAX_OVERFLOW', '20')))
    pool_timeout: int = field(default_factory=lambda: int(os.getenv('DB_POOL_TIMEOUT', '30')))
    pool_recycle: int = field(default_factory=lambda: int(os.getenv('DB_POOL_RECYCLE', '3600')))

    # Connection settings
    connect_timeout: int = field(default_factory=lambda: int(os.getenv('DB_CONNECT_TIMEOUT', '10')))
    statement_timeout: int = field(default_factory=lambda: int(os.getenv('DB_STATEMENT_TIMEOUT', '30000')))

    # Debug settings
    echo: bool = field(default_factory=lambda: os.getenv('SQLALCHEMY_ECHO', 'False').lower() == 'true')

    # Minimum pool connections (for psycopg2 fallback)
    min_connections: int = field(default_factory=lambda: int(os.getenv('DB_POOL_MIN', '2')))
    max_connections: int = field(default_factory=lambda: int(os.getenv('DB_POOL_MAX', '10')))

    def get_database_uri(self) -> str:
        """
        Get SQLAlchemy database URI with proper URL encoding.

        Returns:
            str: Database URI
        """
        # Check for explicit DATABASE_URI override
        if os.getenv('DATABASE_URI'):
            return os.getenv('DATABASE_URI')

        # URL encode credentials to handle special characters
        encoded_user = urllib.parse.quote_plus(str(self.user))
        encoded_password = urllib.parse.quote_plus(str(self.password))

        return f'postgresql://{encoded_user}:{encoded_password}@{self.host}:{self.port}/{self.database}'

    def get_psycopg2_params(self) -> dict:
        """
        Get psycopg2 connection parameters.

        Returns:
            dict: Connection parameters for psycopg2
        """
        return {
            'host': self.host,
            'port': self.port,
            'database': self.database,
            'user': self.user,
            'password': self.password,
            'connect_timeout': self.connect_timeout,
        }

    def validate(self) -> tuple[bool, Optional[str]]:
        """
        Validate database configuration.

        Returns:
            tuple: (is_valid, error_message)
        """
        required_fields = {
            'user': self.user,
            'password': self.password,
            'host': self.host,
            'port': self.port,
            'database': self.database,
        }

        missing_fields = [field for field, value in required_fields.items() if not value]

        if missing_fields:
            return False, f"Missing required configuration: {', '.join(missing_fields)}"

        # Validate numeric fields
        if self.pool_size < 1:
            return False, "pool_size must be at least 1"

        if self.max_overflow < 0:
            return False, "max_overflow must be non-negative"

        if self.pool_timeout < 1:
            return False, "pool_timeout must be at least 1"

        return True, None

    def get_sqlalchemy_config(self) -> dict:
        """
        Get SQLAlchemy configuration dictionary.

        Returns:
            dict: Configuration for SQLAlchemy engine
        """
        return {
            'poolclass': 'QueuePool',
            'pool_size': self.pool_size,
            'max_overflow': self.max_overflow,
            'pool_timeout': self.pool_timeout,
            'pool_recycle': self.pool_recycle,
            'pool_pre_ping': True,
            'echo': self.echo,
            'connect_args': {
                'connect_timeout': self.connect_timeout,
                'options': f'-c statement_timeout={self.statement_timeout}'
            }
        }

    def __repr__(self) -> str:
        """String representation (hiding password)"""
        return (f"DatabaseConfig(user='{self.user}', host='{self.host}', "
                f"port='{self.port}', database='{self.database}', "
                f"pool_size={self.pool_size}, max_overflow={self.max_overflow})")
