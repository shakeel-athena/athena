"""
Configuration Exception Classes

Custom exceptions for configuration operations.
"""


class ConfigurationError(Exception):
    """Base exception for configuration errors"""
    pass


class MissingConfigurationError(ConfigurationError):
    """Exception raised when required configuration is missing"""

    def __init__(self, key: str):
        self.key = key
        super().__init__(f"Required configuration '{key}' is missing")


class InvalidConfigurationError(ConfigurationError):
    """Exception raised when configuration value is invalid"""

    def __init__(self, key: str, reason: str):
        self.key = key
        self.reason = reason
        super().__init__(f"Configuration '{key}' is invalid: {reason}")
