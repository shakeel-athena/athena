"""
Configuration Manager

Centralized configuration management with environment variable loading,
validation, and type conversion.
"""

import os
import logging
from typing import Any, Optional, Dict, List, Union
from pathlib import Path
from dotenv import load_dotenv

from .exceptions import ConfigurationError, MissingConfigurationError, InvalidConfigurationError

logger = logging.getLogger(__name__)


class ConfigurationManager:
    """
    Centralized configuration manager for all Athena components.

    Features:
    - Environment variable loading from .env files
    - Type-safe configuration access
    - Default value support
    - Configuration validation
    - Multiple environment support (dev, staging, prod)
    """

    _instance: Optional['ConfigurationManager'] = None
    _loaded = False

    def __new__(cls):
        """Singleton pattern - only one instance exists."""
        if cls._instance is None:
            cls._instance = super().__new__(cls)
        return cls._instance

    def __init__(self):
        """Initialize configuration manager (only once due to singleton)."""
        if not ConfigurationManager._loaded:
            self._load_environment()
            self._config_cache: Dict[str, Any] = {}
            ConfigurationManager._loaded = True
            logger.info("ConfigurationManager initialized")

    def _load_environment(self):
        """Load environment variables from .env file if it exists."""
        # Look for .env file in project root
        current_dir = Path(__file__).resolve().parent
        project_root = current_dir.parent.parent.parent  # Go up to project root
        env_file = project_root / '.env'

        if env_file.exists():
            load_dotenv(dotenv_path=env_file)
            logger.info(f"Loaded environment from: {env_file}")
        else:
            logger.info("No .env file found, using system environment variables")

        # Also check for environment-specific .env files
        env = os.getenv('ENVIRONMENT', 'development')
        env_specific_file = project_root / f'.env.{env}'
        if env_specific_file.exists():
            load_dotenv(dotenv_path=env_specific_file, override=True)
            logger.info(f"Loaded environment-specific config from: {env_specific_file}")

    def get(self, key: str, default: Any = None, required: bool = False) -> Any:
        """
        Get configuration value.

        Args:
            key: Configuration key
            default: Default value if key not found
            required: If True, raises error when key is missing

        Returns:
            Configuration value

        Raises:
            MissingConfigurationError: If required=True and key not found
        """
        # Check cache first
        if key in self._config_cache:
            return self._config_cache[key]

        # Get from environment
        value = os.getenv(key, default)

        if value is None and required:
            raise MissingConfigurationError(key)

        # Cache the value
        if value is not None:
            self._config_cache[key] = value

        return value

    def get_int(self, key: str, default: Optional[int] = None, required: bool = False) -> Optional[int]:
        """
        Get integer configuration value.

        Args:
            key: Configuration key
            default: Default value if key not found
            required: If True, raises error when key is missing

        Returns:
            Integer value or None

        Raises:
            MissingConfigurationError: If required=True and key not found
            InvalidConfigurationError: If value cannot be converted to int
        """
        value = self.get(key, default, required)

        if value is None:
            return None

        try:
            return int(value)
        except (ValueError, TypeError) as e:
            raise InvalidConfigurationError(key, f"Cannot convert to integer: {value}") from e

    def get_float(self, key: str, default: Optional[float] = None, required: bool = False) -> Optional[float]:
        """
        Get float configuration value.

        Args:
            key: Configuration key
            default: Default value if key not found
            required: If True, raises error when key is missing

        Returns:
            Float value or None

        Raises:
            MissingConfigurationError: If required=True and key not found
            InvalidConfigurationError: If value cannot be converted to float
        """
        value = self.get(key, default, required)

        if value is None:
            return None

        try:
            return float(value)
        except (ValueError, TypeError) as e:
            raise InvalidConfigurationError(key, f"Cannot convert to float: {value}") from e

    def get_bool(self, key: str, default: Optional[bool] = None, required: bool = False) -> Optional[bool]:
        """
        Get boolean configuration value.

        Accepts: true/false, yes/no, 1/0 (case insensitive)

        Args:
            key: Configuration key
            default: Default value if key not found
            required: If True, raises error when key is missing

        Returns:
            Boolean value or None

        Raises:
            MissingConfigurationError: If required=True and key not found
            InvalidConfigurationError: If value cannot be converted to bool
        """
        value = self.get(key, default, required)

        if value is None:
            return None

        if isinstance(value, bool):
            return value

        if isinstance(value, str):
            value_lower = value.lower()
            if value_lower in ('true', 'yes', '1', 'on'):
                return True
            elif value_lower in ('false', 'no', '0', 'off'):
                return False
            else:
                raise InvalidConfigurationError(key, f"Cannot convert to boolean: {value}")

        raise InvalidConfigurationError(key, f"Invalid boolean value: {value}")

    def get_list(self, key: str, default: Optional[List[str]] = None,
                 separator: str = ',', required: bool = False) -> Optional[List[str]]:
        """
        Get list configuration value (comma-separated by default).

        Args:
            key: Configuration key
            default: Default value if key not found
            separator: List item separator (default: ',')
            required: If True, raises error when key is missing

        Returns:
            List of strings or None

        Raises:
            MissingConfigurationError: If required=True and key not found
        """
        value = self.get(key, default, required)

        if value is None:
            return None

        if isinstance(value, list):
            return value

        if isinstance(value, str):
            return [item.strip() for item in value.split(separator) if item.strip()]

        raise InvalidConfigurationError(key, f"Cannot convert to list: {value}")

    def set(self, key: str, value: Any):
        """
        Set configuration value (updates cache and environment).

        Args:
            key: Configuration key
            value: Configuration value
        """
        self._config_cache[key] = value
        os.environ[key] = str(value)
        logger.debug(f"Configuration set: {key}")

    def has(self, key: str) -> bool:
        """
        Check if configuration key exists.

        Args:
            key: Configuration key

        Returns:
            True if key exists, False otherwise
        """
        return key in os.environ or key in self._config_cache

    def get_all(self, prefix: str = '') -> Dict[str, str]:
        """
        Get all configuration values with optional prefix filter.

        Args:
            prefix: Optional prefix to filter keys (e.g., 'DB_', 'AWS_')

        Returns:
            Dictionary of configuration key-value pairs
        """
        if prefix:
            return {k: v for k, v in os.environ.items() if k.startswith(prefix)}
        return dict(os.environ)

    def get_database_config(self) -> Dict[str, Any]:
        """
        Get database configuration.

        Returns:
            Dictionary with database configuration
        """
        return {
            'user': self.get('POSTGRES_USER') or self.get('DB_USER', 'athena'),
            'password': self.get('POSTGRES_PASSWORD') or self.get('DB_PASSWORD', 'athena123'),
            'host': self.get('POSTGRES_HOST') or self.get('DB_HOST', 'localhost'),
            'port': self.get_int('POSTGRES_PORT') or self.get_int('DB_PORT', 5432),
            'database': self.get('POSTGRES_DB') or self.get('DB_NAME', 'athena_db'),
            'pool_size': self.get_int('DB_POOL_SIZE', 10),
            'max_overflow': self.get_int('DB_MAX_OVERFLOW', 20),
            'pool_timeout': self.get_int('DB_POOL_TIMEOUT', 30),
            'pool_recycle': self.get_int('DB_POOL_RECYCLE', 3600),
            'connect_timeout': self.get_int('DB_CONNECT_TIMEOUT', 10),
            'statement_timeout': self.get_int('DB_STATEMENT_TIMEOUT', 30000),
        }

    def get_aws_config(self) -> Dict[str, Any]:
        """
        Get AWS configuration.

        Returns:
            Dictionary with AWS configuration
        """
        return {
            'region': self.get('AWS_REGION', 'us-east-2'),
            'profile': self.get('AWS_PROFILE'),
            'access_key_id': self.get('AWS_ACCESS_KEY_ID'),
            'secret_access_key': self.get('AWS_SECRET_ACCESS_KEY'),
        }

    def get_redis_config(self) -> Dict[str, Any]:
        """
        Get Redis configuration.

        Returns:
            Dictionary with Redis configuration
        """
        return {
            'host': self.get('REDIS_HOST', 'localhost'),
            'port': self.get_int('REDIS_PORT', 6379),
            'db': self.get_int('REDIS_DB', 0),
            'password': self.get('REDIS_PASSWORD'),
            'decode_responses': self.get_bool('REDIS_DECODE_RESPONSES', True),
        }

    def get_keycloak_config(self) -> Dict[str, Any]:
        """
        Get Keycloak configuration.

        Returns:
            Dictionary with Keycloak configuration
        """
        return {
            'server_url': self.get('KEYCLOAK_SERVER_URL', required=False),
            'realm': self.get('KEYCLOAK_REALM', 'athena'),
            'client_id': self.get('KEYCLOAK_CLIENT_ID', 'athena-backend'),
            'client_secret': self.get('KEYCLOAK_CLIENT_SECRET'),
        }

    def get_environment(self) -> str:
        """
        Get current environment.

        Returns:
            Environment name (development, staging, production)
        """
        return self.get('ENVIRONMENT', 'development')

    def is_production(self) -> bool:
        """
        Check if running in production environment.

        Returns:
            True if production, False otherwise
        """
        return self.get_environment().lower() in ('production', 'prod')

    def is_development(self) -> bool:
        """
        Check if running in development environment.

        Returns:
            True if development, False otherwise
        """
        return self.get_environment().lower() in ('development', 'dev')

    def validate_required_config(self, keys: List[str]) -> bool:
        """
        Validate that required configuration keys exist.

        Args:
            keys: List of required configuration keys

        Returns:
            True if all keys exist

        Raises:
            MissingConfigurationError: If any required key is missing
        """
        missing_keys = [key for key in keys if not self.has(key)]

        if missing_keys:
            raise MissingConfigurationError(f"Missing required configuration: {', '.join(missing_keys)}")

        return True

    def clear_cache(self):
        """Clear configuration cache."""
        self._config_cache.clear()
        logger.info("Configuration cache cleared")

    @classmethod
    def reset_singleton(cls):
        """
        Reset singleton instance.

        Warning: This should only be used in testing scenarios.
        """
        logger.warning("Resetting ConfigurationManager singleton")
        cls._instance = None
        cls._loaded = False

    def __repr__(self) -> str:
        """String representation"""
        return f"ConfigurationManager(environment='{self.get_environment()}', cached_keys={len(self._config_cache)})"
