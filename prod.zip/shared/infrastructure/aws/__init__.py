"""
Athena AWS Infrastructure

Centralized AWS client management, session handling, and credential management.
"""

from .client_factory import AWSClientFactory
from .session_manager import AWSSessionManager
from .exceptions import (
    AWSError,
    AWSCredentialsError,
    AWSConnectionError,
    AWSResourceNotFoundError,
    AWSAccessDeniedError,
)

__all__ = [
    'AWSClientFactory',
    'AWSSessionManager',
    'AWSError',
    'AWSCredentialsError',
    'AWSConnectionError',
    'AWSResourceNotFoundError',
    'AWSAccessDeniedError',
]
