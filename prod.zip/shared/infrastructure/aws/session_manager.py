"""
AWS Session Manager

Centralized AWS session and credential management using singleton pattern.
Provides secure credential handling and client caching.
"""

import os
import logging
from typing import Optional, Dict, Any
import boto3
from botocore.exceptions import ClientError, NoCredentialsError, PartialCredentialsError

from .exceptions import AWSCredentialsError, AWSConnectionError

logger = logging.getLogger(__name__)


class AWSSessionManager:
    """
    Manages AWS sessions and credentials with singleton pattern.

    Features:
    - Singleton pattern for session reuse across application
    - Credential validation
    - Region configuration
    - Client caching for performance
    - Support for AWS profiles and IAM roles
    """

    _instance: Optional['AWSSessionManager'] = None
    _session: Optional[boto3.Session] = None
    _clients: Dict[str, Any] = {}

    def __new__(cls):
        """Singleton pattern - only one instance exists."""
        if cls._instance is None:
            cls._instance = super().__new__(cls)
        return cls._instance

    def __init__(self):
        """Initialize the session manager (only once due to singleton)."""
        if not hasattr(self, '_initialized'):
            self._region = os.getenv('AWS_REGION', 'us-east-2')
            # Treat empty string as None for profile
            profile = os.getenv('AWS_PROFILE', None)
            self._profile = profile if profile else None
            self._initialized = True
            logger.info(f"AWSSessionManager initialized for region: {self._region}")

    def get_session(self) -> boto3.Session:
        """
        Get or create AWS session.

        Returns:
            boto3.Session instance

        Raises:
            AWSCredentialsError: If credentials are not configured
        """
        if self._session is None:
            try:
                # Create session with profile if specified
                if self._profile:
                    self._session = boto3.Session(
                        profile_name=self._profile,
                        region_name=self._region
                    )
                    logger.info(f"AWS session created with profile: {self._profile}")
                else:
                    self._session = boto3.Session(region_name=self._region)
                    logger.info(f"AWS session created with default credentials")

                # Validate credentials by getting caller identity
                sts = self._session.client('sts')
                identity = sts.get_caller_identity()
                logger.info(f"AWS session validated - Account: {identity.get('Account')}, "
                          f"ARN: {identity.get('Arn')}")

            except (NoCredentialsError, PartialCredentialsError) as e:
                logger.error(f"AWS credentials error: {e}")
                raise AWSCredentialsError(f"AWS credentials not found: {str(e)}") from e
            except ClientError as e:
                logger.error(f"AWS client error during session creation: {e}")
                raise AWSCredentialsError(f"AWS credentials invalid: {str(e)}") from e
            except Exception as e:
                logger.error(f"Unexpected error creating AWS session: {e}")
                raise AWSConnectionError(f"Failed to create AWS session: {str(e)}") from e

        return self._session

    def get_client(self, service_name: str, region: Optional[str] = None) -> Any:
        """
        Get or create AWS client for a specific service.

        Args:
            service_name: AWS service name (e.g., 'wafv2', 'network-firewall', 'ec2')
            region: Optional region override

        Returns:
            Boto3 client for the service

        Raises:
            AWSCredentialsError: If credentials are not configured
            AWSConnectionError: If client creation fails
        """
        # Use provided region or default
        client_region = region or self._region
        cache_key = f"{service_name}:{client_region}"

        # Return cached client if exists
        if cache_key in self._clients:
            logger.debug(f"Returning cached AWS client for {cache_key}")
            return self._clients[cache_key]

        try:
            session = self.get_session()
            client = session.client(service_name, region_name=client_region)
            self._clients[cache_key] = client
            logger.info(f"Created AWS client for {service_name} in {client_region}")
            return client

        except (NoCredentialsError, PartialCredentialsError) as e:
            logger.error(f"Credentials error creating {service_name} client: {e}")
            raise AWSCredentialsError(f"Cannot create {service_name} client: {str(e)}") from e
        except ClientError as e:
            logger.error(f"Client error creating {service_name} client: {e}")
            raise AWSConnectionError(f"Failed to create {service_name} client: {str(e)}") from e
        except Exception as e:
            logger.error(f"Unexpected error creating {service_name} client: {e}")
            raise AWSConnectionError(f"Unexpected error with {service_name}: {str(e)}") from e

    def validate_credentials(self) -> Dict[str, Any]:
        """
        Validate AWS credentials and get account information.

        Returns:
            Dictionary with account information:
            {
                'valid': bool,
                'account_id': str,
                'arn': str,
                'user_id': str,
                'region': str
            }

        Raises:
            AWSCredentialsError: If credentials are invalid
        """
        try:
            session = self.get_session()
            sts = session.client('sts')
            identity = sts.get_caller_identity()

            account_info = {
                'valid': True,
                'account_id': identity.get('Account'),
                'arn': identity.get('Arn'),
                'user_id': identity.get('UserId'),
                'region': self._region
            }

            logger.info(f"Credentials validated successfully for account: {account_info['account_id']}")
            return account_info

        except Exception as e:
            logger.error(f"Credential validation failed: {e}")
            raise AWSCredentialsError(f"Credential validation failed: {str(e)}") from e

    def get_region(self) -> str:
        """
        Get current AWS region.

        Returns:
            AWS region code (e.g., 'us-east-2')
        """
        return self._region

    def set_region(self, region: str):
        """
        Set AWS region (clears cached session and clients).

        Args:
            region: AWS region code (e.g., 'us-east-1')
        """
        if region != self._region:
            logger.info(f"Changing AWS region from {self._region} to {region}")
            self._region = region
            self._session = None
            self._clients = {}

    def get_profile(self) -> Optional[str]:
        """
        Get current AWS profile name.

        Returns:
            AWS profile name or None if using default credentials
        """
        return self._profile

    def set_profile(self, profile: Optional[str]):
        """
        Set AWS profile (clears cached session and clients).

        Args:
            profile: AWS profile name or None for default credentials
        """
        if profile != self._profile:
            logger.info(f"Changing AWS profile from {self._profile} to {profile}")
            self._profile = profile
            self._session = None
            self._clients = {}

    def clear_cache(self):
        """
        Clear cached session and clients.

        Useful for:
        - Testing
        - Credential rotation
        - Forcing credential refresh
        """
        logger.info("Clearing AWS session and client cache")
        self._session = None
        self._clients = {}

    def get_cached_clients(self) -> Dict[str, Any]:
        """
        Get dictionary of currently cached clients.

        Returns:
            Dictionary of cached clients with keys in format "service:region"
        """
        return self._clients.copy()

    @classmethod
    def reset_singleton(cls):
        """
        Reset singleton instance.

        Warning: This should only be used in testing scenarios.
        """
        logger.warning("Resetting AWSSessionManager singleton")
        cls._instance = None
        cls._session = None
        cls._clients = {}

    def __repr__(self) -> str:
        """String representation"""
        return (f"AWSSessionManager(region='{self._region}', profile='{self._profile}', "
                f"cached_clients={len(self._clients)})")
