"""
AWS Client Factory

Centralized factory for creating and managing AWS service clients.
Provides consistent interface for accessing AWS services across the application.
"""

import logging
from typing import Optional, Any, Dict
from enum import Enum

from .session_manager import AWSSessionManager
from .exceptions import AWSError, AWSResourceNotFoundError

logger = logging.getLogger(__name__)


class AWSService(Enum):
    """Enumeration of supported AWS services"""
    WAF = "wafv2"
    NETWORK_FIREWALL = "network-firewall"
    EC2 = "ec2"
    SECRETS_MANAGER = "secretsmanager"
    S3 = "s3"
    STS = "sts"
    CLOUDWATCH = "cloudwatch"
    LOGS = "logs"
    SNS = "sns"
    SQS = "sqs"
    LAMBDA = "lambda"
    IAM = "iam"


class AWSClientFactory:
    """
    Factory for creating and managing AWS service clients.

    Features:
    - Centralized client creation
    - Client caching and reuse
    - Consistent error handling
    - Support for multiple regions
    - Integration with AWSSessionManager
    """

    def __init__(self, session_manager: Optional[AWSSessionManager] = None):
        """
        Initialize AWS client factory.

        Args:
            session_manager: Optional AWSSessionManager instance (creates default if not provided)
        """
        self.session_manager = session_manager or AWSSessionManager()
        self._clients: Dict[str, Any] = {}
        logger.info("AWSClientFactory initialized")

    def get_client(self, service: AWSService, region: Optional[str] = None) -> Any:
        """
        Get AWS client for specified service.

        Args:
            service: AWSService enum value
            region: Optional region override

        Returns:
            Boto3 client for the service

        Raises:
            AWSError: If client creation fails
        """
        return self.session_manager.get_client(service.value, region=region)

    def get_waf_client(self, region: Optional[str] = None) -> Any:
        """
        Get WAFv2 client.

        Args:
            region: Optional region override

        Returns:
            WAFv2 boto3 client
        """
        return self.get_client(AWSService.WAF, region=region)

    def get_network_firewall_client(self, region: Optional[str] = None) -> Any:
        """
        Get Network Firewall client.

        Args:
            region: Optional region override

        Returns:
            Network Firewall boto3 client
        """
        return self.get_client(AWSService.NETWORK_FIREWALL, region=region)

    def get_ec2_client(self, region: Optional[str] = None) -> Any:
        """
        Get EC2 client.

        Args:
            region: Optional region override

        Returns:
            EC2 boto3 client
        """
        return self.get_client(AWSService.EC2, region=region)

    def get_secrets_manager_client(self, region: Optional[str] = None) -> Any:
        """
        Get Secrets Manager client.

        Args:
            region: Optional region override

        Returns:
            Secrets Manager boto3 client
        """
        return self.get_client(AWSService.SECRETS_MANAGER, region=region)

    def get_s3_client(self, region: Optional[str] = None) -> Any:
        """
        Get S3 client.

        Args:
            region: Optional region override

        Returns:
            S3 boto3 client
        """
        return self.get_client(AWSService.S3, region=region)

    def get_cloudwatch_client(self, region: Optional[str] = None) -> Any:
        """
        Get CloudWatch client.

        Args:
            region: Optional region override

        Returns:
            CloudWatch boto3 client
        """
        return self.get_client(AWSService.CLOUDWATCH, region=region)

    def get_logs_client(self, region: Optional[str] = None) -> Any:
        """
        Get CloudWatch Logs client.

        Args:
            region: Optional region override

        Returns:
            CloudWatch Logs boto3 client
        """
        return self.get_client(AWSService.LOGS, region=region)

    def get_sns_client(self, region: Optional[str] = None) -> Any:
        """
        Get SNS client.

        Args:
            region: Optional region override

        Returns:
            SNS boto3 client
        """
        return self.get_client(AWSService.SNS, region=region)

    def get_sqs_client(self, region: Optional[str] = None) -> Any:
        """
        Get SQS client.

        Args:
            region: Optional region override

        Returns:
            SQS boto3 client
        """
        return self.get_client(AWSService.SQS, region=region)

    def get_lambda_client(self, region: Optional[str] = None) -> Any:
        """
        Get Lambda client.

        Args:
            region: Optional region override

        Returns:
            Lambda boto3 client
        """
        return self.get_client(AWSService.LAMBDA, region=region)

    def get_iam_client(self, region: Optional[str] = None) -> Any:
        """
        Get IAM client.

        Args:
            region: Optional region override

        Returns:
            IAM boto3 client
        """
        return self.get_client(AWSService.IAM, region=region)

    def validate_credentials(self) -> Dict[str, Any]:
        """
        Validate AWS credentials.

        Returns:
            Dictionary with credential information

        Raises:
            AWSCredentialsError: If credentials are invalid
        """
        return self.session_manager.validate_credentials()

    def get_region(self) -> str:
        """
        Get current AWS region.

        Returns:
            AWS region code
        """
        return self.session_manager.get_region()

    def set_region(self, region: str):
        """
        Set AWS region.

        Args:
            region: AWS region code
        """
        self.session_manager.set_region(region)

    def clear_cache(self):
        """Clear all cached clients and sessions"""
        self.session_manager.clear_cache()
        logger.info("AWS client cache cleared")

    def health_check(self) -> Dict[str, Any]:
        """
        Perform health check on AWS connectivity.

        Returns:
            Dictionary with health check results
        """
        try:
            creds = self.validate_credentials()
            return {
                'healthy': True,
                'region': self.get_region(),
                'account_id': creds.get('account_id'),
                'message': 'AWS connectivity healthy'
            }
        except Exception as e:
            logger.error(f"AWS health check failed: {e}")
            return {
                'healthy': False,
                'region': self.get_region(),
                'error': str(e),
                'message': 'AWS connectivity unhealthy'
            }

    def __repr__(self) -> str:
        """String representation"""
        return f"AWSClientFactory(region='{self.get_region()}')"
