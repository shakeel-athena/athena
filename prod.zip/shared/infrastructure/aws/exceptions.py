"""
AWS Exception Classes

Custom exceptions for AWS operations.
"""


class AWSError(Exception):
    """Base exception for AWS errors"""
    pass


class AWSCredentialsError(AWSError):
    """Exception raised when AWS credentials are invalid or missing"""
    pass


class AWSConnectionError(AWSError):
    """Exception raised when connection to AWS service fails"""
    pass


class AWSResourceNotFoundError(AWSError):
    """Exception raised when an AWS resource is not found"""

    def __init__(self, resource_type: str, resource_name: str):
        self.resource_type = resource_type
        self.resource_name = resource_name
        super().__init__(f"{resource_type} '{resource_name}' not found in AWS")


class AWSAccessDeniedError(AWSError):
    """Exception raised when AWS access is denied due to insufficient permissions"""
    pass


class AWSRegionNotAvailableError(AWSError):
    """Exception raised when AWS service is not available in the specified region"""

    def __init__(self, service_name: str, region: str):
        self.service_name = service_name
        self.region = region
        super().__init__(f"{service_name} not available in region {region}")
