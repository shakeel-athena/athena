"""Audit logging for security events"""

import logging
from datetime import datetime
from typing import Dict, Any, Optional


class AuditLogger:
    def __init__(self, db_manager):
        self.db_manager = db_manager
        self.logger = logging.getLogger(__name__)

    async def log_action(self, user_id: str, action_type: str, resource: str, details: Dict[str, Any] = None):
        try:
            with self.db_manager.connection_scope() as conn:
                conn.execute(
                    """INSERT INTO audit_log (user_id, action_type, resource, details, timestamp)
                       VALUES (%s, %s, %s, %s, %s)""",
                    (user_id, action_type, resource, str(details or {}), datetime.utcnow())
                )
            self.logger.info(f"Audit: {user_id} performed {action_type} on {resource}")
        except Exception as e:
            self.logger.error(f"Failed to log audit entry: {e}")

    async def log_security_event(self, event_type: str, source_ip: str, details: Dict[str, Any] = None):
        try:
            with self.db_manager.connection_scope() as conn:
                conn.execute(
                    """INSERT INTO security_events (event_type, source_ip, details, timestamp)
                       VALUES (%s, %s, %s, %s)""",
                    (event_type, source_ip, str(details or {}), datetime.utcnow())
                )
        except Exception as e:
            self.logger.error(f"Failed to log security event: {e}")
