"""Structured logging with correlation IDs"""

import logging
import json
from datetime import datetime
from typing import Dict, Any, Optional
import uuid


class StructuredLogger:
    def __init__(self, name: str):
        self.logger = logging.getLogger(name)
        self.correlation_id: Optional[str] = None

    def set_correlation_id(self, correlation_id: str):
        self.correlation_id = correlation_id

    def _format_log(self, level: str, message: str, extra: Dict[str, Any] = None) -> Dict[str, Any]:
        log_data = {
            'timestamp': datetime.utcnow().isoformat(),
            'level': level,
            'message': message,
            'correlation_id': self.correlation_id or str(uuid.uuid4())
        }
        if extra:
            log_data.update(extra)
        return log_data

    def info(self, message: str, **kwargs):
        log_data = self._format_log('INFO', message, kwargs)
        self.logger.info(json.dumps(log_data))

    def warning(self, message: str, **kwargs):
        log_data = self._format_log('WARNING', message, kwargs)
        self.logger.warning(json.dumps(log_data))

    def error(self, message: str, **kwargs):
        log_data = self._format_log('ERROR', message, kwargs)
        self.logger.error(json.dumps(log_data))

    def debug(self, message: str, **kwargs):
        log_data = self._format_log('DEBUG', message, kwargs)
        self.logger.debug(json.dumps(log_data))
