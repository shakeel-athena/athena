"""Threat Intelligence Provider Interface"""

from abc import ABC, abstractmethod
from typing import List, Dict, Any, Optional
from dataclasses import dataclass, field
from datetime import datetime


@dataclass
class ThreatData:
    id: str
    type: str
    name: str
    description: str
    source: str
    confidence: float
    severity: str
    tags: List[str] = field(default_factory=list)
    metadata: Dict[str, Any] = field(default_factory=dict)
    created_at: datetime = field(default_factory=datetime.utcnow)
    updated_at: datetime = field(default_factory=datetime.utcnow)
    references: List[str] = field(default_factory=list)


class ThreatIntelProvider(ABC):

    @abstractmethod
    async def fetch_data(self, filters: Dict[str, Any] = None) -> List[Dict]:
        pass

    @abstractmethod
    async def normalize_data(self, raw_data: List[Dict]) -> List[ThreatData]:
        pass

    @abstractmethod
    def get_supported_types(self) -> List[str]:
        pass

    @abstractmethod
    async def validate_credentials(self) -> bool:
        pass

    def get_provider_name(self) -> str:
        return self.__class__.__name__
