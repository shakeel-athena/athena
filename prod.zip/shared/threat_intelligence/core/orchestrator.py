"""Threat Intelligence Orchestrator"""

import logging
from typing import List, Dict, Any
from .provider_interface import ThreatIntelProvider, ThreatData

logger = logging.getLogger(__name__)


class ThreatIntelOrchestrator:

    def __init__(self, providers: List[ThreatIntelProvider], db_manager=None):
        self.providers = providers
        self.db_manager = db_manager

    async def collect_all_intelligence(self, filters: Dict[str, Any] = None) -> List[ThreatData]:
        all_data = []

        for provider in self.providers:
            try:
                logger.info(f"Fetching data from {provider.get_provider_name()}")
                raw_data = await provider.fetch_data(filters)
                normalized_data = await provider.normalize_data(raw_data)
                all_data.extend(normalized_data)
                logger.info(f"Collected {len(normalized_data)} items from {provider.get_provider_name()}")
            except Exception as e:
                logger.error(f"Failed to collect from {provider.get_provider_name()}: {e}")

        return all_data

    async def get_provider_status(self) -> Dict[str, Dict[str, Any]]:
        status = {}
        for provider in self.providers:
            try:
                is_valid = await provider.validate_credentials()
                status[provider.get_provider_name()] = {
                    'status': 'healthy' if is_valid else 'unhealthy',
                    'supported_types': provider.get_supported_types()
                }
            except Exception as e:
                status[provider.get_provider_name()] = {
                    'status': 'error',
                    'error': str(e)
                }
        return status

    async def store_intelligence(self, threat_data_list: List[ThreatData]):
        if not self.db_manager:
            logger.warning("No database manager configured")
            return

        try:
            with self.db_manager.connection_scope() as conn:
                for data in threat_data_list:
                    conn.execute(
                        """INSERT INTO threat_intelligence
                           (id, type, name, description, source, confidence, severity, tags, metadata, created_at)
                           VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
                           ON CONFLICT (id) DO UPDATE SET updated_at = NOW()""",
                        (data.id, data.type, data.name, data.description, data.source,
                         data.confidence, data.severity, str(data.tags), str(data.metadata), data.created_at)
                    )
            logger.info(f"Stored {len(threat_data_list)} threat intelligence items")
        except Exception as e:
            logger.error(f"Failed to store intelligence: {e}")
