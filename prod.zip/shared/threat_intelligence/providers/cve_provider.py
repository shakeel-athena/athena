"""CVE Provider"""

import logging
import requests
from typing import List, Dict, Any
from ..core.provider_interface import ThreatIntelProvider, ThreatData

logger = logging.getLogger(__name__)


class CVEProvider(ThreatIntelProvider):

    def __init__(self, config: Dict[str, Any] = None):
        self.config = config or {}
        self.base_url = self.config.get('base_url', 'https://services.nvd.nist.gov/rest/json/cves/2.0')

    async def fetch_data(self, filters: Dict[str, Any] = None) -> List[Dict]:
        try:
            params = {}
            if filters:
                if 'keywords' in filters:
                    params['keywordSearch'] = filters['keywords']
                if 'results_per_page' in filters:
                    params['resultsPerPage'] = filters['results_per_page']

            response = requests.get(self.base_url, params=params, timeout=30)
            response.raise_for_status()
            data = response.json()
            return data.get('vulnerabilities', [])
        except Exception as e:
            logger.error(f"Failed to fetch CVE data: {e}")
            return []

    async def normalize_data(self, raw_data: List[Dict]) -> List[ThreatData]:
        normalized = []
        for item in raw_data:
            cve = item.get('cve', {})
            cve_id = cve.get('id', 'unknown')

            descriptions = cve.get('descriptions', [])
            description = descriptions[0].get('value', '') if descriptions else ''

            metrics = cve.get('metrics', {})
            cvss_v3 = metrics.get('cvssMetricV31', [{}])[0] if 'cvssMetricV31' in metrics else {}
            base_score = cvss_v3.get('cvssData', {}).get('baseScore', 0)

            threat_data = ThreatData(
                id=cve_id,
                type='vulnerability',
                name=cve_id,
                description=description,
                source='NVD_CVE',
                confidence=1.0,
                severity=self._calculate_severity(base_score),
                tags=[],
                metadata={'cvss_score': base_score, 'raw': cve}
            )
            normalized.append(threat_data)

        return normalized

    def get_supported_types(self) -> List[str]:
        return ['vulnerability', 'cve']

    async def validate_credentials(self) -> bool:
        try:
            response = requests.get(self.base_url, timeout=10)
            return response.status_code == 200
        except:
            return False

    def _calculate_severity(self, cvss_score: float) -> str:
        if cvss_score >= 9.0:
            return 'CRITICAL'
        elif cvss_score >= 7.0:
            return 'HIGH'
        elif cvss_score >= 4.0:
            return 'MEDIUM'
        else:
            return 'LOW'
