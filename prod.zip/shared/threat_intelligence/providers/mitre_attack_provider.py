"""MITRE ATT&CK Provider"""

import logging
import requests
from typing import List, Dict, Any
from ..core.provider_interface import ThreatIntelProvider, ThreatData

logger = logging.getLogger(__name__)


class MITREAttackProvider(ThreatIntelProvider):

    def __init__(self, config: Dict[str, Any] = None):
        self.config = config or {}
        self.base_url = self.config.get('base_url', 'https://raw.githubusercontent.com/mitre/cti/master')

    async def fetch_data(self, filters: Dict[str, Any] = None) -> List[Dict]:
        try:
            url = f"{self.base_url}/enterprise-attack/enterprise-attack.json"
            response = requests.get(url, timeout=30)
            response.raise_for_status()
            data = response.json()
            return data.get('objects', [])
        except Exception as e:
            logger.error(f"Failed to fetch MITRE ATT&CK data: {e}")
            return []

    async def normalize_data(self, raw_data: List[Dict]) -> List[ThreatData]:
        normalized = []
        for item in raw_data:
            if item.get('type') not in ['attack-pattern', 'malware', 'tool']:
                continue

            threat_data = ThreatData(
                id=item.get('id', ''),
                type=item.get('type', 'unknown'),
                name=item.get('name', 'Unknown'),
                description=item.get('description', ''),
                source='MITRE_ATT&CK',
                confidence=1.0,
                severity=self._calculate_severity(item),
                tags=self._extract_tags(item),
                metadata=item,
                references=item.get('external_references', [])
            )
            normalized.append(threat_data)

        return normalized

    def get_supported_types(self) -> List[str]:
        return ['attack-pattern', 'malware', 'tool', 'campaign', 'intrusion-set']

    async def validate_credentials(self) -> bool:
        try:
            response = requests.get(f"{self.base_url}/enterprise-attack/enterprise-attack.json", timeout=10)
            return response.status_code == 200
        except:
            return False

    def _calculate_severity(self, item: Dict[str, Any]) -> str:
        if item.get('x_mitre_impact'):
            return 'HIGH'
        return 'MEDIUM'

    def _extract_tags(self, item: Dict[str, Any]) -> List[str]:
        tags = []
        if 'x_mitre_platforms' in item:
            tags.extend(item['x_mitre_platforms'])
        if 'kill_chain_phases' in item:
            for phase in item['kill_chain_phases']:
                tags.append(phase.get('phase_name', ''))
        return tags
