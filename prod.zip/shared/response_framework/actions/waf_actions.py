"""WAF Response Actions"""

import logging
from typing import Dict, Any
from datetime import datetime
from ..core.action_interface import ResponseAction, ActionResult, ResponseResult

logger = logging.getLogger(__name__)


class BlockIPWAFAction(ResponseAction):

    def __init__(self, waf_service):
        self.waf_service = waf_service

    async def execute(self, context: Dict[str, Any]) -> ResponseResult:
        start_time = datetime.utcnow()

        try:
            ip_address = context.get('ip_address')

            if not await self.validate_prerequisites(context):
                return ResponseResult(
                    action_id=self.get_action_type(),
                    result=ActionResult.FAILURE,
                    message="Prerequisites not met",
                    details={},
                    execution_time_ms=0,
                    timestamp=datetime.utcnow()
                )

            result = await self.waf_service.block_ip(ip_address)

            execution_time = (datetime.utcnow() - start_time).total_seconds() * 1000

            return ResponseResult(
                action_id=self.get_action_type(),
                result=ActionResult.SUCCESS if result else ActionResult.FAILURE,
                message=f"WAF blocked IP {ip_address}" if result else "Failed to block",
                details={'ip_address': ip_address},
                execution_time_ms=int(execution_time),
                timestamp=datetime.utcnow()
            )

        except Exception as e:
            execution_time = (datetime.utcnow() - start_time).total_seconds() * 1000
            return ResponseResult(
                action_id=self.get_action_type(),
                result=ActionResult.FAILURE,
                message=f"Error: {str(e)}",
                details={'error': str(e)},
                execution_time_ms=int(execution_time),
                timestamp=datetime.utcnow()
            )

    async def validate_prerequisites(self, context: Dict[str, Any]) -> bool:
        return bool(context.get('ip_address'))

    async def rollback(self, context: Dict[str, Any]) -> ResponseResult:
        ip_address = context.get('ip_address')
        result = await self.waf_service.unblock_ip(ip_address)

        return ResponseResult(
            action_id=f"{self.get_action_type()}_rollback",
            result=ActionResult.SUCCESS if result else ActionResult.FAILURE,
            message=f"WAF unblocked IP {ip_address}" if result else "Failed to unblock",
            details={'ip_address': ip_address},
            execution_time_ms=0,
            timestamp=datetime.utcnow()
        )

    def get_action_type(self) -> str:
        return "waf_block_ip"


class AddSignatureAction(ResponseAction):

    def __init__(self, waf_service):
        self.waf_service = waf_service

    async def execute(self, context: Dict[str, Any]) -> ResponseResult:
        start_time = datetime.utcnow()

        try:
            signature = context.get('signature')

            if not await self.validate_prerequisites(context):
                return ResponseResult(
                    action_id=self.get_action_type(),
                    result=ActionResult.FAILURE,
                    message="Prerequisites not met",
                    details={},
                    execution_time_ms=0,
                    timestamp=datetime.utcnow()
                )

            result = await self.waf_service.add_signature(signature)

            execution_time = (datetime.utcnow() - start_time).total_seconds() * 1000

            return ResponseResult(
                action_id=self.get_action_type(),
                result=ActionResult.SUCCESS if result else ActionResult.FAILURE,
                message=f"Signature added" if result else "Failed to add signature",
                details={'signature': signature},
                execution_time_ms=int(execution_time),
                timestamp=datetime.utcnow()
            )

        except Exception as e:
            execution_time = (datetime.utcnow() - start_time).total_seconds() * 1000
            return ResponseResult(
                action_id=self.get_action_type(),
                result=ActionResult.FAILURE,
                message=f"Error: {str(e)}",
                details={'error': str(e)},
                execution_time_ms=int(execution_time),
                timestamp=datetime.utcnow()
            )

    async def validate_prerequisites(self, context: Dict[str, Any]) -> bool:
        return bool(context.get('signature'))

    async def rollback(self, context: Dict[str, Any]) -> ResponseResult:
        signature = context.get('signature')
        result = await self.waf_service.remove_signature(signature)

        return ResponseResult(
            action_id=f"{self.get_action_type()}_rollback",
            result=ActionResult.SUCCESS if result else ActionResult.FAILURE,
            message=f"Signature removed" if result else "Failed to remove",
            details={'signature': signature},
            execution_time_ms=0,
            timestamp=datetime.utcnow()
        )

    def get_action_type(self) -> str:
        return "waf_add_signature"
