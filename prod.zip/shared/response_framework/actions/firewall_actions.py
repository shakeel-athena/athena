"""Firewall Response Actions"""

import logging
from typing import Dict, Any
from datetime import datetime
import ipaddress
from ..core.action_interface import ResponseAction, ActionResult, ResponseResult

logger = logging.getLogger(__name__)


class BlockIPAction(ResponseAction):

    def __init__(self, firewall_service):
        self.firewall_service = firewall_service

    async def execute(self, context: Dict[str, Any]) -> ResponseResult:
        start_time = datetime.utcnow()

        try:
            ip_address = context.get('ip_address')
            duration = context.get('duration', 3600)

            if not await self.validate_prerequisites(context):
                return ResponseResult(
                    action_id=self.get_action_type(),
                    result=ActionResult.FAILURE,
                    message="Prerequisites not met",
                    details={},
                    execution_time_ms=0,
                    timestamp=datetime.utcnow()
                )

            result = await self.firewall_service.block_ip(ip_address, duration)

            execution_time = (datetime.utcnow() - start_time).total_seconds() * 1000

            return ResponseResult(
                action_id=self.get_action_type(),
                result=ActionResult.SUCCESS if result else ActionResult.FAILURE,
                message=f"IP {ip_address} blocked" if result else "Failed to block IP",
                details={'ip_address': ip_address, 'duration': duration},
                execution_time_ms=int(execution_time),
                timestamp=datetime.utcnow()
            )

        except Exception as e:
            execution_time = (datetime.utcnow() - start_time).total_seconds() * 1000
            return ResponseResult(
                action_id=self.get_action_type(),
                result=ActionResult.FAILURE,
                message=f"Error: {str(e)}",
                details={'error': str(e)},
                execution_time_ms=int(execution_time),
                timestamp=datetime.utcnow()
            )

    async def validate_prerequisites(self, context: Dict[str, Any]) -> bool:
        ip_address = context.get('ip_address')
        if not ip_address:
            return False

        try:
            ipaddress.ip_address(ip_address)
        except ValueError:
            return False

        return True

    async def rollback(self, context: Dict[str, Any]) -> ResponseResult:
        ip_address = context.get('ip_address')
        result = await self.firewall_service.unblock_ip(ip_address)

        return ResponseResult(
            action_id=f"{self.get_action_type()}_rollback",
            result=ActionResult.SUCCESS if result else ActionResult.FAILURE,
            message=f"IP {ip_address} unblocked" if result else "Failed to unblock",
            details={'ip_address': ip_address},
            execution_time_ms=0,
            timestamp=datetime.utcnow()
        )

    def get_action_type(self) -> str:
        return "firewall_block_ip"


class UnblockIPAction(ResponseAction):

    def __init__(self, firewall_service):
        self.firewall_service = firewall_service

    async def execute(self, context: Dict[str, Any]) -> ResponseResult:
        start_time = datetime.utcnow()

        try:
            ip_address = context.get('ip_address')

            if not await self.validate_prerequisites(context):
                return ResponseResult(
                    action_id=self.get_action_type(),
                    result=ActionResult.FAILURE,
                    message="Prerequisites not met",
                    details={},
                    execution_time_ms=0,
                    timestamp=datetime.utcnow()
                )

            result = await self.firewall_service.unblock_ip(ip_address)

            execution_time = (datetime.utcnow() - start_time).total_seconds() * 1000

            return ResponseResult(
                action_id=self.get_action_type(),
                result=ActionResult.SUCCESS if result else ActionResult.FAILURE,
                message=f"IP {ip_address} unblocked" if result else "Failed to unblock IP",
                details={'ip_address': ip_address},
                execution_time_ms=int(execution_time),
                timestamp=datetime.utcnow()
            )

        except Exception as e:
            execution_time = (datetime.utcnow() - start_time).total_seconds() * 1000
            return ResponseResult(
                action_id=self.get_action_type(),
                result=ActionResult.FAILURE,
                message=f"Error: {str(e)}",
                details={'error': str(e)},
                execution_time_ms=int(execution_time),
                timestamp=datetime.utcnow()
            )

    async def validate_prerequisites(self, context: Dict[str, Any]) -> bool:
        ip_address = context.get('ip_address')
        if not ip_address:
            return False

        try:
            ipaddress.ip_address(ip_address)
        except ValueError:
            return False

        return True

    async def rollback(self, context: Dict[str, Any]) -> ResponseResult:
        return ResponseResult(
            action_id=f"{self.get_action_type()}_rollback",
            result=ActionResult.SUCCESS,
            message="No rollback needed for unblock",
            details={},
            execution_time_ms=0,
            timestamp=datetime.utcnow()
        )

    def get_action_type(self) -> str:
        return "firewall_unblock_ip"
