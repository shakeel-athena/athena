"""Action Registry"""

import logging
from typing import Dict, Optional
from .action_interface import ResponseAction

logger = logging.getLogger(__name__)


class ActionRegistry:

    def __init__(self):
        self._actions: Dict[str, ResponseAction] = {}

    def register(self, action: ResponseAction):
        action_type = action.get_action_type()
        self._actions[action_type] = action
        logger.info(f"Registered action: {action_type}")

    def get_action(self, action_type: str) -> Optional[ResponseAction]:
        return self._actions.get(action_type)

    def get_all_actions(self) -> Dict[str, ResponseAction]:
        return self._actions.copy()

    def unregister(self, action_type: str):
        if action_type in self._actions:
            del self._actions[action_type]
            logger.info(f"Unregistered action: {action_type}")
