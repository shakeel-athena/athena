"""Response Action Interface"""

from abc import ABC, abstractmethod
from typing import Dict, Any
from dataclasses import dataclass
from enum import Enum
from datetime import datetime


class ActionResult(Enum):
    SUCCESS = "success"
    FAILURE = "failure"
    PARTIAL = "partial"
    TIMEOUT = "timeout"


@dataclass
class ResponseResult:
    action_id: str
    result: ActionResult
    message: str
    details: Dict[str, Any]
    execution_time_ms: int
    timestamp: datetime


class ResponseAction(ABC):

    @abstractmethod
    async def execute(self, context: Dict[str, Any]) -> ResponseResult:
        pass

    @abstractmethod
    async def validate_prerequisites(self, context: Dict[str, Any]) -> bool:
        pass

    @abstractmethod
    async def rollback(self, context: Dict[str, Any]) -> ResponseResult:
        pass

    @abstractmethod
    def get_action_type(self) -> str:
        pass

    def get_priority(self) -> int:
        return 0
