"""Response Orchestrator"""

import logging
from typing import List, Dict, Any
from datetime import datetime
from .action_interface import ResponseResult, ActionResult
from .action_registry import ActionRegistry

logger = logging.getLogger(__name__)


class ResponseOrchestrator:

    def __init__(self, action_registry: ActionRegistry):
        self.action_registry = action_registry

    async def execute_response(self, trigger_event: Dict[str, Any], actions_config: List[Dict[str, Any]]) -> List[ResponseResult]:
        results = []

        for action_config in actions_config:
            action_type = action_config.get('type')
            action = self.action_registry.get_action(action_type)

            if not action:
                logger.error(f"Action not found: {action_type}")
                results.append(ResponseResult(
                    action_id=action_type,
                    result=ActionResult.FAILURE,
                    message=f"Action {action_type} not registered",
                    details={},
                    execution_time_ms=0,
                    timestamp=datetime.utcnow()
                ))
                continue

            try:
                context = {
                    **action_config.get('parameters', {}),
                    'trigger_event': trigger_event
                }

                result = await action.execute(context)
                results.append(result)

                if result.result == ActionResult.FAILURE and action_config.get('rollback_on_failure'):
                    logger.warning(f"Rolling back action: {action_type}")
                    rollback_result = await action.rollback(context)
                    results.append(rollback_result)

            except Exception as e:
                logger.error(f"Action execution failed: {action_type} - {e}")
                results.append(ResponseResult(
                    action_id=action_type,
                    result=ActionResult.FAILURE,
                    message=f"Execution error: {str(e)}",
                    details={'error': str(e)},
                    execution_time_ms=0,
                    timestamp=datetime.utcnow()
                ))

        return results

    async def execute_policy(self, policy: Dict[str, Any], trigger_event: Dict[str, Any]) -> List[ResponseResult]:
        conditions = policy.get('conditions', [])

        if not self._evaluate_conditions(conditions, trigger_event):
            logger.debug(f"Policy conditions not met: {policy.get('name')}")
            return []

        actions = policy.get('actions', [])
        return await self.execute_response(trigger_event, actions)

    def _evaluate_conditions(self, conditions: List[Dict[str, Any]], event: Dict[str, Any]) -> bool:
        for condition in conditions:
            field = condition.get('field')
            operator = condition.get('operator')
            value = condition.get('value')

            event_value = event.get(field)

            if operator == 'equals' and event_value != value:
                return False
            elif operator == 'greater_than' and not (event_value and event_value > value):
                return False
            elif operator == 'contains' and not (event_value and value in event_value):
                return False

        return True
