"""Response Framework Core"""
