"""
Application Factory

Creates and configures the Flask application with all blueprints and middleware.
"""

import os
import sys
import logging
from datetime import datetime
from flask import Flask, jsonify, g
from flask_cors import CORS
from dotenv import load_dotenv

# Add the backend root to Python path for imports
BACKEND_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
if BACKEND_ROOT not in sys.path:
    sys.path.insert(0, BACKEND_ROOT)

# Add current directory to path for models
sys.path.insert(0, os.path.join(os.path.dirname(__file__)))
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "../../models"))

# Load environment variables early
load_dotenv(dotenv_path=os.path.join(BACKEND_ROOT, "..", ".env"))

# Import core modules
from core.database import setup_db_and_rbac, teardown_db, cleanup_database_connections
from core.aws_config import validate_aws_configuration

# Import API blueprints
from api import waf_bp, alerts_bp, firewall_bp, health_bp, nids_bp
from api.policies import policies_bp
from api.dashboard import dashboard_bp
from api.geo import geo_bp
from api.background_modules import background_modules_bp

# Import admin blueprint
from api.admin import admin_bp

# Import additional blueprints (active response, mute, threat intel)
from api.active_response import bp as active_response_bp
from api.mute import mute_bp
from api.threat_intel import threat_intel_bp

# Import middleware
from utils.rbac import sync_user_middleware
from middleware.rate_limiter import init_rate_limiter, cleanup_rate_limiter
from middleware.validation import init_validation
from middleware.cache import init_cache, CacheManager
from middleware.task_queue import init_task_queue, cleanup_task_queue
from middleware.logging import init_logging, structured_logger, log_api_request, log_security_event, log_performance

# Import Phase 3 middleware
from middleware.alert_correlation import init_alert_correlation
from middleware.mitre_visualization import init_mitre_visualization
from middleware.threat_intel_cache import init_threat_intel_cache

# Configure logging
logger = logging.getLogger(__name__)


def create_app(config_name=None):
    """Create and configure Flask application."""
    app = Flask(__name__)
    CORS(app)  # Enable CORS for frontend communication

    # Configure logging
    logging.basicConfig(level=logging.INFO)
    logger.info("Creating Flask application")

    # Load configuration from environment variables
    app.config['REDIS_HOST'] = os.getenv('REDIS_HOST', 'localhost')
    app.config['REDIS_PORT'] = int(os.getenv('REDIS_PORT', '6379'))
    app.config['REDIS_DB'] = int(os.getenv('REDIS_DB', '0'))
    app.config['SECRET_KEY'] = os.getenv('SECRET_KEY', 'dev-secret-key')

    logger.info(f"Redis configuration: {app.config['REDIS_HOST']}:{app.config['REDIS_PORT']}")

    # ============================================================================
    # Blueprint Registration
    # ============================================================================
    app.register_blueprint(waf_bp)
    app.register_blueprint(alerts_bp)
    app.register_blueprint(firewall_bp)
    app.register_blueprint(health_bp)
    app.register_blueprint(policies_bp)
    app.register_blueprint(dashboard_bp)
    app.register_blueprint(geo_bp)
    app.register_blueprint(background_modules_bp)
    app.register_blueprint(admin_bp)
    app.register_blueprint(nids_bp)
    app.register_blueprint(active_response_bp)
    app.register_blueprint(mute_bp)
    app.register_blueprint(threat_intel_bp)

    logger.info("All blueprints registered successfully")

    # ============================================================================
    # Database and RBAC Setup
    # ============================================================================
    app.before_request(setup_db_and_rbac)
    app.teardown_request(teardown_db)

    # Register RBAC middleware (user sync from JWT to database)
    @app.before_request
    def sync_user():
        """Sync user from JWT to database"""
        from flask import g
        if hasattr(g, 'rbac') and g.rbac is not None:
            sync_user_middleware(g.rbac)

    # ============================================================================
    # Security Middleware Integration
    # ============================================================================
    # Initialize security middleware
    init_rate_limiter(app)
    init_validation(app)

    # Initialize Phase 2 middleware
    init_cache(app)
    init_task_queue(app)
    init_logging(app)

    # Initialize Phase 3 middleware
    init_alert_correlation(app)
    init_mitre_visualization(app)
    init_threat_intel_cache(app)

    # ============================================================================
    # Error Handlers
    # ============================================================================
    @app.errorhandler(404)
    def not_found(error):
        """Handle 404 errors."""
        return jsonify({"error": "Endpoint not found", "success": False}), 404

    @app.errorhandler(500)
    def internal_error(error):
        """Handle 500 errors."""
        return jsonify({"error": "Internal server error", "success": False}), 500

    # ============================================================================
    # Health Check Endpoints (Legacy compatibility)
    # ============================================================================
    @app.route('/health', methods=['GET'])
    def health_check():
        """Basic health check endpoint."""
        from core.aws_config import get_aws_session
        from datetime import datetime
        
        cfg = {
            "status": "healthy",
            "aws_profile": os.getenv("AWS_PROFILE"),
            "aws_region": os.getenv("AWS_REGION", "us-east-2"),
            "aws_scope": os.getenv("AWS_SCOPE", "REGIONAL"),
            "waf_web_acl": os.getenv("WAF_WEB_ACL"),
            "firewall_rule_group": os.getenv("FIREWALL_RULE_GROUP", "allow-ingress")
        }
        return jsonify({"success": True, "data": cfg, "message": "Service is running"}), 200

    @app.route('/api/health/comprehensive', methods=['GET'])
    def comprehensive_health_check():
        """Comprehensive health check including authentication, database, and AWS services."""
        try:
            from flask import g
            from core.database import get_db_connection
            
            health_status = {
                "status": "healthy",
                "timestamp": datetime.utcnow().isoformat() + "Z",
                "checks": {}
            }
            
            # Database Health Check
            try:
                db_conn = get_db_connection()
                if db_conn:
                    cursor = db_conn.execute("SELECT 1 as test")
                    result = cursor.fetchone()
                    if result and result['test'] == 1:
                        health_status["checks"]["database"] = {
                            "status": "healthy",
                            "message": "Database connection successful"
                        }
                    else:
                        health_status["checks"]["database"] = {
                            "status": "unhealthy",
                            "message": "Database query failed"
                        }
                        health_status["status"] = "degraded"
                else:
                    health_status["checks"]["database"] = {
                        "status": "unhealthy",
                        "message": "Database connection failed"
                    }
                    health_status["status"] = "unhealthy"
            except Exception as db_error:
                health_status["checks"]["database"] = {
                    "status": "unhealthy",
                    "message": f"Database error: {str(db_error)}"
                }
                health_status["status"] = "unhealthy"
            
            # AWS Configuration Health Check
            aws_config = validate_aws_configuration()
            health_status["checks"]["aws"] = aws_config
            
            if not aws_config["valid"]:
                health_status["status"] = "degraded"
            
            # Keycloak Configuration Check
            try:
                keycloak_url = os.getenv("KEYCLOAK_URL")
                keycloak_realm = os.getenv("KEYCLOAK_REALM", "athena")
                
                if keycloak_url:
                    # Test Keycloak connectivity
                    import requests
                    keycloak_test_url = f"{keycloak_url}/realms/{keycloak_realm}/.well-known/openid_configuration"
                    response = requests.get(keycloak_test_url, timeout=5)
                    
                    if response.status_code == 200:
                        health_status["checks"]["keycloak"] = {
                            "status": "healthy",
                            "message": "Keycloak is accessible",
                            "url": keycloak_url,
                            "realm": keycloak_realm
                        }
                    else:
                        health_status["checks"]["keycloak"] = {
                            "status": "degraded",
                            "message": f"Keycloak returned status {response.status_code}",
                            "url": keycloak_url,
                            "realm": keycloak_realm
                        }
                        health_status["status"] = "degraded"
                else:
                    health_status["checks"]["keycloak"] = {
                        "status": "unhealthy",
                        "message": "Keycloak URL not configured"
                    }
                    health_status["status"] = "unhealthy"
            except Exception as keycloak_error:
                health_status["checks"]["keycloak"] = {
                    "status": "unhealthy",
                    "message": f"Keycloak connectivity error: {str(keycloak_error)}"
                }
                health_status["status"] = "degraded"
            
            # Authentication Flow Check
            try:
                if hasattr(g, 'rbac') and g.rbac is not None:
                    health_status["checks"]["authentication"] = {
                        "status": "healthy",
                        "message": "RBAC system initialized"
                    }
                else:
                    health_status["checks"]["authentication"] = {
                        "status": "degraded",
                        "message": "RBAC system not available"
                    }
                    health_status["status"] = "degraded"
            except Exception as auth_error:
                health_status["checks"]["authentication"] = {
                    "status": "unhealthy",
                    "message": f"Authentication system error: {str(auth_error)}"
                }
                health_status["status"] = "unhealthy"
            
            # Service-Specific Checks
            health_status["checks"]["services"] = {}
            
            # Firewall Service Check
            try:
                if os.getenv("FIREWALL_RULE_GROUP"):
                    health_status["checks"]["services"]["firewall"] = {
                        "status": "configured",
                        "message": "Firewall rule group configured"
                    }
                else:
                    health_status["checks"]["services"]["firewall"] = {
                        "status": "not_configured",
                        "message": "FIREWALL_RULE_GROUP not set"
                    }
            except Exception as firewall_error:
                health_status["checks"]["services"]["firewall"] = {
                    "status": "error",
                    "message": f"Firewall service error: {str(firewall_error)}"
                }
            
            # WAF Service Check
            try:
                if os.getenv("WAF_WEB_ACL"):
                    health_status["checks"]["services"]["waf"] = {
                        "status": "configured",
                        "message": "WAF Web ACL configured"
                    }
                else:
                    health_status["checks"]["services"]["waf"] = {
                        "status": "not_configured",
                        "message": "WAF_WEB_ACL not set"
                    }
            except Exception as waf_error:
                health_status["checks"]["services"]["waf"] = {
                    "status": "error",
                    "message": f"WAF service error: {str(waf_error)}"
                }
            
            # Environment Configuration Summary
            health_status["environment"] = {
                "aws_region": os.getenv("AWS_REGION", "us-east-2"),
                "aws_profile": os.getenv("AWS_PROFILE"),
                "keycloak_url": os.getenv("KEYCLOAK_URL"),
                "keycloak_realm": os.getenv("KEYCLOAK_REALM", "athena"),
                "firewall_rule_group": os.getenv("FIREWALL_RULE_GROUP"),
                "waf_web_acl": os.getenv("WAF_WEB_ACL"),
                "database_configured": bool(os.getenv("POSTGRES_HOST") or os.getenv("DB_HOST"))
            }
            
            # Determine overall status
            overall_status = health_status["status"]
            if overall_status == "healthy":
                message = "All systems operational"
            elif overall_status == "degraded":
                message = "Some systems degraded but functional"
            else:
                message = "Critical system failures detected"
            
            return jsonify({"success": True, "data": health_status, "message": message}), 200
            
        except Exception as e:
            logger.error(f"Comprehensive health check failed: {e}")
            return jsonify({"success": False, "error": f"Health check failed: {str(e)}"}), 500

    @app.route('/api/health', methods=['GET'])
    def api_health():
        return health_check()

    # ============================================================================
    # User Pages Endpoint (for frontend navigation)
    # ============================================================================
    @app.route('/api/user/pages', methods=['GET'])
    def get_user_accessible_pages():
        """
        Get all pages the current user can access.
        Used by frontend to build navigation menu and check permissions.
        """
        from middleware.auth import require_auth

        # Check if user is authenticated
        if not hasattr(g, 'rbac') or g.rbac is None:
            return jsonify({
                'success': False,
                'error': 'RBAC system not available',
                'pages': [],
                'roles': [],
                'is_admin': False
            }), 503

        try:
            # Ensure user is synced
            if not hasattr(g, 'user_id') or not g.user_id:
                # Try to sync user if not already synced
                if hasattr(g, 'token_payload') and hasattr(g, 'rbac'):
                    sync_user_middleware(g.rbac)

                # Check again after sync attempt
                if not hasattr(g, 'user_id') or not g.user_id:
                    return jsonify({
                        'success': False,
                        'error': 'User not authenticated or not synced',
                        'pages': [],
                        'roles': [],
                        'is_admin': False
                    }), 401

            # Get user's accessible pages and roles
            pages = g.rbac.get_user_pages(g.user_id)
            roles = g.rbac.get_user_roles(g.user_id)
            is_admin = g.rbac.is_admin(g.user_id)

            return jsonify({
                'success': True,
                'pages': pages,
                'roles': roles,
                'is_admin': is_admin,
                'username': g.db_user.get('username', '') if hasattr(g, 'db_user') else '',
                'email': g.db_user.get('email', '') if hasattr(g, 'db_user') else ''
            }), 200

        except Exception as e:
            logger.error(f"[RBAC] Error getting user pages: {e}", exc_info=True)
            return jsonify({
                'success': False,
                'error': 'Failed to fetch user pages',
                'message': str(e),
                'pages': [],
                'roles': [],
                'is_admin': False
            }), 500

    # ============================================================================
    # Application Cleanup
    # ============================================================================
    @app.teardown_appcontext
    def cleanup_resources(error):
        """Cleanup resources on app context teardown."""
        if error:
            logger.error(f"Application context teardown with error: {error}")

    return app


def cleanup_app():
    """Cleanup application resources on shutdown."""
    try:
        cleanup_rate_limiter()
        cleanup_task_queue()
        cleanup_database_connections()
        logger.info("Application cleanup completed")
    except Exception as e:
        logger.error(f"Error during application cleanup: {e}")
