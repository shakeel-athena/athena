"""
Athena Network Response Management - Modularized Application

This is the new modularized version of the Flask application using the application factory pattern.
"""

import os
import logging
from app_factory import create_app, cleanup_app
from response.background_modules.module_manager import module_manager

# Configure logging
logger = logging.getLogger(__name__)

# Create the Flask application using the factory
app = create_app()

if __name__ == '__main__':
    port = int(os.environ.get('PORT', 5000))
    debug = os.environ.get('DEBUG', 'False').lower() == 'true'

    print(f"Starting Enhanced Athena API Server on port {port}")
    print(f"Debug mode: {debug}")
    print("")
    print("Available endpoints:")
    print("  GET  /health                              - Health check")
    print("")
    print(" Firewall Management:")
    print("  GET  /api/firewall/ip-sets                - Get all IP sets")
    print("  GET  /api/firewall/allow-list             - Get allow list")
    print("  GET  /api/firewall/block-list             - Get block list")
    print("  POST /api/firewall/allow-list             - Add IPs to allow list")
    print("  POST /api/firewall/block-list             - Add IPs to block list")
    print("  DELETE /api/firewall/allow-list           - Remove IPs from allow list")
    print("  DELETE /api/firewall/block-list           - Remove IPs from block list")
    print("  GET  /api/firewall/debug                  - Debug resources")
    print("  POST /api/firewall/transfer-ip            - Transfer IP from one list to another")
    print("")
    print("  WAF Signature Management:")
    print("  GET  /api/waf-signatures/available        - Get available signatures")
    print("  GET  /api/waf-signatures/custom           - Get custom signatures")
    print("  GET  /api/waf-signatures/aws-managed      - Get AWS managed rules")
    print("  GET  /api/waf-signatures/status           - Get signature status")
    print("  GET  /api/waf-signatures/active           - Get active signatures")
    print("  POST /api/waf-signatures/add              - Add single signature")
    print("  POST /api/waf-signatures/remove           - Remove single signature")
    print("  POST /api/waf-signatures/toggle           - Toggle signature")
    print("  POST /api/waf-signatures/add-multiple     - Add multiple signatures")
    print("  POST /api/waf-signatures/remove-multiple  - Remove multiple signatures")
    print("  POST /api/waf-signatures/add-all          - Add all signatures")
    print("  POST /api/waf-signatures/remove-all       - Remove all signatures")
    print("")
    print("  Geo-restrictions Management:")
    print("  GET  /api/geo-restrictions/countries        - Get allowed countries")
    print("  POST /api/geo-restrictions/countries        - Add countries to allowed list")
    print("  DELETE /api/geo-restrictions/countries      - Remove countries from allowed list")
    print("  PUT  /api/geo-restrictions/countries        - Set complete countries list")
    print("  POST /api/geo-restrictions/validate        - Validate country codes")
    print("")
    print("  Background Modules Management:")
    print("  GET  /api/background-modules/status                    - Get status of all background modules")
    print("  POST /api/background-modules/<module>/toggle          - Toggle module on/off")
    print("  POST /api/background-modules/<module>/interval        - Update trigger interval")
    print("  GET  /api/background-modules/ip-lists                 - Get IP lists from modules")
    print("  POST /api/background-modules/start                    - Start all modules")
    print("  POST /api/background-modules/stop                     - Stop all modules")
    print("")
    print("  Dashboard and Policies:")
    print("  GET  /api/dashboard                          - Get dashboard data")
    print("  GET  /api/policies                           - Get policies")
    print("  PUT  /api/policies                           - Update policies")
    print("")

    # Start background modules
    try:
        module_manager.start_all()
        logger.info("Background modules started successfully")
    except Exception as e:
        logger.error(f"Failed to start background modules: {e}")

    try:
        app.run(host='0.0.0.0', port=port, debug=debug)
    finally:
        # Cleanup on shutdown
        cleanup_app()
