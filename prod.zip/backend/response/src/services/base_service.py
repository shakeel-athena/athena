"""
Base Service Module

Provides the abstract base class for all services in the Athena backend.
Implements common functionality including validation, logging, and permissions.
"""

import logging
from abc import ABC, abstractmethod
from typing import Any, Dict, List, Optional, Union
from datetime import datetime
from contextlib import asynccontextmanager

from errors.error_types import (
    AthenaError, 
    ValidationError, 
    AuthenticationError, 
    AuthorizationError,
    BusinessLogicError
)


class OperationType:
    """Enumeration of operation types for tracking and auditing."""
    CREATE = "create"
    READ = "read"
    UPDATE = "update"
    DELETE = "delete"
    LIST = "list"
    SEARCH = "search"
    VALIDATE = "validate"
    EXECUTE = "execute"


class OperationResult:
    """
    Standardized result object for service operations.
    
    Provides consistent structure for operation results across all services.
    """
    
    def __init__(self, 
                 success: bool = True,
                 data: Any = None,
                 message: str = None,
                 error_code: str = None,
                 details: Dict[str, Any] = None,
                 metadata: Dict[str, Any] = None):
        """
        Initialize operation result.
        
        Args:
            success: Whether the operation was successful
            data: Result data payload
            message: Human-readable message
            error_code: Error code for failed operations
            details: Additional details about the result
            metadata: Metadata about the operation
        """
        self.success = success
        self.data = data
        self.message = message or ("Operation completed successfully" if success else "Operation failed")
        self.error_code = error_code
        self.details = details or {}
        self.metadata = metadata or {}
        self.timestamp = datetime.utcnow()
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert result to dictionary format."""
        return {
            'success': self.success,
            'data': self.data,
            'message': self.message,
            'error_code': self.error_code,
            'details': self.details,
            'metadata': self.metadata,
            'timestamp': self.timestamp.isoformat()
        }
    
    @classmethod
    def success_result(cls, data: Any = None, message: str = None, **kwargs) -> 'OperationResult':
        """Create a successful operation result."""
        return cls(success=True, data=data, message=message, **kwargs)
    
    @classmethod
    def failure_result(cls, message: str = None, error_code: str = None, **kwargs) -> 'OperationResult':
        """Create a failed operation result."""
        return cls(success=False, message=message, error_code=error_code, **kwargs)


class OperationContext:
    """
    Context object for tracking operation execution.
    
    Provides context information for logging, auditing, and monitoring.
    """
    
    def __init__(self, 
                 operation_type: str,
                 service_name: str,
                 user_id: str = None,
                 resource_id: str = None,
                 correlation_id: str = None):
        """
        Initialize operation context.
        
        Args:
            operation_type: Type of operation being performed
            service_name: Name of the service performing the operation
            user_id: ID of the user performing the operation
            resource_id: ID of the resource being operated on
            correlation_id: Correlation ID for tracking across services
        """
        self.operation_type = operation_type
        self.service_name = service_name
        self.user_id = user_id
        self.resource_id = resource_id
        self.correlation_id = correlation_id
        self.start_time = datetime.utcnow()
        self.end_time = None
        self.duration = None
        self.success = None
        self.error = None
        self.metadata = {}
    
    def complete(self, success: bool = True, error: Exception = None):
        """Mark the operation as completed."""
        self.end_time = datetime.utcnow()
        self.duration = (self.end_time - self.start_time).total_seconds()
        self.success = success
        self.error = error
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert context to dictionary format."""
        return {
            'operation_type': self.operation_type,
            'service_name': self.service_name,
            'user_id': self.user_id,
            'resource_id': self.resource_id,
            'correlation_id': self.correlation_id,
            'start_time': self.start_time.isoformat(),
            'end_time': self.end_time.isoformat() if self.end_time else None,
            'duration': self.duration,
            'success': self.success,
            'error': str(self.error) if self.error else None,
            'metadata': self.metadata
        }


class BaseService(ABC):
    """
    Abstract base class for all services in the Athena backend.
    
    Provides common functionality including:
    - Standardized logging
    - Permission validation
    - Error handling
    - Audit logging
    - Configuration access
    """
    
    def __init__(self, 
                 logger: logging.Logger = None,
                 config_service=None,
                 cache_service=None,
                 audit_service=None):
        """
        Initialize the base service.
        
        Args:
            logger: Logger instance for the service
            config_service: Configuration service instance
            cache_service: Cache service instance  
            audit_service: Audit service instance
        """
        self.logger = logger or logging.getLogger(self.__class__.__name__)
        self.config_service = config_service
        self.cache_service = cache_service
        self.audit_service = audit_service
        self._service_name = self.__class__.__name__
        
        # Performance tracking
        self._operation_count = 0
        self._error_count = 0
        self._last_operation_time = None
    
    async def validate_permissions(self, user_id: str, action: str, resource: str = None) -> bool:
        """
        Validate user permissions for an action.
        
        Args:
            user_id: ID of the user performing the action
            action: Action being performed (e.g., 'read', 'write', 'delete')
            resource: Resource being acted upon (optional)
            
        Returns:
            True if user has permission, False otherwise
            
        Raises:
            AuthenticationError: If user is not authenticated
            AuthorizationError: If user lacks required permissions
        """
        try:
            if not user_id:
                raise AuthenticationError("User authentication required")
            
            # Check cache first if available
            cache_key = f"permissions:{user_id}:{action}:{resource or 'global'}"
            
            if self.cache_service:
                cached_result = await self.cache_service.get(cache_key)
                if cached_result is not None:
                    return cached_result
            
            # Perform permission validation
            has_permission = await self._check_user_permissions(user_id, action, resource)
            
            # Cache the result
            if self.cache_service and has_permission is not None:
                await self.cache_service.set(cache_key, has_permission, ttl=300)  # 5 minutes
            
            if not has_permission:
                raise AuthorizationError(
                    f"User {user_id} lacks permission for action '{action}' on resource '{resource or 'global'}'"
                )
            
            return True
            
        except (AuthenticationError, AuthorizationError):
            raise
        except Exception as e:
            self.logger.error(f"Permission validation failed for user {user_id}: {e}")
            raise AuthorizationError("Permission validation failed")
    
    async def _check_user_permissions(self, user_id: str, action: str, resource: str = None) -> bool:
        """
        Override in subclasses to implement specific permission logic.
        
        Args:
            user_id: ID of the user
            action: Action being performed
            resource: Resource being acted upon
            
        Returns:
            True if user has permission, False otherwise
        """
        # Default implementation - should be overridden by subclasses
        return True
    
    async def audit_action(self, user_id: str, action: str, resource: str = None, 
                          details: Dict[str, Any] = None, success: bool = True):
        """
        Log audit information for user actions.
        
        Args:
            user_id: ID of the user performing the action
            action: Action being performed
            resource: Resource being acted upon (optional)
            details: Additional details about the action (optional)
            success: Whether the action was successful
        """
        if not self.audit_service:
            return
        
        audit_data = {
            'user_id': user_id,
            'action': action,
            'resource': resource,
            'service': self._service_name,
            'success': success,
            'timestamp': datetime.utcnow(),
            'details': details or {}
        }
        
        try:
            await self.audit_service.log_action(audit_data)
        except Exception as e:
            # Don't let audit logging failures break the main flow
            self.logger.error(f"Audit logging failed: {e}")
    
    @asynccontextmanager
    async def operation_context(self, operation_name: str, user_id: str = None):
        """
        Context manager for tracking operations with automatic error handling and logging.
        
        Args:
            operation_name: Name of the operation being performed
            user_id: ID of the user performing the operation (optional)
        """
        start_time = datetime.utcnow()
        self._operation_count += 1
        self._last_operation_time = start_time
        
        self.logger.info(f"Starting operation: {operation_name}", 
                        extra={'operation': operation_name, 'user_id': user_id})
        
        try:
            yield
            duration = (datetime.utcnow() - start_time).total_seconds()
            
            self.logger.info(f"Operation completed: {operation_name} in {duration:.3f}s",
                           extra={'operation': operation_name, 'user_id': user_id, 'duration': duration})
            
            # Audit successful operation
            if user_id:
                await self.audit_action(user_id, operation_name, success=True)
                
        except Exception as e:
            self._error_count += 1
            duration = (datetime.utcnow() - start_time).total_seconds()
            
            self.logger.error(f"Operation failed: {operation_name} after {duration:.3f}s - {e}",
                            extra={'operation': operation_name, 'user_id': user_id, 
                                 'duration': duration, 'error': str(e)})
            
            # Audit failed operation
            if user_id:
                await self.audit_action(user_id, operation_name, 
                                      details={'error': str(e)}, success=False)
            
            # Re-raise the exception
            raise
    
    def get_service_config(self, key: str = None, default: Any = None) -> Union[Dict[str, Any], Any]:
        """
        Get configuration for this service.
        
        Args:
            key: Specific configuration key (optional)
            default: Default value if key not found
            
        Returns:
            Configuration value or entire service configuration
        """
        if not self.config_service:
            return default if key is not None else {}
        
        if key is not None:
            return self.config_service.get(f"{self._service_name}_{key.upper()}", default)
        else:
            return self.config_service.get_service_config(self._service_name.lower()) or {}
    
    def handle_validation_error(self, message: str, field: str = None, value: Any = None) -> None:
        """
        Raise a validation error with proper context.
        
        Args:
            message: Error message
            field: Field that failed validation (optional)
            value: Invalid value (optional)
            
        Raises:
            ValidationError: Always raises this exception
        """
        details = {}
        if field:
            details['field'] = field
        if value is not None:
            details['value'] = str(value)
        
        raise ValidationError(message, details=details, service=self._service_name)
    
    def handle_business_error(self, message: str, error_code: str = None, details: Dict[str, Any] = None) -> None:
        """
        Raise a business logic error with proper context.
        
        Args:
            message: Error message
            error_code: Error code (optional)
            details: Additional error details (optional)
            
        Raises:
            BusinessLogicError: Always raises this exception
        """
        raise BusinessLogicError(
            message=message,
            error_code=error_code or f"{self._service_name}_BUSINESS_ERROR",
            details=details or {},
            service=self._service_name
        )
    
    def log_performance_metrics(self):
        """Log current performance metrics for the service."""
        metrics = {
            'service': self._service_name,
            'total_operations': self._operation_count,
            'total_errors': self._error_count,
            'error_rate': (self._error_count / max(self._operation_count, 1)) * 100,
            'last_operation': self._last_operation_time.isoformat() if self._last_operation_time else None
        }
        
        self.logger.info("Service performance metrics", extra=metrics)
    
    def reset_metrics(self):
        """Reset performance metrics for the service."""
        self._operation_count = 0
        self._error_count = 0
        self._last_operation_time = None
    
    # Abstract methods that subclasses must implement
    @abstractmethod
    async def health_check(self) -> Dict[str, Any]:
        """
        Check the health of the service.
        
        Returns:
            Health check information including status and any issues
        """
        pass
    
    @abstractmethod
    def get_service_info(self) -> Dict[str, Any]:
        """
        Get information about the service.
        
        Returns:
            Service information including capabilities and configuration
        """
        pass
