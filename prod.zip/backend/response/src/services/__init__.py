"""
Services Package

Modular service layer for the Athena backend.

This package provides:
- Abstract base service classes with common functionality
- Dependency injection container for service management
- Concrete service implementations for different domains
- Service factory for centralized service lifecycle management
- Comprehensive error handling and audit logging
"""

from .base_service import (
    BaseService,
    OperationResult,
    OperationContext,
    OperationType
)

from .di.container import (
    DIContainer,
    ServiceLifetime
)

from .di.lifecycle import (
    ServiceLifecycleManager,
    IServiceLifecycleAware
)

from .service_factory import (
    ServiceFactory,
    get_service_factory,
    set_service_factory,
    initialize_service_factory
)

from .firewall_service import (
    FirewallService,
    FirewallRule
)

from .waf.waf_service import (
    WAFService
)

# TODO: Import other services as they are created
# from .alerts_service import AlertsService
# from .audit_service import AuditService
# from .cache_service import CacheService
# from .aws_service import AWSService

__version__ = "1.0.0"

__all__ = [
    # Base classes and interfaces
    'BaseService',
    'OperationResult',
    'OperationContext',
    'OperationType',
    
    # Dependency injection
    'DIContainer',
    'ServiceLifetime',
    'ServiceLifecycleManager',
    'IServiceLifecycleAware',
    
    # Service factory
    'ServiceFactory',
    'get_service_factory',
    'set_service_factory',
    'initialize_service_factory',
    
    # Domain services
    'FirewallService',
    'FirewallRule',
    
    # TODO: Add other services as they are implemented
    # 'WAFService',
    # 'AlertsService',
    # 'AuditService',
    # 'CacheService',
    # 'AWSService'
]
