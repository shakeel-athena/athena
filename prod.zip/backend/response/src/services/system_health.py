"""
System Health Monitoring Module
Collects and provides system health metrics for the local machine
"""
import psutil
import subprocess
import platform
import requests
import logging
from datetime import datetime
from typing import Dict, Any

logger = logging.getLogger(__name__)

# Disable SSL warnings for development
try:
    from requests.packages.urllib3.exceptions import InsecureRequestWarning
    requests.packages.urllib3.disable_warnings(category=InsecureRequestWarning)
except:
    pass


class SystemHealthMonitor:
    """Monitor system health metrics"""

    def __init__(self, wazuh_host=None, wazuh_port=None, wazuh_user=None, wazuh_pass=None, verify_ssl=False):
        self.platform = platform.system()
        self.hostname = platform.node()
        # Wazuh indexer connection params
        self.wazuh_host = wazuh_host
        self.wazuh_port = wazuh_port
        self.wazuh_user = wazuh_user
        self.wazuh_pass = wazuh_pass
        self.verify_ssl = verify_ssl
        self.base_url = f"https://{wazuh_host}:{wazuh_port}" if wazuh_host else None

    def get_cpu_usage(self) -> Dict[str, Any]:
        """Get CPU utilization metrics"""
        try:
            cpu_percent = psutil.cpu_percent(interval=1, percpu=False)
            cpu_count = psutil.cpu_count(logical=True)
            cpu_freq = psutil.cpu_freq()

            per_cpu = psutil.cpu_percent(interval=1, percpu=True)

            return {
                'overall_percent': cpu_percent,
                'cpu_count': cpu_count,
                'per_cpu_percent': per_cpu,
                'frequency_mhz': cpu_freq.current if cpu_freq else None,
                'max_frequency_mhz': cpu_freq.max if cpu_freq else None,
            }
        except Exception as e:
            logger.error(f"Error getting CPU usage: {e}")
            return {
                'overall_percent': 0,
                'cpu_count': 0,
                'per_cpu_percent': [],
                'frequency_mhz': None,
                'max_frequency_mhz': None,
            }

    def get_memory_usage(self) -> Dict[str, Any]:
        """Get RAM usage metrics"""
        try:
            memory = psutil.virtual_memory()
            swap = psutil.swap_memory()

            return {
                'total_gb': round(memory.total / (1024**3), 2),
                'used_gb': round(memory.used / (1024**3), 2),
                'available_gb': round(memory.available / (1024**3), 2),
                'percent': memory.percent,
                'swap_total_gb': round(swap.total / (1024**3), 2),
                'swap_used_gb': round(swap.used / (1024**3), 2),
                'swap_percent': swap.percent,
            }
        except Exception as e:
            logger.error(f"Error getting memory usage: {e}")
            return {
                'total_gb': 0,
                'used_gb': 0,
                'available_gb': 0,
                'percent': 0,
                'swap_total_gb': 0,
                'swap_used_gb': 0,
                'swap_percent': 0,
            }

    def get_disk_usage(self) -> Dict[str, Any]:
        """Get disk usage metrics for all partitions"""
        try:
            partitions = []

            for partition in psutil.disk_partitions(all=False):
                if partition.fstype:
                    try:
                        usage = psutil.disk_usage(partition.mountpoint)
                        partitions.append({
                            'device': partition.device,
                            'mountpoint': partition.mountpoint,
                            'fstype': partition.fstype,
                            'total_gb': round(usage.total / (1024**3), 2),
                            'used_gb': round(usage.used / (1024**3), 2),
                            'free_gb': round(usage.free / (1024**3), 2),
                            'percent': usage.percent,
                        })
                    except PermissionError:
                        continue

            disk_io = psutil.disk_io_counters()
            return {
                'partitions': partitions,
                'total_read_gb': round(disk_io.read_bytes / (1024**3), 2) if disk_io else 0,
                'total_write_gb': round(disk_io.write_bytes / (1024**3), 2) if disk_io else 0,
            }
        except Exception as e:
            logger.error(f"Error getting disk usage: {e}")
            return {
                'partitions': [],
                'total_read_gb': 0,
                'total_write_gb': 0,
            }

    def get_pending_updates(self) -> Dict[str, Any]:
        """Get pending OS updates"""
        try:
            if self.platform == 'Linux':
                # Check for apt-based systems (Ubuntu/Debian)
                try:
                    result = subprocess.run(
                        ['apt', 'list', '--upgradable'],
                        capture_output=True,
                        text=True,
                        timeout=10
                    )
                    lines = result.stdout.strip().split('\n')
                    updates = [line for line in lines if line and not line.startswith('Listing')]

                    return {
                        'count': len(updates),
                        'updates': updates[:10],
                        'system': 'apt',
                        'last_checked': datetime.now().isoformat(),
                    }
                except (subprocess.TimeoutExpired, FileNotFoundError):
                    # Try yum-based systems
                    try:
                        result = subprocess.run(
                            ['yum', 'check-update'],
                            capture_output=True,
                            text=True,
                            timeout=10
                        )
                        lines = result.stdout.strip().split('\n')
                        updates = [line for line in lines if line and not line.startswith('Last')]

                        return {
                            'count': len(updates),
                            'updates': updates[:10],
                            'system': 'yum',
                            'last_checked': datetime.now().isoformat(),
                        }
                    except (subprocess.TimeoutExpired, FileNotFoundError):
                        pass

            return {
                'count': 0,
                'updates': [],
                'system': 'unknown',
                'last_checked': datetime.now().isoformat(),
            }
        except Exception as e:
            logger.error(f"Error getting pending updates: {e}")
            return {
                'count': 0,
                'updates': [],
                'system': 'error',
                'last_checked': datetime.now().isoformat(),
            }

    def get_smart_health(self) -> Dict[str, Any]:
        """Get SMART disk health status"""
        try:
            disks = []
            partitions = psutil.disk_partitions(all=False)
            checked_devices = set()

            for partition in partitions:
                device = partition.device.rstrip('0123456789')

                if device in checked_devices:
                    continue
                checked_devices.add(device)

                try:
                    result = subprocess.run(
                        ['smartctl', '-H', device],
                        capture_output=True,
                        text=True,
                        timeout=5
                    )

                    output = result.stdout
                    health_status = 'UNKNOWN'

                    if 'PASSED' in output:
                        health_status = 'PASSED'
                    elif 'FAILED' in output:
                        health_status = 'FAILED'

                    disks.append({
                        'device': device,
                        'health': health_status,
                    })
                except (subprocess.TimeoutExpired, FileNotFoundError, PermissionError):
                    disks.append({
                        'device': device,
                        'health': 'NOT_AVAILABLE',
                    })

            return {
                'disks': disks,
                'last_checked': datetime.now().isoformat(),
            }
        except Exception as e:
            logger.error(f"Error getting SMART health: {e}")
            return {
                'disks': [],
                'last_checked': datetime.now().isoformat(),
            }

    def get_network_stats(self) -> Dict[str, Any]:
        """Get network statistics"""
        try:
            net_io = psutil.net_io_counters()

            return {
                'bytes_sent_gb': round(net_io.bytes_sent / (1024**3), 2),
                'bytes_recv_gb': round(net_io.bytes_recv / (1024**3), 2),
                'packets_sent': net_io.packets_sent,
                'packets_recv': net_io.packets_recv,
                'errors_in': net_io.errin,
                'errors_out': net_io.errout,
            }
        except Exception as e:
            logger.error(f"Error getting network stats: {e}")
            return {
                'bytes_sent_gb': 0,
                'bytes_recv_gb': 0,
                'packets_sent': 0,
                'packets_recv': 0,
                'errors_in': 0,
                'errors_out': 0,
            }

    def get_system_info(self) -> Dict[str, Any]:
        """Get general system information"""
        try:
            boot_time = datetime.fromtimestamp(psutil.boot_time())
            uptime_seconds = (datetime.now() - boot_time).total_seconds()

            return {
                'platform': platform.system(),
                'platform_release': platform.release(),
                'platform_version': platform.version(),
                'architecture': platform.machine(),
                'hostname': platform.node(),
                'processor': platform.processor(),
                'boot_time': boot_time.isoformat(),
                'uptime_seconds': uptime_seconds,
                'uptime_days': round(uptime_seconds / 86400, 2),
            }
        except Exception as e:
            logger.error(f"Error getting system info: {e}")
            return {
                'platform': 'unknown',
                'platform_release': 'unknown',
                'platform_version': 'unknown',
                'architecture': 'unknown',
                'hostname': 'unknown',
                'processor': 'unknown',
                'boot_time': None,
                'uptime_seconds': 0,
                'uptime_days': 0,
            }

    def get_fim_stats(self, time_range: str = '30d') -> Dict[str, Any]:
        """Get File Integrity Monitoring (FIM) statistics from Wazuh"""
        if not self.base_url:
            return {
                'error': 'Wazuh connection not configured',
                'total': 0,
                'by_event_type': {},
                'recent_changes': []
            }

        try:
            time_mapping = {
                '1h': 'now-1h',
                '24h': 'now-24h',
                '7d': 'now-7d',
                '30d': 'now-30d',
            }
            es_time = time_mapping.get(time_range, 'now-24h')

            query = {
                "query": {
                    "bool": {
                        "must": [
                            {"match": {"rule.groups": "syscheck"}},
                            {"term": {"agent.name": self.hostname}},
                            {"range": {"@timestamp": {"gte": es_time, "lte": "now"}}}
                        ]
                    }
                },
                "size": 10,
                "sort": [{"@timestamp": {"order": "desc"}}],
                "aggs": {
                    "by_event_type": {
                        "terms": {"field": "syscheck.event", "size": 10}
                    }
                },
                "_source": ["@timestamp", "syscheck.event", "syscheck.path", "rule.description"]
            }

            response = requests.post(
                f"{self.base_url}/wazuh-alerts-*/_search",
                auth=(self.wazuh_user, self.wazuh_pass),
                json=query,
                verify=self.verify_ssl,
                timeout=10
            )

            if response.status_code != 200:
                return {
                    'error': f'Elasticsearch query failed: {response.status_code}',
                    'total': 0,
                    'by_event_type': {},
                    'recent_changes': []
                }

            result = response.json()

            event_type_buckets = result.get('aggregations', {}).get('by_event_type', {}).get('buckets', [])
            by_event_type = {'modified': 0, 'added': 0, 'deleted': 0, 'attributes_modified': 0}

            for bucket in event_type_buckets:
                event_type = bucket.get('key', '')
                count = bucket.get('doc_count', 0)
                if event_type in by_event_type:
                    by_event_type[event_type] = count

            total = sum(by_event_type.values())

            recent_changes = []
            for hit in result.get('hits', {}).get('hits', []):
                source = hit.get('_source', {})
                syscheck = source.get('syscheck', {})
                recent_changes.append({
                    'timestamp': source.get('@timestamp'),
                    'event': syscheck.get('event', 'unknown'),
                    'path': syscheck.get('path', 'N/A'),
                    'description': source.get('rule', {}).get('description', 'N/A')
                })

            return {
                'total': total,
                'by_event_type': by_event_type,
                'recent_changes': recent_changes,
                'hostname': self.hostname,
                'time_range': time_range
            }

        except Exception as e:
            logger.error(f"Error getting FIM stats: {e}")
            return {
                'error': str(e),
                'total': 0,
                'by_event_type': {'modified': 0, 'added': 0, 'deleted': 0, 'attributes_modified': 0},
                'recent_changes': []
            }

    def get_all_metrics(self) -> Dict[str, Any]:
        """Get all system health metrics"""
        return {
            'timestamp': datetime.now().isoformat(),
            'system_info': self.get_system_info(),
            'cpu': self.get_cpu_usage(),
            'memory': self.get_memory_usage(),
            'disk': self.get_disk_usage(),
            'network': self.get_network_stats(),
            'updates': self.get_pending_updates(),
            'smart_health': self.get_smart_health(),
            'fim': self.get_fim_stats() if self.base_url else None,
        }
