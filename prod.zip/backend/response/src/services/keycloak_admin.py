"""
Keycloak Admin Service
Manages users in Keycloak via Admin REST API
"""

import logging
from keycloak import KeycloakAdmin, KeycloakError
import os

logger = logging.getLogger(__name__)


class KeycloakAdminService:
    """
    Service to manage Keycloak users via Admin API
    Provides unified user management without requiring direct Keycloak access
    """

    def __init__(self):
        self.server_url = os.getenv('KEYCLOAK_URL') or os.getenv('REACT_APP_KEYCLOAK_URL')
        self.target_realm = os.getenv('KEYCLOAK_REALM') or os.getenv('REACT_APP_KEYCLOAK_REALM')
        self.client_id = os.getenv('KEYCLOAK_ADMIN_CLIENT_ID', 'admin-cli')
        self.username = os.getenv('KEYCLOAK_ADMIN_USER') or os.getenv('KEYCLOAK_ADMIN_USERNAME')
        self.password = os.getenv('KEYCLOAK_ADMIN_PASSWORD')

        self.admin = None
        self._connect()

    def _connect(self):
        """Initialize connection to Keycloak Admin API"""
        try:
            # IMPORTANT: Admin user exists in 'master' realm
            # We authenticate against 'master' then change realm to target
            self.admin = KeycloakAdmin(
                server_url=self.server_url,
                username=self.username,
                password=self.password,
                realm_name='master',  # Authenticate against master realm
                client_id=self.client_id,
                verify=False  # Set to False for development/internal servers
            )

            # Now switch to target realm for user management
            self.admin.realm_name = self.target_realm

            logger.info(f"[Keycloak Admin] ✓ Connected to manage {self.target_realm} realm")
        except Exception as e:
            logger.error(f"[Keycloak Admin] ✗ Failed to connect: {e}")
            # Don't raise - allow app to start, but operations will fail
            self.admin = None

    def is_connected(self):
        """Check if connection to Keycloak is established"""
        return self.admin is not None

    def create_user(self, username, email, first_name, last_name, password, enabled=True):
        """
        Create a new user in Keycloak

        Args:
            username: Unique username
            email: User email
            first_name: First name
            last_name: Last name
            password: Initial password
            enabled: Account enabled status (default: True)

        Returns:
            str: Keycloak user ID (UUID)

        Raises:
            KeycloakError: If user creation fails
            RuntimeError: If not connected to Keycloak
        """
        if not self.is_connected():
            raise RuntimeError("Not connected to Keycloak Admin API")

        try:
            # Create user payload
            user_payload = {
                "username": username,
                "email": email,
                "firstName": first_name,
                "lastName": last_name,
                "enabled": enabled,
                "emailVerified": True,  # Skip email verification for internal users
                "credentials": [
                    {
                        "type": "password",
                        "value": password,
                        "temporary": False  # User won't be forced to change password
                    }
                ]
            }

            # Create user in Keycloak
            keycloak_user_id = self.admin.create_user(user_payload)

            logger.info(f"[Keycloak Admin] ✓ Created user: {username} ({keycloak_user_id})")

            return keycloak_user_id

        except KeycloakError as e:
            error_msg = str(e)
            logger.error(f"[Keycloak Admin] ✗ Failed to create user {username}: {error_msg}")

            # Parse common errors
            if "409" in error_msg or "exists" in error_msg.lower():
                raise ValueError(f"User '{username}' already exists in Keycloak")
            elif "400" in error_msg:
                raise ValueError(f"Invalid user data: {error_msg}")
            else:
                raise RuntimeError(f"Keycloak error: {error_msg}")

    def get_user_by_username(self, username):
        """
        Get user details from Keycloak by username

        Args:
            username: Username to search

        Returns:
            dict: User object or None if not found
        """
        if not self.is_connected():
            logger.warning("[Keycloak Admin] Not connected - cannot get user")
            return None

        try:
            users = self.admin.get_users({"username": username, "exact": True})
            return users[0] if users else None
        except Exception as e:
            logger.error(f"[Keycloak Admin] Failed to get user {username}: {e}")
            return None

    def get_user_by_id(self, keycloak_user_id):
        """
        Get user details from Keycloak by ID

        Args:
            keycloak_user_id: Keycloak user UUID

        Returns:
            dict: User object or None if not found
        """
        if not self.is_connected():
            return None

        try:
            return self.admin.get_user(keycloak_user_id)
        except Exception as e:
            logger.error(f"[Keycloak Admin] Failed to get user by ID {keycloak_user_id}: {e}")
            return None

    def update_user(self, keycloak_user_id, **kwargs):
        """
        Update user in Keycloak

        Args:
            keycloak_user_id: Keycloak user UUID
            **kwargs: Fields to update (email, firstName, lastName, enabled)

        Raises:
            KeycloakError: If update fails
        """
        if not self.is_connected():
            raise RuntimeError("Not connected to Keycloak Admin API")

        try:
            self.admin.update_user(keycloak_user_id, kwargs)
            logger.info(f"[Keycloak Admin] ✓ Updated user: {keycloak_user_id}")
        except KeycloakError as e:
            logger.error(f"[Keycloak Admin] ✗ Failed to update user {keycloak_user_id}: {e}")
            raise RuntimeError(f"Failed to update user: {str(e)}")

    def delete_user(self, keycloak_user_id):
        """
        Delete user from Keycloak

        Args:
            keycloak_user_id: Keycloak user UUID

        Raises:
            KeycloakError: If deletion fails
        """
        if not self.is_connected():
            raise RuntimeError("Not connected to Keycloak Admin API")

        try:
            self.admin.delete_user(keycloak_user_id)
            logger.info(f"[Keycloak Admin] ✓ Deleted user: {keycloak_user_id}")
        except KeycloakError as e:
            logger.error(f"[Keycloak Admin] ✗ Failed to delete user {keycloak_user_id}: {e}")
            raise RuntimeError(f"Failed to delete user: {str(e)}")

    def reset_password(self, keycloak_user_id, new_password, temporary=False):
        """
        Reset user password

        Args:
            keycloak_user_id: Keycloak user UUID
            new_password: New password
            temporary: Force user to change on next login

        Raises:
            KeycloakError: If password reset fails
        """
        if not self.is_connected():
            raise RuntimeError("Not connected to Keycloak Admin API")

        try:
            self.admin.set_user_password(
                keycloak_user_id,
                new_password,
                temporary=temporary
            )
            logger.info(f"[Keycloak Admin] ✓ Reset password for user: {keycloak_user_id}")
        except KeycloakError as e:
            logger.error(f"[Keycloak Admin] ✗ Failed to reset password: {e}")
            raise RuntimeError(f"Failed to reset password: {str(e)}")

    def enable_user(self, keycloak_user_id):
        """Enable user account"""
        self.update_user(keycloak_user_id, enabled=True)

    def disable_user(self, keycloak_user_id):
        """Disable user account"""
        self.update_user(keycloak_user_id, enabled=False)

    def send_verify_email(self, keycloak_user_id):
        """Send email verification link to user"""
        if not self.is_connected():
            raise RuntimeError("Not connected to Keycloak Admin API")

        try:
            self.admin.send_verify_email(keycloak_user_id)
            logger.info(f"[Keycloak Admin] ✓ Sent verification email to: {keycloak_user_id}")
        except KeycloakError as e:
            logger.error(f"[Keycloak Admin] ✗ Failed to send verification email: {e}")
            raise RuntimeError(f"Failed to send verification email: {str(e)}")

    def get_user_count(self):
        """Get total number of users in realm"""
        if not self.is_connected():
            return 0

        try:
            return self.admin.users_count()
        except Exception as e:
            logger.error(f"[Keycloak Admin] Failed to get user count: {e}")
            return 0

    def search_users(self, query, max_results=100):
        """
        Search users by username, email, first name, or last name

        Args:
            query: Search query string
            max_results: Maximum number of results

        Returns:
            list: List of user objects
        """
        if not self.is_connected():
            return []

        try:
            return self.admin.get_users({
                "search": query,
                "max": max_results
            })
        except Exception as e:
            logger.error(f"[Keycloak Admin] Failed to search users: {e}")
            return []

    def sync_user_from_keycloak(self, keycloak_user_id):
        """
        Fetch user details from Keycloak for syncing to database

        Args:
            keycloak_user_id: Keycloak user UUID

        Returns:
            dict: User details (username, email, firstName, lastName, enabled) or None
        """
        user = self.get_user_by_id(keycloak_user_id)
        if not user:
            return None

        return {
            'keycloak_user_id': user.get('id'),
            'username': user.get('username'),
            'email': user.get('email'),
            'first_name': user.get('firstName', ''),
            'last_name': user.get('lastName', ''),
            'enabled': user.get('enabled', True)
        }


# Singleton instance
_keycloak_admin_instance = None

def get_keycloak_admin():
    """
    Get singleton instance of KeycloakAdminService

    Returns:
        KeycloakAdminService: Singleton instance
    """
    global _keycloak_admin_instance
    if _keycloak_admin_instance is None:
        _keycloak_admin_instance = KeycloakAdminService()
    return _keycloak_admin_instance


# Export singleton
keycloak_admin = get_keycloak_admin()
