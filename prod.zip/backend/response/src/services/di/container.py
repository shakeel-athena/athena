"""
Dependency Injection Container

Provides a lightweight dependency injection system for managing service
lifecycles and dependencies in the Athena backend.
"""

import inspect
import asyncio
from typing import Any, Dict, Type, Callable, Optional, Union, List
from enum import Enum
from contextlib import asynccontextmanager
import threading
import time
from datetime import datetime
import logging

class ServiceLifetime(Enum):
    """Service lifetime options"""
    SINGLETON = "singleton"
    TRANSIENT = "transient"
    SCOPED = "scoped"


class ServiceDescriptor:
    """Describes a service registration"""
    
    def __init__(self, 
                 service_type: Type,
                 implementation_type: Type = None,
                 factory: Callable = None,
                 instance: Any = None,
                 lifetime: ServiceLifetime = ServiceLifetime.TRANSIENT):
        """
        Initialize service descriptor.
        
        Args:
            service_type: The interface/type being registered
            implementation_type: The concrete implementation class
            factory: Factory function to create instances
            instance: Pre-created instance (only for SINGLETON)
            lifetime: Service lifetime
        """
        self.service_type = service_type
        self.implementation_type = implementation_type
        self.factory = factory
        self.instance = instance
        self.lifetime = lifetime
        
        # Validate configuration
        self._validate()
    
    def _validate(self):
        """Validate the service descriptor configuration."""
        if self.lifetime == ServiceLifetime.SINGLETON and self.instance is None and self.implementation_type is None and self.factory is None:
            raise ValueError("Singleton services must have instance, implementation_type, or factory")
        
        if self.implementation_type and self.factory:
            raise ValueError("Cannot specify both implementation_type and factory")
        
        if self.instance and (self.implementation_type or self.factory):
            raise ValueError("Cannot specify instance with implementation_type or factory")


class DIContainer:
    """
    Dependency injection container with support for different service lifetimes.
    """
    
    def __init__(self, logger: logging.Logger = None):
        """
        Initialize the DI container.
        
        Args:
            logger: Logger instance for monitoring
        """
        self.logger = logger or logging.getLogger(self.__class__.__name__)
        self._services: Dict[Type, ServiceDescriptor] = {}
        self._singleton_instances: Dict[Type, Any] = {}
        self._scoped_instances: Dict[str, Dict[Type, Any]] = {}
        self._creation_stack: List[Type] = []  # Track circular dependencies
        self._lock = threading.RLock()  # Thread safety for singleton creation
        
        # Performance tracking
        self._creation_count = 0
        self._resolution_count = 0
        self._last_service_created = None
    
    def register_singleton(self, 
                          service_type: Type, 
                          implementation_type: Type = None,
                          factory: Callable = None,
                          instance: Any = None) -> 'DIContainer':
        """
        Register a singleton service.
        
        Args:
            service_type: The service interface/type
            implementation_type: The concrete implementation
            factory: Factory function to create instance
            instance: Pre-created instance
            
        Returns:
            Self for method chaining
        """
        descriptor = ServiceDescriptor(
            service_type=service_type,
            implementation_type=implementation_type,
            factory=factory,
            instance=instance,
            lifetime=ServiceLifetime.SINGLETON
        )
        
        self._services[service_type] = descriptor
        
        # If instance is provided, store it immediately
        if instance is not None:
            self._singleton_instances[service_type] = instance
        
        self.logger.debug(f"Registered singleton service: {service_type.__name__}")
        return self
    
    def register_transient(self, 
                          service_type: Type, 
                          implementation_type: Type = None,
                          factory: Callable = None) -> 'DIContainer':
        """
        Register a transient service.
        
        Args:
            service_type: The service interface/type
            implementation_type: The concrete implementation
            factory: Factory function to create instance
            
        Returns:
            Self for method chaining
        """
        descriptor = ServiceDescriptor(
            service_type=service_type,
            implementation_type=implementation_type,
            factory=factory,
            lifetime=ServiceLifetime.TRANSIENT
        )
        
        self._services[service_type] = descriptor
        self.logger.debug(f"Registered transient service: {service_type.__name__}")
        return self
    
    def register_scoped(self, 
                       service_type: Type, 
                       implementation_type: Type = None,
                       factory: Callable = None) -> 'DIContainer':
        """
        Register a scoped service.
        
        Args:
            service_type: The service interface/type
            implementation_type: The concrete implementation
            factory: Factory function to create instance
            
        Returns:
            Self for method chaining
        """
        descriptor = ServiceDescriptor(
            service_type=service_type,
            implementation_type=implementation_type,
            factory=factory,
            lifetime=ServiceLifetime.SCOPED
        )
        
        self._services[service_type] = descriptor
        self.logger.debug(f"Registered scoped service: {service_type.__name__}")
        return self
    
    def resolve(self, service_type: Type, scope_id: str = None) -> Any:
        """
        Resolve a service instance.
        
        Args:
            service_type: The service type to resolve
            scope_id: Optional scope ID for scoped services
            
        Returns:
            Service instance
            
        Raises:
            ValueError: If service is not registered
            RuntimeError: If circular dependency is detected
        """
        if service_type not in self._services:
            available_services = list(self._services.keys())
            self.logger.error(f"Service {service_type.__name__} not registered. Available: {[s.__name__ for s in available_services]}")
            raise ValueError(f"Service {service_type.__name__} is not registered")
        
        # Check for circular dependencies
        if service_type in self._creation_stack:
            cycle_path = " -> ".join([s.__name__ for s in self._creation_stack] + [service_type.__name__])
            raise RuntimeError(f"Circular dependency detected: {cycle_path}")
        
        self._resolution_count += 1
        descriptor = self._services[service_type]
        
        # Handle different lifetimes
        if descriptor.lifetime == ServiceLifetime.SINGLETON:
            return self._resolve_singleton(service_type, descriptor)
        elif descriptor.lifetime == ServiceLifetime.SCOPED:
            return self._resolve_scoped(service_type, descriptor, scope_id)
        else:  # TRANSIENT
            return self._resolve_transient(service_type, descriptor)
    
    def _resolve_singleton(self, service_type: Type, descriptor: ServiceDescriptor) -> Any:
        """Resolve singleton service instance."""
        if service_type in self._singleton_instances:
            return self._singleton_instances[service_type]
        
        with self._lock:  # Thread safety for singleton creation
            # Double-check pattern
            if service_type in self._singleton_instances:
                return self._singleton_instances[service_type]
            
            instance = self._create_instance(service_type, descriptor)
            self._singleton_instances[service_type] = instance
            
            return instance
    
    def _resolve_scoped(self, service_type: Type, descriptor: ServiceDescriptor, scope_id: str) -> Any:
        """Resolve scoped service instance."""
        if scope_id is None:
            # Generate default scope ID
            scope_id = f"default_scope_{threading.get_ident()}_{int(time.time() * 1000)}"
        
        if scope_id not in self._scoped_instances:
            self._scoped_instances[scope_id] = {}
        
        if service_type in self._scoped_instances[scope_id]:
            return self._scoped_instances[scope_id][service_type]
        
        instance = self._create_instance(service_type, descriptor)
        self._scoped_instances[scope_id][service_type] = instance
        
        return instance
    
    def _resolve_transient(self, service_type: Type, descriptor: ServiceDescriptor) -> Any:
        """Resolve transient service instance."""
        return self._create_instance(service_type, descriptor)
    
    def _create_instance(self, service_type: Type, descriptor: ServiceDescriptor) -> Any:
        """
        Create a new service instance.
        
        Args:
            service_type: The service type
            descriptor: Service descriptor
            
        Returns:
            Created service instance
        """
        self._creation_stack.append(service_type)
        
        try:
            start_time = time.time()
            
            if descriptor.instance is not None:
                instance = descriptor.instance
            elif descriptor.factory is not None:
                instance = self._create_from_factory(descriptor)
            elif descriptor.implementation_type is not None:
                instance = self._create_from_implementation_type(descriptor)
            else:
                # Try to instantiate the service type directly
                instance = self._create_from_implementation_type(descriptor)
            
            creation_time = time.time() - start_time
            self._creation_count += 1
            self._last_service_created = service_type.__name__
            
            self.logger.debug(f"Created service instance: {service_type.__name__} in {creation_time:.4f}s")
            
            return instance
            
        finally:
            self._creation_stack.pop()
    
    def _create_from_factory(self, descriptor: ServiceDescriptor) -> Any:
        """Create instance using factory function."""
        factory_sig = inspect.signature(descriptor.factory)
        factory_params = {}
        
        # Inject required parameters from container
        for param_name, param in factory_sig.parameters.items():
            if param.annotation != inspect.Parameter.empty:
                factory_params[param_name] = self.resolve(param.annotation)
        
        return descriptor.factory(**factory_params)
    
    def _create_from_implementation_type(self, descriptor: ServiceDescriptor) -> Any:
        """Create instance from implementation type."""
        impl_type = descriptor.implementation_type or descriptor.service_type
        
        # Check if class has a custom constructor that accepts the container
        constructor_sig = inspect.signature(impl_type.__init__)
        
        # Get constructor parameters excluding 'self'
        constructor_params = {}
        
        # Try to inject dependencies
        for param_name, param in constructor_sig.parameters.items():
            if param_name == 'self':
                continue
                
            # Check if parameter has type annotation and try to resolve it
            if param.annotation != inspect.Parameter.empty:
                try:
                    constructor_params[param_name] = self.resolve(param.annotation)
                except ValueError:
                    # If dependency is not registered, check if it has a default value
                    if param.default != inspect.Parameter.empty:
                        constructor_params[param_name] = param.default
                    else:
                        raise
        
        return impl_type(**constructor_params)
    
    @asynccontextmanager
    async def create_scope(self):
        """
        Create a new scope for scoped services.
        
        Returns:
            Async context manager with scope ID
        """
        scope_id = f"scope_{threading.get_ident()}_{int(time.time() * 1000000)}"
        
        try:
            yield scope_id
        finally:
            # Cleanup scoped instances
            if scope_id in self._scoped_instances:
                scoped_instances = self._scoped_instances.pop(scope_id)
                
                # Call cleanup methods on instances if they have them
                for instance in scoped_instances.values():
                    if hasattr(instance, 'cleanup'):
                        try:
                            if asyncio.iscoroutinefunction(instance.cleanup):
                                await instance.cleanup()
                            else:
                                instance.cleanup()
                        except Exception as e:
                            self.logger.error(f"Error during scoped instance cleanup: {e}")
    
    def is_registered(self, service_type: Type) -> bool:
        """
        Check if a service type is registered.
        
        Args:
            service_type: Service type to check
            
        Returns:
            True if registered, False otherwise
        """
        return service_type in self._services
    
    def get_registered_services(self) -> List[Type]:
        """
        Get list of all registered service types.
        
        Returns:
            List of registered service types
        """
        return list(self._services.keys())
    
    def get_service_info(self, service_type: Type) -> Dict[str, Any]:
        """
        Get information about a registered service.
        
        Args:
            service_type: Service type to get info for
            
        Returns:
            Service information dictionary
            
        Raises:
            ValueError: If service is not registered
        """
        if service_type not in self._services:
            raise ValueError(f"Service {service_type.__name__} is not registered")
        
        descriptor = self._services[service_type]
        
        info = {
            'service_type': service_type.__name__,
            'lifetime': descriptor.lifetime.value,
            'implementation_type': descriptor.implementation_type.__name__ if descriptor.implementation_type else None,
            'has_factory': descriptor.factory is not None,
            'has_instance': descriptor.instance is not None,
            'is_singleton_created': service_type in self._singleton_instances
        }
        
        return info
    
    def get_container_stats(self) -> Dict[str, Any]:
        """
        Get container performance statistics.
        
        Returns:
            Statistics dictionary
        """
        return {
            'registered_services': len(self._services),
            'singleton_instances': len(self._singleton_instances),
            'active_scopes': len(self._scoped_instances),
            'total_creations': self._creation_count,
            'total_resolutions': self._resolution_count,
            'last_service_created': self._last_service_created,
            'timestamp': datetime.utcnow().isoformat()
        }
    
    def clear_singleton_instances(self):
        """Clear all singleton instances (useful for testing)."""
        self._singleton_instances.clear()
        self.logger.info("Cleared all singleton instances")
    
    def cleanup_scope(self, scope_id: str):
        """
        Cleanup a specific scope.
        
        Args:
            scope_id: Scope ID to cleanup
        """
        if scope_id in self._scoped_instances:
            scoped_instances = self._scoped_instances.pop(scope_id)
            
            # Call cleanup methods
            for instance in scoped_instances.values():
                if hasattr(instance, 'cleanup'):
                    try:
                        instance.cleanup()
                    except Exception as e:
                        self.logger.error(f"Error during scoped instance cleanup: {e}")