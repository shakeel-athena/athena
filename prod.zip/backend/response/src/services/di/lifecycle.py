"""
Service Lifecycle Management

Provides lifecycle management for dependency injection services.
Handles service initialization, startup, shutdown, and health monitoring.
"""

import logging
from abc import ABC, abstractmethod
from typing import Any, Dict, List, Optional, Set
from datetime import datetime
from enum import Enum


class ServiceState(Enum):
    """Enumeration of possible service states."""
    UNINITIALIZED = "uninitialized"
    INITIALIZING = "initializing"
    READY = "ready"
    STARTING = "starting"
    RUNNING = "running"
    STOPPING = "stopping"
    STOPPED = "stopped"
    ERROR = "error"


class IServiceLifecycleAware(ABC):
    """
    Interface for services that need to be aware of their lifecycle.
    
    Services implementing this interface will receive lifecycle callbacks
    from the ServiceLifecycleManager.
    """
    
    @abstractmethod
    async def on_initialize(self) -> bool:
        """
        Called when the service is being initialized.
        
        Returns:
            True if initialization was successful, False otherwise
        """
        pass
    
    @abstractmethod
    async def on_start(self) -> bool:
        """
        Called when the service is being started.
        
        Returns:
            True if startup was successful, False otherwise
        """
        pass
    
    @abstractmethod
    async def on_stop(self) -> bool:
        """
        Called when the service is being stopped.
        
        Returns:
            True if shutdown was successful, False otherwise
        """
        pass
    
    @abstractmethod
    async def on_health_check(self) -> Dict[str, Any]:
        """
        Called during health checks.
        
        Returns:
            Health check information for the service
        """
        pass


class ServiceLifecycleManager:
    """
    Manages the lifecycle of services in the dependency injection container.
    
    Provides centralized management of service initialization, startup,
    shutdown, and health monitoring.
    """
    
    def __init__(self, logger: logging.Logger = None):
        """
        Initialize the lifecycle manager.
        
        Args:
            logger: Logger instance for the manager
        """
        self.logger = logger or logging.getLogger(self.__class__.__name__)
        self._services: Dict[str, IServiceLifecycleAware] = {}
        self._service_states: Dict[str, ServiceState] = {}
        self._service_health: Dict[str, Dict[str, Any]] = {}
        self._startup_order: List[str] = []
        self._shutdown_order: List[str] = []
        self._dependencies: Dict[str, Set[str]] = {}
    
    def register_service(self, name: str, service: IServiceLifecycleAware, 
                        dependencies: List[str] = None):
        """
        Register a service with the lifecycle manager.
        
        Args:
            name: Unique name for the service
            service: Service instance implementing IServiceLifecycleAware
            dependencies: List of service names this service depends on
        """
        if name in self._services:
            raise ValueError(f"Service '{name}' is already registered")
        
        if not isinstance(service, IServiceLifecycleAware):
            raise TypeError(f"Service '{name}' must implement IServiceLifecycleAware")
        
        self._services[name] = service
        self._service_states[name] = ServiceState.UNINITIALIZED
        self._dependencies[name] = set(dependencies or [])
        
        self.logger.info(f"Registered service '{name}' with dependencies: {dependencies or []}")
        
        # Recalculate startup and shutdown order
        self._calculate_service_order()
    
    def unregister_service(self, name: str):
        """
        Unregister a service from the lifecycle manager.
        
        Args:
            name: Name of the service to unregister
        """
        if name not in self._services:
            raise ValueError(f"Service '{name}' is not registered")
        
        # Stop the service if it's running
        if self._service_states[name] == ServiceState.RUNNING:
            self.stop_service(name)
        
        del self._services[name]
        del self._service_states[name]
        del self._dependencies[name]
        if name in self._service_health:
            del self._service_health[name]
        
        self.logger.info(f"Unregistered service '{name}'")
        
        # Recalculate startup and shutdown order
        self._calculate_service_order()
    
    def get_service_state(self, name: str) -> ServiceState:
        """
        Get the current state of a service.
        
        Args:
            name: Name of the service
            
        Returns:
            Current state of the service
        """
        if name not in self._services:
            raise ValueError(f"Service '{name}' is not registered")
        
        return self._service_states[name]
    
    def get_all_service_states(self) -> Dict[str, ServiceState]:
        """
        Get the current state of all registered services.
        
        Returns:
            Dictionary mapping service names to their current states
        """
        return self._service_states.copy()
    
    async def initialize_service(self, name: str) -> bool:
        """
        Initialize a single service.
        
        Args:
            name: Name of the service to initialize
            
        Returns:
            True if initialization was successful, False otherwise
        """
        if name not in self._services:
            raise ValueError(f"Service '{name}' is not registered")
        
        if self._service_states[name] != ServiceState.UNINITIALIZED:
            self.logger.warning(f"Service '{name}' is already initialized or in progress")
            return True
        
        self._service_states[name] = ServiceState.INITIALIZING
        
        try:
            self.logger.info(f"Initializing service '{name}'")
            success = await self._services[name].on_initialize()
            
            if success:
                self._service_states[name] = ServiceState.READY
                self.logger.info(f"Service '{name}' initialized successfully")
            else:
                self._service_states[name] = ServiceState.ERROR
                self.logger.error(f"Service '{name}' initialization failed")
            
            return success
            
        except Exception as e:
            self._service_states[name] = ServiceState.ERROR
            self.logger.error(f"Service '{name}' initialization failed with exception: {e}")
            return False
    
    async def start_service(self, name: str) -> bool:
        """
        Start a single service.
        
        Args:
            name: Name of the service to start
            
        Returns:
            True if startup was successful, False otherwise
        """
        if name not in self._services:
            raise ValueError(f"Service '{name}' is not registered")
        
        if self._service_states[name] == ServiceState.RUNNING:
            self.logger.warning(f"Service '{name}' is already running")
            return True
        
        if self._service_states[name] != ServiceState.READY:
            if not await self.initialize_service(name):
                return False
        
        self._service_states[name] = ServiceState.STARTING
        
        try:
            self.logger.info(f"Starting service '{name}'")
            success = await self._services[name].on_start()
            
            if success:
                self._service_states[name] = ServiceState.RUNNING
                self.logger.info(f"Service '{name}' started successfully")
            else:
                self._service_states[name] = ServiceState.ERROR
                self.logger.error(f"Service '{name}' startup failed")
            
            return success
            
        except Exception as e:
            self._service_states[name] = ServiceState.ERROR
            self.logger.error(f"Service '{name}' startup failed with exception: {e}")
            return False
    
    async def stop_service(self, name: str) -> bool:
        """
        Stop a single service.
        
        Args:
            name: Name of the service to stop
            
        Returns:
            True if shutdown was successful, False otherwise
        """
        if name not in self._services:
            raise ValueError(f"Service '{name}' is not registered")
        
        if self._service_states[name] not in [ServiceState.RUNNING, ServiceState.STARTING]:
            self.logger.warning(f"Service '{name}' is not running")
            return True
        
        self._service_states[name] = ServiceState.STOPPING
        
        try:
            self.logger.info(f"Stopping service '{name}'")
            success = await self._services[name].on_stop()
            
            if success:
                self._service_states[name] = ServiceState.STOPPED
                self.logger.info(f"Service '{name}' stopped successfully")
            else:
                self._service_states[name] = ServiceState.ERROR
                self.logger.error(f"Service '{name}' shutdown failed")
            
            return success
            
        except Exception as e:
            self._service_states[name] = ServiceState.ERROR
            self.logger.error(f"Service '{name}' shutdown failed with exception: {e}")
            return False
    
    async def initialize_all_services(self) -> Dict[str, bool]:
        """
        Initialize all registered services in dependency order.
        
        Returns:
            Dictionary mapping service names to initialization success status
        """
        results = {}
        
        for service_name in self._startup_order:
            results[service_name] = await self.initialize_service(service_name)
        
        return results
    
    async def start_all_services(self) -> Dict[str, bool]:
        """
        Start all registered services in dependency order.
        
        Returns:
            Dictionary mapping service names to startup success status
        """
        results = {}
        
        for service_name in self._startup_order:
            results[service_name] = await self.start_service(service_name)
        
        return results
    
    async def stop_all_services(self) -> Dict[str, bool]:
        """
        Stop all registered services in reverse dependency order.
        
        Returns:
            Dictionary mapping service names to shutdown success status
        """
        results = {}
        
        for service_name in self._shutdown_order:
            results[service_name] = await self.stop_service(service_name)
        
        return results
    
    async def health_check_all_services(self) -> Dict[str, Dict[str, Any]]:
        """
        Perform health checks on all running services.
        
        Returns:
            Dictionary mapping service names to their health information
        """
        results = {}
        
        for name, service in self._services.items():
            if self._service_states[name] == ServiceState.RUNNING:
                try:
                    health_info = await service.on_health_check()
                    health_info['state'] = self._service_states[name].value
                    health_info['timestamp'] = datetime.utcnow().isoformat()
                    self._service_health[name] = health_info
                    results[name] = health_info
                except Exception as e:
                    error_info = {
                        'state': self._service_states[name].value,
                        'healthy': False,
                        'error': str(e),
                        'timestamp': datetime.utcnow().isoformat()
                    }
                    self._service_health[name] = error_info
                    results[name] = error_info
            else:
                results[name] = {
                    'state': self._service_states[name].value,
                    'healthy': False,
                    'message': f"Service is not running (state: {self._service_states[name].value})",
                    'timestamp': datetime.utcnow().isoformat()
                }
        
        return results
    
    def _calculate_service_order(self):
        """
        Calculate the optimal startup and shutdown order based on dependencies.
        
        Uses topological sorting to determine dependency order.
        """
        # Simple topological sort for startup order
        visited = set()
        temp_visited = set()
        startup_order = []
        
        def visit(service_name: str):
            if service_name in temp_visited:
                raise ValueError(f"Circular dependency detected involving service '{service_name}'")
            if service_name in visited:
                return
            
            temp_visited.add(service_name)
            
            # Visit dependencies first
            for dep in self._dependencies.get(service_name, set()):
                if dep in self._services:  # Only consider registered dependencies
                    visit(dep)
            
            temp_visited.remove(service_name)
            visited.add(service_name)
            startup_order.append(service_name)
        
        for service_name in self._services:
            if service_name not in visited:
                visit(service_name)
        
        self._startup_order = startup_order
        self._shutdown_order = list(reversed(startup_order))
        
        self.logger.info(f"Calculated service order - Startup: {self._startup_order}")
        self.logger.info(f"Calculated service order - Shutdown: {self._shutdown_order}")
    
    def get_service_info(self) -> Dict[str, Any]:
        """
        Get comprehensive information about all registered services.
        
        Returns:
            Dictionary containing service information
        """
        return {
            'total_services': len(self._services),
            'service_states': {name: state.value for name, state in self._service_states.items()},
            'startup_order': self._startup_order,
            'shutdown_order': self._shutdown_order,
            'dependencies': {name: list(deps) for name, deps in self._dependencies.items()},
            'service_health': self._service_health
        }
