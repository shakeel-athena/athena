"""
AWS Service Module

Provides centralized AWS client management and operations.
Abstracts AWS SDK dependencies for better testability and maintainability.
"""

from .clients.session_manager import AWSSessionManager
from .aws_service import AWSService

__all__ = ['AWSSessionManager', 'AWSService']
