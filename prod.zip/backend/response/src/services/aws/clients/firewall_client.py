"""
Firewall Client Wrapper

Typed wrapper around boto3 Network Firewall client with enhanced error handling.
"""

import logging
from typing import Dict, List, Any, Optional
from botocore.exceptions import ClientError

from .session_manager import AWSSessionManager
from ..exceptions import (
    AWSResourceNotFoundError,
    AWSAccessDeniedError,
    AWSServiceError
)


class FirewallClient:
    """
    Wrapper around AWS Network Firewall client.

    Provides:
    - Enhanced error handling
    - Type hints
    - Consistent error messages
    - Logging
    """

    def __init__(self, region: Optional[str] = None):
        """
        Initialize Network Firewall client.

        Args:
            region: AWS region (defaults to session manager region)
        """
        self.logger = logging.getLogger(self.__class__.__name__)
        self.session_manager = AWSSessionManager()
        self.region = region or self.session_manager.get_region()
        self._client = None

    @property
    def client(self):
        """Get or create Network Firewall client (lazy initialization)."""
        if self._client is None:
            self._client = self.session_manager.get_client('network-firewall', self.region)
        return self._client

    def get_rule_group(self, rule_group_name: str, rule_group_arn: Optional[str] = None) -> Dict[str, Any]:
        """
        Get Network Firewall rule group details.

        Args:
            rule_group_name: Name of the rule group
            rule_group_arn: ARN of the rule group (optional, used if rule group is shared)

        Returns:
            Rule group configuration

        Raises:
            AWSResourceNotFoundError: If rule group not found
            AWSAccessDeniedError: If access is denied
            AWSServiceError: For other errors
        """
        try:
            if rule_group_arn:
                response = self.client.describe_rule_group(
                    RuleGroupArn=rule_group_arn
                )
            else:
                response = self.client.describe_rule_group(
                    RuleGroupName=rule_group_name
                )
            return response.get('RuleGroup', {})

        except ClientError as e:
            error_code = e.response.get('Error', {}).get('Code', '')

            if error_code == 'ResourceNotFoundException':
                raise AWSResourceNotFoundError("Rule Group", rule_group_name)
            elif error_code in ['AccessDeniedException', 'UnauthorizedException']:
                raise AWSAccessDeniedError(f"Access denied to rule group: {rule_group_name}")
            else:
                self.logger.error(f"Error getting rule group {rule_group_name}: {e}")
                raise AWSServiceError(f"Failed to get rule group: {str(e)}", "Network Firewall")

    def update_rule_group(
        self,
        rule_group_name: str,
        rule_group_arn: Optional[str] = None,
        rule_group: Optional[Dict[str, Any]] = None,
        rules: Optional[str] = None,
        type: str = "STATELESS",
        description: Optional[str] = None,
        capacity: Optional[int] = None,
        **kwargs
    ) -> Dict[str, Any]:
        """
        Update Network Firewall rule group.

        Args:
            rule_group_name: Name of the rule group
            rule_group_arn: ARN of the rule group (optional)
            rule_group: Rule group configuration object
            rules: Rule definition in Suricata compatible format
            type: Rule group type (STATELESS or STATEFUL)
            description: Rule group description
            capacity: Capacity for the rule group
            **kwargs: Additional parameters

        Returns:
            Update response with rule group ARN and update token

        Raises:
            AWSResourceNotFoundError: If rule group not found
            AWSAccessDeniedError: If access is denied
            AWSServiceError: For other errors
        """
        try:
            update_params = {
                'RuleGroupName': rule_group_name,
                'Type': type
            }

            if rule_group_arn:
                update_params['RuleGroupArn'] = rule_group_arn

            if rule_group:
                update_params['RuleGroup'] = rule_group

            if rules is not None:
                update_params['RuleGroup']['RulesString'] = rules

            if description is not None:
                if 'RuleGroup' not in update_params:
                    update_params['RuleGroup'] = {}
                update_params['RuleGroup']['Description'] = description

            if capacity is not None:
                update_params['Capacity'] = capacity

            # Add any additional parameters
            update_params.update(kwargs)

            response = self.client.update_rule_group(**update_params)
            return response

        except ClientError as e:
            error_code = e.response.get('Error', {}).get('Code', '')

            if error_code == 'ResourceNotFoundException':
                raise AWSResourceNotFoundError("Rule Group", rule_group_name)
            elif error_code in ['AccessDeniedException', 'UnauthorizedException']:
                raise AWSAccessDeniedError(f"Access denied to update rule group: {rule_group_name}")
            elif error_code == 'InvalidRequestException':
                raise AWSServiceError(
                    f"Invalid request for rule group {rule_group_name}: {str(e)}",
                    "Network Firewall"
                )
            elif error_code == 'LimitExceededException':
                raise AWSServiceError(
                    f"Capacity limit exceeded for rule group {rule_group_name}",
                    "Network Firewall"
                )
            else:
                self.logger.error(f"Error updating rule group {rule_group_name}: {e}")
                raise AWSServiceError(f"Failed to update rule group: {str(e)}", "Network Firewall")

    def list_rule_groups(
        self,
        type: Optional[str] = None,
        next_token: Optional[str] = None,
        max_results: Optional[int] = None
    ) -> Dict[str, Any]:
        """
        List Network Firewall rule groups.

        Args:
            type: Rule group type filter (STATELESS or STATEFUL)
            next_token: Pagination token
            max_results: Maximum number of results to return

        Returns:
            Dictionary with rule groups list and pagination info

        Raises:
            AWSAccessDeniedError: If access is denied
            AWSServiceError: For other errors
        """
        try:
            list_params = {}

            if type:
                list_params['Type'] = type

            if next_token:
                list_params['NextToken'] = next_token

            if max_results:
                list_params['MaxResults'] = max_results

            response = self.client.list_rule_groups(**list_params)
            return response

        except ClientError as e:
            error_code = e.response.get('Error', {}).get('Code', '')

            if error_code in ['AccessDeniedException', 'UnauthorizedException']:
                raise AWSAccessDeniedError("Access denied to list rule groups")
            else:
                self.logger.error(f"Error listing rule groups: {e}")
                raise AWSServiceError(f"Failed to list rule groups: {str(e)}", "Network Firewall")

    def describe_rule_group(
        self,
        rule_group_name: str,
        rule_group_arn: Optional[str] = None,
        type: str = "STATELESS"
    ) -> Dict[str, Any]:
        """
        Describe Network Firewall rule group with metadata.

        Args:
            rule_group_name: Name of the rule group
            rule_group_arn: ARN of the rule group (optional)
            type: Rule group type (STATELESS or STATEFUL)

        Returns:
            Detailed rule group information including metadata

        Raises:
            AWSResourceNotFoundError: If rule group not found
            AWSAccessDeniedError: If access is denied
            AWSServiceError: For other errors
        """
        try:
            describe_params = {
                'Type': type
            }

            if rule_group_arn:
                describe_params['RuleGroupArn'] = rule_group_arn
            else:
                describe_params['RuleGroupName'] = rule_group_name

            response = self.client.describe_rule_group(**describe_params)
            return response

        except ClientError as e:
            error_code = e.response.get('Error', {}).get('Code', '')

            if error_code == 'ResourceNotFoundException':
                raise AWSResourceNotFoundError("Rule Group", rule_group_name)
            elif error_code in ['AccessDeniedException', 'UnauthorizedException']:
                raise AWSAccessDeniedError(f"Access denied to describe rule group: {rule_group_name}")
            else:
                self.logger.error(f"Error describing rule group {rule_group_name}: {e}")
                raise AWSServiceError(f"Failed to describe rule group: {str(e)}", "Network Firewall")

    def get_firewall_policy(self, firewall_policy_name: str, firewall_policy_arn: Optional[str] = None) -> Dict[str, Any]:
        """
        Get Network Firewall policy details.

        Args:
            firewall_policy_name: Name of the firewall policy
            firewall_policy_arn: ARN of the firewall policy (optional)

        Returns:
            Firewall policy configuration

        Raises:
            AWSResourceNotFoundError: If firewall policy not found
            AWSAccessDeniedError: If access is denied
            AWSServiceError: For other errors
        """
        try:
            if firewall_policy_arn:
                response = self.client.describe_firewall_policy(
                    FirewallPolicyArn=firewall_policy_arn
                )
            else:
                response = self.client.describe_firewall_policy(
                    FirewallPolicyName=firewall_policy_name
                )
            return response.get('FirewallPolicy', {})

        except ClientError as e:
            error_code = e.response.get('Error', {}).get('Code', '')

            if error_code == 'ResourceNotFoundException':
                raise AWSResourceNotFoundError("Firewall Policy", firewall_policy_name)
            elif error_code in ['AccessDeniedException', 'UnauthorizedException']:
                raise AWSAccessDeniedError(f"Access denied to firewall policy: {firewall_policy_name}")
            else:
                self.logger.error(f"Error getting firewall policy {firewall_policy_name}: {e}")
                raise AWSServiceError(f"Failed to get firewall policy: {str(e)}", "Network Firewall")

    def list_firewall_policies(
        self,
        next_token: Optional[str] = None,
        max_results: Optional[int] = None
    ) -> Dict[str, Any]:
        """
        List Network Firewall policies.

        Args:
            next_token: Pagination token
            max_results: Maximum number of results to return

        Returns:
            Dictionary with firewall policies list and pagination info

        Raises:
            AWSAccessDeniedError: If access is denied
            AWSServiceError: For other errors
        """
        try:
            list_params = {}

            if next_token:
                list_params['NextToken'] = next_token

            if max_results:
                list_params['MaxResults'] = max_results

            response = self.client.list_firewall_policies(**list_params)
            return response

        except ClientError as e:
            error_code = e.response.get('Error', {}).get('Code', '')

            if error_code in ['AccessDeniedException', 'UnauthorizedException']:
                raise AWSAccessDeniedError("Access denied to list firewall policies")
            else:
                self.logger.error(f"Error listing firewall policies: {e}")
                raise AWSServiceError(f"Failed to list firewall policies: {str(e)}", "Network Firewall")

    def create_rule_group(
        self,
        rule_group_name: str,
        rule_group: Dict[str, Any],
        type: str = "STATELESS",
        description: Optional[str] = None,
        capacity: int = 100,
        tags: Optional[List[Dict[str, str]]] = None,
        **kwargs
    ) -> Dict[str, Any]:
        """
        Create Network Firewall rule group.

        Args:
            rule_group_name: Name of the rule group
            rule_group: Rule group configuration
            type: Rule group type (STATELESS or STATEFUL)
            description: Rule group description
            capacity: Capacity for the rule group
            tags: List of tags to apply
            **kwargs: Additional parameters

        Returns:
            Create response with rule group ARN and update token

        Raises:
            AWSAccessDeniedError: If access is denied
            AWSServiceError: For other errors
        """
        try:
            create_params = {
                'RuleGroupName': rule_group_name,
                'RuleGroup': rule_group,
                'Type': type,
                'Capacity': capacity
            }

            if description:
                create_params['Description'] = description

            if tags:
                create_params['Tags'] = tags

            # Add any additional parameters
            create_params.update(kwargs)

            response = self.client.create_rule_group(**create_params)
            return response

        except ClientError as e:
            error_code = e.response.get('Error', {}).get('Code', '')

            if error_code in ['AccessDeniedException', 'UnauthorizedException']:
                raise AWSAccessDeniedError(f"Access denied to create rule group: {rule_group_name}")
            elif error_code == 'InvalidRequestException':
                raise AWSServiceError(
                    f"Invalid request for rule group {rule_group_name}: {str(e)}",
                    "Network Firewall"
                )
            elif error_code == 'LimitExceededException':
                raise AWSServiceError(
                    f"Limit exceeded creating rule group {rule_group_name}",
                    "Network Firewall"
                )
            elif error_code == 'ResourceNotFoundException':
                raise AWSServiceError(
                    f"Referenced resource not found for rule group {rule_group_name}",
                    "Network Firewall"
                )
            else:
                self.logger.error(f"Error creating rule group {rule_group_name}: {e}")
                raise AWSServiceError(f"Failed to create rule group: {str(e)}", "Network Firewall")

    def delete_rule_group(
        self,
        rule_group_name: str,
        rule_group_arn: Optional[str] = None,
        type: str = "STATELESS"
    ) -> Dict[str, Any]:
        """
        Delete Network Firewall rule group.

        Args:
            rule_group_name: Name of the rule group
            rule_group_arn: ARN of the rule group (optional)
            type: Rule group type (STATELESS or STATEFUL)

        Returns:
            Delete response

        Raises:
            AWSResourceNotFoundError: If rule group not found
            AWSAccessDeniedError: If access is denied
            AWSServiceError: For other errors
        """
        try:
            delete_params = {
                'Type': type
            }

            if rule_group_arn:
                delete_params['RuleGroupArn'] = rule_group_arn
            else:
                delete_params['RuleGroupName'] = rule_group_name

            response = self.client.delete_rule_group(**delete_params)
            return response

        except ClientError as e:
            error_code = e.response.get('Error', {}).get('Code', '')

            if error_code == 'ResourceNotFoundException':
                raise AWSResourceNotFoundError("Rule Group", rule_group_name)
            elif error_code in ['AccessDeniedException', 'UnauthorizedException']:
                raise AWSAccessDeniedError(f"Access denied to delete rule group: {rule_group_name}")
            elif error_code == 'InvalidRequestException':
                raise AWSServiceError(
                    f"Cannot delete rule group {rule_group_name}: {str(e)}",
                    "Network Firewall"
                )
            else:
                self.logger.error(f"Error deleting rule group {rule_group_name}: {e}")
                raise AWSServiceError(f"Failed to delete rule group: {str(e)}", "Network Firewall")

    def associate_subnets(
        self,
        firewall_name: str,
        subnet_mappings: List[Dict[str, str]]
    ) -> Dict[str, Any]:
        """
        Associate subnets with a firewall.

        Args:
            firewall_name: Name of the firewall
            subnet_mappings: List of subnet mappings

        Returns:
            Association response

        Raises:
            AWSResourceNotFoundError: If firewall not found
            AWSAccessDeniedError: If access is denied
            AWSServiceError: For other errors
        """
        try:
            response = self.client.associate_subnets(
                FirewallName=firewall_name,
                SubnetMappings=subnet_mappings
            )
            return response

        except ClientError as e:
            error_code = e.response.get('Error', {}).get('Code', '')

            if error_code == 'ResourceNotFoundException':
                raise AWSResourceNotFoundError("Firewall", firewall_name)
            elif error_code in ['AccessDeniedException', 'UnauthorizedException']:
                raise AWSAccessDeniedError(f"Access denied to associate subnets with firewall: {firewall_name}")
            else:
                self.logger.error(f"Error associating subnets with firewall {firewall_name}: {e}")
                raise AWSServiceError(f"Failed to associate subnets: {str(e)}", "Network Firewall")

    def disassociate_subnets(
        self,
        firewall_name: str,
        subnet_ids: List[str]
    ) -> Dict[str, Any]:
        """
        Disassociate subnets from a firewall.

        Args:
            firewall_name: Name of the firewall
            subnet_ids: List of subnet IDs to disassociate

        Returns:
            Disassociation response

        Raises:
            AWSResourceNotFoundError: If firewall not found
            AWSAccessDeniedError: If access is denied
            AWSServiceError: For other errors
        """
        try:
            response = self.client.disassociate_subnets(
                FirewallName=firewall_name,
                SubnetIds=subnet_ids
            )
            return response

        except ClientError as e:
            error_code = e.response.get('Error', {}).get('Code', '')

            if error_code == 'ResourceNotFoundException':
                raise AWSResourceNotFoundError("Firewall", firewall_name)
            elif error_code in ['AccessDeniedException', 'UnauthorizedException']:
                raise AWSAccessDeniedError(f"Access denied to disassociate subnets from firewall: {firewall_name}")
            else:
                self.logger.error(f"Error disassociating subnets from firewall {firewall_name}: {e}")
                raise AWSServiceError(f"Failed to disassociate subnets: {str(e)}", "Network Firewall")
