"""
AWS Client Wrappers

Provides typed wrappers around boto3 clients for better error handling and testability.
"""

from .session_manager import AWSSessionManager
from .waf_client import WAFClient
from .firewall_client import FirewallClient

__all__ = ['AWSSessionManager', 'WAFClient', 'FirewallClient']
