"""
WAF Client Wrapper

Typed wrapper around boto3 WAFv2 client with enhanced error handling.
"""

import logging
from typing import Dict, List, Any, Optional
from botocore.exceptions import ClientError

from .session_manager import AWSSessionManager
from ..exceptions import (
    AWSResourceNotFoundError,
    AWSAccessDeniedError,
    AWSServiceError
)


class WAFClient:
    """
    Wrapper around AWS WAFv2 client.

    Provides:
    - Enhanced error handling
    - Type hints
    - Consistent error messages
    - Logging
    """

    def __init__(self, scope: str = "REGIONAL", region: Optional[str] = None):
        """
        Initialize WAF client.

        Args:
            scope: WAF scope (REGIONAL or CLOUDFRONT)
            region: AWS region (defaults to session manager region)
        """
        self.logger = logging.getLogger(self.__class__.__name__)
        self.session_manager = AWSSessionManager()
        self.scope = scope
        self.region = region or self.session_manager.get_region()
        self._client = None

    @property
    def client(self):
        """Get or create WAFv2 client (lazy initialization)."""
        if self._client is None:
            self._client = self.session_manager.get_client('wafv2', self.region)
        return self._client

    def get_web_acl(self, name: str, scope: Optional[str] = None) -> Dict[str, Any]:
        """
        Get Web ACL by name.

        Args:
            name: Web ACL name
            scope: WAF scope (defaults to instance scope)

        Returns:
            Web ACL configuration

        Raises:
            AWSResourceNotFoundError: If Web ACL not found
            AWSAccessDeniedError: If access is denied
            AWSServiceError: For other errors
        """
        try:
            response = self.client.list_web_acls(
                Scope=scope or self.scope,
                Limit=100
            )

            for acl in response.get('WebACLs', []):
                if acl['Name'] == name:
                    # Get full Web ACL details
                    detail_response = self.client.get_web_acl(
                        Name=name,
                        Scope=scope or self.scope,
                        Id=acl['Id']
                    )
                    return detail_response.get('WebACL', {})

            raise AWSResourceNotFoundError("Web ACL", name)

        except ClientError as e:
            error_code = e.response.get('Error', {}).get('Code', '')

            if error_code == 'WAFNonexistentItemException':
                raise AWSResourceNotFoundError("Web ACL", name)
            elif error_code in ['AccessDeniedException', 'UnauthorizedException']:
                raise AWSAccessDeniedError(f"Access denied to Web ACL: {name}")
            else:
                self.logger.error(f"Error getting Web ACL {name}: {e}")
                raise AWSServiceError(f"Failed to get Web ACL: {str(e)}", "WAFv2")

    def list_web_acls(self, scope: Optional[str] = None) -> List[Dict[str, Any]]:
        """
        List all Web ACLs.

        Args:
            scope: WAF scope (defaults to instance scope)

        Returns:
            List of Web ACL summaries

        Raises:
            AWSAccessDeniedError: If access is denied
            AWSServiceError: For other errors
        """
        try:
            response = self.client.list_web_acls(
                Scope=scope or self.scope,
                Limit=100
            )
            return response.get('WebACLs', [])

        except ClientError as e:
            error_code = e.response.get('Error', {}).get('Code', '')

            if error_code in ['AccessDeniedException', 'UnauthorizedException']:
                raise AWSAccessDeniedError("Access denied to list Web ACLs")
            else:
                self.logger.error(f"Error listing Web ACLs: {e}")
                raise AWSServiceError(f"Failed to list Web ACLs: {str(e)}", "WAFv2")

    def update_web_acl(
        self,
        name: str,
        acl_id: str,
        lock_token: str,
        rules: List[Dict[str, Any]],
        default_action: Dict[str, Any],
        scope: Optional[str] = None,
        **kwargs
    ) -> Dict[str, Any]:
        """
        Update Web ACL configuration.

        Args:
            name: Web ACL name
            acl_id: Web ACL ID
            lock_token: Lock token for optimistic locking
            rules: List of WAF rules
            default_action: Default action configuration
            scope: WAF scope (defaults to instance scope)
            **kwargs: Additional Web ACL parameters

        Returns:
            Update response with new lock token

        Raises:
            AWSResourceNotFoundError: If Web ACL not found
            AWSAccessDeniedError: If access is denied
            AWSServiceError: For other errors
        """
        try:
            response = self.client.update_web_acl(
                Name=name,
                Scope=scope or self.scope,
                Id=acl_id,
                LockToken=lock_token,
                Rules=rules,
                DefaultAction=default_action,
                **kwargs
            )
            return response

        except ClientError as e:
            error_code = e.response.get('Error', {}).get('Code', '')

            if error_code == 'WAFNonexistentItemException':
                raise AWSResourceNotFoundError("Web ACL", name)
            elif error_code in ['AccessDeniedException', 'UnauthorizedException']:
                raise AWSAccessDeniedError(f"Access denied to update Web ACL: {name}")
            elif error_code == 'WAFOptimisticLockException':
                raise AWSServiceError(
                    f"Web ACL {name} was modified. Please retry with updated lock token.",
                    "WAFv2"
                )
            else:
                self.logger.error(f"Error updating Web ACL {name}: {e}")
                raise AWSServiceError(f"Failed to update Web ACL: {str(e)}", "WAFv2")

    def list_available_managed_rule_groups(
        self,
        scope: Optional[str] = None
    ) -> List[Dict[str, Any]]:
        """
        List available AWS managed rule groups.

        Args:
            scope: WAF scope (defaults to instance scope)

        Returns:
            List of available managed rule groups

        Raises:
            AWSServiceError: If operation fails
        """
        try:
            response = self.client.list_available_managed_rule_groups(
                Scope=scope or self.scope
            )
            return response.get('ManagedRuleGroups', [])

        except ClientError as e:
            self.logger.error(f"Error listing managed rule groups: {e}")
            raise AWSServiceError(
                f"Failed to list managed rule groups: {str(e)}",
                "WAFv2"
            )

    def get_rule_group(self, name: str, scope: Optional[str] = None, vendor_name: str = "AWS") -> Dict[str, Any]:
        """
        Get managed rule group details.

        Args:
            name: Rule group name
            scope: WAF scope (defaults to instance scope)
            vendor_name: Vendor name (default: AWS)

        Returns:
            Rule group configuration

        Raises:
            AWSResourceNotFoundError: If rule group not found
            AWSServiceError: For other errors
        """
        try:
            response = self.client.describe_managed_rule_group(
                VendorName=vendor_name,
                Name=name,
                Scope=scope or self.scope
            )
            return response

        except ClientError as e:
            error_code = e.response.get('Error', {}).get('Code', '')

            if error_code == 'WAFNonexistentItemException':
                raise AWSResourceNotFoundError("Rule Group", name)
            else:
                self.logger.error(f"Error getting rule group {name}: {e}")
                raise AWSServiceError(f"Failed to get rule group: {str(e)}", "WAFv2")
