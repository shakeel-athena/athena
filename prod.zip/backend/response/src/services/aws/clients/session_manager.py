"""
AWS Session Manager

Centralized AWS session and credential management.
Provides singleton pattern for AWS session to avoid credential duplication.
"""

import os
import logging
from typing import Optional, Dict, Any
import boto3
from botocore.exceptions import ClientError, NoCredentialsError, PartialCredentialsError

from ..exceptions import AWSCredentialsError, AWSConnectionError


class AWSSessionManager:
    """
    Manages AWS sessions and credentials.

    Provides centralized session management with:
    - Singleton pattern for session reuse
    - Credential validation
    - Region configuration
    - Client caching
    """

    _instance: Optional['AWSSessionManager'] = None
    _session: Optional[boto3.Session] = None
    _clients: Dict[str, Any] = {}

    def __new__(cls):
        """Singleton pattern - only one instance exists."""
        if cls._instance is None:
            cls._instance = super().__new__(cls)
        return cls._instance

    def __init__(self):
        """Initialize the session manager."""
        if not hasattr(self, '_initialized'):
            self.logger = logging.getLogger(self.__class__.__name__)
            self._region = os.getenv('AWS_REGION', 'us-east-2')
            self._initialized = True

    def get_session(self) -> boto3.Session:
        """
        Get or create AWS session.

        Returns:
            boto3.Session instance

        Raises:
            AWSCredentialsError: If credentials are not configured
        """
        if self._session is None:
            try:
                self._session = boto3.Session(region_name=self._region)
                # Validate credentials by attempting to get caller identity
                sts = self._session.client('sts')
                sts.get_caller_identity()
                self.logger.info(f"AWS session created successfully for region: {self._region}")
            except (NoCredentialsError, PartialCredentialsError) as e:
                self.logger.error(f"AWS credentials error: {e}")
                raise AWSCredentialsError(f"AWS credentials not found: {str(e)}")
            except ClientError as e:
                self.logger.error(f"AWS client error during session creation: {e}")
                raise AWSCredentialsError(f"AWS credentials invalid: {str(e)}")
            except Exception as e:
                self.logger.error(f"Unexpected error creating AWS session: {e}")
                raise AWSConnectionError(f"Failed to create AWS session: {str(e)}")

        return self._session

    def get_client(self, service_name: str, region: Optional[str] = None) -> Any:
        """
        Get or create AWS client for a specific service.

        Args:
            service_name: AWS service name (e.g., 'wafv2', 'network-firewall', 'secretsmanager')
            region: Optional region override

        Returns:
            Boto3 client for the service

        Raises:
            AWSCredentialsError: If credentials are not configured
            AWSConnectionError: If client creation fails
        """
        # Use provided region or default
        client_region = region or self._region
        cache_key = f"{service_name}:{client_region}"

        # Return cached client if exists
        if cache_key in self._clients:
            return self._clients[cache_key]

        try:
            session = self.get_session()
            client = session.client(service_name, region_name=client_region)
            self._clients[cache_key] = client
            self.logger.info(f"Created AWS client for {service_name} in {client_region}")
            return client
        except (NoCredentialsError, PartialCredentialsError) as e:
            self.logger.error(f"Credentials error creating {service_name} client: {e}")
            raise AWSCredentialsError(f"Cannot create {service_name} client: {str(e)}")
        except ClientError as e:
            self.logger.error(f"Client error creating {service_name} client: {e}")
            raise AWSConnectionError(f"Failed to create {service_name} client: {str(e)}")
        except Exception as e:
            self.logger.error(f"Unexpected error creating {service_name} client: {e}")
            raise AWSConnectionError(f"Unexpected error with {service_name}: {str(e)}")

    def validate_credentials(self) -> Dict[str, Any]:
        """
        Validate AWS credentials and get account information.

        Returns:
            Dictionary with account information

        Raises:
            AWSCredentialsError: If credentials are invalid
        """
        try:
            session = self.get_session()
            sts = session.client('sts')
            identity = sts.get_caller_identity()

            return {
                'valid': True,
                'account_id': identity.get('Account'),
                'arn': identity.get('Arn'),
                'user_id': identity.get('UserId'),
                'region': self._region
            }
        except Exception as e:
            self.logger.error(f"Credential validation failed: {e}")
            raise AWSCredentialsError(f"Credential validation failed: {str(e)}")

    def get_region(self) -> str:
        """Get current AWS region."""
        return self._region

    def set_region(self, region: str):
        """
        Set AWS region (clears cached session and clients).

        Args:
            region: AWS region code (e.g., 'us-east-1')
        """
        if region != self._region:
            self.logger.info(f"Changing AWS region from {self._region} to {region}")
            self._region = region
            self._session = None
            self._clients = {}

    def clear_cache(self):
        """Clear cached session and clients (useful for testing or credential rotation)."""
        self.logger.info("Clearing AWS session and client cache")
        self._session = None
        self._clients = {}

    @classmethod
    def reset_singleton(cls):
        """Reset singleton instance (useful for testing)."""
        cls._instance = None
        cls._session = None
        cls._clients = {}
