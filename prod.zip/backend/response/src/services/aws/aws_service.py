"""
AWS Service

Centralized AWS service that provides unified access to AWS client wrappers.
Implements BaseService interface for consistency with other services.
"""

import logging
from typing import Dict, Any, Optional
from datetime import datetime

from ..base_service import BaseService, OperationResult
from .clients.session_manager import AWSSessionManager
from .clients.waf_client import WAFClient
from .clients.firewall_client import FirewallClient
from .exceptions import (
    AWSCredentialsError,
    AWSConnectionError,
    AWSServiceError
)


class AWSService(BaseService):
    """
    Centralized AWS service providing access to AWS client wrappers.
    
    This service acts as a facade for all AWS operations, providing:
    - Unified credential management
    - Centralized client access
    - Health monitoring for AWS services
    - Consistent error handling
    - Performance tracking
    """
    
    def __init__(self, 
                 config_service=None,
                 cache_service=None,
                 audit_service=None,
                 region: Optional[str] = None):
        """
        Initialize AWS Service.
        
        Args:
            config_service: Configuration service instance
            cache_service: Cache service instance
            audit_service: Audit service instance
            region: AWS region override
        """
        super().__init__(
            config_service=config_service,
            cache_service=cache_service,
            audit_service=audit_service
        )
        
        # AWS session management
        self.session_manager = AWSSessionManager()
        if region:
            self.session_manager.set_region(region)
        
        # Client instances (lazy initialization)
        self._waf_client: Optional[WAFClient] = None
        self._firewall_client: Optional[FirewallClient] = None
        self._secrets_client: Optional[Any] = None  # Will be added in Task 5
        
        # Service state
        self._initialized = False
        self._credential_info: Optional[Dict[str, Any]] = None
        
        self.logger.info(f"AWSService initialized for region: {self.session_manager.get_region()}")
    
    def initialize_sync(self) -> None:
        """Initialize the AWS service synchronously and validate credentials."""
        try:
            # Validate AWS credentials
            self._credential_info = self.validate_credentials()
            self._initialized = True

            self.logger.info(
                f"AWSService initialized successfully - Account: {self._credential_info.get('account_id')}"
            )

        except Exception as e:
            self.logger.error(f"Failed to initialize AWSService: {e}")
            raise AWSServiceError(f"AWSService initialization failed: {str(e)}", "AWS")

    async def initialize(self) -> None:
        """Initialize the AWS service asynchronously and validate credentials."""
        try:
            # Validate AWS credentials
            self._credential_info = self.validate_credentials()
            self._initialized = True

            self.logger.info(
                f"AWSService initialized successfully - Account: {self._credential_info.get('account_id')}"
            )

        except Exception as e:
            self.logger.error(f"Failed to initialize AWSService: {e}")
            raise AWSServiceError(f"AWSService initialization failed: {str(e)}", "AWS")
    
    def get_waf_client(self, scope: str = "REGIONAL") -> WAFClient:
        """
        Get WAF client wrapper.
        
        Args:
            scope: WAF scope (REGIONAL or CLOUDFRONT)
            
        Returns:
            WAFClient instance
        """
        if not self._initialized:
            raise AWSServiceError("AWSService not initialized. Call initialize() first.", "AWS")
        
        if self._waf_client is None or self._waf_client.scope != scope:
            self._waf_client = WAFClient(scope=scope, region=self.session_manager.get_region())
            self.logger.debug(f"Created WAF client with scope: {scope}")
        
        return self._waf_client
    
    def get_firewall_client(self) -> FirewallClient:
        """
        Get Network Firewall client wrapper.
        
        Returns:
            FirewallClient instance
        """
        if not self._initialized:
            raise AWSServiceError("AWSService not initialized. Call initialize() first.", "AWS")
        
        if self._firewall_client is None:
            self._firewall_client = FirewallClient(region=self.session_manager.get_region())
            self.logger.debug("Created Network Firewall client")
        
        return self._firewall_client
    
    def get_secrets_client(self):
        """
        Get Secrets Manager client wrapper.
        
        Returns:
            SecretsClient instance (will be implemented in Task 5)
        """
        if not self._initialized:
            raise AWSServiceError("AWSService not initialized. Call initialize() first.", "AWS")
        
        if self._secrets_client is None:
            # This will be implemented in Task 5
            raise NotImplementedError("Secrets client will be implemented in Task 5")
        
        return self._secrets_client
    
    def validate_credentials(self) -> Dict[str, Any]:
        """
        Validate AWS credentials and get account information.
        
        Returns:
            Dictionary with credential validation results
        """
        try:
            credential_info = self.session_manager.validate_credentials()
            self._credential_info = credential_info
            return credential_info
            
        except Exception as e:
            self.logger.error(f"AWS credential validation failed: {e}")
            raise AWSCredentialsError(f"AWS credential validation failed: {str(e)}")
    
    def get_region(self) -> str:
        """Get current AWS region."""
        return self.session_manager.get_region()
    
    def set_region(self, region: str) -> None:
        """
        Set AWS region and reset clients.
        
        Args:
            region: AWS region code
        """
        self.logger.info(f"Changing AWS region to: {region}")
        self.session_manager.set_region(region)
        
        # Reset clients to force re-creation with new region
        self._waf_client = None
        self._firewall_client = None
        self._secrets_client = None
    
    async def health_check(self) -> Dict[str, Any]:
        """
        Perform comprehensive health check for AWS services.
        
        Returns:
            Health check information for all AWS services
        """
        base_health = await super().health_check()
        
        health_info = {
            'aws_service': {
                'initialized': self._initialized,
                'region': self.get_region(),
                'credentials_valid': False,
                'account_info': None,
                'clients': {
                    'waf_client': self._waf_client is not None,
                    'firewall_client': self._firewall_client is not None,
                    'secrets_client': self._secrets_client is not None
                },
                'services_status': {}
            }
        }
        
        if self._initialized:
            try:
                # Test credential validation
                credential_info = self.validate_credentials()
                health_info['aws_service']['credentials_valid'] = True
                health_info['aws_service']['account_info'] = {
                    'account_id': credential_info.get('account_id'),
                    'arn': credential_info.get('arn'),
                    'user_id': credential_info.get('user_id')
                }
                
                # Test individual service health
                health_info['aws_service']['services_status'] = await self._check_service_health()
                
            except Exception as e:
                health_info['aws_service']['error'] = str(e)
                self.logger.error(f"AWS health check failed: {e}")
        
        base_health.update(health_info)
        return base_health
    
    async def _check_service_health(self) -> Dict[str, Any]:
        """Check health of individual AWS services."""
        services_health = {}
        
        # Test WAF service
        try:
            waf_client = self.get_waf_client()
            # Try to list Web ACLs as a health check
            waf_client.list_web_acls()
            services_health['waf'] = {'status': 'healthy', 'message': 'WAF service accessible'}
        except Exception as e:
            services_health['waf'] = {'status': 'unhealthy', 'error': str(e)}
        
        # Test Network Firewall service
        try:
            firewall_client = self.get_firewall_client()
            # Try to list rule groups as a health check
            firewall_client.list_rule_groups()
            services_health['network_firewall'] = {'status': 'healthy', 'message': 'Network Firewall service accessible'}
        except Exception as e:
            services_health['network_firewall'] = {'status': 'unhealthy', 'error': str(e)}
        
        # Test Secrets Manager service (placeholder)
        services_health['secrets_manager'] = {'status': 'not_implemented', 'message': 'Will be implemented in Task 5'}
        
        return services_health
    
    def get_service_info(self) -> Dict[str, Any]:
        """
        Get information about the AWS service.
        
        Returns:
            Service information including capabilities and configuration
        """
        return {
            'service_name': 'AWSService',
            'version': '1.0.0',
            'description': 'Centralized AWS service providing access to AWS client wrappers',
            'capabilities': [
                'WAFv2 operations',
                'Network Firewall operations',
                'Credential management',
                'Region management',
                'Health monitoring'
            ],
            'configuration': {
                'region': self.get_region(),
                'initialized': self._initialized,
                'credential_info': self._credential_info
            },
            'clients': {
                'waf_client': {
                    'available': self._waf_client is not None,
                    'scope': self._waf_client.scope if self._waf_client else None
                },
                'firewall_client': {
                    'available': self._firewall_client is not None,
                    'region': self._firewall_client.region if self._firewall_client else None
                },
                'secrets_client': {
                    'available': False,
                    'message': 'Will be implemented in Task 5'
                }
            },
            'performance_metrics': {
                'total_operations': self._operation_count,
                'total_errors': self._error_count,
                'error_rate': (self._error_count / max(self._operation_count, 1)) * 100
            }
        }
    
    async def test_connectivity(self) -> OperationResult:
        """
        Test connectivity to all AWS services.
        
        Returns:
            Operation result with connectivity test results
        """
        async with self.operation_context("test_aws_connectivity"):
            try:
                results = {}
                
                # Test WAF connectivity
                try:
                    waf_client = self.get_waf_client()
                    waf_client.list_web_acls()
                    results['waf'] = {'status': 'success', 'message': 'WAF service accessible'}
                except Exception as e:
                    results['waf'] = {'status': 'error', 'error': str(e)}
                
                # Test Network Firewall connectivity
                try:
                    firewall_client = self.get_firewall_client()
                    firewall_client.list_rule_groups()
                    results['network_firewall'] = {'status': 'success', 'message': 'Network Firewall service accessible'}
                except Exception as e:
                    results['network_firewall'] = {'status': 'error', 'error': str(e)}
                
                # Test credential validation
                try:
                    credential_info = self.validate_credentials()
                    results['credentials'] = {'status': 'success', 'account_id': credential_info.get('account_id')}
                except Exception as e:
                    results['credentials'] = {'status': 'error', 'error': str(e)}
                
                # Overall success if all critical services are accessible
                overall_success = all(
                    result.get('status') == 'success' 
                    for service, result in results.items() 
                    if service in ['credentials', 'waf', 'network_firewall']
                )
                
                message = "AWS connectivity test completed successfully" if overall_success else "Some AWS services are inaccessible"
                
                return OperationResult.success_result(
                    data=results,
                    message=message
                )
                
            except Exception as e:
                self.logger.error(f"AWS connectivity test failed: {e}")
                return OperationResult.failure_result(
                    message=f"AWS connectivity test failed: {str(e)}",
                    error_code="AWS_CONNECTIVITY_ERROR"
                )
    
    def reset_clients(self) -> None:
        """Reset all client instances (useful for testing or credential rotation)."""
        self.logger.info("Resetting all AWS clients")
        self._waf_client = None
        self._firewall_client = None
        self._secrets_client = None
        self.session_manager.clear_cache()
    
    async def cleanup(self) -> None:
        """Cleanup resources and reset service state."""
        self.logger.info("Cleaning up AWSService")
        self.reset_clients()
        self._initialized = False
        self._credential_info = None
        await super().cleanup()
