"""
AWS-Specific Exceptions

Custom exception classes for AWS operations.
"""

from errors.error_types import ExternalServiceError


class AWSServiceError(ExternalServiceError):
    """Base exception for AWS service errors."""

    def __init__(self, message: str, service_name: str = "AWS", **kwargs):
        super().__init__(
            message=message,
            service_name=service_name,
            **kwargs
        )


class AWSCredentialsError(AWSServiceError):
    """Raised when AWS credentials are invalid or missing."""

    def __init__(self, message: str = "AWS credentials not configured properly", **kwargs):
        super().__init__(message, service_name="AWS Credentials", **kwargs)


class AWSAccessDeniedError(AWSServiceError):
    """Raised when AWS access is denied due to insufficient permissions."""

    def __init__(self, message: str = "AWS access denied. Check IAM permissions.", **kwargs):
        super().__init__(message, service_name="AWS IAM", **kwargs)


class AWSResourceNotFoundError(AWSServiceError):
    """Raised when an AWS resource is not found."""

    def __init__(self, resource_type: str, resource_name: str, **kwargs):
        message = f"{resource_type} '{resource_name}' not found in AWS"
        super().__init__(message, service_name=f"AWS {resource_type}", **kwargs)


class AWSConnectionError(AWSServiceError):
    """Raised when connection to AWS service fails."""

    def __init__(self, message: str = "AWS service connection timeout", **kwargs):
        super().__init__(message, service_name="AWS Connection", **kwargs)


class AWSRegionNotAvailableError(AWSServiceError):
    """Raised when AWS service is not available in the specified region."""

    def __init__(self, service_name: str, region: str, **kwargs):
        message = f"{service_name} not available in region {region}"
        super().__init__(message, service_name=f"AWS {service_name}", **kwargs)
