"""
Service Factory

Manages the registration and lifecycle of all services in the Athena backend.
Handles dependency injection, service initialization, and configuration.
"""

import logging
from typing import Dict, Type, Any, Optional, List, Callable
from datetime import datetime
import asyncio

from .di.container import DIContainer, ServiceLifetime
from .base_service import BaseService
import sys
import os
# Add the current directory to Python path to ensure we get the right config
current_dir = os.path.dirname(os.path.abspath(__file__))
parent_dir = os.path.dirname(current_dir)
if parent_dir not in sys.path:
    sys.path.insert(0, parent_dir)

# Use direct module import to avoid conflicts
sys.path.insert(0, os.path.join(parent_dir, 'config'))
from configuration_service import ConfigurationService, get_configuration_service
from errors.error_types import ServiceError, ConfigurationError, InitializationError

# Import all service classes
from .firewall_service import FirewallService
# TODO: Import other services as they are created
# from .waf_service import WAFService
# from .alerts_service import AlertsService
# from .audit_service import AuditService
# from .cache_service import CacheService
# from .aws_service import AWSService


class ServiceFactory:
    """
    Factory for managing service registration and lifecycle.
    
    Provides centralized service management with dependency injection,
    configuration management, and automatic service initialization.
    """
    
    def __init__(self, configuration_service: ConfigurationService = None):
        """
        Initialize service factory.
        
        Args:
            configuration_service: Configuration service instance
        """
        self._config_service = configuration_service or get_configuration_service()
        self._container = DIContainer()
        self._logger = logging.getLogger(f"{__name__}.{self.__class__.__name__}")
        self._initialized_services: List[str] = []
        self._service_configs: Dict[str, Dict[str, Any]] = {}
        self._initialization_order: List[str] = []
        
        # Service health tracking
        self._service_health: Dict[str, Dict[str, Any]] = {}
        self._last_health_check = None
        self._health_check_interval = 300  # 5 minutes
    
    async def initialize(self) -> None:
        """Initialize the service factory and all registered services."""
        self._logger.info("Initializing service factory...")
        
        try:
            # Ensure configuration service is initialized
            if not self._config_service.is_healthy():
                raise ConfigurationError("Configuration service is not healthy")
            
            # Register core services
            await self._register_core_services()
            
            # Register domain services
            await self._register_domain_services()
            
            # Register utility services
            await self._register_utility_services()
            
            # Initialize services in dependency order
            await self._initialize_services()
            
            self._logger.info("Service factory initialized successfully")
            
        except Exception as e:
            self._logger.error(f"Failed to initialize service factory: {str(e)}")
            raise InitializationError(f"Service factory initialization failed: {str(e)}")
    
    async def _register_core_services(self) -> None:
        """Register core infrastructure services."""
        self._logger.info("Registering core services...")
        
        # Register configuration service (singleton)
        self._container.register_singleton(
            ConfigurationService,
            factory=lambda: self._config_service
        )
        
        # TODO: Register other core services as they are implemented
        # Example:
        # from .cache_service import CacheService
        # self._container.register_singleton(CacheService)
        
        # from .audit_service import AuditService
        # self._container.register_singleton(AuditService)
        
        # from .aws_service import AWSService
        # self._container.register_singleton(AWSService)
    
    async def _register_domain_services(self) -> None:
        """Register domain-specific services."""
        self._logger.info("Registering domain services...")
        
        # Register firewall service (singleton)
        self._container.register_singleton(FirewallService)
        
        # TODO: Register other domain services as they are implemented
        # Example:
        # self._container.register_singleton(WAFService)
        # self._container.register_singleton(AlertsService)
    
    async def _register_utility_services(self) -> None:
        """Register utility and helper services."""
        self._logger.info("Registering utility services...")
        
        # TODO: Register utility services as they are implemented
        # Example:
        # from .metrics_service import MetricsService
        # self._container.register_singleton(MetricsService)
        
        # from .notification_service import NotificationService
        # self._container.register_singleton(NotificationService)
    
    async def _initialize_services(self) -> None:
        """Initialize all registered services in dependency order."""
        self._logger.info("Initializing services...")
        
        # Determine initialization order based on dependencies
        self._initialization_order = self._determine_initialization_order()
        
        # Initialize each service
        for service_name in self._initialization_order:
            try:
                service = self._container.resolve(self._get_service_type(service_name))
                
                if isinstance(service, BaseService):
                    await service.initialize()
                    self._initialized_services.append(service_name)
                    
                    # Initial health check
                    health = await service.health_check()
                    self._service_health[service_name] = {
                        'status': 'healthy',
                        'last_check': datetime.utcnow(),
                        'health_data': health
                    }
                    
                    self._logger.info(f"Initialized service: {service_name}")
                else:
                    self._logger.warning(f"Service {service_name} does not extend BaseService")
                    
            except Exception as e:
                self._logger.error(f"Failed to initialize service {service_name}: {str(e)}")
                self._service_health[service_name] = {
                    'status': 'error',
                    'last_check': datetime.utcnow(),
                    'error': str(e)
                }
                # Continue initializing other services
                continue
        
        self._logger.info(f"Initialized {len(self._initialized_services)} services")
    
    def _determine_initialization_order(self) -> List[str]:
        """
        Determine service initialization order based on dependencies.
        
        Returns:
            List of service names in initialization order
        """
        # For now, use a simple order
        # In a more complex implementation, this would analyze actual dependencies
        return [
            'configuration_service',
            'cache_service',  # TODO: when implemented
            'audit_service',  # TODO: when implemented
            'aws_service',    # TODO: when implemented
            'firewall_service',
            'waf_service',    # TODO: when implemented
            'alerts_service', # TODO: when implemented
        ]
    
    def _get_service_type(self, service_name: str) -> Type:
        """Get service type by name."""
        service_map = {
            'configuration_service': ConfigurationService,
            'firewall_service': FirewallService,
            # TODO: Add other services as they are implemented
            # 'waf_service': WAFService,
            # 'alerts_service': AlertsService,
            # 'cache_service': CacheService,
            # 'audit_service': AuditService,
            # 'aws_service': AWSService,
        }
        
        if service_name not in service_map:
            raise ServiceError(f"Unknown service: {service_name}")
        
        return service_map[service_name]
    
    def get_service(self, service_type: Type) -> Any:
        """
        Get a service instance from the DI container.
        
        Args:
            service_type: Type of service to resolve
            
        Returns:
            Service instance
            
        Raises:
            ServiceError: If service cannot be resolved
        """
        try:
            return self._container.resolve(service_type)
        except Exception as e:
            raise ServiceError(f"Failed to resolve service {service_type.__name__}: {str(e)}")
    
    def get_service_by_name(self, service_name: str) -> Any:
        """
        Get a service instance by name.
        
        Args:
            service_name: Name of the service
            
        Returns:
            Service instance
            
        Raises:
            ServiceError: If service cannot be resolved
        """
        service_type = self._get_service_type(service_name)
        return self.get_service(service_type)
    
    async def initialize_service(self, service_name: str) -> None:
        """
        Initialize a specific service.
        
        Args:
            service_name: Name of the service to initialize
        """
        try:
            service = self.get_service_by_name(service_name)
            
            if isinstance(service, BaseService):
                await service.initialize()
                self._initialized_services.append(service_name)
                self._logger.info(f"Initialized service: {service_name}")
            else:
                raise ServiceError(f"Service {service_name} does not extend BaseService")
                
        except Exception as e:
            self._logger.error(f"Failed to initialize service {service_name}: {str(e)}")
            raise ServiceError(f"Failed to initialize service {service_name}: {str(e)}")
    
    async def restart_service(self, service_name: str) -> None:
        """
        Restart a specific service.
        
        Args:
            service_name: Name of the service to restart
        """
        try:
            # Get current service
            service = self.get_service_by_name(service_name)
            
            if isinstance(service, BaseService):
                # Shutdown service
                await service.shutdown()
                
                # Remove from initialized list
                if service_name in self._initialized_services:
                    self._initialized_services.remove(service_name)
                
                # Re-initialize service
                await self.initialize_service(service_name)
                
                self._logger.info(f"Restarted service: {service_name}")
            else:
                raise ServiceError(f"Service {service_name} does not support restart")
                
        except Exception as e:
            self._logger.error(f"Failed to restart service {service_name}: {str(e)}")
            raise ServiceError(f"Failed to restart service {service_name}: {str(e)}")
    
    async def shutdown_all_services(self) -> None:
        """Shutdown all initialized services."""
        self._logger.info("Shutting down all services...")
        
        # Shutdown in reverse initialization order
        for service_name in reversed(self._initialized_services):
            try:
                service = self.get_service_by_name(service_name)
                
                if isinstance(service, BaseService):
                    await service.shutdown()
                    self._logger.info(f"Shutdown service: {service_name}")
                    
            except Exception as e:
                self._logger.error(f"Failed to shutdown service {service_name}: {str(e)}")
                continue
        
        self._initialized_services.clear()
        self._service_health.clear()
        
        self._logger.info("All services shutdown complete")
    
    async def health_check_all_services(self) -> Dict[str, Any]:
        """
        Perform health check on all initialized services.
        
        Returns:
            Dictionary with health status of all services
        """
        now = datetime.utcnow()
        
        # Check if we need to run health checks
        if (self._last_health_check and 
            (now - self._last_health_check).total_seconds() < self._health_check_interval):
            return self._get_cached_health_status()
        
        self._logger.info("Performing health check on all services...")
        
        overall_health = {
            'healthy': True,
            'total_services': len(self._initialized_services),
            'healthy_services': 0,
            'unhealthy_services': 0,
            'services': {},
            'last_check': now.isoformat()
        }
        
        for service_name in self._initialized_services:
            try:
                service = self.get_service_by_name(service_name)
                
                if isinstance(service, BaseService):
                    health = await service.health_check()
                    
                    service_healthy = health.get('healthy', False)
                    if service_healthy:
                        overall_health['healthy_services'] += 1
                    else:
                        overall_health['unhealthy_services'] += 1
                        overall_health['healthy'] = False
                    
                    self._service_health[service_name] = {
                        'status': 'healthy' if service_healthy else 'unhealthy',
                        'last_check': now,
                        'health_data': health
                    }
                    
                    overall_health['services'][service_name] = health
                    
                else:
                    overall_health['services'][service_name] = {
                        'healthy': False,
                        'error': 'Service does not extend BaseService'
                    }
                    overall_health['unhealthy_services'] += 1
                    overall_health['healthy'] = False
                    
            except Exception as e:
                self._logger.error(f"Health check failed for service {service_name}: {str(e)}")
                overall_health['services'][service_name] = {
                    'healthy': False,
                    'error': str(e)
                }
                overall_health['unhealthy_services'] += 1
                overall_health['healthy'] = False
        
        self._last_health_check = now
        return overall_health
    
    def _get_cached_health_status(self) -> Dict[str, Any]:
        """Get cached health status."""
        return {
            'healthy': all(
                health['status'] == 'healthy' 
                for health in self._service_health.values()
            ),
            'total_services': len(self._initialized_services),
            'healthy_services': len([
                s for s in self._service_health.values() 
                if s['status'] == 'healthy'
            ]),
            'unhealthy_services': len([
                s for s in self._service_health.values() 
                if s['status'] != 'healthy'
            ]),
            'services': {
                name: health['health_data'] 
                for name, health in self._service_health.items()
            },
            'last_check': self._last_health_check.isoformat() if self._last_health_check else None,
            'cached': True
        }
    
    def get_service_metrics(self, service_name: str = None) -> Dict[str, Any]:
        """
        Get metrics for services.
        
        Args:
            service_name: Specific service name, or None for all services
            
        Returns:
            Dictionary with service metrics
        """
        if service_name:
            if service_name in self._service_health:
                return {
                    'service': service_name,
                    'health': self._service_health[service_name],
                    'initialized': service_name in self._initialized_services
                }
            else:
                return {
                    'service': service_name,
                    'error': 'Service not found or not initialized'
                }
        
        # Return metrics for all services
        return {
            'total_services': len(self._initialized_services),
            'service_health': self._service_health,
            'container_stats': self._container.get_stats(),
            'initialization_order': self._initialization_order
        }
    
    def list_services(self) -> Dict[str, Any]:
        """List all registered and initialized services."""
        return {
            'registered_services': list(self._container._registrations.keys()),
            'initialized_services': self._initialized_services.copy(),
            'service_types': {
                name: service_type.__name__ 
                for name, service_type in {
                    'configuration_service': ConfigurationService,
                    'firewall_service': FirewallService,
                    # TODO: Add other services
                }.items()
            }
        }
    
    def get_container(self) -> DIContainer:
        """Get the DI container for advanced usage."""
        return self._container
    
    def register_custom_service(self, 
                               service_type: Type, 
                               implementation_type: Type = None,
                               lifetime: ServiceLifetime = ServiceLifetime.SINGLETON,
                               factory: Callable = None) -> None:
        """
        Register a custom service.
        
        Args:
            service_type: Service interface type
            implementation_type: Service implementation type
            lifetime: Service lifetime
            factory: Factory function for creating service
        """
        if lifetime == ServiceLifetime.SINGLETON:
            self._container.register_singleton(service_type, implementation_type, factory)
        elif lifetime == ServiceLifetime.TRANSIENT:
            self._container.register_transient(service_type, implementation_type, factory)
        elif lifetime == ServiceLifetime.SCOPED:
            self._container.register_scoped(service_type, implementation_type, factory)
        
        self._logger.info(f"Registered custom service: {service_type.__name__} (lifetime: {lifetime.name})")
    
    async def __aenter__(self):
        """Async context manager entry."""
        await self.initialize()
        return self
    
    async def __aexit__(self, exc_type, exc_val, exc_tb):
        """Async context manager exit."""
        await self.shutdown_all_services()


# Global service factory instance
_service_factory: Optional[ServiceFactory] = None


def get_service_factory() -> ServiceFactory:
    """Get the global service factory instance."""
    global _service_factory
    if _service_factory is None:
        _service_factory = ServiceFactory()
    return _service_factory


def set_service_factory(factory: ServiceFactory) -> None:
    """Set the global service factory instance."""
    global _service_factory
    _service_factory = factory


async def initialize_service_factory() -> ServiceFactory:
    """Initialize and return the global service factory."""
    factory = get_service_factory()
    await factory.initialize()
    return factory


# Convenience functions for getting specific services
def get_firewall_service() -> FirewallService:
    """Get the firewall service."""
    return get_service_factory().get_service(FirewallService)


def get_configuration_service() -> ConfigurationService:
    """Get the configuration service."""
    return get_service_factory().get_service(ConfigurationService)


# TODO: Add convenience functions for other services as they are implemented
# def get_waf_service() -> WAFService:
#     return get_service_factory().get_service(WAFService)
