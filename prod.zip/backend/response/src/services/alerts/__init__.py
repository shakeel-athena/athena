"""
Alerts Service Module

Provides unified alert management from multiple sources (Wazuh, Suricata, Elasticsearch).
"""

from .alerts_service import AlertsService

__all__ = ['AlertsService']
