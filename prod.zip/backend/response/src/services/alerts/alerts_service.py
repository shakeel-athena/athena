"""
Alerts Service

Handles all alert-related operations providing a unified interface
for alerts from Wazuh, Suricata, and Elasticsearch sources.
"""

import logging
from typing import Dict, List, Any, Optional
from datetime import datetime
from collections import defaultdict

from services.base_service import BaseService
from errors.error_types import (
    ValidationError,
    ServiceError,
    ExternalServiceError
)


class AlertsService(BaseService):
    """
    Service for managing and retrieving security alerts from multiple sources.

    Provides high-level operations for:
    - Unified alert retrieval from Wazuh and Suricata
    - Alert filtering and sorting
    - Source-specific alert queries
    - Health checking for alert sources
    """

    def __init__(self,
                 unified_alerts_manager=None,
                 config_service=None,
                 cache_service=None,
                 audit_service=None):
        """
        Initialize Alerts service.

        Args:
            unified_alerts_manager: UnifiedAlertsManager instance
            config_service: Configuration service instance
            cache_service: Cache service for performance optimization
            audit_service: Audit service for logging operations
        """
        super().__init__(
            logger=logging.getLogger(self.__class__.__name__),
            config_service=config_service,
            cache_service=cache_service,
            audit_service=audit_service
        )

        # Dependencies
        self._unified_manager = unified_alerts_manager

    def _get_unified_manager(self):
        """Lazy initialization of unified alerts manager."""
        if self._unified_manager is None:
            import sys
            import os

            # Add alerts to path
            backend_root = os.path.abspath(os.path.join(os.path.dirname(__file__), "../../.."))
            alerts_path = os.path.join(backend_root, "alerts")
            if alerts_path not in sys.path:
                sys.path.insert(0, alerts_path)

            from alerts.unified_alerts import UnifiedAlertsManager
            self._unified_manager = UnifiedAlertsManager()

        return self._unified_manager

    def test_wazuh_connection(self) -> Dict[str, Any]:
        """
        Test connection to Wazuh alert source.

        Returns:
            Dictionary with connection test results
        """
        try:
            manager = self._get_unified_manager()
            connection_status = manager.test_connections()

            return {
                "success": connection_status.get("wazuh", False),
                "message": "Wazuh connection successful" if connection_status.get("wazuh") else "Wazuh connection failed"
            }
        except Exception as e:
            self.logger.error(f"Failed to test Wazuh connection: {e}")
            return {
                "success": False,
                "message": f"Wazuh connection test failed: {str(e)}"
            }

    def get_unified_alerts(self,
                          limit: Optional[int] = None,
                          offset: Optional[int] = None,
                          time_range_hours: Optional[int] = None,
                          severity: Optional[str] = None,
                          source: Optional[str] = None,
                          analyst: Optional[str] = None,
                          apply_mute_rules: bool = True,
                          search: Optional[str] = None,
                          sort_field: Optional[str] = None,
                          sort_direction: Optional[str] = None) -> Dict[str, Any]:
        """
        Get unified alerts from all sources with optional filtering.

        Args:
            limit: Maximum number of alerts to return
            offset: Number of alerts to skip (for pagination)
            time_range_hours: Time range in hours to look back
            severity: Filter by severity level
            source: Filter by source (wazuh, suricata)
            analyst: Current analyst username (for personal mute scope)
            apply_mute_rules: Whether to filter out muted alerts (default: True)
            search: Search query (supports rule:123, sid:456, ip:192.168.1.1, or free text)
            sort_field: Field to sort by (normalized_severity, timestamp, source)
            sort_direction: Sort direction (asc, desc)

        Returns:
            Dictionary containing alerts and metadata
        """
        try:
            manager = self._get_unified_manager()

            # Get alerts with filtering and sorting
            # The UnifiedAlertsManager uses fetch_all_alerts, not get_alerts
            result = manager.fetch_all_alerts(
                limit_per_source=limit or 20,
                offset=offset or 0,
                time_range_hours=time_range_hours or 720,
                severity_filter=severity,
                source_filter=source,
                return_total=True,
                sort_field=sort_field,
                sort_direction=sort_direction
            )

            alerts = result.get('alerts', [])
            original_count = len(alerts)
            muted_count = 0
            search_filtered_count = 0

            # Apply search query parsing and filtering
            if search and search.strip():
                try:
                    import sys
                    import os

                    # Add utils to path
                    utils_path = os.path.abspath(
                        os.path.join(os.path.dirname(__file__), '../..')
                    )
                    if utils_path not in sys.path:
                        sys.path.insert(0, utils_path)

                    from utils.search_parser import parse_search_query, apply_search_filters

                    # Parse special query formats (rule:, sid:, ip:)
                    parsed_query = parse_search_query(search)
                    before_search_count = len(alerts)
                    alerts = apply_search_filters(alerts, parsed_query)
                    search_filtered_count = before_search_count - len(alerts)

                    self.logger.info(
                        f"Search filters applied: {before_search_count} alerts -> "
                        f"{len(alerts)} matched ({search_filtered_count} filtered out) "
                        f"Query: {parsed_query}"
                    )

                except Exception as search_error:
                    self.logger.warning(f"Failed to apply search filters: {search_error}")
                    # Continue without search filtering

            # Apply mute rules to filter out muted alerts
            if apply_mute_rules and alerts:
                try:
                    import sys
                    import os
                    from flask import g

                    # Add backend/response to path for mute_manager import
                    backend_response_path = os.path.abspath(
                        os.path.join(os.path.dirname(__file__), '../../..')
                    )
                    if backend_response_path not in sys.path:
                        sys.path.insert(0, backend_response_path)

                    from mute_manager import MuteManager

                    # Get database connection from Flask g context
                    db_conn = getattr(g, 'db', None)
                    if db_conn:
                        # Extract raw connection if it's a DatabaseWrapper
                        if hasattr(db_conn, 'conn'):
                            raw_conn = db_conn.conn
                        else:
                            raw_conn = db_conn

                        mute_manager = MuteManager(db_connection=raw_conn)

                        # Apply mute rules with analyst context for personal scope
                        filtered_alerts = mute_manager.apply_mute_rules(
                            alerts=alerts,
                            analyst=analyst,
                            scope='global'  # Can be extended to support personal/team
                        )

                        muted_count = original_count - len(filtered_alerts)
                        alerts = filtered_alerts

                        self.logger.info(
                            f"Mute rules applied: {original_count} alerts -> "
                            f"{len(alerts)} visible ({muted_count} muted)"
                        )
                    else:
                        self.logger.warning("Database connection not available, skipping mute rules")

                except Exception as mute_error:
                    self.logger.warning(f"Failed to apply mute rules: {mute_error}")
                    # Continue without mute filtering rather than failing the entire request

            # Get total count - the UnifiedAlertsManager returns it as 'total', not 'total_count'
            total_count = result.get('total', result.get('metadata', {}).get('total_alerts', 0))

            return {
                "alerts": alerts,
                "count": len(alerts),
                "total": total_count,  # Fixed: was using total_count, now using total
                "muted_count": muted_count,
                "statistics": result.get('statistics', {}),
                "filters_applied": {
                    "limit": limit,
                    "offset": offset,
                    "time_range_hours": time_range_hours,
                    "severity": severity,
                    "source": source,
                    "mute_rules_applied": apply_mute_rules
                }
            }
        except Exception as e:
            self.logger.error(f"Failed to get unified alerts: {e}")
            raise ServiceError(f"Failed to retrieve unified alerts: {str(e)}")

    def get_wazuh_alerts(self,
                        limit: Optional[int] = None,
                        time_range_hours: Optional[int] = None,
                        severity: Optional[str] = None) -> List[Dict[str, Any]]:
        """
        Get alerts from Wazuh source only.

        Args:
            limit: Maximum number of alerts to return
            time_range_hours: Time range in hours to look back
            severity: Filter by severity level

        Returns:
            List of Wazuh alerts
        """
        try:
            manager = self._get_unified_manager()

            alerts = manager.wazuh_manager.get_alerts(
                limit=limit,
                time_range_hours=time_range_hours,
                min_severity=severity
            )

            return alerts
        except Exception as e:
            self.logger.error(f"Failed to get Wazuh alerts: {e}")
            raise ServiceError(f"Failed to retrieve Wazuh alerts: {str(e)}")

    def get_suricata_alerts(self,
                           limit: Optional[int] = None,
                           time_range_hours: Optional[int] = None,
                           severity: Optional[str] = None) -> List[Dict[str, Any]]:
        """
        Get alerts from Suricata source only.

        Args:
            limit: Maximum number of alerts to return
            time_range_hours: Time range in hours to look back
            severity: Filter by severity level

        Returns:
            List of Suricata alerts
        """
        try:
            manager = self._get_unified_manager()

            alerts = manager.suricata_manager.get_alerts(
                limit=limit,
                time_range_hours=time_range_hours,
                min_severity=severity
            )

            return alerts
        except Exception as e:
            self.logger.error(f"Failed to get Suricata alerts: {e}")
            raise ServiceError(f"Failed to retrieve Suricata alerts: {str(e)}")

    def get_alerts_health(self) -> Dict[str, Any]:
        """
        Get health status of all alert sources.

        Returns:
            Dictionary with health status of each source
        """
        try:
            manager = self._get_unified_manager()
            connection_status = manager.test_connections()

            health = {
                "overall_status": "healthy" if all(connection_status.values()) else "degraded",
                "sources": {
                    "wazuh": {
                        "status": "healthy" if connection_status.get("wazuh") else "unhealthy",
                        "connected": connection_status.get("wazuh", False)
                    },
                    "suricata": {
                        "status": "healthy" if connection_status.get("suricata") else "unhealthy",
                        "connected": connection_status.get("suricata", False),
                        "data_source": manager.suricata_data_source
                    }
                },
                "timestamp": datetime.utcnow().isoformat()
            }

            return health
        except Exception as e:
            self.logger.error(f"Failed to get alerts health: {e}")
            return {
                "overall_status": "unhealthy",
                "error": str(e),
                "timestamp": datetime.utcnow().isoformat()
            }

    # ========================================================================
    # BaseService Implementation
    # ========================================================================

    async def health_check(self) -> Dict[str, Any]:
        """
        Check the health of the Alerts service.

        Returns:
            Health check information including status and any issues
        """
        return self.get_alerts_health()

    def get_service_info(self) -> Dict[str, Any]:
        """
        Get information about the Alerts service.

        Returns:
            Service information including capabilities and configuration
        """
        return {
            'service': 'AlertsService',
            'version': '1.0.0',
            'capabilities': [
                'unified_alerts',
                'wazuh_alerts',
                'suricata_alerts',
                'health_monitoring',
                'synthetic_alerts'
            ],
            'supported_sources': [
                'wazuh',
                'suricata_file',
                'suricata_elasticsearch'
            ],
            'supported_severities': [
                'Critical',
                'High',
                'Medium',
                'Low'
            ]
        }

    def get_threat_actors(
        self,
        time_range_hours: int = 24,
        min_severity: str = 'High',
        limit: int = 20,
        include_internal: bool = False,
        severity_filter: Optional[str] = None
    ) -> Dict[str, Any]:
        """
        Get filtered threat actors for Network Topology visualization.

        Aggregates alerts by source IP and returns:
        - External IPs with Critical/High alerts (threat actors)
        - Optionally, internal IPs with high alert counts (high-risk hosts)

        Args:
            time_range_hours: Time range in hours to look back
            min_severity: Minimum severity to include ('Critical' or 'High')
            limit: Maximum number of threat actors to return
            include_internal: Whether to include internal high-risk hosts
            severity_filter: Optional specific severity to filter

        Returns:
            Dictionary with threat_actors list and metadata
        """
        try:
            # Import whitelist functions
            from config.ip_whitelist import is_whitelisted, is_private_ip

            # Get unified alerts manager
            manager = self._get_unified_manager()
            if not manager:
                raise ServiceError("Unified alerts manager not available")

            self.logger.info(f"[ThreatActors] Fetching all alerts (time_range={time_range_hours}h)")

            # Fetch all alerts - no severity filtering at ES level
            filtered_alerts = []
            severity_debug = {'Critical': 0, 'High': 0, 'Medium': 0, 'Low': 0}

            # Get Wazuh alerts (all alerts, no severity filter)
            try:
                wazuh_result = manager.wazuh_manager.get_normalized_alerts(
                    limit=10000,  # ES max without scroll
                    time_range_hours=time_range_hours or 168,  # Default 7 days
                )
                wazuh_alerts = wazuh_result.get('alerts', [])
                filtered_alerts.extend(wazuh_alerts)
                for a in wazuh_alerts:
                    sev = a.get('normalized_severity', 'Low')
                    severity_debug[sev] = severity_debug.get(sev, 0) + 1
                self.logger.info(f"[ThreatActors] Wazuh: {len(wazuh_alerts)} alerts")
            except Exception as e:
                self.logger.warning(f"[ThreatActors] Wazuh fetch failed: {e}")

            # Get Suricata alerts (all alerts, no severity filter)
            try:
                self.logger.info(f"[ThreatActors] Fetching Suricata alerts...")
                suricata_result = manager.suricata_manager.get_normalized_alerts(
                    limit=10000,
                    time_range_hours=time_range_hours or 168,
                    return_total=True,  # Ensure dict response with 'alerts' key
                )
                # Handle both dict and list responses
                if isinstance(suricata_result, dict):
                    suricata_alerts = suricata_result.get('alerts', [])
                else:
                    suricata_alerts = suricata_result if isinstance(suricata_result, list) else []
                filtered_alerts.extend(suricata_alerts)
                for a in suricata_alerts:
                    sev = a.get('normalized_severity', 'Low')
                    severity_debug[sev] = severity_debug.get(sev, 0) + 1
                self.logger.info(f"[ThreatActors] Suricata: {len(suricata_alerts)} alerts fetched")
            except Exception as e:
                self.logger.error(f"[ThreatActors] Suricata fetch failed: {e}", exc_info=True)

            self.logger.info(f"[ThreatActors] Total: {len(filtered_alerts)} alerts, distribution: {severity_debug}")

            # Aggregate by external source IP
            threat_actors_map = defaultdict(lambda: {
                'ip': None,
                'is_internal': False,
                'alert_count': 0,
                'critical_count': 0,
                'high_count': 0,
                'signatures': set(),
                'targets': set(),
                'first_seen': None,
                'last_seen': None,
                'alert_ids': []
            })

            # Get registered agent IPs to exclude
            registered_agent_ips = set()
            registered_agent_names = set()
            try:
                from utils.wazuh_client import WazuhAgentClient
                agent_client = WazuhAgentClient()
                agents = agent_client.get_agents() or []
                for agent in agents:
                    if agent.get('ip'):
                        registered_agent_ips.add(agent['ip'])
                    if agent.get('name'):
                        registered_agent_names.add(agent['name'].lower())
                self.logger.info(f"[ThreatActors] Found {len(registered_agent_ips)} registered agent IPs to exclude")
            except Exception as agent_err:
                self.logger.warning(f"[ThreatActors] Could not fetch agents: {agent_err}")

            # Debug counters
            debug_counters = {
                'no_ip': 0,
                'invalid_ip': 0,
                'private_skipped': 0,
                'whitelisted': 0,
                'registered_agent': 0,
                'valid_external': 0,
                'valid_internal': 0
            }

            # Define severity hierarchy for filtering
            severity_levels = {'critical': 4, 'high': 3, 'medium': 2, 'low': 1}
            min_sev_level = severity_levels.get(min_severity.lower(), 3)  # Default to High

            for alert in filtered_alerts:
                # Filter by severity - skip alerts below min_severity
                alert_severity = alert.get('normalized_severity', 'Low').lower()
                alert_sev_level = severity_levels.get(alert_severity, 1)
                if alert_sev_level < min_sev_level:
                    continue  # Skip alerts below minimum severity threshold

                # Get source IP from alert - try multiple locations
                src_ip = None
                is_internal = False

                if alert.get('source') == 'suricata':
                    src_ip = alert.get('src_ip')
                elif alert.get('source') == 'wazuh':
                    src_ip = alert.get('src_ip') or alert.get('data', {}).get('srcip')
                    if not src_ip:
                        src_ip = alert.get('raw', {}).get('data', {}).get('srcip')
                    # If still no source IP, use the agent IP as the source
                    # (for host-based alerts, the agent IS the source)
                    if not src_ip and include_internal:
                        agent_ip = alert.get('raw', {}).get('agent', {}).get('ip')
                        if agent_ip:
                            src_ip = agent_ip
                            is_internal = True

                if not src_ip:
                    debug_counters['no_ip'] += 1
                    continue

                if src_ip in ('Unknown', 'N/A', '', None, '::1', '127.0.0.1'):
                    debug_counters['invalid_ip'] += 1
                    continue

                # Check if this is a private/internal IP
                is_private = is_private_ip(src_ip)

                # Skip private IPs unless include_internal is enabled
                if is_private and not include_internal:
                    debug_counters['private_skipped'] += 1
                    continue

                # If internal IP, check if it's a registered agent (exclude those)
                if is_private and include_internal:
                    if src_ip in registered_agent_ips:
                        debug_counters['registered_agent'] += 1
                        continue  # Skip registered agents - they're expected to generate alerts
                    is_internal = True
                    debug_counters['valid_internal'] += 1

                # Skip whitelisted IPs (known-good services) - only for external IPs
                if not is_private:
                    is_wl, provider, category = is_whitelisted(src_ip)
                    if is_wl:
                        debug_counters['whitelisted'] += 1
                        continue
                    debug_counters['valid_external'] += 1

                # Aggregate
                actor = threat_actors_map[src_ip]
                actor['ip'] = src_ip
                actor['is_internal'] = is_internal or is_private
                actor['alert_count'] += 1

                severity = alert.get('normalized_severity', 'Low')
                if severity.lower() == 'critical':
                    actor['critical_count'] += 1
                elif severity.lower() == 'high':
                    actor['high_count'] += 1

                if alert.get('signature'):
                    actor['signatures'].add(alert['signature'])
                if alert.get('dest_ip'):
                    actor['targets'].add(alert['dest_ip'])

                timestamp = alert.get('timestamp')
                if timestamp:
                    if actor['first_seen'] is None or timestamp < actor['first_seen']:
                        actor['first_seen'] = timestamp
                    if actor['last_seen'] is None or timestamp > actor['last_seen']:
                        actor['last_seen'] = timestamp

                actor['alert_ids'].append(alert.get('id'))

            # Log debug counters
            self.logger.info(f"[ThreatActors] IP filtering summary: {debug_counters}")

            internal_count = sum(1 for d in threat_actors_map.values() if d.get('is_internal'))
            external_count = len(threat_actors_map) - internal_count
            self.logger.info(f"[ThreatActors] Found {len(threat_actors_map)} unique IPs ({external_count} external, {internal_count} internal)")

            # Convert to list and sort by alert count
            threat_actors = []
            for ip, data in threat_actors_map.items():
                # Calculate risk score (simple formula)
                risk_score = min(100,
                    (data['critical_count'] * 30) +
                    (data['high_count'] * 15) +
                    (data['alert_count'] * 2)
                )

                threat_actors.append({
                    'ip': ip,
                    'is_internal': data['is_internal'],
                    'alert_count': data['alert_count'],
                    'critical_count': data['critical_count'],
                    'high_count': data['high_count'],
                    'risk_score': risk_score,
                    'signatures': list(data['signatures'])[:10],  # Limit to 10 signatures
                    'targets': list(data['targets'])[:10],  # Limit to 10 targets
                    'first_seen': data['first_seen'],
                    'last_seen': data['last_seen']
                })

            # Sort by risk score descending, then by alert count
            threat_actors.sort(key=lambda x: (-x['risk_score'], -x['alert_count']))

            # Apply limit
            total_filtered = len(threat_actors)
            threat_actors = threat_actors[:limit]

            return {
                'threat_actors': threat_actors,
                'total_filtered': total_filtered,
                'showing': len(threat_actors),
                'time_range_hours': time_range_hours,
                'min_severity': min_severity,
                'include_internal': include_internal,
                'debug': {
                    'total_alerts_fetched': len(filtered_alerts),
                    'severity_distribution': severity_debug,
                    'ip_filtering': debug_counters
                }
            }

        except Exception as e:
            self.logger.error(f"Failed to get threat actors: {e}", exc_info=True)
            raise ServiceError(f"Failed to retrieve threat actors: {str(e)}")
