"""
NIDS Elasticsearch Service

Handles all Elasticsearch queries for the NIDS dashboard.
Provides aggregations, filtering, and event retrieval from suricata-* indices.
"""

import logging
import requests
import os
from datetime import datetime, timedelta
from typing import Dict, List, Any, Optional
import urllib3

# Disable SSL warnings for local development
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

logger = logging.getLogger(__name__)


class NIDSElasticsearchService:
    """
    Elasticsearch service for NIDS dashboard queries.

    Queries suricata-* indices for:
    - Dashboard aggregations (severity, category, signature counts)
    - Timeline data
    - Network analysis (top IPs, services)
    - Event listing with pagination and filtering
    """

    def __init__(self):
        """Initialize Elasticsearch connection from environment variables."""
        self.es_host = os.getenv('SURICATA_ES_HOST', 'localhost')
        self.es_port = int(os.getenv('SURICATA_ES_PORT', '9220'))
        self.es_username = os.getenv('SURICATA_ES_USERNAME')
        self.es_password = os.getenv('SURICATA_ES_PASSWORD')
        self.verify_ssl = os.getenv('SURICATA_ES_VERIFY_SSL', 'false').lower() == 'true'
        self.index_pattern = os.getenv('SURICATA_ES_INDEX_PATTERN', 'suricata-alerts-*')

        # Build base URL
        self.base_url = f"https://{self.es_host}:{self.es_port}"
        self.logger = logging.getLogger(__name__)

    def _get_auth(self):
        """Get authentication tuple if credentials are configured."""
        if self.es_username and self.es_password:
            return (self.es_username, self.es_password)
        return None

    def _execute_query(self, query: Dict, timeout: int = 60) -> Dict:
        """
        Execute an Elasticsearch query.

        Args:
            query: Elasticsearch query body
            timeout: Request timeout in seconds

        Returns:
            Elasticsearch response as dict
        """
        try:
            response = requests.post(
                f"{self.base_url}/{self.index_pattern}/_search",
                auth=self._get_auth(),
                json=query,
                verify=self.verify_ssl,
                timeout=timeout
            )

            if response.status_code == 200:
                return response.json()
            else:
                self.logger.error(f"ES query failed: {response.status_code} - {response.text[:500]}")
                return {}
        except Exception as e:
            self.logger.error(f"ES query error: {e}")
            return {}

    def _build_time_filter(self, start: str, end: str) -> Dict:
        """Build time range filter for Elasticsearch query."""
        return {
            "range": {
                "@timestamp": {
                    "gte": start,
                    "lte": end
                }
            }
        }

    def _build_base_filters(self, start: str, end: str, **kwargs) -> List[Dict]:
        """
        Build base filter clauses for queries.

        Args:
            start: Start time (relative or absolute)
            end: End time
            **kwargs: Additional filters (category, signature, severity, etc.)

        Returns:
            List of filter clauses for bool query
        """
        filters = [
            self._build_time_filter(start, end),
            {"exists": {"field": "alert.severity"}}  # Only alert events
        ]

        # Category filter - try multiple field variations
        if kwargs.get('category'):
            category_val = kwargs['category']
            filters.append({
                "bool": {
                    "should": [
                        {"term": {"alert.category.keyword": category_val}},
                        {"term": {"alert.category": category_val}},
                        {"match_phrase": {"alert.category": category_val}}
                    ],
                    "minimum_should_match": 1
                }
            })

        # Signature filter - try multiple field variations
        if kwargs.get('signature'):
            sig_val = kwargs['signature']
            filters.append({
                "bool": {
                    "should": [
                        {"term": {"alert.signature.keyword": sig_val}},
                        {"term": {"alert.signature": sig_val}},
                        {"match_phrase": {"alert.signature": sig_val}}
                    ],
                    "minimum_should_match": 1
                }
            })

        # Severity filter
        if kwargs.get('severity'):
            severity = kwargs['severity']
            if severity == '5+':
                filters.append({
                    "range": {"alert.severity": {"gte": 5}}
                })
            else:
                filters.append({
                    "term": {"alert.severity": int(severity)}
                })

        # Source IP filter - try multiple field variations
        if kwargs.get('src_ip'):
            src_ip_val = kwargs['src_ip']
            filters.append({
                "bool": {
                    "should": [
                        {"term": {"src_ip.keyword": src_ip_val}},
                        {"term": {"src_ip": src_ip_val}},
                        {"term": {"source.ip": src_ip_val}}
                    ],
                    "minimum_should_match": 1
                }
            })

        # Destination IP filter - try multiple field variations
        if kwargs.get('dest_ip'):
            dest_ip_val = kwargs['dest_ip']
            filters.append({
                "bool": {
                    "should": [
                        {"term": {"dest_ip.keyword": dest_ip_val}},
                        {"term": {"dest_ip": dest_ip_val}},
                        {"term": {"destination.ip": dest_ip_val}}
                    ],
                    "minimum_should_match": 1
                }
            })

        # Service/protocol filter - try multiple field variations
        if kwargs.get('service_name'):
            svc_val = kwargs['service_name']
            filters.append({
                "bool": {
                    "should": [
                        {"term": {"app_proto.keyword": svc_val}},
                        {"term": {"app_proto": svc_val}},
                        {"term": {"network.protocol": svc_val}}
                    ],
                    "minimum_should_match": 1
                }
            })

        return filters

    def test_connection(self) -> bool:
        """Test Elasticsearch connection."""
        try:
            response = requests.get(
                f"{self.base_url}/_cluster/health",
                auth=self._get_auth(),
                verify=self.verify_ssl,
                timeout=5
            )
            return response.status_code == 200
        except Exception as e:
            self.logger.error(f"ES connection test failed: {e}")
            return False

    def get_overview_aggregations(self, start: str, end: str, **filters) -> Dict[str, Any]:
        """
        Get dashboard overview aggregations in a single query.

        Args:
            start: Start time
            end: End time
            **filters: Optional filters (category, signature, severity, src_ip, dest_ip, service_name)

        Returns:
            - Total alert count
            - Severity breakdown
            - Top categories
            - Top signatures
            - Timeline buckets
        """
        # Try both field naming conventions (standard Suricata and ECS)
        query = {
            "size": 0,
            "query": {
                "bool": {
                    "filter": self._build_base_filters(start, end, **filters)
                }
            },
            "aggs": {
                "severity_breakdown": {
                    "terms": {
                        "field": "alert.severity",
                        "size": 20
                    }
                },
                # Try standard Suricata field names
                "top_categories": {
                    "terms": {
                        "field": "alert.category.keyword",
                        "size": 50,
                        "missing": "__missing__"
                    }
                },
                # Also try without .keyword suffix
                "top_categories_alt": {
                    "terms": {
                        "field": "alert.category",
                        "size": 50,
                        "missing": "__missing__"
                    }
                },
                "top_signatures": {
                    "terms": {
                        "field": "alert.signature.keyword",
                        "size": 50,
                        "missing": "__missing__"
                    }
                },
                "top_signatures_alt": {
                    "terms": {
                        "field": "alert.signature",
                        "size": 50,
                        "missing": "__missing__"
                    }
                },
                "timeline": {
                    "date_histogram": {
                        "field": "@timestamp",
                        "calendar_interval": self._calculate_interval(start, end),
                        "min_doc_count": 0,
                        "extended_bounds": {
                            "min": start,
                            "max": end
                        }
                    }
                }
            },
            "track_total_hits": True
        }

        result = self._execute_query(query)

        if not result:
            self.logger.warning("No result from ES overview query")
            return {
                "totalAlerts": 0,
                "severityBreakdown": [],
                "topCategories": [],
                "topSignatures": [],
                "timeline": []
            }

        hits = result.get('hits', {})
        aggs = result.get('aggregations', {})

        # Debug logging to help identify field issues
        self.logger.info(f"Overview aggs keys: {list(aggs.keys())}")
        for key in ['severity_breakdown', 'top_categories', 'top_categories_alt', 'top_signatures', 'top_signatures_alt']:
            buckets = aggs.get(key, {}).get('buckets', [])
            self.logger.info(f"  {key}: {len(buckets)} buckets")
            if key == 'severity_breakdown' and buckets:
                # Log severity bucket keys to help debug type issues
                self.logger.info(f"    severity keys: {[(b.get('key'), type(b.get('key')).__name__) for b in buckets[:5]]}")

        # Process severity breakdown
        severity_buckets = aggs.get('severity_breakdown', {}).get('buckets', [])
        processed_severity = self._process_severity_buckets(severity_buckets)

        # Try both field naming conventions - use whichever has data
        category_buckets = aggs.get('top_categories', {}).get('buckets', [])
        if not category_buckets or (len(category_buckets) == 1 and category_buckets[0].get('key') == '__missing__'):
            category_buckets = aggs.get('top_categories_alt', {}).get('buckets', [])

        signature_buckets = aggs.get('top_signatures', {}).get('buckets', [])
        if not signature_buckets or (len(signature_buckets) == 1 and signature_buckets[0].get('key') == '__missing__'):
            signature_buckets = aggs.get('top_signatures_alt', {}).get('buckets', [])

        # Filter out __missing__ buckets
        category_buckets = [b for b in category_buckets if b.get('key') != '__missing__']
        signature_buckets = [b for b in signature_buckets if b.get('key') != '__missing__']

        return {
            "totalAlerts": hits.get('total', {}).get('value', 0),
            "severityBreakdown": processed_severity,
            "topCategories": [
                {"key": b['key'], "count": b['doc_count']}
                for b in category_buckets
            ],
            "topSignatures": [
                {"key": b['key'], "count": b['doc_count']}
                for b in signature_buckets
            ],
            "timeline": [
                {"timestamp": b['key'], "count": b['doc_count']}
                for b in aggs.get('timeline', {}).get('buckets', [])
            ]
        }

    def _process_severity_buckets(self, buckets: List[Dict]) -> List[Dict]:
        """
        Process severity buckets into dashboard format.

        Groups severity 5+ into "Others" category.
        Handles both string and numeric keys from Elasticsearch.
        """
        severity_map = {
            1: {"key": "1", "label": "Alert", "count": 0},
            2: {"key": "2", "label": "Critical", "count": 0},
            3: {"key": "3", "label": "Warning", "count": 0},
            4: {"key": "4", "label": "Notice", "count": 0},
        }
        others_count = 0

        for bucket in buckets:
            sev = bucket['key']
            count = bucket['doc_count']

            # Handle both string and numeric keys from ES
            # ES may return "1", 1, or 1.0 depending on field mapping
            try:
                sev_int = int(float(sev)) if isinstance(sev, str) else int(sev)
            except (ValueError, TypeError):
                sev_int = None

            if sev_int in severity_map:
                severity_map[sev_int]["count"] = count
            else:
                others_count += count

        result = list(severity_map.values())
        result.append({"key": "5+", "label": "Others", "count": others_count})

        return result

    def _calculate_interval(self, start: str, end: str) -> str:
        """Calculate appropriate histogram interval based on time range."""
        # Parse relative time strings
        if 'now-' in start:
            # Extract time value (e.g., 'now-24h' -> 24h)
            time_str = start.replace('now-', '')
            if 'h' in time_str:
                hours = int(time_str.replace('h', ''))
            elif 'd' in time_str:
                hours = int(time_str.replace('d', '')) * 24
            elif 'm' in time_str:
                hours = int(time_str.replace('m', '')) // 60
            else:
                hours = 24
        else:
            hours = 24

        # Choose interval based on time range
        if hours <= 1:
            return "5m"
        elif hours <= 24:
            return "1h"
        elif hours <= 168:  # 7 days
            return "1d"
        else:
            return "1d"

    def get_timeline_data(self, start: str, end: str, interval: str = 'auto',
                          **filters) -> Dict[str, Any]:
        """Get timeline chart data with optional filtering."""
        if interval == 'auto':
            interval = self._calculate_interval(start, end)

        query = {
            "size": 0,
            "query": {
                "bool": {
                    "filter": self._build_base_filters(start, end, **filters)
                }
            },
            "aggs": {
                "timeline": {
                    "date_histogram": {
                        "field": "@timestamp",
                        "calendar_interval": interval,
                        "min_doc_count": 0,
                        "extended_bounds": {
                            "min": start,
                            "max": end
                        }
                    },
                    "aggs": {
                        "by_severity": {
                            "terms": {
                                "field": "alert.severity",
                                "size": 10
                            }
                        }
                    }
                }
            }
        }

        result = self._execute_query(query)
        buckets = result.get('aggregations', {}).get('timeline', {}).get('buckets', [])

        return {
            "interval": interval,
            "data": [
                {
                    "timestamp": b['key'],
                    "count": b['doc_count'],
                    "bySeverity": {
                        str(s['key']): s['doc_count']
                        for s in b.get('by_severity', {}).get('buckets', [])
                    }
                }
                for b in buckets
            ]
        }

    def get_network_analysis(self, start: str, end: str, limit: int = 10, **filters) -> Dict[str, Any]:
        """Get network analysis data (top IPs, services, hostnames).

        Args:
            start: Start time
            end: End time
            limit: Number of top items to return
            **filters: Optional filters (category, signature, severity, src_ip, dest_ip, service_name)
        """
        # Try multiple field naming conventions (Suricata native vs ECS)
        query = {
            "size": 0,
            "query": {
                "bool": {
                    "filter": self._build_base_filters(start, end, **filters)
                }
            },
            "aggs": {
                # Standard Suricata fields
                "top_source_ips": {
                    "terms": {
                        "field": "src_ip.keyword",
                        "size": limit
                    }
                },
                "top_source_ips_alt1": {
                    "terms": {
                        "field": "src_ip",
                        "size": limit
                    }
                },
                # ECS format fields
                "top_source_ips_ecs": {
                    "terms": {
                        "field": "source.ip",
                        "size": limit
                    }
                },
                "top_dest_ips": {
                    "terms": {
                        "field": "dest_ip.keyword",
                        "size": limit
                    }
                },
                "top_dest_ips_alt1": {
                    "terms": {
                        "field": "dest_ip",
                        "size": limit
                    }
                },
                "top_dest_ips_ecs": {
                    "terms": {
                        "field": "destination.ip",
                        "size": limit
                    }
                },
                "top_services": {
                    "terms": {
                        "field": "app_proto.keyword",
                        "size": limit
                    }
                },
                "top_services_alt1": {
                    "terms": {
                        "field": "app_proto",
                        "size": limit
                    }
                },
                "top_services_ecs": {
                    "terms": {
                        "field": "network.protocol",
                        "size": limit
                    }
                },
                "top_src_hostnames": {
                    "terms": {
                        "field": "src_hostname.keyword",
                        "size": limit
                    }
                },
                "top_dest_hostnames": {
                    "terms": {
                        "field": "dest_hostname.keyword",
                        "size": limit
                    }
                }
            }
        }

        result = self._execute_query(query)
        aggs = result.get('aggregations', {})

        # Debug logging for network analysis
        self.logger.info(f"Network analysis aggs keys: {list(aggs.keys())}")
        for key in ['top_source_ips', 'top_source_ips_alt1', 'top_source_ips_ecs',
                    'top_dest_ips', 'top_dest_ips_alt1', 'top_dest_ips_ecs',
                    'top_services', 'top_services_alt1', 'top_services_ecs']:
            buckets = aggs.get(key, {}).get('buckets', [])
            self.logger.info(f"  {key}: {len(buckets)} buckets")

        # Helper to get buckets from first non-empty aggregation
        def get_first_non_empty(*agg_names):
            for name in agg_names:
                buckets = aggs.get(name, {}).get('buckets', [])
                if buckets:
                    self.logger.info(f"Using {name} for aggregation")
                    return buckets
            return []

        src_ip_buckets = get_first_non_empty('top_source_ips', 'top_source_ips_alt1', 'top_source_ips_ecs')
        dest_ip_buckets = get_first_non_empty('top_dest_ips', 'top_dest_ips_alt1', 'top_dest_ips_ecs')
        service_buckets = get_first_non_empty('top_services', 'top_services_alt1', 'top_services_ecs')

        return {
            "topSourceIPs": [
                {"ip": b['key'], "count": b['doc_count']}
                for b in src_ip_buckets
            ],
            "topDestIPs": [
                {"ip": b['key'], "count": b['doc_count']}
                for b in dest_ip_buckets
            ],
            "topServices": [
                {"service": b['key'], "count": b['doc_count']}
                for b in service_buckets
            ],
            "topSrcHostnames": [
                {"hostname": b['key'], "count": b['doc_count']}
                for b in aggs.get('top_src_hostnames', {}).get('buckets', [])
            ],
            "topDestHostnames": [
                {"hostname": b['key'], "count": b['doc_count']}
                for b in aggs.get('top_dest_hostnames', {}).get('buckets', [])
            ]
        }

    def get_events(self, start: str, end: str, limit: int = 20, offset: int = 0,
                   sort_field: str = 'timestamp', sort_direction: str = 'desc',
                   search: Optional[str] = None, **filters) -> Dict[str, Any]:
        """
        Get paginated events with filtering.

        Args:
            start: Start time
            end: End time
            limit: Page size
            offset: Pagination offset
            sort_field: Field to sort by
            sort_direction: asc or desc
            search: Full-text search query
            **filters: Additional filter parameters

        Returns:
            Dict with events list and pagination metadata
        """
        filter_clauses = self._build_base_filters(start, end, **filters)

        # Add search query if provided
        query_clause = {"bool": {"filter": filter_clauses}}
        if search:
            query_clause["bool"]["must"] = [{
                "multi_match": {
                    "query": search,
                    "fields": [
                        "alert.signature",
                        "alert.category",
                        "src_ip",
                        "dest_ip"
                    ],
                    "type": "phrase_prefix"
                }
            }]

        # Map sort field to ES field
        sort_mapping = {
            'timestamp': '@timestamp',
            'severity': 'alert.severity',
            'category': 'alert.category.keyword',
            'signature': 'alert.signature.keyword'
        }
        es_sort_field = sort_mapping.get(sort_field, '@timestamp')

        query = {
            "from": offset,
            "size": limit,
            "query": query_clause,
            "sort": [
                {es_sort_field: {"order": sort_direction}}
            ],
            "track_total_hits": True
        }

        result = self._execute_query(query)

        if not result:
            return {"events": [], "total": 0, "limit": limit, "offset": offset}

        hits = result.get('hits', {})
        events = []

        for hit in hits.get('hits', []):
            source = hit.get('_source', {})
            alert_data = source.get('alert', {})
            flow_data = source.get('flow', {})

            # Extract AS/Geo info (may be in different locations depending on ES mapping)
            src_as = source.get('src_as', {})
            dest_as = source.get('dest_as', {})
            src_geo = source.get('src_geo', {})
            dest_geo = source.get('dest_geo', {})

            # Also check ECS-style nested objects
            source_obj = source.get('source', {})
            dest_obj = source.get('destination', {})

            events.append({
                # Core identification
                "id": hit.get('_id'),
                "_index": hit.get('_index'),
                "timestamp": source.get('@timestamp'),

                # Alert information
                "severity": alert_data.get('severity'),
                "category": alert_data.get('category'),
                "signature": alert_data.get('signature'),
                "signatureId": alert_data.get('signature_id'),
                "gid": alert_data.get('gid'),
                "rev": alert_data.get('rev'),
                "action": alert_data.get('action', 'allowed'),
                "metadata": alert_data.get('metadata'),

                # Network information
                "srcIp": source.get('src_ip') or source_obj.get('ip'),
                "destIp": source.get('dest_ip') or dest_obj.get('ip'),
                "srcPort": source.get('src_port') or source_obj.get('port'),
                "destPort": source.get('dest_port') or dest_obj.get('port'),
                "proto": source.get('proto'),
                "appProto": source.get('app_proto'),
                "inIface": source.get('in_iface'),
                "vlan": source.get('vlan'),
                "communityId": source.get('community_id'),

                # Hostname information
                "srcHostname": source.get('src_hostname'),
                "destHostname": source.get('dest_hostname'),

                # MAC addresses
                "srcMac": source.get('src_mac') or source.get('ether', {}).get('src_mac'),
                "destMac": source.get('dest_mac') or source.get('ether', {}).get('dest_mac'),

                # Flow information
                "flowId": source.get('flow_id'),
                "flowStart": flow_data.get('start'),
                "flowEnd": flow_data.get('end'),
                "flowAge": flow_data.get('age'),
                "flowState": flow_data.get('state'),
                "flowReason": flow_data.get('reason'),
                "flowAlerted": flow_data.get('alerted'),
                "flowPktsToserver": flow_data.get('pkts_toserver'),
                "flowPktsToclient": flow_data.get('pkts_toclient'),
                "flowBytesToserver": flow_data.get('bytes_toserver'),
                "flowBytesToclient": flow_data.get('bytes_toclient'),
                "flowDirection": source.get('direction'),

                # AS (Autonomous System) information - Source
                "srcAsn": src_as.get('number') or source_obj.get('as', {}).get('number'),
                "srcAsOrg": src_as.get('organization', {}).get('name') or source_obj.get('as', {}).get('organization', {}).get('name'),

                # AS information - Destination
                "destAsn": dest_as.get('number') or dest_obj.get('as', {}).get('number'),
                "destAsOrg": dest_as.get('organization', {}).get('name') or dest_obj.get('as', {}).get('organization', {}).get('name'),

                # Geo information - Source
                "srcGeoCountry": src_geo.get('country_name') or source_obj.get('geo', {}).get('country_name'),
                "srcGeoCity": src_geo.get('city_name') or source_obj.get('geo', {}).get('city_name'),

                # Geo information - Destination
                "destGeoCountry": dest_geo.get('country_name') or dest_obj.get('geo', {}).get('country_name'),
                "destGeoCity": dest_geo.get('city_name') or dest_obj.get('geo', {}).get('city_name'),

                # Tunnel information
                "tunnelType": source.get('tunnel', {}).get('type'),
                "tunnelDepth": source.get('tunnel', {}).get('depth'),
                "tunnelParentId": source.get('tunnel', {}).get('parent_id'),

                # ICMP information
                "icmpType": source.get('icmp_type'),
                "icmpCode": source.get('icmp_code'),

                # Debug/System information
                "pcapCnt": source.get('pcap_cnt'),
                "txId": source.get('tx_id'),
                "eventType": source.get('event_type'),

                # Tags
                "tags": source.get('tags', []),

                # Service name
                "serviceName": source.get('app_proto'),

                # Include raw data for full details view
                "raw": source
            })

        total = hits.get('total', {})
        total_count = total.get('value', 0) if isinstance(total, dict) else total

        return {
            "events": events,
            "total": total_count,
            "limit": limit,
            "offset": offset,
            "hasMore": (offset + limit) < total_count
        }

    def get_event_by_id(self, event_id: str) -> Optional[Dict]:
        """Get a single event by its Elasticsearch document ID."""
        try:
            response = requests.get(
                f"{self.base_url}/{self.index_pattern}/_doc/{event_id}",
                auth=self._get_auth(),
                verify=self.verify_ssl,
                timeout=10
            )

            if response.status_code == 200:
                result = response.json()
                source = result.get('_source', {})
                alert_data = source.get('alert', {})
                flow_data = source.get('flow', {})

                # Extract AS/Geo info
                src_as = source.get('src_as', {})
                dest_as = source.get('dest_as', {})
                src_geo = source.get('src_geo', {})
                dest_geo = source.get('dest_geo', {})
                source_obj = source.get('source', {})
                dest_obj = source.get('destination', {})

                return {
                    # Core identification
                    "id": result.get('_id'),
                    "_index": result.get('_index'),
                    "timestamp": source.get('@timestamp'),

                    # Alert information
                    "severity": alert_data.get('severity'),
                    "category": alert_data.get('category'),
                    "signature": alert_data.get('signature'),
                    "signatureId": alert_data.get('signature_id'),
                    "gid": alert_data.get('gid'),
                    "rev": alert_data.get('rev'),
                    "action": alert_data.get('action', 'allowed'),
                    "metadata": alert_data.get('metadata'),

                    # Network information
                    "srcIp": source.get('src_ip') or source_obj.get('ip'),
                    "destIp": source.get('dest_ip') or dest_obj.get('ip'),
                    "srcPort": source.get('src_port') or source_obj.get('port'),
                    "destPort": source.get('dest_port') or dest_obj.get('port'),
                    "proto": source.get('proto'),
                    "appProto": source.get('app_proto'),
                    "inIface": source.get('in_iface'),
                    "vlan": source.get('vlan'),
                    "communityId": source.get('community_id'),

                    # Hostname information
                    "srcHostname": source.get('src_hostname'),
                    "destHostname": source.get('dest_hostname'),

                    # MAC addresses
                    "srcMac": source.get('src_mac') or source.get('ether', {}).get('src_mac'),
                    "destMac": source.get('dest_mac') or source.get('ether', {}).get('dest_mac'),

                    # Flow information
                    "flowId": source.get('flow_id'),
                    "flowStart": flow_data.get('start'),
                    "flowEnd": flow_data.get('end'),
                    "flowAge": flow_data.get('age'),
                    "flowState": flow_data.get('state'),
                    "flowReason": flow_data.get('reason'),
                    "flowAlerted": flow_data.get('alerted'),
                    "flowPktsToserver": flow_data.get('pkts_toserver'),
                    "flowPktsToclient": flow_data.get('pkts_toclient'),
                    "flowBytesToserver": flow_data.get('bytes_toserver'),
                    "flowBytesToclient": flow_data.get('bytes_toclient'),
                    "flowDirection": source.get('direction'),

                    # AS information
                    "srcAsn": src_as.get('number') or source_obj.get('as', {}).get('number'),
                    "srcAsOrg": src_as.get('organization', {}).get('name') or source_obj.get('as', {}).get('organization', {}).get('name'),
                    "destAsn": dest_as.get('number') or dest_obj.get('as', {}).get('number'),
                    "destAsOrg": dest_as.get('organization', {}).get('name') or dest_obj.get('as', {}).get('organization', {}).get('name'),

                    # Geo information
                    "srcGeoCountry": src_geo.get('country_name') or source_obj.get('geo', {}).get('country_name'),
                    "srcGeoCity": src_geo.get('city_name') or source_obj.get('geo', {}).get('city_name'),
                    "destGeoCountry": dest_geo.get('country_name') or dest_obj.get('geo', {}).get('country_name'),
                    "destGeoCity": dest_geo.get('city_name') or dest_obj.get('geo', {}).get('city_name'),

                    # Tunnel information
                    "tunnelType": source.get('tunnel', {}).get('type'),
                    "tunnelDepth": source.get('tunnel', {}).get('depth'),
                    "tunnelParentId": source.get('tunnel', {}).get('parent_id'),

                    # ICMP information
                    "icmpType": source.get('icmp_type'),
                    "icmpCode": source.get('icmp_code'),

                    # Debug/System information
                    "pcapCnt": source.get('pcap_cnt'),
                    "txId": source.get('tx_id'),
                    "eventType": source.get('event_type'),

                    # Tags
                    "tags": source.get('tags', []),

                    # Service name
                    "serviceName": source.get('app_proto'),

                    # Protocol-specific data
                    "http": source.get('http'),
                    "dns": source.get('dns'),
                    "tls": source.get('tls'),

                    # MITRE ATT&CK mapping
                    "mitre": alert_data.get('metadata', {}).get('mitre_attack'),

                    # Include raw data for full details view
                    "raw": source
                }
            return None
        except Exception as e:
            self.logger.error(f"Error fetching event {event_id}: {e}")
            return None

    def get_filter_options(self, start: str, end: str) -> Dict[str, Any]:
        """Get available filter options with counts."""
        # Try multiple field naming conventions (standard Suricata and ECS)
        query = {
            "size": 0,
            "query": {
                "bool": {
                    "filter": self._build_base_filters(start, end)
                }
            },
            "aggs": {
                # Categories - try both .keyword and non-keyword
                "categories": {
                    "terms": {
                        "field": "alert.category.keyword",
                        "size": 100
                    }
                },
                "categories_alt": {
                    "terms": {
                        "field": "alert.category",
                        "size": 100
                    }
                },
                # Signatures - try both .keyword and non-keyword
                "signatures": {
                    "terms": {
                        "field": "alert.signature.keyword",
                        "size": 100
                    }
                },
                "signatures_alt": {
                    "terms": {
                        "field": "alert.signature",
                        "size": 100
                    }
                },
                # Severities
                "severities": {
                    "terms": {
                        "field": "alert.severity",
                        "size": 20
                    }
                },
                # Services - try multiple fields
                "services": {
                    "terms": {
                        "field": "app_proto.keyword",
                        "size": 50
                    }
                },
                "services_alt": {
                    "terms": {
                        "field": "app_proto",
                        "size": 50
                    }
                },
                "services_ecs": {
                    "terms": {
                        "field": "network.protocol",
                        "size": 50
                    }
                },
                # Source IPs for filtering
                "source_ips": {
                    "terms": {
                        "field": "src_ip.keyword",
                        "size": 100
                    }
                },
                "source_ips_alt": {
                    "terms": {
                        "field": "src_ip",
                        "size": 100
                    }
                },
                # Destination IPs for filtering
                "dest_ips": {
                    "terms": {
                        "field": "dest_ip.keyword",
                        "size": 100
                    }
                },
                "dest_ips_alt": {
                    "terms": {
                        "field": "dest_ip",
                        "size": 100
                    }
                }
            }
        }

        result = self._execute_query(query)
        aggs = result.get('aggregations', {})

        # Debug logging
        self.logger.info(f"Filter options aggs keys: {list(aggs.keys())}")
        for key in ['categories', 'categories_alt', 'signatures', 'signatures_alt']:
            buckets = aggs.get(key, {}).get('buckets', [])
            self.logger.info(f"  {key}: {len(buckets)} buckets")

        # Helper to get buckets from first non-empty aggregation
        def get_first_non_empty(*agg_names):
            for name in agg_names:
                buckets = aggs.get(name, {}).get('buckets', [])
                if buckets:
                    self.logger.info(f"Using {name} for filter options")
                    return buckets
            return []

        category_buckets = get_first_non_empty('categories', 'categories_alt')
        signature_buckets = get_first_non_empty('signatures', 'signatures_alt')
        service_buckets = get_first_non_empty('services', 'services_alt', 'services_ecs')
        src_ip_buckets = get_first_non_empty('source_ips', 'source_ips_alt')
        dest_ip_buckets = get_first_non_empty('dest_ips', 'dest_ips_alt')

        return {
            "categories": [
                {"value": b['key'], "label": b['key'], "count": b['doc_count']}
                for b in category_buckets
            ],
            "signatures": [
                {"value": b['key'], "label": b['key'], "count": b['doc_count']}
                for b in signature_buckets
            ],
            "severities": self._process_severity_buckets(
                aggs.get('severities', {}).get('buckets', [])
            ),
            "services": [
                {"value": b['key'], "label": b['key'], "count": b['doc_count']}
                for b in service_buckets
            ],
            "sourceIPs": [
                {"value": b['key'], "label": b['key'], "count": b['doc_count']}
                for b in src_ip_buckets
            ],
            "destIPs": [
                {"value": b['key'], "label": b['key'], "count": b['doc_count']}
                for b in dest_ip_buckets
            ]
        }
