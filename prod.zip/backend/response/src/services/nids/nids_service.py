"""
NIDS Service

Business logic layer for NIDS dashboard functionality.
Orchestrates Elasticsearch queries and transforms data for the frontend.
"""

import logging
from datetime import datetime
from typing import Dict, Any, Optional, List

from .elasticsearch_service import NIDSElasticsearchService

logger = logging.getLogger(__name__)


class NIDSService:
    """
    NIDS Service providing business logic for the NIDS dashboard.

    Responsibilities:
    - Coordinate data fetching from Elasticsearch
    - Transform and aggregate data for dashboard visualizations
    - Handle caching and performance optimization
    - Provide health monitoring
    """

    def __init__(self):
        """Initialize NIDS service with Elasticsearch backend."""
        self._es_service = None
        self.logger = logging.getLogger(__name__)

    @property
    def es_service(self) -> NIDSElasticsearchService:
        """Lazy initialization of Elasticsearch service."""
        if self._es_service is None:
            self._es_service = NIDSElasticsearchService()
        return self._es_service

    def get_dashboard_overview(self, start: str, end: str,
                                category: Optional[str] = None,
                                signature: Optional[str] = None,
                                severity: Optional[str] = None,
                                src_ip: Optional[str] = None,
                                dest_ip: Optional[str] = None,
                                service_name: Optional[str] = None) -> Dict[str, Any]:
        """
        Get complete dashboard overview data.

        Args:
            start: Start time (relative like 'now-24h' or ISO format)
            end: End time
            category: Optional category filter
            signature: Optional signature filter
            severity: Optional severity filter
            src_ip: Optional source IP filter
            dest_ip: Optional destination IP filter
            service_name: Optional service/protocol filter

        Returns:
            Dashboard data including:
            - Total alerts
            - Severity breakdown for cards
            - Top categories for chart
            - Top signatures for chart
            - Timeline data
        """
        try:
            overview = self.es_service.get_overview_aggregations(
                start, end,
                category=category,
                signature=signature,
                severity=severity,
                src_ip=src_ip,
                dest_ip=dest_ip,
                service_name=service_name
            )

            # Calculate percentages for severity cards
            total = overview.get('totalAlerts', 0)
            severity_with_percentage = []

            for sev in overview.get('severityBreakdown', []):
                count = sev.get('count', 0)
                percentage = (count / total * 100) if total > 0 else 0
                severity_with_percentage.append({
                    **sev,
                    "percentage": round(percentage, 1)
                })

            return {
                "totalAlerts": total,
                "severityBreakdown": severity_with_percentage,
                "topCategories": overview.get('topCategories', [])[:10],
                "topSignatures": overview.get('topSignatures', [])[:10],
                "timeline": overview.get('timeline', []),
                "timeRange": {
                    "start": start,
                    "end": end
                },
                "retrievedAt": datetime.utcnow().isoformat() + "Z"
            }
        except Exception as e:
            self.logger.error(f"Error getting dashboard overview: {e}")
            raise

    def get_timeline_data(self, start: str, end: str, interval: str = 'auto',
                          category: Optional[str] = None,
                          signature: Optional[str] = None,
                          severity: Optional[str] = None) -> Dict[str, Any]:
        """
        Get timeline chart data with optional filtering.

        Args:
            start: Start time
            end: End time
            interval: Histogram interval (auto, 5m, 1h, 1d)
            category: Optional category filter
            signature: Optional signature filter
            severity: Optional severity filter

        Returns:
            Timeline data with counts per time bucket
        """
        try:
            return self.es_service.get_timeline_data(
                start=start,
                end=end,
                interval=interval,
                category=category,
                signature=signature,
                severity=severity
            )
        except Exception as e:
            self.logger.error(f"Error getting timeline data: {e}")
            raise

    def get_network_analysis(self, start: str, end: str, limit: int = 10,
                              category: Optional[str] = None,
                              signature: Optional[str] = None,
                              severity: Optional[str] = None,
                              src_ip: Optional[str] = None,
                              dest_ip: Optional[str] = None,
                              service_name: Optional[str] = None) -> Dict[str, Any]:
        """
        Get network analysis data for charts.

        Args:
            start: Start time
            end: End time
            limit: Number of top items per category
            category: Optional category filter
            signature: Optional signature filter
            severity: Optional severity filter
            src_ip: Optional source IP filter
            dest_ip: Optional destination IP filter
            service_name: Optional service/protocol filter

        Returns:
            Network analysis data including top IPs, services, hostnames
        """
        try:
            return self.es_service.get_network_analysis(
                start, end, limit,
                category=category,
                signature=signature,
                severity=severity,
                src_ip=src_ip,
                dest_ip=dest_ip,
                service_name=service_name
            )
        except Exception as e:
            self.logger.error(f"Error getting network analysis: {e}")
            raise

    def get_events(self, start: str, end: str, limit: int = 20, offset: int = 0,
                   category: Optional[str] = None, signature: Optional[str] = None,
                   severity: Optional[str] = None, src_ip: Optional[str] = None,
                   dest_ip: Optional[str] = None, service_name: Optional[str] = None,
                   search: Optional[str] = None, sort_field: str = 'timestamp',
                   sort_direction: str = 'desc') -> Dict[str, Any]:
        """
        Get paginated events with filtering.

        Args:
            start: Start time
            end: End time
            limit: Page size (max 100)
            offset: Pagination offset
            category: Filter by category
            signature: Filter by signature
            severity: Filter by severity (1, 2, 3, 4, 5+)
            src_ip: Filter by source IP
            dest_ip: Filter by destination IP
            service_name: Filter by service/protocol
            search: Full-text search
            sort_field: Field to sort by
            sort_direction: asc or desc

        Returns:
            Paginated events with metadata
        """
        try:
            result = self.es_service.get_events(
                start=start,
                end=end,
                limit=limit,
                offset=offset,
                sort_field=sort_field,
                sort_direction=sort_direction,
                search=search,
                category=category,
                signature=signature,
                severity=severity,
                src_ip=src_ip,
                dest_ip=dest_ip,
                service_name=service_name
            )

            # Transform events for frontend
            events = result.get('events', [])
            for event in events:
                # Add normalized severity label
                event['severityLabel'] = self._get_severity_label(event.get('severity'))

            return result
        except Exception as e:
            self.logger.error(f"Error getting events: {e}")
            raise

    def get_event_by_id(self, event_id: str) -> Optional[Dict[str, Any]]:
        """
        Get detailed information for a specific event.

        Args:
            event_id: Elasticsearch document ID

        Returns:
            Event details or None if not found
        """
        try:
            event = self.es_service.get_event_by_id(event_id)
            if event:
                event['severityLabel'] = self._get_severity_label(event.get('severity'))
            return event
        except Exception as e:
            self.logger.error(f"Error getting event {event_id}: {e}")
            return None

    def get_filter_options(self, start: str, end: str) -> Dict[str, Any]:
        """
        Get available filter options with counts.

        Args:
            start: Start time
            end: End time

        Returns:
            Available categories, signatures, severities, and services with counts
        """
        try:
            return self.es_service.get_filter_options(start, end)
        except Exception as e:
            self.logger.error(f"Error getting filter options: {e}")
            raise

    def get_health_status(self) -> Dict[str, Any]:
        """
        Get NIDS service health status.

        Returns:
            Health status including Elasticsearch connection status
        """
        try:
            es_connected = self.es_service.test_connection()

            return {
                "status": "healthy" if es_connected else "unhealthy",
                "elasticsearch": {
                    "connected": es_connected,
                    "host": self.es_service.es_host,
                    "port": self.es_service.es_port,
                    "index_pattern": self.es_service.index_pattern
                },
                "timestamp": datetime.utcnow().isoformat() + "Z"
            }
        except Exception as e:
            self.logger.error(f"Error getting health status: {e}")
            return {
                "status": "unhealthy",
                "error": str(e),
                "timestamp": datetime.utcnow().isoformat() + "Z"
            }

    def _get_severity_label(self, severity: Optional[int]) -> str:
        """Get human-readable severity label."""
        severity_labels = {
            1: "Alert",
            2: "Critical",
            3: "Warning",
            4: "Notice"
        }
        if severity is None:
            return "Unknown"
        if severity >= 5:
            return "Info"
        return severity_labels.get(severity, "Unknown")
