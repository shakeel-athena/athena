"""
NIDS Service Module

Provides services for NIDS dashboard functionality including:
- Dashboard aggregations and statistics
- Event listing and filtering
- Network analysis
- Elasticsearch integration
"""

from .nids_service import NIDSService
from .elasticsearch_service import NIDSElasticsearchService

__all__ = ['NIDSService', 'NIDSElasticsearchService']
