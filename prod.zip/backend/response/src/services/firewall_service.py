"""
Firewall Service

Handles all firewall-related operations including rule management,
IP blocking/unblocking, and AWS Security Group integration.
"""

from typing import Dict, List, Any, Optional
from datetime import datetime, timedelta
import logging
import asyncio
from contextlib import asynccontextmanager

import sys
import os
# Add parent directory to path for absolute imports
current_dir = os.path.dirname(os.path.abspath(__file__))
parent_dir = os.path.dirname(current_dir)
if parent_dir not in sys.path:
    sys.path.insert(0, parent_dir)

# Add config directory to path
config_dir = os.path.join(parent_dir, 'config')
if config_dir not in sys.path:
    sys.path.insert(0, config_dir)

from .base_service import BaseService, OperationResult, OperationContext
from configuration_service import get_configuration_service
from configuration_service import AthenaConfig
from errors.error_types import (
    ValidationError, ServiceError, ConfigurationError,
    ExternalServiceError, AuthorizationError
)


class FirewallRule:
    """Represents a firewall rule."""
    
    def __init__(self, 
                 rule_id: str,
                 direction: str,
                 protocol: str,
                 port_range: str,
                 cidr_blocks: List[str],
                 description: str = "",
                 priority: int = 100,
                 enabled: bool = True):
        """
        Initialize firewall rule.
        
        Args:
            rule_id: Unique rule identifier
            direction: Rule direction (ingress/egress)
            protocol: Protocol (tcp/udp/icmp/all)
            port_range: Port range (e.g., "80", "443", "8080-8090")
            cidr_blocks: List of CIDR blocks
            description: Rule description
            priority: Rule priority (lower = higher priority)
            enabled: Whether rule is enabled
        """
        self.rule_id = rule_id
        self.direction = direction
        self.protocol = protocol
        self.port_range = port_range
        self.cidr_blocks = cidr_blocks
        self.description = description
        self.priority = priority
        self.enabled = enabled
        self.created_at = datetime.utcnow()
        self.updated_at = self.created_at
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert rule to dictionary."""
        return {
            'rule_id': self.rule_id,
            'direction': self.direction,
            'protocol': self.protocol,
            'port_range': self.port_range,
            'cidr_blocks': self.cidr_blocks,
            'description': self.description,
            'priority': self.priority,
            'enabled': self.enabled,
            'created_at': self.created_at.isoformat(),
            'updated_at': self.updated_at.isoformat()
        }


class FirewallService(BaseService):
    """
    Service for managing firewall rules and IP blocking.
    
    Provides high-level operations for firewall management including
    rule creation, modification, deletion, and IP blocking/unblocking.
    Integrates with AWS Security Groups and other firewall backends.
    """
    
    def __init__(self,
                 config_service=None,
                 aws_client=None,
                 aws_service=None,
                 cache_service=None,
                 audit_service=None):
        """
        Initialize firewall service.

        Args:
            config_service: Configuration service instance
            aws_client: AWS client for security group operations (deprecated, use aws_service)
            aws_service: AWS service instance (preferred over aws_client)
            cache_service: Cache service for performance optimization
            audit_service: Audit service for logging operations
        """
        super().__init__("firewall_service")

        # Dependencies
        self._config_service = config_service or get_configuration_service()
        # Support both aws_service (new) and aws_client (legacy)
        self._aws_client = aws_service or aws_client
        self._cache_service = cache_service
        self._audit_service = audit_service
        
        # Initialize configuration
        self._config: AthenaConfig = None
        self._security_group_id = None
        
        # In-memory rule storage (in production, this would be a database)
        self._rules: Dict[str, FirewallRule] = {}
        self._blocked_ips: Dict[str, Dict[str, Any]] = {}
        
        # Performance metrics
        self._metrics = {
            'rules_created': 0,
            'rules_modified': 0,
            'rules_deleted': 0,
            'ips_blocked': 0,
            'ips_unblocked': 0,
            'operations_succeeded': 0,
            'operations_failed': 0
        }
    
    async def initialize(self) -> None:
        """Initialize the firewall service."""
        await super().initialize()
        
        try:
            # Load configuration
            if not self._config_service.is_healthy():
                raise ConfigurationError("Configuration service is not healthy")
            
            self._config = self._config_service.config
            firewall_config = self._config_service.get_section('firewall')
            
            self._security_group_id = firewall_config.get('rule_group')
            self._logger.info(f"Firewall service initialized with security group: {self._security_group_id}")
            
            await self._load_existing_rules()
            
        except Exception as e:
            await self.audit_action("system", "service_initialization", None, {"error": str(e)}, False)
            raise ServiceError(f"Failed to initialize firewall service: {str(e)}")
    
    async def _load_existing_rules(self) -> None:
        """Load existing firewall rules from storage."""
        # In production, this would load from database
        # For now, initialize with default rules
        default_rules = [
            FirewallRule(
                rule_id="default-allow-http",
                direction="ingress",
                protocol="tcp",
                port_range="80",
                cidr_blocks=["0.0.0.0/0"],
                description="Allow HTTP traffic",
                priority=200
            ),
            FirewallRule(
                rule_id="default-allow-https",
                direction="ingress",
                protocol="tcp",
                port_range="443",
                cidr_blocks=["0.0.0.0/0"],
                description="Allow HTTPS traffic",
                priority=200
            )
        ]
        
        for rule in default_rules:
            self._rules[rule.rule_id] = rule
        
        self._logger.info(f"Loaded {len(self._rules)} existing firewall rules")
    
    @asynccontextmanager
    async def _aws_operation(self, operation_name: str):
        """Context manager for AWS operations with error handling."""
        async with self.operation_context(operation_name) as ctx:
            try:
                if not self._aws_client:
                    raise ServiceError("AWS client not available")
                
                yield ctx
                self._metrics['operations_succeeded'] += 1
                
            except Exception as e:
                self._metrics['operations_failed'] += 1
                self._logger.error(f"AWS operation '{operation_name}' failed: {str(e)}")
                raise ExternalServiceError(f"AWS operation failed: {str(e)}")
    
    async def create_rule(self, 
                         user_id: str,
                         rule_data: Dict[str, Any]) -> OperationResult:
        """
        Create a new firewall rule.
        
        Args:
            user_id: User ID performing the operation
            rule_data: Rule configuration data
            
        Returns:
            Operation result with created rule
        """
        async with self.operation_context("create_rule", user_id) as ctx:
            try:
                # Validate permissions
                if not await self.validate_permissions(user_id, "firewall:rule:create"):
                    raise AuthorizationError(f"User {user_id} not authorized to create firewall rules")
                
                # Validate rule data
                validation_result = await self._validate_rule_data(rule_data)
                if not validation_result.is_valid:
                    raise ValidationError(f"Invalid rule data: {validation_result.errors}")
                
                # Create rule
                rule_id = self._generate_rule_id()
                rule = FirewallRule(
                    rule_id=rule_id,
                    direction=rule_data.get('direction'),
                    protocol=rule_data.get('protocol'),
                    port_range=rule_data.get('port_range'),
                    cidr_blocks=rule_data.get('cidr_blocks', []),
                    description=rule_data.get('description', ''),
                    priority=rule_data.get('priority', 100),
                    enabled=rule_data.get('enabled', True)
                )
                
                # Store rule
                self._rules[rule_id] = rule
                
                # Apply to AWS if configured
                if self._config.firewall_enabled and self._aws_client:
                    await self._apply_rule_to_aws(rule)
                
                # Cache invalidation
                if self._cache_service:
                    await self._cache_service.delete_pattern("firewall:rules:*")
                
                # Audit logging
                await self.audit_action(
                    user_id, 
                    "firewall_rule_created", 
                    rule.rule_id,
                    {"rule_data": rule_data}
                )
                
                # Update metrics
                self._metrics['rules_created'] += 1
                
                self._logger.info(f"Created firewall rule: {rule_id}")
                
                return OperationResult.success(rule, "Firewall rule created successfully")
                
            except Exception as e:
                self._logger.error(f"Failed to create firewall rule: {str(e)}")
                raise
    
    async def update_rule(self, 
                         user_id: str,
                         rule_id: str,
                         updates: Dict[str, Any]) -> OperationResult:
        """
        Update an existing firewall rule.
        
        Args:
            user_id: User ID performing the operation
            rule_id: Rule ID to update
            updates: Updates to apply
            
        Returns:
            Operation result with updated rule
        """
        async with self.operation_context("update_rule", user_id) as ctx:
            try:
                # Validate permissions
                if not await self.validate_permissions(user_id, "firewall:rule:update"):
                    raise AuthorizationError(f"User {user_id} not authorized to update firewall rules")
                
                # Get existing rule
                if rule_id not in self._rules:
                    raise ValidationError(f"Rule {rule_id} not found")
                
                rule = self._rules[rule_id]
                old_data = rule.to_dict()
                
                # Apply updates
                for field, value in updates.items():
                    if hasattr(rule, field) and field not in ['rule_id', 'created_at']:
                        setattr(rule, field, value)
                
                rule.updated_at = datetime.utcnow()
                
                # Validate updated rule
                validation_result = await self._validate_rule_data(rule.to_dict())
                if not validation_result.is_valid:
                    # Revert changes
                    self._rules[rule_id] = FirewallRule(**old_data)
                    raise ValidationError(f"Invalid rule updates: {validation_result.errors}")
                
                # Apply to AWS if configured
                if self._config.firewall_enabled and self._aws_client:
                    await self._update_rule_in_aws(rule)
                
                # Cache invalidation
                if self._cache_service:
                    await self._cache_service.delete_pattern("firewall:rules:*")
                
                # Audit logging
                await self.audit_action(
                    user_id, 
                    "firewall_rule_updated", 
                    rule.rule_id,
                    {"old_data": old_data, "updates": updates}
                )
                
                # Update metrics
                self._metrics['rules_modified'] += 1
                
                self._logger.info(f"Updated firewall rule: {rule_id}")
                
                return OperationResult.success(rule, "Firewall rule updated successfully")
                
            except Exception as e:
                self._logger.error(f"Failed to update firewall rule {rule_id}: {str(e)}")
                raise
    
    async def delete_rule(self, 
                         user_id: str,
                         rule_id: str) -> OperationResult:
        """
        Delete a firewall rule.
        
        Args:
            user_id: User ID performing the operation
            rule_id: Rule ID to delete
            
        Returns:
            Operation result with success flag
        """
        async with self.operation_context("delete_rule", user_id) as ctx:
            try:
                # Validate permissions
                if not await self.validate_permissions(user_id, "firewall:rule:delete"):
                    raise AuthorizationError(f"User {user_id} not authorized to delete firewall rules")
                
                # Check if rule exists
                if rule_id not in self._rules:
                    raise ValidationError(f"Rule {rule_id} not found")
                
                rule = self._rules[rule_id]
                
                # Remove from AWS if configured
                if self._config.firewall_enabled and self._aws_client:
                    await self._remove_rule_from_aws(rule)
                
                # Remove from storage
                del self._rules[rule_id]
                
                # Cache invalidation
                if self._cache_service:
                    await self._cache_service.delete_pattern("firewall:rules:*")
                
                # Audit logging
                await self.audit_action(
                    user_id, 
                    "firewall_rule_deleted", 
                    rule_id,
                    {"rule_data": rule.to_dict()}
                )
                
                # Update metrics
                self._metrics['rules_deleted'] += 1
                
                self._logger.info(f"Deleted firewall rule: {rule_id}")
                
                return OperationResult.success(True, "Firewall rule deleted successfully")
                
            except Exception as e:
                self._logger.error(f"Failed to delete firewall rule {rule_id}: {str(e)}")
                raise
    
    async def block_ip(self, 
                      user_id: str,
                      ip_address: str,
                      reason: str = "",
                      duration_hours: int = 24) -> OperationResult:
        """
        Block an IP address.
        
        Args:
            user_id: User ID performing the operation
            ip_address: IP address to block
            reason: Reason for blocking
            duration_hours: Duration in hours for the block
            
        Returns:
            Operation result with block ID
        """
        async with self.operation_context("block_ip", user_id) as ctx:
            try:
                # Validate permissions
                if not await self.validate_permissions(user_id, "firewall:ip:block"):
                    raise AuthorizationError(f"User {user_id} not authorized to block IPs")
                
                # Validate IP address
                if not self._is_valid_ip(ip_address):
                    raise ValidationError(f"Invalid IP address: {ip_address}")
                
                # Create block record
                block_id = f"block-{ip_address}-{int(datetime.utcnow().timestamp())}"
                block_data = {
                    'ip_address': ip_address,
                    'blocked_at': datetime.utcnow(),
                    'blocked_by': user_id,
                    'reason': reason,
                    'expires_at': datetime.utcnow() + timedelta(hours=duration_hours),
                    'block_id': block_id
                }
                
                # Store block record
                self._blocked_ips[ip_address] = block_data
                
                # Apply to AWS if configured
                if self._config.firewall_enabled and self._aws_client:
                    await self._block_ip_in_aws(ip_address, reason)
                
                # Cache invalidation
                if self._cache_service:
                    await self._cache_service.delete_pattern("firewall:blocked_ips:*")
                
                # Audit logging
                await self.audit_action(
                    user_id, 
                    "ip_blocked", 
                    ip_address,
                    {"block_id": block_id, "reason": reason, "duration_hours": duration_hours}
                )
                
                # Update metrics
                self._metrics['ips_blocked'] += 1
                
                self._logger.info(f"Blocked IP address: {ip_address} (reason: {reason})")
                
                return OperationResult.success(block_id, f"IP {ip_address} blocked successfully")
                
            except Exception as e:
                self._logger.error(f"Failed to block IP {ip_address}: {str(e)}")
                raise
    
    async def unblock_ip(self, 
                        user_id: str,
                        ip_address: str) -> OperationResult:
        """
        Unblock an IP address.
        
        Args:
            user_id: User ID performing the operation
            ip_address: IP address to unblock
            
        Returns:
            Operation result with success flag
        """
        async with self.operation_context("unblock_ip", user_id) as ctx:
            try:
                # Validate permissions
                if not await self.validate_permissions(user_id, "firewall:ip:unblock"):
                    raise AuthorizationError(f"User {user_id} not authorized to unblock IPs")
                
                # Check if IP is blocked
                if ip_address not in self._blocked_ips:
                    raise ValidationError(f"IP {ip_address} is not currently blocked")
                
                block_data = self._blocked_ips[ip_address]
                
                # Remove from AWS if configured
                if self._config.firewall_enabled and self._aws_client:
                    await self._unblock_ip_in_aws(ip_address)
                
                # Remove block record
                del self._blocked_ips[ip_address]
                
                # Cache invalidation
                if self._cache_service:
                    await self._cache_service.delete_pattern("firewall:blocked_ips:*")
                
                # Audit logging
                await self.audit_action(
                    user_id, 
                    "ip_unblocked", 
                    ip_address,
                    {"original_block_data": block_data}
                )
                
                # Update metrics
                self._metrics['ips_unblocked'] += 1
                
                self._logger.info(f"Unblocked IP address: {ip_address}")
                
                return OperationResult.success(True, f"IP {ip_address} unblocked successfully")
                
            except Exception as e:
                self._logger.error(f"Failed to unblock IP {ip_address}: {str(e)}")
                raise
    
    async def get_rules(self, 
                       user_id: str,
                       enabled_only: bool = False) -> OperationResult:
        """
        Get firewall rules.
        
        Args:
            user_id: User ID performing the operation
            enabled_only: Whether to return only enabled rules
            
        Returns:
            Operation result with list of rules
        """
        async with self.operation_context("get_rules", user_id) as ctx:
            try:
                # Validate permissions
                if not await self.validate_permissions(user_id, "firewall:rule:read"):
                    raise AuthorizationError(f"User {user_id} not authorized to read firewall rules")
                
                rules = list(self._rules.values())
                
                if enabled_only:
                    rules = [rule for rule in rules if rule.enabled]
                
                # Sort by priority
                rules.sort(key=lambda r: r.priority)
                
                return OperationResult.success(rules, f"Retrieved {len(rules)} firewall rules")
                
            except Exception as e:
                self._logger.error(f"Failed to get firewall rules: {str(e)}")
                raise
    
    async def get_blocked_ips(self, 
                             user_id: str,
                             include_expired: bool = False) -> OperationResult:
        """
        Get list of blocked IPs.
        
        Args:
            user_id: User ID performing the operation
            include_expired: Whether to include expired blocks
            
        Returns:
            Operation result with list of blocked IPs
        """
        async with self.operation_context("get_blocked_ips", user_id) as ctx:
            try:
                # Validate permissions
                if not await self.validate_permissions(user_id, "firewall:ip:read"):
                    raise AuthorizationError(f"User {user_id} not authorized to read blocked IPs")
                
                blocked_ips = list(self._blocked_ips.values())
                
                if not include_expired:
                    now = datetime.utcnow()
                    blocked_ips = [
                        block for block in blocked_ips 
                        if block['expires_at'] > now
                    ]
                
                # Convert datetime objects to strings for JSON serialization
                result = []
                for block in blocked_ips:
                    block_copy = block.copy()
                    block_copy['blocked_at'] = block['blocked_at'].isoformat()
                    block_copy['expires_at'] = block['expires_at'].isoformat()
                    result.append(block_copy)
                
                return OperationResult.success(result, f"Retrieved {len(result)} blocked IPs")
                
            except Exception as e:
                self._logger.error(f"Failed to get blocked IPs: {str(e)}")
                raise
    
    async def get_metrics(self, 
                         user_id: str) -> OperationResult:
        """
        Get firewall service metrics.
        
        Args:
            user_id: User ID performing the operation
            
        Returns:
            Operation result with metrics
        """
        async with self.operation_context("get_metrics", user_id) as ctx:
            try:
                # Validate permissions
                if not await self.validate_permissions(user_id, "firewall:metrics:read"):
                    raise AuthorizationError(f"User {user_id} not authorized to read firewall metrics")
                
                metrics = {
                    **self._metrics,
                    'total_rules': len(self._rules),
                    'enabled_rules': len([r for r in self._rules.values() if r.enabled]),
                    'blocked_ips': len(self._blocked_ips),
                    'active_blocks': len([
                        b for b in self._blocked_ips.values() 
                        if b['expires_at'] > datetime.utcnow()
                    ]),
                    'aws_integration_enabled': self._config.firewall_enabled if self._config else False,
                    'security_group_id': self._security_group_id
                }
                
                return OperationResult.success(metrics, "Firewall metrics retrieved successfully")
                
            except Exception as e:
                self._logger.error(f"Failed to get firewall metrics: {str(e)}")
                raise
    
    async def _validate_rule_data(self, rule_data: Dict[str, Any]) -> OperationResult:
        """Validate firewall rule data."""
        try:
            required_fields = ['direction', 'protocol', 'port_range', 'cidr_blocks']
            errors = []
            
            for field in required_fields:
                if field not in rule_data or not rule_data[field]:
                    errors.append(f"Missing required field: {field}")
            
            if 'direction' in rule_data and rule_data['direction'] not in ['ingress', 'egress']:
                errors.append("Direction must be 'ingress' or 'egress'")
            
            if 'protocol' in rule_data:
                valid_protocols = ['tcp', 'udp', 'icmp', 'all']
                if rule_data['protocol'] not in valid_protocols:
                    errors.append(f"Protocol must be one of: {', '.join(valid_protocols)}")
            
            if 'cidr_blocks' in rule_data:
                cidr_blocks = rule_data['cidr_blocks']
                if not isinstance(cidr_blocks, list):
                    errors.append("CIDR blocks must be a list")
                else:
                    for cidr in cidr_blocks:
                        if not self._is_valid_cidr(cidr):
                            errors.append(f"Invalid CIDR block: {cidr}")
            
            if errors:
                return OperationResult.error("Validation failed", errors)
            
            return OperationResult.success(True, "Rule data is valid")
            
        except Exception as e:
            return OperationResult.error(f"Validation error: {str(e)}", [str(e)])
    
    def _generate_rule_id(self) -> str:
        """Generate a unique rule ID."""
        timestamp = int(datetime.utcnow().timestamp())
        random_suffix = hash(str(timestamp)) % 10000
        return f"rule-{timestamp}-{random_suffix}"
    
    def _is_valid_ip(self, ip_address: str) -> bool:
        """Validate IP address format."""
        import re
        ipv4_pattern = r'^(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$'
        return bool(re.match(ipv4_pattern, ip_address))
    
    def _is_valid_cidr(self, cidr: str) -> bool:
        """Validate CIDR notation."""
        import re
        pattern = r'^(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)/(?:[0-9]|[1-2][0-9]|3[0-2])$'
        return bool(re.match(pattern, cidr))
    
    async def _apply_rule_to_aws(self, rule: FirewallRule) -> None:
        """Apply rule to AWS security group."""
        if not self._aws_client:
            return
        
        async with self._aws_operation("apply_rule_to_aws"):
            # Implementation would depend on AWS client interface
            # This is a placeholder for AWS Security Group operations
            pass
    
    async def _update_rule_in_aws(self, rule: FirewallRule) -> None:
        """Update rule in AWS security group."""
        if not self._aws_client:
            return
        
        async with self._aws_operation("update_rule_in_aws"):
            # Implementation for updating AWS rule
            pass
    
    async def _remove_rule_from_aws(self, rule: FirewallRule) -> None:
        """Remove rule from AWS security group."""
        if not self._aws_client:
            return
        
        async with self._aws_operation("remove_rule_from_aws"):
            # Implementation for removing AWS rule
            pass
    
    async def _block_ip_in_aws(self, ip_address: str, reason: str) -> None:
        """Block IP in AWS security group."""
        if not self._aws_client:
            return
        
        async with self._aws_operation("block_ip_in_aws"):
            # Implementation for AWS IP blocking
            pass
    
    async def _unblock_ip_in_aws(self, ip_address: str) -> None:
        """Unblock IP in AWS security group."""
        if not self._aws_client:
            return
        
        async with self._aws_operation("unblock_ip_in_aws"):
            # Implementation for AWS IP unblocking
            pass
    
    async def cleanup_expired_blocks(self) -> OperationResult:
        """Clean up expired IP blocks."""
        async with self.operation_context("cleanup_expired_blocks") as ctx:
            try:
                now = datetime.utcnow()
                expired_ips = [
                    ip for ip, block in self._blocked_ips.items()
                    if block['expires_at'] < now
                ]
                
                for ip in expired_ips:
                    del self._blocked_ips[ip]
                    
                    # Remove from AWS if configured
                    if self._config.firewall_enabled and self._aws_client:
                        await self._unblock_ip_in_aws(ip)
                
                # Cache invalidation
                if self._cache_service:
                    await self._cache_service.delete_pattern("firewall:blocked_ips:*")
                
                self._logger.info(f"Cleaned up {len(expired_ips)} expired IP blocks")
                
                return OperationResult.success(
                    len(expired_ips), 
                    f"Cleaned up {len(expired_ips)} expired IP blocks"
                )
                
            except Exception as e:
                self._logger.error(f"Failed to cleanup expired blocks: {str(e)}")
                raise
    
    async def health_check(self) -> Dict[str, Any]:
        """Perform health check for the firewall service."""
        base_health = await super().health_check()

        firewall_health = {
            'total_rules': len(self._rules),
            'enabled_rules': len([r for r in self._rules.values() if r.enabled]),
            'blocked_ips': len(self._blocked_ips),
            'active_blocks': len([
                b for b in self._blocked_ips.values()
                if b['expires_at'] > datetime.utcnow()
            ]),
            'metrics': self._metrics,
            'config_loaded': self._config is not None,
            'aws_client_available': self._aws_client is not None
        }

        base_health.update(firewall_health)

        return base_health

    def get_service_info(self) -> Dict[str, Any]:
        """
        Get information about the firewall service.

        Returns:
            Service information including capabilities and configuration
        """
        return {
            'service_name': 'firewall_service',
            'version': '1.0.0',
            'description': 'Firewall rule and IP blocking management service',
            'capabilities': [
                'firewall_rule_management',
                'ip_blocking',
                'ip_unblocking',
                'rule_validation',
                'aws_security_group_integration'
            ],
            'configuration': {
                'security_group_id': self._security_group_id,
                'firewall_enabled': self._config.firewall_enabled if self._config else False,
                'aws_integration': self._aws_client is not None
            },
            'metrics': {
                'total_rules': len(self._rules),
                'enabled_rules': len([r for r in self._rules.values() if r.enabled]),
                'blocked_ips': len(self._blocked_ips),
                'operations_count': self._metrics
            }
        }
