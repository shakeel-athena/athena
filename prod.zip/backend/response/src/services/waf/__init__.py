"""
WAF Service Module

Provides Web Application Firewall management functionality including
signature management, rule group management, and IP reputation controls.
"""

from .waf_service import WAFService

__all__ = ['WAFService']
