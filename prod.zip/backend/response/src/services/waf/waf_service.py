"""
WAF Service

Handles all Web Application Firewall operations including signature management,
rule group management, IP reputation controls, and geo-restrictions.
"""

import logging
from typing import Dict, List, Any, Optional
from datetime import datetime

from services.base_service import BaseService
from services.aws import AWSService
from errors.error_types import (
    ValidationError,
    ServiceError,
    ExternalServiceError,
    ConfigurationError
)


class WAFService(BaseService):
    """
    Service for managing Web Application Firewall configurations.

    Provides high-level operations for:
    - Signature management (custom and AWS managed)
    - Rule group management
    - IP reputation controls
    - Geo-restriction management
    - Configuration management
    """

    def __init__(self,
                 aws_service: Optional[AWSService] = None,
                 config_service=None,
                 cache_service=None,
                 audit_service=None):
        """
        Initialize WAF service.

        Args:
            aws_service: AWS Service instance for centralized AWS operations
            config_service: Configuration service instance
            cache_service: Cache service for performance optimization
            audit_service: Audit service for logging operations
        """
        super().__init__(
            logger=logging.getLogger(self.__class__.__name__),
            config_service=config_service,
            cache_service=cache_service,
            audit_service=audit_service
        )

        # Dependencies
        self._aws_service = aws_service

        # Manager instances (lazy-loaded)
        self._signature_manager = None
        self._ip_reputation_manager = None
        self._common_attack_manager = None
        self._anonymous_ip_manager = None
        self._linux_vuln_manager = None
        self._unix_vuln_manager = None
        self._known_bad_inputs_manager = None
        self._geo_blocking_manager = None

        # Configuration
        self._web_acl_name = None
        self._web_acl_id = None
        self._web_acl_scope = None
        self._aws_region = None

    def _initialize_managers(self):
        """Lazy initialization of WAF manager instances."""
        if self._signature_manager is None:
            from models.WAF_Signature_Blocking import WAFSignatureBlockingManager
            from models.WAF_IP_REPU_SIG import WAFIPReputationManager
            from models.WAF_CommonAttackManager import WAFCommonAttackManager
            from models.WAF_AnonymousIPManager import WAFAnonymousIPManager
            from models.WAF_LinuxVulnManager import WAFLinuxVulnManager
            from models.WAF_UnixVulnManager import WAFUnixVulnManager
            from models.WAF_KnownBadInputsManager import WAFKnownBadInputsManager
            from models.Geo_blocking import GeoBlockingManager

            # Get configuration
            import os
            self._web_acl_name = os.getenv("WAF_WEB_ACL")
            self._aws_region = os.getenv("AWS_REGION", "us-east-2")
            self._web_acl_scope = os.getenv("AWS_SCOPE", "REGIONAL")

            # Get WAF client from AWS Service
            if self._aws_service:
                waf_client_wrapper = self._aws_service.get_waf_client(scope=self._web_acl_scope)
                # Extract raw boto3 client for legacy managers
                waf_client = waf_client_wrapper.client
            else:
                # Fallback to direct client creation for backward compatibility
                import boto3
                session = boto3.Session(region_name=self._aws_region)
                waf_client = session.client('wafv2', region_name=self._aws_region)

            # Initialize managers
            self._signature_manager = WAFSignatureBlockingManager(
                wafv2_client=waf_client,
                web_acl_name=self._web_acl_name,
                scope=self._web_acl_scope
            )

            self._ip_reputation_manager = WAFIPReputationManager(
                wafv2_client=waf_client,
                scope=self._web_acl_scope,
                region=self._aws_region
            )

            self._common_attack_manager = WAFCommonAttackManager(
                wafv2_client=waf_client,
                scope=self._web_acl_scope,
                region=self._aws_region
            )

            self._anonymous_ip_manager = WAFAnonymousIPManager(
                wafv2_client=waf_client,
                scope=self._web_acl_scope,
                region=self._aws_region
            )

            self._linux_vuln_manager = WAFLinuxVulnManager(
                wafv2_client=waf_client,
                scope=self._web_acl_scope,
                region=self._aws_region
            )

            self._unix_vuln_manager = WAFUnixVulnManager(
                wafv2_client=waf_client,
                scope=self._web_acl_scope,
                region=self._aws_region
            )

            self._known_bad_inputs_manager = WAFKnownBadInputsManager(
                wafv2_client=waf_client,
                scope=self._web_acl_scope,
                region=self._aws_region
            )

            self._geo_blocking_manager = GeoBlockingManager(
                wafv2=waf_client,
                scope=self._web_acl_scope
            )

    # ========================================================================
    # Signature Management Operations
    # ========================================================================

    def get_available_signatures(self) -> Dict[str, Any]:
        """
        Get all available WAF signatures (custom and AWS managed).

        Returns:
            Dictionary of available signatures
        """
        try:
            self._initialize_managers()
            return self._signature_manager.get_available_signatures()
        except Exception as e:
            self.logger.error(f"Failed to get available signatures: {e}")
            raise ServiceError(f"Failed to get available signatures: {str(e)}")

    def get_custom_signatures(self) -> Dict[str, Any]:
        """
        Get only custom WAF signatures.

        Returns:
            Dictionary of custom signatures
        """
        try:
            all_sigs = self.get_available_signatures()
            return {k: v for k, v in all_sigs.items() if v.get("type") == "CUSTOM"}
        except Exception as e:
            self.logger.error(f"Failed to get custom signatures: {e}")
            raise ServiceError(f"Failed to get custom signatures: {str(e)}")

    def get_aws_managed_signatures(self) -> Dict[str, Any]:
        """
        Get only AWS managed WAF signatures.

        Returns:
            Dictionary of AWS managed signatures
        """
        try:
            all_sigs = self.get_available_signatures()
            return {k: v for k, v in all_sigs.items() if v.get("type") == "MANAGED"}
        except Exception as e:
            self.logger.error(f"Failed to get AWS managed signatures: {e}")
            raise ServiceError(f"Failed to get AWS managed signatures: {str(e)}")

    def get_signature_status(self) -> Dict[str, Any]:
        """
        Get the status of all WAF signatures (active/inactive).

        Returns:
            Dictionary with signature status information
        """
        try:
            self._initialize_managers()
            return self._signature_manager.get_signature_status()
        except Exception as e:
            msg = str(e)
            if "Web ACL" in msg and ("not found" in msg or "must be provided" in msg):
                return {}
            self.logger.error(f"Failed to get signature status: {e}")
            raise ServiceError(f"Failed to get signature status: {msg}")

    def get_active_signatures(self) -> List[str]:
        """
        Get currently active WAF signatures.

        Returns:
            List of active signature IDs
        """
        try:
            self._initialize_managers()
            return self._signature_manager.get_active_signatures()
        except Exception as e:
            msg = str(e)
            if "Web ACL" in msg and ("not found" in msg or "must be provided" in msg):
                return []
            self.logger.error(f"Failed to get active signatures: {e}")
            raise ServiceError(f"Failed to get active signatures: {msg}")

    def add_signature(self, signature_id: str) -> bool:
        """
        Add a WAF signature to the Web ACL.

        Args:
            signature_id: ID of the signature to add

        Returns:
            True if signature was added, False if already exists
        """
        if not signature_id:
            raise ValidationError("signature_id is required")

        try:
            self._initialize_managers()
            return self._signature_manager.add_signature(signature_id)
        except Exception as e:
            self.logger.error(f"Failed to add signature {signature_id}: {e}")
            raise ServiceError(f"Failed to add signature: {str(e)}")

    def remove_signature(self, signature_id: str) -> bool:
        """
        Remove a WAF signature from the Web ACL.

        Args:
            signature_id: ID of the signature to remove

        Returns:
            True if signature was removed successfully
        """
        if not signature_id:
            raise ValidationError("signature_id is required")

        try:
            self._initialize_managers()
            return self._signature_manager.remove_signature(signature_id)
        except Exception as e:
            self.logger.error(f"Failed to remove signature {signature_id}: {e}")
            raise ServiceError(f"Failed to remove signature: {str(e)}")

    def toggle_signature(self, signature_id: str, enabled: bool) -> bool:
        """
        Toggle a WAF signature on/off.

        Args:
            signature_id: ID of the signature to toggle
            enabled: True to enable, False to disable

        Returns:
            True if toggle was successful
        """
        if not signature_id:
            raise ValidationError("signature_id is required")

        try:
            self._initialize_managers()
            return self._signature_manager.toggle_signature(signature_id, enabled)
        except Exception as e:
            self.logger.error(f"Failed to toggle signature {signature_id}: {e}")
            raise ServiceError(f"Failed to toggle signature: {str(e)}")

    def add_multiple_signatures(self, signature_ids: List[str]) -> Dict[str, Any]:
        """
        Add multiple WAF signatures at once.

        Args:
            signature_ids: List of signature IDs to add

        Returns:
            Dictionary with results for each signature
        """
        if not signature_ids:
            raise ValidationError("signature_ids list is required")

        try:
            self._initialize_managers()
            return self._signature_manager.add_multiple_signatures(signature_ids)
        except Exception as e:
            self.logger.error(f"Failed to add multiple signatures: {e}")
            raise ServiceError(f"Failed to add multiple signatures: {str(e)}")

    def remove_multiple_signatures(self, signature_ids: List[str]) -> Dict[str, Any]:
        """
        Remove multiple WAF signatures at once.

        Args:
            signature_ids: List of signature IDs to remove

        Returns:
            Dictionary with results for each signature
        """
        if not signature_ids:
            raise ValidationError("signature_ids list is required")

        try:
            self._initialize_managers()
            return self._signature_manager.remove_multiple_signatures(signature_ids)
        except Exception as e:
            self.logger.error(f"Failed to remove multiple signatures: {e}")
            raise ServiceError(f"Failed to remove multiple signatures: {str(e)}")

    def add_all_signatures(self) -> Dict[str, Any]:
        """
        Add all available signatures to the Web ACL.

        Returns:
            Dictionary with operation results
        """
        try:
            self._initialize_managers()
            return self._signature_manager.add_all_signatures()
        except Exception as e:
            self.logger.error(f"Failed to add all signatures: {e}")
            raise ServiceError(f"Failed to add all signatures: {str(e)}")

    def remove_all_signatures(self) -> Dict[str, Any]:
        """
        Remove all signatures from the Web ACL.

        Returns:
            Dictionary with operation results
        """
        try:
            self._initialize_managers()
            return self._signature_manager.remove_all_signatures()
        except Exception as e:
            self.logger.error(f"Failed to remove all signatures: {e}")
            raise ServiceError(f"Failed to remove all signatures: {str(e)}")

    # ========================================================================
    # Configuration Management
    # ========================================================================

    def get_waf_configuration(self) -> Dict[str, Any]:
        """
        Get current WAF configuration.

        Returns:
            Dictionary with WAF configuration details
        """
        try:
            self._initialize_managers()
            return self._signature_manager.get_waf_configuration()
        except Exception as e:
            self.logger.error(f"Failed to get WAF configuration: {e}")
            raise ServiceError(f"Failed to get WAF configuration: {str(e)}")

    # ========================================================================
    # Geo-Restriction Management
    # ========================================================================

    def get_geo_restrictions(self) -> Dict[str, Any]:
        """
        Get list of allowed countries (inverse of geo-restricted).

        Returns:
            Dictionary with allowed_countries list
        """
        try:
            self._initialize_managers()
            # Get the blocked countries from WAF
            blocked_countries = self._geo_blocking_manager.get_countries(self._web_acl_name)
            # Return as allowed_countries format expected by frontend
            return {"allowed_countries": blocked_countries}
        except Exception as e:
            self.logger.error(f"Failed to get geo restrictions: {e}")
            raise ServiceError(f"Failed to get geo restrictions: {str(e)}")

    def update_geo_restrictions(self, country_codes: List[str]) -> bool:
        """
        Update geo-restriction list (set allowed countries).

        Args:
            country_codes: List of country codes to allow

        Returns:
            True if update was successful
        """
        if not isinstance(country_codes, list):
            raise ValidationError("country_codes must be a list")

        try:
            self._initialize_managers()
            self._geo_blocking_manager.set_countries(country_codes, self._web_acl_name)
            return True
        except Exception as e:
            self.logger.error(f"Failed to update geo restrictions: {e}")
            raise ServiceError(f"Failed to update geo restrictions: {str(e)}")

    # ========================================================================
    # IP Reputation Management
    # ========================================================================

    def get_ip_reputation_rules(self) -> Dict[str, Any]:
        """
        Get IP reputation rules configuration.

        Returns:
            Dictionary with IP reputation rules
        """
        try:
            self._initialize_managers()
            return self._ip_reputation_manager.get_ip_reputation_rules(self._web_acl_name)
        except Exception as e:
            self.logger.error(f"Failed to get IP reputation rules: {e}")
            raise ServiceError(f"Failed to get IP reputation rules: {str(e)}")

    def update_ip_reputation_action(self, rule_name: str, action: str) -> bool:
        """
        Update action for an IP reputation rule.

        Args:
            rule_name: Name of the rule
            action: Action to set (Block, Count, Allow)

        Returns:
            True if update was successful
        """
        if not rule_name:
            raise ValidationError("rule_name is required")

        if action not in ["Block", "Count", "Allow"]:
            raise ValidationError("action must be Block, Count, or Allow")

        try:
            self._initialize_managers()
            return self._ip_reputation_manager.update_rule_action(self._web_acl_name, rule_name, action)
        except Exception as e:
            self.logger.error(f"Failed to update IP reputation rule action: {e}")
            raise ServiceError(f"Failed to update IP reputation rule action: {str(e)}")

    def reset_ip_reputation_rule(self, rule_name: str) -> bool:
        """
        Reset an IP reputation rule to default settings.

        Args:
            rule_name: Name of the rule to reset

        Returns:
            True if reset was successful
        """
        if not rule_name:
            raise ValidationError("rule_name is required")

        try:
            self._initialize_managers()
            return self._ip_reputation_manager.reset_rule_to_default(self._web_acl_name, rule_name)
        except Exception as e:
            self.logger.error(f"Failed to reset IP reputation rule: {e}")
            raise ServiceError(f"Failed to reset IP reputation rule: {str(e)}")

    def add_to_ip_reputation_allowlist(self, rule_name: str, ip_address: str) -> bool:
        """
        Add IP address to reputation rule allowlist.

        Args:
            rule_name: Name of the rule
            ip_address: IP address to allowlist

        Returns:
            True if IP was added successfully
        """
        if not rule_name:
            raise ValidationError("rule_name is required")

        if not ip_address:
            raise ValidationError("ip_address is required")

        try:
            self._initialize_managers()
            return self._ip_reputation_manager.add_to_allowlist(rule_name, ip_address)
        except Exception as e:
            self.logger.error(f"Failed to add IP to allowlist: {e}")
            raise ServiceError(f"Failed to add IP to allowlist: {str(e)}")

    # ========================================================================
    # Rule Group Management
    # ========================================================================

    def get_rule_group_rules(self, group_type: str) -> Dict[str, Any]:
        """
        Get rules for a specific managed rule group.

        Args:
            group_type: Type of rule group (common-attack, anonymous-ip, linux-vuln, unix-vuln, known-bad-inputs)

        Returns:
            Dictionary with rule group rules
        """
        manager_map = {
            'common-attack': self._common_attack_manager,
            'anonymous-ip': self._anonymous_ip_manager,
            'linux-vuln': self._linux_vuln_manager,
            'unix-vuln': self._unix_vuln_manager,
            'known-bad-inputs': self._known_bad_inputs_manager
        }

        if group_type not in manager_map:
            raise ValidationError(f"Invalid group_type: {group_type}")

        try:
            self._initialize_managers()
            manager = manager_map[group_type]
            return manager.get_individual_rules(self._web_acl_name)
        except Exception as e:
            self.logger.error(f"Failed to get rule group rules for {group_type}: {e}")
            raise ServiceError(f"Failed to get rule group rules: {str(e)}")

    def toggle_rule_group_rule(self, group_type: str, rule_name: str, enabled: bool) -> bool:
        """
        Toggle a specific rule in a managed rule group.

        Args:
            group_type: Type of rule group
            rule_name: Name of the rule to toggle
            enabled: True to enable, False to disable

        Returns:
            True if toggle was successful
        """
        manager_map = {
            'common-attack': self._common_attack_manager,
            'anonymous-ip': self._anonymous_ip_manager,
            'linux-vuln': self._linux_vuln_manager,
            'unix-vuln': self._unix_vuln_manager,
            'known-bad-inputs': self._known_bad_inputs_manager
        }

        if group_type not in manager_map:
            raise ValidationError(f"Invalid group_type: {group_type}")

        if not rule_name:
            raise ValidationError("rule_name is required")

        try:
            self._initialize_managers()
            manager = manager_map[group_type]
            return manager.toggle_rule(rule_name, enabled)
        except Exception as e:
            self.logger.error(f"Failed to toggle rule {rule_name} in {group_type}: {e}")
            raise ServiceError(f"Failed to toggle rule: {str(e)}")

    # ========================================================================
    # BaseService Implementation
    # ========================================================================

    async def health_check(self) -> Dict[str, Any]:
        """
        Check the health of the WAF service.

        Returns:
            Health check information including status and any issues
        """
        health = {
            'service': 'WAFService',
            'status': 'healthy',
            'timestamp': datetime.utcnow().isoformat(),
            'checks': {}
        }

        try:
            # Check AWS service connectivity
            if self._aws_service:
                try:
                    # Test AWS service health
                    aws_health = await self._aws_service.health_check()
                    aws_service_status = aws_health.get('aws_service', {})
                    
                    if aws_service_status.get('credentials_valid', False):
                        health['checks']['aws_service'] = 'connected'
                        health['checks']['aws_region'] = aws_service_status.get('region')
                    else:
                        health['checks']['aws_service'] = 'credentials_invalid'
                        health['status'] = 'degraded'
                except Exception as e:
                    health['checks']['aws_service'] = f'error: {str(e)}'
                    health['status'] = 'degraded'
            else:
                health['checks']['aws_service'] = 'not_configured'
                health['status'] = 'degraded'

            # Check configuration
            import os
            if os.getenv("WAF_WEB_ACL"):
                health['checks']['configuration'] = 'valid'
                health['checks']['web_acl'] = os.getenv("WAF_WEB_ACL")
            else:
                health['checks']['configuration'] = 'missing_web_acl'
                health['status'] = 'degraded'

        except Exception as e:
            health['status'] = 'unhealthy'
            health['error'] = str(e)

        return health

    def get_service_info(self) -> Dict[str, Any]:
        """
        Get information about the WAF service.

        Returns:
            Service information including capabilities and configuration
        """
        info = {
            'service': 'WAFService',
            'version': '1.0.0',
            'capabilities': [
                'signature_management',
                'rule_group_management',
                'ip_reputation_control',
                'geo_restrictions',
                'configuration_management'
            ],
            'supported_rule_groups': [
                'common-attack',
                'anonymous-ip',
                'linux-vuln',
                'unix-vuln',
                'known-bad-inputs'
            ],
            'aws_integration': {
                'aws_service_enabled': self._aws_service is not None,
                'client_abstraction': True
            }
        }

        # Add AWS service info if available
        if self._aws_service:
            try:
                aws_info = self._aws_service.get_service_info()
                info['aws_service_info'] = {
                    'service_name': aws_info.get('service_name'),
                    'version': aws_info.get('version'),
                    'region': self._aws_service.get_region()
                }
            except Exception as e:
                self.logger.warning(f"Failed to get AWS service info: {e}")

        return info
