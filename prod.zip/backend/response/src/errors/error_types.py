"""
Error Types Module

Defines custom exception classes for the Athena backend with proper
classification and context handling.
"""

from abc import ABC
from enum import Enum
from typing import Dict, Any, Optional, Union
import traceback
from datetime import datetime


class ErrorCategory(Enum):
    """Error categories for classification"""
    VALIDATION = "validation"
    AUTHENTICATION = "authentication"
    AUTHORIZATION = "authorization"
    BUSINESS_LOGIC = "business_logic"
    EXTERNAL_SERVICE = "external_service"
    DATABASE = "database"
    NETWORK = "network"
    SYSTEM = "system"
    UNKNOWN = "unknown"


class ErrorSeverity(Enum):
    """Error severity levels"""
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    CRITICAL = "critical"


class ErrorContext:
    """Context information for errors"""
    
    def __init__(self, 
                 user_id: str = None, 
                 request_id: str = None, 
                 endpoint: str = None, 
                 method: str = None, 
                 service: str = None,
                 additional_data: Dict[str, Any] = None):
        """
        Initialize error context.
        
        Args:
            user_id: ID of the user who triggered the error
            request_id: Unique request identifier
            endpoint: API endpoint where error occurred
            method: HTTP method
            service: Service where error occurred
            additional_data: Additional context data
        """
        self.user_id = user_id
        self.request_id = request_id
        self.endpoint = endpoint
        self.method = method
        self.service = service
        self.additional_data = additional_data or {}
        self.timestamp = datetime.utcnow()
        self.stack_trace = None
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert context to dictionary"""
        return {
            'user_id': self.user_id,
            'request_id': self.request_id,
            'endpoint': self.endpoint,
            'method': self.method,
            'service': self.service,
            'additional_data': self.additional_data,
            'timestamp': self.timestamp.isoformat(),
            'stack_trace': self.stack_trace
        }


class AthenaError(Exception, ABC):
    """
    Base error class for Athena application.
    
    All custom errors should inherit from this class to ensure
    consistent error handling, logging, and API responses.
    """
    
    def __init__(self, 
                 message: str, 
                 error_code: str = None, 
                 category: ErrorCategory = ErrorCategory.UNKNOWN,
                 severity: ErrorSeverity = ErrorSeverity.MEDIUM,
                 http_status_code: int = 500,
                 context: ErrorContext = None,
                 details: Dict[str, Any] = None,
                 cause: Exception = None,
                 service: str = None):
        """
        Initialize AthenaError.
        
        Args:
            message: Human-readable error message
            error_code: Machine-readable error code
            category: Error category
            severity: Error severity level
            http_status_code: HTTP status code for API responses
            context: Error context information
            details: Additional error details
            cause: Original exception that caused this error
            service: Service where error occurred
        """
        super().__init__(message)
        self.message = message
        self.error_code = error_code or self.__class__.__name__
        self.category = category
        self.severity = severity
        self.http_status_code = http_status_code
        self.context = context or ErrorContext(service=service)
        self.details = details or {}
        self.cause = cause
        
        # Auto-populate context
        if self.context and not self.context.stack_trace:
            self.context.stack_trace = traceback.format_exc()
        
        if service and not self.context.service:
            self.context.service = service
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert error to dictionary for API response"""
        response = {
            'error': True,
            'message': self.message,
            'error_code': self.error_code,
            'category': self.category.value,
            'severity': self.severity.value,
            'timestamp': self.context.timestamp.isoformat() if self.context else datetime.utcnow().isoformat(),
            'request_id': self.context.request_id if self.context else None
        }
        
        # Include additional context in development or for detailed errors
        if self.details:
            response['details'] = self.details
        
        # Include stack trace in development or for critical errors
        if self.context and self.context.stack_trace and self._should_include_stack_trace():
            response['stack_trace'] = self.context.stack_trace
        
        # Include context information for debugging
        if self.context and self._should_include_context():
            response['context'] = {
                'user_id': self.context.user_id,
                'endpoint': self.context.endpoint,
                'method': self.context.method,
                'service': self.context.service
            }
        
        return response
    
    def _should_include_stack_trace(self) -> bool:
        """Determine if stack trace should be included in response"""
        # Include for critical errors or in development environment
        return (self.severity in [ErrorSeverity.HIGH, ErrorSeverity.CRITICAL] or 
                self._is_development_environment())
    
    def _should_include_context(self) -> bool:
        """Determine if context should be included in response"""
        return self._is_development_environment()
    
    def _is_development_environment(self) -> bool:
        """Check if running in development environment"""
        import os
        return os.getenv('ENVIRONMENT', 'production').lower() in ['development', 'dev', 'test']


# Specific Error Types

class ValidationError(AthenaError):
    """Validation error for bad input data"""
    
    def __init__(self, 
                 message: str, 
                 field: str = None, 
                 value: Any = None, 
                 validation_rule: str = None,
                 **kwargs):
        """
        Initialize validation error.
        
        Args:
            message: Validation error message
            field: Field that failed validation
            value: Invalid value
            validation_rule: Rule that was violated
            **kwargs: Additional arguments for parent class
        """
        details = kwargs.get('details', {})
        if field:
            details['field'] = field
        if value is not None:
            details['value'] = str(value)
        if validation_rule:
            details['validation_rule'] = validation_rule
        
        super().__init__(
            message=message,
            category=ErrorCategory.VALIDATION,
            severity=ErrorSeverity.LOW,
            http_status_code=400,
            details=details,
            **kwargs
        )


class AuthenticationError(AthenaError):
    """Authentication error for failed user authentication"""
    
    def __init__(self, 
                 message: str = "Authentication failed", 
                 auth_method: str = None,
                 **kwargs):
        """
        Initialize authentication error.
        
        Args:
            message: Error message
            auth_method: Authentication method that failed
            **kwargs: Additional arguments for parent class
        """
        details = kwargs.get('details', {})
        if auth_method:
            details['auth_method'] = auth_method
        
        super().__init__(
            message=message,
            error_code="AUTHENTICATION_FAILED",
            category=ErrorCategory.AUTHENTICATION,
            severity=ErrorSeverity.MEDIUM,
            http_status_code=401,
            details=details,
            **kwargs
        )


class AuthorizationError(AthenaError):
    """Authorization error for insufficient permissions"""
    
    def __init__(self, 
                 message: str = "Access denied", 
                 required_permission: str = None,
                 user_role: str = None,
                 **kwargs):
        """
        Initialize authorization error.
        
        Args:
            message: Error message
            required_permission: Permission that was required
            user_role: User's current role
            **kwargs: Additional arguments for parent class
        """
        details = kwargs.get('details', {})
        if required_permission:
            details['required_permission'] = required_permission
        if user_role:
            details['user_role'] = user_role
        
        super().__init__(
            message=message,
            error_code="ACCESS_DENIED",
            category=ErrorCategory.AUTHORIZATION,
            severity=ErrorSeverity.MEDIUM,
            http_status_code=403,
            details=details,
            **kwargs
        )


class BusinessLogicError(AthenaError):
    """Business logic error for application-specific rule violations"""
    
    def __init__(self, 
                 message: str, 
                 business_rule: str = None,
                 **kwargs):
        """
        Initialize business logic error.
        
        Args:
            message: Error message
            business_rule: Business rule that was violated
            **kwargs: Additional arguments for parent class
        """
        details = kwargs.get('details', {})
        if business_rule:
            details['business_rule'] = business_rule
        
        super().__init__(
            message=message,
            category=ErrorCategory.BUSINESS_LOGIC,
            severity=ErrorSeverity.MEDIUM,
            http_status_code=422,
            details=details,
            **kwargs
        )


class ExternalServiceError(AthenaError):
    """External service error for third-party service failures"""
    
    def __init__(self, 
                 message: str, 
                 service_name: str = None,
                 service_endpoint: str = None,
                 service_status_code: int = None,
                 **kwargs):
        """
        Initialize external service error.
        
        Args:
            message: Error message
            service_name: Name of external service
            service_endpoint: Endpoint that was called
            service_status_code: HTTP status code from service
            **kwargs: Additional arguments for parent class
        """
        details = kwargs.get('details', {})
        if service_name:
            details['service_name'] = service_name
        if service_endpoint:
            details['service_endpoint'] = service_endpoint
        if service_status_code:
            details['service_status_code'] = service_status_code
        
        super().__init__(
            message=message,
            error_code="EXTERNAL_SERVICE_ERROR",
            category=ErrorCategory.EXTERNAL_SERVICE,
            severity=ErrorSeverity.HIGH,
            http_status_code=502,
            details=details,
            **kwargs
        )


class DatabaseError(AthenaError):
    """Database error for data access failures"""
    
    def __init__(self, 
                 message: str, 
                 query: str = None,
                 table: str = None,
                 **kwargs):
        """
        Initialize database error.
        
        Args:
            message: Error message
            query: Database query that failed
            table: Database table involved
            **kwargs: Additional arguments for parent class
        """
        details = kwargs.get('details', {})
        if query:
            details['query'] = query
        if table:
            details['table'] = table
        
        super().__init__(
            message=message,
            error_code="DATABASE_ERROR",
            category=ErrorCategory.DATABASE,
            severity=ErrorSeverity.HIGH,
            http_status_code=500,
            details=details,
            **kwargs
        )


class NetworkError(AthenaError):
    """Network error for connectivity issues"""
    
    def __init__(self, 
                 message: str, 
                 host: str = None,
                 port: int = None,
                 timeout: float = None,
                 **kwargs):
        """
        Initialize network error.
        
        Args:
            message: Error message
            host: Host that couldn't be reached
            port: Port that couldn't be reached
            timeout: Timeout duration
            **kwargs: Additional arguments for parent class
        """
        details = kwargs.get('details', {})
        if host:
            details['host'] = host
        if port:
            details['port'] = port
        if timeout:
            details['timeout'] = timeout
        
        super().__init__(
            message=message,
            error_code="NETWORK_ERROR",
            category=ErrorCategory.NETWORK,
            severity=ErrorSeverity.HIGH,
            http_status_code=503,
            details=details,
            **kwargs
        )


class SystemError(AthenaError):
    """System error for infrastructure failures"""
    
    def __init__(self, 
                 message: str, 
                 system_component: str = None,
                 error_type: str = None,
                 **kwargs):
        """
        Initialize system error.
        
        Args:
            message: Error message
            system_component: System component that failed
            error_type: Type of system error
            **kwargs: Additional arguments for parent class
        """
        details = kwargs.get('details', {})
        if system_component:
            details['system_component'] = system_component
        if error_type:
            details['error_type'] = error_type
        
        super().__init__(
            message=message,
            error_code="SYSTEM_ERROR",
            category=ErrorCategory.SYSTEM,
            severity=ErrorSeverity.CRITICAL,
            http_status_code=500,
            details=details,
            **kwargs
        )


class ConfigurationError(AthenaError):
    """Configuration error for missing/invalid configuration"""
    
    def __init__(self, 
                 message: str, 
                 config_key: str = None,
                 config_value: str = None,
                 **kwargs):
        """
        Initialize configuration error.
        
        Args:
            message: Error message
            config_key: Configuration key that is problematic
            config_value: Configuration value that is problematic
            **kwargs: Additional arguments for parent class
        """
        details = kwargs.get('details', {})
        if config_key:
            details['config_key'] = config_key
        if config_value is not None:
            details['config_value'] = str(config_value)
        
        super().__init__(
            message=message,
            error_code="CONFIGURATION_ERROR",
            category=ErrorCategory.SYSTEM,
            severity=ErrorSeverity.CRITICAL,
            http_status_code=500,
            details=details,
            **kwargs
        )


class ResourceNotFoundError(AthenaError):
    """Error for when a requested resource is not found"""
    
    def __init__(self, 
                 message: str, 
                 resource_type: str = None,
                 resource_id: str = None,
                 **kwargs):
        """
        Initialize resource not found error.
        
        Args:
            message: Error message
            resource_type: Type of resource that wasn't found
            resource_id: ID/value of resource that wasn't found
            **kwargs: Additional arguments for parent class
        """
        details = kwargs.get('details', {})
        if resource_type:
            details['resource_type'] = resource_type
        if resource_id:
            details['resource_id'] = resource_id
        
        super().__init__(
            message=message,
            error_code="RESOURCE_NOT_FOUND",
            category=ErrorCategory.BUSINESS_LOGIC,
            severity=ErrorSeverity.LOW,
            http_status_code=404,
            details=details,
            **kwargs
        )


class RateLimitError(AthenaError):
    """Error for when rate limits are exceeded"""
    
    def __init__(self, 
                 message: str = "Rate limit exceeded", 
                 limit_type: str = None,
                 reset_time: datetime = None,
                 **kwargs):
        """
        Initialize rate limit error.
        
        Args:
            message: Error message
            limit_type: Type of rate limit that was exceeded
            reset_time: When the rate limit resets
            **kwargs: Additional arguments for parent class
        """
        details = kwargs.get('details', {})
        if limit_type:
            details['limit_type'] = limit_type
        if reset_time:
            details['reset_time'] = reset_time.isoformat()
        
        super().__init__(
            message=message,
            error_code="RATE_LIMIT_EXCEEDED",
            category=ErrorCategory.BUSINESS_LOGIC,
            severity=ErrorSeverity.LOW,
            http_status_code=429,
            details=details,
            **kwargs
        )


class ServiceError(AthenaError):
    """Error for service-related failures"""
    
    def __init__(self, 
                 message: str, 
                 service_name: str = None,
                 operation: str = None,
                 **kwargs):
        """
        Initialize service error.
        
        Args:
            message: Error message
            service_name: Name of the service that failed
            operation: Operation that was being performed
            **kwargs: Additional arguments for parent class
        """
        details = kwargs.get('details', {})
        if service_name:
            details['service_name'] = service_name
        if operation:
            details['operation'] = operation
        
        super().__init__(
            message=message,
            error_code="SERVICE_ERROR",
            category=ErrorCategory.SYSTEM,
            severity=ErrorSeverity.HIGH,
            http_status_code=500,
            details=details,
            **kwargs
        )


class InitializationError(AthenaError):
    """Error for service initialization failures"""
    
    def __init__(self, 
                 message: str, 
                 component: str = None,
                 initialization_step: str = None,
                 **kwargs):
        """
        Initialize initialization error.
        
        Args:
            message: Error message
            component: Component that failed to initialize
            initialization_step: Step in initialization that failed
            **kwargs: Additional arguments for parent class
        """
        details = kwargs.get('details', {})
        if component:
            details['component'] = component
        if initialization_step:
            details['initialization_step'] = initialization_step
        
        super().__init__(
            message=message,
            error_code="INITIALIZATION_ERROR",
            category=ErrorCategory.SYSTEM,
            severity=ErrorSeverity.CRITICAL,
            http_status_code=500,
            details=details,
            **kwargs
        )
