"""
Admin API Blueprint

This module provides the admin API blueprint for user and role management.
"""

from flask import Blueprint

# Create admin blueprint
admin_bp = Blueprint('admin', __name__, url_prefix='/api/admin')

# Import routes to register them with the blueprint
from .users import *
from .roles import *
from .pages import *
