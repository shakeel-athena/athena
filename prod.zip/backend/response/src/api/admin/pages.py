"""
Page Management API - Read-only endpoints for Role Management
This module provides read-only access to pages for role assignment purposes.
The full Page Management UI has been removed.
"""

from flask import jsonify, g
from . import admin_bp
from middleware.auth import require_auth
from utils.rbac import require_admin


@admin_bp.route('/pages', methods=['GET'])
@require_auth
@require_admin()
def get_pages():
    """Get all pages (read-only for role assignment)"""
    try:
        db = g.db

        # Ensure clean transaction
        try:
            db.rollback()
        except:
            pass

        cursor = db.execute("""
            SELECT id, page_path, page_name, page_category as category, description,
                   icon, display_order, is_active, created_at
            FROM pages
            WHERE is_active = TRUE
            ORDER BY page_category, display_order, page_name
        """)
        pages = cursor.fetchall()

        return jsonify({
            'success': True,
            'pages': pages,
            'total': len(pages)
        }), 200

    except Exception as e:
        return jsonify({
            'success': False,
            'message': f'Failed to retrieve pages: {str(e)}'
        }), 500


@admin_bp.route('/pages/categories', methods=['GET'])
@require_auth
@require_admin()
def get_page_categories():
    """Get unique page categories (read-only for role assignment)"""
    try:
        db = g.db

        # Ensure clean transaction
        try:
            db.rollback()
        except:
            pass

        cursor = db.execute("""
            SELECT DISTINCT page_category as category
            FROM pages
            WHERE is_active = TRUE
            ORDER BY page_category
        """)
        categories_data = cursor.fetchall()

        categories = [cat['category'] for cat in categories_data]

        return jsonify({
            'success': True,
            'categories': categories
        }), 200

    except Exception as e:
        return jsonify({
            'success': False,
            'message': f'Failed to retrieve categories: {str(e)}'
        }), 500
