"""
Role Management API
Create, read, update, delete roles and assign permissions
"""

from flask import request, jsonify, g, current_app
from . import admin_bp
from middleware.auth import require_auth
from utils.rbac import require_admin
import logging

logger = logging.getLogger(__name__)


@admin_bp.route('/roles', methods=['GET'])
@require_auth
@require_admin()
def get_roles():
    """
    Get all roles with summary information

    Returns:
        200: List of roles with page and user counts
    """
    try:
        db = g.db

        # Ensure clean transaction
        try:
            db.rollback()
        except:
            pass

        cursor = db.execute("""
            SELECT
                r.id,
                r.role_name,
                r.display_name,
                r.description,
                r.is_system_role,
                r.priority,
                r.created_at,
                COUNT(DISTINCT rp.page_id) as page_count,
                COUNT(DISTINCT ur.user_id) as user_count
            FROM roles r
            LEFT JOIN role_pages rp ON r.id = rp.role_id
            LEFT JOIN user_roles ur ON r.id = ur.role_id
            GROUP BY r.id
            ORDER BY r.priority DESC, r.created_at DESC
        """)

        rows = cursor.fetchall()

        # Convert to list of dicts with proper serialization
        roles = []
        for row in rows:
            role_dict = {
                'id': row['id'],
                'role_name': row['role_name'],
                'display_name': row['display_name'],
                'description': row['description'],
                'is_system_role': row['is_system_role'],
                'priority': row['priority'],
                'created_at': row['created_at'].isoformat() if row['created_at'] else None,
                'page_count': row['page_count'],
                'user_count': row['user_count']
            }
            roles.append(role_dict)

        return jsonify({
            'success': True,
            'roles': roles,
            'total': len(roles)
        }), 200

    except Exception as e:
        logger.error(f"Failed to get roles: {e}")
        try:
            db.rollback()
        except:
            pass
        return jsonify({'error': 'Failed to fetch roles', 'message': str(e)}), 500


@admin_bp.route('/roles/<int:role_id>', methods=['GET'])
@require_auth
@require_admin()
def get_role(role_id):
    """
    Get detailed information about a specific role

    Args:
        role_id: Role ID

    Returns:
        200: Role details including assigned pages
        404: Role not found
    """
    try:
        db = g.db

        # Get role basic info
        cursor = db.execute("""
            SELECT * FROM roles WHERE id = %s
        """, (role_id,))
        role = cursor.fetchone()

        if not role:
            return jsonify({'error': 'Role not found'}), 404

        # Get assigned pages
        cursor = db.execute("""
            SELECT
                p.id as page_id,
                p.page_path,
                p.page_name,
                p.page_category,
                rp.can_view,
                rp.can_edit
            FROM role_pages rp
            JOIN pages p ON rp.page_id = p.id
            WHERE rp.role_id = %s
            ORDER BY p.display_order
        """, (role_id,))
        pages = cursor.fetchall()

        # Get assigned users count
        cursor = db.execute("""
            SELECT COUNT(*) as user_count
            FROM user_roles
            WHERE role_id = %s
        """, (role_id,))
        user_count = cursor.fetchone()['user_count']

        return jsonify({
            'success': True,
            'role': role,
            'pages': pages,
            'user_count': user_count
        }), 200

    except Exception as e:
        logger.error(f"Failed to get role {role_id}: {e}")
        return jsonify({'error': 'Failed to fetch role', 'message': str(e)}), 500


@admin_bp.route('/roles', methods=['POST'])
@require_auth
@require_admin()
def create_role():
    """
    Create a new role

    Body:
        {
            "role_name": "junior-analyst",
            "display_name": "Junior Analyst",
            "description": "Entry level analyst role",
            "priority": 10
        }

    Returns:
        201: Role created successfully
        400: Validation error
        409: Role name already exists
    """
    try:
        data = request.get_json()

        # Validate required fields
        if not data.get('role_name'):
            return jsonify({'error': 'role_name is required'}), 400

        if not data.get('display_name'):
            return jsonify({'error': 'display_name is required'}), 400

        db = g.db
        rbac = g.rbac

        # Check if role name already exists
        cursor = db.execute("""
            SELECT id FROM roles WHERE role_name = %s
        """, (data['role_name'],))

        if cursor.fetchone():
            return jsonify({'error': 'Role name already exists'}), 409

        # Create role
        cursor = db.execute("""
            INSERT INTO roles (role_name, display_name, description, priority, created_by)
            VALUES (%s, %s, %s, %s, %s)
            RETURNING id, role_name, display_name, description, priority, created_at
        """, (
            data['role_name'],
            data['display_name'],
            data.get('description', ''),
            data.get('priority', 0),
            g.user_id
        ))

        role = cursor.fetchone()
        db.commit()

        # Audit log
        rbac.audit_log(
            g.user_id,
            g.db_user['username'],
            'role_created',
            None,
            'allowed',
            f"Created role: {role['role_name']}"
        )

        logger.info(f"Role created: {role['role_name']} by user {g.db_user['username']}")

        return jsonify({
            'success': True,
            'message': 'Role created successfully',
            'role': role
        }), 201

    except Exception as e:
        logger.error(f"Failed to create role: {e}")
        db.rollback()
        return jsonify({'error': 'Failed to create role', 'message': str(e)}), 500


@admin_bp.route('/roles/<int:role_id>', methods=['PUT'])
@require_auth
@require_admin()
def update_role(role_id):
    """
    Update role details (name, description, priority)

    Args:
        role_id: Role ID

    Body:
        {
            "display_name": "Updated Display Name",
            "description": "Updated description",
            "priority": 20
        }

    Returns:
        200: Role updated successfully
        404: Role not found
        400: Cannot modify system role
    """
    try:
        data = request.get_json()
        db = g.db
        rbac = g.rbac

        # Check if role exists and is not a system role
        cursor = db.execute("""
            SELECT is_system_role, role_name FROM roles WHERE id = %s
        """, (role_id,))
        role = cursor.fetchone()

        if not role:
            return jsonify({'error': 'Role not found'}), 404

        if role['is_system_role']:
            return jsonify({
                'error': 'Cannot modify system role',
                'message': 'System roles are protected and cannot be modified'
            }), 400

        # Update role
        cursor = db.execute("""
            UPDATE roles
            SET display_name = COALESCE(%s, display_name),
                description = COALESCE(%s, description),
                priority = COALESCE(%s, priority),
                updated_at = NOW()
            WHERE id = %s
            RETURNING *
        """, (
            data.get('display_name'),
            data.get('description'),
            data.get('priority'),
            role_id
        ))

        updated_role = cursor.fetchone()
        db.commit()

        # Audit log
        rbac.audit_log(
            g.user_id,
            g.db_user['username'],
            'role_updated',
            None,
            'allowed',
            f"Updated role: {role['role_name']}"
        )

        logger.info(f"Role updated: {role['role_name']} by user {g.db_user['username']}")

        return jsonify({
            'success': True,
            'message': 'Role updated successfully',
            'role': updated_role
        }), 200

    except Exception as e:
        logger.error(f"Failed to update role {role_id}: {e}")
        db.rollback()
        return jsonify({'error': 'Failed to update role', 'message': str(e)}), 500


@admin_bp.route('/roles/<int:role_id>', methods=['DELETE'])
@require_auth
@require_admin()
def delete_role(role_id):
    """
    Delete a role (CASCADE deletes role_pages and user_roles)

    Args:
        role_id: Role ID

    Returns:
        200: Role deleted successfully
        404: Role not found
        400: Cannot delete system role
    """
    try:
        db = g.db
        rbac = g.rbac

        # Check if role exists and is not a system role
        cursor = db.execute("""
            SELECT is_system_role, role_name FROM roles WHERE id = %s
        """, (role_id,))
        role = cursor.fetchone()

        if not role:
            return jsonify({'error': 'Role not found'}), 404

        if role['is_system_role']:
            return jsonify({
                'error': 'Cannot delete system role',
                'message': 'System roles are protected and cannot be deleted'
            }), 400

        # Delete role (CASCADE handles role_pages and user_roles)
        db.execute("DELETE FROM roles WHERE id = %s", (role_id,))
        db.commit()

        # Clear cache for all users (roles changed)
        rbac.clear_cache()

        # Audit log
        rbac.audit_log(
            g.user_id,
            g.db_user['username'],
            'role_deleted',
            None,
            'allowed',
            f"Deleted role: {role['role_name']}"
        )

        logger.info(f"Role deleted: {role['role_name']} by user {g.db_user['username']}")

        return jsonify({
            'success': True,
            'message': 'Role deleted successfully'
        }), 200

    except Exception as e:
        logger.error(f"Failed to delete role {role_id}: {e}")
        db.rollback()
        return jsonify({'error': 'Failed to delete role', 'message': str(e)}), 500


@admin_bp.route('/roles/<int:role_id>/pages', methods=['GET'])
@require_auth
@require_admin()
def get_role_pages(role_id):
    """
    Get all pages assigned to a role

    Args:
        role_id: Role ID

    Returns:
        200: List of pages
        404: Role not found
    """
    try:
        db = g.db

        # Check if role exists
        cursor = db.execute("SELECT id FROM roles WHERE id = %s", (role_id,))
        if not cursor.fetchone():
            return jsonify({'error': 'Role not found'}), 404

        # Get assigned pages
        cursor = db.execute("""
            SELECT
                p.id as page_id,
                p.page_path,
                p.page_name,
                p.page_category,
                p.description,
                p.icon,
                rp.can_view,
                rp.can_edit,
                p.display_order
            FROM role_pages rp
            JOIN pages p ON rp.page_id = p.id
            WHERE rp.role_id = %s
            ORDER BY p.display_order
        """, (role_id,))

        pages = cursor.fetchall()

        return jsonify({
            'success': True,
            'pages': pages,
            'total': len(pages)
        }), 200

    except Exception as e:
        logger.error(f"Failed to get role pages for role {role_id}: {e}")
        return jsonify({'error': 'Failed to fetch role pages', 'message': str(e)}), 500


@admin_bp.route('/roles/<int:role_id>/pages', methods=['POST'])
@require_auth
@require_admin()
def assign_pages_to_role(role_id):
    """
    Assign pages to a role (replaces existing assignments)

    Args:
        role_id: Role ID

    Body:
        {
            "pages": [
                {"page_id": 1, "can_view": true, "can_edit": false},
                {"page_id": 2, "can_view": true, "can_edit": true}
            ]
        }

    Returns:
        200: Pages assigned successfully
        404: Role not found
    """
    try:
        data = request.get_json()
        pages = data.get('pages', [])

        db = g.db
        rbac = g.rbac

        # Check if role exists
        cursor = db.execute("SELECT role_name FROM roles WHERE id = %s", (role_id,))
        role = cursor.fetchone()
        if not role:
            return jsonify({'error': 'Role not found'}), 404

        # Delete existing assignments
        db.execute("DELETE FROM role_pages WHERE role_id = %s", (role_id,))

        # Insert new assignments
        for page in pages:
            db.execute("""
                INSERT INTO role_pages (role_id, page_id, can_view, can_edit)
                VALUES (%s, %s, %s, %s)
                ON CONFLICT (role_id, page_id) DO UPDATE
                SET can_view = EXCLUDED.can_view,
                    can_edit = EXCLUDED.can_edit
            """, (
                role_id,
                page['page_id'],
                page.get('can_view', True),
                page.get('can_edit', False)
            ))

        db.commit()

        # Clear cache (permissions changed)
        rbac.clear_cache()

        # Audit log
        rbac.audit_log(
            g.user_id,
            g.db_user['username'],
            'role_pages_updated',
            None,
            'allowed',
            f"Updated pages for role: {role['role_name']}"
        )

        logger.info(f"Pages assigned to role {role['role_name']}: {len(pages)} pages")

        return jsonify({
            'success': True,
            'message': 'Pages assigned successfully',
            'assigned_count': len(pages)
        }), 200

    except Exception as e:
        logger.error(f"Failed to assign pages to role {role_id}: {e}")
        db.rollback()
        return jsonify({'error': 'Failed to assign pages', 'message': str(e)}), 500


@admin_bp.route('/roles/<int:role_id>/pages/<int:page_id>', methods=['DELETE'])
@require_auth
@require_admin()
def remove_page_from_role(role_id, page_id):
    """
    Remove a page from a role

    Args:
        role_id: Role ID
        page_id: Page ID

    Returns:
        200: Page removed successfully
        404: Role or page not found
    """
    try:
        db = g.db
        rbac = g.rbac

        # Delete assignment
        cursor = db.execute("""
            DELETE FROM role_pages
            WHERE role_id = %s AND page_id = %s
            RETURNING role_id
        """, (role_id, page_id))

        if not cursor.fetchone():
            return jsonify({'error': 'Assignment not found'}), 404

        db.commit()

        # Clear cache
        rbac.clear_cache()

        logger.info(f"Page {page_id} removed from role {role_id}")

        return jsonify({
            'success': True,
            'message': 'Page removed from role'
        }), 200

    except Exception as e:
        logger.error(f"Failed to remove page {page_id} from role {role_id}: {e}")
        db.rollback()
        return jsonify({'error': 'Failed to remove page', 'message': str(e)}), 500


@admin_bp.route('/roles/<int:role_id>/clone', methods=['POST'])
@require_auth
@require_admin()
def clone_role(role_id):
    """
    Clone a role with all its permissions

    Args:
        role_id: Role ID to clone

    Body:
        {
            "new_role_name": "junior-analyst-v2",
            "new_display_name": "Junior Analyst V2",
            "new_description": "Cloned from Junior Analyst",
            "copy_permissions": true
        }

    Returns:
        201: Role cloned successfully
        404: Source role not found
        409: New role name already exists
    """
    try:
        data = request.get_json()

        # Validate required fields
        if not data.get('new_role_name'):
            return jsonify({'error': 'new_role_name is required'}), 400

        if not data.get('new_display_name'):
            return jsonify({'error': 'new_display_name is required'}), 400

        db = g.db
        rbac = g.rbac

        # Check if source role exists
        cursor = db.execute("""
            SELECT * FROM roles WHERE id = %s
        """, (role_id,))
        source_role = cursor.fetchone()

        if not source_role:
            return jsonify({'error': 'Source role not found'}), 404

        # Check if new role name already exists
        cursor = db.execute("""
            SELECT id FROM roles WHERE role_name = %s
        """, (data['new_role_name'],))
        if cursor.fetchone():
            return jsonify({'error': 'New role name already exists'}), 409

        # Create new role
        cursor = db.execute("""
            INSERT INTO roles (role_name, display_name, description, priority, created_by)
            VALUES (%s, %s, %s, %s, %s)
            RETURNING id, role_name, display_name, description, priority, created_at
        """, (
            data['new_role_name'],
            data['new_display_name'],
            data.get('new_description', f"Cloned from {source_role['display_name'] or source_role['role_name']}"),
            source_role['priority'],
            g.user_id
        ))

        new_role = cursor.fetchone()
        new_role_id = new_role['id']

        # Copy permissions if requested
        permissions_copied = 0
        if data.get('copy_permissions', True):
            cursor = db.execute("""
                SELECT page_id, can_view, can_edit
                FROM role_pages
                WHERE role_id = %s
            """, (role_id,))

            source_permissions = cursor.fetchall()

            for perm in source_permissions:
                db.execute("""
                    INSERT INTO role_pages (role_id, page_id, can_view, can_edit)
                    VALUES (%s, %s, %s, %s)
                """, (new_role_id, perm['page_id'], perm['can_view'], perm['can_edit']))
                permissions_copied += 1

        db.commit()

        # Clear cache
        rbac.clear_cache()

        # Audit log
        rbac.audit_log(
            g.user_id,
            g.db_user['username'],
            'role_cloned',
            None,
            'allowed',
            f"Cloned role {source_role['role_name']} to {data['new_role_name']} ({permissions_copied} permissions copied)"
        )

        logger.info(f"[Role Management] ✓ Role cloned: {source_role['role_name']} → {data['new_role_name']} ({permissions_copied} permissions)")

        return jsonify({
            'success': True,
            'message': 'Role cloned successfully',
            'role': {
                'id': new_role['id'],
                'role_name': new_role['role_name'],
                'display_name': new_role['display_name'],
                'description': new_role['description'],
                'priority': new_role['priority'],
                'created_at': new_role['created_at'].isoformat() if new_role['created_at'] else None
            },
            'permissions_copied': permissions_copied,
            'source_role': source_role['role_name']
        }), 201

    except Exception as e:
        logger.error(f"Failed to clone role {role_id}: {e}")
        db.rollback()
        return jsonify({'error': 'Failed to clone role', 'message': str(e)}), 500
