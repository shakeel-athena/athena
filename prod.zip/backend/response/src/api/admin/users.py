"""
User Management API
Manage users and their role assignments
"""

from flask import request, jsonify, g, current_app
from . import admin_bp
from middleware.auth import require_auth
from utils.rbac import require_admin
from services.keycloak_admin import keycloak_admin
import logging
import re

logger = logging.getLogger(__name__)


@admin_bp.route('/users', methods=['GET'])
@require_auth
@require_admin()
def get_users():
    """
    Get all users with their roles

    Query params:
        page: Page number (default: 1)
        limit: Items per page (default: 50)
        search: Search by username or email

    Returns:
        200: List of users
    """
    try:
        db = g.db

        # Ensure clean transaction
        try:
            db.rollback()
        except:
            pass

        # Get query params
        page = request.args.get('page', 1, type=int)
        limit = request.args.get('limit', 50, type=int)
        search = request.args.get('search', '', type=str)

        offset = (page - 1) * limit

        # Build query
        where_clause = ""
        params = []

        if search:
            where_clause = "WHERE (u.username ILIKE %s OR u.email ILIKE %s)"
            search_param = f"%{search}%"
            params = [search_param, search_param]

        # Get users
        query = f"""
            SELECT
                u.id,
                u.keycloak_user_id,
                u.username,
                u.email,
                u.full_name,
                u.is_admin,
                u.is_active,
                u.created_at,
                u.updated_at,
                COUNT(DISTINCT ur.role_id) as role_count
            FROM users u
            LEFT JOIN user_roles ur ON u.id = ur.user_id
            {where_clause}
            GROUP BY u.id, u.keycloak_user_id, u.username, u.email, u.full_name, u.is_admin, u.is_active, u.created_at, u.updated_at
            ORDER BY u.created_at DESC
            LIMIT %s OFFSET %s
        """

        params.extend([limit, offset])
        cursor = db.execute(query, tuple(params))
        rows = cursor.fetchall()

        # Convert to list of dicts with proper serialization
        users = []
        for row in rows:
            user_dict = {
                'id': row['id'],
                'keycloak_user_id': row['keycloak_user_id'],
                'username': row['username'],
                'email': row['email'],
                'full_name': row['full_name'],
                'is_admin': row['is_admin'],
                'is_active': row['is_active'],
                'source': 'Keycloak',  # Default source (not in DB schema)
                'last_login': None,  # Not tracked in current schema
                'created_at': row['created_at'].isoformat() if row['created_at'] else None,
                'updated_at': row['updated_at'].isoformat() if row['updated_at'] else None,
                'role_count': row['role_count']
            }
            users.append(user_dict)

        # Get total count
        count_query = f"SELECT COUNT(*) as total FROM users u {where_clause}"
        cursor = db.execute(count_query, tuple(params[:len(params)-2]) if params else ())
        total = cursor.fetchone()['total']

        return jsonify({
            'success': True,
            'users': users,
            'total': total,
            'page': page,
            'limit': limit,
            'pages': (total + limit - 1) // limit
        }), 200

    except Exception as e:
        logger.error(f"Failed to get users: {e}")
        try:
            db.rollback()
        except:
            pass
        return jsonify({'error': 'Failed to fetch users', 'message': str(e)}), 500


@admin_bp.route('/users/<int:user_id>', methods=['GET'])
@require_auth
@require_admin()
def get_user(user_id):
    """
    Get detailed information about a user

    Args:
        user_id: User ID

    Returns:
        200: User details with roles and permissions
        404: User not found
    """
    try:
        db = g.db

        # Get user basic info
        cursor = db.execute("""
            SELECT * FROM users WHERE id = %s
        """, (user_id,))
        user = cursor.fetchone()

        if not user:
            return jsonify({'error': 'User not found'}), 404

        # Get user's roles
        cursor = db.execute("""
            SELECT
                r.id,
                r.role_name,
                r.display_name,
                r.description,
                ur.assigned_at,
                ur.expires_at,
                u_assigner.username as assigned_by_username
            FROM user_roles ur
            JOIN roles r ON ur.role_id = r.id
            LEFT JOIN users u_assigner ON ur.assigned_by = u_assigner.id
            WHERE ur.user_id = %s
            ORDER BY r.priority DESC
        """, (user_id,))
        roles = cursor.fetchall()

        # Get user's accessible pages
        cursor = db.execute("""
            SELECT
                p.page_path,
                p.page_name,
                p.page_category,
                MAX(rp.can_view::int)::boolean as can_view,
                MAX(rp.can_edit::int)::boolean as can_edit
            FROM user_roles ur
            JOIN role_pages rp ON ur.role_id = rp.role_id
            JOIN pages p ON rp.page_id = p.id
            WHERE ur.user_id = %s
            GROUP BY p.id, p.page_path, p.page_name, p.page_category
            ORDER BY p.display_order
        """, (user_id,))
        pages = cursor.fetchall()

        return jsonify({
            'success': True,
            'user': user,
            'roles': roles,
            'pages': pages
        }), 200

    except Exception as e:
        logger.error(f"Failed to get user {user_id}: {e}")
        return jsonify({'error': 'Failed to fetch user', 'message': str(e)}), 500


@admin_bp.route('/users/<int:user_id>/roles', methods=['GET'])
@require_auth
@require_admin()
def get_user_roles(user_id):
    """
    Get roles assigned to a user

    Args:
        user_id: User ID

    Returns:
        200: List of roles
        404: User not found
    """
    try:
        db = g.db

        # Check if user exists
        cursor = db.execute("SELECT id FROM users WHERE id = %s", (user_id,))
        if not cursor.fetchone():
            return jsonify({'error': 'User not found'}), 404

        # Get roles
        cursor = db.execute("""
            SELECT
                r.id,
                r.role_name,
                r.display_name,
                r.description,
                r.is_system_role,
                ur.assigned_at,
                ur.expires_at
            FROM user_roles ur
            JOIN roles r ON ur.role_id = r.id
            WHERE ur.user_id = %s
            ORDER BY r.priority DESC
        """, (user_id,))

        rows = cursor.fetchall()

        # Convert to list of dicts with proper serialization
        roles = []
        for row in rows:
            role_dict = {
                'id': row['id'],
                'role_name': row['role_name'],
                'display_name': row['display_name'],
                'description': row['description'],
                'is_system_role': row['is_system_role'],
                'assigned_at': row['assigned_at'].isoformat() if row['assigned_at'] else None,
                'expires_at': row['expires_at'].isoformat() if row['expires_at'] else None
            }
            roles.append(role_dict)

        return jsonify({
            'success': True,
            'roles': roles,
            'total': len(roles)
        }), 200

    except Exception as e:
        logger.error(f"Failed to get user roles for user {user_id}: {e}")
        return jsonify({'error': 'Failed to fetch user roles', 'message': str(e)}), 500


@admin_bp.route('/users/<int:user_id>/roles', methods=['POST'])
@require_auth
@require_admin()
def assign_roles_to_user(user_id):
    """
    Assign roles to a user

    Args:
        user_id: User ID

    Body:
        {
            "role_ids": [1, 2, 3],
            "expires_at": "2025-12-31T23:59:59Z"  # Optional
        }

    Returns:
        200: Roles assigned successfully
        404: User or role not found
    """
    try:
        data = request.get_json()
        role_ids = data.get('role_ids', [])
        expires_at = data.get('expires_at')

        if not role_ids:
            return jsonify({'error': 'role_ids is required'}), 400

        db = g.db
        rbac = g.rbac

        # Check if user exists
        cursor = db.execute("SELECT username FROM users WHERE id = %s", (user_id,))
        user = cursor.fetchone()
        if not user:
            return jsonify({'error': 'User not found'}), 404

        # Assign roles
        assigned_count = 0
        for role_id in role_ids:
            # Check if role exists
            cursor = db.execute("SELECT id FROM roles WHERE id = %s", (role_id,))
            if not cursor.fetchone():
                logger.warning(f"Role {role_id} not found, skipping")
                continue

            db.execute("""
                INSERT INTO user_roles (user_id, role_id, assigned_by, expires_at)
                VALUES (%s, %s, %s, %s)
                ON CONFLICT (user_id, role_id) DO UPDATE
                SET expires_at = EXCLUDED.expires_at
            """, (user_id, role_id, g.user_id, expires_at))
            assigned_count += 1

        db.commit()

        # Clear cache for this user
        rbac.clear_cache(user_id)

        # Audit log
        rbac.audit_log(
            g.user_id,
            g.db_user['username'],
            'user_roles_assigned',
            None,
            'allowed',
            f"Assigned {assigned_count} roles to user {user['username']}"
        )

        logger.info(f"Assigned {assigned_count} roles to user {user['username']}")

        return jsonify({
            'success': True,
            'message': 'Roles assigned successfully',
            'assigned_count': assigned_count
        }), 200

    except Exception as e:
        logger.error(f"Failed to assign roles to user {user_id}: {e}")
        db.rollback()
        return jsonify({'error': 'Failed to assign roles', 'message': str(e)}), 500


@admin_bp.route('/users/<int:user_id>/roles/<int:role_id>', methods=['DELETE'])
@require_auth
@require_admin()
def remove_role_from_user(user_id, role_id):
    """
    Remove a role from a user

    Args:
        user_id: User ID
        role_id: Role ID

    Returns:
        200: Role removed successfully
        404: Assignment not found
    """
    try:
        db = g.db
        rbac = g.rbac

        # Delete assignment
        cursor = db.execute("""
            DELETE FROM user_roles
            WHERE user_id = %s AND role_id = %s
            RETURNING user_id
        """, (user_id, role_id))

        if not cursor.fetchone():
            return jsonify({'error': 'Role assignment not found'}), 404

        db.commit()

        # Clear cache for this user
        rbac.clear_cache(user_id)

        # Audit log
        rbac.audit_log(
            g.user_id,
            g.db_user['username'],
            'user_role_removed',
            None,
            'allowed',
            f"Removed role {role_id} from user {user_id}"
        )

        logger.info(f"Role {role_id} removed from user {user_id}")

        return jsonify({
            'success': True,
            'message': 'Role removed successfully'
        }), 200

    except Exception as e:
        logger.error(f"Failed to remove role {role_id} from user {user_id}: {e}")
        db.rollback()
        return jsonify({'error': 'Failed to remove role', 'message': str(e)}), 500


@admin_bp.route('/users/<int:user_id>/admin', methods=['PUT'])
@require_auth
@require_admin()
def toggle_admin_status(user_id):
    """
    Toggle user's system admin status

    Args:
        user_id: User ID

    Body:
        {
            "is_admin": true
        }

    Returns:
        200: Admin status updated
        404: User not found
        403: Cannot modify own admin status
    """
    try:
        data = request.get_json()
        is_admin = data.get('is_admin', False)

        # Prevent admin from removing their own admin status
        if user_id == g.user_id and not is_admin:
            return jsonify({
                'error': 'Cannot remove your own admin privileges'
            }), 403

        db = g.db
        rbac = g.rbac

        # Update admin status
        cursor = db.execute("""
            UPDATE users
            SET is_admin = %s, updated_at = NOW()
            WHERE id = %s
            RETURNING username
        """, (is_admin, user_id))

        user = cursor.fetchone()
        if not user:
            return jsonify({'error': 'User not found'}), 404

        db.commit()

        # Clear cache
        rbac.clear_cache(user_id)

        # Audit log
        rbac.audit_log(
            g.user_id,
            g.db_user['username'],
            'admin_status_changed',
            None,
            'allowed',
            f"Changed admin status for {user['username']} to {is_admin}"
        )

        logger.info(f"Admin status changed for {user['username']}: {is_admin}")

        return jsonify({
            'success': True,
            'message': 'Admin status updated'
        }), 200

    except Exception as e:
        logger.error(f"Failed to toggle admin status for user {user_id}: {e}")
        db.rollback()
        return jsonify({'error': 'Failed to update admin status', 'message': str(e)}), 500


@admin_bp.route('/users/<int:user_id>/pages', methods=['GET'])
@require_auth
@require_admin()
def get_user_pages(user_id):
    """
    Get all pages the user can access (for preview/testing)

    Args:
        user_id: User ID

    Returns:
        200: List of accessible pages
        404: User not found
    """
    try:
        db = g.db

        # Check if user exists
        cursor = db.execute("SELECT id FROM users WHERE id = %s", (user_id,))
        if not cursor.fetchone():
            return jsonify({'error': 'User not found'}), 404

        # Get pages using RBAC manager
        rbac = g.rbac
        pages = rbac.get_user_pages(user_id)

        return jsonify({
            'success': True,
            'pages': pages,
            'total': len(pages)
        }), 200

    except Exception as e:
        logger.error(f"Failed to get pages for user {user_id}: {e}")
        return jsonify({'error': 'Failed to fetch user pages', 'message': str(e)}), 500


@admin_bp.route('/users/<string:keycloak_user_id>/pages', methods=['GET'])
@require_auth
@require_admin()
def get_user_pages_by_uuid(keycloak_user_id):
    """
    Get all pages the user can access using Keycloak UUID (for frontend compatibility)

    Args:
        keycloak_user_id: User's Keycloak UUID

    Returns:
        200: List of accessible pages
        404: User not found
    """
    try:
        db = g.db

        # Find user by Keycloak UUID
        cursor = db.execute("SELECT id FROM users WHERE keycloak_user_id = %s", (keycloak_user_id,))
        user = cursor.fetchone()
        
        if not user:
            return jsonify({'error': 'User not found'}), 404

        # Get pages using RBAC manager
        rbac = g.rbac
        pages = rbac.get_user_pages(user['id'])

        return jsonify({
            'success': True,
            'pages': pages,
            'total': len(pages)
        }), 200

    except Exception as e:
        logger.error(f"Failed to get pages for user {keycloak_user_id}: {e}")
        return jsonify({'error': 'Failed to fetch user pages', 'message': str(e)}), 500


@admin_bp.route('/users', methods=['POST'])
@require_auth
@require_admin()
def create_user():
    """
    Create a new user in both Keycloak and Athena database

    Body:
        {
            "username": "john.doe",
            "email": "john@company.com",
            "first_name": "John",
            "last_name": "Doe",
            "password": "SecurePass123!",
            "role_ids": [2, 3],  // Optional: assign roles immediately
            "is_admin": false,   // Optional: make system admin
            "send_email": true   // Optional: send welcome email
        }

    Returns:
        201: User created successfully
        400: Validation error
        409: User already exists
        500: Server error
    """
    try:
        data = request.get_json()

        # Validate required fields
        required_fields = ['username', 'email', 'password', 'first_name', 'last_name']
        for field in required_fields:
            if not data.get(field):
                return jsonify({'error': f'{field} is required'}), 400

        # Validate username format (alphanumeric + dots, hyphens, underscores)
        if not re.match(r'^[a-zA-Z0-9._-]{3,50}$', data['username']):
            return jsonify({
                'error': 'Invalid username format. Use 3-50 alphanumeric characters, dots, hyphens, or underscores'
            }), 400

        # Validate email format
        if not re.match(r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$', data['email']):
            return jsonify({'error': 'Invalid email format'}), 400

        # Validate password strength (minimum 8 chars, at least 1 uppercase, 1 lowercase, 1 number)
        if len(data['password']) < 8:
            return jsonify({'error': 'Password must be at least 8 characters'}), 400

        if not re.search(r'[A-Z]', data['password']):
            return jsonify({'error': 'Password must contain at least one uppercase letter'}), 400

        if not re.search(r'[a-z]', data['password']):
            return jsonify({'error': 'Password must contain at least one lowercase letter'}), 400

        if not re.search(r'[0-9]', data['password']):
            return jsonify({'error': 'Password must contain at least one number'}), 400

        db = g.db
        rbac = g.rbac

        # Check if username already exists in database
        cursor = db.execute("""
            SELECT id FROM users WHERE username = %s
        """, (data['username'],))

        if cursor.fetchone():
            return jsonify({'error': 'Username already exists'}), 409

        # Check if email already exists
        cursor = db.execute("""
            SELECT id FROM users WHERE email = %s
        """, (data['email'],))

        if cursor.fetchone():
            return jsonify({'error': 'Email already exists'}), 409

        # Step 1: Create user in Keycloak
        keycloak_user_id = None
        try:
            keycloak_user_id = keycloak_admin.create_user(
                username=data['username'],
                email=data['email'],
                first_name=data['first_name'],
                last_name=data['last_name'],
                password=data['password'],
                enabled=True
            )
        except ValueError as e:
            # User already exists in Keycloak
            return jsonify({'error': str(e)}), 409
        except Exception as e:
            logger.error(f"Failed to create user in Keycloak: {e}")
            return jsonify({
                'error': 'Failed to create user in authentication system',
                'message': str(e)
            }), 500

        # Step 2: Create user in Athena database
        try:
            cursor = db.execute("""
                INSERT INTO users (
                    keycloak_user_id,
                    username,
                    email,
                    full_name,
                    is_admin,
                    is_active
                ) VALUES (%s, %s, %s, %s, %s, TRUE)
                RETURNING id, username, email, full_name, is_admin, created_at
            """, (
                keycloak_user_id,
                data['username'],
                data['email'],
                f"{data['first_name']} {data['last_name']}",
                data.get('is_admin', False)
            ))

            user = cursor.fetchone()
            user_id = user['id']

            # Step 3: Assign roles if provided
            role_ids = data.get('role_ids', [])
            if role_ids:
                for role_id in role_ids:
                    # Verify role exists
                    cursor = db.execute("SELECT id FROM roles WHERE id = %s", (role_id,))
                    if cursor.fetchone():
                        db.execute("""
                            INSERT INTO user_roles (user_id, role_id, assigned_by)
                            VALUES (%s, %s, %s)
                        """, (user_id, role_id, g.user_id))

            db.commit()

            # Step 4: Audit log
            rbac.audit_log(
                g.user_id,
                g.db_user['username'],
                'user_created',
                f"/api/admin/users/{user_id}",
                'allowed',
                f"Created user {data['username']} with {len(role_ids)} roles"
            )

            logger.info(f"[User Management] ✓ User created: {data['username']} ({user_id})")

            return jsonify({
                'success': True,
                'message': 'User created successfully',
                'user': {
                    'id': user['id'],
                    'keycloak_user_id': keycloak_user_id,
                    'username': user['username'],
                    'email': user['email'],
                    'full_name': user['full_name'],
                    'is_admin': user['is_admin'],
                    'created_at': user['created_at'].isoformat(),
                    'roles_assigned': len(role_ids)
                }
            }), 201

        except Exception as e:
            logger.error(f"Failed to create user in database: {e}")
            db.rollback()

            # Rollback: Delete user from Keycloak
            if keycloak_user_id:
                try:
                    keycloak_admin.delete_user(keycloak_user_id)
                    logger.info(f"✓ Rolled back Keycloak user creation: {keycloak_user_id}")
                except Exception as rollback_error:
                    logger.error(f"✗ Failed to rollback Keycloak user: {rollback_error}")

            return jsonify({
                'error': 'Failed to create user in database',
                'message': str(e)
            }), 500

    except Exception as e:
        logger.exception("Unexpected error creating user")
        return jsonify({'error': 'Internal server error', 'message': str(e)}), 500


@admin_bp.route('/users/<int:user_id>', methods=['PUT'])
@require_auth
@require_admin()
def update_user(user_id):
    """
    Update user details

    Body:
        {
            "email": "newemail@company.com",
            "first_name": "John",
            "last_name": "Doe",
            "is_admin": false
        }
    """
    try:
        data = request.get_json()
        db = g.db
        rbac = g.rbac

        # Get current user
        cursor = db.execute("""
            SELECT keycloak_user_id, username, email
            FROM users WHERE id = %s
        """, (user_id,))

        user = cursor.fetchone()
        if not user:
            return jsonify({'error': 'User not found'}), 404

        # Update in Keycloak
        update_payload = {}
        if data.get('email'):
            if not re.match(r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$', data['email']):
                return jsonify({'error': 'Invalid email format'}), 400
            update_payload['email'] = data['email']
        if data.get('first_name'):
            update_payload['firstName'] = data['first_name']
        if data.get('last_name'):
            update_payload['lastName'] = data['last_name']

        if update_payload:
            try:
                keycloak_admin.update_user(user['keycloak_user_id'], **update_payload)
            except Exception as e:
                logger.error(f"Failed to update user in Keycloak: {e}")
                return jsonify({'error': 'Failed to update user in authentication system'}), 500

        # Update in database
        full_name = None
        if data.get('first_name') or data.get('last_name'):
            first = data.get('first_name', '')
            last = data.get('last_name', '')
            full_name = f"{first} {last}".strip() if first or last else None

        db.execute("""
            UPDATE users
            SET email = COALESCE(%s, email),
                full_name = COALESCE(%s, full_name),
                is_admin = COALESCE(%s, is_admin),
                updated_at = NOW()
            WHERE id = %s
        """, (
            data.get('email'),
            full_name,
            data.get('is_admin'),
            user_id
        ))

        db.commit()

        # Audit log
        rbac.audit_log(
            g.user_id,
            g.db_user['username'],
            'user_updated',
            f"/api/admin/users/{user_id}",
            'allowed',
            f"Updated user {user['username']}"
        )

        logger.info(f"[User Management] ✓ User updated: {user['username']}")

        return jsonify({
            'success': True,
            'message': 'User updated successfully'
        }), 200

    except Exception as e:
        logger.error(f"Failed to update user {user_id}: {e}")
        db.rollback()
        return jsonify({'error': 'Failed to update user', 'message': str(e)}), 500


@admin_bp.route('/users/<int:user_id>/password', methods=['PUT'])
@require_auth
@require_admin()
def reset_user_password(user_id):
    """
    Reset user password

    Body:
        {
            "new_password": "NewSecurePass123!",
            "temporary": false  // Force change on next login
        }
    """
    try:
        data = request.get_json()

        if not data.get('new_password'):
            return jsonify({'error': 'new_password is required'}), 400

        # Validate password strength
        if len(data['new_password']) < 8:
            return jsonify({'error': 'Password must be at least 8 characters'}), 400
        if not re.search(r'[A-Z]', data['new_password']):
            return jsonify({'error': 'Password must contain at least one uppercase letter'}), 400
        if not re.search(r'[a-z]', data['new_password']):
            return jsonify({'error': 'Password must contain at least one lowercase letter'}), 400
        if not re.search(r'[0-9]', data['new_password']):
            return jsonify({'error': 'Password must contain at least one number'}), 400

        db = g.db
        rbac = g.rbac

        # Get user
        cursor = db.execute("""
            SELECT keycloak_user_id, username
            FROM users WHERE id = %s
        """, (user_id,))

        user = cursor.fetchone()
        if not user:
            return jsonify({'error': 'User not found'}), 404

        # Reset password in Keycloak
        try:
            keycloak_admin.reset_password(
                user['keycloak_user_id'],
                data['new_password'],
                temporary=data.get('temporary', False)
            )
        except Exception as e:
            logger.error(f"Failed to reset password in Keycloak: {e}")
            return jsonify({'error': 'Failed to reset password', 'message': str(e)}), 500

        # Audit log
        rbac.audit_log(
            g.user_id,
            g.db_user['username'],
            'password_reset',
            f"/api/admin/users/{user_id}/password",
            'allowed',
            f"Reset password for {user['username']}"
        )

        logger.info(f"[User Management] ✓ Password reset for user: {user['username']}")

        return jsonify({
            'success': True,
            'message': 'Password reset successfully'
        }), 200

    except Exception as e:
        logger.error(f"Failed to reset password for user {user_id}: {e}")
        return jsonify({'error': 'Failed to reset password', 'message': str(e)}), 500


@admin_bp.route('/users/<int:user_id>', methods=['DELETE'])
@require_auth
@require_admin()
def delete_user(user_id):
    """
    Delete user from both Keycloak and database
    """
    try:
        db = g.db
        rbac = g.rbac

        # Get user
        cursor = db.execute("""
            SELECT keycloak_user_id, username
            FROM users WHERE id = %s
        """, (user_id,))

        user = cursor.fetchone()
        if not user:
            return jsonify({'error': 'User not found'}), 404

        # Cannot delete yourself
        if user_id == g.user_id:
            return jsonify({'error': 'Cannot delete your own account'}), 400

        # Delete from Keycloak first
        try:
            keycloak_admin.delete_user(user['keycloak_user_id'])
        except Exception as e:
            logger.error(f"Failed to delete user from Keycloak: {e}")
            return jsonify({'error': 'Failed to delete user from authentication system'}), 500

        # Delete from database (cascades to user_roles via ON DELETE CASCADE)
        db.execute("DELETE FROM users WHERE id = %s", (user_id,))
        db.commit()

        # Audit log
        rbac.audit_log(
            g.user_id,
            g.db_user['username'],
            'user_deleted',
            f"/api/admin/users/{user_id}",
            'allowed',
            f"Deleted user {user['username']}"
        )

        logger.info(f"[User Management] ✓ Deleted user: {user['username']}")

        return jsonify({
            'success': True,
            'message': 'User deleted successfully'
        }), 200

    except Exception as e:
        logger.error(f"Failed to delete user {user_id}: {e}")
        db.rollback()
        return jsonify({'error': 'Failed to delete user', 'message': str(e)}), 500


@admin_bp.route('/users/<int:user_id>/toggle-status', methods=['PUT'])
@require_auth
@require_admin()
def toggle_user_status(user_id):
    """
    Enable or disable user account
    """
    try:
        db = g.db
        rbac = g.rbac

        # Get user
        cursor = db.execute("""
            SELECT keycloak_user_id, username, is_active
            FROM users WHERE id = %s
        """, (user_id,))

        user = cursor.fetchone()
        if not user:
            return jsonify({'error': 'User not found'}), 404

        # Cannot disable yourself
        if user_id == g.user_id:
            return jsonify({'error': 'Cannot disable your own account'}), 400

        new_status = not user['is_active']

        # Update in Keycloak
        try:
            if new_status:
                keycloak_admin.enable_user(user['keycloak_user_id'])
            else:
                keycloak_admin.disable_user(user['keycloak_user_id'])
        except Exception as e:
            logger.error(f"Failed to update user status in Keycloak: {e}")
            return jsonify({'error': 'Failed to update user status in authentication system'}), 500

        # Update in database
        db.execute("""
            UPDATE users
            SET is_active = %s, updated_at = NOW()
            WHERE id = %s
        """, (new_status, user_id))

        db.commit()

        # Audit log
        action = 'enabled' if new_status else 'disabled'
        rbac.audit_log(
            g.user_id,
            g.db_user['username'],
            f'user_{action}',
            f"/api/admin/users/{user_id}/toggle-status",
            'allowed',
            f"{action.capitalize()} user {user['username']}"
        )

        logger.info(f"[User Management] ✓ User {action}: {user['username']}")

        return jsonify({
            'success': True,
            'message': f'User {action} successfully',
            'is_active': new_status
        }), 200

    except Exception as e:
        logger.error(f"Failed to toggle user status {user_id}: {e}")
        db.rollback()
        return jsonify({'error': 'Failed to update user status', 'message': str(e)}), 500
