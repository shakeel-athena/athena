"""
Alerts API Blueprint

Provides REST API endpoints for security alert management.
"""

from .routes import alerts_bp

__all__ = ['alerts_bp']
