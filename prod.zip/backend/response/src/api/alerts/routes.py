"""
Alerts API Routes

Flask blueprint containing all alert-related API endpoints.
"""

from flask import Blueprint, request, jsonify, g
import logging
import asyncio
import sys
import os
import requests
from requests.auth import HTTPBasicAuth
from pathlib import Path
from datetime import datetime
import uuid

PROJECT_ROOT = Path(__file__).resolve().parent.parent.parent.parent.parent.parent
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

# Wazuh Manager API Configuration (for agent status)
# Uses environment variables, fallback to 172.16.1.93 (current Wazuh Manager)
WAZUH_API_URL = os.getenv('WAZUH_API_URL', 'https://172.16.1.93:55000')
WAZUH_API_USER = os.getenv('WAZUH_API_USER', 'wazuh')
WAZUH_API_PASSWORD = os.getenv('WAZUH_API_PASSWORD', 'wazuh')

from services.alerts import AlertsService
from errors.error_types import ValidationError, ServiceError
from shared.infrastructure.events import get_event_bus, EventPriority

# Create blueprint
alerts_bp = Blueprint('alerts', __name__, url_prefix='/api')

# Logger
logger = logging.getLogger(__name__)

# Service instance (will be initialized when needed)
_alerts_service = None


def get_alerts_service() -> AlertsService:
    """Get or create Alerts service instance."""
    global _alerts_service
    if _alerts_service is None:
        _alerts_service = AlertsService()
    return _alerts_service


def success_response(data, message="Success"):
    """Create standardized success response."""
    return jsonify({
        "success": True,
        "message": message,
        "data": data
    }), 200


def error_response(message, status_code=500):
    """Create standardized error response."""
    return jsonify({
        "success": False,
        "error": message
    }), status_code


# ============================================================================
# Alert Testing Endpoints
# ============================================================================

@alerts_bp.route('/alerts/test-wazuh', methods=['GET'])
def test_wazuh_connection():
    """Test connection to Wazuh alert source."""
    try:
        service = get_alerts_service()
        result = service.test_wazuh_connection()
        return success_response(result, result['message'])
    except Exception as e:
        logger.error(f"Wazuh connection test failed: {e}")
        return error_response(f"Wazuh connection test failed: {str(e)}", 500)


# ============================================================================
# Unified Alerts Endpoints
# ============================================================================

@alerts_bp.route('/alerts', methods=['GET'])
def get_unified_alerts():
    """Get unified alerts from all sources with optional filtering."""
    try:
        event_bus = get_event_bus()
        asyncio.run(event_bus.publish_alert(
            {'source': 'api', 'action': 'fetch_alerts'},
            'alerts_api',
            EventPriority.LOW
        ))
    except:
        pass

    try:
        # Parse query parameters
        limit = request.args.get('limit', type=int)
        offset = request.args.get('offset', default=0, type=int)
        time_range_hours = request.args.get('time_range_hours', type=int)
        severity = request.args.get('severity', type=str)
        source = request.args.get('source', type=str)
        search = request.args.get('search', type=str)
        apply_mute = request.args.get('apply_mute', default='true', type=str).lower() == 'true'

        # Sorting parameters for large datasets
        sort_field = request.args.get('sort_field', type=str)
        sort_direction = request.args.get('sort_direction', default='desc', type=str)

        # Get current analyst from session/token (fallback to query param)
        # TODO: Replace with proper JWT authentication
        analyst = request.args.get('analyst') or 'unknown'

        service = get_alerts_service()
        result = service.get_unified_alerts(
            limit=limit,
            offset=offset,
            time_range_hours=time_range_hours,
            severity=severity,
            source=source,
            analyst=analyst,
            apply_mute_rules=apply_mute,
            search=search,
            sort_field=sort_field,
            sort_direction=sort_direction
        )

        return success_response(result, "Unified alerts retrieved successfully")
    except ValidationError as e:
        return error_response(str(e), 400)
    except ServiceError as e:
        return error_response(str(e), 500)
    except Exception as e:
        logger.error(f"Failed to get unified alerts: {e}")
        return error_response(f"Failed to retrieve unified alerts: {str(e)}", 500)


# ============================================================================
# Source-Specific Alert Endpoints
# ============================================================================

@alerts_bp.route('/alerts/wazuh', methods=['GET'])
def get_wazuh_alerts():
    """Get alerts from Wazuh source only."""
    try:
        # Parse query parameters
        limit = request.args.get('limit', type=int)
        time_range_hours = request.args.get('time_range_hours', type=int)
        severity = request.args.get('severity', type=str)

        service = get_alerts_service()
        alerts = service.get_wazuh_alerts(
            limit=limit,
            time_range_hours=time_range_hours,
            severity=severity
        )

        return success_response({
            "alerts": alerts,
            "count": len(alerts),
            "source": "wazuh"
        }, "Wazuh alerts retrieved successfully")
    except ValidationError as e:
        return error_response(str(e), 400)
    except ServiceError as e:
        return error_response(str(e), 500)
    except Exception as e:
        logger.error(f"Failed to get Wazuh alerts: {e}")
        return error_response(f"Failed to retrieve Wazuh alerts: {str(e)}", 500)


@alerts_bp.route('/alerts/suricata', methods=['GET'])
def get_suricata_alerts():
    """Get alerts from Suricata source only."""
    try:
        # Parse query parameters
        limit = request.args.get('limit', type=int)
        time_range_hours = request.args.get('time_range_hours', type=int)
        severity = request.args.get('severity', type=str)

        service = get_alerts_service()
        alerts = service.get_suricata_alerts(
            limit=limit,
            time_range_hours=time_range_hours,
            severity=severity
        )

        return success_response({
            "alerts": alerts,
            "count": len(alerts),
            "source": "suricata"
        }, "Suricata alerts retrieved successfully")
    except ValidationError as e:
        return error_response(str(e), 400)
    except ServiceError as e:
        return error_response(str(e), 500)
    except Exception as e:
        logger.error(f"Failed to get Suricata alerts: {e}")
        return error_response(f"Failed to retrieve Suricata alerts: {str(e)}", 500)


# ============================================================================
# Health Check Endpoints
# ============================================================================

@alerts_bp.route('/alerts/health', methods=['GET'])
def get_alerts_health():
    """Get health status of all alert sources."""
    try:
        service = get_alerts_service()
        health = service.get_alerts_health()

        status_code = 200 if health.get('overall_status') == 'healthy' else 503
        return jsonify({
            "success": True,
            "data": health
        }), status_code
    except Exception as e:
        logger.error(f"Failed to get alerts health: {e}")
        return error_response(f"Failed to get alerts health: {str(e)}", 500)


# ============================================================================
# Agent Status Endpoints (for Threat Topology)
# ============================================================================

class WazuhAgentClient:
    """Client for fetching agent data from Wazuh Manager API"""

    def __init__(self):
        self.base_url = WAZUH_API_URL
        self.username = WAZUH_API_USER
        self.password = WAZUH_API_PASSWORD
        self.token = None

    def authenticate(self):
        """Get JWT token from Wazuh API"""
        try:
            url = f"{self.base_url}/security/user/authenticate"
            response = requests.post(
                url,
                auth=HTTPBasicAuth(self.username, self.password),
                verify=False,
                timeout=30
            )
            response.raise_for_status()
            data = response.json()
            self.token = data['data']['token']
            logger.info("Successfully authenticated with Wazuh API for agent fetch")
            return self.token
        except requests.exceptions.RequestException as e:
            logger.error(f"Failed to authenticate with Wazuh API: {str(e)}")
            raise

    def get_agents(self, select_fields=None, _retry=False):
        """
        Fetch all agents from Wazuh Manager API

        Args:
            select_fields: List of fields to select (uses Wazuh field names like os.name, os.platform)
            _retry: Internal flag to prevent infinite retry loops

        Returns:
            List of agent dictionaries
        """
        if not self.token:
            self.authenticate()

        try:
            # Default fields useful for topology - using exact Wazuh API field names
            # See: https://documentation.wazuh.com/current/user-manual/api/reference.html
            if not select_fields:
                select_fields = [
                    'id', 'name', 'ip', 'status',
                    'os.name', 'os.platform', 'os.version',
                    'lastKeepAlive', 'dateAdd', 'version', 'group',
                    'disconnection_time', 'status_code'
                ]

            url = f"{self.base_url}/agents"
            params = {
                'select': ','.join(select_fields),
                'limit': 1000,  # Get all agents
                'offset': 0
            }

            response = requests.get(
                url,
                headers={'Authorization': f'Bearer {self.token}'},
                params=params,
                verify=False,
                timeout=30
            )

            # Handle 401 Unauthorized by re-authenticating and retrying once
            if response.status_code == 401 and not _retry:
                logger.warning("Wazuh API token expired, re-authenticating...")
                self.token = None
                self.authenticate()
                return self.get_agents(select_fields=select_fields, _retry=True)

            response.raise_for_status()
            data = response.json()

            agents = data.get('data', {}).get('affected_items', [])
            logger.info(f"Fetched {len(agents)} agents from Wazuh Manager")

            return agents

        except requests.exceptions.RequestException as e:
            logger.error(f"Failed to fetch agents from Wazuh API: {str(e)}")
            raise

    def get_agent_summary(self, _retry=False):
        """
        Get agent status summary from Wazuh

        Returns:
            Dictionary with counts: {active, disconnected, pending, never_connected, total}
        """
        if not self.token:
            self.authenticate()

        try:
            url = f"{self.base_url}/agents/summary/status"

            response = requests.get(
                url,
                headers={'Authorization': f'Bearer {self.token}'},
                verify=False,
                timeout=30
            )

            # Handle 401 Unauthorized by re-authenticating and retrying once
            if response.status_code == 401 and not _retry:
                logger.warning("Wazuh API token expired, re-authenticating...")
                self.token = None
                self.authenticate()
                return self.get_agent_summary(_retry=True)

            response.raise_for_status()
            data = response.json()

            return data.get('data', {})

        except requests.exceptions.RequestException as e:
            logger.error(f"Failed to fetch agent summary: {str(e)}")
            raise


# Singleton client instance
_wazuh_agent_client = None

def get_wazuh_agent_client():
    """Get or create Wazuh agent client instance"""
    global _wazuh_agent_client
    if _wazuh_agent_client is None:
        _wazuh_agent_client = WazuhAgentClient()
    return _wazuh_agent_client


@alerts_bp.route('/alerts/agents', methods=['GET'])
def get_agents():
    """
    Get list of registered Wazuh agents with status information.

    Returns:
        {
            "success": true,
            "data": [
                {
                    "id": "001",
                    "name": "web-server-01",
                    "ip": "10.0.1.103",
                    "status": "active",
                    "os": "Ubuntu 22.04",
                    "lastKeepAlive": "2026-01-08T05:00:00Z",
                    "dateAdd": "2025-12-01T10:00:00Z",
                    "version": "4.7.0",
                    "group": ["default"]
                },
                ...
            ],
            "summary": {
                "active": 10,
                "disconnected": 2,
                "pending": 0,
                "never_connected": 1,
                "total": 13
            }
        }
    """
    try:
        client = get_wazuh_agent_client()

        # Fetch agents and summary in parallel-ish
        agents = client.get_agents()

        # Try to get summary, but don't fail if unavailable
        summary = {}
        try:
            summary = client.get_agent_summary()
        except Exception as e:
            logger.warning(f"Could not fetch agent summary: {e}")
            # Calculate from agents list
            summary = {
                'active': len([a for a in agents if a.get('status') == 'active']),
                'disconnected': len([a for a in agents if a.get('status') == 'disconnected']),
                'pending': len([a for a in agents if a.get('status') == 'pending']),
                'never_connected': len([a for a in agents if a.get('status') == 'never_connected']),
                'total': len(agents)
            }

        # Normalize agent data for frontend
        normalized_agents = []
        for agent in agents:
            # Extract OS info
            os_info = agent.get('os', {})
            os_name = 'Unknown'
            if isinstance(os_info, dict):
                os_name = os_info.get('name', '') or os_info.get('platform', '')
                os_version = os_info.get('version', '')
                if os_version:
                    os_name = f"{os_name} {os_version}".strip()
            elif isinstance(os_info, str):
                os_name = os_info

            normalized_agents.append({
                'id': agent.get('id'),
                'name': agent.get('name'),
                'ip': agent.get('ip'),
                'status': agent.get('status', 'unknown'),
                'os': os_name,
                'lastKeepAlive': agent.get('lastKeepAlive'),
                'dateAdd': agent.get('dateAdd'),
                'version': agent.get('version'),
                'group': agent.get('group', [])
            })

        return success_response({
            'agents': normalized_agents,
            'summary': summary,
            'count': len(normalized_agents)
        }, f"Successfully retrieved {len(normalized_agents)} agents")

    except requests.exceptions.ConnectionError as e:
        logger.error(f"Could not connect to Wazuh Manager API: {e}")
        return error_response("Wazuh Manager API unavailable. Check WAZUH_API_URL configuration.", 503)
    except requests.exceptions.Timeout as e:
        logger.error(f"Wazuh Manager API timeout: {e}")
        return error_response("Wazuh Manager API request timed out", 504)
    except Exception as e:
        logger.error(f"Failed to get agents: {e}", exc_info=True)
        return error_response(f"Failed to retrieve agents: {str(e)}", 500)


@alerts_bp.route('/alerts/agents/summary', methods=['GET'])
def get_agents_summary():
    """Get summary of agent statuses (active, disconnected, etc.)"""
    try:
        client = get_wazuh_agent_client()
        summary = client.get_agent_summary()

        return success_response(summary, "Agent summary retrieved successfully")
    except Exception as e:
        logger.error(f"Failed to get agent summary: {e}")
        return error_response(f"Failed to retrieve agent summary: {str(e)}", 500)


# ============================================================================
# Topology Threat Actors Endpoint
# ============================================================================

@alerts_bp.route('/topology/threat-actors', methods=['GET'])
def get_topology_threat_actors():
    """
    Get filtered threat actors for Network Topology visualization.

    Returns external IPs and internal high-risk hosts with Critical/High alerts,
    excluding whitelisted IPs and registered agents.

    Query Parameters:
        time_range: str - Time range for alerts (1h, 6h, 24h, 7d, 30d)
        min_severity: str - Minimum severity to include (Critical, High)
        limit: int - Maximum number of threat actors to return (default: 20)
        include_internal: bool - Include internal high-risk hosts (default: false)

    Returns:
        JSON with threat_actors list, total_filtered count, and debug info
    """
    try:
        # Parse time range
        time_range = request.args.get('time_range', '24h', type=str)
        time_range_hours = {
            '1h': 1,
            '6h': 6,
            '24h': 24,
            '7d': 168,
            '30d': 720
        }.get(time_range, 24)

        # Parse other parameters
        min_severity = request.args.get('min_severity', 'High', type=str)
        if min_severity not in ('Critical', 'High'):
            min_severity = 'High'

        limit = request.args.get('limit', 20, type=int)
        limit = max(1, min(50, limit))  # Clamp between 1 and 50

        include_internal = request.args.get('include_internal', 'false', type=str).lower() == 'true'

        # Get threat actors from service
        service = get_alerts_service()
        result = service.get_threat_actors(
            time_range_hours=time_range_hours,
            min_severity=min_severity,
            limit=limit,
            include_internal=include_internal
        )

        return success_response(result, f"Retrieved {result['showing']} threat actors")

    except Exception as e:
        logger.error(f"Failed to get threat actors: {e}", exc_info=True)
        return error_response(f"Failed to retrieve threat actors: {str(e)}", 500)


# ============================================================================
# Bulk Actions Endpoints
# ============================================================================

def _extract_ip_from_alert(alert):
    """Extract source IP from alert based on source type."""
    if not alert:
        return None

    source = alert.get('source', '').lower()

    if source == 'suricata':
        return alert.get('src_ip')
    elif source == 'wazuh':
        # Try multiple possible locations for Wazuh IP
        data = alert.get('data', {})
        if isinstance(data, dict):
            ip = data.get('srcip') or data.get('src_ip')
            if ip:
                return ip

        raw_data = alert.get('raw', {}).get('data', {})
        if isinstance(raw_data, dict):
            ip = raw_data.get('srcip') or raw_data.get('src_ip')
            if ip:
                return ip

    return None


@alerts_bp.route('/alerts/bulk-block-ips', methods=['POST'])
def bulk_block_ips():
    """
    Block multiple IPs from selected alerts in parallel

    Request Body:
    {
        "alerts": [
            {
                "id": "alert-123",
                "source": "suricata",
                "src_ip": "1.2.3.4",
                "signature": "Port Scan Detected"
            },
            ...
        ],
        "analyst": "john.doe",
        "threat_type": "malware_c2",  // Optional: apply to all
        "reason": "Mass blocking during active incident"  // Optional
    }

    Response:
    {
        "success": true,
        "data": {
            "bulk_action_id": "uuid",
            "total": 50,
            "blocked": 48,
            "failed": 2,
            "skipped": 0,
            "results": [...]
        }
    }
    """
    try:
        data = request.get_json()

        # Validation
        if not data or 'alerts' not in data or 'analyst' not in data:
            return error_response("alerts and analyst required", 400)

        alerts = data['alerts']
        if not alerts or len(alerts) == 0:
            return error_response("alerts array cannot be empty", 400)

        if len(alerts) > 100:
            return error_response("Maximum 100 alerts per bulk action", 400)

        analyst = data['analyst']
        default_threat_type = data.get('threat_type', 'suspicious_activity')
        default_reason = data.get('reason', f'Bulk block from {len(alerts)} alerts')

        # Get database connection
        db_conn = getattr(g, 'db', None)
        if db_conn is None:
            return error_response("Database connection not available", 500)

        # Extract raw connection if it's a DatabaseWrapper
        if hasattr(db_conn, 'conn'):
            raw_conn = db_conn.conn
        else:
            raw_conn = db_conn

        cursor = raw_conn.cursor()

        try:
            # Create bulk action audit entry
            bulk_action_id = str(uuid.uuid4())
            initiated_at = datetime.now()

            cursor.execute("""
                INSERT INTO bulk_actions_audit
                (id, action_type, analyst, initiated_at, item_count, status)
                VALUES (%s, %s, %s, %s, %s, %s)
            """, [bulk_action_id, 'bulk_block_ips', analyst, initiated_at, len(alerts), 'in_progress'])

            raw_conn.commit()

            # Import firewall service
            sys.path.insert(0, str(PROJECT_ROOT / 'backend' / 'response' / 'src'))
            from api.firewall.routes import block_ip_from_alert_internal

            # Process each alert
            results = []
            success_count = 0
            failure_count = 0
            skipped_count = 0
            error_details = []

            for alert in alerts:
                alert_id = alert.get('id')
                ip = _extract_ip_from_alert(alert)

                if not ip or ip == 'Unknown' or ip == 'N/A':
                    skipped_count += 1
                    results.append({
                        "alert_id": alert_id,
                        "ip": None,
                        "status": "skipped",
                        "error": "No valid IP address in alert"
                    })
                    continue

                try:
                    # Check if IP already blocked
                    cursor.execute("""
                        SELECT id FROM firewall_ip_metadata
                        WHERE ip_address = %s AND active = TRUE
                    """, [ip])

                    if cursor.fetchone():
                        skipped_count += 1
                        results.append({
                            "alert_id": alert_id,
                            "ip": ip,
                            "status": "skipped",
                            "error": "IP already blocked"
                        })
                        continue

                    # Block the IP
                    block_data = {
                        'alert_id': alert_id,
                        'alert_source': alert.get('source'),
                        'alert_severity': alert.get('normalized_severity') or alert.get('severity'),
                        'threat_type': default_threat_type,
                        'reason': default_reason,
                        'direction': 'both',
                        'analyst': analyst,
                        'bulk_action_id': bulk_action_id
                    }

                    result = block_ip_from_alert_internal(ip, block_data, cursor, raw_conn)

                    if result.get('success'):
                        success_count += 1
                        results.append({
                            "alert_id": alert_id,
                            "ip": ip,
                            "status": "blocked",
                            "waf_enforced": result.get('waf_enforced', False),
                            "layers_blocked": result.get('layers_blocked', ['network_firewall'])
                        })
                    else:
                        failure_count += 1
                        error_msg = result.get('error', 'Unknown error')
                        error_details.append({
                            "alert_id": alert_id,
                            "ip": ip,
                            "error": error_msg
                        })
                        results.append({
                            "alert_id": alert_id,
                            "ip": ip,
                            "status": "failed",
                            "error": error_msg
                        })

                except Exception as e:
                    failure_count += 1
                    error_msg = str(e)
                    logger.error(f"Failed to block IP {ip} from alert {alert_id}: {e}")
                    error_details.append({
                        "alert_id": alert_id,
                        "ip": ip,
                        "error": error_msg
                    })
                    results.append({
                        "alert_id": alert_id,
                        "ip": ip,
                        "status": "failed",
                        "error": error_msg
                    })

            # Update bulk action audit entry
            completed_at = datetime.now()
            final_status = 'completed' if failure_count == 0 else ('partial_failure' if success_count > 0 else 'failed')

            cursor.execute("""
                UPDATE bulk_actions_audit
                SET completed_at = %s,
                    success_count = %s,
                    failure_count = %s,
                    status = %s,
                    error_details = %s::jsonb,
                    affected_items = %s::jsonb
                WHERE id = %s
            """, [
                completed_at,
                success_count,
                failure_count,
                final_status,
                str(error_details) if error_details else None,
                str(results),
                bulk_action_id
            ])

            raw_conn.commit()

            return success_response({
                "bulk_action_id": bulk_action_id,
                "total": len(alerts),
                "blocked": success_count,
                "failed": failure_count,
                "skipped": skipped_count,
                "results": results
            }, f"Bulk block completed: {success_count} blocked, {failure_count} failed, {skipped_count} skipped")

        finally:
            cursor.close()

    except Exception as e:
        logger.error(f"Bulk block IPs error: {e}", exc_info=True)
        return error_response(str(e), 500)


@alerts_bp.route('/alerts/bulk-mute', methods=['POST'])
def bulk_mute_alerts():
    """
    Mute multiple alerts at once

    Request Body:
    {
        "alerts": [{"id": "alert-123", "source": "suricata", ...}, ...],
        "analyst": "john.doe",
        "classification": "false_positive",
        "reason": "Bulk mute during maintenance window",
        "duration_hours": 168
    }
    """
    try:
        data = request.get_json()

        if not data or 'alerts' not in data or 'analyst' not in data:
            return error_response("alerts and analyst required", 400)

        alerts = data['alerts']
        if not alerts or len(alerts) > 100:
            return error_response("alerts must contain 1-100 items", 400)

        analyst = data['analyst']
        classification = data.get('classification', 'noisy_signature')
        reason = data.get('reason', f'Bulk mute from {len(alerts)} alerts')
        duration_hours = data.get('duration_hours', 168)

        # Get database connection
        db_conn = getattr(g, 'db', None)
        if db_conn is None:
            return error_response("Database connection not available", 500)

        if hasattr(db_conn, 'conn'):
            raw_conn = db_conn.conn
        else:
            raw_conn = db_conn

        cursor = raw_conn.cursor()

        try:
            # Create bulk action audit
            bulk_action_id = str(uuid.uuid4())

            cursor.execute("""
                INSERT INTO bulk_actions_audit
                (id, action_type, analyst, initiated_at, item_count, status)
                VALUES (%s, %s, %s, %s, %s, %s)
            """, [bulk_action_id, 'bulk_mute_alerts', analyst, datetime.now(), len(alerts), 'in_progress'])

            raw_conn.commit()

            # Import mute manager
            sys.path.insert(0, str(PROJECT_ROOT / 'backend' / 'response'))
            from mute_manager import MuteManager
            mute_manager = MuteManager()

            # Process each alert
            results = []
            success_count = 0
            failure_count = 0
            skipped_count = 0

            for alert in alerts:
                alert_id = alert.get('id')

                try:
                    # Create mute rule for this alert
                    conditions = {}

                    # Extract primary identifiers based on source
                    if alert.get('source') == 'suricata':
                        if alert.get('signature_id'):
                            conditions['signature_id'] = alert['signature_id']
                    elif alert.get('source') == 'wazuh':
                        if alert.get('rule_id'):
                            conditions['rule_id'] = str(alert['rule_id'])

                    if not conditions:
                        failure_count += 1
                        results.append({
                            "alert_id": alert_id,
                            "status": "failed",
                            "error": "No mutable conditions found in alert"
                        })
                        continue

                    # Extract additional conditions for more granular muting
                    # Network information
                    if alert.get('src_ip'):
                        conditions['source_ip'] = alert['src_ip']
                    if alert.get('dest_ip'):
                        conditions['dest_ip'] = alert['dest_ip']

                    # Metadata
                    if alert.get('normalized_severity'):
                        conditions['severity'] = alert['normalized_severity']
                    if alert.get('category'):
                        conditions['category'] = alert['category']

                    # Source-specific fields
                    if alert.get('source') == 'wazuh' and alert.get('agent_name'):
                        conditions['agent_name'] = alert['agent_name']
                    elif alert.get('source') == 'suricata':
                        sensor_hostname = alert.get('raw', {}).get('node', {}).get('hostname')
                        if sensor_hostname:
                            conditions['sensor_hostname'] = sensor_hostname

                    mute_manager.create_mute_rule(
                        conditions=conditions,
                        classification=classification,
                        analyst=analyst,
                        reason=reason,
                        duration_hours=duration_hours,
                        source_type=alert.get('source'),
                        original_alert_id=alert_id,
                        scope='global'
                    )

                    success_count += 1
                    results.append({
                        "alert_id": alert_id,
                        "status": "muted"
                    })

                except ValueError as e:
                    # Check if this is a duplicate rule error
                    error_msg = str(e)
                    if "Similar mute rule already exists" in error_msg or "already exists" in error_msg.lower():
                        skipped_count += 1
                        results.append({
                            "alert_id": alert_id,
                            "status": "skipped",
                            "reason": error_msg
                        })
                        logger.info(f"Skipped alert {alert_id}: {error_msg}")
                    else:
                        # Other ValueError - treat as failure
                        failure_count += 1
                        logger.error(f"Failed to mute alert {alert_id}: {e}")
                        results.append({
                            "alert_id": alert_id,
                            "status": "failed",
                            "error": error_msg
                        })

                except Exception as e:
                    failure_count += 1
                    logger.error(f"Failed to mute alert {alert_id}: {e}")
                    results.append({
                        "alert_id": alert_id,
                        "status": "failed",
                        "error": str(e)
                    })

            # Update bulk action
            final_status = 'completed' if failure_count == 0 else 'partial_failure'

            cursor.execute("""
                UPDATE bulk_actions_audit
                SET completed_at = %s,
                    success_count = %s,
                    failure_count = %s,
                    status = %s,
                    affected_items = %s::jsonb
                WHERE id = %s
            """, [datetime.now(), success_count, failure_count, final_status, str(results), bulk_action_id])

            raw_conn.commit()

            return success_response({
                "bulk_action_id": bulk_action_id,
                "total": len(alerts),
                "muted": success_count,
                "failed": failure_count,
                "skipped": skipped_count,
                "results": results
            }, f"Bulk mute completed: {success_count} muted, {failure_count} failed, {skipped_count} skipped")

        finally:
            cursor.close()

    except Exception as e:
        logger.error(f"Bulk mute error: {e}", exc_info=True)
        return error_response(str(e), 500)
