"""
Mute Rules API Routes

Flask blueprint containing all mute rule management endpoints.
Supports alert suppression for both Wazuh and Suricata events.
"""

from flask import Blueprint, request, jsonify, g
import logging
import sys
import os
from pathlib import Path

# Add backend root to path for imports
BACKEND_ROOT = Path(__file__).resolve().parent.parent.parent.parent.parent
if str(BACKEND_ROOT) not in sys.path:
    sys.path.insert(0, str(BACKEND_ROOT))

from response.mute_manager import MuteManager

# Create blueprint (imported in __init__.py)
from . import mute_bp

# Logger
logger = logging.getLogger(__name__)


def get_mute_manager():
    """Get MuteManager instance with database connection from Flask g context."""
    db_conn = getattr(g, 'db', None)
    if db_conn is None:
        raise Exception("Database connection not available")

    # Check if it's a DatabaseWrapper and extract the raw psycopg2 connection
    if hasattr(db_conn, 'conn'):
        # It's a DatabaseWrapper - extract the raw connection
        raw_conn = db_conn.conn
    else:
        # Assume it's already a raw connection
        raw_conn = db_conn

    return MuteManager(db_connection=raw_conn)


def success_response(data=None, message="Success"):
    """Create standardized success response."""
    response = {
        "success": True,
        "message": message
    }
    if data is not None:
        response["data"] = data
    return jsonify(response), 200


def error_response(message, status_code=400):
    """Create standardized error response."""
    return jsonify({
        "success": False,
        "error": message
    }), status_code


# ============================================================================
# Mute Rules Management Endpoints
# ============================================================================

@mute_bp.route('/rules', methods=['POST'])
def create_mute_rule():
    """
    Create a new mute rule

    Request body:
    {
        "conditions": {
            "signature_id": "2200121",           // Suricata signature ID
            "rule_id": "5104",                   // Wazuh rule ID
            "source_ip": "192.168.1.100",        // Exact IP match
            "source_ip_cidr": "10.0.0.0/24",     // CIDR range
            "dest_ip": "10.0.0.5",               // Exact dest IP
            "dest_ip_cidr": "192.168.0.0/16",    // Dest CIDR
            "severity": "Medium",                // Normalized severity
            "category": "authentication",        // Category
            "agent_name": "server1",             // Wazuh agent
            "sensor_hostname": "suricata-01"     // Suricata sensor
        },
        "classification": "false_positive",      // Required: false_positive, benign_positive, noisy_signature, maintenance, business_approved
        "reason": "Justification for muting",    // Required
        "analyst": "john.doe",                   // Required: username
        "duration_hours": 168,                   // Optional: 168 = 7 days, null = permanent
        "source_type": "suricata",               // Optional: wazuh, suricata, both
        "original_alert_id": "alert_123",        // Optional: alert that triggered this
        "scope": "global"                        // Optional: personal, team, global (default)
    }

    Response:
    {
        "success": true,
        "message": "Mute rule created successfully",
        "data": {
            "id": "uuid",
            "created_at": "2025-11-16T10:30:00",
            "expires_at": "2025-11-23T10:30:00",
            "approval_status": "auto_approved",  // or "pending_approval"
            "requires_approval": false,
            "active": true
        }
    }
    """
    try:
        data = request.get_json()

        # Validate required fields
        if not data:
            return error_response("Request body is required", 400)

        required_fields = ['conditions', 'classification', 'reason', 'analyst']
        missing_fields = [field for field in required_fields if field not in data]
        if missing_fields:
            return error_response(f"Missing required fields: {', '.join(missing_fields)}", 400)

        # Validate conditions is not empty
        if not data['conditions'] or not isinstance(data['conditions'], dict):
            return error_response("Conditions must be a non-empty object", 400)

        # Validate classification
        valid_classifications = ['false_positive', 'benign_positive', 'noisy_signature', 'maintenance', 'business_approved']
        if data['classification'] not in valid_classifications:
            return error_response(f"Invalid classification. Must be one of: {', '.join(valid_classifications)}", 400)

        # Get MuteManager instance
        mute_manager = get_mute_manager()

        # Create mute rule
        result = mute_manager.create_mute_rule(
            conditions=data['conditions'],
            classification=data['classification'],
            reason=data['reason'],
            analyst=data['analyst'],
            duration_hours=data.get('duration_hours'),
            source_type=data.get('source_type'),
            original_alert_id=data.get('original_alert_id'),
            scope=data.get('scope', 'global')
        )

        return success_response(result, "Mute rule created successfully")

    except Exception as e:
        logger.error(f"Error creating mute rule: {e}")
        import traceback
        traceback.print_exc()
        return error_response(f"Failed to create mute rule: {str(e)}", 500)


@mute_bp.route('/rules', methods=['GET'])
def get_mute_rules():
    """
    Get all mute rules

    Query parameters:
    - active_only: true/false (default: true) - Only show active rules
    - pending_approval_only: true/false (default: false) - Only show pending approval rules

    Response:
    {
        "success": true,
        "message": "Mute rules retrieved successfully",
        "data": {
            "rules": [
                {
                    "id": "uuid",
                    "conditions": {...},
                    "classification": "false_positive",
                    "created_by": "john.doe",
                    "reason": "Justification",
                    "created_at": "2025-11-16T10:30:00",
                    "expires_at": "2025-11-23T10:30:00",
                    "active": true,
                    "approval_status": "auto_approved",
                    "hit_count": 42,
                    "first_matched_at": "2025-11-16T11:00:00",
                    "last_matched_at": "2025-11-16T15:30:00"
                }
            ],
            "total": 10
        }
    }
    """
    try:
        # Parse query parameters
        active_only = request.args.get('active_only', 'true').lower() == 'true'
        pending_approval_only = request.args.get('pending_approval_only', 'false').lower() == 'true'

        # Get MuteManager instance
        mute_manager = get_mute_manager()

        # Get rules
        rules = mute_manager.get_mute_rules(
            active_only=active_only,
            pending_approval_only=pending_approval_only
        )

        return success_response({
            'rules': rules,
            'total': len(rules)
        }, "Mute rules retrieved successfully")

    except Exception as e:
        logger.error(f"Error getting mute rules: {e}")
        return error_response(f"Failed to get mute rules: {str(e)}", 500)


@mute_bp.route('/rules/<rule_id>/approve', methods=['POST'])
def approve_mute_rule(rule_id):
    """
    Approve a pending mute rule

    Request body:
    {
        "approver": "jane.senior"  // Required: senior analyst username
    }

    Response:
    {
        "success": true,
        "message": "Mute rule approved successfully"
    }
    """
    try:
        data = request.get_json()

        if not data or 'approver' not in data:
            return error_response("Approver username is required", 400)

        # Get MuteManager instance
        mute_manager = get_mute_manager()

        # Approve rule
        mute_manager.approve_mute_rule(rule_id, data['approver'])

        return success_response(None, "Mute rule approved successfully")

    except Exception as e:
        logger.error(f"Error approving mute rule {rule_id}: {e}")
        return error_response(f"Failed to approve mute rule: {str(e)}", 500)


@mute_bp.route('/rules/<rule_id>/reject', methods=['POST'])
def reject_mute_rule(rule_id):
    """
    Reject a pending mute rule

    Request body:
    {
        "approver": "jane.senior",           // Required: senior analyst username
        "reason": "Reason for rejection"     // Required: justification
    }

    Response:
    {
        "success": true,
        "message": "Mute rule rejected successfully"
    }
    """
    try:
        data = request.get_json()

        if not data or 'approver' not in data or 'reason' not in data:
            return error_response("Approver and reason are required", 400)

        # Get MuteManager instance
        mute_manager = get_mute_manager()

        # Reject rule
        mute_manager.reject_mute_rule(rule_id, data['approver'], data['reason'])

        return success_response(None, "Mute rule rejected successfully")

    except Exception as e:
        logger.error(f"Error rejecting mute rule {rule_id}: {e}")
        return error_response(f"Failed to reject mute rule: {str(e)}", 500)


@mute_bp.route('/rules/<rule_id>', methods=['DELETE'])
def delete_mute_rule(rule_id):
    """
    Delete (deactivate) a mute rule

    Query parameters:
    - analyst: username of analyst deleting the rule

    Response:
    {
        "success": true,
        "message": "Mute rule deleted successfully"
    }
    """
    try:
        analyst = request.args.get('analyst')

        if not analyst:
            return error_response("Analyst username is required", 400)

        # Get MuteManager instance
        mute_manager = get_mute_manager()

        # Delete rule
        mute_manager.delete_mute_rule(rule_id, analyst)

        return success_response(None, "Mute rule deleted successfully")

    except Exception as e:
        logger.error(f"Error deleting mute rule {rule_id}: {e}")
        return error_response(f"Failed to delete mute rule: {str(e)}", 500)


@mute_bp.route('/audit-log', methods=['GET'])
def get_audit_log():
    """
    Get audit log for mute rule actions

    Query parameters:
    - analyst: Filter by analyst username (optional)
    - action: Filter by action type (optional)
    - limit: Number of records to return (default: 100)
    - offset: Offset for pagination (default: 0)

    Response:
    {
        "success": true,
        "message": "Audit log retrieved successfully",
        "data": {
            "logs": [
                {
                    "id": "uuid",
                    "timestamp": "2025-11-16T10:30:00",
                    "action": "mute_rule_created",
                    "analyst": "john.doe",
                    "mute_rule_id": "uuid",
                    "alert_severity": "Medium",
                    "alert_source": "suricata",
                    "details": {...}
                }
            ],
            "total": 50
        }
    }
    """
    try:
        # Parse query parameters
        analyst = request.args.get('analyst')
        action = request.args.get('action')
        limit = request.args.get('limit', 100, type=int)
        offset = request.args.get('offset', 0, type=int)

        # Get database connection
        db_conn = getattr(g, 'db', None)
        if db_conn is None:
            return error_response("Database connection not available", 500)

        # Build query
        filters = []
        params = []

        if analyst:
            filters.append("analyst = %s")
            params.append(analyst)

        if action:
            filters.append("action = %s")
            params.append(action)

        where_clause = "WHERE " + " AND ".join(filters) if filters else ""

        # Get audit logs
        cursor = db_conn.cursor()

        try:
            # Get total count
            cursor.execute(f"""
                SELECT COUNT(*) FROM mute_audit_log
                {where_clause}
            """, params)
            total = cursor.fetchone()[0]

            # Get paginated logs
            params.extend([limit, offset])
            cursor.execute(f"""
                SELECT * FROM mute_audit_log
                {where_clause}
                ORDER BY timestamp DESC
                LIMIT %s OFFSET %s
            """, params)

            columns = [desc[0] for desc in cursor.description]
            logs = [dict(zip(columns, row)) for row in cursor.fetchall()]

            # Convert datetime objects to ISO format strings
            for log in logs:
                if 'timestamp' in log and log['timestamp']:
                    log['timestamp'] = log['timestamp'].isoformat()

            return success_response({
                'logs': logs,
                'total': total,
                'limit': limit,
                'offset': offset
            }, "Audit log retrieved successfully")

        finally:
            cursor.close()

    except Exception as e:
        logger.error(f"Error getting audit log: {e}")
        import traceback
        traceback.print_exc()
        return error_response(f"Failed to get audit log: {str(e)}", 500)


@mute_bp.route('/expire-rules', methods=['POST'])
def expire_old_rules():
    """
    Manually trigger expiration of old rules (normally run as cron job)

    Response:
    {
        "success": true,
        "message": "Expired 5 rules",
        "data": {
            "expired_count": 5
        }
    }
    """
    try:
        # Get MuteManager instance
        mute_manager = get_mute_manager()

        # Expire old rules
        expired_count = mute_manager.expire_old_rules()

        return success_response({
            'expired_count': expired_count
        }, f"Expired {expired_count} rules")

    except Exception as e:
        logger.error(f"Error expiring rules: {e}")
        return error_response(f"Failed to expire rules: {str(e)}", 500)


@mute_bp.route('/rules/<rule_id>', methods=['GET'])
def get_mute_rule_details(rule_id):
    """
    Get single mute rule with full details and metrics

    Response:
    {
        "success": true,
        "message": "Mute rule retrieved successfully",
        "data": {
            "id": "uuid",
            "conditions": {...},
            "classification": "false_positive",
            "created_by": "john.doe",
            "reason": "Justification",
            "created_at": "2025-11-16T10:30:00",
            "expires_at": "2025-11-23T10:30:00",
            "active": true,
            "approval_status": "auto_approved",
            "hit_count": 42,
            "first_matched_at": "2025-11-16T11:00:00",
            "last_matched_at": "2025-11-16T15:30:00",
            "source_type": "suricata",
            "original_alert_id": "alert_123",
            "scope": "global",
            "audit_trail": [...]
        }
    }
    """
    try:
        db_conn = getattr(g, 'db', None)
        if db_conn is None:
            return error_response("Database connection not available", 500)

        # Extract raw connection if it's a DatabaseWrapper
        if hasattr(db_conn, 'conn'):
            raw_conn = db_conn.conn
        else:
            raw_conn = db_conn

        cursor = raw_conn.cursor()

        try:
            cursor.execute("""
                SELECT
                    id,
                    conditions,
                    classification,
                    created_by,
                    reason,
                    created_at,
                    expires_at,
                    active,
                    approval_status,
                    hit_count,
                    first_matched_at,
                    last_matched_at,
                    source_type,
                    original_alert_id,
                    scope
                FROM mute_rules
                WHERE id = %s
            """, [rule_id])

            row = cursor.fetchone()
            if not row:
                return error_response("Mute rule not found", 404)

            rule = {
                "id": str(row[0]),
                "conditions": row[1],
                "classification": row[2],
                "created_by": row[3],
                "reason": row[4],
                "created_at": row[5].isoformat() if row[5] else None,
                "expires_at": row[6].isoformat() if row[6] else None,
                "active": row[7],
                "approval_status": row[8],
                "hit_count": row[9] or 0,
                "first_matched_at": row[10].isoformat() if row[10] else None,
                "last_matched_at": row[11].isoformat() if row[11] else None,
                "source_type": row[12],
                "original_alert_id": row[13],
                "scope": row[14]
            }

            # Get audit trail
            cursor.execute("""
                SELECT action, analyst, timestamp, details
                FROM mute_audit_log
                WHERE mute_rule_id = %s
                ORDER BY timestamp DESC
                LIMIT 50
            """, [rule_id])

            audit_trail = []
            for audit_row in cursor.fetchall():
                audit_trail.append({
                    "action": audit_row[0],
                    "analyst": audit_row[1],
                    "timestamp": audit_row[2].isoformat() if audit_row[2] else None,
                    "details": audit_row[3]
                })

            rule["audit_trail"] = audit_trail

            return success_response(rule, "Mute rule retrieved successfully")

        finally:
            cursor.close()

    except Exception as e:
        logger.error(f"Get mute rule error: {e}", exc_info=True)
        return error_response(str(e), 500)


@mute_bp.route('/rules/<rule_id>', methods=['PUT'])
def update_mute_rule(rule_id):
    """
    Update mute rule (expires_at and reason only for safety)

    Request body:
    {
        "analyst": "john.doe",
        "expires_at": "2025-12-01T00:00:00",  // Optional
        "reason": "Updated reason"              // Optional
    }
    """
    try:
        data = request.get_json()

        if 'analyst' not in data:
            return error_response("analyst required", 400)

        allowed_fields = ['expires_at', 'reason']
        updates = {k: v for k, v in data.items() if k in allowed_fields}

        if not updates:
            return error_response("No valid fields to update", 400)

        db_conn = getattr(g, 'db', None)
        if db_conn is None:
            return error_response("Database connection not available", 500)

        # Extract raw connection if it's a DatabaseWrapper
        if hasattr(db_conn, 'conn'):
            raw_conn = db_conn.conn
        else:
            raw_conn = db_conn

        cursor = raw_conn.cursor()

        try:
            set_clause = ', '.join([f"{k} = %s" for k in updates.keys()])
            values = list(updates.values()) + [rule_id]

            cursor.execute(f"""
                UPDATE mute_rules
                SET {set_clause}
                WHERE id = %s
            """, values)

            raw_conn.commit()

            # Log audit
            mute_manager = get_mute_manager()
            mute_manager._log_audit(
                action='mute_rule_updated',
                analyst=data['analyst'],
                mute_rule_id=rule_id,
                details={"updated_fields": list(updates.keys())}
            )

            return success_response({"rule_id": rule_id}, "Mute rule updated successfully")

        finally:
            cursor.close()

    except Exception as e:
        logger.error(f"Update mute rule error: {e}", exc_info=True)
        return error_response(str(e), 500)


@mute_bp.route('/rules/bulk-delete', methods=['POST'])
def bulk_delete_mute_rules():
    """
    Delete multiple mute rules at once

    Request body:
    {
        "rule_ids": ["uuid1", "uuid2", ...],
        "analyst": "john.doe"
    }

    Response:
    {
        "success": true,
        "message": "Deleted 5 mute rules",
        "data": {
            "deleted_count": 5,
            "deleted_ids": ["uuid1", "uuid2", ...]
        }
    }
    """
    try:
        data = request.get_json()

        if 'rule_ids' not in data or 'analyst' not in data:
            return error_response("rule_ids and analyst required", 400)

        rule_ids = data['rule_ids']
        analyst = data['analyst']

        if not rule_ids:
            return error_response("rule_ids cannot be empty", 400)

        if len(rule_ids) > 50:
            return error_response("Maximum 50 rules per bulk delete", 400)

        db_conn = getattr(g, 'db', None)
        if db_conn is None:
            return error_response("Database connection not available", 500)

        # Extract raw connection if it's a DatabaseWrapper
        if hasattr(db_conn, 'conn'):
            raw_conn = db_conn.conn
        else:
            raw_conn = db_conn

        cursor = raw_conn.cursor()

        try:
            # Deactivate rules
            placeholders = ','.join(['%s'] * len(rule_ids))
            cursor.execute(f"""
                UPDATE mute_rules
                SET active = FALSE
                WHERE id IN ({placeholders})
                RETURNING id
            """, rule_ids)

            deleted_ids = [str(row[0]) for row in cursor.fetchall()]
            raw_conn.commit()

            # Log audit for each
            mute_manager = get_mute_manager()
            for rule_id in deleted_ids:
                mute_manager._log_audit(
                    action='mute_rule_deleted',
                    analyst=analyst,
                    mute_rule_id=rule_id,
                    details={"bulk_delete": True}
                )

            return success_response({
                "deleted_count": len(deleted_ids),
                "deleted_ids": deleted_ids
            }, f"Deleted {len(deleted_ids)} mute rules")

        finally:
            cursor.close()

    except Exception as e:
        logger.error(f"Bulk delete error: {e}", exc_info=True)
        return error_response(str(e), 500)


@mute_bp.route('/rules/stats', methods=['GET'])
def get_mute_rules_statistics():
    """
    Get aggregate statistics for dashboard

    Response:
    {
        "success": true,
        "message": "Statistics retrieved successfully",
        "data": {
            "active_rules": 10,
            "expiring_soon": 2,
            "unused_rules": 3,
            "total_hits": 1500,
            "top_rules": [...]
        }
    }
    """
    try:
        db_conn = getattr(g, 'db', None)
        if db_conn is None:
            return error_response("Database connection not available", 500)

        # Extract raw connection if it's a DatabaseWrapper
        if hasattr(db_conn, 'conn'):
            raw_conn = db_conn.conn
        else:
            raw_conn = db_conn

        cursor = raw_conn.cursor()

        try:
            # Overall stats
            cursor.execute("""
                SELECT
                    COUNT(*) FILTER (WHERE active = TRUE) as active_rules,
                    COUNT(*) FILTER (WHERE active = TRUE AND expires_at < NOW() + INTERVAL '24 hours' AND expires_at IS NOT NULL) as expiring_soon,
                    COUNT(*) FILTER (WHERE active = TRUE AND (hit_count = 0 OR hit_count IS NULL)) as unused_rules,
                    SUM(COALESCE(hit_count, 0)) FILTER (WHERE active = TRUE) as total_hits
                FROM mute_rules
            """)

            row = cursor.fetchone()
            stats = {
                "active_rules": row[0] or 0,
                "expiring_soon": row[1] or 0,
                "unused_rules": row[2] or 0,
                "total_hits": int(row[3]) if row[3] else 0
            }

            # Top rules by hit count
            cursor.execute("""
                SELECT id, conditions, hit_count, created_by
                FROM mute_rules
                WHERE active = TRUE
                ORDER BY hit_count DESC NULLS LAST
                LIMIT 10
            """)

            top_rules = []
            for row in cursor.fetchall():
                top_rules.append({
                    "id": str(row[0]),
                    "conditions": row[1],
                    "hit_count": row[2] or 0,
                    "created_by": row[3]
                })

            stats["top_rules"] = top_rules

            return success_response(stats, "Statistics retrieved successfully")

        finally:
            cursor.close()

    except Exception as e:
        logger.error(f"Get stats error: {e}", exc_info=True)
        return error_response(str(e), 500)


@mute_bp.route('/test', methods=['GET'])
def test_mute_system():
    """
    Test mute system connection and basic functionality

    Response:
    {
        "success": true,
        "message": "Mute system is operational",
        "data": {
            "database_connected": true,
            "tables_exist": true,
            "active_rules_count": 10
        }
    }
    """
    try:
        # Get database connection
        db_conn = getattr(g, 'db', None)
        if db_conn is None:
            return error_response("Database connection not available", 500)

        # Extract raw connection if it's a DatabaseWrapper
        if hasattr(db_conn, 'conn'):
            raw_conn = db_conn.conn
        else:
            raw_conn = db_conn

        cursor = raw_conn.cursor()

        try:
            # Check if tables exist
            cursor.execute("""
                SELECT table_name FROM information_schema.tables
                WHERE table_schema = 'public'
                AND table_name IN ('mute_rules', 'mute_audit_log')
            """)
            tables = [row[0] for row in cursor.fetchall()]
            tables_exist = len(tables) == 2

            # Count active rules
            active_rules_count = 0
            if 'mute_rules' in tables:
                cursor.execute("SELECT COUNT(*) FROM mute_rules WHERE active = TRUE")
                active_rules_count = cursor.fetchone()[0]

            return success_response({
                'database_connected': True,
                'tables_exist': tables_exist,
                'tables_found': tables,
                'active_rules_count': active_rules_count
            }, "Mute system is operational")

        finally:
            cursor.close()

    except Exception as e:
        logger.error(f"Error testing mute system: {e}")
        import traceback
        traceback.print_exc()
        return error_response(f"Mute system test failed: {str(e)}", 500)
