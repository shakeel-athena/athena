"""
Mute Rules API Blueprint
Handles alert suppression and whitelist management
"""

from flask import Blueprint

mute_bp = Blueprint('mute', __name__, url_prefix='/api/mute')

from . import routes
