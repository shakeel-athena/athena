"""
IP Status API Routes

Provides current status information for IP addresses:
- Firewall/WAF blocking status
- Active mute rules
- Alert statistics
"""

import logging
from flask import jsonify, g
from . import threat_intel_bp
from .routes import require_api_key, rate_limit
import psycopg2.extras

logger = logging.getLogger(__name__)


def get_db_connection():
    """Get database connection from Flask g context."""
    db_conn = getattr(g, 'db', None)
    if db_conn is None:
        raise Exception("Database connection not available")

    # Check if it's a DatabaseWrapper and extract the raw psycopg2 connection
    if hasattr(db_conn, 'conn'):
        return db_conn.conn
    return db_conn


@threat_intel_bp.route('/enrich-ip/<ip_address>/status', methods=['GET'])
@require_api_key
@rate_limit(max_requests=30, window=60)
def get_ip_status(ip_address):
    """
    Get current status of an IP address

    Returns:
        {
            "ip_address": "192.168.1.100",
            "firewall_blocked": true,
            "firewall_blocked_since": "2025-12-25T08:30:00Z",
            "firewall_reason": "Brute force attack",
            "firewall_analyst": "john.doe",

            "waf_blocked": true,
            "waf_blocked_since": "2025-12-25T08:30:00Z",

            "mute_rules": [
                {
                    "id": 123,
                    "conditions": {"source_ip": "192.168.1.100"},
                    "reason": "False positive",
                    "created_by": "jane.smith",
                    "created_at": "2025-12-24T10:00:00Z",
                    "classification": "false_positive"
                }
            ],

            "times_seen_in_alerts": 15
        }
    """
    try:
        db_conn = get_db_connection()
        cursor = db_conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor)

        # 1. Check firewall_ip_metadata table for block status
        cursor.execute("""
            SELECT
                ip_address,
                aws_enforced,
                waf_enforced,
                added_at,
                added_by,
                reason,
                times_seen_in_alerts
            FROM firewall_ip_metadata
            WHERE ip_address::text = %s
              AND active = TRUE
              AND list_type = 'block'
            LIMIT 1
        """, [ip_address])

        block_info = cursor.fetchone()

        # 2. Check mute_rules table for active rules matching this IP
        cursor.execute("""
            SELECT
                id,
                conditions,
                reason,
                created_by,
                created_at,
                expires_at,
                classification
            FROM mute_rules
            WHERE active = TRUE
              AND approval_status IN ('auto_approved', 'approved')
              AND (expires_at IS NULL OR expires_at > NOW())
              AND (
                  conditions->>'source_ip' = %s
                  OR conditions->>'dest_ip' = %s
                  OR (conditions->>'source_ip_cidr' IS NOT NULL
                      AND %s::inet << (conditions->>'source_ip_cidr')::inet)
                  OR (conditions->>'dest_ip_cidr' IS NOT NULL
                      AND %s::inet << (conditions->>'dest_ip_cidr')::inet)
              )
        """, [ip_address, ip_address, ip_address, ip_address])

        mute_rules = cursor.fetchall()

        # 3. Build response
        response = {
            "ip_address": ip_address,

            # Firewall status
            "firewall_blocked": block_info['aws_enforced'] if block_info else False,
            "firewall_blocked_since": block_info['added_at'].isoformat() if block_info and block_info['added_at'] else None,
            "firewall_reason": block_info['reason'] if block_info else None,
            "firewall_analyst": block_info['added_by'] if block_info else None,

            # WAF status
            "waf_blocked": block_info['waf_enforced'] if block_info else False,
            "waf_blocked_since": block_info['added_at'].isoformat() if block_info and block_info['added_at'] else None,

            # Mute rules
            "mute_rules": [
                {
                    "id": rule['id'],
                    "conditions": rule['conditions'],
                    "reason": rule['reason'],
                    "created_by": rule['created_by'],
                    "created_at": rule['created_at'].isoformat() if rule['created_at'] else None,
                    "expires_at": rule['expires_at'].isoformat() if rule['expires_at'] else None,
                    "classification": rule['classification']
                }
                for rule in mute_rules
            ],

            # Alert statistics
            "times_seen_in_alerts": block_info['times_seen_in_alerts'] if block_info else 0
        }

        cursor.close()
        return jsonify(response), 200

    except Exception as e:
        logger.error(f"Error getting IP status for {ip_address}: {e}", exc_info=True)
        return jsonify({
            "success": False,
            "error": f"Failed to get IP status: {str(e)}"
        }), 500
