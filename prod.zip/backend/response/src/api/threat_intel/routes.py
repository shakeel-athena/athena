"""
Threat Intelligence API Routes
Provides IP enrichment and threat intelligence data
"""
import logging
import time
import os
from functools import wraps
from collections import defaultdict
from flask import jsonify, request
from . import threat_intel_bp
from .service import IPEnrichmentService

logger = logging.getLogger(__name__)

# API Key Authentication (for production, use proper JWT or OAuth2)
API_KEY_HEADER = 'X-API-Key'
INTERNAL_API_KEY = os.getenv('THREAT_INTEL_API_KEY', '')  # Set in .env file
ALLOW_LOCALHOST = os.getenv('THREAT_INTEL_ALLOW_LOCALHOST', 'true').lower() == 'true'

def require_api_key(f):
    """
    API Key authentication decorator
    Checks for valid API key in X-API-Key header or allows localhost access
    For production, replace with proper JWT/OAuth2 authentication
    """
    @wraps(f)
    def decorated_function(*args, **kwargs):
        # Check if localhost access is allowed
        client_ip = request.remote_addr
        if ALLOW_LOCALHOST and client_ip in ['127.0.0.1', 'localhost', '::1']:
            logger.debug(f"Allowing localhost access from {client_ip}")
            return f(*args, **kwargs)

        # Check for API key in header
        api_key = request.headers.get(API_KEY_HEADER)

        if not api_key:
            logger.warning(f"Missing API key from {client_ip}")
            return jsonify({
                "success": False,
                "error": "Missing API key. Include X-API-Key header or access from localhost."
            }), 401

        # Validate API key
        if not INTERNAL_API_KEY:
            logger.error("THREAT_INTEL_API_KEY not configured in environment")
            return jsonify({
                "success": False,
                "error": "API authentication not properly configured"
            }), 500

        if api_key != INTERNAL_API_KEY:
            logger.warning(f"Invalid API key from {client_ip}")
            return jsonify({
                "success": False,
                "error": "Invalid API key"
            }), 403

        # Valid API key
        return f(*args, **kwargs)

    return decorated_function

# Simple in-memory rate limiting (for production, use Redis-based rate limiting)
_rate_limit_storage = defaultdict(list)
_RATE_LIMIT_WINDOW = 60  # seconds
_RATE_LIMIT_MAX_REQUESTS = 20  # requests per window

def rate_limit(max_requests=_RATE_LIMIT_MAX_REQUESTS, window=_RATE_LIMIT_WINDOW):
    """
    Simple rate limiting decorator
    For production, replace with Redis-based rate limiting (e.g., flask-limiter)
    """
    def decorator(f):
        @wraps(f)
        def decorated_function(*args, **kwargs):
            # Get client identifier (IP address)
            client_ip = request.remote_addr or 'unknown'
            key = f"{f.__name__}:{client_ip}"

            # Get current time
            now = time.time()

            # Clean old entries
            _rate_limit_storage[key] = [
                timestamp for timestamp in _rate_limit_storage[key]
                if now - timestamp < window
            ]

            # Check rate limit
            if len(_rate_limit_storage[key]) >= max_requests:
                logger.warning(f"Rate limit exceeded for {client_ip} on {f.__name__}")
                return jsonify({
                    "success": False,
                    "error": "Rate limit exceeded. Please try again later.",
                    "retry_after": int(window - (now - _rate_limit_storage[key][0]))
                }), 429

            # Add current request
            _rate_limit_storage[key].append(now)

            # Execute the function
            return f(*args, **kwargs)

        return decorated_function
    return decorator

# Initialize the IP enrichment service
ip_enrichment_service = None

def get_enrichment_service():
    """Get or initialize the IP enrichment service"""
    global ip_enrichment_service
    if ip_enrichment_service is None:
        ip_enrichment_service = IPEnrichmentService()
    return ip_enrichment_service

@threat_intel_bp.route('/enrich-ip/<ip_address>', methods=['GET'])
@require_api_key  # Check API key first
@rate_limit(max_requests=20, window=60)  # 20 requests per minute per IP
def enrich_ip(ip_address):
    """
    Enrich an IP address with threat intelligence from multiple sources

    Args:
        ip_address (str): IP address to enrich

    Returns:
        JSON response with enrichment data matching the schema:
        {
            "ip_address": str,
            "cached": bool,
            "geolocation": {...},
            "threat_intelligence": {...},
            "composite_score": {...},
            "virustotal": {...},
            "otx": {...}
        }
    """
    try:
        # Validate IP address format
        if not ip_address or ip_address == 'Unknown':
            return jsonify({
                "success": False,
                "error": "Invalid IP address"
            }), 400

        # Basic IP validation (IPv4 only for now)
        parts = ip_address.split('.')
        if len(parts) != 4:
            return jsonify({
                "success": False,
                "error": "Invalid IPv4 address format"
            }), 400

        try:
            for part in parts:
                num = int(part)
                if num < 0 or num > 255:
                    raise ValueError
        except (ValueError, AttributeError):
            return jsonify({
                "success": False,
                "error": "Invalid IPv4 address"
            }), 400

        # Check if IP is private
        is_private = _is_private_ip(ip_address)
        if is_private:
            # For private IPs, skip external threat intel but still fetch internal context and related IoCs
            service = get_enrichment_service()
            internal_context = service._fetch_internal_context(ip_address)
            related_iocs = service._fetch_related_iocs(ip_address)

            return jsonify({
                "ip_address": ip_address,
                "is_private": True,
                "enrichment_available": False,
                "cached": False,
                "geolocation": {
                    "country_code": "",
                    "country_name": "Private Network",
                    "city": "Internal",
                    "isp": "Private Network",
                    "asn": ""
                },
                "threat_intelligence": {
                    "abuseipdb_score": 0,
                    "total_reports": 0,
                    "is_tor": False,
                    "is_whitelisted": False,
                    "is_private": True
                },
                "composite_score": None,
                "virustotal": None,
                "otx": None,
                "greynoise": None,
                "whois": None,
                "cloud_provider": None,
                "passive_dns": None,
                "internal_context": internal_context,
                "related_iocs": related_iocs
            }), 200

        # Get enrichment service and fetch data
        service = get_enrichment_service()
        enrichment_data = service.enrich_ip(ip_address)

        return jsonify(enrichment_data), 200

    except Exception as e:
        logger.error(f"Error enriching IP {ip_address}: {e}", exc_info=True)
        return jsonify({
            "success": False,
            "error": f"Failed to enrich IP address: {str(e)}"
        }), 500

def _is_private_ip(ip_address):
    """
    Check if an IP address is private/internal

    Args:
        ip_address (str): IP address to check

    Returns:
        bool: True if IP is private, False otherwise
    """
    try:
        parts = [int(p) for p in ip_address.split('.')]

        # 10.0.0.0/8
        if parts[0] == 10:
            return True

        # 172.16.0.0/12
        if parts[0] == 172 and 16 <= parts[1] <= 31:
            return True

        # 192.168.0.0/16
        if parts[0] == 192 and parts[1] == 168:
            return True

        # 127.0.0.0/8 (localhost)
        if parts[0] == 127:
            return True

        # 169.254.0.0/16 (link-local)
        if parts[0] == 169 and parts[1] == 254:
            return True

        return False

    except (ValueError, IndexError, AttributeError):
        return False

@threat_intel_bp.route('/enrich-ip/batch', methods=['POST'])
@require_api_key
@rate_limit(max_requests=5, window=60)  # 5 batch requests per minute per IP
def enrich_ip_batch():
    """
    Enrich multiple IP addresses in a single request

    Request body:
    {
        "ip_addresses": ["192.168.1.1", "8.8.8.8", ...]
    }

    Returns:
        JSON response with enrichment data for each IP
    """
    try:
        data = request.get_json()

        if not data or 'ip_addresses' not in data:
            return jsonify({
                "success": False,
                "error": "Missing ip_addresses in request body"
            }), 400

        ip_addresses = data['ip_addresses']

        if not isinstance(ip_addresses, list):
            return jsonify({
                "success": False,
                "error": "ip_addresses must be a list"
            }), 400

        if len(ip_addresses) > 50:
            return jsonify({
                "success": False,
                "error": "Maximum 50 IP addresses per batch request"
            }), 400

        # Get enrichment service
        service = get_enrichment_service()

        # Enrich each IP
        results = {}
        errors = {}

        for ip in ip_addresses:
            try:
                # Skip private IPs
                if _is_private_ip(ip):
                    errors[ip] = "Private IP address"
                    continue

                enrichment_data = service.enrich_ip(ip)
                results[ip] = enrichment_data

            except Exception as e:
                logger.error(f"Error enriching IP {ip} in batch: {e}")
                errors[ip] = str(e)

        return jsonify({
            "success": True,
            "results": results,
            "errors": errors,
            "total": len(ip_addresses),
            "successful": len(results),
            "failed": len(errors)
        }), 200

    except Exception as e:
        logger.error(f"Error in batch IP enrichment: {e}", exc_info=True)
        return jsonify({
            "success": False,
            "error": f"Failed to process batch request: {str(e)}"
        }), 500

@threat_intel_bp.route('/threat-intel/stats', methods=['GET'])
@require_api_key
@rate_limit(max_requests=10, window=60)  # 10 requests per minute
def get_threat_intel_stats():
    """
    Get threat intelligence cache statistics

    Returns:
        JSON response with cache statistics
    """
    try:
        service = get_enrichment_service()
        stats = service.get_cache_stats()

        return jsonify({
            "success": True,
            "stats": stats
        }), 200

    except Exception as e:
        logger.error(f"Error getting threat intel stats: {e}", exc_info=True)
        return jsonify({
            "success": False,
            "error": f"Failed to get statistics: {str(e)}"
        }), 500

@threat_intel_bp.route('/threat-intel/cache/clear', methods=['POST'])
@require_api_key
@rate_limit(max_requests=5, window=60)  # 5 requests per minute (admin operation)
def clear_threat_intel_cache():
    """
    Clear the threat intelligence cache

    Returns:
        JSON response with success status
    """
    try:
        service = get_enrichment_service()
        service.clear_cache()

        return jsonify({
            "success": True,
            "message": "Threat intelligence cache cleared successfully"
        }), 200

    except Exception as e:
        logger.error(f"Error clearing threat intel cache: {e}", exc_info=True)
        return jsonify({
            "success": False,
            "error": f"Failed to clear cache: {str(e)}"
        }), 500
