"""
Threat Intelligence API Blueprint
Provides IP enrichment and threat intelligence endpoints
"""
from flask import Blueprint

threat_intel_bp = Blueprint('threat_intel', __name__, url_prefix='/api')

from . import routes
from . import status_routes
