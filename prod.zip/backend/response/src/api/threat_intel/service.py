"""
IP Enrichment Service
Aggregates threat intelligence from multiple sources
"""
import os
import logging
import requests
import time
from datetime import datetime, timedelta
from typing import Dict, Any, Optional
from concurrent.futures import ThreadPoolExecutor, as_completed
import json

logger = logging.getLogger(__name__)

# Try to import Redis, but make it optional
try:
    import redis
    REDIS_AVAILABLE = True
except ImportError:
    REDIS_AVAILABLE = False
    logger.warning("Redis not available, using in-memory cache (not recommended for production)")

class IPEnrichmentService:
    """Service for enriching IP addresses with threat intelligence"""

    def __init__(self):
        """Initialize the IP enrichment service"""
        self.cache_ttl = timedelta(hours=24)  # Cache for 24 hours
        self.cache_ttl_seconds = int(self.cache_ttl.total_seconds())

        # Metrics tracking
        self.metrics = {
            'total_requests': 0,
            'cache_hits': 0,
            'cache_misses': 0,
            'api_calls': {
                'geolocation': {'success': 0, 'failure': 0},
                'abuseipdb': {'success': 0, 'failure': 0},
                'virustotal': {'success': 0, 'failure': 0},
                'otx': {'success': 0, 'failure': 0},
                'greynoise': {'success': 0, 'failure': 0},
                'internal_context': {'success': 0, 'failure': 0}
            },
            'errors': 0
        }

        # Initialize cache (Redis if available, otherwise in-memory)
        if REDIS_AVAILABLE:
            try:
                redis_host = os.getenv('REDIS_HOST', 'localhost')
                redis_port = int(os.getenv('REDIS_PORT', 6379))
                redis_db = int(os.getenv('REDIS_DB', 0))
                redis_password = os.getenv('REDIS_PASSWORD', None)

                self.redis_client = redis.Redis(
                    host=redis_host,
                    port=redis_port,
                    db=redis_db,
                    password=redis_password,
                    decode_responses=True,
                    socket_timeout=5,
                    socket_connect_timeout=5
                )
                # Test connection
                self.redis_client.ping()
                self.use_redis = True
                logger.info(f"Redis cache initialized at {redis_host}:{redis_port}")
            except Exception as e:
                logger.warning(f"Failed to connect to Redis: {e}. Falling back to in-memory cache")
                self.use_redis = False
                self.cache = {}
        else:
            self.use_redis = False
            self.cache = {}
            logger.info("Using in-memory cache (Redis not installed)")

        # Load API keys from environment
        self.abuseipdb_api_key = os.getenv('ABUSEIPDB_API_KEY', '')
        self.virustotal_api_key = os.getenv('VIRUSTOTAL_API_KEY', '')
        self.otx_api_key = os.getenv('OTX_API_KEY', '')
        self.greynoise_api_key = os.getenv('GREYNOISE_API_KEY', '')

        # API endpoints
        self.abuseipdb_url = "https://api.abuseipdb.com/api/v2/check"
        self.virustotal_url = "https://www.virustotal.com/api/v3/ip_addresses"
        self.otx_url = "https://otx.alienvault.com/api/v1/indicators/IPv4"

        # Cache for OpenSearch field type detection
        self._opensearch_field_cache = {}

        logger.info("IP Enrichment Service initialized")

    def enrich_ip(self, ip_address: str) -> Dict[str, Any]:
        """
        Enrich an IP address with threat intelligence from multiple sources

        Args:
            ip_address (str): IP address to enrich

        Returns:
            Dict containing enrichment data matching the API schema
        """
        start_time = time.time()
        self.metrics['total_requests'] += 1

        # Check cache first
        cache_key = f"ip_enrichment:{ip_address}"

        if self.use_redis:
            # Try Redis cache
            try:
                cached_json = self.redis_client.get(cache_key)
                if cached_json:
                    self.metrics['cache_hits'] += 1
                    elapsed_time = (time.time() - start_time) * 1000
                    logger.info(f"Cache HIT for IP: {ip_address} (took {elapsed_time:.2f}ms)")
                    cached_data = json.loads(cached_json)
                    cached_data['cached'] = True
                    return cached_data
            except Exception as e:
                logger.error(f"Redis cache read error: {e}")
        else:
            # Use in-memory cache
            if cache_key in self.cache:
                cached_data, cached_time = self.cache[cache_key]
                if datetime.now() - cached_time < self.cache_ttl:
                    self.metrics['cache_hits'] += 1
                    elapsed_time = (time.time() - start_time) * 1000
                    logger.info(f"Cache HIT for IP: {ip_address} (took {elapsed_time:.2f}ms)")
                    cached_data['cached'] = True
                    return cached_data

        # Cache miss
        self.metrics['cache_misses'] += 1

        # Fetch data from multiple sources in parallel for better performance
        logger.info(f"Fetching fresh enrichment data for IP: {ip_address}")

        # Use ThreadPoolExecutor to fetch all sources concurrently
        with ThreadPoolExecutor(max_workers=10) as executor:
            # Submit all tasks
            geo_future = executor.submit(self._fetch_geolocation, ip_address)
            abuse_future = executor.submit(self._fetch_abuseipdb, ip_address)
            vt_future = executor.submit(self._fetch_virustotal, ip_address)
            otx_future = executor.submit(self._fetch_otx, ip_address)
            greynoise_future = executor.submit(self._fetch_greynoise, ip_address)
            internal_future = executor.submit(self._fetch_internal_context, ip_address)
            whois_future = executor.submit(self._fetch_whois, ip_address)
            passive_dns_future = executor.submit(self._fetch_passive_dns, ip_address)
            related_iocs_future = executor.submit(self._fetch_related_iocs, ip_address)

            # Collect results
            geolocation_data = geo_future.result()
            abuseipdb_data = abuse_future.result()
            virustotal_data = vt_future.result()
            otx_data = otx_future.result()
            greynoise_data = greynoise_future.result()
            internal_context = internal_future.result()
            whois_data = whois_future.result()
            passive_dns_data = passive_dns_future.result()
            related_iocs_data = related_iocs_future.result()

            # Cloud provider detection needs geo data, so run it after geo completes
            cloud_provider_data = self._fetch_cloud_provider(ip_address, geolocation_data)

        # Calculate composite risk score
        composite_score = self._calculate_composite_score(
            abuseipdb_data,
            virustotal_data,
            otx_data
        )

        # Build response matching the API schema
        enrichment_data = {
            "ip_address": ip_address,
            "cached": False,
            "geolocation": geolocation_data,
            "threat_intelligence": abuseipdb_data,
            "composite_score": composite_score,
            "virustotal": virustotal_data,
            "otx": otx_data,
            "greynoise": greynoise_data,
            "internal_context": internal_context,
            "whois": whois_data,
            "cloud_provider": cloud_provider_data,
            "passive_dns": passive_dns_data,
            "related_iocs": related_iocs_data
        }

        # Cache the result
        if self.use_redis:
            try:
                # Store in Redis with TTL
                self.redis_client.setex(
                    cache_key,
                    self.cache_ttl_seconds,
                    json.dumps(enrichment_data)
                )
                logger.info(f"Cached enrichment data in Redis for IP: {ip_address}")
            except Exception as e:
                logger.error(f"Redis cache write error: {e}")
        else:
            # Store in memory
            self.cache[cache_key] = (enrichment_data, datetime.now())

        # Log performance metrics
        elapsed_time = (time.time() - start_time) * 1000
        logger.info(
            f"Cache MISS for IP: {ip_address} - Fresh data fetched in {elapsed_time:.2f}ms "
            f"(geo: {geolocation_data.get('country_code', 'N/A')}, "
            f"threat_score: {abuseipdb_data.get('abuseipdb_score', 0)})"
        )

        return enrichment_data

    def _fetch_geolocation(self, ip_address: str) -> Dict[str, Any]:
        """
        Fetch geolocation data for an IP address

        Uses ip-api.com free service (no API key required)
        """
        try:
            start_time = time.time()
            # Note: Free tier of ip-api.com only supports HTTP, not HTTPS
            # For HTTPS, need paid plan at https://members.ip-api.com/
            url = f"http://ip-api.com/json/{ip_address}"
            response = requests.get(url, timeout=5)
            elapsed = (time.time() - start_time) * 1000

            if response.status_code == 200:
                data = response.json()

                if data.get('status') == 'success':
                    self.metrics['api_calls']['geolocation']['success'] += 1
                    logger.debug(f"Geolocation API success for {ip_address} ({elapsed:.0f}ms)")
                    return {
                        "country_code": data.get('countryCode', ''),
                        "country_name": data.get('country', ''),
                        "city": data.get('city', ''),
                        "isp": data.get('isp', ''),
                        "asn": data.get('as', '')
                    }

            self.metrics['api_calls']['geolocation']['failure'] += 1
            logger.warning(f"Geolocation API returned non-success status for {ip_address}")

        except Exception as e:
            self.metrics['api_calls']['geolocation']['failure'] += 1
            logger.error(f"Error fetching geolocation for {ip_address}: {e}")

        return {
            "country_code": "",
            "country_name": "",
            "city": "",
            "isp": "",
            "asn": ""
        }

    def _fetch_abuseipdb(self, ip_address: str) -> Dict[str, Any]:
        """
        Fetch threat intelligence from AbuseIPDB

        Requires ABUSEIPDB_API_KEY environment variable
        """
        if not self.abuseipdb_api_key:
            logger.warning("AbuseIPDB API key not configured")
            return self._empty_abuseipdb_response()

        try:
            headers = {
                'Accept': 'application/json',
                'Key': self.abuseipdb_api_key
            }

            params = {
                'ipAddress': ip_address,
                'maxAgeInDays': 90,
                'verbose': True
            }

            response = requests.get(
                self.abuseipdb_url,
                headers=headers,
                params=params,
                timeout=10
            )

            if response.status_code == 200:
                data = response.json().get('data', {})

                return {
                    "abuseipdb_score": data.get('abuseConfidenceScore', 0),
                    "total_reports": data.get('totalReports', 0),
                    "is_tor": data.get('isTor', False),
                    "is_whitelisted": data.get('isWhitelisted', False),
                    "is_private": data.get('isPublic', True) is False
                }

            else:
                logger.warning(f"AbuseIPDB API returned status {response.status_code}")

        except Exception as e:
            logger.error(f"Error fetching AbuseIPDB data for {ip_address}: {e}")

        return self._empty_abuseipdb_response()

    def _fetch_virustotal(self, ip_address: str) -> Dict[str, Any]:
        """
        Fetch threat intelligence from VirusTotal

        Requires VIRUSTOTAL_API_KEY environment variable
        """
        if not self.virustotal_api_key:
            logger.warning("VirusTotal API key not configured")
            return self._empty_virustotal_response()

        try:
            headers = {
                'x-apikey': self.virustotal_api_key
            }

            url = f"{self.virustotal_url}/{ip_address}"

            response = requests.get(url, headers=headers, timeout=10)

            if response.status_code == 200:
                data = response.json().get('data', {})
                attributes = data.get('attributes', {})
                last_analysis_stats = attributes.get('last_analysis_stats', {})

                malicious = last_analysis_stats.get('malicious', 0)
                suspicious = last_analysis_stats.get('suspicious', 0)
                total = sum(last_analysis_stats.values())

                # Calculate VT score (0-100 based on detection ratio)
                vt_score = 0
                if total > 0:
                    vt_score = int(((malicious + suspicious) / total) * 100)

                return {
                    "vt_score": vt_score,
                    "malicious": malicious,
                    "suspicious": suspicious,
                    "total_vendors": total
                }

            else:
                logger.warning(f"VirusTotal API returned status {response.status_code}")

        except Exception as e:
            logger.error(f"Error fetching VirusTotal data for {ip_address}: {e}")

        return self._empty_virustotal_response()

    def _fetch_otx(self, ip_address: str) -> Dict[str, Any]:
        """
        Fetch threat intelligence from AlienVault OTX

        Requires OTX_API_KEY environment variable
        """
        if not self.otx_api_key:
            logger.warning("OTX API key not configured")
            return self._empty_otx_response()

        try:
            headers = {
                'X-OTX-API-KEY': self.otx_api_key
            }

            # Fetch general info
            url = f"{self.otx_url}/{ip_address}/general"
            response = requests.get(url, headers=headers, timeout=10)

            if response.status_code == 200:
                data = response.json()

                pulse_count = data.get('pulse_info', {}).get('count', 0)
                pulses = data.get('pulse_info', {}).get('pulses', [])

                # Extract pulse information
                pulse_list = []
                malware_families = set()

                for pulse in pulses[:5]:  # Limit to first 5 pulses
                    pulse_list.append({
                        "id": pulse.get('id', ''),
                        "name": pulse.get('name', ''),
                        "created": pulse.get('created', ''),
                        "tags": pulse.get('tags', [])
                    })

                    # Extract malware families from tags
                    for tag in pulse.get('tags', []):
                        if any(keyword in tag.lower() for keyword in ['malware', 'trojan', 'rat', 'ransomware', 'botnet']):
                            malware_families.add(tag)

                # Calculate OTX score based on pulse count
                otx_score = min(pulse_count * 10, 100)

                return {
                    "pulse_count": pulse_count,
                    "otx_score": otx_score,
                    "pulses": pulse_list,
                    "malware_families": list(malware_families)
                }

            else:
                logger.warning(f"OTX API returned status {response.status_code}")

        except Exception as e:
            logger.error(f"Error fetching OTX data for {ip_address}: {e}")

        return self._empty_otx_response()

    def _fetch_greynoise(self, ip_address: str) -> Optional[Dict[str, Any]]:
        """
        Fetch threat intelligence from GreyNoise

        GreyNoise identifies benign scanners, security researchers, and other
        "internet noise" to help distinguish real threats from background noise.

        Requires GREYNOISE_API_KEY environment variable (free Community API)
        Get your free key at: https://viz.greynoise.io/signup
        """
        if not self.greynoise_api_key:
            logger.debug("GreyNoise API key not configured")
            return None

        try:
            start_time = time.time()
            # GreyNoise Community API endpoint
            url = f"https://api.greynoise.io/v3/community/{ip_address}"
            headers = {
                'key': self.greynoise_api_key,
                'Accept': 'application/json'
            }

            response = requests.get(url, headers=headers, timeout=10)
            elapsed = (time.time() - start_time) * 1000

            if response.status_code == 200:
                data = response.json()
                self.metrics['api_calls']['greynoise']['success'] += 1
                logger.debug(f"GreyNoise API success for {ip_address} ({elapsed:.0f}ms)")

                # Process GreyNoise response
                noise = data.get('noise', False)  # Is this IP internet noise?
                riot = data.get('riot', False)    # Is this a known benign service?
                classification = data.get('classification', 'unknown')
                name = data.get('name', '')
                link = data.get('link', f'https://viz.greynoise.io/ip/{ip_address}')

                return {
                    "noise": noise,
                    "riot": riot,
                    "classification": classification,
                    "name": name,
                    "link": link,
                    "message": data.get('message', '')
                }

            elif response.status_code == 404:
                # IP not found in GreyNoise - this is actually good (not known noise)
                self.metrics['api_calls']['greynoise']['success'] += 1
                logger.debug(f"GreyNoise: IP {ip_address} not found (not internet noise)")
                return {
                    "noise": False,
                    "riot": False,
                    "classification": "unknown",
                    "name": "",
                    "link": f"https://viz.greynoise.io/ip/{ip_address}",
                    "message": "IP not found in GreyNoise database"
                }

            else:
                self.metrics['api_calls']['greynoise']['failure'] += 1
                logger.warning(f"GreyNoise API returned status {response.status_code} for {ip_address}")

        except Exception as e:
            self.metrics['api_calls']['greynoise']['failure'] += 1
            logger.error(f"Error fetching GreyNoise data for {ip_address}: {e}")

        return None

    def _get_opensearch_ip_field_name(self, field_base: str, es_host: str, es_port: int,
                                       es_index: str, es_username: str, es_password: str,
                                       es_verify_ssl: bool) -> str:
        """
        Detect the correct field name for IP queries in OpenSearch.

        For 'ip' type fields: use 'src_ip' or 'dest_ip'
        For 'text' fields with keyword multi-field: use 'src_ip.keyword' or 'dest_ip.keyword'

        Caches the result to avoid repeated mapping checks.

        Args:
            field_base: Base field name like 'src_ip' or 'dest_ip'
            es_host, es_port, es_index, es_username, es_password, es_verify_ssl: OpenSearch connection params

        Returns:
            str: The correct field name to use in queries ('field' or 'field.keyword')
        """
        import urllib3

        # Check cache first
        cache_key = f"{es_host}:{es_port}/{es_index}/{field_base}"
        if cache_key in self._opensearch_field_cache:
            return self._opensearch_field_cache[cache_key]

        try:
            urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

            # Query the mapping for this field
            mapping_url = f"https://{es_host}:{es_port}/{es_index}/_mapping/field/{field_base}"
            auth = (es_username, es_password) if es_username and es_password else None

            response = requests.get(
                mapping_url,
                auth=auth,
                verify=es_verify_ssl,
                timeout=5
            )

            if response.status_code == 200:
                result = response.json()

                # Check any index in the response for the field type
                for index_name, index_data in result.items():
                    mappings = index_data.get('mappings', {})
                    field_info = mappings.get(field_base, {})
                    field_mapping = field_info.get('mapping', {}).get(field_base, {})
                    field_type = field_mapping.get('type')

                    # If it's an 'ip' type field, don't use .keyword
                    if field_type == 'ip':
                        logger.debug(f"Field {field_base} is type 'ip', using without .keyword suffix")
                        self._opensearch_field_cache[cache_key] = field_base
                        return field_base

                    # If it has a keyword multi-field, use .keyword
                    fields = field_mapping.get('fields', {})
                    if 'keyword' in fields:
                        logger.debug(f"Field {field_base} has .keyword multi-field, using with suffix")
                        field_with_keyword = f"{field_base}.keyword"
                        self._opensearch_field_cache[cache_key] = field_with_keyword
                        return field_with_keyword

                    # Default to base field if text type
                    if field_type == 'text':
                        logger.debug(f"Field {field_base} is type 'text' without .keyword, using base field")
                        self._opensearch_field_cache[cache_key] = field_base
                        return field_base

                    break  # Only check first index

        except Exception as e:
            logger.warning(f"Failed to detect field type for {field_base}: {e}")

        # Default: assume 'ip' type (no .keyword needed) based on current system
        logger.debug(f"Using default (no .keyword) for field {field_base}")
        self._opensearch_field_cache[cache_key] = field_base
        return field_base

    def _fetch_internal_context(self, ip_address: str) -> Optional[Dict[str, Any]]:
        """
        Fetch internal alert history for an IP address directly from OpenSearch

        Queries OpenSearch/Elasticsearch directly with IP filtering for better performance
        and accuracy (avoids the 500 alert limit from the REST API).
        """
        try:
            import urllib3
            urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

            start_time = time.time()

            # Get Elasticsearch connection details (matching _fetch_related_iocs configuration)
            es_host = os.getenv('SURICATA_ES_HOST', 'localhost')
            es_port = int(os.getenv('SURICATA_ES_PORT', '9220'))
            es_username = os.getenv('SURICATA_ES_USERNAME')
            es_password = os.getenv('SURICATA_ES_PASSWORD')
            es_verify_ssl = os.getenv('SURICATA_ES_VERIFY_SSL', 'false').lower() == 'true'
            es_index = os.getenv('SURICATA_ES_INDEX_PATTERN', 'suricata-*')

            # Detect correct field names (handles both 'ip' type and 'keyword' fields)
            src_ip_field = self._get_opensearch_ip_field_name(
                'src_ip', es_host, es_port, es_index, es_username, es_password, es_verify_ssl
            )
            dest_ip_field = self._get_opensearch_ip_field_name(
                'dest_ip', es_host, es_port, es_index, es_username, es_password, es_verify_ssl
            )

            # Build query to find all alerts involving this IP (src or dest)
            query = {
                "query": {
                    "bool": {
                        "must": [
                            {"range": {"@timestamp": {"gte": "now-30d"}}},
                            {"exists": {"field": "alert.severity"}}
                        ],
                        "should": [
                            {"term": {src_ip_field: ip_address}},
                            {"term": {dest_ip_field: ip_address}}
                        ],
                        "minimum_should_match": 1
                    }
                },
                "size": 1000,  # Get up to 1000 alerts for this IP
                "sort": [{"@timestamp": {"order": "desc"}}]
            }

            # Use HTTPS and authentication
            es_url = f"https://{es_host}:{es_port}/{es_index}/_search"
            auth = (es_username, es_password) if es_username and es_password else None

            logger.debug(f"Querying OpenSearch for internal context: {ip_address} at {es_url}")

            response = requests.post(
                es_url,
                json=query,
                timeout=10,
                headers={'Content-Type': 'application/json'},
                auth=auth,
                verify=es_verify_ssl
            )
            elapsed = (time.time() - start_time) * 1000

            if response.status_code != 200:
                logger.warning(f"OpenSearch query failed for {ip_address}: status {response.status_code}")
                self.metrics['api_calls']['internal_context']['failure'] += 1
                return {
                    "total_alerts": 0,
                    "first_seen": None,
                    "last_seen": None,
                    "affected_hosts_count": 0,
                    "sources": {'wazuh': 0, 'suricata': 0},
                    "severity_counts": {'low': 0, 'medium': 0, 'high': 0, 'critical': 0},
                    "top_alert_types": []
                }

            result = response.json()
            hits = result.get('hits', {}).get('hits', [])

            logger.debug(f"Found {len(hits)} alerts for {ip_address} in OpenSearch")

            if not hits:
                self.metrics['api_calls']['internal_context']['success'] += 1
                return {
                    "total_alerts": 0,
                    "first_seen": None,
                    "last_seen": None,
                    "affected_hosts_count": 0,
                    "sources": {'wazuh': 0, 'suricata': 0},
                    "severity_counts": {'low': 0, 'medium': 0, 'high': 0, 'critical': 0},
                    "top_alert_types": []
                }

            # Process alerts
            timestamps = []
            affected_hosts = set()
            alert_types = {}
            sources = {'wazuh': 0, 'suricata': 0}
            severity_counts = {'low': 0, 'medium': 0, 'high': 0, 'critical': 0}

            for hit in hits:
                source_data = hit.get('_source', {})

                # Extract timestamp
                timestamp_str = source_data.get('@timestamp')
                if timestamp_str:
                    try:
                        ts = datetime.fromisoformat(timestamp_str.replace('Z', '+00:00'))
                        timestamps.append(ts)
                    except Exception:
                        pass

                # Collect affected hosts (the OTHER IP in the alert)
                src_ip = source_data.get('src_ip')
                dest_ip = source_data.get('dest_ip')
                if src_ip == ip_address and dest_ip:
                    affected_hosts.add(dest_ip)
                elif dest_ip == ip_address and src_ip:
                    affected_hosts.add(src_ip)

                # Count alert types (signature)
                alert_data = source_data.get('alert', {})
                signature = alert_data.get('signature', 'Unknown')
                alert_types[signature] = alert_types.get(signature, 0) + 1

                # Count sources (all from Suricata since we're querying Suricata index)
                sources['suricata'] += 1

                # Count severities
                severity_num = alert_data.get('severity', 3)
                if severity_num == 1:
                    severity_counts['critical'] += 1
                elif severity_num == 2:
                    severity_counts['high'] += 1
                elif severity_num == 3:
                    severity_counts['medium'] += 1
                else:
                    severity_counts['low'] += 1

            # Calculate time range
            first_seen = min(timestamps).isoformat() if timestamps else None
            last_seen = max(timestamps).isoformat() if timestamps else None

            # Get top 5 alert types
            top_alert_types = sorted(
                alert_types.items(),
                key=lambda x: x[1],
                reverse=True
            )[:5]

            self.metrics['api_calls']['internal_context']['success'] += 1
            logger.info(f"Internal context found {len(hits)} alerts for {ip_address} ({elapsed:.0f}ms)")

            return {
                "total_alerts": len(hits),
                "first_seen": first_seen,
                "last_seen": last_seen,
                "affected_hosts_count": len(affected_hosts),
                "sources": sources,
                "severity_counts": severity_counts,
                "top_alert_types": [{"type": t[0], "count": t[1]} for t in top_alert_types]
            }

        except Exception as e:
            self.metrics['api_calls']['internal_context']['failure'] += 1
            logger.error(f"Error fetching internal context for {ip_address}: {e}", exc_info=True)
            # Return empty result instead of None for exceptions
            return {
                "total_alerts": 0,
                "first_seen": None,
                "last_seen": None,
                "affected_hosts_count": 0,
                "sources": {'wazuh': 0, 'suricata': 0},
                "severity_counts": {'low': 0, 'medium': 0, 'high': 0, 'critical': 0},
                "top_alert_types": []
            }

    def _calculate_composite_score(
        self,
        abuseipdb_data: Dict[str, Any],
        virustotal_data: Dict[str, Any],
        otx_data: Dict[str, Any]
    ) -> Dict[str, Any]:
        """
        Calculate composite risk score from multiple sources

        Returns a composite score object with risk level, confidence, and reasoning
        """
        # Extract individual scores
        abuseipdb_score = abuseipdb_data.get('abuseipdb_score', 0)
        vt_score = virustotal_data.get('vt_score', 0)
        otx_score = otx_data.get('otx_score', 0)

        # Weight the scores (AbuseIPDB is most reliable, followed by VT, then OTX)
        weights = {
            'abuseipdb': 0.5,
            'virustotal': 0.3,
            'otx': 0.2
        }

        composite_score = int(
            (abuseipdb_score * weights['abuseipdb']) +
            (vt_score * weights['virustotal']) +
            (otx_score * weights['otx'])
        )

        # Determine risk level
        if composite_score >= 90:
            risk_level = 'CRITICAL'
        elif composite_score >= 75:
            risk_level = 'HIGH'
        elif composite_score >= 50:
            risk_level = 'MEDIUM'
        elif composite_score >= 25:
            risk_level = 'LOW'
        else:
            risk_level = 'MINIMAL'

        # Calculate confidence based on data availability
        available_sources = sum([
            1 if abuseipdb_score > 0 else 0,
            1 if vt_score > 0 else 0,
            1 if otx_score > 0 else 0
        ])
        confidence = available_sources / 3.0

        # Generate reasoning text
        reasoning = self._generate_reasoning(
            abuseipdb_data,
            virustotal_data,
            otx_data,
            risk_level
        )

        return {
            "composite_score": composite_score,
            "risk_level": risk_level,
            "confidence": confidence,
            "reasoning": reasoning,
            "component_scores": {
                "abuseipdb": abuseipdb_score,
                "virustotal": vt_score,
                "otx": otx_score,
                "internal_activity": 0  # Placeholder for future internal analysis
            }
        }

    def _generate_reasoning(
        self,
        abuseipdb_data: Dict[str, Any],
        virustotal_data: Dict[str, Any],
        otx_data: Dict[str, Any],
        risk_level: str
    ) -> str:
        """Generate human-readable reasoning for the risk assessment"""
        parts = []

        # AbuseIPDB reasoning
        abuse_score = abuseipdb_data.get('abuseipdb_score', 0)
        total_reports = abuseipdb_data.get('total_reports', 0)

        if abuse_score > 0:
            if abuse_score >= 75:
                parts.append(f"Reported {total_reports} times on AbuseIPDB with high confidence of malicious activity")
            elif abuse_score >= 50:
                parts.append(f"Reported {total_reports} times on AbuseIPDB with moderate confidence")
            else:
                parts.append(f"Limited abuse reports ({total_reports}) on AbuseIPDB")

        # VirusTotal reasoning
        vt_score = virustotal_data.get('vt_score', 0)
        malicious = virustotal_data.get('malicious', 0)

        if vt_score > 0:
            parts.append(f"{malicious} security vendors flagged this IP as malicious")

        # OTX reasoning
        pulse_count = otx_data.get('pulse_count', 0)
        malware = otx_data.get('malware_families', [])

        if pulse_count > 0:
            parts.append(f"Associated with {pulse_count} threat intelligence pulse(s)")

        if malware:
            parts.append(f"Linked to malware: {', '.join(malware[:3])}")

        # Default message if no data
        if not parts:
            return "No significant threat intelligence data available for this IP address."

        # Combine parts
        if risk_level in ['CRITICAL', 'HIGH']:
            prefix = "Multiple threat intelligence sources indicate malicious activity from this IP address"
        elif risk_level == 'MEDIUM':
            prefix = "Some threat intelligence sources have flagged this IP address"
        elif risk_level == 'LOW':
            prefix = "Limited threat intelligence suggests potential risk"
        else:
            prefix = "Minimal threat indicators detected"

        return f"{prefix}. {'. '.join(parts)}."

    def _empty_abuseipdb_response(self) -> Dict[str, Any]:
        """Return empty AbuseIPDB response structure"""
        return {
            "abuseipdb_score": 0,
            "total_reports": 0,
            "is_tor": False,
            "is_whitelisted": False,
            "is_private": False
        }

    def _empty_virustotal_response(self) -> Dict[str, Any]:
        """Return empty VirusTotal response structure"""
        return {
            "vt_score": 0,
            "malicious": 0,
            "suspicious": 0,
            "total_vendors": 0
        }

    def _empty_otx_response(self) -> Dict[str, Any]:
        """Return empty OTX response structure"""
        return {
            "pulse_count": 0,
            "otx_score": 0,
            "pulses": [],
            "malware_families": []
        }

    def _fetch_whois(self, ip_address: str) -> Optional[Dict[str, Any]]:
        """
        Fetch WHOIS data for an IP address

        Returns registrant information, abuse contacts, and network details
        """
        try:
            from ipwhois import IPWhois

            start_time = time.time()
            obj = IPWhois(ip_address)

            # Use RDAP lookup (more structured than legacy WHOIS)
            result = obj.lookup_rdap(depth=1)
            elapsed = (time.time() - start_time) * 1000

            logger.debug(f"WHOIS lookup success for {ip_address} ({elapsed:.0f}ms)")

            # Extract relevant information
            network = result.get('network', {})
            objects = result.get('objects', {})

            # Find abuse contact from objects
            abuse_contacts = []
            for obj_key, obj_data in objects.items():
                if obj_data.get('roles') and 'abuse' in obj_data.get('roles', []):
                    contact = obj_data.get('contact', {})
                    if contact.get('email'):
                        abuse_contacts.extend(contact['email'])

            # Get registrar/organization info
            registrant = None
            for obj_key, obj_data in objects.items():
                if obj_data.get('roles') and 'registrant' in obj_data.get('roles', []):
                    contact = obj_data.get('contact', {})
                    registrant = contact.get('name', obj_key)
                    break

            return {
                "asn": result.get('asn'),
                "asn_cidr": result.get('asn_cidr'),
                "asn_country_code": result.get('asn_country_code'),
                "asn_description": result.get('asn_description'),
                "asn_registry": result.get('asn_registry'),
                "network_name": network.get('name'),
                "network_cidr": network.get('cidr'),
                "registrant": registrant,
                "abuse_contacts": list(set(abuse_contacts))[:3] if abuse_contacts else []
            }

        except Exception as e:
            logger.error(f"Error fetching WHOIS data for {ip_address}: {e}")
            return None

    def _fetch_cloud_provider(self, ip_address: str, geo_data: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        """
        Detect if IP belongs to a major cloud provider (AWS/Azure/GCP)

        Uses ASN information from geolocation data
        """
        try:
            asn_info = geo_data.get('asn', '').upper()
            isp_info = geo_data.get('isp', '').upper()

            # Known cloud provider ASNs and patterns
            cloud_providers = {
                'AWS': {
                    'asns': ['AS16509', 'AS14618', 'AS38895', 'AS58588'],
                    'keywords': ['AMAZON', 'AWS']
                },
                'Azure': {
                    'asns': ['AS8075', 'AS8068'],
                    'keywords': ['MICROSOFT', 'AZURE']
                },
                'GCP': {
                    'asns': ['AS15169', 'AS36384', 'AS36385', 'AS36040'],
                    'keywords': ['GOOGLE', 'GCP']
                },
                'Oracle Cloud': {
                    'asns': ['AS31898', 'AS14340'],
                    'keywords': ['ORACLE']
                },
                'DigitalOcean': {
                    'asns': ['AS14061'],
                    'keywords': ['DIGITALOCEAN']
                },
                'Alibaba Cloud': {
                    'asns': ['AS45102', 'AS37963'],
                    'keywords': ['ALIBABA', 'ALICLOUD']
                }
            }

            # Check ASN and keywords
            for provider, details in cloud_providers.items():
                # Check ASN match
                for asn in details['asns']:
                    if asn in asn_info:
                        logger.debug(f"Detected {provider} via ASN: {asn}")
                        return {
                            "provider": provider,
                            "detection_method": "asn",
                            "confidence": "high"
                        }

                # Check keyword match
                for keyword in details['keywords']:
                    if keyword in isp_info or keyword in asn_info:
                        logger.debug(f"Detected {provider} via keyword: {keyword}")
                        return {
                            "provider": provider,
                            "detection_method": "keyword",
                            "confidence": "medium"
                        }

            # No cloud provider detected
            return None

        except Exception as e:
            logger.error(f"Error detecting cloud provider for {ip_address}: {e}")
            return None

    def _fetch_passive_dns(self, ip_address: str) -> Optional[Dict[str, Any]]:
        """
        Fetch passive DNS data (historical domain resolutions) from VirusTotal

        Shows which domains have resolved to this IP address
        """
        if not self.virustotal_api_key:
            logger.debug("VirusTotal API key not configured for passive DNS")
            return None

        try:
            start_time = time.time()
            headers = {'x-apikey': self.virustotal_api_key}

            # Get resolutions from VirusTotal
            url = f"{self.virustotal_url}/{ip_address}/resolutions"
            params = {'limit': 10}  # Get last 10 resolutions

            response = requests.get(url, headers=headers, params=params, timeout=10)
            elapsed = (time.time() - start_time) * 1000

            if response.status_code == 200:
                data = response.json()
                resolutions = data.get('data', [])

                domains = []
                for resolution in resolutions:
                    attributes = resolution.get('attributes', {})
                    host_name = attributes.get('host_name')
                    last_resolved = attributes.get('date')

                    if host_name:
                        domains.append({
                            "domain": host_name,
                            "last_resolved": datetime.fromtimestamp(last_resolved).isoformat() if last_resolved else None
                        })

                logger.debug(f"Passive DNS found {len(domains)} domains for {ip_address} ({elapsed:.0f}ms)")

                return {
                    "total_domains": len(domains),
                    "domains": domains[:10]  # Limit to top 10
                }

            elif response.status_code == 404:
                # No resolutions found
                logger.debug(f"No passive DNS data found for {ip_address}")
                return {
                    "total_domains": 0,
                    "domains": []
                }

            else:
                logger.warning(f"VirusTotal passive DNS API returned status {response.status_code}")
                return None

        except Exception as e:
            logger.error(f"Error fetching passive DNS for {ip_address}: {e}")
            return None

    def _fetch_related_iocs(self, ip_address: str) -> Optional[Dict[str, Any]]:
        """
        Find related IoCs from OpenSearch/Elasticsearch

        Identifies other IPs that appear in similar alerts (same attack signatures)
        to help identify coordinated campaigns
        """
        try:
            import os
            import requests
            import urllib3
            from collections import defaultdict

            # Disable SSL warnings (matching suricata_alerts_elasticsearch.py)
            urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

            # Get Elasticsearch connection details from environment
            es_host = os.getenv('SURICATA_ES_HOST', 'localhost')
            es_port = int(os.getenv('SURICATA_ES_PORT', '9220'))
            es_username = os.getenv('SURICATA_ES_USERNAME')
            es_password = os.getenv('SURICATA_ES_PASSWORD')
            es_verify_ssl = os.getenv('SURICATA_ES_VERIFY_SSL', 'false').lower() == 'true'
            es_index = os.getenv('SURICATA_ES_INDEX_PATTERN', 'suricata-alerts-*')

            base_url = f"https://{es_host}:{es_port}"
            auth = (es_username, es_password) if es_username and es_password else None

            # Detect correct field names (handles both 'ip' type and 'keyword' fields)
            src_ip_field = self._get_opensearch_ip_field_name(
                'src_ip', es_host, es_port, es_index, es_username, es_password, es_verify_ssl
            )
            dest_ip_field = self._get_opensearch_ip_field_name(
                'dest_ip', es_host, es_port, es_index, es_username, es_password, es_verify_ssl
            )

            # Step 1: Get all alerts for the target IP from last 30 days
            target_query = {
                "query": {
                    "bool": {
                        "must": [
                            {
                                "range": {
                                    "@timestamp": {
                                        "gte": "now-30d",
                                        "lte": "now"
                                    }
                                }
                            },
                            {
                                "exists": {
                                    "field": "alert.severity"
                                }
                            }
                        ],
                        "should": [
                            {"term": {src_ip_field: ip_address}},
                            {"term": {dest_ip_field: ip_address}}
                        ],
                        "minimum_should_match": 1
                    }
                },
                "size": 100,  # Get up to 100 alerts for this IP
                "_source": ["alert.signature", "alert.signature_id"]
            }

            response = requests.post(
                f"{base_url}/{es_index}/_search",
                auth=auth,
                json=target_query,
                verify=es_verify_ssl,
                timeout=30
            )

            if response.status_code != 200:
                logger.warning(f"OpenSearch query failed for target IP {ip_address}: {response.status_code}")
                return None

            result = response.json()
            hits = result.get('hits', {}).get('hits', [])

            if not hits:
                logger.debug(f"No alerts found for IP {ip_address} in OpenSearch")
                return {
                    "total_related_ips": 0,
                    "related_ips": []
                }

            # Extract unique signatures
            signatures = set()
            for hit in hits:
                sig = hit.get('_source', {}).get('alert', {}).get('signature')
                if sig:
                    signatures.add(sig)

            if not signatures:
                logger.debug(f"No signatures found for IP {ip_address}")
                return {
                    "total_related_ips": 0,
                    "related_ips": []
                }

            signatures_list = list(signatures)[:20]  # Limit to 20 signatures
            logger.debug(f"Found {len(signatures_list)} unique signatures for {ip_address}")

            # Step 2: Find other IPs with the same signatures
            related_query = {
                "query": {
                    "bool": {
                        "must": [
                            {
                                "range": {
                                    "@timestamp": {
                                        "gte": "now-30d",
                                        "lte": "now"
                                    }
                                }
                            },
                            {
                                "exists": {
                                    "field": "alert.severity"
                                }
                            },
                            {
                                "terms": {
                                    "alert.signature.keyword": signatures_list
                                }
                            }
                        ],
                        "must_not": [
                            {"term": {src_ip_field: ip_address}},
                            {"term": {dest_ip_field: ip_address}}
                        ]
                    }
                },
                "size": 1000,  # Get up to 1000 related alerts
                "_source": ["src_ip", "dest_ip", "alert.signature", "@timestamp"]
            }

            response = requests.post(
                f"{base_url}/{es_index}/_search",
                auth=auth,
                json=related_query,
                verify=es_verify_ssl,
                timeout=30
            )

            if response.status_code != 200:
                logger.warning(f"OpenSearch query failed for related IPs: {response.status_code}")
                return None

            result = response.json()
            hits = result.get('hits', {}).get('hits', [])

            # Aggregate results by IP
            ip_stats = defaultdict(lambda: {
                'signatures': set(),
                'alert_count': 0,
                'first_seen': None,
                'last_seen': None
            })

            for hit in hits:
                source = hit.get('_source', {})
                src_ip = source.get('src_ip')
                dest_ip = source.get('dest_ip')
                signature = source.get('alert', {}).get('signature')
                timestamp = source.get('@timestamp')

                # Process both source and destination IPs
                for related_ip in [src_ip, dest_ip]:
                    if related_ip and related_ip != ip_address:
                        stats = ip_stats[related_ip]

                        if signature:
                            stats['signatures'].add(signature)

                        stats['alert_count'] += 1

                        if timestamp:
                            if stats['first_seen'] is None or timestamp < stats['first_seen']:
                                stats['first_seen'] = timestamp
                            if stats['last_seen'] is None or timestamp > stats['last_seen']:
                                stats['last_seen'] = timestamp

            # Filter and sort results
            related_ips = []
            for ip, stats in ip_stats.items():
                # Only include IPs with multiple shared alerts
                if stats['alert_count'] > 2:
                    related_ips.append({
                        'ip_address': ip,
                        'shared_signatures': len(stats['signatures']),
                        'alert_count': stats['alert_count'],
                        'first_seen': stats['first_seen'],
                        'last_seen': stats['last_seen'],
                        'signatures': list(stats['signatures'])[:5]  # Limit to 5 signatures
                    })

            # Sort by shared signatures (descending), then by alert count (descending)
            related_ips.sort(key=lambda x: (x['shared_signatures'], x['alert_count']), reverse=True)

            # Limit to top 10
            related_ips = related_ips[:10]

            logger.debug(f"Found {len(related_ips)} related IoCs for {ip_address}")

            return {
                "total_related_ips": len(related_ips),
                "related_ips": related_ips
            }

        except Exception as e:
            logger.error(f"Error fetching related IoCs for {ip_address}: {e}", exc_info=True)
            return None

    def clear_cache(self):
        """Clear the enrichment cache"""
        if self.use_redis:
            try:
                # Clear all keys matching our pattern
                cursor = 0
                pattern = "ip_enrichment:*"
                deleted_count = 0

                while True:
                    cursor, keys = self.redis_client.scan(cursor, match=pattern, count=100)
                    if keys:
                        deleted_count += self.redis_client.delete(*keys)
                    if cursor == 0:
                        break

                logger.info(f"Cleared {deleted_count} entries from Redis cache")
            except Exception as e:
                logger.error(f"Error clearing Redis cache: {e}")
        else:
            self.cache.clear()
            logger.info("IP enrichment in-memory cache cleared")

    def get_cache_stats(self) -> Dict[str, Any]:
        """Get cache statistics and performance metrics"""
        cache_size = 0
        cache_type = "in-memory"

        if self.use_redis:
            try:
                # Count keys matching our pattern
                cursor = 0
                pattern = "ip_enrichment:*"

                while True:
                    cursor, keys = self.redis_client.scan(cursor, match=pattern, count=100)
                    cache_size += len(keys)
                    if cursor == 0:
                        break

                cache_type = "redis"
            except Exception as e:
                logger.error(f"Error getting Redis stats: {e}")
        else:
            cache_size = len(self.cache)

        # Calculate cache hit rate
        total_cache_requests = self.metrics['cache_hits'] + self.metrics['cache_misses']
        cache_hit_rate = (self.metrics['cache_hits'] / total_cache_requests * 100) if total_cache_requests > 0 else 0

        return {
            "cache_type": cache_type,
            "cache_size": cache_size,
            "cache_ttl_hours": self.cache_ttl.total_seconds() / 3600,
            "api_keys_configured": {
                "abuseipdb": bool(self.abuseipdb_api_key),
                "virustotal": bool(self.virustotal_api_key),
                "otx": bool(self.otx_api_key),
                "greynoise": bool(self.greynoise_api_key)
            },
            "metrics": {
                "total_requests": self.metrics['total_requests'],
                "cache_hits": self.metrics['cache_hits'],
                "cache_misses": self.metrics['cache_misses'],
                "cache_hit_rate_percent": round(cache_hit_rate, 2),
                "api_calls": self.metrics['api_calls'],
                "errors": self.metrics['errors']
            }
        }
