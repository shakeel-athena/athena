"""
API Module

Contains all Flask blueprints for the Athena Response API.
"""

from .waf import waf_bp
from .alerts import alerts_bp
from .firewall import firewall_bp
from .health import health_bp
from .policies import policies_bp
from .dashboard import dashboard_bp
from .geo import geo_bp
from .background_modules import background_modules_bp
from .mute import mute_bp
from .nids import nids_bp

__all__ = [
    'waf_bp',
    'alerts_bp',
    'firewall_bp',
    'health_bp',
    'policies_bp',
    'dashboard_bp',
    'geo_bp',
    'background_modules_bp',
    'mute_bp',
    'nids_bp'
]
