"""
Dashboard API Module

Contains Flask blueprint for dashboard data and analytics endpoints.
"""

from .routes import dashboard_bp

__all__ = ['dashboard_bp']
