"""
Dashboard API Routes

Flask blueprint containing endpoints for dashboard data and analytics.
"""

import logging
from datetime import datetime
from flask import Blueprint, jsonify

# Create blueprint
dashboard_bp = Blueprint('dashboard', __name__, url_prefix='/api')

# Logger
logger = logging.getLogger(__name__)


def error_response(message, status_code=400):
    """Create standardized error response."""
    return jsonify({
        "success": False,
        "error": message
    }), status_code


# ============================================================================
# Dashboard Endpoints
# ============================================================================

@dashboard_bp.route('/dashboard', methods=['GET'])
def get_dashboard():
    """Return dashboard data in the exact shape the UI expects (no wrapper)."""
    try:
        now_iso = datetime.utcnow().isoformat() + "Z"
        payload = {
            "overview": {
                "last_updated": now_iso,
                "time_range": "24h",
                "total_alerts": 0,
                "actions_executed": 0,
                "average_response_time_ms": 120,
                "actions_successful": 0,
            },
            "threat_distribution": {
                "by_type": [
                    {"type": "sql_injection", "count": 0, "percentage": 0, "trend": "+0%"},
                    {"type": "xss", "count": 0, "percentage": 0, "trend": "+0%"},
                    {"type": "path_traversal", "count": 0, "percentage": 0, "trend": "+0%"},
                    {"type": "other", "count": 0, "percentage": 0, "trend": "+0%"},
                ]
            },
            "geographic_threats": {
                "coordinates": [
                    {"country": "United States", "city": "New York", "lat": 40.7128, "lng": -74.0060, "count": 0},
                    {"country": "Germany", "city": "Frankfurt", "lat": 50.1109, "lng": 8.6821, "count": 0},
                    {"country": "Singapore", "city": "Singapore", "lat": 1.3521, "lng": 103.8198, "count": 0},
                ]
            },
            "response_actions": {
                "by_action_type": [
                    {"provider": "waf", "action": "block_ip", "count": 0, "avg_time_ms": 0, "success_rate": 100},
                    {"provider": "waf", "action": "challenge", "count": 0, "avg_time_ms": 0, "success_rate": 100},
                    {"provider": "firewall", "action": "rate_limit_subnet", "count": 0, "avg_time_ms": 0, "success_rate": 100},
                ]
            },
            "time_series": {
                "alerts": [],
                "actions": []
            }
        }
        return jsonify(payload), 200
    except Exception as e:
        return error_response(f"Failed to get dashboard: {str(e)}", 500)
