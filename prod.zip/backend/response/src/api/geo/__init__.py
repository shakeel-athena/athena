"""
Geo-restrictions API Module

Contains Flask blueprint for geographic IP blocking management endpoints.
"""

from .routes import geo_bp

__all__ = ['geo_bp']
