"""
Geo-restrictions API Routes

Flask blueprint containing endpoints for geographic IP blocking management.
"""

import logging
from flask import Blueprint, request, jsonify

# Create blueprint
geo_bp = Blueprint('geo', __name__, url_prefix='/api/geo-restrictions')

# Logger
logger = logging.getLogger(__name__)


def success_response(data, message="Success"):
    """Create standardized success response."""
    return jsonify({
        "success": True,
        "message": message,
        "data": data
    }), 200


def error_response(message, status_code=400):
    """Create standardized error response."""
    return jsonify({
        "success": False,
        "error": message
    }), status_code


def get_geo_manager():
    """Get NetworkFirewallGeoBlockingManager instance (cached)."""
    from core.aws_config import get_geo_manager
    return get_geo_manager()


# ============================================================================
# Geo-restrictions Management Endpoints
# ============================================================================

@geo_bp.route('/countries', methods=['GET'])
def get_geo_countries():
    """Get current allowed countries."""
    try:
        geo_manager = get_geo_manager()
        if geo_manager is None:
            return error_response("Geo-restrictions manager not available", 500)

        countries = geo_manager.get_current_countries()
        return success_response(countries, "Countries retrieved successfully")
    except Exception as e:
        return error_response(f"Failed to get countries: {str(e)}", 500)


@geo_bp.route('/countries', methods=['POST'])
def add_geo_countries():
    """Add countries to the allowed list."""
    try:
        data = request.get_json()
        if not data or 'countries' not in data:
            return error_response("Countries list is required", 400)

        countries = data['countries']
        if isinstance(countries, str):
            countries = [c.strip() for c in countries.split(',') if c.strip()]

        geo_manager = get_geo_manager()
        if geo_manager is None:
            return error_response("Geo-restrictions manager not available", 500)

        result = geo_manager.add_countries(countries)
        return success_response(result, f"Added {len(countries)} countries")
    except Exception as e:
        return error_response(f"Failed to add countries: {str(e)}", 500)


@geo_bp.route('/countries', methods=['DELETE'])
def remove_geo_countries():
    """Remove countries from the allowed list."""
    try:
        data = request.get_json()
        if not data or 'countries' not in data:
            return error_response("Countries list is required", 400)

        countries = data['countries']
        if isinstance(countries, str):
            countries = [c.strip() for c in countries.split(',') if c.strip()]

        geo_manager = get_geo_manager()
        if geo_manager is None:
            return error_response("Geo-restrictions manager not available", 500)

        result = geo_manager.remove_countries(countries)
        return success_response(result, f"Removed {len(countries)} countries")
    except Exception as e:
        return error_response(f"Failed to remove countries: {str(e)}", 500)


@geo_bp.route('/countries', methods=['PUT'])
def set_geo_countries():
    """Set the complete list of allowed countries."""
    try:
        data = request.get_json()
        if not data or 'countries' not in data:
            return error_response("Countries list is required", 400)

        countries = data['countries']
        if isinstance(countries, str):
            countries = [c.strip() for c in countries.split(',') if c.strip()]

        geo_manager = get_geo_manager()
        if geo_manager is None:
            return error_response("Geo-restrictions manager not available", 500)

        result = geo_manager.set_countries(countries)
        return success_response(result, f"Set {len(countries)} countries")
    except Exception as e:
        return error_response(f"Failed to set countries: {str(e)}", 500)


@geo_bp.route('/validate', methods=['POST'])
def validate_geo_countries():
    """Validate country codes."""
    try:
        data = request.get_json()
        if not data or 'countries' not in data:
            return error_response("Countries list is required", 400)

        countries = data['countries']
        if isinstance(countries, str):
            countries = [c.strip() for c in countries.split(',') if c.strip()]

        geo_manager = get_geo_manager()
        if geo_manager is None:
            return error_response("Geo-restrictions manager not available", 500)

        result = geo_manager.validate_country_codes(countries)
        return success_response(result, "Countries validated")
    except Exception as e:
        return error_response(f"Failed to validate countries: {str(e)}", 500)
