"""
WAF API Blueprint

Provides REST API endpoints for Web Application Firewall management.
"""

from .routes import waf_bp

__all__ = ['waf_bp']
