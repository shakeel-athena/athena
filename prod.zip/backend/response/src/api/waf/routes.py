"""
WAF API Routes

Flask blueprint containing all WAF-related API endpoints.
All endpoints require authentication and appropriate role permissions.
"""

from flask import Blueprint, request, jsonify
import logging

from services.waf import WAFService
from services.aws import AWSService
from errors.error_types import ValidationError, ServiceError
from middleware.auth import require_auth
from utils.rbac import require_page_access, require_edit_access

# Create blueprint
waf_bp = Blueprint('waf', __name__, url_prefix='/api')

# Logger
logger = logging.getLogger(__name__)

# Service instances (will be initialized when needed)
_waf_service = None
_aws_service = None


def get_aws_service() -> AWSService:
    """Get or create AWS service instance."""
    global _aws_service
    if _aws_service is None:
        import os

        # Get AWS region from environment
        aws_region = os.getenv("AWS_REGION", "us-east-2")

        # Initialize AWS service
        _aws_service = AWSService(region=aws_region)
        _aws_service.initialize_sync()

        logger.info(f"Created and initialized AWS service for region: {aws_region}")

    return _aws_service


def get_waf_service() -> WAFService:
    """Get or create WAF service instance."""
    global _waf_service
    if _waf_service is None:
        # Get AWS service
        aws_service = get_aws_service()
        
        # Initialize WAF service with AWS service
        _waf_service = WAFService(aws_service=aws_service)
        
        logger.info("Created WAF service with AWS service integration")

    return _waf_service


def success_response(data, message="Success"):
    """Create standardized success response."""
    return jsonify({
        "success": True,
        "message": message,
        "data": data
    }), 200


def error_response(message, status_code=500):
    """Create standardized error response."""
    return jsonify({
        "success": False,
        "error": message
    }), status_code


# ============================================================================
# Signature Management Endpoints
# ============================================================================

@waf_bp.route('/waf-signatures/available', methods=['GET'])
@require_auth
@require_page_access('/waf-signatures')
def get_available_signatures():
    """Get all available WAF signatures (custom and AWS managed)."""
    try:
        service = get_waf_service()
        signatures = service.get_available_signatures()
        return success_response(signatures, "Available signatures retrieved")
    except Exception as e:
        logger.error(f"Failed to get available signatures: {e}")
        return error_response(f"Failed to get available signatures: {str(e)}", 500)


@waf_bp.route('/waf-signatures/custom', methods=['GET'])
@require_auth
@require_page_access('/waf-signatures')
def get_custom_signatures():
    """Get only custom WAF signatures."""
    try:
        service = get_waf_service()
        custom = service.get_custom_signatures()
        return success_response(custom, "Custom signatures retrieved")
    except Exception as e:
        logger.error(f"Failed to get custom signatures: {e}")
        return error_response(f"Failed to get custom signatures: {str(e)}", 500)


@waf_bp.route('/waf-signatures/aws-managed', methods=['GET'])
@require_auth
@require_page_access('/waf-signatures')
def get_aws_managed_signatures():
    """Get only AWS managed WAF signatures."""
    try:
        service = get_waf_service()
        managed = service.get_aws_managed_signatures()
        return success_response(managed, "AWS managed signatures retrieved")
    except Exception as e:
        logger.error(f"Failed to get AWS managed signatures: {e}")
        return error_response(f"Failed to get AWS managed signatures: {str(e)}", 500)


@waf_bp.route('/waf-signatures/status', methods=['GET'])
@require_auth
@require_page_access('/waf-signatures')
def get_signature_status():
    """Get the status of all WAF signatures (active/inactive)."""
    try:
        service = get_waf_service()
        status = service.get_signature_status()

        if not status:
            return success_response({}, "Web ACL not configured. Set WAF_WEB_ACL, AWS_REGION, and AWS_SCOPE.")

        return success_response(status, "Signature status retrieved")
    except Exception as e:
        logger.error(f"Failed to get signature status: {e}")
        return error_response(f"Failed to get signature status: {str(e)}", 500)


@waf_bp.route('/waf-signatures/active', methods=['GET'])
@require_auth
@require_page_access('/waf-signatures')
def get_active_signatures():
    """Get currently active WAF signatures."""
    try:
        service = get_waf_service()
        active_signatures = service.get_active_signatures()

        if not active_signatures:
            return success_response([], "Web ACL not configured. Set WAF_WEB_ACL, AWS_REGION, and AWS_SCOPE.")

        return success_response(active_signatures, "Active signatures retrieved")
    except Exception as e:
        logger.error(f"Failed to get active signatures: {e}")
        return error_response(f"Failed to get active signatures: {str(e)}", 500)


@waf_bp.route('/waf-signatures/add', methods=['POST'])
@require_auth
@require_edit_access('/waf-signatures')
def add_signature():
    """Add a WAF signature to the Web ACL."""
    try:
        data = request.get_json()
        if not data or 'signature_id' not in data:
            return error_response("signature_id is required", 400)

        service = get_waf_service()
        success = service.add_signature(data['signature_id'])

        if success:
            return success_response({"signature_id": data['signature_id']}, "Signature added successfully")
        else:
            return success_response({"signature_id": data['signature_id']}, "Signature already exists")
    except ValidationError as e:
        return error_response(str(e), 400)
    except Exception as e:
        logger.error(f"Failed to add signature: {e}")
        return error_response(f"Failed to add signature: {str(e)}", 500)


@waf_bp.route('/waf-signatures/remove', methods=['POST'])
@require_auth
@require_edit_access('/waf-signatures')
def remove_signature():
    """Remove a WAF signature from the Web ACL."""
    try:
        data = request.get_json()
        if not data or 'signature_id' not in data:
            return error_response("signature_id is required", 400)

        service = get_waf_service()
        success = service.remove_signature(data['signature_id'])

        return success_response({"signature_id": data['signature_id']}, "Signature removed successfully")
    except ValidationError as e:
        return error_response(str(e), 400)
    except Exception as e:
        logger.error(f"Failed to remove signature: {e}")
        return error_response(f"Failed to remove signature: {str(e)}", 500)


@waf_bp.route('/waf-signatures/toggle', methods=['POST'])
@require_auth
@require_edit_access('/waf-signatures')
def toggle_signature():
    """Toggle a WAF signature on/off."""
    try:
        data = request.get_json()
        if not data or 'signature_id' not in data:
            return error_response("signature_id is required", 400)
        if 'enabled' not in data:
            return error_response("enabled is required", 400)

        service = get_waf_service()
        success = service.toggle_signature(data['signature_id'], data['enabled'])

        action = "enabled" if data['enabled'] else "disabled"
        return success_response(
            {"signature_id": data['signature_id'], "enabled": data['enabled']},
            f"Signature {action} successfully"
        )
    except ValidationError as e:
        return error_response(str(e), 400)
    except Exception as e:
        logger.error(f"Failed to toggle signature: {e}")
        return error_response(f"Failed to toggle signature: {str(e)}", 500)


@waf_bp.route('/waf-signatures/add-multiple', methods=['POST'])
@require_auth
@require_edit_access('/waf-signatures')
def add_multiple_signatures():
    """Add multiple WAF signatures at once."""
    try:
        data = request.get_json()
        if not data or 'signature_ids' not in data:
            return error_response("signature_ids is required", 400)

        service = get_waf_service()
        results = service.add_multiple_signatures(data['signature_ids'])

        return success_response(results, "Multiple signatures processed")
    except ValidationError as e:
        return error_response(str(e), 400)
    except Exception as e:
        logger.error(f"Failed to add multiple signatures: {e}")
        return error_response(f"Failed to add multiple signatures: {str(e)}", 500)


@waf_bp.route('/waf-signatures/remove-multiple', methods=['POST'])
@require_auth
@require_edit_access('/waf-signatures')
def remove_multiple_signatures():
    """Remove multiple WAF signatures at once."""
    try:
        data = request.get_json()
        if not data or 'signature_ids' not in data:
            return error_response("signature_ids is required", 400)

        service = get_waf_service()
        results = service.remove_multiple_signatures(data['signature_ids'])

        return success_response(results, "Multiple signatures removed")
    except ValidationError as e:
        return error_response(str(e), 400)
    except Exception as e:
        logger.error(f"Failed to remove multiple signatures: {e}")
        return error_response(f"Failed to remove multiple signatures: {str(e)}", 500)


@waf_bp.route('/waf-signatures/add-all', methods=['POST'])
@require_auth
@require_edit_access('/waf-signatures')
def add_all_signatures():
    """Add all available signatures to the Web ACL."""
    try:
        service = get_waf_service()
        results = service.add_all_signatures()

        return success_response(results, "All signatures added")
    except Exception as e:
        logger.error(f"Failed to add all signatures: {e}")
        return error_response(f"Failed to add all signatures: {str(e)}", 500)


@waf_bp.route('/waf-signatures/remove-all', methods=['POST'])
@require_auth
@require_edit_access('/waf-signatures')
def remove_all_signatures():
    """Remove all signatures from the Web ACL."""
    try:
        service = get_waf_service()
        results = service.remove_all_signatures()

        return success_response(results, "All signatures removed")
    except Exception as e:
        logger.error(f"Failed to remove all signatures: {e}")
        return error_response(f"Failed to remove all signatures: {str(e)}", 500)


# ============================================================================
# Configuration Endpoints
# ============================================================================

@waf_bp.route('/waf/configuration', methods=['GET'])
@require_auth
@require_page_access('/waf-signatures')
def get_waf_configuration():
    """Get current WAF configuration."""
    try:
        service = get_waf_service()
        config = service.get_waf_configuration()

        return success_response(config, "WAF configuration retrieved")
    except Exception as e:
        logger.error(f"Failed to get WAF configuration: {e}")
        return error_response(f"Failed to get WAF configuration: {str(e)}", 500)


# ============================================================================
# Geo-Restriction Endpoints
# ============================================================================

@waf_bp.route('/waf-geo-restrictions/countries', methods=['GET'])
@require_auth
@require_page_access('/waf-signatures')
def get_geo_restrictions():
    """Get list of geo-restricted countries."""
    try:
        service = get_waf_service()
        countries = service.get_geo_restrictions()

        return success_response(countries, "Geo restrictions retrieved")
    except Exception as e:
        logger.error(f"Failed to get geo restrictions: {e}")
        return error_response(f"Failed to get geo restrictions: {str(e)}", 500)


@waf_bp.route('/waf-geo-restrictions/countries', methods=['POST'])
@require_auth
@require_edit_access('/waf-signatures')
def update_geo_restrictions():
    """Update geo-restriction list (allowed countries)."""
    try:
        data = request.get_json()
        # Accept either allowed_countries (frontend) or country_codes (backward compat)
        country_codes = data.get('allowed_countries') or data.get('country_codes')
        if not data or not country_codes:
            return error_response("allowed_countries is required", 400)

        service = get_waf_service()
        success = service.update_geo_restrictions(country_codes)

        return success_response(
            {"allowed_countries": country_codes},
            "Geo restrictions updated successfully"
        )
    except ValidationError as e:
        return error_response(str(e), 400)
    except Exception as e:
        logger.error(f"Failed to update geo restrictions: {e}")
        return error_response(f"Failed to update geo restrictions: {str(e)}", 500)


# ============================================================================
# IP Reputation Endpoints
# ============================================================================

@waf_bp.route('/waf-ip-reputation/rules', methods=['GET'])
@require_auth
@require_page_access('/waf-signatures')
def get_ip_reputation_rules():
    """Get IP reputation rules configuration."""
    try:
        service = get_waf_service()
        rules = service.get_ip_reputation_rules()

        return success_response(rules, "IP reputation rules retrieved")
    except Exception as e:
        logger.error(f"Failed to get IP reputation rules: {e}")
        return error_response(f"Failed to get IP reputation rules: {str(e)}", 500)


@waf_bp.route('/waf-ip-reputation/rules/<rule_name>/action', methods=['PUT'])
@require_auth
@require_edit_access('/waf-signatures')
def update_ip_reputation_action(rule_name):
    """Update action for an IP reputation rule."""
    try:
        data = request.get_json()
        if not data or 'action' not in data:
            return error_response("action is required", 400)

        service = get_waf_service()
        success = service.update_ip_reputation_action(rule_name, data['action'])

        return success_response(
            {"rule_name": rule_name, "action": data['action']},
            "IP reputation rule action updated"
        )
    except ValidationError as e:
        return error_response(str(e), 400)
    except Exception as e:
        logger.error(f"Failed to update IP reputation action: {e}")
        return error_response(f"Failed to update IP reputation action: {str(e)}", 500)


@waf_bp.route('/waf-ip-reputation/rules/<rule_name>/reset', methods=['POST'])
@require_auth
@require_edit_access('/waf-signatures')
def reset_ip_reputation_rule(rule_name):
    """Reset an IP reputation rule to default settings."""
    try:
        service = get_waf_service()
        success = service.reset_ip_reputation_rule(rule_name)

        return success_response(
            {"rule_name": rule_name},
            "IP reputation rule reset to defaults"
        )
    except ValidationError as e:
        return error_response(str(e), 400)
    except Exception as e:
        logger.error(f"Failed to reset IP reputation rule: {e}")
        return error_response(f"Failed to reset IP reputation rule: {str(e)}", 500)


@waf_bp.route('/waf-ip-reputation/rules/<rule_name>/allow-list', methods=['POST'])
@require_auth
@require_edit_access('/waf-signatures')
def add_to_ip_reputation_allowlist(rule_name):
    """Add IP address to reputation rule allowlist."""
    try:
        data = request.get_json()
        if not data or 'ip_address' not in data:
            return error_response("ip_address is required", 400)

        service = get_waf_service()
        success = service.add_to_ip_reputation_allowlist(rule_name, data['ip_address'])

        return success_response(
            {"rule_name": rule_name, "ip_address": data['ip_address']},
            "IP address added to allowlist"
        )
    except ValidationError as e:
        return error_response(str(e), 400)
    except Exception as e:
        logger.error(f"Failed to add IP to allowlist: {e}")
        return error_response(f"Failed to add IP to allowlist: {str(e)}", 500)


# ============================================================================
# Anonymous IP Endpoints
# ============================================================================

@waf_bp.route('/waf-anonymous-ip/rules', methods=['GET'])
@require_auth
@require_page_access('/waf-signatures')
def get_anonymous_ip_rules():
    """Get Anonymous IP rules configuration."""
    try:
        service = get_waf_service()
        rules = service.get_rule_group_rules('anonymous-ip')
        return success_response(rules, "Anonymous IP rules retrieved")
    except Exception as e:
        logger.error(f"Failed to get Anonymous IP rules: {e}")
        return error_response(f"Failed to get Anonymous IP rules: {str(e)}", 500)


@waf_bp.route('/waf-anonymous-ip/rules/<rule_name>/action', methods=['PUT'])
@require_auth
@require_edit_access('/waf-signatures')
def update_anonymous_ip_action(rule_name):
    """Update action for an Anonymous IP rule."""
    try:
        data = request.get_json()
        if not data or 'action' not in data:
            return error_response("action is required", 400)

        service = get_waf_service()
        service._initialize_managers()
        result = service._anonymous_ip_manager.update_rule_action(
            service._web_acl_name, rule_name, data['action']
        )
        return success_response(result, "Anonymous IP rule action updated")
    except ValidationError as e:
        return error_response(str(e), 400)
    except Exception as e:
        logger.error(f"Failed to update Anonymous IP action: {e}")
        return error_response(f"Failed to update Anonymous IP action: {str(e)}", 500)


@waf_bp.route('/waf-anonymous-ip/rules/<rule_name>/reset', methods=['POST'])
@require_auth
@require_edit_access('/waf-signatures')
def reset_anonymous_ip_rule(rule_name):
    """Reset an Anonymous IP rule to default settings."""
    try:
        service = get_waf_service()
        service._initialize_managers()
        result = service._anonymous_ip_manager.reset_rule_to_default(
            service._web_acl_name, rule_name
        )
        return success_response(result, "Anonymous IP rule reset to defaults")
    except ValidationError as e:
        return error_response(str(e), 400)
    except Exception as e:
        logger.error(f"Failed to reset Anonymous IP rule: {e}")
        return error_response(f"Failed to reset Anonymous IP rule: {str(e)}", 500)


@waf_bp.route('/waf-anonymous-ip/rules/<rule_name>/allow-list', methods=['POST'])
@require_auth
@require_edit_access('/waf-signatures')
def add_anonymous_ip_allowlist(rule_name):
    """Add to Anonymous IP rule allowlist."""
    try:
        data = request.get_json()
        ip_list = data.get('ipList', [])
        domain_list = data.get('domainList', [])

        service = get_waf_service()
        service._initialize_managers()
        result = service._anonymous_ip_manager.create_allow_list_rule(
            service._web_acl_name, rule_name, ip_list, domain_list
        )
        return success_response(result, "Anonymous IP allowlist updated")
    except ValidationError as e:
        return error_response(str(e), 400)
    except Exception as e:
        logger.error(f"Failed to update Anonymous IP allowlist: {e}")
        return error_response(f"Failed to update Anonymous IP allowlist: {str(e)}", 500)


# ============================================================================
# Common Attack Endpoints
# ============================================================================

@waf_bp.route('/waf-common-attack/rules', methods=['GET'])
@require_auth
@require_page_access('/waf-signatures')
def get_common_attack_rules():
    """Get Common Attack rules configuration."""
    try:
        service = get_waf_service()
        rules = service.get_rule_group_rules('common-attack')
        return success_response(rules, "Common Attack rules retrieved")
    except Exception as e:
        logger.error(f"Failed to get Common Attack rules: {e}")
        return error_response(f"Failed to get Common Attack rules: {str(e)}", 500)


@waf_bp.route('/waf-common-attack/rules/<rule_name>/action', methods=['PUT'])
@require_auth
@require_edit_access('/waf-signatures')
def update_common_attack_action(rule_name):
    """Update action for a Common Attack rule."""
    try:
        data = request.get_json()
        if not data or 'action' not in data:
            return error_response("action is required", 400)

        service = get_waf_service()
        service._initialize_managers()
        result = service._common_attack_manager.update_rule_action(
            service._web_acl_name, rule_name, data['action']
        )
        return success_response(result, "Common Attack rule action updated")
    except ValidationError as e:
        return error_response(str(e), 400)
    except Exception as e:
        logger.error(f"Failed to update Common Attack action: {e}")
        return error_response(f"Failed to update Common Attack action: {str(e)}", 500)


@waf_bp.route('/waf-common-attack/rules/<rule_name>/reset', methods=['POST'])
@require_auth
@require_edit_access('/waf-signatures')
def reset_common_attack_rule(rule_name):
    """Reset a Common Attack rule to default settings."""
    try:
        service = get_waf_service()
        service._initialize_managers()
        result = service._common_attack_manager.reset_rule_to_default(
            service._web_acl_name, rule_name
        )
        return success_response(result, "Common Attack rule reset to defaults")
    except ValidationError as e:
        return error_response(str(e), 400)
    except Exception as e:
        logger.error(f"Failed to reset Common Attack rule: {e}")
        return error_response(f"Failed to reset Common Attack rule: {str(e)}", 500)


@waf_bp.route('/waf-common-attack/rules/<rule_name>/allow-list', methods=['POST'])
@require_auth
@require_edit_access('/waf-signatures')
def add_common_attack_allowlist(rule_name):
    """Add to Common Attack rule allowlist."""
    try:
        data = request.get_json()
        ip_list = data.get('ipList', [])
        domain_list = data.get('domainList', [])

        service = get_waf_service()
        service._initialize_managers()
        result = service._common_attack_manager.create_allow_list_rule(
            service._web_acl_name, rule_name, ip_list, domain_list
        )
        return success_response(result, "Common Attack allowlist updated")
    except ValidationError as e:
        return error_response(str(e), 400)
    except Exception as e:
        logger.error(f"Failed to update Common Attack allowlist: {e}")
        return error_response(f"Failed to update Common Attack allowlist: {str(e)}", 500)


# ============================================================================
# Linux Vulnerability Endpoints
# ============================================================================

@waf_bp.route('/waf-linux-vuln/rules', methods=['GET'])
@require_auth
@require_page_access('/waf-signatures')
def get_linux_vuln_rules():
    """Get Linux Vulnerability rules configuration."""
    try:
        service = get_waf_service()
        rules = service.get_rule_group_rules('linux-vuln')
        return success_response(rules, "Linux Vulnerability rules retrieved")
    except Exception as e:
        logger.error(f"Failed to get Linux Vulnerability rules: {e}")
        return error_response(f"Failed to get Linux Vulnerability rules: {str(e)}", 500)


@waf_bp.route('/waf-linux-vuln/rules/<rule_name>/action', methods=['PUT'])
@require_auth
@require_edit_access('/waf-signatures')
def update_linux_vuln_action(rule_name):
    """Update action for a Linux Vulnerability rule."""
    try:
        data = request.get_json()
        if not data or 'action' not in data:
            return error_response("action is required", 400)

        service = get_waf_service()
        service._initialize_managers()
        result = service._linux_vuln_manager.update_rule_action(
            service._web_acl_name, rule_name, data['action']
        )
        return success_response(result, "Linux Vulnerability rule action updated")
    except ValidationError as e:
        return error_response(str(e), 400)
    except Exception as e:
        logger.error(f"Failed to update Linux Vulnerability action: {e}")
        return error_response(f"Failed to update Linux Vulnerability action: {str(e)}", 500)


@waf_bp.route('/waf-linux-vuln/rules/<rule_name>/reset', methods=['POST'])
@require_auth
@require_edit_access('/waf-signatures')
def reset_linux_vuln_rule(rule_name):
    """Reset a Linux Vulnerability rule to default settings."""
    try:
        service = get_waf_service()
        service._initialize_managers()
        result = service._linux_vuln_manager.reset_rule_to_default(
            service._web_acl_name, rule_name
        )
        return success_response(result, "Linux Vulnerability rule reset to defaults")
    except ValidationError as e:
        return error_response(str(e), 400)
    except Exception as e:
        logger.error(f"Failed to reset Linux Vulnerability rule: {e}")
        return error_response(f"Failed to reset Linux Vulnerability rule: {str(e)}", 500)


@waf_bp.route('/waf-linux-vuln/rules/<rule_name>/allow-list', methods=['POST'])
@require_auth
@require_edit_access('/waf-signatures')
def add_linux_vuln_allowlist(rule_name):
    """Add to Linux Vulnerability rule allowlist."""
    try:
        data = request.get_json()
        ip_list = data.get('ipList', [])
        domain_list = data.get('domainList', [])

        service = get_waf_service()
        service._initialize_managers()
        result = service._linux_vuln_manager.create_allow_list_rule(
            service._web_acl_name, rule_name, ip_list, domain_list
        )
        return success_response(result, "Linux Vulnerability allowlist updated")
    except ValidationError as e:
        return error_response(str(e), 400)
    except Exception as e:
        logger.error(f"Failed to update Linux Vulnerability allowlist: {e}")
        return error_response(f"Failed to update Linux Vulnerability allowlist: {str(e)}", 500)


# ============================================================================
# Unix Vulnerability Endpoints
# ============================================================================

@waf_bp.route('/waf-unix-vuln/rules', methods=['GET'])
@require_auth
@require_page_access('/waf-signatures')
def get_unix_vuln_rules():
    """Get Unix Vulnerability rules configuration."""
    try:
        service = get_waf_service()
        rules = service.get_rule_group_rules('unix-vuln')
        return success_response(rules, "Unix Vulnerability rules retrieved")
    except Exception as e:
        logger.error(f"Failed to get Unix Vulnerability rules: {e}")
        return error_response(f"Failed to get Unix Vulnerability rules: {str(e)}", 500)


@waf_bp.route('/waf-unix-vuln/rules/<rule_name>/action', methods=['PUT'])
@require_auth
@require_edit_access('/waf-signatures')
def update_unix_vuln_action(rule_name):
    """Update action for a Unix Vulnerability rule."""
    try:
        data = request.get_json()
        if not data or 'action' not in data:
            return error_response("action is required", 400)

        service = get_waf_service()
        service._initialize_managers()
        result = service._unix_vuln_manager.update_rule_action(
            service._web_acl_name, rule_name, data['action']
        )
        return success_response(result, "Unix Vulnerability rule action updated")
    except ValidationError as e:
        return error_response(str(e), 400)
    except Exception as e:
        logger.error(f"Failed to update Unix Vulnerability action: {e}")
        return error_response(f"Failed to update Unix Vulnerability action: {str(e)}", 500)


@waf_bp.route('/waf-unix-vuln/rules/<rule_name>/reset', methods=['POST'])
@require_auth
@require_edit_access('/waf-signatures')
def reset_unix_vuln_rule(rule_name):
    """Reset a Unix Vulnerability rule to default settings."""
    try:
        service = get_waf_service()
        service._initialize_managers()
        result = service._unix_vuln_manager.reset_rule_to_default(
            service._web_acl_name, rule_name
        )
        return success_response(result, "Unix Vulnerability rule reset to defaults")
    except ValidationError as e:
        return error_response(str(e), 400)
    except Exception as e:
        logger.error(f"Failed to reset Unix Vulnerability rule: {e}")
        return error_response(f"Failed to reset Unix Vulnerability rule: {str(e)}", 500)


@waf_bp.route('/waf-unix-vuln/rules/<rule_name>/allow-list', methods=['POST'])
@require_auth
@require_edit_access('/waf-signatures')
def add_unix_vuln_allowlist(rule_name):
    """Add to Unix Vulnerability rule allowlist."""
    try:
        data = request.get_json()
        ip_list = data.get('ipList', [])
        domain_list = data.get('domainList', [])

        service = get_waf_service()
        service._initialize_managers()
        result = service._unix_vuln_manager.create_allow_list_rule(
            service._web_acl_name, rule_name, ip_list, domain_list
        )
        return success_response(result, "Unix Vulnerability allowlist updated")
    except ValidationError as e:
        return error_response(str(e), 400)
    except Exception as e:
        logger.error(f"Failed to update Unix Vulnerability allowlist: {e}")
        return error_response(f"Failed to update Unix Vulnerability allowlist: {str(e)}", 500)


# ============================================================================
# Known Bad Inputs Endpoints
# ============================================================================

@waf_bp.route('/waf-known-bad-inputs/rules', methods=['GET'])
@require_auth
@require_page_access('/waf-signatures')
def get_known_bad_inputs_rules():
    """Get Known Bad Inputs rules configuration."""
    try:
        service = get_waf_service()
        rules = service.get_rule_group_rules('known-bad-inputs')
        return success_response(rules, "Known Bad Inputs rules retrieved")
    except Exception as e:
        logger.error(f"Failed to get Known Bad Inputs rules: {e}")
        return error_response(f"Failed to get Known Bad Inputs rules: {str(e)}", 500)


@waf_bp.route('/waf-known-bad-inputs/rules/<rule_name>/action', methods=['PUT'])
@require_auth
@require_edit_access('/waf-signatures')
def update_known_bad_inputs_action(rule_name):
    """Update action for a Known Bad Inputs rule."""
    try:
        data = request.get_json()
        if not data or 'action' not in data:
            return error_response("action is required", 400)

        service = get_waf_service()
        service._initialize_managers()
        result = service._known_bad_inputs_manager.update_rule_action(
            service._web_acl_name, rule_name, data['action']
        )
        return success_response(result, "Known Bad Inputs rule action updated")
    except ValidationError as e:
        return error_response(str(e), 400)
    except Exception as e:
        logger.error(f"Failed to update Known Bad Inputs action: {e}")
        return error_response(f"Failed to update Known Bad Inputs action: {str(e)}", 500)


@waf_bp.route('/waf-known-bad-inputs/rules/<rule_name>/reset', methods=['POST'])
@require_auth
@require_edit_access('/waf-signatures')
def reset_known_bad_inputs_rule(rule_name):
    """Reset a Known Bad Inputs rule to default settings."""
    try:
        service = get_waf_service()
        service._initialize_managers()
        result = service._known_bad_inputs_manager.reset_rule_to_default(
            service._web_acl_name, rule_name
        )
        return success_response(result, "Known Bad Inputs rule reset to defaults")
    except ValidationError as e:
        return error_response(str(e), 400)
    except Exception as e:
        logger.error(f"Failed to reset Known Bad Inputs rule: {e}")
        return error_response(f"Failed to reset Known Bad Inputs rule: {str(e)}", 500)


@waf_bp.route('/waf-known-bad-inputs/rules/<rule_name>/allow-list', methods=['POST'])
@require_auth
@require_edit_access('/waf-signatures')
def add_known_bad_inputs_allowlist(rule_name):
    """Add to Known Bad Inputs rule allowlist."""
    try:
        data = request.get_json()
        ip_list = data.get('ipList', [])
        domain_list = data.get('domainList', [])

        service = get_waf_service()
        service._initialize_managers()
        result = service._known_bad_inputs_manager.create_allow_list_rule(
            service._web_acl_name, rule_name, ip_list, domain_list
        )
        return success_response(result, "Known Bad Inputs allowlist updated")
    except ValidationError as e:
        return error_response(str(e), 400)
    except Exception as e:
        logger.error(f"Failed to update Known Bad Inputs allowlist: {e}")
        return error_response(f"Failed to update Known Bad Inputs allowlist: {str(e)}", 500)


# ============================================================================
# Rule Group Management Endpoints (Generic)
# ============================================================================

@waf_bp.route('/waf-rule-groups/<group_type>/rules', methods=['GET'])
@require_auth
@require_page_access('/waf-signatures')
def get_rule_group_rules(group_type):
    """Get rules for a specific managed rule group."""
    try:
        service = get_waf_service()
        rules = service.get_rule_group_rules(group_type)

        return success_response(rules, f"{group_type} rule group rules retrieved")
    except ValidationError as e:
        return error_response(str(e), 400)
    except Exception as e:
        logger.error(f"Failed to get rule group rules: {e}")
        return error_response(f"Failed to get rule group rules: {str(e)}", 500)


@waf_bp.route('/waf-rule-groups/<group_type>/rules/<rule_name>/toggle', methods=['POST'])
@require_auth
@require_edit_access('/waf-signatures')
def toggle_rule_group_rule(group_type, rule_name):
    """Toggle a specific rule in a managed rule group."""
    try:
        data = request.get_json()
        if not data or 'enabled' not in data:
            return error_response("enabled is required", 400)

        service = get_waf_service()
        success = service.toggle_rule_group_rule(group_type, rule_name, data['enabled'])

        action = "enabled" if data['enabled'] else "disabled"
        return success_response(
            {"group_type": group_type, "rule_name": rule_name, "enabled": data['enabled']},
            f"Rule {action} successfully"
        )
    except ValidationError as e:
        return error_response(str(e), 400)
    except Exception as e:
        logger.error(f"Failed to toggle rule: {e}")
        return error_response(f"Failed to toggle rule: {str(e)}", 500)


# ============================================================================
# WAF IP Sets Management Endpoints (NEW)
# ============================================================================

@waf_bp.route('/waf/ip-sets', methods=['GET'])
@require_auth
@require_page_access('/waf-signatures')
def list_waf_ip_sets():
    """
    List all WAF IP sets with their details.

    Query Parameters:
    - scope: REGIONAL or CLOUDFRONT (default: REGIONAL)

    Response:
    {
        "success": true,
        "message": "Retrieved N IP sets",
        "data": [
            {
                "name": "Blocked",
                "id": "abc123",
                "arn": "arn:aws:wafv2:...",
                "description": "Blocked IPs",
                "ip_count": 10,
                "ip_address_version": "IPV4"
            }
        ]
    }
    """
    try:
        import os
        scope = request.args.get('scope', os.getenv('AWS_SCOPE', 'REGIONAL'))

        # Import WAF functions
        import sys
        from pathlib import Path
        backend_response_path = Path(__file__).resolve().parent.parent.parent.parent
        if str(backend_response_path) not in sys.path:
            sys.path.insert(0, str(backend_response_path))

        from actions.WAF import list_ip_sets

        ip_sets = list_ip_sets(scope=scope)

        return success_response(
            ip_sets,
            f"Retrieved {len(ip_sets)} IP sets"
        )
    except Exception as e:
        logger.error(f"Failed to list WAF IP sets: {e}", exc_info=True)
        return error_response(f"Failed to list IP sets: {str(e)}", 500)


@waf_bp.route('/waf/ip-sets/<ip_set_name>', methods=['GET'])
@require_auth
@require_page_access('/waf-signatures')
def get_waf_ip_set(ip_set_name):
    """
    Get all IPs in a specific WAF IP set.

    Path Parameters:
    - ip_set_name: Name of the IP set (e.g., "Blocked")

    Query Parameters:
    - scope: REGIONAL or CLOUDFRONT (default: REGIONAL)
    - page: Page number for pagination (default: 1)
    - per_page: IPs per page (default: 100, max: 500)

    Response:
    {
        "success": true,
        "message": "Retrieved 10 IPs from IP set 'Blocked'",
        "data": {
            "name": "Blocked",
            "id": "abc123",
            "arn": "arn:aws:wafv2:...",
            "description": "Blocked IPs",
            "addresses": ["192.168.1.1/32", "10.0.0.1/32"],
            "ip_count": 10,
            "ip_address_version": "IPV4",
            "pagination": {
                "page": 1,
                "per_page": 100,
                "total_ips": 10,
                "total_pages": 1
            }
        }
    }
    """
    try:
        import os
        scope = request.args.get('scope', os.getenv('AWS_SCOPE', 'REGIONAL'))
        page = int(request.args.get('page', 1))
        per_page = min(int(request.args.get('per_page', 100)), 500)

        # Import WAF functions
        import sys
        from pathlib import Path
        backend_response_path = Path(__file__).resolve().parent.parent.parent.parent
        if str(backend_response_path) not in sys.path:
            sys.path.insert(0, str(backend_response_path))

        from actions.WAF import get_ip_set_ips

        ip_set_data = get_ip_set_ips(ip_set_name, scope=scope)

        # Implement pagination
        all_addresses = ip_set_data['addresses']
        total_ips = len(all_addresses)
        total_pages = (total_ips + per_page - 1) // per_page  # Ceiling division

        start_idx = (page - 1) * per_page
        end_idx = start_idx + per_page
        paginated_addresses = all_addresses[start_idx:end_idx]

        ip_set_data['addresses'] = paginated_addresses
        ip_set_data['pagination'] = {
            'page': page,
            'per_page': per_page,
            'total_ips': total_ips,
            'total_pages': total_pages
        }

        return success_response(
            ip_set_data,
            f"Retrieved {len(paginated_addresses)} IPs from IP set '{ip_set_name}' (page {page}/{total_pages})"
        )
    except RuntimeError as e:
        return error_response(str(e), 404)
    except Exception as e:
        logger.error(f"Failed to get WAF IP set '{ip_set_name}': {e}", exc_info=True)
        return error_response(f"Failed to get IP set: {str(e)}", 500)


@waf_bp.route('/waf/ip-sets/<ip_set_name>/ips', methods=['POST'])
@require_auth
@require_edit_access('/waf-signatures')
def add_ip_to_waf_set(ip_set_name):
    """
    Add an IP to a WAF IP set.

    Path Parameters:
    - ip_set_name: Name of the IP set (e.g., "Blocked")

    Request Body:
    {
        "ip": "192.168.1.100",
        "reason": "Malicious activity detected",
        "analyst": "admin"
    }

    Response:
    {
        "success": true,
        "message": "IP 192.168.1.100/32 added to IP set 'Blocked'",
        "data": {
            "ip": "192.168.1.100",
            "ip_cidr": "192.168.1.100/32",
            "ip_set_name": "Blocked",
            "already_exists": false
        }
    }
    """
    try:
        import os
        data = request.get_json()

        if not data or 'ip' not in data:
            return error_response("ip is required", 400)

        ip = data['ip']
        scope = data.get('scope', os.getenv('AWS_SCOPE', 'REGIONAL'))

        # Import WAF functions
        import sys
        from pathlib import Path
        backend_response_path = Path(__file__).resolve().parent.parent.parent.parent
        if str(backend_response_path) not in sys.path:
            sys.path.insert(0, str(backend_response_path))

        from actions.WAF import block_ip

        # Validate IP address
        import ipaddress
        try:
            ipaddress.ip_address(ip)
        except ValueError:
            return error_response(f"Invalid IP address: {ip}", 400)

        # Add to WAF IP set
        was_added = block_ip(ip, ip_set_name=ip_set_name, scope=scope)

        ip_cidr = f"{ip}/32" if '/' not in ip else ip

        if was_added:
            message = f"IP {ip_cidr} added to IP set '{ip_set_name}'"
        else:
            message = f"IP {ip_cidr} already exists in IP set '{ip_set_name}'"

        return success_response(
            {
                "ip": ip,
                "ip_cidr": ip_cidr,
                "ip_set_name": ip_set_name,
                "already_exists": not was_added,
                "reason": data.get('reason'),
                "analyst": data.get('analyst')
            },
            message
        )
    except RuntimeError as e:
        return error_response(str(e), 400)
    except Exception as e:
        logger.error(f"Failed to add IP to WAF IP set '{ip_set_name}': {e}", exc_info=True)
        return error_response(f"Failed to add IP: {str(e)}", 500)


@waf_bp.route('/waf/ip-sets/<ip_set_name>/ips', methods=['DELETE'])
@require_auth
@require_edit_access('/waf-signatures')
def remove_ip_from_waf_set(ip_set_name):
    """
    Remove an IP from a WAF IP set.

    Path Parameters:
    - ip_set_name: Name of the IP set (e.g., "Blocked")

    Request Body:
    {
        "ip": "192.168.1.100",
        "reason": "False positive",
        "analyst": "admin"
    }

    Response:
    {
        "success": true,
        "message": "IP 192.168.1.100/32 removed from IP set 'Blocked'",
        "data": {
            "ip": "192.168.1.100",
            "ip_cidr": "192.168.1.100/32",
            "ip_set_name": "Blocked",
            "was_present": true
        }
    }
    """
    try:
        import os
        data = request.get_json()

        if not data or 'ip' not in data:
            return error_response("ip is required", 400)

        ip = data['ip']
        scope = data.get('scope', os.getenv('AWS_SCOPE', 'REGIONAL'))

        # Import WAF functions
        import sys
        from pathlib import Path
        backend_response_path = Path(__file__).resolve().parent.parent.parent.parent
        if str(backend_response_path) not in sys.path:
            sys.path.insert(0, str(backend_response_path))

        from actions.WAF import unblock_ip

        # Validate IP address
        import ipaddress
        try:
            ipaddress.ip_address(ip)
        except ValueError:
            return error_response(f"Invalid IP address: {ip}", 400)

        # Remove from WAF IP set
        was_removed = unblock_ip(ip, ip_set_name=ip_set_name, scope=scope)

        ip_cidr = f"{ip}/32" if '/' not in ip else ip

        if was_removed:
            message = f"IP {ip_cidr} removed from IP set '{ip_set_name}'"
        else:
            message = f"IP {ip_cidr} was not found in IP set '{ip_set_name}'"

        return success_response(
            {
                "ip": ip,
                "ip_cidr": ip_cidr,
                "ip_set_name": ip_set_name,
                "was_present": was_removed,
                "reason": data.get('reason'),
                "analyst": data.get('analyst')
            },
            message
        )
    except RuntimeError as e:
        return error_response(str(e), 400)
    except Exception as e:
        logger.error(f"Failed to remove IP from WAF IP set '{ip_set_name}': {e}", exc_info=True)
        return error_response(f"Failed to remove IP: {str(e)}", 500)
