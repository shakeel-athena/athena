"""
Background Modules API Routes

Flask blueprint containing endpoints for background module management.
"""

import logging
from flask import Blueprint, request, jsonify

# Create blueprint
background_modules_bp = Blueprint('background_modules', __name__, url_prefix='/api/background-modules')

# Logger
logger = logging.getLogger(__name__)

# Import module manager
from response.background_modules.module_manager import module_manager


def error_response(message, status_code=400):
    """Create standardized error response."""
    return jsonify({
        "success": False,
        "error": message
    }), status_code


# ============================================================================
# Background Modules API Endpoints
# ============================================================================

@background_modules_bp.route('/status', methods=['GET'])
def get_background_modules_status():
    """Get status of all background modules"""
    try:
        status = module_manager.get_all_status()
        return jsonify({
            'success': True,
            'data': status
        })
    except Exception as e:
        return error_response(str(e), 500)


@background_modules_bp.route('/<module_name>/toggle', methods=['POST'])
def toggle_background_module(module_name):
    """Toggle a background module on/off"""
    try:
        data = request.get_json()
        enabled = data.get('enabled', False)

        success = module_manager.toggle_module(module_name, enabled)

        if success:
            return jsonify({
                'success': True,
                'message': f'{module_name} module {"enabled" if enabled else "disabled"}'
            })
        else:
            return error_response(f'Failed to toggle {module_name} module', 400)

    except Exception as e:
        return error_response(str(e), 500)


@background_modules_bp.route('/<module_name>/interval', methods=['POST'])
def update_background_module_interval(module_name):
    """Update trigger interval for a module"""
    try:
        data = request.get_json()
        hours = data.get('hours', 6)

        if not isinstance(hours, (int, float)) or hours <= 0:
            return error_response('Invalid interval. Must be a positive number.', 400)

        success = module_manager.update_interval(module_name, hours)

        if success:
            return jsonify({
                'success': True,
                'message': f'{module_name} module interval updated to {hours} hours'
            })
        else:
            return error_response(f'Failed to update interval for {module_name} module', 400)

    except Exception as e:
        return error_response(str(e), 500)


@background_modules_bp.route('/ip-lists', methods=['GET'])
def get_background_modules_ip_lists():
    """Get current IP lists from both modules"""
    try:
        ip_lists = module_manager.get_ip_lists()
        return jsonify({
            'success': True,
            'data': ip_lists
        })
    except Exception as e:
        return error_response(str(e), 500)


@background_modules_bp.route('/start', methods=['POST'])
def start_background_modules():
    """Start all background modules"""
    try:
        module_manager.start_all()
        return jsonify({
            'success': True,
            'message': 'All background modules started'
        })
    except Exception as e:
        return error_response(str(e), 500)


@background_modules_bp.route('/stop', methods=['POST'])
def stop_background_modules():
    """Stop all background modules"""
    try:
        module_manager.stop_all()
        return jsonify({
            'success': True,
            'message': 'All background modules stopped'
        })
    except Exception as e:
        return error_response(str(e), 500)


@background_modules_bp.route('/<module_name>/config', methods=['POST'])
def update_module_config(module_name):
    """Update module configuration"""
    try:
        data = request.get_json()
        interval_hours = data.get('interval_hours', 0)
        interval_minutes = data.get('interval_minutes', 5)
        date_range_days = data.get('date_range_days', 7)

        success = module_manager.update_module_config(
            module_name,
            interval_hours,
            interval_minutes,
            date_range_days
        )

        if success:
            return jsonify({
                'success': True,
                'message': f'{module_name} configuration updated successfully'
            })
        else:
            return error_response(f'Failed to update {module_name} configuration', 400)

    except Exception as e:
        return error_response(str(e), 500)
