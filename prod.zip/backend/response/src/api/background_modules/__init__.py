"""
Background Modules API Module

Contains Flask blueprint for background module management endpoints.
"""

from .routes import background_modules_bp

__all__ = ['background_modules_bp']
