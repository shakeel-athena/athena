"""
Health Check API Blueprint

Provides REST API endpoints for service health monitoring.
"""

from .routes import health_bp

__all__ = ['health_bp']
