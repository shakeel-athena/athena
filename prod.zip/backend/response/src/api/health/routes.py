"""
Health Check API Routes

Flask blueprint containing health check and monitoring endpoints.
"""

from flask import Blueprint, jsonify
import logging
from datetime import datetime

from services.aws import AWSService

# Create blueprint
health_bp = Blueprint('health', __name__, url_prefix='/api')

# Logger
logger = logging.getLogger(__name__)

# AWS service instance (will be initialized when needed)
_aws_service = None


def get_aws_service() -> AWSService:
    """Get or create AWS service instance."""
    global _aws_service
    if _aws_service is None:
        import os

        # Get AWS region from environment
        aws_region = os.getenv("AWS_REGION", "us-east-2")

        # Initialize AWS service
        _aws_service = AWSService(region=aws_region)
        _aws_service.initialize_sync()

        logger.info(f"Created and initialized AWS service for region: {aws_region}")

    return _aws_service


def success_response(data, message="Success"):
    """Create standardized success response."""
    return jsonify({
        "success": True,
        "message": message,
        "data": data
    }), 200


# ============================================================================
# Health Check Endpoints
# ============================================================================

@health_bp.route('/health', methods=['GET'])
def health_check():
    """Basic health check endpoint."""
    return success_response({
        "status": "healthy",
        "timestamp": datetime.utcnow().isoformat(),
        "service": "athena-response-backend"
    }, "Service is healthy")


@health_bp.route('/health/detailed', methods=['GET'])
def detailed_health_check():
    """Detailed health check with component status."""
    health_data = {
        "status": "healthy",
        "timestamp": datetime.utcnow().isoformat(),
        "service": "athena-response-backend",
        "components": {
            "api": {"status": "healthy"},
            "database": {"status": "unknown"},
            "aws": {"status": "unknown"}
        }
    }

    # Check database connection
    try:
        from app import get_db_connection
        conn = get_db_connection()
        health_data["components"]["database"] = {"status": "healthy"}
    except Exception as e:
        health_data["components"]["database"] = {
            "status": "unhealthy",
            "error": str(e)
        }
        health_data["status"] = "degraded"

    # Check AWS connectivity using AWSService
    try:
        aws_service = get_aws_service()
        aws_health = aws_service.health_check()
        
        # Extract AWS service health information
        aws_service_status = aws_health.get('aws_service', {})
        
        if aws_service_status.get('credentials_valid', False):
            health_data["components"]["aws"] = {
                "status": "healthy",
                "region": aws_service_status.get('region'),
                "account_id": aws_service_status.get('account_info', {}).get('account_id'),
                "services": aws_service_status.get('services_status', {})
            }
        else:
            health_data["components"]["aws"] = {
                "status": "unhealthy",
                "error": "AWS credentials invalid",
                "region": aws_service_status.get('region')
            }
            health_data["status"] = "degraded"
            
    except Exception as e:
        health_data["components"]["aws"] = {
            "status": "unhealthy",
            "error": str(e)
        }
        health_data["status"] = "degraded"

    status_code = 200 if health_data["status"] == "healthy" else 503
    return jsonify({
        "success": True,
        "data": health_data
    }), status_code


@health_bp.route('/health/aws', methods=['GET'])
def aws_health_check():
    """AWS-specific health check endpoint."""
    try:
        aws_service = get_aws_service()
        aws_health = aws_service.health_check()
        
        return success_response(aws_health, "AWS health check completed")
        
    except Exception as e:
        logger.error(f"AWS health check failed: {e}")
        return jsonify({
            "success": False,
            "error": f"AWS health check failed: {str(e)}"
        }), 500


@health_bp.route('/health/aws/connectivity', methods=['GET'])
def aws_connectivity_test():
    """Test AWS service connectivity."""
    try:
        aws_service = get_aws_service()
        connectivity_result = aws_service.test_connectivity()
        
        if connectivity_result.success:
            return success_response(
                connectivity_result.to_dict(),
                "AWS connectivity test passed"
            )
        else:
            return jsonify({
                "success": False,
                "error": connectivity_result.message,
                "data": connectivity_result.to_dict()
            }), 500
            
    except Exception as e:
        logger.error(f"AWS connectivity test failed: {e}")
        return jsonify({
            "success": False,
            "error": f"AWS connectivity test failed: {str(e)}"
        }), 500


@health_bp.route('/ping', methods=['GET'])
def ping():
    """Simple ping endpoint."""
    return jsonify({"status": "ok", "timestamp": datetime.utcnow().isoformat()}), 200
