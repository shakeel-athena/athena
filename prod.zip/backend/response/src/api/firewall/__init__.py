"""
Firewall API Blueprint

Provides REST API endpoints for firewall IP management.
"""

from .routes import firewall_bp

__all__ = ['firewall_bp']
