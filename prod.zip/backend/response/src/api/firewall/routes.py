"""
Firewall API Routes

Flask blueprint containing all firewall IP management endpoints.
All endpoints require authentication and appropriate role permissions.
"""

from flask import Blueprint, request, jsonify, g
import logging
import os
import ipaddress

from services.aws import AWSService
from models.Firewall_IP_Blocking import FirewallIPBlockingManager
from errors.error_types import ValidationError, ServiceError
from firewall_audit_manager import FirewallAuditManager
from middleware.auth import require_auth
from utils.rbac import require_page_access, require_edit_access, require_admin

# Create blueprint
firewall_bp = Blueprint('firewall', __name__, url_prefix='/api')

# Logger
logger = logging.getLogger(__name__)

# Service instances (will be initialized when needed)
_firewall_service = None
_aws_service = None


def get_aws_service() -> AWSService:
    """Get or create AWS service instance."""
    global _aws_service
    if _aws_service is None:
        # Get AWS region from environment
        aws_region = os.getenv("AWS_REGION", "us-east-2")

        # Initialize AWS service
        _aws_service = AWSService(region=aws_region)
        _aws_service.initialize_sync()

        logger.info(f"Created and initialized AWS service for region: {aws_region}")

    return _aws_service


def get_firewall_manager():
    """Get or create Firewall IP blocking manager instance."""
    global _firewall_service
    if _firewall_service is None:
        # Get firewall configuration from environment
        aws_region = os.getenv("AWS_REGION", "us-east-2")
        rule_group_name = os.getenv("FIREWALL_RULE_GROUP", "allow-ingress")

        # Initialize firewall IP blocking manager
        _firewall_service = FirewallIPBlockingManager(
            region_name=aws_region,
            rule_group_name=rule_group_name
        )

        logger.info(f"Created firewall IP blocking manager for rule group: {rule_group_name}")

    return _firewall_service


def validate_aws_configuration():
    """Validate AWS configuration using AWSService."""
    try:
        aws_service = get_aws_service()
        credential_info = aws_service.validate_credentials()
        return {"valid": True, "account_id": credential_info.get('account_id')}
    except Exception as e:
        return {"valid": False, "error": str(e)}


def success_response(data, message="Success"):
    """Create standardized success response."""
    return jsonify({
        "success": True,
        "message": message,
        "data": data
    }), 200


def error_response(message, status_code=500):
    """Create standardized error response."""
    return jsonify({
        "success": False,
        "error": message
    }), status_code


def get_validated_data():
    """Get validated data from Flask g object."""
    return getattr(g, 'validated_data', None)


# Decorators for validation and rate limiting (simplified versions)
def validate_input(schema_name):
    """Validate input data (simplified)."""
    def decorator(f):
        def wrapper(*args, **kwargs):
            data = request.get_json()
            # Store validated data in g
            g.validated_data = data
            return f(*args, **kwargs)
        wrapper.__name__ = f.__name__
        return wrapper
    return decorator


def rate_limit(limit=10, window=60):
    """Rate limiting decorator (simplified)."""
    def decorator(f):
        def wrapper(*args, **kwargs):
            # In production, this would check rate limits
            # For now, just pass through
            return f(*args, **kwargs)
        wrapper.__name__ = f.__name__
        return wrapper
    return decorator


# ============================================================================
# Firewall IP Management Endpoints
# ============================================================================

@firewall_bp.route('/firewall/ip-sets', methods=['GET'])
@require_auth
@require_page_access('/firewall')
def get_ip_sets():
    """Get both allow and block lists with enhanced error handling."""
    try:
        # Check AWS configuration first
        if not os.getenv("FIREWALL_RULE_GROUP"):
            logger.warning("FIREWALL_RULE_GROUP not configured")
            return success_response(
                {"allow_list": [], "block_list": []},
                "Firewall rule group not configured. Please set FIREWALL_RULE_GROUP environment variable."
            )

        # Validate AWS configuration before proceeding
        aws_config = validate_aws_configuration()
        if not aws_config["valid"]:
            logger.error(f"AWS configuration validation failed: {aws_config['error']}")
            if "credentials" in aws_config['error'].lower():
                return error_response("AWS credentials not configured properly", 500)
            else:
                return error_response(f"AWS configuration error: {aws_config['error']}", 500)

        service = get_firewall_manager()
        allow_ips = service.get_allow_ips()
        block_ips = service.get_block_ips()

        return success_response({
            "allow_list": allow_ips,
            "block_list": block_ips
        }, "IP sets retrieved successfully")

    except Exception as e:
        logger.error(f"Firewall IP sets error: {e}")
        msg = str(e)

        # Graceful empty response if rule group not found (prevents blank UI)
        if "rule group" in msg.lower() and "not found" in msg.lower():
            rule_group = os.getenv("FIREWALL_RULE_GROUP", "not set")
            return success_response(
                {"allow_list": [], "block_list": []},
                f"Firewall rule group '{rule_group}' not found in AWS. Please check FIREWALL_RULE_GROUP environment variable."
            )

        # Enhanced error categorization
        if "credentials" in msg.lower():
            return error_response("AWS credentials not configured properly", 500)
        elif "access denied" in msg.lower() or "unauthorized" in msg.lower():
            return error_response("AWS access denied. Check IAM permissions for Network Firewall.", 403)
        elif "network firewall" in msg.lower() and "not found" in msg.lower():
            return error_response("AWS Network Firewall service not available in this region", 503)
        elif "timeout" in msg.lower() or "connection" in msg.lower():
            return error_response("AWS service connection timeout. Please try again later.", 504)
        else:
            return error_response(f"Failed to get IP sets: {msg}", 500)


@firewall_bp.route('/firewall/allow-list', methods=['GET'])
@require_auth
@require_page_access('/firewall')
def get_allow_list():
    """Get the allow list."""
    try:
        service = get_firewall_manager()
        allow_ips = service.get_allow_ips()
        return success_response(allow_ips, "Allow list retrieved successfully")
    except Exception as e:
        msg = str(e)
        if "Rule group" in msg and "not found" in msg:
            return success_response([], "Rule group not found. Set FIREWALL_RULE_GROUP and AWS_REGION.")
        return error_response(f"Failed to get allow list: {msg}", 500)


@firewall_bp.route('/firewall/block-list', methods=['GET'])
@require_auth
@require_page_access('/firewall')
def get_block_list():
    """Get the block list."""
    try:
        service = get_firewall_manager()
        block_ips = service.get_block_ips()
        return success_response(block_ips, "Block list retrieved successfully")
    except Exception as e:
        msg = str(e)
        if "Rule group" in msg and "not found" in msg:
            return success_response([], "Rule group not found. Set FIREWALL_RULE_GROUP and AWS_REGION.")
        return error_response(f"Failed to get block list: {msg}", 500)


@firewall_bp.route('/firewall/allow-list', methods=['POST'])
@require_auth
@require_edit_access('/firewall')
@validate_input('firewall_ip_list')
@rate_limit(limit=10, window=60)
def add_to_allow_list():
    """Add IPs to the allow list."""
    try:
        validated_data = get_validated_data()
        ips = validated_data.get('ips', [])

        if not ips:
            return error_response("ips list is required", 400)

        service = get_firewall_manager()
        added_ips = service.add_allow_ips(ips)

        return success_response(added_ips, f"Added {len(added_ips)} IPs to allow list")
    except Exception as e:
        logger.error(f"Failed to add IPs to allow list: {e}")
        return error_response(f"Failed to add IPs to allow list: {str(e)}", 500)


@firewall_bp.route('/firewall/block-list', methods=['POST'])
@require_auth
@require_edit_access('/firewall')
@validate_input('firewall_ip_list')
@rate_limit(limit=10, window=60)
def add_to_block_list():
    """Add IPs to the block list."""
    try:
        validated_data = get_validated_data()
        ips = validated_data.get('ips', [])

        if not ips:
            return error_response("ips list is required", 400)

        service = get_firewall_manager()
        added_ips = service.add_block_ips(ips)

        return success_response(added_ips, f"Added {len(added_ips)} IPs to block list")
    except Exception as e:
        logger.error(f"Failed to add IPs to block list: {e}")
        return error_response(f"Failed to add IPs to block list: {str(e)}", 500)


@firewall_bp.route('/firewall/allow-list', methods=['DELETE'])
@require_auth
@require_edit_access('/firewall')
@validate_input('firewall_ip_list')
@rate_limit(limit=10, window=60)
def remove_from_allow_list():
    """Remove IPs from the allow list."""
    try:
        validated_data = get_validated_data()
        ips = validated_data.get('ips', [])

        if not ips:
            return error_response("ips list is required", 400)

        service = get_firewall_manager()
        removed_ips = service.remove_allow_ips(ips)

        return success_response(removed_ips, f"Removed {len(removed_ips)} IPs from allow list")
    except Exception as e:
        logger.error(f"Failed to remove IPs from allow list: {e}")
        return error_response(f"Failed to remove IPs from allow list: {str(e)}", 500)


@firewall_bp.route('/firewall/block-list', methods=['DELETE'])
@require_auth
@require_edit_access('/firewall')
@validate_input('firewall_ip_list')
@rate_limit(limit=10, window=60)
def remove_from_block_list():
    """Remove IPs from the block list."""
    try:
        validated_data = get_validated_data()
        ips = validated_data.get('ips', [])

        if not ips:
            return error_response("ips list is required", 400)

        service = get_firewall_manager()
        removed_ips = service.remove_block_ips(ips)

        return success_response(removed_ips, f"Removed {len(removed_ips)} IPs from block list")
    except Exception as e:
        logger.error(f"Failed to remove IPs from block list: {e}")
        return error_response(f"Failed to remove IPs from block list: {str(e)}", 500)


@firewall_bp.route('/firewall/debug', methods=['GET'])
@require_auth
@require_admin()
def firewall_debug():
    """Get firewall debug information."""
    try:
        service = get_firewall_manager()

        debug_info = {
            "rule_group_name": service.rule_group_name,
            "region": service.region_name,
            "rule_group_exists": False,
            "allow_list_count": 0,
            "block_list_count": 0
        }

        try:
            allow_ips = service.get_allow_ips()
            block_ips = service.get_block_ips()
            debug_info["rule_group_exists"] = True
            debug_info["allow_list_count"] = len(allow_ips)
            debug_info["block_list_count"] = len(block_ips)
        except:
            pass

        return success_response(debug_info, "Firewall debug information retrieved")
    except Exception as e:
        logger.error(f"Failed to get firewall debug info: {e}")
        return error_response(f"Failed to get firewall debug info: {str(e)}", 500)


@firewall_bp.route('/firewall/transfer-ip', methods=['POST'])
@require_auth
@require_edit_access('/firewall')
@validate_input('firewall_transfer')
@rate_limit(limit=5, window=60)
def transfer_ip():
    """Transfer IP from one list to another."""
    try:
        validated_data = get_validated_data()
        ip = validated_data.get('ip')
        from_list = validated_data.get('from_list')  # 'allow' or 'block'
        to_list = validated_data.get('to_list')      # 'allow' or 'block'

        if not ip or not from_list or not to_list:
            return error_response("ip, from_list, and to_list are required", 400)

        if from_list == to_list:
            return error_response("from_list and to_list must be different", 400)

        service = get_firewall_manager()

        # Remove from source list
        if from_list == 'allow':
            service.remove_allow_ips([ip])
        else:
            service.remove_block_ips([ip])

        # Add to destination list
        if to_list == 'allow':
            service.add_allow_ips([ip])
        else:
            service.add_block_ips([ip])

        return success_response(
            {"ip": ip, "from": from_list, "to": to_list},
            f"Transferred {ip} from {from_list} list to {to_list} list"
        )
    except Exception as e:
        logger.error(f"Failed to transfer IP: {e}")
        return error_response(f"Failed to transfer IP: {str(e)}", 500)


# ============================================================================
# NEW ENDPOINTS: Alert-Based IP Blocking with Audit Trail
# ============================================================================

def get_audit_manager():
    """Get FirewallAuditManager instance with database connection from Flask g context."""
    db_conn = getattr(g, 'db', None)
    if db_conn is None:
        return None  # Database not available (AWS-only mode)

    # Check if it's a DatabaseWrapper and extract the raw psycopg2 connection
    if hasattr(db_conn, 'conn'):
        # It's a DatabaseWrapper - extract the raw connection
        raw_conn = db_conn.conn
    else:
        # Assume it's already a raw connection
        raw_conn = db_conn

    return FirewallAuditManager(db_connection=raw_conn)


@firewall_bp.route('/firewall/block-from-alert', methods=['POST'])
@require_auth
@require_edit_access('/firewall')
def block_ip_from_alert():
    """
    Block IP from security alert with dual-layer blocking (Network Firewall + WAF)

    Request Body:
    {
        "ip": "192.168.1.100",
        "alert_id": "suricata-alert-123",
        "alert_source": "suricata" | "wazuh",
        "alert_severity": "High",
        "threat_type": "malware_c2",
        "reason": "Malware C2 detected",
        "direction": "both",
        "analyst": "admin"
    }

    Response:
    {
        "success": true,
        "message": "IP 192.168.1.100 blocked successfully",
        "data": {
            "ip": "192.168.1.100",
            "ip_cidr": "192.168.1.100/32",
            "metadata_id": "uuid",
            "aws_enforced": true,
            "waf_enforced": true,
            "waf_error": null,
            "layers_blocked": ["network_firewall", "waf"]
        }
    }
    """
    try:
        data = request.get_json()

        # Validate required fields
        required = ['ip', 'alert_id', 'alert_source', 'analyst']
        for field in required:
            if field not in data:
                return error_response(f"Missing required field: {field}", 400)

        ip = data['ip']

        # Get database connection from Flask g context
        db_conn = getattr(g, 'db', None)
        cursor = None
        conn = None

        if db_conn:
            # Extract raw connection if it's a DatabaseWrapper
            if hasattr(db_conn, 'conn'):
                conn = db_conn.conn
            else:
                conn = db_conn
            cursor = conn.cursor()

        # Use internal function for dual-layer blocking
        result = block_ip_from_alert_internal(ip, data, cursor=cursor, conn=conn)

        if cursor:
            cursor.close()

        if result.get('success'):
            logger.info(f"Returning block response for {ip}: waf_enforced={result.get('waf_enforced')}, updated={result.get('updated', False)}")
            return success_response(result, f"IP {ip} blocked successfully")
        else:
            return error_response(result.get('error', 'Unknown error'), 500)

    except Exception as e:
        logger.error(f"Error blocking IP from alert: {e}", exc_info=True)
        return error_response(f"Failed to block IP: {str(e)}", 500)


def block_ip_from_alert_internal(ip, data, cursor=None, conn=None):
    """
    Internal function to block IP without Flask request context.
    Used by bulk actions endpoint.

    Implements dual-layer blocking: Network Firewall + WAF

    Args:
        ip: IP address to block
        data: dict with alert_id, alert_source, analyst, etc.
        cursor: database cursor (optional)
        conn: database connection (optional)

    Returns:
        dict with success/error
    """
    try:
        # Validate IP address format
        try:
            ip_obj = ipaddress.ip_address(ip)
        except ValueError:
            return {"success": False, "error": f"Invalid IP address: {ip}"}

        # Import IP validation utilities
        import sys
        import os as os_module
        utils_path = os_module.path.join(os_module.path.dirname(__file__), '../../')
        utils_path = os_module.path.abspath(utils_path)
        if utils_path not in sys.path:
            sys.path.insert(0, utils_path)

        from utils.ip_validator import validate_ip_for_blocking, check_if_already_blocked

        # Validate IP can be safely blocked
        is_valid, validation_msg = validate_ip_for_blocking(ip, allow_private=True)
        if not is_valid:
            return {"success": False, "error": validation_msg}

        # Check if already blocked in database
        if cursor:
            is_blocked, block_id = check_if_already_blocked(ip, cursor)
            if is_blocked:
                logger.warning(f"IP {ip} found in database as already blocked (ID: {block_id})")

                # Verify the record is valid by checking if it has proper metadata
                cursor.execute("""
                    SELECT id, added_at, aws_enforced, active, expires_at
                    FROM firewall_ip_metadata
                    WHERE id = %s
                """, [block_id])

                record = cursor.fetchone()
                if record:
                    record_id, added_at, aws_enforced, active, expires_at = record
                    logger.info(f"Found existing record: active={active}, aws_enforced={aws_enforced}, added_at={added_at}")

                    # If record exists and is properly enforced, update it instead of creating new one
                    if active and aws_enforced:
                        # Update the existing record with new data
                        logger.info(f"Updating existing blocked IP record for {ip} (ID: {block_id})")

                        # Calculate new expiration if provided
                        new_expires_at = None
                        expires_in_hours = data.get('expires_in_hours')
                        if expires_in_hours:
                            from datetime import datetime, timedelta
                            new_expires_at = datetime.now() + timedelta(hours=expires_in_hours)

                        # Ensure WAF blocking is attempted for the existing IP
                        waf_enforced_update = False
                        waf_error_update = None

                        try:
                            waf_ip_set_name = os.getenv("WAF_BLOCKLIST_NAME", "Blocked")
                            waf_scope = os.getenv("AWS_SCOPE", "REGIONAL")

                            logger.info(f"Ensuring IP {ip} is blocked in AWS WAF...")

                            # Import WAF blocking function
                            import sys
                            import os as os_module
                            backend_response_path = os_module.path.join(os_module.path.dirname(__file__), '..', '..', '..')
                            backend_response_path = os_module.path.abspath(backend_response_path)
                            if backend_response_path not in sys.path:
                                sys.path.insert(0, backend_response_path)

                            from actions.WAF import block_ip as waf_block_ip

                            # Block in WAF (returns tuple: success, already_existed, error)
                            success, already_existed, error = waf_block_ip(ip, ip_set_name=waf_ip_set_name, scope=waf_scope)

                            if success:
                                waf_enforced_update = True
                                logger.info(f"✅ WAF blocking ensured for {ip} (already_existed={already_existed})")
                            else:
                                waf_error_update = error
                                logger.warning(f"Failed to ensure WAF blocking for {ip}: {error}")

                        except Exception as waf_err:
                            logger.warning(f"Failed to ensure WAF blocking for {ip}: {waf_err}")
                            waf_error_update = str(waf_err)

                        # Update database record
                        cursor.execute("""
                            UPDATE firewall_ip_metadata
                            SET reason = %s,
                                threat_type = %s,
                                expires_at = %s,
                                direction = %s,
                                waf_enforced = %s,
                                waf_error = %s
                            WHERE id = %s
                        """, [
                            data.get('reason', 'Updated block'),
                            data.get('threat_type', 'other'),
                            new_expires_at,
                            data.get('direction', 'both'),
                            waf_enforced_update,
                            waf_error_update,
                            block_id
                        ])

                        conn.commit()
                        logger.info(f"✅ Updated existing block record for {ip}")

                        return {
                            "success": True,
                            "ip": ip,
                            "ip_cidr": f"{ip}/32" if '/' not in ip else ip,
                            "metadata_id": str(block_id),
                            "aws_enforced": True,
                            "waf_enforced": waf_enforced_update,
                            "waf_error": waf_error_update,
                            "layers_blocked": ["network_firewall"] + (["waf"] if waf_enforced_update else []),
                            "updated": True
                        }
                    else:
                        # Stale/incomplete record - log warning and allow re-blocking
                        logger.warning(f"Found stale/incomplete record for {ip} - allowing re-block (active={active}, aws_enforced={aws_enforced})")
                else:
                    logger.warning(f"Record {block_id} not found - allowing re-block")

        # Normalize to CIDR with appropriate prefix length
        if isinstance(ip_obj, ipaddress.IPv4Address):
            ip_cidr = f"{ip}/32" if '/' not in ip else ip
        else:  # IPv6Address
            ip_cidr = f"{ip}/128" if '/' not in ip else ip

        # Log warning if present
        warning = None
        if validation_msg:
            warning = validation_msg
            logger.warning(f"IP blocking warning for {ip}: {validation_msg}")

        # Validate AWS config
        aws_config = validate_aws_configuration()
        if not aws_config["valid"]:
            return {"success": False, "error": "AWS credentials not configured properly"}

        # 1. Add to AWS Network Firewall (Layer 3/4)
        logger.info(f"Blocking IP {ip} in AWS Network Firewall (Layer 3/4)...")
        firewall_manager = get_firewall_manager()

        try:
            result = firewall_manager.add_block_ips([ip_cidr])
            logger.info(f"AWS Network Firewall result: {result}")
        except Exception as aws_error:
            error_msg = str(aws_error).lower()
            # If IP is already in AWS, treat as success and continue with database logging
            if "already" in error_msg or "duplicate" in error_msg or "exists" in error_msg:
                logger.warning(f"IP {ip} already exists in AWS Network Firewall - continuing with database logging")
            else:
                # Real error - re-raise
                raise

        # 2. Add to AWS WAF (Layer 7 - Application Layer)
        waf_enforced = False
        waf_error = None

        try:
            waf_ip_set_name = os.getenv("WAF_BLOCKLIST_NAME", "Blocked")
            waf_scope = os.getenv("AWS_SCOPE", "REGIONAL")

            logger.info(f"Blocking IP {ip} in AWS WAF (Layer 7) - IP Set: {waf_ip_set_name}...")

            # Import WAF blocking function - simpler import path
            import sys
            import os as os_module
            # Add backend/response directory to path if not already there
            backend_response_path = os_module.path.join(os_module.path.dirname(__file__), '..', '..', '..')
            backend_response_path = os_module.path.abspath(backend_response_path)
            if backend_response_path not in sys.path:
                sys.path.insert(0, backend_response_path)

            # Import from actions.WAF module
            from actions.WAF import block_ip as waf_block_ip

            # Block in WAF (returns tuple: success, already_existed, error)
            success, already_existed, error = waf_block_ip(ip, ip_set_name=waf_ip_set_name, scope=waf_scope)

            if success:
                waf_enforced = True
                if already_existed:
                    logger.info(f"✅ WAF SUCCESS: IP {ip} already in WAF IP Set '{waf_ip_set_name}' (idempotent)")
                else:
                    logger.info(f"✅ WAF SUCCESS: IP {ip} added to WAF IP Set '{waf_ip_set_name}'")
            else:
                waf_error = error
                logger.warning(f"Failed to block IP {ip} in WAF: {error}")

        except Exception as waf_err:
            logger.warning(f"Failed to block IP {ip} in WAF: {waf_err}")
            waf_error = str(waf_err)
            # Continue - Network Firewall block succeeded, WAF is additional layer

        # 3. Log to database
        metadata_id = None

        if cursor and conn:
            try:
                logger.info(f"Attempting to log IP block to database for {ip}...")

                # Calculate expiration if duration provided
                expires_at = None
                expires_in_hours = data.get('expires_in_hours')
                if expires_in_hours:
                    from datetime import datetime, timedelta
                    expires_at = datetime.now() + timedelta(hours=expires_in_hours)
                    logger.info(f"IP will expire at: {expires_at}")

                alert_context = {
                    'alert_id': data.get('alert_id'),
                    'alert_source': data.get('alert_source'),
                    'alert_severity': data.get('alert_severity'),
                    'threat_type': data.get('threat_type', 'other'),
                    'reason': data.get('reason', 'Blocked from security alert'),
                    'direction': data.get('direction', 'both'),
                    'aws_rule_group': os.getenv('FIREWALL_RULE_GROUP'),
                    'aws_region': os.getenv('AWS_REGION', 'us-east-2'),
                    'bulk_action_id': data.get('bulk_action_id'),  # Link to bulk action
                    'waf_enforced': waf_enforced,
                    'waf_ip_set': waf_ip_set_name if waf_enforced else None,
                    'waf_error': waf_error,
                    'expires_at': expires_at
                }

                # Use FirewallAuditManager directly with provided cursor
                from firewall_audit_manager import FirewallAuditManager
                audit_manager = FirewallAuditManager(conn)

                metadata_id = audit_manager.log_ip_blocked(
                    ip=ip,
                    analyst=data.get('analyst'),
                    alert_context=alert_context
                )

                # Commit the transaction
                conn.commit()
                logger.info(f"✅ Successfully logged IP block to database - Metadata ID: {metadata_id}")
            except Exception as db_error:
                logger.error(f"❌ Database logging failed: {db_error}", exc_info=True)
                # Rollback on error
                try:
                    conn.rollback()
                except:
                    pass
                # Continue even if database logging fails - AWS blocks succeeded
        else:
            logger.warning(f"⚠️ Database connection not available - cursor={cursor is not None}, conn={conn is not None}")

        return {
            "success": True,
            "ip": ip,
            "ip_cidr": ip_cidr,
            "metadata_id": str(metadata_id) if metadata_id else None,
            "aws_enforced": True,
            "waf_enforced": waf_enforced,
            "waf_error": waf_error,
            "layers_blocked": ["network_firewall"] + (["waf"] if waf_enforced else [])
        }

    except Exception as e:
        logger.error(f"Error blocking IP internally: {e}", exc_info=True)
        return {"success": False, "error": str(e)}


@firewall_bp.route('/firewall/blocked-ips', methods=['GET'])
@require_auth
@require_page_access('/firewall')
def get_blocked_ips_list():
    """
    Get all IPs blocked from alerts with metadata

    Query Params:
    - threat_type: Filter by threat type
    - alert_source: Filter by alert source (suricata/wazuh)
    - analyst: Filter by analyst
    - active_only: true/false (default: true)

    Response:
    {
        "success": true,
        "message": "Retrieved X blocked IPs",
        "data": [
            {
                "id": "uuid",
                "ip_address": "192.168.1.100",
                "threat_type": "malware_c2",
                "alert_source": "suricata",
                "alert_severity": "High",
                "original_alert_id": "suricata-alert-123",
                "added_by": "admin",
                "added_at": "2025-11-17T10:00:00",
                "reason": "Malware detected",
                "active": true
            }
        ]
    }
    """
    try:
        audit_manager = get_audit_manager()
        if not audit_manager:
            return error_response("Database not available", 500)

        # Parse filters from query params
        filters = {
            'threat_type': request.args.get('threat_type'),
            'alert_source': request.args.get('alert_source'),
            'analyst': request.args.get('analyst'),
            'active_only': request.args.get('active_only', 'true').lower() == 'true'
        }

        # Remove None values
        filters = {k: v for k, v in filters.items() if v is not None}

        logger.info(f"Fetching blocked IPs with filters: {filters}")
        blocked_ips = audit_manager.get_blocked_ips(filters)
        logger.info(f"Found {len(blocked_ips)} blocked IPs in database")

        # Convert datetime objects and IP addresses to strings for JSON serialization
        for record in blocked_ips:
            if record.get('added_at'):
                record['added_at'] = record['added_at'].isoformat()
            if record.get('removed_at'):
                record['removed_at'] = record['removed_at'].isoformat()
            # Convert IPv4Address/IPv6Address objects to string
            if record.get('ip_address'):
                record['ip_address'] = str(record['ip_address'])

        return success_response(
            blocked_ips,
            f"Retrieved {len(blocked_ips)} blocked IPs"
        )

    except Exception as e:
        logger.error(f"Error fetching blocked IPs: {e}", exc_info=True)
        return error_response(f"Failed to fetch blocked IPs: {str(e)}", 500)


@firewall_bp.route('/firewall/blocked-ips/unblock', methods=['POST'])
@require_auth
@require_edit_access('/firewall')
def unblock_ip_from_alert():
    """
    Unblock IP (simple, no reason required per user requirement)

    Request Body:
    {
        "ip": "192.168.1.100",
        "analyst": "admin"
    }

    Response:
    {
        "success": true,
        "message": "IP 192.168.1.100 unblocked successfully",
        "data": {
            "ip": "192.168.1.100",
            "unblocked": true
        }
    }
    """
    try:
        data = request.get_json()

        if not data or 'ip' not in data or 'analyst' not in data:
            return error_response("IP and analyst required", 400)

        ip = data['ip']
        analyst = data['analyst']

        # Normalize to CIDR with appropriate prefix length
        try:
            ip_obj = ipaddress.ip_address(ip)
            if isinstance(ip_obj, ipaddress.IPv4Address):
                ip_cidr = f"{ip}/32" if '/' not in ip else ip
            else:  # IPv6Address
                ip_cidr = f"{ip}/128" if '/' not in ip else ip
        except ValueError:
            return error_response(f"Invalid IP address: {ip}", 400)

        # 1. Remove from AWS Network Firewall (EXISTING functionality)
        logger.info(f"Unblocking IP {ip} from AWS Network Firewall...")
        firewall_manager = get_firewall_manager()
        result = firewall_manager.remove_block_ips([ip_cidr])

        # 2. Update database (NEW audit trail)
        audit_manager = get_audit_manager()
        if audit_manager:
            try:
                audit_manager.log_ip_unblocked(ip=ip, analyst=analyst)
                logger.info(f"Logged IP unblock to database")
            except Exception as db_error:
                logger.warning(f"Database logging failed: {db_error}")
                # Continue even if database logging fails - AWS unblock succeeded

        return success_response({
            'ip': ip,
            'unblocked': True
        }, f"IP {ip} unblocked successfully")

    except Exception as e:
        logger.error(f"Error unblocking IP: {e}", exc_info=True)
        return error_response(f"Failed to unblock IP: {str(e)}", 500)


# ============================================================================
# Blocked IPs Management Endpoints (for Admin Page)
# ============================================================================

@firewall_bp.route('/firewall/blocked-ips/<ip_id>', methods=['GET'])
@require_auth
@require_page_access('/firewall')
def get_blocked_ip_details(ip_id):
    """
    Get single blocked IP with full details and audit trail

    Response:
    {
        "success": true,
        "data": {
            "id": "uuid",
            "ip_address": "192.168.1.100",
            "ip_cidr": "192.168.1.100/32",
            "added_at": "2025-11-16T10:30:00",
            "added_by": "john.doe",
            "reason": "Malware C2 detected",
            "threat_type": "malware_c2",
            "alert_source": "suricata",
            "alert_severity": "Critical",
            "original_alert_id": "alert_abc123",
            "aws_enforced": true,
            "aws_enforced_at": "2025-11-16T10:31:00",
            "aws_enforcement_error": null,
            "times_seen_in_alerts": 45,
            "last_seen_in_alert": "2025-11-17T08:15:00",
            "active": true,
            "expires_at": null,
            "notes": "Additional context",
            "tags": {...},
            "audit_trail": [...]
        }
    }
    """
    try:
        audit_manager = get_audit_manager()
        if not audit_manager:
            return error_response("Database not available", 500)

        # Get IP details
        ip_details = audit_manager.get_blocked_ip_by_id(ip_id)
        if not ip_details:
            return error_response("Blocked IP not found", 404)

        # Convert datetime and IP objects to strings
        if ip_details.get('added_at'):
            ip_details['added_at'] = ip_details['added_at'].isoformat()
        if ip_details.get('removed_at'):
            ip_details['removed_at'] = ip_details['removed_at'].isoformat()
        if ip_details.get('expires_at'):
            ip_details['expires_at'] = ip_details['expires_at'].isoformat()
        if ip_details.get('aws_enforced_at'):
            ip_details['aws_enforced_at'] = ip_details['aws_enforced_at'].isoformat()
        if ip_details.get('last_seen_in_alert'):
            ip_details['last_seen_in_alert'] = ip_details['last_seen_in_alert'].isoformat()
        if ip_details.get('ip_address'):
            ip_details['ip_address'] = str(ip_details['ip_address'])

        # Get audit trail
        audit_trail = audit_manager.get_audit_trail_for_ip(ip_id)
        for entry in audit_trail:
            if entry.get('timestamp'):
                entry['timestamp'] = entry['timestamp'].isoformat()

        ip_details['audit_trail'] = audit_trail

        return success_response(ip_details, "Blocked IP details retrieved successfully")

    except Exception as e:
        logger.error(f"Error getting blocked IP details: {e}", exc_info=True)
        return error_response(str(e), 500)


@firewall_bp.route('/firewall/blocked-ips/stats', methods=['GET'])
@require_auth
@require_page_access('/firewall')
def get_blocked_ips_stats():
    """
    Get statistics for blocked IPs dashboard

    Response:
    {
        "success": true,
        "data": {
            "total_blocked": 150,
            "aws_enforced": 145,
            "aws_pending": 3,
            "aws_failed": 2,
            "expiring_soon": 5,
            "by_threat_type": {
                "malware_c2": 60,
                "brute_force": 45,
                "port_scan": 25,
                "other": 20
            },
            "top_blocked_ips": [
                {
                    "ip": "10.0.0.50",
                    "times_seen": 500,
                    "threat_type": "malware_c2"
                }
            ]
        }
    }
    """
    try:
        audit_manager = get_audit_manager()
        if not audit_manager:
            return error_response("Database not available", 500)

        stats = audit_manager.get_blocked_ips_statistics()

        # Convert IP addresses to strings in top_blocked_ips
        if 'top_blocked_ips' in stats:
            for ip_stat in stats['top_blocked_ips']:
                if 'ip' in ip_stat:
                    ip_stat['ip'] = str(ip_stat['ip'])

        return success_response(stats, "Statistics retrieved successfully")

    except Exception as e:
        logger.error(f"Error getting blocked IPs stats: {e}", exc_info=True)
        return error_response(str(e), 500)


@firewall_bp.route('/firewall/blocked-ips/bulk-unblock', methods=['POST'])
@require_auth
@require_edit_access('/firewall')
def bulk_unblock_ips():
    """
    Unblock multiple IPs at once

    Request:
    {
        "ip_ids": ["uuid1", "uuid2", ...],
        "analyst": "john.doe",
        "reason": "False positive - internal scanner"
    }

    Response:
    {
        "success": true,
        "data": {
            "unblocked_count": 5,
            "unblocked_ips": ["192.168.1.100", ...],
            "aws_removal_pending": 0,
            "aws_removal_failed": 0
        }
    }
    """
    try:
        data = request.get_json()

        if not data or 'ip_ids' not in data or 'analyst' not in data:
            return error_response("ip_ids and analyst required", 400)

        ip_ids = data['ip_ids']
        analyst = data['analyst']
        reason = data.get('reason', 'Bulk unblock operation')

        if not ip_ids:
            return error_response("ip_ids cannot be empty", 400)

        if len(ip_ids) > 50:
            return error_response("Maximum 50 IPs per bulk unblock", 400)

        audit_manager = get_audit_manager()
        if not audit_manager:
            return error_response("Database not available", 500)

        # Get IP addresses for the given IDs
        ips_to_unblock = audit_manager.get_ips_by_ids(ip_ids)
        if not ips_to_unblock:
            return error_response("No IPs found for given IDs", 404)

        unblocked_ips = []
        aws_failed_count = 0

        firewall_manager = get_firewall_manager()

        for ip_record in ips_to_unblock:
            ip_address = str(ip_record['ip_address'])
            ip_id = str(ip_record['id'])
            ip_cidr = ip_record.get('ip_cidr', f"{ip_address}/32")

            # Try to remove from AWS Network Firewall (Layer 3/4)
            aws_success = False
            aws_error_msg = None
            aws_already_removed = False

            try:
                firewall_manager.remove_block_ips([ip_cidr])
                aws_success = True
                logger.info(f"Successfully removed {ip_address} from AWS Network Firewall")
            except Exception as aws_error:
                aws_error_msg = str(aws_error)
                logger.warning(f"AWS Network Firewall removal failed for {ip_address}: {aws_error_msg}")

                # Check if IP was already removed (not an error - desired state achieved)
                if "not found" in aws_error_msg.lower() or "does not exist" in aws_error_msg.lower():
                    logger.info(f"IP {ip_address} already removed from AWS Network Firewall (not in block list)")
                    aws_success = True
                    aws_already_removed = True
                else:
                    # Real AWS error - increment failure count
                    aws_failed_count += 1
                    logger.error(f"AWS Network Firewall removal FAILED for {ip_address}: {aws_error_msg}")

            # Try to remove from WAF (Layer 7) - independent of Network Firewall result
            waf_removed = False
            waf_error = None
            try:
                from actions.WAF import unblock_ip as waf_unblock_ip
                waf_ip_set_name = os.getenv("WAF_BLOCKLIST_NAME", "Blocked")
                waf_scope = os.getenv("AWS_SCOPE", "REGIONAL")

                waf_removed = waf_unblock_ip(ip_address, ip_set_name=waf_ip_set_name, scope=waf_scope)
                if waf_removed:
                    logger.info(f"Successfully removed {ip_address} from WAF IP Set '{waf_ip_set_name}'")
                else:
                    logger.info(f"IP {ip_address} was not in WAF IP Set (already removed or never added)")
            except Exception as waf_err:
                waf_error = str(waf_err)
                logger.warning(f"WAF removal failed for {ip_address}: {waf_error}")
                # Don't increment aws_failed_count - WAF failure doesn't prevent unblock

            # Only update database if AWS operation succeeded or IP already removed
            # This keeps database in sync with AWS reality
            if aws_success or aws_already_removed:
                try:
                    audit_manager.log_ip_unblocked(
                        ip=ip_address,
                        analyst=analyst,
                        reason=reason
                    )
                    unblocked_ips.append(ip_address)

                    if aws_already_removed:
                        logger.info(f"Database synced: IP {ip_address} was already removed from AWS")
                    else:
                        logger.info(f"Database updated: IP {ip_address} marked as inactive")

                except Exception as db_error:
                    logger.error(f"Failed to update database for IP {ip_address}: {db_error}")
            else:
                # AWS removal failed - don't update database
                logger.warning(f"Skipping database update for {ip_address} - AWS removal failed")
                logger.warning(f"IP {ip_address} remains active in database (still blocked in AWS)")

        return success_response({
            "unblocked_count": len(unblocked_ips),
            "unblocked_ips": unblocked_ips,
            "aws_removal_pending": 0,
            "aws_removal_failed": aws_failed_count
        }, f"Unblocked {len(unblocked_ips)} IPs")

    except Exception as e:
        logger.error(f"Bulk unblock error: {e}", exc_info=True)
        return error_response(str(e), 500)


@firewall_bp.route('/firewall/blocked-ips/<ip_id>', methods=['PUT'])
@require_auth
@require_edit_access('/firewall')
def update_blocked_ip(ip_id):
    """
    Update blocked IP metadata

    Request:
    {
        "analyst": "john.doe",
        "expires_at": "2025-12-01T00:00:00",  // Optional
        "notes": "Extended block for investigation",  // Optional
        "tags": {"investigation_id": "IR-2025-001"}  // Optional
    }
    """
    try:
        data = request.get_json()

        if not data or 'analyst' not in data:
            return error_response("analyst required", 400)

        analyst = data['analyst']
        allowed_fields = ['expires_at', 'notes', 'tags', 'reason']
        updates = {k: v for k, v in data.items() if k in allowed_fields}

        if not updates:
            return error_response("No valid fields to update", 400)

        audit_manager = get_audit_manager()
        if not audit_manager:
            return error_response("Database not available", 500)

        # Update the IP metadata
        audit_manager.update_blocked_ip(ip_id, updates, analyst)

        return success_response(
            {"ip_id": ip_id},
            "Blocked IP updated successfully"
        )

    except Exception as e:
        logger.error(f"Update blocked IP error: {e}", exc_info=True)
        return error_response(str(e), 500)


@firewall_bp.route('/firewall/blocked-ips/expire', methods=['POST'])
@require_auth
@require_admin()
def expire_blocked_ips():
    """
    Cron job endpoint to expire and unblock IPs that have passed their expiration time.
    Similar to mute rules expiration.

    Response:
    {
        "success": true,
        "data": {
            "expired_count": 5,
            "expired_ips": ["192.168.1.100", "10.0.0.50", ...]
        }
    }
    """
    try:
        audit_manager = get_audit_manager()
        if not audit_manager:
            return error_response("Database not available", 500)

        firewall_manager = get_firewall_manager()

        # Get database connection
        db_conn = getattr(g, 'db', None)
        if not db_conn:
            return error_response("Database connection not available", 500)

        if hasattr(db_conn, 'conn'):
            conn = db_conn.conn
        else:
            conn = db_conn

        cursor = conn.cursor()

        try:
            # Find all expired IPs that are still active
            cursor.execute("""
                SELECT id, ip_address, ip_cidr, added_by, expires_at
                FROM firewall_ip_blocking
                WHERE active = TRUE
                  AND expires_at IS NOT NULL
                  AND expires_at <= NOW()
            """)

            expired_ips = cursor.fetchall()

            if not expired_ips:
                return success_response({
                    "expired_count": 0,
                    "expired_ips": []
                }, "No expired IPs found")

            expired_count = 0
            expired_ip_list = []
            errors = []

            for ip_record in expired_ips:
                ip_id, ip_address, ip_cidr, added_by, expires_at = ip_record
                ip_str = str(ip_address)

                try:
                    # Remove from AWS Network Firewall
                    firewall_manager.remove_block_ips([ip_cidr or f"{ip_str}/32"])

                    # Try to remove from WAF (best effort)
                    try:
                        from actions.WAF import unblock_ip as waf_unblock_ip
                        waf_ip_set_name = os.getenv("WAF_BLOCKLIST_NAME", "Blocked")
                        waf_scope = os.getenv("AWS_SCOPE", "REGIONAL")
                        waf_unblock_ip(ip_str, ip_set_name=waf_ip_set_name, scope=waf_scope)
                    except Exception as waf_err:
                        logger.warning(f"WAF removal failed for expired IP {ip_str}: {waf_err}")

                    # Mark as inactive in database
                    cursor.execute("""
                        UPDATE firewall_ip_blocking
                        SET active = FALSE,
                            removed_at = NOW(),
                            removed_by = %s
                        WHERE id = %s
                    """, ['system_cron', ip_id])

                    # Log to audit trail
                    cursor.execute("""
                        INSERT INTO firewall_audit_log
                        (action, analyst, ip_address, details)
                        VALUES (%s, %s, %s, %s)
                    """, [
                        'expired',
                        'system_cron',
                        ip_str,
                        f'{{"expires_at": "{expires_at.isoformat()}", "auto_expired": true}}'
                    ])

                    expired_count += 1
                    expired_ip_list.append(ip_str)
                    logger.info(f"Expired and unblocked IP: {ip_str} (expired at {expires_at})")

                except Exception as e:
                    error_msg = f"Failed to expire IP {ip_str}: {str(e)}"
                    errors.append(error_msg)
                    logger.error(error_msg)

            conn.commit()

            message = f"Expired {expired_count} IP(s)"
            if errors:
                message += f" with {len(errors)} error(s)"

            return success_response({
                "expired_count": expired_count,
                "expired_ips": expired_ip_list,
                "errors": errors if errors else None
            }, message)

        finally:
            cursor.close()

    except Exception as e:
        logger.error(f"Expire blocked IPs error: {e}", exc_info=True)
        return error_response(str(e), 500)
