"""
Active Response Monitoring API

Provides endpoints for monitoring Active Response activities:
- Get currently active blocks
- Get block history
- Get AR statistics
"""

import os
import logging
from datetime import datetime, timedelta
from flask import jsonify, request
from . import bp
import requests
from requests.auth import HTTPBasicAuth
import psycopg2
from psycopg2.extras import RealDictCursor

logger = logging.getLogger(__name__)

# Wazuh Indexer configuration (requires environment variables)
WAZUH_INDEXER_URL = os.getenv('WAZUH_INDEXER_URL')
WAZUH_INDEXER_USER = os.getenv('WAZUH_INDEXER_USER')
WAZUH_INDEXER_PASSWORD = os.getenv('WAZUH_INDEXER_PASSWORD')

# Database configuration (requires environment variables)
DB_CONFIG = {
    'host': os.getenv('POSTGRES_HOST'),
    'database': os.getenv('POSTGRES_DB'),
    'user': os.getenv('POSTGRES_USER'),
    'password': os.getenv('POSTGRES_PASSWORD'),
    'port': os.getenv('POSTGRES_PORT', '5432')
}


def get_db_connection():
    """Get PostgreSQL database connection"""
    return psycopg2.connect(**DB_CONFIG)


def query_wazuh_indexer(query_body, index='wazuh-alerts-*'):
    """
    Query Wazuh Indexer (OpenSearch)

    Args:
        query_body: OpenSearch query DSL
        index: Index pattern to query

    Returns:
        dict: Query results
    """
    try:
        url = f"{WAZUH_INDEXER_URL}/{index}/_search"

        response = requests.post(
            url,
            json=query_body,
            auth=HTTPBasicAuth(WAZUH_INDEXER_USER, WAZUH_INDEXER_PASSWORD),
            verify=False,
            timeout=30
        )

        response.raise_for_status()
        return response.json()

    except requests.exceptions.RequestException as e:
        logger.error(f"Failed to query Wazuh Indexer: {str(e)}")
        raise


def calculate_time_remaining(blocked_at, timeout_seconds):
    """
    Calculate time remaining for an active block

    Args:
        blocked_at: ISO timestamp when block was created
        timeout_seconds: Block timeout duration

    Returns:
        int: Seconds remaining (0 if expired)
    """
    try:
        blocked_time = datetime.fromisoformat(blocked_at.replace('Z', '+00:00'))
        expires_at = blocked_time + timedelta(seconds=timeout_seconds)
        now = datetime.now(expires_at.tzinfo)

        remaining = (expires_at - now).total_seconds()
        return max(0, int(remaining))

    except Exception as e:
        logger.error(f"Error calculating time remaining: {str(e)}")
        return 0


def extract_triggering_rule(data):
    """
    Extract the original triggering rule ID from AR block alert data

    The rule ID is nested in: data.parameters.alert.rule.id
    This is the original rule that triggered Active Response (e.g., 5710, 5763)

    Args:
        data: The 'data' field from rule 651 alert

    Returns:
        str: Rule ID (e.g., "5710") or "Unknown" if not found
    """
    try:
        # Navigate through nested structure: data -> parameters -> alert -> rule -> id
        parameters = data.get('parameters', {})
        alert = parameters.get('alert', {})
        rule = alert.get('rule', {})
        rule_id = rule.get('id', 'Unknown')

        logger.debug(f"Extracted rule ID: {rule_id} from AR alert data")
        return rule_id

    except Exception as e:
        logger.debug(f"Could not extract triggering rule: {str(e)}")
        return 'Unknown'


@bp.route('/blocks/active', methods=['GET'])
def get_active_blocks():
    """
    Get currently active AR blocks (not yet expired)

    Query Parameters:
        - agent_id: Filter by specific agent
        - limit: Number of results (default 50)

    Returns:
        {
            "active_blocks": [
                {
                    "ip_address": "192.168.1.100",
                    "agent_id": "001",
                    "agent_name": "web-server-01",
                    "blocked_at": "2025-12-30T10:45:23Z",
                    "expires_at": "2025-12-30T11:15:23Z",
                    "time_remaining_seconds": 1234,
                    "command": "firewall-drop",
                    "triggered_by_rule": "5763",
                    "rule_description": "SSH brute force attack"
                }
            ],
            "total": 1
        }
    """
    try:
        agent_id = request.args.get('agent_id')
        limit = int(request.args.get('limit', 50))

        # Query for rule 651 (Host Blocked by Active Response)
        # Look back maximum timeout period (4 hours = 14400 seconds)
        query_body = {
            "query": {
                "bool": {
                    "must": [
                        {"match": {"rule.id": "651"}},
                        {"range": {"@timestamp": {"gte": "now-4h"}}}
                    ]
                }
            },
            "size": limit,
            "sort": [{"@timestamp": {"order": "desc"}}]
        }

        # Add agent filter if specified
        if agent_id:
            query_body["query"]["bool"]["must"].append(
                {"match": {"agent.id": agent_id}}
            )

        results = query_wazuh_indexer(query_body)

        active_blocks = []

        for hit in results.get('hits', {}).get('hits', []):
            source = hit['_source']

            # Extract block details
            data = source.get('data', {})
            rule = source.get('rule', {})
            agent = source.get('agent', {})

            ip_address = data.get('srcip', 'Unknown')
            command = data.get('command', 'firewall-drop')
            blocked_at = source.get('@timestamp')

            # Estimate timeout based on command (default 1800 seconds = 30 min)
            # In production, this should come from ossec.conf or database
            timeout_seconds = 1800

            time_remaining = calculate_time_remaining(blocked_at, timeout_seconds)

            # Only include blocks that haven't expired yet
            if time_remaining > 0:
                block_info = {
                    'ip_address': ip_address,
                    'agent_id': agent.get('id', 'Unknown'),
                    'agent_name': agent.get('name', 'Unknown'),
                    'blocked_at': blocked_at,
                    'expires_at': (
                        datetime.fromisoformat(blocked_at.replace('Z', '+00:00')) +
                        timedelta(seconds=timeout_seconds)
                    ).isoformat(),
                    'time_remaining_seconds': time_remaining,
                    'command': command,
                    'triggered_by_rule': extract_triggering_rule(data),
                    'rule_description': rule.get('description', 'Active Response Block')
                }

                active_blocks.append(block_info)

        return jsonify({
            'active_blocks': active_blocks,
            'total': len(active_blocks)
        }), 200

    except Exception as e:
        logger.error(f"Error getting active blocks: {str(e)}")
        return jsonify({'error': str(e)}), 500


@bp.route('/blocks/history', methods=['GET'])
def get_blocks_history():
    """
    Get AR block history with pagination

    Query Parameters:
        - days: Number of days to look back (default 7)
        - page: Page number (default 1)
        - page_size: Results per page (default 50)
        - agent_id: Filter by agent
        - ip_address: Filter by IP

    Returns:
        {
            "blocks": [
                {
                    "ip_address": "192.168.1.100",
                    "agent_id": "001",
                    "agent_name": "web-server-01",
                    "blocked_at": "2025-12-30T10:45:23Z",
                    "command": "firewall-drop",
                    "triggered_by_rule": "5763",
                    "rule_description": "SSH brute force attack"
                }
            ],
            "total": 156,
            "page": 1,
            "page_size": 50,
            "total_pages": 4
        }
    """
    try:
        days = int(request.args.get('days', 7))
        page = int(request.args.get('page', 1))
        page_size = int(request.args.get('page_size', 50))
        agent_id = request.args.get('agent_id')
        ip_address = request.args.get('ip_address')

        # Build query
        must_conditions = [
            {"match": {"rule.id": "651"}},
            {"range": {"@timestamp": {"gte": f"now-{days}d"}}}
        ]

        if agent_id:
            must_conditions.append({"match": {"agent.id": agent_id}})

        if ip_address:
            must_conditions.append({"match": {"data.srcip": ip_address}})

        # Calculate pagination
        from_index = (page - 1) * page_size

        query_body = {
            "query": {
                "bool": {
                    "must": must_conditions
                }
            },
            "from": from_index,
            "size": page_size,
            "sort": [{"@timestamp": {"order": "desc"}}]
        }

        results = query_wazuh_indexer(query_body)

        blocks = []

        for hit in results.get('hits', {}).get('hits', []):
            source = hit['_source']
            data = source.get('data', {})
            rule = source.get('rule', {})
            agent = source.get('agent', {})

            block_info = {
                'ip_address': data.get('srcip', 'Unknown'),
                'agent_id': agent.get('id', 'Unknown'),
                'agent_name': agent.get('name', 'Unknown'),
                'blocked_at': source.get('@timestamp'),
                'command': data.get('command', 'firewall-drop'),
                'triggered_by_rule': extract_triggering_rule(data),
                'rule_description': rule.get('description', 'Active Response Block')
            }

            blocks.append(block_info)

        total_hits = results.get('hits', {}).get('total', {}).get('value', 0)
        total_pages = (total_hits + page_size - 1) // page_size

        return jsonify({
            'blocks': blocks,
            'total': total_hits,
            'page': page,
            'page_size': page_size,
            'total_pages': total_pages
        }), 200

    except Exception as e:
        logger.error(f"Error getting block history: {str(e)}")
        return jsonify({'error': str(e)}), 500


@bp.route('/stats', methods=['GET'])
def get_ar_stats():
    """
    Get Active Response statistics

    Returns:
        {
            "blocks_today": 45,
            "blocks_this_week": 312,
            "active_blocks_now": 3,
            "top_blocked_ips": [
                {"ip": "192.168.1.100", "count": 23},
                {"ip": "10.5.3.44", "count": 15}
            ],
            "top_targeted_agents": [
                {"agent_id": "001", "agent_name": "web-server-01", "count": 89},
                {"agent_id": "002", "agent_name": "ssh-bastion", "count": 67}
            ],
            "blocks_by_rule": {
                "5763": {"count": 234, "description": "SSH brute force"},
                "31103": {"count": 78, "description": "Web attack"}
            }
        }
    """
    try:
        # Get blocks today
        today_query = {
            "query": {
                "bool": {
                    "must": [
                        {"match": {"rule.id": "651"}},
                        {"range": {"@timestamp": {"gte": "now-1d"}}}
                    ]
                }
            },
            "size": 0
        }

        today_result = query_wazuh_indexer(today_query)
        blocks_today = today_result.get('hits', {}).get('total', {}).get('value', 0)

        # Get blocks this week
        week_query = {
            "query": {
                "bool": {
                    "must": [
                        {"match": {"rule.id": "651"}},
                        {"range": {"@timestamp": {"gte": "now-7d"}}}
                    ]
                }
            },
            "size": 0
        }

        week_result = query_wazuh_indexer(week_query)
        blocks_this_week = week_result.get('hits', {}).get('total', {}).get('value', 0)

        # Get top blocked IPs (aggregation)
        ip_agg_query = {
            "query": {
                "bool": {
                    "must": [
                        {"match": {"rule.id": "651"}},
                        {"range": {"@timestamp": {"gte": "now-7d"}}}
                    ]
                }
            },
            "size": 0,
            "aggs": {
                "top_ips": {
                    "terms": {
                        "field": "data.srcip.keyword",
                        "size": 10
                    }
                }
            }
        }

        ip_result = query_wazuh_indexer(ip_agg_query)
        top_blocked_ips = [
            {"ip": bucket['key'], "count": bucket['doc_count']}
            for bucket in ip_result.get('aggregations', {}).get('top_ips', {}).get('buckets', [])
        ]

        # Get top targeted agents
        agent_agg_query = {
            "query": {
                "bool": {
                    "must": [
                        {"match": {"rule.id": "651"}},
                        {"range": {"@timestamp": {"gte": "now-7d"}}}
                    ]
                }
            },
            "size": 0,
            "aggs": {
                "top_agents": {
                    "terms": {
                        "field": "agent.id.keyword",
                        "size": 10
                    },
                    "aggs": {
                        "agent_name": {
                            "terms": {
                                "field": "agent.name.keyword",
                                "size": 1
                            }
                        }
                    }
                }
            }
        }

        agent_result = query_wazuh_indexer(agent_agg_query)
        top_targeted_agents = []

        for bucket in agent_result.get('aggregations', {}).get('top_agents', {}).get('buckets', []):
            agent_name_buckets = bucket.get('agent_name', {}).get('buckets', [])
            agent_name = agent_name_buckets[0]['key'] if agent_name_buckets else 'Unknown'

            top_targeted_agents.append({
                "agent_id": bucket['key'],
                "agent_name": agent_name,
                "count": bucket['doc_count']
            })

        # Calculate active blocks (last 4 hours, not expired)
        active_query = {
            "query": {
                "bool": {
                    "must": [
                        {"match": {"rule.id": "651"}},
                        {"range": {"@timestamp": {"gte": "now-4h"}}}
                    ]
                }
            },
            "size": 0
        }

        active_result = query_wazuh_indexer(active_query)
        active_blocks_now = active_result.get('hits', {}).get('total', {}).get('value', 0)

        return jsonify({
            'blocks_today': blocks_today,
            'blocks_this_week': blocks_this_week,
            'active_blocks_now': active_blocks_now,
            'top_blocked_ips': top_blocked_ips,
            'top_targeted_agents': top_targeted_agents
        }), 200

    except Exception as e:
        logger.error(f"Error getting AR statistics: {str(e)}")
        return jsonify({'error': str(e)}), 500


# ============================================================================
# UNIFIED AUDIT TRAIL - Merges Wazuh Indexer + PostgreSQL + Calculated Events
# ============================================================================

def estimate_timeout(rule_id):
    """
    Estimate timeout duration based on rule ID
    Based on ossec.conf active-response configuration
    """
    timeout_map = {
        '5763': 1800,   # SSH brute force - 30 min
        '5710': 1800,   # SSH invalid user - 30 min
        '5711': 2400,   # Port scan - 40 min
        '5712': 2400,   # Port scan - 40 min
        '31103': 3600,  # Web attack - 60 min
        '5503': 600,    # Account lockout - 10 min
        '5551': 600
    }
    return timeout_map.get(str(rule_id), 1800)  # Default 30 min


def get_rule_description(rule_id):
    """Get human-readable rule description"""
    rule_map = {
        '5763': 'SSH authentication failure (brute force)',
        '5710': 'SSH: Attempt to login using a non-existent user',
        '5711': 'Port scanning detected',
        '5712': 'Port scanning detected',
        '31103': 'Web application attack (SQLi/XSS/RCE)',
        '5503': 'Multiple failed login attempts',
        '5551': 'Multiple authentication failures',
        'Unknown': 'Active Response trigger'
    }
    return rule_map.get(str(rule_id), 'Active Response trigger')


def fetch_manual_actions_from_db(days, agent_id=None, ip_address=None):
    """Fetch manual actions from ar_manual_actions table"""
    try:
        conn = get_db_connection()
        cursor = conn.cursor(cursor_factory=RealDictCursor)

        query = """
            SELECT id, action_type, ip_address, agent_id, timeout_seconds,
                   reason, analyst, created_at
            FROM ar_manual_actions
            WHERE created_at >= NOW() - INTERVAL '%s days'
        """
        params = [days]

        if agent_id:
            query += " AND agent_id = %s"
            params.append(agent_id)

        if ip_address:
            query += " AND ip_address = %s"
            params.append(ip_address)

        query += " ORDER BY created_at DESC"

        cursor.execute(query, params)
        actions = cursor.fetchall()

        cursor.close()
        conn.close()

        return actions

    except Exception as e:
        logger.error(f"Error fetching manual actions from DB: {str(e)}")
        return []


def get_agent_name_from_cache(agent_id):
    """
    Get agent name from cache or return formatted agent ID
    TODO: Implement agent name lookup via Wazuh API if needed
    """
    # For now, return a formatted agent ID
    # In production, you could query Wazuh API or maintain a cache
    return f"Agent-{agent_id}"


def calculate_block_status(blocked_at, timeout_seconds):
    """Determine if block is active or expired"""
    try:
        blocked_time = datetime.fromisoformat(blocked_at.replace('Z', '+00:00'))
        expires_at = blocked_time + timedelta(seconds=timeout_seconds)
        now = datetime.now(blocked_time.tzinfo)

        if now < expires_at:
            return 'active'
        else:
            return 'expired'
    except Exception as e:
        logger.debug(f"Error calculating block status: {str(e)}")
        return 'unknown'


def calculate_expirations(wazuh_blocks, manual_actions):
    """
    Calculate expiration events for blocks that weren't manually unblocked

    Logic:
    1. For each Wazuh block, calculate when it should expire
    2. Check if there was a manual unblock before expiration
    3. If no manual unblock, create expiration event
    """
    expirations = []

    # Group manual unblocks by IP and agent
    manual_unblocks = {}
    for action in manual_actions:
        if action['action_type'] == 'unblock':
            key = f"{action['ip_address']}_{action['agent_id']}"
            if key not in manual_unblocks:
                manual_unblocks[key] = []
            manual_unblocks[key].append(action['created_at'])

    for block in wazuh_blocks:
        try:
            data = block.get('_source', {}).get('data', {})
            agent = block.get('_source', {}).get('agent', {})

            ip = data.get('srcip', 'Unknown')
            agent_id = agent.get('id', 'Unknown')
            blocked_at_str = block.get('_source', {}).get('@timestamp')

            if not blocked_at_str:
                continue

            blocked_at = datetime.fromisoformat(blocked_at_str.replace('Z', '+00:00'))
            rule_id = extract_triggering_rule(data)
            timeout = estimate_timeout(rule_id)
            expires_at = blocked_at + timedelta(seconds=timeout)

            key = f"{ip}_{agent_id}"

            # Check if there was a manual unblock
            manually_unblocked = False
            if key in manual_unblocks:
                for unblock_time in manual_unblocks[key]:
                    # Ensure unblock_time is timezone-aware
                    if isinstance(unblock_time, datetime):
                        if unblock_time.tzinfo is None:
                            unblock_time = unblock_time.replace(tzinfo=blocked_at.tzinfo)
                        if blocked_at < unblock_time < expires_at:
                            manually_unblocked = True
                            break

            # If not manually unblocked and expiration time has passed, create expiration event
            now = datetime.now(blocked_at.tzinfo)
            if not manually_unblocked and expires_at < now:
                expirations.append({
                    'id': f"expiration-{block.get('_id', 'unknown')}",
                    'timestamp': expires_at.isoformat(),
                    'action_type': 'expired',
                    'ip_address': ip,
                    'agent_id': agent_id,
                    'agent_name': agent.get('name', 'Unknown'),
                    'performed_by': 'System',
                    'performed_via': 'timeout',
                    'reason': f"Timeout period ({timeout} seconds) elapsed",
                    'triggered_by_rule': rule_id,
                    'command': 'firewall-drop',
                    'duration_seconds': timeout,
                    'status': 'expired'
                })

        except Exception as e:
            logger.debug(f"Error calculating expiration for block: {str(e)}")
            continue

    return expirations


def aggregate_duplicate_blocks(wazuh_blocks):
    """
    Aggregate consecutive AR blocks for same IP within 5-second window

    Returns aggregated blocks with trigger_count and trigger_events metadata

    Args:
        wazuh_blocks: List of Wazuh Indexer hits containing AR block alerts

    Returns:
        List of aggregated blocks with metadata:
        - block: Original hit object
        - trigger_count: Number of triggers within 5-second window
        - trigger_timestamps: List of timestamps for all triggers
    """
    aggregated = []
    grouped = {}  # Key: (srcip, agent_id), Value: list of blocks

    for block in wazuh_blocks:
        source = block['_source']
        data = source.get('data', {})
        agent = source.get('agent', {})

        srcip = data.get('srcip', 'Unknown')
        agent_id = agent.get('id', 'Unknown')
        timestamp = source.get('@timestamp')

        key = (srcip, agent_id)

        if key not in grouped:
            grouped[key] = []
        grouped[key].append({
            'block': block,
            'timestamp': timestamp
        })

    # For each group, aggregate blocks within 5-second window
    for key, blocks in grouped.items():
        blocks.sort(key=lambda x: x['timestamp'])

        i = 0
        while i < len(blocks):
            current = blocks[i]
            current_time = datetime.fromisoformat(current['timestamp'].replace('Z', '+00:00'))

            # Find all blocks within 5 seconds
            window = [current]
            j = i + 1
            while j < len(blocks):
                next_time = datetime.fromisoformat(blocks[j]['timestamp'].replace('Z', '+00:00'))
                if (next_time - current_time).total_seconds() <= 5:
                    window.append(blocks[j])
                    j += 1
                else:
                    break

            # Create aggregated entry
            primary = window[0]['block']
            aggregated.append({
                'block': primary,
                'trigger_count': len(window),
                'trigger_timestamps': [w['timestamp'] for w in window]
            })

            i = j

    return aggregated


@bp.route('/audit-trail', methods=['GET'])
def get_unified_audit_trail():
    """
    Get unified audit trail combining:
    - Automatic blocks from Wazuh Indexer (rule 651)
    - Manual actions from PostgreSQL (ar_manual_actions)
    - Calculated timeout expirations

    Query Parameters:
        - days: Number of days to look back (default 7)
        - page: Page number (default 1)
        - page_size: Results per page (default 50)
        - agent_id: Filter by agent
        - ip_address: Filter by IP
        - action_type: Filter by action type (block, unblock, expired, all)

    Returns:
        {
            "audit_trail": [...],
            "total": 156,
            "page": 1,
            "page_size": 50,
            "total_pages": 4
        }
    """
    try:
        days = int(request.args.get('days', 7))
        page = int(request.args.get('page', 1))
        page_size = int(request.args.get('page_size', 50))
        agent_id = request.args.get('agent_id')
        ip_address = request.args.get('ip_address')
        action_type_filter = request.args.get('action_type', 'all')

        audit_entries = []

        # 1. Fetch automatic blocks from Wazuh Indexer
        must_conditions = [
            {"match": {"rule.id": "651"}},
            {"range": {"@timestamp": {"gte": f"now-{days}d"}}}
        ]

        if agent_id:
            must_conditions.append({"match": {"agent.id": agent_id}})

        if ip_address:
            must_conditions.append({"match": {"data.srcip": ip_address}})

        wazuh_query = {
            "query": {
                "bool": {
                    "must": must_conditions
                }
            },
            "size": 1000,  # Fetch up to 1000 blocks for calculation
            "sort": [{"@timestamp": {"order": "desc"}}]
        }

        wazuh_results = query_wazuh_indexer(wazuh_query)
        wazuh_blocks = wazuh_results.get('hits', {}).get('hits', [])

        # Aggregate duplicate blocks within 5-second window
        aggregated_blocks = aggregate_duplicate_blocks(wazuh_blocks)

        # Process aggregated Wazuh blocks
        for agg_entry in aggregated_blocks:
            try:
                block = agg_entry['block']
                trigger_count = agg_entry['trigger_count']
                trigger_timestamps = agg_entry['trigger_timestamps']

                source = block['_source']
                data = source.get('data', {})
                rule = source.get('rule', {})
                agent = source.get('agent', {})

                rule_id = extract_triggering_rule(data)
                timeout = estimate_timeout(rule_id)
                blocked_at = source.get('@timestamp')

                entry = {
                    'id': block['_id'],
                    'timestamp': blocked_at,
                    'action_type': 'block',
                    'ip_address': data.get('srcip', 'Unknown'),
                    'agent_id': agent.get('id', 'Unknown'),
                    'agent_name': agent.get('name', 'Unknown'),
                    'performed_by': 'System',
                    'performed_via': 'automatic',
                    'reason': f"Triggered by rule {rule_id}: {get_rule_description(rule_id)}",
                    'triggered_by_rule': rule_id,
                    'command': data.get('command', 'firewall-drop'),
                    'duration_seconds': timeout,
                    'status': calculate_block_status(blocked_at, timeout),
                    'trigger_count': trigger_count,
                    'trigger_timestamps': trigger_timestamps if trigger_count > 1 else None
                }

                audit_entries.append(entry)
            except Exception as e:
                logger.debug(f"Error processing Wazuh block: {str(e)}")
                continue

        # 2. Fetch manual actions from PostgreSQL
        manual_actions = fetch_manual_actions_from_db(days, agent_id, ip_address)

        for action in manual_actions:
            try:
                audit_entries.append({
                    'id': str(action['id']),
                    'timestamp': action['created_at'].isoformat(),
                    'action_type': action['action_type'],  # 'block' or 'unblock'
                    'ip_address': action['ip_address'],
                    'agent_id': action['agent_id'],
                    'agent_name': get_agent_name_from_cache(action['agent_id']),
                    'performed_by': action['analyst'],
                    'performed_via': 'manual',
                    'reason': action['reason'],
                    'triggered_by_rule': None,
                    'command': 'firewall-drop',
                    'duration_seconds': action.get('timeout_seconds'),
                    'status': 'completed'
                })
            except Exception as e:
                logger.debug(f"Error processing manual action: {str(e)}")
                continue

        # 3. Calculate timeout expirations
        expirations = calculate_expirations(wazuh_blocks, manual_actions)
        audit_entries.extend(expirations)

        # 4. Sort all entries chronologically (newest first)
        audit_entries.sort(key=lambda x: x['timestamp'], reverse=True)

        # 5. Apply action type filter
        if action_type_filter and action_type_filter != 'all':
            audit_entries = [e for e in audit_entries if e['action_type'] == action_type_filter]

        # 6. Paginate
        total = len(audit_entries)
        start = (page - 1) * page_size
        end = start + page_size
        paginated_entries = audit_entries[start:end]

        total_pages = (total + page_size - 1) // page_size if total > 0 else 1

        return jsonify({
            'audit_trail': paginated_entries,
            'total': total,
            'page': page,
            'page_size': page_size,
            'total_pages': total_pages
        }), 200

    except Exception as e:
        logger.error(f"Error getting unified audit trail: {str(e)}")
        return jsonify({'error': str(e)}), 500
