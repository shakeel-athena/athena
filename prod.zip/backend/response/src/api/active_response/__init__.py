"""
Active Response API Blueprint

Provides REST API endpoints for managing Wazuh Active Response configuration.
"""

from flask import Blueprint

# Create blueprint
bp = Blueprint('active_response', __name__, url_prefix='/api/active-response')

# Import routes
from . import whitelist
from . import monitoring
from . import actions
from . import advanced_monitoring  # Advanced SOC features: IP aggregation, threat scoring, attack timeline
