"""
Active Response Whitelist API

CRUD operations for managing Active Response IP whitelist.
"""

import os
import sys
import ipaddress
from datetime import datetime
from flask import jsonify, request
from . import bp

# Add project root to path for imports
project_root = os.path.abspath(os.path.join(os.path.dirname(__file__), '../../../..'))
sys.path.insert(0, project_root)

# Import database connection (will be provided by app context)
import psycopg2
from psycopg2.extras import RealDictCursor


def get_db_connection():
    """Get PostgreSQL database connection from environment variables (required)"""
    return psycopg2.connect(
        host=os.getenv('POSTGRES_HOST'),
        database=os.getenv('POSTGRES_DB'),
        user=os.getenv('POSTGRES_USER'),
        password=os.getenv('POSTGRES_PASSWORD'),
        port=os.getenv('POSTGRES_PORT', '5432')
    )


def validate_ip_address(ip_str):
    """
    Validate IP address or CIDR range

    Returns:
        tuple: (is_valid, ip_type, error_message)
    """
    try:
        # Try parsing as CIDR
        network = ipaddress.ip_network(ip_str, strict=False)

        # Check if it's a single IP or a network
        if '/' in ip_str:
            return True, 'cidr', None
        else:
            return True, 'single', None

    except ValueError as e:
        return False, None, str(e)


@bp.route('/whitelist', methods=['GET'])
def get_whitelist():
    """
    Get all whitelisted IPs

    Query Parameters:
        status: Filter by approval_status (approved, pending, rejected)

    Returns:
        JSON array of whitelist entries
    """
    try:
        status_filter = request.args.get('status', 'approved')

        conn = get_db_connection()
        cursor = conn.cursor(cursor_factory=RealDictCursor)

        if status_filter == 'all':
            cursor.execute("""
                SELECT id, ip_address, ip_type, description, created_by,
                       approved_by, approval_status, created_at, approved_at
                FROM ar_whitelist
                ORDER BY created_at DESC
            """)
        else:
            cursor.execute("""
                SELECT id, ip_address, ip_type, description, created_by,
                       approved_by, approval_status, created_at, approved_at
                FROM ar_whitelist
                WHERE approval_status = %s
                ORDER BY created_at DESC
            """, (status_filter,))

        entries = cursor.fetchall()
        cursor.close()
        conn.close()

        # Convert datetime objects to ISO format
        for entry in entries:
            if entry['created_at']:
                entry['created_at'] = entry['created_at'].isoformat()
            if entry['approved_at']:
                entry['approved_at'] = entry['approved_at'].isoformat()

        return jsonify({
            'success': True,
            'total': len(entries),
            'whitelist': entries
        }), 200

    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500


@bp.route('/whitelist', methods=['POST'])
def add_to_whitelist():
    """
    Add IP to whitelist

    Request Body:
        {
            "ip_address": "10.0.5.100" or "10.0.0.0/8",
            "description": "Internal CI/CD server",
            "created_by": "john.doe",
            "auto_approve": false (optional, default: false)
        }

    Returns:
        JSON with created entry
    """
    try:
        data = request.get_json()

        # Validate required fields
        if not data or 'ip_address' not in data:
            return jsonify({
                'success': False,
                'error': 'Missing required field: ip_address'
            }), 400

        if 'description' not in data:
            return jsonify({
                'success': False,
                'error': 'Missing required field: description'
            }), 400

        if 'created_by' not in data:
            return jsonify({
                'success': False,
                'error': 'Missing required field: created_by'
            }), 400

        # Validate IP address format
        is_valid, ip_type, error_msg = validate_ip_address(data['ip_address'])

        if not is_valid:
            return jsonify({
                'success': False,
                'error': f'Invalid IP address format: {error_msg}'
            }), 400

        # Check if IP already exists
        conn = get_db_connection()
        cursor = conn.cursor()

        cursor.execute("""
            SELECT id FROM ar_whitelist WHERE ip_address = %s
        """, (data['ip_address'],))

        existing = cursor.fetchone()

        if existing:
            cursor.close()
            conn.close()
            return jsonify({
                'success': False,
                'error': 'IP address already exists in whitelist'
            }), 409

        # Auto-approve if requested (requires admin privileges)
        auto_approve = data.get('auto_approve', False)
        approval_status = 'approved' if auto_approve else 'pending'
        approved_by = data['created_by'] if auto_approve else None
        approved_at = datetime.now() if auto_approve else None

        # Insert new entry
        cursor.execute("""
            INSERT INTO ar_whitelist
            (ip_address, ip_type, description, created_by, approved_by, approval_status, approved_at)
            VALUES (%s, %s, %s, %s, %s, %s, %s)
            RETURNING id, ip_address, ip_type, description, created_by,
                      approved_by, approval_status, created_at, approved_at
        """, (
            data['ip_address'],
            ip_type,
            data['description'],
            data['created_by'],
            approved_by,
            approval_status,
            approved_at
        ))

        new_entry = cursor.fetchone()
        conn.commit()
        cursor.close()
        conn.close()

        # Convert to dict
        entry_dict = {
            'id': str(new_entry[0]),
            'ip_address': new_entry[1],
            'ip_type': new_entry[2],
            'description': new_entry[3],
            'created_by': new_entry[4],
            'approved_by': new_entry[5],
            'approval_status': new_entry[6],
            'created_at': new_entry[7].isoformat(),
            'approved_at': new_entry[8].isoformat() if new_entry[8] else None
        }

        return jsonify({
            'success': True,
            'message': 'IP added to whitelist successfully',
            'entry': entry_dict,
            'needs_sync': approval_status == 'approved'
        }), 201

    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500


@bp.route('/whitelist/<entry_id>', methods=['DELETE'])
def remove_from_whitelist(entry_id):
    """
    Remove IP from whitelist

    Path Parameters:
        entry_id: UUID of the whitelist entry

    Returns:
        JSON with success status
    """
    try:
        conn = get_db_connection()
        cursor = conn.cursor()

        # Check if entry exists
        cursor.execute("""
            SELECT ip_address FROM ar_whitelist WHERE id = %s
        """, (entry_id,))

        entry = cursor.fetchone()

        if not entry:
            cursor.close()
            conn.close()
            return jsonify({
                'success': False,
                'error': 'Whitelist entry not found'
            }), 404

        # Delete entry
        cursor.execute("""
            DELETE FROM ar_whitelist WHERE id = %s
        """, (entry_id,))

        conn.commit()
        cursor.close()
        conn.close()

        return jsonify({
            'success': True,
            'message': f'IP {entry[0]} removed from whitelist',
            'needs_sync': True
        }), 200

    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500


@bp.route('/whitelist/<entry_id>/approve', methods=['PUT'])
def approve_whitelist_entry(entry_id):
    """
    Approve pending whitelist entry

    Path Parameters:
        entry_id: UUID of the whitelist entry

    Request Body:
        {
            "approved_by": "admin_username"
        }

    Returns:
        JSON with updated entry
    """
    try:
        data = request.get_json()

        if not data or 'approved_by' not in data:
            return jsonify({
                'success': False,
                'error': 'Missing required field: approved_by'
            }), 400

        conn = get_db_connection()
        cursor = conn.cursor(cursor_factory=RealDictCursor)

        # Update entry
        cursor.execute("""
            UPDATE ar_whitelist
            SET approval_status = 'approved',
                approved_by = %s,
                approved_at = NOW()
            WHERE id = %s
            RETURNING id, ip_address, ip_type, description, created_by,
                      approved_by, approval_status, created_at, approved_at
        """, (data['approved_by'], entry_id))

        updated_entry = cursor.fetchone()

        if not updated_entry:
            cursor.close()
            conn.close()
            return jsonify({
                'success': False,
                'error': 'Whitelist entry not found'
            }), 404

        conn.commit()
        cursor.close()
        conn.close()

        # Convert datetime objects
        if updated_entry['created_at']:
            updated_entry['created_at'] = updated_entry['created_at'].isoformat()
        if updated_entry['approved_at']:
            updated_entry['approved_at'] = updated_entry['approved_at'].isoformat()

        return jsonify({
            'success': True,
            'message': 'Whitelist entry approved',
            'entry': updated_entry,
            'needs_sync': True
        }), 200

    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500


@bp.route('/whitelist/<entry_id>/reject', methods=['PUT'])
def reject_whitelist_entry(entry_id):
    """
    Reject pending whitelist entry

    Path Parameters:
        entry_id: UUID of the whitelist entry

    Request Body:
        {
            "approved_by": "admin_username"
        }

    Returns:
        JSON with updated entry
    """
    try:
        data = request.get_json()

        if not data or 'approved_by' not in data:
            return jsonify({
                'success': False,
                'error': 'Missing required field: approved_by'
            }), 400

        conn = get_db_connection()
        cursor = conn.cursor(cursor_factory=RealDictCursor)

        # Update entry
        cursor.execute("""
            UPDATE ar_whitelist
            SET approval_status = 'rejected',
                approved_by = %s,
                approved_at = NOW()
            WHERE id = %s
            RETURNING id, ip_address, ip_type, description, created_by,
                      approved_by, approval_status, created_at, approved_at
        """, (data['approved_by'], entry_id))

        updated_entry = cursor.fetchone()

        if not updated_entry:
            cursor.close()
            conn.close()
            return jsonify({
                'success': False,
                'error': 'Whitelist entry not found'
            }), 404

        conn.commit()
        cursor.close()
        conn.close()

        # Convert datetime objects
        if updated_entry['created_at']:
            updated_entry['created_at'] = updated_entry['created_at'].isoformat()
        if updated_entry['approved_at']:
            updated_entry['approved_at'] = updated_entry['approved_at'].isoformat()

        return jsonify({
            'success': True,
            'message': 'Whitelist entry rejected',
            'entry': updated_entry
        }), 200

    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500
