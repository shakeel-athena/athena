"""
Advanced Active Response Monitoring API

Provides SOC-grade analytics and intelligence:
- IP-based aggregation (groups duplicate blocks)
- Threat scoring with risk levels
- Attack timeline visualization
- MITRE ATT&CK mapping
- Complete IP intelligence profiles
"""

import os
import logging
from datetime import datetime, timedelta
from flask import jsonify, request
from collections import defaultdict
from . import bp
import requests
from requests.auth import HTTPBasicAuth
import psycopg2
from psycopg2.extras import RealDictCursor

# Import utilities
import sys
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '../../'))
from utils.mitre_mapping import (
    get_mitre_mapping,
    classify_attack_stage,
    build_attack_kill_chain,
    get_attack_stage_color
)
from utils.threat_scoring import (
    calculate_threat_score,
    calculate_attack_velocity,
    get_recommended_actions
)

logger = logging.getLogger(__name__)

# Wazuh Indexer configuration (requires environment variables)
WAZUH_INDEXER_URL = os.getenv('WAZUH_INDEXER_URL')
WAZUH_INDEXER_USER = os.getenv('WAZUH_INDEXER_USER')
WAZUH_INDEXER_PASSWORD = os.getenv('WAZUH_INDEXER_PASSWORD')

# Database configuration (requires environment variables)
DB_CONFIG = {
    'host': os.getenv('POSTGRES_HOST'),
    'database': os.getenv('POSTGRES_DB'),
    'user': os.getenv('POSTGRES_USER'),
    'password': os.getenv('POSTGRES_PASSWORD'),
    'port': os.getenv('POSTGRES_PORT', '5432')
}


def get_db_connection():
    """Get PostgreSQL database connection"""
    return psycopg2.connect(**DB_CONFIG)


# Map of AR-triggering rules for timeline queries
AR_TRIGGER_RULES = {
    'ssh': ['5710', '5763', '5712', '5711'],  # SSH brute force
    'port_scan': ['5401', '5402', '5403', '5404'],  # Port scanning
    'rdp': ['60122'],  # RDP brute force
    'web': ['31103'],  # Web attacks (expand based on need)
    'account': ['5503', '5551'],  # Account lockout
    'ar_block': ['651']  # Active Response execution
}

# Flatten for query
ALL_AR_RULES = []
for category, rules in AR_TRIGGER_RULES.items():
    ALL_AR_RULES.extend(rules)


def aggregate_temporal_blocks(wazuh_blocks):
    """
    Aggregate consecutive AR blocks for same IP within 5-second window

    This prevents race conditions where multiple AR alerts trigger
    before the firewall rule is fully applied.

    Args:
        wazuh_blocks: List of Wazuh Indexer hits containing AR block alerts

    Returns:
        List of aggregated blocks with metadata:
        - block: Original hit object (first in window)
        - trigger_count: Number of triggers within 5-second window
        - trigger_timestamps: List of timestamps for all triggers
    """
    aggregated = []
    grouped = {}  # Key: (srcip, agent_id), Value: list of blocks

    for block in wazuh_blocks:
        source = block['_source']
        data = source.get('data', {})
        agent = source.get('agent', {})

        srcip = data.get('srcip', 'Unknown')
        agent_id = agent.get('id', 'Unknown')
        timestamp = source.get('@timestamp')

        key = (srcip, agent_id)

        if key not in grouped:
            grouped[key] = []
        grouped[key].append({
            'block': block,
            'timestamp': timestamp
        })

    # For each group, aggregate blocks within 5-second window
    for key, blocks in grouped.items():
        blocks.sort(key=lambda x: x['timestamp'])

        i = 0
        while i < len(blocks):
            current = blocks[i]
            current_time = datetime.fromisoformat(current['timestamp'].replace('Z', '+00:00'))

            # Find all blocks within 5 seconds
            window = [current]
            j = i + 1
            while j < len(blocks):
                next_time = datetime.fromisoformat(blocks[j]['timestamp'].replace('Z', '+00:00'))
                if (next_time - current_time).total_seconds() <= 5:
                    window.append(blocks[j])
                    j += 1
                else:
                    break

            # Create aggregated entry
            primary = window[0]['block']
            aggregated.append({
                'block': primary,
                'trigger_count': len(window),
                'trigger_timestamps': [w['timestamp'] for w in window]
            })

            i = j

    return aggregated


def query_wazuh_indexer(query_body, index='wazuh-alerts-*'):
    """
    Query Wazuh Indexer (OpenSearch)

    Args:
        query_body: OpenSearch query DSL
        index: Index pattern to query

    Returns:
        dict: Query results
    """
    try:
        url = f"{WAZUH_INDEXER_URL}/{index}/_search"

        response = requests.post(
            url,
            json=query_body,
            auth=HTTPBasicAuth(WAZUH_INDEXER_USER, WAZUH_INDEXER_PASSWORD),
            verify=False,
            timeout=30
        )

        response.raise_for_status()
        return response.json()

    except requests.exceptions.RequestException as e:
        logger.error(f"Failed to query Wazuh Indexer: {str(e)}")
        raise


def extract_triggering_rule(data):
    """
    Extract the original triggering rule ID from AR block alert data

    Args:
        data: The 'data' field from rule 651 alert

    Returns:
        str: Rule ID (e.g., "5710") or "Unknown"
    """
    try:
        parameters = data.get('parameters', {})
        alert = parameters.get('alert', {})
        rule = alert.get('rule', {})
        rule_id = rule.get('id', 'Unknown')
        return rule_id

    except Exception as e:
        logger.debug(f"Could not extract triggering rule: {str(e)}")
        return 'Unknown'


@bp.route('/aggregated-incidents', methods=['GET'])
def get_aggregated_incidents():
    """
    Get IP-aggregated incidents with threat scoring

    Groups duplicate blocks from same IP and enriches with:
    - Threat score (0-100)
    - Risk level (Critical/High/Medium/Low)
    - MITRE techniques
    - Attack timeline
    - Recommended actions

    Query Parameters:
        - hours: Time window in hours (default 24)
        - min_blocks: Minimum blocks to show (default 1)
        - risk_level: Filter by risk (Critical, High, Medium, Low)

    Returns:
        {
            "incidents": [
                {
                    "ip_address": "192.168.1.100",
                    "block_count": 20,
                    "unique_rules": 2,
                    "rules_triggered": ["5710", "5712"],
                    "first_seen": "2025-12-31T10:15:30Z",
                    "last_seen": "2025-12-31T10:18:45Z",
                    "duration_minutes": 3.25,
                    "attack_velocity": 6.15,
                    "affected_agents": [
                        {"id": "003", "name": "trace9-vm", "count": 20}
                    ],
                    "threat_score": 85,
                    "risk_level": "Critical",
                    "priority": 1,
                    "mitre_techniques": [
                        {
                            "technique": "T1110.001",
                            "technique_name": "Brute Force: Password Guessing",
                            "tactic": "TA0006",
                            "tactic_name": "Credential Access"
                        }
                    ],
                    "attack_stages": ["reconnaissance", "execution"],
                    "recommended_actions": [...]
                }
            ],
            "total_incidents": 5,
            "total_blocks": 127,
            "high_risk_count": 2
        }
    """
    try:
        hours = int(request.args.get('hours', 24))
        min_blocks = int(request.args.get('min_blocks', 1))
        risk_filter = request.args.get('risk_level')

        # Query rule 651 (AR blocks) within time window
        query_body = {
            "query": {
                "bool": {
                    "must": [
                        {"match": {"rule.id": "651"}},
                        {"range": {"@timestamp": {"gte": f"now-{hours}h"}}}
                    ]
                }
            },
            "size": 1000,  # Fetch up to 1000 blocks for aggregation
            "sort": [{"@timestamp": {"order": "desc"}}]
        }

        results = query_wazuh_indexer(query_body)

        # STEP 1: Apply temporal aggregation (5-second window) to raw blocks
        # This groups rapid-fire blocks from same IP+agent within 5 seconds
        raw_blocks = results.get('hits', {}).get('hits', [])
        aggregated_blocks = aggregate_temporal_blocks(raw_blocks)

        # STEP 2: Aggregate by IP address using temporally-aggregated blocks
        ip_aggregation = defaultdict(lambda: {
            'blocks': [],
            'rules_triggered': [],
            'agents': defaultdict(int),
            'timestamps': []
        })

        for agg_block in aggregated_blocks:
            hit = agg_block['block']
            trigger_count = agg_block['trigger_count']
            trigger_timestamps = agg_block['trigger_timestamps']

            source = hit['_source']
            data = source.get('data', {})
            agent = source.get('agent', {})

            ip_address = data.get('srcip', 'Unknown')
            rule_id = extract_triggering_rule(data)
            timestamp = source.get('@timestamp')
            agent_id = agent.get('id', 'Unknown')
            agent_name = agent.get('name', 'Unknown')
            command = data.get('command', 'firewall-drop')

            # Aggregate data (using temporally-aggregated blocks)
            ip_aggregation[ip_address]['blocks'].append({
                'timestamp': timestamp,
                'rule_id': rule_id,
                'agent_id': agent_id,
                'agent_name': agent_name,
                'command': command,
                'trigger_count': trigger_count  # Preserve trigger count for future use
            })

            ip_aggregation[ip_address]['rules_triggered'].append(rule_id)
            ip_aggregation[ip_address]['agents'][f"{agent_name}({agent_id})"] += 1

            # Add ALL trigger timestamps for accurate duration calculation
            # If block is aggregated (multiple AR blocks within 5-sec window),
            # include all timestamps to calculate correct first_seen/last_seen
            if trigger_count > 1 and trigger_timestamps:
                for ts in trigger_timestamps:
                    ip_aggregation[ip_address]['timestamps'].append(ts)
            else:
                ip_aggregation[ip_address]['timestamps'].append(timestamp)

        # Query PostgreSQL for manual unblocks within the time window
        # This ensures we don't show IPs as "active" if they were manually unblocked
        manually_unblocked_ips = {}
        try:
            conn = get_db_connection()
            cursor = conn.cursor(cursor_factory=RealDictCursor)
            cursor.execute("""
                SELECT ip_address, MAX(created_at) as unblock_time
                FROM ar_manual_actions
                WHERE action_type = 'unblock'
                AND created_at >= NOW() - INTERVAL '%s hours'
                GROUP BY ip_address
            """, (hours,))

            for row in cursor.fetchall():
                manually_unblocked_ips[row['ip_address']] = row['unblock_time']

            cursor.close()
            conn.close()
        except Exception as e:
            logger.error(f"Error querying manual unblocks: {str(e)}")
            # Continue without filtering - better to show false positives than miss real threats

        # Build incident list with threat scoring
        incidents = []

        for ip_address, data in ip_aggregation.items():
            block_count = len(data['blocks'])

            # Filter by minimum blocks
            if block_count < min_blocks:
                continue

            # Extract unique rules
            rules_triggered = list(set(data['rules_triggered']))
            unique_rules_count = len(rules_triggered)

            # Calculate time window
            timestamps = sorted(data['timestamps'])
            first_seen = timestamps[0]
            last_seen = timestamps[-1]

            # Skip if IP was manually unblocked after its last block
            if ip_address in manually_unblocked_ips:
                unblock_time = manually_unblocked_ips[ip_address]
                # Convert last_seen to timezone-aware datetime for comparison
                last_seen_dt = datetime.fromisoformat(last_seen.replace('Z', '+00:00'))
                # Ensure unblock_time is timezone-aware
                if unblock_time.tzinfo is None:
                    from datetime import timezone
                    unblock_time = unblock_time.replace(tzinfo=timezone.utc)

                # If unblock happened after last block, exclude this IP from aggregated incidents
                if unblock_time > last_seen_dt:
                    logger.info(f"Excluding {ip_address} from aggregated incidents - manually unblocked at {unblock_time} (last block: {last_seen})")
                    continue

            # Calculate attack velocity
            attack_velocity = calculate_attack_velocity(
                first_seen, last_seen, block_count
            )

            # Calculate duration in minutes
            first_dt = datetime.fromisoformat(first_seen.replace('Z', '+00:00'))
            last_dt = datetime.fromisoformat(last_seen.replace('Z', '+00:00'))
            duration_minutes = (last_dt - first_dt).total_seconds() / 60

            # Build affected agents list
            affected_agents = [
                {'name': agent_name, 'count': count}
                for agent_name, count in data['agents'].items()
            ]

            # Calculate threat score
            threat_data = calculate_threat_score({
                'ip_address': ip_address,
                'block_count': block_count,
                'rules_triggered': rules_triggered,
                'unique_rules_count': unique_rules_count,
                'first_seen': first_seen,
                'last_seen': last_seen,
                'attack_velocity': attack_velocity
            }, include_reputation=True)

            # Apply risk level filter
            if risk_filter and threat_data['risk_level'] != risk_filter:
                continue

            # Extract MITRE techniques
            mitre_techniques = []
            attack_stages = set()

            for rule_id in rules_triggered:
                mitre = get_mitre_mapping(rule_id)
                mitre_techniques.append({
                    'rule_id': rule_id,
                    'technique': mitre['technique'],
                    'technique_name': mitre['technique_name'],
                    'tactic': mitre['tactic'],
                    'tactic_name': mitre['tactic_name'],
                    'severity': mitre['severity']
                })
                attack_stages.add(mitre['attack_stage'])

            # Build attack kill chain
            kill_chain = build_attack_kill_chain(rules_triggered)

            # Get recommended actions
            recommended_actions = get_recommended_actions(
                threat_data,
                {
                    'ip_address': ip_address,
                    'block_count': block_count,
                    'rules_triggered': rules_triggered
                }
            )

            # Build incident object
            incident = {
                'ip_address': ip_address,
                'block_count': block_count,
                'unique_rules': unique_rules_count,
                'rules_triggered': rules_triggered,
                'first_seen': first_seen,
                'last_seen': last_seen,
                'duration_minutes': round(duration_minutes, 2),
                'attack_velocity': round(attack_velocity, 2),
                'affected_agents': affected_agents,
                'threat_score': threat_data['threat_score'],
                'risk_level': threat_data['risk_level'],
                'priority': threat_data['priority'],
                'color': threat_data['color'],
                'score_breakdown': threat_data['breakdown'],
                'mitre_techniques': mitre_techniques,
                'attack_stages': list(attack_stages),
                'kill_chain': kill_chain,
                'recommended_actions': recommended_actions,
                'reputation_data': threat_data.get('reputation_data'),
                'total_events': block_count
            }

            incidents.append(incident)

        # Sort by threat score (highest first)
        incidents.sort(key=lambda x: (x['priority'], -x['threat_score']))

        # Calculate summary stats
        total_blocks = sum(inc['block_count'] for inc in incidents)
        high_risk_count = sum(1 for inc in incidents if inc['priority'] <= 2)

        return jsonify({
            'incidents': incidents,
            'total_incidents': len(incidents),
            'total_blocks': total_blocks,
            'high_risk_count': high_risk_count,
            'time_window_hours': hours
        }), 200

    except Exception as e:
        logger.error(f"Error getting aggregated incidents: {str(e)}")
        return jsonify({'error': str(e)}), 500


def deduplicate_timeline_events(hits):
    """
    Remove duplicate events from different log sources

    Wazuh often logs the same event in multiple places:
    - /var/log/auth.log
    - journald
    - syslog

    This function deduplicates events with same rule/agent/timestamp.
    Keeps the first occurrence (usually from auth.log).

    Args:
        hits: List of Wazuh Indexer hit objects

    Returns:
        List of deduplicated hits
    """
    seen = {}
    deduplicated = []

    for hit in hits:
        source = hit['_source']
        rule = source.get('rule', {})
        agent = source.get('agent', {})
        timestamp = source.get('@timestamp', '')

        rule_id = rule.get('id', 'Unknown')
        agent_id = agent.get('id', 'Unknown')

        # Create key: rule + agent + timestamp (second precision)
        # This ignores milliseconds to catch duplicates from different log sources
        timestamp_key = timestamp[:19] if timestamp else ''

        key = (rule_id, agent_id, timestamp_key)

        if key not in seen:
            seen[key] = True
            deduplicated.append(hit)
        # else: Skip duplicate event

    return deduplicated


def determine_event_type(rule_id):
    """Map rule ID to event type for visualization"""
    if rule_id in ['5710', '5763', '5712', '5711']:
        return 'ssh_attempt'
    elif rule_id in ['5401', '5402', '5403', '5404']:
        return 'port_scan'
    elif rule_id in ['60122']:
        return 'rdp_attempt'
    elif rule_id in ['31103']:
        return 'web_attack'
    elif rule_id in ['5503', '5551']:
        return 'failed_login'
    elif rule_id == '651':
        return 'ar_block'
    else:
        return 'unknown'


@bp.route('/attack-timeline/<ip_address>', methods=['GET'])
def get_attack_timeline(ip_address):
    """
    Get chronological attack timeline for specific IP

    Shows complete attack chain with MITRE mapping and visualization data

    Query Parameters:
        - hours: Time window (default 24)

    Returns:
        {
            "ip_address": "192.168.1.100",
            "timeline": [
                {
                    "timestamp": "2025-12-31T10:15:30Z",
                    "rule_id": "5710",
                    "rule_description": "SSH invalid user",
                    "agent_id": "003",
                    "agent_name": "trace9-vm",
                    "command": "firewall-drop",
                    "mitre_technique": "T1110.001",
                    "mitre_tactic": "TA0006",
                    "attack_stage": "reconnaissance",
                    "stage_color": "#FFA500",
                    "severity": "Medium"
                }
            ],
            "attack_chain": [...],
            "duration_minutes": 3.25,
            "total_events": 20
        }
    """
    try:
        hours = int(request.args.get('hours', 24))

        # Query for all AR-related events (attack attempts + AR blocks)
        query_body = {
            "query": {
                "bool": {
                    "must": [
                        {"terms": {"rule.id": ALL_AR_RULES}},  # All AR-related rules
                        {"range": {"@timestamp": {"gte": f"now-{hours}h"}}}
                    ],
                    "should": [
                        {"match": {"data.srcip": ip_address}},  # For attack events
                        {"match": {"data.dstip": ip_address}}   # For some rules
                    ],
                    "minimum_should_match": 1
                }
            },
            "size": 1000,  # Increased to handle all events
            "sort": [{"@timestamp": {"order": "asc"}}]  # Chronological order
        }

        results = query_wazuh_indexer(query_body)

        timeline = []
        rules_seen = []
        all_hits = results.get('hits', {}).get('hits', [])

        # STEP 1: Deduplicate events from multiple log sources
        # (Same event logged in auth.log, journald, syslog, etc.)
        deduplicated_hits = deduplicate_timeline_events(all_hits)

        # STEP 2: Separate AR blocks from other events
        ar_blocks = [hit for hit in deduplicated_hits if hit['_source'].get('rule', {}).get('id') == '651']
        other_events = [hit for hit in deduplicated_hits if hit['_source'].get('rule', {}).get('id') != '651']

        # STEP 3: Apply temporal aggregation to AR blocks (5-second window)
        aggregated_ar_blocks = aggregate_temporal_blocks(ar_blocks)

        # STEP 4: Convert aggregated AR blocks back to hit format with metadata
        ar_hits_with_meta = []
        for agg in aggregated_ar_blocks:
            hit = agg['block']
            # Add aggregation metadata for later processing
            hit['_aggregation_meta'] = {
                'trigger_count': agg['trigger_count'],
                'trigger_timestamps': agg['trigger_timestamps']
            }
            ar_hits_with_meta.append(hit)

        # STEP 5: Combine AR blocks and other events, sort chronologically
        processed_hits = other_events + ar_hits_with_meta
        processed_hits.sort(key=lambda x: x['_source']['@timestamp'])

        # STEP 6: Build timeline events from processed hits
        for hit in processed_hits:
            source = hit['_source']
            data = source.get('data', {})
            agent = source.get('agent', {})
            rule = source.get('rule', {})

            timestamp = source.get('@timestamp')
            rule_id = rule.get('id', 'Unknown')

            # For Rule 651, extract the triggering rule
            if rule_id == '651':
                triggering_rule = extract_triggering_rule(data)
                command = data.get('command', 'firewall-drop')
                event_type = 'ar_block'
            else:
                triggering_rule = rule_id
                command = None
                event_type = determine_event_type(rule_id)

            # Get MITRE mapping for the actual attack rule (not 651)
            mitre = get_mitre_mapping(triggering_rule)

            # Extract aggregation metadata if present (for AR blocks)
            aggregation_meta = hit.get('_aggregation_meta', {})
            trigger_count = aggregation_meta.get('trigger_count', 1)
            trigger_timestamps = aggregation_meta.get('trigger_timestamps', None)

            # Determine if this event triggered an AR block
            # (Look for Rule 651 with same timestamp +/- 5 seconds)
            triggered_block = False
            if event_type != 'ar_block':
                # Check if there's a corresponding Rule 651 within 5 seconds
                event_time = datetime.fromisoformat(timestamp.replace('Z', '+00:00'))
                for other_hit in processed_hits:
                    other_source = other_hit['_source']
                    other_rule_id = other_source.get('rule', {}).get('id')
                    if other_rule_id == '651':
                        other_time = datetime.fromisoformat(other_source.get('@timestamp').replace('Z', '+00:00'))
                        time_diff = abs((other_time - event_time).total_seconds())
                        if time_diff <= 5:
                            triggered_block = True
                            break

            # Build timeline event
            event = {
                'timestamp': timestamp,
                'event_type': event_type,  # 'ssh_attempt', 'port_scan', 'ar_block', etc.
                'rule_id': rule_id,
                'triggered_rule': triggering_rule if rule_id == '651' else None,
                'rule_description': mitre['description'],
                'agent_id': agent.get('id', 'Unknown'),
                'agent_name': agent.get('name', 'Unknown'),
                'command': command,
                'triggered_block': triggered_block,  # Did this event trigger AR?
                'mitre_technique': mitre['technique'],
                'mitre_technique_name': mitre['technique_name'],
                'mitre_tactic': mitre['tactic'],
                'mitre_tactic_name': mitre['tactic_name'],
                'attack_stage': mitre['attack_stage'],
                'stage_color': get_attack_stage_color(mitre['attack_stage']),
                'severity': mitre['severity'],
                # Aggregation metadata (for AR blocks)
                'is_aggregated': trigger_count > 1,
                'aggregation_count': trigger_count,
                'aggregation_timestamps': trigger_timestamps
            }

            timeline.append(event)
            rules_seen.append(triggering_rule)

        # Build attack kill chain
        kill_chain = build_attack_kill_chain(rules_seen)

        # Calculate attack duration
        if timeline:
            first_event = datetime.fromisoformat(timeline[0]['timestamp'].replace('Z', '+00:00'))
            last_event = datetime.fromisoformat(timeline[-1]['timestamp'].replace('Z', '+00:00'))
            duration_minutes = (last_event - first_event).total_seconds() / 60
        else:
            duration_minutes = 0

        return jsonify({
            'ip_address': ip_address,
            'timeline': timeline,
            'attack_chain': kill_chain,
            'duration_minutes': round(duration_minutes, 2),
            'total_events': len(timeline),
            'first_seen': timeline[0]['timestamp'] if timeline else None,
            'last_seen': timeline[-1]['timestamp'] if timeline else None
        }), 200

    except Exception as e:
        logger.error(f"Error getting attack timeline for {ip_address}: {str(e)}")
        return jsonify({'error': str(e)}), 500


@bp.route('/ip-intelligence/<ip_address>', methods=['GET'])
def get_ip_intelligence(ip_address):
    """
    Get comprehensive IP intelligence profile

    Correlates data from:
    - Active Response blocks
    - Wazuh alerts (rule 651)
    - IP reputation (AbuseIPDB)
    - Threat scoring

    Query Parameters:
        - hours: Time window (default 24)

    Returns:
        {
            "ip_address": "192.168.1.100",
            "threat_score": 85,
            "risk_level": "Critical",
            "first_seen": "2025-12-31T10:15:30Z",
            "last_seen": "2025-12-31T10:18:45Z",
            "total_blocks": 20,
            "unique_rules": 2,
            "attack_velocity": 6.15,
            "affected_agents": [...],
            "timeline": [...],
            "mitre_techniques": [...],
            "reputation": {...},
            "recommended_actions": [...]
        }
    """
    try:
        hours = int(request.args.get('hours', 24))

        # Get attack timeline
        timeline_response = get_attack_timeline(ip_address)
        timeline_data = timeline_response[0].json

        # Build aggregated intelligence
        timeline = timeline_data.get('timeline', [])
        rules_triggered = list(set([event['rule_id'] for event in timeline]))

        if not timeline:
            return jsonify({
                'ip_address': ip_address,
                'error': 'No activity found for this IP in the specified time window'
            }), 404

        # Extract affected agents
        agents = defaultdict(int)
        for event in timeline:
            agent_name = event['agent_name']
            agent_id = event['agent_id']
            agents[f"{agent_name}({agent_id})"] += 1

        affected_agents = [
            {'name': name, 'count': count}
            for name, count in agents.items()
        ]

        # Calculate threat score
        first_seen = timeline[0]['timestamp']
        last_seen = timeline[-1]['timestamp']
        block_count = len(timeline)

        threat_data = calculate_threat_score({
            'ip_address': ip_address,
            'block_count': block_count,
            'rules_triggered': rules_triggered,
            'unique_rules_count': len(rules_triggered),
            'first_seen': first_seen,
            'last_seen': last_seen
        }, include_reputation=True)

        # Extract MITRE techniques
        mitre_techniques = []
        for rule_id in rules_triggered:
            mitre = get_mitre_mapping(rule_id)
            mitre_techniques.append({
                'rule_id': rule_id,
                'technique': mitre['technique'],
                'technique_name': mitre['technique_name'],
                'tactic': mitre['tactic'],
                'tactic_name': mitre['tactic_name']
            })

        # Get recommended actions
        recommended_actions = get_recommended_actions(
            threat_data,
            {
                'ip_address': ip_address,
                'block_count': block_count,
                'rules_triggered': rules_triggered
            }
        )

        return jsonify({
            'ip_address': ip_address,
            'threat_score': threat_data['threat_score'],
            'risk_level': threat_data['risk_level'],
            'priority': threat_data['priority'],
            'color': threat_data['color'],
            'first_seen': first_seen,
            'last_seen': last_seen,
            'total_blocks': block_count,
            'unique_rules': len(rules_triggered),
            'rules_triggered': rules_triggered,
            'attack_velocity': round(timeline_data['duration_minutes'] / block_count if block_count > 0 else 0, 2),
            'duration_minutes': timeline_data['duration_minutes'],
            'affected_agents': affected_agents,
            'timeline': timeline,
            'attack_chain': timeline_data.get('attack_chain', []),
            'mitre_techniques': mitre_techniques,
            'reputation': threat_data.get('reputation_data'),
            'score_breakdown': threat_data['breakdown'],
            'recommended_actions': recommended_actions
        }), 200

    except Exception as e:
        logger.error(f"Error getting IP intelligence for {ip_address}: {str(e)}")
        return jsonify({'error': str(e)}), 500
