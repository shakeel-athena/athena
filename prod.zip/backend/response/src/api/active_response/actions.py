"""
Active Response Manual Actions API

Provides endpoints for manual AR actions:
- Manually block an IP address
- Manually unblock an IP address
- Get manual action audit log
"""

import os
import logging
from datetime import datetime
from flask import jsonify, request
from . import bp
import requests
from requests.auth import HTTPBasicAuth
import psycopg2
from psycopg2.extras import RealDictCursor
import paramiko
import time

logger = logging.getLogger(__name__)

# Wazuh API configuration (requires environment variables)
WAZUH_API_URL = os.getenv('WAZUH_API_URL')
WAZUH_API_USER = os.getenv('WAZUH_API_USER')
WAZUH_API_PASSWORD = os.getenv('WAZUH_API_PASSWORD')

# Database configuration (requires environment variables)
DB_CONFIG = {
    'host': os.getenv('POSTGRES_HOST'),
    'database': os.getenv('POSTGRES_DB'),
    'user': os.getenv('POSTGRES_USER'),
    'password': os.getenv('POSTGRES_PASSWORD'),
    'port': os.getenv('POSTGRES_PORT', '5432')
}

# Wazuh Manager SSH configuration (requires environment variables)
WAZUH_MANAGER_HOST = os.getenv('WAZUH_MANAGER_HOST')
WAZUH_SSH_USER = os.getenv('WAZUH_SSH_USER')
WAZUH_SSH_PASSWORD = os.getenv('WAZUH_SSH_PASSWORD')
WAZUH_SSH_KEY_PATH = os.getenv('WAZUH_SSH_KEY_PATH')  # SSH key auth (recommended for production)


class WazuhAPIClient:
    """Client for interacting with Wazuh API"""

    def __init__(self):
        self.base_url = WAZUH_API_URL
        self.username = WAZUH_API_USER
        self.password = WAZUH_API_PASSWORD
        self.token = None

    def authenticate(self):
        """Get JWT token from Wazuh API"""
        try:
            url = f"{self.base_url}/security/user/authenticate"

            response = requests.post(
                url,
                auth=HTTPBasicAuth(self.username, self.password),
                verify=False,
                timeout=30
            )

            response.raise_for_status()
            data = response.json()
            self.token = data['data']['token']

            logger.info("Successfully authenticated with Wazuh API")
            return self.token

        except requests.exceptions.RequestException as e:
            logger.error(f"Failed to authenticate with Wazuh API: {str(e)}")
            raise

    def trigger_active_response(self, agent_ids, command, arguments):
        """
        Trigger Active Response on specific agents

        Args:
            agent_ids: List of agent IDs or 'all'
            command: AR command (e.g., '!firewall-drop')
            arguments: Command arguments - first arg should be IP address

        Returns:
            dict: API response
        """
        if not self.token:
            self.authenticate()

        try:
            # Wazuh API expects agents_list as QUERY PARAMETER
            if agent_ids == 'all':
                agents_param = '000'  # '000' means all agents
            elif isinstance(agent_ids, list):
                agents_param = ','.join(agent_ids)
            else:
                agents_param = str(agent_ids)

            url = f"{self.base_url}/active-response?agents_list={agents_param}"

            # Build request payload - Wazuh expects 'alert' object with 'data.srcip'
            payload = {
                'command': command,
                'alert': {
                    'data': {
                        'srcip': arguments[0] if arguments else ''
                    }
                }
            }

            logger.info(f"Triggering AR - URL: {url}, Payload: {payload}")

            response = requests.put(
                url,
                headers={'Authorization': f'Bearer {self.token}'},
                json=payload,
                verify=False,
                timeout=30
            )

            logger.info(f"Wazuh API Response Status: {response.status_code}")

            # Log response body even on error
            try:
                response_data = response.json()
                logger.info(f"Wazuh API Response: {response_data}")
            except:
                logger.info(f"Wazuh API Response (text): {response.text}")

            response.raise_for_status()
            return response.json()

        except requests.exceptions.RequestException as e:
            logger.error(f"Failed to trigger Active Response: {str(e)}")
            if hasattr(e.response, 'text'):
                logger.error(f"Response body: {e.response.text}")
            raise


def unblock_ip_via_ssh(ip_address, agent_id):
    """
    Unblock IP via SSH to Wazuh Manager (Professional Approach)

    This method SSHs to the Wazuh Manager and directly removes the iptables rule
    on the specified agent. This is more reliable than the Wazuh API for manual unblocking.

    Args:
        ip_address: IP address to unblock
        agent_id: Agent ID where the block should be removed

    Returns:
        dict: Success status and message
    """
    try:
        logger.info(f"Attempting SSH unblock for IP {ip_address} on agent {agent_id}")

        # Get agent IP from Wazuh API first
        wazuh_client = WazuhAPIClient()
        wazuh_client.authenticate()

        # Get agent info
        agent_response = requests.get(
            f"{WAZUH_API_URL}/agents?agents_list={agent_id}",
            headers={'Authorization': f'Bearer {wazuh_client.token}'},
            verify=False,
            timeout=30
        )

        if agent_response.status_code != 200:
            raise Exception(f"Failed to get agent info: {agent_response.text}")

        agent_data = agent_response.json()
        if not agent_data.get('data', {}).get('affected_items'):
            raise Exception(f"Agent {agent_id} not found")

        agent_ip = agent_data['data']['affected_items'][0].get('ip')

        if not agent_ip:
            raise Exception(f"Could not determine IP for agent {agent_id}")

        logger.info(f"Agent {agent_id} IP: {agent_ip}")

        # Connect to Wazuh Manager via SSH
        ssh = paramiko.SSHClient()
        ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())

        logger.info(f"Connecting to Wazuh Manager {WAZUH_MANAGER_HOST}")

        # Prefer SSH key authentication (more secure for production)
        if WAZUH_SSH_KEY_PATH and os.path.exists(WAZUH_SSH_KEY_PATH):
            try:
                # Try Ed25519 key first (modern), then RSA
                try:
                    private_key = paramiko.Ed25519Key.from_private_key_file(WAZUH_SSH_KEY_PATH)
                except:
                    private_key = paramiko.RSAKey.from_private_key_file(WAZUH_SSH_KEY_PATH)
                ssh.connect(
                    hostname=WAZUH_MANAGER_HOST,
                    username=WAZUH_SSH_USER,
                    pkey=private_key,
                    timeout=30
                )
                logger.info("Connected using SSH key authentication")
            except Exception as e:
                logger.warning(f"SSH key auth failed ({e}), falling back to password")
                ssh.connect(
                    hostname=WAZUH_MANAGER_HOST,
                    username=WAZUH_SSH_USER,
                    password=WAZUH_SSH_PASSWORD,
                    timeout=30
                )
        else:
            # Fallback to password authentication
            ssh.connect(
                hostname=WAZUH_MANAGER_HOST,
                username=WAZUH_SSH_USER,
                password=WAZUH_SSH_PASSWORD,
                timeout=30
            )

        # SSH to the agent and remove the iptables rule
        # Try passwordless SSH first (recommended), fall back to password if needed

        # Try passwordless SSH first (best practice for production)
        # Note: Agent username may differ from manager username
        # For trace9-vm, username is 'trace9-vm' not 'amygdala-test'
        agent_username = os.getenv('WAZUH_AGENT_SSH_USER', 'trace9-vm')  # Default to trace9-vm

        passwordless_command = (
            f"ssh -o StrictHostKeyChecking=no -o ConnectTimeout=5 -o BatchMode=yes "
            f"{agent_username}@{agent_ip} "
            f"'sudo iptables -D INPUT -s {ip_address} -j DROP'"
        )

        logger.info(f"Attempting passwordless SSH to agent {agent_ip}")
        stdin, stdout, stderr = ssh.exec_command(passwordless_command, timeout=10)

        # Wait for command with short timeout
        timeout_counter = 0
        while not stdout.channel.exit_status_ready():
            time.sleep(0.5)
            timeout_counter += 0.5
            if timeout_counter > 10:
                # Passwordless SSH failed, try with password
                logger.warning(f"Passwordless SSH failed, trying with password...")
                break

        exit_status = stdout.channel.recv_exit_status() if stdout.channel.exit_status_ready() else -1
        output = stdout.read().decode()
        error = stderr.read().decode()

        logger.info(f"Passwordless SSH exit status: {exit_status}")
        logger.info(f"Passwordless SSH error output: {error}")

        # If passwordless failed, check if it's because rule doesn't exist (already unblocked)
        if exit_status != 0:
            # iptables -D returns error if rule doesn't exist (already removed)
            # This is actually OK - means the block already expired or was manually removed
            if "Bad rule" in error or "No chain/target/match" in error or "does a matching rule exist" in error:
                logger.info(f"Block already removed (rule doesn't exist)")
                ssh.close()
                return {
                    'success': True,
                    'message': f'Block already removed (likely expired via timeout or manually removed)',
                    'method': 'ssh_manager_to_agent'
                }

            # If not "Bad rule", try sshpass as fallback (in case sudo password is the issue)
            logger.info(f"Passwordless SSH failed (exit {exit_status}), trying sshpass approach")

            # Try using sshpass for password automation
            agent_password = os.getenv('WAZUH_AGENT_SSH_PASSWORD', WAZUH_SSH_PASSWORD)
            sshpass_command = (
                f"sshpass -p '{agent_password}' ssh -o StrictHostKeyChecking=no "
                f"{agent_username}@{agent_ip} "
                f"'echo {agent_password} | sudo -S iptables -D INPUT -s {ip_address} -j DROP'"
            )

            stdin, stdout, stderr = ssh.exec_command(sshpass_command, timeout=15)

            # Wait for command to complete
            timeout_counter = 0
            while not stdout.channel.exit_status_ready():
                time.sleep(0.5)
                timeout_counter += 0.5
                if timeout_counter > 15:
                    raise Exception(
                        "Command timeout. Please setup SSH keys using: "
                        "setup_prerequisites/active_response/setup_ssh_keys.sh"
                    )

            exit_status = stdout.channel.recv_exit_status()
            output = stdout.read().decode()
            error = stderr.read().decode()

        ssh.close()

        logger.info(f"Unblock command exit status: {exit_status}")
        logger.info(f"Unblock command output: {output}")

        if exit_status != 0:
            # Check again if rule doesn't exist (for sshpass path)
            if "Bad rule" in error or "No chain/target/match" in error or "does a matching rule exist" in error:
                logger.info(f"Block already removed (timeout expired)")
                return {
                    'success': True,
                    'message': f'Block already removed (likely expired via timeout)',
                    'method': 'ssh_manager_to_agent'
                }
            else:
                logger.error(f"Unblock command failed: {error}")
                raise Exception(f"Failed to remove iptables rule: {error}")

        return {
            'success': True,
            'message': f'Successfully unblocked {ip_address} on agent {agent_id}',
            'method': 'ssh_manager_to_agent',
            'output': output
        }

    except Exception as e:
        logger.error(f"SSH unblock failed: {str(e)}")
        raise


def get_db_connection():
    """Get PostgreSQL database connection"""
    return psycopg2.connect(**DB_CONFIG)


def log_manual_action(action_type, ip_address, agent_id, timeout_seconds, reason, analyst):
    """
    Log manual AR action to database for audit trail

    Args:
        action_type: 'block' or 'unblock'
        ip_address: Target IP
        agent_id: Agent ID where action was performed
        timeout_seconds: Block timeout (0 for unblock)
        reason: Justification for action
        analyst: Username of analyst who performed action
    """
    try:
        conn = get_db_connection()
        cursor = conn.cursor()

        cursor.execute("""
            INSERT INTO ar_manual_actions
            (action_type, ip_address, agent_id, timeout_seconds, reason, analyst, created_at)
            VALUES (%s, %s, %s, %s, %s, %s, NOW())
        """, (action_type, ip_address, agent_id, timeout_seconds, reason, analyst))

        conn.commit()
        cursor.close()
        conn.close()

        logger.info(f"Logged manual {action_type} action for IP {ip_address} by {analyst}")

    except Exception as e:
        logger.error(f"Failed to log manual action: {str(e)}")
        # Don't raise - logging failure shouldn't block the action


def check_whitelist(ip_address):
    """
    Check if IP is in whitelist

    Args:
        ip_address: IP to check

    Returns:
        bool: True if whitelisted
    """
    try:
        conn = get_db_connection()
        cursor = conn.cursor()

        cursor.execute("""
            SELECT COUNT(*) FROM ar_whitelist
            WHERE ip_address = %s AND approval_status = 'approved'
        """, (ip_address,))

        count = cursor.fetchone()[0]

        cursor.close()
        conn.close()

        return count > 0

    except Exception as e:
        logger.error(f"Failed to check whitelist: {str(e)}")
        return False


@bp.route('/manual-block', methods=['POST'])
def manual_block_ip():
    """
    Manually block an IP address via Active Response

    Request Body:
        {
            "ip_address": "1.2.3.4",
            "agent_id": "001" or "all",
            "timeout_seconds": 3600,
            "reason": "Confirmed C2 traffic from threat intel",
            "analyst": "john.doe"
        }

    Returns:
        {
            "success": true,
            "message": "IP 1.2.3.4 blocked on agent 001 for 3600 seconds",
            "details": {...}
        }
    """
    try:
        data = request.get_json()

        # Validate required fields
        required_fields = ['ip_address', 'agent_id', 'timeout_seconds', 'reason', 'analyst']
        missing_fields = [field for field in required_fields if field not in data]

        if missing_fields:
            return jsonify({
                'error': f'Missing required fields: {", ".join(missing_fields)}'
            }), 400

        ip_address = data['ip_address']
        agent_id = data['agent_id']
        timeout_seconds = int(data['timeout_seconds'])
        reason = data['reason']
        analyst = data['analyst']

        # Validate IP not in whitelist
        if check_whitelist(ip_address):
            return jsonify({
                'error': f'IP {ip_address} is whitelisted and cannot be blocked'
            }), 403

        # Trigger Active Response via Wazuh API
        wazuh_client = WazuhAPIClient()

        arguments = [ip_address, str(timeout_seconds)]

        response = wazuh_client.trigger_active_response(
            agent_ids=agent_id,
            command='firewall-drop',
            arguments=arguments
        )

        # Log action to database
        log_manual_action(
            action_type='block',
            ip_address=ip_address,
            agent_id=str(agent_id),
            timeout_seconds=timeout_seconds,
            reason=reason,
            analyst=analyst
        )

        return jsonify({
            'success': True,
            'message': f'IP {ip_address} blocked on agent {agent_id} for {timeout_seconds} seconds',
            'details': response
        }), 200

    except Exception as e:
        logger.error(f"Error in manual block: {str(e)}")
        return jsonify({'error': str(e)}), 500


@bp.route('/unblock', methods=['POST'])
def manual_unblock_ip():
    """
    Manually unblock an IP address (remove AR block)

    Request Body:
        {
            "ip_address": "1.2.3.4",
            "agent_id": "001" or "all",
            "reason": "False positive - legitimate admin",
            "analyst": "john.doe"
        }

    Returns:
        {
            "success": true,
            "message": "IP 1.2.3.4 unblocked on agent 001",
            "details": {...}
        }
    """
    try:
        data = request.get_json()

        # Validate required fields
        required_fields = ['ip_address', 'agent_id', 'reason', 'analyst']
        missing_fields = [field for field in required_fields if field not in data]

        if missing_fields:
            return jsonify({
                'error': f'Missing required fields: {", ".join(missing_fields)}'
            }), 400

        ip_address = data['ip_address']
        agent_id = data['agent_id']
        reason = data['reason']
        analyst = data['analyst']

        # Use SSH-based unblock (Professional approach)
        # This directly removes the iptables rule via Wazuh Manager → Agent SSH
        logger.info(f"Attempting SSH-based unblock for {ip_address} on agent {agent_id}")

        result = unblock_ip_via_ssh(ip_address, agent_id)

        # Log action to database
        log_manual_action(
            action_type='unblock',
            ip_address=ip_address,
            agent_id=str(agent_id),
            timeout_seconds=0,
            reason=reason,
            analyst=analyst
        )

        return jsonify({
            'success': True,
            'message': f'IP {ip_address} unblocked on agent {agent_id}',
            'details': result
        }), 200

    except Exception as e:
        logger.error(f"Error in manual unblock: {str(e)}")
        return jsonify({'error': str(e)}), 500


@bp.route('/manual-actions/history', methods=['GET'])
def get_manual_actions_history():
    """
    Get manual AR action audit log

    Query Parameters:
        - days: Number of days to look back (default 30)
        - analyst: Filter by analyst username
        - action_type: Filter by action type ('block' or 'unblock')

    Returns:
        {
            "actions": [
                {
                    "id": "uuid",
                    "action_type": "block",
                    "ip_address": "1.2.3.4",
                    "agent_id": "001",
                    "timeout_seconds": 3600,
                    "reason": "Confirmed threat",
                    "analyst": "john.doe",
                    "created_at": "2025-12-30T10:45:23Z"
                }
            ],
            "total": 45
        }
    """
    try:
        days = int(request.args.get('days', 30))
        analyst = request.args.get('analyst')
        action_type = request.args.get('action_type')

        conn = get_db_connection()
        cursor = conn.cursor(cursor_factory=RealDictCursor)

        # Build query
        query = """
            SELECT id, action_type, ip_address, agent_id, timeout_seconds,
                   reason, analyst, created_at
            FROM ar_manual_actions
            WHERE created_at >= NOW() - INTERVAL '%s days'
        """
        params = [days]

        if analyst:
            query += " AND analyst = %s"
            params.append(analyst)

        if action_type:
            query += " AND action_type = %s"
            params.append(action_type)

        query += " ORDER BY created_at DESC"

        cursor.execute(query, params)
        actions = cursor.fetchall()

        cursor.close()
        conn.close()

        # Convert to JSON-serializable format
        actions_list = [
            {
                'id': str(action['id']),
                'action_type': action['action_type'],
                'ip_address': action['ip_address'],
                'agent_id': action['agent_id'],
                'timeout_seconds': action['timeout_seconds'],
                'reason': action['reason'],
                'analyst': action['analyst'],
                'created_at': action['created_at'].isoformat()
            }
            for action in actions
        ]

        return jsonify({
            'actions': actions_list,
            'total': len(actions_list)
        }), 200

    except Exception as e:
        logger.error(f"Error getting manual actions history: {str(e)}")
        return jsonify({'error': str(e)}), 500
