"""
NIDS API Blueprint

Provides REST API endpoints for Network Intrusion Detection System (NIDS) dashboard.
Supports aggregations, filtering, and real-time event viewing for Suricata alerts.
"""

from .routes import nids_bp

__all__ = ['nids_bp']
