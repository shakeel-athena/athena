"""
NIDS API Routes

Flask blueprint containing all NIDS dashboard-related API endpoints.
Provides endpoints for dashboard overview, events listing, filtering, and analytics.
"""

from flask import Blueprint, request, jsonify
import logging
from datetime import datetime

# Create blueprint
nids_bp = Blueprint('nids', __name__, url_prefix='/api/nids')

logger = logging.getLogger(__name__)

# Service instance (lazy initialization)
_nids_service = None


def get_nids_service():
    """Get or create NIDS service instance."""
    global _nids_service
    if _nids_service is None:
        from services.nids import NIDSService
        _nids_service = NIDSService()
    return _nids_service


def success_response(data, message="Success"):
    """Create standardized success response."""
    return jsonify({
        "success": True,
        "message": message,
        "data": data
    }), 200


def error_response(message, status_code=500):
    """Create standardized error response."""
    return jsonify({
        "success": False,
        "error": message
    }), status_code


def parse_time_range(start_str, end_str):
    """
    Parse time range from query parameters.

    Supports:
    - Relative: 'now-24h', 'now-7d', 'now'
    - Absolute: ISO format timestamps

    Returns:
        tuple: (start_time, end_time) as datetime objects or relative strings
    """
    return start_str or 'now-24h', end_str or 'now'


# ============================================================================
# Dashboard Overview Endpoints
# ============================================================================

@nids_bp.route('/overview', methods=['GET'])
def get_nids_overview():
    """
    Get NIDS dashboard overview data with aggregations.

    Query Parameters:
        start: Start time (relative like 'now-24h' or ISO format)
        end: End time (relative like 'now' or ISO format)
        category: Optional category filter
        signature: Optional signature filter
        severity: Optional severity filter
        srcIp: Optional source IP filter
        destIp: Optional destination IP filter
        serviceName: Optional service/protocol filter

    Returns:
        Aggregated data including:
        - Total alert count
        - Severity breakdown (1-4 levels, 5+ grouped)
        - Top categories with counts
        - Top signatures with counts
        - Timeline data for charts
    """
    try:
        start = request.args.get('start', 'now-24h')
        end = request.args.get('end', 'now')

        # Optional filters
        category = request.args.get('category')
        signature = request.args.get('signature')
        severity = request.args.get('severity')
        src_ip = request.args.get('srcIp')
        dest_ip = request.args.get('destIp')
        service_name = request.args.get('serviceName')

        service = get_nids_service()
        result = service.get_dashboard_overview(
            start, end,
            category=category,
            signature=signature,
            severity=severity,
            src_ip=src_ip,
            dest_ip=dest_ip,
            service_name=service_name
        )

        return success_response(result, "NIDS overview retrieved successfully")
    except Exception as e:
        logger.error(f"Failed to get NIDS overview: {e}", exc_info=True)
        return error_response(f"Failed to retrieve NIDS overview: {str(e)}", 500)


@nids_bp.route('/timeline', methods=['GET'])
def get_nids_timeline():
    """
    Get timeline chart data for NIDS alerts.

    Query Parameters:
        start: Start time
        end: End time
        interval: Bucket interval (auto, 5m, 1h, 1d)
        category: Optional category filter
        signature: Optional signature filter
        severity: Optional severity filter

    Returns:
        Time-bucketed alert counts for timeline visualization.
    """
    try:
        start = request.args.get('start', 'now-24h')
        end = request.args.get('end', 'now')
        interval = request.args.get('interval', 'auto')
        category = request.args.get('category')
        signature = request.args.get('signature')
        severity = request.args.get('severity')

        service = get_nids_service()
        result = service.get_timeline_data(
            start=start,
            end=end,
            interval=interval,
            category=category,
            signature=signature,
            severity=severity
        )

        return success_response(result, "Timeline data retrieved successfully")
    except Exception as e:
        logger.error(f"Failed to get timeline data: {e}", exc_info=True)
        return error_response(f"Failed to retrieve timeline data: {str(e)}", 500)


@nids_bp.route('/network-analysis', methods=['GET'])
def get_network_analysis():
    """
    Get network analysis data for NIDS dashboard.

    Query Parameters:
        start: Start time
        end: End time
        limit: Number of top items to return (default: 10)
        category: Optional category filter
        signature: Optional signature filter
        severity: Optional severity filter
        srcIp: Optional source IP filter
        destIp: Optional destination IP filter
        serviceName: Optional service/protocol filter

    Returns:
        Top source IPs, destination IPs, services, and hostnames.
    """
    try:
        start = request.args.get('start', 'now-24h')
        end = request.args.get('end', 'now')
        limit = request.args.get('limit', 10, type=int)

        # Optional filters
        category = request.args.get('category')
        signature = request.args.get('signature')
        severity = request.args.get('severity')
        src_ip = request.args.get('srcIp')
        dest_ip = request.args.get('destIp')
        service_name = request.args.get('serviceName')

        service = get_nids_service()
        result = service.get_network_analysis(
            start, end, limit,
            category=category,
            signature=signature,
            severity=severity,
            src_ip=src_ip,
            dest_ip=dest_ip,
            service_name=service_name
        )

        return success_response(result, "Network analysis retrieved successfully")
    except Exception as e:
        logger.error(f"Failed to get network analysis: {e}", exc_info=True)
        return error_response(f"Failed to retrieve network analysis: {str(e)}", 500)


# ============================================================================
# Events Endpoints
# ============================================================================

@nids_bp.route('/events', methods=['GET'])
def get_nids_events():
    """
    Get paginated NIDS events with filtering.

    Query Parameters:
        start: Start time
        end: End time
        limit: Page size (default: 20, max: 100)
        offset: Pagination offset
        category: Filter by alert category
        signature: Filter by signature name
        severity: Filter by severity (1, 2, 3, 4, 5+)
        srcIp: Filter by source IP
        destIp: Filter by destination IP
        serviceName: Filter by service/protocol
        search: Full-text search query
        sortField: Field to sort by (timestamp, severity)
        sortDirection: asc or desc

    Returns:
        Paginated list of events with metadata.
    """
    try:
        # Parse parameters
        start = request.args.get('start', 'now-24h')
        end = request.args.get('end', 'now')
        limit = min(request.args.get('limit', 20, type=int), 100)
        offset = request.args.get('offset', 0, type=int)

        # Filters
        category = request.args.get('category')
        signature = request.args.get('signature')
        severity = request.args.get('severity')
        src_ip = request.args.get('srcIp')
        dest_ip = request.args.get('destIp')
        service_name = request.args.get('serviceName')
        search = request.args.get('search')

        # Sorting
        sort_field = request.args.get('sortField', 'timestamp')
        sort_direction = request.args.get('sortDirection', 'desc')

        service = get_nids_service()
        result = service.get_events(
            start=start,
            end=end,
            limit=limit,
            offset=offset,
            category=category,
            signature=signature,
            severity=severity,
            src_ip=src_ip,
            dest_ip=dest_ip,
            service_name=service_name,
            search=search,
            sort_field=sort_field,
            sort_direction=sort_direction
        )

        return success_response(result, f"Retrieved {len(result.get('events', []))} events")
    except Exception as e:
        logger.error(f"Failed to get NIDS events: {e}", exc_info=True)
        return error_response(f"Failed to retrieve events: {str(e)}", 500)


@nids_bp.route('/events/<event_id>', methods=['GET'])
def get_event_details(event_id):
    """
    Get detailed information for a specific event.

    Path Parameters:
        event_id: The Elasticsearch document ID

    Returns:
        Full event details including raw data.
    """
    try:
        service = get_nids_service()
        result = service.get_event_by_id(event_id)

        if result:
            return success_response(result, "Event details retrieved")
        else:
            return error_response("Event not found", 404)
    except Exception as e:
        logger.error(f"Failed to get event details: {e}", exc_info=True)
        return error_response(f"Failed to retrieve event details: {str(e)}", 500)


# ============================================================================
# Filter Options Endpoints
# ============================================================================

@nids_bp.route('/filters', methods=['GET'])
def get_filter_options():
    """
    Get available filter options with counts.

    Query Parameters:
        start: Start time
        end: End time

    Returns:
        Available categories, signatures, and severities with counts.
    """
    try:
        start = request.args.get('start', 'now-24h')
        end = request.args.get('end', 'now')

        service = get_nids_service()
        result = service.get_filter_options(start, end)

        return success_response(result, "Filter options retrieved successfully")
    except Exception as e:
        logger.error(f"Failed to get filter options: {e}", exc_info=True)
        return error_response(f"Failed to retrieve filter options: {str(e)}", 500)


# ============================================================================
# Health Check Endpoint
# ============================================================================

@nids_bp.route('/health', methods=['GET'])
def get_nids_health():
    """
    Get NIDS service health status.

    Returns:
        Health status including Elasticsearch connection and data availability.
    """
    try:
        service = get_nids_service()
        health = service.get_health_status()

        status_code = 200 if health.get('status') == 'healthy' else 503
        return jsonify({
            "success": True,
            "data": health
        }), status_code
    except Exception as e:
        logger.error(f"Failed to get NIDS health: {e}", exc_info=True)
        return jsonify({
            "success": False,
            "data": {
                "status": "unhealthy",
                "error": str(e),
                "timestamp": datetime.utcnow().isoformat() + "Z"
            }
        }), 503
