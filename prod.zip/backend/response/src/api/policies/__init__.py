"""
Policies API Module

Contains Flask blueprint for security policy management endpoints.
"""

from .routes import policies_bp

__all__ = ['policies_bp']
