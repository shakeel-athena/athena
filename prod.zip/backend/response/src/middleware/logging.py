"""
Structured Logging & Monitoring for Athena Network Response Management

This module provides comprehensive logging and monitoring capabilities with
structured JSON logging, performance metrics, error tracking, and alerting.
It integrates with security events, API requests, and system health monitoring.
"""

import json
import logging
import time
import traceback
import threading
import psutil
import os
import socket
from typing import Any, Dict, Optional, List
from datetime import datetime, timedelta
from dataclasses import dataclass, asdict
from enum import Enum
from functools import wraps
from flask import Flask, request, g
import uuid
from contextlib import contextmanager

class LogLevel(Enum):
    """Log levels with numeric values for filtering"""
    DEBUG = 10
    INFO = 20
    WARNING = 30
    ERROR = 40
    CRITICAL = 50

class EventType(Enum):
    """Event types for categorization"""
    API_REQUEST = "api_request"
    API_RESPONSE = "api_response"
    SECURITY_EVENT = "security_event"
    PERFORMANCE_METRIC = "performance_metric"
    ERROR = "error"
    SYSTEM_HEALTH = "system_health"
    BUSINESS_EVENT = "business_event"
    AUDIT = "audit"

@dataclass
class LogEvent:
    """Structured log event"""
    timestamp: datetime
    level: LogLevel
    event_type: EventType
    message: str
    request_id: Optional[str] = None
    user_id: Optional[str] = None
    session_id: Optional[str] = None
    ip_address: Optional[str] = None
    user_agent: Optional[str] = None
    endpoint: Optional[str] = None
    method: Optional[str] = None
    status_code: Optional[int] = None
    response_time_ms: Optional[float] = None
    error_details: Optional[Dict] = None
    metadata: Optional[Dict] = None
    tags: Optional[List[str]] = None

class StructuredLogger:
    """Structured JSON logger with enhanced capabilities"""
    
    def __init__(self, name: str = "athena"):
        self.logger = logging.getLogger(name)
        self.logger.setLevel(logging.INFO)
        
        # Prevent duplicate handlers
        if not self.logger.handlers:
            self._setup_handlers()
    
    def _setup_handlers(self):
        """Setup structured logging handlers"""
        # Console handler with JSON formatting
        console_handler = logging.StreamHandler()
        console_handler.setLevel(logging.INFO)
        
        # JSON formatter
        formatter = StructuredFormatter()
        console_handler.setFormatter(formatter)
        
        self.logger.addHandler(console_handler)
        
        # File handler for persistent logs
        log_dir = os.environ.get('LOG_DIR', 'logs')
        if log_dir and not os.path.exists(log_dir):
            os.makedirs(log_dir)
        
        log_file = os.path.join(log_dir, 'athena.log')
        file_handler = logging.FileHandler(log_file)
        file_handler.setLevel(logging.DEBUG)
        file_handler.setFormatter(formatter)
        
        self.logger.addHandler(file_handler)
    
    def log_event(self, event: LogEvent):
        """Log a structured event"""
        log_data = asdict(event)
        
        # Convert datetime to ISO string
        log_data['timestamp'] = event.timestamp.isoformat()
        
        # Convert enums to values
        log_data['level'] = event.level.value
        log_data['event_type'] = event.event_type.value
        
        # Add hostname and process info
        log_data['hostname'] = socket.gethostname()
        log_data['process_id'] = os.getpid()
        log_data['thread_id'] = threading.get_ident()
        
        # Log at appropriate level
        self.logger.log(event.level.value, json.dumps(log_data))
    
    def debug(self, message: str, event_type: EventType = EventType.SYSTEM_HEALTH, **kwargs):
        """Log debug event"""
        event = LogEvent(
            timestamp=datetime.utcnow(),
            level=LogLevel.DEBUG,
            event_type=event_type,
            message=message,
            **kwargs
        )
        self.log_event(event)
    
    def info(self, message: str, event_type: EventType = EventType.SYSTEM_HEALTH, **kwargs):
        """Log info event"""
        event = LogEvent(
            timestamp=datetime.utcnow(),
            level=LogLevel.INFO,
            event_type=event_type,
            message=message,
            **kwargs
        )
        self.log_event(event)
    
    def warning(self, message: str, event_type: EventType = EventType.SYSTEM_HEALTH, **kwargs):
        """Log warning event"""
        event = LogEvent(
            timestamp=datetime.utcnow(),
            level=LogLevel.WARNING,
            event_type=event_type,
            message=message,
            **kwargs
        )
        self.log_event(event)
    
    def error(self, message: str, event_type: EventType = EventType.ERROR, **kwargs):
        """Log error event"""
        event = LogEvent(
            timestamp=datetime.utcnow(),
            level=LogLevel.ERROR,
            event_type=event_type,
            message=message,
            **kwargs
        )
        self.log_event(event)
    
    def critical(self, message: str, event_type: EventType = EventType.ERROR, **kwargs):
        """Log critical event"""
        event = LogEvent(
            timestamp=datetime.utcnow(),
            level=LogLevel.CRITICAL,
            event_type=event_type,
            message=message,
            **kwargs
        )
        self.log_event(event)
    
    def log(self, level: LogLevel, message: str, event_type: EventType = EventType.SYSTEM_HEALTH, **kwargs):
        """Log event at specified level"""
        event = LogEvent(
            timestamp=datetime.utcnow(),
            level=level,
            event_type=event_type,
            message=message,
            **kwargs
        )
        self.log_event(event)

class StructuredFormatter(logging.Formatter):
    """JSON formatter for structured logging"""
    
    def format(self, record):
        # Try to parse as JSON if it's already structured
        try:
            log_data = json.loads(record.getMessage())
            return json.dumps(log_data)
        except (json.JSONDecodeError, TypeError):
            # Fallback to basic structured format
            log_data = {
                'timestamp': datetime.utcnow().isoformat(),
                'level': record.levelname,
                'message': record.getMessage(),
                'module': record.module,
                'function': record.funcName,
                'line': record.lineno
            }
            return json.dumps(log_data)

class PerformanceMonitor:
    """Performance monitoring and metrics collection"""
    
    def __init__(self, logger: StructuredLogger):
        self.logger = logger
        self.metrics = {
            'request_count': 0,
            'total_response_time': 0.0,
            'error_count': 0,
            'security_events': 0,
            'slow_requests': 0
        }
        self.slow_request_threshold = 1000  # 1 second
        self._lock = threading.Lock()
    
    def record_request(self, response_time_ms: float, status_code: int, endpoint: str):
        """Record API request metrics"""
        with self._lock:
            self.metrics['request_count'] += 1
            self.metrics['total_response_time'] += response_time_ms
            
            if status_code >= 400:
                self.metrics['error_count'] += 1
            
            if response_time_ms > self.slow_request_threshold:
                self.metrics['slow_requests'] += 1
                
                # Log slow request
                self.logger.warning(
                    f"Slow request detected: {endpoint}",
                    event_type=EventType.PERFORMANCE_METRIC,
                    endpoint=endpoint,
                    response_time_ms=response_time_ms,
                    status_code=status_code,
                    metadata={'threshold_ms': self.slow_request_threshold}
                )
    
    def record_security_event(self, event_type: str, details: Dict):
        """Record security event"""
        with self._lock:
            self.metrics['security_events'] += 1
        
        self.logger.warning(
            f"Security event: {event_type}",
            event_type=EventType.SECURITY_EVENT,
            metadata={'security_event_type': event_type, **details}
        )
    
    def get_metrics(self) -> Dict:
        """Get current performance metrics"""
        with self._lock:
            if self.metrics['request_count'] > 0:
                avg_response_time = self.metrics['total_response_time'] / self.metrics['request_count']
                error_rate = (self.metrics['error_count'] / self.metrics['request_count']) * 100
            else:
                avg_response_time = 0
                error_rate = 0
            
            return {
                'request_count': self.metrics['request_count'],
                'average_response_time_ms': round(avg_response_time, 2),
                'error_rate_percent': round(error_rate, 2),
                'error_count': self.metrics['error_count'],
                'security_events': self.metrics['security_events'],
                'slow_requests': self.metrics['slow_requests']
            }
    
    def reset_metrics(self):
        """Reset all metrics"""
        with self._lock:
            for key in self.metrics:
                self.metrics[key] = 0

class SystemMonitor:
    """System health and resource monitoring"""
    
    def __init__(self, logger: StructuredLogger):
        self.logger = logger
        self.monitoring_enabled = True
        self.check_interval = 60  # seconds
        self._monitor_thread = None
        self._running = False
    
    def start_monitoring(self):
        """Start system monitoring thread"""
        if self._running:
            return
        
        self._running = True
        self._monitor_thread = threading.Thread(target=self._monitor_loop, daemon=True)
        self._monitor_thread.start()
        self.logger.info("System monitoring started")
    
    def stop_monitoring(self):
        """Stop system monitoring thread"""
        self._running = False
        if self._monitor_thread:
            self._monitor_thread.join(timeout=5)
        self.logger.info("System monitoring stopped")
    
    def _monitor_loop(self):
        """Main monitoring loop"""
        while self._running:
            try:
                self._check_system_health()
                time.sleep(self.check_interval)
            except Exception as e:
                self.logger.error(f"System monitoring error: {e}")
                time.sleep(self.check_interval)
    
    def _check_system_health(self):
        """Check system health metrics"""
        try:
            # CPU usage
            cpu_percent = psutil.cpu_percent(interval=1)
            
            # Memory usage
            memory = psutil.virtual_memory()
            memory_percent = memory.percent
            
            # Disk usage
            disk = psutil.disk_usage('/')
            disk_percent = disk.percent
            
            # Network connections
            connections = len(psutil.net_connections())
            
            # Process count
            process_count = len(psutil.pids())
            
            health_data = {
                'cpu_percent': cpu_percent,
                'memory_percent': memory_percent,
                'memory_available_gb': round(memory.available / (1024**3), 2),
                'disk_percent': disk_percent,
                'disk_free_gb': round(disk.free / (1024**3), 2),
                'network_connections': connections,
                'process_count': process_count
            }
            
            # Check for warnings
            warnings = []
            if cpu_percent > 80:
                warnings.append("high_cpu")
            if memory_percent > 85:
                warnings.append("high_memory")
            if disk_percent > 90:
                warnings.append("low_disk_space")
            
            # Log health status
            level = LogLevel.WARNING if warnings else LogLevel.INFO
            message = f"System health check - {'Warnings: ' + ', '.join(warnings) if warnings else 'Healthy'}"
            
            self.logger.log(
                level,
                message,
                event_type=EventType.SYSTEM_HEALTH,
                metadata=health_data,
                tags=warnings if warnings else ['healthy']
            )
            
        except Exception as e:
            self.logger.error(f"System health check failed: {e}")
    
    def get_system_info(self) -> Dict:
        """Get current system information"""
        try:
            return {
                'cpu_percent': psutil.cpu_percent(),
                'memory_percent': psutil.virtual_memory().percent,
                'disk_percent': psutil.disk_usage('/').percent,
                'load_average': os.getloadavg() if hasattr(os, 'getloadavg') else None,
                'uptime_seconds': time.time() - psutil.boot_time(),
                'process_count': len(psutil.pids()),
                'network_connections': len(psutil.net_connections())
            }
        except Exception as e:
            self.logger.error(f"Failed to get system info: {e}")
            return {}

# Global instances
structured_logger = StructuredLogger()
performance_monitor = PerformanceMonitor(structured_logger)
system_monitor = SystemMonitor(structured_logger)

def get_request_id():
    """Get or generate request ID"""
    if not hasattr(g, 'request_id'):
        g.request_id = str(uuid.uuid4())
    return g.request_id

def log_api_request(func):
    """Decorator to log API requests"""
    @wraps(func)
    def decorated_function(*args, **kwargs):
        request_id = get_request_id()
        start_time = time.time()
        
        # Log request
        structured_logger.info(
            f"API request: {request.method} {request.path}",
            event_type=EventType.API_REQUEST,
            request_id=request_id,
            ip_address=request.remote_addr,
            user_agent=request.headers.get('User-Agent'),
            endpoint=request.path,
            method=request.method,
            metadata={
                'query_params': dict(request.args),
                'content_length': request.content_length
            }
        )
        
        try:
            # Execute request
            response = func(*args, **kwargs)
            
            # Calculate response time
            response_time_ms = (time.time() - start_time) * 1000
            
            # Get status code
            status_code = getattr(response, 'status_code', 200)
            
            # Log response
            structured_logger.info(
                f"API response: {request.method} {request.path} - {status_code}",
                event_type=EventType.API_RESPONSE,
                request_id=request_id,
                endpoint=request.path,
                method=request.method,
                status_code=status_code,
                response_time_ms=response_time_ms
            )
            
            # Record performance metrics
            performance_monitor.record_request(response_time_ms, status_code, request.path)
            
            return response
            
        except Exception as e:
            # Calculate response time
            response_time_ms = (time.time() - start_time) * 1000
            
            # Log error
            structured_logger.error(
                f"API error: {request.method} {request.path} - {str(e)}",
                event_type=EventType.ERROR,
                request_id=request_id,
                endpoint=request.path,
                method=request.method,
                response_time_ms=response_time_ms,
                error_details={
                    'error_type': type(e).__name__,
                    'error_message': str(e),
                    'traceback': traceback.format_exc()
                }
            )
            
            # Record performance metrics
            performance_monitor.record_request(response_time_ms, 500, request.path)
            
            raise
    
    return decorated_function

def log_security_event(event_type: str, details: Dict, level: LogLevel = LogLevel.WARNING):
    """Log security event"""
    structured_logger.log(
        level,
        f"Security event: {event_type}",
        event_type=EventType.SECURITY_EVENT,
        request_id=getattr(g, 'request_id', None),
        ip_address=request.remote_addr if request else None,
        metadata={'security_event_type': event_type, **details}
    )
    
    performance_monitor.record_security_event(event_type, details)

@contextmanager
def log_performance(operation: str, metadata: Dict = None):
    """Context manager for performance logging"""
    start_time = time.time()
    request_id = get_request_id()
    
    try:
        structured_logger.debug(
            f"Starting operation: {operation}",
            event_type=EventType.PERFORMANCE_METRIC,
            request_id=request_id,
            metadata={'operation': operation, 'phase': 'start', **(metadata or {})}
        )
        
        yield
        
    except Exception as e:
        duration_ms = (time.time() - start_time) * 1000
        
        structured_logger.error(
            f"Operation failed: {operation} - {str(e)}",
            event_type=EventType.ERROR,
            request_id=request_id,
            metadata={
                'operation': operation,
                'duration_ms': duration_ms,
                'phase': 'error',
                **(metadata or {})
            },
            error_details={
                'error_type': type(e).__name__,
                'error_message': str(e)
            }
        )
        raise
    
    else:
        duration_ms = (time.time() - start_time) * 1000
        
        structured_logger.info(
            f"Operation completed: {operation}",
            event_type=EventType.PERFORMANCE_METRIC,
            request_id=request_id,
            metadata={
                'operation': operation,
                'duration_ms': duration_ms,
                'phase': 'completed',
                **(metadata or {})
            }
        )

def init_logging(app: Flask):
    """Initialize structured logging with Flask app"""
    # Configure logging level from environment
    log_level = os.environ.get('LOG_LEVEL', 'INFO').upper()
    structured_logger.logger.setLevel(getattr(logging, log_level))
    
    # Start system monitoring
    system_monitor.start_monitoring()
    
    # Add request ID to each request
    @app.before_request
    def before_request():
        g.request_id = str(uuid.uuid4())
        g.start_time = time.time()
    
    # Add logging endpoints
    @app.route('/api/logging/stats', methods=['GET'])
    def get_logging_stats():
        """Get logging and performance statistics"""
        return jsonify({
            'success': True,
            'data': {
                'performance_metrics': performance_monitor.get_metrics(),
                'system_info': system_monitor.get_system_info()
            }
        })
    
    @app.route('/api/logging/reset-metrics', methods=['POST'])
    def reset_metrics():
        """Reset performance metrics"""
        performance_monitor.reset_metrics()
        structured_logger.info("Performance metrics reset", event_type=EventType.AUDIT)
        
        return jsonify({
            'success': True,
            'message': 'Metrics reset successfully'
        })
    
    @app.route('/api/logging/test-event', methods=['POST'])
    def test_log_event():
        """Test logging with custom event"""
        try:
            data = request.get_json() or {}
            message = data.get('message', 'Test log event')
            level = data.get('level', 'INFO')
            event_type = data.get('event_type', 'SYSTEM_HEALTH')
            metadata = data.get('metadata', {})
            
            log_level = getattr(LogLevel, level.upper(), LogLevel.INFO)
            log_event_type = getattr(EventType, event_type.upper(), EventType.SYSTEM_HEALTH)
            
            structured_logger.log(
                log_level,
                message,
                event_type=log_event_type,
                request_id=get_request_id(),
                metadata=metadata
            )
            
            return jsonify({
                'success': True,
                'message': 'Test event logged successfully'
            })
            
        except Exception as e:
            return jsonify({
                'success': False,
                'error': str(e)
            }), 500
    
    structured_logger.info("Structured logging initialized", event_type=EventType.SYSTEM_HEALTH)

# Cleanup function
def cleanup_logging():
    """Cleanup logging resources"""
    system_monitor.stop_monitoring()
