"""
MITRE ATT&CK Visualization for Athena Network Response Management

This module provides comprehensive MITRE ATT&CK framework integration with
visual kill chain representation, tactic/technique mapping, and attack
path analysis to enable faster threat analysis and detection.
"""

import json
import logging
from typing import List, Dict, Any, Optional, Set, Tuple
from datetime import datetime, timedelta
from dataclasses import dataclass, asdict
from enum import Enum
import networkx as nx
import matplotlib.pyplot as plt
import matplotlib.patches as patches
from matplotlib.patches import FancyBboxPatch
import base64
from io import BytesIO
import numpy as np
from collections import defaultdict, Counter
import hashlib

logger = logging.getLogger(__name__)

class TacticPhase(Enum):
    """MITRE ATT&CK tactic phases"""
    INITIAL_ACCESS = "initial-access"
    EXECUTION = "execution"
    PERSISTENCE = "persistence"
    PRIVILEGE_ESCALATION = "privilege-escalation"
    DEFENSE_EVASION = "defense-evasion"
    CREDENTIAL_ACCESS = "credential-access"
    DISCOVERY = "discovery"
    LATERAL_MOVEMENT = "lateral-movement"
    COLLECTION = "collection"
    COMMAND_AND_CONTROL = "command-and-control"
    EXFILTRATION = "exfiltration"
    IMPACT = "impact"

@dataclass
class MITRETactic:
    """MITRE ATT&CK tactic definition"""
    id: str
    name: str
    description: str
    phase: TacticPhase
    techniques: List[str]
    
@dataclass
class MITRETechnique:
    """MITRE ATT&CK technique definition"""
    id: str
    name: str
    description: str
    tactic_id: str
    tactic_name: str
    subtechniques: List[str]
    detection_methods: List[str]
    mitigation_strategies: List[str]
    
@dataclass
class AttackPath:
    """Attack path representation"""
    path_id: str
    tactics: List[str]
    techniques: List[str]
    confidence: float
    severity: str
    description: str
    evidence: List[Dict[str, Any]]
    recommended_actions: List[str]
    
@dataclass
class KillChainVisualization:
    """Kill chain visualization data"""
    attack_paths: List[AttackPath]
    timeline: List[Dict[str, Any]]
    affected_assets: List[str]
    threat_actors: List[str]
    overall_risk: str
    coverage_gaps: List[str]

class MITREAttackFramework:
    """MITRE ATT&CK framework data and operations"""
    
    def __init__(self):
        self.tactics = {}
        self.techniques = {}
        self.tactic_technique_mapping = defaultdict(list)
        self.technique_tactic_mapping = {}
        
        # Initialize MITRE ATT&CK data
        self._initialize_mitre_data()
    
    def _initialize_mitre_data(self):
        """Initialize MITRE ATT&CK framework data"""
        
        # MITRE ATT&CK Tactics
        tactics_data = {
            "TA0001": {
                "id": "TA0001",
                "name": "Initial Access",
                "description": "The adversary is trying to get into your network.",
                "phase": TacticPhase.INITIAL_ACCESS
            },
            "TA0002": {
                "id": "TA0002", 
                "name": "Execution",
                "description": "The adversary is trying to run malicious code.",
                "phase": TacticPhase.EXECUTION
            },
            "TA0003": {
                "id": "TA0003",
                "name": "Persistence", 
                "description": "The adversary is trying to maintain their foothold.",
                "phase": TacticPhase.PERSISTENCE
            },
            "TA0004": {
                "id": "TA0004",
                "name": "Privilege Escalation",
                "description": "The adversary is trying to gain higher-level permissions.",
                "phase": TacticPhase.PRIVILEGE_ESCALATION
            },
            "TA0005": {
                "id": "TA0005",
                "name": "Defense Evasion",
                "description": "The adversary is trying to avoid being detected.",
                "phase": TacticPhase.DEFENSE_EVASION
            },
            "TA0006": {
                "id": "TA0006",
                "name": "Credential Access",
                "description": "The adversary is trying to steal account names and passwords.",
                "phase": TacticPhase.CREDENTIAL_ACCESS
            },
            "TA0007": {
                "id": "TA0007",
                "name": "Discovery",
                "description": "The adversary is trying to figure out your environment.",
                "phase": TacticPhase.DISCOVERY
            },
            "TA0008": {
                "id": "TA0008",
                "name": "Lateral Movement",
                "description": "The adversary is trying to move through your environment.",
                "phase": TacticPhase.LATERAL_MOVEMENT
            },
            "TA0009": {
                "id": "TA0009",
                "name": "Collection",
                "description": "The adversary is trying to gather data of interest to their goal.",
                "phase": TacticPhase.COLLECTION
            },
            "TA0011": {
                "id": "TA0011",
                "name": "Command and Control",
                "description": "The adversary is trying to communicate with compromised systems.",
                "phase": TacticPhase.COMMAND_AND_CONTROL
            },
            "TA0010": {
                "id": "TA0010",
                "name": "Exfiltration",
                "description": "The adversary is trying to steal data.",
                "phase": TacticPhase.EXFILTRATION
            },
            "TA0040": {
                "id": "TA0040",
                "name": "Impact",
                "description": "The adversary is trying to manipulate, interrupt, or destroy your systems and data.",
                "phase": TacticPhase.IMPACT
            }
        }
        
        # MITRE ATT&CK Techniques (subset for demonstration)
        techniques_data = {
            # Initial Access
            "T1078": {
                "id": "T1078",
                "name": "Valid Accounts",
                "description": "Adversaries may obtain and abuse credentials of existing accounts.",
                "tactic_id": "TA0001",
                "tactic_name": "Initial Access",
                "detection_methods": ["Account monitoring", "Failed login tracking", "Unusual access patterns"],
                "mitigation_strategies": ["Multi-factor authentication", "Account lockout policies", "Privileged access management"]
            },
            "T1190": {
                "id": "T1190",
                "name": "Exploit Public-Facing Application",
                "description": "Adversaries may attempt to take advantage of a weakness in an Internet-facing computer program.",
                "tactic_id": "TA0001",
                "tactic_name": "Initial Access",
                "detection_methods": ["Web application firewall", "Anomaly detection", "Vulnerability scanning"],
                "mitigation_strategies": ["Regular patching", "Web application firewall", "Input validation"]
            },
            "T1566": {
                "id": "T1566",
                "name": "Phishing",
                "description": "Adversaries may send phishing emails to target users.",
                "tactic_id": "TA0001",
                "tactic_name": "Initial Access",
                "detection_methods": ["Email filtering", "User training", "Link analysis"],
                "mitigation_strategies": ["Email security gateway", "User awareness training", "Anti-phishing policies"]
            },
            
            # Execution
            "T1059": {
                "id": "T1059",
                "name": "Command and Scripting Interpreter",
                "description": "Adversaries may abuse command and script interpreters to execute commands.",
                "tactic_id": "TA0002",
                "tactic_name": "Execution",
                "detection_methods": ["Process monitoring", "Command line logging", "Script analysis"],
                "mitigation_strategies": ["Application whitelisting", "PowerShell logging", "Command audit"]
            },
            "T1203": {
                "id": "T1203",
                "name": "Exploitation for Client Execution",
                "description": "Adversaries may exploit software vulnerabilities to execute code.",
                "tactic_id": "TA0002",
                "tactic_name": "Execution",
                "detection_methods": ["Exploit detection", "Memory analysis", "Behavior monitoring"],
                "mitigation_strategies": ["Application patching", "Memory protection", "Sandboxing"]
            },
            
            # Persistence
            "T1543": {
                "id": "T1543",
                "name": "Create or Modify System Process",
                "description": "Adversaries may create or modify system processes to repeatedly execute malicious code.",
                "tactic_id": "TA0003",
                "tactic_name": "Persistence",
                "detection_methods": ["Service monitoring", "Process creation tracking", "Registry monitoring"],
                "mitigation_strategies": ["Service configuration management", "Process monitoring", "Registry protection"]
            },
            "T1053": {
                "id": "T1053",
                "name": "Scheduled Task/Job",
                "description": "Adversaries may abuse task scheduling functionality to execute code.",
                "tactic_id": "TA0003",
                "tactic_name": "Persistence",
                "detection_methods": ["Task scheduler monitoring", "Cron job analysis", "Scheduled task auditing"],
                "mitigation_strategies": ["Task scheduler restrictions", "Cron job monitoring", "User permission controls"]
            },
            
            # Privilege Escalation
            "T1068": {
                "id": "T1068",
                "name": "Exploitation for Privilege Escalation",
                "description": "Adversaries may exploit software vulnerabilities to elevate privileges.",
                "tactic_id": "TA0004",
                "tactic_name": "Privilege Escalation",
                "detection_methods": ["Vulnerability scanning", "Privilege monitoring", "System integrity checks"],
                "mitigation_strategies": ["Regular patching", "Principle of least privilege", "System hardening"]
            },
            "T1078": {
                "id": "T1078",
                "name": "Valid Accounts",
                "description": "Adversaries may obtain and abuse credentials of existing accounts.",
                "tactic_id": "TA0004",
                "tactic_name": "Privilege Escalation",
                "detection_methods": ["Account monitoring", "Privilege escalation detection", "Access pattern analysis"],
                "mitigation_strategies": ["Privileged access management", "Account separation", "Regular access reviews"]
            },
            
            # Defense Evasion
            "T1027": {
                "id": "T1027",
                "name": "Obfuscated Files or Information",
                "description": "Adversaries may attempt to make their executables or files difficult to discover or analyze.",
                "tactic_id": "TA0005",
                "tactic_name": "Defense Evasion",
                "detection_methods": ["File analysis", "Entropy detection", "Pattern recognition"],
                "mitigation_strategies": ["File scanning", "Behavioral analysis", "Sandboxing"]
            },
            "T1112": {
                "id": "T1112",
                "name": "Modify Registry",
                "description": "Adversaries may modify registry settings to evade defenses.",
                "tactic_id": "TA0005",
                "tactic_name": "Defense Evasion",
                "detection_methods": ["Registry monitoring", "Change detection", "Configuration auditing"],
                "mitigation_strategies": ["Registry protection", "Configuration management", "Integrity monitoring"]
            },
            
            # Credential Access
            "T1003": {
                "id": "T1003",
                "name": "OS Credential Dumping",
                "description": "Adversaries may attempt to dump credentials to obtain account login information.",
                "tactic_id": "TA0006",
                "tactic_name": "Credential Access",
                "detection_methods": ["Memory monitoring", "Process tracking", "File access monitoring"],
                "mitigation_strategies": ["Credential protection", "Memory encryption", "Access control"]
            },
            "T1110": {
                "id": "T1110",
                "name": "Brute Force",
                "description": "Adversaries may use brute force techniques to gain access to accounts.",
                "tactic_id": "TA0006",
                "tactic_name": "Credential Access",
                "detection_methods": ["Failed login monitoring", "Account lockout tracking", "Anomaly detection"],
                "mitigation_strategies": ["Account lockout policies", "Multi-factor authentication", "Rate limiting"]
            },
            
            # Discovery
            "T1082": {
                "id": "T1082",
                "name": "System Information Discovery",
                "description": "Adversaries may attempt to gather detailed information about the system.",
                "tactic_id": "TA0007",
                "tactic_name": "Discovery",
                "detection_methods": ["System call monitoring", "Command tracking", "Information access logging"],
                "mitigation_strategies": ["Access control", "System monitoring", "Information classification"]
            },
            "T1033": {
                "id": "T1033",
                "name": "System Owner/User Discovery",
                "description": "Adversaries may attempt to identify the primary user on a system.",
                "tactic_id": "TA0007",
                "tactic_name": "Discovery",
                "detection_methods": ["User enumeration monitoring", "Account access tracking", "System query logging"],
                "mitigation_strategies": ["User access controls", "Account information protection", "Query monitoring"]
            },
            "T1046": {
                "id": "T1046",
                "name": "Network Service Scanning",
                "description": "Adversaries may attempt to get a listing of services running on remote hosts.",
                "tactic_id": "TA0007",
                "tactic_name": "Discovery",
                "detection_methods": ["Network monitoring", "Port scan detection", "Service enumeration tracking"],
                "mitigation_strategies": ["Network segmentation", "Port filtering", "Service access controls"]
            },
            
            # Lateral Movement
            "T1021": {
                "id": "T1021",
                "name": "Remote Services",
                "description": "Adversaries may use remote desktop protocol to move laterally.",
                "tactic_id": "TA0008",
                "tactic_name": "Lateral Movement",
                "detection_methods": ["Remote access monitoring", "Connection tracking", "Authentication logging"],
                "mitigation_strategies": ["Network segmentation", "Remote access controls", "Multi-factor authentication"]
            },
            "T1077": {
                "id": "T1077",
                "name": "Windows Admin Shares",
                "description": "Adversaries may use admin shares to move laterally.",
                "tactic_id": "TA0008",
                "tactic_name": "Lateral Movement",
                "detection_methods": ["Share access monitoring", "Network traffic analysis", "File access tracking"],
                "mitigation_strategies": ["Share access controls", "Network monitoring", "File system protection"]
            },
            
            # Collection
            "T1113": {
                "id": "T1113",
                "name": "Screen Capture",
                "description": "Adversaries may attempt to gather information about the system.",
                "tactic_id": "TA0009",
                "tactic_name": "Collection",
                "detection_methods": ["Screen capture monitoring", "Process tracking", "File access monitoring"],
                "mitigation_strategies": ["Application control", "Screen capture protection", "User awareness"]
            },
            "T1115": {
                "id": "T1115",
                "name": "Clipboard Data",
                "description": "Adversaries may access clipboard data to gather information.",
                "tactic_id": "TA0009",
                "tactic_name": "Collection",
                "detection_methods": ["Clipboard monitoring", "Process tracking", "Memory analysis"],
                "mitigation_strategies": ["Clipboard protection", "Application monitoring", "Memory protection"]
            },
            
            # Command and Control
            "T1071": {
                "id": "T1071",
                "name": "Application Layer Protocol",
                "description": "Adversaries may communicate using application layer protocols.",
                "tactic_id": "TA0011",
                "tactic_name": "Command and Control",
                "detection_methods": ["Network traffic analysis", "Protocol monitoring", "Anomaly detection"],
                "mitigation_strategies": ["Network segmentation", "Protocol filtering", "Traffic analysis"]
            },
            "T1095": {
                "id": "T1095",
                "name": "Non-Application Layer Protocol",
                "description": "Adversaries may use non-application layer protocols for communication.",
                "tactic_id": "TA0011",
                "tactic_name": "Command and Control",
                "detection_methods": ["Network monitoring", "Protocol analysis", "Traffic pattern detection"],
                "mitigation_strategies": ["Network filtering", "Protocol controls", "Traffic monitoring"]
            },
            
            # Exfiltration
            "T1041": {
                "id": "T1041",
                "name": "Exfiltration Over C2 Channel",
                "description": "Adversaries may exfiltrate data over command and control channels.",
                "tactic_id": "TA0010",
                "tactic_name": "Exfiltration",
                "detection_methods": ["Data loss prevention", "Traffic monitoring", "Content analysis"],
                "mitigation_strategies": ["Data loss prevention", "Network monitoring", "Encryption controls"]
            },
            "T1567": {
                "id": "T1567",
                "name": "Exfiltration Over Web Service",
                "description": "Adversaries may exfiltrate data using web services.",
                "tactic_id": "TA0010",
                "tactic_name": "Exfiltration",
                "detection_methods": ["Web traffic monitoring", "Data transfer tracking", "Content analysis"],
                "mitigation_strategies": ["Web filtering", "Data loss prevention", "Upload controls"]
            },
            
            # Impact
            "T1486": {
                "id": "T1486",
                "name": "Data Encrypted for Impact",
                "description": "Adversaries may encrypt data for impact on the victim.",
                "tactic_id": "TA0040",
                "tactic_name": "Impact",
                "detection_methods": ["File monitoring", "Encryption detection", "Ransomware signatures"],
                "mitigation_strategies": ["Backup systems", "File integrity monitoring", "Ransomware protection"]
            },
            "T1485": {
                "id": "T1485",
                "name": "Data Destruction",
                "description": "Adversaries may destroy data to impact victim operations.",
                "tactic_id": "TA0040",
                "tactic_name": "Impact",
                "detection_methods": ["File deletion monitoring", "Data integrity checks", "System logging"],
                "mitigation_strategies": ["Backup systems", "Access controls", "Data protection"]
            }
        }
        
        # Create tactic objects
        for tactic_id, tactic_data in tactics_data.items():
            self.tactics[tactic_id] = MITRETactic(
                id=tactic_data["id"],
                name=tactic_data["name"],
                description=tactic_data["description"],
                phase=tactic_data["phase"],
                techniques=[]
            )
        
        # Create technique objects and build mappings
        for tech_id, tech_data in techniques_data.items():
            technique = MITRETechnique(
                id=tech_data["id"],
                name=tech_data["name"],
                description=tech_data["description"],
                tactic_id=tech_data["tactic_id"],
                tactic_name=tech_data["tactic_name"],
                subtechniques=[],
                detection_methods=tech_data["detection_methods"],
                mitigation_strategies=tech_data["mitigation_strategies"]
            )
            
            self.techniques[tech_id] = technique
            self.tactic_technique_mapping[tech_data["tactic_id"]].append(tech_id)
            self.technique_tactic_mapping[tech_id] = tech_data["tactic_id"]
        
        # Update tactics with their techniques
        for tactic_id, technique_ids in self.tactic_technique_mapping.items():
            if tactic_id in self.tactics:
                self.tactics[tactic_id].techniques = technique_ids
        
        logger.info(f"Initialized MITRE ATT&CK framework with {len(self.tactics)} tactics and {len(self.techniques)} techniques")

class MITREVisualizationEngine:
    """MITRE ATT&CK visualization and analysis engine"""
    
    def __init__(self, app=None):
        self.app = app
        self.enabled = True
        self.framework = MITREAttackFramework()
        self.attack_graph = nx.DiGraph()
        self.visualization_cache = {}
        self.cache_ttl = 3600  # 1 hour
        
        if app is not None:
            self.init_app(app)
    
    def init_app(self, app):
        """Initialize visualization engine with Flask app"""
        self.enabled = app.config.get('MITRE_VISUALIZATION_ENABLED', True)
        logger.info(f"MITRE visualization engine initialized: enabled={self.enabled}")
    
    def analyze_attack_patterns(self, alerts: List[Dict[str, Any]]) -> KillChainVisualization:
        """Analyze alerts and create attack pattern visualization"""
        if not self.enabled or not alerts:
            return self._create_empty_visualization()
        
        try:
            # Extract MITRE tactics and techniques from alerts
            alert_mitre_data = self._extract_mitre_data_from_alerts(alerts)
            
            # Build attack graph
            attack_graph = self._build_attack_graph(alert_mitre_data)
            
            # Identify attack paths
            attack_paths = self._identify_attack_paths(attack_graph, alert_mitre_data)
            
            # Create timeline
            timeline = self._create_attack_timeline(alerts, alert_mitre_data)
            
            # Identify affected assets
            affected_assets = self._identify_affected_assets(alerts)
            
            # Identify potential threat actors
            threat_actors = self._identify_threat_actors(alert_mitre_data)
            
            # Calculate overall risk
            overall_risk = self._calculate_overall_risk(attack_paths, alerts)
            
            # Identify coverage gaps
            coverage_gaps = self._identify_coverage_gaps(attack_paths)
            
            return KillChainVisualization(
                attack_paths=attack_paths,
                timeline=timeline,
                affected_assets=affected_assets,
                threat_actors=threat_actors,
                overall_risk=overall_risk,
                coverage_gaps=coverage_gaps
            )
            
        except Exception as e:
            logger.error(f"Error analyzing attack patterns: {e}")
            return self._create_empty_visualization()
    
    def generate_kill_chain_diagram(self, visualization: KillChainVisualization) -> str:
        """Generate kill chain diagram as base64 image"""
        try:
            # Create figure
            fig, ax = plt.subplots(figsize=(16, 10))
            fig.patch.set_facecolor('white')
            
            # Define tactic positions and colors
            tactic_positions = self._get_tactic_positions()
            tactic_colors = self._get_tactic_colors()
            
            # Draw tactics as boxes
            for tactic_id, (x, y, width, height) in tactic_positions.items():
                if tactic_id in self.framework.tactics:
                    tactic = self.framework.tactics[tactic_id]
                    
                    # Check if tactic is in attack paths
                    is_active = any(tactic_id in path.tactics for path in visualization.attack_paths)
                    
                    color = tactic_colors[tactic_id] if is_active else '#E8E8E8'
                    alpha = 0.8 if is_active else 0.3
                    
                    # Draw tactic box
                    rect = FancyBboxPatch(
                        (x, y), width, height,
                        boxstyle="round,pad=0.05",
                        facecolor=color,
                        edgecolor='black',
                        alpha=alpha,
                        linewidth=2 if is_active else 1
                    )
                    ax.add_patch(rect)
                    
                    # Add tactic name
                    ax.text(x + width/2, y + height/2, tactic.name,
                           ha='center', va='center', fontsize=10, fontweight='bold')
            
            # Draw attack paths
            for i, path in enumerate(visualization.attack_paths):
                self._draw_attack_path(ax, path, tactic_positions, i)
            
            # Add legend
            self._add_legend(ax, visualization)
            
            # Set plot properties
            ax.set_xlim(0, 20)
            ax.set_ylim(0, 12)
            ax.set_aspect('equal')
            ax.axis('off')
            ax.set_title('MITRE ATT&CK Kill Chain Analysis', fontsize=16, fontweight='bold', pad=20)
            
            # Convert to base64
            buffer = BytesIO()
            plt.savefig(buffer, format='png', dpi=150, bbox_inches='tight')
            buffer.seek(0)
            image_base64 = base64.b64encode(buffer.getvalue()).decode()
            plt.close()
            
            return image_base64
            
        except Exception as e:
            logger.error(f"Error generating kill chain diagram: {e}")
            return ""
    
    def generate_technique_heatmap(self, alerts: List[Dict[str, Any]]) -> str:
        """Generate technique frequency heatmap"""
        try:
            # Count technique frequencies
            technique_counts = Counter()
            tactic_technique_counts = defaultdict(Counter)
            
            for alert in alerts:
                techniques = self._extract_techniques_from_alert(alert)
                for technique_id in techniques:
                    technique_counts[technique_id] += 1
                    tactic_id = self.framework.technique_tactic_mapping.get(technique_id)
                    if tactic_id:
                        tactic_technique_counts[tactic_id][technique_id] += 1
            
            if not technique_counts:
                return ""
            
            # Create heatmap data
            tactics = list(self.framework.tactics.keys())
            techniques = list(technique_counts.keys())
            
            # Create matrix
            matrix = np.zeros((len(tactics), len(techniques)))
            for i, tactic_id in enumerate(tactics):
                for j, technique_id in enumerate(techniques):
                    matrix[i, j] = tactic_technique_counts[tactic_id][technique_id]
            
            # Create heatmap
            fig, ax = plt.subplots(figsize=(14, 8))
            
            # Plot heatmap
            im = ax.imshow(matrix, cmap='Reds', aspect='auto')
            
            # Set labels
            ax.set_xticks(range(len(techniques)))
            ax.set_xticklabels([self.framework.techniques[t].name for t in techniques], rotation=45, ha='right')
            ax.set_yticks(range(len(tactics)))
            ax.set_yticklabels([self.framework.tactics[t].name for t in tactics])
            
            # Add colorbar
            plt.colorbar(im, ax=ax, label='Frequency')
            
            # Add title
            ax.set_title('MITRE ATT&CK Technique Frequency Heatmap', fontsize=14, fontweight='bold')
            
            # Convert to base64
            buffer = BytesIO()
            plt.savefig(buffer, format='png', dpi=150, bbox_inches='tight')
            buffer.seek(0)
            image_base64 = base64.b64encode(buffer.getvalue()).decode()
            plt.close()
            
            return image_base64
            
        except Exception as e:
            logger.error(f"Error generating technique heatmap: {e}")
            return ""
    
    def generate_attack_timeline(self, visualization: KillChainVisualization) -> str:
        """Generate attack timeline visualization"""
        try:
            if not visualization.timeline:
                return ""
            
            fig, ax = plt.subplots(figsize=(16, 8))
            
            # Group events by tactic
            tactic_events = defaultdict(list)
            for event in visualization.timeline:
                tactic_events[event['tactic']].append(event)
            
            # Define colors for tactics
            tactic_colors = self._get_tactic_colors()
            
            # Plot timeline
            y_pos = 0
            for tactic_id, events in tactic_events.items():
                if tactic_id in self.framework.tactics:
                    tactic = self.framework.tactics[tactic_id]
                    color = tactic_colors.get(tactic_id, '#CCCCCC')
                    
                    for event in events:
                        start_time = event['timestamp']
                        duration = event.get('duration', 1)
                        
                        # Draw event bar
                        ax.barh(y_pos, duration, left=start_time, color=color, alpha=0.7, 
                               label=tactic.name if tactic_id not in [e['tactic'] for e in tactic_events[tactic_id][1:]] else "")
                        
                        # Add event label
                        ax.text(start_time + duration/2, y_pos, event.get('technique', ''),
                               ha='center', va='center', fontsize=8, fontweight='bold')
                    
                    y_pos += 1
            
            # Set plot properties
            ax.set_xlabel('Time', fontsize=12)
            ax.set_ylabel('Attack Tactics', fontsize=12)
            ax.set_title('Attack Timeline Analysis', fontsize=14, fontweight='bold')
            ax.grid(True, alpha=0.3)
            
            # Add legend
            handles, labels = ax.get_legend_handles_labels()
            if handles:
                ax.legend(handles, labels, bbox_to_anchor=(1.05, 1), loc='upper left')
            
            # Convert to base64
            buffer = BytesIO()
            plt.savefig(buffer, format='png', dpi=150, bbox_inches='tight')
            buffer.seek(0)
            image_base64 = base64.b64encode(buffer.getvalue()).decode()
            plt.close()
            
            return image_base64
            
        except Exception as e:
            logger.error(f"Error generating attack timeline: {e}")
            return ""
    
    def _extract_mitre_data_from_alerts(self, alerts: List[Dict[str, Any]]) -> Dict[str, Any]:
        """Extract MITRE tactics and techniques from alerts"""
        mitre_data = {
            'tactics': set(),
            'techniques': set(),
            'alert_mapping': []
        }
        
        for alert in alerts:
            alert_mitre = {
                'alert_id': alert.get('id'),
                'tactics': self._extract_tactics_from_alert(alert),
                'techniques': self._extract_techniques_from_alert(alert),
                'timestamp': alert.get('timestamp', datetime.utcnow()),
                'severity': alert.get('severity', 'medium')
            }
            
            mitre_data['tactics'].update(alert_mitre['tactics'])
            mitre_data['techniques'].update(alert_mitre['techniques'])
            mitre_data['alert_mapping'].append(alert_mitre)
        
        return mitre_data
    
    def _extract_tactics_from_alert(self, alert: Dict[str, Any]) -> List[str]:
        """Extract MITRE tactics from alert"""
        tactics = []
        
        # Check for explicit MITRE tactics
        if 'mitre_tactics' in alert:
            tactics.extend(alert['mitre_tactics'])
        
        # Extract from rule name or signature
        signature = alert.get('signature', '').lower()
        rule_name = alert.get('rule', '').lower()
        
        tactic_keywords = {
            "TA0001": ['initial access', 'reconnaissance', 'phishing', 'exploit public-facing'],
            "TA0002": ['execution', 'command', 'script', 'run malicious code'],
            "TA0003": ['persistence', 'backdoor', 'rootkit', 'maintain foothold'],
            "TA0004": ['privilege escalation', 'sudo', 'admin', 'elevated permissions'],
            "TA0005": ['defense evasion', 'obfuscation', 'anti-virus', 'hide'],
            "TA0006": ['credential access', 'password', 'hash', 'steal credentials'],
            "TA0007": ['discovery', 'scan', 'enum', 'system information'],
            "TA0008": ['lateral movement', 'remote', 'spread', 'move laterally'],
            "TA0009": ['collection', 'data gathering', 'exfil', 'gather data'],
            "TA0010": ['exfiltration', 'data transfer', 'upload', 'steal data'],
            "TA0011": ['command and control', 'c2', 'c&c', 'communication'],
            "TA0040": ['impact', 'ransomware', 'destruction', 'damage']
        }
        
        for tactic_id, keywords in tactic_keywords.items():
            if any(keyword in signature or keyword in rule_name for keyword in keywords):
                tactics.append(tactic_id)
        
        return list(set(tactics))
    
    def _extract_techniques_from_alert(self, alert: Dict[str, Any]) -> List[str]:
        """Extract MITRE techniques from alert"""
        techniques = []
        
        # Check for explicit MITRE techniques
        if 'mitre_techniques' in alert:
            techniques.extend(alert['mitre_techniques'])
        
        # Extract from rule name or signature
        signature = alert.get('signature', '').lower()
        rule_name = alert.get('rule', '').lower()
        
        technique_keywords = {
            "T1078": ['valid accounts', 'account creation', 'credentials'],
            "T1110": ['brute force', 'password spray', 'guessing'],
            "T1059": ['command line', 'powershell', 'bash', 'script'],
            "T1055": ['process injection', 'dll injection'],
            "T1053": ['scheduled task', 'cron job'],
            "T1543": ['service creation', 'new service'],
            "T1486": ['ransomware', 'encryption', 'file locked'],
            "T1046": ['port scan', 'network scan'],
            "T1040": ['network sniffing', 'packet capture'],
            "T1033": ['system owner', 'user discovery'],
            "T1082": ['system information', 'host discovery'],
            "T1190": ['exploit public-facing', 'web application'],
            "T1566": ['phishing', 'spear phishing'],
            "T1021": ['remote services', 'rdp', 'remote desktop'],
            "T1003": ['credential dumping', 'password dump'],
            "T1027": ['obfuscated', 'packed', 'encrypted'],
            "T1071": ['application layer protocol', 'http', 'dns'],
            "T1567": ['exfiltration over web', 'upload', 'data transfer']
        }
        
        for technique_id, keywords in technique_keywords.items():
            if any(keyword in signature or keyword in rule_name for keyword in keywords):
                techniques.append(technique_id)
        
        return list(set(techniques))
    
    def _build_attack_graph(self, mitre_data: Dict[str, Any]) -> nx.DiGraph:
        """Build attack graph from MITRE data"""
        graph = nx.DiGraph()
        
        # Add nodes for tactics and techniques
        for tactic_id in mitre_data['tactics']:
            if tactic_id in self.framework.tactics:
                tactic = self.framework.tactics[tactic_id]
                graph.add_node(tactic_id, type='tactic', name=tactic.name)
        
        for technique_id in mitre_data['techniques']:
            if technique_id in self.framework.techniques:
                technique = self.framework.techniques[technique_id]
                graph.add_node(technique_id, type='technique', name=technique.name)
                
                # Add edge from tactic to technique
                if technique.tactic_id in graph:
                    graph.add_edge(technique.tactic_id, technique_id)
        
        # Add temporal edges based on alert timestamps
        alert_mapping = mitre_data['alert_mapping']
        for i in range(len(alert_mapping) - 1):
            current_alert = alert_mapping[i]
            next_alert = alert_mapping[i + 1]
            
            # Connect techniques that appear sequentially
            current_techniques = current_alert['techniques']
            next_techniques = next_alert['techniques']
            
            for current_tech in current_techniques:
                for next_tech in next_techniques:
                    if current_tech in graph and next_tech in graph:
                        graph.add_edge(current_tech, next_tech, type='temporal')
        
        return graph
    
    def _identify_attack_paths(self, graph: nx.DiGraph, mitre_data: Dict[str, Any]) -> List[AttackPath]:
        """Identify attack paths in the graph"""
        attack_paths = []
        
        # Find paths from Initial Access to other tactics
        initial_access_nodes = [n for n in graph.nodes() 
                              if graph.nodes[n].get('type') == 'tactic' and 
                              n == 'TA0001']
        
        for start_node in initial_access_nodes:
            # Find all paths from this node
            for target_node in graph.nodes():
                if start_node != target_node:
                    try:
                        paths = list(nx.all_simple_paths(graph, start_node, target_node, cutoff=5))
                        for path in paths:
                            attack_path = self._create_attack_path(path, mitre_data)
                            if attack_path:
                                attack_paths.append(attack_path)
                    except nx.NetworkXNoPath:
                        continue
        
        # Sort by confidence and return top paths
        attack_paths.sort(key=lambda x: x.confidence, reverse=True)
        return attack_paths[:10]  # Return top 10 paths
    
    def _create_attack_path(self, path: List[str], mitre_data: Dict[str, Any]) -> Optional[AttackPath]:
        """Create attack path from node path"""
        if len(path) < 2:
            return None
        
        tactics = [node for node in path if self.framework.tactics.get(node)]
        techniques = [node for node in path if self.framework.techniques.get(node)]
        
        # Calculate confidence based on evidence
        evidence_count = sum(1 for alert in mitre_data['alert_mapping'] 
                           if any(tech in alert['techniques'] for tech in techniques))
        confidence = min(evidence_count / len(techniques), 1.0) if techniques else 0.0
        
        # Calculate severity
        severity = self._calculate_path_severity(techniques, mitre_data)
        
        # Generate description
        description = self._generate_path_description(tactics, techniques)
        
        # Get evidence
        evidence = [alert for alert in mitre_data['alert_mapping'] 
                   if any(tech in alert['techniques'] for tech in techniques)]
        
        # Generate recommended actions
        recommended_actions = self._generate_path_actions(tactics, techniques)
        
        return AttackPath(
            path_id=hashlib.md5(':'.join(path).encode()).hexdigest()[:16],
            tactics=tactics,
            techniques=techniques,
            confidence=confidence,
            severity=severity,
            description=description,
            evidence=evidence,
            recommended_actions=recommended_actions
        )
    
    def _calculate_path_severity(self, techniques: List[str], mitre_data: Dict[str, Any]) -> str:
        """Calculate severity of attack path"""
        if not techniques:
            return "Low"
        
        # Count high-impact techniques
        high_impact_techniques = {
            "T1486",  # Ransomware
            "T1485",  # Data Destruction
            "T1003",  # Credential Dumping
            "T1110",  # Brute Force
            "T1190",  # Exploit Public-Facing Application
        }
        
        high_impact_count = sum(1 for tech in techniques if tech in high_impact_techniques)
        
        if high_impact_count >= 2:
            return "Critical"
        elif high_impact_count >= 1:
            return "High"
        elif len(techniques) >= 5:
            return "Medium"
        else:
            return "Low"
    
    def _generate_path_description(self, tactics: List[str], techniques: List[str]) -> str:
        """Generate description for attack path"""
        tactic_names = [self.framework.tactics[t].name for t in tactics if t in self.framework.tactics]
        technique_names = [self.framework.techniques[t].name for t in techniques if t in self.framework.techniques]
        
        description = f"Attack path involving {len(tactics)} tactics: {', '.join(tactic_names[:3])}"
        if technique_names:
            description += f" with techniques: {', '.join(technique_names[:3])}"
        
        return description
    
    def _generate_path_actions(self, tactics: List[str], techniques: List[str]) -> List[str]:
        """Generate recommended actions for attack path"""
        actions = []
        
        # General actions
        actions.extend([
            "Investigate all alerts in this attack path",
            "Review affected systems for compromise",
            "Implement additional monitoring for observed techniques"
        ])
        
        # Technique-specific actions
        for technique_id in techniques:
            if technique_id in self.framework.techniques:
                technique = self.framework.techniques[technique_id]
                actions.extend(technique.mitigation_strategies[:2])  # Add top 2 mitigations
        
        return list(set(actions))  # Remove duplicates
    
    def _create_attack_timeline(self, alerts: List[Dict[str, Any]], mitre_data: Dict[str, Any]) -> List[Dict[str, Any]]:
        """Create attack timeline from alerts"""
        timeline = []
        
        for alert in mitre_data['alert_mapping']:
            for technique_id in alert['techniques']:
                if technique_id in self.framework.techniques:
                    technique = self.framework.techniques[technique_id]
                    
                    timeline_event = {
                        'timestamp': alert['timestamp'],
                        'tactic': technique.tactic_id,
                        'technique': technique.name,
                        'technique_id': technique_id,
                        'alert_id': alert['alert_id'],
                        'severity': alert['severity'],
                        'duration': 1  # Default duration
                    }
                    timeline.append(timeline_event)
        
        # Sort by timestamp
        timeline.sort(key=lambda x: x['timestamp'])
        
        return timeline
    
    def _identify_affected_assets(self, alerts: List[Dict[str, Any]]) -> List[str]:
        """Identify affected assets from alerts"""
        assets = set()
        
        for alert in alerts:
            # Extract from various fields
            for field in ['src_ip', 'dest_ip', 'hostname', 'asset', 'target']:
                if field in alert and alert[field]:
                    assets.add(str(alert[field]))
        
        return list(assets)
    
    def _identify_threat_actors(self, mitre_data: Dict[str, Any]) -> List[str]:
        """Identify potential threat actors based on techniques"""
        threat_actors = []
        
        # Simple threat actor mapping based on technique patterns
        technique_patterns = {
            "APT28": ["T1190", "T1059", "T1003", "T1021"],
            "APT29": ["T1566", "T1055", "T1082", "T1041"],
            "Lazarus": ["T1190", "T1059", "T1486", "T1071"],
            "FIN7": ["T1566", "T1203", "T1003", "T1110"],
            "Conti": ["T1190", "T1110", "T1486", "T1021"]
        }
        
        observed_techniques = set(mitre_data['techniques'])
        
        for actor, techniques in technique_patterns.items():
            overlap = len(observed_techniques & set(techniques))
            if overlap >= 2:  # At least 2 matching techniques
                threat_actors.append(actor)
        
        return threat_actors
    
    def _calculate_overall_risk(self, attack_paths: List[AttackPath], alerts: List[Dict[str, Any]]) -> str:
        """Calculate overall risk score"""
        if not attack_paths:
            return "Low"
        
        # Factor in number of attack paths, confidence, and severity
        high_confidence_paths = [p for p in attack_paths if p.confidence > 0.7]
        critical_paths = [p for p in attack_paths if p.severity == "Critical"]
        
        if len(critical_paths) >= 2 or len(high_confidence_paths) >= 3:
            return "Critical"
        elif len(critical_paths) >= 1 or len(high_confidence_paths) >= 2:
            return "High"
        elif len(attack_paths) >= 3:
            return "Medium"
        else:
            return "Low"
    
    def _identify_coverage_gaps(self, attack_paths: List[AttackPath]) -> List[str]:
        """Identify coverage gaps in detection"""
        gaps = []
        
        # Common techniques that are hard to detect
        hard_to_detect = {
            "T1055": "Process Injection",
            "T1027": "Obfuscated Files",
            "T1095": "Non-Application Layer Protocol",
            "T1112": "Modify Registry",
            "T1071": "Application Layer Protocol"
        }
        
        observed_techniques = set()
        for path in attack_paths:
            observed_techniques.update(path.techniques)
        
        for tech_id, tech_name in hard_to_detect.items():
            if tech_id in observed_techniques:
                gaps.append(f"Detection gap for {tech_name} ({tech_id})")
        
        return gaps
    
    def _create_empty_visualization(self) -> KillChainVisualization:
        """Create empty visualization for cases with no data"""
        return KillChainVisualization(
            attack_paths=[],
            timeline=[],
            affected_assets=[],
            threat_actors=[],
            overall_risk="Low",
            coverage_gaps=[]
        )
    
    def _get_tactic_positions(self) -> Dict[str, Tuple[float, float, float, float]]:
        """Get positions for tactics in kill chain diagram"""
        return {
            "TA0001": (1, 10, 2.5, 1.5),  # Initial Access
            "TA0002": (4, 10, 2.5, 1.5),  # Execution
            "TA0003": (7, 10, 2.5, 1.5),  # Persistence
            "TA0004": (10, 10, 2.5, 1.5), # Privilege Escalation
            "TA0005": (13, 10, 2.5, 1.5), # Defense Evasion
            "TA0006": (16, 10, 2.5, 1.5), # Credential Access
            "TA0007": (1, 7, 2.5, 1.5),   # Discovery
            "TA0008": (4, 7, 2.5, 1.5),   # Lateral Movement
            "TA0009": (7, 7, 2.5, 1.5),   # Collection
            "TA0011": (10, 7, 2.5, 1.5),  # Command and Control
            "TA0010": (13, 7, 2.5, 1.5),  # Exfiltration
            "TA0040": (16, 7, 2.5, 1.5)   # Impact
        }
    
    def _get_tactic_colors(self) -> Dict[str, str]:
        """Get colors for tactics"""
        return {
            "TA0001": "#FF6B6B",  # Initial Access - Red
            "TA0002": "#4ECDC4",  # Execution - Teal
            "TA0003": "#45B7D1",  # Persistence - Blue
            "TA0004": "#96CEB4",  # Privilege Escalation - Green
            "TA0005": "#FFEAA7",  # Defense Evasion - Yellow
            "TA0006": "#DDA0DD",  # Credential Access - Plum
            "TA0007": "#98D8C8",  # Discovery - Mint
            "TA0008": "#F7DC6F",  # Lateral Movement - Light Yellow
            "TA0009": "#BB8FCE",  # Collection - Purple
            "TA0011": "#85C1E2",  # Command and Control - Light Blue
            "TA0010": "#F8B739",  # Exfiltration - Orange
            "TA0040": "#EC7063"   # Impact - Dark Red
        }
    
    def _draw_attack_path(self, ax, path: AttackPath, positions: Dict[str, Tuple[float, float, float, float]], path_index: int):
        """Draw attack path on diagram"""
        if len(path.tactics) < 2:
            return
        
        # Get coordinates for tactics in path
        coords = []
        for tactic_id in path.tactics:
            if tactic_id in positions:
                x, y, w, h = positions[tactic_id]
                coords.append((x + w/2, y + h/2))
        
        if len(coords) < 2:
            return
        
        # Draw path lines
        for i in range(len(coords) - 1):
            x1, y1 = coords[i]
            x2, y2 = coords[i + 1]
            
            # Draw arrow
            ax.annotate('', xy=(x2, y2), xytext=(x1, y1),
                       arrowprops=dict(arrowstyle='->', lw=2, color='red', alpha=0.7))
        
        # Add path label
        if coords:
            mid_x = sum(c[0] for c in coords) / len(coords)
            mid_y = sum(c[1] for c in coords) / len(coords) + 0.5
            ax.text(mid_x, mid_y, f'Path {path_index + 1}', 
                   ha='center', va='center', fontsize=8, 
                   bbox=dict(boxstyle="round,pad=0.3", facecolor='white', alpha=0.8))
    
    def _add_legend(self, ax, visualization: KillChainVisualization):
        """Add legend to diagram"""
        legend_elements = []
        
        # Add attack path info
        if visualization.attack_paths:
            legend_elements.append(f"Attack Paths: {len(visualization.attack_paths)}")
            legend_elements.append(f"Overall Risk: {visualization.overall_risk}")
        
        if visualization.threat_actors:
            legend_elements.append(f"Threat Actors: {', '.join(visualization.threat_actors[:3])}")
        
        if legend_elements:
            ax.text(0.02, 0.98, '\n'.join(legend_elements), 
                   transform=ax.transAxes, fontsize=10,
                   verticalalignment='top',
                   bbox=dict(boxstyle='round', facecolor='wheat', alpha=0.8))

# Global visualization engine instance
mitre_engine = MITREVisualizationEngine()

# Flask integration
def init_mitre_visualization(app):
    """Initialize MITRE visualization engine with Flask app"""
    mitre_engine.init_app(app)
    
    # Add MITRE visualization endpoints
    @app.route('/api/mitre/analyze', methods=['POST'])
    def analyze_attack_patterns():
        """Analyze attack patterns from alerts"""
        try:
            data = request.get_json()
            alerts = data.get('alerts', [])
            
            if not alerts:
                return jsonify({
                    'success': False,
                    'error': 'No alerts provided for analysis'
                }), 400
            
            visualization = mitre_engine.analyze_attack_patterns(alerts)
            
            return jsonify({
                'success': True,
                'data': asdict(visualization)
            })
            
        except Exception as e:
            return jsonify({
                'success': False,
                'error': str(e)
            }), 500
    
    @app.route('/api/mitre/kill-chain', methods=['POST'])
    def generate_kill_chain():
        """Generate kill chain diagram"""
        try:
            data = request.get_json()
            alerts = data.get('alerts', [])
            
            if not alerts:
                return jsonify({
                    'success': False,
                    'error': 'No alerts provided for analysis'
                }), 400
            
            visualization = mitre_engine.analyze_attack_patterns(alerts)
            diagram = mitre_engine.generate_kill_chain_diagram(visualization)
            
            return jsonify({
                'success': True,
                'data': {
                    'diagram': diagram,
                    'visualization': asdict(visualization)
                }
            })
            
        except Exception as e:
            return jsonify({
                'success': False,
                'error': str(e)
            }), 500
    
    @app.route('/api/mitre/heatmap', methods=['POST'])
    def generate_technique_heatmap():
        """Generate technique frequency heatmap"""
        try:
            data = request.get_json()
            alerts = data.get('alerts', [])
            
            if not alerts:
                return jsonify({
                    'success': False,
                    'error': 'No alerts provided for analysis'
                }), 400
            
            heatmap = mitre_engine.generate_technique_heatmap(alerts)
            
            return jsonify({
                'success': True,
                'data': {
                    'heatmap': heatmap
                }
            })
            
        except Exception as e:
            return jsonify({
                'success': False,
                'error': str(e)
            }), 500
    
    @app.route('/api/mitre/timeline', methods=['POST'])
    def generate_attack_timeline():
        """Generate attack timeline visualization"""
        try:
            data = request.get_json()
            alerts = data.get('alerts', [])
            
            if not alerts:
                return jsonify({
                    'success': False,
                    'error': 'No alerts provided for analysis'
                }), 400
            
            visualization = mitre_engine.analyze_attack_patterns(alerts)
            timeline = mitre_engine.generate_attack_timeline(visualization)
            
            return jsonify({
                'success': True,
                'data': {
                    'timeline': timeline,
                    'visualization': asdict(visualization)
                }
            })
            
        except Exception as e:
            return jsonify({
                'success': False,
                'error': str(e)
            }), 500
    
    @app.route('/api/mitre/tactics', methods=['GET'])
    def get_mitre_tactics():
        """Get MITRE ATT&CK tactics"""
        tactics = {}
        for tactic_id, tactic in mitre_engine.framework.tactics.items():
            tactics[tactic_id] = {
                'id': tactic.id,
                'name': tactic.name,
                'description': tactic.description,
                'phase': tactic.phase.value,
                'techniques': tactic.techniques
            }
        
        return jsonify({
            'success': True,
            'data': tactics
        })
    
    @app.route('/api/mitre/techniques', methods=['GET'])
    def get_mitre_techniques():
        """Get MITRE ATT&CK techniques"""
        techniques = {}
        for tech_id, technique in mitre_engine.framework.techniques.items():
            techniques[tech_id] = {
                'id': technique.id,
                'name': technique.name,
                'description': technique.description,
                'tactic_id': technique.tactic_id,
                'tactic_name': technique.tactic_name,
                'detection_methods': technique.detection_methods,
                'mitigation_strategies': technique.mitigation_strategies
            }
        
        return jsonify({
            'success': True,
            'data': techniques
        })
    
    logger.info("MITRE visualization management endpoints registered")
