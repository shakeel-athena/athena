"""
Background Task Queue for Athena Network Response Management

This module provides asynchronous task processing capabilities to handle
long-running operations without blocking API responses. It supports
threat intelligence enrichment, bulk updates, and periodic tasks.
"""

import redis
import json
import pickle
import logging
import threading
import time
import uuid
from typing import Any, Optional, Dict, List, Callable
from datetime import datetime, timedelta
from dataclasses import dataclass, asdict
from enum import Enum
from concurrent.futures import ThreadPoolExecutor
import traceback
import os
from flask import current_app, jsonify

logger = logging.getLogger(__name__)

class TaskStatus(Enum):
    """Task execution status"""
    PENDING = "pending"
    RUNNING = "running"
    COMPLETED = "completed"
    FAILED = "failed"
    CANCELLED = "cancelled"

class TaskPriority(Enum):
    """Task priority levels"""
    LOW = 1
    NORMAL = 2
    HIGH = 3
    CRITICAL = 4

@dataclass
class Task:
    """Background task definition"""
    id: str
    name: str
    func_name: str
    args: tuple
    kwargs: dict
    status: TaskStatus
    priority: TaskPriority
    created_at: datetime
    started_at: Optional[datetime] = None
    completed_at: Optional[datetime] = None
    result: Optional[Any] = None
    error: Optional[str] = None
    progress: float = 0.0
    max_retries: int = 3
    retry_count: int = 0
    timeout: int = 300  # 5 minutes default timeout

class TaskQueue:
    """Redis-based background task queue"""
    
    def __init__(self, app=None):
        self.redis_client = None
        self.redis = None
        self.enabled = True
        self.task_functions = {}
        self.worker_threads = []
        self.max_workers = 4
        self.poll_interval = 1
        self.running = False
        self.stats = {
            'tasks_submitted': 0,
            'tasks_completed': 0,
            'tasks_failed': 0,
            'tasks_cancelled': 0,
            'workers_active': 0,
            'queue_size': 0
        }
        
        if app is not None:
            self.init_app(app)
    
    def init_app(self, app):
        """Initialize task queue with Flask app"""
        self.enabled = app.config.get('TASK_QUEUE_ENABLED', True)
        
        if not self.enabled:
            logger.info("Task queue is disabled")
            return
        
        try:
            # Redis configuration
            redis_host = app.config.get('REDIS_HOST', 'localhost')
            redis_port = app.config.get('REDIS_PORT', 6379)
            redis_db = app.config.get('REDIS_DB', 0)
            redis_password = app.config.get('REDIS_PASSWORD', None)
            
            # Create Redis connection
            self.redis = redis.Redis(
                host=redis_host,
                port=redis_port,
                db=redis_db,
                password=redis_password,
                decode_responses=False
            )
            
            # Test connection
            self.redis.ping()
            
            # Configuration
            self.max_workers = app.config.get('TASK_QUEUE_MAX_WORKERS', 4)
            self.poll_interval = app.config.get('TASK_QUEUE_POLL_INTERVAL', 1)
            
            logger.info(f"Task queue initialized with {self.max_workers} workers")
            
        except Exception as e:
            logger.error(f"Failed to initialize task queue: {e}")
            self.enabled = False
            self.redis = None
    
    def task(self, name: str = None, priority: TaskPriority = TaskPriority.NORMAL, 
             timeout: int = 300, max_retries: int = 3):
        """Decorator to register a function as a background task"""
        def decorator(func):
            task_name = name or func.__name__
            self.task_functions[task_name] = func
            
            def submit_task(*args, **kwargs):
                return self.submit(task_name, *args, **kwargs, 
                                 priority=priority, timeout=timeout, 
                                 max_retries=max_retries)
            
            # Attach submit method to original function
            func.submit = submit_task
            func.delay = submit_task  # Celery-like interface
            
            return func
        
        return decorator
    
    def submit(self, func_name: str, *args, priority: TaskPriority = TaskPriority.NORMAL,
               timeout: int = 300, max_retries: int = 3, **kwargs) -> str:
        """Submit a task to the queue"""
        if not self.enabled or not self.redis:
            raise RuntimeError("Task queue is not available")
        
        if func_name not in self.task_functions:
            raise ValueError(f"Unknown task function: {func_name}")
        
        # Create task
        task_id = str(uuid.uuid4())
        task = Task(
            id=task_id,
            name=func_name,
            func_name=func_name,
            args=args,
            kwargs=kwargs,
            status=TaskStatus.PENDING,
            priority=priority,
            created_at=datetime.utcnow(),
            timeout=timeout,
            max_retries=max_retries
        )
        
        # Store task
        self._store_task(task)
        
        # Add to priority queue
        queue_key = f"tasks:queue:{priority.value}"
        self.redis.lpush(queue_key, task_id)
        
        self.stats['tasks_submitted'] += 1
        logger.info(f"Task {task_id} ({func_name}) submitted to queue")
        
        return task_id
    
    def get_task(self, task_id: str) -> Optional[Task]:
        """Get task by ID"""
        if not self.enabled or not self.redis:
            return None
        
        try:
            task_data = self.redis.get(f"task:{task_id}")
            if task_data:
                return self._deserialize_task(task_data)
            return None
        except Exception as e:
            logger.error(f"Failed to get task {task_id}: {e}")
            return None
    
    def get_tasks(self, status: Optional[TaskStatus] = None, 
                  limit: int = 50) -> List[Task]:
        """Get tasks by status"""
        if not self.enabled or not self.redis:
            return []
        
        try:
            if status:
                pattern = f"tasks:status:{status.value}"
            else:
                pattern = "tasks:status:*"
            
            task_ids = self.redis.smembers(pattern)
            tasks = []
            
            for task_id in task_ids[:limit]:
                task = self.get_task(task_id.decode())
                if task:
                    tasks.append(task)
            
            return sorted(tasks, key=lambda t: t.created_at, reverse=True)
            
        except Exception as e:
            logger.error(f"Failed to get tasks: {e}")
            return []
    
    def cancel_task(self, task_id: str) -> bool:
        """Cancel a pending task"""
        if not self.enabled or not self.redis:
            return False
        
        try:
            task = self.get_task(task_id)
            if not task:
                return False
            
            if task.status == TaskStatus.PENDING:
                task.status = TaskStatus.CANCELLED
                task.completed_at = datetime.utcnow()
                self._store_task(task)
                
                # Remove from queue
                queue_key = f"tasks:queue:{task.priority.value}"
                self.redis.lrem(queue_key, 0, task_id)
                
                self.stats['tasks_cancelled'] += 1
                logger.info(f"Task {task_id} cancelled")
                return True
            
            return False
            
        except Exception as e:
            logger.error(f"Failed to cancel task {task_id}: {e}")
            return False
    
    def retry_task(self, task_id: str) -> bool:
        """Retry a failed task"""
        if not self.enabled or not self.redis:
            return False
        
        try:
            task = self.get_task(task_id)
            if not task or task.status != TaskStatus.FAILED:
                return False
            
            if task.retry_count < task.max_retries:
                task.status = TaskStatus.PENDING
                task.retry_count += 1
                task.error = None
                task.progress = 0.0
                
                self._store_task(task)
                
                # Re-add to queue
                queue_key = f"tasks:queue:{task.priority.value}"
                self.redis.lpush(queue_key, task_id)
                
                logger.info(f"Task {task_id} queued for retry ({task.retry_count}/{task.max_retries})")
                return True
            
            return False
            
        except Exception as e:
            logger.error(f"Failed to retry task {task_id}: {e}")
            return False
    
    def update_progress(self, task_id: str, progress: float):
        """Update task progress (0.0 to 1.0)"""
        if not self.enabled or not self.redis:
            return
        
        try:
            task = self.get_task(task_id)
            if task and task.status == TaskStatus.RUNNING:
                task.progress = max(0.0, min(1.0, progress))
                self._store_task(task)
        except Exception as e:
            logger.error(f"Failed to update progress for task {task_id}: {e}")
    
    def start_workers(self):
        """Start worker threads"""
        if not self.enabled or self.running:
            return
        
        self.running = True
        
        for i in range(self.max_workers):
            worker = threading.Thread(target=self._worker_loop, name=f"TaskWorker-{i}")
            worker.daemon = True
            worker.start()
            self.worker_threads.append(worker)
        
        logger.info(f"Started {self.max_workers} task workers")
    
    def stop_workers(self):
        """Stop worker threads"""
        if not self.running:
            return
        
        self.running = False
        
        # Wait for workers to finish
        for worker in self.worker_threads:
            worker.join(timeout=5)
        
        self.worker_threads.clear()
        logger.info("Task workers stopped")
    
    def _worker_loop(self):
        """Worker thread main loop"""
        logger.info(f"Worker {threading.current_thread().name} started")
        
        while self.running:
            try:
                # Get next task (check queues by priority)
                task_id = self._get_next_task()
                
                if task_id:
                    self._execute_task(task_id)
                else:
                    # No tasks available, wait
                    time.sleep(self.poll_interval)
                    
            except Exception as e:
                logger.error(f"Worker error: {e}")
                time.sleep(self.poll_interval)
        
        logger.info(f"Worker {threading.current_thread().name} stopped")
    
    def _get_next_task(self) -> Optional[str]:
        """Get next task from priority queues"""
        if not self.redis:
            return None
        
        # Check queues from highest to lowest priority
        for priority_value in sorted([p.value for p in TaskPriority], reverse=True):
            queue_key = f"tasks:queue:{priority_value}"
            task_id = self.redis.rpop(queue_key)
            
            if task_id:
                return task_id.decode()
        
        return None
    
    def _execute_task(self, task_id: str):
        """Execute a task"""
        try:
            task = self.get_task(task_id)
            if not task:
                return
            
            # Update status
            task.status = TaskStatus.RUNNING
            task.started_at = datetime.utcnow()
            task.progress = 0.0
            self._store_task(task)
            
            self.stats['workers_active'] += 1
            logger.info(f"Executing task {task_id} ({task.name})")
            
            # Get function
            func = self.task_functions.get(task.func_name)
            if not func:
                raise ValueError(f"Task function {task.func_name} not found")
            
            # Execute with timeout
            with ThreadPoolExecutor(max_workers=1) as executor:
                future = executor.submit(func, *task.args, **task.kwargs)
                
                try:
                    result = future.result(timeout=task.timeout)
                    
                    # Success
                    task.status = TaskStatus.COMPLETED
                    task.result = result
                    task.progress = 1.0
                    
                    self.stats['tasks_completed'] += 1
                    logger.info(f"Task {task_id} completed successfully")
                    
                except TimeoutError:
                    task.status = TaskStatus.FAILED
                    task.error = f"Task timed out after {task.timeout} seconds"
                    
                    self.stats['tasks_failed'] += 1
                    logger.error(f"Task {task_id} timed out")
                
                except Exception as e:
                    task.status = TaskStatus.FAILED
                    task.error = str(e)
                    
                    self.stats['tasks_failed'] += 1
                    logger.error(f"Task {task_id} failed: {e}")
                    logger.debug(traceback.format_exc())
        
        except Exception as e:
            logger.error(f"Failed to execute task {task_id}: {e}")
            if task:
                task.status = TaskStatus.FAILED
                task.error = str(e)
        
        finally:
            task.completed_at = datetime.utcnow()
            self._store_task(task)
            self.stats['workers_active'] -= 1
    
    def _store_task(self, task: Task):
        """Store task in Redis"""
        if not self.redis:
            return
        
        try:
            # Store task data
            task_key = f"task:{task.id}"
            task_data = self._serialize_task(task)
            self.redis.set(task_key, task_data)
            
            # Update status index
            status_key = f"tasks:status:{task.status.value}"
            self.redis.sadd(status_key, task.id)
            
            # Remove from old status indexes
            for status in TaskStatus:
                if status != task.status:
                    old_status_key = f"tasks:status:{status.value}"
                    self.redis.srem(old_status_key, task.id)
            
            # Set expiration (24 hours for completed/failed tasks)
            if task.status in [TaskStatus.COMPLETED, TaskStatus.FAILED, TaskStatus.CANCELLED]:
                self.redis.expire(task_key, 86400)
            
        except Exception as e:
            logger.error(f"Failed to store task {task.id}: {e}")
    
    def _serialize_task(self, task: Task) -> bytes:
        """Serialize task for storage"""
        task_dict = asdict(task)
        
        # Convert datetime objects to ISO strings
        for key, value in task_dict.items():
            if isinstance(value, datetime):
                task_dict[key] = value.isoformat() if value else None
            elif isinstance(value, (TaskStatus, TaskPriority)):
                task_dict[key] = value.value
        
        return pickle.dumps(task_dict)
    
    def _deserialize_task(self, data: bytes) -> Task:
        """Deserialize task from storage"""
        task_dict = pickle.loads(data)
        
        # Convert ISO strings back to datetime objects
        for key, value in task_dict.items():
            if key in ['created_at', 'started_at', 'completed_at'] and value:
                task_dict[key] = datetime.fromisoformat(value)
            elif key == 'status':
                task_dict[key] = TaskStatus(value)
            elif key == 'priority':
                task_dict[key] = TaskPriority(value)
        
        return Task(**task_dict)
    
    def get_stats(self) -> Dict[str, Any]:
        """Get task queue statistics"""
        if not self.enabled:
            return {'enabled': False}
        
        # Update queue size
        if self.redis:
            try:
                queue_size = 0
                for priority in TaskPriority:
                    queue_key = f"tasks:queue:{priority.value}"
                    queue_size += self.redis.llen(queue_key)
                self.stats['queue_size'] = queue_size
            except Exception as e:
                logger.warning(f"Failed to get queue size: {e}")
        
        return {
            'enabled': self.enabled,
            'running': self.running,
            'workers_active': self.stats['workers_active'],
            'max_workers': self.max_workers,
            'queue_size': self.stats['queue_size'],
            'tasks_submitted': self.stats['tasks_submitted'],
            'tasks_completed': self.stats['tasks_completed'],
            'tasks_failed': self.stats['tasks_failed'],
            'tasks_cancelled': self.stats['tasks_cancelled'],
            'registered_functions': list(self.task_functions.keys())
        }
    
    def cleanup_old_tasks(self, days: int = 7) -> int:
        """Clean up old completed/failed tasks"""
        if not self.enabled or not self.redis:
            return 0
        
        try:
            cutoff_date = datetime.utcnow() - timedelta(days=days)
            cleaned = 0
            
            for status in [TaskStatus.COMPLETED, TaskStatus.FAILED, TaskStatus.CANCELLED]:
                task_ids = self.redis.smembers(f"tasks:status:{status.value}")
                
                for task_id in task_ids:
                    task = self.get_task(task_id.decode())
                    if task and task.completed_at and task.completed_at < cutoff_date:
                        # Delete task
                        self.redis.delete(f"task:{task_id}")
                        self.redis.srem(f"tasks:status:{status.value}", task_id)
                        cleaned += 1
            
            logger.info(f"Cleaned up {cleaned} old tasks")
            return cleaned
            
        except Exception as e:
            logger.error(f"Failed to cleanup old tasks: {e}")
            return 0

# Global task queue instance
task_queue = TaskQueue()

# Flask integration
def init_task_queue(app):
    """Initialize task queue with Flask app"""
    task_queue.init_app(app)
    
    # Start workers
    with app.app_context():
        task_queue.start_workers()
    
    # Add task queue management endpoints
    @app.route('/api/tasks/stats', methods=['GET'])
    def get_task_stats():
        """Get task queue statistics"""
        return jsonify({
            'success': True,
            'data': task_queue.get_stats()
        })
    
    @app.route('/api/tasks', methods=['GET'])
    def get_tasks():
        """Get list of tasks"""
        status = request.args.get('status')
        limit = int(request.args.get('limit', 50))
        
        if status:
            try:
                status_enum = TaskStatus(status)
                tasks = task_queue.get_tasks(status_enum, limit)
            except ValueError:
                return jsonify({
                    'success': False,
                    'error': f'Invalid status: {status}'
                }), 400
        else:
            tasks = task_queue.get_tasks(limit=limit)
        
        # Convert tasks to dict
        task_list = []
        for task in tasks:
            task_dict = asdict(task)
            # Convert datetime objects to ISO strings
            for key, value in task_dict.items():
                if isinstance(value, datetime):
                    task_dict[key] = value.isoformat() if value else None
                elif isinstance(value, (TaskStatus, TaskPriority)):
                    task_dict[key] = value.value
            task_list.append(task_dict)
        
        return jsonify({
            'success': True,
            'data': task_list
        })
    
    @app.route('/api/tasks/<task_id>', methods=['GET'])
    def get_task(task_id):
        """Get specific task"""
        task = task_queue.get_task(task_id)
        if not task:
            return jsonify({
                'success': False,
                'error': 'Task not found'
            }), 404
        
        task_dict = asdict(task)
        for key, value in task_dict.items():
            if isinstance(value, datetime):
                task_dict[key] = value.isoformat() if value else None
            elif isinstance(value, (TaskStatus, TaskPriority)):
                task_dict[key] = value.value
        
        return jsonify({
            'success': True,
            'data': task_dict
        })
    
    @app.route('/api/tasks/<task_id>/cancel', methods=['POST'])
    def cancel_task(task_id):
        """Cancel a task"""
        success = task_queue.cancel_task(task_id)
        if success:
            return jsonify({
                'success': True,
                'message': 'Task cancelled successfully'
            })
        else:
            return jsonify({
                'success': False,
                'error': 'Task cannot be cancelled'
            }), 400
    
    @app.route('/api/tasks/<task_id>/retry', methods=['POST'])
    def retry_task(task_id):
        """Retry a failed task"""
        success = task_queue.retry_task(task_id)
        if success:
            return jsonify({
                'success': True,
                'message': 'Task queued for retry'
            })
        else:
            return jsonify({
                'success': False,
                'error': 'Task cannot be retried'
            }), 400
    
    @app.route('/api/tasks/cleanup', methods=['POST'])
    def cleanup_tasks():
        """Clean up old tasks"""
        try:
            data = request.get_json() or {}
            days = data.get('days', 7)
            
            cleaned = task_queue.cleanup_old_tasks(days)
            
            return jsonify({
                'success': True,
                'message': f'Cleaned up {cleaned} old tasks',
                'data': {'cleaned_count': cleaned}
            })
        except Exception as e:
            return jsonify({
                'success': False,
                'error': str(e)
            }), 500
    
    logger.info("Task queue management endpoints registered")

# Cleanup on app shutdown
def cleanup_task_queue():
    """Cleanup task queue on shutdown"""
    if task_queue.running:
        task_queue.stop_workers()
