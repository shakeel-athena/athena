"""
Alert Correlation Engine for Athena Network Response Management

This module provides intelligent alert correlation and grouping capabilities
to reduce alert fatigue and enable faster threat detection. It automatically
groups related alerts by IP, timeframe, tactics, and attack patterns.
"""

import json
import time
import logging
from typing import List, Dict, Any, Optional, Set, Tuple
from datetime import datetime, timedelta
from dataclasses import dataclass, asdict
from enum import Enum
import hashlib
import re
from collections import defaultdict, Counter
import ipaddress
from concurrent.futures import ThreadPoolExecutor
import threading

logger = logging.getLogger(__name__)

class AlertSeverity(Enum):
    """Alert severity levels"""
    CRITICAL = 1
    HIGH = 2
    MEDIUM = 3
    LOW = 4

class CorrelationType(Enum):
    """Types of alert correlation"""
    IP_BASED = "ip_based"
    TIMEFRAME = "timeframe"
    TACTIC = "tactic"
    SIGNATURE = "signature"
    GEOGRAPHIC = "geographic"
    BEHAVIORAL = "behavioral"

@dataclass
class CorrelatedAlert:
    """Represents a correlated alert group"""
    correlation_id: str
    correlation_type: CorrelationType
    severity: AlertSeverity
    title: str
    description: str
    alerts: List[Dict[str, Any]]
    primary_indicators: List[str]
    secondary_indicators: List[str]
    start_time: datetime
    end_time: datetime
    confidence_score: float
    mitre_tactics: List[str]
    mitre_techniques: List[str]
    recommended_actions: List[str]
    metadata: Dict[str, Any]

@dataclass
class CorrelationRule:
    """Alert correlation rule definition"""
    name: str
    correlation_type: CorrelationType
    conditions: Dict[str, Any]
    time_window_minutes: int
    min_alert_count: int
    severity_threshold: AlertSeverity
    enabled: bool = True
    weight: float = 1.0

class AlertCorrelationEngine:
    """Intelligent alert correlation and grouping engine"""
    
    def __init__(self, app=None):
        self.app = app
        self.enabled = True
        self.correlation_rules = []
        self.active_correlations = {}
        self.correlation_history = []
        self.max_history_size = 10000
        self.correlation_threshold = 0.7
        self.time_window_default = 60  # minutes
        self._lock = threading.Lock()
        
        # Statistics
        self.stats = {
            'alerts_processed': 0,
            'correlations_created': 0,
            'correlations_by_type': defaultdict(int),
            'false_positives': 0,
            'true_positives': 0,
            'processing_time_ms': 0.0
        }
        
        # Initialize default correlation rules
        self._initialize_default_rules()
        
        if app is not None:
            self.init_app(app)
    
    def init_app(self, app):
        """Initialize correlation engine with Flask app"""
        self.enabled = app.config.get('ALERT_CORRELATION_ENABLED', True)
        self.correlation_threshold = app.config.get('CORRELATION_THRESHOLD', 0.7)
        self.time_window_default = app.config.get('CORRELATION_TIME_WINDOW', 60)
        
        logger.info(f"Alert correlation engine initialized: enabled={self.enabled}")
    
    def _initialize_default_rules(self):
        """Initialize default correlation rules"""
        default_rules = [
            # IP-based correlation rules
            CorrelationRule(
                name="Multiple Alerts from Same IP",
                correlation_type=CorrelationType.IP_BASED,
                conditions={
                    'same_source_ip': True,
                    'min_alert_count': 3,
                    'time_window_minutes': 30
                },
                time_window_minutes=30,
                min_alert_count=3,
                severity_threshold=AlertSeverity.MEDIUM,
                weight=1.0
            ),
            
            CorrelationRule(
                name="Brute Force Attack Pattern",
                correlation_type=CorrelationType.BEHAVIORAL,
                conditions={
                    'pattern': 'failed_login_attempts',
                    'same_source_ip': True,
                    'min_attempts': 5,
                    'time_window_minutes': 10
                },
                time_window_minutes=10,
                min_alert_count=5,
                severity_threshold=AlertSeverity.HIGH,
                weight=1.5
            ),
            
            # Time-based correlation rules
            CorrelationRule(
                name="Alert Spike in Time Window",
                correlation_type=CorrelationType.TIMEFRAME,
                conditions={
                    'min_alert_count': 10,
                    'time_window_minutes': 5,
                    'severity_threshold': AlertSeverity.MEDIUM
                },
                time_window_minutes=5,
                min_alert_count=10,
                severity_threshold=AlertSeverity.MEDIUM,
                weight=1.2
            ),
            
            # MITRE tactic correlation
            CorrelationRule(
                name="Tactic-Based Attack Chain",
                correlation_type=CorrelationType.TACTIC,
                conditions={
                    'same_tactic': True,
                    'min_alert_count': 2,
                    'time_window_minutes': 60
                },
                time_window_minutes=60,
                min_alert_count=2,
                severity_threshold=AlertSeverity.HIGH,
                weight=1.3
            ),
            
            # Geographic correlation
            CorrelationRule(
                name="Cross-Geographic Attack",
                correlation_type=CorrelationType.GEOGRAPHIC,
                conditions={
                    'multiple_countries': True,
                    'same_signature': True,
                    'min_alert_count': 3,
                    'time_window_minutes': 120
                },
                time_window_minutes=120,
                min_alert_count=3,
                severity_threshold=AlertSeverity.HIGH,
                weight=1.4
            ),
            
            # Signature-based correlation
            CorrelationRule(
                name="Repeating Attack Signature",
                correlation_type=CorrelationType.SIGNATURE,
                conditions={
                    'same_signature': True,
                    'min_alert_count': 3,
                    'time_window_minutes': 45
                },
                time_window_minutes=45,
                min_alert_count=3,
                severity_threshold=AlertSeverity.MEDIUM,
                weight=1.1
            )
        ]
        
        self.correlation_rules.extend(default_rules)
        logger.info(f"Initialized {len(default_rules)} default correlation rules")
    
    def add_correlation_rule(self, rule: CorrelationRule):
        """Add a new correlation rule"""
        with self._lock:
            self.correlation_rules.append(rule)
            logger.info(f"Added correlation rule: {rule.name}")
    
    def remove_correlation_rule(self, rule_name: str) -> bool:
        """Remove a correlation rule by name"""
        with self._lock:
            for i, rule in enumerate(self.correlation_rules):
                if rule.name == rule_name:
                    del self.correlation_rules[i]
                    logger.info(f"Removed correlation rule: {rule_name}")
                    return True
            return False
    
    def correlate_alerts(self, alerts: List[Dict[str, Any]]) -> List[CorrelatedAlert]:
        """Correlate a list of alerts and return correlated groups"""
        if not self.enabled or not alerts:
            return []
        
        start_time = time.time()
        
        try:
            # Update statistics
            self.stats['alerts_processed'] += len(alerts)
            
            # Preprocess alerts
            processed_alerts = self._preprocess_alerts(alerts)
            
            # Apply correlation rules
            correlations = []
            
            with ThreadPoolExecutor(max_workers=4) as executor:
                futures = []
                for rule in self.correlation_rules:
                    if rule.enabled:
                        future = executor.submit(self._apply_correlation_rule, rule, processed_alerts)
                        futures.append(future)
                
                for future in futures:
                    try:
                        rule_correlations = future.result(timeout=30)
                        correlations.extend(rule_correlations)
                    except Exception as e:
                        logger.error(f"Error applying correlation rule: {e}")
            
            # Merge overlapping correlations
            merged_correlations = self._merge_correlations(correlations)
            
            # Update statistics
            self.stats['correlations_created'] += len(merged_correlations)
            for correlation in merged_correlations:
                self.stats['correlations_by_type'][correlation.correlation_type.value] += 1
            
            # Store in history
            self._add_to_history(merged_correlations)
            
            # Update processing time
            processing_time = (time.time() - start_time) * 1000
            self.stats['processing_time_ms'] += processing_time
            
            logger.info(f"Correlated {len(alerts)} alerts into {len(merged_correlations)} groups in {processing_time:.2f}ms")
            
            return merged_correlations
            
        except Exception as e:
            logger.error(f"Error during alert correlation: {e}")
            return []
    
    def _preprocess_alerts(self, alerts: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """Preprocess alerts for correlation"""
        processed = []
        
        for alert in alerts:
            processed_alert = alert.copy()
            
            # Extract and normalize fields
            processed_alert['source_ip'] = self._extract_source_ip(alert)
            processed_alert['destination_ip'] = self._extract_destination_ip(alert)
            processed_alert['timestamp'] = self._parse_timestamp(alert)
            processed_alert['severity'] = self._normalize_severity(alert)
            processed_alert['signature'] = self._extract_signature(alert)
            processed_alert['mitre_tactics'] = self._extract_mitre_tactics(alert)
            processed_alert['mitre_techniques'] = self._extract_mitre_techniques(alert)
            processed_alert['country'] = self._extract_country(alert)
            
            processed.append(processed_alert)
        
        return processed
    
    def _apply_correlation_rule(self, rule: CorrelationRule, alerts: List[Dict[str, Any]]) -> List[CorrelatedAlert]:
        """Apply a specific correlation rule to alerts"""
        correlations = []
        
        try:
            if rule.correlation_type == CorrelationType.IP_BASED:
                correlations = self._correlate_by_ip(rule, alerts)
            elif rule.correlation_type == CorrelationType.TIMEFRAME:
                correlations = self._correlate_by_timeframe(rule, alerts)
            elif rule.correlation_type == CorrelationType.TACTIC:
                correlations = self._correlate_by_tactic(rule, alerts)
            elif rule.correlation_type == CorrelationType.SIGNATURE:
                correlations = self._correlate_by_signature(rule, alerts)
            elif rule.correlation_type == CorrelationType.GEOGRAPHIC:
                correlations = self._correlate_by_geography(rule, alerts)
            elif rule.correlation_type == CorrelationType.BEHAVIORAL:
                correlations = self._correlate_by_behavior(rule, alerts)
        
        except Exception as e:
            logger.error(f"Error applying correlation rule {rule.name}: {e}")
        
        return correlations
    
    def _correlate_by_ip(self, rule: CorrelationRule, alerts: List[Dict[str, Any]]) -> List[CorrelatedAlert]:
        """Correlate alerts by source IP"""
        correlations = []
        
        # Group alerts by source IP
        ip_groups = defaultdict(list)
        for alert in alerts:
            if alert.get('source_ip'):
                ip_groups[alert['source_ip']].append(alert)
        
        # Apply correlation conditions
        for ip, ip_alerts in ip_groups.items():
            if len(ip_alerts) >= rule.min_alert_count:
                # Check time window
                timestamps = [a['timestamp'] for a in ip_alerts if a.get('timestamp')]
                if timestamps and self._within_time_window(timestamps, rule.time_window_minutes):
                    correlation = self._create_correlation(
                        rule, ip_alerts, CorrelationType.IP_BASED,
                        primary_indicators=[ip],
                        title=f"Multiple Alerts from {ip}"
                    )
                    if correlation:
                        correlations.append(correlation)
        
        return correlations
    
    def _correlate_by_timeframe(self, rule: CorrelationRule, alerts: List[Dict[str, Any]]) -> List[CorrelatedAlert]:
        """Correlate alerts by time window"""
        correlations = []
        
        # Sort alerts by timestamp
        sorted_alerts = sorted([a for a in alerts if a.get('timestamp')], 
                              key=lambda x: x['timestamp'])
        
        # Sliding window approach
        window_size = timedelta(minutes=rule.time_window_minutes)
        
        for i in range(len(sorted_alerts)):
            window_alerts = [sorted_alerts[i]]
            
            for j in range(i + 1, len(sorted_alerts)):
                if sorted_alerts[j]['timestamp'] - sorted_alerts[i]['timestamp'] <= window_size:
                    window_alerts.append(sorted_alerts[j])
                else:
                    break
            
            if len(window_alerts) >= rule.min_alert_count:
                correlation = self._create_correlation(
                    rule, window_alerts, CorrelationType.TIMEFRAME,
                    primary_indicators=[f"Time window: {sorted_alerts[i]['timestamp']}"],
                    title=f"Alert Spike in {rule.time_window_minutes}min window"
                )
                if correlation:
                    correlations.append(correlation)
        
        return correlations
    
    def _correlate_by_tactic(self, rule: CorrelationRule, alerts: List[Dict[str, Any]]) -> List[CorrelatedAlert]:
        """Correlate alerts by MITRE tactic"""
        correlations = []
        
        # Group alerts by MITRE tactics
        tactic_groups = defaultdict(list)
        for alert in alerts:
            tactics = alert.get('mitre_tactics', [])
            for tactic in tactics:
                tactic_groups[tactic].append(alert)
        
        # Apply correlation conditions
        for tactic, tactic_alerts in tactic_groups.items():
            if len(tactic_alerts) >= rule.min_alert_count:
                # Check time window
                timestamps = [a['timestamp'] for a in tactic_alerts if a.get('timestamp')]
                if timestamps and self._within_time_window(timestamps, rule.time_window_minutes):
                    correlation = self._create_correlation(
                        rule, tactic_alerts, CorrelationType.TACTIC,
                        primary_indicators=[tactic],
                        title=f"Tactic-Based Attack: {tactic}",
                        mitre_tactics=[tactic]
                    )
                    if correlation:
                        correlations.append(correlation)
        
        return correlations
    
    def _correlate_by_signature(self, rule: CorrelationRule, alerts: List[Dict[str, Any]]) -> List[CorrelatedAlert]:
        """Correlate alerts by attack signature"""
        correlations = []
        
        # Group alerts by signature
        signature_groups = defaultdict(list)
        for alert in alerts:
            signature = alert.get('signature')
            if signature:
                signature_groups[signature].append(alert)
        
        # Apply correlation conditions
        for signature, sig_alerts in signature_groups.items():
            if len(sig_alerts) >= rule.min_alert_count:
                # Check time window
                timestamps = [a['timestamp'] for a in sig_alerts if a.get('timestamp')]
                if timestamps and self._within_time_window(timestamps, rule.time_window_minutes):
                    correlation = self._create_correlation(
                        rule, sig_alerts, CorrelationType.SIGNATURE,
                        primary_indicators=[signature],
                        title=f"Repeating Attack: {signature}"
                    )
                    if correlation:
                        correlations.append(correlation)
        
        return correlations
    
    def _correlate_by_geography(self, rule: CorrelationRule, alerts: List[Dict[str, Any]]) -> List[CorrelatedAlert]:
        """Correlate alerts by geographic patterns"""
        correlations = []
        
        # Group alerts by signature and check for multiple countries
        signature_groups = defaultdict(list)
        for alert in alerts:
            signature = alert.get('signature')
            country = alert.get('country')
            if signature and country:
                signature_groups[signature].append(alert)
        
        # Apply correlation conditions
        for signature, sig_alerts in signature_groups.items():
            # Check for multiple countries
            countries = set(a.get('country') for a in sig_alerts if a.get('country'))
            if len(countries) >= 2 and len(sig_alerts) >= rule.min_alert_count:
                # Check time window
                timestamps = [a['timestamp'] for a in sig_alerts if a.get('timestamp')]
                if timestamps and self._within_time_window(timestamps, rule.time_window_minutes):
                    correlation = self._create_correlation(
                        rule, sig_alerts, CorrelationType.GEOGRAPHIC,
                        primary_indicators=[signature],
                        secondary_indicators=list(countries),
                        title=f"Cross-Geographic Attack: {signature}"
                    )
                    if correlation:
                        correlations.append(correlation)
        
        return correlations
    
    def _correlate_by_behavior(self, rule: CorrelationRule, alerts: List[Dict[str, Any]]) -> List[CorrelatedAlert]:
        """Correlate alerts by behavioral patterns"""
        correlations = []
        
        pattern = rule.conditions.get('pattern')
        
        if pattern == 'failed_login_attempts':
            correlations = self._detect_brute_force_pattern(rule, alerts)
        elif pattern == 'port_scan':
            correlations = self._detect_port_scan_pattern(rule, alerts)
        elif pattern == 'data_exfiltration':
            correlations = self._detect_exfiltration_pattern(rule, alerts)
        
        return correlations
    
    def _detect_brute_force_pattern(self, rule: CorrelationRule, alerts: List[Dict[str, Any]]) -> List[CorrelatedAlert]:
        """Detect brute force attack patterns"""
        correlations = []
        
        # Group by source IP and look for failed login attempts
        ip_groups = defaultdict(list)
        for alert in alerts:
            if (alert.get('source_ip') and 
                'login' in alert.get('signature', '').lower() and 
                'failed' in alert.get('signature', '').lower()):
                ip_groups[alert['source_ip']].append(alert)
        
        for ip, ip_alerts in ip_groups.items():
            if len(ip_alerts) >= rule.min_alert_count:
                timestamps = [a['timestamp'] for a in ip_alerts if a.get('timestamp')]
                if timestamps and self._within_time_window(timestamps, rule.time_window_minutes):
                    correlation = self._create_correlation(
                        rule, ip_alerts, CorrelationType.BEHAVIORAL,
                        primary_indicators=[ip],
                        title=f"Brute Force Attack from {ip}",
                        severity=AlertSeverity.HIGH
                    )
                    if correlation:
                        correlations.append(correlation)
        
        return correlations
    
    def _detect_port_scan_pattern(self, rule: CorrelationRule, alerts: List[Dict[str, Any]]) -> List[CorrelatedAlert]:
        """Detect port scan patterns"""
        correlations = []
        
        # Group by source IP and look for multiple destination ports
        ip_groups = defaultdict(list)
        for alert in alerts:
            if (alert.get('source_ip') and 
                alert.get('destination_port') and
                'scan' in alert.get('signature', '').lower()):
                ip_groups[alert['source_ip']].append(alert)
        
        for ip, ip_alerts in ip_groups.items():
            # Check for multiple destination ports
            dest_ports = set(a.get('destination_port') for a in ip_alerts if a.get('destination_port'))
            if len(dest_ports) >= 5 and len(ip_alerts) >= rule.min_alert_count:
                timestamps = [a['timestamp'] for a in ip_alerts if a.get('timestamp')]
                if timestamps and self._within_time_window(timestamps, rule.time_window_minutes):
                    correlation = self._create_correlation(
                        rule, ip_alerts, CorrelationType.BEHAVIORAL,
                        primary_indicators=[ip],
                        secondary_indicators=[f"Ports scanned: {len(dest_ports)}"],
                        title=f"Port Scan from {ip}",
                        severity=AlertSeverity.HIGH
                    )
                    if correlation:
                        correlations.append(correlation)
        
        return correlations
    
    def _detect_exfiltration_pattern(self, rule: CorrelationRule, alerts: List[Dict[str, Any]]) -> List[CorrelatedAlert]:
        """Detect data exfiltration patterns"""
        correlations = []
        
        # Look for large outbound transfers or unusual data access
        exfiltration_alerts = []
        for alert in alerts:
            if (alert.get('signature') and 
                any(keyword in alert['signature'].lower() 
                    for keyword in ['exfiltration', 'data transfer', 'large upload'])):
                exfiltration_alerts.append(alert)
        
        if len(exfiltration_alerts) >= rule.min_alert_count:
            timestamps = [a['timestamp'] for a in exfiltration_alerts if a.get('timestamp')]
            if timestamps and self._within_time_window(timestamps, rule.time_window_minutes):
                correlation = self._create_correlation(
                    rule, exfiltration_alerts, CorrelationType.BEHAVIORAL,
                    primary_indicators=["Data exfiltration detected"],
                    title="Potential Data Exfiltration",
                    severity=AlertSeverity.CRITICAL
                )
                if correlation:
                    correlations.append(correlation)
        
        return correlations
    
    def _create_correlation(self, rule: CorrelationRule, alerts: List[Dict[str, Any]], 
                          correlation_type: CorrelationType, primary_indicators: List[str],
                          title: str, secondary_indicators: List[str] = None,
                          mitre_tactics: List[str] = None, severity: AlertSeverity = None) -> Optional[CorrelatedAlert]:
        """Create a correlated alert from grouped alerts"""
        try:
            # Calculate confidence score
            confidence = self._calculate_confidence_score(rule, alerts)
            
            if confidence < self.correlation_threshold:
                return None
            
            # Determine severity
            if not severity:
                severity = self._calculate_correlation_severity(alerts)
            
            # Extract MITRE techniques
            techniques = []
            for alert in alerts:
                techniques.extend(alert.get('mitre_techniques', []))
            techniques = list(set(techniques))
            
            # Generate description
            description = self._generate_description(correlation_type, alerts, primary_indicators)
            
            # Generate recommended actions
            recommended_actions = self._generate_recommended_actions(correlation_type, severity)
            
            # Create correlation ID
            correlation_id = self._generate_correlation_id(alerts, correlation_type)
            
            # Get time range
            timestamps = [a['timestamp'] for a in alerts if a.get('timestamp')]
            start_time = min(timestamps) if timestamps else datetime.utcnow()
            end_time = max(timestamps) if timestamps else datetime.utcnow()
            
            return CorrelatedAlert(
                correlation_id=correlation_id,
                correlation_type=correlation_type,
                severity=severity,
                title=title,
                description=description,
                alerts=alerts,
                primary_indicators=primary_indicators,
                secondary_indicators=secondary_indicators or [],
                start_time=start_time,
                end_time=end_time,
                confidence_score=confidence,
                mitre_tactics=mitre_tactics or [],
                mitre_techniques=techniques,
                recommended_actions=recommended_actions,
                metadata={
                    'rule_name': rule.name,
                    'rule_weight': rule.weight,
                    'alert_count': len(alerts),
                    'created_at': datetime.utcnow().isoformat()
                }
            )
            
        except Exception as e:
            logger.error(f"Error creating correlation: {e}")
            return None
    
    def _calculate_confidence_score(self, rule: CorrelationRule, alerts: List[Dict[str, Any]]) -> float:
        """Calculate confidence score for correlation"""
        base_score = 0.5
        
        # Factor in alert count
        alert_count_factor = min(len(alerts) / 10.0, 1.0) * 0.3
        
        # Factor in rule weight
        weight_factor = rule.weight * 0.2
        
        # Factor in severity consistency
        severities = [a.get('severity', AlertSeverity.LOW) for a in alerts]
        severity_consistency = 1.0 - (len(set(severities)) / len(severities)) if severities else 0
        severity_factor = severity_consistency * 0.2
        
        # Factor in time clustering
        timestamps = [a['timestamp'] for a in alerts if a.get('timestamp')]
        time_factor = 0.0
        if timestamps and len(timestamps) > 1:
            time_diffs = [(timestamps[i+1] - timestamps[i]).total_seconds() 
                         for i in range(len(timestamps)-1)]
            avg_time_diff = sum(time_diffs) / len(time_diffs)
            time_factor = max(0, 1.0 - (avg_time_diff / 3600.0)) * 0.2  # Favor tighter clustering
        
        confidence = base_score + alert_count_factor + weight_factor + severity_factor + time_factor
        return min(confidence, 1.0)
    
    def _calculate_correlation_severity(self, alerts: List[Dict[str, Any]]) -> AlertSeverity:
        """Calculate severity for correlated alert"""
        severities = [a.get('severity', AlertSeverity.LOW) for a in alerts]
        
        if not severities:
            return AlertSeverity.MEDIUM
        
        # Use the highest severity, but consider frequency
        severity_counts = Counter(severities)
        highest_severity = min(severities)  # Lower number = higher severity
        
        # If we have many high-severity alerts, upgrade
        if severity_counts[AlertSeverity.CRITICAL] >= 2:
            return AlertSeverity.CRITICAL
        elif severity_counts[AlertSeverity.HIGH] >= 3:
            return AlertSeverity.CRITICAL
        elif severity_counts[AlertSeverity.HIGH] >= 1:
            return AlertSeverity.HIGH
        elif severity_counts[AlertSeverity.MEDIUM] >= 5:
            return AlertSeverity.HIGH
        else:
            return highest_severity
    
    def _generate_description(self, correlation_type: CorrelationType, alerts: List[Dict[str, Any]], 
                            primary_indicators: List[str]) -> str:
        """Generate description for correlated alert"""
        alert_count = len(alerts)
        
        descriptions = {
            CorrelationType.IP_BASED: f"Multiple security alerts ({alert_count}) detected from the same source IP address, indicating potential targeted activity.",
            CorrelationType.TIMEFRAME: f"Alert spike detected with {alert_count} alerts occurring within a short time window, suggesting possible coordinated attack.",
            CorrelationType.TACTIC: f"Multiple alerts ({alert_count}) following the same MITRE attack tactic, indicating a structured attack campaign.",
            CorrelationType.SIGNATURE: f"Recurring attack signature detected {alert_count} times, suggesting persistent threat activity.",
            CorrelationType.GEOGRAPHIC: f"Attack pattern detected across multiple geographic locations with {alert_count} related alerts.",
            CorrelationType.BEHAVIORAL: f"Behavioral analysis identified {alert_count} related alerts indicating a specific attack pattern."
        }
        
        base_desc = descriptions.get(correlation_type, f"Correlated {alert_count} security alerts.")
        
        # Add primary indicators
        if primary_indicators:
            base_desc += f" Primary indicators: {', '.join(primary_indicators[:3])}"
        
        return base_desc
    
    def _generate_recommended_actions(self, correlation_type: CorrelationType, severity: AlertSeverity) -> List[str]:
        """Generate recommended actions based on correlation type and severity"""
        actions = []
        
        # Base actions for all correlations
        actions.extend([
            "Investigate all correlated alerts together",
            "Review source IP reputation and geolocation",
            "Check for additional related alerts in extended time window"
        ])
        
        # Type-specific actions
        if correlation_type == CorrelationType.IP_BASED:
            actions.extend([
                "Consider blocking source IP if malicious",
                "Analyze attack patterns from this IP",
                "Review authentication logs for this IP"
            ])
        elif correlation_type == CorrelationType.TIMEFRAME:
            actions.extend([
                "Analyze for potential distributed attack",
                "Review system performance during alert spike",
                "Check for coordinated activity across multiple sources"
            ])
        elif correlation_type == CorrelationType.TACTIC:
            actions.extend([
                "Review MITRE ATT&CK framework for this tactic",
            "Implement specific controls for this attack tactic",
            "Update detection rules for related techniques"
            ])
        elif correlation_type == CorrelationType.SIGNATURE:
            actions.extend([
                "Update signature definitions",
                "Review signature effectiveness",
                "Consider implementing additional detection methods"
            ])
        elif correlation_type == CorrelationType.BEHAVIORAL:
            actions.extend([
                "Implement behavioral analytics",
                "Review user and entity behavior analytics",
                "Consider implementing machine learning detection"
            ])
        
        # Severity-specific actions
        if severity == AlertSeverity.CRITICAL:
            actions.extend([
                "IMMEDIATE RESPONSE REQUIRED",
                "Escalate to security incident response team",
                "Consider isolating affected systems"
            ])
        elif severity == AlertSeverity.HIGH:
            actions.extend([
                "Prioritize investigation within 1 hour",
                "Review containment strategies",
                "Prepare incident response plan"
            ])
        
        return actions
    
    def _generate_correlation_id(self, alerts: List[Dict[str, Any]], correlation_type: CorrelationType) -> str:
        """Generate unique correlation ID"""
        # Create hash from alert IDs and correlation type
        alert_ids = sorted([a.get('id', str(hash(str(a)))) for a in alerts])
        correlation_data = f"{correlation_type.value}:{':'.join(alert_ids)}"
        return hashlib.md5(correlation_data.encode()).hexdigest()[:16]
    
    def _within_time_window(self, timestamps: List[datetime], window_minutes: int) -> bool:
        """Check if timestamps fall within the specified time window"""
        if not timestamps:
            return False
        
        min_time = min(timestamps)
        max_time = max(timestamps)
        time_diff = (max_time - min_time).total_seconds() / 60
        
        return time_diff <= window_minutes
    
    def _merge_correlations(self, correlations: List[CorrelatedAlert]) -> List[CorrelatedAlert]:
        """Merge overlapping correlations to reduce duplicates"""
        if not correlations:
            return []
        
        # Sort by start time
        sorted_correlations = sorted(correlations, key=lambda x: x.start_time)
        
        merged = []
        current = sorted_correlations[0]
        
        for next_corr in sorted_correlations[1:]:
            # Check for overlap (same alerts or significant overlap)
            current_alert_ids = set(a.get('id') for a in current.alerts)
            next_alert_ids = set(a.get('id') for a in next_corr.alerts)
            
            overlap = len(current_alert_ids & next_alert_ids)
            overlap_ratio = overlap / min(len(current_alert_ids), len(next_alert_ids))
            
            if overlap_ratio > 0.5:  # Significant overlap
                # Merge correlations
                merged_alerts = current.alerts + [a for a in next_corr.alerts 
                                                if a.get('id') not in current_alert_ids]
                
                current.alerts = merged_alerts
                current.end_time = max(current.end_time, next_corr.end_time)
                current.confidence_score = max(current.confidence_score, next_corr.confidence_score)
                current.metadata['merged_from'] = current.metadata.get('merged_from', []) + [next_corr.correlation_id]
            else:
                merged.append(current)
                current = next_corr
        
        merged.append(current)
        return merged
    
    def _add_to_history(self, correlations: List[CorrelatedAlert]):
        """Add correlations to history"""
        with self._lock:
            self.correlation_history.extend(correlations)
            
            # Trim history if needed
            if len(self.correlation_history) > self.max_history_size:
                self.correlation_history = self.correlation_history[-self.max_history_size:]
    
    # Helper methods for data extraction
    def _extract_source_ip(self, alert: Dict[str, Any]) -> Optional[str]:
        """Extract source IP from alert"""
        for field in ['src_ip', 'source_ip', 'ip', 'client_ip']:
            if field in alert:
                return alert[field]
        return None
    
    def _extract_destination_ip(self, alert: Dict[str, Any]) -> Optional[str]:
        """Extract destination IP from alert"""
        for field in ['dest_ip', 'destination_ip', 'target_ip']:
            if field in alert:
                return alert[field]
        return None
    
    def _parse_timestamp(self, alert: Dict[str, Any]) -> Optional[datetime]:
        """Parse timestamp from alert"""
        for field in ['timestamp', 'time', '@timestamp', 'created_at']:
            if field in alert:
                try:
                    if isinstance(alert[field], str):
                        return datetime.fromisoformat(alert[field].replace('Z', '+00:00'))
                    elif isinstance(alert[field], (int, float)):
                        return datetime.fromtimestamp(alert[field])
                except:
                    continue
        return datetime.utcnow()
    
    def _normalize_severity(self, alert: Dict[str, Any]) -> AlertSeverity:
        """Normalize alert severity"""
        severity_str = str(alert.get('severity', 'medium')).lower()
        
        if severity_str in ['critical', 'crit']:
            return AlertSeverity.CRITICAL
        elif severity_str in ['high', 'error']:
            return AlertSeverity.HIGH
        elif severity_str in ['medium', 'warning', 'warn']:
            return AlertSeverity.MEDIUM
        else:
            return AlertSeverity.LOW
    
    def _extract_signature(self, alert: Dict[str, Any]) -> Optional[str]:
        """Extract attack signature from alert"""
        for field in ['signature', 'rule', 'alert_type', 'category']:
            if field in alert:
                return str(alert[field])
        return None
    
    def _extract_mitre_tactics(self, alert: Dict[str, Any]) -> List[str]:
        """Extract MITRE tactics from alert"""
        tactics = []
        
        # Check for explicit MITRE tactics
        if 'mitre_tactics' in alert:
            tactics.extend(alert['mitre_tactics'])
        
        # Extract from rule name or signature
        signature = alert.get('signature', '').lower()
        rule_name = alert.get('rule', '').lower()
        
        tactic_keywords = {
            'initial access': ['initial access', 'reconnaissance', 'phishing'],
            'execution': ['execution', 'command', 'script'],
            'persistence': ['persistence', 'backdoor', 'rootkit'],
            'privilege escalation': ['privilege escalation', 'sudo', 'admin'],
            'defense evasion': ['defense evasion', 'obfuscation', 'anti-virus'],
            'credential access': ['credential access', 'password', 'hash'],
            'discovery': ['discovery', 'scan', 'enum'],
            'lateral movement': ['lateral movement', 'remote', 'spread'],
            'collection': ['collection', 'data gathering', 'exfil'],
            'exfiltration': ['exfiltration', 'data transfer', 'upload'],
            'impact': ['impact', 'ransomware', 'destruction']
        }
        
        for tactic, keywords in tactic_keywords.items():
            if any(keyword in signature or keyword in rule_name for keyword in keywords):
                tactics.append(tactic)
        
        return list(set(tactics))
    
    def _extract_mitre_techniques(self, alert: Dict[str, Any]) -> List[str]:
        """Extract MITRE techniques from alert"""
        techniques = []
        
        # Check for explicit MITRE techniques
        if 'mitre_techniques' in alert:
            techniques.extend(alert['mitre_techniques'])
        
        # Extract from rule name or signature
        signature = alert.get('signature', '').lower()
        rule_name = alert.get('rule', '').lower()
        
        technique_keywords = {
            'T1078': ['valid accounts', 'account creation'],
            'T1110': ['brute force', 'password spray', 'guessing'],
            'T1059': ['command line', 'powershell', 'bash'],
            'T1055': ['process injection', 'dll injection'],
            'T1053': ['scheduled task', 'cron job'],
            'T1543': ['service creation', 'new service'],
            'T1486': ['ransomware', 'encryption', 'file locked'],
            'T1046': ['port scan', 'network scan'],
            'T1040': ['network sniffing', 'packet capture'],
            'T1033': ['system owner', 'user discovery'],
            'T1082': ['system information', 'host discovery']
        }
        
        for technique, keywords in technique_keywords.items():
            if any(keyword in signature or keyword in rule_name for keyword in keywords):
                techniques.append(technique)
        
        return list(set(techniques))
    
    def _extract_country(self, alert: Dict[str, Any]) -> Optional[str]:
        """Extract country from alert"""
        for field in ['country', 'src_country', 'geo_country']:
            if field in alert:
                return alert[field]
        return None
    
    def get_correlation_statistics(self) -> Dict[str, Any]:
        """Get correlation engine statistics"""
        with self._lock:
            stats = self.stats.copy()
            stats['correlations_by_type'] = dict(stats['correlations_by_type'])
            stats['active_rules'] = len([r for r in self.correlation_rules if r.enabled])
            stats['total_rules'] = len(self.correlation_rules)
            stats['history_size'] = len(self.correlation_history)
            
            if stats['alerts_processed'] > 0:
                stats['correlation_rate'] = (stats['correlations_created'] / stats['alerts_processed']) * 100
            else:
                stats['correlation_rate'] = 0
            
            if stats['correlations_created'] > 0:
                stats['true_positive_rate'] = (stats['true_positives'] / stats['correlations_created']) * 100
            else:
                stats['true_positive_rate'] = 0
            
            return stats
    
    def get_recent_correlations(self, limit: int = 50) -> List[Dict[str, Any]]:
        """Get recent correlated alerts"""
        with self._lock:
            recent = self.correlation_history[-limit:] if self.correlation_history else []
            return [asdict(correlation) for correlation in recent]
    
    def update_correlation_feedback(self, correlation_id: str, is_true_positive: bool):
        """Update correlation with feedback for learning"""
        with self._lock:
            if is_true_positive:
                self.stats['true_positives'] += 1
            else:
                self.stats['false_positives'] += 1
        
        logger.info(f"Updated feedback for correlation {correlation_id}: {'TP' if is_true_positive else 'FP'}")

# Global correlation engine instance
correlation_engine = AlertCorrelationEngine()

# Flask integration
def init_alert_correlation(app):
    """Initialize alert correlation engine with Flask app"""
    correlation_engine.init_app(app)
    
    # Add correlation management endpoints
    @app.route('/api/correlation/stats', methods=['GET'])
    def get_correlation_stats():
        """Get correlation engine statistics"""
        return jsonify({
            'success': True,
            'data': correlation_engine.get_correlation_statistics()
        })
    
    @app.route('/api/correlation/recent', methods=['GET'])
    def get_recent_correlations():
        """Get recent correlated alerts"""
        limit = int(request.args.get('limit', 50))
        correlations = correlation_engine.get_recent_correlations(limit)
        
        return jsonify({
            'success': True,
            'data': correlations
        })
    
    @app.route('/api/correlation/correlate', methods=['POST'])
    def correlate_alerts():
        """Correlate a list of alerts"""
        try:
            data = request.get_json()
            alerts = data.get('alerts', [])
            
            if not alerts:
                return jsonify({
                    'success': False,
                    'error': 'No alerts provided for correlation'
                }), 400
            
            correlations = correlation_engine.correlate_alerts(alerts)
            
            return jsonify({
                'success': True,
                'data': {
                    'correlations': [asdict(c) for c in correlations],
                    'input_alerts': len(alerts),
                    'correlated_groups': len(correlations)
                }
            })
            
        except Exception as e:
            return jsonify({
                'success': False,
                'error': str(e)
            }), 500
    
    @app.route('/api/correlation/feedback', methods=['POST'])
    def update_correlation_feedback():
        """Update correlation feedback"""
        try:
            data = request.get_json()
            correlation_id = data.get('correlation_id')
            is_true_positive = data.get('is_true_positive', False)
            
            if not correlation_id:
                return jsonify({
                    'success': False,
                    'error': 'correlation_id is required'
                }), 400
            
            correlation_engine.update_correlation_feedback(correlation_id, is_true_positive)
            
            return jsonify({
                'success': True,
                'message': 'Feedback updated successfully'
            })
            
        except Exception as e:
            return jsonify({
                'success': False,
                'error': str(e)
            }), 500
    
    @app.route('/api/correlation/rules', methods=['GET'])
    def get_correlation_rules():
        """Get correlation rules"""
        rules = [asdict(rule) for rule in correlation_engine.correlation_rules]
        
        return jsonify({
            'success': True,
            'data': rules
        })
    
    @app.route('/api/correlation/rules', methods=['POST'])
    def add_correlation_rule():
        """Add a new correlation rule"""
        try:
            data = request.get_json()
            
            # Validate required fields
            required_fields = ['name', 'correlation_type', 'conditions', 'time_window_minutes', 'min_alert_count']
            for field in required_fields:
                if field not in data:
                    return jsonify({
                        'success': False,
                        'error': f'Missing required field: {field}'
                    }), 400
            
            # Create rule
            rule = CorrelationRule(
                name=data['name'],
                correlation_type=CorrelationType(data['correlation_type']),
                conditions=data['conditions'],
                time_window_minutes=data['time_window_minutes'],
                min_alert_count=data['min_alert_count'],
                severity_threshold=AlertSeverity(data.get('severity_threshold', 3)),
                enabled=data.get('enabled', True),
                weight=data.get('weight', 1.0)
            )
            
            correlation_engine.add_correlation_rule(rule)
            
            return jsonify({
                'success': True,
                'message': 'Correlation rule added successfully',
                'data': asdict(rule)
            })
            
        except Exception as e:
            return jsonify({
                'success': False,
                'error': str(e)
            }), 500
    
    @app.route('/api/correlation/rules/<rule_name>', methods=['DELETE'])
    def remove_correlation_rule(rule_name):
        """Remove a correlation rule"""
        success = correlation_engine.remove_correlation_rule(rule_name)
        
        if success:
            return jsonify({
                'success': True,
                'message': f'Correlation rule {rule_name} removed successfully'
            })
        else:
            return jsonify({
                'success': False,
                'error': f'Correlation rule {rule_name} not found'
            }), 404
    
    logger.info("Alert correlation management endpoints registered")
