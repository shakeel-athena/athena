"""
Redis Caching Layer for Athena Network Response Management

This module provides distributed caching capabilities to improve performance
and enable horizontal scaling. It handles caching of frequently accessed data
including Elasticsearch queries, threat intelligence, and API responses.
"""

import redis
import json
import pickle
import hashlib
import logging
from typing import Any, Optional, Union, Dict, List
from datetime import datetime, timedelta
from functools import wraps
import os
from flask import request, jsonify

logger = logging.getLogger(__name__)

class RedisCache:
    """Redis-based distributed caching system"""
    
    def __init__(self, app=None):
        self.redis_client = None
        self.default_ttl = 3600  # 1 hour default TTL
        self.key_prefix = "athena:"
        self.enabled = True
        self.stats = {
            'hits': 0,
            'misses': 0,
            'sets': 0,
            'deletes': 0,
            'errors': 0
        }
        
        if app is not None:
            self.init_app(app)
    
    def init_app(self, app):
        """Initialize Redis cache with Flask app"""
        self.enabled = app.config.get('CACHE_ENABLED', True)
        
        if not self.enabled:
            logger.info("Redis caching is disabled")
            return
        
        try:
            # Redis configuration
            redis_host = app.config.get('REDIS_HOST', 'localhost')
            redis_port = app.config.get('REDIS_PORT', 6379)
            redis_db = app.config.get('REDIS_DB', 0)
            redis_password = app.config.get('REDIS_PASSWORD', None)
            
            # Connection settings
            redis_socket_timeout = app.config.get('REDIS_SOCKET_TIMEOUT', 5)
            redis_socket_connect_timeout = app.config.get('REDIS_SOCKET_CONNECT_TIMEOUT', 5)
            redis_max_connections = app.config.get('REDIS_MAX_CONNECTIONS', 50)
            
            # Create Redis connection pool
            self.redis_client = redis.ConnectionPool(
                host=redis_host,
                port=redis_port,
                db=redis_db,
                password=redis_password,
                socket_timeout=redis_socket_timeout,
                socket_connect_timeout=redis_socket_connect_timeout,
                max_connections=redis_max_connections,
                decode_responses=False  # We'll handle encoding ourselves
            )
            
            # Create Redis client
            self.redis = redis.Redis(connection_pool=self.redis_client)
            
            # Test connection
            self.redis.ping()
            
            # Configuration
            self.default_ttl = app.config.get('CACHE_DEFAULT_TIMEOUT', 3600)
            self.key_prefix = app.config.get('CACHE_KEY_PREFIX', 'athena:')
            
            logger.info(f"Redis cache initialized: {redis_host}:{redis_port}/{redis_db}")
            
        except Exception as e:
            logger.error(f"Failed to initialize Redis cache: {e}")
            self.enabled = False
            self.redis_client = None
            self.redis = None
    
    def _make_key(self, key: str) -> str:
        """Create a namespaced cache key"""
        return f"{self.key_prefix}{key}"
    
    def _serialize(self, value: Any) -> bytes:
        """Serialize value for storage"""
        try:
            if isinstance(value, (str, int, float, bool)):
                return str(value).encode('utf-8')
            elif isinstance(value, (dict, list, tuple)):
                return json.dumps(value, default=str).encode('utf-8')
            else:
                return pickle.dumps(value)
        except Exception as e:
            logger.error(f"Failed to serialize cache value: {e}")
            raise
    
    def _deserialize(self, value: bytes) -> Any:
        """Deserialize value from storage"""
        try:
            # Try JSON first (more common for API responses)
            try:
                return json.loads(value.decode('utf-8'))
            except (json.JSONDecodeError, UnicodeDecodeError):
                # Fall back to pickle
                return pickle.loads(value)
        except Exception as e:
            logger.error(f"Failed to deserialize cache value: {e}")
            return None
    
    def get(self, key: str) -> Optional[Any]:
        """Get value from cache"""
        if not self.enabled or not self.redis:
            self.stats['misses'] += 1
            return None
        
        try:
            cache_key = self._make_key(key)
            value = self.redis.get(cache_key)
            
            if value is not None:
                self.stats['hits'] += 1
                return self._deserialize(value)
            else:
                self.stats['misses'] += 1
                return None
                
        except Exception as e:
            logger.error(f"Cache get error for key {key}: {e}")
            self.stats['errors'] += 1
            return None
    
    def set(self, key: str, value: Any, ttl: Optional[int] = None) -> bool:
        """Set value in cache"""
        if not self.enabled or not self.redis:
            return False
        
        try:
            cache_key = self._make_key(key)
            serialized_value = self._serialize(value)
            ttl = ttl or self.default_ttl
            
            result = self.redis.setex(cache_key, ttl, serialized_value)
            
            if result:
                self.stats['sets'] += 1
                return True
            else:
                self.stats['errors'] += 1
                return False
                
        except Exception as e:
            logger.error(f"Cache set error for key {key}: {e}")
            self.stats['errors'] += 1
            return False
    
    def delete(self, key: str) -> bool:
        """Delete value from cache"""
        if not self.enabled or not self.redis:
            return False
        
        try:
            cache_key = self._make_key(key)
            result = self.redis.delete(cache_key)
            
            if result > 0:
                self.stats['deletes'] += 1
                return True
            else:
                return False
                
        except Exception as e:
            logger.error(f"Cache delete error for key {key}: {e}")
            self.stats['errors'] += 1
            return False
    
    def clear(self, pattern: Optional[str] = None) -> int:
        """Clear cache entries matching pattern"""
        if not self.enabled or not self.redis:
            return 0
        
        try:
            if pattern:
                search_pattern = self._make_key(pattern)
            else:
                search_pattern = self._make_key("*")
            
            keys = self.redis.keys(search_pattern)
            
            if keys:
                deleted = self.redis.delete(*keys)
                self.stats['deletes'] += deleted
                logger.info(f"Cleared {deleted} cache entries matching pattern: {pattern}")
                return deleted
            else:
                return 0
                
        except Exception as e:
            logger.error(f"Cache clear error for pattern {pattern}: {e}")
            self.stats['errors'] += 1
            return 0
    
    def exists(self, key: str) -> bool:
        """Check if key exists in cache"""
        if not self.enabled or not self.redis:
            return False
        
        try:
            cache_key = self._make_key(key)
            return bool(self.redis.exists(cache_key))
        except Exception as e:
            logger.error(f"Cache exists error for key {key}: {e}")
            self.stats['errors'] += 1
            return False
    
    def get_ttl(self, key: str) -> int:
        """Get time-to-live for key"""
        if not self.enabled or not self.redis:
            return -1
        
        try:
            cache_key = self._make_key(key)
            return self.redis.ttl(cache_key)
        except Exception as e:
            logger.error(f"Cache TTL error for key {key}: {e}")
            self.stats['errors'] += 1
            return -1
    
    def get_stats(self) -> Dict[str, Any]:
        """Get cache statistics"""
        total_requests = self.stats['hits'] + self.stats['misses']
        hit_rate = (self.stats['hits'] / total_requests * 100) if total_requests > 0 else 0
        
        stats = {
            'enabled': self.enabled,
            'connected': self.redis is not None,
            'hits': self.stats['hits'],
            'misses': self.stats['misses'],
            'sets': self.stats['sets'],
            'deletes': self.stats['deletes'],
            'errors': self.stats['errors'],
            'hit_rate_percent': round(hit_rate, 2),
            'total_requests': total_requests
        }
        
        # Add Redis info if available
        if self.redis:
            try:
                redis_info = self.redis.info()
                stats['redis_info'] = {
                    'used_memory': redis_info.get('used_memory_human'),
                    'connected_clients': redis_info.get('connected_clients'),
                    'total_commands_processed': redis_info.get('total_commands_processed'),
                    'keyspace_hits': redis_info.get('keyspace_hits'),
                    'keyspace_misses': redis_info.get('keyspace_misses')
                }
            except Exception as e:
                logger.warning(f"Failed to get Redis info: {e}")
        
        return stats
    
    def reset_stats(self):
        """Reset cache statistics"""
        self.stats = {
            'hits': 0,
            'misses': 0,
            'sets': 0,
            'deletes': 0,
            'errors': 0
        }


# Global cache instance
cache = RedisCache()

def cache_key_generator(*args, **kwargs) -> str:
    """Generate cache key from function arguments"""
    # Create a hash of the arguments
    key_data = {
        'args': args,
        'kwargs': sorted(kwargs.items())
    }
    key_hash = hashlib.md5(json.dumps(key_data, sort_keys=True, default=str).encode()).hexdigest()
    return key_hash

def cached(ttl: Optional[int] = None, key_prefix: str = "", cache_none: bool = False):
    """Decorator to cache function results"""
    def decorator(f):
        @wraps(f)
        def decorated_function(*args, **kwargs):
            if not cache.enabled:
                return f(*args, **kwargs)
            
            # Generate cache key
            func_name = f.__name__
            arg_key = cache_key_generator(*args, **kwargs)
            cache_key = f"{key_prefix}{func_name}:{arg_key}"
            
            # Try to get from cache
            cached_result = cache.get(cache_key)
            if cached_result is not None:
                logger.debug(f"Cache hit for {cache_key}")
                return cached_result
            
            # Execute function and cache result
            result = f(*args, **kwargs)
            
            # Cache the result (unless it's None and cache_none is False)
            if result is not None or cache_none:
                cache.set(cache_key, result, ttl)
                logger.debug(f"Cached result for {cache_key}")
            
            return result
        
        return decorated_function
    return decorator

def cache_response(ttl: Optional[int] = None, key_prefix: str = "", vary_on: Optional[List[str]] = None):
    """Decorator to cache Flask route responses"""
    def decorator(f):
        @wraps(f)
        def decorated_function(*args, **kwargs):
            if not cache.enabled:
                return f(*args, **kwargs)
            
            # Generate cache key based on request
            func_name = f.__name__
            
            # Include request parameters in key
            key_parts = [func_name]
            
            # Add URL parameters
            if request.args:
                sorted_args = sorted(request.args.items())
                key_parts.append(f"args:{sorted_args}")
            
            # Add specified vary_on parameters
            if vary_on:
                for param in vary_on:
                    if param in request.args:
                        key_parts.append(f"{param}:{request.args[param]}")
            
            # Add user context if available
            if hasattr(request, 'user_id') and request.user_id:
                key_parts.append(f"user:{request.user_id}")
            
            cache_key = f"{key_prefix}response:{':'.join(key_parts)}"
            
            # Try to get from cache
            cached_response = cache.get(cache_key)
            if cached_response is not None:
                logger.debug(f"Response cache hit for {cache_key}")
                return cached_response
            
            # Execute function and cache response
            response = f(*args, **kwargs)
            
            # Only cache successful responses
            if hasattr(response, 'status_code') and response.status_code == 200:
                cache.set(cache_key, response, ttl)
                logger.debug(f"Cached response for {cache_key}")
            
            return response
        
        return decorated_function
    return decorator

class CacheManager:
    """High-level cache management for specific data types"""
    
    @staticmethod
    def cache_alerts(alerts: List[Dict], source: str, query_params: Dict, ttl: int = 300) -> bool:
        """Cache alert query results"""
        key = f"alerts:{source}:{cache_key_generator(**query_params)}"
        return cache.set(key, alerts, ttl)
    
    @staticmethod
    def get_cached_alerts(source: str, query_params: Dict) -> Optional[List[Dict]]:
        """Get cached alert query results"""
        key = f"alerts:{source}:{cache_key_generator(**query_params)}"
        return cache.get(key)
    
    @staticmethod
    def cache_threat_intelligence(data: Dict, source: str, indicator: str, ttl: int = 3600) -> bool:
        """Cache threat intelligence data"""
        key = f"threat_intel:{source}:{indicator}"
        return cache.set(key, data, ttl)
    
    @staticmethod
    def get_cached_threat_intelligence(source: str, indicator: str) -> Optional[Dict]:
        """Get cached threat intelligence data"""
        key = f"threat_intel:{source}:{indicator}"
        return cache.get(key)
    
    @staticmethod
    def cache_firewall_rules(rules: Dict, rule_type: str, ttl: int = 600) -> bool:
        """Cache firewall rules"""
        key = f"firewall_rules:{rule_type}"
        return cache.set(key, rules, ttl)
    
    @staticmethod
    def get_cached_firewall_rules(rule_type: str) -> Optional[Dict]:
        """Get cached firewall rules"""
        key = f"firewall_rules:{rule_type}"
        return cache.get(key)
    
    @staticmethod
    def cache_user_session(user_id: str, session_data: Dict, ttl: int = 7200) -> bool:
        """Cache user session data"""
        key = f"session:{user_id}"
        return cache.set(key, session_data, ttl)
    
    @staticmethod
    def get_cached_user_session(user_id: str) -> Optional[Dict]:
        """Get cached user session data"""
        key = f"session:{user_id}"
        return cache.get(key)
    
    @staticmethod
    def invalidate_user_cache(user_id: str) -> int:
        """Invalidate all cache entries for a user"""
        pattern = f"*user:{user_id}*"
        return cache.clear(pattern)
    
    @staticmethod
    def invalidate_source_cache(source: str) -> int:
        """Invalidate all cache entries for a data source"""
        pattern = f"*{source}*"
        return cache.clear(pattern)

# Flask integration
def init_cache(app):
    """Initialize cache with Flask app"""
    cache.init_app(app)
    
    # Add cache management to app context
    @app.route('/api/cache/stats', methods=['GET'])
    def get_cache_stats():
        """Get cache statistics"""
        return jsonify({
            'success': True,
            'data': cache.get_stats()
        })
    
    @app.route('/api/cache/clear', methods=['POST'])
    def clear_cache():
        """Clear cache entries"""
        try:
            data = request.get_json() or {}
            pattern = data.get('pattern', '*')
            
            cleared = cache.clear(pattern)
            
            return jsonify({
                'success': True,
                'message': f'Cleared {cleared} cache entries',
                'data': {'cleared_count': cleared}
            })
        except Exception as e:
            return jsonify({
                'success': False,
                'error': str(e)
            }), 500
    
    @app.route('/api/cache/reset-stats', methods=['POST'])
    def reset_cache_stats():
        """Reset cache statistics"""
        cache.reset_stats()
        return jsonify({
            'success': True,
            'message': 'Cache statistics reset'
        })
    
    logger.info("Cache management endpoints registered")
