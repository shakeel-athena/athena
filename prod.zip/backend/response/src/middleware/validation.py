"""
Input Validation Framework

This module provides comprehensive input validation for the Athena Network Response Management system.
It includes schema validation, sanitization, and security checks to prevent injection attacks
and ensure data integrity.
"""

import re
import ipaddress
from typing import Any, Dict, List, Optional, Union, Callable
from functools import wraps
from flask import request, jsonify, g
import logging
from datetime import datetime, timedelta
import json

# Configure logging
logger = logging.getLogger(__name__)


class ValidationError(Exception):
    """Exception raised when validation fails"""
    def __init__(self, message: str, field: str = None, value: Any = None):
        self.message = message
        self.field = field
        self.value = value
        super().__init__(message)


class ValidationSchema:
    """
    Schema definition for input validation
    """
    
    def __init__(self, schema: Dict[str, Dict[str, Any]]):
        """
        Initialize validation schema
        
        Args:
            schema: Dictionary defining field validation rules
        """
        self.schema = schema
        self.validators = {
            'required': self._validate_required,
            'type': self._validate_type,
            'min_length': self._validate_min_length,
            'max_length': self._validate_max_length,
            'pattern': self._validate_pattern,
            'enum': self._validate_enum,
            'min': self._validate_min,
            'max': self._validate_max,
            'ip_address': self._validate_ip_address,
            'ip_list': self._validate_ip_list,
            'country_code': self._validate_country_code,
            'country_list': self._validate_country_list,
            'timestamp': self._validate_timestamp,
            'time_range': self._validate_time_range,
            'severity': self._validate_severity,
            'source': self._validate_source,
            'non_empty': self._validate_non_empty,
            'no_sql_injection': self._validate_no_sql_injection,
            'no_xss': self._validate_no_xss,
            'alphanumeric': self._validate_alphanumeric,
            'slug': self._validate_slug,
            'email': self._validate_email,
            'url': self._validate_url,
        }
    
    def validate(self, data: Dict[str, Any]) -> Dict[str, Any]:
        """
        Validate input data against schema
        
        Args:
            data: Input data to validate
            
        Returns:
            Validated and sanitized data
            
        Raises:
            ValidationError: If validation fails
        """
        validated_data = {}
        errors = []
        
        # Check required fields
        for field_name, field_rules in self.schema.items():
            if field_rules.get('required', False) and field_name not in data:
                errors.append(f"Field '{field_name}' is required")
        
        # Validate each field
        for field_name, value in data.items():
            if field_name not in self.schema:
                # Skip unknown fields unless strict mode is enabled
                continue
            
            field_rules = self.schema[field_name]
            
            try:
                validated_value = self._validate_field(field_name, value, field_rules)
                validated_data[field_name] = validated_value
            except ValidationError as e:
                errors.append(f"Field '{field_name}': {e.message}")
        
        if errors:
            raise ValidationError("; ".join(errors))
        
        return validated_data
    
    def _validate_field(self, field_name: str, value: Any, rules: Dict[str, Any]) -> Any:
        """Validate a single field against its rules"""
        # Apply each validation rule
        for rule_name, rule_value in rules.items():
            if rule_name in self.validators:
                value = self.validators[rule_name](field_name, value, rule_value)
        
        return value
    
    # Validation rule implementations
    def _validate_required(self, field: str, value: Any, required: bool) -> Any:
        if required and (value is None or value == ''):
            raise ValidationError(f"Field '{field}' is required", field, value)
        return value
    
    def _validate_type(self, field: str, value: Any, expected_type: str) -> Any:
        type_map = {
            'str': str,
            'int': int,
            'float': float,
            'bool': bool,
            'list': list,
            'dict': dict
        }
        
        if expected_type not in type_map:
            raise ValidationError(f"Unknown type '{expected_type}' for field '{field}'")
        
        expected_python_type = type_map[expected_type]
        
        if not isinstance(value, expected_python_type):
            # Try to convert if possible
            try:
                if expected_type == 'int':
                    return int(value)
                elif expected_type == 'float':
                    return float(value)
                elif expected_type == 'bool':
                    if isinstance(value, str):
                        return value.lower() in ('true', '1', 'yes', 'on')
                    return bool(value)
                elif expected_type == 'list':
                    if isinstance(value, str):
                        # Split comma-separated string
                        return [item.strip() for item in value.split(',') if item.strip()]
                    return list(value)
                elif expected_type == 'str':
                    return str(value)
                else:
                    raise ValidationError(f"Field '{field}' must be of type '{expected_type}'", field, value)
            except (ValueError, TypeError):
                raise ValidationError(f"Field '{field}' must be of type '{expected_type}'", field, value)
        
        return value
    
    def _validate_min_length(self, field: str, value: Any, min_length: int) -> Any:
        if isinstance(value, (str, list)) and len(value) < min_length:
            raise ValidationError(f"Field '{field}' must have at least {min_length} characters/items", field, value)
        return value
    
    def _validate_max_length(self, field: str, value: Any, max_length: int) -> Any:
        if isinstance(value, (str, list)) and len(value) > max_length:
            raise ValidationError(f"Field '{field}' must have at most {max_length} characters/items", field, value)
        return value
    
    def _validate_pattern(self, field: str, value: Any, pattern: str) -> Any:
        if isinstance(value, str):
            if not re.match(pattern, value):
                raise ValidationError(f"Field '{field}' does not match required pattern", field, value)
        return value
    
    def _validate_enum(self, field: str, value: Any, enum_values: List[Any]) -> Any:
        if value not in enum_values:
            raise ValidationError(f"Field '{field}' must be one of: {enum_values}", field, value)
        return value
    
    def _validate_min(self, field: str, value: Any, min_value: Union[int, float]) -> Any:
        if isinstance(value, (int, float)) and value < min_value:
            raise ValidationError(f"Field '{field}' must be at least {min_value}", field, value)
        return value
    
    def _validate_max(self, field: str, value: Any, max_value: Union[int, float]) -> Any:
        if isinstance(value, (int, float)) and value > max_value:
            raise ValidationError(f"Field '{field}' must be at most {max_value}", field, value)
        return value
    
    def _validate_ip_address(self, field: str, value: Any, required: bool) -> Any:
        if isinstance(value, str):
            try:
                ipaddress.ip_address(value.strip())
                return value.strip()
            except ValueError:
                raise ValidationError(f"Field '{field}' must be a valid IP address", field, value)
        return value
    
    def _validate_ip_list(self, field: str, value: Any, required: bool) -> Any:
        if isinstance(value, str):
            # Split comma-separated IPs
            ip_list = [ip.strip() for ip in value.split(',') if ip.strip()]
        elif isinstance(value, list):
            ip_list = value
        else:
            raise ValidationError(f"Field '{field}' must be a list of IP addresses", field, value)
        
        validated_ips = []
        for ip in ip_list:
            try:
                ipaddress.ip_address(ip)
                validated_ips.append(ip.strip())
            except ValueError:
                raise ValidationError(f"Invalid IP address in field '{field}': {ip}", field, ip)
        
        return validated_ips
    
    def _validate_country_code(self, field: str, value: Any, required: bool) -> Any:
        if isinstance(value, str):
            # Validate ISO 3166-1 alpha-2 country codes
            if not re.match(r'^[A-Z]{2}$', value.upper()):
                raise ValidationError(f"Field '{field}' must be a valid 2-letter country code", field, value)
            return value.upper()
        return value
    
    def _validate_country_list(self, field: str, value: Any, required: bool) -> Any:
        if isinstance(value, str):
            # Split comma-separated country codes
            country_list = [c.strip() for c in value.split(',') if c.strip()]
        elif isinstance(value, list):
            country_list = value
        else:
            raise ValidationError(f"Field '{field}' must be a list of country codes", field, value)
        
        validated_countries = []
        for country in country_list:
            if not re.match(r'^[A-Z]{2}$', country.upper()):
                raise ValidationError(f"Invalid country code in field '{field}': {country}", field, country)
            validated_countries.append(country.upper())
        
        return validated_countries
    
    def _validate_timestamp(self, field: str, value: Any, required: bool) -> Any:
        if isinstance(value, str):
            try:
                # Try ISO format first
                datetime.fromisoformat(value.replace('Z', '+00:00'))
                return value
            except ValueError:
                try:
                    # Try Unix timestamp
                    float(value)
                    return value
                except ValueError:
                    raise ValidationError(f"Field '{field}' must be a valid timestamp", field, value)
        return value
    
    def _validate_time_range(self, field: str, value: Any, required: bool) -> Any:
        if isinstance(value, (int, str)):
            try:
                int_value = int(value)
                if int_value < 0:
                    raise ValidationError(f"Field '{field}' must be a positive integer", field, value)
                return int_value
            except ValueError:
                raise ValidationError(f"Field '{field}' must be a valid time range (integer)", field, value)
        return value
    
    def _validate_severity(self, field: str, value: Any, required: bool) -> Any:
        if isinstance(value, str):
            valid_severities = ['Critical', 'High', 'Medium', 'Low']
            if value.capitalize() not in valid_severities:
                raise ValidationError(f"Field '{field}' must be one of: {valid_severities}", field, value)
            return value.capitalize()
        return value
    
    def _validate_source(self, field: str, value: Any, required: bool) -> Any:
        if isinstance(value, str):
            valid_sources = ['wazuh', 'suricata', 'all']
            if value.lower() not in valid_sources:
                raise ValidationError(f"Field '{field}' must be one of: {valid_sources}", field, value)
            return value.lower()
        return value
    
    def _validate_non_empty(self, field: str, value: Any, required: bool) -> Any:
        if isinstance(value, str) and not value.strip():
            raise ValidationError(f"Field '{field}' cannot be empty", field, value)
        elif isinstance(value, list) and len(value) == 0:
            raise ValidationError(f"Field '{field}' cannot be empty", field, value)
        return value
    
    def _validate_no_sql_injection(self, field: str, value: Any, required: bool) -> Any:
        if isinstance(value, str):
            # Basic SQL injection patterns
            sql_patterns = [
                r"(\b(SELECT|INSERT|UPDATE|DELETE|DROP|CREATE|ALTER|EXEC|UNION)\b)",
                r"(\b(OR|AND)\s+\d+\s*=\s*\d+)",
                r"(\b(OR|AND)\s+['\"]?\w+['\"]?\s*=\s*['\"]?\w+['\"]?)",
                r"(--|#|/\*|\*/)",
                r"(\b(SCRIPT|JAVASCRIPT|VBSCRIPT|ONLOAD|ONERROR)\b)",
            ]
            
            for pattern in sql_patterns:
                if re.search(pattern, value, re.IGNORECASE):
                    raise ValidationError(f"Field '{field}' contains potentially malicious content", field, value)
        return value
    
    def _validate_no_xss(self, field: str, value: Any, required: bool) -> Any:
        if isinstance(value, str):
            # Basic XSS patterns
            xss_patterns = [
                r"<\s*script[^>]*>.*?<\s*/\s*script\s*>",
                r"<\s*iframe[^>]*>.*?<\s*/\s*iframe\s*>",
                r"javascript\s*:",
                r"on\w+\s*=",
                r"<\s*img[^>]*src\s*=\s*['\"]?javascript",
            ]
            
            for pattern in xss_patterns:
                if re.search(pattern, value, re.IGNORECASE):
                    raise ValidationError(f"Field '{field}' contains potentially malicious content", field, value)
        return value
    
    def _validate_alphanumeric(self, field: str, value: Any, required: bool) -> Any:
        if isinstance(value, str) and not re.match(r'^[a-zA-Z0-9_-]+$', value):
            raise ValidationError(f"Field '{field}' must contain only alphanumeric characters, underscores, and hyphens", field, value)
        return value
    
    def _validate_slug(self, field: str, value: Any, required: bool) -> Any:
        if isinstance(value, str) and not re.match(r'^[a-z0-9-]+$', value):
            raise ValidationError(f"Field '{field}' must be a valid slug (lowercase alphanumeric with hyphens)", field, value)
        return value
    
    def _validate_email(self, field: str, value: Any, required: bool) -> Any:
        if isinstance(value, str):
            email_pattern = r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'
            if not re.match(email_pattern, value):
                raise ValidationError(f"Field '{field}' must be a valid email address", field, value)
        return value
    
    def _validate_url(self, field: str, value: Any, required: bool) -> Any:
        if isinstance(value, str):
            url_pattern = r'^https?://[^\s/$.?#].[^\s]*$'
            if not re.match(url_pattern, value):
                raise ValidationError(f"Field '{field}' must be a valid URL", field, value)
        return value


# Predefined schemas for common endpoints
SCHEMAS = {
    'firewall_ip_list': ValidationSchema({
        'ips': {
            'required': True,
            'type': 'list',
            'ip_list': True,
            'non_empty': True,
            'max_length': 1000  # Maximum 1000 IPs per request
        }
    }),
    
    'firewall_ip_transfer': ValidationSchema({
        'ip': {
            'required': True,
            'type': 'str',
            'ip_address': True
        },
        'from': {
            'required': True,
            'type': 'str',
            'enum': ['allow', 'block']
        },
        'to': {
            'required': True,
            'type': 'str',
            'enum': ['allow', 'block']
        }
    }),
    
    'waf_signature': ValidationSchema({
        'signature_id': {
            'required': True,
            'type': 'str',
            'non_empty': True,
            'max_length': 100,
            'no_sql_injection': True,
            'no_xss': True
        }
    }),
    
    'waf_signatures_multiple': ValidationSchema({
        'signature_ids': {
            'required': True,
            'type': 'list',
            'non_empty': True,
            'max_length': 100,  # Maximum 100 signatures per request
            'min_length': 1
        }
    }),
    
    'geo_countries': ValidationSchema({
        'countries': {
            'required': True,
            'type': 'list',
            'country_list': True,
            'non_empty': True,
            'max_length': 250  # Maximum number of countries
        }
    }),
    
    'alerts_query': ValidationSchema({
        'limit': {
            'required': False,
            'type': 'int',
            'min': 1,
            'max': 1000
        },
        'offset': {
            'required': False,
            'type': 'int',
            'min': 0
        },
        'time_range': {
            'required': False,
            'type': 'str',
            'time_range': True
        },
        'severity': {
            'required': False,
            'type': 'str',
            'severity': True
        },
        'source': {
            'required': False,
            'type': 'str',
            'source': True
        },
        'search': {
            'required': False,
            'type': 'str',
            'max_length': 500,
            'no_sql_injection': True,
            'no_xss': True
        },
        'return_total': {
            'required': False,
            'type': 'bool'
        }
    }),
    
    'background_module_config': ValidationSchema({
        'interval_hours': {
            'required': False,
            'type': 'int',
            'min': 0,
            'max': 168  # Maximum 1 week
        },
        'interval_minutes': {
            'required': False,
            'type': 'int',
            'min': 1,
            'max': 59
        },
        'date_range_days': {
            'required': False,
            'type': 'int',
            'min': 1,
            'max': 365  # Maximum 1 year
        }
    }),
    
    'rate_limit_reset': ValidationSchema({
        'type': {
            'required': True,
            'type': 'str',
            'enum': ['ip', 'user']
        },
        'target': {
            'required': True,
            'type': 'str',
            'non_empty': True,
            'max_length': 100
        }
    })
}


def validate_input(schema_name: str, source: str = 'json'):
    """
    Decorator for input validation
    
    Args:
        schema_name: Name of the schema to use for validation
        source: Source of input data ('json', 'args', 'form')
        
    Usage:
        @app.route('/api/example', methods=['POST'])
        @validate_input('firewall_ip_list')
        def example_route():
            return jsonify({'message': 'Validated successfully'})
    """
    def decorator(f: Callable) -> Callable:
        @wraps(f)
        def decorated_function(*args, **kwargs):
            try:
                # Get input data from specified source
                if source == 'json':
                    data = request.get_json() or {}
                elif source == 'args':
                    data = request.args.to_dict()
                elif source == 'form':
                    data = request.form.to_dict()
                else:
                    raise ValidationError(f"Invalid source '{source}' for validation")
                
                # Validate data
                if schema_name not in SCHEMAS:
                    raise ValidationError(f"Unknown schema '{schema_name}'")
                
                validated_data = SCHEMAS[schema_name].validate(data)
                
                # Store validated data in Flask's g object
                g.validated_data = validated_data
                
                return f(*args, **kwargs)
                
            except ValidationError as e:
                logger.warning(f"Validation error: {e.message}")
                return jsonify({
                    'error': 'Validation failed',
                    'message': e.message,
                    'field': e.field,
                    'success': False
                }), 400
                
            except Exception as e:
                logger.error(f"Unexpected validation error: {e}")
                return jsonify({
                    'error': 'Validation error',
                    'message': 'An unexpected error occurred during validation',
                    'success': False
                }), 500
        
        return decorated_function
    return decorator


def sanitize_input(data: Any) -> Any:
    """
    Sanitize input data to remove potentially harmful content
    
    Args:
        data: Input data to sanitize
        
    Returns:
        Sanitized data
    """
    if isinstance(data, str):
        # Remove potentially harmful characters
        sanitized = data.strip()
        # Remove null bytes
        sanitized = sanitized.replace('\x00', '')
        # Normalize whitespace
        sanitized = ' '.join(sanitized.split())
        return sanitized
    
    elif isinstance(data, list):
        return [sanitize_input(item) for item in data]
    
    elif isinstance(data, dict):
        return {key: sanitize_input(value) for key, value in data.items()}
    
    else:
        return data


def get_validation_errors() -> Optional[List[str]]:
    """
    Get validation errors from the current request context
    
    Returns:
        List of validation errors or None if no errors
    """
    return getattr(g, 'validation_errors', None)


def get_validated_data() -> Optional[Dict[str, Any]]:
    """
    Get validated data from the current request context
    
    Returns:
        Validated data dictionary or None if no validation was performed
    """
    return getattr(g, 'validated_data', None)


def init_validation(app):
    """
    Initialize validation framework with Flask application
    
    Args:
        app: Flask application instance
    """
    # Add global error handler for validation errors
    @app.errorhandler(ValidationError)
    def handle_validation_error(error):
        """Handle validation errors globally"""
        return jsonify({
            'error': 'Validation failed',
            'message': error.message,
            'field': error.field,
            'success': False
        }), 400
    
    # Add validation endpoint for testing
    @app.route('/api/validation/test', methods=['POST'])
    def test_validation():
        """Test validation with custom schema"""
        try:
            data = request.get_json() or {}
            schema_def = data.get('schema', {})
            test_data = data.get('data', {})
            
            # Create custom schema
            schema = ValidationSchema(schema_def)
            validated_data = schema.validate(test_data)
            
            return jsonify({
                'success': True,
                'message': 'Validation successful',
                'validated_data': validated_data
            })
            
        except Exception as e:
            return jsonify({
                'success': False,
                'error': str(e)
            }), 400
    
    logger.info("Validation framework initialized successfully")
