"""
Flask Authentication Middleware

This module provides Flask decorators for JWT authentication and role-based access control.
"""

from functools import wraps
from flask import request, jsonify, g
from typing import List, Optional, Callable
import sys
import os

# Add parent directory to path to import keycloak utility
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from utils.keycloak import decode_token, extract_user_info, extract_roles, TokenValidationError, KEYCLOAK_CLIENT_ID


def extract_token_from_header() -> Optional[str]:
    """
    Extract JWT token from Authorization header.

    Returns:
        Token string or None if not found

    Raises:
        ValueError: If Authorization header format is invalid
    """
    auth_header = request.headers.get('Authorization')

    if not auth_header:
        return None

    # Expected format: "Bearer <token>"
    parts = auth_header.split()

    if len(parts) != 2:
        raise ValueError("Invalid Authorization header format. Expected 'Bearer <token>'")

    if parts[0].lower() != 'bearer':
        raise ValueError("Invalid Authorization header format. Expected 'Bearer' prefix")

    return parts[1]


def require_auth(f: Callable) -> Callable:
    """
    Decorator to require JWT authentication for a Flask route.

    Validates the JWT token and stores user information in Flask's g object.
    The following attributes are available in the route function:
    - g.token_payload: Full decoded JWT payload
    - g.user: User information dictionary
    - g.roles: List of user roles

    Usage:
        @app.route('/api/protected')
        @require_auth
        def protected_route():
            username = g.user['username']
            return jsonify({'message': f'Hello {username}'})

    Returns:
        Decorated function

    Responses:
        401: If token is missing or invalid
    """
    @wraps(f)
    def decorated_function(*args, **kwargs):
        try:
            # Extract token from header
            token = extract_token_from_header()

            if not token:
                return jsonify({
                    'error': 'Authentication required',
                    'message': 'No authorization token provided'
                }), 401

            # Decode and validate token
            token_payload = decode_token(token)

            # Extract user info and roles
            user_info = extract_user_info(token_payload)
            roles = extract_roles(token_payload, KEYCLOAK_CLIENT_ID)

            # Store in Flask's g object for access in route
            g.token_payload = token_payload
            g.user = user_info
            g.roles = roles

            return f(*args, **kwargs)

        except ValueError as e:
            return jsonify({
                'error': 'Invalid authorization header',
                'message': str(e)
            }), 401

        except TokenValidationError as e:
            return jsonify({
                'error': 'Token validation failed',
                'message': str(e)
            }), 401

        except Exception as e:
            return jsonify({
                'error': 'Authentication error',
                'message': 'An unexpected error occurred during authentication'
            }), 500

    return decorated_function


def require_role(required_role: str) -> Callable:
    """
    Decorator to require a specific role for a Flask route.

    Must be used in combination with @require_auth.
    Checks if the authenticated user has the specified role.

    Usage:
        @app.route('/api/admin')
        @require_auth
        @require_role('admin')
        def admin_route():
            return jsonify({'message': 'Admin access granted'})

    Args:
        required_role: Role name required to access the route

    Returns:
        Decorated function

    Responses:
        403: If user doesn't have the required role
    """
    def decorator(f: Callable) -> Callable:
        @wraps(f)
        def decorated_function(*args, **kwargs):
            # Check if user is authenticated (require_auth should have set g.roles)
            if not hasattr(g, 'roles'):
                return jsonify({
                    'error': 'Authentication required',
                    'message': 'User is not authenticated'
                }), 401

            # Check if user has the required role
            if required_role not in g.roles:
                return jsonify({
                    'error': 'Access denied',
                    'message': f'Role "{required_role}" is required',
                    'user_roles': g.roles
                }), 403

            return f(*args, **kwargs)

        return decorated_function
    return decorator


def require_any_role(required_roles: List[str]) -> Callable:
    """
    Decorator to require any of the specified roles for a Flask route.

    Must be used in combination with @require_auth.
    Checks if the authenticated user has at least one of the specified roles.

    Usage:
        @app.route('/api/security')
        @require_auth
        @require_any_role(['admin', 'security-analyst'])
        def security_route():
            return jsonify({'message': 'Security access granted'})

    Args:
        required_roles: List of role names (user needs at least one)

    Returns:
        Decorated function

    Responses:
        403: If user doesn't have any of the required roles
    """
    def decorator(f: Callable) -> Callable:
        @wraps(f)
        def decorated_function(*args, **kwargs):
            # Check if user is authenticated
            if not hasattr(g, 'roles'):
                return jsonify({
                    'error': 'Authentication required',
                    'message': 'User is not authenticated'
                }), 401

            # Check if user has any of the required roles
            has_role = any(role in g.roles for role in required_roles)

            if not has_role:
                return jsonify({
                    'error': 'Access denied',
                    'message': f'One of the following roles is required: {", ".join(required_roles)}',
                    'user_roles': g.roles
                }), 403

            return f(*args, **kwargs)

        return decorated_function
    return decorator


def require_all_roles(required_roles: List[str]) -> Callable:
    """
    Decorator to require all of the specified roles for a Flask route.

    Must be used in combination with @require_auth.
    Checks if the authenticated user has all of the specified roles.

    Usage:
        @app.route('/api/super-admin')
        @require_auth
        @require_all_roles(['admin', 'auditor'])
        def super_admin_route():
            return jsonify({'message': 'Super admin access granted'})

    Args:
        required_roles: List of role names (user needs all of them)

    Returns:
        Decorated function

    Responses:
        403: If user doesn't have all of the required roles
    """
    def decorator(f: Callable) -> Callable:
        @wraps(f)
        def decorated_function(*args, **kwargs):
            # Check if user is authenticated
            if not hasattr(g, 'roles'):
                return jsonify({
                    'error': 'Authentication required',
                    'message': 'User is not authenticated'
                }), 401

            # Check if user has all of the required roles
            missing_roles = [role for role in required_roles if role not in g.roles]

            if missing_roles:
                return jsonify({
                    'error': 'Access denied',
                    'message': f'Missing required roles: {", ".join(missing_roles)}',
                    'user_roles': g.roles
                }), 403

            return f(*args, **kwargs)

        return decorated_function
    return decorator


def optional_auth(f: Callable) -> Callable:
    """
    Decorator for optional JWT authentication.

    Validates the JWT token if present, but doesn't require it.
    Useful for routes that behave differently for authenticated vs anonymous users.

    Usage:
        @app.route('/api/public')
        @optional_auth
        def public_route():
            if hasattr(g, 'user'):
                return jsonify({'message': f'Hello {g.user["username"]}'})
            else:
                return jsonify({'message': 'Hello anonymous'})

    Returns:
        Decorated function
    """
    @wraps(f)
    def decorated_function(*args, **kwargs):
        try:
            # Try to extract token from header
            token = extract_token_from_header()

            if token:
                # Decode and validate token
                token_payload = decode_token(token)

                # Extract user info and roles
                user_info = extract_user_info(token_payload)
                roles = extract_roles(token_payload, KEYCLOAK_CLIENT_ID)

                # Store in Flask's g object
                g.token_payload = token_payload
                g.user = user_info
                g.roles = roles

        except (ValueError, TokenValidationError):
            # Token is invalid, but that's okay for optional auth
            pass

        return f(*args, **kwargs)

    return decorated_function
