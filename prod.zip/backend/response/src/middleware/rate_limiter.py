"""
Rate Limiting Middleware

This module provides rate limiting functionality for the Athena Network Response Management system.
It implements multiple rate limiting strategies including IP-based, user-based, and endpoint-specific limits.
"""

import time
import hashlib
import json
from typing import Dict, Optional, Callable, Any, Union
from collections import defaultdict, deque
from functools import wraps
from flask import Flask, request, jsonify, g
import logging
import os
import threading

# Configure logging
logger = logging.getLogger(__name__)


class RateLimitExceeded(Exception):
    """Exception raised when rate limit is exceeded"""
    def __init__(self, message: str, retry_after: int = None):
        self.message = message
        self.retry_after = retry_after
        super().__init__(message)


class MemoryRateLimiter:
    """
    In-memory rate limiter using sliding window algorithm.
    
    This implementation stores rate limit data in memory and is suitable for
    single-instance deployments. For distributed deployments, consider using
    Redis-based rate limiting.
    """
    
    def __init__(self):
        """Initialize the in-memory rate limiter"""
        self._locks: Dict[str, threading.Lock] = defaultdict(threading.Lock)
        self._requests: Dict[str, deque] = defaultdict(deque)
        self._cleanup_thread = None
        self._running = False
        self._start_cleanup_thread()
    
    def _start_cleanup_thread(self):
        """Start background thread to clean up old request records"""
        if self._cleanup_thread is None or not self._cleanup_thread.is_alive():
            self._running = True
            self._cleanup_thread = threading.Thread(target=self._cleanup_old_requests, daemon=True)
            self._cleanup_thread.start()
    
    def _cleanup_old_requests(self):
        """Clean up old request records to prevent memory leaks"""
        while self._running:
            try:
                current_time = time.time()
                keys_to_remove = []
                
                for key, requests in self._requests.items():
                    # Remove requests older than 1 hour
                    while requests and current_time - requests[0] > 3600:
                        requests.popleft()
                    
                    # Remove empty queues
                    if not requests:
                        keys_to_remove.append(key)
                
                for key in keys_to_remove:
                    del self._requests[key]
                
                # Sleep for 5 minutes before next cleanup
                time.sleep(300)
                
            except Exception as e:
                logger.error(f"Error in cleanup thread: {e}")
                time.sleep(60)
    
    def is_allowed(self, key: str, limit: int, window: int) -> tuple[bool, int]:
        """
        Check if a request is allowed based on rate limit
        
        Args:
            key: Unique identifier for the client (IP, user ID, etc.)
            limit: Maximum number of requests allowed
            window: Time window in seconds
            
        Returns:
            Tuple of (is_allowed, retry_after)
        """
        current_time = time.time()
        
        with self._locks[key]:
            requests = self._requests[key]
            
            # Remove old requests outside the window
            while requests and current_time - requests[0] > window:
                requests.popleft()
            
            # Check if limit is exceeded
            if len(requests) >= limit:
                # Calculate retry_after (time until oldest request expires)
                oldest_request = requests[0]
                retry_after = int(window - (current_time - oldest_request))
                return False, max(retry_after, 1)
            
            # Add current request
            requests.append(current_time)
            return True, 0
    
    def get_current_usage(self, key: str, window: int) -> int:
        """
        Get current usage count for a key
        
        Args:
            key: Unique identifier for the client
            window: Time window in seconds
            
        Returns:
            Current number of requests in the window
        """
        current_time = time.time()
        
        with self._locks[key]:
            requests = self._requests[key]
            
            # Remove old requests outside the window
            while requests and current_time - requests[0] > window:
                requests.popleft()
            
            return len(requests)
    
    def reset(self, key: str):
        """Reset rate limit for a specific key"""
        with self._locks[key]:
            if key in self._requests:
                del self._requests[key]
    
    def stop(self):
        """Stop the cleanup thread"""
        self._running = False
        if self._cleanup_thread:
            self._cleanup_thread.join(timeout=5)


class RateLimiter:
    """
    Main rate limiter class that provides different rate limiting strategies
    """
    
    def __init__(self, storage_backend: Optional[MemoryRateLimiter] = None):
        """
        Initialize rate limiter
        
        Args:
            storage_backend: Storage backend for rate limit data
        """
        self.storage = storage_backend or MemoryRateLimiter()
        
        # Default rate limit configurations
        self.default_limits = {
            'global': {'limit': 1000, 'window': 3600},  # 1000 requests per hour globally
            'ip': {'limit': 100, 'window': 60},        # 100 requests per minute per IP
            'user': {'limit': 200, 'window': 60},      # 200 requests per minute per user
            'endpoint': {
                '/api/alerts': {'limit': 30, 'window': 60},      # 30 requests per minute
                '/api/firewall': {'limit': 20, 'window': 60},    # 20 requests per minute
                '/api/waf-signatures': {'limit': 15, 'window': 60}, # 15 requests per minute
                '/api/background-modules': {'limit': 10, 'window': 60}, # 10 requests per minute
                '/api/admin': {'limit': 50, 'window': 60},        # 50 requests per minute
                '/health': {'limit': 10, 'window': 60},           # 10 requests per minute
            }
        }
        
        # Authentication endpoints have stricter limits
        self.auth_limits = {
            'limit': 5, 'window': 300  # 5 requests per 5 minutes for auth endpoints
        }
    
    def _get_client_ip(self) -> str:
        """Get client IP address from request"""
        # Check for forwarded IP headers first
        if request.headers.get('X-Forwarded-For'):
            return request.headers.get('X-Forwarded-For').split(',')[0].strip()
        elif request.headers.get('X-Real-IP'):
            return request.headers.get('X-Real-IP')
        else:
            return request.remote_addr or 'unknown'
    
    def _get_user_key(self) -> Optional[str]:
        """Get user identifier for rate limiting"""
        if hasattr(g, 'user') and g.user:
            return f"user:{g.user.get('id', g.user.get('username', 'unknown'))}"
        return None
    
    def _get_endpoint_key(self, endpoint: str) -> str:
        """Get endpoint-specific key for rate limiting"""
        # Group similar endpoints
        if endpoint.startswith('/api/firewall'):
            return '/api/firewall'
        elif endpoint.startswith('/api/waf-signatures'):
            return '/api/waf-signatures'
        elif endpoint.startswith('/api/background-modules'):
            return '/api/background-modules'
        elif endpoint.startswith('/api/admin'):
            return '/api/admin'
        elif endpoint.startswith('/api/alerts'):
            return '/api/alerts'
        else:
            return endpoint
    
    def _is_auth_endpoint(self, endpoint: str) -> bool:
        """Check if endpoint is authentication-related"""
        auth_endpoints = [
            '/auth', '/login', '/logout', '/token', '/refresh',
            '/api/auth', '/api/login', '/api/logout'
        ]
        return any(endpoint.startswith(auth_ep) for auth_ep in auth_endpoints)
    
    def check_rate_limit(self, endpoint: str = None) -> tuple[bool, int, Dict[str, Any]]:
        """
        Check if request is allowed based on rate limits
        
        Args:
            endpoint: Request endpoint path
            
        Returns:
            Tuple of (is_allowed, retry_after, limit_info)
        """
        endpoint = endpoint or request.path
        client_ip = self._get_client_ip()
        user_key = self._get_user_key()
        endpoint_key = self._get_endpoint_key(endpoint)
        
        limit_info = {
            'endpoint': endpoint,
            'client_ip': client_ip,
            'user_key': user_key,
            'limits_checked': []
        }
        
        # Check authentication endpoint limits first (stricter)
        if self._is_auth_endpoint(endpoint):
            auth_key = f"auth:{client_ip}"
            is_allowed, retry_after = self.storage.is_allowed(
                auth_key,
                self.auth_limits['limit'],
                self.auth_limits['window']
            )
            
            limit_info['limits_checked'].append({
                'type': 'auth',
                'key': auth_key,
                'limit': self.auth_limits['limit'],
                'window': self.auth_limits['window'],
                'current': self.storage.get_current_usage(auth_key, self.auth_limits['window'])
            })
            
            if not is_allowed:
                return False, retry_after, limit_info
        
        # Check IP-based rate limit
        ip_key = f"ip:{client_ip}"
        ip_limit = self.default_limits['ip']
        is_allowed, retry_after = self.storage.is_allowed(
            ip_key,
            ip_limit['limit'],
            ip_limit['window']
        )
        
        limit_info['limits_checked'].append({
            'type': 'ip',
            'key': ip_key,
            'limit': ip_limit['limit'],
            'window': ip_limit['window'],
            'current': self.storage.get_current_usage(ip_key, ip_limit['window'])
        })
        
        if not is_allowed:
            return False, retry_after, limit_info
        
        # Check user-based rate limit if user is authenticated
        if user_key:
            user_limit = self.default_limits['user']
            is_allowed, retry_after = self.storage.is_allowed(
                user_key,
                user_limit['limit'],
                user_limit['window']
            )
            
            limit_info['limits_checked'].append({
                'type': 'user',
                'key': user_key,
                'limit': user_limit['limit'],
                'window': user_limit['window'],
                'current': self.storage.get_current_usage(user_key, user_limit['window'])
            })
            
            if not is_allowed:
                return False, retry_after, limit_info
        
        # Check endpoint-specific rate limit
        if endpoint_key in self.default_limits['endpoint']:
            endpoint_limit = self.default_limits['endpoint'][endpoint_key]
            endpoint_full_key = f"endpoint:{endpoint_key}:{client_ip}"
            is_allowed, retry_after = self.storage.is_allowed(
                endpoint_full_key,
                endpoint_limit['limit'],
                endpoint_limit['window']
            )
            
            limit_info['limits_checked'].append({
                'type': 'endpoint',
                'key': endpoint_full_key,
                'limit': endpoint_limit['limit'],
                'window': endpoint_limit['window'],
                'current': self.storage.get_current_usage(endpoint_full_key, endpoint_limit['window'])
            })
            
            if not is_allowed:
                return False, retry_after, limit_info
        
        return True, 0, limit_info
    
    def get_rate_limit_headers(self, limit_info: Dict[str, Any]) -> Dict[str, str]:
        """
        Generate rate limit headers for response
        
        Args:
            limit_info: Rate limit information from check_rate_limit
            
        Returns:
            Dictionary of rate limit headers
        """
        headers = {}
        
        # Add headers for the most restrictive limit that was checked
        if limit_info['limits_checked']:
            # Find the limit with the lowest remaining capacity
            most_restrictive = min(
                limit_info['limits_checked'],
                key=lambda x: x['limit'] - x['current']
            )
            
            headers.update({
                'X-RateLimit-Limit': str(most_restrictive['limit']),
                'X-RateLimit-Remaining': str(most_restrictive['limit'] - most_restrictive['current']),
                'X-RateLimit-Reset': str(int(time.time() + most_restrictive['window'])),
                'X-RateLimit-Type': most_restrictive['type']
            })
        
        return headers


# Global rate limiter instance
rate_limiter = RateLimiter()


def rate_limit(limit: Optional[int] = None, window: Optional[int] = None, 
                per_ip: bool = True, per_user: bool = True):
    """
    Decorator for applying rate limiting to Flask routes
    
    Args:
        limit: Custom limit override
        window: Custom window override in seconds
        per_ip: Whether to apply IP-based rate limiting
        per_user: Whether to apply user-based rate limiting
        
    Usage:
        @app.route('/api/example')
        @rate_limit(limit=10, window=60)  # 10 requests per minute
        def example_route():
            return jsonify({'message': 'Hello'})
    """
    def decorator(f: Callable) -> Callable:
        @wraps(f)
        def decorated_function(*args, **kwargs):
            try:
                # Check rate limit
                is_allowed, retry_after, limit_info = rate_limiter.check_rate_limit()
                
                # Add rate limit headers to response
                if hasattr(g, 'rate_limit_headers'):
                    g.rate_limit_headers.update(rate_limiter.get_rate_limit_headers(limit_info))
                else:
                    g.rate_limit_headers = rate_limiter.get_rate_limit_headers(limit_info)
                
                if not is_allowed:
                    response = jsonify({
                        'error': 'Rate limit exceeded',
                        'message': 'Too many requests. Please try again later.',
                        'retry_after': retry_after
                    })
                    response.status_code = 429
                    
                    # Add rate limit headers to error response
                    headers = rate_limiter.get_rate_limit_headers(limit_info)
                    if retry_after:
                        headers['Retry-After'] = str(retry_after)
                    
                    for key, value in headers.items():
                        response.headers[key] = value
                    
                    return response
                
                return f(*args, **kwargs)
                
            except Exception as e:
                logger.error(f"Rate limiting error: {e}")
                # Allow request to proceed if rate limiting fails
                return f(*args, **kwargs)
        
        return decorated_function
    return decorator


def init_rate_limiter(app: Flask):
    """
    Initialize rate limiter with Flask application
    
    Args:
        app: Flask application instance
    """
    # Configure rate limiter from environment variables
    if os.getenv('RATE_LIMIT_ENABLED', 'true').lower() == 'false':
        logger.info("Rate limiting is disabled")
        return
    
    # Override default limits from environment
    if os.getenv('RATE_LIMIT_GLOBAL'):
        try:
            limit, window = map(int, os.getenv('RATE_LIMIT_GLOBAL').split(','))
            rate_limiter.default_limits['global'] = {'limit': limit, 'window': window}
        except ValueError:
            logger.warning("Invalid RATE_LIMIT_GLOBAL format. Expected 'limit,window'")
    
    if os.getenv('RATE_LIMIT_IP'):
        try:
            limit, window = map(int, os.getenv('RATE_LIMIT_IP').split(','))
            rate_limiter.default_limits['ip'] = {'limit': limit, 'window': window}
        except ValueError:
            logger.warning("Invalid RATE_LIMIT_IP format. Expected 'limit,window'")
    
    if os.getenv('RATE_LIMIT_USER'):
        try:
            limit, window = map(int, os.getenv('RATE_LIMIT_USER').split(','))
            rate_limiter.default_limits['user'] = {'limit': limit, 'window': window}
        except ValueError:
            logger.warning("Invalid RATE_LIMIT_USER format. Expected 'limit,window'")
    
    # Add before_request handler to set rate limit headers
    @app.before_request
    def add_rate_limit_headers():
        """Add rate limit headers to all responses"""
        g.rate_limit_headers = {}
    
    @app.after_request
    def set_rate_limit_headers(response):
        """Set rate limit headers in response"""
        if hasattr(g, 'rate_limit_headers'):
            for key, value in g.rate_limit_headers.items():
                response.headers[key] = value
        return response
    
    # Add rate limit reset endpoint (admin only)
    @app.route('/api/admin/rate-limit/reset', methods=['POST'])
    def reset_rate_limit():
        """Reset rate limit for a specific IP or user (admin only)"""
        try:
            data = request.get_json() or {}
            target_type = data.get('type', 'ip')  # 'ip' or 'user'
            target = data.get('target')
            
            if not target:
                return jsonify({
                    'error': 'Target is required',
                    'message': 'Provide IP address or user identifier'
                }), 400
            
            if target_type == 'ip':
                key = f"ip:{target}"
            elif target_type == 'user':
                key = f"user:{target}"
            else:
                return jsonify({
                    'error': 'Invalid type',
                    'message': 'Type must be "ip" or "user"'
                }), 400
            
            rate_limiter.storage.reset(key)
            
            return jsonify({
                'success': True,
                'message': f'Rate limit reset for {target_type}: {target}'
            })
            
        except Exception as e:
            logger.error(f"Error resetting rate limit: {e}")
            return jsonify({
                'error': 'Internal server error',
                'message': 'Failed to reset rate limit'
            }), 500
    
    logger.info("Rate limiter initialized successfully")


# Cleanup function
def cleanup_rate_limiter():
    """Cleanup rate limiter resources"""
    if hasattr(rate_limiter, 'storage'):
        rate_limiter.storage.stop()
