"""
Threat Intelligence Caching for Athena Network Response Management

This module provides intelligent caching for external threat intelligence sources
to reduce API costs, improve response times, and optimize external API calls to
MISP, OTX, AbuseIPDB, and other threat intelligence providers.
"""

import json
import time
import logging
import hashlib
import requests
from typing import List, Dict, Any, Optional, Set, Tuple
from datetime import datetime, timedelta
from dataclasses import dataclass, asdict
from enum import Enum
import threading
from concurrent.futures import ThreadPoolExecutor, as_completed
import redis
from urllib.parse import urljoin, urlparse
import os

logger = logging.getLogger(__name__)

class ThreatIntelSource(Enum):
    """Threat intelligence source types"""
    MISP = "misp"
    OTX = "otx"
    ABUSEIPDB = "abuseipdb"
    VIRUSTOTAL = "virustotal"
    THREAT_CONNECT = "threat_connect"
    CUSTOM = "custom"

class IndicatorType(Enum):
    """Types of threat intelligence indicators"""
    IP_ADDRESS = "ip"
    DOMAIN = "domain"
    URL = "url"
    HASH = "hash"
    EMAIL = "email"
    FILENAME = "filename"

@dataclass
class ThreatIntelIndicator:
    """Threat intelligence indicator data"""
    indicator: str
    indicator_type: IndicatorType
    source: ThreatIntelSource
    confidence: float
    severity: str
    first_seen: datetime
    last_seen: datetime
    tags: List[str]
    description: str
    raw_data: Dict[str, Any]
    expires_at: datetime
    cache_key: str

@dataclass
class ThreatIntelConfig:
    """Configuration for threat intelligence source"""
    source: ThreatIntelSource
    enabled: bool
    api_key: Optional[str]
    api_url: str
    rate_limit_per_minute: int
    timeout_seconds: int
    cache_ttl_hours: int
    retry_attempts: int
    batch_size: int

class ThreatIntelCache:
    """Intelligent threat intelligence caching system"""
    
    def __init__(self, app=None):
        self.app = app
        self.enabled = True
        self.redis_client = None
        self.cache_prefix = "threat_intel:"
        self.sources = {}
        self.request_queue = []
        self.batch_processor = None
        self.stats = {
            'cache_hits': 0,
            'cache_misses': 0,
            'api_requests': 0,
            'api_failures': 0,
            'indicators_cached': 0,
            'cache_size': 0,
            'last_cleanup': None
        }
        self._lock = threading.Lock()
        
        if app is not None:
            self.init_app(app)
    
    def init_app(self, app):
        """Initialize threat intelligence cache with Flask app"""
        self.enabled = app.config.get('THREAT_INTEL_CACHE_ENABLED', True)
        
        if not self.enabled:
            logger.info("Threat intelligence cache is disabled")
            return
        
        try:
            # Initialize Redis connection
            redis_host = app.config.get('REDIS_HOST', 'localhost')
            redis_port = app.config.get('REDIS_PORT', 6379)
            redis_db = app.config.get('REDIS_DB', 0)
            redis_password = app.config.get('REDIS_PASSWORD', None)
            
            self.redis_client = redis.Redis(
                host=redis_host,
                port=redis_port,
                db=redis_db,
                password=redis_password,
                decode_responses=False
            )
            
            # Test connection
            self.redis_client.ping()
            
            # Initialize threat intelligence sources
            self._initialize_sources(app.config)
            
            # Start batch processor
            self._start_batch_processor()
            
            logger.info("Threat intelligence cache initialized successfully")
            
        except Exception as e:
            logger.error(f"Failed to initialize threat intelligence cache: {e}")
            self.enabled = False
    
    def _initialize_sources(self, config: Dict[str, Any]):
        """Initialize threat intelligence source configurations"""
        
        # MISP Configuration
        self.sources[ThreatIntelSource.MISP] = ThreatIntelConfig(
            source=ThreatIntelSource.MISP,
            enabled=config.get('MISP_ENABLED', False),
            api_key=config.get('MISP_API_KEY'),
            api_url=config.get('MISP_API_URL', ''),
            rate_limit_per_minute=config.get('MISP_RATE_LIMIT', 60),
            timeout_seconds=config.get('MISP_TIMEOUT', 30),
            cache_ttl_hours=config.get('MISP_CACHE_TTL', 24),
            retry_attempts=config.get('MISP_RETRY_ATTEMPTS', 3),
            batch_size=config.get('MISP_BATCH_SIZE', 100)
        )
        
        # OTX Configuration
        self.sources[ThreatIntelSource.OTX] = ThreatIntelConfig(
            source=ThreatIntelSource.OTX,
            enabled=config.get('OTX_ENABLED', False),
            api_key=config.get('OTX_API_KEY'),
            api_url=config.get('OTX_API_URL', 'https://otx.alienvault.com/api/v1'),
            rate_limit_per_minute=config.get('OTX_RATE_LIMIT', 60),
            timeout_seconds=config.get('OTX_TIMEOUT', 30),
            cache_ttl_hours=config.get('OTX_CACHE_TTL', 12),
            retry_attempts=config.get('OTX_RETRY_ATTEMPTS', 3),
            batch_size=config.get('OTX_BATCH_SIZE', 50)
        )
        
        # AbuseIPDB Configuration
        self.sources[ThreatIntelSource.ABUSEIPDB] = ThreatIntelConfig(
            source=ThreatIntelSource.ABUSEIPDB,
            enabled=config.get('ABUSEIPDB_ENABLED', False),
            api_key=config.get('ABUSEIPDB_API_KEY'),
            api_url=config.get('ABUSEIPDB_API_URL', 'https://api.abuseipdb.com/api/v2'),
            rate_limit_per_minute=config.get('ABUSEIPDB_RATE_LIMIT', 1000),
            timeout_seconds=config.get('ABUSEIPDB_TIMEOUT', 10),
            cache_ttl_hours=config.get('ABUSEIPDB_CACHE_TTL', 6),
            retry_attempts=config.get('ABUSEIPDB_RETRY_ATTEMPTS', 3),
            batch_size=config.get('ABUSEIPDB_BATCH_SIZE', 100)
        )
        
        # VirusTotal Configuration
        self.sources[ThreatIntelSource.VIRUSTOTAL] = ThreatIntelConfig(
            source=ThreatIntelSource.VIRUSTOTAL,
            enabled=config.get('VIRUSTOTAL_ENABLED', False),
            api_key=config.get('VIRUSTOTAL_API_KEY'),
            api_url=config.get('VIRUSTOTAL_API_URL', 'https://www.virustotal.com/vtapi/v2'),
            rate_limit_per_minute=config.get('VIRUSTOTAL_RATE_LIMIT', 4),
            timeout_seconds=config.get('VIRUSTOTAL_TIMEOUT', 30),
            cache_ttl_hours=config.get('VIRUSTOTAL_CACHE_TTL', 24),
            retry_attempts=config.get('VIRUSTOTAL_RETRY_ATTEMPTS', 3),
            batch_size=config.get('VIRUSTOTAL_BATCH_SIZE', 25)
        )
        
        # ThreatConnect Configuration
        self.sources[ThreatIntelSource.THREAT_CONNECT] = ThreatIntelConfig(
            source=ThreatIntelSource.THREAT_CONNECT,
            enabled=config.get('THREAT_CONNECT_ENABLED', False),
            api_key=config.get('THREAT_CONNECT_API_KEY'),
            api_url=config.get('THREAT_CONNECT_API_URL', ''),
            rate_limit_per_minute=config.get('THREAT_CONNECT_RATE_LIMIT', 60),
            timeout_seconds=config.get('THREAT_CONNECT_TIMEOUT', 30),
            cache_ttl_hours=config.get('THREAT_CONNECT_CACHE_TTL', 12),
            retry_attempts=config.get('THREAT_CONNECT_RETRY_ATTEMPTS', 3),
            batch_size=config.get('THREAT_CONNECT_BATCH_SIZE', 50)
        )
        
        logger.info(f"Initialized {len(self.sources)} threat intelligence sources")
    
    def _start_batch_processor(self):
        """Start background batch processor for queued requests"""
        self.batch_processor = threading.Thread(target=self._batch_processor_loop, daemon=True)
        self.batch_processor.start()
        logger.info("Threat intelligence batch processor started")
    
    def _batch_processor_loop(self):
        """Background batch processor main loop"""
        while True:
            try:
                if self.request_queue:
                    self._process_batch_requests()
                else:
                    time.sleep(1)  # Wait for requests
            except Exception as e:
                logger.error(f"Error in batch processor: {e}")
                time.sleep(5)
    
    def _process_batch_requests(self):
        """Process queued requests in batches"""
        if not self.request_queue:
            return
        
        # Group requests by source
        requests_by_source = defaultdict(list)
        
        with self._lock:
            for request in self.request_queue[:100]:  # Process max 100 at a time
                requests_by_source[request['source']].append(request)
            
            # Remove processed requests from queue
            processed_count = sum(len(reqs) for reqs in requests_by_source.values())
            self.request_queue = self.request_queue[processed_count:]
        
        # Process each source's requests
        for source, requests in requests_by_source.items():
            if source in self.sources and self.sources[source].enabled:
                try:
                    self._process_source_batch(source, requests)
                except Exception as e:
                    logger.error(f"Error processing batch for {source.value}: {e}")
    
    def _process_source_batch(self, source: ThreatIntelSource, requests: List[Dict[str, Any]]):
        """Process batch requests for a specific source"""
        config = self.sources[source]
        
        # Group by indicator type for efficient API calls
        requests_by_type = defaultdict(list)
        for request in requests:
            requests_by_type[request['indicator_type']].append(request)
        
        # Process each type
        for indicator_type, type_requests in requests_by_type.items():
            try:
                if source == ThreatIntelSource.MISP:
                    self._fetch_misp_batch(config, type_requests)
                elif source == ThreatIntelSource.OTX:
                    self._fetch_otx_batch(config, type_requests)
                elif source == ThreatIntelSource.ABUSEIPDB:
                    self._fetch_abuseipdb_batch(config, type_requests)
                elif source == ThreatIntelSource.VIRUSTOTAL:
                    self._fetch_virustotal_batch(config, type_requests)
                elif source == ThreatIntelSource.THREAT_CONNECT:
                    self._fetch_threat_connect_batch(config, type_requests)
                
            except Exception as e:
                logger.error(f"Error processing {source.value} batch for {indicator_type.value}: {e}")
    
    def get_indicator(self, indicator: str, indicator_type: IndicatorType, 
                     sources: List[ThreatIntelSource] = None) -> List[ThreatIntelIndicator]:
        """Get threat intelligence for an indicator from cache or API"""
        if not self.enabled:
            return []
        
        if sources is None:
            sources = [s for s in ThreatIntelSource if s in self.sources and self.sources[s].enabled]
        
        results = []
        
        for source in sources:
            try:
                # Check cache first
                cache_key = self._generate_cache_key(source, indicator_type, indicator)
                cached_indicator = self._get_from_cache(cache_key)
                
                if cached_indicator:
                    self.stats['cache_hits'] += 1
                    results.append(cached_indicator)
                else:
                    # Cache miss - queue for batch processing
                    self.stats['cache_misses'] += 1
                    self._queue_request(source, indicator_type, indicator)
                    
            except Exception as e:
                logger.error(f"Error getting indicator {indicator} from {source.value}: {e}")
        
        return results
    
    def get_indicators_batch(self, indicators: List[Tuple[str, IndicatorType]], 
                           sources: List[ThreatIntelSource] = None) -> Dict[str, List[ThreatIntelIndicator]]:
        """Get threat intelligence for multiple indicators"""
        if not self.enabled:
            return {}
        
        if sources is None:
            sources = [s for s in ThreatIntelSource if s in self.sources and self.sources[s].enabled]
        
        results = {}
        
        # Check cache for all indicators
        uncached_indicators = []
        
        for indicator, indicator_type in indicators:
            indicator_results = []
            cache_key = None
            
            for source in sources:
                try:
                    cache_key = self._generate_cache_key(source, indicator_type, indicator)
                    cached_indicator = self._get_from_cache(cache_key)
                    
                    if cached_indicator:
                        self.stats['cache_hits'] += 1
                        indicator_results.append(cached_indicator)
                    else:
                        self.stats['cache_misses'] += 1
                        
                except Exception as e:
                    logger.error(f"Error checking cache for {indicator}: {e}")
            
            if indicator_results:
                results[indicator] = indicator_results
            else:
                uncached_indicators.append((indicator, indicator_type))
        
        # Queue uncached indicators for batch processing
        for indicator, indicator_type in uncached_indicators:
            for source in sources:
                self._queue_request(source, indicator_type, indicator)
        
        return results
    
    def _queue_request(self, source: ThreatIntelSource, indicator_type: IndicatorType, indicator: str):
        """Queue a request for batch processing"""
        request = {
            'source': source,
            'indicator_type': indicator_type,
            'indicator': indicator,
            'timestamp': time.time()
        }
        
        with self._lock:
            self.request_queue.append(request)
    
    def _get_from_cache(self, cache_key: str) -> Optional[ThreatIntelIndicator]:
        """Get indicator from cache"""
        try:
            if not self.redis_client:
                return None
            
            cached_data = self.redis_client.get(cache_key)
            if cached_data:
                data = json.loads(cached_data.decode('utf-8'))
                
                # Check if expired
                expires_at = datetime.fromisoformat(data['expires_at'])
                if datetime.utcnow() < expires_at:
                    return ThreatIntelIndicator(
                        indicator=data['indicator'],
                        indicator_type=IndicatorType(data['indicator_type']),
                        source=ThreatIntelSource(data['source']),
                        confidence=data['confidence'],
                        severity=data['severity'],
                        first_seen=datetime.fromisoformat(data['first_seen']),
                        last_seen=datetime.fromisoformat(data['last_seen']),
                        tags=data['tags'],
                        description=data['description'],
                        raw_data=data['raw_data'],
                        expires_at=expires_at,
                        cache_key=cache_key
                    )
                else:
                    # Remove expired entry
                    self.redis_client.delete(cache_key)
            
            return None
            
        except Exception as e:
            logger.error(f"Error getting from cache: {e}")
            return None
    
    def _cache_indicator(self, indicator: ThreatIntelIndicator):
        """Cache an indicator"""
        try:
            if not self.redis_client:
                return
            
            cache_data = {
                'indicator': indicator.indicator,
                'indicator_type': indicator.indicator_type.value,
                'source': indicator.source.value,
                'confidence': indicator.confidence,
                'severity': indicator.severity,
                'first_seen': indicator.first_seen.isoformat(),
                'last_seen': indicator.last_seen.isoformat(),
                'tags': indicator.tags,
                'description': indicator.description,
                'raw_data': indicator.raw_data,
                'expires_at': indicator.expires_at.isoformat()
            }
            
            # Cache with TTL
            ttl_seconds = int((indicator.expires_at - datetime.utcnow()).total_seconds())
            self.redis_client.setex(
                indicator.cache_key,
                ttl_seconds,
                json.dumps(cache_data)
            )
            
            self.stats['indicators_cached'] += 1
            
        except Exception as e:
            logger.error(f"Error caching indicator: {e}")
    
    def _generate_cache_key(self, source: ThreatIntelSource, indicator_type: IndicatorType, indicator: str) -> str:
        """Generate cache key for indicator"""
        key_data = f"{source.value}:{indicator_type.value}:{indicator}"
        key_hash = hashlib.md5(key_data.encode()).hexdigest()
        return f"{self.cache_prefix}{key_hash}"
    
    def _fetch_misp_batch(self, config: ThreatIntelConfig, requests: List[Dict[str, Any]]):
        """Fetch indicators from MISP in batch"""
        if not config.api_key or not config.api_url:
            return
        
        headers = {
            'Authorization': config.api_key,
            'Accept': 'application/json',
            'Content-Type': 'application/json'
        }
        
        # MISP doesn't have a true batch API, so we'll make individual requests
        # but respect rate limits
        for request in requests:
            try:
                indicator = request['indicator']
                indicator_type = request['indicator_type']
                
                # Build MISP search query
                search_url = urljoin(config.api_url, '/attributes/restSearch')
                search_data = {
                    'value': indicator,
                    'type': self._map_indicator_type_to_misp(indicator_type),
                    'limit': 10
                }
                
                response = requests.post(
                    search_url,
                    headers=headers,
                    json=search_data,
                    timeout=config.timeout_seconds
                )
                
                if response.status_code == 200:
                    data = response.json()
                    if data.get('Attribute'):
                        for attr in data['Attribute']:
                            indicator_obj = self._parse_misp_attribute(attr, indicator, indicator_type)
                            if indicator_obj:
                                self._cache_indicator(indicator_obj)
                
                self.stats['api_requests'] += 1
                
                # Rate limiting
                time.sleep(60.0 / config.rate_limit_per_minute)
                
            except Exception as e:
                logger.error(f"Error fetching from MISP: {e}")
                self.stats['api_failures'] += 1
    
    def _fetch_otx_batch(self, config: ThreatIntelConfig, requests: List[Dict[str, Any]]):
        """Fetch indicators from OTX in batch"""
        if not config.api_key:
            return
        
        headers = {
            'X-OTX-API-KEY': config.api_key,
            'Accept': 'application/json'
        }
        
        for request in requests:
            try:
                indicator = request['indicator']
                indicator_type = request['indicator_type']
                
                # Build OTX URL based on indicator type
                if indicator_type == IndicatorType.IP_ADDRESS:
                    url = f"{config.api_url}/indicators/IPv4/{indicator}/reputation"
                elif indicator_type == IndicatorType.DOMAIN:
                    url = f"{config.api_url}/indicators/domain/{indicator}/reputation"
                elif indicator_type == IndicatorType.URL:
                    url = f"{config.api_url}/indicators/URL/{indicator}/reputation"
                elif indicator_type == IndicatorType.HASH:
                    url = f"{config.api_url}/indicators/file/{indicator}/general"
                else:
                    continue
                
                response = requests.get(url, headers=headers, timeout=config.timeout_seconds)
                
                if response.status_code == 200:
                    data = response.json()
                    indicator_obj = self._parse_otx_response(data, indicator, indicator_type)
                    if indicator_obj:
                        self._cache_indicator(indicator_obj)
                
                self.stats['api_requests'] += 1
                time.sleep(60.0 / config.rate_limit_per_minute)
                
            except Exception as e:
                logger.error(f"Error fetching from OTX: {e}")
                self.stats['api_failures'] += 1
    
    def _fetch_abuseipdb_batch(self, config: ThreatIntelConfig, requests: List[Dict[str, Any]]):
        """Fetch indicators from AbuseIPDB in batch"""
        if not config.api_key:
            return
        
        headers = {
            'Key': config.api_key,
            'Accept': 'application/json'
        }
        
        # AbuseIPDB supports bulk checking
        ip_indicators = [req['indicator'] for req in requests 
                        if req['indicator_type'] == IndicatorType.IP_ADDRESS]
        
        if not ip_indicators:
            return
        
        # Process in batches
        for i in range(0, len(ip_indicators), config.batch_size):
            batch = ip_indicators[i:i + config.batch_size]
            
            try:
                data = {
                    'ips': ','.join(batch),
                    'maxAgeInDays': config.cache_ttl_hours * 24,
                    'verbose': ''
                }
                
                response = requests.post(
                    f"{config.api_url}/check",
                    headers=headers,
                    data=data,
                    timeout=config.timeout_seconds
                )
                
                if response.status_code == 200:
                    result = response.json()
                    if 'data' in result:
                        for item in result['data']:
                            indicator_obj = self._parse_abuseipdb_response(item, IndicatorType.IP_ADDRESS)
                            if indicator_obj:
                                self._cache_indicator(indicator_obj)
                
                self.stats['api_requests'] += 1
                time.sleep(60.0 / config.rate_limit_per_minute)
                
            except Exception as e:
                logger.error(f"Error fetching from AbuseIPDB: {e}")
                self.stats['api_failures'] += 1
    
    def _fetch_virustotal_batch(self, config: ThreatIntelConfig, requests: List[Dict[str, Any]]):
        """Fetch indicators from VirusTotal in batch"""
        if not config.api_key:
            return
        
        params = {'apikey': config.api_key}
        
        # Group by indicator type for VirusTotal API
        ip_indicators = []
        domain_indicators = []
        hash_indicators = []
        url_indicators = []
        
        for request in requests:
            indicator = request['indicator']
            indicator_type = request['indicator_type']
            
            if indicator_type == IndicatorType.IP_ADDRESS:
                ip_indicators.append(indicator)
            elif indicator_type == IndicatorType.DOMAIN:
                domain_indicators.append(indicator)
            elif indicator_type == IndicatorType.HASH:
                hash_indicators.append(indicator)
            elif indicator_type == IndicatorType.URL:
                url_indicators.append(indicator)
        
        # Process each type
        all_indicators = [
            (ip_indicators, 'ip_addresses', IndicatorType.IP_ADDRESS),
            (domain_indicators, 'domains', IndicatorType.DOMAIN),
            (hash_indicators, 'files', IndicatorType.HASH),
            (url_indicators, 'urls', IndicatorType.URL)
        ]
        
        for indicators, endpoint, indicator_type in all_indicators:
            if not indicators:
                continue
            
            for indicator in indicators:
                try:
                    url = f"{config.api_url}/{endpoint}/report"
                    params['resource'] = indicator
                    
                    response = requests.get(url, params=params, timeout=config.timeout_seconds)
                    
                    if response.status_code == 200:
                        data = response.json()
                        indicator_obj = self._parse_virustotal_response(data, indicator, indicator_type)
                        if indicator_obj:
                            self._cache_indicator(indicator_obj)
                    
                    self.stats['api_requests'] += 1
                    time.sleep(60.0 / config.rate_limit_per_minute)
                    
                except Exception as e:
                    logger.error(f"Error fetching from VirusTotal: {e}")
                    self.stats['api_failures'] += 1
    
    def _fetch_threat_connect_batch(self, config: ThreatIntelConfig, requests: List[Dict[str, Any]]):
        """Fetch indicators from ThreatConnect in batch"""
        # Placeholder for ThreatConnect integration
        # Implementation would depend on specific ThreatConnect API
        logger.info("ThreatConnect batch fetching not yet implemented")
    
    def _map_indicator_type_to_misp(self, indicator_type: IndicatorType) -> str:
        """Map indicator type to MISP attribute type"""
        mapping = {
            IndicatorType.IP_ADDRESS: 'ip-dst',
            IndicatorType.DOMAIN: 'domain',
            IndicatorType.URL: 'url',
            IndicatorType.HASH: 'md5',  # Could be sha1, sha256 based on hash length
            IndicatorType.EMAIL: 'email-src',
            IndicatorType.FILENAME: 'filename'
        }
        return mapping.get(indicator_type, 'text')
    
    def _parse_misp_attribute(self, attr: Dict[str, Any], indicator: str, 
                            indicator_type: IndicatorType) -> Optional[ThreatIntelIndicator]:
        """Parse MISP attribute response"""
        try:
            # Calculate TTL based on timestamp
            timestamp = datetime.fromisoformat(attr.get('timestamp', datetime.utcnow().isoformat()))
            expires_at = timestamp + timedelta(hours=24)  # Default 24 hour TTL
            
            return ThreatIntelIndicator(
                indicator=indicator,
                indicator_type=indicator_type,
                source=ThreatIntelSource.MISP,
                confidence=attr.get('confidence', 50) / 100.0,
                severity=attr.get('threat_level', 'medium'),
                first_seen=timestamp,
                last_seen=timestamp,
                tags=attr.get('Tag', []),
                description=attr.get('comment', ''),
                raw_data=attr,
                expires_at=expires_at,
                cache_key=self._generate_cache_key(ThreatIntelSource.MISP, indicator_type, indicator)
            )
        except Exception as e:
            logger.error(f"Error parsing MISP attribute: {e}")
            return None
    
    def _parse_otx_response(self, data: Dict[str, Any], indicator: str, 
                          indicator_type: IndicatorType) -> Optional[ThreatIntelIndicator]:
        """Parse OTX response"""
        try:
            # Extract relevant data from OTX response
            reputation = data.get('reputation', {})
            pulses = data.get('pulse_info', {}).get('pulses', [])
            
            # Calculate confidence based on pulses and reputation
            confidence = min(len(pulses) * 0.1, 1.0)
            if reputation.get('malicious', False):
                confidence = max(confidence, 0.7)
            
            # Determine severity
            if reputation.get('malicious', False):
                severity = 'high'
            elif len(pulses) > 5:
                severity = 'medium'
            else:
                severity = 'low'
            
            # Extract tags from pulses
            tags = []
            for pulse in pulses:
                tags.extend(pulse.get('tags', []))
            
            # Calculate TTL
            created = datetime.fromisoformat(data.get('created', datetime.utcnow().isoformat()))
            expires_at = created + timedelta(hours=12)  # 12 hour TTL
            
            return ThreatIntelIndicator(
                indicator=indicator,
                indicator_type=indicator_type,
                source=ThreatIntelSource.OTX,
                confidence=confidence,
                severity=severity,
                first_seen=created,
                last_seen=created,
                tags=tags,
                description=f"OTX threat intelligence with {len(pulses)} pulses",
                raw_data=data,
                expires_at=expires_at,
                cache_key=self._generate_cache_key(ThreatIntelSource.OTX, indicator_type, indicator)
            )
        except Exception as e:
            logger.error(f"Error parsing OTX response: {e}")
            return None
    
    def _parse_abuseipdb_response(self, data: Dict[str, Any], 
                                indicator_type: IndicatorType) -> Optional[ThreatIntelIndicator]:
        """Parse AbuseIPDB response"""
        try:
            # Extract data from AbuseIPDB response
            abuse_confidence = data.get('abuseConfidencePercentage', 0) / 100.0
            total_reports = data.get('totalReports', 0)
            last_reported = data.get('lastReportedAt')
            
            # Determine severity based on abuse confidence and reports
            if abuse_confidence >= 0.75 or total_reports >= 50:
                severity = 'high'
            elif abuse_confidence >= 0.25 or total_reports >= 10:
                severity = 'medium'
            else:
                severity = 'low'
            
            # Create tags
            tags = []
            if total_reports > 0:
                tags.append(f"reports:{total_reports}")
            if abuse_confidence > 0:
                tags.append(f"abuse_confidence:{int(abuse_confidence * 100)}%")
            
            # Parse dates
            created = datetime.fromisoformat(last_reported) if last_reported else datetime.utcnow()
            expires_at = created + timedelta(hours=6)  # 6 hour TTL
            
            return ThreatIntelIndicator(
                indicator=data.get('ipAddress'),
                indicator_type=indicator_type,
                source=ThreatIntelSource.ABUSEIPDB,
                confidence=abuse_confidence,
                severity=severity,
                first_seen=created,
                last_seen=created,
                tags=tags,
                description=f"AbuseIPDB data: {total_reports} reports, {abuse_confidence * 100}% abuse confidence",
                raw_data=data,
                expires_at=expires_at,
                cache_key=self._generate_cache_key(ThreatIntelSource.ABUSEIPDB, indicator_type, data.get('ipAddress'))
            )
        except Exception as e:
            logger.error(f"Error parsing AbuseIPDB response: {e}")
            return None
    
    def _parse_virustotal_response(self, data: Dict[str, Any], indicator: str, 
                                 indicator_type: IndicatorType) -> Optional[ThreatIntelIndicator]:
        """Parse VirusTotal response"""
        try:
            # Extract scan results
            positives = data.get('positives', 0)
            total = data.get('total', 0)
            scan_date = data.get('scan_date')
            
            # Calculate confidence based on detection ratio
            confidence = positives / total if total > 0 else 0.0
            
            # Determine severity
            if confidence >= 0.5:
                severity = 'high'
            elif confidence >= 0.1:
                severity = 'medium'
            else:
                severity = 'low'
            
            # Create tags
            tags = []
            if positives > 0:
                tags.append(f"detections:{positives}/{total}")
            
            # Extract scan results for additional context
            scans = data.get('scans', {})
            detected_engines = [engine for engine, result in scans.items() if result.get('detected')]
            if detected_engines:
                tags.append(f"engines:{','.join(detected_engines[:5])}")  # Limit to first 5
            
            # Parse dates
            created = datetime.fromisoformat(scan_date) if scan_date else datetime.utcnow()
            expires_at = created + timedelta(hours=24)  # 24 hour TTL
            
            return ThreatIntelIndicator(
                indicator=indicator,
                indicator_type=indicator_type,
                source=ThreatIntelSource.VIRUSTOTAL,
                confidence=confidence,
                severity=severity,
                first_seen=created,
                last_seen=created,
                tags=tags,
                description=f"VirusTotal: {positives}/{total} engines detected threats",
                raw_data=data,
                expires_at=expires_at,
                cache_key=self._generate_cache_key(ThreatIntelSource.VIRUSTOTAL, indicator_type, indicator)
            )
        except Exception as e:
            logger.error(f"Error parsing VirusTotal response: {e}")
            return None
    
    def cleanup_expired_cache(self) -> int:
        """Clean up expired cache entries"""
        if not self.redis_client:
            return 0
        
        try:
            # Get all cache keys
            keys = self.redis_client.keys(f"{self.cache_prefix}*")
            cleaned = 0
            
            for key in keys:
                try:
                    cached_data = self.redis_client.get(key)
                    if cached_data:
                        data = json.loads(cached_data.decode('utf-8'))
                        expires_at = datetime.fromisoformat(data['expires_at'])
                        
                        if datetime.utcnow() >= expires_at:
                            self.redis_client.delete(key)
                            cleaned += 1
                except Exception:
                    # Delete corrupted entries
                    self.redis_client.delete(key)
                    cleaned += 1
            
            self.stats['last_cleanup'] = datetime.utcnow().isoformat()
            logger.info(f"Cleaned up {cleaned} expired cache entries")
            
            return cleaned
            
        except Exception as e:
            logger.error(f"Error cleaning up cache: {e}")
            return 0
    
    def get_cache_statistics(self) -> Dict[str, Any]:
        """Get cache statistics"""
        with self._lock:
            stats = self.stats.copy()
            
            # Calculate hit rate
            total_requests = stats['cache_hits'] + stats['cache_misses']
            stats['hit_rate_percent'] = (stats['cache_hits'] / total_requests * 100) if total_requests > 0 else 0
            
            # Get cache size
            if self.redis_client:
                try:
                    cache_keys = self.redis_client.keys(f"{self.cache_prefix}*")
                    stats['cache_size'] = len(cache_keys)
                except Exception:
                    stats['cache_size'] = 0
            else:
                stats['cache_size'] = 0
            
            # Add source statistics
            stats['sources'] = {}
            for source, config in self.sources.items():
                stats['sources'][source.value] = {
                    'enabled': config.enabled,
                    'rate_limit': config.rate_limit_per_minute,
                    'cache_ttl_hours': config.cache_ttl_hours
                }
            
            # Add queue statistics
            stats['queue_size'] = len(self.request_queue)
            
            return stats
    
    def clear_cache(self, source: ThreatIntelSource = None) -> int:
        """Clear cache for specific source or all sources"""
        if not self.redis_client:
            return 0
        
        try:
            if source:
                # Clear specific source
                pattern = f"{self.cache_prefix}*"
                keys = self.redis_client.keys(pattern)
                cleared = 0
                
                for key in keys:
                    try:
                        cached_data = self.redis_client.get(key)
                        if cached_data:
                            data = json.loads(cached_data.decode('utf-8'))
                            if data.get('source') == source.value:
                                self.redis_client.delete(key)
                                cleared += 1
                    except Exception:
                        continue
            else:
                # Clear all threat intel cache
                keys = self.redis_client.keys(f"{self.cache_prefix}*")
                cleared = len(keys)
                if keys:
                    self.redis_client.delete(*keys)
            
            logger.info(f"Cleared {cleared} cache entries for {source.value if source else 'all sources'}")
            return cleared
            
        except Exception as e:
            logger.error(f"Error clearing cache: {e}")
            return 0

# Global threat intelligence cache instance
threat_intel_cache = ThreatIntelCache()

# Flask integration
def init_threat_intel_cache(app):
    """Initialize threat intelligence cache with Flask app"""
    threat_intel_cache.init_app(app)
    
    # Add threat intelligence cache endpoints
    @app.route('/api/threat-intel/indicator', methods=['GET'])
    def get_indicator():
        """Get threat intelligence for an indicator"""
        try:
            indicator = request.args.get('indicator')
            indicator_type_str = request.args.get('type', 'ip')
            sources_str = request.args.get('sources', '')
            
            if not indicator:
                return jsonify({
                    'success': False,
                    'error': 'indicator parameter is required'
                }), 400
            
            # Parse indicator type
            try:
                indicator_type = IndicatorType(indicator_type_str)
            except ValueError:
                return jsonify({
                    'success': False,
                    'error': f'Invalid indicator type: {indicator_type_str}'
                }), 400
            
            # Parse sources
            sources = None
            if sources_str:
                try:
                    sources = [ThreatIntelSource(s.strip()) for s in sources_str.split(',')]
                except ValueError:
                    return jsonify({
                        'success': False,
                        'error': 'Invalid source format'
                    }), 400
            
            # Get indicator data
            indicators = threat_intel_cache.get_indicator(indicator, indicator_type, sources)
            
            return jsonify({
                'success': True,
                'data': [asdict(ind) for ind in indicators]
            })
            
        except Exception as e:
            return jsonify({
                'success': False,
                'error': str(e)
            }), 500
    
    @app.route('/api/threat-intel/batch', methods=['POST'])
    def get_indicators_batch():
        """Get threat intelligence for multiple indicators"""
        try:
            data = request.get_json()
            indicators_data = data.get('indicators', [])
            sources_str = data.get('sources', '')
            
            if not indicators_data:
                return jsonify({
                    'success': False,
                    'error': 'indicators parameter is required'
                }), 400
            
            # Parse indicators
            indicators = []
            for item in indicators_data:
                if isinstance(item, str):
                    # Default to IP type
                    indicators.append((item, IndicatorType.IP_ADDRESS))
                elif isinstance(item, dict):
                    indicator = item.get('indicator')
                    indicator_type_str = item.get('type', 'ip')
                    
                    if not indicator:
                        continue
                    
                    try:
                        indicator_type = IndicatorType(indicator_type_str)
                        indicators.append((indicator, indicator_type))
                    except ValueError:
                        continue
            
            # Parse sources
            sources = None
            if sources_str:
                try:
                    sources = [ThreatIntelSource(s.strip()) for s in sources_str.split(',')]
                except ValueError:
                    return jsonify({
                        'success': False,
                        'error': 'Invalid source format'
                    }), 400
            
            # Get indicators data
            results = threat_intel_cache.get_indicators_batch(indicators, sources)
            
            # Convert to serializable format
            serializable_results = {}
            for indicator, indicator_list in results.items():
                serializable_results[indicator] = [asdict(ind) for ind in indicator_list]
            
            return jsonify({
                'success': True,
                'data': serializable_results
            })
            
        except Exception as e:
            return jsonify({
                'success': False,
                'error': str(e)
            }), 500
    
    @app.route('/api/threat-intel/stats', methods=['GET'])
    def get_threat_intel_stats():
        """Get threat intelligence cache statistics"""
        return jsonify({
            'success': True,
            'data': threat_intel_cache.get_cache_statistics()
        })
    
    @app.route('/api/threat-intel/cleanup', methods=['POST'])
    def cleanup_threat_intel_cache():
        """Clean up expired cache entries"""
        try:
            cleaned = threat_intel_cache.cleanup_expired_cache()
            
            return jsonify({
                'success': True,
                'message': f'Cleaned up {cleaned} expired entries',
                'data': {'cleaned_count': cleaned}
            })
            
        except Exception as e:
            return jsonify({
                'success': False,
                'error': str(e)
            }), 500
    
    @app.route('/api/threat-intel/clear', methods=['POST'])
    def clear_threat_intel_cache():
        """Clear threat intelligence cache"""
        try:
            data = request.get_json() or {}
            source_str = data.get('source')
            
            source = None
            if source_str:
                try:
                    source = ThreatIntelSource(source_str)
                except ValueError:
                    return jsonify({
                        'success': False,
                        'error': f'Invalid source: {source_str}'
                    }), 400
            
            cleared = threat_intel_cache.clear_cache(source)
            
            return jsonify({
                'success': True,
                'message': f'Cleared {cleared} cache entries',
                'data': {'cleared_count': cleared}
            })
            
        except Exception as e:
            return jsonify({
                'success': False,
                'error': str(e)
            }), 500
    
    logger.info("Threat intelligence cache management endpoints registered")
