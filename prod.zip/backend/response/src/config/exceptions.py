"""
Configuration Exception Classes

Custom exceptions for configuration-related errors.
"""

from typing import Any, Dict, List, Optional


class ConfigurationError(Exception):
    """
    Base exception for configuration errors.
    """
    
    def __init__(self, 
                 message: str, 
                 key: str = None, 
                 value: Any = None, 
                 context: Dict[str, Any] = None):
        """
        Initialize configuration error.
        
        Args:
            message: Error message
            key: Configuration key that caused the error
            value: Value that caused the error
            context: Additional context information
        """
        super().__init__(message)
        self.message = message
        self.key = key
        self.value = value
        self.context = context or {}
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert exception to dictionary for API responses."""
        return {
            'error': 'ConfigurationError',
            'message': self.message,
            'key': self.key,
            'value': self.value,
            'context': self.context
        }


class ValidationError(ConfigurationError):
    """
    Exception raised when configuration validation fails.
    """
    
    def __init__(self, 
                 message: str, 
                 key: str = None, 
                 value: Any = None, 
                 validation_rule: str = None,
                 context: Dict[str, Any] = None):
        """
        Initialize validation error.
        
        Args:
            message: Error message
            key: Configuration key that failed validation
            value: Value that failed validation
            validation_rule: Name of the validation rule that failed
            context: Additional context information
        """
        super().__init__(message, key, value, context)
        self.validation_rule = validation_rule
        self.context['validation_rule'] = validation_rule
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert exception to dictionary for API responses."""
        result = super().to_dict()
        result['error'] = 'ValidationError'
        return result


class RequiredConfigurationError(ConfigurationError):
    """
    Exception raised when required configuration is missing.
    """
    
    def __init__(self, 
                 message: str, 
                 key: str = None, 
                 context: Dict[str, Any] = None):
        """
        Initialize required configuration error.
        
        Args:
            message: Error message
            key: Missing configuration key
            context: Additional context information
        """
        super().__init__(message, key, None, context)
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert exception to dictionary for API responses."""
        result = super().to_dict()
        result['error'] = 'RequiredConfigurationError'
        return result


class ConfigurationParseError(ConfigurationError):
    """
    Exception raised when configuration cannot be parsed.
    """
    
    def __init__(self, 
                 message: str, 
                 key: str = None, 
                 value: Any = None, 
                 expected_type: str = None,
                 context: Dict[str, Any] = None):
        """
        Initialize parse error.
        
        Args:
            message: Error message
            key: Configuration key that failed to parse
            value: Value that failed to parse
            expected_type: Expected type for the value
            context: Additional context information
        """
        super().__init__(message, key, value, context)
        self.expected_type = expected_type
        self.context['expected_type'] = expected_type
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert exception to dictionary for API responses."""
        result = super().to_dict()
        result['error'] = 'ConfigurationParseError'
        return result


class ConfigurationProviderError(ConfigurationError):
    """
    Exception raised when configuration provider fails.
    """
    
    def __init__(self, 
                 message: str, 
                 provider_name: str = None, 
                 operation: str = None,
                 context: Dict[str, Any] = None):
        """
        Initialize provider error.
        
        Args:
            message: Error message
            provider_name: Name of the provider that failed
            operation: Operation that was being performed
            context: Additional context information
        """
        super().__init__(message, None, None, context)
        self.provider_name = provider_name
        self.operation = operation
        self.context.update({
            'provider_name': provider_name,
            'operation': operation
        })
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert exception to dictionary for API responses."""
        result = super().to_dict()
        result['error'] = 'ConfigurationProviderError'
        return result


class ConfigurationReloadError(ConfigurationError):
    """
    Exception raised when configuration reload fails.
    """
    
    def __init__(self, 
                 message: str, 
                 failed_keys: List[str] = None,
                 context: Dict[str, Any] = None):
        """
        Initialize reload error.
        
        Args:
            message: Error message
            failed_keys: List of keys that failed to reload
            context: Additional context information
        """
        super().__init__(message, None, None, context)
        self.failed_keys = failed_keys or []
        self.context['failed_keys'] = self.failed_keys
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert exception to dictionary for API responses."""
        result = super().to_dict()
        result['error'] = 'ConfigurationReloadError'
        return result


class CircularReferenceError(ConfigurationError):
    """
    Exception raised when circular reference is detected in configuration.
    """
    
    def __init__(self, 
                 message: str, 
                 key: str = None, 
                 reference_chain: List[str] = None,
                 context: Dict[str, Any] = None):
        """
        Initialize circular reference error.
        
        Args:
            message: Error message
            key: Configuration key where circular reference was detected
            reference_chain: Chain of keys that created the circular reference
            context: Additional context information
        """
        super().__init__(message, key, None, context)
        self.reference_chain = reference_chain or []
        self.context['reference_chain'] = self.reference_chain
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert exception to dictionary for API responses."""
        result = super().to_dict()
        result['error'] = 'CircularReferenceError'
        return result


class ConfigurationSecurityError(ConfigurationError):
    """
    Exception raised for security-related configuration errors.
    """
    
    def __init__(self, 
                 message: str, 
                 key: str = None, 
                 security_issue: str = None,
                 context: Dict[str, Any] = None):
        """
        Initialize security error.
        
        Args:
            message: Error message
            key: Configuration key with security issue
            security_issue: Description of the security issue
            context: Additional context information
        """
        super().__init__(message, key, None, context)
        self.security_issue = security_issue
        self.context['security_issue'] = security_issue
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert exception to dictionary for API responses."""
        result = super().to_dict()
        result['error'] = 'ConfigurationSecurityError'
        return result


class ConfigurationInitializationError(ConfigurationError):
    """
    Exception raised when configuration service fails to initialize.
    """
    
    def __init__(self, 
                 message: str, 
                 initialization_step: str = None,
                 cause: Exception = None,
                 context: Dict[str, Any] = None):
        """
        Initialize initialization error.
        
        Args:
            message: Error message
            initialization_step: Step that failed during initialization
            cause: Original exception that caused the failure
            context: Additional context information
        """
        super().__init__(message, None, None, context)
        self.initialization_step = initialization_step
        self.cause = cause
        self.context.update({
            'initialization_step': initialization_step,
            'cause': str(cause) if cause else None
        })
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert exception to dictionary for API responses."""
        result = super().to_dict()
        result['error'] = 'ConfigurationInitializationError'
        return result


class ConfigurationValidationError(ConfigurationError):
    """
    Exception raised when configuration validation fails at runtime.
    """
    
    def __init__(self, 
                 message: str, 
                 validation_errors: List[str] = None,
                 validation_warnings: List[str] = None,
                 context: Dict[str, Any] = None):
        """
        Initialize validation error.
        
        Args:
            message: Error message
            validation_errors: List of validation errors
            validation_warnings: List of validation warnings
            context: Additional context information
        """
        super().__init__(message, None, None, context)
        self.validation_errors = validation_errors or []
        self.validation_warnings = validation_warnings or []
        self.context.update({
            'validation_errors': self.validation_errors,
            'validation_warnings': self.validation_warnings
        })
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert exception to dictionary for API responses."""
        result = super().to_dict()
        result['error'] = 'ConfigurationValidationError'
        return result