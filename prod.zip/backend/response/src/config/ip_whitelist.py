"""
IP Whitelist Configuration for Threat Actor Filtering

This module provides IP whitelisting functionality to exclude known-good
services from being flagged as threat actors in the Network Topology view.
"""

import ipaddress
from typing import Tuple, Optional

# Known-good IP ranges to exclude from threat actors
# Format: { "IP or CIDR": ("Provider Name", "Category") }
IP_WHITELIST = {
    # DNS Providers
    "8.8.8.8": ("Google DNS", "dns"),
    "8.8.4.4": ("Google DNS", "dns"),
    "1.1.1.1": ("Cloudflare DNS", "dns"),
    "1.0.0.1": ("Cloudflare DNS", "dns"),
    "9.9.9.9": ("Quad9 DNS", "dns"),
    "208.67.222.222": ("OpenDNS", "dns"),
    "208.67.220.220": ("OpenDNS", "dns"),

    # Cloud Providers (CIDR ranges)
    "13.0.0.0/8": ("Microsoft Azure", "cloud"),
    "20.0.0.0/8": ("Microsoft Azure", "cloud"),
    "40.0.0.0/8": ("Microsoft Azure", "cloud"),
    "52.0.0.0/8": ("Amazon AWS", "cloud"),
    "54.0.0.0/8": ("Amazon AWS", "cloud"),
    "35.0.0.0/8": ("Google Cloud", "cloud"),
    "34.0.0.0/8": ("Google Cloud", "cloud"),

    # CDNs
    "104.16.0.0/12": ("Cloudflare CDN", "cdn"),
    "151.101.0.0/16": ("Fastly CDN", "cdn"),
    "199.232.0.0/16": ("Fastly CDN", "cdn"),
    "23.0.0.0/8": ("Akamai CDN", "cdn"),

    # Microsoft Services
    "13.107.0.0/16": ("Microsoft 365", "microsoft"),
    "204.79.197.0/24": ("Microsoft", "microsoft"),

    # Apple Services
    "17.0.0.0/8": ("Apple", "apple"),

    # NTP Servers
    "129.6.15.28": ("NIST NTP", "ntp"),
    "129.6.15.29": ("NIST NTP", "ntp"),
    "132.163.96.1": ("NIST NTP", "ntp"),
}


def is_whitelisted(ip: str) -> Tuple[bool, Optional[str], Optional[str]]:
    """
    Check if an IP address is whitelisted.

    Args:
        ip: IP address string to check

    Returns:
        Tuple of (is_whitelisted, provider_name, category)
        If not whitelisted, returns (False, None, None)
    """
    if not ip or ip in ('Unknown', 'N/A', '', '::1', '127.0.0.1'):
        return False, None, None

    try:
        ip_obj = ipaddress.ip_address(ip)
    except ValueError:
        return False, None, None

    for entry, (provider, category) in IP_WHITELIST.items():
        try:
            if '/' in entry:
                # CIDR range
                network = ipaddress.ip_network(entry, strict=False)
                if ip_obj in network:
                    return True, provider, category
            else:
                # Single IP
                if ip == entry:
                    return True, provider, category
        except ValueError:
            continue

    return False, None, None


def is_private_ip(ip: str) -> bool:
    """
    Check if an IP address is private (RFC1918) or reserved.

    Args:
        ip: IP address string to check

    Returns:
        True if the IP is private/internal, False otherwise
    """
    if not ip or ip in ('Unknown', 'N/A', '', '::1', '127.0.0.1'):
        return True  # Treat invalid as private to skip

    try:
        ip_obj = ipaddress.ip_address(ip)
        return ip_obj.is_private or ip_obj.is_loopback or ip_obj.is_reserved
    except ValueError:
        return True  # Treat invalid IPs as private to skip


def get_whitelist_summary() -> dict:
    """
    Get a summary of the whitelist configuration.

    Returns:
        Dictionary with whitelist statistics and entries by category
    """
    categories = {}
    for entry, (provider, category) in IP_WHITELIST.items():
        if category not in categories:
            categories[category] = []
        categories[category].append({
            'entry': entry,
            'provider': provider
        })

    return {
        'total_entries': len(IP_WHITELIST),
        'categories': categories
    }
