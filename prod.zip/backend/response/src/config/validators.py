"""
Configuration Validators

Collection of validation functions for configuration values.
"""

import re
import json
from typing import Any, List, Union, Dict
from urllib.parse import urlparse


def validate_aws_region(value: str) -> bool:
    """
    Validate AWS region format.
    
    Args:
        value: AWS region string
        
    Returns:
        True if valid, False otherwise
    """
    if not value or not isinstance(value, str):
        return False
    
    # AWS region pattern: us-east-1, eu-west-2, etc.
    pattern = r'^(us|eu|ap|sa|ca|me|af|il|mx)-(north|south|east|west|central)-[0-9]+$'
    return bool(re.match(pattern, value.lower()))


def validate_aws_access_key(value: str) -> bool:
    """
    Validate AWS access key format.
    
    Args:
        value: AWS access key string
        
    Returns:
        True if valid, False otherwise
    """
    if not value or not isinstance(value, str):
        return False
    
    # AWS access key pattern: 20 alphanumeric characters
    pattern = r'^[A-Z0-9]{20}$'
    return bool(re.match(pattern, value))


def validate_port(value: Union[str, int]) -> bool:
    """
    Validate port number.
    
    Args:
        value: Port number
        
    Returns:
        True if valid, False otherwise
    """
    try:
        port = int(value)
        return 1 <= port <= 65535
    except (ValueError, TypeError):
        return False


def validate_url(value: str) -> bool:
    """
    Validate URL format.
    
    Args:
        value: URL string
        
    Returns:
        True if valid, False otherwise
    """
    if not value or not isinstance(value, str):
        return False
    
    try:
        result = urlparse(value)
        return all([result.scheme, result.netloc])
    except Exception:
        return False


def validate_email(value: str) -> bool:
    """
    Validate email format.
    
    Args:
        value: Email string
        
    Returns:
        True if valid, False otherwise
    """
    if not value or not isinstance(value, str):
        return False
    
    # Basic email validation pattern
    pattern = r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'
    return bool(re.match(pattern, value))


def validate_cidr(value: str) -> bool:
    """
    Validate CIDR notation.
    
    Args:
        value: CIDR string (e.g., "192.168.1.0/24")
        
    Returns:
        True if valid, False otherwise
    """
    if not value or not isinstance(value, str):
        return False
    
    # IPv4 CIDR pattern
    ipv4_pattern = r'^(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)/(?:[0-9]|[1-2][0-9]|3[0-2])$'
    
    # IPv6 CIDR pattern (simplified)
    ipv6_pattern = r'^(?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}/(?:[0-9]|[1-9][0-9]|1[0-1][0-9]|12[0-8])$'
    
    return bool(re.match(ipv4_pattern, value) or re.match(ipv6_pattern, value))


def validate_json(value: str) -> bool:
    """
    Validate JSON format.
    
    Args:
        value: JSON string
        
    Returns:
        True if valid, False otherwise
    """
    if not value or not isinstance(value, str):
        return False
    
    try:
        json.loads(value)
        return True
    except (json.JSONDecodeError, ValueError):
        return False


def validate_ip_address(value: str) -> bool:
    """
    Validate IP address format (IPv4 or IPv6).
    
    Args:
        value: IP address string
        
    Returns:
        True if valid, False otherwise
    """
    if not value or not isinstance(value, str):
        return False
    
    # IPv4 pattern
    ipv4_pattern = r'^(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$'
    
    # IPv6 pattern (simplified)
    ipv6_pattern = r'^(?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}$'
    
    return bool(re.match(ipv4_pattern, value) or re.match(ipv6_pattern, value))


def validate_ip_address_list(value: List[str]) -> bool:
    """
    Validate list of IP addresses.
    
    Args:
        value: List of IP address strings
        
    Returns:
        True if all valid, False otherwise
    """
    if not isinstance(value, list):
        return False
    
    return all(validate_ip_address(ip) for ip in value)


def validate_domain(value: str) -> bool:
    """
    Validate domain name format.
    
    Args:
        value: Domain name string
        
    Returns:
        True if valid, False otherwise
    """
    if not value or not isinstance(value, str):
        return False
    
    # Domain name pattern
    pattern = r'^(?:[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?\.)+[a-zA-Z]{2,}$'
    return bool(re.match(pattern, value.lower()))


def validate_country_codes(value: Union[str, List[str]]) -> bool:
    """
    Validate ISO 3166-1 alpha-2 country codes.
    
    Args:
        value: Country code string or list of country codes
        
    Returns:
        True if valid, False otherwise
    """
    # List of valid ISO 3166-1 alpha-2 country codes
    valid_codes = {
        'US', 'CA', 'GB', 'DE', 'FR', 'IT', 'ES', 'NL', 'BE', 'AT', 'CH', 'DK', 'SE', 'NO', 'FI',
        'PL', 'CZ', 'SK', 'HU', 'RO', 'BG', 'GR', 'PT', 'IE', 'LU', 'EE', 'LV', 'LT', 'SI', 'HR',
        'RU', 'UA', 'BY', 'MD', 'GE', 'AM', 'AZ', 'KZ', 'KG', 'TJ', 'TM', 'UZ', 'CN', 'JP', 'KR',
        'IN', 'PK', 'BD', 'LK', 'NP', 'BT', 'MV', 'TH', 'VN', 'LA', 'KH', 'MM', 'PH', 'ID', 'MY',
        'SG', 'BN', 'TL', 'AU', 'NZ', 'FJ', 'PG', 'SB', 'VU', 'NC', 'PF', 'AS', 'GU', 'MP', 'PW',
        'FM', 'KI', 'NR', 'MH', 'TV', 'TO', 'WS', 'NU', 'CK', 'AX', 'FO', 'GL', 'IS', 'SJ', 'UM',
        'VA', 'SM', 'AD', 'MC', 'LI', 'GG', 'JE', 'IM', 'AX', 'FO', 'GL', 'IS', 'SJ'
    }
    
    if isinstance(value, str):
        value = value.split(',')
    
    if not isinstance(value, list):
        return False
    
    # Clean and validate each code
    for code in value:
        if not isinstance(code, str):
            return False
        clean_code = code.strip().upper()
        if clean_code not in valid_codes:
            return False
    
    return True


def validate_database_url(value: str) -> bool:
    """
    Validate database URL format.
    
    Args:
        value: Database URL string
        
    Returns:
        True if valid, False otherwise
    """
    if not value or not isinstance(value, str):
        return False
    
    try:
        result = urlparse(value)
        valid_schemes = ['postgresql', 'mysql', 'sqlite', 'oracle', 'mssql']
        return result.scheme in valid_schemes and all([result.scheme, result.netloc])
    except Exception:
        return False


def validate_redis_url(value: str) -> bool:
    """
    Validate Redis URL format.
    
    Args:
        value: Redis URL string
        
    Returns:
        True if valid, False otherwise
    """
    if not value or not isinstance(value, str):
        return False
    
    try:
        result = urlparse(value)
        return result.scheme in ['redis', 'rediss'] and result.netloc
    except Exception:
        return False


def validate_log_level(value: str) -> bool:
    """
    Validate logging level.
    
    Args:
        value: Log level string
        
    Returns:
        True if valid, False otherwise
    """
    if not value or not isinstance(value, str):
        return False
    
    valid_levels = ['DEBUG', 'INFO', 'WARNING', 'ERROR', 'CRITICAL']
    return value.upper() in valid_levels


def validate_time_range(value: Union[str, int]) -> bool:
    """
    Validate time range value.
    
    Args:
        value: Time range in seconds or interval string
        
    Returns:
        True if valid, False otherwise
    """
    try:
        # If integer, validate range (1 second to 30 days)
        if isinstance(value, int):
            return 1 <= value <= 2592000
        
        # If string, try to parse interval format (e.g., "1h", "30m", "7d")
        if isinstance(value, str):
            pattern = r'^(\d+)([smhdw])$'
            match = re.match(pattern, value.lower())
            if not match:
                return False
            
            num, unit = match.groups()
            num = int(num)
            
            # Convert to seconds and validate range
            multipliers = {'s': 1, 'm': 60, 'h': 3600, 'd': 86400, 'w': 604800}
            seconds = num * multipliers[unit]
            return 1 <= seconds <= 2592000
        
        return False
    except (ValueError, TypeError):
        return False


def validate_file_path(value: str) -> bool:
    """
    Validate file path format.
    
    Args:
        value: File path string
        
    Returns:
        True if valid format, False otherwise
    """
    if not value or not isinstance(value, str):
        return False
    
    # Basic path validation - check for dangerous patterns
    dangerous_patterns = [
        r'\.\./',  # Directory traversal
        r'^/',     # Absolute path (may be allowed in some cases)
        r'^\.\./', # Starting with parent directory
    ]
    
    for pattern in dangerous_patterns:
        if re.search(pattern, value):
            return False
    
    # Check for valid characters
    valid_chars = r'^[a-zA-Z0-9_\-/\.]+$'
    return bool(re.match(valid_chars, value))


def validate_json_schema(value: str) -> bool:
    """
    Validate JSON schema format.
    
    Args:
        value: JSON schema string
        
    Returns:
        True if valid schema, False otherwise
    """
    if not validate_json(value):
        return False
    
    try:
        schema = json.loads(value)
        
        # Basic JSON Schema validation
        required_keys = ['$schema', 'type']
        if not all(key in schema for key in required_keys):
            return False
        
        # Validate schema version
        if not isinstance(schema.get('$schema'), str):
            return False
        
        # Validate type
        valid_types = ['object', 'array', 'string', 'number', 'integer', 'boolean', 'null']
        if schema.get('type') not in valid_types:
            return False
        
        return True
    except (json.JSONDecodeError, ValueError, TypeError):
        return False


def validate_keycloak_realm(value: str) -> bool:
    """
    Validate Keycloak realm name format.
    
    Args:
        value: Realm name string
        
    Returns:
        True if valid, False otherwise
    """
    if not value or not isinstance(value, str):
        return False
    
    # Keycloak realm naming rules:
    # - Only letters, numbers, hyphens, and underscores
    # - Must start with a letter
    # - Cannot be longer than 60 characters
    pattern = r'^[a-zA-Z][a-zA-Z0-9_-]{0,59}$'
    return bool(re.match(pattern, value))


def validate_cron_expression(value: str) -> bool:
    """
    Validate cron expression format.
    
    Args:
        value: Cron expression string
        
    Returns:
        True if valid, False otherwise
    """
    if not value or not isinstance(value, str):
        return False
    
    # Basic cron validation (5 or 6 fields)
    parts = value.strip().split()
    if len(parts) not in [5, 6]:
        return False
    
    # Validate each field (basic validation)
    # This is a simplified validation - full cron validation is more complex
    for i, part in enumerate(parts[:5]):
        if not re.match(r'^(\*|([0-9]|1[0-9]|2[0-9]|3[0-9]|4[0-9]|5[0-9])|([0-9]|1[0-9]|2[0-9]|3[0-9]|4[0-9]|5[0-9])-([0-9]|1[0-9]|2[0-9]|3[0-9]|4[0-9]|5[0-9])|(\*/([0-9]|1[0-9]|2[0-9]|3[0-9]|4[0-9]|5[0-9])))$', part):
            return False
    
    return True