"""
Configuration Package

Centralized configuration management for the Athena backend.

This package provides:
- Environment-based configuration with validation
- Type-safe configuration access
- Configuration caching and monitoring
- Comprehensive error handling
- Section-based configuration organization
"""

from .base_config import (
    ConfigurationProvider,
    ConfigurationManager,
    ConfigValidationLevel
)

from .environment_config import EnvironmentConfigurationProvider

from .configuration_service import (
    ConfigurationService,
    AthenaConfig,
    MonitoringConfig,
    SecurityConfig,
    DatabasePoolConfig,
    CacheConfig,
    LoggingConfig,
    get_configuration_service,
    set_configuration_service,
    initialize_configuration
)

from .validators import (
    validate_aws_region,
    validate_aws_access_key,
    validate_port,
    validate_url,
    validate_email,
    validate_cidr,
    validate_json,
    validate_ip_address,
    validate_ip_address_list,
    validate_domain,
    validate_country_codes,
    validate_database_url,
    validate_redis_url,
    validate_log_level,
    validate_time_range,
    validate_file_path,
    validate_json_schema,
    validate_keycloak_realm,
    validate_cron_expression
)

from .exceptions import (
    ConfigurationError,
    ValidationError,
    RequiredConfigurationError,
    ConfigurationParseError,
    ConfigurationProviderError,
    ConfigurationReloadError,
    CircularReferenceError,
    ConfigurationSecurityError,
    ConfigurationInitializationError,
    ConfigurationValidationError
)

__version__ = "1.0.0"

__all__ = [
    # Core classes
    'ConfigurationProvider',
    'ConfigurationManager',
    'ConfigurationService',
    'EnvironmentConfigurationProvider',
    
    # Configuration classes
    'AthenaConfig',
    'MonitoringConfig',
    'SecurityConfig',
    'DatabasePoolConfig',
    'CacheConfig',
    'LoggingConfig',
    
    # Enums and constants
    'ConfigValidationLevel',
    
    # Factory functions
    'get_configuration_service',
    'set_configuration_service',
    'initialize_configuration',
    
    # Validators
    'validate_aws_region',
    'validate_aws_access_key',
    'validate_port',
    'validate_url',
    'validate_email',
    'validate_cidr',
    'validate_json',
    'validate_ip_address',
    'validate_ip_address_list',
    'validate_domain',
    'validate_country_codes',
    'validate_database_url',
    'validate_redis_url',
    'validate_log_level',
    'validate_time_range',
    'validate_file_path',
    'validate_json_schema',
    'validate_keycloak_realm',
    'validate_cron_expression',
    
    # Exceptions
    'ConfigurationError',
    'ValidationError',
    'RequiredConfigurationError',
    'ConfigurationParseError',
    'ConfigurationProviderError',
    'ConfigurationReloadError',
    'CircularReferenceError',
    'ConfigurationSecurityError',
    'ConfigurationInitializationError',
    'ConfigurationValidationError'
]