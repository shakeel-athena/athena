"""
Centralized Configuration Service

Provides a unified interface for all configuration needs in the Athena backend.
Combines environment-based configuration with validation, caching, and type safety.
"""

import logging
from typing import Any, Dict, List, Optional, Type
from dataclasses import dataclass, field
from contextlib import asynccontextmanager
import asyncio
from datetime import datetime, timedelta

import sys
import os
# Add current directory to path for direct imports
current_dir = os.path.dirname(os.path.abspath(__file__))
if current_dir not in sys.path:
    sys.path.insert(0, current_dir)

from base_config import ConfigurationProvider, ConfigValidationLevel
from environment_config import EnvironmentConfigurationProvider
from exceptions import (
    ConfigurationError, ValidationError, RequiredConfigurationError
)


@dataclass
class MonitoringConfig:
    """Configuration for monitoring and metrics."""
    enabled: bool = True
    metrics_endpoint: str = "/metrics"
    health_check_interval: int = 60
    performance_tracking: bool = True


@dataclass
class SecurityConfig:
    """Configuration for security settings."""
    secret_key: str = ""
    jwt_expiry_hours: int = 24
    session_timeout: int = 3600
    max_login_attempts: int = 5
    password_min_length: int = 8
    require_2fa: bool = False


@dataclass
class DatabasePoolConfig:
    """Database connection pool configuration."""
    pool_size: int = 10
    max_overflow: int = 20
    pool_timeout: int = 30
    pool_recycle: int = 3600
    connect_timeout: int = 10
    statement_timeout: int = 30000


@dataclass
class CacheConfig:
    """Cache configuration."""
    enabled: bool = True
    default_ttl: int = 300
    max_keys: int = 10000


@dataclass
class LoggingConfig:
    """Logging configuration."""
    level: str = "INFO"
    format: str = "%(asctime)s - %(name)s - %(levelname)s - %(message)s"
    file_path: Optional[str] = None
    max_file_size: int = 10485760  # 10MB
    backup_count: int = 5
    structured: bool = False


@dataclass
class AthenaConfig:
    """Complete Athena application configuration."""
    
    # Core application settings
    environment: str = "production"
    debug: bool = False
    port: int = 5000
    secret_key: str = ""
    cors_origins: List[str] = field(default_factory=lambda: ["*"])
    
    # AWS configuration
    aws_access_key_id: str = ""
    aws_secret_access_key: str = ""
    aws_session_token: str = ""
    aws_region: str = "us-east-2"
    aws_profile: str = ""
    
    # Database configuration (loaded from environment - no defaults for security)
    postgres_host: str = ""
    postgres_port: int = 5432
    postgres_db: str = ""
    postgres_user: str = ""
    postgres_password: str = ""
    postgres_pool: DatabasePoolConfig = field(default_factory=DatabasePoolConfig)
    
    # Keycloak configuration
    keycloak_url: str = ""
    keycloak_realm: str = "athena"
    keycloak_client_id: str = ""
    keycloak_client_secret: str = ""
    keycloak_redirect_uri: str = ""
    
    # Firewall configuration
    firewall_enabled: bool = True
    firewall_rule_group: str = "allow-ingress"
    firewall_cache_ttl: int = 300
    
    # WAF configuration
    waf_enabled: bool = True
    waf_web_acl: str = ""
    waf_scope: str = "REGIONAL"
    waf_cache_ttl: int = 600
    
    # Alerts configuration
    wazuh_host: str = "localhost"
    wazuh_port: int = 55000
    wazuh_username: str = ""
    wazuh_password: str = ""
    wazuh_verify_ssl: bool = True
    suricata_log_file: str = "/var/log/suricata/eve.json"
    default_alerts_limit: int = 100
    default_time_range_hours: int = 24

    # Cache configuration
    redis_url: str = ""
    cache: CacheConfig = field(default_factory=CacheConfig)
    
    # Logging configuration
    logging: LoggingConfig = field(default_factory=LoggingConfig)
    
    # Security configuration
    security: SecurityConfig = field(default_factory=SecurityConfig)
    
    # Monitoring configuration
    monitoring: MonitoringConfig = field(default_factory=MonitoringConfig)
    
    # Configuration metadata
    last_updated: datetime = field(default_factory=datetime.now)
    validation_errors: List[str] = field(default_factory=list)
    validation_warnings: List[str] = field(default_factory=list)


class ConfigurationService:
    """
    Centralized configuration service for the Athena backend.
    
    Provides unified access to all configuration with validation,
    caching, and comprehensive section management.
    """
    
    def __init__(self, 
                 provider: ConfigurationProvider = None,
                 validation_level: ConfigValidationLevel = ConfigValidationLevel.ERROR):
        """
        Initialize configuration service.
        
        Args:
            provider: Configuration provider (defaults to environment provider)
            validation_level: Level of validation to perform
        """
        self._provider = provider or EnvironmentConfigurationProvider(
            validation_level=validation_level
        )
        self._validation_level = validation_level
        self._config = AthenaConfig()
        self._logger = logging.getLogger(f"{__name__}.{self.__class__.__name__}")
        self._lock = asyncio.Lock()
        self._initialized = False
        
        # Subscribe to configuration changes if provider supports it
        if hasattr(self._provider, 'subscribe') and callable(getattr(self._provider, 'subscribe')):
            self._provider.subscribe(self._on_config_change)
    
    async def initialize(self) -> None:
        """Initialize configuration service."""
        async with self._lock:
            if self._initialized:
                return
            
            try:
                self._logger.info("Initializing configuration service...")
                await self._load_configuration()
                await self._validate_configuration()
                self._initialized = True
                self._logger.info("Configuration service initialized successfully")
            except Exception as e:
                self._logger.error(f"Failed to initialize configuration service: {str(e)}")
                raise ConfigurationError(f"Configuration initialization failed: {str(e)}")
    
    async def _load_configuration(self) -> None:
        """Load configuration from provider."""
        # Core application configuration
        self._config.environment = self._provider.get_string(
            'ENVIRONMENT', default='production', 
            allowed_values=['development', 'staging', 'production']
        )
        self._config.debug = self._provider.get_bool('DEBUG', default=False)
        self._config.port = self._provider.get_int('PORT', default=5000, min_val=1, max_val=65535)
        self._config.secret_key = self._provider.get_string('SECRET_KEY', min_length=32, required=True)
        self._config.cors_origins = self._provider.get_list('CORS_ORIGINS', default=['*'])
        
        # AWS configuration
        self._config.aws_access_key_id = self._provider.get_string('AWS_ACCESS_KEY_ID')
        self._config.aws_secret_access_key = self._provider.get_string('AWS_SECRET_ACCESS_KEY')
        self._config.aws_session_token = self._provider.get_string('AWS_SESSION_TOKEN')
        self._config.aws_region = self._provider.get_string(
            'AWS_REGION', default='us-east-2', validator='aws_region'
        )
        self._config.aws_profile = self._provider.get_string('AWS_PROFILE')
        
        # Database configuration
        self._config.postgres_host = self._provider.get_string('POSTGRES_HOST', default='localhost')
        self._config.postgres_port = self._provider.get_int('POSTGRES_PORT', default=5432, min_val=1, max_val=65535)
        self._config.postgres_db = self._provider.get_string('POSTGRES_DB', default='athena_db')
        self._config.postgres_user = self._provider.get_string('POSTGRES_USER', default='athena_user')
        self._config.postgres_password = self._provider.get_string('POSTGRES_PASSWORD', default='athena_password')
        
        # Database pool configuration
        self._config.postgres_pool.pool_size = self._provider.get_int('DB_POOL_SIZE', default=10, min_val=1, max_val=100)
        self._config.postgres_pool.max_overflow = self._provider.get_int('DB_MAX_OVERFLOW', default=20, min_val=0, max_val=100)
        self._config.postgres_pool.pool_timeout = self._provider.get_int('DB_POOL_TIMEOUT', default=30, min_val=1, max_val=300)
        self._config.postgres_pool.pool_recycle = self._provider.get_int('DB_POOL_RECYCLE', default=3600, min_val=300)
        self._config.postgres_pool.connect_timeout = self._provider.get_int('DB_CONNECT_TIMEOUT', default=10, min_val=1, max_val=60)
        self._config.postgres_pool.statement_timeout = self._provider.get_int('DB_STATEMENT_TIMEOUT', default=30000, min_val=1000)
        
        # Keycloak configuration
        self._config.keycloak_url = self._provider.get_string('KEYCLOAK_URL', validator='url')
        self._config.keycloak_realm = self._provider.get_string('KEYCLOAK_REALM', default='athena')
        self._config.keycloak_client_id = self._provider.get_string('KEYCLOAK_CLIENT_ID')
        self._config.keycloak_client_secret = self._provider.get_string('KEYCLOAK_CLIENT_SECRET')
        self._config.keycloak_redirect_uri = self._provider.get_string('KEYCLOAK_REDIRECT_URI')
        
        # Firewall configuration
        self._config.firewall_enabled = self._provider.get_bool('FIREWALL_ENABLED', default=True)
        self._config.firewall_rule_group = self._provider.get_string('FIREWALL_RULE_GROUP', default='allow-ingress')
        self._config.firewall_cache_ttl = self._provider.get_int('FIREWALL_CACHE_TTL', default=300, min_val=60)
        
        # WAF configuration
        self._config.waf_enabled = self._provider.get_bool('WAF_ENABLED', default=True)
        self._config.waf_web_acl = self._provider.get_string('WAF_WEB_ACL')
        self._config.waf_scope = self._provider.get_string('AWS_SCOPE', default='REGIONAL', allowed_values=['REGIONAL', 'CLOUDFRONT'])
        self._config.waf_cache_ttl = self._provider.get_int('WAF_CACHE_TTL', default=600, min_val=60)
        
        # Alerts configuration
        self._config.wazuh_host = self._provider.get_string('WAZUH_HOST', default='localhost')
        self._config.wazuh_port = self._provider.get_int('WAZUH_PORT', default=55000, min_val=1, max_val=65535)
        self._config.wazuh_username = self._provider.get_string('WAZUH_USERNAME')
        self._config.wazuh_password = self._provider.get_string('WAZUH_PASSWORD')
        self._config.wazuh_verify_ssl = self._provider.get_bool('WAZUH_VERIFY_SSL', default=True)
        self._config.suricata_log_file = self._provider.get_string('SURICATA_LOG_FILE', default='/var/log/suricata/eve.json')
        self._config.default_alerts_limit = self._provider.get_int('DEFAULT_ALERTS_LIMIT', default=100, min_val=1, max_val=1000)
        self._config.default_time_range_hours = self._provider.get_int('DEFAULT_TIME_RANGE_HOURS', default=24, min_val=1, max_val=720)

        # Cache configuration
        self._config.redis_url = self._provider.get_string('REDIS_URL')
        self._config.cache.enabled = self._provider.get_bool('CACHE_ENABLED', default=True)
        self._config.cache.default_ttl = self._provider.get_int('CACHE_DEFAULT_TTL', default=300, min_val=60)
        self._config.cache.max_keys = self._provider.get_int('CACHE_MAX_KEYS', default=10000, min_val=100)
        
        # Logging configuration
        self._config.logging.level = self._provider.get_string('LOG_LEVEL', default='INFO', allowed_values=[
            'DEBUG', 'INFO', 'WARNING', 'ERROR', 'CRITICAL'
        ])
        self._config.logging.format = self._provider.get_string(
            'LOG_FORMAT', 
            default='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
        )
        self._config.logging.file_path = self._provider.get_string('LOG_FILE_PATH')
        self._config.logging.max_file_size = self._provider.get_int('LOG_MAX_FILE_SIZE', default=10485760, min_val=1024)
        self._config.logging.backup_count = self._provider.get_int('LOG_BACKUP_COUNT', default=5, min_val=1, max_val=20)
        self._config.logging.structured = self._provider.get_bool('LOG_STRUCTURED', default=False)
        
        # Security configuration
        self._config.security.secret_key = self._provider.get_string('SECRET_KEY', min_length=32, required=True)
        self._config.security.jwt_expiry_hours = self._provider.get_int('JWT_EXPIRY_HOURS', default=24, min_val=1, max_val=168)
        self._config.security.session_timeout = self._provider.get_int('SESSION_TIMEOUT', default=3600, min_val=300)
        self._config.security.max_login_attempts = self._provider.get_int('MAX_LOGIN_ATTEMPTS', default=5, min_val=1, max_val=10)
        self._config.security.password_min_length = self._provider.get_int('PASSWORD_MIN_LENGTH', default=8, min_val=6, max_val=128)
        self._config.security.require_2fa = self._provider.get_bool('REQUIRE_2FA', default=False)
        
        # Monitoring configuration
        self._config.monitoring.enabled = self._provider.get_bool('MONITORING_ENABLED', default=True)
        self._config.monitoring.metrics_endpoint = self._provider.get_string('METRICS_ENDPOINT', default='/metrics')
        self._config.monitoring.health_check_interval = self._provider.get_int('HEALTH_CHECK_INTERVAL', default=60, min_val=10)
        self._config.monitoring.performance_tracking = self._provider.get_bool('PERFORMANCE_TRACKING', default=True)
        
        self._config.last_updated = datetime.now()
    
    async def _validate_configuration(self) -> None:
        """Validate the loaded configuration."""
        self._config.validation_errors.clear()
        self._config.validation_warnings.clear()
        
        # Validate required configurations
        if not self._config.secret_key:
            self._config.validation_errors.append("SECRET_KEY is required")
        
        if not self._config.keycloak_url:
            self._config.validation_errors.append("KEYCLOAK_URL is required for authentication")
        
        # Validate AWS credential consistency
        access_key = self._config.aws_access_key_id
        secret_key = self._config.aws_secret_access_key
        session_token = self._config.aws_session_token
        
        if access_key and not secret_key:
            self._config.validation_errors.append("AWS_SECRET_ACCESS_KEY required when AWS_ACCESS_KEY_ID is set")
        
        if secret_key and not access_key:
            self._config.validation_errors.append("AWS_ACCESS_KEY_ID required when AWS_SECRET_ACCESS_KEY is set")
        
        if session_token and not (access_key and secret_key):
            self._config.validation_errors.append("AWS_ACCESS_KEY_ID and AWS_SECRET_ACCESS_KEY required when using session token")
        
        # Validate database configuration
        if not self._config.postgres_host:
            self._config.validation_errors.append("POSTGRES_HOST is required")
        
        if self._config.postgres_pool.pool_size <= 0:
            self._config.validation_errors.append("Database pool size must be positive")
        
        if self._config.postgres_pool.max_overflow < 0:
            self._config.validation_errors.append("Database pool max overflow cannot be negative")
        
        # Add warnings for optional but recommended configurations
        if not self._config.waf_web_acl:
            self._config.validation_warnings.append("WAF_WEB_ACL not configured - WAF features will be limited")
        
        if not self._config.redis_url:
            self._config.validation_warnings.append("REDIS_URL not configured - caching will be disabled")
        
        # Log validation results
        if self._config.validation_errors:
            self._logger.error(f"Configuration validation errors: {self._config.validation_errors}")
        
        if self._config.validation_warnings:
            self._logger.warning(f"Configuration validation warnings: {self._config.validation_warnings}")
    
    def _on_config_change(self, key: str, old_value: Any, new_value: Any) -> None:
        """Handle configuration changes."""
        self._logger.info(f"Configuration changed: {key} = {old_value} -> {new_value}")
        # Mark configuration as needing reload
        self._initialized = False
    
    @property
    def config(self) -> AthenaConfig:
        """Get current configuration."""
        return self._config
    
    def get_section(self, section: str) -> Dict[str, Any]:
        """Get a specific configuration section."""
        section_map = {
            'aws': {
                'access_key_id': self._config.aws_access_key_id,
                'secret_access_key': self._config.aws_secret_access_key,
                'session_token': self._config.aws_session_token,
                'region': self._config.aws_region,
                'profile': self._config.aws_profile,
            },
            'database': {
                'host': self._config.postgres_host,
                'port': self._config.postgres_port,
                'database': self._config.postgres_db,
                'user': self._config.postgres_user,
                'password': self._config.postgres_password,
                'pool': self._config.postgres_pool,
            },
            'keycloak': {
                'url': self._config.keycloak_url,
                'realm': self._config.keycloak_realm,
                'client_id': self._config.keycloak_client_id,
                'client_secret': self._config.keycloak_client_secret,
                'redirect_uri': self._config.keycloak_redirect_uri,
            },
            'firewall': {
                'enabled': self._config.firewall_enabled,
                'rule_group': self._config.firewall_rule_group,
                'cache_ttl': self._config.firewall_cache_ttl,
            },
            'waf': {
                'enabled': self._config.waf_enabled,
                'web_acl': self._config.waf_web_acl,
                'scope': self._config.waf_scope,
                'cache_ttl': self._config.waf_cache_ttl,
            },
            'alerts': {
                'wazuh_host': self._config.wazuh_host,
                'wazuh_port': self._config.wazuh_port,
                'wazuh_username': self._config.wazuh_username,
                'wazuh_password': self._config.wazuh_password,
                'wazuh_verify_ssl': self._config.wazuh_verify_ssl,
                'suricata_log_file': self._config.suricata_log_file,
                'default_limit': self._config.default_alerts_limit,
                'default_time_range_hours': self._config.default_time_range_hours,
                'use_synthetic_data': self._config.use_synthetic_data,
            },
            'cache': {
                'redis_url': self._config.redis_url,
                **self._config.cache.__dict__,
            },
            'logging': self._config.logging.__dict__,
            'security': self._config.security.__dict__,
            'monitoring': self._config.monitoring.__dict__,
            'app': {
                'environment': self._config.environment,
                'debug': self._config.debug,
                'port': self._config.port,
                'secret_key': self._config.secret_key,
                'cors_origins': self._config.cors_origins,
            },
        }
        
        return section_map.get(section, {})
    
    async def reload(self) -> None:
        """Reload configuration from provider."""
        self._logger.info("Reloading configuration...")
        self._initialized = False
        
        # Clear provider cache if available
        if hasattr(self._provider, 'clear_cache'):
            self._provider.clear_cache()
        
        await self.initialize()
    
    def is_healthy(self) -> bool:
        """Check if configuration service is healthy."""
        return self._initialized and len(self._config.validation_errors) == 0
    
    def get_health_status(self) -> Dict[str, Any]:
        """Get health status of configuration service."""
        return {
            'initialized': self._initialized,
            'healthy': self.is_healthy(),
            'validation_errors': self._config.validation_errors,
            'validation_warnings': self._config.validation_warnings,
            'last_updated': self._config.last_updated.isoformat(),
            'provider_stats': getattr(self._provider, 'get_cache_stats', lambda: {})()
        }
    
    @asynccontextmanager
    async def configuration_context(self, operation: str):
        """Context manager for configuration operations."""
        start_time = datetime.now()
        try:
            yield self._config
            duration = (datetime.now() - start_time).total_seconds()
            self._logger.debug(f"Configuration operation '{operation}' completed in {duration:.3f}s")
        except Exception as e:
            duration = (datetime.now() - start_time).total_seconds()
            self._logger.error(f"Configuration operation '{operation}' failed after {duration:.3f}s: {str(e)}")
            raise


# Global configuration service instance
_config_service: Optional[ConfigurationService] = None


def get_configuration_service() -> ConfigurationService:
    """Get the global configuration service instance."""
    global _config_service
    if _config_service is None:
        _config_service = ConfigurationService()
    return _config_service


def set_configuration_service(service: ConfigurationService) -> None:
    """Set the global configuration service instance."""
    global _config_service
    _config_service = service


async def initialize_configuration() -> ConfigurationService:
    """Initialize and return the global configuration service."""
    service = get_configuration_service()
    await service.initialize()
    return service
