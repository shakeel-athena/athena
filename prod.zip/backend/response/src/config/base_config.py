"""
Base Configuration Provider

Abstract base class for configuration providers with validation support.
"""

from abc import ABC, abstractmethod
from enum import Enum
from typing import Any, Dict, List, Optional, Callable
import logging


class ConfigValidationLevel(Enum):
    """Configuration validation levels."""
    NONE = "none"        # No validation
    WARNING = "warning"  # Log warnings for invalid config
    ERROR = "error"      # Raise errors for invalid config


class ConfigurationProvider(ABC):
    """
    Abstract base class for configuration providers.
    
    Defines the interface that all configuration providers must implement
    for consistent configuration access and validation.
    """
    
    def __init__(self, validation_level: ConfigValidationLevel = ConfigValidationLevel.ERROR):
        """
        Initialize configuration provider.
        
        Args:
            validation_level: Level of validation to perform
        """
        self.validation_level = validation_level
        self._logger = logging.getLogger(f"{__name__}.{self.__class__.__name__}")
        self._subscribers: List[Callable[[str, Any, Any], None]] = []
    
    @abstractmethod
    def get(self, key: str, default: Any = None, required: bool = False) -> Any:
        """
        Get configuration value.
        
        Args:
            key: Configuration key
            default: Default value if not found
            required: Whether the configuration is required
            
        Returns:
            Configuration value
            
        Raises:
            ConfigurationError: If required configuration is missing
        """
        pass
    
    @abstractmethod
    def get_section(self, section: str) -> Dict[str, Any]:
        """
        Get entire configuration section.
        
        Args:
            section: Configuration section name
            
        Returns:
            Dictionary of configuration values for the section
        """
        pass
    
    @abstractmethod
    def validate_section(self, section: str, level: ConfigValidationLevel = ConfigValidationLevel.ERROR) -> Dict[str, Any]:
        """
        Validate a configuration section.
        
        Args:
            section: Configuration section name
            level: Validation level to use
            
        Returns:
            Validation result with errors and warnings
        """
        pass
    
    def subscribe(self, callback: Callable[[str, Any, Any], None]) -> None:
        """
        Subscribe to configuration changes.
        
        Args:
            callback: Function to call when configuration changes
                     Called with (key, old_value, new_value)
        """
        self._subscribers.append(callback)
    
    def unsubscribe(self, callback: Callable[[str, Any, Any], None]) -> None:
        """
        Unsubscribe from configuration changes.
        
        Args:
            callback: Function to remove from subscribers
        """
        if callback in self._subscribers:
            self._subscribers.remove(callback)
    
    def _notify_subscribers(self, key: str, old_value: Any, new_value: Any) -> None:
        """
        Notify subscribers of configuration changes.
        
        Args:
            key: Configuration key that changed
            old_value: Previous value
            new_value: New value
        """
        for callback in self._subscribers:
            try:
                callback(key, old_value, new_value)
            except Exception as e:
                self._logger.error(f"Error notifying configuration subscriber: {str(e)}")
    
    def get_cache_stats(self) -> Dict[str, Any]:
        """
        Get cache statistics (if provider supports caching).
        
        Returns:
            Cache statistics dictionary
        """
        return {}
    
    def clear_cache(self) -> None:
        """Clear any configuration caches."""
        pass
    
    def is_healthy(self) -> bool:
        """
        Check if configuration provider is healthy.
        
        Returns:
            True if provider is healthy, False otherwise
        """
        return True
    
    def get_health_status(self) -> Dict[str, Any]:
        """
        Get health status of configuration provider.
        
        Returns:
            Health status information
        """
        return {
            'healthy': self.is_healthy(),
            'validation_level': self.validation_level.value,
            'subscriber_count': len(self._subscribers)
        }


class ConfigurationManager:
    """
    Manager for multiple configuration providers.
    
    Allows chaining multiple providers with priority ordering
    and automatic fallback handling.
    """
    
    def __init__(self):
        """Initialize configuration manager."""
        self._providers: List[ConfigurationProvider] = []
        self._logger = logging.getLogger(f"{__name__}.{self.__class__.__name__}")
    
    def add_provider(self, provider: ConfigurationProvider, priority: int = 0) -> None:
        """
        Add a configuration provider.
        
        Args:
            provider: Configuration provider to add
            priority: Priority (higher = higher priority)
        """
        self._providers.append((priority, provider))
        self._providers.sort(key=lambda x: x[0], reverse=True)
        self._logger.info(f"Added configuration provider: {provider.__class__.__name__} (priority: {priority})")
    
    def remove_provider(self, provider: ConfigurationProvider) -> None:
        """
        Remove a configuration provider.
        
        Args:
            provider: Configuration provider to remove
        """
        self._providers = [(p, pr) for p, pr in self._providers if pr != provider]
        self._logger.info(f"Removed configuration provider: {provider.__class__.__name__}")
    
    def get(self, key: str, default: Any = None, required: bool = False) -> Any:
        """
        Get configuration value from highest priority provider.
        
        Args:
            key: Configuration key
            default: Default value if not found
            required: Whether the configuration is required
            
        Returns:
            Configuration value
        """
        for priority, provider in self._providers:
            try:
                value = provider.get(key, None, required=False)
                if value is not None:
                    return value
            except Exception as e:
                self._logger.warning(f"Provider {provider.__class__.__name__} failed for key {key}: {str(e)}")
                continue
        
        if required:
            raise Exception(f"Required configuration '{key}' not found in any provider")
        
        return default
    
    def get_section(self, section: str) -> Dict[str, Any]:
        """
        Get configuration section from highest priority provider.
        
        Args:
            section: Configuration section name
            
        Returns:
            Merged configuration section from all providers
        """
        result = {}
        
        for priority, provider in self._providers:
            try:
                section_data = provider.get_section(section)
                # Merge with existing data (lower priority providers)
                result.update(section_data)
            except Exception as e:
                self._logger.warning(f"Provider {provider.__class__.__name__} failed for section {section}: {str(e)}")
                continue
        
        return result
    
    def validate_section(self, section: str, level: ConfigValidationLevel = ConfigValidationLevel.ERROR) -> Dict[str, Any]:
        """
        Validate configuration section across all providers.
        
        Args:
            section: Configuration section name
            level: Validation level to use
            
        Returns:
            Combined validation result
        """
        result = {
            'valid': True,
            'errors': [],
            'warnings': [],
            'provider_results': {}
        }
        
        for priority, provider in self._providers:
            try:
                provider_result = provider.validate_section(section, level)
                result['provider_results'][provider.__class__.__name__] = provider_result
                
                # Combine validation results
                if not provider_result.get('valid', True):
                    result['valid'] = False
                
                result['errors'].extend(provider_result.get('errors', []))
                result['warnings'].extend(provider_result.get('warnings', []))
                
            except Exception as e:
                result['valid'] = False
                result['errors'].append(f"Provider {provider.__class__.__name__} validation failed: {str(e)}")
        
        return result
    
    def get_all_providers(self) -> List[ConfigurationProvider]:
        """Get all registered providers."""
        return [provider for priority, provider in self._providers]
    
    def is_healthy(self) -> bool:
        """Check if all providers are healthy."""
        return all(provider.is_healthy() for priority, provider in self._providers)
    
    def get_health_status(self) -> Dict[str, Any]:
        """Get health status of all providers."""
        return {
            'healthy': self.is_healthy(),
            'provider_count': len(self._providers),
            'providers': [
                {
                    'name': provider.__class__.__name__,
                    'priority': priority,
                    'health': provider.get_health_status()
                }
                for priority, provider in self._providers
            ]
        }