"""
Environment Configuration Provider

Provides environment-based configuration with validation,
type conversion, and caching for the Athena backend.
"""

import os
import re
import sys
from typing import Any, Dict, List, Optional, Union, Callable

# Add current directory to path for direct imports
current_dir = os.path.dirname(os.path.abspath(__file__))
if current_dir not in sys.path:
    sys.path.insert(0, current_dir)

from base_config import ConfigurationProvider, ConfigValidationLevel
from validators import (
    validate_aws_region, validate_aws_access_key, validate_port,
    validate_url, validate_email, validate_cidr, validate_json,
    validate_ip_address_list, validate_country_codes
)
from exceptions import (
    ConfigurationError, ValidationError, RequiredConfigurationError
)


class EnvironmentConfigurationProvider(ConfigurationProvider):
    """
    Environment-based configuration provider with validation.
    
    Loads configuration from environment variables with proper validation,
    type conversion, and caching for performance.
    """
    
    def __init__(self,
                 prefix: str = "",
                 validation_level: ConfigValidationLevel = ConfigValidationLevel.ERROR,
                 cache_enabled: bool = True):
        """
        Initialize environment configuration provider.

        Args:
            prefix: Optional prefix for environment variables
            validation_level: Level of validation to perform
            cache_enabled: Whether to enable configuration caching
        """
        # Call parent class constructor to initialize _subscribers and other base attributes
        super().__init__(validation_level=validation_level)

        self.prefix = prefix.upper() + "_" if prefix else ""
        self.cache_enabled = cache_enabled
        self._logger = self._create_logger()
        self._validation_cache = {}
        self._config_cache = {}
        
        # Register custom validators
        self._validators = {
            'aws_region': validate_aws_region,
            'aws_access_key': validate_aws_access_key,
            'port': validate_port,
            'url': validate_url,
            'email': validate_email,
            'cidr': validate_cidr,
            'json': validate_json,
            'ip_list': validate_ip_address_list,
            'country_codes': validate_country_codes,
        }
    
    def _create_logger(self):
        """Create logger for configuration provider."""
        import logging
        return logging.getLogger(f"{__name__}.{self.__class__.__name__}")
    
    def _get_env_key(self, key: str) -> str:
        """Get full environment variable key."""
        return f"{self.prefix}{key.upper()}"
    
    def _get_cached_value(self, key: str) -> Optional[Any]:
        """Get value from cache if available."""
        if not self.cache_enabled:
            return None
        
        cache_key = f"{self.prefix}{key}"
        return self._config_cache.get(cache_key)
    
    def _cache_value(self, key: str, value: Any):
        """Cache a configuration value."""
        if self.cache_enabled:
            cache_key = f"{self.prefix}{key}"
            self._config_cache[cache_key] = value
    
    def get(self, key: str, default: Any = None, required: bool = False) -> Any:
        """
        Get configuration value from environment.
        
        Args:
            key: Configuration key
            default: Default value if not found
            required: Whether the configuration is required
            
        Returns:
            Configuration value
            
        Raises:
            RequiredConfigurationError: If required configuration is missing
        """
        # Check cache first
        cached_value = self._get_cached_value(key)
        if cached_value is not None:
            return cached_value
        
        env_key = self._get_env_key(key)
        value = os.getenv(env_key, default)
        
        if required and value is None:
            raise RequiredConfigurationError(f"Required configuration '{key}' (env: {env_key}) is not set")
        
        self._logger.debug(f"Config: {key} = {value}")
        
        # Cache the value
        self._cache_value(key, value)
        
        return value
    
    def get_int(self, 
                key: str, 
                default: int = 0, 
                min_val: int = None, 
                max_val: int = None, 
                required: bool = False) -> int:
        """
        Get integer configuration with validation.
        
        Args:
            key: Configuration key
            default: Default value
            min_val: Minimum allowed value
            max_val: Maximum allowed value
            required: Whether the configuration is required
            
        Returns:
            Integer configuration value
            
        Raises:
            ValidationError: If value is invalid
        """
        # Check cache first
        cached_value = self._get_cached_value(key)
        if cached_value is not None:
            return cached_value
        
        raw_value = self.get(key, str(default) if required else None, required)
        
        if raw_value is None:
            return default
        
        try:
            value = int(raw_value)
            
            # Range validation
            if min_val is not None and value < min_val:
                raise ValidationError(f"Configuration '{key}' value {value} is below minimum {min_val}")
            
            if max_val is not None and value > max_val:
                raise ValidationError(f"Configuration '{key}' value {value} is above maximum {max_val}")
            
            self._logger.debug(f"Config int: {key} = {value}")
            
            # Cache the validated value
            self._cache_value(key, value)
            
            return value
            
        except ValueError as e:
            raise ValidationError(f"Configuration '{key}' must be an integer: {str(e)}")
    
    def get_bool(self, key: str, default: bool = False, required: bool = False) -> bool:
        """
        Get boolean configuration with validation.
        
        Args:
            key: Configuration key
            default: Default value
            required: Whether the configuration is required
            
        Returns:
            Boolean configuration value
            
        Raises:
            ValidationError: If value is invalid
        """
        # Check cache first
        cached_value = self._get_cached_value(key)
        if cached_value is not None:
            return cached_value
        
        raw_value = self.get(key, str(default).lower() if required else None, required)
        
        if raw_value is None:
            return default
        
        # Handle various boolean representations
        true_values = ['true', '1', 'yes', 'on', 'enabled', 't', 'y']
        false_values = ['false', '0', 'no', 'off', 'disabled', 'f', 'n']
        
        value_lower = str(raw_value).lower().strip()
        
        if value_lower in true_values:
            value = True
        elif value_lower in false_values:
            value = False
        else:
            raise ValidationError(f"Configuration '{key}' must be a boolean value: {raw_value}")
        
        self._logger.debug(f"Config bool: {key} = {value}")
        
        # Cache the validated value
        self._cache_value(key, value)
        
        return value
    
    def get_string(self, 
                   key: str, 
                   default: str = "", 
                   min_length: int = None, 
                   max_length: int = None, 
                   allowed_values: List[str] = None, 
                   validator: str = None,
                   required: bool = False) -> str:
        """
        Get string configuration with validation.
        
        Args:
            key: Configuration key
            default: Default value
            min_length: Minimum string length
            max_length: Maximum string length
            allowed_values: List of allowed values
            validator: Custom validator function name
            required: Whether the configuration is required
            
        Returns:
            String configuration value
            
        Raises:
            ValidationError: If value is invalid
        """
        # Check cache first
        cached_value = self._get_cached_value(key)
        if cached_value is not None:
            return cached_value
        
        raw_value = self.get(key, default if required else None, required)
        
        if raw_value is None:
            return default
        
        value = str(raw_value).strip()
        
        # Length validation
        if min_length is not None and len(value) < min_length:
            raise ValidationError(f"Configuration '{key}' length {len(value)} is below minimum {min_length}")
        
        if max_length is not None and len(value) > max_length:
            raise ValidationError(f"Configuration '{key}' length {len(value)} is above maximum {max_length}")
        
        # Custom validator
        if validator and validator in self._validators:
            if not self._validators[validator](value):
                raise ValidationError(f"Configuration '{key}' failed {validator} validation: {value}")
        
        # Allowed values validation
        if allowed_values and value not in allowed_values:
            raise ValidationError(f"Configuration '{key}' value '{value}' not in allowed values: {allowed_values}")
        
        self._logger.debug(f"Config string: {key} = {value}")
        
        # Cache the validated value
        self._cache_value(key, value)
        
        return value
    
    def get_list(self, 
                 key: str, 
                 default: List[str] = None, 
                 separator: str = ",", 
                 item_type: type = str,
                 validator: str = None,
                 required: bool = False) -> List[Any]:
        """
        Get list configuration with validation.
        
        Args:
            key: Configuration key
            default: Default value
            separator: Separator for splitting list
            item_type: Type of list items
            validator: Custom validator function name
            required: Whether the configuration is required
            
        Returns:
            List configuration value
            
        Raises:
            ValidationError: If value is invalid
        """
        # Check cache first
        cached_value = self._get_cached_value(key)
        if cached_value is not None:
            return cached_value
        
        raw_value = self.get(key, separator.join(default) if default and required else None, required)
        
        if raw_value is None:
            return default or []
        
        # Split and clean items
        items = [item.strip() for item in str(raw_value).split(separator) if item.strip()]
        
        # Type conversion
        try:
            if item_type == int:
                items = [int(item) for item in items]
            elif item_type == float:
                items = [float(item) for item in items]
            elif item_type == bool:
                items = [item.lower() in ['true', '1', 'yes'] for item in items]
        except ValueError as e:
            raise ValidationError(f"Configuration '{key}' contains invalid {item_type.__name__} values: {str(e)}")
        
        # Custom validation
        if validator and validator in self._validators:
            if not self._validators[validator](items):
                raise ValidationError(f"Configuration '{key}' failed {validator} validation")
        
        # Cache the validated value
        self._cache_value(key, items)
        
        return items
    
    def validate_section(self, section: str, level: ConfigValidationLevel = ConfigValidationLevel.ERROR) -> Dict[str, Any]:
        """
        Validate a configuration section.
        
        Args:
            section: Configuration section name
            level: Validation level to use
            
        Returns:
            Validation result
        """
        if section in self._validation_cache:
            return self._validation_cache[section]
        
        validation_result = self._validate_section_internal(section)
        self._validation_cache[section] = validation_result
        
        return validation_result
    
    def get_section(self, section: str) -> Dict[str, Any]:
        """Get entire configuration section."""
        section_config = {
            'aws': self._get_aws_config(),
            'database': self._get_database_config(),
            'keycloak': self._get_keycloak_config(),
            'firewall': self._get_firewall_config(),
            'waf': self._get_waf_config(),
            'alerts': self._get_alerts_config(),
            'cache': self._get_cache_config(),
            'logging': self._get_logging_config(),
            'app': self._get_app_config(),
        }
        
        return section_config.get(section, {})
    
    def _get_aws_config(self) -> Dict[str, Any]:
        """Get AWS configuration section."""
        return {
            'access_key_id': self.get_string('AWS_ACCESS_KEY_ID'),
            'secret_access_key': self.get_string('AWS_SECRET_ACCESS_KEY'),
            'session_token': self.get_string('AWS_SESSION_TOKEN'),
            'region': self.get_string('AWS_REGION', default='us-east-2', validator='aws_region'),
            'profile': self.get_string('AWS_PROFILE'),
            'scope': self.get_string('AWS_SCOPE', default='REGIONAL', allowed_values=['REGIONAL', 'CLOUDFRONT']),
        }
    
    def _get_database_config(self) -> Dict[str, Any]:
        """Get database configuration section."""
        return {
            'host': self.get_string('POSTGRES_HOST', default='localhost'),
            'port': self.get_int('POSTGRES_PORT', default=5432, validator='port'),
            'database': self.get_string('POSTGRES_DB', default='athena_db'),
            'user': self.get_string('POSTGRES_USER', default='athena_user'),
            'password': self.get_string('POSTGRES_PASSWORD', default='athena_password'),
            'pool_size': self.get_int('DB_POOL_SIZE', default=10, min_val=1, max_val=100),
            'pool_max_overflow': self.get_int('DB_MAX_OVERFLOW', default=20, min_val=0, max_val=100),
            'pool_timeout': self.get_int('DB_POOL_TIMEOUT', default=30, min_val=1, max_val=300),
            'pool_recycle': self.get_int('DB_POOL_RECYCLE', default=3600, min_val=300),
            'connect_timeout': self.get_int('DB_CONNECT_TIMEOUT', default=10, min_val=1, max_val=60),
            'statement_timeout': self.get_int('DB_STATEMENT_TIMEOUT', default=30000, min_val=1000),
        }
    
    def _get_keycloak_config(self) -> Dict[str, Any]:
        """Get Keycloak configuration section."""
        return {
            'url': self.get_string('KEYCLOAK_URL', validator='url'),
            'realm': self.get_string('KEYCLOAK_REALM', default='athena'),
            'client_id': self.get_string('KEYCLOAK_CLIENT_ID'),
            'client_secret': self.get_string('KEYCLOAK_CLIENT_SECRET'),
            'redirect_uri': self.get_string('KEYCLOAK_REDIRECT_URI'),
        }
    
    def _get_firewall_config(self) -> Dict[str, Any]:
        """Get firewall configuration section."""
        return {
            'rule_group': self.get_string('FIREWALL_RULE_GROUP', default='allow-ingress'),
            'enabled': self.get_bool('FIREWALL_ENABLED', default=True),
            'cache_ttl': self.get_int('FIREWALL_CACHE_TTL', default=300, min_val=60),
        }
    
    def _get_waf_config(self) -> Dict[str, Any]:
        """Get WAF configuration section."""
        return {
            'web_acl': self.get_string('WAF_WEB_ACL'),
            'scope': self.get_string('AWS_SCOPE', default='REGIONAL', allowed_values=['REGIONAL', 'CLOUDFRONT']),
            'enabled': self.get_bool('WAF_ENABLED', default=True),
            'cache_ttl': self.get_int('WAF_CACHE_TTL', default=600, min_val=60),
        }
    
    def _get_alerts_config(self) -> Dict[str, Any]:
        """Get alerts configuration section."""
        return {
            'wazuh_host': self.get_string('WAZUH_HOST', default='localhost'),
            'wazuh_port': self.get_int('WAZUH_PORT', default=55000, validator='port'),
            'wazuh_username': self.get_string('WAZUH_USERNAME'),
            'wazuh_password': self.get_string('WAZUH_PASSWORD'),
            'wazuh_verify_ssl': self.get_bool('WAZUH_VERIFY_SSL', default=True),
            'suricata_log_file': self.get_string('SURICATA_LOG_FILE', default='/var/log/suricata/eve.json'),
            'default_limit': self.get_int('DEFAULT_ALERTS_LIMIT', default=100, min_val=1, max_val=1000),
            'default_time_range': self.get_int('DEFAULT_TIME_RANGE_HOURS', default=24, min_val=1, max_val=720),
        }
    
    def _get_cache_config(self) -> Dict[str, Any]:
        """Get cache configuration section."""
        return {
            'redis_url': self.get_string('REDIS_URL'),
            'default_ttl': self.get_int('CACHE_DEFAULT_TTL', default=300, min_val=60),
            'max_keys': self.get_int('CACHE_MAX_KEYS', default=10000, min_val=100),
            'enabled': self.get_bool('CACHE_ENABLED', default=True),
        }
    
    def _get_logging_config(self) -> Dict[str, Any]:
        """Get logging configuration section."""
        return {
            'level': self.get_string('LOG_LEVEL', default='INFO', allowed_values=[
                'DEBUG', 'INFO', 'WARNING', 'ERROR', 'CRITICAL'
            ]),
            'format': self.get_string('LOG_FORMAT', default='%(asctime)s - %(name)s - %(levelname)s - %(message)s'),
            'file_path': self.get_string('LOG_FILE_PATH'),
            'max_file_size': self.get_int('LOG_MAX_FILE_SIZE', default=10485760, min_val=1024),  # 10MB
            'backup_count': self.get_int('LOG_BACKUP_COUNT', default=5, min_val=1, max_val=20),
            'structured': self.get_bool('LOG_STRUCTURED', default=False),
        }
    
    def _get_app_config(self) -> Dict[str, Any]:
        """Get application configuration section."""
        return {
            'port': self.get_int('PORT', default=5000, validator='port'),
            'debug': self.get_bool('DEBUG', default=False),
            'environment': self.get_string('ENVIRONMENT', default='production', allowed_values=[
                'development', 'staging', 'production'
            ]),
            'secret_key': self.get_string('SECRET_KEY', min_length=32, required=True),
            'cors_origins': self.get_list('CORS_ORIGINS', default=['*']),
        }
    
    def _validate_section_internal(self, section: str) -> Dict[str, Any]:
        """Internal implementation of section validation."""
        validation_result = {
            'valid': True,
            'errors': [],
            'warnings': []
        }
        
        try:
            config = self.get_section(section)
            self._validate_section_config(section, config, validation_result)
        except Exception as e:
            validation_result['valid'] = False
            validation_result['errors'].append(f"Section validation failed: {str(e)}")
        
        return validation_result
    
    def _validate_section_config(self, section: str, config: Dict[str, Any], result: Dict[str, Any]):
        """Validate specific section configuration."""
        if section == 'aws':
            self._validate_aws_config(config, result)
        elif section == 'database':
            self._validate_database_config(config, result)
        elif section == 'keycloak':
            self._validate_keycloak_config(config, result)
        elif section == 'firewall':
            self._validate_firewall_config(config, result)
        elif section == 'waf':
            self._validate_waf_config(config, result)
        elif section in ['alerts', 'cache', 'logging', 'app']:
            # Basic validation for other sections
            pass
    
    def _validate_aws_config(self, config: Dict[str, Any], result: Dict[str, Any]):
        """Validate AWS configuration."""
        # Check credential consistency
        access_key = config.get('access_key_id')
        secret_key = config.get('secret_access_key')
        session_token = config.get('session_token')
        
        if access_key and not secret_key:
            result['errors'].append("AWS_SECRET_ACCESS_KEY required when AWS_ACCESS_KEY_ID is set")
            result['valid'] = False
        
        if secret_key and not access_key:
            result['errors'].append("AWS_ACCESS_KEY_ID required when AWS_SECRET_ACCESS_KEY is set")
            result['valid'] = False
        
        if session_token and not (access_key and secret_key):
            result['errors'].append("AWS_ACCESS_KEY_ID and AWS_SECRET_ACCESS_KEY required when using session token")
            result['valid'] = False
    
    def _validate_database_config(self, config: Dict[str, Any], result: Dict[str, Any]):
        """Validate database configuration."""
        required_fields = ['host', 'port', 'database', 'user']
        for field in required_fields:
            if not config.get(field):
                result['errors'].append(f"Database configuration missing required field: {field}")
                result['valid'] = False
        
        # Validate pool configuration
        if config.get('pool_size', 0) <= 0:
            result['errors'].append("Database pool size must be positive")
            result['valid'] = False
        
        if config.get('pool_max_overflow', 0) < 0:
            result['errors'].append("Database pool max overflow cannot be negative")
            result['valid'] = False
    
    def _validate_keycloak_config(self, config: Dict[str, Any], result: Dict[str, Any]):
        """Validate Keycloak configuration."""
        if not config.get('url'):
            result['errors'].append("KEYCLOAK_URL is required for authentication")
            result['valid'] = False
    
    def _validate_firewall_config(self, config: Dict[str, Any], result: Dict[str, Any]):
        """Validate firewall configuration."""
        if not config.get('rule_group'):
            result['warnings'].append("FIREWALL_RULE_GROUP not configured - firewall features will be limited")
    
    def _validate_waf_config(self, config: Dict[str, Any], result: Dict[str, Any]):
        """Validate WAF configuration."""
        if not config.get('web_acl'):
            result['warnings'].append("WAF_WEB_ACL not configured - WAF features will be limited")
    
    def clear_cache(self):
        """Clear all configuration caches."""
        self._config_cache.clear()
        self._validation_cache.clear()
        self._logger.debug("Configuration cache cleared")
    
    def get_cache_stats(self) -> Dict[str, Any]:
        """Get cache statistics."""
        return {
            'config_cache_size': len(self._config_cache),
            'validation_cache_size': len(self._validation_cache),
            'cache_enabled': self.cache_enabled
        }
