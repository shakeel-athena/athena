"""
Wazuh Suppression Sync Service (Optimized)

Syncs PostgreSQL mute_rules to Wazuh Manager using:
1. CDB lists for IP-based suppression
2. Rule overrides (level="0") for rule-level suppression

Uses hash-based change detection to avoid unnecessary syncs.
Deploys to separate files to preserve manual rules.

Author: Athena Security Platform
"""

import psycopg2
import paramiko
import os
import hashlib
import json
import time
from datetime import datetime
import xml.etree.ElementTree as ET
from xml.dom import minidom


class WazuhSyncService:
    def __init__(self, db_connection):
        self.db = db_connection
        self.ssh_host = os.getenv('WAZUH_MANAGER_HOST') or os.getenv('WAZUH_HOST')
        self.ssh_user = os.getenv('WAZUH_SSH_USER')
        self.ssh_password = os.getenv('WAZUH_SSH_PASSWORD')

        # SSH Key Authentication (RECOMMENDED - more secure than password)
        self.ssh_key_path = os.getenv('WAZUH_SSH_KEY_PATH')  # If set, uses key auth instead of password

        # Separate files for Athena-managed rules (preserves manual rules)
        self.cdb_path = '/var/ossec/etc/lists/athena_mute_ips'
        self.rules_path = '/var/ossec/etc/rules/athena_mute_rules.xml'

    def _create_ssh_connection(self):
        """
        Create SSH connection using key or password authentication

        Supports both Ed25519 (recommended) and RSA keys for production deployments.

        Returns:
            paramiko.SSHClient: Connected SSH client
        """
        ssh = paramiko.SSHClient()
        ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())

        # Prefer SSH key if configured (more secure for production)
        if self.ssh_key_path and os.path.exists(self.ssh_key_path):
            try:
                # Try Ed25519 key first (modern, recommended), then RSA fallback
                try:
                    private_key = paramiko.Ed25519Key.from_private_key_file(self.ssh_key_path)
                    print(f"[Wazuh Sync] Using Ed25519 key authentication")
                except Exception:
                    private_key = paramiko.RSAKey.from_private_key_file(self.ssh_key_path)
                    print(f"[Wazuh Sync] Using RSA key authentication")

                ssh.connect(
                    self.ssh_host,
                    username=self.ssh_user,
                    pkey=private_key,
                    timeout=30
                )
                print(f"[Wazuh Sync] SSH key auth successful to {self.ssh_host}")
                return ssh
            except Exception as e:
                print(f"[Wazuh Sync] [WARN] SSH key auth failed ({e}), falling back to password")

        # Fallback to password authentication
        ssh.connect(
            self.ssh_host,
            username=self.ssh_user,
            password=self.ssh_password,
            timeout=30
        )
        return ssh

    def sync_mute_rules(self):
        """
        Main sync function with hash-based change detection

        Returns:
            dict: {
                'success': bool,
                'skipped': bool,
                'ip_rules_synced': int,
                'rule_suppressions_synced': int,
                'timestamp': str,
                'duration_ms': int
            }
        """
        start_time = time.time()

        try:
            # 1. Fetch active Wazuh mute rules from PostgreSQL
            mute_rules = self._fetch_mute_rules()

            # 2. Calculate hash of current rules
            rules_hash = self._calculate_rules_hash(mute_rules)

            # 3. Check if rules changed since last sync
            last_hash = self._get_last_sync_hash()

            if rules_hash == last_hash:
                # Rules unchanged, skip sync (99% of cron runs)
                duration_ms = int((time.time() - start_time) * 1000)

                self._log_sync(
                    rules_hash=rules_hash,
                    rules_count=len(mute_rules),
                    success=True,
                    duration_ms=duration_ms,
                    skipped=True
                )

                return {
                    'success': True,
                    'skipped': True,
                    'ip_rules_synced': 0,
                    'rule_suppressions_synced': 0,
                    'timestamp': datetime.now().isoformat(),
                    'duration_ms': duration_ms,
                    'message': 'No changes detected, sync skipped'
                }

            # 4. Separate IP-based rules from rule-based suppressions
            ip_rules, rule_suppressions = self._categorize_rules(mute_rules)

            print(f"[Wazuh Sync] Processing {len(ip_rules)} IP rules, {len(rule_suppressions)} rule overrides")

            # 5. Deploy CDB list for IP-based rules
            cdb_success = True
            if ip_rules:
                cdb_success = self._deploy_cdb_list(ip_rules)
            else:
                # Create empty file if no IP rules
                cdb_success = self._deploy_cdb_list([])

            # 6. Deploy XML rule overrides for rule-level suppressions
            rules_success = True
            if rule_suppressions:
                rules_success = self._deploy_rule_overrides(rule_suppressions)
            else:
                # Create empty file if no rule suppressions
                rules_success = self._deploy_rule_overrides([])

            # 7. Compile CDB and restart Wazuh only if deployment succeeded
            if cdb_success and rules_success:
                restart_success = self._compile_and_restart()

                if restart_success:
                    # Store new hash
                    self._save_last_sync_hash(rules_hash, len(mute_rules))

                    duration_ms = int((time.time() - start_time) * 1000)

                    self._log_sync(
                        rules_hash=rules_hash,
                        rules_count=len(mute_rules),
                        success=True,
                        duration_ms=duration_ms
                    )

                    return {
                        'success': True,
                        'skipped': False,
                        'ip_rules_synced': len(ip_rules),
                        'rule_suppressions_synced': len(rule_suppressions),
                        'timestamp': datetime.now().isoformat(),
                        'duration_ms': duration_ms,
                        'rules_hash': rules_hash
                    }
                else:
                    duration_ms = int((time.time() - start_time) * 1000)

                    self._log_sync(
                        rules_hash=rules_hash,
                        rules_count=len(mute_rules),
                        success=False,
                        duration_ms=duration_ms,
                        error_message="Wazuh restart failed"
                    )

                    return {
                        'success': False,
                        'skipped': False,
                        'error': 'Wazuh restart failed',
                        'duration_ms': duration_ms
                    }
            else:
                duration_ms = int((time.time() - start_time) * 1000)

                error_msg = []
                if not cdb_success:
                    error_msg.append("CDB deployment failed")
                if not rules_success:
                    error_msg.append("Rules deployment failed")

                self._log_sync(
                    rules_hash=rules_hash,
                    rules_count=len(mute_rules),
                    success=False,
                    duration_ms=duration_ms,
                    error_message=", ".join(error_msg)
                )

                return {
                    'success': False,
                    'skipped': False,
                    'error': ', '.join(error_msg),
                    'duration_ms': duration_ms
                }

        except Exception as e:
            duration_ms = int((time.time() - start_time) * 1000)

            self._log_sync(
                rules_hash='',
                rules_count=0,
                success=False,
                duration_ms=duration_ms,
                error_message=str(e)
            )

            print(f"[Wazuh Sync] Exception: {e}")
            return {
                'success': False,
                'skipped': False,
                'error': str(e),
                'duration_ms': duration_ms
            }

    def _calculate_rules_hash(self, mute_rules):
        """
        Calculate SHA256 hash of mute rules for change detection

        Args:
            mute_rules: List of (rule_id, conditions, reason) tuples

        Returns:
            str: SHA256 hex digest
        """
        # Sort rules by ID for consistent hashing
        sorted_rules = sorted(mute_rules, key=lambda x: str(x[0]))

        # Create deterministic JSON representation
        rules_json = json.dumps(
            [(str(rule_id), conditions, reason) for rule_id, conditions, reason in sorted_rules],
            sort_keys=True
        )

        # Calculate hash
        return hashlib.sha256(rules_json.encode()).hexdigest()

    def _get_last_sync_hash(self):
        """Get hash from last successful sync"""
        cursor = self.db.cursor()
        try:
            cursor.execute("""
                SELECT sync_hash
                FROM suppression_sync_log
                WHERE service = 'wazuh'
                AND success = TRUE
                ORDER BY synced_at DESC
                LIMIT 1
            """)
            result = cursor.fetchone()
            return result[0] if result else None
        except Exception as e:
            # Table might not exist yet
            print(f"[Wazuh Sync] Warning: Could not fetch last hash: {e}")
            return None
        finally:
            cursor.close()

    def _save_last_sync_hash(self, rules_hash, rules_count):
        """Save hash of successful sync"""
        cursor = self.db.cursor()
        try:
            cursor.execute("""
                INSERT INTO suppression_sync_log
                (service, sync_hash, rules_count, synced_at, success)
                VALUES (%s, %s, %s, NOW(), TRUE)
            """, ['wazuh', rules_hash, rules_count])
            self.db.commit()
        except Exception as e:
            print(f"[Wazuh Sync] Warning: Could not save sync hash: {e}")
            self.db.rollback()
        finally:
            cursor.close()

    def _log_sync(self, rules_hash, rules_count, success, duration_ms, error_message=None, skipped=False):
        """Log sync operation"""
        cursor = self.db.cursor()
        try:
            cursor.execute("""
                INSERT INTO suppression_sync_log
                (service, sync_hash, rules_count, success, error_message, synced_at, duration_ms)
                VALUES (%s, %s, %s, %s, %s, NOW(), %s)
            """, ['wazuh', rules_hash, rules_count, success, error_message, duration_ms])
            self.db.commit()
        except Exception as e:
            print(f"[Wazuh Sync] Warning: Could not log sync: {e}")
            self.db.rollback()
        finally:
            cursor.close()

    def _fetch_mute_rules(self):
        """Fetch active Wazuh mute rules from PostgreSQL"""

        cursor = self.db.cursor()
        cursor.execute("""
            SELECT id, conditions, reason
            FROM mute_rules
            WHERE active = TRUE
            AND approval_status IN ('auto_approved', 'approved')
            AND (source_type = 'wazuh' OR source_type = 'both' OR source_type IS NULL)
            AND (expires_at IS NULL OR expires_at > NOW())
        """)

        rules = cursor.fetchall()
        cursor.close()

        return rules

    def _categorize_rules(self, mute_rules):
        """
        Separate IP-based rules from rule-level suppressions

        IP-based rules use CDB lists (fast lookup)
        Rule-level suppressions use XML overrides (level="0")
        """

        ip_rules = []
        rule_suppressions = []

        for rule_id, conditions, reason in mute_rules:
            # IP-based suppression (use CDB)
            if 'source_ip' in conditions:
                ip_rules.append({
                    'id': rule_id,
                    'ip': conditions['source_ip'],
                    'reason': reason or 'Muted by Athena',
                    'rule_id': conditions.get('rule_id')  # Optional: specific rule
                })

            # Rule-level suppression (use rule override)
            elif 'rule_id' in conditions and 'source_ip' not in conditions:
                rule_suppressions.append({
                    'id': rule_id,
                    'rule_id': conditions['rule_id'],
                    'reason': reason or 'Muted by Athena'
                })

        return ip_rules, rule_suppressions

    def _deploy_cdb_list(self, ip_rules):
        """
        Deploy CDB list for IP-based suppressions

        Format: IP:Description
        Example: 10.0.0.50:Vulnerability scanner
        """

        lines = []
        lines.append("# ============================================================================")
        lines.append("# Athena Security Platform - Auto-Generated IP Whitelist")
        lines.append("# DO NOT EDIT MANUALLY - Changes will be overwritten")
        lines.append("# ============================================================================")
        lines.append(f"# Generated: {datetime.now().isoformat()}")
        lines.append(f"# Total IPs: {len(ip_rules)}")
        lines.append("# This file is auto-managed by Athena Suppression Sync Service")
        lines.append("# Manual IP whitelists should be added to a separate CDB file")
        lines.append("# ============================================================================")
        lines.append("")

        for rule in ip_rules:
            # CDB format: key:value
            lines.append(f"{rule['ip']}:{rule['reason']}")

        cdb_content = "\n".join(lines)

        try:
            ssh = self._create_ssh_connection()

            # Use SFTP + temp file method (more reliable than heredoc)
            tmp_file = '/tmp/athena_mute_ips.tmp'

            # Write to temp file via SFTP
            sftp = ssh.open_sftp()
            with sftp.file(tmp_file, 'w') as f:
                f.write(cdb_content)
            sftp.close()

            # Backup existing CDB (optional)
            backup_cmd = f"echo '{self.ssh_password}' | sudo -S cp {self.cdb_path} {self.cdb_path}.bak.$(date +%Y%m%d_%H%M%S) 2>/dev/null || true"
            stdin, stdout, stderr = ssh.exec_command(backup_cmd)
            stdout.read()

            # Move temp file to final location with sudo
            move_cmd = f"echo '{self.ssh_password}' | sudo -S mv {tmp_file} {self.cdb_path}"
            stdin, stdout, stderr = ssh.exec_command(move_cmd)
            move_output = stdout.read().decode()
            move_error = stderr.read().decode()

            # Set permissions
            perms_cmd = f"echo '{self.ssh_password}' | sudo -S chown root:ossec {self.cdb_path} && echo '{self.ssh_password}' | sudo -S chmod 640 {self.cdb_path}"
            stdin, stdout, stderr = ssh.exec_command(perms_cmd)
            stdout.read()

            # Verify file was created
            verify_cmd = f"echo '{self.ssh_password}' | sudo -S wc -l {self.cdb_path}"
            stdin, stdout, stderr = ssh.exec_command(verify_cmd)
            verify_output = stdout.read().decode().strip()

            ssh.close()

            print(f"[Wazuh Sync] [OK] Deployed CDB list to {self.cdb_path} ({verify_output})")
            return True

        except Exception as e:
            print(f"[Wazuh Sync] [ERROR] Error deploying CDB list: {e}")
            return False

    def _deploy_rule_overrides(self, rule_suppressions):
        """
        Deploy rule overrides to athena_mute_rules.xml (SEPARATE file)

        This creates rules with level="0" and overwrite="yes" to suppress existing rules.
        Deploys to /var/ossec/etc/rules/athena_mute_rules.xml
        NOT to /var/ossec/etc/rules/local_rules.xml (preserves manual rules)
        """

        # Generate XML
        root = ET.Element('group', name='athena_suppressed,local,')

        for rule_sup in rule_suppressions:
            rule_elem = ET.SubElement(
                root,
                'rule',
                id=str(rule_sup['rule_id']),
                level='0',
                overwrite='yes'
            )

            desc_elem = ET.SubElement(rule_elem, 'description')
            desc_elem.text = f"Suppressed by Athena: {rule_sup['reason']}"

        # Pretty print XML
        xml_str = ET.tostring(root, encoding='unicode')

        # Parse and prettify
        dom = minidom.parseString(xml_str)
        pretty_xml = dom.toprettyxml(indent="  ")

        # Remove XML declaration (Wazuh doesn't like it in rule files)
        pretty_xml = '\n'.join(pretty_xml.split('\n')[1:])

        # Add custom header (NO XML declaration - Wazuh rule files don't need it)
        xml_content = f"""<!-- ============================================================================ -->
<!-- Athena Security Platform - Auto-Generated Mute Rules                        -->
<!-- DO NOT EDIT MANUALLY - Changes will be overwritten                          -->
<!-- ============================================================================ -->
<!-- Generated: {datetime.now().isoformat()} -->
<!-- Total rules: {len(rule_suppressions)} -->
<!-- This file is auto-managed by Athena Suppression Sync Service                -->
<!-- Manual suppression rules should go in: /var/ossec/etc/rules/local_rules.xml -->
<!-- ============================================================================ -->

{pretty_xml}"""

        try:
            ssh = self._create_ssh_connection()

            # Use SFTP + temp file method (more reliable than heredoc)
            tmp_file = '/tmp/athena_mute_rules.xml.tmp'

            # Write to temp file via SFTP
            sftp = ssh.open_sftp()
            with sftp.file(tmp_file, 'w') as f:
                f.write(xml_content)
            sftp.close()

            # Backup existing rules (optional)
            backup_cmd = f"echo '{self.ssh_password}' | sudo -S cp {self.rules_path} {self.rules_path}.bak.$(date +%Y%m%d_%H%M%S) 2>/dev/null || true"
            stdin, stdout, stderr = ssh.exec_command(backup_cmd)
            stdout.read()

            # Move temp file to final location with sudo
            move_cmd = f"echo '{self.ssh_password}' | sudo -S mv {tmp_file} {self.rules_path}"
            stdin, stdout, stderr = ssh.exec_command(move_cmd)
            move_output = stdout.read().decode()
            move_error = stderr.read().decode()

            # Set permissions
            perms_cmd = f"echo '{self.ssh_password}' | sudo -S chown root:ossec {self.rules_path} && echo '{self.ssh_password}' | sudo -S chmod 640 {self.rules_path}"
            stdin, stdout, stderr = ssh.exec_command(perms_cmd)
            stdout.read()

            # Verify file was created
            verify_cmd = f"echo '{self.ssh_password}' | sudo -S wc -l {self.rules_path}"
            stdin, stdout, stderr = ssh.exec_command(verify_cmd)
            verify_output = stdout.read().decode().strip()

            ssh.close()

            print(f"[Wazuh Sync] [OK] Deployed rule overrides to {self.rules_path} ({verify_output})")
            return True

        except Exception as e:
            print(f"[Wazuh Sync] [ERROR] Error deploying rule overrides: {e}")
            return False

    def _compile_and_restart(self):
        """
        Compile CDB lists and restart Wazuh Manager

        Note: Wazuh requires full restart (unlike Suricata which supports reload)
        """

        try:
            ssh = self._create_ssh_connection()

            # Compile CDB lists
            print("[Wazuh Sync] Compiling CDB lists...")
            compile_cmd = f"echo '{self.ssh_password}' | sudo -S /var/ossec/bin/ossec-makelists"
            stdin, stdout, stderr = ssh.exec_command(compile_cmd)
            compile_output = stdout.read().decode()
            compile_error = stderr.read().decode()

            if compile_output:
                print(f"[Wazuh Sync] CDB Compilation output: {compile_output.strip()}")
            if compile_error and 'sudo' not in compile_error.lower():
                print(f"[Wazuh Sync] CDB Compilation warnings: {compile_error.strip()}")

            # Restart Wazuh Manager
            print("[Wazuh Sync] Restarting Wazuh Manager...")
            restart_cmd = f"echo '{self.ssh_password}' | sudo -S systemctl restart wazuh-manager"
            stdin, stdout, stderr = ssh.exec_command(restart_cmd)
            stdout.read()

            # Wait for service to be ready
            print("[Wazuh Sync] Waiting for Wazuh Manager to start...")
            time.sleep(10)

            # Verify service is running
            check_cmd = f"echo '{self.ssh_password}' | sudo -S systemctl is-active wazuh-manager"
            stdin, stdout, stderr = ssh.exec_command(check_cmd)
            status = stdout.read().decode().strip()

            ssh.close()

            if status == 'active':
                print("[Wazuh Sync] [OK] Wazuh Manager restarted successfully")
                return True
            else:
                print(f"[Wazuh Sync] [WARN] Wazuh Manager status: {status}")
                return False

        except Exception as e:
            print(f"[Wazuh Sync] [ERROR] Error restarting Wazuh: {e}")
            return False


# Example usage for testing
if __name__ == '__main__':
    import psycopg2

    # Connect to PostgreSQL
    conn = psycopg2.connect(
        host='localhost',
        database='athena',
        user='postgres',
        password='athena_pass',
        port='5432'
    )

    # Create sync service
    sync_service = WazuhSyncService(conn)

    # Run sync
    result = sync_service.sync_mute_rules()

    print(f"\n{'='*80}")
    print("Wazuh Sync Result:")
    print(f"{'='*80}")
    print(json.dumps(result, indent=2))

    conn.close()
