"""
Wazuh Active Response Deployment Service

Automated deployment of Active Response configuration to Wazuh Manager via SSH.
Extends WazuhSyncService to leverage existing SSH infrastructure.

Author: Athena Security Platform
"""

import psycopg2
import paramiko
import os
import hashlib
import time
from datetime import datetime
import xml.etree.ElementTree as ET
from xml.dom import minidom


class WazuhARDeploymentService:
    """
    Deploys Active Response configuration to Wazuh Manager

    Features:
    - SSH-based deployment
    - Automatic backup before changes
    - Idempotent (safe to run multiple times)
    - Hash-based change detection
    - Comprehensive error handling
    - Rollback on failure
    """

    def __init__(self, db_connection=None):
        self.db = db_connection
        self.ssh_host = os.getenv('WAZUH_MANAGER_HOST') or os.getenv('WAZUH_HOST')
        self.ssh_user = os.getenv('WAZUH_SSH_USER')
        self.ssh_password = os.getenv('WAZUH_SSH_PASSWORD')
        self.ssh_key_path = os.getenv('WAZUH_SSH_KEY_PATH')

        # Wazuh paths
        self.ossec_conf_path = '/var/ossec/etc/ossec.conf'
        self.whitelist_cdb_path = '/var/ossec/etc/lists/athena_ar_whitelist'
        self.backup_dir = f'/var/ossec/backups/ar-deployment-{datetime.now().strftime("%Y%m%d")}'

    def deploy_active_response(self, mode='comprehensive'):
        """
        Main deployment function

        Args:
            mode: 'comprehensive', 'ssh-only', or 'dry-run'

        Returns:
            dict: Deployment result with success status and details
        """
        print("=" * 80)
        print("Athena Active Response Deployment")
        print("=" * 80)
        print(f"Target Wazuh Manager: {self.ssh_host}")
        print(f"SSH User: {self.ssh_user}")
        print(f"Deployment Mode: {mode}")
        print("=" * 80)

        start_time = time.time()

        try:
            # Step 1: Verify SSH connectivity
            print("\n[1/8] Verifying SSH connectivity...")
            ssh = self._create_ssh_connection()
            print("[OK] SSH connection established")

            # Step 2: Backup current configuration
            print("\n[2/8] Backing up ossec.conf...")
            backup_path = self._backup_ossec_conf(ssh)
            print(f"[OK] Backup created: {backup_path}")

            # Step 3: Deploy whitelist CDB
            print("\n[3/8] Deploying whitelist CDB...")
            self._deploy_whitelist_cdb(ssh)
            print("[OK] Whitelist deployed and compiled")

            # Step 4: Check if AR already configured
            print("\n[4/8] Checking existing AR configuration...")
            already_configured = self._check_ar_configured(ssh)

            if already_configured:
                print("[INFO] Active Response already configured")
                print("[INFO] Updating configuration...")
            else:
                print("[INFO] Active Response not configured, deploying...")

            # Step 5: Inject AR configuration into ossec.conf
            print("\n[5/8] Injecting AR configuration into ossec.conf...")
            self._inject_ar_config(ssh, mode)
            print("[OK] AR configuration injected")

            # Step 6: Validate configuration
            print("\n[6/8] Validating configuration syntax...")
            self._validate_ossec_conf(ssh)
            print("[OK] Configuration syntax valid")

            # Step 7: Restart Wazuh Manager
            print("\n[7/8] Restarting Wazuh Manager...")
            self._restart_wazuh_manager(ssh)
            print("[OK] Wazuh Manager restarted")

            # Step 8: Verify AR is enabled
            print("\n[8/8] Verifying Active Response is enabled...")
            self._verify_ar_enabled(ssh)
            print("[OK] Active Response is enabled and functional")

            ssh.close()

            duration = time.time() - start_time
            print("\n" + "=" * 80)
            print(f"[SUCCESS] Active Response deployed in {duration:.2f} seconds")
            print("=" * 80)

            print("\nNext steps:")
            print("  1. Check Wazuh logs: sudo tail -50 /var/ossec/logs/ossec.log")
            print("  2. View AR config: sudo grep -A 5 'active-response' /var/ossec/etc/ossec.conf")
            print("  3. Test with SSH brute force simulation")

            return {
                'success': True,
                'mode': mode,
                'duration_seconds': duration,
                'backup_path': backup_path,
                'timestamp': datetime.now().isoformat()
            }

        except Exception as e:
            print(f"\n[ERROR] Deployment failed: {e}")
            print("[INFO] Rolling back changes...")

            try:
                self._rollback(ssh, backup_path)
                print("[OK] Rollback completed")
            except Exception as rollback_error:
                print(f"[ERROR] Rollback failed: {rollback_error}")

            return {
                'success': False,
                'error': str(e),
                'timestamp': datetime.now().isoformat()
            }

    def _create_ssh_connection(self):
        """
        Create SSH connection to Wazuh Manager

        Supports both Ed25519 (recommended) and RSA keys for production deployments.
        """
        ssh = paramiko.SSHClient()
        ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())

        # Try SSH key first, then password
        if self.ssh_key_path and os.path.exists(self.ssh_key_path):
            try:
                # Try Ed25519 key first (modern, recommended), then RSA fallback
                try:
                    private_key = paramiko.Ed25519Key.from_private_key_file(self.ssh_key_path)
                    print("[AR Deploy] Using Ed25519 key authentication")
                except Exception:
                    private_key = paramiko.RSAKey.from_private_key_file(self.ssh_key_path)
                    print("[AR Deploy] Using RSA key authentication")

                ssh.connect(self.ssh_host, username=self.ssh_user, pkey=private_key, timeout=30)
                print(f"[AR Deploy] SSH key auth successful to {self.ssh_host}")
                return ssh
            except Exception as e:
                print(f"[WARN] SSH key auth failed ({e}), trying password...")

        # Password authentication
        ssh.connect(self.ssh_host, username=self.ssh_user, password=self.ssh_password, timeout=30)
        return ssh

    def _backup_ossec_conf(self, ssh):
        """Backup ossec.conf before making changes"""
        # Create backup directory
        stdin, stdout, stderr = ssh.exec_command(f'sudo mkdir -p {self.backup_dir}')
        stdout.channel.recv_exit_status()

        # Backup ossec.conf
        backup_file = f'{self.backup_dir}/ossec.conf.backup'
        stdin, stdout, stderr = ssh.exec_command(f'sudo cp {self.ossec_conf_path} {backup_file}')
        exit_status = stdout.channel.recv_exit_status()

        if exit_status != 0:
            raise Exception(f"Backup failed: {stderr.read().decode()}")

        # Verify backup exists
        stdin, stdout, stderr = ssh.exec_command(f'sudo test -f {backup_file} && echo "OK"')
        result = stdout.read().decode().strip()

        if result != "OK":
            raise Exception("Backup verification failed")

        return backup_file

    def _deploy_whitelist_cdb(self, ssh):
        """Deploy whitelist CDB list"""
        # Fetch whitelist from database
        whitelist_content = self._generate_whitelist_content()

        # Create temp file locally
        temp_file = '/tmp/athena_ar_whitelist'
        with open(temp_file, 'w') as f:
            f.write(whitelist_content)

        # Upload via SFTP
        sftp = ssh.open_sftp()
        try:
            sftp.put(temp_file, '/tmp/athena_ar_whitelist')
            sftp.close()
        except Exception as e:
            sftp.close()
            raise Exception(f"SFTP upload failed: {e}")

        # Move to correct location with sudo
        stdin, stdout, stderr = ssh.exec_command(f'sudo mv /tmp/athena_ar_whitelist {self.whitelist_cdb_path}')
        exit_status = stdout.channel.recv_exit_status()

        if exit_status != 0:
            raise Exception(f"Failed to move whitelist: {stderr.read().decode()}")

        # Set permissions
        stdin, stdout, stderr = ssh.exec_command(f'sudo chown root:wazuh {self.whitelist_cdb_path}')
        stdout.channel.recv_exit_status()

        stdin, stdout, stderr = ssh.exec_command(f'sudo chmod 640 {self.whitelist_cdb_path}')
        stdout.channel.recv_exit_status()

        # Compile CDB
        stdin, stdout, stderr = ssh.exec_command('sudo /var/ossec/bin/ossec-makelists')
        output = stdout.read().decode()
        exit_status = stdout.channel.recv_exit_status()

        if exit_status != 0 or 'error' in output.lower():
            raise Exception(f"CDB compilation failed: {stderr.read().decode()}")

        # Clean up temp file
        os.remove(temp_file)

    def _generate_whitelist_content(self):
        """Generate whitelist content from database"""
        if not self.db:
            # Fallback to default whitelist
            return """# Athena Active Response Whitelist - Critical Infrastructure
# Format: IP_ADDRESS:DESCRIPTION
172.16.1.87:Wazuh Manager Primary
172.16.1.93:Wazuh Manager Backup
127.0.0.1:Localhost
::1:Localhost IPv6
"""

        cursor = self.db.cursor()
        cursor.execute("""
            SELECT ip_address, description
            FROM ar_whitelist
            WHERE approval_status = 'approved'
            ORDER BY created_at ASC
        """)

        entries = cursor.fetchall()
        cursor.close()

        content = "# " + "=" * 76 + "\n"
        content += "# Athena Active Response Whitelist - Critical Infrastructure\n"
        content += "# Format: IP_ADDRESS:DESCRIPTION\n"
        content += "# These IPs will NEVER be blocked by Active Response\n"
        content += "# Managed by Athena Security Platform\n"
        content += "# " + "=" * 76 + "\n"

        for ip_address, description in entries:
            content += f"{ip_address}:{description}\n"

        return content

    def _check_ar_configured(self, ssh):
        """Check if Active Response is already configured"""
        stdin, stdout, stderr = ssh.exec_command('sudo grep -q "ATHENA ACTIVE RESPONSE" /var/ossec/etc/ossec.conf && echo "CONFIGURED"')
        result = stdout.read().decode().strip()
        return result == "CONFIGURED"

    def _inject_ar_config(self, ssh, mode):
        """Inject Active Response configuration into ossec.conf"""
        # Fetch current ossec.conf
        sftp = ssh.open_sftp()
        remote_file = sftp.open(self.ossec_conf_path, 'r')
        ossec_conf_content = remote_file.read().decode()
        remote_file.close()
        sftp.close()

        # Check if already configured
        if 'ATHENA ACTIVE RESPONSE CONFIGURATION' in ossec_conf_content:
            # Remove old configuration
            print("[INFO] Removing old AR configuration...")
            ossec_conf_content = self._remove_old_ar_config(ossec_conf_content)

        # Generate AR configuration
        ar_config = self._generate_ar_config(mode)

        # Insert before closing </ossec_config>
        insertion_point = ossec_conf_content.rfind('</ossec_config>')

        if insertion_point == -1:
            raise Exception("Could not find </ossec_config> tag in ossec.conf")

        new_content = (
            ossec_conf_content[:insertion_point] +
            "\n" + ar_config + "\n" +
            ossec_conf_content[insertion_point:]
        )

        # Write to temp file
        temp_file = '/tmp/ossec.conf.new'
        with open(temp_file, 'w') as f:
            f.write(new_content)

        # Upload via SFTP
        sftp = ssh.open_sftp()
        sftp.put(temp_file, '/tmp/ossec.conf.new')
        sftp.close()

        # Replace ossec.conf with sudo
        stdin, stdout, stderr = ssh.exec_command('sudo mv /tmp/ossec.conf.new /var/ossec/etc/ossec.conf')
        exit_status = stdout.channel.recv_exit_status()

        if exit_status != 0:
            raise Exception(f"Failed to update ossec.conf: {stderr.read().decode()}")

        # Set correct permissions
        stdin, stdout, stderr = ssh.exec_command('sudo chown root:wazuh /var/ossec/etc/ossec.conf')
        stdout.channel.recv_exit_status()

        stdin, stdout, stderr = ssh.exec_command('sudo chmod 640 /var/ossec/etc/ossec.conf')
        stdout.channel.recv_exit_status()

        os.remove(temp_file)

    def _remove_old_ar_config(self, content):
        """Remove old AR configuration from ossec.conf"""
        lines = content.split('\n')
        new_lines = []
        skip = False

        for line in lines:
            if 'ATHENA ACTIVE RESPONSE CONFIGURATION' in line:
                skip = True
            elif skip and '</active-response>' in line:
                skip = False
                continue
            elif not skip:
                new_lines.append(line)

        return '\n'.join(new_lines)

    def _generate_ar_config(self, mode):
        """Generate Active Response XML configuration"""
        config = """  <!-- ====================================================================
       ATHENA ACTIVE RESPONSE CONFIGURATION
       Built-in scripts for automated incident response
       Generated by Athena Security Platform
       ==================================================================== -->

  <!-- Command: Firewall Drop (Linux/Unix) -->
  <command>
    <name>firewall-drop</name>
    <executable>firewall-drop</executable>
    <timeout_allowed>yes</timeout_allowed>
  </command>

  <!-- Command: Firewall Drop (Windows) -->
  <command>
    <name>win-firewall-drop</name>
    <executable>netsh.exe</executable>
    <timeout_allowed>yes</timeout_allowed>
  </command>

  <!-- Command: Disable User Account -->
  <command>
    <name>disable-account</name>
    <executable>disable-account</executable>
    <timeout_allowed>yes</timeout_allowed>
  </command>

  <!-- ====================================================================
       ACTIVE RESPONSE RULES
       Define which alerts trigger which automated responses
       ==================================================================== -->

"""

        if mode in ['comprehensive', 'ssh-only']:
            # SSH Brute Force Protection
            config += """  <!-- AR1: SSH Brute Force Protection (Linux/Unix) -->
  <active-response>
    <disabled>no</disabled>
    <command>firewall-drop</command>
    <location>local</location>
    <rules_id>5763</rules_id>
    <timeout>1800</timeout>
    <repeated_offenders>3600,7200,14400</repeated_offenders>
  </active-response>

  <!-- AR2: SSH Brute Force Protection (Windows) -->
  <active-response>
    <disabled>no</disabled>
    <command>win-firewall-drop</command>
    <location>local</location>
    <rules_id>5763</rules_id>
    <timeout>1800</timeout>
    <repeated_offenders>3600,7200,14400</repeated_offenders>
  </active-response>

"""

        if mode == 'comprehensive':
            # Web Attack Blocking
            config += """  <!-- AR3: Web Attack Blocking (High Severity) -->
  <active-response>
    <disabled>no</disabled>
    <command>firewall-drop</command>
    <location>local</location>
    <rules_group>web,attack</rules_group>
    <level>12</level>
    <timeout>3600</timeout>
  </active-response>

  <!-- AR4: Network Scanning Detection -->
  <active-response>
    <disabled>no</disabled>
    <command>firewall-drop</command>
    <location>local</location>
    <rules_id>5402,5403,5404</rules_id>
    <timeout>2400</timeout>
  </active-response>

  <!-- AR5: Multiple Failed Login - Account Lockout -->
  <active-response>
    <disabled>no</disabled>
    <command>disable-account</command>
    <location>local</location>
    <rules_id>5503,5551</rules_id>
    <timeout>600</timeout>
  </active-response>

"""

        return config

    def _validate_ossec_conf(self, ssh):
        """Validate ossec.conf syntax"""
        stdin, stdout, stderr = ssh.exec_command('sudo /var/ossec/bin/wazuh-logtest-legacy -t 2>&1')
        output = stdout.read().decode()
        exit_status = stdout.channel.recv_exit_status()

        if exit_status != 0 or 'error' in output.lower():
            raise Exception(f"Configuration validation failed: {output}")

    def _restart_wazuh_manager(self, ssh):
        """Restart Wazuh Manager service"""
        stdin, stdout, stderr = ssh.exec_command('sudo systemctl restart wazuh-manager')
        exit_status = stdout.channel.recv_exit_status()

        if exit_status != 0:
            raise Exception(f"Failed to restart Wazuh Manager: {stderr.read().decode()}")

        # Wait for service to stabilize
        time.sleep(5)

        # Verify service is running
        stdin, stdout, stderr = ssh.exec_command('sudo systemctl is-active wazuh-manager')
        status = stdout.read().decode().strip()

        if status != 'active':
            raise Exception(f"Wazuh Manager failed to start: {status}")

    def _verify_ar_enabled(self, ssh):
        """Verify Active Response is enabled and functional"""
        stdin, stdout, stderr = ssh.exec_command('sudo grep -i "active.response.*enabled" /var/ossec/logs/ossec.log | tail -1')
        output = stdout.read().decode()

        if 'enabled' not in output.lower():
            raise Exception("Active Response not enabled in Wazuh logs")

        # Check for AR commands loaded
        stdin, stdout, stderr = ssh.exec_command('sudo grep -i "active response command.*successfully loaded" /var/ossec/logs/ossec.log | tail -5')
        output = stdout.read().decode()

        if not output or 'firewall-drop' not in output:
            raise Exception("Active Response commands not loaded properly")

    def _rollback(self, ssh, backup_path):
        """Rollback to backup configuration"""
        stdin, stdout, stderr = ssh.exec_command(f'sudo cp {backup_path} {self.ossec_conf_path}')
        exit_status = stdout.channel.recv_exit_status()

        if exit_status != 0:
            raise Exception(f"Rollback failed: {stderr.read().decode()}")

        # Restart to apply rollback
        stdin, stdout, stderr = ssh.exec_command('sudo systemctl restart wazuh-manager')
        stdout.channel.recv_exit_status()
