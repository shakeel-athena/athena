"""
Athena Security Platform - Integrations Package
Handles synchronization with external security platforms (Suricata, Wazuh, Logstash)
"""

from .suricata_sync import SuricataSyncService

__all__ = ['SuricataSyncService']
