"""
Database Configuration and Connection Management

Handles database connection pooling, RBAC integration, and connection lifecycle.
"""

import os
import sys
import psycopg2
from psycopg2.extras import RealDictCursor
from psycopg2 import pool
import logging
from flask import g
from typing import Optional

# Add the backend root to Python path for imports
BACKEND_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), "../.."))
if BACKEND_ROOT not in sys.path:
    sys.path.insert(0, BACKEND_ROOT)

# Try to import enhanced database connection (optional - fallback available)
try:
    from database.connection import DatabaseConnection, DatabaseConfig
    ENHANCED_DB_AVAILABLE = True
except ImportError:
    # Enhanced database module not available, will use fallback
    DatabaseConnection = None
    DatabaseConfig = None
    ENHANCED_DB_AVAILABLE = False

from utils.rbac import RBACManager

logger = logging.getLogger(__name__)

# Global connection pool variables
_db_pool = None
_db_connection = None


class DatabaseWrapper:
    """Enhanced wrapper around psycopg2 connection to match RBAC's expected interface"""
    
    def __init__(self, conn):
        self.conn = conn
        self.cursor_factory = RealDictCursor
    
    def execute(self, query, params=None):
        """Execute query and return cursor with RealDictCursor"""
        cursor = self.conn.cursor(cursor_factory=RealDictCursor)
        if params:
            cursor.execute(query, params)
        else:
            cursor.execute(query)
        return cursor
    
    def commit(self):
        """Commit transaction"""
        self.conn.commit()
    
    def rollback(self):
        """Rollback transaction"""
        self.conn.rollback()
    
    def close(self):
        """Close connection"""
        self.conn.close()


def get_db_connection():
    """Get database connection from enhanced pool"""
    global _db_pool, _db_connection

    # If enhanced database is not available, use fallback directly
    if not ENHANCED_DB_AVAILABLE:
        return get_fallback_db_connection()

    # Initialize enhanced database connection if not already done
    if _db_connection is None:
        try:
            # Create database configuration from environment (now handles both POSTGRES_* and DB_*)
            db_config = DatabaseConfig()
            
            # Configure connection pool settings
            db_config.SQLALCHEMY_POOL_SIZE = int(os.getenv('DB_POOL_SIZE', '10'))
            db_config.SQLALCHEMY_MAX_OVERFLOW = int(os.getenv('DB_MAX_OVERFLOW', '20'))
            db_config.SQLALCHEMY_POOL_TIMEOUT = int(os.getenv('DB_POOL_TIMEOUT', '30'))
            db_config.SQLALCHEMY_POOL_RECYCLE = int(os.getenv('DB_POOL_RECYCLE', '3600'))
            db_config.CONNECT_TIMEOUT = int(os.getenv('DB_CONNECT_TIMEOUT', '10'))
            db_config.STATEMENT_TIMEOUT = int(os.getenv('DB_STATEMENT_TIMEOUT', '30000'))
            
            # Initialize enhanced database connection
            _db_connection = DatabaseConnection(db_config)
            _db_connection.initialize()
            
            logger.info(f"Enhanced database connection pool initialized with size: {db_config.SQLALCHEMY_POOL_SIZE}")
            
        except Exception as e:
            logger.error(f"Failed to initialize enhanced database connection: {e}")
            # Fallback to basic psycopg2 pool
            return get_fallback_db_connection()
    
    # Try to get connection from enhanced pool first
    try:
        session = _db_connection.get_session()
        # Create a wrapper that matches the expected interface
        # Get the raw dbapi connection from SQLAlchemy
        sa_conn = session.connection()
        raw_conn = sa_conn.connection.dbapi_connection
        return DatabaseWrapper(raw_conn)
    except Exception as e:
        logger.error(f"Failed to get database connection from enhanced pool: {e}")
        # Fallback to basic psycopg2 pool
        return get_fallback_db_connection()


def get_fallback_db_connection():
    """Fallback database connection using basic psycopg2 pool"""
    global _db_pool

    if _db_pool is None:
        # Use standardized database configuration for fallback (no hardcoded defaults)
        db_config = {
            'host': os.getenv('POSTGRES_HOST') or os.getenv('DB_HOST'),
            'port': os.getenv('POSTGRES_PORT') or os.getenv('DB_PORT') or '5432',
            'database': os.getenv('POSTGRES_DB') or os.getenv('DB_NAME'),
            'user': os.getenv('POSTGRES_USER') or os.getenv('DB_USER'),
            'password': os.getenv('POSTGRES_PASSWORD') or os.getenv('DB_PASSWORD'),
        }
        try:
            # Enhanced pool configuration for fallback
            minconn = int(os.getenv('DB_POOL_MIN', '2'))
            maxconn = int(os.getenv('DB_POOL_MAX', '10'))
            _db_pool = psycopg2.pool.ThreadedConnectionPool(minconn, maxconn, **db_config)
            logger.info(f"Fallback database connection pool initialized with min={minconn}, max={maxconn}")
        except Exception as e:
            logger.error(f"Failed to create fallback database connection pool: {e}")
            return None
    
    try:
        conn = _db_pool.getconn()
        return DatabaseWrapper(conn)
    except Exception as e:
        logger.error(f"Failed to get database connection from fallback pool: {e}")
        return None


def setup_db_and_rbac():
    """Setup database connection and RBAC for each request"""
    try:
        g.db = get_db_connection()
        if g.db:
            # Create RBAC instance with this connection
            g.rbac = RBACManager(g.db)
        else:
            g.rbac = None
            logger.warning("Database connection not available for request")
    except Exception as e:
        logger.error(f"Failed to setup database connection: {e}")
        g.db = None
        g.rbac = None


def teardown_db(exception):
    """Close database connection after each request"""
    db = getattr(g, 'db', None)
    if db is not None and hasattr(db, 'conn'):
        try:
            # Return connection to appropriate pool
            if _db_connection is not None:
                # Enhanced pool - session will be automatically closed
                pass
            elif _db_pool is not None:
                # Fallback pool
                _db_pool.putconn(db.conn)
        except Exception as e:
            logger.error(f"Failed to return connection to pool: {e}")


def get_db_pool_stats():
    """Get database connection pool statistics"""
    stats = {
        'enhanced_pool': {
            'initialized': _db_connection is not None,
            'pool_size': os.getenv('DB_POOL_SIZE', '10'),
            'max_overflow': os.getenv('DB_MAX_OVERFLOW', '20'),
            'pool_timeout': os.getenv('DB_POOL_TIMEOUT', '30'),
            'pool_recycle': os.getenv('DB_POOL_RECYCLE', '3600')
        },
        'fallback_pool': {
            'initialized': _db_pool is not None,
            'min_connections': os.getenv('DB_POOL_MIN', '2'),
            'max_connections': os.getenv('DB_POOL_MAX', '10')
        }
    }
    
    # Get actual pool stats if available
    if _db_pool is not None:
        try:
            stats['fallback_pool']['current_connections'] = len(_db_pool._pool)
            stats['fallback_pool']['available_connections'] = _db_pool._pool.qsize()
        except Exception as e:
            logger.warning(f"Could not get fallback pool stats: {e}")
    
    return stats


def cleanup_database_connections():
    """Cleanup database connections on shutdown"""
    global _db_pool, _db_connection
    
    try:
        if _db_connection is not None:
            _db_connection.close()
            _db_connection = None
            logger.info("Enhanced database connection closed")
        
        if _db_pool is not None:
            _db_pool.closeall()
            _db_pool = None
            logger.info("Fallback database connection pool closed")
            
    except Exception as e:
        logger.error(f"Error cleaning up database connections: {e}")
