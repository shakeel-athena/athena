"""
Core Module

Contains core application functionality including database and AWS configuration.
"""

from .database import (
    get_db_connection,
    setup_db_and_rbac,
    teardown_db,
    get_db_pool_stats,
    cleanup_database_connections
)

from .aws_config import (
    get_aws_session,
    validate_aws_configuration,
    get_firewall_manager,
    get_waf_signature_manager,
    get_geo_manager,
    AWSConfigurationError
)

__all__ = [
    # Database functions
    'get_db_connection',
    'setup_db_and_rbac', 
    'teardown_db',
    'get_db_pool_stats',
    'cleanup_database_connections',
    
    # AWS functions
    'get_aws_session',
    'validate_aws_configuration',
    'get_firewall_manager',
    'get_waf_signature_manager',
    'get_geo_manager',
    'AWSConfigurationError'
]
