"""
AWS Configuration and Session Management

Handles AWS session creation, credential validation, and service initialization.
"""

import os
import boto3
import logging
from typing import Dict, Any, Optional

logger = logging.getLogger(__name__)


class AWSConfigurationError(Exception):
    """Custom exception for AWS configuration errors"""
    pass


def get_aws_session():
    """Enhanced AWS session with comprehensive error handling and validation"""
    try:
        aws_region = os.getenv("AWS_REGION", "us-east-2")
        access_key = os.getenv("AWS_ACCESS_KEY_ID")
        secret_key = os.getenv("AWS_SECRET_ACCESS_KEY")
        session_token = os.getenv("AWS_SESSION_TOKEN")
        
        logger.info(f"Initializing AWS session for region: {aws_region}")
        
        # Enhanced credential validation with better error messages
        if access_key and secret_key:
            access_key = access_key.strip()
            secret_key = secret_key.strip()
            
            if not access_key or not secret_key:
                raise AWSConfigurationError("AWS credentials provided but are empty or contain only whitespace")
            
            # Validate AWS access key format (should start with specific prefixes)
            if not (access_key.startswith('AKIA') or access_key.startswith('ASIA')):
                logger.warning(f"AWS access key ID format may be invalid: {access_key[:8]}...")
            
            logger.info("Using explicit AWS credentials from environment")
            
            # Create session and validate immediately
            session = boto3.Session(
                aws_access_key_id=access_key,
                aws_secret_access_key=secret_key,
                aws_session_token=session_token.strip() if session_token else None,
                region_name=aws_region,
            )
            
            # Validate the session works
            try:
                sts_client = session.client('sts')
                identity = sts_client.get_caller_identity()
                logger.info(f"Successfully validated AWS credentials for account: {identity.get('Account', 'unknown')}")
                return session
            except Exception as validation_error:
                raise AWSConfigurationError(f"AWS credentials validation failed: {validation_error}")
        
        # Try profile-based authentication with enhanced error handling
        aws_profile = os.getenv("AWS_PROFILE")
        if aws_profile:
            logger.info(f"Attempting to use AWS profile: {aws_profile}")
            try:
                # Check if profile exists in AWS config
                import botocore
                session = boto3.Session(profile_name=aws_profile, region_name=aws_region)
                
                # Test the session by attempting to get caller identity
                sts_client = session.client('sts')
                identity = sts_client.get_caller_identity()
                logger.info(f"Successfully validated AWS profile '{aws_profile}' for account: {identity.get('Account', 'unknown')}")
                return session
                
            except botocore.exceptions.ProfileNotFound:
                logger.error(f"AWS profile '{aws_profile}' not found in AWS configuration files")
                raise AWSConfigurationError(f"AWS profile '{aws_profile}' not found. Please check ~/.aws/config and ~/.aws/credentials files.")
            except Exception as profile_error:
                logger.error(f"Failed to use AWS profile '{aws_profile}': {profile_error}")
                raise AWSConfigurationError(f"AWS profile '{aws_profile}' validation failed: {profile_error}")
        
        # Default to environment-based authentication with comprehensive testing
        logger.info("Attempting to use default AWS credential chain (environment variables, EC2 instance profile, ECS task role, etc.)")
        try:
            session = boto3.Session(region_name=aws_region)
            
            # Test the session with multiple attempts for different credential sources
            sts_client = session.client('sts', config=botocore.config.Config(
                retries={'max_attempts': 3, 'mode': 'adaptive'}
            ))
            
            identity = sts_client.get_caller_identity()
            logger.info(f"Successfully validated default AWS credentials for account: {identity.get('Account', 'unknown')}")
            return session
            
        except botocore.exceptions.NoCredentialsError:
            logger.error("No AWS credentials found in any location (environment, instance profile, etc.)")
            raise AWSConfigurationError("No AWS credentials found. Please set AWS_ACCESS_KEY_ID/AWS_SECRET_ACCESS_KEY, AWS_PROFILE, or configure IAM role.")
        except botocore.exceptions.CredentialRetrievalError as e:
            logger.error(f"AWS credential retrieval failed: {e}")
            raise AWSConfigurationError(f"AWS credential retrieval failed: {e}")
        except Exception as default_error:
            logger.error(f"Default AWS credential chain validation failed: {default_error}")
            raise AWSConfigurationError(f"AWS credentials validation failed: {default_error}")
            
    except AWSConfigurationError:
        # Re-raise our custom errors
        raise
    except Exception as e:
        logger.error(f"Unexpected error creating AWS session: {e}")
        raise AWSConfigurationError(f"Failed to create AWS session: {e}")


def validate_aws_configuration() -> Dict[str, Any]:
    """Validate AWS configuration and return status"""
    try:
        session = get_aws_session()
        sts_client = session.client('sts')
        identity = sts_client.get_caller_identity()
        
        return {
            "valid": True,
            "account_id": identity.get('Account'),
            "user_id": identity.get('UserId'),
            "arn": identity.get('Arn'),
            "region": session.region_name
        }
    except AWSConfigurationError as e:
        return {
            "valid": False,
            "error": str(e)
        }
    except Exception as e:
        return {
            "valid": False,
            "error": f"Unexpected validation error: {e}"
        }


# Cached manager instances for better performance
_firewall_manager = None
_waf_signature_manager = None
_geo_manager = None


def get_firewall_manager():
    """Get FirewallIPBlockingManager instance (cached)."""
    global _firewall_manager
    if _firewall_manager is None:
        from models.Firewall_IP_Blocking import FirewallIPBlockingManager
        session = get_aws_session()
        rule_group_name = os.getenv("FIREWALL_RULE_GROUP", "allow-ingress")
        aws_region = os.getenv("AWS_REGION", "us-east-2")
        _firewall_manager = FirewallIPBlockingManager(session=session, region_name=aws_region, rule_group_name=rule_group_name)
    return _firewall_manager


def get_waf_signature_manager():
    """Get WAFSignatureBlockingManager instance (cached)."""
    global _waf_signature_manager
    if _waf_signature_manager is None:
        from response.models.WAF_Signature_Blocking import WAFSignatureBlockingManager
        session = get_aws_session()
        wafv2_client = session.client('wafv2')
        web_acl_name = os.getenv("WAF_WEB_ACL")
        _waf_signature_manager = WAFSignatureBlockingManager(
            wafv2_client=wafv2_client,
            scope=os.getenv("AWS_SCOPE", "REGIONAL"),
            web_acl_name=web_acl_name
        )
    return _waf_signature_manager


def get_geo_manager():
    """Get NetworkFirewallGeoBlockingManager instance (cached)."""
    global _geo_manager
    if _geo_manager is None:
        try:
            from models.NF_geo_blocking import NetworkFirewallGeoBlockingManager
            session = get_aws_session()
            _geo_manager = NetworkFirewallGeoBlockingManager(session.client("network-firewall"), "geo-restrictions")
        except Exception as e:
            logger.error(f"Error initializing geo manager: {e}")
            return None
    return _geo_manager
