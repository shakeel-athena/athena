"""
Threat Scoring Engine for Active Response Dashboard

Calculates comprehensive threat scores based on:
1. Attack Frequency (40%)
2. Rule Severity (30%)
3. IP Reputation (20%) - AbuseIPDB integration
4. Attack Velocity (10%)

Implements Risk-Based Alerting (RBA) framework used by
industry-leading SIEM platforms (Splunk, ArcSight, Sentinel)
"""

import logging
import os
import requests
from datetime import datetime

logger = logging.getLogger(__name__)

# AbuseIPDB configuration
ABUSEIPDB_API_KEY = os.getenv('ABUSEIPDB_API_KEY', '')
ABUSEIPDB_ENABLED = bool(ABUSEIPDB_API_KEY)


def get_abuseipdb_score(ip_address, max_age_days=90):
    """
    Get IP reputation score from AbuseIPDB

    Args:
        ip_address (str): IP address to check
        max_age_days (int): Maximum age of reports to consider

    Returns:
        dict: {
            'confidence_score': int (0-100),
            'abuse_confidence': int,
            'country_code': str,
            'usage_type': str,
            'is_whitelisted': bool,
            'total_reports': int
        }
    """
    if not ABUSEIPDB_ENABLED:
        logger.debug("AbuseIPDB API key not configured, skipping reputation check")
        return {
            'confidence_score': 50,  # Default neutral score
            'abuse_confidence': 0,
            'country_code': 'Unknown',
            'usage_type': 'Unknown',
            'is_whitelisted': False,
            'total_reports': 0,
            'source': 'default'
        }

    try:
        url = 'https://api.abuseipdb.com/api/v2/check'
        headers = {
            'Accept': 'application/json',
            'Key': ABUSEIPDB_API_KEY
        }
        params = {
            'ipAddress': ip_address,
            'maxAgeInDays': max_age_days,
            'verbose': True
        }

        response = requests.get(url, headers=headers, params=params, timeout=10)
        response.raise_for_status()

        data = response.json().get('data', {})

        return {
            'confidence_score': data.get('abuseConfidenceScore', 0),
            'abuse_confidence': data.get('abuseConfidenceScore', 0),
            'country_code': data.get('countryCode', 'Unknown'),
            'usage_type': data.get('usageType', 'Unknown'),
            'is_whitelisted': data.get('isWhitelisted', False),
            'total_reports': data.get('totalReports', 0),
            'is_tor': data.get('isTor', False),
            'domain': data.get('domain', ''),
            'isp': data.get('isp', 'Unknown'),
            'source': 'abuseipdb'
        }

    except requests.exceptions.RequestException as e:
        logger.error(f"AbuseIPDB API error for {ip_address}: {str(e)}")
        return {
            'confidence_score': 50,
            'abuse_confidence': 0,
            'country_code': 'Unknown',
            'usage_type': 'Unknown',
            'is_whitelisted': False,
            'total_reports': 0,
            'source': 'error'
        }


def calculate_frequency_score(block_count, max_blocks=20):
    """
    Calculate frequency score based on number of blocks

    Args:
        block_count (int): Number of AR blocks from this IP
        max_blocks (int): Threshold for maximum score

    Returns:
        float: Score 0-40 points
    """
    # Linear scaling: 1 block = 2 points, 20+ blocks = 40 points
    score = min(40, (block_count / max_blocks) * 40)
    return round(score, 1)


def calculate_severity_score(rules_triggered, unique_rules_count):
    """
    Calculate severity score based on rules triggered

    Args:
        rules_triggered (list): List of rule IDs that triggered
        unique_rules_count (int): Number of distinct rules

    Returns:
        float: Score 0-30 points
    """
    # Severity weights for common rules
    severity_map = {
        '5710': 5,    # SSH invalid user - Low/Medium
        '5711': 6,    # SSH failed auth - Medium
        '5763': 15,   # SSH brute force - High
        '5712': 20,   # Multiple failed logins - Critical
        '31103': 18,  # Web attack - High
        '31106': 20,  # Command injection - Critical
        '31151': 22,  # Shell access attempt - Critical
        '5401': 3,    # Port scan - Low
        '5402': 5,    # Multiple connections - Medium
        '5403': 7,    # Nmap scan - Medium
        '510': 25,    # Suspicious service - Critical
        '554': 20,    # Scheduled task - Critical
        '5503': 10,   # Multiple failed logins - Medium
        '5551': 15,   # Authentication failures - High
    }

    # Get maximum severity from triggered rules
    max_rule_severity = 0
    for rule in rules_triggered:
        rule_severity = severity_map.get(str(rule), 5)  # Default 5 if unknown
        max_rule_severity = max(max_rule_severity, rule_severity)

    # Add bonus points for attacking multiple vectors (breadth of attack)
    breadth_bonus = min(10, unique_rules_count * 2)

    total_severity = max_rule_severity + breadth_bonus

    return round(min(30, total_severity), 1)


def calculate_reputation_score(ip_reputation_data):
    """
    Calculate reputation score from AbuseIPDB data

    Args:
        ip_reputation_data (dict): AbuseIPDB response data

    Returns:
        float: Score 0-20 points
    """
    confidence = ip_reputation_data.get('confidence_score', 0)

    # AbuseIPDB returns 0-100 confidence, normalize to 0-20
    score = (confidence / 100) * 20

    # Bonus points for specific indicators
    if ip_reputation_data.get('is_tor', False):
        score += 5  # TOR exit node = higher risk

    if ip_reputation_data.get('total_reports', 0) > 10:
        score += 3  # Well-known malicious IP

    # Penalty for whitelisted IPs
    if ip_reputation_data.get('is_whitelisted', False):
        score = max(0, score - 10)

    return round(min(20, score), 1)


def calculate_velocity_score(attack_velocity):
    """
    Calculate velocity score based on attack speed (events per minute)

    Args:
        attack_velocity (float): Events per minute

    Returns:
        float: Score 0-10 points
    """
    if attack_velocity >= 10:
        return 10.0  # Very fast attack (10+ events/min)
    elif attack_velocity >= 5:
        return 8.0   # Fast attack (5-10 events/min)
    elif attack_velocity >= 2:
        return 6.0   # Moderate attack (2-5 events/min)
    elif attack_velocity >= 1:
        return 4.0   # Slow attack (1-2 events/min)
    elif attack_velocity >= 0.5:
        return 2.0   # Very slow attack
    else:
        return 1.0   # Minimal activity


def calculate_attack_velocity(first_seen, last_seen, event_count):
    """
    Calculate attack velocity (events per minute)

    Args:
        first_seen (str or datetime): First event timestamp
        last_seen (str or datetime): Last event timestamp
        event_count (int): Total number of events

    Returns:
        float: Events per minute
    """
    try:
        if isinstance(first_seen, str):
            first_seen = datetime.fromisoformat(first_seen.replace('Z', '+00:00'))

        if isinstance(last_seen, str):
            last_seen = datetime.fromisoformat(last_seen.replace('Z', '+00:00'))

        duration = (last_seen - first_seen).total_seconds() / 60  # minutes

        if duration == 0:
            # All events in same second = instant attack
            return float(event_count)
        else:
            return event_count / duration

    except Exception as e:
        logger.error(f"Error calculating velocity: {str(e)}")
        return 0.0


def calculate_threat_score(incident_data, include_reputation=True):
    """
    Calculate comprehensive threat score (0-100)

    Scoring Formula:
    - Frequency Score (40%): Number of attack attempts
    - Severity Score (30%): Rules triggered severity levels
    - Reputation Score (20%): AbuseIPDB confidence
    - Velocity Score (10%): Attack speed (events/min)

    Args:
        incident_data (dict): {
            'ip_address': str,
            'block_count': int,
            'rules_triggered': list,
            'unique_rules_count': int,
            'first_seen': str,
            'last_seen': str,
            'attack_velocity': float (optional, will calculate if not provided)
        }
        include_reputation (bool): Whether to query AbuseIPDB (default True)

    Returns:
        dict: {
            'threat_score': int (0-100),
            'risk_level': str ('Critical', 'High', 'Medium', 'Low'),
            'priority': int (1=Critical, 4=Low),
            'breakdown': {
                'frequency': float,
                'severity': float,
                'reputation': float,
                'velocity': float
            },
            'reputation_data': dict (AbuseIPDB response)
        }
    """
    try:
        # Extract incident data
        ip_address = incident_data.get('ip_address', 'Unknown')
        block_count = incident_data.get('block_count', 0)
        rules_triggered = incident_data.get('rules_triggered', [])
        unique_rules_count = incident_data.get('unique_rules_count', len(set(rules_triggered)))

        # 1. Calculate Frequency Score (0-40 points)
        frequency_score = calculate_frequency_score(block_count)

        # 2. Calculate Severity Score (0-30 points)
        severity_score = calculate_severity_score(rules_triggered, unique_rules_count)

        # 3. Calculate Reputation Score (0-20 points)
        reputation_data = None
        reputation_score = 0.0

        if include_reputation and ip_address != 'Unknown':
            reputation_data = get_abuseipdb_score(ip_address)
            reputation_score = calculate_reputation_score(reputation_data)

        # 4. Calculate Velocity Score (0-10 points)
        attack_velocity = incident_data.get('attack_velocity')

        if attack_velocity is None:
            # Calculate if not provided
            first_seen = incident_data.get('first_seen')
            last_seen = incident_data.get('last_seen')

            if first_seen and last_seen:
                attack_velocity = calculate_attack_velocity(
                    first_seen, last_seen, block_count
                )
            else:
                attack_velocity = 0.0

        velocity_score = calculate_velocity_score(attack_velocity)

        # Calculate Total Score
        total_score = int(frequency_score + severity_score + reputation_score + velocity_score)

        # Classify Risk Level and Priority
        if total_score >= 80:
            risk_level = "Critical"
            priority = 1
            color = "#DC143C"  # Crimson
        elif total_score >= 60:
            risk_level = "High"
            priority = 2
            color = "#FF6B6B"  # Red
        elif total_score >= 40:
            risk_level = "Medium"
            priority = 3
            color = "#FFA500"  # Orange
        else:
            risk_level = "Low"
            priority = 4
            color = "#4CAF50"  # Green

        result = {
            'threat_score': total_score,
            'risk_level': risk_level,
            'priority': priority,
            'color': color,
            'breakdown': {
                'frequency': frequency_score,
                'severity': severity_score,
                'reputation': reputation_score,
                'velocity': velocity_score
            },
            'metrics': {
                'block_count': block_count,
                'unique_rules': unique_rules_count,
                'attack_velocity': round(attack_velocity, 2)
            }
        }

        if reputation_data:
            result['reputation_data'] = reputation_data

        logger.debug(f"Threat score for {ip_address}: {total_score} ({risk_level})")

        return result

    except Exception as e:
        logger.error(f"Error calculating threat score: {str(e)}")
        return {
            'threat_score': 0,
            'risk_level': 'Unknown',
            'priority': 5,
            'color': '#808080',
            'breakdown': {
                'frequency': 0,
                'severity': 0,
                'reputation': 0,
                'velocity': 0
            },
            'error': str(e)
        }


def get_recommended_actions(threat_score_data, incident_data):
    """
    Generate recommended actions based on threat score and incident details

    Args:
        threat_score_data (dict): Output from calculate_threat_score()
        incident_data (dict): Original incident data

    Returns:
        list: List of recommended actions with priority
    """
    actions = []

    risk_level = threat_score_data['risk_level']
    ip_address = incident_data.get('ip_address', 'Unknown')
    block_count = incident_data.get('block_count', 0)

    # Critical risk actions
    if risk_level == 'Critical':
        actions.append({
            'priority': 1,
            'action': 'IMMEDIATE: Escalate to incident response team',
            'automated': False,
            'icon': '🚨'
        })
        actions.append({
            'priority': 1,
            'action': f'Block {ip_address} across ALL systems immediately',
            'automated': True,
            'api_endpoint': '/api/firewall/block-global',
            'icon': '🛡️'
        })
        actions.append({
            'priority': 1,
            'action': 'Review logs for successful authentication attempts',
            'automated': False,
            'icon': '🔍'
        })

    # High risk actions
    elif risk_level == 'High':
        actions.append({
            'priority': 2,
            'action': f'Block {ip_address} temporarily (24 hours)',
            'automated': True,
            'api_endpoint': '/api/active-response/manual-block',
            'icon': '⏱️'
        })
        actions.append({
            'priority': 2,
            'action': 'Investigate source IP and correlate with threat intelligence',
            'automated': False,
            'icon': '🕵️'
        })

    # Medium risk actions
    elif risk_level == 'Medium':
        actions.append({
            'priority': 3,
            'action': 'Monitor IP for escalation patterns',
            'automated': True,
            'icon': '👁️'
        })
        actions.append({
            'priority': 3,
            'action': 'Review attack timeline for patterns',
            'automated': False,
            'icon': '📊'
        })

    # Frequency-based actions
    if block_count >= 10:
        actions.append({
            'priority': 2,
            'action': 'Implement rate limiting for this IP',
            'automated': True,
            'icon': '🚦'
        })

    # Reputation-based actions
    reputation_data = threat_score_data.get('reputation_data', {})
    if reputation_data.get('is_tor', False):
        actions.append({
            'priority': 2,
            'action': 'TOR exit node detected - consider blocking TOR traffic',
            'automated': False,
            'icon': '🧅'
        })

    if reputation_data.get('total_reports', 0) > 10:
        actions.append({
            'priority': 1,
            'action': 'Add to permanent threat intelligence blocklist',
            'automated': True,
            'api_endpoint': '/api/threat-intel/add-ioc',
            'icon': '📋'
        })

    # MITRE-specific recommendations
    rules = incident_data.get('rules_triggered', [])
    if '5763' in rules or '5712' in rules:  # SSH brute force
        actions.append({
            'priority': 2,
            'action': 'Enable multi-factor authentication on SSH',
            'automated': False,
            'reference': 'https://attack.mitre.org/mitigations/M1032/',
            'icon': '🔐'
        })

    if '31103' in rules or '31106' in rules:  # Web attacks
        actions.append({
            'priority': 2,
            'action': 'Enable Web Application Firewall (WAF)',
            'automated': False,
            'reference': 'https://attack.mitre.org/mitigations/M1050/',
            'icon': '🛡️'
        })

    # Sort by priority
    actions.sort(key=lambda x: x['priority'])

    return actions
