"""
IP Validation Utilities

Validates IP addresses before blocking to prevent accidental blocks of:
- Internal infrastructure
- Loopback addresses
- Private network gateways
- Broadcast addresses
"""

import ipaddress
from typing import Tuple, Optional


# Protected IP ranges that should never be blocked
PROTECTED_RANGES = [
    '127.0.0.0/8',      # Loopback
    '169.254.0.0/16',   # Link-local
    '224.0.0.0/4',      # Multicast
    '240.0.0.0/4',      # Reserved
    '::1/128',          # IPv6 loopback
    'fe80::/10',        # IPv6 link-local
    'ff00::/8',         # IPv6 multicast
]

# Warn about private ranges (allow but warn)
PRIVATE_RANGES = [
    '10.0.0.0/8',
    '172.16.0.0/12',
    '192.168.0.0/16',
    'fc00::/7',         # IPv6 private
]


def validate_ip_for_blocking(ip_address: str, allow_private: bool = False) -> Tuple[bool, Optional[str]]:
    """
    Validate if an IP address can safely be blocked.

    Args:
        ip_address: IP address to validate (IPv4 or IPv6)
        allow_private: If False, blocking private IPs will return a warning

    Returns:
        Tuple of (is_valid, error_message)
        - (True, None) if IP can be safely blocked
        - (False, "reason") if IP should NOT be blocked
        - (True, "warning") if IP can be blocked but with a warning

    Examples:
        >>> validate_ip_for_blocking("8.8.8.8")
        (True, None)

        >>> validate_ip_for_blocking("127.0.0.1")
        (False, "Cannot block loopback address 127.0.0.1")

        >>> validate_ip_for_blocking("192.168.1.1")
        (True, "Warning: 192.168.1.1 is a private IP address. Ensure this is intentional.")
    """

    try:
        ip_obj = ipaddress.ip_address(ip_address)
    except ValueError:
        return (False, f"Invalid IP address format: {ip_address}")

    # Check protected ranges (cannot block)
    for protected_range in PROTECTED_RANGES:
        network = ipaddress.ip_network(protected_range)
        if ip_obj in network:
            return (False, f"Cannot block protected address {ip_address} (in range {protected_range})")

    # Check private ranges (warn but allow)
    if not allow_private:
        for private_range in PRIVATE_RANGES:
            network = ipaddress.ip_network(private_range)
            if ip_obj in network:
                return (True, f"Warning: {ip_address} is a private IP address. Ensure this is intentional.")

    # Check for broadcast addresses
    if ip_obj.is_multicast:
        return (False, f"Cannot block multicast address {ip_address}")

    if ip_obj.is_reserved:
        return (False, f"Cannot block reserved address {ip_address}")

    # All checks passed
    return (True, None)


def check_if_already_blocked(ip_address: str, cursor) -> Tuple[bool, Optional[str]]:
    """
    Check if an IP is already blocked in the database.

    Args:
        ip_address: IP address to check
        cursor: Database cursor

    Returns:
        Tuple of (is_blocked, block_id)
    """

    if not cursor:
        return (False, None)

    try:
        cursor.execute("""
            SELECT id FROM firewall_ip_metadata
            WHERE ip_address = %s AND active = TRUE AND list_type = 'block'
            LIMIT 1
        """, [ip_address])

        result = cursor.fetchone()
        if result:
            return (True, str(result[0]))
        return (False, None)

    except Exception:
        # If database check fails, continue with blocking
        return (False, None)


def validate_cidr_notation(cidr: str) -> Tuple[bool, Optional[str]]:
    """
    Validate CIDR notation format.

    Args:
        cidr: CIDR notation string (e.g., "192.168.1.0/24")

    Returns:
        Tuple of (is_valid, error_message)

    Examples:
        >>> validate_cidr_notation("192.168.1.0/24")
        (True, None)

        >>> validate_cidr_notation("192.168.1.0/33")
        (False, "Invalid CIDR prefix length: /33 (must be 0-32 for IPv4)")

        >>> validate_cidr_notation("not_an_ip")
        (False, "Invalid CIDR format: not_an_ip")
    """

    if not cidr or '/' not in cidr:
        return (False, "CIDR notation must include a prefix length (e.g., 192.168.1.0/24)")

    try:
        network = ipaddress.ip_network(cidr, strict=False)

        # Check prefix length validity
        if isinstance(network, ipaddress.IPv4Network):
            if not (0 <= network.prefixlen <= 32):
                return (False, f"Invalid CIDR prefix length: /{network.prefixlen} (must be 0-32 for IPv4)")
        else:  # IPv6
            if not (0 <= network.prefixlen <= 128):
                return (False, f"Invalid CIDR prefix length: /{network.prefixlen} (must be 0-128 for IPv6)")

        # Warn about overly broad ranges
        if isinstance(network, ipaddress.IPv4Network) and network.prefixlen < 8:
            return (True, f"Warning: CIDR /{network.prefixlen} is very broad and will match {network.num_addresses} addresses")
        elif isinstance(network, ipaddress.IPv6Network) and network.prefixlen < 64:
            return (True, f"Warning: CIDR /{network.prefixlen} is very broad and will match many addresses")

        return (True, None)

    except ValueError as e:
        return (False, f"Invalid CIDR format: {str(e)}")
