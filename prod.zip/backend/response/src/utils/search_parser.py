"""
Search Query Parser

Parses special search query formats:
- rule:123 -> Filter by Wazuh rule ID
- sid:456 -> Filter by Suricata signature ID
- ip:192.168.1.1 -> Filter by IP address (source or destination)
- "regular text" -> Free-text search
"""

import re
from typing import Dict, Optional


def parse_search_query(search_term: str) -> Dict[str, Optional[str]]:
    """
    Parse search query into structured filters.

    Args:
        search_term: Search string that may contain special prefixes

    Returns:
        Dictionary with parsed filters:
        {
            'rule_id': '123' or None,
            'signature_id': '456' or None,
            'ip_address': '192.168.1.1' or None,
            'free_text': 'remaining search text' or None
        }

    Examples:
        >>> parse_search_query("rule:12345")
        {'rule_id': '12345', 'signature_id': None, 'ip_address': None, 'free_text': None}

        >>> parse_search_query("sid:2024234 malware")
        {'rule_id': None, 'signature_id': '2024234', 'ip_address': None, 'free_text': 'malware'}

        >>> parse_search_query("ip:10.0.0.5")
        {'rule_id': None, 'signature_id': None, 'ip_address': '10.0.0.5', 'free_text': None}
    """

    if not search_term or not search_term.strip():
        return {
            'rule_id': None,
            'signature_id': None,
            'ip_address': None,
            'free_text': None
        }

    search_term = search_term.strip()

    # Initialize result
    parsed = {
        'rule_id': None,
        'signature_id': None,
        'ip_address': None,
        'free_text': None
    }

    # Pattern for rule:123
    rule_match = re.search(r'\brule:(\d+)\b', search_term, re.IGNORECASE)
    if rule_match:
        parsed['rule_id'] = rule_match.group(1)
        # Remove from search term
        search_term = re.sub(r'\brule:\d+\b', '', search_term, flags=re.IGNORECASE)

    # Pattern for sid:456 (Suricata signature ID)
    sid_match = re.search(r'\bsid:(\d+)\b', search_term, re.IGNORECASE)
    if sid_match:
        parsed['signature_id'] = sid_match.group(1)
        # Remove from search term
        search_term = re.sub(r'\bsid:\d+\b', '', search_term, flags=re.IGNORECASE)

    # Pattern for ip:192.168.1.1 (IPv4 or IPv6)
    ip_match = re.search(
        r'\bip:((?:[0-9]{1,3}\.){3}[0-9]{1,3}|(?:[0-9a-fA-F]{0,4}:){2,7}[0-9a-fA-F]{0,4})\b',
        search_term,
        re.IGNORECASE
    )
    if ip_match:
        parsed['ip_address'] = ip_match.group(1)
        # Remove from search term
        search_term = re.sub(
            r'\bip:(?:[0-9]{1,3}\.){3}[0-9]{1,3}\b',
            '',
            search_term,
            flags=re.IGNORECASE
        )
        search_term = re.sub(
            r'\bip:(?:[0-9a-fA-F]{0,4}:){2,7}[0-9a-fA-F]{0,4}\b',
            '',
            search_term,
            flags=re.IGNORECASE
        )

    # Remaining text is free-text search
    remaining_text = search_term.strip()
    if remaining_text:
        parsed['free_text'] = remaining_text

    return parsed


def apply_search_filters(alerts: list, parsed_query: Dict[str, Optional[str]]) -> list:
    """
    Apply parsed search filters to alerts list.

    Args:
        alerts: List of alert dictionaries
        parsed_query: Parsed query from parse_search_query()

    Returns:
        Filtered list of alerts
    """

    if not alerts:
        return []

    filtered = alerts

    # Filter by rule ID (Wazuh)
    if parsed_query.get('rule_id'):
        rule_id = parsed_query['rule_id']
        filtered = [
            alert for alert in filtered
            if alert.get('source') == 'wazuh' and str(alert.get('rule_id')) == rule_id
        ]

    # Filter by signature ID (Suricata)
    if parsed_query.get('signature_id'):
        sig_id = parsed_query['signature_id']
        filtered = [
            alert for alert in filtered
            if alert.get('source') == 'suricata' and str(alert.get('signature_id')) == sig_id
        ]

    # Filter by IP address (source or destination)
    if parsed_query.get('ip_address'):
        ip = parsed_query['ip_address']
        filtered = [
            alert for alert in filtered
            if (
                alert.get('src_ip') == ip or
                alert.get('dest_ip') == ip or
                (alert.get('data') and (
                    alert['data'].get('srcip') == ip or
                    alert['data'].get('dstip') == ip
                ))
            )
        ]

    # Filter by free-text search
    if parsed_query.get('free_text'):
        search_text = parsed_query['free_text'].lower()
        filtered = [
            alert for alert in filtered
            if (
                # Search in rule description
                (alert.get('rule_description') and search_text in alert['rule_description'].lower()) or
                # Search in signature
                (alert.get('signature') and search_text in alert['signature'].lower()) or
                # Search in category
                (alert.get('category') and search_text in alert['category'].lower()) or
                # Search in alert ID
                (alert.get('id') and search_text in str(alert['id']).lower())
            )
        ]

    return filtered
