"""
Database Connection Utility for RBAC System
Provides PostgreSQL connection pool with proper transaction management
"""

import os
import psycopg2
import psycopg2.extras
from psycopg2.pool import SimpleConnectionPool
import logging

logger = logging.getLogger(__name__)


class DatabaseConnection:
    """
    PostgreSQL database connection manager with connection pooling
    """

    def __init__(self):
        self.pool = None
        self._initialize_pool()

    def _initialize_pool(self):
        """Initialize connection pool"""
        try:
            # Get database config from environment (required - no defaults for security)
            db_host = os.getenv('POSTGRES_HOST') or os.getenv('DB_HOST')
            db_port = os.getenv('POSTGRES_PORT') or os.getenv('DB_PORT') or '5432'
            db_name = os.getenv('POSTGRES_DB') or os.getenv('DB_NAME')
            db_user = os.getenv('POSTGRES_USER') or os.getenv('DB_USER')
            db_password = os.getenv('POSTGRES_PASSWORD') or os.getenv('DB_PASSWORD')

            # Log connection info (without sensitive data)
            logger.info(f"[DB] Connecting to: {db_name}@{db_host}:{db_port}")

            # Create connection pool
            self.pool = SimpleConnectionPool(
                minconn=1,
                maxconn=20,
                host=db_host,
                port=db_port,
                database=db_name,
                user=db_user,
                password=db_password,
                cursor_factory=psycopg2.extras.RealDictCursor  # Return rows as dicts
            )

            logger.info(f"[DB] Connection pool initialized successfully")

        except Exception as e:
            logger.error(f"[DB] Failed to initialize database pool: {e}")
            raise

    def get_connection(self):
        """Get a connection from the pool"""
        try:
            return self.pool.getconn()
        except Exception as e:
            logger.error(f"[DB] Failed to get database connection: {e}")
            raise

    def return_connection(self, conn):
        """Return a connection to the pool"""
        try:
            if conn:
                self.pool.putconn(conn)
        except Exception as e:
            logger.error(f"[DB] Failed to return connection to pool: {e}")

    def close_all(self):
        """Close all connections in pool"""
        if self.pool:
            self.pool.closeall()
            logger.info("[DB] Database pool closed")


class DatabaseConnectionWrapper:
    """
    Wrapper for database connection to match expected interface
    Provides execute(), commit(), rollback() methods with automatic cleanup
    """

    def __init__(self, pool):
        self.pool = pool
        self._connection = None
        self._cursor = None

    def _ensure_connection(self):
        """Ensure we have an active connection"""
        if not self._connection:
            self._connection = self.pool.get_connection()

    def execute(self, query, params=None):
        """Execute query and return cursor"""
        self._ensure_connection()
        try:
            self._cursor = self._connection.cursor()
            self._cursor.execute(query, params)
            return self._cursor
        except Exception as e:
            self._connection.rollback()
            logger.error(f"[DB] Query execution failed: {e}")
            logger.error(f"[DB] Query: {query}")
            logger.error(f"[DB] Params: {params}")
            raise

    def commit(self):
        """Commit transaction"""
        if self._connection:
            try:
                self._connection.commit()
            except Exception as e:
                logger.error(f"[DB] Commit failed: {e}")
                raise

    def rollback(self):
        """Rollback transaction"""
        if self._connection:
            try:
                self._connection.rollback()
            except Exception as e:
                logger.error(f"[DB] Rollback failed: {e}")

    def close(self):
        """Return connection to pool"""
        if self._cursor:
            try:
                self._cursor.close()
            except:
                pass
            self._cursor = None
        if self._connection:
            self.pool.return_connection(self._connection)
            self._connection = None

    def __enter__(self):
        """Context manager entry"""
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        """Context manager exit - auto commit on success, rollback on error"""
        if exc_type:
            self.rollback()
        else:
            self.commit()
        self.close()


# Global database pool instance
_db_pool = None


def get_db():
    """
    Get database connection wrapper

    Returns:
        DatabaseConnectionWrapper instance
    """
    global _db_pool
    if _db_pool is None:
        _db_pool = DatabaseConnection()
    return DatabaseConnectionWrapper(_db_pool)


def init_db():
    """
    Initialize database connection pool

    Returns:
        DatabaseConnection pool instance
    """
    global _db_pool
    if _db_pool is None:
        _db_pool = DatabaseConnection()
        logger.info("[DB] Database initialized")
    return _db_pool


def close_db():
    """Close database connection pool"""
    global _db_pool
    if _db_pool:
        _db_pool.close_all()
        _db_pool = None
        logger.info("[DB] Database closed")
