"""
MITRE ATT&CK Framework Mapping for Wazuh Rules

Maps Wazuh rule IDs to MITRE ATT&CK techniques and tactics
for enhanced threat intelligence and SOC analysis.

Based on official Wazuh documentation:
https://documentation.wazuh.com/current/user-manual/ruleset/mitre.html
"""

WAZUH_RULE_TO_MITRE_MAP = {
    # ============================================================================
    # SSH Brute Force / Credential Access Attacks
    # ============================================================================
    '5710': {
        'technique': 'T1110.001',
        'technique_name': 'Brute Force: Password Guessing',
        'sub_technique': 'Password Guessing',
        'tactic': 'TA0006',
        'tactic_name': 'Credential Access',
        'severity': 'Medium',
        'attack_stage': 'reconnaissance',
        'description': 'SSH attempt to login using a non-existent user',
        'recommended_actions': [
            'Monitor for account enumeration patterns',
            'Enable fail2ban or Active Response',
            'Review SSH authentication logs',
            'Consider implementing SSH key-only authentication'
        ]
    },

    '5763': {
        'technique': 'T1110.001',
        'technique_name': 'Brute Force: Password Guessing',
        'sub_technique': 'Password Guessing',
        'tactic': 'TA0006',
        'tactic_name': 'Credential Access',
        'severity': 'High',
        'attack_stage': 'initial_access',
        'description': 'SSH authentication failed - brute force attack detected',
        'recommended_actions': [
            'Block IP address immediately',
            'Review authentication logs for successful logins from this IP',
            'Verify user account integrity',
            'Enable multi-factor authentication'
        ]
    },

    '5712': {
        'technique': 'T1110',
        'technique_name': 'Brute Force',
        'sub_technique': None,
        'tactic': 'TA0006',
        'tactic_name': 'Credential Access',
        'severity': 'Critical',
        'attack_stage': 'execution',
        'description': 'Multiple authentication failures - aggressive brute force',
        'recommended_actions': [
            'IMMEDIATE: Block IP across all systems',
            'Lock affected user accounts',
            'Force password reset for targeted accounts',
            'Escalate to incident response team'
        ]
    },

    '5711': {
        'technique': 'T1078.003',
        'technique_name': 'Valid Accounts: Local Accounts',
        'sub_technique': 'Local Accounts',
        'tactic': 'TA0001',
        'tactic_name': 'Initial Access',
        'severity': 'Medium',
        'attack_stage': 'reconnaissance',
        'description': 'Attempt to access with invalid or unauthorized credentials',
        'recommended_actions': [
            'Review user account activity',
            'Check for compromised credentials',
            'Audit local account permissions'
        ]
    },

    # ============================================================================
    # Web Application Attacks
    # ============================================================================
    '31103': {
        'technique': 'T1190',
        'technique_name': 'Exploit Public-Facing Application',
        'sub_technique': None,
        'tactic': 'TA0001',
        'tactic_name': 'Initial Access',
        'severity': 'High',
        'attack_stage': 'exploitation',
        'description': 'Web application attack detected (SQL injection, XSS, etc.)',
        'recommended_actions': [
            'Block attacker IP immediately',
            'Review web application logs for payload',
            'Patch vulnerable application',
            'Enable web application firewall (WAF)',
            'Check for successful exploitation attempts'
        ]
    },

    '31106': {
        'technique': 'T1059.007',
        'technique_name': 'Command and Scripting Interpreter: JavaScript',
        'sub_technique': 'JavaScript',
        'tactic': 'TA0002',
        'tactic_name': 'Execution',
        'severity': 'High',
        'attack_stage': 'execution',
        'description': 'Web shell or command injection attempt',
        'recommended_actions': [
            'Block IP immediately',
            'Scan web server for web shells',
            'Review recently modified files',
            'Check for unauthorized file uploads'
        ]
    },

    '31151': {
        'technique': 'T1059.004',
        'technique_name': 'Command and Scripting Interpreter: Unix Shell',
        'sub_technique': 'Unix Shell',
        'tactic': 'TA0002',
        'tactic_name': 'Execution',
        'severity': 'Critical',
        'attack_stage': 'execution',
        'description': 'Command injection or shell access attempt',
        'recommended_actions': [
            'CRITICAL: Isolate affected system',
            'Block attacker IP',
            'Forensic analysis required',
            'Check for data exfiltration'
        ]
    },

    # ============================================================================
    # Network Scanning / Reconnaissance
    # ============================================================================
    '5401': {
        'technique': 'T1046',
        'technique_name': 'Network Service Scanning',
        'sub_technique': None,
        'tactic': 'TA0007',
        'tactic_name': 'Discovery',
        'severity': 'Low',
        'attack_stage': 'reconnaissance',
        'description': 'Network port scanning detected',
        'recommended_actions': [
            'Monitor scanner IP for follow-up attacks',
            'Block if repeated scanning detected',
            'Review exposed services'
        ]
    },

    '5402': {
        'technique': 'T1046',
        'technique_name': 'Network Service Scanning',
        'sub_technique': None,
        'tactic': 'TA0007',
        'tactic_name': 'Discovery',
        'severity': 'Medium',
        'attack_stage': 'reconnaissance',
        'description': 'Multiple connection attempts - possible port scan',
        'recommended_actions': [
            'Block IP to prevent further reconnaissance',
            'Review firewall rules',
            'Minimize exposed attack surface'
        ]
    },

    '5403': {
        'technique': 'T1046',
        'technique_name': 'Network Service Scanning',
        'sub_technique': None,
        'tactic': 'TA0007',
        'tactic_name': 'Discovery',
        'severity': 'Medium',
        'attack_stage': 'reconnaissance',
        'description': 'Nmap or aggressive scanning activity detected',
        'recommended_actions': [
            'Block scanner IP',
            'Alert security team - likely precursor to attack',
            'Increase monitoring on scanned systems'
        ]
    },

    '5404': {
        'technique': 'T1046',
        'technique_name': 'Network Service Scanning',
        'sub_technique': None,
        'tactic': 'TA0007',
        'tactic_name': 'Discovery',
        'severity': 'Medium',
        'attack_stage': 'reconnaissance',
        'description': 'Possible network reconnaissance detected',
        'recommended_actions': [
            'Correlate with other alerts from same IP',
            'Consider blocking if pattern continues'
        ]
    },

    # ============================================================================
    # Malware / Persistence
    # ============================================================================
    '510': {
        'technique': 'T1543.003',
        'technique_name': 'Create or Modify System Process: Windows Service',
        'sub_technique': 'Windows Service',
        'tactic': 'TA0003',
        'tactic_name': 'Persistence',
        'severity': 'Critical',
        'attack_stage': 'persistence',
        'description': 'Suspicious service installation detected',
        'recommended_actions': [
            'CRITICAL: Investigate service immediately',
            'Quarantine affected system',
            'Scan for malware',
            'Review service executable',
            'Check for lateral movement'
        ]
    },

    '554': {
        'technique': 'T1053.005',
        'technique_name': 'Scheduled Task/Job: Scheduled Task',
        'sub_technique': 'Scheduled Task',
        'tactic': 'TA0003',
        'tactic_name': 'Persistence',
        'severity': 'High',
        'attack_stage': 'persistence',
        'description': 'Unauthorized scheduled task creation',
        'recommended_actions': [
            'Review task details and payload',
            'Disable suspicious tasks',
            'Investigate user account that created task'
        ]
    },

    # ============================================================================
    # Account Manipulation / Privilege Escalation
    # ============================================================================
    '5503': {
        'technique': 'T1078',
        'technique_name': 'Valid Accounts',
        'sub_technique': None,
        'tactic': 'TA0001',
        'tactic_name': 'Initial Access',
        'severity': 'Medium',
        'attack_stage': 'initial_access',
        'description': 'Multiple failed login attempts - potential credential stuffing',
        'recommended_actions': [
            'Lock account temporarily',
            'Verify legitimate user',
            'Review account activity logs'
        ]
    },

    '5551': {
        'technique': 'T1110',
        'technique_name': 'Brute Force',
        'sub_technique': None,
        'tactic': 'TA0006',
        'tactic_name': 'Credential Access',
        'severity': 'High',
        'attack_stage': 'execution',
        'description': 'Multiple authentication failures from same source',
        'recommended_actions': [
            'Lock affected account',
            'Block source IP',
            'Review for successful logins',
            'Enable MFA'
        ]
    },

    # ============================================================================
    # RDP Attacks
    # ============================================================================
    '60122': {
        'technique': 'T1110.001',
        'technique_name': 'Brute Force: Password Guessing',
        'sub_technique': 'Password Guessing',
        'tactic': 'TA0006',
        'tactic_name': 'Credential Access',
        'severity': 'High',
        'attack_stage': 'initial_access',
        'description': 'RDP authentication failed - brute force attack detected',
        'recommended_actions': [
            'Block IP address immediately',
            'Review RDP access logs',
            'Enable Network Level Authentication (NLA)',
            'Consider disabling RDP if not needed',
            'Implement account lockout policies'
        ]
    },

    # ============================================================================
    # Active Response / Defensive Actions
    # ============================================================================
    '651': {
        'technique': 'T1562.004',
        'technique_name': 'Impair Defenses: Disable or Modify System Firewall',
        'sub_technique': 'Disable or Modify System Firewall',
        'tactic': 'TA0040',
        'tactic_name': 'Impact',
        'severity': 'Low',  # Not an attack, defensive action
        'attack_stage': 'mitigation',
        'description': 'Active Response: Firewall block applied',
        'recommended_actions': [
            'Monitor block effectiveness',
            'Verify timeout settings',
            'Check for evasion attempts',
            'Review triggered rule for false positives'
        ]
    },
}


def get_mitre_mapping(rule_id):
    """
    Get MITRE ATT&CK mapping for Wazuh rule

    Args:
        rule_id (str): Wazuh rule ID (e.g., '5710')

    Returns:
        dict: MITRE mapping with technique, tactic, severity, description
              Returns default dict if rule not mapped
    """
    return WAZUH_RULE_TO_MITRE_MAP.get(str(rule_id), {
        'technique': 'Unknown',
        'technique_name': 'Unknown Technique',
        'sub_technique': None,
        'tactic': 'Unknown',
        'tactic_name': 'Unknown Tactic',
        'severity': 'Low',
        'attack_stage': 'unknown',
        'description': f'No MITRE mapping available for rule {rule_id}',
        'recommended_actions': ['Review alert details', 'Correlate with other events']
    })


def get_attack_stage_color(stage):
    """
    Get color code for attack stage visualization

    Args:
        stage (str): Attack stage (reconnaissance, initial_access, execution, etc.)

    Returns:
        str: Hex color code for UI visualization
    """
    stage_colors = {
        'reconnaissance': '#FFA500',  # Orange
        'initial_access': '#FF6B6B',  # Red
        'execution': '#DC143C',       # Crimson
        'persistence': '#8B0000',     # Dark Red
        'exploitation': '#FF0000',    # Bright Red
        'mitigation': '#00A86B',      # Green (defensive action)
        'unknown': '#808080'          # Gray
    }
    return stage_colors.get(stage, '#808080')


def get_severity_priority(severity):
    """
    Convert severity to numeric priority for sorting

    Args:
        severity (str): Severity level (Critical, High, Medium, Low)

    Returns:
        int: Priority number (1=Critical, 4=Low)
    """
    severity_map = {
        'Critical': 1,
        'High': 2,
        'Medium': 3,
        'Low': 4,
        'Unknown': 5
    }
    return severity_map.get(severity, 5)


def get_tactic_order(tactic_id):
    """
    Get MITRE tactic order for attack chain visualization

    Args:
        tactic_id (str): MITRE tactic ID (e.g., 'TA0001')

    Returns:
        int: Order number for timeline (1=first, 14=last)
    """
    tactic_order = {
        'TA0043': 1,   # Reconnaissance
        'TA0042': 2,   # Resource Development
        'TA0001': 3,   # Initial Access
        'TA0002': 4,   # Execution
        'TA0003': 5,   # Persistence
        'TA0004': 6,   # Privilege Escalation
        'TA0005': 7,   # Defense Evasion
        'TA0006': 8,   # Credential Access
        'TA0007': 9,   # Discovery
        'TA0008': 10,  # Lateral Movement
        'TA0009': 11,  # Collection
        'TA0011': 12,  # Command and Control
        'TA0010': 13,  # Exfiltration
        'TA0040': 14,  # Impact
    }
    return tactic_order.get(tactic_id, 99)


def classify_attack_stage(rule_id):
    """
    Classify attack stage based on rule ID

    Args:
        rule_id (str): Wazuh rule ID

    Returns:
        str: Attack stage (reconnaissance, initial_access, execution, etc.)
    """
    mapping = get_mitre_mapping(rule_id)
    return mapping.get('attack_stage', 'unknown')


def get_all_techniques_for_tactic(tactic_id):
    """
    Get all MITRE techniques observed for a specific tactic

    Args:
        tactic_id (str): MITRE tactic ID (e.g., 'TA0006')

    Returns:
        list: List of technique IDs associated with this tactic
    """
    techniques = []
    for rule_id, mapping in WAZUH_RULE_TO_MITRE_MAP.items():
        if mapping['tactic'] == tactic_id:
            techniques.append({
                'technique': mapping['technique'],
                'technique_name': mapping['technique_name'],
                'rule_id': rule_id,
                'severity': mapping['severity']
            })
    return techniques


def build_attack_kill_chain(rule_ids):
    """
    Build MITRE ATT&CK kill chain from list of triggered rules

    Args:
        rule_ids (list): List of Wazuh rule IDs

    Returns:
        list: Ordered list of attack stages with MITRE mappings
    """
    tactics_seen = {}

    for rule_id in rule_ids:
        mapping = get_mitre_mapping(rule_id)
        tactic_id = mapping['tactic']

        if tactic_id not in tactics_seen:
            tactics_seen[tactic_id] = {
                'tactic_id': tactic_id,
                'tactic_name': mapping['tactic_name'],
                'order': get_tactic_order(tactic_id),
                'techniques': [],
                'rules': []
            }

        tactics_seen[tactic_id]['techniques'].append({
            'technique': mapping['technique'],
            'technique_name': mapping['technique_name'],
            'severity': mapping['severity']
        })

        tactics_seen[tactic_id]['rules'].append(rule_id)

    # Sort by MITRE tactic order
    kill_chain = sorted(tactics_seen.values(), key=lambda x: x['order'])

    return kill_chain
