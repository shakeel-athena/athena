"""
Keycloak JWT Token Validation Utility

This module provides utilities for validating JWT tokens issued by Keycloak.
It fetches the public key from Keycloak's JWKS endpoint and validates tokens.
"""

import os
import jwt
import requests
from functools import lru_cache
from typing import Dict, Optional, List
from datetime import datetime, timedelta

# Keycloak configuration from environment variables with fallbacks
KEYCLOAK_URL = os.getenv('KEYCLOAK_URL') or os.getenv('REACT_APP_KEYCLOAK_URL', 'http://localhost:8080')
KEYCLOAK_REALM = os.getenv('KEYCLOAK_REALM') or os.getenv('REACT_APP_KEYCLOAK_REALM', 'athena-security')
KEYCLOAK_CLIENT_ID = os.getenv('KEYCLOAK_CLIENT_ID') or os.getenv('REACT_APP_KEYCLOAK_CLIENT_ID', 'athena-backend-flask')

# Public-facing Keycloak URL (what the browser sees) - for issuer validation
# This handles Docker environments where internal URL differs from external URL
KEYCLOAK_PUBLIC_URL = os.getenv('KEYCLOAK_PUBLIC_URL', 'http://localhost:8080')

# Debug logging for configuration
print("=" * 80)
print("[KEYCLOAK CONFIG] Loading Keycloak configuration:")
print(f"[KEYCLOAK CONFIG] KEYCLOAK_URL (internal): {KEYCLOAK_URL}")
print(f"[KEYCLOAK CONFIG] KEYCLOAK_PUBLIC_URL (external): {KEYCLOAK_PUBLIC_URL}")
print(f"[KEYCLOAK CONFIG] KEYCLOAK_REALM: {KEYCLOAK_REALM}")
print(f"[KEYCLOAK CONFIG] KEYCLOAK_CLIENT_ID: {KEYCLOAK_CLIENT_ID}")
print(f"[KEYCLOAK CONFIG] Expected JWT token audience: {KEYCLOAK_CLIENT_ID}")
print("=" * 80)

# Construct JWKS URI (use internal URL for fetching keys from within Docker)
JWKS_URI = f"{KEYCLOAK_URL}/realms/{KEYCLOAK_REALM}/protocol/openid-connect/certs"

# Accepted issuers - both internal Docker hostname and external public URL
ISSUER = f"{KEYCLOAK_URL}/realms/{KEYCLOAK_REALM}"
ISSUER_PUBLIC = f"{KEYCLOAK_PUBLIC_URL}/realms/{KEYCLOAK_REALM}"
ACCEPTED_ISSUERS = [ISSUER, ISSUER_PUBLIC]

# Cache configuration
JWKS_CACHE_TTL = timedelta(hours=1)
_jwks_cache = None
_jwks_cache_time = None


class TokenValidationError(Exception):
    """Custom exception for token validation errors"""
    pass


@lru_cache(maxsize=128)
def get_public_key(kid: str) -> str:
    """
    Fetch public key from Keycloak JWKS endpoint for given key ID.

    Args:
        kid: Key ID from JWT header

    Returns:
        Public key in PEM format

    Raises:
        TokenValidationError: If key cannot be fetched or found
    """
    global _jwks_cache, _jwks_cache_time

    # Check if cache is valid
    now = datetime.now()
    if _jwks_cache is None or _jwks_cache_time is None or \
       (now - _jwks_cache_time) > JWKS_CACHE_TTL:
        try:
            response = requests.get(JWKS_URI, timeout=5)
            response.raise_for_status()
            _jwks_cache = response.json()
            _jwks_cache_time = now
        except requests.RequestException as e:
            raise TokenValidationError(f"Failed to fetch JWKS: {str(e)}")

    # Find the key with matching kid
    for key in _jwks_cache.get('keys', []):
        if key.get('kid') == kid:
            # Convert JWK to PEM format
            return jwt.algorithms.RSAAlgorithm.from_jwk(key)

    raise TokenValidationError(f"Public key not found for kid: {kid}")


def decode_token(token: str, verify: bool = True) -> Dict:
    """
    Decode and validate JWT token from Keycloak.

    Args:
        token: JWT token string
        verify: Whether to verify the token signature (default: True)

    Returns:
        Decoded token payload as dictionary

    Raises:
        TokenValidationError: If token is invalid or expired
    """
    if not token:
        raise TokenValidationError("Token is required")

    try:
        # First decode without verification to get the key ID
        unverified_header = jwt.get_unverified_header(token)
        kid = unverified_header.get('kid')

        if not kid:
            raise TokenValidationError("Token header missing 'kid' field")

        # Get the public key
        public_key = get_public_key(kid)

        # Debug: decode without verification first to see token contents
        unverified_payload = jwt.decode(token, options={"verify_signature": False})
        token_issuer = unverified_payload.get('iss')
        print(f"[TOKEN DEBUG] Token audience (aud): {unverified_payload.get('aud')}")
        print(f"[TOKEN DEBUG] Expected audience: {KEYCLOAK_CLIENT_ID}")
        print(f"[TOKEN DEBUG] Token issuer (iss): {token_issuer}")
        print(f"[TOKEN DEBUG] Accepted issuers: {ACCEPTED_ISSUERS}")

        # Validate issuer manually against accepted list
        if verify and token_issuer not in ACCEPTED_ISSUERS:
            raise TokenValidationError(f"Invalid issuer: {token_issuer}. Expected one of: {ACCEPTED_ISSUERS}")

        # Decode and verify the token
        # Note: We don't verify audience since the frontend client (public)
        # doesn't include backend client IDs in the aud claim by default
        # Note: We manually validate issuer above to support multiple issuers
        decoded = jwt.decode(
            token,
            public_key,
            algorithms=['RS256'],
            options={
                'verify_signature': verify,
                'verify_aud': False,  # Disabled - frontend tokens don't include backend aud
                'verify_iss': False,  # Disabled - we validate manually above for multiple issuers
                'verify_exp': verify,
            }
        )

        return decoded

    except jwt.ExpiredSignatureError:
        raise TokenValidationError("Token has expired")
    except jwt.InvalidAudienceError as e:
        print(f"[TOKEN ERROR] Audience validation failed: {str(e)}")
        raise TokenValidationError("Invalid token audience")
    except jwt.InvalidIssuerError:
        raise TokenValidationError("Invalid token issuer")
    except jwt.InvalidTokenError as e:
        raise TokenValidationError(f"Invalid token: {str(e)}")
    except Exception as e:
        raise TokenValidationError(f"Token validation failed: {str(e)}")


def extract_user_info(token_payload: Dict) -> Dict:
    """
    Extract user information from decoded token payload.

    Args:
        token_payload: Decoded JWT payload

    Returns:
        Dictionary containing user information
    """
    return {
        'user_id': token_payload.get('sub'),
        'username': token_payload.get('preferred_username'),
        'email': token_payload.get('email'),
        'email_verified': token_payload.get('email_verified', False),
        'first_name': token_payload.get('given_name'),
        'last_name': token_payload.get('family_name'),
        'full_name': token_payload.get('name'),
    }


def extract_roles(token_payload: Dict, client_id: Optional[str] = None) -> List[str]:
    """
    Extract roles from decoded token payload.

    Args:
        token_payload: Decoded JWT payload
        client_id: Optional client ID to extract client-specific roles

    Returns:
        List of role names
    """
    roles = []

    # Extract realm roles
    realm_access = token_payload.get('realm_access', {})
    realm_roles = realm_access.get('roles', [])
    roles.extend(realm_roles)

    # Extract client roles if client_id is specified
    if client_id:
        resource_access = token_payload.get('resource_access', {})
        client_access = resource_access.get(client_id, {})
        client_roles = client_access.get('roles', [])
        roles.extend(client_roles)

    # Remove duplicates and default roles
    roles = list(set(roles))
    roles = [r for r in roles if not r.startswith('default-roles-')]

    return roles


def has_role(token_payload: Dict, required_role: str, client_id: Optional[str] = None) -> bool:
    """
    Check if token has a specific role.

    Args:
        token_payload: Decoded JWT payload
        required_role: Role to check for
        client_id: Optional client ID for client-specific roles

    Returns:
        True if user has the role, False otherwise
    """
    user_roles = extract_roles(token_payload, client_id)
    return required_role in user_roles


def has_any_role(token_payload: Dict, required_roles: List[str], client_id: Optional[str] = None) -> bool:
    """
    Check if token has any of the specified roles.

    Args:
        token_payload: Decoded JWT payload
        required_roles: List of roles to check for
        client_id: Optional client ID for client-specific roles

    Returns:
        True if user has at least one of the roles, False otherwise
    """
    user_roles = extract_roles(token_payload, client_id)
    return any(role in user_roles for role in required_roles)


def has_all_roles(token_payload: Dict, required_roles: List[str], client_id: Optional[str] = None) -> bool:
    """
    Check if token has all of the specified roles.

    Args:
        token_payload: Decoded JWT payload
        required_roles: List of roles to check for
        client_id: Optional client ID for client-specific roles

    Returns:
        True if user has all of the roles, False otherwise
    """
    user_roles = extract_roles(token_payload, client_id)
    return all(role in user_roles for role in required_roles)


def validate_token(token: str) -> tuple[Dict, Dict, List[str]]:
    """
    Validate token and extract user info and roles.

    Convenience function that combines decode_token, extract_user_info, and extract_roles.

    Args:
        token: JWT token string

    Returns:
        Tuple of (token_payload, user_info, roles)

    Raises:
        TokenValidationError: If token is invalid
    """
    payload = decode_token(token)
    user_info = extract_user_info(payload)
    roles = extract_roles(payload, KEYCLOAK_CLIENT_ID)

    return payload, user_info, roles
