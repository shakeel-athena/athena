"""
RBAC Manager - Dynamic Role-Based Access Control
Handles page-level permissions for users based on their roles
"""

from functools import wraps
from flask import g, request, jsonify
from typing import Tuple, List, Dict, Optional
import logging

logger = logging.getLogger(__name__)


class RBACManager:
    """
    Simple page-based RBAC manager
    - Users have roles
    - Roles have access to pages
    - Check if user can access a page
    """

    def __init__(self, db):
        self.db = db
        self._permission_cache = {}

    def sync_user_from_jwt(self, jwt_payload: Dict) -> Optional[Dict]:
        """
        Sync user from Keycloak JWT to our database
        Creates user if doesn't exist, updates if exists

        Args:
            jwt_payload: Decoded JWT token from Keycloak

        Returns:
            User record from database
        """
        keycloak_user_id = jwt_payload.get('sub')
        username = jwt_payload.get('preferred_username', '')
        email = jwt_payload.get('email', '')
        full_name = jwt_payload.get('name', '')

        if not keycloak_user_id:
            logger.error("No 'sub' claim in JWT payload")
            return None

        # Try to read existing user first (most common case)
        try:
            # Clean transaction before read
            try:
                self.db.rollback()
            except:
                pass

            cursor = self.db.execute(
                "SELECT * FROM users WHERE keycloak_user_id = %s",
                (keycloak_user_id,)
            )
            existing_user = cursor.fetchone()

            if existing_user:
                # User exists, check if update needed
                if (existing_user['username'] == username and
                    existing_user['email'] == email and
                    existing_user['full_name'] == full_name):
                    # No update needed, return existing user
                    logger.debug(f"User already synced: {username}")
                    return existing_user
        except Exception as e:
            logger.warning(f"Failed to check existing user: {e}")
            try:
                self.db.rollback()
            except:
                pass

        # User doesn't exist or needs update - perform upsert
        try:
            # Note: Do NOT rollback before write operations - only before reads
            # First try to update existing user by username (in case keycloak_user_id changed)
            cursor = self.db.execute("""
                UPDATE users
                SET keycloak_user_id = %s,
                    email = %s,
                    full_name = %s,
                    updated_at = NOW()
                WHERE username = %s
                RETURNING *
            """, (keycloak_user_id, email, full_name, username))

            user = cursor.fetchone()

            if not user:
                # User doesn't exist by username, try upsert by keycloak_user_id
                cursor = self.db.execute("""
                    INSERT INTO users (keycloak_user_id, username, email, full_name)
                    VALUES (%s, %s, %s, %s)
                    ON CONFLICT (keycloak_user_id) DO UPDATE
                    SET username = EXCLUDED.username,
                        email = EXCLUDED.email,
                        full_name = EXCLUDED.full_name,
                        updated_at = NOW()
                    RETURNING *
                """, (keycloak_user_id, username, email, full_name))

                user = cursor.fetchone()

            if not user:
                logger.error(f"Failed to fetch user after upsert for {username}")
                self.db.rollback()
                return None

            self.db.commit()

            logger.info(f"User synced: {username} (ID: {user['id']})")
            return user

        except Exception as e:
            logger.error(f"Failed to sync user from JWT: {e}")
            try:
                self.db.rollback()
            except:
                pass
            return None

    def get_user_by_keycloak_id(self, keycloak_user_id: str) -> Optional[Dict]:
        """Get user by Keycloak UUID"""
        try:
            # Ensure clean transaction
            try:
                self.db.rollback()
            except:
                pass

            cursor = self.db.execute(
                "SELECT * FROM users WHERE keycloak_user_id = %s AND is_active = TRUE",
                (keycloak_user_id,)
            )
            return cursor.fetchone()
        except Exception as e:
            logger.error(f"Failed to get user: {e}")
            try:
                self.db.rollback()
            except:
                pass
            return None

    def get_user_pages(self, user_id: int) -> List[Dict]:
        """
        Get all pages the user can access
        Returns list of pages with can_view and can_edit flags

        Args:
            user_id: User's database ID

        Returns:
            List of dicts: [{page_path, page_name, page_category, can_view, can_edit}, ...]
        """
        cache_key = f"user_{user_id}_pages"
        if cache_key in self._permission_cache:
            return self._permission_cache[cache_key]

        try:
            # Ensure clean transaction
            try:
                self.db.rollback()
            except:
                pass

            # Check if system admin (bypass role checks)
            cursor = self.db.execute(
                "SELECT is_admin FROM users WHERE id = %s",
                (user_id,)
            )
            user = cursor.fetchone()

            if user and user['is_admin']:
                # Admin gets all pages with full edit access
                cursor = self.db.execute("""
                    SELECT
                        page_path,
                        page_name,
                        page_category,
                        description,
                        icon,
                        TRUE as can_view,
                        TRUE as can_edit,
                        display_order
                    FROM pages
                    WHERE is_active = TRUE
                      AND page_path != '/unauthorized'
                    ORDER BY display_order
                """)
            else:
                # Get pages based on user's roles
                cursor = self.db.execute("""
                    SELECT DISTINCT
                        p.page_path,
                        p.page_name,
                        p.page_category,
                        p.description,
                        p.icon,
                        MAX(rp.can_view::int)::boolean as can_view,
                        MAX(rp.can_edit::int)::boolean as can_edit,
                        p.display_order
                    FROM users u
                    JOIN user_roles ur ON u.id = ur.user_id
                    JOIN roles r ON ur.role_id = r.id
                    JOIN role_pages rp ON r.id = rp.role_id
                    JOIN pages p ON rp.page_id = p.id
                    WHERE u.id = %s
                      AND u.is_active = TRUE
                      AND p.is_active = TRUE
                      AND (ur.expires_at IS NULL OR ur.expires_at > NOW())
                    GROUP BY p.id, p.page_path, p.page_name, p.page_category,
                             p.description, p.icon, p.display_order
                    ORDER BY p.display_order
                """, (user_id,))

            pages = cursor.fetchall()
            self._permission_cache[cache_key] = pages

            logger.debug(f"User {user_id} has access to {len(pages)} pages")
            return pages

        except Exception as e:
            logger.error(f"Failed to get user pages: {e}")
            try:
                self.db.rollback()
            except:
                pass
            return []

    def can_access_page(self, user_id: int, page_path: str) -> Tuple[bool, bool]:
        """
        Check if user can access a specific page

        Args:
            user_id: User's database ID
            page_path: Page path like '/dashboard' or '/firewall'

        Returns:
            Tuple of (can_access: bool, can_edit: bool)
        """
        pages = self.get_user_pages(user_id)

        for page in pages:
            if page['page_path'] == page_path:
                return True, page.get('can_edit', False)

        return False, False

    def is_admin(self, user_id: int) -> bool:
        """Check if user is system administrator"""
        try:
            # Ensure we have a clean transaction
            try:
                self.db.rollback()
            except:
                pass

            cursor = self.db.execute(
                "SELECT is_admin FROM users WHERE id = %s",
                (user_id,)
            )
            user = cursor.fetchone()

            if not user:
                logger.warning(f"User {user_id} not found in database")
                return False

            return bool(user['is_admin'])
        except Exception as e:
            logger.error(f"Failed to check admin status: {e}")
            try:
                self.db.rollback()
            except:
                pass
            return False

    def get_user_roles(self, user_id: int) -> List[Dict]:
        """Get all roles assigned to a user"""
        try:
            # Ensure clean transaction
            try:
                self.db.rollback()
            except:
                pass

            cursor = self.db.execute("""
                SELECT
                    r.id,
                    r.role_name,
                    r.display_name,
                    r.description,
                    ur.assigned_at,
                    ur.expires_at
                FROM roles r
                JOIN user_roles ur ON r.id = ur.role_id
                WHERE ur.user_id = %s
                  AND (ur.expires_at IS NULL OR ur.expires_at > NOW())
                ORDER BY r.priority DESC
            """, (user_id,))
            return cursor.fetchall()
        except Exception as e:
            logger.error(f"Failed to get user roles: {e}")
            try:
                self.db.rollback()
            except:
                pass
            return []

    def audit_log(self, user_id: Optional[int], username: str, action: str,
                  page_path: Optional[str], result: str, reason: Optional[str] = None):
        """
        Log access attempt for audit trail

        Args:
            user_id: User's database ID (can be None for anonymous)
            username: Username string
            action: Action attempted (e.g., 'page_access', 'api_call')
            page_path: Page path accessed
            result: 'allowed' or 'denied'
            reason: Optional reason for denial
        """
        try:
            ip_address = request.remote_addr if request else None
            user_agent = request.headers.get('User-Agent', '') if request else ''
            request_method = request.method if request else ''
            request_path = request.path if request else ''

            self.db.execute("""
                INSERT INTO audit_log
                (user_id, username, action, page_path, result, reason,
                 ip_address, user_agent, request_method, request_path)
                VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
            """, (user_id, username, action, page_path, result, reason,
                  ip_address, user_agent, request_method, request_path))

            self.db.commit()

        except Exception as e:
            logger.error(f"Failed to write audit log: {e}")
            self.db.rollback()

    def clear_cache(self, user_id: Optional[int] = None):
        """Clear permission cache"""
        if user_id:
            self._permission_cache.pop(f"user_{user_id}_pages", None)
            logger.debug(f"Cleared cache for user {user_id}")
        else:
            self._permission_cache.clear()
            logger.debug("Cleared all permission cache")


# ============================================
# FLASK MIDDLEWARE & DECORATORS
# ============================================

def sync_user_middleware(rbac: RBACManager):
    """
    Enhanced middleware to sync user from Keycloak JWT
    Call this after Keycloak authentication middleware
    Sets g.db_user and g.user_id for downstream use
    """
    # Prevent duplicate sync in same request
    if hasattr(g, '_user_synced') and g._user_synced:
        return

    # Check for token_payload first (set by @require_auth)
    # Don't set _user_synced flag yet - allow retry after @require_auth runs
    if not hasattr(g, 'token_payload') or g.token_payload is None:
        logger.debug("No token_payload in Flask context yet - will retry after auth")
        # Set safe defaults but don't mark as synced (allow retry)
        g.db_user = None
        g.user_id = None
        g.is_admin = False
        return

    # Now we have a token, mark as synced to prevent duplicate sync
    g._user_synced = True

    try:
        # Use token_payload directly (raw JWT claims)
        token_payload = g.token_payload

        # Validate 'sub' claim exists
        if 'sub' not in token_payload:
            logger.error("No 'sub' claim found in JWT token - user identification failed")
            # Set safe defaults
            g.db_user = None
            g.user_id = None
            g.is_admin = False
            return

        # Validate that the sub claim is not empty
        if not token_payload.get('sub'):
            logger.error("Empty 'sub' claim in JWT token")
            g.db_user = None
            g.user_id = None
            g.is_admin = False
            return

        # Attempt to sync user to database
        logger.debug(f"[RBAC] Attempting to sync user: {token_payload.get('preferred_username', 'unknown')} (sub: {token_payload.get('sub')})")

        db_user = rbac.sync_user_from_jwt(token_payload)

        if db_user:
            g.db_user = db_user
            g.user_id = db_user['id']
            g.is_admin = bool(db_user['is_admin'])
            logger.info(f"[RBAC] Successfully synced user: {token_payload.get('preferred_username', 'unknown')} (DB ID: {db_user['id']})")
        else:
            logger.error(f"[RBAC] Failed to sync user from JWT: {token_payload.get('sub')} - database sync returned None")
            # Set safe defaults to prevent downstream crashes
            g.db_user = None
            g.user_id = None
            g.is_admin = False

    except Exception as e:
        logger.error(f"[RBAC] Critical error in sync_user_middleware: {e}", exc_info=True)
        # Set safe defaults to prevent downstream crashes
        g.db_user = None
        g.user_id = None
        g.is_admin = False


def require_page_access(page_path: str):
    """
    Decorator to check if user can access a page
    Must be used after @require_auth

    Usage:
        @app.route('/api/firewall')
        @require_auth
        @require_page_access('/firewall')
        def get_firewall():
            # User can access /firewall page
            # Check g.can_edit to see if they can modify
            pass

    Args:
        page_path: Page path to check (e.g., '/dashboard', '/firewall')
    """
    def decorator(f):
        @wraps(f)
        def wrapper(*args, **kwargs):
            # Get RBAC manager from request context
            if not hasattr(g, 'rbac'):
                return jsonify({'error': 'Service Unavailable', 'message': 'RBAC system not available'}), 503

            rbac = g.rbac

            # Sync user if not already synced (idempotent)
            # Note: Check for None too since before_request may set g.user_id = None
            if not hasattr(g, 'user_id') or g.user_id is None:
                if not hasattr(g, 'token_payload'):
                    return jsonify({'error': 'Unauthorized', 'message': 'User not authenticated'}), 401
                sync_user_middleware(rbac)

            # Check if user is authenticated
            if not hasattr(g, 'db_user') or g.db_user is None or not hasattr(g, 'user_id') or g.user_id is None:
                return jsonify({'error': 'Unauthorized', 'message': 'User not authenticated'}), 401

            # Check page access
            can_access, can_edit = rbac.can_access_page(g.user_id, page_path)

            # Audit log
            username = g.db_user.get('username', 'unknown') if g.db_user else 'unknown'
            rbac.audit_log(
                g.user_id,
                username,
                'page_access',
                page_path,
                'allowed' if can_access else 'denied',
                None if can_access else f'No access to page: {page_path}'
            )

            if not can_access:
                return jsonify({
                    'error': 'Forbidden',
                    'message': f'You do not have access to this page: {page_path}',
                    'page_path': page_path
                }), 403

            # Store can_edit flag for use in route handler
            g.can_edit = can_edit

            return f(*args, **kwargs)
        return wrapper
    return decorator


def require_edit_access(page_path: str):
    """
    Decorator to check if user has edit permission on a page
    Stricter than require_page_access - requires can_edit=True

    Usage:
        @app.route('/api/firewall/block-ip', methods=['POST'])
        @require_auth
        @require_edit_access('/firewall')
        def block_ip():
            # User can edit firewall
            pass
    """
    def decorator(f):
        @wraps(f)
        def wrapper(*args, **kwargs):
            # Get RBAC manager from request context
            if not hasattr(g, 'rbac'):
                return jsonify({'error': 'Service Unavailable', 'message': 'RBAC system not available'}), 503

            rbac = g.rbac

            # Sync user if not already synced (idempotent)
            # Note: Check for None too since before_request may set g.user_id = None
            if not hasattr(g, 'user_id') or g.user_id is None:
                if not hasattr(g, 'token_payload'):
                    return jsonify({'error': 'Unauthorized'}), 401
                sync_user_middleware(rbac)

            # Check authentication
            if not hasattr(g, 'db_user') or g.db_user is None or not hasattr(g, 'user_id') or g.user_id is None:
                return jsonify({'error': 'Unauthorized'}), 401

            # Check access and edit permission
            can_access, can_edit = rbac.can_access_page(g.user_id, page_path)

            # Audit log
            username = g.db_user.get('username', 'unknown') if g.db_user else 'unknown'
            rbac.audit_log(
                g.user_id,
                username,
                'edit_access',
                page_path,
                'allowed' if (can_access and can_edit) else 'denied',
                'No edit permission' if can_access and not can_edit else 'No page access'
            )

            if not can_access:
                return jsonify({
                    'error': 'Forbidden',
                    'message': f'You do not have access to this page: {page_path}'
                }), 403

            if not can_edit:
                return jsonify({
                    'error': 'Forbidden',
                    'message': f'You can only view this page. Edit permission required.',
                    'page_path': page_path
                }), 403

            return f(*args, **kwargs)
        return wrapper
    return decorator


def require_admin():
    """
    Decorator to require system admin access
    Only users with is_admin=TRUE can proceed

    Usage:
        @app.route('/api/admin/roles', methods=['POST'])
        @require_auth
        @require_admin()
        def create_role():
            # Only system admins can create roles
            pass
    """
    def decorator(f):
        @wraps(f)
        def wrapper(*args, **kwargs):
            # Get RBAC manager from request context
            if not hasattr(g, 'rbac'):
                return jsonify({'error': 'Service Unavailable', 'message': 'RBAC system not available'}), 503

            rbac = g.rbac

            # Sync user if not already synced
            # Note: Check for None too since before_request may set g.user_id = None
            if not hasattr(g, 'user_id') or g.user_id is None:
                if not hasattr(g, 'token_payload'):
                    return jsonify({'error': 'Unauthorized'}), 401
                sync_user_middleware(rbac)

            # Check authentication
            if not hasattr(g, 'db_user') or g.db_user is None or not hasattr(g, 'user_id') or g.user_id is None:
                return jsonify({'error': 'Unauthorized'}), 401

            # Check admin status
            if not rbac.is_admin(g.user_id):
                # Audit log
                username = g.db_user.get('username', 'unknown') if g.db_user else 'unknown'
                rbac.audit_log(
                    g.user_id,
                    username,
                    'admin_access',
                    request.path,
                    'denied',
                    'System admin access required'
                )

                return jsonify({
                    'error': 'Forbidden',
                    'message': 'System administrator access required'
                }), 403

            return f(*args, **kwargs)
        return wrapper
    return decorator
