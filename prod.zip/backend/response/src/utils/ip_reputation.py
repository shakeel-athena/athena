"""
IP Reputation Service

Integrates with multiple threat intelligence APIs to get IP reputation data:
- AbuseIPDB: Crowdsourced IP abuse reports
- VirusTotal: Malware and malicious activity detection
- AlienVault OTX: Open Threat Exchange

Author: Claude Code
Date: December 31, 2025
"""

import os
import requests
import logging
from typing import Dict, Optional
from datetime import datetime, timedelta

# Configure logging
logger = logging.getLogger(__name__)


class IPReputationService:
    """Service for fetching IP reputation from multiple sources"""

    def __init__(self):
        """Initialize API keys from environment variables"""
        self.abuseipdb_api_key = os.getenv('ABUSEIPDB_API_KEY')
        self.virustotal_api_key = os.getenv('VIRUSTOTAL_API_KEY')
        self.otx_api_key = os.getenv('OTX_API_KEY')

        # API endpoints
        self.abuseipdb_url = 'https://api.abuseipdb.com/api/v2/check'
        self.virustotal_url = 'https://www.virustotal.com/api/v3/ip_addresses'
        self.otx_url = 'https://otx.alienvault.com/api/v1/indicators/IPv4'

        # Validate configuration
        if not self.abuseipdb_api_key:
            logger.warning("AbuseIPDB API key not configured - IP reputation will be limited")

    def get_comprehensive_reputation(self, ip_address: str) -> Dict:
        """
        Get comprehensive IP reputation from all available sources

        Args:
            ip_address: IP address to check

        Returns:
            Dictionary with reputation data from all sources
        """
        reputation = {
            'ip_address': ip_address,
            'checked_at': datetime.utcnow().isoformat(),
            'sources': {},
            'overall_score': 0,
            'is_malicious': False,
            'threat_level': 'Unknown'
        }

        # Get AbuseIPDB data
        if self.abuseipdb_api_key:
            abuseipdb_data = self.get_abuseipdb_reputation(ip_address)
            if abuseipdb_data:
                reputation['sources']['abuseipdb'] = abuseipdb_data
                reputation['overall_score'] = max(
                    reputation['overall_score'],
                    abuseipdb_data.get('confidence_score', 0)
                )

        # Get VirusTotal data
        if self.virustotal_api_key:
            virustotal_data = self.get_virustotal_reputation(ip_address)
            if virustotal_data:
                reputation['sources']['virustotal'] = virustotal_data

        # Get AlienVault OTX data
        if self.otx_api_key:
            otx_data = self.get_otx_reputation(ip_address)
            if otx_data:
                reputation['sources']['otx'] = otx_data

        # Determine overall malicious status
        reputation['is_malicious'] = reputation['overall_score'] >= 50

        # Classify threat level
        if reputation['overall_score'] >= 75:
            reputation['threat_level'] = 'Critical'
        elif reputation['overall_score'] >= 50:
            reputation['threat_level'] = 'High'
        elif reputation['overall_score'] >= 25:
            reputation['threat_level'] = 'Medium'
        else:
            reputation['threat_level'] = 'Low'

        return reputation

    def get_abuseipdb_reputation(self, ip_address: str, max_age_days: int = 90) -> Optional[Dict]:
        """
        Query AbuseIPDB for IP reputation

        Args:
            ip_address: IP address to check
            max_age_days: Maximum age of reports to consider (default 90 days)

        Returns:
            Dictionary with AbuseIPDB reputation data or None if error
        """
        if not self.abuseipdb_api_key:
            logger.warning("AbuseIPDB API key not configured")
            return None

        try:
            headers = {
                'Key': self.abuseipdb_api_key,
                'Accept': 'application/json'
            }

            params = {
                'ipAddress': ip_address,
                'maxAgeInDays': max_age_days,
                'verbose': True
            }

            response = requests.get(
                self.abuseipdb_url,
                headers=headers,
                params=params,
                timeout=10
            )

            if response.status_code == 200:
                data = response.json().get('data', {})

                reputation = {
                    'confidence_score': data.get('abuseConfidenceScore', 0),
                    'total_reports': data.get('totalReports', 0),
                    'num_distinct_users': data.get('numDistinctUsers', 0),
                    'last_reported_at': data.get('lastReportedAt'),
                    'country_code': data.get('countryCode', 'Unknown'),
                    'country_name': data.get('countryName', 'Unknown'),
                    'usage_type': data.get('usageType', 'Unknown'),
                    'isp': data.get('isp', 'Unknown'),
                    'domain': data.get('domain', 'Unknown'),
                    'is_tor': data.get('isTor', False),
                    'is_whitelisted': data.get('isWhitelisted', False),
                    'abuse_categories': []
                }

                # Parse reports for abuse categories
                reports = data.get('reports', [])
                if reports:
                    categories = set()
                    for report in reports:
                        for category in report.get('categories', []):
                            categories.add(category)
                    reputation['abuse_categories'] = list(categories)

                logger.info(f"AbuseIPDB check for {ip_address}: {reputation['confidence_score']}/100")
                return reputation

            elif response.status_code == 429:
                logger.warning(f"AbuseIPDB API rate limit exceeded for {ip_address}")
                return {
                    'error': 'Rate limit exceeded',
                    'confidence_score': 0
                }
            else:
                logger.error(f"AbuseIPDB API error: {response.status_code} - {response.text}")
                return None

        except requests.exceptions.Timeout:
            logger.error(f"AbuseIPDB API timeout for {ip_address}")
            return None
        except Exception as e:
            logger.error(f"AbuseIPDB API error for {ip_address}: {str(e)}")
            return None

    def get_virustotal_reputation(self, ip_address: str) -> Optional[Dict]:
        """
        Query VirusTotal for IP reputation

        Args:
            ip_address: IP address to check

        Returns:
            Dictionary with VirusTotal reputation data or None if error
        """
        if not self.virustotal_api_key:
            logger.debug("VirusTotal API key not configured")
            return None

        try:
            headers = {
                'x-apikey': self.virustotal_api_key
            }

            response = requests.get(
                f"{self.virustotal_url}/{ip_address}",
                headers=headers,
                timeout=10
            )

            if response.status_code == 200:
                data = response.json().get('data', {})
                attributes = data.get('attributes', {})
                stats = attributes.get('last_analysis_stats', {})

                reputation = {
                    'malicious_count': stats.get('malicious', 0),
                    'suspicious_count': stats.get('suspicious', 0),
                    'harmless_count': stats.get('harmless', 0),
                    'undetected_count': stats.get('undetected', 0),
                    'reputation': attributes.get('reputation', 0),
                    'country': attributes.get('country', 'Unknown'),
                    'asn': attributes.get('asn', 'Unknown'),
                    'as_owner': attributes.get('as_owner', 'Unknown')
                }

                # Calculate confidence score based on detections
                total_engines = sum([
                    reputation['malicious_count'],
                    reputation['suspicious_count'],
                    reputation['harmless_count'],
                    reputation['undetected_count']
                ])

                if total_engines > 0:
                    malicious_ratio = (reputation['malicious_count'] + reputation['suspicious_count']) / total_engines
                    reputation['confidence_score'] = int(malicious_ratio * 100)
                else:
                    reputation['confidence_score'] = 0

                logger.info(f"VirusTotal check for {ip_address}: {reputation['malicious_count']} malicious detections")
                return reputation

            elif response.status_code == 429:
                logger.warning(f"VirusTotal API rate limit exceeded for {ip_address}")
                return {'error': 'Rate limit exceeded', 'confidence_score': 0}
            else:
                logger.error(f"VirusTotal API error: {response.status_code}")
                return None

        except requests.exceptions.Timeout:
            logger.error(f"VirusTotal API timeout for {ip_address}")
            return None
        except Exception as e:
            logger.error(f"VirusTotal API error for {ip_address}: {str(e)}")
            return None

    def get_otx_reputation(self, ip_address: str) -> Optional[Dict]:
        """
        Query AlienVault OTX for IP reputation

        Args:
            ip_address: IP address to check

        Returns:
            Dictionary with OTX reputation data or None if error
        """
        if not self.otx_api_key:
            logger.debug("AlienVault OTX API key not configured")
            return None

        try:
            headers = {
                'X-OTX-API-KEY': self.otx_api_key
            }

            # Get general IP info
            response = requests.get(
                f"{self.otx_url}/{ip_address}/general",
                headers=headers,
                timeout=10
            )

            if response.status_code == 200:
                data = response.json()

                reputation = {
                    'pulse_count': data.get('pulse_info', {}).get('count', 0),
                    'pulses': [],
                    'tags': [],
                    'malware_families': []
                }

                # Get pulse details (threat intelligence reports)
                pulses = data.get('pulse_info', {}).get('pulses', [])
                for pulse in pulses[:5]:  # Limit to 5 most recent pulses
                    reputation['pulses'].append({
                        'name': pulse.get('name', 'Unknown'),
                        'created': pulse.get('created', ''),
                        'tags': pulse.get('tags', []),
                        'malware_families': pulse.get('malware_families', [])
                    })

                    # Collect all tags and malware families
                    reputation['tags'].extend(pulse.get('tags', []))
                    reputation['malware_families'].extend(pulse.get('malware_families', []))

                # Deduplicate
                reputation['tags'] = list(set(reputation['tags']))
                reputation['malware_families'] = list(set(reputation['malware_families']))

                # Calculate confidence score based on pulse count
                if reputation['pulse_count'] > 10:
                    reputation['confidence_score'] = 90
                elif reputation['pulse_count'] > 5:
                    reputation['confidence_score'] = 70
                elif reputation['pulse_count'] > 0:
                    reputation['confidence_score'] = 50
                else:
                    reputation['confidence_score'] = 0

                logger.info(f"OTX check for {ip_address}: {reputation['pulse_count']} pulses")
                return reputation

            elif response.status_code == 429:
                logger.warning(f"OTX API rate limit exceeded for {ip_address}")
                return {'error': 'Rate limit exceeded', 'confidence_score': 0}
            else:
                logger.error(f"OTX API error: {response.status_code}")
                return None

        except requests.exceptions.Timeout:
            logger.error(f"OTX API timeout for {ip_address}")
            return None
        except Exception as e:
            logger.error(f"OTX API error for {ip_address}: {str(e)}")
            return None

    def calculate_reputation_score_for_threat_scoring(self, ip_address: str) -> int:
        """
        Calculate reputation score (0-20 points) for threat scoring system

        Args:
            ip_address: IP address to check

        Returns:
            Integer score from 0-20
        """
        reputation = self.get_comprehensive_reputation(ip_address)

        overall_score = reputation.get('overall_score', 0)

        # Map 0-100 confidence to 0-20 points
        if overall_score >= 75:
            return 20  # Known malicious
        elif overall_score >= 50:
            return 15  # High confidence malicious
        elif overall_score >= 25:
            return 10  # Suspicious
        elif overall_score >= 10:
            return 5   # Slightly suspicious
        else:
            return 0   # Clean or unknown


# Singleton instance
_reputation_service = None


def get_reputation_service() -> IPReputationService:
    """Get singleton instance of reputation service"""
    global _reputation_service
    if _reputation_service is None:
        _reputation_service = IPReputationService()
    return _reputation_service


def get_ip_reputation(ip_address: str) -> Dict:
    """
    Convenience function to get IP reputation

    Args:
        ip_address: IP address to check

    Returns:
        Dictionary with reputation data
    """
    service = get_reputation_service()
    return service.get_comprehensive_reputation(ip_address)


def calculate_reputation_score(ip_address: str) -> int:
    """
    Convenience function to get reputation score for threat scoring

    Args:
        ip_address: IP address to check

    Returns:
        Integer score from 0-20
    """
    service = get_reputation_service()
    return service.calculate_reputation_score_for_threat_scoring(ip_address)


if __name__ == '__main__':
    # Test the service
    logging.basicConfig(level=logging.INFO)

    test_ips = [
        '8.8.8.8',  # Google DNS - should be clean
        '185.220.101.1',  # Known TOR exit node
        '172.16.1.240'  # Your test IP
    ]

    service = IPReputationService()

    for ip in test_ips:
        print(f"\n{'='*80}")
        print(f"Testing IP: {ip}")
        print('='*80)

        reputation = service.get_comprehensive_reputation(ip)
        print(f"\nOverall Score: {reputation['overall_score']}/100")
        print(f"Threat Level: {reputation['threat_level']}")
        print(f"Is Malicious: {reputation['is_malicious']}")

        if 'abuseipdb' in reputation['sources']:
            abuse_data = reputation['sources']['abuseipdb']
            print(f"\nAbuseIPDB:")
            print(f"  Confidence: {abuse_data.get('confidence_score', 0)}/100")
            print(f"  Total Reports: {abuse_data.get('total_reports', 0)}")
            print(f"  Country: {abuse_data.get('country_name', 'Unknown')}")
            print(f"  ISP: {abuse_data.get('isp', 'Unknown')}")
            print(f"  TOR: {abuse_data.get('is_tor', False)}")

        if 'virustotal' in reputation['sources']:
            vt_data = reputation['sources']['virustotal']
            print(f"\nVirusTotal:")
            print(f"  Malicious: {vt_data.get('malicious_count', 0)}")
            print(f"  Suspicious: {vt_data.get('suspicious_count', 0)}")

        if 'otx' in reputation['sources']:
            otx_data = reputation['sources']['otx']
            print(f"\nAlienVault OTX:")
            print(f"  Pulse Count: {otx_data.get('pulse_count', 0)}")
            print(f"  Tags: {', '.join(otx_data.get('tags', [])[:5])}")
