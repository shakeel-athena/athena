import os
import sys
from flask import Flask, request, jsonify, g
from flask_cors import CORS
import boto3
from typing import List, Dict, Any
from dotenv import load_dotenv
from datetime import datetime
import logging
import json

import contextlib
import io

# Add the backend root to Python path for imports
BACKEND_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), "../.."))
PROJECT_ROOT = os.path.abspath(os.path.join(BACKEND_ROOT, ".."))
if BACKEND_ROOT not in sys.path:
    sys.path.insert(0, BACKEND_ROOT)
if PROJECT_ROOT not in sys.path:
    sys.path.insert(0, PROJECT_ROOT)
# Add current directory to path for models
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "../../models"))

# Load environment variables early
load_dotenv(dotenv_path=os.path.join(BACKEND_ROOT, "..", ".env"))

from models.Firewall_IP_Blocking import FirewallIPBlockingManager
from models.Geo_blocking import GeoBlockingManager
from models.WAF_IP_REPU_SIG import WAFIPReputationManager
from models.WAF_CommonAttackManager import WAFCommonAttackManager
from models.WAF_AnonymousIPManager import WAFAnonymousIPManager
from models.WAF_LinuxVulnManager import WAFLinuxVulnManager
from models.WAF_UnixVulnManager import WAFUnixVulnManager
from models.WAF_KnownBadInputsManager import WAFKnownBadInputsManager

# Background Modules Integration
from response.background_modules.module_manager import module_manager

# Alerts Integration
sys.path.insert(0, os.path.join(BACKEND_ROOT, "alerts"))
from alerts.unified_alerts import UnifiedAlertsManager
from alerts.config import (
    WAZUH_HOST, WAZUH_PORT, WAZUH_USERNAME, WAZUH_PASSWORD, WAZUH_VERIFY_SSL,
    SURICATA_LOG_FILE, DEFAULT_ALERTS_LIMIT, DEFAULT_TIME_RANGE_HOURS
)

app = Flask(__name__)
CORS(app)  # Enable CORS for frontend communication

# Configure logging
logger = logging.getLogger(__name__)
logging.basicConfig(level=logging.INFO)

# ============================================================================
# Blueprint Registration
# ============================================================================
from api import waf_bp, alerts_bp, firewall_bp, health_bp, mute_bp, nids_bp
from api.threat_intel import threat_intel_bp
from api.active_response import bp as active_response_bp

app.register_blueprint(waf_bp)
app.register_blueprint(alerts_bp)
app.register_blueprint(firewall_bp)
app.register_blueprint(health_bp)
app.register_blueprint(mute_bp)
app.register_blueprint(threat_intel_bp)
app.register_blueprint(active_response_bp)
app.register_blueprint(nids_bp)

logger.info("All blueprints registered successfully")

# ============================================================================
# Database Connection Setup - Using Shared Infrastructure
# ============================================================================
from utils.rbac import RBACManager

# Try to import shared infrastructure (optional - fallback available)
try:
    from shared.infrastructure.database import DatabaseConnectionManager, DatabaseConfig
    SHARED_DB_AVAILABLE = True
except ImportError:
    # Shared infrastructure not available, will use fallback
    DatabaseConnectionManager = None
    DatabaseConfig = None
    SHARED_DB_AVAILABLE = False
    logger.info("Shared database infrastructure not available, using fallback")

# Global database connection manager
_db_manager = None

def get_db_manager():
    """Get or initialize the shared database connection manager"""
    global _db_manager

    if not SHARED_DB_AVAILABLE:
        # Use fallback from core.database
        from core.database import get_db_connection
        return None  # Will use get_db_connection() directly

    if _db_manager is None:
        try:
            db_config = DatabaseConfig()
            _db_manager = DatabaseConnectionManager(db_config)
            _db_manager.initialize()
            logger.info("Shared database connection manager initialized")
        except Exception as e:
            logger.error(f"Failed to initialize shared database manager: {e}")
            raise

    return _db_manager

def get_db_connection():
    """Get database connection (wrapper for compatibility)"""
    try:
        db_manager = get_db_manager()
        return db_manager.get_connection()
    except Exception as e:
        logger.error(f"Failed to get database connection: {e}")
        return None

@app.before_request
def setup_db_and_rbac():
    """Setup database connection and RBAC for each request"""
    try:
        g.db = get_db_connection()
        if g.db:
            # Create RBAC instance with this connection
            g.rbac = RBACManager(g.db)
        else:
            g.rbac = None
            logger.warning("Database connection not available for request")
    except Exception as e:
        logger.error(f"Failed to setup database connection: {e}")
        g.db = None
        g.rbac = None

@app.teardown_request
def teardown_db(exception):
    """Close database connection after each request"""
    db = getattr(g, 'db', None)
    if db is not None:
        try:
            # Return connection to shared pool
            db_manager = get_db_manager()
            db_manager.return_connection(db)
        except Exception as e:
            logger.error(f"Failed to return connection to pool: {e}")

def get_db_pool_stats():
    """Get database connection pool statistics"""
    try:
        db_manager = get_db_manager()
        return db_manager.get_pool_stats()
    except Exception as e:
        logger.error(f"Failed to get pool stats: {e}")
        return {}

def cleanup_database_connections():
    """Cleanup database connections on shutdown"""
    global _db_manager

    try:
        if _db_manager is not None:
            _db_manager.close()
            _db_manager = None
            logger.info("Shared database connection manager closed")

    except Exception as e:
        logger.error(f"Error cleaning up database connections: {e}")

# ============================================================================
# Security Middleware Integration
# ============================================================================
from api.admin import admin_bp
from utils.rbac import sync_user_middleware
from middleware.rate_limiter import init_rate_limiter, rate_limit, cleanup_rate_limiter
from middleware.validation import init_validation, validate_input, get_validated_data
from middleware.cache import init_cache, cache, cached, CacheManager
from middleware.task_queue import init_task_queue, task_queue, cleanup_task_queue
from middleware.logging import init_logging, structured_logger, log_api_request, log_security_event, log_performance

# Register admin blueprint
app.register_blueprint(admin_bp)

# Initialize security middleware
init_rate_limiter(app)
init_validation(app)

# Initialize Phase 2 middleware
init_cache(app)
init_task_queue(app)
init_logging(app)

# Initialize Phase 3 middleware
from middleware.alert_correlation import init_alert_correlation
from middleware.mitre_visualization import init_mitre_visualization
from middleware.threat_intel_cache import init_threat_intel_cache

init_alert_correlation(app)
init_mitre_visualization(app)
init_threat_intel_cache(app)

# Register RBAC middleware (user sync from JWT to database)
@app.before_request
def sync_user():
    """Sync user from JWT to database - only if already authenticated"""
    # Only sync if user has been authenticated (@require_auth has set token_payload)
    if hasattr(g, 'rbac') and g.rbac is not None and hasattr(g, 'token_payload'):
        sync_user_middleware(g.rbac)

# ============================================================================
# USER RBAC ENDPOINTS
# ============================================================================
from middleware.auth import require_auth

@app.route('/api/user/pages', methods=['GET'])
@require_auth
def get_user_accessible_pages():
    """
    Get all pages the current user can access
    Used by frontend to build navigation menu and check permissions

    Returns:
        200: List of accessible pages with permissions
        503: RBAC system not available
        500: Internal error
    """
    if not hasattr(g, 'rbac') or g.rbac is None:
        return jsonify({
            'success': False,
            'error': 'RBAC system not available',
            'pages': [],
            'roles': [],
            'is_admin': False
        }), 503

    try:
        # Ensure user is synced
        if not hasattr(g, 'user_id') or not g.user_id:
            # Try to sync user if not already synced
            from utils.rbac import sync_user_middleware
            if hasattr(g, 'token_payload') and hasattr(g, 'rbac'):
                sync_user_middleware(g.rbac)

            # Check again after sync attempt
            if not hasattr(g, 'user_id') or not g.user_id:
                return jsonify({
                    'success': False,
                    'error': 'User not authenticated or not synced',
                    'pages': [],
                    'roles': [],
                    'is_admin': False
                }), 401

        # Get user's accessible pages and roles
        pages = g.rbac.get_user_pages(g.user_id)
        roles = g.rbac.get_user_roles(g.user_id)
        is_admin = g.rbac.is_admin(g.user_id)

        return jsonify({
            'success': True,
            'pages': pages,
            'roles': roles,
            'is_admin': is_admin,
            'username': g.db_user.get('username', '') if hasattr(g, 'db_user') else '',
            'email': g.db_user.get('email', '') if hasattr(g, 'db_user') else ''
        }), 200

    except Exception as e:
        logger.error(f"[RBAC] Error getting user pages: {e}", exc_info=True)
        return jsonify({
            'success': False,
            'error': 'Failed to fetch user pages',
            'message': str(e),
            'pages': [],
            'roles': [],
            'is_admin': False
        }), 500

# ============================================================================
# AWS Configuration - Using Shared Infrastructure
# ============================================================================
from shared.infrastructure.aws import AWSClientFactory
from shared.infrastructure.aws.exceptions import AWSCredentialsError, AWSConnectionError

print("[REAL MODE] Response Backend connecting to AWS services")

# Global AWS client factory
_aws_factory = None

def get_aws_factory():
    """Get or initialize the shared AWS client factory"""
    global _aws_factory

    if _aws_factory is None:
        try:
            _aws_factory = AWSClientFactory()
            logger.info("Shared AWS client factory initialized")
        except Exception as e:
            logger.error(f"Failed to initialize AWS factory: {e}")
            raise

    return _aws_factory

def get_aws_session():
    """Get AWS session (compatibility wrapper - deprecated, use get_aws_factory() instead)"""
    logger.warning("get_aws_session() is deprecated, use get_aws_factory() instead")
    try:
        aws_factory = get_aws_factory()
        return aws_factory.session_manager.get_session()
    except Exception as e:
        logger.error(f"Failed to get AWS session: {e}")
        raise

def validate_aws_configuration():
    """Validate AWS configuration and return status"""
    try:
        aws_factory = get_aws_factory()
        creds = aws_factory.validate_credentials()

        return {
            "valid": True,
            "account_id": creds.get('account_id'),
            "user_id": creds.get('user_id'),
            "arn": creds.get('arn'),
            "region": creds.get('region')
        }
    except (AWSCredentialsError, AWSConnectionError) as e:
        return {
            "valid": False,
            "error": str(e)
        }
    except Exception as e:
        return {
            "valid": False,
            "error": f"Unexpected validation error: {e}"
        }

# Cache manager instance for better performance
_firewall_manager = None

def get_firewall_manager():
    """Get FirewallIPBlockingManager instance (cached)."""
    global _firewall_manager
    if _firewall_manager is None:
        session = get_aws_session()
        rule_group_name = os.getenv("FIREWALL_RULE_GROUP", "allow-ingress")
        aws_region = os.getenv("AWS_REGION", "us-east-2")
        _firewall_manager = FirewallIPBlockingManager(session=session, region_name=aws_region, rule_group_name=rule_group_name)
    return _firewall_manager

# Cache WAF signature manager instance for better performance
_waf_signature_manager = None

def get_waf_signature_manager():
    """Get WAFSignatureBlockingManager instance (cached)."""
    global _waf_signature_manager
    if _waf_signature_manager is None:
        from response.models.WAF_Signature_Blocking import WAFSignatureBlockingManager
        session = get_aws_session()
        wafv2_client = session.client('wafv2')
        web_acl_name = os.getenv("WAF_WEB_ACL")
        _waf_signature_manager = WAFSignatureBlockingManager(
            wafv2_client=wafv2_client,
            scope=os.getenv("AWS_SCOPE", "REGIONAL"),
            web_acl_name=web_acl_name
        )
    return _waf_signature_manager

# Helper function for error responses
def error_response(message: str, status_code: int = 400) -> tuple:
    """Return standardized error response."""
    return jsonify({"error": message, "success": False}), status_code

# Helper function for success responses
def success_response(data: Any = None, message: str = "Success") -> tuple:
    """Return standardized success response."""
    response = {"success": True, "message": message}
    if data is not None:
        response["data"] = data
    return jsonify(response), 200

@app.route('/health', methods=['GET'])
def health_check():
    """Basic health check endpoint."""
    cfg = {
        "status": "healthy",
        "aws_profile": os.getenv("AWS_PROFILE"),
        "aws_region": os.getenv("AWS_REGION", "us-east-2"),
        "aws_scope": os.getenv("AWS_SCOPE", "REGIONAL"),
        "waf_web_acl": os.getenv("WAF_WEB_ACL"),
        "firewall_rule_group": os.getenv("FIREWALL_RULE_GROUP", "allow-ingress")
    }
    return success_response(cfg, "Service is running")

@app.route('/api/health/comprehensive', methods=['GET'])
def comprehensive_health_check():
    """Comprehensive health check including authentication, database, and AWS services."""
    try:
        health_status = {
            "status": "healthy",
            "timestamp": datetime.utcnow().isoformat() + "Z",
            "checks": {}
        }
        
        # Database Health Check
        try:
            db_conn = get_db_connection()
            if db_conn:
                cursor = db_conn.execute("SELECT 1 as test")
                result = cursor.fetchone()
                if result and result['test'] == 1:
                    health_status["checks"]["database"] = {
                        "status": "healthy",
                        "message": "Database connection successful"
                    }
                else:
                    health_status["checks"]["database"] = {
                        "status": "unhealthy",
                        "message": "Database query failed"
                    }
                    health_status["status"] = "degraded"
            else:
                health_status["checks"]["database"] = {
                    "status": "unhealthy",
                    "message": "Database connection failed"
                }
                health_status["status"] = "unhealthy"
        except Exception as db_error:
            health_status["checks"]["database"] = {
                "status": "unhealthy",
                "message": f"Database error: {str(db_error)}"
            }
            health_status["status"] = "unhealthy"
        
        # AWS Configuration Health Check
        aws_config = validate_aws_configuration()
        health_status["checks"]["aws"] = aws_config
        
        if not aws_config["valid"]:
            health_status["status"] = "degraded"
        
        # Keycloak Configuration Check
        try:
            keycloak_url = os.getenv("KEYCLOAK_URL")
            keycloak_realm = os.getenv("KEYCLOAK_REALM", "athena")
            
            if keycloak_url:
                # Test Keycloak connectivity
                import requests
                keycloak_test_url = f"{keycloak_url}/realms/{keycloak_realm}/.well-known/openid_configuration"
                response = requests.get(keycloak_test_url, timeout=5)
                
                if response.status_code == 200:
                    health_status["checks"]["keycloak"] = {
                        "status": "healthy",
                        "message": "Keycloak is accessible",
                        "url": keycloak_url,
                        "realm": keycloak_realm
                    }
                else:
                    health_status["checks"]["keycloak"] = {
                        "status": "degraded",
                        "message": f"Keycloak returned status {response.status_code}",
                        "url": keycloak_url,
                        "realm": keycloak_realm
                    }
                    health_status["status"] = "degraded"
            else:
                health_status["checks"]["keycloak"] = {
                    "status": "unhealthy",
                    "message": "Keycloak URL not configured"
                }
                health_status["status"] = "unhealthy"
        except Exception as keycloak_error:
            health_status["checks"]["keycloak"] = {
                "status": "unhealthy",
                "message": f"Keycloak connectivity error: {str(keycloak_error)}"
            }
            health_status["status"] = "degraded"
        
        # Authentication Flow Check
        try:
            if hasattr(g, 'rbac') and g.rbac is not None:
                health_status["checks"]["authentication"] = {
                    "status": "healthy",
                    "message": "RBAC system initialized"
                }
            else:
                health_status["checks"]["authentication"] = {
                    "status": "degraded",
                    "message": "RBAC system not available"
                }
                health_status["status"] = "degraded"
        except Exception as auth_error:
            health_status["checks"]["authentication"] = {
                "status": "unhealthy",
                "message": f"Authentication system error: {str(auth_error)}"
            }
            health_status["status"] = "unhealthy"
        
        # Service-Specific Checks
        health_status["checks"]["services"] = {}
        
        # Firewall Service Check
        try:
            if os.getenv("FIREWALL_RULE_GROUP"):
                health_status["checks"]["services"]["firewall"] = {
                    "status": "configured",
                    "message": "Firewall rule group configured"
                }
            else:
                health_status["checks"]["services"]["firewall"] = {
                    "status": "not_configured",
                    "message": "FIREWALL_RULE_GROUP not set"
                }
        except Exception as firewall_error:
            health_status["checks"]["services"]["firewall"] = {
                "status": "error",
                "message": f"Firewall service error: {str(firewall_error)}"
            }
        
        # WAF Service Check
        try:
            if os.getenv("WAF_WEB_ACL"):
                health_status["checks"]["services"]["waf"] = {
                    "status": "configured",
                    "message": "WAF Web ACL configured"
                }
            else:
                health_status["checks"]["services"]["waf"] = {
                    "status": "not_configured",
                    "message": "WAF_WEB_ACL not set"
                }
        except Exception as waf_error:
            health_status["checks"]["services"]["waf"] = {
                "status": "error",
                "message": f"WAF service error: {str(waf_error)}"
            }
        
        # Environment Configuration Summary
        health_status["environment"] = {
            "aws_region": os.getenv("AWS_REGION", "us-east-2"),
            "aws_profile": os.getenv("AWS_PROFILE"),
            "keycloak_url": os.getenv("KEYCLOAK_URL"),
            "keycloak_realm": os.getenv("KEYCLOAK_REALM", "athena"),
            "firewall_rule_group": os.getenv("FIREWALL_RULE_GROUP"),
            "waf_web_acl": os.getenv("WAF_WEB_ACL"),
            "database_configured": bool(os.getenv("POSTGRES_HOST") or os.getenv("DB_HOST"))
        }
        
        # Determine overall status
        overall_status = health_status["status"]
        if overall_status == "healthy":
            message = "All systems operational"
        elif overall_status == "degraded":
            message = "Some systems degraded but functional"
        else:
            message = "Critical system failures detected"
        
        return success_response(health_status, message)
        
    except Exception as e:
        logger.error(f"Comprehensive health check failed: {e}")
        return error_response(f"Health check failed: {str(e)}", 500)

# ============================================================================
# Alerts Management Endpoints - DISABLED
# Now handled by Alerts Blueprint (src/api/alerts/routes.py)
# ============================================================================

# Cache unified alerts manager instance
_unified_alerts_manager = None

def _parse_time_range_arg(value, default_hours):
    if value is None:
        return default_hours
    if isinstance(value, int):
        return value
    try:
        stripped = str(value).strip().lower()
        if stripped.isdigit():
            return int(stripped)
        suffix_map = {
            'h': 1,
            'd': 24,
            'w': 24 * 7,
            'm': 24 * 30,
        }
        magnitude = int(stripped[:-1])
        multiplier = suffix_map.get(stripped[-1])
        if multiplier:
            return magnitude * multiplier
    except (ValueError, TypeError):
        pass
    raise ValueError("Invalid time_range value")

def get_unified_alerts_manager():
    """Get UnifiedAlertsManager instance (cached)"""
    global _unified_alerts_manager
    if _unified_alerts_manager is None:
        _unified_alerts_manager = UnifiedAlertsManager(
            wazuh_host=WAZUH_HOST,
            wazuh_port=WAZUH_PORT,
            wazuh_user=WAZUH_USERNAME,
            wazuh_pass=WAZUH_PASSWORD,
            suricata_log=SURICATA_LOG_FILE,
            verify_ssl=WAZUH_VERIFY_SSL
        )
    return _unified_alerts_manager

@app.route('/api/health', methods=['GET'])
def api_health():
    return health_check()


# ============================================================================
# System Health Monitoring
# ============================================================================
from services.system_health import SystemHealthMonitor

@app.route('/api/system-health', methods=['GET'])
def get_system_health():
    """
    Get system health metrics for the local machine

    Returns:
        JSON response with CPU, memory, disk, network, updates, and SMART health
    """
    try:
        import time
        logger.info("[System Health] Fetching system health metrics...")
        start_time = time.time()

        # Initialize system health monitor with Wazuh connection params
        monitor = SystemHealthMonitor(
            wazuh_host=WAZUH_HOST,
            wazuh_port=WAZUH_PORT,
            wazuh_user=WAZUH_USERNAME,
            wazuh_pass=WAZUH_PASSWORD,
            verify_ssl=WAZUH_VERIFY_SSL
        )

        # Get all metrics
        metrics = monitor.get_all_metrics()

        elapsed = time.time() - start_time
        logger.info(f"[System Health] Metrics collected in {elapsed:.2f}s")

        return jsonify({
            'success': True,
            'data': metrics,
            'timestamp': datetime.now().isoformat()
        })

    except Exception as e:
        logger.error(f"Error fetching system health: {e}", exc_info=True)
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500


# ============================================================================
# Firewall IP Management Endpoints - DISABLED
# Now handled by Firewall Blueprint (src/api/firewall/routes.py)
# ============================================================================

# ============================================================================
# WAF Signature Management Endpoints - DISABLED
# Now handled by WAF Blueprint (src/api/waf/routes.py)
# ============================================================================

@app.errorhandler(404)
def not_found(error):
    """Handle 404 errors."""
    return error_response("Endpoint not found", 404)

@app.errorhandler(500)
def internal_error(error):
    """Handle 500 errors."""
    return error_response("Internal server error", 500)

# --- Minimal endpoints for Unified GUI compatibility ---
# In-memory policy store (basic placeholder)
POLICY_STATE = {
    "rules": []
}

@app.route('/api/policies', methods=['GET'])
def get_policies():
    """Return response policies (placeholder)."""
    try:
        return success_response(POLICY_STATE, "Policies retrieved")
    except Exception as e:
        return error_response(f"Failed to get policies: {str(e)}", 500)

@app.route('/api/policies', methods=['PUT'])
def put_policies():
    """Update response policies (placeholder)."""
    try:
        data = request.get_json() or {}
        if not isinstance(data, dict) or 'rules' not in data:
            return error_response("Payload must be an object with 'rules' array", 400)
        if not isinstance(data['rules'], list):
            return error_response("'rules' must be an array", 400)
        POLICY_STATE['rules'] = data['rules']
        return success_response(POLICY_STATE, "Policies updated")
    except Exception as e:
        return error_response(f"Failed to update policies: {str(e)}", 500)

@app.route('/api/dashboard', methods=['GET'])
def get_dashboard():
    """Return dashboard data in the exact shape the UI expects (no wrapper)."""
    try:
        now_iso = datetime.utcnow().isoformat() + "Z"
        payload = {
            "overview": {
                "last_updated": now_iso,
                "time_range": "24h",
                "total_alerts": 0,
                "actions_executed": 0,
                "average_response_time_ms": 120,
                "actions_successful": 0,
            },
            "threat_distribution": {
                "by_type": [
                    {"type": "sql_injection", "count": 0, "percentage": 0, "trend": "+0%"},
                    {"type": "xss", "count": 0, "percentage": 0, "trend": "+0%"},
                    {"type": "path_traversal", "count": 0, "percentage": 0, "trend": "+0%"},
                    {"type": "other", "count": 0, "percentage": 0, "trend": "+0%"},
                ]
            },
            "geographic_threats": {
                "coordinates": [
                    {"country": "United States", "city": "New York", "lat": 40.7128, "lng": -74.0060, "count": 0},
                    {"country": "Germany", "city": "Frankfurt", "lat": 50.1109, "lng": 8.6821, "count": 0},
                    {"country": "Singapore", "city": "Singapore", "lat": 1.3521, "lng": 103.8198, "count": 0},
                ]
            },
            "response_actions": {
                "by_action_type": [
                    {"provider": "waf", "action": "block_ip", "count": 0, "avg_time_ms": 0, "success_rate": 100},
                    {"provider": "waf", "action": "challenge", "count": 0, "avg_time_ms": 0, "success_rate": 100},
                    {"provider": "firewall", "action": "rate_limit_subnet", "count": 0, "avg_time_ms": 0, "success_rate": 100},
                ]
            },
            "time_series": {
                "alerts": [],
                "actions": []
            }
        }
        return jsonify(payload), 200
    except Exception as e:
        return error_response(f"Failed to get dashboard: {str(e)}", 500)

# Geo-restrictions Management Endpoints

# Cache geo-restrictions manager instance for better performance
_geo_manager = None

def get_geo_manager():
    """Get NetworkFirewallGeoBlockingManager instance (cached)."""
    global _geo_manager
    if _geo_manager is None:
        try:
            from models.NF_geo_blocking import NetworkFirewallGeoBlockingManager
            session = get_aws_session()
            _geo_manager = NetworkFirewallGeoBlockingManager(session.client("network-firewall"), "geo-restrictions")
        except Exception as e:
            print(f"Error initializing geo manager: {e}")
            return None
    return _geo_manager

@app.route('/api/geo-restrictions/countries', methods=['GET'])
def get_geo_countries():
    """Get current allowed countries."""
    try:
        geo_manager = get_geo_manager()
        if geo_manager is None:
            return error_response("Geo-restrictions manager not available", 500)

        countries = geo_manager.get_current_countries()
        return success_response(countries, "Countries retrieved successfully")
    except Exception as e:
        return error_response(f"Failed to get countries: {str(e)}", 500)

@app.route('/api/geo-restrictions/countries', methods=['POST'])
def add_geo_countries():
    """Add countries to the allowed list."""
    try:
        data = request.get_json()
        if not data or 'countries' not in data:
            return error_response("Countries list is required", 400)

        countries = data['countries']
        if isinstance(countries, str):
            countries = [c.strip() for c in countries.split(',') if c.strip()]

        geo_manager = get_geo_manager()
        if geo_manager is None:
            return error_response("Geo-restrictions manager not available", 500)

        result = geo_manager.add_countries(countries)
        return success_response(result, f"Added {len(countries)} countries")
    except Exception as e:
        return error_response(f"Failed to add countries: {str(e)}", 500)

@app.route('/api/geo-restrictions/countries', methods=['DELETE'])
def remove_geo_countries():
    """Remove countries from the allowed list."""
    try:
        data = request.get_json()
        if not data or 'countries' not in data:
            return error_response("Countries list is required", 400)

        countries = data['countries']
        if isinstance(countries, str):
            countries = [c.strip() for c in countries.split(',') if c.strip()]

        geo_manager = get_geo_manager()
        if geo_manager is None:
            return error_response("Geo-restrictions manager not available", 500)

        result = geo_manager.remove_countries(countries)
        return success_response(result, f"Removed {len(countries)} countries")
    except Exception as e:
        return error_response(f"Failed to remove countries: {str(e)}", 500)

@app.route('/api/geo-restrictions/countries', methods=['PUT'])
def set_geo_countries():
    """Set the complete list of allowed countries."""
    try:
        data = request.get_json()
        if not data or 'countries' not in data:
            return error_response("Countries list is required", 400)

        countries = data['countries']
        if isinstance(countries, str):
            countries = [c.strip() for c in countries.split(',') if c.strip()]

        geo_manager = get_geo_manager()
        if geo_manager is None:
            return error_response("Geo-restrictions manager not available", 500)

        result = geo_manager.set_countries(countries)
        return success_response(result, f"Set {len(countries)} countries")
    except Exception as e:
        return error_response(f"Failed to set countries: {str(e)}", 500)

@app.route('/api/geo-restrictions/validate', methods=['POST'])
def validate_geo_countries():
    """Validate country codes."""
    try:
        data = request.get_json()
        if not data or 'countries' not in data:
            return error_response("Countries list is required", 400)

        countries = data['countries']
        if isinstance(countries, str):
            countries = [c.strip() for c in countries.split(',') if c.strip()]

        geo_manager = get_geo_manager()
        if geo_manager is None:
            return error_response("Geo-restrictions manager not available", 500)

        result = geo_manager.validate_country_codes(countries)
        return success_response(result, "Countries validated")
    except Exception as e:
        return error_response(f"Failed to validate countries: {str(e)}", 500)

# Background Modules Integration

# Background Modules API Endpoints
@app.route('/api/background-modules/status', methods=['GET'])
def get_background_modules_status():
    """Get status of all background modules"""
    try:
        status = module_manager.get_all_status()
        return jsonify({
            'success': True,
            'data': status
        })
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@app.route('/api/background-modules/<module_name>/toggle', methods=['POST'])
def toggle_background_module(module_name):
    """Toggle a background module on/off"""
    try:
        data = request.get_json()
        enabled = data.get('enabled', False)

        success = module_manager.toggle_module(module_name, enabled)

        if success:
            return jsonify({
                'success': True,
                'message': f'{module_name} module {"enabled" if enabled else "disabled"}'
            })
        else:
            return jsonify({
                'success': False,
                'error': f'Failed to toggle {module_name} module'
            }), 400

    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@app.route('/api/background-modules/<module_name>/interval', methods=['POST'])
def update_background_module_interval(module_name):
    """Update trigger interval for a module"""
    try:
        data = request.get_json()
        hours = data.get('hours', 6)

        if not isinstance(hours, (int, float)) or hours <= 0:
            return jsonify({
                'success': False,
                'error': 'Invalid interval. Must be a positive number.'
            }), 400

        success = module_manager.update_interval(module_name, hours)

        if success:
            return jsonify({
                'success': True,
                'message': f'{module_name} module interval updated to {hours} hours'
            })
        else:
            return jsonify({
                'success': False,
                'error': f'Failed to update interval for {module_name} module'
            }), 400

    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@app.route('/api/background-modules/ip-lists', methods=['GET'])
def get_background_modules_ip_lists():
    """Get current IP lists from both modules"""
    try:
        ip_lists = module_manager.get_ip_lists()
        return jsonify({
            'success': True,
            'data': ip_lists
        })
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@app.route('/api/background-modules/start', methods=['POST'])
def start_background_modules():
    """Start all background modules"""
    try:
        module_manager.start_all()
        return jsonify({
            'success': True,
            'message': 'All background modules started'
        })
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@app.route('/api/background-modules/stop', methods=['POST'])
def stop_background_modules():
    """Stop all background modules"""
    try:
        module_manager.stop_all()
        return jsonify({
            'success': True,
            'message': 'All background modules stopped'
        })
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@app.route('/api/background-modules/<module_name>/config', methods=['POST'])
def update_module_config(module_name):
    """Update module configuration"""
    try:
        data = request.get_json()
        interval_hours = data.get('interval_hours', 0)
        interval_minutes = data.get('interval_minutes', 5)
        date_range_days = data.get('date_range_days', 7)

        success = module_manager.update_module_config(
            module_name,
            interval_hours,
            interval_minutes,
            date_range_days
        )

        if success:
            return jsonify({
                'success': True,
                'message': f'{module_name} configuration updated successfully'
            })
        else:
            return jsonify({
                'success': False,
                'error': f'Failed to update {module_name} configuration'
            }), 400

    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

if __name__ == '__main__':
    port = int(os.environ.get('PORT', 5000))
    debug = os.environ.get('DEBUG', 'False').lower() == 'true'

    print(f"Starting Enhanced Athena API Server on port {port}")
    print(f"Debug mode: {debug}")
    print("")
    print("Available endpoints:")
    print("  GET  /health                              - Health check")
    print("")
    print(" Firewall Management:")
    print("  GET  /api/firewall/ip-sets                - Get all IP sets")
    print("  GET  /api/firewall/allow-list             - Get allow list")
    print("  GET  /api/firewall/block-list             - Get block list")
    print("  POST /api/firewall/allow-list             - Add IPs to allow list")
    print("  POST /api/firewall/block-list             - Add IPs to block list")
    print("  DELETE /api/firewall/allow-list           - Remove IPs from allow list")
    print("  DELETE /api/firewall/block-list           - Remove IPs from block list")
    print("  GET  /api/firewall/debug                  - Debug resources")
    print("  POST /api/firewall/transfer-ip            - Transfer IP from one list to another")
    print("")
    print("  WAF Signature Management:")
    print("  GET  /api/waf-signatures/available        - Get available signatures")
    print("  GET  /api/waf-signatures/custom           - Get custom signatures")
    print("  GET  /api/waf-signatures/aws-managed      - Get AWS managed rules")
    print("  GET  /api/waf-signatures/status           - Get signature status")
    print("  GET  /api/waf-signatures/active           - Get active signatures")
    print("  POST /api/waf-signatures/add              - Add single signature")
    print("  POST /api/waf-signatures/remove           - Remove single signature")
    print("  POST /api/waf-signatures/toggle           - Toggle signature")
    print("  POST /api/waf-signatures/add-multiple     - Add multiple signatures")
    print("  POST /api/waf-signatures/remove-multiple  - Remove multiple signatures")
    print("  POST /api/waf-signatures/add-all          - Add all signatures")
    print("  POST /api/waf-signatures/remove-all       - Remove all signatures")
    print("")
    print("  Geo-restrictions Management:")
    print("  GET  /api/geo-restrictions/countries        - Get allowed countries")
    print("  POST /api/geo-restrictions/countries        - Add countries to allowed list")
    print("  DELETE /api/geo-restrictions/countries      - Remove countries from allowed list")
    print("  PUT  /api/geo-restrictions/countries        - Set complete countries list")
    print("  POST /api/geo-restrictions/validate        - Validate country codes")
    print("")
    print("  Background Modules Management:")
    print("  GET  /api/background-modules/status                    - Get status of all background modules")
    print("  POST /api/background-modules/<module>/toggle          - Toggle module on/off")
    print("  POST /api/background-modules/<module>/interval        - Update trigger interval")
    print("  GET  /api/background-modules/ip-lists                 - Get IP lists from modules")
    print("  POST /api/background-modules/start                    - Start all modules")
    print("  POST /api/background-modules/stop                     - Stop all modules")
    print("")
    print("  NIDS Dashboard:")
    print("  GET  /api/nids/overview                   - Get NIDS dashboard overview")
    print("  GET  /api/nids/events                     - Get paginated NIDS events")
    print("  GET  /api/nids/events/<id>                - Get event details by ID")
    print("  GET  /api/nids/timeline                   - Get timeline chart data")
    print("  GET  /api/nids/network-analysis           - Get network analysis data")
    print("  GET  /api/nids/filters                    - Get available filter options")
    print("  GET  /api/nids/health                     - Get NIDS service health status")
    print("")

    # Start background modules
    module_manager.start_all()

    app.run(host='0.0.0.0', port=port, debug=debug)
