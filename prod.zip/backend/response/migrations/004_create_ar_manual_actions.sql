-- ============================================================================
-- Active Response Manual Actions Audit Log Table
-- ============================================================================
-- Purpose: Track all manual AR block/unblock actions for audit trail
-- Created: 2025-12-30
-- ============================================================================

-- Enable UUID extension if not already enabled
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- Create ar_manual_actions table
CREATE TABLE IF NOT EXISTS ar_manual_actions (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    action_type VARCHAR(10) NOT NULL CHECK (action_type IN ('block', 'unblock')),
    ip_address VARCHAR(45) NOT NULL,
    agent_id VARCHAR(50) NOT NULL,
    timeout_seconds INTEGER DEFAULT 0,
    reason TEXT NOT NULL,
    analyst VARCHAR(100) NOT NULL,
    created_at TIMESTAMP DEFAULT NOW()
);

-- Create indexes for performance
CREATE INDEX IF NOT EXISTS idx_ar_manual_actions_created_at ON ar_manual_actions(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_ar_manual_actions_analyst ON ar_manual_actions(analyst);
CREATE INDEX IF NOT EXISTS idx_ar_manual_actions_ip ON ar_manual_actions(ip_address);
CREATE INDEX IF NOT EXISTS idx_ar_manual_actions_agent ON ar_manual_actions(agent_id);
CREATE INDEX IF NOT EXISTS idx_ar_manual_actions_type ON ar_manual_actions(action_type);

-- Add comment to table
COMMENT ON TABLE ar_manual_actions IS 'Audit log for manual Active Response block/unblock actions performed by analysts';

-- Add column comments
COMMENT ON COLUMN ar_manual_actions.id IS 'Unique identifier for the manual action';
COMMENT ON COLUMN ar_manual_actions.action_type IS 'Type of action: block or unblock';
COMMENT ON COLUMN ar_manual_actions.ip_address IS 'IP address that was blocked or unblocked';
COMMENT ON COLUMN ar_manual_actions.agent_id IS 'Wazuh agent ID where action was performed (or "all")';
COMMENT ON COLUMN ar_manual_actions.timeout_seconds IS 'Block duration in seconds (0 for unblock)';
COMMENT ON COLUMN ar_manual_actions.reason IS 'Justification for the manual action';
COMMENT ON COLUMN ar_manual_actions.analyst IS 'Username of analyst who performed the action';
COMMENT ON COLUMN ar_manual_actions.created_at IS 'Timestamp when action was performed';

-- Grant permissions (adjust based on your user setup)
GRANT SELECT, INSERT ON ar_manual_actions TO athena_user;

-- Success message
DO $$
BEGIN
    RAISE NOTICE '✅ ar_manual_actions table created successfully';
    RAISE NOTICE '✅ Indexes created for performance';
    RAISE NOTICE '✅ Ready to track manual AR actions';
END $$;
