-- Migration: Create wazuh_active_response_log table
-- Purpose: Audit trail for Wazuh Active Response auto-blocks
-- Created: 2025-12-22
-- Aligns with existing schema patterns from firewall_audit_log and audit_log

CREATE TABLE IF NOT EXISTS wazuh_active_response_log (
    id uuid DEFAULT gen_random_uuid() NOT NULL,

    -- Block details
    ip_address character varying(45) NOT NULL,
    action character varying(20) NOT NULL,
    agent_id character varying(50) NOT NULL,
    agent_name character varying(255),

    -- Alert context
    alert_id character varying(255),
    alert_source character varying(20),
    risk_score numeric(5,2),

    -- Block configuration
    command character varying(100) DEFAULT 'firewall-drop'::character varying,
    timeout_seconds integer DEFAULT 1800 NOT NULL,

    -- Timing
    blocked_at timestamp without time zone DEFAULT now() NOT NULL,
    expires_at timestamp without time zone NOT NULL,
    unblocked_at timestamp without time zone,

    -- Decision metadata
    auto_block boolean DEFAULT false NOT NULL,
    triggered_by character varying(100),
    block_reason text,

    -- Success tracking
    success boolean DEFAULT true NOT NULL,
    error_message text,

    -- Audit
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,

    -- Constraints
    CONSTRAINT wazuh_active_response_log_pkey PRIMARY KEY (id),
    CONSTRAINT valid_action CHECK ((action::text = ANY (ARRAY['BLOCK'::character varying, 'UNBLOCK'::character varying]::text[]))),
    CONSTRAINT valid_alert_source CHECK ((alert_source IS NULL) OR (alert_source::text = ANY (ARRAY['wazuh'::character varying, 'suricata'::character varying]::text[]))),
    CONSTRAINT valid_risk_score CHECK ((risk_score IS NULL) OR ((risk_score >= 0) AND (risk_score <= 100)))
);

-- Indexes
CREATE INDEX idx_war_ip_address ON wazuh_active_response_log(ip_address);
CREATE INDEX idx_war_agent_id ON wazuh_active_response_log(agent_id);
CREATE INDEX idx_war_blocked_at ON wazuh_active_response_log(blocked_at DESC);
CREATE INDEX idx_war_expires_at ON wazuh_active_response_log(expires_at);
CREATE INDEX idx_war_auto_block ON wazuh_active_response_log(auto_block);
CREATE INDEX idx_war_alert_id ON wazuh_active_response_log(alert_id) WHERE alert_id IS NOT NULL;
CREATE INDEX idx_war_active_blocks ON wazuh_active_response_log(ip_address, expires_at)
    WHERE unblocked_at IS NULL AND success = TRUE;

-- Trigger for updated_at
-- Trigger to automatically update updated_at timestamp
-- Uses existing update_updated_at_column() function from database
CREATE TRIGGER trigger_update_updated_at
    BEFORE UPDATE ON wazuh_active_response_log
    FOR EACH ROW
    EXECUTE FUNCTION update_updated_at_column();

-- Comments for documentation
COMMENT ON TABLE wazuh_active_response_log IS 'Complete audit trail of Wazuh Active Response block/unblock actions for compliance (SOC2/GDPR/HIPAA)';
COMMENT ON COLUMN wazuh_active_response_log.ip_address IS 'IP address that was blocked/unblocked';
COMMENT ON COLUMN wazuh_active_response_log.action IS 'Type of action: BLOCK or UNBLOCK';
COMMENT ON COLUMN wazuh_active_response_log.agent_id IS 'Wazuh agent ID where block was applied (e.g., "001", "002")';
COMMENT ON COLUMN wazuh_active_response_log.alert_id IS 'Original alert ID from Elasticsearch that triggered this block';
COMMENT ON COLUMN wazuh_active_response_log.alert_source IS 'Source of alert: wazuh or suricata';
COMMENT ON COLUMN wazuh_active_response_log.risk_score IS 'Calculated risk score (0-100) at time of block decision';
COMMENT ON COLUMN wazuh_active_response_log.timeout_seconds IS 'Block duration in seconds (default: 1800 = 30 minutes per user requirements)';
COMMENT ON COLUMN wazuh_active_response_log.blocked_at IS 'Timestamp when block was initiated';
COMMENT ON COLUMN wazuh_active_response_log.expires_at IS 'Timestamp when block expires (blocked_at + timeout_seconds)';
COMMENT ON COLUMN wazuh_active_response_log.unblocked_at IS 'NULL if still active; set when manually unblocked or expired';
COMMENT ON COLUMN wazuh_active_response_log.auto_block IS 'TRUE if automatically blocked (risk≥80, FP≤20%, confirmed pattern); FALSE if manual analyst action';
COMMENT ON COLUMN wazuh_active_response_log.triggered_by IS 'Username who triggered block or "auto_block_engine" for automated blocks';
COMMENT ON COLUMN wazuh_active_response_log.block_reason IS 'Human-readable explanation for why IP was blocked';
COMMENT ON COLUMN wazuh_active_response_log.success IS 'Whether Wazuh API call succeeded';
COMMENT ON COLUMN wazuh_active_response_log.error_message IS 'Error details if success=FALSE';
