-- Migration: Create threat_scores table
-- Purpose: Store calculated risk scores and threat intelligence analysis for each alert
-- Created: 2025-12-22

CREATE TABLE IF NOT EXISTS threat_scores (
    id SERIAL PRIMARY KEY,

    -- Alert identification
    alert_id VARCHAR(255) NOT NULL,
    alert_source VARCHAR(50) NOT NULL,  -- 'wazuh' or 'suricata'
    alert_timestamp TIMESTAMP NOT NULL,

    -- IP information
    ip_address VARCHAR(45) NOT NULL,  -- IPv4 or IPv6
    is_private_ip BOOLEAN NOT NULL DEFAULT FALSE,

    -- Risk scoring components
    risk_score DECIMAL(5,2) NOT NULL CHECK (risk_score >= 0 AND risk_score <= 100),
    risk_level VARCHAR(20) NOT NULL,  -- 'Critical', 'High', 'Medium', 'Low'

    -- Threat intelligence scores (0-100 scale)
    abuseipdb_score DECIMAL(5,2) DEFAULT NULL,
    virustotal_score DECIMAL(5,2) DEFAULT NULL,
    otx_score DECIMAL(5,2) DEFAULT NULL,

    -- Risk factors
    severity_score DECIMAL(5,2) NOT NULL,  -- Based on alert severity
    geo_anomaly_score DECIMAL(5,2) DEFAULT 0,  -- Geographic anomaly detection
    network_anomaly_score DECIMAL(5,2) DEFAULT 0,  -- Network behavior anomaly

    -- False positive analysis
    fp_probability DECIMAL(5,2) NOT NULL CHECK (fp_probability >= 0 AND fp_probability <= 100),
    fp_reasons TEXT[] DEFAULT NULL,  -- Array of FP indicators

    -- Scoring metadata
    scoring_factors JSONB NOT NULL,  -- Complete breakdown of score calculation
    recommendation VARCHAR(50) NOT NULL,  -- 'auto_block', 'review', 'monitor', 'ignore'
    confidence_level DECIMAL(5,2) NOT NULL,  -- 0-100 confidence in scoring

    -- Auto-block decision
    auto_block_eligible BOOLEAN NOT NULL DEFAULT FALSE,
    auto_block_reason TEXT DEFAULT NULL,
    confirmed_malicious_pattern VARCHAR(100) DEFAULT NULL,  -- Pattern type if confirmed

    -- Timestamps
    scored_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    enrichment_completed_at TIMESTAMP DEFAULT NULL,

    -- Audit
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

-- Indexes for performance
CREATE INDEX idx_threat_scores_alert_id ON threat_scores(alert_id);
CREATE INDEX idx_threat_scores_ip_address ON threat_scores(ip_address);
CREATE INDEX idx_threat_scores_risk_score ON threat_scores(risk_score DESC);
CREATE INDEX idx_threat_scores_risk_level ON threat_scores(risk_level);
CREATE INDEX idx_threat_scores_auto_block_eligible ON threat_scores(auto_block_eligible);
CREATE INDEX idx_threat_scores_alert_timestamp ON threat_scores(alert_timestamp DESC);
CREATE INDEX idx_threat_scores_scored_at ON threat_scores(scored_at DESC);

-- Composite indexes for common queries
CREATE INDEX idx_threat_scores_alert_source_severity ON threat_scores(alert_source, risk_level);
CREATE INDEX idx_threat_scores_ip_risk ON threat_scores(ip_address, risk_score DESC);
CREATE INDEX idx_threat_scores_autoblock_risk ON threat_scores(auto_block_eligible, risk_score DESC)
    WHERE auto_block_eligible = TRUE;

-- Unique constraint to prevent duplicate scoring of same alert
CREATE UNIQUE INDEX idx_threat_scores_unique_alert ON threat_scores(alert_id, alert_source);

-- Trigger to update updated_at timestamp
CREATE OR REPLACE FUNCTION update_threat_scores_updated_at()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trigger_threat_scores_updated_at
    BEFORE UPDATE ON threat_scores
    FOR EACH ROW
    EXECUTE FUNCTION update_threat_scores_updated_at();

-- Comments for documentation
COMMENT ON TABLE threat_scores IS 'Stores calculated risk scores and threat intelligence analysis for security alerts';
COMMENT ON COLUMN threat_scores.scoring_factors IS 'JSONB breakdown of all factors used in risk calculation for GDPR Article 22 compliance';
COMMENT ON COLUMN threat_scores.fp_probability IS 'Probability (0-100) that this alert is a false positive';
COMMENT ON COLUMN threat_scores.auto_block_eligible IS 'Whether alert meets criteria for automatic temporary blocking via Wazuh AR';
COMMENT ON COLUMN threat_scores.confirmed_malicious_pattern IS 'If auto-block eligible, the confirmed attack pattern detected (e.g., brute_force, web_attack, malware_c2)';
