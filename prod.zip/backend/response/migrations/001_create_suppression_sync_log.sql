-- ============================================================================
-- Athena Security Platform - Suppression Sync Log Table
-- ============================================================================
-- Purpose: Track synchronization of mute rules to Suricata/Wazuh
-- Features: Hash-based change detection, audit trail, performance monitoring
-- ============================================================================

-- Create suppression_sync_log table
CREATE TABLE IF NOT EXISTS suppression_sync_log (
    id SERIAL PRIMARY KEY,
    service VARCHAR(20) NOT NULL,           -- 'suricata' or 'wazuh'
    sync_hash VARCHAR(64) NOT NULL,         -- SHA256 hash of rules
    rules_count INTEGER DEFAULT 0,          -- Number of rules synced
    success BOOLEAN DEFAULT TRUE,           -- Whether sync succeeded
    error_message TEXT,                     -- Error details if failed
    synced_at TIMESTAMP DEFAULT NOW(),      -- When sync occurred
    duration_ms INTEGER,                    -- How long sync took (milliseconds)

    CONSTRAINT valid_service CHECK (service IN ('suricata', 'wazuh', 'logstash'))
);

-- Create index for efficient lookups
CREATE INDEX IF NOT EXISTS idx_suppression_sync_service
    ON suppression_sync_log(service, synced_at DESC);

-- Create index for hash lookups
CREATE INDEX IF NOT EXISTS idx_suppression_sync_hash
    ON suppression_sync_log(service, sync_hash);

-- Add comments for documentation
COMMENT ON TABLE suppression_sync_log IS
    'Tracks synchronization of mute rules to security platforms (Suricata, Wazuh). Uses hash-based change detection to avoid unnecessary syncs.';

COMMENT ON COLUMN suppression_sync_log.sync_hash IS
    'SHA256 hash of rule configurations - used for change detection. If hash matches previous sync, sync is skipped.';

COMMENT ON COLUMN suppression_sync_log.duration_ms IS
    'Sync duration in milliseconds. Skipped syncs should be <100ms, actual syncs 2-3 seconds.';

-- Create view for monitoring sync health
CREATE OR REPLACE VIEW suppression_sync_health AS
SELECT
    service,
    COUNT(*) as total_syncs,
    COUNT(*) FILTER (WHERE success = TRUE) as successful_syncs,
    COUNT(*) FILTER (WHERE success = FALSE) as failed_syncs,
    MAX(synced_at) as last_sync_time,
    ROUND(AVG(duration_ms)::numeric, 2) as avg_duration_ms,
    COUNT(*) FILTER (WHERE duration_ms < 100) as likely_skipped_syncs,
    COUNT(*) FILTER (WHERE duration_ms >= 100) as actual_syncs
FROM suppression_sync_log
WHERE synced_at > NOW() - INTERVAL '24 hours'
GROUP BY service
ORDER BY service;

COMMENT ON VIEW suppression_sync_health IS
    'Health monitoring for suppression sync. Shows sync statistics for last 24 hours.';

-- Sample query to check recent syncs
-- SELECT * FROM suppression_sync_log ORDER BY synced_at DESC LIMIT 10;
-- SELECT * FROM suppression_sync_health;
