-- Migration: Create custom_wazuh_ar_rules table
-- Purpose: Track dynamically created Wazuh Active Response rules for self-learning threat response
-- Created: 2025-12-27
-- Part of Phase 1: Self-Learning Active Response Architecture

CREATE TABLE IF NOT EXISTS custom_wazuh_ar_rules (
    id uuid DEFAULT gen_random_uuid() NOT NULL,

    -- Rule identification
    rule_id character varying(50) UNIQUE NOT NULL,
    rule_name character varying(255) NOT NULL,
    rule_type character varying(50) NOT NULL,

    -- Target specification
    ip_address character varying(45),
    attack_pattern character varying(100),
    wazuh_rule_ids text[],

    -- Rule content
    rule_xml text NOT NULL,
    rule_file_path character varying(500),
    timeout_seconds integer DEFAULT 1800 NOT NULL,
    location character varying(20) DEFAULT 'local'::character varying,

    -- Creation metadata
    created_by character varying(100) NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    created_reason text,
    original_alert_id character varying(255),
    risk_score numeric(5,2),
    fp_probability numeric(5,2),
    enrichment_data jsonb,

    -- Status tracking
    is_active boolean DEFAULT true NOT NULL,
    disabled_at timestamp without time zone,
    disabled_by character varying(100),
    disabled_reason text,

    -- Effectiveness tracking
    times_triggered integer DEFAULT 0 NOT NULL,
    last_triggered_at timestamp without time zone,
    blocked_ips_count integer DEFAULT 0 NOT NULL,

    -- Audit
    updated_at timestamp without time zone DEFAULT now() NOT NULL,

    -- Constraints
    CONSTRAINT custom_wazuh_ar_rules_pkey PRIMARY KEY (id),
    CONSTRAINT unique_rule_id UNIQUE (rule_id),
    CONSTRAINT valid_rule_type CHECK (rule_type::text = ANY (ARRAY['auto_created'::character varying, 'analyst_created'::character varying]::text[])),
    CONSTRAINT valid_location CHECK (location::text = ANY (ARRAY['local'::character varying, 'all'::character varying]::text[])),
    CONSTRAINT valid_risk_score CHECK ((risk_score IS NULL) OR ((risk_score >= 0) AND (risk_score <= 100))),
    CONSTRAINT valid_fp_probability CHECK ((fp_probability IS NULL) OR ((fp_probability >= 0) AND (fp_probability <= 1))),
    CONSTRAINT valid_timeout CHECK (timeout_seconds > 0),
    CONSTRAINT valid_times_triggered CHECK (times_triggered >= 0),
    CONSTRAINT valid_blocked_ips_count CHECK (blocked_ips_count >= 0)
);

-- Indexes for common queries
CREATE INDEX idx_car_rule_id ON custom_wazuh_ar_rules(rule_id);
CREATE INDEX idx_car_ip_address ON custom_wazuh_ar_rules(ip_address) WHERE ip_address IS NOT NULL;
CREATE INDEX idx_car_attack_pattern ON custom_wazuh_ar_rules(attack_pattern) WHERE attack_pattern IS NOT NULL;
CREATE INDEX idx_car_rule_type ON custom_wazuh_ar_rules(rule_type);
CREATE INDEX idx_car_is_active ON custom_wazuh_ar_rules(is_active);
CREATE INDEX idx_car_created_at ON custom_wazuh_ar_rules(created_at DESC);
CREATE INDEX idx_car_created_by ON custom_wazuh_ar_rules(created_by);
CREATE INDEX idx_car_times_triggered ON custom_wazuh_ar_rules(times_triggered DESC);
CREATE INDEX idx_car_last_triggered ON custom_wazuh_ar_rules(last_triggered_at DESC) WHERE last_triggered_at IS NOT NULL;
CREATE INDEX idx_car_active_rules ON custom_wazuh_ar_rules(is_active, created_at DESC) WHERE is_active = TRUE;
CREATE INDEX idx_car_enrichment_data ON custom_wazuh_ar_rules USING gin(enrichment_data) WHERE enrichment_data IS NOT NULL;

-- Trigger for updated_at
CREATE TRIGGER trigger_update_updated_at
    BEFORE UPDATE ON custom_wazuh_ar_rules
    FOR EACH ROW
    EXECUTE FUNCTION update_updated_at_column();

-- Comments for documentation
COMMENT ON TABLE custom_wazuh_ar_rules IS 'Self-learning threat response: Tracks dynamically created Wazuh AR rules from automated threat analysis and analyst decisions';
COMMENT ON COLUMN custom_wazuh_ar_rules.rule_id IS 'Unique Wazuh rule ID (e.g., AR_100500) - auto-incremented from AR_100000';
COMMENT ON COLUMN custom_wazuh_ar_rules.rule_name IS 'Human-readable rule name (e.g., "Auto-Block Brute Force from 1.2.3.4")';
COMMENT ON COLUMN custom_wazuh_ar_rules.rule_type IS 'Creation source: auto_created (by system) or analyst_created (by security analyst)';
COMMENT ON COLUMN custom_wazuh_ar_rules.ip_address IS 'Target IP address (NULL if rule targets attack pattern, not specific IP)';
COMMENT ON COLUMN custom_wazuh_ar_rules.attack_pattern IS 'Attack classification: brute_force, web_attack, malware_c2, port_scan, dos_attack, etc.';
COMMENT ON COLUMN custom_wazuh_ar_rules.wazuh_rule_ids IS 'Array of Wazuh rule IDs that trigger this AR rule (e.g., {5710, 5712} for SSH brute force)';
COMMENT ON COLUMN custom_wazuh_ar_rules.rule_xml IS 'Complete XML rule definition for ossec.conf or ar_custom_rules.xml';
COMMENT ON COLUMN custom_wazuh_ar_rules.rule_file_path IS 'Path where rule is stored on Wazuh Manager (e.g., /var/ossec/etc/shared/ar_custom_rules.xml)';
COMMENT ON COLUMN custom_wazuh_ar_rules.timeout_seconds IS 'Block duration in seconds (default: 1800 = 30 minutes)';
COMMENT ON COLUMN custom_wazuh_ar_rules.location IS 'Wazuh AR location: local (specific agent) or all (all agents)';
COMMENT ON COLUMN custom_wazuh_ar_rules.created_by IS 'Username who created rule or "auto_threat_response_service" for system-generated rules';
COMMENT ON COLUMN custom_wazuh_ar_rules.created_reason IS 'Human-readable explanation for why rule was created';
COMMENT ON COLUMN custom_wazuh_ar_rules.original_alert_id IS 'ID of alert that triggered rule creation (for audit trail)';
COMMENT ON COLUMN custom_wazuh_ar_rules.risk_score IS 'Risk score (0-100) at time of rule creation';
COMMENT ON COLUMN custom_wazuh_ar_rules.fp_probability IS 'False positive probability (0.0-1.0) at time of rule creation';
COMMENT ON COLUMN custom_wazuh_ar_rules.enrichment_data IS 'JSON snapshot of threat intelligence enrichment data (AbuseIPDB, VirusTotal, etc.) at rule creation';
COMMENT ON COLUMN custom_wazuh_ar_rules.is_active IS 'TRUE if rule is currently active in Wazuh; FALSE if disabled/deleted';
COMMENT ON COLUMN custom_wazuh_ar_rules.disabled_at IS 'Timestamp when rule was disabled (NULL if still active)';
COMMENT ON COLUMN custom_wazuh_ar_rules.disabled_by IS 'Username who disabled rule';
COMMENT ON COLUMN custom_wazuh_ar_rules.disabled_reason IS 'Reason for disabling (e.g., "False positive", "Policy change")';
COMMENT ON COLUMN custom_wazuh_ar_rules.times_triggered IS 'Counter: How many times this rule has been triggered (incremented via custom_ar_rule_triggers)';
COMMENT ON COLUMN custom_wazuh_ar_rules.last_triggered_at IS 'Timestamp of most recent trigger';
COMMENT ON COLUMN custom_wazuh_ar_rules.blocked_ips_count IS 'Total unique IPs blocked by this rule';
