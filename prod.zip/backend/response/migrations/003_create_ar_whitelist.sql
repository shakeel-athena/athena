-- ============================================================================
-- Active Response Whitelist Table
-- Stores IPs that should NEVER be blocked by Active Response
-- ============================================================================

-- Create ar_whitelist table
CREATE TABLE IF NOT EXISTS ar_whitelist (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    ip_address VARCHAR(45) NOT NULL UNIQUE,
    ip_type VARCHAR(10) NOT NULL CHECK (ip_type IN ('single', 'cidr')),
    description TEXT NOT NULL,
    created_by VARCHAR(100) NOT NULL,
    approved_by VARCHAR(100),
    approval_status VARCHAR(20) NOT NULL DEFAULT 'approved' CHECK (approval_status IN ('pending', 'approved', 'rejected')),
    created_at TIMESTAMP NOT NULL DEFAULT NOW(),
    approved_at TIMESTAMP,
    updated_at TIMESTAMP NOT NULL DEFAULT NOW(),
    CONSTRAINT check_approval_logic CHECK (
        (approval_status = 'approved' AND approved_by IS NOT NULL AND approved_at IS NOT NULL) OR
        (approval_status != 'approved')
    )
);

-- Create indexes for performance
CREATE INDEX IF NOT EXISTS idx_ar_whitelist_approval ON ar_whitelist(approval_status);
CREATE INDEX IF NOT EXISTS idx_ar_whitelist_ip ON ar_whitelist(ip_address);
CREATE INDEX IF NOT EXISTS idx_ar_whitelist_created_at ON ar_whitelist(created_at DESC);

-- Add comments
COMMENT ON TABLE ar_whitelist IS 'Active Response whitelist - IPs that should never be blocked';
COMMENT ON COLUMN ar_whitelist.ip_address IS 'IP address or CIDR range (e.g., 10.0.0.0/8)';
COMMENT ON COLUMN ar_whitelist.ip_type IS 'Type: single or cidr';
COMMENT ON COLUMN ar_whitelist.approval_status IS 'Status: pending, approved, or rejected';

-- Insert initial critical infrastructure IPs
INSERT INTO ar_whitelist (ip_address, ip_type, description, created_by, approved_by, approval_status, approved_at)
VALUES
    ('172.16.1.87', 'single', 'Wazuh Manager Primary - NEVER BLOCK', 'system', 'system', 'approved', NOW()),
    ('172.16.1.93', 'single', 'Wazuh Manager Backup - NEVER BLOCK', 'system', 'system', 'approved', NOW()),
    ('127.0.0.1', 'single', 'Localhost', 'system', 'system', 'approved', NOW()),
    ('::1', 'single', 'Localhost IPv6', 'system', 'system', 'approved', NOW()),
    ('10.0.0.0/8', 'cidr', 'Internal Network RFC1918 - Class A', 'system', 'system', 'approved', NOW()),
    ('172.16.0.0/12', 'cidr', 'Internal Network RFC1918 - Class B', 'system', 'system', 'approved', NOW()),
    ('192.168.0.0/16', 'cidr', 'Internal Network RFC1918 - Class C', 'system', 'system', 'approved', NOW())
ON CONFLICT (ip_address) DO NOTHING;

-- Verify insertion
SELECT COUNT(*) as "Initial whitelist entries" FROM ar_whitelist WHERE approval_status = 'approved';
