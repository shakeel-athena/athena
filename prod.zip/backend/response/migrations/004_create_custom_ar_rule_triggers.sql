-- Migration: Create custom_ar_rule_triggers table
-- Purpose: Track every trigger of custom Wazuh AR rules for effectiveness analysis
-- Created: 2025-12-27
-- Part of Phase 1: Self-Learning Active Response Architecture

CREATE TABLE IF NOT EXISTS custom_ar_rule_triggers (
    id uuid DEFAULT gen_random_uuid() NOT NULL,

    -- Rule reference
    rule_id character varying(50) NOT NULL,

    -- Trigger details
    triggered_at timestamp without time zone DEFAULT now() NOT NULL,
    ip_address character varying(45) NOT NULL,
    agent_id character varying(50) NOT NULL,
    alert_id character varying(255),

    -- Result
    blocked boolean DEFAULT true NOT NULL,
    error_message text,

    -- Constraints
    CONSTRAINT custom_ar_rule_triggers_pkey PRIMARY KEY (id),
    CONSTRAINT fk_car_rule_id FOREIGN KEY (rule_id)
        REFERENCES custom_wazuh_ar_rules(rule_id)
        ON DELETE CASCADE
        ON UPDATE CASCADE
);

-- Indexes for common queries
CREATE INDEX idx_cart_rule_id ON custom_ar_rule_triggers(rule_id);
CREATE INDEX idx_cart_triggered_at ON custom_ar_rule_triggers(triggered_at DESC);
CREATE INDEX idx_cart_ip_address ON custom_ar_rule_triggers(ip_address);
CREATE INDEX idx_cart_agent_id ON custom_ar_rule_triggers(agent_id);
CREATE INDEX idx_cart_blocked ON custom_ar_rule_triggers(blocked);
CREATE INDEX idx_cart_alert_id ON custom_ar_rule_triggers(alert_id) WHERE alert_id IS NOT NULL;
CREATE INDEX idx_cart_rule_date ON custom_ar_rule_triggers(rule_id, triggered_at DESC);

-- Trigger to update parent rule statistics
CREATE OR REPLACE FUNCTION update_rule_trigger_stats()
RETURNS TRIGGER AS $$
BEGIN
    -- Update times_triggered counter
    UPDATE custom_wazuh_ar_rules
    SET times_triggered = times_triggered + 1,
        last_triggered_at = NEW.triggered_at,
        updated_at = now()
    WHERE rule_id = NEW.rule_id;

    -- Update blocked_ips_count (count distinct IPs)
    UPDATE custom_wazuh_ar_rules
    SET blocked_ips_count = (
        SELECT COUNT(DISTINCT ip_address)
        FROM custom_ar_rule_triggers
        WHERE rule_id = NEW.rule_id
          AND blocked = TRUE
    ),
    updated_at = now()
    WHERE rule_id = NEW.rule_id;

    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trigger_update_rule_stats
    AFTER INSERT ON custom_ar_rule_triggers
    FOR EACH ROW
    EXECUTE FUNCTION update_rule_trigger_stats();

-- Comments for documentation
COMMENT ON TABLE custom_ar_rule_triggers IS 'Tracks every trigger of custom AR rules for effectiveness analysis and metrics';
COMMENT ON COLUMN custom_ar_rule_triggers.rule_id IS 'Reference to custom_wazuh_ar_rules.rule_id (cascades on delete)';
COMMENT ON COLUMN custom_ar_rule_triggers.triggered_at IS 'Timestamp when rule was triggered by matching alert';
COMMENT ON COLUMN custom_ar_rule_triggers.ip_address IS 'Source IP that triggered the rule';
COMMENT ON COLUMN custom_ar_rule_triggers.agent_id IS 'Wazuh agent ID where block was applied';
COMMENT ON COLUMN custom_ar_rule_triggers.alert_id IS 'Wazuh/Suricata alert ID that matched the rule';
COMMENT ON COLUMN custom_ar_rule_triggers.blocked IS 'TRUE if block succeeded; FALSE if block failed';
COMMENT ON COLUMN custom_ar_rule_triggers.error_message IS 'Error details if blocked=FALSE';
COMMENT ON FUNCTION update_rule_trigger_stats() IS 'Auto-updates times_triggered, last_triggered_at, and blocked_ips_count in custom_wazuh_ar_rules';
