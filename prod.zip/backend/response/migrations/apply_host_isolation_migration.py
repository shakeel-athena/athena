"""
Apply Host Isolation Log Migration

Creates host_isolation_log table for tracking host isolation actions via Wazuh Active Response
"""

import os
import sys
from pathlib import Path
from dotenv import load_dotenv
import psycopg2

# Load environment variables
PROJECT_ROOT = Path(__file__).resolve().parent.parent.parent.parent
load_dotenv(dotenv_path=os.path.join(PROJECT_ROOT, '.env'))


def get_db_connection():
    """Get PostgreSQL database connection"""
    return psycopg2.connect(
        host=os.getenv('POSTGRES_HOST', 'localhost'),
        port=os.getenv('POSTGRES_PORT', '5432'),
        database=os.getenv('POSTGRES_DB', 'athena_db'),
        user=os.getenv('POSTGRES_USER', 'athena'),
        password=os.getenv('POSTGRES_PASSWORD')
    )


def apply_migration():
    """Apply host isolation log migration"""
    print("=" * 70)
    print("HOST ISOLATION LOG TABLE MIGRATION")
    print("=" * 70)

    # Read migration SQL
    migration_file = Path(__file__).parent / '005_create_host_isolation_log.sql'
    with open(migration_file, 'r') as f:
        migration_sql = f.read()

    print(f"\nReading migration from: {migration_file}")

    try:
        # Connect to database
        print("\nConnecting to database...")
        conn = get_db_connection()
        cursor = conn.cursor()

        print(f"  Connected to: {os.getenv('POSTGRES_DB')}")
        print(f"  Host: {os.getenv('POSTGRES_HOST')}")
        print()

        # Check if table already exists
        cursor.execute("""
            SELECT EXISTS (
                SELECT FROM information_schema.tables
                WHERE table_name = 'host_isolation_log'
            )
        """)
        table_exists = cursor.fetchone()[0]

        if table_exists:
            print("⚠️  Table 'host_isolation_log' already exists.")
            print("\nExisting table structure:")
            cursor.execute("""
                SELECT column_name, data_type, column_default
                FROM information_schema.columns
                WHERE table_name = 'host_isolation_log'
                ORDER BY ordinal_position
            """)
            for row in cursor.fetchall():
                column_name, data_type, default = row
                print(f"  {column_name:<25} {data_type:<20} default: {default or 'NULL'}")

            print("\n" + "=" * 70)
            response = input("\nRe-apply migration (will DROP and recreate table)? (yes/no): ").lower()
            if response != 'yes':
                print("\nMigration cancelled.")
                cursor.close()
                conn.close()
                return False

            # Drop existing table
            print("\nDropping existing table...")
            cursor.execute("DROP TABLE IF EXISTS host_isolation_log CASCADE")
            conn.commit()

        # Execute migration
        print("\nApplying migration...")
        cursor.execute(migration_sql)
        conn.commit()

        # Verify table was created
        cursor.execute("""
            SELECT column_name, data_type, column_default, is_nullable
            FROM information_schema.columns
            WHERE table_name = 'host_isolation_log'
            ORDER BY ordinal_position
        """)

        print("\n" + "=" * 70)
        print("MIGRATION SUCCESSFUL")
        print("=" * 70)
        print("\nTable 'host_isolation_log' created with columns:")
        print("-" * 70)
        for row in cursor.fetchall():
            column_name, data_type, default, nullable = row
            nullable_str = "NULL" if nullable == "YES" else "NOT NULL"
            default_str = f"default: {default}" if default else ""
            print(f"  {column_name:<25} {data_type:<20} {nullable_str:<10} {default_str}")

        # Verify indexes
        print("\n" + "=" * 70)
        print("INDEXES CREATED")
        print("=" * 70)
        cursor.execute("""
            SELECT indexname, indexdef
            FROM pg_indexes
            WHERE tablename = 'host_isolation_log'
            ORDER BY indexname
        """)
        for row in cursor.fetchall():
            index_name, index_def = row
            print(f"\n  {index_name}:")
            print(f"    {index_def}")

        # Verify views
        print("\n" + "=" * 70)
        print("VIEWS CREATED")
        print("=" * 70)
        cursor.execute("""
            SELECT table_name
            FROM information_schema.views
            WHERE table_name IN ('currently_isolated_hosts', 'host_isolation_analytics')
            ORDER BY table_name
        """)
        views = cursor.fetchall()
        for view in views:
            print(f"  ✓ {view[0]}")

        # Show verification queries
        print("\n" + "=" * 70)
        print("VERIFICATION")
        print("=" * 70)
        cursor.execute("SELECT COUNT(*) FROM host_isolation_log")
        count = cursor.fetchone()[0]
        print(f"\nTotal records in host_isolation_log: {count}")

        print("\n" + "=" * 70)
        print("SAMPLE QUERIES")
        print("=" * 70)
        print("\n  -- View currently isolated hosts:")
        print("  SELECT * FROM currently_isolated_hosts;")
        print("\n  -- View isolation analytics:")
        print("  SELECT * FROM host_isolation_analytics;")
        print("\n  -- View recent isolation actions:")
        print("  SELECT * FROM host_isolation_log ORDER BY created_at DESC LIMIT 10;")

        cursor.close()
        conn.close()

        print("\n" + "=" * 70)
        print("Migration completed successfully! ✓")
        print("=" * 70)
        return True

    except psycopg2.Error as e:
        print(f"\n[ERROR] Database error: {e}")
        return False
    except Exception as e:
        print(f"\n[ERROR] Unexpected error: {e}")
        import traceback
        traceback.print_exc()
        return False


if __name__ == "__main__":
    success = apply_migration()
    sys.exit(0 if success else 1)
