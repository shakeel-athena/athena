"""
Apply WAF Status Migration

Adds WAF tracking columns to firewall_ip_metadata table for dual-layer blocking
"""

import os
import sys
from pathlib import Path
from dotenv import load_dotenv
import psycopg2

# Load environment variables
PROJECT_ROOT = Path(__file__).resolve().parent.parent.parent.parent
load_dotenv(dotenv_path=os.path.join(PROJECT_ROOT, '.env'))


def get_db_connection():
    """Get PostgreSQL database connection"""
    return psycopg2.connect(
        host=os.getenv('POSTGRES_HOST', 'localhost'),
        port=os.getenv('POSTGRES_PORT', '5432'),
        database=os.getenv('POSTGRES_DB', 'athena_db'),
        user=os.getenv('POSTGRES_USER', 'athena'),
        password=os.getenv('POSTGRES_PASSWORD')
    )


def apply_migration():
    """Apply WAF status columns migration"""
    print("=" * 60)
    print("WAF STATUS COLUMNS MIGRATION")
    print("=" * 60)

    # Read migration SQL
    migration_file = Path(__file__).parent / 'add_waf_status_columns.sql'
    with open(migration_file, 'r') as f:
        migration_sql = f.read()

    print(f"\nReading migration from: {migration_file}")

    try:
        # Connect to database
        print("\nConnecting to database...")
        conn = get_db_connection()
        cursor = conn.cursor()

        print(f"  Connected to: {os.getenv('POSTGRES_DB')}")
        print(f"  Host: {os.getenv('POSTGRES_HOST')}")
        print()

        # Check if columns already exist
        cursor.execute("""
            SELECT column_name
            FROM information_schema.columns
            WHERE table_name = 'firewall_ip_metadata'
            AND column_name IN ('waf_enforced', 'waf_ip_set', 'waf_error')
        """)
        existing_columns = [row[0] for row in cursor.fetchall()]

        if existing_columns:
            print(f"Found existing WAF columns: {', '.join(existing_columns)}")
            print("\nMigration already applied or partially applied.")
            response = input("Re-apply migration? (yes/no): ").lower()
            if response != 'yes':
                print("\nMigration cancelled.")
                cursor.close()
                conn.close()
                return False

        # Execute migration
        print("\nApplying migration...")
        cursor.execute(migration_sql)
        conn.commit()

        # Verify columns were added
        cursor.execute("""
            SELECT column_name, data_type, column_default
            FROM information_schema.columns
            WHERE table_name = 'firewall_ip_metadata'
            AND column_name IN ('waf_enforced', 'waf_ip_set', 'waf_error')
            ORDER BY column_name
        """)

        print("\n" + "=" * 60)
        print("MIGRATION SUCCESSFUL")
        print("=" * 60)
        print("\nColumns added to firewall_ip_metadata:")
        print("-" * 60)
        for row in cursor.fetchall():
            column_name, data_type, default = row
            print(f"  {column_name:<20} {data_type:<20} default: {default or 'NULL'}")

        # Show sample query
        print("\n" + "=" * 60)
        print("VERIFICATION")
        print("=" * 60)
        cursor.execute("""
            SELECT COUNT(*) as total_ips,
                   COUNT(CASE WHEN waf_enforced = TRUE THEN 1 END) as waf_blocked
            FROM firewall_ip_metadata
        """)
        total, waf_blocked = cursor.fetchone()
        print(f"\nTotal IPs in firewall_ip_metadata: {total}")
        print(f"IPs with WAF enforcement: {waf_blocked}")

        cursor.close()
        conn.close()

        print("\n" + "=" * 60)
        print("Migration completed successfully!")
        print("=" * 60)
        return True

    except psycopg2.Error as e:
        print(f"\n[ERROR] Database error: {e}")
        return False
    except Exception as e:
        print(f"\n[ERROR] Unexpected error: {e}")
        import traceback
        traceback.print_exc()
        return False


if __name__ == "__main__":
    success = apply_migration()
    sys.exit(0 if success else 1)
