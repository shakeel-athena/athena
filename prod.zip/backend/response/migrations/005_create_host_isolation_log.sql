-- ============================================================================
-- Athena Security Platform - Host Isolation Log Table
-- ============================================================================
-- Purpose: Track host isolation actions via Wazuh Active Response
-- Features: Complete audit trail, agent tracking, alert context, expiration
-- ============================================================================

-- Create host_isolation_log table
CREATE TABLE IF NOT EXISTS host_isolation_log (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),

    -- Agent identification
    agent_id VARCHAR(50) NOT NULL,
    agent_name VARCHAR(255),
    agent_ip VARCHAR(45),

    -- Alert context (what triggered the isolation)
    alert_id VARCHAR(255),
    alert_source VARCHAR(20) CHECK (alert_source IN ('wazuh', 'suricata')),
    alert_severity VARCHAR(20),
    threat_type VARCHAR(50),
    reason TEXT NOT NULL,

    -- Action tracking
    action VARCHAR(20) NOT NULL CHECK (action IN ('ISOLATE', 'RESTORE')),
    analyst VARCHAR(100) NOT NULL,

    -- Timing
    isolated_at TIMESTAMP DEFAULT NOW(),
    restored_at TIMESTAMP,
    expires_at TIMESTAMP,  -- Optional auto-restore time

    -- Wazuh API response tracking
    wazuh_api_success BOOLEAN DEFAULT TRUE,
    wazuh_api_error TEXT,
    active BOOLEAN DEFAULT TRUE,

    -- Metadata
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW()
);

-- Indexes for performance
CREATE INDEX IF NOT EXISTS idx_host_isolation_agent_id
    ON host_isolation_log(agent_id);

CREATE INDEX IF NOT EXISTS idx_host_isolation_active
    ON host_isolation_log(active) WHERE active = TRUE;

CREATE INDEX IF NOT EXISTS idx_host_isolation_isolated_at
    ON host_isolation_log(isolated_at DESC);

CREATE INDEX IF NOT EXISTS idx_host_isolation_expires_at
    ON host_isolation_log(expires_at) WHERE expires_at IS NOT NULL;

CREATE INDEX IF NOT EXISTS idx_host_isolation_analyst
    ON host_isolation_log(analyst, created_at DESC);

-- Add comments for documentation
COMMENT ON TABLE host_isolation_log IS
    'Tracks host isolation actions performed via Wazuh Active Response. Records when hosts are isolated/restored, by whom, and why.';

COMMENT ON COLUMN host_isolation_log.agent_id IS
    'Wazuh agent ID (e.g., "001", "002"). Used to trigger Active Response via Wazuh API.';

COMMENT ON COLUMN host_isolation_log.action IS
    'Action type: ISOLATE (block all traffic except Wazuh Manager) or RESTORE (remove isolation).';

COMMENT ON COLUMN host_isolation_log.active IS
    'Whether this isolation is currently active. Set to FALSE when host is restored.';

COMMENT ON COLUMN host_isolation_log.expires_at IS
    'Optional expiration time for auto-restoration. If set, host should be automatically restored at this time.';

COMMENT ON COLUMN host_isolation_log.wazuh_api_success IS
    'Whether the Wazuh API call succeeded. FALSE indicates the API call failed but action was still logged.';

-- Create view for currently isolated hosts
CREATE OR REPLACE VIEW currently_isolated_hosts AS
SELECT
    h.id,
    h.agent_id,
    h.agent_name,
    h.agent_ip,
    h.threat_type,
    h.reason,
    h.analyst,
    h.isolated_at,
    h.expires_at,
    EXTRACT(EPOCH FROM (NOW() - h.isolated_at))/3600 as hours_isolated,
    CASE
        WHEN h.expires_at IS NULL THEN 'Permanent'
        WHEN h.expires_at > NOW() THEN 'Active'
        ELSE 'Expired'
    END as status
FROM host_isolation_log h
WHERE h.active = TRUE
  AND h.action = 'ISOLATE'
ORDER BY h.isolated_at DESC;

COMMENT ON VIEW currently_isolated_hosts IS
    'Shows all currently isolated hosts with duration and expiration status.';

-- Create view for isolation history and analytics
CREATE OR REPLACE VIEW host_isolation_analytics AS
SELECT
    agent_id,
    agent_name,
    COUNT(*) as total_isolations,
    MAX(isolated_at) as last_isolation,
    AVG(EXTRACT(EPOCH FROM (COALESCE(restored_at, NOW()) - isolated_at))/3600) as avg_isolation_hours,
    COUNT(*) FILTER (WHERE active = TRUE) as currently_isolated
FROM host_isolation_log
WHERE action = 'ISOLATE'
GROUP BY agent_id, agent_name
ORDER BY total_isolations DESC;

COMMENT ON VIEW host_isolation_analytics IS
    'Analytics view showing isolation frequency and patterns per agent.';

-- Sample queries for monitoring
-- SELECT * FROM currently_isolated_hosts;
-- SELECT * FROM host_isolation_analytics;
-- SELECT * FROM host_isolation_log WHERE agent_id = '001' ORDER BY created_at DESC;
