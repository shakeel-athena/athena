-- Migration: Add alert context fields to wazuh_active_response_log
-- Date: 2024-12-24
-- Purpose: Enhance SOC analyst visibility with attack pattern and alert context

-- Add confirmed_malicious_pattern column
ALTER TABLE wazuh_active_response_log
ADD COLUMN IF NOT EXISTS confirmed_malicious_pattern VARCHAR(50);

-- Add rule context fields
ALTER TABLE wazuh_active_response_log
ADD COLUMN IF NOT EXISTS rule_id VARCHAR(20);

ALTER TABLE wazuh_active_response_log
ADD COLUMN IF NOT EXISTS rule_description TEXT;

ALTER TABLE wazuh_active_response_log
ADD COLUMN IF NOT EXISTS rule_level INTEGER;

-- Add attack details (JSON field for extensibility)
ALTER TABLE wazuh_active_response_log
ADD COLUMN IF NOT EXISTS attack_details JSONB;

-- Add indexes for common queries
CREATE INDEX IF NOT EXISTS idx_ar_log_pattern
ON wazuh_active_response_log(confirmed_malicious_pattern);

CREATE INDEX IF NOT EXISTS idx_ar_log_rule
ON wazuh_active_response_log(rule_id);

-- Update existing records: Extract pattern from block_reason
-- Pattern is embedded like: "Auto-block: risk=23.8, FP=0.0%, pattern=brute_force"
UPDATE wazuh_active_response_log
SET confirmed_malicious_pattern =
    CASE
        WHEN block_reason ~ 'pattern=([a-z_]+)' THEN
            (regexp_match(block_reason, 'pattern=([a-z_]+)'))[1]
        ELSE NULL
    END
WHERE confirmed_malicious_pattern IS NULL
  AND block_reason IS NOT NULL
  AND block_reason LIKE '%pattern=%';

-- Verify migration
SELECT
    COUNT(*) as total_records,
    COUNT(confirmed_malicious_pattern) as records_with_pattern,
    COUNT(DISTINCT confirmed_malicious_pattern) as unique_patterns
FROM wazuh_active_response_log;

SELECT
    confirmed_malicious_pattern,
    COUNT(*) as count
FROM wazuh_active_response_log
WHERE confirmed_malicious_pattern IS NOT NULL
GROUP BY confirmed_malicious_pattern
ORDER BY count DESC;
