-- Migration: Add WAF status tracking columns to firewall_ip_metadata table
-- Description: Adds columns to track dual-layer blocking status (Network Firewall + WAF)
-- Date: 2025-01-XX
-- Author: Claude Code

-- Add WAF enforcement status column
ALTER TABLE firewall_ip_metadata
ADD COLUMN IF NOT EXISTS waf_enforced BOOLEAN DEFAULT FALSE;

-- Add WAF IP Set name column
ALTER TABLE firewall_ip_metadata
ADD COLUMN IF NOT EXISTS waf_ip_set VARCHAR(255);

-- Add WAF error tracking column
ALTER TABLE firewall_ip_metadata
ADD COLUMN IF NOT EXISTS waf_error TEXT;

-- Add comment for documentation
COMMENT ON COLUMN firewall_ip_metadata.waf_enforced IS 'Indicates if IP was successfully blocked in AWS WAF IP Set';
COMMENT ON COLUMN firewall_ip_metadata.waf_ip_set IS 'Name of the WAF IP Set where the IP was added';
COMMENT ON COLUMN firewall_ip_metadata.waf_error IS 'Error message if WAF blocking failed';

-- Create index for querying by WAF status
CREATE INDEX IF NOT EXISTS idx_firewall_ip_metadata_waf_enforced
ON firewall_ip_metadata(waf_enforced)
WHERE waf_enforced = TRUE;

-- Success message
SELECT 'WAF status columns added to firewall_ip_metadata table successfully' AS status;
