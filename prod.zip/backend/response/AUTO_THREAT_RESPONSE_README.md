# Auto Threat Response System - Implementation Complete

## 📋 Overview

This implements **automatic enrichment, risk scoring, and temporary blocking** for Critical/High severity alerts via Wazuh Active Response.

**Key Features:**
- ✅ Auto-enrichment for Critical/High alerts only
- ✅ Risk scoring (0-100) with false positive detection
- ✅ Auto-block via Wazuh Active Response (30-minute timeout)
- ✅ Complete audit trail in PostgreSQL
- ✅ Standalone service (doesn't modify existing flows)

---

## 📁 Files Created

### 1. Database Migration
**File:** `backend/response/migrations/002_create_wazuh_active_response_log.sql`

Creates `wazuh_active_response_log` table for audit trail:
- Tracks all Wazuh Active Response blocks
- Records risk score, FP probability, block reason
- 30-minute timeout per user requirements
- Supports SOC2/GDPR/HIPAA compliance

### 2. Risk Scoring Engine
**File:** `backend/response/src/services/risk_scoring_engine.py`

Calculates 0-100 risk scores using:
- **30%** AbuseIPDB score
- **25%** VirusTotal detections
- **25%** Alert severity
- **10%** Geographic anomaly
- **10%** Network anomaly
- **-20%** False positive penalty (CDN/cloud IPs)

**Auto-block criteria:**
- Risk ≥ 80
- FP probability ≤ 20%
- Confirmed pattern (brute force, web attack, malware C2, port scan, DoS)

### 3. Wazuh Active Response Client
**File:** `backend/response/src/services/wazuh_active_response_client.py`

Communicates with Wazuh Manager API:
- Sends `firewall-drop` commands to agents
- 30-minute timeout on all blocks
- Logs all actions to PostgreSQL
- Can block on specific agent or all agents

### 4. Main Orchestrator Service
**File:** `backend/response/src/services/auto_threat_response_service.py`

Main service that ties everything together:
1. Fetches Critical/High alerts from `/api/alerts`
2. Enriches source IPs (AbuseIPDB, VirusTotal, OTX)
3. Calculates risk scores
4. Auto-blocks high-risk IPs via Wazuh AR
5. Logs everything to PostgreSQL

**Can run:**
- **Single iteration** (for testing)
- **Continuous mode** (production, runs every 5 minutes)

---

## 🔧 Environment Variables Needed

Add to your `.env` file:

```bash
# Wazuh Active Response
WAZUH_MANAGER_URL=https://172.16.1.93:55000
WAZUH_API_USER=wazuh
WAZUH_API_PASSWORD=wazuh
WAZUH_VERIFY_SSL=False

# Auto Response Configuration
ALERTS_API_URL=http://localhost:5001/api/alerts
AUTO_RESPONSE_MAX_ALERTS=50

# (Existing vars - already configured)
POSTGRES_HOST=localhost
POSTGRES_PORT=5432
POSTGRES_DB=athena_db
POSTGRES_USER=athena_user
POSTGRES_PASSWORD=athena_pass
ABUSEIPDB_API_KEY=...
VIRUSTOTAL_API_KEY=...
OTX_API_KEY=...
```

---

## 🚀 Testing Instructions

### Step 1: Run Database Migration

```bash
cd backend/response

# Apply migration
python -c "
import psycopg2
import os
from dotenv import load_dotenv
from pathlib import Path

load_dotenv()

conn = psycopg2.connect(
    host=os.getenv('POSTGRES_HOST'),
    port=os.getenv('POSTGRES_PORT'),
    database=os.getenv('POSTGRES_DB'),
    user=os.getenv('POSTGRES_USER'),
    password=os.getenv('POSTGRES_PASSWORD')
)

sql = Path('migrations/002_create_wazuh_active_response_log.sql').read_text()
cursor = conn.cursor()
cursor.execute(sql)
conn.commit()
print('✅ Migration applied successfully')
"
```

### Step 2: Verify Migration

```bash
python -c "
import psycopg2
import os
from dotenv import load_dotenv

load_dotenv()

conn = psycopg2.connect(
    host=os.getenv('POSTGRES_HOST'),
    port=os.getenv('POSTGRES_PORT'),
    database=os.getenv('POSTGRES_DB'),
    user=os.getenv('POSTGRES_USER'),
    password=os.getenv('POSTGRES_PASSWORD')
)

cursor = conn.cursor()
cursor.execute(\"SELECT column_name FROM information_schema.columns WHERE table_name='wazuh_active_response_log'\")
columns = [row[0] for row in cursor.fetchall()]
print(f'✅ wazuh_active_response_log table exists with {len(columns)} columns')
print(f'Columns: {columns}')
"
```

### Step 3: Test Risk Scoring Engine

```bash
cd backend/response/src

python -c "
from services.risk_scoring_engine import RiskScoringEngine

engine = RiskScoringEngine()

# Sample alert
alert = {
    'normalized_severity': 'Critical',
    'signature': 'SSH brute force authentication failure',
    'source': 'wazuh'
}

# Sample enrichment
enrichment = {
    'is_private': False,
    'threat_intelligence': {
        'abuseipdb': {'abuseConfidenceScore': 95, 'totalReports': 50},
        'virustotal': {'last_analysis_stats': {'malicious': 8, 'suspicious': 2, 'harmless': 0, 'undetected': 60}}
    },
    'geolocation': {'country_code': 'CN', 'is_vpn': False}
}

# Calculate risk
risk = engine.calculate_risk_score(alert, enrichment)

print('Risk Assessment:')
print(f\"  Risk Score: {risk['risk_score']}\")
print(f\"  Risk Level: {risk['risk_level']}\")
print(f\"  Recommendation: {risk['recommendation']}\")
print(f\"  Auto-block Eligible: {risk['auto_block_eligible']}\")
print(f\"  FP Probability: {risk['fp_probability']:.2%}\")
print(f\"  Confirmed Pattern: {risk.get('confirmed_pattern', 'None')}\")
"
```

Expected output:
```
Risk Assessment:
  Risk Score: 85-95 (high)
  Risk Level: CRITICAL
  Recommendation: BLOCK
  Auto-block Eligible: True
  FP Probability: 0-10%
  Confirmed Pattern: brute_force
```

### Step 4: Test Wazuh API Connection

```bash
cd backend/response/src

python -c "
from services.wazuh_active_response_client import WazuhActiveResponseClient

client = WazuhActiveResponseClient()

# Test authentication
token = client._get_auth_token()

if token:
    print('✅ Wazuh API authentication successful')
    print(f'Token: {token[:20]}...')
else:
    print('❌ Wazuh API authentication failed')
    print('Check WAZUH_MANAGER_URL, WAZUH_API_USER, WAZUH_API_PASSWORD in .env')
"
```

### Step 5: Test Full Service (Single Run - DRY RUN)

**IMPORTANT:** This will process real alerts but NOT actually block IPs (we'll test blocking separately).

```bash
cd backend/response/src

# Run service once (processes alerts but blocks commented out for safety)
python services/auto_threat_response_service.py
```

Expected output:
```
================================================================================
Starting Auto Threat Response iteration
================================================================================
Fetching alerts from http://localhost:5001/api/alerts
Found X Critical/High alerts to process
============================================================
Processing Alert: abc123 (wazuh, Critical)
============================================================
Source IP: 192.168.1.100
Enriching IP: 192.168.1.100
Enrichment complete: AbuseIPDB=50, VT malicious=2
Risk Assessment: score=65.00, level=HIGH, recommendation=REVIEW, auto_block=False
============================================================
Total processed: X, Enriched: X, Scored: X, Auto-blocked: 0
```

### Step 6: Test Auto-Block (Controlled Test)

**WARNING:** This will actually block an IP via Wazuh Active Response for 30 minutes!

```bash
cd backend/response/src

# Test with a safe IP (non-critical internal test IP)
python -c "
from services.wazuh_active_response_client import WazuhActiveResponseClient
import psycopg2
import os
from dotenv import load_dotenv

load_dotenv()

# Connect to DB
db = psycopg2.connect(
    host=os.getenv('POSTGRES_HOST'),
    port=os.getenv('POSTGRES_PORT'),
    database=os.getenv('POSTGRES_DB'),
    user=os.getenv('POSTGRES_USER'),
    password=os.getenv('POSTGRES_PASSWORD')
)

client = WazuhActiveResponseClient(db_connection=db)

# Block test IP on agent 001 (change to your test agent ID)
TEST_IP = '192.0.2.1'  # TEST-NET-1 (safe IP for testing)
TEST_AGENT = '001'  # Change to your Wazuh agent ID

result = client.block_ip_on_agent(
    agent_id=TEST_AGENT,
    ip_address=TEST_IP,
    alert_id='test_alert_123',
    alert_source='test',
    risk_score=85.0,
    block_reason='Test auto-block'
)

if result['success']:
    print(f'✅ Test block successful: {TEST_IP} on agent {TEST_AGENT}')
    print('   Block will expire in 30 minutes')
    print('   Check wazuh_active_response_log table in PostgreSQL')
else:
    print(f'❌ Test block failed: {result.get(\"error\")}')

db.close()
"
```

### Step 7: Verify Block in Database

```bash
python -c "
import psycopg2
import os
from dotenv import load_dotenv

load_dotenv()

conn = psycopg2.connect(
    host=os.getenv('POSTGRES_HOST'),
    port=os.getenv('POSTGRES_PORT'),
    database=os.getenv('POSTGRES_DB'),
    user=os.getenv('POSTGRES_USER'),
    password=os.getenv('POSTGRES_PASSWORD')
)

cursor = conn.cursor()
cursor.execute(\"\"\"
    SELECT ip_address, agent_id, blocked_at, expires_at, risk_score, block_reason
    FROM wazuh_active_response_log
    ORDER BY blocked_at DESC
    LIMIT 5
\"\"\")

print('Recent Wazuh Active Response blocks:')
for row in cursor.fetchall():
    print(f\"  IP: {row[0]}, Agent: {row[1]}, Score: {row[4]}, Reason: {row[5]}\")
"
```

---

## 🎯 Production Deployment

### Option 1: Systemd Service (Linux)

Create `/etc/systemd/system/athena-auto-response.service`:

```ini
[Unit]
Description=Athena Auto Threat Response Service
After=network.target postgresql.service

[Service]
Type=simple
User=athena
WorkingDirectory=/path/to/backend/response/src
ExecStart=/usr/bin/python3 services/auto_threat_response_service.py --continuous --interval 300
Restart=always
RestartSec=10
Environment="PATH=/usr/local/bin:/usr/bin:/bin"
EnvironmentFile=/path/to/.env

[Install]
WantedBy=multi-user.target
```

Enable and start:
```bash
sudo systemctl daemon-reload
sudo systemctl enable athena-auto-response
sudo systemctl start athena-auto-response
sudo systemctl status athena-auto-response
```

View logs:
```bash
sudo journalctl -u athena-auto-response -f
```

### Option 2: Cron Job

```bash
# Run every 5 minutes
*/5 * * * * cd /path/to/backend/response/src && /usr/bin/python3 services/auto_threat_response_service.py >> /var/log/athena-auto-response.log 2>&1
```

### Option 3: Docker Container

Create `Dockerfile`:
```dockerfile
FROM python:3.9-slim

WORKDIR /app
COPY backend/response /app
RUN pip install -r requirements.txt

CMD ["python", "src/services/auto_threat_response_service.py", "--continuous", "--interval", "300"]
```

---

## 📊 Monitoring

### View Statistics

```bash
# Check recent risk scores
psql -U athena_user -d athena_db -c "
    SELECT ip_address, risk_score, risk_level, auto_block_eligible
    FROM threat_scores
    ORDER BY scored_at DESC
    LIMIT 10;
"

# Check recent auto-blocks
psql -U athena_user -d athena_db -c "
    SELECT ip_address, agent_id, blocked_at, expires_at, block_reason
    FROM wazuh_active_response_log
    WHERE auto_block = TRUE
    ORDER BY blocked_at DESC
    LIMIT 10;
"

# Check active blocks
psql -U athena_user -d athena_db -c "
    SELECT ip_address, agent_id, blocked_at, expires_at, risk_score
    FROM wazuh_active_response_log
    WHERE unblocked_at IS NULL AND success = TRUE AND expires_at > NOW()
    ORDER BY blocked_at DESC;
"
```

### Dashboard Metrics

Key metrics to monitor:
- Total alerts processed
- Enrichment success rate
- Risk score distribution
- Auto-blocks triggered
- False positive rate
- Average risk score

---

## 🔒 Security Considerations

1. **Wazuh API Credentials**: Store securely in `.env`, never commit to git
2. **Database Access**: Use read-only connections where possible
3. **Rate Limiting**: Consider rate limits on enrichment APIs (AbuseIPDB free tier = 1000/day)
4. **False Positives**: Monitor `fp_probability` and adjust thresholds if needed
5. **Agent ID**: Validate agent IDs before sending block commands

---

## 🐛 Troubleshooting

### Service not processing alerts
- Check `ALERTS_API_URL` is correct
- Verify Flask backend is running on port 5001
- Check logs for enrichment API failures

### Wazuh blocks not working
- Verify Wazuh Manager API is accessible
- Check Wazuh agent has Active Response enabled
- Verify `firewall-drop` command exists in Wazuh config
- Check agent firewall (iptables/Windows Firewall) for rules

### Risk scores too high/low
- Adjust weights in `RiskScoringEngine` class
- Check enrichment data quality
- Review false positive indicators

### Database errors
- Check PostgreSQL connection
- Verify `threat_scores` table exists
- Check `wazuh_active_response_log` table created

---

## 📝 Next Steps

1. **Review code** - All 4 files above
2. **Run tests** - Follow testing instructions
3. **Adjust thresholds** - Tune risk score weights and auto-block criteria
4. **Deploy** - Choose systemd, cron, or Docker
5. **Monitor** - Watch logs and database for first 24 hours

---

## ✅ Success Criteria

- ✅ SQL migration applied successfully
- ✅ Risk scoring calculates correct scores (0-100)
- ✅ False positive detection works (CDN/cloud IPs)
- ✅ Wazuh API authentication successful
- ✅ Auto-blocks trigger for risk≥80, FP≤20%, confirmed patterns
- ✅ All actions logged to PostgreSQL
- ✅ Service runs without errors for 1 hour

**You're ready to test!** Let me know when you want to run the migrations and start testing.
