# Dual-Layer IP Blocking Prerequisites

This document outlines all prerequisites for implementing dual-layer IP blocking (Network Firewall + WAF).

## Status: Environment Variables ✅

All required environment variables are configured in `.env`:

```bash
AWS_REGION=us-east-2
AWS_SCOPE=REGIONAL
WAF_WEB_ACL=test-webacl
WAF_BLOCKLIST_NAME=Blocked
FIREWALL_RULE_GROUP=allow-ingress
```

---

## Prerequisites Checklist

### 1. AWS Credentials ⚠️

**Current Status:** Expired token detected

**Required:** Valid AWS credentials with appropriate permissions

**Setup Options:**

#### Option A: Refresh IAM Credentials (Recommended)
```bash
# If using AWS SSO
aws sso login --profile your-profile

# If using environment variables, update in .env:
AWS_ACCESS_KEY_ID=your-access-key
AWS_SECRET_ACCESS_KEY=your-secret-key
AWS_SESSION_TOKEN=your-session-token  # if using temporary credentials
```

#### Option B: Use IAM Role (Production)
- Run application on EC2/ECS with attached IAM role
- No credentials in .env needed

---

### 2. AWS IAM Permissions 🔑

The AWS user/role needs these permissions:

#### WAF Permissions
```json
{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Effect": "Allow",
      "Action": [
        "wafv2:GetIPSet",
        "wafv2:UpdateIPSet",
        "wafv2:ListIPSets",
        "wafv2:GetWebACL",
        "wafv2:ListWebACLs"
      ],
      "Resource": "*"
    }
  ]
}
```

#### Network Firewall Permissions
```json
{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Effect": "Allow",
      "Action": [
        "network-firewall:DescribeRuleGroup",
        "network-firewall:UpdateRuleGroup",
        "network-firewall:ListRuleGroups"
      ],
      "Resource": "*"
    }
  ]
}
```

---

### 3. AWS WAF Infrastructure 🏗️

#### 3.1 Web ACL

**Required:** WAF Web ACL named `test-webacl` (from WAF_WEB_ACL)

**Verify:**
```bash
aws wafv2 list-web-acls --scope REGIONAL --region us-east-2
```

**Create if missing:**
```bash
aws wafv2 create-web-acl \
  --name test-webacl \
  --scope REGIONAL \
  --region us-east-2 \
  --default-action Allow={} \
  --visibility-config SampledRequestsEnabled=true,CloudWatchMetricsEnabled=true,MetricName=test-webacl
```

#### 3.2 IP Set for Blocking

**Required:** IP Set named `Blocked` (from WAF_BLOCKLIST_NAME)

**Verify:**
```bash
aws wafv2 list-ip-sets --scope REGIONAL --region us-east-2
```

**Create if missing:**
```bash
aws wafv2 create-ip-set \
  --name Blocked \
  --scope REGIONAL \
  --region us-east-2 \
  --ip-address-version IPV4 \
  --addresses \
  --description "Malicious source IPs blocked from detection/events"
```

#### 3.3 WAF Rule for IP Set

**Required:** A rule in the Web ACL that references the IP Set with Block action

**Create via AWS Console:**
1. Go to AWS Console → WAF & Shield → Web ACLs
2. Select `test-webacl`
3. Go to Rules tab → Add rules → Add my own rules and rule groups
4. Rule type: **IP set**
5. Configuration:
   - **Name:** `BlockMaliciousSourceIPs`
   - **IP set:** Select `Blocked`
   - **IP address to use:** Source IP address
   - **Action:** **Block**
   - **Priority:** `0` (or appropriate value)
6. Add rule

**Create via AWS CLI:**
```bash
# First, get current Web ACL config
aws wafv2 get-web-acl --scope REGIONAL --region us-east-2 --name test-webacl --id <web-acl-id>

# Then update with the new rule (requires lock token from get-web-acl)
# This is complex - recommend using console
```

---

### 4. Network Firewall Infrastructure ✅

**Status:** Already configured

- Rule Group: `allow-ingress` (STATEFUL)
- IP Set: `BLOCK_NET` within the rule group
- Integration: Already working in detection/events page

---

### 5. Verify Setup (Run After Credentials Refresh)

```bash
# From project root
cd "d:\Athena\Promochos\Main Branch\version1.1.02"

# Run verification script
python backend/response/verify_waf_prerequisites.py
```

**Expected Output:**
```
============================================================
VERIFICATION SUMMARY
============================================================

Checks Passed: 6/6

[SUCCESS] ALL PREREQUISITES MET - Ready to implement!

You can proceed with the implementation.
```

---

## Implementation Scope

Once prerequisites are met, we will implement:

### Backend Changes

1. **`backend/response/src/api/firewall/routes.py`**
   - Modify `block_ip_from_alert_internal()` to block at both layers
   - Add WAF blocking integration
   - Update response metadata to include WAF status

2. **`backend/response/src/api/alerts/routes.py`**
   - Update bulk block endpoint to use dual-layer blocking
   - Add WAF status to bulk action results

### Frontend Changes

3. **`frontend/src/components/BlockIPModal.js`**
   - Update warning message to mention both layers
   - Show enforcement status for both Network Firewall and WAF

4. **`frontend/src/pages/Firewall.js`** (optional)
   - Add WAF blocking status column
   - Show which IPs are blocked at which layers

### Database Changes

5. **`firewall_ip_metadata` table**
   - Add `waf_enforced` boolean column
   - Add `waf_error` text column for error tracking

---

## Quick Setup Guide

### Step 1: Refresh AWS Credentials

```bash
# Option 1: AWS SSO
aws sso login

# Option 2: Update .env with fresh credentials
# Edit .env and update:
# AWS_ACCESS_KEY_ID=...
# AWS_SECRET_ACCESS_KEY=...
# AWS_SESSION_TOKEN=...  # if temporary
```

### Step 2: Create WAF IP Set (if needed)

**Via AWS Console:**
1. Go to AWS Console → WAF & Shield
2. Region: **US East (Ohio)** / us-east-2
3. IP sets → Create IP set
   - Name: `Blocked`
   - Region: REGIONAL (us-east-2)
   - IP version: IPv4
   - Addresses: Leave empty
4. Create IP set

### Step 3: Add IP Set Rule to Web ACL

1. Web ACLs → `test-webacl` → Rules
2. Add rules → Add my own rules and rule groups
3. Rule type: IP set
4. Configure:
   - Name: `BlockMaliciousSourceIPs`
   - IP set: `Blocked`
   - Action: **Block**
   - Priority: 0
5. Add rule → Save

### Step 4: Verify

```bash
python backend/response/verify_waf_prerequisites.py
```

### Step 5: Proceed with Implementation

Once verification passes, confirm to proceed with implementation.

---

## Troubleshooting

### Issue: "ExpiredToken" errors

**Solution:** Refresh AWS credentials (see Step 1 above)

### Issue: "AccessDenied" errors

**Solution:** Add required IAM permissions (see Section 2 above)

### Issue: "Web ACL not found"

**Solution:** Create Web ACL or update `WAF_WEB_ACL` in `.env` to match existing ACL name

### Issue: "IP Set not found"

**Solution:** Create IP Set (see Step 2 above)

---

## Cost Implications

- **WAF IP Set:** Free (part of WAF pricing)
- **WAF Rule:** $1/month per rule
- **WAF Requests:** $0.60 per million requests (applied to web traffic)
- **Network Firewall:** Already deployed (no additional cost)

**Total Additional Cost:** ~$1-5/month depending on web traffic volume

---

## Security Benefits

✅ **Defense in Depth** - Multiple layers of protection
✅ **Comprehensive Coverage** - Network + Application layer
✅ **Redundancy** - Blocks even if one layer fails
✅ **Audit Trail** - Detailed logging at both layers
✅ **Compliance** - Demonstrates layered security controls

---

## Next Steps

1. ✅ Review prerequisites (completed)
2. ⚠️ Refresh AWS credentials
3. ⏳ Run verification script
4. ⏳ Confirm all checks pass
5. ⏳ Proceed with implementation

---

**Ready to implement?** Once verification passes, let me know and I'll implement the dual-layer blocking functionality.
