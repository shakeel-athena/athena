#!/usr/bin/env python3
"""
Wazuh Suppression Sync - Cron Job Entry Point

Run this script via cron every 5 minutes to sync mute rules to Wazuh Manager.

Example crontab entry:
*/5 * * * * cd /path/to/backend/response && python cron/run_wazuh_sync.py >> /var/log/athena/wazuh_sync.log 2>&1
"""

import sys
import os
from pathlib import Path
from datetime import datetime

# Add parent directory to path
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..', 'src')))

import psycopg2
from dotenv import load_dotenv
from integrations.wazuh_sync import WazuhSyncService

# Load environment variables
env_path = Path(__file__).parent.parent.parent / '.env'
load_dotenv(env_path)


def sync_wazuh():
    """Main sync function"""

    print(f"\n{'='*80}")
    print(f"Wazuh Suppression Sync - {datetime.now().isoformat()}")
    print(f"{'='*80}")

    try:
        # Connect to database (requires environment variables)
        conn = psycopg2.connect(
            host=os.getenv('POSTGRES_HOST'),
            database=os.getenv('POSTGRES_DB'),
            user=os.getenv('POSTGRES_USER'),
            password=os.getenv('POSTGRES_PASSWORD'),
            port=os.getenv('POSTGRES_PORT', '5432')
        )

        # Create sync service
        sync_service = WazuhSyncService(conn)

        # Run sync
        result = sync_service.sync_mute_rules()

        # Print result
        print(f"\nSync Result:")
        print(f"  Success: {result['success']}")
        print(f"  Skipped: {result.get('skipped', False)}")

        if not result.get('skipped'):
            print(f"  IP Rules Synced: {result.get('ip_rules_synced', 0)}")
            print(f"  Rule Suppressions Synced: {result.get('rule_suppressions_synced', 0)}")

        print(f"  Duration: {result['duration_ms']}ms")

        if not result['success']:
            print(f"  Error: {result.get('error', 'Unknown error')}")

        conn.close()

        print(f"{'='*80}\n")

        return 0 if result['success'] else 1

    except Exception as e:
        print(f"\n[ERROR] Sync failed with exception: {e}")
        import traceback
        traceback.print_exc()
        print(f"{'='*80}\n")
        return 1


if __name__ == '__main__':
    sys.exit(sync_wazuh())
