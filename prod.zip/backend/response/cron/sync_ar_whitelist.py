#!/usr/bin/env python3
"""
Active Response Whitelist Sync Service

Automated cron job that syncs approved whitelist entries from PostgreSQL
to Wazuh Manager every 5 minutes.

Setup:
    Add to crontab:
    */5 * * * * cd /path/to/project && python backend/response/cron/sync_ar_whitelist.py >> /var/log/ar_whitelist_sync.log 2>&1

Usage:
    python sync_ar_whitelist.py [--dry-run]
"""

import os
import sys
import argparse
import psycopg2
import hashlib
from datetime import datetime
from pathlib import Path

# Add project root to Python path
project_root = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(project_root))
sys.path.insert(0, str(project_root / 'setup_prerequisites' / 'active_response'))

# Load environment variables
from dotenv import load_dotenv
env_path = project_root / '.env'
load_dotenv(env_path)

# Import deployment service
from wazuh_ar_deployment import WazuhARDeploymentService


class ARWhitelistSyncService:
    """Syncs Active Response whitelist from PostgreSQL to Wazuh Manager"""

    def __init__(self, dry_run=False):
        self.dry_run = dry_run
        self.db_connection = None
        self.last_hash_file = project_root / 'backend' / 'response' / 'cron' / '.ar_whitelist_hash'

    def connect_db(self):
        """Connect to PostgreSQL database (requires environment variables)"""
        try:
            self.db_connection = psycopg2.connect(
                host=os.getenv('POSTGRES_HOST'),
                database=os.getenv('POSTGRES_DB'),
                user=os.getenv('POSTGRES_USER'),
                password=os.getenv('POSTGRES_PASSWORD'),
                port=os.getenv('POSTGRES_PORT', '5432')
            )
            return True
        except Exception as e:
            print(f"[ERROR] Database connection failed: {e}")
            return False

    def get_approved_whitelist(self):
        """Fetch all approved whitelist entries from database"""
        cursor = self.db_connection.cursor()

        cursor.execute("""
            SELECT ip_address, description
            FROM ar_whitelist
            WHERE approval_status = 'approved'
            ORDER BY created_at ASC
        """)

        entries = cursor.fetchall()
        cursor.close()

        return entries

    def calculate_whitelist_hash(self, entries):
        """Calculate hash of whitelist for change detection"""
        content = '\n'.join([f"{ip}:{desc}" for ip, desc in entries])
        return hashlib.md5(content.encode()).hexdigest()

    def get_last_deployed_hash(self):
        """Get hash of last deployed whitelist"""
        if not self.last_hash_file.exists():
            return None

        try:
            with open(self.last_hash_file, 'r') as f:
                return f.read().strip()
        except Exception:
            return None

    def save_deployed_hash(self, hash_value):
        """Save hash of deployed whitelist"""
        try:
            self.last_hash_file.parent.mkdir(parents=True, exist_ok=True)
            with open(self.last_hash_file, 'w') as f:
                f.write(hash_value)
        except Exception as e:
            print(f"[WARN] Failed to save hash: {e}")

    def sync_whitelist(self):
        """Main sync function"""
        print("=" * 80)
        print(f"Active Response Whitelist Sync - {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
        print("=" * 80)

        if self.dry_run:
            print("[INFO] DRY RUN MODE - No changes will be made")

        # Connect to database
        print("[1/5] Connecting to PostgreSQL...")
        if not self.connect_db():
            return False

        print("[OK] Database connected")

        # Fetch approved whitelist
        print("\n[2/5] Fetching approved whitelist entries...")
        entries = self.get_approved_whitelist()
        print(f"[OK] Found {len(entries)} approved entries")

        # Calculate hash for change detection
        print("\n[3/5] Checking for changes...")
        current_hash = self.calculate_whitelist_hash(entries)
        last_hash = self.get_last_deployed_hash()

        if current_hash == last_hash:
            print("[INFO] No changes detected - whitelist is up to date")
            self.db_connection.close()
            return True

        print(f"[INFO] Changes detected (hash: {current_hash[:8]}...)")

        # Display entries to be deployed
        print("\nWhitelist entries to deploy:")
        for ip, desc in entries:
            print(f"  - {ip:20s} : {desc}")

        if self.dry_run:
            print("\n[DRY RUN] Would deploy to Wazuh Manager")
            self.db_connection.close()
            return True

        # Deploy to Wazuh Manager
        print("\n[4/5] Deploying whitelist to Wazuh Manager...")

        try:
            # Create deployment service with database connection
            deployment_service = WazuhARDeploymentService(db_connection=self.db_connection)

            # Create SSH connection
            ssh = deployment_service._create_ssh_connection()
            print("[OK] SSH connection established")

            # Deploy only whitelist (not full AR config)
            deployment_service._deploy_whitelist_cdb(ssh)
            print("[OK] Whitelist deployed")

            # Update whitelist tags in ossec.conf if needed
            self._update_ossec_whitelist_tags(deployment_service, ssh, entries)

            # Restart Wazuh Manager to apply changes
            print("\n[5/5] Restarting Wazuh Manager...")
            deployment_service._restart_wazuh_manager(ssh)
            print("[OK] Wazuh Manager restarted")

            ssh.close()

            # Save hash of deployed whitelist
            self.save_deployed_hash(current_hash)

            print("\n" + "=" * 80)
            print("[SUCCESS] Whitelist synchronized successfully")
            print("=" * 80)

            self.db_connection.close()
            return True

        except Exception as e:
            print(f"\n[ERROR] Sync failed: {e}")
            self.db_connection.close()
            return False

    def _update_ossec_whitelist_tags(self, deployment_service, ssh, entries):
        """
        Update <white_list> tags in ossec.conf

        This ensures whitelist is active without requiring CDB compilation.
        """
        print("[INFO] Updating whitelist tags in ossec.conf...")

        # Fetch current ossec.conf
        sftp = ssh.open_sftp()
        remote_file = sftp.open(deployment_service.ossec_conf_path, 'r')
        ossec_conf_content = remote_file.read().decode()
        remote_file.close()
        sftp.close()

        # Remove old whitelist tags
        lines = ossec_conf_content.split('\n')
        new_lines = []
        in_global = False
        skip_whitelist = False

        for line in lines:
            if '<global>' in line:
                in_global = True
                new_lines.append(line)
            elif '</global>' in line:
                # Before closing global, add new whitelist tags
                if in_global:
                    new_lines.append('')
                    new_lines.append('  <!-- Active Response Whitelist (Auto-generated) -->')

                    # Add only single IPs (not CIDR) to <white_list> tags
                    for ip, desc in entries:
                        if '/' not in ip:  # Single IP, not CIDR
                            new_lines.append(f'  <white_list>{ip}</white_list>')

                in_global = False
                new_lines.append(line)
            elif in_global and '<white_list>' in line:
                # Skip old whitelist entries
                skip_whitelist = True
                continue
            elif skip_whitelist and '</white_list>' in line:
                skip_whitelist = False
                continue
            elif not skip_whitelist:
                new_lines.append(line)

        new_content = '\n'.join(new_lines)

        # Deploy updated ossec.conf
        import tempfile
        with tempfile.NamedTemporaryFile(mode='w', delete=False, suffix='_ossec.conf') as temp_file:
            temp_file.write(new_content)
            local_temp_path = temp_file.name

        try:
            remote_temp_path = '/tmp/ossec.conf.whitelist_update'
            sftp = ssh.open_sftp()
            sftp.put(local_temp_path, remote_temp_path)
            sftp.close()

            # Replace ossec.conf
            stdout, stderr, exit_status = deployment_service._exec_sudo_command(
                ssh, f'mv {remote_temp_path} {deployment_service.ossec_conf_path}'
            )

            if exit_status != 0:
                raise Exception(f"Failed to update ossec.conf: {stderr}")

            # Set permissions
            deployment_service._exec_sudo_command(ssh, 'chown root:wazuh /var/ossec/etc/ossec.conf')
            deployment_service._exec_sudo_command(ssh, 'chmod 640 /var/ossec/etc/ossec.conf')

            print("[OK] Whitelist tags updated in ossec.conf")

        finally:
            if os.path.exists(local_temp_path):
                os.remove(local_temp_path)


def main():
    """Main entry point"""
    parser = argparse.ArgumentParser(
        description='Sync Active Response whitelist from PostgreSQL to Wazuh Manager'
    )
    parser.add_argument(
        '--dry-run',
        action='store_true',
        help='Test without deploying changes'
    )

    args = parser.parse_args()

    sync_service = ARWhitelistSyncService(dry_run=args.dry_run)

    try:
        success = sync_service.sync_whitelist()
        sys.exit(0 if success else 1)
    except Exception as e:
        print(f"[FATAL] Sync service crashed: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)


if __name__ == '__main__':
    main()
