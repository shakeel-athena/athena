#!/usr/bin/env python3
"""
Athena Security Platform - Suppression Sync Cron Job (Optimized)
==================================================================

Purpose:
    Runs every 5 minutes but only syncs when rules actually change (hash-based)

Expected behavior:
    - 99% of runs: Skip (rules unchanged) - completes in <100ms
    - 1% of runs: Sync (rules changed) - completes in 2-3 seconds

Performance:
    - Old: 288 syncs/day, 288 SSH connections, 288 service reloads
    - New: ~10-20 syncs/day, 99.2% skip rate, 30x faster average runtime

Setup:
    Add to crontab:
    */5 * * * * cd /opt/athena/backend/response && python3 cron/sync_suppressions.py >> /var/log/athena/suppression_sync.log 2>&1

Author: Athena Security Team
Date: December 2025
"""

import sys
import os
import time
from datetime import datetime

# Add parent directory to path
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..', 'src')))

import psycopg2
from integrations.suricata_sync import SuricataSyncService
from integrations.wazuh_sync import WazuhSyncService


def main():
    """Main cron job function"""
    start_time = time.time()
    print(f"\n{'='*80}")
    print(f"Suppression Sync Cron Job - {datetime.now().isoformat()}")
    print(f"{'='*80}")

    try:
        # Connect to PostgreSQL (requires environment variables)
        conn = psycopg2.connect(
            host=os.getenv('POSTGRES_HOST'),
            database=os.getenv('POSTGRES_DB'),
            user=os.getenv('POSTGRES_USER'),
            password=os.getenv('POSTGRES_PASSWORD'),
            port=os.getenv('POSTGRES_PORT', '5432')
        )

        # Sync Suricata (with hash-based change detection)
        print("\n[Suricata] Checking for rule changes...")
        suricata_sync = SuricataSyncService(conn)
        suricata_result = suricata_sync.sync_mute_rules()

        if suricata_result.get('skipped'):
            print(f"[Suricata] [OK] No changes detected, sync skipped")
            print(f"[Suricata]    Rules: {suricata_result.get('rules_synced', 0)}")
            print(f"[Suricata]    Duration: {suricata_result.get('duration_ms', 0)}ms")
            print(f"[Suricata]    Hash: {suricata_result.get('sync_hash', 'N/A')[:16]}...")
        elif suricata_result.get('success'):
            print(f"[Suricata] [OK] Successfully synced {suricata_result.get('rules_synced', 0)} rules")
            print(f"[Suricata]    Duration: {suricata_result.get('duration_ms', 0)}ms")
            print(f"[Suricata]    Hash: {suricata_result.get('sync_hash', 'N/A')[:16]}...")
        else:
            print(f"[Suricata] [FAIL] Sync failed: {suricata_result.get('message', 'Unknown error')}")
            print(f"[Suricata]    Duration: {suricata_result.get('duration_ms', 0)}ms")

        # Sync Wazuh (with hash-based change detection)
        print("\n[Wazuh] Checking for rule changes...")
        wazuh_sync = WazuhSyncService(conn)
        wazuh_result = wazuh_sync.sync_mute_rules()

        if wazuh_result.get('skipped'):
            print(f"[Wazuh] [OK] No changes detected, sync skipped")
            print(f"[Wazuh]    IP Rules: {wazuh_result.get('ip_rules_synced', 0)}")
            print(f"[Wazuh]    Rule Overrides: {wazuh_result.get('rule_suppressions_synced', 0)}")
            print(f"[Wazuh]    Duration: {wazuh_result.get('duration_ms', 0)}ms")
        elif wazuh_result.get('success'):
            print(f"[Wazuh] [OK] Successfully synced rules")
            print(f"[Wazuh]    IP Rules: {wazuh_result.get('ip_rules_synced', 0)}")
            print(f"[Wazuh]    Rule Overrides: {wazuh_result.get('rule_suppressions_synced', 0)}")
            print(f"[Wazuh]    Duration: {wazuh_result.get('duration_ms', 0)}ms")
        else:
            print(f"[Wazuh] [FAIL] Sync failed: {wazuh_result.get('error', 'Unknown error')}")
            print(f"[Wazuh]    Duration: {wazuh_result.get('duration_ms', 0)}ms")

        conn.close()

        # Total execution time
        total_duration = int((time.time() - start_time) * 1000)
        print(f"\n{'='*80}")
        print(f"Total execution time: {total_duration}ms")
        print(f"{'='*80}\n")

        # Exit with appropriate code
        if suricata_result.get('success') and wazuh_result.get('success'):
            sys.exit(0)
        else:
            sys.exit(1)

    except Exception as e:
        print(f"\n[FAIL] FATAL ERROR: {str(e)}")
        import traceback
        traceback.print_exc()
        sys.exit(1)


if __name__ == '__main__':
    main()
