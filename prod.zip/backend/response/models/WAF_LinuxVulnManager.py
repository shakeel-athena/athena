from .BaseManagedRuleGroupManager import BaseManagedRuleGroupManager

class WAFLinuxVulnManager(BaseManagedRuleGroupManager):
    """
    Manages AWS Linux Rule Set managed rule group.
    Contains 3 individual rules for Linux-specific vulnerability protection.
    """
    
    def __init__(self, wafv2_client=None, scope: str = "REGIONAL", region: str = "us-east-1"):
        """
        Initialize the Linux Vulnerability Protection Manager
        
        Args:
            wafv2_client: Boto3 WAFv2 client
            scope: WAF scope (REGIONAL or CLOUDFRONT)
            region: AWS region
        """
        # AWS Linux Rule Set individual rules with exact names from AWS documentation
        rule_definitions = {
            "LFI_URIPATH": {
                "name": "LFI_URIPATH",
                "display_name": "Linux LFI in URI Path",
                "description": "Inspects the request path for attempts to exploit Local File Inclusion (LFI) vulnerabilities in web applications. Example patterns include files like /proc/version",
                "default_action": "Block",
                "priority": 1
            },
            "LFI_QUERYSTRING": {
                "name": "LFI_QUERYSTRING",
                "display_name": "Linux LFI in Query String",
                "description": "Inspects the values of querystring for attempts to exploit Local File Inclusion (LFI) vulnerabilities in web applications. Example patterns include files like /proc/version",
                "default_action": "Block",
                "priority": 2
            },
            "LFI_HEADER": {
                "name": "LFI_HEADER",
                "display_name": "Linux LFI in Headers",
                "description": "Inspects request headers for attempts to exploit Local File Inclusion (LFI) vulnerabilities in web applications. Example patterns include files like /proc/version",
                "default_action": "Block",
                "priority": 3
            }
        }
        
        super().__init__(
            wafv2_client=wafv2_client,
            scope=scope,
            region=region,
            rule_group_name="AWS-AWSManagedRulesLinuxRuleSet",
            rule_definitions=rule_definitions
        )
