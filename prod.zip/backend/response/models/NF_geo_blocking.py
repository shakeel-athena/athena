import os
import json
from typing import List, Optional, Dict, Any
from botocore.exceptions import ClientError


class NetworkFirewallGeoBlockingManager:
    """
    Manager class for Network Firewall Geo-blocking functionality.
    Handles adding, removing, and managing country-based geo-restrictions.
    """
    
    def __init__(self, network_firewall_client, rule_group_name: str = "geo-restrictions"):
        """
        Initialize the Network Firewall Geo-blocking Manager.
        
        Args:
            network_firewall_client: AWS Network Firewall client
            rule_group_name: Name of the stateful rule group (default: "geo-restrictions")
        """
        self.network_firewall = network_firewall_client
        self.rule_group_name = rule_group_name
        
    def _get_rule_group_details(self) -> Dict[str, Any]:
        """
        Get detailed information about the geo-restrictions rule group.
        
        Returns:
            Dict containing rule group details
            
        Raises:
            RuntimeError: If rule group is not found
        """
        try:
            response = self.network_firewall.describe_rule_group(
                RuleGroupName=self.rule_group_name,
                Type='STATEFUL'
            )
            return response
        except ClientError as e:
            if e.response['Error']['Code'] == 'ResourceNotFoundException':
                raise RuntimeError(f"Rule group '{self.rule_group_name}' not found")
            raise RuntimeError(f"Failed to get rule group details: {e}")
    
    def _extract_current_countries(self, rule_group_details: Dict[str, Any]) -> List[str]:
        """
        Extract current allowed countries from the rule group.
        
        Args:
            rule_group_details: Rule group details from AWS
            
        Returns:
            List of currently allowed country codes
        """
        try:
            rule_group = rule_group_details.get('RuleGroup', {})
            rules_source = rule_group.get('RulesSource', {})
            stateful_rules = rules_source.get('StatefulRules', [])
            
            if not stateful_rules:
                return []
            
            # Look for geoip rule options
            for rule in stateful_rules:
                rule_options = rule.get('RuleOptions', [])
                for option in rule_options:
                    if option.get('Keyword') == 'geoip':
                        settings = option.get('Settings', [])
                        if len(settings) >= 3:  # Format: ['src', '!AT', 'country1', 'country2', ...]
                            # Extract countries (skip 'src' and '!AT')
                            countries = [country for country in settings[2:] if len(country) == 2]
                            return sorted(countries)
            
            return []
        except Exception as e:
            print(f"Error extracting countries: {e}")
            return []
    
    def get_current_countries(self) -> List[str]:
        """
        Get the current list of allowed countries.
        
        Returns:
            List of currently allowed country codes
        """
        try:
            rule_group_details = self._get_rule_group_details()
            return self._extract_current_countries(rule_group_details)
        except Exception as e:
            print(f"Error getting current countries: {e}")
            return []
    
    def _construct_geoip_rule(self, countries: List[str]) -> Dict[str, Any]:
        """
        Construct a geoip rule with the specified countries.
        
        Args:
            countries: List of country codes to allow
            
        Returns:
            Dict containing the rule structure
        """
        # Sort countries for consistency
        countries = sorted([country.upper() for country in countries])
        
        # Construct geoip settings preserving the original format: ['src', '!AT', 'country1', 'country2', ...]
        geoip_settings = ['src', '!AT'] + countries
        
        rule = {
            'Action': 'DROP',
            'Header': {
                'Protocol': 'IP',
                'Source': 'ANY',
                'Destination': '$HOME_NET',
                'SourcePort': 'ANY',
                'DestinationPort': 'ANY',
                'Direction': 'FORWARD'
            },
            'RuleOptions': [
                {
                    'Keyword': 'sid',
                    'Settings': ['1']
                },
                {
                    'Keyword': 'geoip',
                    'Settings': geoip_settings
                }
            ]
        }
        
        return rule
    
    def _update_rule_group(self, new_countries: List[str]) -> bool:
        """
        Update the rule group with new country list.
        
        Args:
            new_countries: List of country codes to allow
            
        Returns:
            True if update successful, False otherwise
        """
        try:
            # Get current rule group details
            current_details = self._get_rule_group_details()
            rule_group = current_details.get('RuleGroup', {})
            
            # Construct new rule with updated countries
            new_rule = self._construct_geoip_rule(new_countries)
            
            # Create complete rule group with all original fields (this is the key fix!)
            updated_rule_group = {
                'RuleVariables': rule_group.get('RuleVariables', {}),
                'RulesSource': {
                    'StatefulRules': [new_rule]
                },
                'StatefulRuleOptions': rule_group.get('StatefulRuleOptions', {})
            }
            
            # Update the rule group
            self.network_firewall.update_rule_group(
                RuleGroupName=self.rule_group_name,
                Type='STATEFUL',
                RuleGroup=updated_rule_group,
                UpdateToken=current_details.get('UpdateToken')
            )
            return True
            
        except ClientError as e:
            print(f"Error updating rule group: {e}")
            return False
        except Exception as e:
            print(f"Unexpected error updating rule group: {e}")
            return False
    
    def add_countries(self, countries: List[str]) -> List[str]:
        """
        Add countries to the allowed list.
        
        Args:
            countries: List of country codes to add
            
        Returns:
            Updated list of allowed countries
        """
        try:
            # Normalize country codes
            countries = [country.upper() for country in countries]
            
            # Get current countries
            current_countries = self.get_current_countries()
            
            # Add new countries (avoid duplicates)
            new_countries = sorted(set(current_countries + countries))
            
            # Update if there are changes
            if new_countries != current_countries:
                if self._update_rule_group(new_countries):
                    print(f"Successfully added countries: {countries}")
                    return new_countries
                else:
                    print("Failed to update rule group")
                    return current_countries
            else:
                print("No new countries to add")
                return current_countries
                
        except Exception as e:
            print(f"Error adding countries: {e}")
            return self.get_current_countries()
    
    def remove_countries(self, countries: List[str]) -> List[str]:
        """
        Remove countries from the allowed list.
        
        Args:
            countries: List of country codes to remove
            
        Returns:
            Updated list of allowed countries
        """
        try:
            # Normalize country codes
            countries = [country.upper() for country in countries]
            
            # Get current countries
            current_countries = self.get_current_countries()
            
            # Remove specified countries
            new_countries = [country for country in current_countries if country not in countries]
            
            # Update if there are changes
            if new_countries != current_countries:
                if self._update_rule_group(new_countries):
                    print(f"Successfully removed countries: {countries}")
                    return new_countries
                else:
                    print("Failed to update rule group")
                    return current_countries
            else:
                print("No countries to remove")
                return current_countries
                
        except Exception as e:
            print(f"Error removing countries: {e}")
            return self.get_current_countries()
    
    def set_countries(self, countries: List[str]) -> List[str]:
        """
        Set the complete list of allowed countries (replaces existing list).
        
        Args:
            countries: Complete list of country codes to allow
            
        Returns:
            Updated list of allowed countries
        """
        try:
            # Normalize and sort country codes
            countries = sorted([country.upper() for country in countries])
            
            # Update the rule group
            if self._update_rule_group(countries):
                print(f"Successfully set countries: {countries}")
                return countries
            else:
                print("Failed to update rule group")
                return self.get_current_countries()
                
        except Exception as e:
            print(f"Error setting countries: {e}")
            return self.get_current_countries()
    
    def display_current_configuration(self) -> None:
        """
        Display the current geo-restrictions configuration.
        """
        try:
            rule_group_details = self._get_rule_group_details()
            rule_group = rule_group_details.get('RuleGroup', {})
            
            print(f"\n=== {self.rule_group_name.upper()} CONFIGURATION ===")
            print(f"Rule Group Name: {rule_group.get('RuleGroupName', 'N/A')}")
            print(f"Capacity: {rule_group.get('Capacity', 'N/A')}")
            print(f"Description: {rule_group.get('Description', 'N/A')}")
            
            current_countries = self.get_current_countries()
            print(f"\nCurrently Allowed Countries ({len(current_countries)}):")
            if current_countries:
                for i, country in enumerate(current_countries, 1):
                    print(f"  {i:2d}. {country}")
            else:
                print("  No countries configured")
                
        except Exception as e:
            print(f"Error displaying configuration: {e}")
    
    def validate_country_codes(self, countries: List[str]) -> List[str]:
        """
        Validate and normalize country codes.
        
        Args:
            countries: List of country codes to validate
            
        Returns:
            List of valid, normalized country codes
        """
        # Common country codes for validation
        valid_countries = {
            'AD', 'AE', 'AF', 'AG', 'AI', 'AL', 'AM', 'AO', 'AQ', 'AR', 'AS', 'AT', 'AU', 'AW', 'AX', 'AZ',
            'BA', 'BB', 'BD', 'BE', 'BF', 'BG', 'BH', 'BI', 'BJ', 'BL', 'BM', 'BN', 'BO', 'BQ', 'BR', 'BS',
            'BT', 'BV', 'BW', 'BY', 'BZ', 'CA', 'CC', 'CD', 'CF', 'CG', 'CH', 'CI', 'CK', 'CL', 'CM', 'CN',
            'CO', 'CR', 'CU', 'CV', 'CW', 'CX', 'CY', 'CZ', 'DE', 'DJ', 'DK', 'DM', 'DO', 'DZ', 'EC', 'EE',
            'EG', 'EH', 'ER', 'ES', 'ET', 'FI', 'FJ', 'FK', 'FM', 'FO', 'FR', 'GA', 'GB', 'GD', 'GE', 'GF',
            'GG', 'GH', 'GI', 'GL', 'GM', 'GN', 'GP', 'GQ', 'GR', 'GS', 'GT', 'GU', 'GW', 'GY', 'HK', 'HM',
            'HN', 'HR', 'HT', 'HU', 'ID', 'IE', 'IL', 'IM', 'IN', 'IO', 'IQ', 'IR', 'IS', 'IT', 'JE', 'JM',
            'JO', 'JP', 'KE', 'KG', 'KH', 'KI', 'KM', 'KN', 'KP', 'KR', 'KW', 'KY', 'KZ', 'LA', 'LB', 'LC',
            'LI', 'LK', 'LR', 'LS', 'LT', 'LU', 'LV', 'LY', 'MA', 'MC', 'MD', 'ME', 'MF', 'MG', 'MH', 'MK',
            'ML', 'MM', 'MN', 'MO', 'MP', 'MQ', 'MR', 'MS', 'MT', 'MU', 'MV', 'MW', 'MX', 'MY', 'MZ', 'NA',
            'NC', 'NE', 'NF', 'NG', 'NI', 'NL', 'NO', 'NP', 'NR', 'NU', 'NZ', 'OM', 'PA', 'PE', 'PF', 'PG',
            'PH', 'PK', 'PL', 'PM', 'PN', 'PR', 'PS', 'PT', 'PW', 'PY', 'QA', 'RE', 'RO', 'RS', 'RU', 'RW',
            'SA', 'SB', 'SC', 'SD', 'SE', 'SG', 'SH', 'SI', 'SJ', 'SK', 'SL', 'SM', 'SN', 'SO', 'SR', 'SS',
            'ST', 'SV', 'SX', 'SY', 'SZ', 'TC', 'TD', 'TF', 'TG', 'TH', 'TJ', 'TK', 'TL', 'TM', 'TN', 'TO',
            'TR', 'TT', 'TV', 'TW', 'TZ', 'UA', 'UG', 'UM', 'US', 'UY', 'UZ', 'VA', 'VC', 'VE', 'VG', 'VI',
            'VN', 'VU', 'WF', 'WS', 'YE', 'YT', 'ZA', 'ZM', 'ZW'
        }
        
        normalized = []
        for country in countries:
            country_upper = country.upper()
            if len(country_upper) == 2 and country_upper in valid_countries:
                normalized.append(country_upper)
            else:
                print(f"Warning: Invalid country code '{country}' - skipping")
        
        return normalized


# Example usage function
def example_usage():
    """
    Example of how to use the NetworkFirewallGeoBlockingManager
    """
    import boto3
    from dotenv import load_dotenv
    import os
    
    load_dotenv(dotenv_path=os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))), '.env'))
    
    # Initialize AWS session
    session = boto3.Session(
        profile_name=os.getenv("AWS_PROFILE"),
        region_name="us-east-2"
    )
    
    # Create Network Firewall client
    network_firewall = session.client("network-firewall")
    
    # Initialize the manager
    geo_manager = NetworkFirewallGeoBlockingManager(network_firewall)
    
    # Display current configuration
    geo_manager.display_current_configuration()
    
    # Add new countries
    print("\n=== TESTING ADD COUNTRIES ===")
    new_countries = geo_manager.add_countries(['GB', 'AU', 'NZ'])
    print(f"After adding GB, AU, NZ: {new_countries}")
    
    # Remove countries
    print("\n=== TESTING REMOVE COUNTRIES ===")
    updated_countries = geo_manager.remove_countries(['IN', 'LI'])
    print(f"After removing IN, LI: {updated_countries}")
    
    # Set complete list
    print("\n=== TESTING SET COUNTRIES ===")
    final_countries = geo_manager.set_countries(['US', 'CA', 'GB', 'DE', 'FR'])
    print(f"Final country list: {final_countries}")

    print("\n=== FINAL CONFIGURATION ===")
    geo_manager.display_current_configuration()


if __name__ == "__main__":
    example_usage()
