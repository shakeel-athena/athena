from .BaseManagedRuleGroupManager import BaseManagedRuleGroupManager

class WAFCommonAttackManager(BaseManagedRuleGroupManager):
    """
    Manages AWS Common Rule Set (Core Rule Set) managed rule group.
    Contains 20 individual rules for general web application protection.
    """
    
    def __init__(self, wafv2_client=None, scope: str = "REGIONAL", region: str = "us-east-1"):
        """
        Initialize the Common Attack Protection Manager
        
        Args:
            wafv2_client: Boto3 WAFv2 client
            scope: WAF scope (REGIONAL or CLOUDFRONT)
            region: AWS region
        """
        # AWS Common Rule Set individual rules with exact names from AWS documentation
        rule_definitions = {
            "NoUserAgent_HEADER": {
                "name": "NoUserAgent_HEADER",
                "display_name": "Missing User-Agent Header",
                "description": "Inspects for requests that are missing the HTTP User-Agent header",
                "default_action": "Block",
                "priority": 1
            },
            "UserAgent_BadBots_HEADER": {
                "name": "UserAgent_BadBots_HEADER",
                "display_name": "Bad Bot User-Agent",
                "description": "Inspects for common User-Agent header values that indicate bad bots (nessus, nmap, etc.)",
                "default_action": "Block",
                "priority": 2
            },
            "SizeRestrictions_QUERYSTRING": {
                "name": "SizeRestrictions_QUERYSTRING",
                "display_name": "Query String Size Limit",
                "description": "Inspects for URI query strings that are over 2,048 bytes",
                "default_action": "Block",
                "priority": 3
            },
            "SizeRestrictions_Cookie_HEADER": {
                "name": "SizeRestrictions_Cookie_HEADER",
                "display_name": "Cookie Size Limit",
                "description": "Inspects for cookie headers that are over 10,240 bytes",
                "default_action": "Block",
                "priority": 4
            },
            "SizeRestrictions_BODY": {
                "name": "SizeRestrictions_BODY",
                "display_name": "Request Body Size Limit",
                "description": "Inspects for request bodies that are over 8 KB (8,192 bytes)",
                "default_action": "Block",
                "priority": 5
            },
            "SizeRestrictions_URIPATH": {
                "name": "SizeRestrictions_URIPATH",
                "display_name": "URI Path Size Limit",
                "description": "Inspects for URI paths that are over 1,024 bytes",
                "default_action": "Block",
                "priority": 6
            },
            "EC2MetaDataSSRF_BODY": {
                "name": "EC2MetaDataSSRF_BODY",
                "display_name": "EC2 Metadata SSRF in Body",
                "description": "Inspects for attempts to exfiltrate Amazon EC2 metadata from the request body",
                "default_action": "Block",
                "priority": 7
            },
            "EC2MetaDataSSRF_COOKIE": {
                "name": "EC2MetaDataSSRF_COOKIE",
                "display_name": "EC2 Metadata SSRF in Cookie",
                "description": "Inspects for attempts to exfiltrate Amazon EC2 metadata from the request cookie",
                "default_action": "Block",
                "priority": 8
            },
            "EC2MetaDataSSRF_URIPATH": {
                "name": "EC2MetaDataSSRF_URIPATH",
                "display_name": "EC2 Metadata SSRF in URI Path",
                "description": "Inspects for attempts to exfiltrate Amazon EC2 metadata from the request URI path",
                "default_action": "Block",
                "priority": 9
            },
            "EC2MetaDataSSRF_QUERYARGUMENTS": {
                "name": "EC2MetaDataSSRF_QUERYARGUMENTS",
                "display_name": "EC2 Metadata SSRF in Query Arguments",
                "description": "Inspects for attempts to exfiltrate Amazon EC2 metadata from the request query arguments",
                "default_action": "Block",
                "priority": 10
            },
            "GenericLFI_QUERYARGUMENTS": {
                "name": "GenericLFI_QUERYARGUMENTS",
                "display_name": "Generic LFI in Query Arguments",
                "description": "Inspects for the presence of Local File Inclusion (LFI) exploits in the query arguments",
                "default_action": "Block",
                "priority": 11
            },
            "GenericLFI_URIPATH": {
                "name": "GenericLFI_URIPATH",
                "display_name": "Generic LFI in URI Path",
                "description": "Inspects for the presence of Local File Inclusion (LFI) exploits in the URI path",
                "default_action": "Block",
                "priority": 12
            },
            "GenericLFI_BODY": {
                "name": "GenericLFI_BODY",
                "display_name": "Generic LFI in Request Body",
                "description": "Inspects for the presence of Local File Inclusion (LFI) exploits in the request body",
                "default_action": "Block",
                "priority": 13
            },
            "RestrictedExtensions_URIPATH": {
                "name": "RestrictedExtensions_URIPATH",
                "display_name": "Restricted Extensions in URI Path",
                "description": "Inspects for requests whose URI paths contain system file extensions that are unsafe to read or run (.log, .ini, etc.)",
                "default_action": "Block",
                "priority": 14
            },
            "RestrictedExtensions_QUERYARGUMENTS": {
                "name": "RestrictedExtensions_QUERYARGUMENTS",
                "display_name": "Restricted Extensions in Query Arguments",
                "description": "Inspects for requests whose query arguments contain system file extensions that are unsafe to read or run (.log, .ini, etc.)",
                "default_action": "Block",
                "priority": 15
            },
            "GenericRFI_QUERYARGUMENTS": {
                "name": "GenericRFI_QUERYARGUMENTS",
                "display_name": "Generic RFI in Query Arguments",
                "description": "Inspects the values of all query parameters for attempts to exploit RFI (Remote File Inclusion) in web applications",
                "default_action": "Block",
                "priority": 16
            },
            "GenericRFI_BODY": {
                "name": "GenericRFI_BODY",
                "display_name": "Generic RFI in Request Body",
                "description": "Inspects the request body for attempts to exploit RFI (Remote File Inclusion) in web applications",
                "default_action": "Block",
                "priority": 17
            },
            "GenericRFI_URIPATH": {
                "name": "GenericRFI_URIPATH",
                "display_name": "Generic RFI in URI Path",
                "description": "Inspects the URI path for attempts to exploit RFI (Remote File Inclusion) in web applications",
                "default_action": "Block",
                "priority": 18
            },
            "CrossSiteScripting_COOKIE": {
                "name": "CrossSiteScripting_COOKIE",
                "display_name": "Cross-Site Scripting in Cookies",
                "description": "Inspects the values of cookie headers for common cross-site scripting (XSS) patterns",
                "default_action": "Block",
                "priority": 19
            },
            "CrossSiteScripting_QUERYARGUMENTS": {
                "name": "CrossSiteScripting_QUERYARGUMENTS",
                "display_name": "Cross-Site Scripting in Query Arguments",
                "description": "Inspects the values of query arguments for common cross-site scripting (XSS) patterns",
                "default_action": "Block",
                "priority": 20
            }
        }
        
        super().__init__(
            wafv2_client=wafv2_client,
            scope=scope,
            region=region,
            rule_group_name="AWS-AWSManagedRulesCommonRuleSet",
            rule_definitions=rule_definitions
        )
