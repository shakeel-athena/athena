import boto3
import json
from typing import Dict, List, Tuple
import os

# Note: Environment variables are loaded by the calling app (app.py)

class WAFSignatureBlockingManager:
    """
    Manages WAF signatures and rules for blocking malicious traffic.
    """
    BASIC_SIGNATURES = {
        "GEO_RESTRICTIONS": {
            "name": "Geo-Restrictions",  # AWS Rule Name
            "display_name": "Geographic Restrictions",  # User-friendly name
            "priority": 2,
            "action": "Block",
            "statement": {
                "GeoMatchStatement": {
                    "CountryCodes": ["CN", "RU", "KP", "IR"]
                }
            },
            "description": "Blocks traffic from restricted geographical locations"
        },
        "BLOCKIP_RULE": {
            "name": "BLOCKIP_RULE",  # AWS Rule Name
            "display_name": "IP Blocking Rule",  # User-friendly name
            "priority": 9,
            "action": "Block",
            "statement": {
                "ByteMatchStatement": {
                    "SearchString": "blocked",
                    "FieldToMatch": {
                        "UriPath": {}
                    },
                    "TextTransformations": [
                        {
                            "Priority": 0,
                            "Type": "LOWERCASE"
                        }
                    ],
                    "PositionalConstraint": "CONTAINS"
                }
            },
            "description": "Blocks traffic containing 'blocked' in URI path"
        },
        "WAF_RATE_LIMITER": {
            "name": "WAF_Rate_Limiter_Rule",  # AWS Rule Name
            "display_name": "Rate Limiting Protection",  # User-friendly name
            "priority": 10,
            "action": "Block",
            "statement": {
                "RateBasedStatement": {
                    "Limit": 2000,
                    "AggregateKeyType": "IP"
                }
            },
            "description": "Rate limiting rule to prevent abuse"
        }
    }
    
    def __init__(self, wafv2_client=None, scope: str = "REGIONAL", web_acl_name: str = None):
        """
        Initialize the WAF Signature Blocking Manager.
        
        Args:
            wafv2_client: Pre-configured WAFv2 client (optional)
            scope: WAF scope (REGIONAL or CLOUDFRONT)
            web_acl_name: Name of the Web ACL to manage
        """
        self.wafv2_client = wafv2_client or boto3.client('wafv2')
        self.scope = scope
        self.web_acl_name = web_acl_name or os.getenv("WAF_WEB_ACL")
        
        if not self.web_acl_name:
            raise ValueError("Web ACL name must be provided either in constructor or WAF_WEB_ACL environment variable")
    
    def _get_web_acl(self) -> Tuple[Dict, str]:
        """
        Retrieve the Web ACL and its lock token.
        
        Returns:
            Tuple of (web_acl_dict, lock_token)
        """
        try:
            # First, get the Web ACL ID
            web_acls = self.wafv2_client.list_web_acls(Scope=self.scope)
            web_acl_id = None
            
            for acl in web_acls.get('WebACLs', []):
                if acl['Name'] == self.web_acl_name:
                    web_acl_id = acl['Id']
                    break
            
            if not web_acl_id:
                raise ValueError(f"Web ACL '{self.web_acl_name}' not found")
            
            # Get the full Web ACL details
            response = self.wafv2_client.get_web_acl(
                Name=self.web_acl_name,
                Scope=self.scope,
                Id=web_acl_id
            )
            
            return response['WebACL'], response['LockToken']
            
        except Exception as e:
            raise RuntimeError(f"Failed to retrieve Web ACL '{self.web_acl_name}': {e}")
    
    def _update_web_acl(self, web_acl: Dict, lock_token: str) -> None:
        """
        Update the Web ACL with new rules.
        
        Args:
            web_acl: The modified Web ACL dictionary
            lock_token: The lock token for optimistic locking
        """
        try:
            # Ensure description is not empty for AWS validation
            description = web_acl.get('Description', '').strip()
            if not description:
                description = 'Managed by Athena Network Response Management'
                
            self.wafv2_client.update_web_acl(
                Scope=self.scope,
                Id=web_acl['Id'],
                Name=web_acl['Name'],
                DefaultAction=web_acl['DefaultAction'],
                Rules=web_acl['Rules'],
                Description=description,
                LockToken=lock_token,
                VisibilityConfig={
                    'SampledRequestsEnabled': True,
                    'CloudWatchMetricsEnabled': True,
                    'MetricName': web_acl['Name']
                }
            )
        except Exception as e:
            raise RuntimeError(f"Failed to update Web ACL: {e}")
    
    def get_available_signatures(self) -> Dict[str, Dict]:
        """
        Get all available signature definitions.
        
        Returns:
            Dictionary of signature IDs and their definitions
        """
        # Combine basic signatures with AWS managed rules that match existing rules
        aws_managed_rules = {
            "AWS_AMAZON_IP_REPUTATION": {
                "name": "AWS-AWSManagedRulesAmazonIpReputationList",  # AWS Rule Name
                "display_name": "Amazon IP Reputation List",  # User-friendly name
                "priority": 3,
                "description": "Blocks requests from IP addresses identified as malicious by AWS"
            },
            "AWS_ANONYMOUS_IP_LIST": {
                "name": "AWS-AWSManagedRulesAnonymousIpList",  # AWS Rule Name
                "display_name": "Anonymous IP Protection",  # User-friendly name
                "priority": 4,
                "description": "Blocks requests from anonymous IP addresses (VPNs, proxies, Tor)"
            },
            "AWS_COMMON_RULE_SET": {
                "name": "AWS-AWSManagedRulesCommonRuleSet",  # AWS Rule Name
                "display_name": "Common Attack Protection",  # User-friendly name
                "priority": 5,
                "description": "Blocks common web application attacks"
            },
            "AWS_KNOWN_BAD_INPUTS": {
                "name": "AWS-AWSManagedRulesKnownBadInputsRuleSet",  # AWS Rule Name
                "display_name": "Known Bad Inputs Filter",  # User-friendly name
                "priority": 6,
                "description": "Blocks requests with patterns known to be malicious"
            },
            "AWS_LINUX_RULE_SET": {
                "name": "AWS-AWSManagedRulesLinuxRuleSet",  # AWS Rule Name
                "display_name": "Linux Vulnerability Protection",  # User-friendly name
                "priority": 7,
                "description": "Blocks requests targeting Linux-specific vulnerabilities"
            },
            "AWS_UNIX_RULE_SET": {
                "name": "AWS-AWSManagedRulesUnixRuleSet",  # AWS Rule Name
                "display_name": "Unix Vulnerability Protection",  # User-friendly name
                "priority": 8,
                "description": "Blocks requests targeting Unix-specific vulnerabilities"
            }
        }
        
        # Combine basic signatures and AWS managed rules
        all_signatures = {}
        
        # Add basic signatures
        for sig_id, sig_def in self.BASIC_SIGNATURES.items():
            all_signatures[sig_id] = {
                "name": sig_def["name"],  # AWS Rule Name (for backend operations)
                "display_name": sig_def["display_name"],  # User-friendly name (for frontend)
                "description": sig_def["description"],
                "priority": sig_def["priority"],
                "type": "CUSTOM"
            }
        
        # Add AWS managed rules  
        for sig_id, sig_def in aws_managed_rules.items():
            all_signatures[sig_id] = {
                "name": sig_def["name"],  # AWS Rule Name (for backend operations)
                "display_name": sig_def["display_name"],  # User-friendly name (for frontend)
                "description": sig_def["description"],
                "priority": sig_def["priority"],
                "type": "MANAGED"
            }
            
        return all_signatures
    
    def get_active_signatures(self) -> List[str]:
        """
        Get list of currently active signature rule names in the Web ACL.
        A rule is considered active if it has a Block action.
        
        Returns:
            List of active signature rule names
        """
        try:
            web_acl, _ = self._get_web_acl()
            active_signatures = []
            
            # Get all available signatures (both custom and AWS managed)
            available_signatures = self.get_available_signatures()
            
            # Check which rules from our available signatures are active (Block action)
            for rule in web_acl.get('Rules', []):
                rule_name = rule['Name']
                
                # Find which signature this rule corresponds to
                for sig_id, sig_info in available_signatures.items():
                    if sig_info["name"] == rule_name:
                        # Check if rule has Block action (active) or Allow/Count action (inactive)
                        if 'Action' in rule and 'Block' in rule['Action']:
                            active_signatures.append(sig_id)
                        elif 'OverrideAction' in rule and 'None' in rule['OverrideAction']:
                            # AWS Managed rules are always considered active when present
                            active_signatures.append(sig_id)
                        break
            
            return active_signatures
            
        except Exception as e:
            raise RuntimeError(f"Failed to get active signatures: {e}")
    
    def add_signature(self, signature_id: str) -> bool:
        """
        Add a specific signature rule to the Web ACL.
        
        Args:
            signature_id: ID of the signature to add (e.g., 'AWS_AMAZON_IP_REPUTATION')
        
        Returns:
            True if signature was added, False if already exists
        """
        available_signatures = self.get_available_signatures()
        if signature_id not in available_signatures:
            raise ValueError(f"Unknown signature ID: {signature_id}. Available: {list(available_signatures.keys())}")
        
        try:
            web_acl, lock_token = self._get_web_acl()
            signature_info = available_signatures[signature_id]
            
            # Check if rule already exists
            existing_rule_names = [rule['Name'] for rule in web_acl.get('Rules', [])]
            if signature_info["name"] in existing_rule_names:
                return False  # Rule already exists
            
            # Create the new rule based on type
            if signature_info["type"] == "MANAGED":
                # Create AWS Managed Rule Group reference
                rule_group_name = signature_info["name"].replace("AWS-", "")
                new_rule = {
                    "Name": signature_info["name"],  # Use AWS Rule Name
                    "Priority": signature_info["priority"],
                    "Statement": {
                        "ManagedRuleGroupStatement": {
                            "VendorName": "AWS",
                            "Name": rule_group_name
                        }
                    },
                    "OverrideAction": {
                        "None": {}
                    },
                    "VisibilityConfig": {
                        "SampledRequestsEnabled": True,
                        "CloudWatchMetricsEnabled": True,
                        "MetricName": signature_info["name"].replace("-", "_")
                    }
                }
            else:
                # Create custom rule from BASIC_SIGNATURES
                signature_def = self.BASIC_SIGNATURES[signature_id]
                new_rule = {
                    "Name": signature_def["name"],  # Use AWS Rule Name
                    "Priority": signature_def["priority"],
                    "Statement": signature_def["statement"],
                    "Action": {
                        signature_def["action"]: {}
                    },
                    "VisibilityConfig": {
                        "SampledRequestsEnabled": True,
                        "CloudWatchMetricsEnabled": True,
                        "MetricName": signature_def["name"].replace("-", "_")
                    }
                }
            
            # Add the rule to the Web ACL
            web_acl['Rules'].append(new_rule)
            
            # Sort rules by priority to maintain order
            web_acl['Rules'].sort(key=lambda x: x['Priority'])
            
            # Update the Web ACL
            self._update_web_acl(web_acl, lock_token)
            
            return True
            
        except Exception as e:
            raise RuntimeError(f"Failed to add signature '{signature_id}': {e}")
    
    def remove_signature(self, signature_id: str) -> bool:
        """
        Remove a specific signature rule from the Web ACL.
        
        Args:
            signature_id: ID of the signature to remove
        
        Returns:
            True if signature was removed, False if not found
        """
        available_signatures = self.get_available_signatures()
        if signature_id not in available_signatures:
            raise ValueError(f"Unknown signature ID: {signature_id}. Available: {list(available_signatures.keys())}")
        
        try:
            web_acl, lock_token = self._get_web_acl()
            signature_info = available_signatures[signature_id]
            
            # Find and remove the rule
            original_count = len(web_acl.get('Rules', []))
            web_acl['Rules'] = [
                rule for rule in web_acl.get('Rules', []) 
                if rule['Name'] != signature_info["name"]  # Use AWS Rule Name
            ]
            
            if len(web_acl['Rules']) == original_count:
                return False  # Rule was not found
            
            # Update the Web ACL
            self._update_web_acl(web_acl, lock_token)
            
            return True
            
        except Exception as e:
            raise RuntimeError(f"Failed to remove signature '{signature_id}': {e}")
    
    def toggle_signature(self, signature_id: str) -> bool:
        """
        Toggle a signature by changing its action between Block and Allow.
        For AWS Managed rules, this adds/removes the rule.
        For custom rules, this changes the action between Block and Allow.
        
        Args:
            signature_id: ID of the signature to toggle
            
        Returns:
            True if signature is now active (Block), False if now inactive (Allow)
        """
        available_signatures = self.get_available_signatures()
        if signature_id not in available_signatures:
            raise ValueError(f"Unknown signature ID: {signature_id}. Available: {list(available_signatures.keys())}")
        
        try:
            web_acl, lock_token = self._get_web_acl()
            signature_info = available_signatures[signature_id]
            
            # Find the existing rule
            existing_rule = None
            for rule in web_acl.get('Rules', []):
                if rule['Name'] == signature_info["name"]:  # Use AWS Rule Name
                    existing_rule = rule
                    break
            
            if existing_rule:
                # Rule exists - toggle its action
                if signature_info["type"] == "MANAGED":
                    # For AWS Managed rules, remove the rule to disable
                    web_acl['Rules'] = [
                        rule for rule in web_acl.get('Rules', []) 
                        if rule['Name'] != signature_info["name"]  # Use AWS Rule Name
                    ]
                    # Sort rules by priority to maintain order
                    web_acl['Rules'].sort(key=lambda x: x['Priority'])
                    # Update the Web ACL
                    self._update_web_acl(web_acl, lock_token)
                    return False  # Now inactive
                else:
                    # For custom rules, toggle between Block and Allow
                    if 'Action' in existing_rule and 'Block' in existing_rule['Action']:
                        # Currently blocking - change to allow
                        existing_rule['Action'] = {"Allow": {}}
                        # Sort rules by priority to maintain order
                        web_acl['Rules'].sort(key=lambda x: x['Priority'])
                        # Update the Web ACL
                        self._update_web_acl(web_acl, lock_token)
                        return False  # Now inactive
                    else:
                        # Currently allowing - change to block
                        existing_rule['Action'] = {"Block": {}}
                        # Sort rules by priority to maintain order
                        web_acl['Rules'].sort(key=lambda x: x['Priority'])
                        # Update the Web ACL
                        self._update_web_acl(web_acl, lock_token)
                        return True  # Now active
            else:
                # Rule doesn't exist - add it
                if signature_info["type"] == "MANAGED":
                    # Create AWS Managed Rule Group reference
                    rule_group_name = signature_info["name"].replace("AWS-", "")
                    new_rule = {
                        "Name": signature_info["name"],  # Use AWS Rule Name
                        "Priority": signature_info["priority"],
                        "Statement": {
                            "ManagedRuleGroupStatement": {
                                "VendorName": "AWS",
                                "Name": rule_group_name
                            }
                        },
                        "OverrideAction": {
                            "None": {}
                        },
                        "VisibilityConfig": {
                            "SampledRequestsEnabled": True,
                            "CloudWatchMetricsEnabled": True,
                            "MetricName": signature_info["name"].replace("-", "_")
                        }
                    }
                else:
                    # Create custom rule from BASIC_SIGNATURES
                    signature_def = self.BASIC_SIGNATURES[signature_id]
                    new_rule = {
                        "Name": signature_def["name"],  # Use AWS Rule Name
                        "Priority": signature_def["priority"],
                        "Statement": signature_def["statement"],
                        "Action": {
                            signature_def["action"]: {}
                        },
                        "VisibilityConfig": {
                            "SampledRequestsEnabled": True,
                            "CloudWatchMetricsEnabled": True,
                            "MetricName": signature_def["name"].replace("-", "_")
                        }
                    }
                
                # Add the rule to the Web ACL
                web_acl['Rules'].append(new_rule)
                
                # Sort rules by priority to maintain order
                web_acl['Rules'].sort(key=lambda x: x['Priority'])
                
                # Update the Web ACL
                self._update_web_acl(web_acl, lock_token)
                
                return True  # Now active
            
        except Exception as e:
            raise RuntimeError(f"Failed to toggle signature: {e}")
    
    def add_multiple_signatures(self, signature_ids: List[str]) -> Dict[str, bool]:
        """
        Add multiple signatures to the Web ACL.
        
        Args:
            signature_ids: List of signature IDs to add
        
        Returns:
            Dictionary mapping signature IDs to success status
        """
        results = {}
        for sig_id in signature_ids:
            try:
                results[sig_id] = self.add_signature(sig_id)
            except Exception as e:
                results[sig_id] = False
                print(f"Failed to add signature {sig_id}: {e}")
        
        return results
    
    def remove_multiple_signatures(self, signature_ids: List[str]) -> Dict[str, bool]:
        """
        Remove multiple signatures from the Web ACL.
        
        Args:
            signature_ids: List of signature IDs to remove
        
        Returns:
            Dictionary mapping signature IDs to success status
        """
        results = {}
        for sig_id in signature_ids:
            try:
                results[sig_id] = self.remove_signature(sig_id)
            except Exception as e:
                results[sig_id] = False
                print(f"Failed to remove signature {sig_id}: {e}")
        
        return results
    
    def remove_all_signatures(self) -> Dict[str, bool]:
        """
        Remove all signatures from the Web ACL.
        
        Returns:
            Dictionary mapping signature IDs to success status
        """
        return self.remove_multiple_signatures(list(self.BASIC_SIGNATURES.keys()))
    
    def get_signature_status(self) -> Dict[str, Dict]:
        """
        Get the status of all available signatures.
        
        Returns:
            Dictionary mapping signature IDs to their status information
        """
        try:
            available_signatures = self.get_available_signatures()
            active_signatures = self.get_active_signatures()
            
            status = {}
            for sig_id, sig_info in available_signatures.items():
                status[sig_id] = {
                    "name": sig_info["name"],  # AWS Rule Name (for backend operations)
                    "display_name": sig_info["display_name"],  # User-friendly name (for frontend)
                    "description": sig_info["description"],
                    "priority": sig_info["priority"],
                    "type": sig_info["type"],
                    "active": sig_id in active_signatures
                }
            
            return status
            
        except Exception as e:
            raise RuntimeError(f"Failed to get signature status: {e}")
    
    def get_web_acl_info(self) -> Dict:
        """
        Get information about the Web ACL.
        
        Returns:
            Dictionary containing Web ACL information
        """
        try:
            web_acl, _ = self._get_web_acl()
            return {
                "name": web_acl.get("Name"),
                "id": web_acl.get("Id"),
                "arn": web_acl.get("ARN"),
                "description": web_acl.get("Description"),
                "default_action": web_acl.get("DefaultAction"),
                "rule_count": len(web_acl.get("Rules", [])),
                "rules": web_acl.get("Rules", [])
            }
        except Exception as e:
            raise RuntimeError(f"Failed to get Web ACL info: {e}")
