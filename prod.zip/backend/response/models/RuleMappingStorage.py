import json
import os
from typing import Dict, Optional, List

class RuleMappingStorage:
    """Handles storage and retrieval of rule mappings between original managed rules and custom allow list rules."""
    
    def __init__(self, storage_file: str = "rule_mappings.json"):
        # Use absolute path to ensure we find the file regardless of working directory
        if not os.path.isabs(storage_file):
            # Find the src directory relative to this models directory
            models_dir = os.path.dirname(os.path.abspath(__file__))
            src_dir = os.path.join(os.path.dirname(models_dir), "src")
            storage_file = os.path.join(src_dir, storage_file)
        self.storage_file = storage_file
        self.mappings = self._load_mappings()
    
    def _load_mappings(self) -> Dict:
        """Load mappings from storage file."""
        if os.path.exists(self.storage_file):
            try:
                with open(self.storage_file, 'r') as f:
                    return json.load(f)
            except (json.JSONDecodeError, IOError) as e:
                print(f"Error loading mappings: {e}")
                return {}
        return {}
    
    def _save_mappings(self):
        """Save mappings to storage file."""
        try:
            with open(self.storage_file, 'w') as f:
                json.dump(self.mappings, f, indent=2)
        except IOError as e:
            print(f"Error saving mappings: {e}")
    
    def save_rule_mapping(self, rule_group: str, original_rule: str, custom_rule_name: str, 
                         ip_list: List[str], domain_list: List[str], 
                         ip_set_arn: str = None, regex_set_arn: str = None) -> None:
        """Save mapping between original rule and custom rule."""
        key = f"{rule_group}:{original_rule}"
        self.mappings[key] = {
            "custom_rule_name": custom_rule_name,
            "ip_list": ip_list,
            "domain_list": domain_list,
            "ip_set_arn": ip_set_arn,
            "regex_set_arn": regex_set_arn,
            "created_at": self._get_timestamp()
        }
        self._save_mappings()
    
    def get_rule_mapping(self, rule_group: str, original_rule: str) -> Optional[Dict]:
        """Get mapping for a specific rule."""
        # Reload mappings to ensure we have the latest data
        self.mappings = self._load_mappings()
        
        key = f"{rule_group}:{original_rule}"
        print(f"DEBUG: RuleMappingStorage.get_rule_mapping() looking for key: '{key}'")
        print(f"DEBUG: Available keys in mappings: {list(self.mappings.keys())}")
        result = self.mappings.get(key)
        print(f"DEBUG: get_rule_mapping result for '{key}': {result is not None}")
        return result
    
    def update_rule_mapping(self, rule_group: str, original_rule: str, 
                           ip_list: List[str], domain_list: List[str],
                           ip_set_arn: str = None, regex_set_arn: str = None) -> None:
        """Update existing rule mapping."""
        key = f"{rule_group}:{original_rule}"
        if key in self.mappings:
            self.mappings[key]["ip_list"] = ip_list
            self.mappings[key]["domain_list"] = domain_list
            if ip_set_arn:
                self.mappings[key]["ip_set_arn"] = ip_set_arn
            if regex_set_arn:
                self.mappings[key]["regex_set_arn"] = regex_set_arn
            self.mappings[key]["updated_at"] = self._get_timestamp()
            self._save_mappings()
    
    def delete_rule_mapping(self, rule_group: str, original_rule: str) -> None:
        """Delete rule mapping."""
        key = f"{rule_group}:{original_rule}"
        if key in self.mappings:
            del self.mappings[key]
            self._save_mappings()
    
    def get_all_mappings(self) -> Dict:
        """Get all mappings."""
        return self.mappings
    
    def _get_timestamp(self) -> str:
        """Get current timestamp."""
        from datetime import datetime
        return datetime.now().isoformat()
