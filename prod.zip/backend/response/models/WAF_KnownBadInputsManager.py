from .BaseManagedRuleGroupManager import BaseManagedRuleGroupManager
from typing import Dict

class WAFKnownBadInputsManager(BaseManagedRuleGroupManager):
    """
    Manages AWS Known Bad Inputs Rule Set managed rule group.
    Note: AWS does not provide individual rule details for this group.
    This manager provides basic functionality for the rule group level.
    """
    
    def __init__(self, wafv2_client=None, scope: str = "REGIONAL", region: str = "us-east-1"):
        """
        Initialize the Known Bad Inputs Manager
        
        Args:
            wafv2_client: Boto3 WAFv2 client
            scope: WAF scope (REGIONAL or CLOUDFRONT)
            region: AWS region
        """
        # AWS Known Bad Inputs Rule Set - no individual rules documented by AWS
        rule_definitions = {
            "KnownBadInputsRuleSet": {
                "name": "KnownBadInputsRuleSet",
                "display_name": "Known Bad Inputs Rule Set",
                "description": "Blocks requests with patterns known to be malicious. Individual rules are not documented by AWS for security reasons.",
                "default_action": "Block",
                "priority": 1
            }
        }
        
        super().__init__(
            wafv2_client=wafv2_client,
            scope=scope,
            region=region,
            rule_group_name="AWS-AWSManagedRulesKnownBadInputsRuleSet",
            rule_definitions=rule_definitions
        )
    
    def get_individual_rules(self, web_acl_name: str = "test-webacl") -> Dict:
        """
        Override to handle the case where individual rules are not documented.
        Returns the rule group as a single unit.
        """
        try:
            web_acl, _ = self._get_web_acl(web_acl_name)
            rule_group = self._find_managed_rule_group(web_acl)
            
            rules_info = {}
            
            if rule_group:
                # Get rule group overrides
                rule_group_overrides = rule_group.get("OverrideAction", {})
                
                # Since individual rules are not documented, treat as single rule group
                rules_info["KnownBadInputsRuleSet"] = {
                    "name": "KnownBadInputsRuleSet",
                    "display_name": "Known Bad Inputs Rule Set",
                    "description": "Blocks requests with patterns known to be malicious. Individual rules are not documented by AWS for security reasons.",
                    "default_action": "Block",
                    "current_action": "Block",  # Default action for the entire rule group
                    "priority": 1,
                    "note": "This rule group contains multiple individual rules, but AWS does not document them for security reasons."
                }
            
            return {
                "rule_group_name": self.rule_group_name,
                "rules": rules_info,
                "web_acl_name": web_acl_name,
                "note": "Individual rules are not documented by AWS for this rule group"
            }
            
        except Exception as e:
            raise RuntimeError(f"Failed to get individual rules: {str(e)}")
