import os
from typing import List, Optional, Tuple

from botocore.exceptions import ClientError


class GeoBlockingManager:
    def __init__(self, wafv2, scope: str = "REGIONAL") -> None:
        self.scope = scope
        self.wafv2 = wafv2

    def _get_web_acl(self, name: str) -> Tuple[dict, str]:
        resp = self.wafv2.list_web_acls(Scope=self.scope)
        for acl in resp.get("WebACLs", []):
            if acl["Name"] == name:
                full = self.wafv2.get_web_acl(Name=name, Scope=self.scope, Id=acl["Id"])
                return full["WebACL"], full["LockToken"]
        raise RuntimeError(f"WebACL '{name}' not found in scope {self.scope}")

    @staticmethod
    def _find_rule_statement(rule: dict) -> Optional[dict]:
        stmt = rule.get("Statement", {})
        if "GeoMatchStatement" in stmt:
            return stmt
        for key in ("NotStatement", "AndStatement", "OrStatement"):
            if key in stmt:
                inner = stmt[key]
                if isinstance(inner, dict) and "Statements" in inner:
                    for s in inner["Statements"]:
                        if "GeoMatchStatement" in s:
                            return s
                elif isinstance(inner, dict) and "Statement" in inner:
                    if "GeoMatchStatement" in inner["Statement"]:
                        return inner["Statement"]
        return None

    @staticmethod
    def _get_geo_countries(geo_stmt: dict) -> List[str]:
        return list(geo_stmt.get("GeoMatchStatement", {}).get("CountryCodes", []))

    def get_countries(self, web_acl_name: str, rule_name: Optional[str] = None) -> List[str]:
        web_acl, _ = self._get_web_acl(web_acl_name)
        for rule in web_acl.get("Rules", []):
            if rule_name and rule["Name"] != rule_name:
                continue
            stmt = self._find_rule_statement(rule)
            if stmt and "GeoMatchStatement" in stmt:
                return self._get_geo_countries(stmt)
        raise RuntimeError("GeoMatch rule not found")

    def _update_countries(self, web_acl_name: str, rule_name: Optional[str], new_codes: List[str]) -> None:
        web_acl, lock = self._get_web_acl(web_acl_name)

        found = False
        for rule in web_acl.get("Rules", []):
            if rule_name and rule["Name"] != rule_name:
                continue
            stmt = self._find_rule_statement(rule)
            if stmt and "GeoMatchStatement" in stmt:
                stmt["GeoMatchStatement"]["CountryCodes"] = new_codes
                # Set action to Count to allow all traffic while monitoring
                # rule["Action"] = {"Count": {}}  # Removed automatic action change
                print(f"DEBUG: Setting rule action to Count for rule: {rule.get('Name', 'unknown')}")
                found = True
                break
        if not found:
            raise RuntimeError("GeoMatch rule not found for update")

        try:
            update_kwargs = {
                "Name": web_acl["Name"],
                "Scope": self.scope,
                "Id": web_acl["Id"],
                "DefaultAction": web_acl["DefaultAction"],
                "Rules": web_acl.get("Rules", []),
                "VisibilityConfig": web_acl["VisibilityConfig"],
                "LockToken": lock,
            }
            desc = web_acl.get("Description")
            if desc:
                update_kwargs["Description"] = desc
            self.wafv2.update_web_acl(**update_kwargs)
        except ClientError as e:
            raise RuntimeError(f"Failed to update WebACL: {e}")

    def add_countries(self, codes: List[str], web_acl_name: str, rule_name: Optional[str] = None) -> List[str]:
        codes = [c.upper() for c in codes]
        existing = self.get_countries(web_acl_name, rule_name)
        new = sorted(set(existing) | set(codes))
        if new != existing:
            self._update_countries(web_acl_name, rule_name, new)
        return new

    def remove_countries(self, codes: List[str], web_acl_name: str, rule_name: Optional[str] = None) -> List[str]:
        codes = [c.upper() for c in codes]
        existing = self.get_countries(web_acl_name, rule_name)
        new = [c for c in existing if c not in codes]
        if new != existing:
            self._update_countries(web_acl_name, rule_name, new)
        return new

    def set_countries(self, codes: List[str], web_acl_name: str, rule_name: Optional[str] = None) -> List[str]:
        codes = [c.upper() for c in codes]
        new = sorted(set(codes))
        self._update_countries(web_acl_name, rule_name, new)
        return new 
    def get_rule_action(self, web_acl_name: str, rule_name: Optional[str] = None) -> str:
        """Get the current action (Block/Allow/Count) of a geo-restrictions rule"""
        web_acl, _ = self._get_web_acl(web_acl_name)
        for rule in web_acl.get("Rules", []):
            if rule_name and rule["Name"] != rule_name:
                continue
            stmt = self._find_rule_statement(rule)
            if stmt and "GeoMatchStatement" in stmt:
                action = rule.get("Action", {})
                if "Block" in action:
                    return "Block"
                elif "Allow" in action:
                    return "Allow"
                elif "Count" in action:
                    return "Count"
                else:
                    return "Unknown"
        raise RuntimeError("GeoMatch rule not found")
