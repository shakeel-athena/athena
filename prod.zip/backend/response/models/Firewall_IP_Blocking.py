import os
import sys
from typing import List, Optional, Tuple, Dict
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parent.parent.parent.parent
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from shared.infrastructure.aws import AWSClientFactory
from botocore.exceptions import ClientError


class FirewallIPBlockingManager:
    def __init__(self, session=None, region_name: str = "us-east-2", rule_group_name: str = "allow-ingress") -> None:
        """
        Initialize manager for updating ALLOW_NET and BLOCK_NET IP sets in Network Firewall rule group.

        Args:
            session: DEPRECATED - ignored, using shared AWS factory
            region_name: AWS region
            rule_group_name: Name of the stateful rule group containing IP sets
        """
        self.region_name = region_name
        self.rule_group_name = rule_group_name
        self.allow_set_name = "ALLOW_NET"
        self.block_set_name = "BLOCK_NET"
        self._rule_group_arn = None

        aws_factory = AWSClientFactory()
        self.nfw_client = aws_factory.get_network_firewall_client(region=region_name)
        self.ec2_client = aws_factory.get_ec2_client(region=region_name)

    def _normalize_cidr(self, ip: str) -> str:
        """Normalize IP to CIDR format."""
        ip = ip.strip()
        if "/" in ip:
            return ip
        if ":" in ip:
            return f"{ip}/128"
        return f"{ip}/32"

    def _get_rule_group(self) -> Tuple[Dict, str]:
        """Get the stateful rule group and its update token."""
        try:
            # Use cached ARN if available
            if not self._rule_group_arn:
                # List rule groups to find our target (only once)
                response = self.nfw_client.list_rule_groups(Type='STATEFUL')
                
                for rg in response.get('RuleGroups', []):
                    if rg['Name'] == self.rule_group_name:
                        self._rule_group_arn = rg['Arn']
                        break
                
                if not self._rule_group_arn:
                    raise RuntimeError(f"Rule group '{self.rule_group_name}' not found")
            
            # Get detailed rule group information using cached ARN
            response = self.nfw_client.describe_rule_group(RuleGroupArn=self._rule_group_arn)
            return response['RuleGroup'], response['UpdateToken']
            
        except ClientError as e:
            raise RuntimeError(f"Failed to get rule group '{self.rule_group_name}': {e}")

    def _get_ip_sets_from_rules(self, rule_group: Dict) -> Dict[str, List[str]]:
        """Get IP sets from Network Firewall rule group variables."""
        ip_sets = {self.allow_set_name: [], self.block_set_name: []}
        
        # Get IP sets from rule group variables
        rule_variables = rule_group.get('RuleVariables', {})
        ip_set_variables = rule_variables.get('IPSets', {})
        
        for set_name in [self.allow_set_name, self.block_set_name]:
            if set_name in ip_set_variables:
                definition = ip_set_variables[set_name].get('Definition', [])
                ip_sets[set_name] = definition
                #print(f"Debug: Found IP set '{set_name}' with {len(definition)} IPs: {definition}")
            else:
                print(f"Debug: IP set '{set_name}' not found in rule group variables")
        
        return ip_sets

    def _update_ip_sets_in_rule_group(self, rule_group: Dict, ip_sets_updates: Dict[str, List[str]]) -> None:
        """Update IP sets in Network Firewall rule group variables."""
        try:
            # Get fresh rule group and update token (required for optimistic locking)
            response = self.nfw_client.describe_rule_group(RuleGroupArn=self._rule_group_arn)
            current_rule_group = response['RuleGroup']
            update_token = response['UpdateToken']
            
            # Update the IP sets in the rule variables
            if 'RuleVariables' not in current_rule_group:
                current_rule_group['RuleVariables'] = {}
            if 'IPSets' not in current_rule_group['RuleVariables']:
                current_rule_group['RuleVariables']['IPSets'] = {}
            
            # Update each IP set
            for set_name, ip_list in ip_sets_updates.items():
                current_rule_group['RuleVariables']['IPSets'][set_name] = {
                    'Definition': ip_list
                }
                #print(f"Debug: Updating IP set '{set_name}' with {len(ip_list)} IPs")
            
            # Update the rule group
            self.nfw_client.update_rule_group(
                RuleGroupArn=self._rule_group_arn,
                RuleGroup=current_rule_group,
                UpdateToken=update_token
            )
            
            # Removed debug print for better performance
            pass
            
        except Exception as e:
            raise RuntimeError(f"Failed to update rule group IP sets: {e}")

    def debug_list_available_resources(self):
        """Debug helper to list available VPC prefix lists and Network Firewall resources."""
        print("=== Debug: Available Resources ===")
        
        # List VPC prefix lists
        print("\n--- VPC Prefix Lists ---")
        try:
            response = self.ec2_client.describe_managed_prefix_lists()
            prefix_lists = response.get('PrefixLists', [])
            for pl in prefix_lists:
                print(f"Name: {pl.get('PrefixListName', 'N/A')}, ID: {pl['PrefixListId']}, State: {pl.get('State')}")
        except Exception as e:
            print(f"Error listing prefix lists: {e}")
        
        # List Network Firewall rule groups
        print("\n--- Network Firewall Rule Groups ---")
        try:
            response = self.nfw_client.list_rule_groups(Type='STATEFUL')
            for rg in response.get('RuleGroups', []):
                print(f"Name: {rg['Name']}, ARN: {rg['Arn']}")
        except Exception as e:
            print(f"Error listing rule groups: {e}")
        
        # Get details of our specific rule group
        print(f"\n--- Rule Group '{self.rule_group_name}' Details ---")
        try:
            rule_group, update_token = self._get_rule_group()
            print(f"Rule group structure keys: {list(rule_group.keys())}")
            
            if 'RulesSource' in rule_group:
                rules_source = rule_group['RulesSource']
                print(f"RulesSource keys: {list(rules_source.keys())}")
                
                # Check for IP set references in Suricata rules
                if 'RulesString' in rules_source:
                    rules_string = rules_source['RulesString']
                    print(f"Rules string preview (first 500 chars): {rules_string[:500]}")
                    # Look for IP set references
                    if 'ALLOW_NET' in rules_string or 'BLOCK_NET' in rules_string:
                        print("Found ALLOW_NET or BLOCK_NET references in rules string!")
                
                # Check variables
                if 'RuleVariables' in rule_group:
                    variables = rule_group['RuleVariables']
                    print(f"Rule variables: {variables}")
                    
        except Exception as e:
            print(f"Error getting rule group details: {e}")
        
        print("=== End Debug Info ===\n")

    def get_allow_ips(self) -> List[str]:
        """Get current IPs in ALLOW_NET set."""
        rule_group, _ = self._get_rule_group()
        ip_sets = self._get_ip_sets_from_rules(rule_group)
        return ip_sets.get(self.allow_set_name, [])

    def get_block_ips(self) -> List[str]:
        """Get current IPs in BLOCK_NET set."""
        rule_group, _ = self._get_rule_group()
        ip_sets = self._get_ip_sets_from_rules(rule_group)
        return ip_sets.get(self.block_set_name, [])

    def add_allow_ips(self, ips: List[str]) -> List[str]:
        """Add multiple IPs to ALLOW_NET set."""
        rule_group, _ = self._get_rule_group()
        ip_sets = self._get_ip_sets_from_rules(rule_group)
        current_ips = set(ip_sets.get(self.allow_set_name, []))
        
        added_count = 0
        for ip in ips:
            cidr = self._normalize_cidr(ip)
            if cidr not in current_ips:
                current_ips.add(cidr)
                added_count += 1
        
        if added_count > 0:
            self._update_ip_sets_in_rule_group(rule_group, {self.allow_set_name: list(current_ips)})
        
        return list(current_ips)

    def remove_allow_ips(self, ips: List[str]) -> List[str]:
        """Remove multiple IPs from ALLOW_NET set."""
        rule_group, _ = self._get_rule_group()
        ip_sets = self._get_ip_sets_from_rules(rule_group)
        current_ips = set(ip_sets.get(self.allow_set_name, []))
        
        removed_count = 0
        for ip in ips:
            cidr = self._normalize_cidr(ip)
            if cidr in current_ips:
                current_ips.remove(cidr)
                removed_count += 1
        
        if removed_count > 0:
            self._update_ip_sets_in_rule_group(rule_group, {self.allow_set_name: list(current_ips)})
        
        return list(current_ips)

    def add_block_ips(self, ips: List[str]) -> List[str]:
        """Add multiple IPs to BLOCK_NET set."""
        rule_group, _ = self._get_rule_group()
        ip_sets = self._get_ip_sets_from_rules(rule_group)
        current_ips = set(ip_sets.get(self.block_set_name, []))
        
        added_count = 0
        for ip in ips:
            cidr = self._normalize_cidr(ip)
            if cidr not in current_ips:
                current_ips.add(cidr)
                added_count += 1
        
        if added_count > 0:
            self._update_ip_sets_in_rule_group(rule_group, {self.block_set_name: list(current_ips)})
        
        return list(current_ips)

    def remove_block_ips(self, ips: List[str]) -> List[str]:
        """Remove multiple IPs from BLOCK_NET set."""
        rule_group, _ = self._get_rule_group()
        ip_sets = self._get_ip_sets_from_rules(rule_group)
        current_ips = set(ip_sets.get(self.block_set_name, []))
        
        removed_count = 0
        for ip in ips:
            cidr = self._normalize_cidr(ip)
            if cidr in current_ips:
                current_ips.remove(cidr)
                removed_count += 1
        
        if removed_count > 0:
            self._update_ip_sets_in_rule_group(rule_group, {self.block_set_name: list(current_ips)})
        
        return list(current_ips)

    def get_all_ips(self) -> Dict[str, List[str]]:
        """Get all IPs from both ALLOW_NET and BLOCK_NET sets."""
        return {
            "allow": self.get_allow_ips(),
            "block": self.get_block_ips(),
        }

    def transfer_ip(self, ip: str, from_list: str, to_list: str) -> Dict[str, List[str]]:
        """Transfer an IP from one list to another atomically.
        
        Args:
            ip: IP address to transfer
            from_list: Source list ('allow' or 'block')
            to_list: Destination list ('allow' or 'block')
            
        Returns:
            Dict with updated allow and block lists
            
        Raises:
            ValueError: If IP not found in source list or invalid list names
        """
        if from_list not in ['allow', 'block'] or to_list not in ['allow', 'block']:
            raise ValueError("List names must be 'allow' or 'block'")
        
        if from_list == to_list:
            raise ValueError("Source and destination lists cannot be the same")
        
        # Normalize IP
        cidr = self._normalize_cidr(ip)
        
        # Get current rule group and IP sets
        rule_group, _ = self._get_rule_group()
        ip_sets = self._get_ip_sets_from_rules(rule_group)
        
        # Get current IPs from both sets
        allow_ips = set(ip_sets.get(self.allow_set_name, []))
        block_ips = set(ip_sets.get(self.block_set_name, []))
        
        # Validate IP exists in source list
        if from_list == 'allow' and cidr not in allow_ips:
            raise ValueError(f"IP {cidr} not found in allow list")
        elif from_list == 'block' and cidr not in block_ips:
            raise ValueError(f"IP {cidr} not found in block list")
        
        # Perform the transfer
        if from_list == 'allow' and to_list == 'block':
            allow_ips.remove(cidr)
            block_ips.add(cidr)
        elif from_list == 'block' and to_list == 'allow':
            block_ips.remove(cidr)
            allow_ips.add(cidr)
        
        # Update both IP sets atomically
        updated_sets = {
            self.allow_set_name: list(allow_ips),
            self.block_set_name: list(block_ips)
        }
        
        self._update_ip_sets_in_rule_group(rule_group, updated_sets)
        
        return {
            "allow": list(allow_ips),
            "block": list(block_ips)
        }
