from .BaseManagedRuleGroupManager import BaseManagedRuleGroupManager

class WAFUnixVulnManager(BaseManagedRuleGroupManager):
    """
    Manages AWS Unix Rule Set managed rule group.
    Contains 3 individual rules for POSIX/Unix-specific vulnerability protection.
    """
    
    def __init__(self, wafv2_client=None, scope: str = "REGIONAL", region: str = "us-east-1"):
        """
        Initialize the Unix Vulnerability Protection Manager
        
        Args:
            wafv2_client: Boto3 WAFv2 client
            scope: WAF scope (REGIONAL or CLOUDFRONT)
            region: AWS region
        """
        # AWS Unix Rule Set individual rules with exact names from AWS documentation
        rule_definitions = {
            "UNIXShellCommandsVariables_QUERYSTRING": {
                "name": "UNIXShellCommandsVariables_QUERYSTRING",
                "display_name": "Unix Shell Commands in Query String",
                "description": "Inspects the values of the query string for attempts to exploit command injection, LFI, and path traversal vulnerabilities in web applications that run on Unix systems. Examples include patterns like echo $HOME and echo $PATH",
                "default_action": "Block",
                "priority": 1
            },
            "UNIXShellCommandsVariables_BODY": {
                "name": "UNIXShellCommandsVariables_BODY",
                "display_name": "Unix Shell Commands in Request Body",
                "description": "Inspects the request body for attempts to exploit command injection, LFI, and path traversal vulnerabilities in web applications that run on Unix systems. Examples include patterns like echo $HOME and echo $PATH",
                "default_action": "Block",
                "priority": 2
            },
            "UNIXShellCommandsVariables_HEADER": {
                "name": "UNIXShellCommandsVariables_HEADER",
                "display_name": "Unix Shell Commands in Headers",
                "description": "Inspects all request headers for attempts to exploit command injection, LFI, and path traversal vulnerabilities in web applications that run on Unix systems. Examples include patterns like echo $HOME and echo $PATH",
                "default_action": "Block",
                "priority": 3
            }
        }
        
        super().__init__(
            wafv2_client=wafv2_client,
            scope=scope,
            region=region,
            rule_group_name="AWS-AWSManagedRulesUnixRuleSet",
            rule_definitions=rule_definitions
        )
