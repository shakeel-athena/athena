from .BaseManagedRuleGroupManager import BaseManagedRuleGroupManager

class WAFAnonymousIPManager(BaseManagedRuleGroupManager):
    """
    Manages AWS Anonymous IP List managed rule group.
    Contains 2 individual rules for blocking anonymous IP addresses.
    """
    
    def __init__(self, wafv2_client=None, scope: str = "REGIONAL", region: str = "us-east-1"):
        """
        Initialize the Anonymous IP Protection Manager
        
        Args:
            wafv2_client: Boto3 WAFv2 client
            scope: WAF scope (REGIONAL or CLOUDFRONT)
            region: AWS region
        """
        # AWS Anonymous IP List individual rules with exact names from AWS documentation
        rule_definitions = {
            "AnonymousIPList": {
                "name": "AnonymousIPList",
                "display_name": "Anonymous IP List",
                "description": "Inspects for a list of IP addresses of sources known to anonymize client information, like TOR nodes, temporary proxies, and other masking services",
                "default_action": "Block",
                "priority": 1
            },
            "HostingProviderIPList": {
                "name": "HostingProviderIPList",
                "display_name": "Hosting Provider IP List",
                "description": "Inspects for a list of IP addresses from web hosting and cloud providers, which are less likely to source end-user traffic",
                "default_action": "Block",
                "priority": 2
            }
        }
        
        super().__init__(
            wafv2_client=wafv2_client,
            scope=scope,
            region=region,
            rule_group_name="AWS-AWSManagedRulesAnonymousIpList",
            rule_definitions=rule_definitions
        )
