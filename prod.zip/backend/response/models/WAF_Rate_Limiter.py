import os
from typing import Optional, Tuple, Dict
from botocore.exceptions import ClientError
from dotenv import load_dotenv

load_dotenv(dotenv_path=os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))), '.env'))

class WAFRateLimiterManager:
    def __init__(self, wafv2, scope: str = "REGIONAL") -> None:
        self.scope = scope
        self.wafv2 = wafv2
        self.rule_name = os.getenv("WAF_Rate_Limiter")

    def _get_web_acl(self, name: str) -> Tuple[dict, str]:
        resp = self.wafv2.list_web_acls(Scope=self.scope)
        for acl in resp.get("WebACLs", []):
            if acl["Name"] == name:
                full = self.wafv2.get_web_acl(Name=name, Scope=self.scope, Id=acl["Id"])
                return full["WebACL"], full["LockToken"]
        raise RuntimeError(f"WebACL '{name}' not found in scope {self.scope}")

    @staticmethod
    def _find_rate_statement(rule: dict) -> Optional[dict]:
        stmt = rule.get("Statement", {})
        if "RateBasedStatement" in stmt:
            return stmt
        for key in ("NotStatement", "AndStatement", "OrStatement"):
            if key in stmt:
                inner = stmt[key]
                # Nested as list of statements
                if isinstance(inner, dict) and "Statements" in inner:
                    for s in inner["Statements"]:
                        if "RateBasedStatement" in s:
                            return s
                # Single nested Statement
                elif isinstance(inner, dict) and "Statement" in inner:
                    if "RateBasedStatement" in inner["Statement"]:
                        return inner["Statement"]
        return None

    def get_current_settings(self, web_acl_name: str) -> Dict[str, Optional[int]]:
        web_acl, _ = self._get_web_acl(web_acl_name)
        for rule in web_acl.get("Rules", []):
            if rule["Name"] != self.rule_name:
                continue
            stmt = self._find_rate_statement(rule)
            if stmt and "RateBasedStatement" in stmt:
                rbr = stmt["RateBasedStatement"]
                return {
                    "Limit": rbr.get("Limit"),
                    "EvaluationWindowSec": rbr.get("EvaluationWindowSec"),
                }
        raise RuntimeError("Rate-based rule not found")

    def _update_settings(self, web_acl_name:  str, new_limit: Optional[int], new_window_sec: Optional[int]) -> Dict[str, Optional[int]]:
        web_acl, lock = self._get_web_acl(web_acl_name)

        found = False
        for rule in web_acl.get("Rules", []):
            if rule["Name"] != self.rule_name:
                continue
            stmt = self._find_rate_statement(rule)
            if stmt and "RateBasedStatement" in stmt:
                rate_stmt = stmt["RateBasedStatement"]
                if new_limit is not None:
                    rate_stmt["Limit"] = int(new_limit)
                if new_window_sec is not None:
                    rate_stmt["EvaluationWindowSec"] = int(new_window_sec)
                found = True
                break
        if not found:
            raise RuntimeError("Rate-based rule not found for update")

        try:
            update_kwargs = {
                "Name": web_acl["Name"],
                "Scope": self.scope,
                "Id": web_acl["Id"],
                "DefaultAction": web_acl["DefaultAction"],
                "Rules": web_acl.get("Rules", []),
                "VisibilityConfig": web_acl["VisibilityConfig"],
                "LockToken": lock,
            }
            desc = web_acl.get("Description")
            if desc:
                update_kwargs["Description"] = desc
            self.wafv2.update_web_acl(**update_kwargs)
        except ClientError as e:
            raise RuntimeError(f"Failed to update WebACL: {e}")

        # Return the updated settings for convenience
        return self.get_current_settings(web_acl_name)

    def set_limit(self, web_acl_name: str, limit: int) -> Dict[str, Optional[int]]:
        if limit < 10:
            raise ValueError("Limit must be >= 10")
        return self._update_settings(web_acl_name, new_limit=limit, new_window_sec=None)

    def set_window(self, web_acl_name: str, window_sec: int) -> Dict[str, Optional[int]]:
        if window_sec not in (60, 120, 300, 600):
            raise ValueError("EvaluationWindowSec must be one of 60, 120, 300, 600")
        return self._update_settings(web_acl_name, new_limit=None, new_window_sec=window_sec)

    def set_limit_and_window(self, web_acl_name: str, limit: int, window_sec: int) -> Dict[str, Optional[int]]:
        if limit < 10:
            raise ValueError("Limit must be >= 10")
        if window_sec not in (60, 120, 300, 600):
            raise ValueError("EvaluationWindowSec must be one of 60, 120, 300, 600")
        return self._update_settings(web_acl_name, new_limit=limit, new_window_sec=window_sec)
