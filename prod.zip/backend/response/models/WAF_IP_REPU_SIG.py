import boto3
import json
from typing import Dict, List, Tuple, Optional
import os


from .BaseManagedRuleGroupManager import BaseManagedRuleGroupManager
class WAFIPReputationManager(BaseManagedRuleGroupManager):
    """
    Manages WAF IP Reputation rules for AWS managed IP reputation lists.
    Handles the 3 main AWS managed IP reputation rule groups:
    - AWSManagedIPReputationList
    - AWSManagedReconnaissanceList  
    - AWSManagedIPDDoSList
    """
    
    def __init__(self, wafv2_client=None, scope: str = "REGIONAL", region: str = "us-east-1"):
        """Initialize the WAF IP Reputation Manager"""
        # AWS Managed IP Reputation Rule Groups
        self.IP_REPUTATION_RULES = {
            "AWSManagedIPReputationList": {
                "name": "AWSManagedIPReputationList",
                "display_name": "AWS Managed IP Reputation List",
                "description": "Blocks requests from IP addresses that are known to be malicious",
                "default_action": "Block",
                "priority": 1
            },
            "AWSManagedReconnaissanceList": {
                "name": "AWSManagedReconnaissanceList", 
                "display_name": "AWS Managed Reconnaissance List",
                "description": "Blocks requests from IP addresses that are known to perform reconnaissance",
                "default_action": "Block",
                "priority": 2
            },
            "AWSManagedIPDDoSList": {
                "name": "AWSManagedIPDDoSList",
                "display_name": "AWS Managed IP DDoS List", 
                "description": "Blocks requests from IP addresses that are known to perform DDoS attacks",
                "default_action": "Count",
                "priority": 3
            }
        }
        
        # Call parent constructor with required parameters
        super().__init__(
            wafv2_client=wafv2_client, 
            scope=scope, 
            region=region, 
            rule_group_name="AWS-AWSManagedRulesAmazonIpReputationList", 
            rule_definitions=self.IP_REPUTATION_RULES
        )

    def _get_web_acl(self, web_acl_name: str) -> Tuple[Dict, str]:
        """Get Web ACL details and lock token"""
        try:
            # First, get the Web ACL ID
            web_acls = self.wafv2_client.list_web_acls(Scope=self.scope)
            web_acl_id = None
            
            for acl in web_acls.get('WebACLs', []):
                if acl['Name'] == web_acl_name:
                    web_acl_id = acl['Id']
                    break
            
            if not web_acl_id:
                raise ValueError(f"Web ACL '{web_acl_name}' not found")
            
            # Get the full Web ACL details
            response = self.wafv2_client.get_web_acl(
                Name=web_acl_name,
                Scope=self.scope,
                Id=web_acl_id
            )
            return response['WebACL'], response['LockToken']
        except Exception as e:
            raise RuntimeError(f"Failed to get Web ACL '{web_acl_name}': {str(e)}")

    def _find_ip_reputation_rule_group(self, web_acl: Dict) -> Optional[Dict]:
        """Find the AWS Managed IP Reputation rule group in the Web ACL"""
        for rule in web_acl.get("Rules", []):
            if rule["Name"] == "AWS-AWSManagedRulesAmazonIpReputationList":
                return rule
        return None

    def get_ip_reputation_rules(self, web_acl_name: str = "test-webacl") -> Dict:
        """
        Get all IP reputation rules and their current actions
        
        Returns:
            Dict containing rule information and current actions
        """
        try:
            web_acl, _ = self._get_web_acl(web_acl_name)
            rule_group = self._find_ip_reputation_rule_group(web_acl)
            
            rules_info = {}
            
            if rule_group:
                # Get rule group overrides
                rule_group_overrides = rule_group.get("OverrideAction", {})
                individual_overrides = rule_group.get("Statement", {}).get("ManagedRuleGroupStatement", {}).get("RuleActionOverrides", [])
                
                # Create a map of individual rule overrides
                print(f"DEBUG: Individual overrides found: {individual_overrides}")
                override_map = {}
                for override in individual_overrides:
                    override_map[override["Name"]] = override["ActionToUse"]
                
                # Process each IP reputation rule
                for rule_key, rule_info in self.IP_REPUTATION_RULES.items():
                    rule_name = rule_info["name"]
                    
                    # Check for individual rule override first
                    if rule_name in override_map:
                        action = override_map[rule_name]
                        if "Block" in action:
                            current_action = "Block"
                        elif "Allow" in action:
                            current_action = "Allow"
                        elif "Count" in action:
                            current_action = "Count"
                        else:
                            current_action = "Unknown"
                    else:
                        # Use rule group default action
                        if "None" in rule_group_overrides:
                            current_action = rule_info["default_action"]  # Use default from rule group
                        else:
                            current_action = "Unknown"
                    
                    rules_info[rule_key] = {
                        "name": rule_name,
                        "display_name": rule_info["display_name"],
                        "description": rule_info["description"],
                        "default_action": rule_info["default_action"],
                        "current_action": current_action,
                        "priority": rule_info["priority"],
                        "enabled": True
                    }
            else:
                # Rule group not found, return default info
                for rule_key, rule_info in self.IP_REPUTATION_RULES.items():
                    rules_info[rule_key] = {
                        "name": rule_info["name"],
                        "display_name": rule_info["display_name"],
                        "description": rule_info["description"],
                        "default_action": rule_info["default_action"],
                        "current_action": "Not Found",
                        "priority": rule_info["priority"],
                        "enabled": False
                    }
            
            return {
                "rules": rules_info,
                "total_rules": len(rules_info),
                "web_acl_name": web_acl_name
            }
        except Exception as e:
            raise RuntimeError(f"Failed to get IP reputation rules: {str(e)}")

    def update_rule_action(self, web_acl_name: str, rule_name: str, new_action: str) -> Dict:
        """
        Update the action of a specific IP reputation rule
        
        Args:
            web_acl_name: Name of the Web ACL
            rule_name: Name of the rule to update
            new_action: New action (Block, Allow, Count)
            
        Returns:
            Dict with success status and message
        """
        try:
            web_acl, lock_token = self._get_web_acl(web_acl_name)
            rule_group = self._find_ip_reputation_rule_group(web_acl)
            
            if not rule_group:
                raise ValueError("IP Reputation rule group not found")
            
            # Get existing rule action overrides
            existing_overrides = rule_group.get("Statement", {}).get("ManagedRuleGroupStatement", {}).get("RuleActionOverrides", [])
            
            # Remove existing override for this rule if it exists
            existing_overrides = [override for override in existing_overrides if override["Name"] != rule_name]
            
            # Add new override
            new_override = {
                "Name": rule_name,
                "ActionToUse": {new_action: {}}
            }
            existing_overrides.append(new_override)
            
            # Update the rule group
            # Update the ManagedRuleGroupStatement
            managed_stmt = rule_group["Statement"]["ManagedRuleGroupStatement"]
            managed_stmt["RuleActionOverrides"] = existing_overrides
            
            # Update the Web ACL
            self.wafv2_client.update_web_acl(
                Name=web_acl_name,
                Scope=self.scope,
                Id=web_acl["Id"],
                DefaultAction=web_acl["DefaultAction"],
                Rules=web_acl["Rules"],
                LockToken=lock_token,
                VisibilityConfig=web_acl["VisibilityConfig"],
            )
            
            return {
                "success": True,
                "message": f"Rule {rule_name} action updated to {new_action}",
                "rule_name": rule_name,
                "new_action": new_action
            }
            
        except Exception as e:
            raise RuntimeError(f"Failed to update rule action: {str(e)}")

    def reset_rule_to_default(self, web_acl_name: str, rule_name: str) -> Dict:
        """
        Reset a specific rule's action to its default (Block)
        
        Args:
            web_acl_name: Name of the Web ACL
            rule_name: Name of the rule to reset
            
        Returns:
            Dict with success status and message
        """
        try:
            web_acl, lock_token = self._get_web_acl(web_acl_name)
            rule_group = self._find_ip_reputation_rule_group(web_acl)
            
            if not rule_group:
                raise ValueError("IP Reputation rule group not found")
            
            # Get existing rule action overrides
            existing_overrides = rule_group.get("Statement", {}).get("ManagedRuleGroupStatement", {}).get("RuleActionOverrides", [])
            
            # Remove override for this rule
            existing_overrides = [override for override in existing_overrides if override["Name"] != rule_name]
            
            # Update the rule group
            # Update the ManagedRuleGroupStatement
            managed_stmt = rule_group["Statement"]["ManagedRuleGroupStatement"]
            managed_stmt["RuleActionOverrides"] = existing_overrides
            
            # Update the Web ACL
            self.wafv2_client.update_web_acl(
                Name=web_acl_name,
                Scope=self.scope,
                Id=web_acl["Id"],
                DefaultAction=web_acl["DefaultAction"],
                Rules=web_acl["Rules"],
                LockToken=lock_token,
                VisibilityConfig=web_acl["VisibilityConfig"],
            )
            
            return {
                "success": True,
                "message": f"Rule {rule_name} reset to default action",
                "rule_name": rule_name,
                "default_action": "Block"
            }
            
        except Exception as e:
            raise RuntimeError(f"Failed to reset rule: {str(e)}")
