import boto3
import json
import os
from typing import Dict, List, Tuple, Optional
from botocore.exceptions import ClientError
from .RuleMappingStorage import RuleMappingStorage
import time

import re

class BaseManagedRuleGroupManager:
    """
    Base class for managing AWS managed rule groups with individual rule overrides.
    Provides common functionality for:
    - Getting individual rules within a managed rule group
    - Updating rule actions (Block/Allow/Count)
    - Resetting rules to default actions
    - Creating allow list custom rules with multiple IPs/domains
    """

    def __init__(self, wafv2_client=None, scope: str = "REGIONAL", region: str = "us-east-1",
                 rule_group_name: str = "", rule_definitions: Dict = None):
        """
        Initialize the base managed rule group manager

        Args:
            wafv2_client: Boto3 WAFv2 client
            scope: WAF scope (REGIONAL or CLOUDFRONT)
            region: AWS region
            rule_group_name: Name of the managed rule group
            rule_definitions: Dictionary defining individual rules within the group
        """
        self.region = region
        self.scope = scope
        self.rule_group_name = rule_group_name
        self.rule_definitions = rule_definitions or {}

        if wafv2_client:
            self.wafv2_client = wafv2_client
        else:
            self.wafv2_client = boto3.client('wafv2', region_name=region)

        # Initialize rule mapping storage
        self.rule_mapping_storage = RuleMappingStorage()

    def _get_web_acl(self, web_acl_name: str = "test-webacl") -> Tuple[Dict, str]:
        """
        Get Web ACL and its lock token

        Args:
            web_acl_name: Name of the Web ACL

        Returns:
            Tuple of (web_acl_dict, lock_token)
        """
        try:
            # First, list Web ACLs to get the ID
            response = self.wafv2_client.list_web_acls(
                Scope=self.scope,
                Limit=100
            )

            web_acl_id = None
            for web_acl in response.get('WebACLs', []):
                if web_acl['Name'] == web_acl_name:
                    web_acl_id = web_acl['Id']
                    break

            if not web_acl_id:
                raise ValueError(f"Web ACL '{web_acl_name}' not found")

            # Get the Web ACL details
            response = self.wafv2_client.get_web_acl(
                Name=web_acl_name,
                Scope=self.scope,
                Id=web_acl_id
            )

            return response['WebACL'], response['LockToken']

        except ClientError as e:
            raise RuntimeError(f"Failed to get Web ACL: {e}")

    def _find_managed_rule_group(self, web_acl: Dict) -> Optional[Dict]:
        """
        Find the managed rule group in the Web ACL

        Args:
            web_acl: Web ACL dictionary

        Returns:
            Rule group dictionary or None if not found
        """
        for rule in web_acl.get("Rules", []):
            if rule.get("Name") == self.rule_group_name:
                return rule
        return None

    def get_individual_rules(self, web_acl_name: str = "test-webacl") -> Dict:
        """
        Get all individual rules within the managed rule group and their current actions

        Args:
            web_acl_name: Name of the Web ACL

        Returns:
            Dictionary containing rule information and current actions
        """
        try:
            web_acl, _ = self._get_web_acl(web_acl_name)
            rule_group = self._find_managed_rule_group(web_acl)

            rules_info = {}

            if rule_group:
                # Get rule group overrides
                rule_group_overrides = rule_group.get("OverrideAction", {})
                individual_overrides = rule_group.get("Statement", {}).get("ManagedRuleGroupStatement", {}).get("RuleActionOverrides", [])

                # Create a map of individual rule overrides
                print(f"DEBUG: Individual overrides found: {individual_overrides}")
                override_map = {}
                for override in individual_overrides:
                    override_map[override["Name"]] = override["ActionToUse"]

                # Process each rule definition
                for rule_name, rule_info in self.rule_definitions.items():
                    current_action = rule_info.get("default_action", "Block")

                    # Check if there's an individual override
                    if rule_name in override_map:
                        current_action = list(override_map[rule_name].keys())[0]

                    rules_info[rule_name] = {
                        "name": rule_name,
                        "display_name": rule_info.get("display_name", rule_name),
                        "description": rule_info.get("description", ""),
                        "default_action": rule_info.get("default_action", "Block"),
                        "current_action": current_action,
                        "priority": rule_info.get("priority", 0)
                    }

            return {
                "rule_group_name": self.rule_group_name,
                "rules": rules_info,
                "web_acl_name": web_acl_name
            }

        except Exception as e:
            raise RuntimeError(f"Failed to get individual rules: {str(e)}")

    def update_rule_action(self, web_acl_name: str, rule_name: str, new_action: str) -> Dict:
        """
        Update the action of a specific rule within the managed rule group

        Args:
            web_acl_name: Name of the Web ACL
            rule_name: Name of the rule to update
            new_action: New action (Block, Allow, Count)

        Returns:
            Dict with success status and message
        """
        try:
            web_acl, lock_token = self._get_web_acl(web_acl_name)
            rule_group = self._find_managed_rule_group(web_acl)

            if not rule_group:
                raise ValueError(f"Managed rule group '{self.rule_group_name}' not found")

            # Get existing rule action overrides
            existing_overrides = rule_group.get("Statement", {}).get("ManagedRuleGroupStatement", {}).get("RuleActionOverrides", [])

            # Remove existing override for this rule if it exists
            existing_overrides = [override for override in existing_overrides if override["Name"] != rule_name]

            # Add new override
            new_override = {
                "Name": rule_name,
                "ActionToUse": {new_action: {}}
            }
            existing_overrides.append(new_override)

            # Update the rule group
            managed_stmt = rule_group["Statement"]["ManagedRuleGroupStatement"]
            managed_stmt["RuleActionOverrides"] = existing_overrides

            # Update the Web ACL
            self.wafv2_client.update_web_acl(
                Name=web_acl_name,
                Scope=self.scope,
                Id=web_acl["Id"],
                DefaultAction=web_acl["DefaultAction"],
                Rules=web_acl["Rules"],
                LockToken=lock_token,
                VisibilityConfig=web_acl["VisibilityConfig"],
            )

            return {
                "success": True,
                "message": f"Rule '{rule_name}' action updated to '{new_action}'",
                "rule_name": rule_name,
                "new_action": new_action
            }

        except Exception as e:
            return {
                "success": False,
                "message": f"Failed to update rule action: {str(e)}",
                "rule_name": rule_name,
                "new_action": new_action
            }

    def reset_rule_to_default(self, web_acl_name: str, rule_name: str) -> Dict:
        """
        Reset a rule to its default action by removing any overrides

        Args:
            web_acl_name: Name of the Web ACL
            rule_name: Name of the rule to reset

        Returns:
            Dict with success status and message
        """
        try:
            web_acl, lock_token = self._get_web_acl(web_acl_name)
            rule_group = self._find_managed_rule_group(web_acl)

            if not rule_group:
                raise ValueError(f"Managed rule group '{self.rule_group_name}' not found")

            # Get existing rule action overrides
            existing_overrides = rule_group.get("Statement", {}).get("ManagedRuleGroupStatement", {}).get("RuleActionOverrides", [])

            # Remove override for this rule
            existing_overrides = [override for override in existing_overrides if override["Name"] != rule_name]

            # Update the rule group
            managed_stmt = rule_group["Statement"]["ManagedRuleGroupStatement"]
            managed_stmt["RuleActionOverrides"] = existing_overrides

            # Update the Web ACL
            self.wafv2_client.update_web_acl(
                Name=web_acl_name,
                Scope=self.scope,
                Id=web_acl["Id"],
                DefaultAction=web_acl["DefaultAction"],
                Rules=web_acl["Rules"],
                LockToken=lock_token,
                VisibilityConfig=web_acl["VisibilityConfig"],
            )

            # Get default action from rule definitions
            default_action = self.rule_definitions.get(rule_name, {}).get("default_action", "Block")

            return {
                "success": True,
                "message": f"Rule '{rule_name}' reset to default action '{default_action}'",
                "rule_name": rule_name,
                "default_action": default_action
            }

        except Exception as e:
            return {
                "success": False,
                "message": f"Failed to reset rule: {str(e)}",
                "rule_name": rule_name
            }

    def _get_next_priority(self, web_acl: Dict) -> int:
        """
        Get the next available priority for a new rule

        Args:
            web_acl: Web ACL dictionary

        Returns:
            Next available priority number
        """
        existing_priorities = [rule.get("Priority", 0) for rule in web_acl.get("Rules", [])]
        return max(existing_priorities, default=0) + 1

    def _get_custom_rule_priority(self, web_acl: Dict, original_rule_name: str) -> int:
        """
        Get the priority for a custom rule that should be placed immediately after its corresponding AWS managed rule
        Aggressively shifts all subsequent rules (both AWS managed and custom) to make space

        Args:
            web_acl: Web ACL dictionary
            original_rule_name: Name of the original AWS managed rule

        Returns:
            Priority number for the custom rule
        """
        # Find the AWS managed rule group that contains the original rule
        print(f"DEBUG: Looking for managed rule group: {self.rule_group_name}")
        managed_rule_group = self._find_managed_rule_group(web_acl)
        if not managed_rule_group:
            print(f"DEBUG: Managed rule group '{self.rule_group_name}' not found, using end priority")
            # Fallback to end if managed rule group not found
            existing_priorities = [rule.get("Priority", 0) for rule in web_acl.get("Rules", [])]
            return max(existing_priorities, default=0) + 1

        # Get the priority of the managed rule group
        managed_rule_priority = managed_rule_group.get("Priority", 0)
        print(f"DEBUG: Found managed rule group '{self.rule_group_name}' at priority {managed_rule_priority}")

        # The custom rule should be placed immediately after the managed rule group
        custom_rule_priority = managed_rule_priority + 1
        print(f"DEBUG: Target custom rule priority: {custom_rule_priority} (immediately after {self.rule_group_name})")

        # Find all rules that have priorities >= custom_rule_priority (these need to be shifted)
        all_rules = web_acl.get("Rules", [])
        rules_to_shift = []

        for rule in all_rules:
            rule_priority = rule.get("Priority", 0)
            rule_name = rule.get("Name", "")

            if rule_priority >= custom_rule_priority:
                rules_to_shift.append((rule_name, rule_priority))

        if not rules_to_shift:
            print(f"DEBUG: No rules need shifting, using priority {custom_rule_priority}")
            return custom_rule_priority

        # Sort rules by priority in descending order (highest priority first)
        # This ensures we update from the end to avoid conflicts
        rules_to_shift.sort(key=lambda x: x[1], reverse=True)
        print(f"DEBUG: Need to shift {len(rules_to_shift)} rules (from highest to lowest): {rules_to_shift}")

        # Update priorities of all rules (both AWS managed and custom) starting from highest priority
        # This avoids conflicts since we're always moving to an unoccupied priority
        successful_shifts = 0

        # Individual rule-by-rule approach with enhanced retry logic
        print(f"DEBUG: Starting individual priority shifts for {len(rules_to_shift)} rules")

        for i, (rule_name, old_priority) in enumerate(rules_to_shift):
            new_priority = old_priority + 1

            print(f"DEBUG: Shifting rule '{rule_name}' priority from {old_priority} to {new_priority} ({i+1}/{len(rules_to_shift)})")

            # Add small delay between updates to reduce AWS API conflicts
            if i > 0:
                import time
                print(f"DEBUG: Adding 2 second delay between rule updates...")
                time.sleep(2)

            success = self._update_single_rule_priority(web_acl, rule_name, new_priority)
            if success:
                successful_shifts += 1
                print(f"DEBUG: Successfully shifted '{rule_name}' to priority {new_priority}")
                # Update the web_acl dictionary to reflect the change for next iteration
                for rule in web_acl["Rules"]:
                    if rule["Name"] == rule_name:
                        rule["Priority"] = new_priority
                        break
            else:
                print(f"ERROR: Failed to shift '{rule_name}' priority from {old_priority} to {new_priority}")
                print(f"ERROR: Stopping priority shifts after {successful_shifts} successful updates")
                break

        if successful_shifts == len(rules_to_shift):
            print(f"DEBUG: All {successful_shifts} priority shifts completed successfully!")
            return custom_rule_priority
        else:
            print(f"ERROR: Only {successful_shifts}/{len(rules_to_shift)} priority shifts succeeded")
            print(f"ERROR: Falling back to end priority due to priority shift failures")
            return self._get_next_priority(web_acl)

    def _update_single_rule_priority(self, web_acl: Dict, rule_name: str, new_priority: int) -> bool:
        """
        Update the priority of a single rule with robust retry logic

        Args:
            web_acl: Web ACL dictionary
            rule_name: Name of the rule to update
            new_priority: New priority value

        Returns:
            True if successful, False otherwise
        """
        max_retries = 6  # Increased from 5 to 6
        base_wait_time = 4  # Increased base wait time to 4 seconds

        for attempt in range(max_retries):
            try:
                # Always get fresh Web ACL data with latest LockToken
                print(f"DEBUG: Attempt {attempt + 1}/{max_retries} - Getting fresh Web ACL data for rule '{rule_name}'")
                web_acl_response = self.wafv2_client.get_web_acl(
                    Scope=self.scope,
                    Id=web_acl["Id"],
                    Name=web_acl["Name"]
                )
                current_web_acl = web_acl_response["WebACL"]
                current_lock_token = web_acl_response["LockToken"]  # FIXED: LockToken is at response level
                print(f"DEBUG: Got fresh LockToken: {current_lock_token[:16]}...")

                # Find the rule and update its priority
                updated_rules = current_web_acl.get("Rules", []).copy()
                rule_found = False
                old_priority = None

                for rule in updated_rules:
                    if rule.get("Name") == rule_name:
                        old_priority = rule.get("Priority")
                        rule["Priority"] = new_priority
                        rule_found = True
                        print(f"DEBUG: Found rule '{rule_name}' with priority {old_priority}, updating to {new_priority}")
                        break

                if not rule_found:
                    print(f"ERROR: Rule '{rule_name}' not found in Web ACL")
                    return False

                # Handle Description field properly (cannot be empty)
                description = current_web_acl.get("Description", "")
                update_description = description if description else "WAF rules with priority management"

                # Perform the update
                print(f"DEBUG: Updating Web ACL with rule '{rule_name}' priority change {old_priority} -> {new_priority}")
                update_response = self.wafv2_client.update_web_acl(
                    Scope=self.scope,
                    Id=current_web_acl["Id"],
                    Name=current_web_acl["Name"],
                    DefaultAction=current_web_acl["DefaultAction"],
                    Rules=updated_rules,
                    Description=update_description,  # FIXED: Ensure not empty
                    VisibilityConfig=current_web_acl["VisibilityConfig"],
                    LockToken=current_lock_token  # FIXED: Use response-level LockToken
                )

                print(f"DEBUG: Successfully updated rule '{rule_name}' priority to {new_priority}")
                return True

            except ClientError as e:
                error_code = e.response.get('Error', {}).get('Code', 'Unknown')
                error_msg = str(e)

                print(f"ERROR: Attempt {attempt + 1}/{max_retries} failed for rule '{rule_name}': {error_code}")
                print(f"ERROR: Full ClientError: {error_msg}")

                if 'LockToken' in error_msg:
                    wait_time = base_wait_time * (2 ** attempt)  # Exponential backoff: 4, 8, 16, 32, 64, 128 seconds
                    print(f"ERROR: LockToken conflict detected in ClientError, waiting {wait_time} seconds before retry...")
                    import time
                    time.sleep(wait_time)
                else:
                    print(f"ERROR: Non-LockToken ClientError, not retrying: {error_code}")
                    return False

            except Exception as e:
                error_msg = str(e)
                print(f"ERROR: Attempt {attempt + 1}/{max_retries} failed for rule '{rule_name}': {error_msg}")

                # Check if this is a LockToken error in any exception type
                if 'LockToken' in error_msg:
                    wait_time = base_wait_time * (2 ** attempt)  # Exponential backoff: 4, 8, 16, 32, 64, 128 seconds
                    print(f"ERROR: LockToken conflict detected in generic exception, waiting {wait_time} seconds before retry...")
                    import time
                    time.sleep(wait_time)
                else:
                    print(f"ERROR: Non-LockToken error, not retrying: {error_msg}")
                    return False

        print(f"ERROR: All {max_retries} attempts failed for rule '{rule_name}'")
        return False

    def _create_ip_set(self, ip_set_name: str, ip_list: List[str]) -> str:
        try:
            print(f"DEBUG: Looking for IP set: {ip_set_name}")
            print(f"DEBUG: IP list to create/update: {ip_list}")

            # First try to find existing IP set
            try:
                print(f"DEBUG: Calling list_ip_sets with scope: {self.scope}")
                response = self.wafv2_client.list_ip_sets(Scope=self.scope)
                print(f"DEBUG: Found {len(response['IPSets'])} IP sets")

                for ip_set in response["IPSets"]:
                    print(f"DEBUG: Checking IP set: {ip_set['Name']}")
                    if ip_set["Name"] == ip_set_name:
                        print(f"DEBUG: Found existing IP set: {ip_set_name}, updating...")
                        # IP set exists, update it
                        ip_set_id = ip_set["Id"]

                        # Get current IP set details to get lock token
                        print(f"DEBUG: Getting IP set details for ID: {ip_set_id}")
                        get_response = self.wafv2_client.get_ip_set(
                            Name=ip_set_name,
                            Scope=self.scope,
                            Id=ip_set_id
                        )
                        lock_token = get_response["LockToken"]
                        ip_set_arn = get_response["IPSet"]["ARN"]  # Get ARN from existing IP set
                        print(f"DEBUG: Got IP set ARN: {ip_set_arn}")

                        # Update the IP set with new addresses
                        print(f"DEBUG: Updating IP set with addresses: {ip_list}")
                        update_response = self.wafv2_client.update_ip_set(
                            Name=ip_set_name,
                            Scope=self.scope,
                            Id=ip_set_id,
                            Addresses=ip_list,
                            LockToken=lock_token
                        )
                        print(f"DEBUG: Successfully updated IP set: {ip_set_name}")
                        # Return the ARN we got from the existing IP set
                        return ip_set_arn

            except ClientError as list_error:
                print(f"DEBUG: ClientError checking existing IP sets: {list_error}")
                print(f"DEBUG: Error code: {list_error.response.get('Error', {}).get('Code', 'Unknown')}")
                print(f"DEBUG: Error message: {list_error.response.get('Error', {}).get('Message', 'Unknown')}")
                # Continue to create new IP set
            except Exception as e:
                print(f"DEBUG: General error checking existing IP sets: {e}")
                print(f"DEBUG: Error type: {type(e).__name__}")
                # Continue to create new IP set

            print(f"DEBUG: IP set {ip_set_name} not found, creating new one...")
            print(f"DEBUG: About to call create_ip_set with:")
            print(f"DEBUG:   Name: {ip_set_name}")
            print(f"DEBUG:   Scope: {self.scope}")
            print(f"DEBUG:   Addresses: {ip_list}")

            # Create new IP set if it doesn't exist
            try:
                response = self.wafv2_client.create_ip_set(
                    Name=ip_set_name,
                    Scope=self.scope,
                    Description=f"Allow list IPs for {ip_set_name}",
                    IPAddressVersion='IPV4',
                    Addresses=ip_list
                )
                print(f"DEBUG: Successfully created new IP set: {ip_set_name}")
                print(f"DEBUG: Response: {response}")
                return response['Summary']['ARN']
            except ClientError as create_error:
                print(f"DEBUG: ClientError creating IP set: {create_error}")
                print(f"DEBUG: Error code: {create_error.response.get('Error', {}).get('Code', 'Unknown')}")
                print(f"DEBUG: Error message: {create_error.response.get('Error', {}).get('Message', 'Unknown')}")
                print(f"DEBUG: Full error response: {create_error.response}")
                raise RuntimeError(f"Failed to create IP set: {create_error}")
            except Exception as create_exception:
                print(f"DEBUG: General exception creating IP set: {create_exception}")
                print(f"DEBUG: Exception type: {type(create_exception).__name__}")
                raise RuntimeError(f"Failed to create IP set: {create_exception}")

        except Exception as outer_exception:
            print(f"DEBUG: Outer exception in _create_ip_set: {outer_exception}")
            print(f"DEBUG: Outer exception type: {type(outer_exception).__name__}")
            raise RuntimeError(f"Failed to create/update IP set: {outer_exception}")

    def _update_ip_set(self, ip_set_arn: str, ip_list: List[str]) -> None:
        """
        Update an existing IP set

        Args:
            ip_set_arn: ARN of the IP set to update
            ip_list: New list of IP addresses
        """
        try:
            # Get the IP set ID from ARN
            ip_set_id = ip_set_arn.split('/')[-1]

            # Get the IP set details
            response = self.wafv2_client.get_ip_set(
                Name=ip_set_id,
                Scope=self.scope,
                Id=ip_set_id
            )

            # Update the IP set
            self.wafv2_client.update_ip_set(
                Name=ip_set_id,
                Scope=self.scope,
                Id=ip_set_id,
                Addresses=ip_list,
                LockToken=response['LockToken']
            )
        except ClientError as e:
            raise RuntimeError(f"Failed to update IP set: {e}")

    def _create_regex_pattern_set(self, regex_set_name: str, domain_list: List[str]) -> str:
        """
        Create a regex pattern set for allow list or update existing one

        Args:
            regex_set_name: Name for the regex pattern set
            domain_list: List of domains

        Returns:
            ARN of the created or updated regex pattern set
        """
        try:
            print(f"DEBUG: Looking for regex pattern set: {regex_set_name}")

            # Convert domains to regex patterns
            regex_patterns = [".*" + re.escape(domain) + ".*" for domain in domain_list]

            # First try to find existing regex pattern set
            try:
                response = self.wafv2_client.list_regex_pattern_sets(Scope=self.scope)
                print(f"DEBUG: Found {len(response['RegexPatternSets'])} regex pattern sets")

                for regex_set in response["RegexPatternSets"]:
                    print(f"DEBUG: Checking regex pattern set: {regex_set['Name']}")
                    if regex_set["Name"] == regex_set_name:
                        print(f"DEBUG: Found existing regex pattern set: {regex_set_name}, updating...")
                        # Regex pattern set exists, update it
                        regex_set_id = regex_set["Id"]

                        # Get current regex pattern set details to get lock token
                        get_response = self.wafv2_client.get_regex_pattern_set(
                            Name=regex_set_name,
                            Scope=self.scope,
                            Id=regex_set_id
                        )
                        lock_token = get_response["LockToken"]
                        regex_set_arn = get_response["RegexPatternSet"]["ARN"]  # Get ARN from existing set

                        # Update the regex pattern set with new patterns
                        update_response = self.wafv2_client.update_regex_pattern_set(
                            Name=regex_set_name,
                            Scope=self.scope,
                            Id=regex_set_id,
                            RegularExpressionList=[{"RegexString": pattern} for pattern in regex_patterns],
                            LockToken=lock_token
                        )
                        print(f"DEBUG: Successfully updated regex pattern set: {regex_set_name}")
                        # Return the ARN we got from the existing regex pattern set
                        return regex_set_arn

            except Exception as e:
                print(f"DEBUG: Error checking existing regex pattern sets: {e}")
                # Continue to create new regex pattern set

            print(f"DEBUG: Regex pattern set {regex_set_name} not found, creating new one...")
            # Create new regex pattern set if it doesn't exist
            response = self.wafv2_client.create_regex_pattern_set(
                Name=regex_set_name,
                Scope=self.scope,
                Description=f"Allow list domains for {regex_set_name}",
                RegularExpressionList=[{"RegexString": pattern} for pattern in regex_patterns]
            )
            print(f"DEBUG: Successfully created new regex pattern set: {regex_set_name}")
            return response['Summary']['ARN']

        except ClientError as e:
            print(f"DEBUG: ClientError in _create_regex_pattern_set: {e}")
            raise RuntimeError(f"Failed to create/update regex pattern set: {e}")

    def _update_regex_pattern_set(self, regex_set_arn: str, domain_list: List[str]) -> None:
        """
        Update an existing regex pattern set

        Args:
            regex_set_arn: ARN of the regex pattern set to update
            domain_list: New list of domain patterns
        """
        try:
            # Get the regex set ID from ARN
            regex_set_id = regex_set_arn.split('/')[-1]

            # Get the regex set details
            response = self.wafv2_client.get_regex_pattern_set(
                Name=regex_set_id,
                Scope=self.scope,
                Id=regex_set_id
            )

            # Convert domains to regex patterns
            regex_patterns = []
            for domain in domain_list:
                escaped_domain = domain.replace('.', r'\.')
                pattern = f".*{escaped_domain}.*"
                regex_patterns.append(pattern)

            # Update the regex pattern set
            self.wafv2_client.update_regex_pattern_set(
                Name=regex_set_id,
                Scope=self.scope,
                Id=regex_set_id,
                RegularExpressionList=[
                    {"RegexString": pattern} for pattern in regex_patterns
                ],
                LockToken=response['LockToken']
            )
        except ClientError as e:
            raise RuntimeError(f"Failed to update regex pattern set: {e}")

    def create_allow_list_rule(self, web_acl_name: str, original_rule_name: str,
                              ip_list: List[str] = None, domain_list: List[str] = None) -> Dict:
        """
        Create a custom rule that allows specific IPs/domains for a managed rule
        Uses IP sets and regex pattern sets for efficient multiple IP/domain handling

        Args:
            web_acl_name: Name of the Web ACL
            original_rule_name: Name of the original rule to create exceptions for
            ip_list: List of IP addresses to allow
            domain_list: List of domains to allow

        Returns:
            Dict with success status and custom rule information
        """
        try:
            web_acl, lock_token = self._get_web_acl(web_acl_name)

            print(f"DEBUG: Retrieved Web ACL: {web_acl_name}")
            print(f"DEBUG: Web ACL has {len(web_acl.get('Rules', []))} rules")

            # Generate custom rule name following the pattern
            custom_rule_name = f"Block_{original_rule_name}_ExceptCertainPaths"
            print(f"DEBUG: Looking for custom rule: {custom_rule_name}")

            # Check if custom rule already exists
            existing_rule = None
            for rule in web_acl.get("Rules", []):
                print(f"DEBUG: Checking existing rule: {rule['Name']}")
                if rule["Name"] == custom_rule_name:
                    existing_rule = rule
                    print(f"DEBUG: Found existing custom rule: {custom_rule_name}")
                    break

            if existing_rule:
                print(f"DEBUG: Custom rule already exists, updating IP sets and regex patterns")
                # Update existing IP set and regex pattern instead of creating new rule
                ip_set_arn = None
                if ip_list:
                    ip_set_name = f"ALLOWED_IPS_{original_rule_name}"
                    ip_set_arn = self._create_ip_set(ip_set_name, ip_list)

                regex_set_arn = None
                if domain_list:
                    regex_set_name = f"ALLOWED_DOMAINS_{original_rule_name}"
                    regex_set_arn = self._create_regex_pattern_set(regex_set_name, domain_list)

                # Update the mapping with new data
                storage = RuleMappingStorage()
                storage.save_rule_mapping(
                    rule_group=self.rule_group_name,
                    original_rule=original_rule_name,
                    custom_rule_name=custom_rule_name,
                    ip_list=ip_list or [],
                    domain_list=domain_list or [],
                    ip_set_arn=ip_set_arn,
                    regex_set_arn=regex_set_arn
                )

                return {
                    "success": True,
                    "message": f"Successfully updated allow list rule '{custom_rule_name}' for '{original_rule_name}'",
                    "custom_rule_name": custom_rule_name,
                    "original_rule_name": original_rule_name,
                    "ip_set_arn": ip_set_arn,
                    "regex_set_arn": regex_set_arn,
                    "updated": True
                }

            print(f"DEBUG: Custom rule does not exist, proceeding to create it")

            # Create IP set if IPs are provided
            ip_set_arn = None
            if ip_list:
                ip_set_name = f"ALLOWED_IPS_{original_rule_name}"
                try:
                    print(f"DEBUG: Creating IP set for rule: {original_rule_name}")
                    ip_set_arn = self._create_ip_set(ip_set_name, ip_list)
                    print(f"DEBUG: After creating IP set - ip_set_arn: {ip_set_arn}")
                except Exception as ip_error:
                    print(f"ERROR: Failed to create IP set '{ip_set_name}': {str(ip_error)}")
                    print(f"ERROR: IP set error type: {type(ip_error).__name__}")
                    raise RuntimeError(f"IP set creation failed: {str(ip_error)}")

            # Create regex pattern set if domains are provided
            regex_set_arn = None
            if domain_list:
                regex_set_name = f"ALLOWED_DOMAINS_{original_rule_name}"
                try:
                    print(f"DEBUG: Creating regex pattern set for rule: {original_rule_name}")
                    regex_set_arn = self._create_regex_pattern_set(regex_set_name, domain_list)
                    print(f"DEBUG: After creating regex pattern set - regex_set_arn: {regex_set_arn}")
                except Exception as regex_error:
                    print(f"ERROR: Failed to create regex pattern set '{regex_set_name}': {str(regex_error)}")
                    print(f"ERROR: Regex set error type: {type(regex_error).__name__}")
                    raise RuntimeError(f"Regex pattern set creation failed: {str(regex_error)}")

            # Build the custom rule statement following the Block_GenericRFI_BODY_ExceptCertainPaths pattern
            statements = []

            # Create the main LabelMatchStatement to match the managed rule
            label_key = f"awswaf:managed:aws:amazon-ip-reputation-list:{original_rule_name}"
            if "CommonRuleSet" in self.rule_group_name:
                label_key = f"awswaf:managed:aws:core-rule-set:{original_rule_name}"
            elif "KnownBadInputsRuleSet" in self.rule_group_name:
                label_key = f"awswaf:managed:aws:known-bad-inputs:{original_rule_name}"
            elif "LinuxRuleSet" in self.rule_group_name:
                label_key = f"awswaf:managed:aws:linux:{original_rule_name}"
            elif "UnixRuleSet" in self.rule_group_name:
                label_key = f"awswaf:managed:aws:unix:{original_rule_name}"
            elif "AnonymousIpList" in self.rule_group_name:
                label_key = f"awswaf:managed:aws:anonymous-ip-list:{original_rule_name}"
            elif "SQLiRuleSet" in self.rule_group_name:
                label_key = f"awswaf:managed:aws:sqli:{original_rule_name}"

            # Create the main statement structure
            # If we have exceptions, use AndStatement, otherwise use LabelMatchStatement directly
            label_statement = {
                "LabelMatchStatement": {
                    "Scope": "LABEL",
                    "Key": label_key
                }
            }

            # Add exception conditions using NotStatement (allow IPs/domains)
            print(f"DEBUG: Before rule creation check - ip_set_arn: {ip_set_arn}, regex_set_arn: {regex_set_arn}")
            if ip_set_arn or regex_set_arn:
                exception_statements = []

                # Add IP set exception if provided
                if ip_set_arn:
                    exception_statements.append({
                        "IPSetReferenceStatement": {
                            "ARN": ip_set_arn
                        }
                    })

                # Add regex pattern set exception if provided
                if regex_set_arn:
                    exception_statements.append({
                        "RegexPatternSetReferenceStatement": {
                            "ARN": regex_set_arn,
                            "FieldToMatch": {
                                "SingleHeader": {
                                    "Name": "host"
                                }
                            },
                            "TextTransformations": [
                                {
                                    "Priority": 0,
                                    "Type": "LOWERCASE"
                                }
                            ]
                        }
                    })

                # Create NotStatement for exceptions (these will be allowed)
                if len(exception_statements) == 1:
                    not_statement = {
                        "NotStatement": {
                            "Statement": exception_statements[0]
                        }
                    }
                else:
                    not_statement = {
                        "NotStatement": {
                            "Statement": {
                                "OrStatement": {
                                    "Statements": exception_statements
                                }
                            }
                        }
                    }

                # Use AndStatement when we have exceptions
                rule_statement = {
                    "AndStatement": {
                        "Statements": [label_statement, not_statement]
                    }
                }
            else:
                # Use LabelMatchStatement directly when no exceptions
                rule_statement = label_statement

            # Always create the custom rule regardless of IP set/regex pattern success
            print(f"DEBUG: About to get next priority for custom rule creation")
            # Get the next available priority
            next_priority = self._get_custom_rule_priority(web_acl, original_rule_name)
            print(f"DEBUG: Next priority calculated: {next_priority}")

            # CRITICAL: After priority shifts, get fresh Web ACL and LockToken
            print("DEBUG: Getting fresh Web ACL and LockToken after priority shifts...")
            web_acl, lock_token = self._get_web_acl(web_acl_name)
            print(f"DEBUG: Fresh Web ACL has {len(web_acl.get('Rules', []))} rules")
            print(f"DEBUG: Fresh LockToken: {lock_token[:16]}...")

            # Create the custom rule
            custom_rule = {
                "Name": custom_rule_name,
                "Priority": next_priority,  # Dynamic priority
                "Statement": rule_statement,
                "Action": {
                    "Block": {}
                },
                "VisibilityConfig": {
                    "SampledRequestsEnabled": True,
                    "CloudWatchMetricsEnabled": True,
                    "MetricName": custom_rule_name
                }
            }

            # Add the custom rule to the Web ACL
            web_acl["Rules"].append(custom_rule)  # Append the rule

            # Sort rules by priority to maintain proper order
            web_acl["Rules"].sort(key=lambda x: x.get("Priority", 999999))
            print(f"DEBUG: Added custom rule with priority {next_priority}, total rules: {len(web_acl['Rules'])}")

            # Update the Web ACL with retry logic for concurrent access issues
            print(f"DEBUG: About to update Web ACL with custom rule: {custom_rule_name}")
            print(f"DEBUG: Custom rule structure: {json.dumps(custom_rule, indent=2)}")

            max_retries = 3
            retry_delay = 1  # Start with 1 second

            for attempt in range(max_retries):
                try:
                    # Get fresh Web ACL and lock token for each retry
                    if attempt > 0:
                        print(f"DEBUG: Retry attempt {attempt + 1}/{max_retries}")
                        time.sleep(retry_delay)
                        web_acl, lock_token = self._get_web_acl(web_acl_name)

                        # Re-add custom rule to refreshed rules list
                        web_acl["Rules"].append(custom_rule)
                        web_acl["Rules"].sort(key=lambda x: x.get("Priority", 999999))
                        print(f"DEBUG: Refreshed Web ACL, total rules: {len(web_acl['Rules'])}")

                    self.wafv2_client.update_web_acl(
                        Name=web_acl_name,
                        Scope=self.scope,
                        Id=web_acl["Id"],
                        DefaultAction=web_acl["DefaultAction"],
                        Rules=web_acl["Rules"],
                        LockToken=lock_token,
                        VisibilityConfig=web_acl["VisibilityConfig"],
                    )
                    print(f"DEBUG: Successfully updated Web ACL with custom rule")
                    break  # Success, exit retry loop

                except Exception as web_acl_error:
                    error_str = str(web_acl_error)
                    print(f"ERROR: Attempt {attempt + 1} failed to update Web ACL: {error_str}")

                    # Check if this is a retryable error
                    if "WAFUnavailableEntityException" in error_str and attempt < max_retries - 1:
                        print(f"DEBUG: WAF unavailable, will retry in {retry_delay} seconds...")
                        retry_delay *= 2  # Exponential backoff
                        continue
                    else:
                        print(f"ERROR: Web ACL details - ID: {web_acl.get('Id')}, Name: {web_acl_name}")
                        print(f"ERROR: Custom rule: {custom_rule}")
                        raise web_acl_error

            # Save the mapping using RuleMappingStorage
            print(f"DEBUG: About to save rule mapping for {custom_rule_name}")
            try:
                storage = RuleMappingStorage()
                storage.save_rule_mapping(
                    rule_group=self.rule_group_name,
                    original_rule=original_rule_name,
                    custom_rule_name=custom_rule_name,
                    ip_list=ip_list or [],
                    domain_list=domain_list or [],
                    ip_set_arn=ip_set_arn,
                    regex_set_arn=regex_set_arn
                )
                print(f"DEBUG: Successfully saved rule mapping")
            except Exception as mapping_error:
                print(f"ERROR: Failed to save rule mapping: {str(mapping_error)}")
                print(f"ERROR: Mapping details - rule_group: {self.rule_group_name}, original_rule: {original_rule_name}")
                # Don't fail the whole operation if mapping save fails
                print(f"WARNING: Continuing despite mapping save failure")

            return {
                "success": True,
                "message": f"Successfully created allow list rule '{custom_rule_name}' for '{original_rule_name}'",
                "custom_rule_name": custom_rule_name,
                "original_rule_name": original_rule_name,
                "ip_set_arn": ip_set_arn,
                "regex_set_arn": regex_set_arn
            }

        except Exception as e:
            print(f"ERROR: Exception in create_allow_list_rule: {str(e)}")
            print(f"ERROR: Exception type: {type(e).__name__}")
            print(f"ERROR: Rule details - original_rule: {original_rule_name}, ip_list: {ip_list}, domain_list: {domain_list}")
            import traceback
            print(f"ERROR: Full traceback:")
            traceback.print_exc()
            return {
                "success": False,
                "message": f"Failed to create allow list rule: {str(e)}",
                "original_rule_name": original_rule_name,
                "error_type": type(e).__name__
            }

    def update_allow_list_rule(self, web_acl_name: str, original_rule_name: str,
                               ip_list: List[str] = None, domain_list: List[str] = None) -> Dict:
        """
        Update an existing allow list rule with new IPs/domains

        Args:
            web_acl_name: Name of the Web ACL
            original_rule_name: Name of the original rule
            ip_list: List of IP addresses to allow
            domain_list: List of domains to allow

        Returns:
            Dict with success status and message
        """
        try:
            # Get existing rule mapping
            rule_group_key = self.rule_group_name.replace("AWS-AWSManagedRules", "").replace("List", "").lower()
            mapping = self.rule_mapping_storage.get_rule_mapping(rule_group_key, original_rule_name)

            if not mapping:
                return {
                    "success": False,
                    "message": f"No existing allow list rule found for '{original_rule_name}'"
                }

            custom_rule_name = mapping["custom_rule_name"]
            ip_set_arn = mapping.get("ip_set_arn")
            regex_set_arn = mapping.get("regex_set_arn")

            # Update IP set if it exists and we have new IPs
            if ip_set_arn and ip_list is not None:
                self._update_ip_set(ip_set_arn, ip_list)

            # Update regex pattern set if it exists and we have new domains
            if regex_set_arn and domain_list is not None:
                self._update_regex_pattern_set(regex_set_arn, domain_list)

            # Update rule mapping
            self.rule_mapping_storage.update_rule_mapping(
                rule_group_key, original_rule_name, ip_list or [], domain_list or [], ip_set_arn, regex_set_arn
            )

            return {
                "success": True,
                "message": f"Allow list rule '{custom_rule_name}' updated successfully",
                "custom_rule_name": custom_rule_name,
                "original_rule_name": original_rule_name,
                "ip_list": ip_list or [],
                "domain_list": domain_list or []
            }

        except Exception as e:
            return {
                "success": False,
                "message": f"Failed to update allow list rule: {str(e)}",
                "original_rule_name": original_rule_name
            }

    def get_rule_mapping(self, rule_group: str, original_rule: str) -> Optional[Dict]:
        """
        Get rule mapping for a specific rule

        Args:
            rule_group: Rule group name
            original_rule: Original rule name

        Returns:
            Rule mapping dictionary or None
        """
        return self.rule_mapping_storage.get_rule_mapping(rule_group, original_rule)

    def get_allow_list_data(self, rule_group: str, original_rule: str) -> Dict:
        """
        Get allow list data for a specific rule by reading directly from AWS resources

        Args:
            rule_group: Rule group name
            original_rule: Original rule name

        Returns:
            Dictionary with IP and domain lists from AWS
        """
        try:
            print(f"DEBUG: get_allow_list_data called for rule_group='{rule_group}', original_rule='{original_rule}'")

            # Fetch actual IP set data directly by name
            ip_list = []
            ip_set_name = f"ALLOWED_IPS_{original_rule}"
            print(f"DEBUG: Looking for IP set: {ip_set_name}")

            try:
                response = self.wafv2_client.list_ip_sets(Scope=self.scope)
                print(f"DEBUG: Found {len(response['IPSets'])} IP sets")
                for ip_set in response["IPSets"]:
                    print(f"DEBUG: Checking IP set: {ip_set['Name']}")
                    if ip_set["Name"] == ip_set_name:
                        print(f"DEBUG: Found matching IP set: {ip_set_name}")
                        get_response = self.wafv2_client.get_ip_set(
                            Name=ip_set_name,
                            Scope=self.scope,
                            Id=ip_set["Id"]
                        )
                        ip_list = get_response["IPSet"]["Addresses"]
                        print(f"DEBUG: Retrieved {len(ip_list)} IP addresses: {ip_list}")
                        break
            except Exception as e:
                print(f"DEBUG: Error fetching IP set data: {e}")

            # Fetch actual regex pattern data directly by name
            domain_list = []
            regex_set_name = f"ALLOWED_DOMAINS_{original_rule}"
            print(f"DEBUG: Looking for regex pattern set: {regex_set_name}")

            try:
                response = self.wafv2_client.list_regex_pattern_sets(Scope=self.scope)
                print(f"DEBUG: Found {len(response['RegexPatternSets'])} regex pattern sets")
                for regex_set in response["RegexPatternSets"]:
                    print(f"DEBUG: Checking regex pattern set: {regex_set['Name']}")
                    if regex_set["Name"] == regex_set_name:
                        print(f"DEBUG: Found matching regex pattern set: {regex_set_name}")
                        get_response = self.wafv2_client.get_regex_pattern_set(
                            Name=regex_set_name,
                            Scope=self.scope,
                            Id=regex_set["Id"]
                        )
                        # Convert regex patterns back to domains (remove .* if present)
                        domain_list = []
                        for pattern in get_response["RegexPatternSet"]["RegularExpressionList"]:
                            domain = pattern["RegexString"]
                            # Remove leading .* if present
                            if domain.startswith(".*"):
                                domain = domain[2:]
                            # Remove escaping backslashes
                            domain = domain.replace("\\.", ".")
                            domain_list.append(domain)
                        print(f"DEBUG: Retrieved {len(domain_list)} domains: {domain_list}")
                        break
            except Exception as e:
                print(f"DEBUG: Error fetching regex pattern data: {e}")

            result = {
                "ipList": ip_list,
                "domainList": domain_list
            }
            print(f"DEBUG: Returning allow list data: {result}")
            return result

        except Exception as e:
            print(f"ERROR: Exception in get_allow_list_data: {e}")
            return {"ipList": [], "domainList": []}
