from .BaseManagedRuleGroupManager import BaseManagedRuleGroupManager

class WAFSQLDatabaseManager(BaseManagedRuleGroupManager):
    """
    Manages AWS SQL Database Rule Set managed rule group.
    Contains 6 individual rules for SQL injection protection.
    """
    
    def __init__(self, wafv2_client=None, scope: str = "REGIONAL", region: str = "us-east-1"):
        """
        Initialize the SQL Database Protection Manager
        
        Args:
            wafv2_client: Boto3 WAFv2 client
            scope: WAF scope (REGIONAL or CLOUDFRONT)
            region: AWS region
        """
        # AWS SQL Database Rule Set individual rules with exact names from AWS documentation
        rule_definitions = {
            "SQLi_QUERYARGUMENTS": {
                "name": "SQLi_QUERYARGUMENTS",
                "display_name": "SQL Injection in Query Arguments",
                "description": "Uses the built-in AWS WAF SQL injection attack rule statement, with sensitivity level set to Low, to inspect the values of all query parameters for patterns that match malicious SQL code",
                "default_action": "Block",
                "priority": 1
            },
            "SQLiExtendedPatterns_QUERYARGUMENTS": {
                "name": "SQLiExtendedPatterns_QUERYARGUMENTS",
                "display_name": "Extended SQL Injection Patterns in Query Arguments",
                "description": "Inspects the values of all query parameters for patterns that match malicious SQL code. The patterns this rule inspects for aren't covered by the rule SQLi_QUERYARGUMENTS",
                "default_action": "Block",
                "priority": 2
            },
            "SQLi_BODY": {
                "name": "SQLi_BODY",
                "display_name": "SQL Injection in Request Body",
                "description": "Uses the built-in AWS WAF SQL injection attack rule statement, with sensitivity level set to Low, to inspect the request body for patterns that match malicious SQL code",
                "default_action": "Block",
                "priority": 3
            },
            "SQLiExtendedPatterns_BODY": {
                "name": "SQLiExtendedPatterns_BODY",
                "display_name": "Extended SQL Injection Patterns in Request Body",
                "description": "Inspects the request body for patterns that match malicious SQL code. The patterns this rule inspects for aren't covered by the rule SQLi_BODY",
                "default_action": "Block",
                "priority": 4
            },
            "SQLi_COOKIE": {
                "name": "SQLi_COOKIE",
                "display_name": "SQL Injection in Cookies",
                "description": "Uses the built-in AWS WAF SQL injection attack rule statement, with sensitivity level set to Low, to inspect the request cookie headers for patterns that match malicious SQL code",
                "default_action": "Block",
                "priority": 5
            },
            "SQLi_URIPATH": {
                "name": "SQLi_URIPATH",
                "display_name": "SQL Injection in URI Path",
                "description": "Uses the built-in AWS WAF SQL injection attack rule statement, with sensitivity level set to Low, to inspect the request URI path for patterns that match malicious SQL code",
                "default_action": "Block",
                "priority": 6
            }
        }
        
        super().__init__(
            wafv2_client=wafv2_client,
            scope=scope,
            region=region,
            rule_group_name="AWS-AWSManagedRulesSQLiRuleSet",
            rule_definitions=rule_definitions
        )
