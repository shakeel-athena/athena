"""
Athena Security Platform - Firewall Audit Manager
Handles database logging for alert-based IP blocking
"""

import psycopg2
import psycopg2.extras
from datetime import datetime
import json


class FirewallAuditManager:
    """
    Manages audit trail for IPs blocked from security alerts
    Stores WHO blocked WHAT IP, WHEN, and WHY (from which alert)

    Similar to MuteManager but for firewall IP blocking operations
    """

    def __init__(self, db_connection):
        """
        Initialize with PostgreSQL connection

        Args:
            db_connection: Raw psycopg2 connection (extracted from DatabaseWrapper)
        """
        self.db = db_connection
        self._should_close_db = False

    def __del__(self):
        """Close database connection if we created it"""
        if self._should_close_db and self.db:
            try:
                self.db.close()
            except:
                pass

    def log_ip_blocked(self, ip, analyst, alert_context):
        """
        Log IP block with full alert context

        Args:
            ip: IP address (will be normalized to CIDR)
            analyst: Username who blocked
            alert_context: {
                'alert_id': 'suricata-alert-123',
                'alert_source': 'suricata' | 'wazuh',
                'alert_severity': 'Critical' | 'High' | 'Medium' | 'Low',
                'threat_type': 'malware_c2' | 'brute_force' | etc,
                'reason': 'Why IP was blocked',
                'direction': 'inbound' | 'outbound' | 'both',
                'aws_rule_group': 'athena-network-firewall'
            }

        Returns:
            UUID of created firewall_ip_metadata record
        """
        if not self.db:
            raise Exception("Database connection not available")

        # Normalize IP to CIDR with appropriate prefix length
        if '/' not in ip:
            try:
                import ipaddress
                ip_obj = ipaddress.ip_address(ip)
                if isinstance(ip_obj, ipaddress.IPv4Address):
                    ip_cidr = f"{ip}/32"
                else:  # IPv6Address
                    ip_cidr = f"{ip}/128"
            except:
                ip_cidr = f"{ip}/32"  # Fallback to IPv4
        else:
            ip_cidr = ip

        cursor = self.db.cursor()
        try:
            # Insert metadata record
            cursor.execute("""
                INSERT INTO firewall_ip_metadata
                (ip_address, ip_cidr, list_type, added_by, reason,
                 alert_source, original_alert_id, alert_severity, threat_type,
                 aws_enforced, aws_rule_group, aws_enforced_at, expires_at, direction,
                 waf_enforced, waf_ip_set, waf_error)
                VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
                RETURNING id
            """, [
                ip,
                ip_cidr,
                'block',
                analyst,
                alert_context.get('reason', 'Blocked from security alert'),
                alert_context.get('alert_source'),
                alert_context.get('alert_id'),
                alert_context.get('alert_severity'),
                alert_context.get('threat_type', 'other'),
                True,  # aws_enforced
                alert_context.get('aws_rule_group', 'athena-network-firewall'),
                datetime.now(),
                alert_context.get('expires_at'),  # Use provided expiration time
                alert_context.get('direction', 'both'),
                alert_context.get('waf_enforced', False),  # waf_enforced
                alert_context.get('waf_ip_set'),  # waf_ip_set
                alert_context.get('waf_error')  # waf_error
            ])

            metadata_id = cursor.fetchone()[0]

            # Log to audit trail
            cursor.execute("""
                INSERT INTO firewall_audit_log
                (action, analyst, ip_metadata_id, ip_address, ip_cidr,
                 alert_source, original_alert_id, alert_severity,
                 aws_rule_group, aws_region, aws_success, details)
                VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
            """, [
                'ip_added_to_block',
                analyst,
                metadata_id,
                ip,
                ip_cidr,
                alert_context.get('alert_source'),
                alert_context.get('alert_id'),
                alert_context.get('alert_severity'),
                alert_context.get('aws_rule_group'),
                alert_context.get('aws_region', 'us-east-2'),
                True,
                json.dumps({
                    'threat_type': alert_context.get('threat_type'),
                    'reason': alert_context.get('reason'),
                    'direction': alert_context.get('direction'),
                    'severity': alert_context.get('alert_severity')
                })
            ])

            self.db.commit()

            print(f"[✓] IP {ip} blocked - Metadata ID: {metadata_id}")
            return metadata_id

        except Exception as e:
            self.db.rollback()
            print(f"[!] Error logging IP block: {e}")
            raise e
        finally:
            cursor.close()

    def log_ip_unblocked(self, ip, analyst, reason=None):
        """
        Log IP unblock action

        Args:
            ip: IP address to unblock
            analyst: Username who unblocked
            reason: Optional reason for unblocking

        Returns:
            UUID of updated metadata record
        """
        if not self.db:
            raise Exception("Database connection not available")

        # Normalize IP to CIDR
        ip_cidr = f"{ip}/32" if '/' not in ip else ip

        cursor = self.db.cursor()
        try:
            # Update metadata record - mark as inactive
            cursor.execute("""
                UPDATE firewall_ip_metadata
                SET active = FALSE,
                    removed_at = NOW(),
                    removed_by = %s,
                    removal_reason = %s
                WHERE ip_cidr = %s AND active = TRUE AND list_type = 'block'
                RETURNING id
            """, [analyst, reason, ip_cidr])

            result = cursor.fetchone()
            if not result:
                raise Exception(f"No active block found for IP: {ip}")

            metadata_id = result[0]

            # Log to audit trail
            cursor.execute("""
                INSERT INTO firewall_audit_log
                (action, analyst, ip_metadata_id, ip_address, ip_cidr,
                 aws_success, details)
                VALUES (%s, %s, %s, %s, %s, %s, %s)
            """, [
                'ip_removed_from_block',
                analyst,
                metadata_id,
                ip,
                ip_cidr,
                True,
                json.dumps({
                    'action': 'manual_unblock',
                    'reason': reason,
                    'timestamp': datetime.now().isoformat()
                })
            ])

            self.db.commit()

            print(f"[✓] IP {ip} unblocked - Metadata ID: {metadata_id}")
            return metadata_id

        except Exception as e:
            self.db.rollback()
            print(f"[!] Error logging IP unblock: {e}")
            raise e
        finally:
            cursor.close()

    def get_blocked_ips(self, filters=None):
        """
        Get all IPs blocked from alerts with metadata

        Args:
            filters: {
                'threat_type': str,
                'alert_source': str,
                'analyst': str,
                'active_only': bool (default: True)
            }

        Returns:
            List of blocked IP records with full metadata
        """
        if not self.db:
            return []

        cursor = self.db.cursor(cursor_factory=psycopg2.extras.RealDictCursor)

        try:
            where_clauses = ["list_type = 'block'"]
            params = []

            if filters:
                if filters.get('active_only', True):
                    where_clauses.append("active = TRUE")

                if filters.get('threat_type'):
                    where_clauses.append("threat_type = %s")
                    params.append(filters['threat_type'])

                if filters.get('alert_source'):
                    where_clauses.append("alert_source = %s")
                    params.append(filters['alert_source'])

                if filters.get('analyst'):
                    where_clauses.append("added_by = %s")
                    params.append(filters['analyst'])

            where_clause = " AND ".join(where_clauses)

            cursor.execute(f"""
                SELECT
                    id,
                    ip_address,
                    ip_cidr,
                    threat_type,
                    alert_source,
                    alert_severity,
                    original_alert_id,
                    added_by,
                    added_at,
                    removed_by,
                    removed_at,
                    reason,
                    active,
                    aws_enforced,
                    aws_enforced_at,
                    aws_enforcement_error,
                    aws_rule_group,
                    waf_enforced,
                    waf_ip_set,
                    waf_error,
                    times_seen_in_alerts,
                    last_seen_in_alert,
                    expires_at,
                    notes,
                    tags,
                    list_type
                FROM firewall_ip_metadata
                WHERE {where_clause}
                ORDER BY added_at DESC
            """, params)

            results = cursor.fetchall()

            print(f"[✓] Retrieved {len(results)} blocked IPs")
            return results

        except Exception as e:
            print(f"[!] Error fetching blocked IPs: {e}")
            return []
        finally:
            cursor.close()

    def get_ip_metadata(self, ip):
        """
        Get metadata for specific IP

        Args:
            ip: IP address

        Returns:
            Dict with IP metadata or None if not found
        """
        if not self.db:
            return None

        ip_cidr = f"{ip}/32" if '/' not in ip else ip

        cursor = self.db.cursor(cursor_factory=psycopg2.extras.RealDictCursor)

        try:
            cursor.execute("""
                SELECT
                    id,
                    ip_address,
                    ip_cidr,
                    list_type,
                    threat_type,
                    alert_source,
                    alert_severity,
                    original_alert_id,
                    added_by,
                    added_at,
                    removed_by,
                    removed_at,
                    reason,
                    direction,
                    active,
                    aws_enforced,
                    aws_rule_group,
                    times_seen_in_alerts,
                    last_seen_in_alert
                FROM firewall_ip_metadata
                WHERE ip_cidr = %s AND list_type = 'block'
                ORDER BY added_at DESC
                LIMIT 1
            """, [ip_cidr])

            return cursor.fetchone()

        except Exception as e:
            print(f"[!] Error fetching IP metadata: {e}")
            return None
        finally:
            cursor.close()

    def get_audit_trail(self, ip):
        """
        Get complete audit history for specific IP

        Args:
            ip: IP address

        Returns:
            List of audit log entries
        """
        if not self.db:
            return []

        ip_cidr = f"{ip}/32" if '/' not in ip else ip

        cursor = self.db.cursor(cursor_factory=psycopg2.extras.RealDictCursor)

        try:
            cursor.execute("""
                SELECT
                    timestamp,
                    action,
                    analyst,
                    alert_source,
                    original_alert_id,
                    alert_severity,
                    aws_success,
                    aws_rule_group,
                    details
                FROM firewall_audit_log
                WHERE ip_cidr = %s
                ORDER BY timestamp DESC
            """, [ip_cidr])

            return cursor.fetchall()

        except Exception as e:
            print(f"[!] Error fetching audit trail: {e}")
            return []
        finally:
            cursor.close()

    def increment_alert_count(self, ip):
        """
        Increment the times_seen_in_alerts counter for an IP

        Args:
            ip: IP address

        Used when the same IP appears in multiple alerts
        """
        if not self.db:
            return

        ip_cidr = f"{ip}/32" if '/' not in ip else ip

        cursor = self.db.cursor()
        try:
            cursor.execute("""
                UPDATE firewall_ip_metadata
                SET times_seen_in_alerts = times_seen_in_alerts + 1,
                    last_seen_in_alert = NOW()
                WHERE ip_cidr = %s AND active = TRUE AND list_type = 'block'
            """, [ip_cidr])
            self.db.commit()
        except:
            self.db.rollback()
        finally:
            cursor.close()

    def get_statistics(self):
        """
        Get overall statistics for blocked IPs

        Returns:
            Dict with statistics
        """
        if not self.db:
            return {}

        cursor = self.db.cursor(cursor_factory=psycopg2.extras.RealDictCursor)

        try:
            cursor.execute("""
                SELECT
                    COUNT(*) FILTER (WHERE active = TRUE) as active_blocks,
                    COUNT(*) FILTER (WHERE active = FALSE) as inactive_blocks,
                    COUNT(DISTINCT added_by) as unique_analysts,
                    COUNT(*) FILTER (WHERE alert_source = 'suricata') as suricata_blocks,
                    COUNT(*) FILTER (WHERE alert_source = 'wazuh') as wazuh_blocks,
                    COUNT(*) FILTER (WHERE threat_type = 'malware_c2') as malware_blocks,
                    COUNT(*) FILTER (WHERE threat_type = 'brute_force') as brute_force_blocks
                FROM firewall_ip_metadata
                WHERE list_type = 'block'
            """)

            return cursor.fetchone()

        except Exception as e:
            print(f"[!] Error fetching statistics: {e}")
            return {}
        finally:
            cursor.close()

    def get_blocked_ips_statistics(self):
        """
        Get detailed statistics for Blocked IPs Management page

        Returns:
            Dict with comprehensive statistics
        """
        if not self.db:
            return {
                'total_blocked': 0,
                'aws_enforced': 0,
                'aws_pending': 0,
                'aws_failed': 0,
                'by_threat_type': {},
                'top_blocked_ips': []
            }

        cursor = self.db.cursor(cursor_factory=psycopg2.extras.RealDictCursor)

        try:
            # Get main statistics
            cursor.execute("""
                SELECT
                    COUNT(*) FILTER (WHERE active = TRUE) as total_blocked,
                    COUNT(*) FILTER (WHERE active = TRUE AND aws_enforced = TRUE) as aws_enforced,
                    COUNT(*) FILTER (WHERE active = TRUE AND aws_enforced = FALSE AND aws_enforcement_error IS NULL) as aws_pending,
                    COUNT(*) FILTER (WHERE active = TRUE AND aws_enforcement_error IS NOT NULL) as aws_failed
                FROM firewall_ip_metadata
                WHERE list_type = 'block'
            """)

            result = cursor.fetchone()
            if result:
                # Convert to regular dict and ensure all values are JSON serializable
                stats = {
                    'total_blocked': int(result['total_blocked']) if result['total_blocked'] is not None else 0,
                    'aws_enforced': int(result['aws_enforced']) if result['aws_enforced'] is not None else 0,
                    'aws_pending': int(result['aws_pending']) if result['aws_pending'] is not None else 0,
                    'aws_failed': int(result['aws_failed']) if result['aws_failed'] is not None else 0
                }
            else:
                stats = {
                    'total_blocked': 0,
                    'aws_enforced': 0,
                    'aws_pending': 0,
                    'aws_failed': 0
                }

            # Get breakdown by threat type
            cursor.execute("""
                SELECT threat_type, COUNT(*) as count
                FROM firewall_ip_metadata
                WHERE list_type = 'block' AND active = TRUE
                GROUP BY threat_type
                ORDER BY count DESC
            """)

            threat_types = {}
            for row in cursor.fetchall():
                threat_types[row['threat_type'] or 'other'] = int(row['count'])

            stats['by_threat_type'] = threat_types

            # Get top blocked IPs by times_seen_in_alerts
            cursor.execute("""
                SELECT ip_address, times_seen_in_alerts, threat_type
                FROM firewall_ip_metadata
                WHERE list_type = 'block' AND active = TRUE
                ORDER BY times_seen_in_alerts DESC
                LIMIT 10
            """)

            top_ips = []
            for row in cursor.fetchall():
                top_ips.append({
                    'ip': str(row['ip_address']),
                    'times_seen': row['times_seen_in_alerts'] or 0,
                    'threat_type': row['threat_type'] or 'other'
                })

            stats['top_blocked_ips'] = top_ips

            return stats

        except Exception as e:
            print(f"[!] Error fetching blocked IPs statistics: {e}")
            import traceback
            traceback.print_exc()
            return {
                'total_blocked': 0,
                'aws_enforced': 0,
                'aws_pending': 0,
                'aws_failed': 0,
                'by_threat_type': {},
                'top_blocked_ips': []
            }
        finally:
            cursor.close()

    def get_blocked_ip_by_id(self, ip_id):
        """
        Get single blocked IP with full details and audit trail

        Args:
            ip_id: UUID of the IP record

        Returns:
            Dict with IP details or None if not found
        """
        if not self.db:
            return None

        cursor = self.db.cursor(cursor_factory=psycopg2.extras.RealDictCursor)

        try:
            cursor.execute("""
                SELECT
                    id, ip_address, ip_cidr, added_at, added_by, reason,
                    threat_type, alert_source, alert_severity, original_alert_id,
                    aws_enforced, aws_enforced_at, aws_enforcement_error,
                    waf_enforced, waf_ip_set, waf_error,
                    times_seen_in_alerts, last_seen_in_alert, active,
                    expires_at, notes, tags, direction, list_type
                FROM firewall_ip_metadata
                WHERE id = %s
            """, [ip_id])

            ip_record = cursor.fetchone()
            if not ip_record:
                return None

            # Get audit trail
            cursor.execute("""
                SELECT action, analyst, timestamp, details, ip_address
                FROM firewall_audit_log
                WHERE ip_address = %s
                ORDER BY timestamp DESC
                LIMIT 50
            """, [ip_record['ip_address']])

            audit_trail = []
            for audit_row in cursor.fetchall():
                audit_trail.append({
                    'action': audit_row['action'],
                    'analyst': audit_row['analyst'],
                    'timestamp': audit_row['timestamp'].isoformat() if audit_row['timestamp'] else None,
                    'details': audit_row['details']
                })

            result = dict(ip_record)
            result['audit_trail'] = audit_trail

            return result

        except Exception as e:
            print(f"[!] Error fetching blocked IP by ID: {e}")
            import traceback
            traceback.print_exc()
            return None
        finally:
            cursor.close()

    def get_ips_by_ids(self, ip_ids):
        """
        Get multiple IPs by their IDs (for bulk operations)

        Args:
            ip_ids: List of UUID strings

        Returns:
            List of IP records
        """
        if not self.db or not ip_ids:
            return []

        cursor = self.db.cursor(cursor_factory=psycopg2.extras.RealDictCursor)

        try:
            # Cast the array elements to UUID to match the id column type
            cursor.execute("""
                SELECT id, ip_address, ip_cidr, threat_type
                FROM firewall_ip_metadata
                WHERE id = ANY(%s::uuid[]) AND active = TRUE
            """, [ip_ids])

            return [dict(row) for row in cursor.fetchall()]

        except Exception as e:
            print(f"[!] Error fetching IPs by IDs: {e}")
            import traceback
            traceback.print_exc()
            return []
        finally:
            cursor.close()
