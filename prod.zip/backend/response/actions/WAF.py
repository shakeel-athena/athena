import os
import sys
import time
from typing import List, Tuple, Optional
from pathlib import Path

from botocore.exceptions import ClientError
from dotenv import load_dotenv

REPO_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), "../../.."))
if REPO_ROOT not in sys.path:
    sys.path.insert(0, REPO_ROOT)

# Import shared AWS client factory for consistent credential management
from shared.infrastructure.aws import AWSClientFactory

from backend.response.models.Geo_blocking import GeoBlockingManager
from backend.response.models.WAF_Rate_Limiter import WAFRateLimiterManager


load_dotenv(dotenv_path=os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))), '.env'))

WAF_BLOCKLIST_NAME = os.getenv("WAF_BLOCKLIST_NAME")
WAF_WEB_ACL=os.getenv("WAF_WEB_ACL")
WAF_GEO_RULE_NAME=os.getenv("WAF_GEO_RULE_NAME")
AWS_SCOPE=os.getenv("AWS_SCOPE")



def _get_wafv2_client():
    """Get a fresh WAFv2 client with current credentials using shared AWS factory"""
    aws_factory = AWSClientFactory()
    return aws_factory.get_waf_client(region="us-east-2")

# Legacy global for backward compatibility - but prefer using _get_wafv2_client()
wafv2 = _get_wafv2_client()

# Helper to safely close the wafv2 client when execution ends

def _close_wafv2_client() -> None:
    close_method = getattr(wafv2, "close", None)
    if callable(close_method):
        try:
            close_method()
        except Exception:
            # Swallow any close errors to not mask real failures
            pass


def _normalize_cidr(ip: str) -> str:
    ip = ip.strip()
    if "/" in ip:
        return ip
    if ":" in ip:
        return f"{ip}/128"
    return f"{ip}/32"



def _find_ip_set(client, name: str, scope: str) -> Tuple[str, str]:
    resp = client.list_ip_sets(Scope=scope)
    for s in resp.get("IPSets", []):
        if s.get("Name") == name:
            return s["Id"], s["ARN"]
    raise RuntimeError(f"IP set '{name}' not found in scope {scope}")



def block_ip(ip: str, ip_set_name: str = "Blocked", scope: str = "REGIONAL", max_retries: int = 3) -> Tuple[bool, bool, Optional[str]]:
    """Add an IP to the specified WAFv2 IP set with retry logic for lock conflicts.

    Args:
        ip: IP address to block (will be normalized to CIDR)
        ip_set_name: Name of the WAF IP set
        scope: REGIONAL or CLOUDFRONT
        max_retries: Maximum retry attempts for lock token conflicts

    Returns:
        Tuple of (success: bool, already_existed: bool, error: str|None)
        - success: True if IP is now in the set (either newly added or already present)
        - already_existed: True if IP was already in the set before this call
        - error: Error message if operation failed, None on success
    """
    for attempt in range(max_retries):
        try:
            # Get fresh client with current credentials
            client = _get_wafv2_client()

            ipset_id, _ = _find_ip_set(client, ip_set_name, scope)
            details = client.get_ip_set(Name=ip_set_name, Scope=scope, Id=ipset_id)
            addresses: List[str] = list(details["IPSet"].get("Addresses", []))
            lock_token = details["LockToken"]

            cidr = _normalize_cidr(ip)

            # IP already blocked - this is SUCCESS, not failure
            if cidr in addresses:
                return (True, True, None)  # success=True, already_existed=True, error=None

            # Add IP to the set
            addresses.append(cidr)
            client.update_ip_set(
                Name=ip_set_name,
                Scope=scope,
                Id=ipset_id,
                LockToken=lock_token,
                Addresses=addresses,
            )
            return (True, False, None)  # success=True, newly_added=True, error=None

        except ClientError as e:
            error_code = e.response.get('Error', {}).get('Code', '')

            # Retry on lock token conflicts (another request modified the IP set)
            if error_code == 'WAFOptimisticLockException' and attempt < max_retries - 1:
                # Exponential backoff: 100ms, 200ms, 400ms
                time.sleep(0.1 * (2 ** attempt))
                continue

            # Other AWS errors or max retries exceeded
            error_msg = f"Failed to update IP set '{ip_set_name}': {str(e)}"
            return (False, False, error_msg)  # success=False, error=message

        except Exception as e:
            # Catch any other unexpected errors
            error_msg = f"Unexpected error blocking IP in WAF: {str(e)}"
            return (False, False, error_msg)

    # Max retries exceeded
    return (False, False, f"Max retries ({max_retries}) exceeded for WAF IP set update")



def unblock_ip(ip: str, ip_set_name: str = "Blocked", scope: str = "REGIONAL", max_retries: int = 3) -> Tuple[bool, bool, Optional[str]]:
    """Remove an IP from the specified WAFv2 IP set with retry logic for lock conflicts.

    Args:
        ip: IP address to unblock (will be normalized to CIDR)
        ip_set_name: Name of the WAF IP set
        scope: REGIONAL or CLOUDFRONT
        max_retries: Maximum retry attempts for lock token conflicts

    Returns:
        Tuple of (success: bool, was_present: bool, error: str|None)
        - success: True if IP is no longer in the set (either removed or wasn't present)
        - was_present: True if IP was in the set before this call
        - error: Error message if operation failed, None on success
    """
    for attempt in range(max_retries):
        try:
            # Get fresh client with current credentials
            client = _get_wafv2_client()

            ipset_id, _ = _find_ip_set(client, ip_set_name, scope)
            details = client.get_ip_set(Name=ip_set_name, Scope=scope, Id=ipset_id)
            addresses: List[str] = list(details["IPSet"].get("Addresses", []))
            lock_token = details["LockToken"]

            cidr = _normalize_cidr(ip)

            # IP not in set - this is SUCCESS (idempotent)
            if cidr not in addresses:
                return (True, False, None)  # success=True, was_not_present=False, error=None

            # Remove IP from the set
            addresses.remove(cidr)
            client.update_ip_set(
                Name=ip_set_name,
                Scope=scope,
                Id=ipset_id,
                LockToken=lock_token,
                Addresses=addresses,
            )
            return (True, True, None)  # success=True, was_removed=True, error=None

        except ClientError as e:
            error_code = e.response.get('Error', {}).get('Code', '')

            # Retry on lock token conflicts
            if error_code == 'WAFOptimisticLockException' and attempt < max_retries - 1:
                time.sleep(0.1 * (2 ** attempt))
                continue

            # Other AWS errors or max retries exceeded
            error_msg = f"Failed to update IP set '{ip_set_name}': {str(e)}"
            return (False, False, error_msg)

        except Exception as e:
            error_msg = f"Unexpected error unblocking IP in WAF: {str(e)}"
            return (False, False, error_msg)

    # Max retries exceeded
    return (False, False, f"Max retries ({max_retries}) exceeded for WAF IP set update")


def list_ip_sets(scope: str = "REGIONAL") -> List[dict]:
    """List all WAF IP sets in the specified scope.

    Returns:
        List of IP set dictionaries with keys: Name, Id, ARN, Description
    """
    client = _get_wafv2_client()

    try:
        response = client.list_ip_sets(Scope=scope)
        ip_sets = []

        for ip_set in response.get("IPSets", []):
            # Get full details for each IP set
            try:
                details = client.get_ip_set(
                    Name=ip_set["Name"],
                    Scope=scope,
                    Id=ip_set["Id"]
                )
                ip_set_info = details["IPSet"]

                ip_sets.append({
                    "name": ip_set_info.get("Name"),
                    "id": ip_set_info.get("Id"),
                    "arn": ip_set_info.get("ARN"),
                    "description": ip_set_info.get("Description", ""),
                    "ip_count": len(ip_set_info.get("Addresses", [])),
                    "ip_address_version": ip_set_info.get("IPAddressVersion", "IPV4")
                })
            except ClientError as e:
                # Log error but continue with other IP sets
                print(f"Error getting details for IP set {ip_set['Name']}: {e}")
                continue

        return ip_sets
    except ClientError as e:
        raise RuntimeError(f"Failed to list IP sets: {e}")


def get_ip_set_ips(ip_set_name: str, scope: str = "REGIONAL") -> dict:
    """Get all IPs in the specified WAF IP set.

    Args:
        ip_set_name: Name of the IP set
        scope: REGIONAL or CLOUDFRONT

    Returns:
        Dictionary with keys: name, id, arn, addresses, ip_count
    """
    client = _get_wafv2_client()

    try:
        ipset_id, ipset_arn = _find_ip_set(client, ip_set_name, scope)
        details = client.get_ip_set(Name=ip_set_name, Scope=scope, Id=ipset_id)
        ip_set_info = details["IPSet"]

        return {
            "name": ip_set_info.get("Name"),
            "id": ip_set_info.get("Id"),
            "arn": ip_set_info.get("ARN"),
            "description": ip_set_info.get("Description", ""),
            "addresses": ip_set_info.get("Addresses", []),
            "ip_count": len(ip_set_info.get("Addresses", [])),
            "ip_address_version": ip_set_info.get("IPAddressVersion", "IPV4")
        }
    except ClientError as e:
        raise RuntimeError(f"Failed to get IP set '{ip_set_name}': {e}")


def add_geo_countries(wafv2, web_acl_name: str, codes: List[str],rule_name: Optional[str] = None, scope: str = "REGIONAL") -> List[str]:
    mgr = GeoBlockingManager(wafv2=wafv2, scope=scope)
    return mgr.add_countries(codes, web_acl_name, rule_name)



def remove_geo_countries(wafv2, web_acl_name: str, codes: List[str],rule_name: Optional[str] = None, scope: str = "REGIONAL") -> List[str]:
    mgr = GeoBlockingManager(wafv2=wafv2, scope=scope)
    return mgr.remove_countries(codes, web_acl_name, rule_name)




def test_block_ip():

    test_ip = "203.0.113.10/32"

    updated = block_ip(test_ip, ip_set_name=WAF_BLOCKLIST_NAME, scope=AWS_SCOPE)

    if updated:             
        print(f"IP {test_ip} added to blocklist '{WAF_BLOCKLIST_NAME}'")
    else:
        print(f"IP {test_ip} already in blocklist '{WAF_BLOCKLIST_NAME}'")



def test_add_geo_countries():
   
    country_to_add = "AT"
    country_to_remove = "AF"


    mgr = GeoBlockingManager(wafv2=wafv2, scope=AWS_SCOPE)

    before = mgr.get_countries(WAF_WEB_ACL, WAF_GEO_RULE_NAME)
    print("Before:", " ".join(before))

    mgr.remove_countries([country_to_remove], WAF_WEB_ACL, WAF_GEO_RULE_NAME)

    before = mgr.get_countries(WAF_WEB_ACL, WAF_GEO_RULE_NAME)
    print(f"After Removing: {country_to_remove} ")
    print(sorted(before))
    
    mgr.add_countries([country_to_add], WAF_WEB_ACL, WAF_GEO_RULE_NAME)

    before = mgr.get_countries(WAF_WEB_ACL, WAF_GEO_RULE_NAME)
    print(f"After Adding: {country_to_add}"  )
    print(sorted(before))


def test_rate_limiter_settings():

   
    new_limit = 90
    new_window = 120

    mgr = WAFRateLimiterManager(wafv2=wafv2, scope=AWS_SCOPE)

    print(f"Fetching current rate limiter settings for ACL '{WAF_WEB_ACL}'...")

    current = mgr.get_current_settings(WAF_WEB_ACL)

    print(f"Current: Limit={current.get('Limit')}, WindowSec={current.get('EvaluationWindowSec')}")

    # Only perform update if env vars provided
    if new_limit is not None or new_window is not None:
        
        limit_val = int(new_limit) 
        window_val = int(new_window) 

        print("Updating rate limiter settings...")
        updated = (
            mgr.set_limit_and_window(WAF_WEB_ACL, limit_val if limit_val is not None else current.get("Limit"),
                                      window_val if window_val is not None else current.get("EvaluationWindowSec"))
            if (limit_val is not None and window_val is not None)
            else (mgr.set_limit(WAF_WEB_ACL, limit_val) if limit_val is not None else mgr.set_window(WAF_WEB_ACL, window_val))
        )
        print(f"Updated: Limit={updated.get('Limit')}, WindowSec={updated.get('EvaluationWindowSec')}")
    else:
        print("No NEW_RATE_LIMIT/NEW_RATE_WINDOW provided; not updating.")

def test_firewall_ip_blocking():
    """Test Network Firewall IP blocking and allowing functionality."""
    from backend.response.models.Firewall_IP_Blocking import FirewallIPBlockingManager
    
    # Use the same session as WAF for consistent AWS credentials
    mgr = FirewallIPBlockingManager(session=session, region_name="us-east-2", rule_group_name="allow-ingress")
    
    print("=== Network Firewall IP Blocking Test ===")
    
    # Test IPs
    test_allow_ips = ["2.2.2.2"]
    test_block_ips = ["1.1.1.1"]
    
    try:
        # First, run debug to see what resources are available
        #mgr.debug_list_available_resources()
        
        print(f"Current ALLOW_NET IPs: {mgr.get_allow_ips()}")
        print(f"Current BLOCK_NET IPs: {mgr.get_block_ips()}")
        
        # Add IPs to allow list
        print(f"\nAdding IPs to ALLOW_NET: {test_allow_ips}")
        added_allow = mgr.add_allow_ips(test_allow_ips)
        print(f"Added to ALLOW_NET: {added_allow}")
        
        # Add IPs to block list
        print(f"\nAdding IPs to BLOCK_NET: {test_block_ips}")
        added_block = mgr.add_block_ips(test_block_ips)
        print(f"Added to BLOCK_NET: {added_block}")
        
        # Show current state
        #print(f"\nCurrent ALLOW_NET IPs: {mgr.get_allow_ips()}")
        #print(f"Current BLOCK_NET IPs: {mgr.get_block_ips()}")
        
        # Remove some IPs
        #print(f"\nRemoving IPs from ALLOW_NET: {test_allow_ips[:1]}")
        #removed_allow = mgr.remove_allow_ips(test_allow_ips[:1])
        #print(f"Removed from ALLOW_NET: {removed_allow}")
        
        #print(f"\nRemoving IPs from BLOCK_NET: {test_block_ips[:1]}")
        #removed_block = mgr.remove_block_ips(test_block_ips[:1])
        #print(f"Removed from BLOCK_NET: {removed_block}")
        
        # Final state
        print(f"\nFinal ALLOW_NET IPs: {mgr.get_allow_ips()}")
        print(f"Final BLOCK_NET IPs: {mgr.get_block_ips()}")
        
        # Get all IPs
        all_ips = mgr.get_all_ips()
        print(f"\nAll IPs summary: {all_ips}")
        
    except Exception as e:
        print(f"Network Firewall test failed: {e}")
        print("Note: Make sure you have AWS Network Firewall permissions and the 'test-allow-ingress' rule group exists.")



if __name__ == "__main__":


#-----IP Blocking-------------

    try:
        #test_block_ip()
    

#----------Geo-Blocking-----------------------------

        #test_add_geo_countries()
        
#--------------Rate Limiter-------------------------

        #test_rate_limiter_settings()

#--------------Firewall IP Blocking------------------

        test_firewall_ip_blocking()

#---------------------------------------------------
    finally:
        _close_wafv2_client()
        
