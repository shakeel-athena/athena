import boto3
import os
import json
from dotenv import load_dotenv

load_dotenv(dotenv_path=os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))), '.env'))

# AWS Configuration
AWS_ACCESS_KEY_ID = os.getenv("AWS_ACCESS_KEY_ID")
AWS_SECRET_ACCESS_KEY = os.getenv("AWS_SECRET_ACCESS_KEY")
AWS_REGION = os.getenv("AWS_REGION")
AWS_SESSION_TOKEN = os.getenv("AWS_SESSION_TOKEN")
AWS_PROFILE = os.getenv("AWS_PROFILE")

session = boto3.Session(profile_name=AWS_PROFILE, region_name="us-east-2")
print(f"Session: {session}")

# Create a Network Firewall client
network_firewall = session.client("network-firewall")

def list_stateful_rule_groups():
    """List all stateful rule groups"""
    print("Fetching Stateful Rule Groups...\n")
    try:
        response = network_firewall.list_rule_groups()
        for rule_group in response.get("RuleGroups", []):
            print(f"Name: {rule_group['Name']} | ARN: {rule_group['Arn']}")
        return response.get("RuleGroups", [])
    except Exception as e:
        print(f"Error listing rule groups: {e}")
        return []

def get_geo_restrictions_rule_group():
    """Get the geo-restrictions stateful rule group"""
    print("\nLooking for 'geo-restrictions' rule group...\n")
    try:
        rule_groups = list_stateful_rule_groups()
        geo_rule_group = None
        
        for rule_group in rule_groups:
            if rule_group['Name'] == 'geo-restrictions':
                geo_rule_group = rule_group
                break
        
        if geo_rule_group:
            print(f"Found geo-restrictions rule group: {geo_rule_group['Arn']}")
            return geo_rule_group
        else:
            print("geo-restrictions rule group not found!")
            return None
    except Exception as e:
        print(f"Error finding geo-restrictions rule group: {e}")
        return None

def get_rule_group_details(rule_group_name):
    """Get detailed information about a specific rule group"""
    try:
        response = network_firewall.describe_rule_group(
            RuleGroupName=rule_group_name,
            Type='STATEFUL'
        )
        return response
    except Exception as e:
        print(f"Error getting rule group details: {e}")
        return None

def display_country_rules(rule_group_details):
    """Display the country allow rules from the rule group"""
    if not rule_group_details:
        return
    
    print("\n=== GEO-RESTRICTIONS RULE GROUP DETAILS ===")
    rule_group = rule_group_details.get('RuleGroup', {})
    rules_source = rule_group.get('RulesSource', {})
    
    print(f"Rule Group Name: {rule_group.get('RuleGroupName', 'N/A')}")
    print(f"Capacity: {rule_group.get('Capacity', 'N/A')}")
    
    # Check for stateful rules
    stateful_rules = rules_source.get('StatefulRules', [])
    if stateful_rules:
        print(f"\nNumber of Stateful Rules: {len(stateful_rules)}")
        print("\n=== COUNTRY ALLOW RULES ===")
        
        for i, rule in enumerate(stateful_rules, 1):
            action = rule.get('Action', 'N/A')
            header = rule.get('Header', {})
            rule_options = rule.get('RuleOptions', [])
            
            print(f"\nRule {i}:")
            print(f"  Action: {action}")
            print(f"  Protocol: {header.get('Protocol', 'N/A')}")
            print(f"  Source: {header.get('Source', 'N/A')}")
            print(f"  Destination: {header.get('Destination', 'N/A')}")
            print(f"  Source Port: {header.get('SourcePort', 'N/A')}")
            print(f"  Destination Port: {header.get('DestinationPort', 'N/A')}")
            print(f"  Direction: {header.get('Direction', 'N/A')}")
            
            # Display rule options (this is where country codes might be)
            if rule_options:
                print("  Rule Options:")
                for option in rule_options:
                    print(f"    Keyword: {option.get('Keyword', 'N/A')}")
                    print(f"    Settings: {option.get('Settings', 'N/A')}")
    else:
        print("\nNo stateful rules found in this rule group.")
        
        # Check for rules string (Suricata rules)
        rules_string = rules_source.get('RulesString', '')
        if rules_string:
            print("\n=== SURICATA RULES ===")
            print("Rules String:")
            print(rules_string)

def update_country_rules(rule_group_name, new_countries):
    """Update the country allow rules in the rule group"""
    try:
        # First get current rule group details
        current_details = get_rule_group_details(rule_group_name)
        if not current_details:
            print("Could not retrieve current rule group details")
            return False
        
        # This is a simplified example - you would need to construct the proper rule format
        # based on your current rule structure
        print(f"\nTo update country rules, you would need to:")
        print(f"1. Modify the rules in the rule group")
        print(f"2. Use update_rule_group() API call")
        print(f"3. New countries to allow: {new_countries}")
        
        # Note: Actual implementation would require understanding the current rule format
        # and constructing new rules accordingly
        
        return True
    except Exception as e:
        print(f"Error updating country rules: {e}")
        return False

def main():
    """Main function to check and manage geo-restrictions rule group"""
    print("=== AWS Network Firewall Geo-Restrictions Manager ===\n")
    
    # Find the geo-restrictions rule group
    geo_rule_group = get_geo_restrictions_rule_group()
    
    if geo_rule_group:
        # Get detailed information
        rule_group_details = get_rule_group_details('geo-restrictions')
        
        if rule_group_details:
            # Display current country rules
            display_country_rules(rule_group_details)
            
            # Example of how to update countries (you would implement this based on your needs)
            print("\n=== UPDATE FUNCTIONALITY ===")
            print("To add/remove countries, you can modify the rules and use update_rule_group()")
            print("Example countries to allow: ['US', 'CA', 'GB', 'DE', 'FR']")
            
            # Uncomment the line below to actually update (be careful!)
            # update_country_rules('geo-restrictions', ['US', 'CA', 'GB', 'DE', 'FR'])
        else:
            print("Could not retrieve rule group details")
    else:
        print("geo-restrictions rule group not found. Available rule groups:")
        list_stateful_rule_groups()

if __name__ == "__main__":
    main()
