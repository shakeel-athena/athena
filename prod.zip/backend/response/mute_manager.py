"""
Athena Security Platform - Mute Rules Manager
Handles alert suppression for both Wazuh and Suricata events
"""

import psycopg2
import psycopg2.extras
from datetime import datetime, timedelta
import ipaddress
import json
import os


class MuteManager:
    """
    Manages mute rules for unified Wazuh/Suricata alerts
    Supports flexible JSONB conditions and CIDR matching
    """

    def __init__(self, db_connection=None):
        """
        Initialize MuteManager

        Args:
            db_connection: PostgreSQL connection object (optional)
        """
        self.db = db_connection
        self._should_close_db = False

        # If no connection provided, create one
        if self.db is None:
            self.db = self._get_db_connection()
            self._should_close_db = True

    def _get_db_connection(self):
        """Get PostgreSQL connection from environment variables"""
        try:
            return psycopg2.connect(
                host=os.getenv('POSTGRES_HOST', 'localhost'),
                database=os.getenv('POSTGRES_DB', 'athena_db'),
                user=os.getenv('POSTGRES_USER', 'athena_user'),
                password=os.getenv('POSTGRES_PASSWORD', 'athena_pass'),
                port=os.getenv('POSTGRES_PORT', '5432')
            )
        except Exception as e:
            print(f"[!] Warning: Could not connect to database: {e}")
            return None

    def __del__(self):
        """Close database connection if we created it"""
        if self._should_close_db and self.db:
            try:
                self.db.close()
            except:
                pass

    def create_mute_rule(self, conditions, classification, reason, analyst,
                        duration_hours=None, source_type=None,
                        original_alert_id=None, scope='global'):
        """
        Create a new mute rule

        Args:
            conditions (dict): Mute criteria
            classification (str): Why muting (false_positive, benign_positive, etc.)
            reason (str): Required justification
            analyst (str): Username creating the rule
            duration_hours (int): Auto-expire after X hours (None = permanent)
            source_type (str): 'wazuh', 'suricata', or 'both'
            original_alert_id (str): Alert that triggered this mute
            scope (str): 'personal', 'team', or 'global'

        Returns:
            dict: Created rule details including approval status
        """

        if not self.db:
            raise Exception("Database connection not available")

        # Calculate expiration
        expires_at = None
        if duration_hours:
            expires_at = datetime.now() + timedelta(hours=duration_hours)

        # Check if approval required
        approval_status, requires_approval = self._check_approval_required(
            conditions,
            classification,
            duration_hours
        )

        # Determine active status
        active = (approval_status == 'auto_approved')

        # Set scope_user and scope_team based on scope
        scope_user = analyst if scope == 'personal' else None
        scope_team = None  # TODO: Get team from analyst's profile

        # Check for conflicting rules (non-blocking, returns warnings)
        conflicts = self.check_for_conflicts(conditions, scope, scope_user)

        cursor = self.db.cursor()
        try:
            # Proceed with insert regardless of conflicts (warnings only)
            conditions_json = json.dumps(conditions)
            cursor.execute("""
                INSERT INTO mute_rules
                (conditions, classification, created_by, reason, expires_at,
                 approval_status, active, scope, scope_user, scope_team,
                 source_type, original_alert_id)
                VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
                RETURNING id, created_at
            """, [
                conditions_json,
                classification,
                analyst,
                reason,
                expires_at,
                approval_status,
                active,
                scope,
                scope_user,
                scope_team,
                source_type,
                original_alert_id
            ])

            rule_id, created_at = cursor.fetchone()
            self.db.commit()

            # Audit log with alert context
            alert_severity = None
            alert_source = source_type
            source_ip = None

            # Extract severity and IP from conditions if available
            if 'severity' in conditions:
                alert_severity = conditions['severity']
            if 'source_ip' in conditions:
                source_ip = conditions['source_ip']
            elif 'source_ip_cidr' in conditions:
                # Use CIDR range as reference
                source_ip = conditions['source_ip_cidr'].split('/')[0]

            self._log_audit(
                action='mute_rule_created',
                analyst=analyst,
                mute_rule_id=rule_id,
                alert_id=original_alert_id,
                alert_severity=alert_severity,
                alert_source=alert_source,
                ip_address=source_ip,
                details={
                    'conditions': conditions,
                    'classification': classification,
                    'reason': reason,
                    'approval_required': requires_approval,
                    'duration_hours': duration_hours
                }
            )

            # Trigger Suricata sync if rule is for Suricata or both
            if source_type in ['suricata', 'both', None] and active:
                try:
                    # Import here to avoid circular imports
                    import sys
                    import os
                    sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'src'))
                    from integrations.suricata_sync import SuricataSyncService

                    sync_service = SuricataSyncService(self.db)
                    result = sync_service.sync_mute_rules()

                    if result.get('skipped'):
                        # Rules unchanged, sync skipped (happens during cron if no changes)
                        print(f"[Mute Manager] Suricata sync skipped (no changes)")
                    elif result['success']:
                        # Rules changed, synced to Suricata
                        print(f"[Mute Manager] Synced {result['rules_synced']} rules to Suricata in {result['duration_ms']}ms")
                    else:
                        print(f"[Mute Manager] Suricata sync failed, Tier 4 (API filter) still active")

                except Exception as e:
                    # Don't fail mute creation if sync fails
                    # Tier 4 (API filter) provides immediate suppression
                    print(f"[Mute Manager] Warning: Suricata sync error: {e}")

            # Trigger Wazuh sync if rule is for Wazuh or both
            if source_type in ['wazuh', 'both', None] and active:
                try:
                    # Import here to avoid circular imports
                    import sys
                    import os
                    sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'src'))
                    from integrations.wazuh_sync import WazuhSyncService

                    sync_service = WazuhSyncService(self.db)
                    result = sync_service.sync_mute_rules()

                    if result.get('skipped'):
                        # Rules unchanged, sync skipped (happens during cron if no changes)
                        print(f"[Mute Manager] Wazuh sync skipped (no changes)")
                    elif result['success']:
                        # Rules changed, synced to Wazuh
                        print(f"[Mute Manager] Synced {result['ip_rules_synced']} IP rules, {result['rule_suppressions_synced']} rule overrides to Wazuh in {result['duration_ms']}ms")
                    else:
                        print(f"[Mute Manager] Wazuh sync failed, Tier 4 (API filter) still active")

                except Exception as e:
                    # Don't fail mute creation if sync fails
                    # Tier 4 (API filter) provides immediate suppression
                    print(f"[Mute Manager] Warning: Wazuh sync error: {e}")

            return {
                'id': str(rule_id),
                'created_at': created_at.isoformat(),
                'expires_at': expires_at.isoformat() if expires_at else None,
                'approval_status': approval_status,
                'requires_approval': requires_approval,
                'active': active,
                'conflicts': conflicts  # Include conflict warnings (non-blocking)
            }
        except Exception as e:
            self.db.rollback()
            raise e
        finally:
            cursor.close()

    def _check_approval_required(self, conditions, classification, duration_hours):
        """
        Determine if mute rule requires senior analyst approval

        Simplified: All mutes are auto-approved (no approval workflow)
        """
        # Always auto-approve all mute rules
        return 'auto_approved', False

    def apply_mute_rules(self, alerts, analyst=None, scope='global'):
        """
        Filter out muted alerts based on active rules (optimized with indexed lookup)

        Args:
            alerts (list): List of normalized alert dicts
            analyst (str): Current analyst (for personal scope filtering)
            scope (str): Filter by scope

        Returns:
            list: Filtered alerts (non-muted only)
        """

        if not self.db or not alerts:
            return alerts

        # Get active mute rules
        cursor = self.db.cursor(cursor_factory=psycopg2.extras.DictCursor)

        try:
            scope_filter = ""
            params = []

            if scope == 'personal' and analyst:
                scope_filter = "AND (scope = 'global' OR (scope = 'personal' AND scope_user = %s))"
                params.append(analyst)
            elif scope == 'team':
                # TODO: Add team membership lookup
                scope_filter = "AND scope IN ('global', 'team')"
            else:
                scope_filter = "AND scope = 'global'"

            cursor.execute(f"""
                SELECT id, conditions FROM mute_rules
                WHERE active = TRUE
                AND approval_status IN ('auto_approved', 'approved')
                AND (expires_at IS NULL OR expires_at > NOW())
                {scope_filter}
            """, params)

            mute_rules = cursor.fetchall()

            if not mute_rules:
                return alerts

            # Build indexed lookup for common exact-match conditions (O(1) access)
            # This reduces O(n*m) to O(n) for most cases
            mute_index = {
                'signature_id': {},  # Suricata
                'rule_id': {},       # Wazuh
                'source_ip': {},     # Network alerts
                'severity': {},      # All alerts
                'category': {}       # All alerts
            }

            # Rules that require full scan (CIDR, complex conditions)
            complex_rules = []

            for rule in mute_rules:
                conditions = rule['conditions']
                rule_entry = {'id': rule['id'], 'conditions': conditions}

                # Check if rule has indexable single condition
                indexable_keys = set(conditions.keys()) & set(mute_index.keys())

                # If rule has CIDR conditions, it needs full scan
                has_cidr = 'source_ip_cidr' in conditions or 'dest_ip_cidr' in conditions

                if has_cidr or len(conditions) > 1 or not indexable_keys:
                    # Complex rule - requires full condition check
                    complex_rules.append(rule_entry)
                else:
                    # Simple exact-match rule - can be indexed
                    for key in indexable_keys:
                        value = str(conditions[key])  # Normalize to string for lookup
                        if value not in mute_index[key]:
                            mute_index[key][value] = []
                        mute_index[key][value].append(rule_entry)

            # Track matched rules for batch metrics update
            matched_rule_ids = set()

            # Filter alerts using indexed lookup
            visible_alerts = []

            for alert in alerts:
                is_muted = False

                # Try indexed lookup first (fast path - O(1))
                candidate_rules = []

                # Check signature_id index (Suricata)
                sig_id = alert.get('signature_id')
                if sig_id:
                    candidate_rules.extend(mute_index['signature_id'].get(str(sig_id), []))

                # Check rule_id index (Wazuh)
                rule_id = alert.get('rule_id')
                if rule_id:
                    candidate_rules.extend(mute_index['rule_id'].get(str(rule_id), []))

                # Check source_ip index
                src_ip = alert.get('src_ip')
                if src_ip:
                    candidate_rules.extend(mute_index['source_ip'].get(str(src_ip), []))

                # Check severity index
                severity = alert.get('normalized_severity')
                if severity:
                    candidate_rules.extend(mute_index['severity'].get(str(severity), []))

                # Check category index
                category = alert.get('category')
                if category:
                    candidate_rules.extend(mute_index['category'].get(str(category), []))

                # Check indexed candidates
                for rule_entry in candidate_rules:
                    if self._alert_matches_conditions(alert, rule_entry['conditions']):
                        is_muted = True
                        matched_rule_ids.add(rule_entry['id'])
                        break

                # If not muted by indexed rules, check complex rules (CIDR, multi-condition)
                if not is_muted:
                    for rule_entry in complex_rules:
                        if self._alert_matches_conditions(alert, rule_entry['conditions']):
                            is_muted = True
                            matched_rule_ids.add(rule_entry['id'])
                            break

                if not is_muted:
                    visible_alerts.append(alert)

            # Batch update metrics for all matched rules (one DB operation)
            if matched_rule_ids:
                self._batch_update_mute_metrics(list(matched_rule_ids))

            return visible_alerts

        except Exception as e:
            print(f"[!] Error applying mute rules: {e}")
            return alerts  # Return all alerts if error
        finally:
            cursor.close()

    def _alert_matches_conditions(self, alert, conditions):
        """
        Check if alert matches ALL conditions in mute rule (AND logic)

        Args:
            alert (dict): Normalized alert
            conditions (dict): Mute rule conditions

        Returns:
            bool: True if ALL conditions match
        """

        # Check each condition
        for key, value in conditions.items():

            # Rule ID (Wazuh)
            if key == 'rule_id':
                if str(alert.get('rule_id')) != str(value):
                    return False

            # Signature ID (Suricata)
            elif key == 'signature_id':
                if str(alert.get('signature_id')) != str(value):
                    return False

            # Source IP (exact match)
            elif key == 'source_ip':
                if alert.get('src_ip') != value:
                    return False

            # Source IP CIDR range
            elif key == 'source_ip_cidr':
                try:
                    alert_ip = ipaddress.ip_address(alert.get('src_ip', ''))
                    network = ipaddress.ip_network(value)
                    if alert_ip not in network:
                        return False
                except:
                    return False

            # Destination IP (exact match)
            elif key == 'dest_ip':
                if alert.get('dest_ip') != value:
                    return False

            # Destination IP CIDR range
            elif key == 'dest_ip_cidr':
                try:
                    alert_ip = ipaddress.ip_address(alert.get('dest_ip', ''))
                    network = ipaddress.ip_network(value)
                    if alert_ip not in network:
                        return False
                except:
                    return False

            # Severity (normalized)
            elif key == 'severity':
                if alert.get('normalized_severity') != value:
                    return False

            # Category
            elif key == 'category':
                if alert.get('category') != value:
                    return False

            # Agent (Wazuh)
            elif key == 'agent_name':
                if alert.get('agent_name') != value:
                    return False

            # Sensor (Suricata)
            elif key == 'sensor_hostname':
                sensor = alert.get('raw', {}).get('node', {}).get('hostname')
                if sensor != value:
                    return False

        # All conditions matched
        return True

    def _update_mute_metrics(self, rule_id):
        """Update hit_count and last_matched_at for a mute rule"""
        if not self.db:
            return

        cursor = self.db.cursor()
        try:
            cursor.execute("""
                UPDATE mute_rules
                SET hit_count = hit_count + 1,
                    last_matched_at = NOW(),
                    first_matched_at = COALESCE(first_matched_at, NOW())
                WHERE id = %s
            """, [rule_id])
            self.db.commit()
        except:
            self.db.rollback()
        finally:
            cursor.close()

    def _batch_update_mute_metrics(self, rule_ids):
        """Batch update hit_count and last_matched_at for multiple mute rules (performance optimization)

        Args:
            rule_ids (list): List of rule IDs that matched alerts
        """
        if not self.db or not rule_ids:
            return

        cursor = self.db.cursor()
        try:
            # Count occurrences of each rule ID (for rules that matched multiple alerts)
            from collections import Counter
            rule_counts = Counter(rule_ids)

            # Build batch update using unnest for efficiency
            # This updates all rules in a single query instead of N individual queries
            ids = list(rule_counts.keys())
            counts = [rule_counts[rid] for rid in ids]

            cursor.execute("""
                UPDATE mute_rules
                SET hit_count = hit_count + data.count,
                    last_matched_at = NOW(),
                    first_matched_at = COALESCE(first_matched_at, NOW())
                FROM (
                    SELECT UNNEST(%s::uuid[]) AS id, UNNEST(%s::integer[]) AS count
                ) AS data
                WHERE mute_rules.id = data.id
            """, [ids, counts])
            self.db.commit()
        except Exception as e:
            print(f"[!] Error batch updating mute metrics: {e}")
            self.db.rollback()
        finally:
            cursor.close()

    def _log_audit(self, action, analyst, mute_rule_id=None, alert_id=None,
                   alert_severity=None, alert_source=None, ip_address=None, details=None):
        """
        Write to audit log with full context

        Args:
            action: Type of action (mute_rule_created, approved, etc.)
            analyst: Username performing action
            mute_rule_id: UUID of mute rule
            alert_id: Original alert ID that triggered mute
            alert_severity: Critical/High/Medium/Low
            alert_source: wazuh/suricata
            ip_address: Source IP from alert
            details: Additional JSONB details
        """
        if not self.db:
            return

        cursor = self.db.cursor()
        try:
            cursor.execute("""
                INSERT INTO mute_audit_log
                (action, analyst, mute_rule_id, alert_id, alert_severity, alert_source, ip_address, details)
                VALUES (%s, %s, %s, %s, %s, %s, %s, %s)
            """, [
                action,
                analyst or 'system',
                mute_rule_id,
                alert_id,
                alert_severity,
                alert_source,
                ip_address,
                json.dumps(details or {})
            ])
            self.db.commit()
        except Exception as e:
            print(f"[!] Error logging audit: {e}")
            self.db.rollback()
        finally:
            cursor.close()

    def get_mute_rules(self, active_only=True, pending_approval_only=False):
        """Get all mute rules (for management page)"""
        if not self.db:
            return []

        cursor = self.db.cursor(cursor_factory=psycopg2.extras.RealDictCursor)

        try:
            filters = []
            if active_only:
                filters.append("active = TRUE")
            if pending_approval_only:
                filters.append("approval_status = 'pending_approval'")

            where_clause = "WHERE " + " AND ".join(filters) if filters else ""

            cursor.execute(f"""
                SELECT * FROM mute_rules
                {where_clause}
                ORDER BY created_at DESC
            """)

            return cursor.fetchall()
        except:
            return []
        finally:
            cursor.close()

    def approve_mute_rule(self, rule_id, approver):
        """Approve a pending mute rule"""
        if not self.db:
            raise Exception("Database connection not available")

        cursor = self.db.cursor()
        try:
            cursor.execute("""
                UPDATE mute_rules
                SET approval_status = 'approved',
                    approved_by = %s,
                    approved_at = NOW(),
                    active = TRUE
                WHERE id = %s AND approval_status = 'pending_approval'
            """, [approver, rule_id])
            self.db.commit()

            self._log_audit('mute_rule_approved', approver, rule_id, {})
        except Exception as e:
            self.db.rollback()
            raise e
        finally:
            cursor.close()

    def reject_mute_rule(self, rule_id, approver, reason):
        """Reject a pending mute rule"""
        if not self.db:
            raise Exception("Database connection not available")

        cursor = self.db.cursor()
        try:
            cursor.execute("""
                UPDATE mute_rules
                SET approval_status = 'rejected',
                    approved_by = %s,
                    approved_at = NOW(),
                    active = FALSE
                WHERE id = %s AND approval_status = 'pending_approval'
            """, [approver, rule_id])
            self.db.commit()

            self._log_audit('mute_rule_rejected', approver, rule_id, {'reason': reason})
        except Exception as e:
            self.db.rollback()
            raise e
        finally:
            cursor.close()

    def delete_mute_rule(self, rule_id, analyst):
        """Delete a mute rule"""
        if not self.db:
            raise Exception("Database connection not available")

        cursor = self.db.cursor()
        try:
            cursor.execute("UPDATE mute_rules SET active = FALSE WHERE id = %s", [rule_id])
            self.db.commit()

            self._log_audit('mute_rule_deleted', analyst, rule_id, {})
        except Exception as e:
            self.db.rollback()
            raise e
        finally:
            cursor.close()

    def check_for_conflicts(self, conditions, scope='global', scope_user=None):
        """
        Check for conflicting or redundant mute rules

        Args:
            conditions (dict): New rule conditions to check
            scope (str): Scope of new rule (personal, team, global)
            scope_user (str): User for personal scope

        Returns:
            list: List of conflict warnings with details
        """
        if not self.db:
            return []

        conflicts = []
        cursor = self.db.cursor(cursor_factory=psycopg2.extras.RealDictCursor)

        try:
            # Get all active rules
            cursor.execute("""
                SELECT id, conditions, created_by, created_at, expires_at, scope, scope_user
                FROM mute_rules
                WHERE active = TRUE
                  AND approval_status IN ('auto_approved', 'approved')
                  AND (expires_at IS NULL OR expires_at > NOW())
            """)

            existing_rules = cursor.fetchall()

            for rule in existing_rules:
                existing_conditions = rule['conditions']
                conflict_type = self._detect_conflict(conditions, existing_conditions, scope, scope_user, rule)

                if conflict_type:
                    expires_msg = "Permanent" if not rule['expires_at'] else f"Expires {rule['expires_at'].strftime('%Y-%m-%d %H:%M')}"
                    conflicts.append({
                        'rule_id': str(rule['id']),
                        'type': conflict_type,
                        'created_by': rule['created_by'],
                        'created_at': rule['created_at'].strftime('%Y-%m-%d %H:%M'),
                        'expires': expires_msg,
                        'scope': rule['scope'],
                        'existing_conditions': existing_conditions,
                        'message': self._format_conflict_message(conflict_type, existing_conditions, rule)
                    })

            return conflicts

        except Exception as e:
            print(f"[!] Error checking conflicts: {e}")
            return []
        finally:
            cursor.close()

    def _detect_conflict(self, new_cond, existing_cond, new_scope, new_scope_user, existing_rule):
        """
        Detect if two condition sets conflict

        Returns:
            str: Conflict type ('exact', 'overlapping_cidr', 'broader', 'narrower') or None
        """

        # Skip personal scope rules from other users
        if existing_rule['scope'] == 'personal' and existing_rule['scope_user'] != new_scope_user:
            return None

        # 1. Exact match
        if new_cond == existing_cond:
            return 'exact'

        # 2. Check CIDR overlaps
        cidr_conflict = self._check_cidr_conflict(new_cond, existing_cond)
        if cidr_conflict:
            return cidr_conflict

        # 3. Check if one rule is broader/narrower (subset of conditions)
        if self._is_broader_rule(new_cond, existing_cond):
            return 'broader'  # New rule is broader than existing
        elif self._is_broader_rule(existing_cond, new_cond):
            return 'narrower'  # New rule is narrower (more specific)

        # 4. Check partial overlap (some conditions match)
        matching_conditions = []
        for key in new_cond.keys():
            if key in existing_cond and new_cond[key] == existing_cond[key]:
                matching_conditions.append(key)

        if len(matching_conditions) > 0 and len(matching_conditions) < max(len(new_cond), len(existing_cond)):
            return 'partial_overlap'

        return None

    def _check_cidr_conflict(self, new_cond, existing_cond):
        """Check for CIDR range conflicts"""
        try:
            # Check source_ip_cidr conflicts
            if 'source_ip_cidr' in new_cond and 'source_ip_cidr' in existing_cond:
                new_net = ipaddress.ip_network(new_cond['source_ip_cidr'])
                existing_net = ipaddress.ip_network(existing_cond['source_ip_cidr'])

                if new_net == existing_net:
                    return 'exact_cidr'
                elif new_net.overlaps(existing_net):
                    if new_net.subnet_of(existing_net):
                        return 'cidr_subnet'  # New is smaller subnet of existing
                    elif existing_net.subnet_of(new_net):
                        return 'cidr_supernet'  # New contains existing
                    else:
                        return 'overlapping_cidr'

            # Check if new source_ip is in existing CIDR
            if 'source_ip' in new_cond and 'source_ip_cidr' in existing_cond:
                ip = ipaddress.ip_address(new_cond['source_ip'])
                network = ipaddress.ip_network(existing_cond['source_ip_cidr'])
                if ip in network:
                    return 'ip_in_cidr'

            # Check if new CIDR contains existing source_ip
            if 'source_ip_cidr' in new_cond and 'source_ip' in existing_cond:
                ip = ipaddress.ip_address(existing_cond['source_ip'])
                network = ipaddress.ip_network(new_cond['source_ip_cidr'])
                if ip in network:
                    return 'cidr_contains_ip'

        except (ValueError, KeyError):
            pass

        return None

    def _is_broader_rule(self, cond1, cond2):
        """
        Check if cond1 is broader than cond2 (cond1 has fewer conditions, making it less specific)

        Returns:
            bool: True if cond1 is subset of cond2 (broader)
        """
        if len(cond1) >= len(cond2):
            return False

        # Check if all conditions in cond1 exist in cond2 with same values
        for key, value in cond1.items():
            if key not in cond2 or cond2[key] != value:
                return False

        return True

    def _format_conflict_message(self, conflict_type, existing_conditions, rule):
        """Format user-friendly conflict message"""
        cond_str = ', '.join([f"{k.replace('_', ' ')}: {v}" for k, v in existing_conditions.items()])

        messages = {
            'exact': f"Identical rule already exists with conditions: {cond_str}",
            'exact_cidr': f"Rule with same CIDR range already exists: {cond_str}",
            'overlapping_cidr': f"Rule with overlapping CIDR range exists: {cond_str}",
            'cidr_subnet': f"Your CIDR is a subnet of existing rule: {cond_str}",
            'cidr_supernet': f"Your CIDR contains an existing rule: {cond_str}",
            'ip_in_cidr': f"This IP is already covered by existing CIDR rule: {cond_str}",
            'cidr_contains_ip': f"Your CIDR would cover an existing IP rule: {cond_str}",
            'broader': f"A broader rule already exists (fewer conditions): {cond_str}",
            'narrower': f"A more specific rule already exists (more conditions): {cond_str}",
            'partial_overlap': f"Rule with partial overlap exists: {cond_str}"
        }

        return messages.get(conflict_type, f"Similar rule exists: {cond_str}")

    def expire_old_rules(self):
        """
        Cron job: Mark expired rules as inactive
        Should run every hour
        """
        if not self.db:
            return 0

        cursor = self.db.cursor()
        try:
            cursor.execute("""
                UPDATE mute_rules
                SET active = FALSE
                WHERE expires_at < NOW()
                AND active = TRUE
                RETURNING id
            """)

            expired_ids = cursor.fetchall()
            self.db.commit()

            for (rule_id,) in expired_ids:
                self._log_audit('mute_rule_expired', 'system', rule_id, {})

            return len(expired_ids)
        except:
            self.db.rollback()
            return 0
        finally:
            cursor.close()
