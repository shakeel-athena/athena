"""
Background Modules Package
Contains MISP and OTX background modules for threat intelligence data collection
"""

__version__ = "1.0.0"
__author__ = "Athena Network Response Management"
