#!/usr/bin/env python3
"""
OTX Background Module
Fetches IPv4 addresses from OTX and saves to file
"""

import os
import sys
import json
import time
import threading
from datetime import datetime, timedelta
from OTXv2 import OTXv2
import logging
from dotenv import load_dotenv

# Load environment variables
load_dotenv(dotenv_path=os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))), '.env'))

# Add project root to path for database imports
project_root = os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))
sys.path.insert(0, project_root)

try:
    from database import init_db, get_session_scope
    from database.blocked_ip_manager import BlockedIPManager, is_ip_blocked
    DATABASE_ENABLED = True
except ImportError as e:
    logging.warning(f"Database module not available: {e}. Running without database integration.")
    DATABASE_ENABLED = False

try:
    from response.models.Firewall_IP_Blocking import FirewallIPBlockingManager
    FIREWALL_ENABLED = True
except ImportError as e:
    logging.warning(f"Firewall module not available: {e}. Running without firewall integration.")
    FIREWALL_ENABLED = False

# Setup logging
import os
log_dir = os.path.dirname(os.path.abspath(__file__))

# Create logger
logger = logging.getLogger('OTXModule')
logger.setLevel(logging.INFO)

# Remove existing handlers to avoid duplicates
for handler in logger.handlers[:]:
    logger.removeHandler(handler)

# Create file handler
file_handler = logging.FileHandler(os.path.join(log_dir, 'otx_module.log'))
file_handler.setLevel(logging.INFO)

# Create console handler
console_handler = logging.StreamHandler()
console_handler.setLevel(logging.INFO)

# Create formatter
formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
file_handler.setFormatter(formatter)
console_handler.setFormatter(formatter)

# Add handlers to logger
logger.addHandler(file_handler)
logger.addHandler(console_handler)

class OTXModule:
    def __init__(self, config_file=None):
        if config_file is None:
            # More robust path resolution
            current_dir = os.path.dirname(os.path.abspath(__file__))
            response_dir = os.path.dirname(current_dir)
            config_file = os.path.join(response_dir, 'configs', 'config.json')
        self.config_file = config_file
        self.running = False
        self.thread = None
        self.db_initialized = False
        self.firewall_manager = None
        self.load_config()
        
        # Initialize database connection
        if DATABASE_ENABLED:
            try:
                init_db()
                self.db_initialized = True
                logger.info("Database connection initialized for OTX module")
            except Exception as e:
                logger.error(f"Failed to initialize database: {e}")
                self.db_initialized = False
        
        # Initialize firewall manager
        if FIREWALL_ENABLED:
            try:
                self.firewall_manager = FirewallIPBlockingManager()
                logger.info("Firewall manager initialized for OTX module")
            except Exception as e:
                logger.error(f"Failed to initialize firewall manager: {e}")
                self.firewall_manager = None
        
    def load_config(self):
        """Load configuration from JSON file"""
        try:
            with open(self.config_file, 'r') as f:
                config = json.load(f)
            self.config = config['otx_module']
            
            # Override API key from environment if config has empty key
            if not self.config.get('api_key') or self.config['api_key'] == "":
                self.config['api_key'] = os.getenv("OTX_API_KEY", "")
                
            logger.info("Configuration loaded successfully")
        except Exception as e:
            logger.error(f"Failed to load configuration: {e}")
            self.config = {
                "enabled": False,
                "trigger_interval_hours": 0,
                "trigger_interval_minutes": 5,
                "last_run": None,
                "next_run": None,
                "api_key": os.getenv("OTX_API_KEY", ""),
                "date_range_days": 3
            }
    
    def save_config(self):
        """Save configuration to JSON file"""
        try:
            with open(self.config_file, 'r') as f:
                config = json.load(f)
            config['otx_module'] = self.config
            
            with open(self.config_file, 'w') as f:
                json.dump(config, f, indent=2, default=str)
            logger.info("Configuration saved successfully")
        except Exception as e:
            logger.error(f"Failed to save configuration: {e}")
    
    def sync_ips_with_firewall(self, otx_ips):
        """Sync OTX IPs with firewall BLOCK_NET IP set."""
        if not self.firewall_manager or not FIREWALL_ENABLED:
            logger.warning("Firewall manager not available, skipping firewall sync")
            return []
        
        try:
            logger.info("Syncing OTX IPs with firewall BLOCK_NET...")
            
            # Get current IPs from ALLOW_NET
            current_allow_ips = self.firewall_manager.get_allow_ips()
            logger.info(f"Current ALLOW_NET contains {len(current_allow_ips)} IPs")
            
            # Convert ALLOW_NET IPs to a set for comparison (remove /32 or /128 suffix)
            allow_set = set()
            for ip in current_allow_ips:
                if ip.endswith('/32'):
                    allow_set.add(ip[:-3])  # Remove /32 suffix
                elif ip.endswith('/128'):
                    allow_set.add(ip[:-4])  # Remove /128 suffix for IPv6
                else:
                    allow_set.add(ip)
            
            # Get current IPs from BLOCK_NET
            current_block_ips = self.firewall_manager.get_block_ips()
            logger.info(f"Current BLOCK_NET contains {len(current_block_ips)} IPs")
            
            # Convert current BLOCK_NET IPs to a set for comparison (remove /32 suffix for IPv4)
            current_block_set = set()
            for ip in current_block_ips:
                if ip.endswith('/32'):
                    current_block_set.add(ip[:-3])  # Remove /32 suffix
                elif ip.endswith('/128'):
                    current_block_set.add(ip[:-4])  # Remove /128 suffix for IPv6
                else:
                    current_block_set.add(ip)
            
            # Filter IPs: exclude those in ALLOW_NET and those already in BLOCK_NET
            new_ips = []
            skipped_allow = []
            for ip in otx_ips:
                if ip in allow_set:
                    skipped_allow.append(ip)
                    logger.info(f"Skipping IP {ip} - found in ALLOW_NET")
                elif ip not in current_block_set:
                    new_ips.append(ip)
            
            if skipped_allow:
                logger.info(f"Skipped {len(skipped_allow)} IPs that are in ALLOW_NET")
            
            logger.info(f"Found {len(new_ips)} new IPs to add to BLOCK_NET")
            
            # Add new IPs to BLOCK_NET
            if new_ips:
                try:
                    added_ips = self.firewall_manager.add_block_ips(new_ips)
                    logger.info(f"Successfully added {len(new_ips)} IPs to BLOCK_NET")
                    return new_ips
                except Exception as e:
                    logger.error(f"Failed to add IPs to BLOCK_NET: {e}")
                    return []
            else:
                logger.info("No new IPs to add to BLOCK_NET")
                return []
                
        except Exception as e:
            logger.error(f"Error syncing IPs with firewall: {e}")
            return []
    
    def fetch_otx_ipv4(self):
        """Fetch IPv4 addresses from OTX"""
        try:
            logger.info("Starting OTX IPv4 fetch...")
            
            # Calculate date range
            end_date = datetime.now()
            start_date = end_date - timedelta(days=self.config['date_range_days'])
            
            # Initialize OTX client
            otx = OTXv2(self.config['api_key'])
            
            # Get pulses
            start_timestamp = start_date.isoformat()
            all_pulses = []
            all_iocs = []
            ipv4_count = 0
            
            try:
                for pulse in otx.getsince(start_timestamp, limit=100):
                    # Parse the modified date to filter
                    pulse_modified = pulse.get('modified', '')
                    if not pulse_modified:
                        continue
                        
                    try:
                        # Fast date parsing
                        if '.' in pulse_modified:
                            modified_dt = datetime.strptime(pulse_modified, '%Y-%m-%dT%H:%M:%S.%f')
                        else:
                            modified_dt = datetime.strptime(pulse_modified, '%Y-%m-%dT%H:%M:%S')
                        
                        # Check if we're past our end date
                        if modified_dt >= end_date:
                            break
                        
                        # Only process pulses within our date range
                        if start_date <= modified_dt < end_date:
                            all_pulses.append(pulse)
                            
                            # Extract IOCs from this pulse
                            pulse_id = pulse.get('id')
                            
                            try:
                                # Get indicators for this pulse
                                indicators = otx.get_pulse_indicators(pulse_id)
                                
                                for indicator in indicators:
                                    if indicator.get('type') == 'IPv4':
                                        all_iocs.append(indicator.get('indicator', ''))
                                        ipv4_count += 1
                                
                            except Exception as e:
                                logger.warning(f"Error extracting IOCs from pulse {pulse_id}: {e}")
                                continue
                        
                    except ValueError:
                        continue
                    
                    # Rate limiting
                    time.sleep(0.05)
                    
            except Exception as e:
                logger.error(f"Error fetching OTX pulses: {e}")
                return False
            
            # Remove duplicates and filter valid IPv4s
            ipv4_addresses = []
            for ip in set(all_iocs):
                if ip and '.' in ip and len(ip.split('.')) == 4:
                    try:
                        parts = ip.split('.')
                        if all(0 <= int(part) <= 255 for part in parts):
                            ipv4_addresses.append(ip)
                    except (ValueError, AttributeError):
                        continue
            
            logger.info(f"Total pulses: {len(all_pulses)}, Unique IPv4 addresses: {len(ipv4_addresses)}")
            
            # Database integration - check for existing IPs and add new ones
            new_ips = []
            existing_ips = []
            
            if self.db_initialized and DATABASE_ENABLED:
                try:
                    logger.info("Checking IPs against database...")
                    
                    for ip in ipv4_addresses:
                        if is_ip_blocked(ip, module='OTX'):
                            existing_ips.append(ip)
                        else:
                            new_ips.append(ip)
                    
                    logger.info(f"Database check: {len(new_ips)} new IPs, {len(existing_ips)} already blocked")
                    
                    # Add new IPs to database in bulk
                    if new_ips:
                        added_count = BlockedIPManager.add_multiple_blocked_ips(new_ips, 'OTX')
                        logger.info(f"Added {added_count} new IPs to database")
                    
                except Exception as e:
                    logger.error(f"Database operation failed: {e}")
                    # Fall back to treating all IPs as new
                    new_ips = ipv4_addresses
            else:
                logger.warning("Database not available, skipping database integration")
                new_ips = ipv4_addresses
            
            # Firewall integration - sync IPs with BLOCK_NET
            firewall_added_ips = self.sync_ips_with_firewall(ipv4_addresses)
            
            # Note: IPs are now stored in database only, no file saving needed
            
            # Log summary with database and firewall stats
            if self.db_initialized and DATABASE_ENABLED:
                logger.info(f"Summary: {len(ipv4_addresses)} total IPs ({len(new_ips)} new, {len(existing_ips)} existing in DB)")
            if firewall_added_ips:
                logger.info(f"Firewall sync: Added {len(firewall_added_ips)} new IPs to BLOCK_NET")
            
            # Update last run time
            self.config['last_run'] = datetime.now().isoformat()
            self.save_config()
            
            return True
            
        except Exception as e:
            logger.error(f"Error fetching OTX data: {e}")
            return False
    
    def run_loop(self):
        """Main execution loop"""
        logger.info("OTX Module started")
        
        while self.running:
            try:
                if self.config['enabled']:
                    # Check if it's time to run
                    now = datetime.now()
                    next_run = None
                    
                    if self.config['next_run']:
                        next_run = datetime.fromisoformat(self.config['next_run'])
                    
                    if not next_run or now >= next_run:
                        logger.info("Triggering OTX fetch...")
                        success = self.fetch_otx_ipv4()
                        
                        if success:
                            # Calculate next run time using both hours and minutes
                            total_minutes = (self.config.get('trigger_interval_hours', 0) * 60) + self.config.get('trigger_interval_minutes', 0)
                            next_run = now + timedelta(minutes=total_minutes)
                            self.config['next_run'] = next_run.isoformat()
                            self.save_config()
                            logger.info(f"Next run scheduled for: {next_run}")
                        else:
                            logger.error("OTX fetch failed, retrying in 1 hour")
                            next_run = now + timedelta(hours=1)
                            self.config['next_run'] = next_run.isoformat()
                            self.save_config()
                    else:
                        logger.debug(f"Next run scheduled for: {next_run}")
                else:
                    # Check if we would have triggered
                    if self.config.get('next_run'):
                        next_run = datetime.fromisoformat(self.config['next_run'])
                        if now >= next_run:
                            logger.info(f"OTX trigger skipped - module is disabled (would have run at {next_run})")
                    logger.debug("OTX Module is disabled")
                
                # Sleep for 1 minute before checking again
                time.sleep(60)
                
            except Exception as e:
                logger.error(f"Error in OTX module loop: {e}")
                time.sleep(60)
        
        logger.info("OTX Module stopped")
    
    def start(self):
        """Start the background module"""
        if not self.running:
            self.running = True
            self.thread = threading.Thread(target=self.run_loop, daemon=True)
            self.thread.start()
            logger.info("OTX Module started in background")
        else:
            logger.warning("OTX Module is already running")
    
    def stop(self):
        """Stop the background module"""
        if self.running:
            self.running = False
            if self.thread:
                self.thread.join(timeout=5)
            logger.info("OTX Module stopped")
        else:
            logger.warning("OTX Module is not running")
    
    def toggle_enabled(self, enabled):
        """Toggle the enabled state"""
        self.config['enabled'] = enabled
        
        if enabled:
            # When enabling, set next run time
            total_minutes = (self.config.get('trigger_interval_hours', 0) * 60) + self.config.get('trigger_interval_minutes', 0)
            next_run = datetime.now() + timedelta(minutes=total_minutes)
            self.config['next_run'] = next_run.isoformat()
            logger.info(f"OTX Module enabled. Next run scheduled for: {next_run}")
        else:
            # When disabling, clear next run time
            self.config['next_run'] = None
            logger.info(f"OTX Module disabled. Next run cleared.")
        
        self.save_config()
        logger.info(f"OTX Module {'enabled' if enabled else 'disabled'}")
    
    def update_interval(self, hours=None, minutes=None):
        """Update the trigger interval"""
        if hours is not None:
            self.config['trigger_interval_hours'] = hours
        if minutes is not None:
            self.config['trigger_interval_minutes'] = minutes
        self.save_config()
        
        total_minutes = (self.config.get('trigger_interval_hours', 0) * 60) + self.config.get('trigger_interval_minutes', 0)
        logger.info(f"OTX Module interval updated to {self.config.get('trigger_interval_hours', 0)}h {self.config.get('trigger_interval_minutes', 0)}m (total: {total_minutes} minutes)")
    
    def get_status(self):
        """Get current status"""
        return {
            'enabled': self.config['enabled'],
            'running': self.running,
            'last_run': self.config['last_run'],
            'next_run': self.config['next_run'],
            'interval_hours': self.config.get('trigger_interval_hours', 0),
            'interval_minutes': self.config.get('trigger_interval_minutes', 0),
            'date_range_days': self.config.get('date_range_days', 3),
            'total_interval_minutes': (self.config.get('trigger_interval_hours', 0) * 60) + self.config.get('trigger_interval_minutes', 0)
        }

# Global instance
otx_module = OTXModule()
