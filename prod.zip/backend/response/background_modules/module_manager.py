#!/usr/bin/env python3
"""
Background Module Manager
Manages MISP, OTX, and AbuseIPDB background modules
"""

import json
import logging
from datetime import datetime

# Optional background modules (gracefully degrade if missing deps)
try:
    from .misp_module import misp_module as misp_module
    _misp_import_error = None
except Exception as e:
    _misp_import_error = e
    class _DummyModule:
        def __init__(self, name):
            self.name = name
        def start(self):
            pass
        def stop(self):
            pass
        def get_status(self):
            return {"enabled": False, "available": False, "error": f"{self.name} unavailable: {_misp_import_error}"}
        def toggle_enabled(self, enabled):
            pass
        def update_interval(self, **kwargs):
            pass
        def save_config(self):
            pass
    misp_module = _DummyModule("misp")

try:
    from .otx_module import otx_module as otx_module
    _otx_import_error = None
except Exception as e:
    _otx_import_error = e
    if '_DummyModule' not in globals():
        class _DummyModule:
            def __init__(self, name):
                self.name = name
            def start(self):
                pass
            def stop(self):
                pass
            def get_status(self):
                return {"enabled": False, "available": False, "error": f"{self.name} unavailable: {_otx_import_error}"}
            def toggle_enabled(self, enabled):
                pass
            def update_interval(self, **kwargs):
                pass
            def save_config(self):
                pass
    otx_module = _DummyModule("otx")

try:
    from .Abuse_ipdb_module import abuseipdb_module as abuseipdb_module
    _abuseipdb_import_error = None
except Exception as e:
    _abuseipdb_import_error = e
    if '_DummyModule' not in globals():
        class _DummyModule:
            def __init__(self, name):
                self.name = name
            def start(self):
                pass
            def stop(self):
                pass
            def get_status(self):
                return {"enabled": False, "available": False, "error": f"{self.name} unavailable: {_abuseipdb_import_error}"}
            def toggle_enabled(self, enabled):
                pass
            def update_interval(self, **kwargs):
                pass
            def save_config(self):
                pass
    abuseipdb_module = _DummyModule("abuseipdb")

# Setup logging
import os
log_dir = os.path.dirname(os.path.abspath(__file__))

# Create logger
logger = logging.getLogger('ModuleManager')
logger.setLevel(logging.INFO)

# Remove existing handlers to avoid duplicates
for handler in logger.handlers[:]:
    logger.removeHandler(handler)

# Create file handler
file_handler = logging.FileHandler(os.path.join(log_dir, 'module_manager.log'))
file_handler.setLevel(logging.INFO)

# Create console handler
console_handler = logging.StreamHandler()
console_handler.setLevel(logging.INFO)

# Create formatter
formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
file_handler.setFormatter(formatter)
console_handler.setFormatter(formatter)

# Add handlers to logger
logger.addHandler(file_handler)
logger.addHandler(console_handler)

class ModuleManager:
    def __init__(self):
        self.modules = {
            'misp': misp_module,
            'otx': otx_module,
            'abuseipdb': abuseipdb_module
        }
        logger.info("Module Manager initialized")
    
    def start_all(self):
        """Start all modules"""
        for name, module in self.modules.items():
            try:
                module.start()
                logger.info(f"Started {name} module")
            except Exception as e:
                logger.error(f"Failed to start {name} module: {e}")
    
    def stop_all(self):
        """Stop all modules"""
        for name, module in self.modules.items():
            try:
                module.stop()
                logger.info(f"Stopped {name} module")
            except Exception as e:
                logger.error(f"Failed to stop {name} module: {e}")
    
    def get_all_status(self):
        """Get status of all modules"""
        status = {}
        for name, module in self.modules.items():
            try:
                status[name] = module.get_status()
            except Exception as e:
                logger.error(f"Failed to get status for {name} module: {e}")
                status[name] = {'error': str(e)}
        return status
    
    def toggle_module(self, module_name, enabled):
        """Toggle a specific module"""
        if module_name in self.modules:
            try:
                self.modules[module_name].toggle_enabled(enabled)
                logger.info(f"{module_name} module {'enabled' if enabled else 'disabled'}")
                return True
            except Exception as e:
                logger.error(f"Failed to toggle {module_name} module: {e}")
                return False
        else:
            logger.error(f"Unknown module: {module_name}")
            return False
    
    def update_interval(self, module_name, hours=None, minutes=None):
        """Update interval for a specific module"""
        if module_name in self.modules:
            try:
                self.modules[module_name].update_interval(hours=hours, minutes=minutes)
                logger.info(f"{module_name} module interval updated")
                return True
            except Exception as e:
                logger.error(f"Failed to update interval for {module_name} module: {e}")
                return False
        else:
            logger.error(f"Unknown module: {module_name}")
            return False
    
    def get_ip_lists(self):
        """Get current IP lists from database instead of files"""
        # Note: IP lists are now retrieved from database via BlockedIPManager
        # This method is kept for backward compatibility but should use database queries
        logger.warning("get_ip_lists() method is deprecated. Use database queries instead.")
        return {'misp': [], 'otx': []}
    
    def update_module_config(self, module_name, interval_hours, interval_minutes, date_range_days):
        """Update module configuration including interval and date range"""
        if module_name in self.modules:
            try:
                module = self.modules[module_name]
                
                # Update interval
                module.update_interval(hours=interval_hours, minutes=interval_minutes)
                
                # Update date range in config
                module.config['date_range_days'] = date_range_days
                module.save_config()
                
                logger.info(f"{module_name} module configuration updated: "
                           f"{interval_hours}h {interval_minutes}m, {date_range_days} days")
                return True
            except Exception as e:
                logger.error(f"Failed to update config for {module_name} module: {e}")
                return False
        else:
            logger.error(f"Unknown module: {module_name}")
            return False

# Global instance
module_manager = ModuleManager()
