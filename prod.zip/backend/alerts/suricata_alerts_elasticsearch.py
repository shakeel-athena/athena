#!/usr/bin/env python3
"""
Suricata Alerts Manager (Elasticsearch-based)
Fetches and manages network security alerts from Suricata via Elasticsearch.
This replaces the file-based approach with direct Elasticsearch queries.
"""

import logging
import requests
from datetime import datetime, timedelta
from typing import List, Dict, Any, Optional
from collections import defaultdict
import urllib3

# Disable SSL warnings for local development
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)


class SuricataAlertsElasticsearchManager:
    """Manager class for Suricata network security alerts via Elasticsearch"""
    
    def __init__(self, 
                 es_host='localhost',
                 es_port=9220,
                 es_username=None,
                 es_password=None,
                 verify_ssl=False,
                 index_pattern='suricata-alerts-*'):
        """
        Initialize Suricata Alerts Elasticsearch Manager
        
        Args:
            es_host: Elasticsearch hostname
            es_port: Elasticsearch port
            es_username: Elasticsearch username (optional)
            es_password: Elasticsearch password (optional)
            verify_ssl: Verify SSL certificates
            index_pattern: Elasticsearch index pattern for Suricata alerts
        """
        self.es_host = es_host
        self.es_port = es_port
        self.es_username = es_username
        self.es_password = es_password
        self.verify_ssl = verify_ssl
        self.index_pattern = index_pattern
        self.logger = logging.getLogger(__name__)

        # Build base URL (always use HTTPS, verify_ssl only controls certificate verification)
        self.base_url = f"https://{es_host}:{es_port}"
        
    def test_connection(self) -> bool:
        """
        Test Elasticsearch connection
        
        Returns:
            bool: True if connection successful
        """
        try:
            auth = None
            if self.es_username and self.es_password:
                auth = (self.es_username, self.es_password)
            
            response = requests.get(
                f"{self.base_url}/_cluster/health",
                auth=auth,
                verify=self.verify_ssl,
                timeout=5
            )
            return response.status_code == 200
        except Exception as e:
            print(f"Elasticsearch connection test failed: {e}")
            return False
    
    def _build_base_query(self,
                          severity: Optional[int] = None,
                          time_range_hours: int = 24,
                          search: Optional[str] = None,
                          src_ip: Optional[str] = None,
                          dest_ip: Optional[str] = None,
                          signature: Optional[str] = None,
                          category: Optional[str] = None) -> Dict[str, Any]:
        """
        Build base Elasticsearch query for Suricata alerts
        
        Args:
            severity: Filter by severity (1=Critical, 2=High, 3=Medium, 4+=Low)
            time_range_hours: Time range in hours
            search: General search term
            src_ip: Filter by source IP
            dest_ip: Filter by destination IP
            signature: Filter by signature name
            category: Filter by category
            
        Returns:
            Elasticsearch query dict
        """
        # Build must clauses
        must_clauses = []
        
        # Time range filter (only if time_range_hours > 0, otherwise query all alerts)
        if time_range_hours and time_range_hours > 0:
            time_filter = {
                "range": {
                    "@timestamp": {
                        "gte": f"now-{time_range_hours}h",
                        "lte": "now"
                    }
                }
            }
            must_clauses.append(time_filter)
        
        # Filter by alert existence (only show actual alerts, not flow/dns/etc.)
        # The event_type field is inside event.original (string), but alert data is parsed out
        must_clauses.append({
            "exists": {
                "field": "alert.severity"
            }
        })
        
        # Severity filter (use alert.severity field from raw Suricata data)
        if severity is not None:
            # Suricata severity: 1=Critical, 2=High, 3=Medium, 4+=Low
            # Filter directly by numeric severity value in alert.severity
            must_clauses.append({
                "term": {
                    "alert.severity": severity
                }
            })
        
        # IP filters
        if src_ip:
            must_clauses.append({
                "term": {
                    "src_ip.keyword": src_ip
                }
            })
        
        if dest_ip:
            must_clauses.append({
                "term": {
                    "dest_ip.keyword": dest_ip
                }
            })
        
        # Signature filter (use nested alert.signature field)
        if signature:
            must_clauses.append({
                "wildcard": {
                    "alert.signature.keyword": f"*{signature}*"
                }
            })
        
        # Category filter (use nested alert.category field)
        if category:
            must_clauses.append({
                "wildcard": {
                    "alert.category.keyword": f"*{category}*"
                }
            })
        
        # General search (searches across multiple fields including nested)
        if search:
            must_clauses.append({
                "multi_match": {
                    "query": search,
                    "fields": ["alert.signature", "alert.category", "src_ip", "dest_ip"],
                    "type": "phrase_prefix"
                }
            })
        
        query = {
            "query": {
                "bool": {
                    "must": must_clauses
                }
            }
        }
        
        return query
    
    def get_alerts(self,
                   limit: int = 100,
                   offset: int = 0,
                   severity: Optional[int] = None,
                   time_range_hours: int = 24,
                   src_ip: Optional[str] = None,
                   dest_ip: Optional[str] = None,
                   signature: Optional[str] = None,
                   category: Optional[str] = None,
                   search: Optional[str] = None,
                   return_total: bool = False) -> Dict[str, Any]:
        """
        Fetch Suricata alerts from Elasticsearch
        
        Args:
            limit: Maximum number of alerts to return
            offset: Number of alerts to skip (for pagination)
            severity: Filter by severity (1=high, 2=medium, 3=low, 4=lowest)
            time_range_hours: Time range in hours
            src_ip: Filter by source IP
            dest_ip: Filter by destination IP
            signature: Filter by signature name
            category: Filter by category
            search: General search term
            return_total: If True, return dict with alerts and total count
            
        Returns:
            Dict with 'alerts' list and 'total' count if return_total=True, else just list
        """
        # Cap limit to Elasticsearch's default max_result_window (10000)
        # Requests for more than 10000 will fail without index.max_result_window being increased
        ES_MAX_RESULT_WINDOW = 10000
        if limit > ES_MAX_RESULT_WINDOW:
            self.logger.warning(f"Requested limit {limit} exceeds ES max_result_window, capping to {ES_MAX_RESULT_WINDOW}")
            limit = ES_MAX_RESULT_WINDOW

        query = self._build_base_query(
            severity=severity,
            time_range_hours=time_range_hours,
            search=search,
            src_ip=src_ip,
            dest_ip=dest_ip,
            signature=signature,
            category=category
        )

        # Add pagination
        query["from"] = offset
        query["size"] = limit
        
        # Sort by severity (ascending: 1=Critical first), then by timestamp (newest first)
        # This ensures high-severity alerts appear first even if they're older
        query["sort"] = [
            {
                # Sort by alert.severity ascending (1=Critical comes first)
                "alert.severity": {
                    "order": "asc",  # Ascending: 1 (Critical) comes before 4 (Low)
                    "missing": "_last"  # Put alerts without severity at the end
                }
            },
            {"@timestamp": {"order": "desc"}}  # Then by timestamp (newest first)
        ]
        
        # Enable accurate total count (True = track all hits accurately, no limit)
        # This ensures we get accurate counts even for large datasets (>10k alerts)
        query["track_total_hits"] = True
        
        try:
            auth = None
            if self.es_username and self.es_password:
                auth = (self.es_username, self.es_password)
            
            response = requests.post(
                f"{self.base_url}/{self.index_pattern}/_search",
                auth=auth,
                json=query,
                verify=self.verify_ssl,
                timeout=60
            )
            
            if response.status_code == 200:
                result = response.json()
                hits = result.get('hits', {})
                hits_list = hits.get('hits', [])

                # Extract _source from each hit, include _id for unique identification
                alerts = [{**hit['_source'], 'id': hit.get('_id')} for hit in hits_list]

                # Get total count
                total = hits.get('total', {})
                if isinstance(total, dict):
                    total_count = total.get('value', 0)
                else:
                    total_count = total

                if return_total:
                    return {
                        'alerts': alerts,
                        'total': total_count
                    }
                else:
                    return alerts
            else:
                self.logger.error(f"Elasticsearch query failed: {response.status_code} - {response.text[:500]}")
                if return_total:
                    return {'alerts': [], 'total': 0}
                return []
                
        except Exception as e:
            print(f"Error fetching Suricata alerts from Elasticsearch: {e}")
            if return_total:
                return {'alerts': [], 'total': 0}
            return []
    
    def get_aggregations(self,
                        severity: Optional[int] = None,
                        time_range_hours: int = 24,
                        search: Optional[str] = None) -> Dict[str, Any]:
        """
        Get aggregated statistics for Suricata alerts
        
        Args:
            severity: Filter by severity
            time_range_hours: Time range in hours
            search: Search term
            
        Returns:
            Dict with total count and severity breakdown
        """
        query = self._build_base_query(
            severity=severity,
            time_range_hours=time_range_hours,
            search=search
        )
        
        # Add aggregations
        query["size"] = 0  # We only want aggregations, not hits
        query["track_total_hits"] = True
        query["aggs"] = {
            "by_severity_raw": {
                "terms": {
                    "field": "alert.severity",
                    "size": 10
                }
            },
            "by_category": {
                "terms": {
                    "field": "alert.category.keyword",
                    "size": 10
                }
            },
            "by_signature": {
                "terms": {
                    "field": "alert.signature.keyword",
                    "size": 10
                }
            },
            "top_src_ips": {
                "terms": {
                    "field": "src_ip.keyword",
                    "size": 10
                }
            },
            "top_dest_ips": {
                "terms": {
                    "field": "dest_ip.keyword",
                    "size": 10
                }
            }
        }
        
        try:
            auth = None
            if self.es_username and self.es_password:
                auth = (self.es_username, self.es_password)
            
            response = requests.post(
                f"{self.base_url}/{self.index_pattern}/_search",
                auth=auth,
                json=query,
                verify=self.verify_ssl,
                timeout=60
            )
            
            if response.status_code == 200:
                result = response.json()
                
                # Get total count
                total = result.get('hits', {}).get('total', {})
                if isinstance(total, dict):
                    total_count = total.get('value', 0)
                else:
                    total_count = total
                
                # Extract aggregations
                aggs = result.get('aggregations', {})
                
                # Convert raw severity buckets (numeric: 1,2,3,4) to normalized dict
                severity_buckets = aggs.get('by_severity_raw', {}).get('buckets', [])
                by_severity = {
                    'Critical': 0,
                    'High': 0,
                    'Medium': 0,
                    'Low': 0
                }
                # Map Suricata severity: 1=Critical, 2=High, 3=Medium, 4+=Low
                severity_map = {
                    1: 'Critical',
                    2: 'High',
                    3: 'Medium',
                    4: 'Low'
                }
                for bucket in severity_buckets:
                    raw_sev = bucket.get('key')  # numeric: 1, 2, 3, or 4
                    count = bucket.get('doc_count', 0)
                    normalized_sev = severity_map.get(raw_sev, 'Low')
                    by_severity[normalized_sev] = by_severity.get(normalized_sev, 0) + count
                
                # Convert other aggregations
                by_category = {bucket['key']: bucket['doc_count'] 
                              for bucket in aggs.get('by_category', {}).get('buckets', [])}
                
                top_signatures = {bucket['key']: bucket['doc_count'] 
                                 for bucket in aggs.get('by_signature', {}).get('buckets', [])}
                
                top_src_ips = {bucket['key']: bucket['doc_count'] 
                              for bucket in aggs.get('top_src_ips', {}).get('buckets', [])}
                
                top_dest_ips = {bucket['key']: bucket['doc_count'] 
                               for bucket in aggs.get('top_dest_ips', {}).get('buckets', [])}
                
                return {
                    'total': total_count,
                    'by_severity': by_severity,
                    'by_category': by_category,
                    'top_signatures': top_signatures,
                    'top_src_ips': top_src_ips,
                    'top_dest_ips': top_dest_ips
                }
            else:
                print(f"Elasticsearch aggregation query failed: {response.status_code}")
                return {
                    'total': 0,
                    'by_severity': {'Critical': 0, 'High': 0, 'Medium': 0, 'Low': 0},
                    'by_category': {},
                    'top_signatures': {},
                    'top_src_ips': {},
                    'top_dest_ips': {}
                }
                
        except Exception as e:
            print(f"Error getting Suricata aggregations: {e}")
            return {
                'total': 0,
                'by_severity': {'Critical': 0, 'High': 0, 'Medium': 0, 'Low': 0},
                'by_category': {},
                'top_signatures': {},
                'top_src_ips': {},
                'top_dest_ips': {}
            }

    def get_threat_actor_aggregations(self,
                                       time_range_hours: int = 24,
                                       min_severity: str = 'High',
                                       limit: int = 50) -> Dict[str, Any]:
        """
        Get threat actor data using Elasticsearch aggregations.
        Aggregates by source IP with severity counts, signatures, and timestamps.

        Args:
            time_range_hours: Time range in hours to look back
            min_severity: Minimum severity level ('Critical' or 'High')
            limit: Maximum number of source IPs to return

        Returns:
            Dict with aggregated threat actor data
        """
        # Map severity to Suricata values (1=Critical, 2=High)
        max_severity = 1 if min_severity == 'Critical' else 2

        query = self._build_base_query(time_range_hours=time_range_hours)

        # Add severity filter (1=Critical, 2=High are high severity)
        query["query"]["bool"]["must"].append({
            "range": {
                "alert.severity": {"lte": max_severity}
            }
        })

        # No documents needed, only aggregations
        query["size"] = 0
        query["track_total_hits"] = True

        # Aggregate by source IP with nested aggregations
        query["aggs"] = {
            "by_source_ip": {
                "terms": {
                    "field": "src_ip.keyword",
                    "size": limit,
                    "order": {"_count": "desc"}
                },
                "aggs": {
                    "severity_breakdown": {
                        "terms": {
                            "field": "alert.severity",
                            "size": 10
                        }
                    },
                    "signatures": {
                        "terms": {
                            "field": "alert.signature.keyword",
                            "size": 10
                        }
                    },
                    "targets": {
                        "terms": {
                            "field": "dest_ip.keyword",
                            "size": 10
                        }
                    },
                    "first_seen": {
                        "min": {"field": "@timestamp"}
                    },
                    "last_seen": {
                        "max": {"field": "@timestamp"}
                    }
                }
            }
        }

        try:
            auth = None
            if self.es_username and self.es_password:
                auth = (self.es_username, self.es_password)

            response = requests.post(
                f"{self.base_url}/{self.index_pattern}/_search",
                auth=auth,
                json=query,
                verify=self.verify_ssl,
                timeout=30
            )

            if response.status_code == 200:
                result = response.json()
                total = result.get('hits', {}).get('total', {})
                total_count = total.get('value', 0) if isinstance(total, dict) else total

                ip_buckets = result.get('aggregations', {}).get('by_source_ip', {}).get('buckets', [])

                threat_actors = []
                for bucket in ip_buckets:
                    src_ip = bucket.get('key', 'Unknown')
                    alert_count = bucket.get('doc_count', 0)

                    # Process severity breakdown (Suricata: 1=Critical, 2=High)
                    severity_buckets = bucket.get('severity_breakdown', {}).get('buckets', [])
                    critical_count = 0
                    high_count = 0
                    for sev_bucket in severity_buckets:
                        level = sev_bucket.get('key', 0)
                        count = sev_bucket.get('doc_count', 0)
                        if level == 1:
                            critical_count += count
                        elif level == 2:
                            high_count += count

                    # Get signatures
                    sig_buckets = bucket.get('signatures', {}).get('buckets', [])
                    signatures = [s.get('key', '') for s in sig_buckets]

                    # Get targets
                    target_buckets = bucket.get('targets', {}).get('buckets', [])
                    targets = [t.get('key', '') for t in target_buckets]

                    # Get timestamps
                    first_seen = bucket.get('first_seen', {}).get('value_as_string')
                    last_seen = bucket.get('last_seen', {}).get('value_as_string')

                    threat_actors.append({
                        'ip': src_ip,
                        'alert_count': alert_count,
                        'critical_count': critical_count,
                        'high_count': high_count,
                        'signatures': signatures,
                        'targets': targets,
                        'first_seen': first_seen,
                        'last_seen': last_seen,
                        'source': 'suricata'
                    })

                return {
                    'threat_actors': threat_actors,
                    'total_alerts': total_count,
                    'source': 'suricata'
                }
            else:
                self.logger.error(f"Threat actor aggregation query failed: {response.status_code}")
                return {'threat_actors': [], 'total_alerts': 0, 'source': 'suricata'}

        except Exception as e:
            self.logger.error(f"Error getting threat actor aggregations: {e}")
            return {'threat_actors': [], 'total_alerts': 0, 'source': 'suricata'}

    def get_normalized_alerts(self,
                             limit: int = 100,
                             offset: int = 0,
                             severity: Optional[int] = None,
                             time_range_hours: int = 24,
                             search: Optional[str] = None,
                             return_total: bool = False) -> Dict[str, Any]:
        """
        Get alerts in normalized format for unified API
        
        Args:
            limit: Maximum number of alerts
            offset: Number of alerts to skip
            severity: Filter by severity (1=high, 2=medium, 3=low)
            time_range_hours: Time range in hours
            search: Search term
            return_total: Whether to return total count
            
        Returns:
            Dict with 'alerts' list and 'total' count if return_total=True, else just list
        """
        result = self.get_alerts(
            limit=limit,
            offset=offset,
            severity=severity,
            time_range_hours=time_range_hours,
            search=search,
            return_total=return_total
        )
        
        if return_total:
            raw_alerts = result.get('alerts', [])
            total = result.get('total', 0)
        else:
            raw_alerts = result if isinstance(result, list) else result.get('alerts', [])
            total = 0
        
        normalized_alerts = []

        for event in raw_alerts:
            # Extract fields - check multiple possible locations
            # 1. Root level (from new Logstash config)
            # 2. event_data.alert (from some Logstash configs)
            # 3. alert (from raw Suricata or old Logstash)

            event_data = event.get('event_data', {})
            alert_obj = event.get('alert', {}) or event_data.get('alert', {})
            
            # Extract signature, category, severity
            signature = (event.get('signature') or 
                        alert_obj.get('signature') or 
                        'Unknown')
            
            category = (event.get('category') or 
                       alert_obj.get('category') or 
                       'Unknown')
            
            # Extract severity from multiple possible locations
            # Priority: alert.severity > alert_severity > suricata.alert.severity > severity > default 4
            alert_severity = None

            # Try alert object first (standard EVE JSON structure)
            if alert_obj and alert_obj.get('severity') is not None:
                alert_severity = alert_obj.get('severity')
            # Try root level alert_severity
            elif event.get('alert_severity') is not None:
                alert_severity = event.get('alert_severity')
            # Try suricata.alert.severity (some Logstash configs)
            elif event.get('suricata', {}).get('alert', {}).get('severity') is not None:
                alert_severity = event['suricata']['alert']['severity']
            # Try root level severity
            elif event.get('severity') is not None:
                alert_severity = event.get('severity')
            # Try event_data.alert.severity
            elif event_data.get('alert', {}).get('severity') is not None:
                alert_severity = event_data['alert']['severity']

            # Default to 4 (Low) if not found
            if alert_severity is None:
                alert_severity = 4

            # Convert string severity to int if needed
            try:
                alert_severity = int(alert_severity) if alert_severity else 4
            except (ValueError, TypeError):
                alert_severity = 4

            # Compute normalized_severity from alert_severity
            normalized_severity = self._normalize_severity(alert_severity)

            # Get IPs and ports (usually at root level)
            src_ip = event.get('src_ip') or event_data.get('src_ip', 'Unknown')
            src_port = event.get('src_port') or event_data.get('src_port', 0)
            dest_ip = event.get('dest_ip') or event_data.get('dest_ip', 'Unknown')
            dest_port = event.get('dest_port') or event_data.get('dest_port', 0)
            
            # Get other fields
            proto = event.get('proto') or event_data.get('proto', 'Unknown')
            timestamp = event.get('timestamp') or event.get('@timestamp', datetime.now().isoformat())
            flow_id = event.get('flow_id') or event_data.get('flow_id', 0)
            
            # Get signature_id
            signature_id = (event.get('signature_id') or 
                          alert_obj.get('signature_id') or 
                          0)
            
            # Get action if available
            action = alert_obj.get('action', 'allowed')
            
            normalized = {
                'id': event.get('id'),  # Elasticsearch document ID
                'source': 'suricata',
                'timestamp': timestamp,
                'alert_id': f"suricata_{flow_id}_{signature_id}",
                'signature_id': signature_id,
                'signature': signature,
                'category': category,
                'severity': alert_severity,
                'normalized_severity': normalized_severity,
                'action': action,
                'src_ip': src_ip,
                'src_port': src_port,
                'dest_ip': dest_ip,
                'dest_port': dest_port,
                'protocol': proto,
                'app_proto': event.get('app_proto', ''),
                'flow_id': flow_id,
                'raw': event
            }
            normalized_alerts.append(normalized)

        # Log summary of normalized alerts
        if normalized_alerts:
            sev_counts = {}
            for a in normalized_alerts:
                sev = a.get('normalized_severity', 'Unknown')
                sev_counts[sev] = sev_counts.get(sev, 0) + 1
            self.logger.info(f"[SuricataES] Normalized {len(normalized_alerts)} alerts: {sev_counts}")

        if return_total:
            return {
                'alerts': normalized_alerts,
                'total': total
            }
        else:
            return normalized_alerts
    
    @staticmethod
    def _normalize_severity(severity: int) -> str:
        """
        Normalize Suricata severity to standard severity
        
        Suricata Severity:
        - 1: Critical
        - 2: High
        - 3: Medium
        - 4+: Low
        
        Args:
            severity: Suricata severity level
            
        Returns:
            Normalized severity string
        """
        if severity == 1:
            return "Critical"
        elif severity == 2:
            return "High"
        elif severity == 3:
            return "Medium"
        else:  # 4 or higher
            return "Low"

