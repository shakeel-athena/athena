#!/usr/bin/env python3
"""
Wazuh Alerts Manager
Fetches and manages security alerts from Wazuh Indexer (OpenSearch).
"""

import requests
import json
from datetime import datetime, timedelta
from typing import List, Dict, Any, Optional
from urllib3.exceptions import InsecureRequestWarning

# Suppress SSL warnings (for development)
requests.packages.urllib3.disable_warnings(category=InsecureRequestWarning)


class WazuhAlertsManager:
    """Manager class for Wazuh security alerts"""
    
    def __init__(self, host='localhost', port=9200, username='admin', password='admin', verify_ssl=False):
        """
        Initialize Wazuh Alerts Manager
        
        Args:
            host: Wazuh indexer hostname or IP
            port: Indexer port (default: 9200)
            username: Indexer username
            password: Indexer password
            verify_ssl: Verify SSL certificate (default: False)
        """
        self.host = host
        self.port = port
        self.username = username
        self.password = password
        self.verify_ssl = verify_ssl
        self.base_url = f"https://{host}:{port}"
        self._connection_tested = False
        
    def test_connection(self) -> bool:
        """
        Test connection to Wazuh Indexer
        
        Returns:
            bool: True if connection successful, False otherwise
        """
        try:
            response = requests.get(
                self.base_url,
                auth=(self.username, self.password),
                verify=self.verify_ssl,
                timeout=10
            )
            
            if response.status_code == 200:
                info = response.json()
                self._connection_tested = True
                return True
            else:
                return False
                
        except requests.exceptions.RequestException as e:
            return False
    
    def _build_base_query(self,
                          rule_level: Optional[int] = None,
                          rule_level_min: Optional[int] = None,
                          rule_level_max: Optional[int] = None,
                          search: Optional[str] = None,
                          time_range_hours: int = 24,
                          agent_id: Optional[str] = None,
                          agent_name: Optional[str] = None) -> Dict[str, Any]:
        """Build base OpenSearch query with filters"""
        query = {
            "query": {
                "bool": {
                    "must": []
                }
            }
        }
        
        # Add time range filter using Elasticsearch relative time (always current/live)
        # This ensures we get the most recent data up to now
        # If time_range_hours is 0 or None, query ALL alerts (no time filter)
        if time_range_hours and time_range_hours > 0:
            query["query"]["bool"]["must"].append({
                "range": {
                    "@timestamp": {  # Wazuh uses @timestamp field in Elasticsearch
                        "gte": f"now-{time_range_hours}h",  # Relative time ensures live data
                        "lte": "now"
                    }
                }
            })
        
        # Add rule level filter (use range min/max if provided, otherwise fallback to >= rule_level for backward compatibility)
        if rule_level_min is not None or rule_level_max is not None:
            level_filter = {}
            if rule_level_min is not None:
                level_filter["gte"] = rule_level_min
            if rule_level_max is not None:
                level_filter["lt"] = rule_level_max
            query["query"]["bool"]["must"].append({
                "range": {
                    "rule.level": level_filter
                }
            })
        elif rule_level is not None:
            # Backward compatibility: if only rule_level provided, use >=
            query["query"]["bool"]["must"].append({
                "range": {
                    "rule.level": {
                        "gte": rule_level
                    }
                }
            })
        
        # Add search filter
        if search:
            query["query"]["bool"]["must"].append({
                "query_string": {
                    "query": f"*{search}*",
                    "fields": ["rule.description", "full_log", "decoder.name"],
                    "default_operator": "AND"
                }
            })
        
        # Add agent filters
        if agent_id:
            query["query"]["bool"]["must"].append({
                "term": {"agent.id": agent_id}
            })
        
        if agent_name:
            query["query"]["bool"]["must"].append({
                "term": {"agent.name.keyword": agent_name}
            })
        
        # If no filters, match all
        if not query["query"]["bool"]["must"]:
            query["query"] = {"match_all": {}}
        
        return query

    def get_alerts(self, 
                   limit: int = 100,
                   offset: int = 0,
                   rule_level: Optional[int] = None,
                   rule_level_min: Optional[int] = None,
                   rule_level_max: Optional[int] = None,
                   search: Optional[str] = None,
                   time_range_hours: int = 24, 
                   agent_id: Optional[str] = None,
                   agent_name: Optional[str] = None,
                   search_after: Optional[List[Any]] = None) -> Dict[str, Any]:
        """
        Get alerts from Wazuh Indexer with pagination support
        
        Args:
            limit: Maximum number of alerts to retrieve (max 10000 per request)
            offset: Number of alerts to skip (for from/size pagination, max 10000)
            rule_level: Filter by rule level (e.g., 7 for high severity) - backward compatibility only
            rule_level_min: Minimum rule level (inclusive)
            rule_level_max: Maximum rule level (exclusive)
            search: Search term to filter alerts
            time_range_hours: Time range in hours to look back
            agent_id: Filter by specific agent ID
            agent_name: Filter by specific agent name
            search_after: For pagination beyond 10k, use search_after from previous response
            
        Returns:
            Dict with 'alerts' list and 'total' count, or empty list on error
        """
        # Build base query
        query = self._build_base_query(
            rule_level=rule_level,
            rule_level_min=rule_level_min,
            rule_level_max=rule_level_max,
            search=search,
            time_range_hours=time_range_hours,
            agent_id=agent_id,
            agent_name=agent_name
        )
        
        # Use search_after for pagination beyond 10k, otherwise use from/size
        if search_after:
            # Pagination beyond 10k limit using search_after
            query["size"] = min(limit, 10000)  # Max 10k per request
            query["sort"] = [
                {"@timestamp": {"order": "desc"}},  # Use @timestamp for Elasticsearch
                {"_id": {"order": "asc"}}  # Tie-breaker for consistent sorting
            ]
            query["search_after"] = search_after
        else:
            # Normal pagination (works up to 10k offset)
            query["size"] = min(limit, 10000)
            query["from"] = min(offset, 10000)  # OpenSearch max offset is 10k
            query["sort"] = [
                {"@timestamp": {"order": "desc"}},  # Use @timestamp for Elasticsearch
                {"_id": {"order": "asc"}}
            ]
        
        try:
            # Enable track_total_hits for accurate count (True = track all hits accurately, no limit)
            # This ensures we get accurate counts even for large datasets (>10k alerts)
            query["track_total_hits"] = True
            
            # Query wazuh-alerts-* indices
            response = requests.post(
                f"{self.base_url}/wazuh-alerts-*/_search",
                auth=(self.username, self.password),
                json=query,
                verify=self.verify_ssl,
                timeout=60  # Increased timeout for large queries
            )
            
            if response.status_code == 200:
                result = response.json()
                hits = result.get('hits', {})
                hits_list = hits.get('hits', [])
                # Include _id from Elasticsearch for unique identification
                alerts = [{**hit['_source'], 'id': hit.get('_id')} for hit in hits_list]
                
                # Get total count
                total = hits.get('total', {})
                if isinstance(total, dict):
                    total_count = total.get('value', 0)
                else:
                    total_count = total
                
                # Get search_after value from last hit for next page
                next_search_after = None
                if hits_list and offset + len(alerts) < total_count:
                    next_search_after = hits_list[-1].get('sort', None)
                
                return {
                    'alerts': alerts,
                    'total': total_count,
                    'next_search_after': next_search_after,
                    'has_more': next_search_after is not None
                }
            else:
                return {'alerts': [], 'total': 0, 'next_search_after': None, 'has_more': False}
                
        except requests.exceptions.RequestException as e:
            return {'alerts': [], 'total': 0, 'next_search_after': None, 'has_more': False}
    
    def get_aggregations(self,
                        rule_level: Optional[int] = None,
                        rule_level_min: Optional[int] = None,
                        rule_level_max: Optional[int] = None,
                        search: Optional[str] = None,
                        time_range_hours: int = 24,
                        agent_id: Optional[str] = None,
                        agent_name: Optional[str] = None) -> Dict[str, Any]:
        """
        Get accurate counts and aggregations without fetching all alerts
        Uses OpenSearch aggregations for efficient counting
        
        Returns:
            Dict with total count and counts by severity
        """
        query = self._build_base_query(
            rule_level=rule_level,
            rule_level_min=rule_level_min,
            rule_level_max=rule_level_max,
            search=search,
            time_range_hours=time_range_hours,
            agent_id=agent_id,
            agent_name=agent_name
        )
        
        # Use size: 0 to get only aggregations, no actual documents
        query["size"] = 0
        query["track_total_hits"] = True
        
        # Add aggregations for severity counts
        query["aggs"] = {
            "by_severity_level": {
                "terms": {
                    "field": "rule.level",
                    "size": 100  # Get all unique severity levels
                }
            },
            "by_source": {
                "terms": {
                    "field": "agent.name.keyword",
                    "size": 10  # Top 10 agents
                }
            }
        }
        
        try:
            response = requests.post(
                f"{self.base_url}/wazuh-alerts-*/_search",
                auth=(self.username, self.password),
                json=query,
                verify=self.verify_ssl,
                timeout=30
            )
            
            if response.status_code == 200:
                result = response.json()
                
                # Get total count
                total = result.get('hits', {}).get('total', {})
                if isinstance(total, dict):
                    total_count = total.get('value', 0)
                else:
                    total_count = total
                
                # Process severity aggregations
                aggs = result.get('aggregations', {})
                severity_levels = aggs.get('by_severity_level', {}).get('buckets', [])
                
                # Map Wazuh levels to normalized severities
                by_severity = {
                    "Critical": 0,
                    "High": 0,
                    "Medium": 0,
                    "Low": 0
                }
                
                for bucket in severity_levels:
                    level = bucket.get('key', 0)
                    count = bucket.get('doc_count', 0)
                    severity = self._normalize_severity(level)
                    by_severity[severity] = by_severity.get(severity, 0) + count
                
                return {
                    'total': total_count,
                    'by_severity': by_severity
                }
            else:
                return {'total': 0, 'by_severity': {"Critical": 0, "High": 0, "Medium": 0, "Low": 0}}
                
        except requests.exceptions.RequestException as e:
            return {'total': 0, 'by_severity': {"Critical": 0, "High": 0, "Medium": 0, "Low": 0}}

    def get_agent_statistics(self,
                            time_range_hours: int = 24,
                            search: Optional[str] = None) -> List[Dict[str, Any]]:
        """
        Get accurate per-agent alert statistics using Elasticsearch aggregations.
        This is much more efficient than computing stats from fetched alerts.

        Returns:
            List of dicts with agent name, id, ip, os, and severity counts
        """
        query = self._build_base_query(
            time_range_hours=time_range_hours,
            search=search
        )

        # Use size: 0 to get only aggregations, no actual documents
        query["size"] = 0
        query["track_total_hits"] = True

        # Nested aggregations: by agent name -> by severity level
        query["aggs"] = {
            "by_agent": {
                "terms": {
                    "field": "agent.name",
                    "size": 500  # Get up to 500 agents
                },
                "aggs": {
                    "agent_info": {
                        "top_hits": {
                            "size": 1,
                            "sort": [{"@timestamp": {"order": "desc"}}],
                            "_source": ["agent.id", "agent.ip", "agent.os.platform"]
                        }
                    },
                    "by_severity": {
                        "terms": {
                            "field": "rule.level",
                            "size": 20
                        }
                    }
                }
            }
        }

        try:
            response = requests.post(
                f"{self.base_url}/wazuh-alerts-*/_search",
                auth=(self.username, self.password),
                json=query,
                verify=self.verify_ssl,
                timeout=30
            )

            if response.status_code == 200:
                result = response.json()
                agent_buckets = result.get('aggregations', {}).get('by_agent', {}).get('buckets', [])

                agent_stats = []
                for bucket in agent_buckets:
                    agent_name = bucket.get('key', 'Unknown')
                    total = bucket.get('doc_count', 0)

                    # Get agent info from top_hits
                    top_hit = bucket.get('agent_info', {}).get('hits', {}).get('hits', [])
                    agent_id = 'Unknown'
                    agent_ip = 'Unknown'
                    agent_os = 'Unknown'
                    if top_hit:
                        source = top_hit[0].get('_source', {}).get('agent', {})
                        agent_id = source.get('id', 'Unknown')
                        agent_ip = source.get('ip', 'Unknown')
                        agent_os = source.get('os', {}).get('platform', 'Unknown') if source.get('os') else 'Unknown'

                    # Process severity breakdown
                    severity_buckets = bucket.get('by_severity', {}).get('buckets', [])
                    severity_counts = {"Critical": 0, "High": 0, "Medium": 0, "Low": 0}
                    for sev_bucket in severity_buckets:
                        level = sev_bucket.get('key', 0)
                        count = sev_bucket.get('doc_count', 0)
                        severity = self._normalize_severity(level)
                        severity_counts[severity] = severity_counts.get(severity, 0) + count

                    agent_stats.append({
                        'agent': agent_name,
                        'agent_id': agent_id,
                        'agent_ip': agent_ip,
                        'agent_os': agent_os,
                        'Critical': severity_counts['Critical'],
                        'High': severity_counts['High'],
                        'Medium': severity_counts['Medium'],
                        'Low': severity_counts['Low'],
                        'total': total
                    })

                # Sort by total alerts descending
                agent_stats.sort(key=lambda x: x['total'], reverse=True)
                return agent_stats
            else:
                return []

        except requests.exceptions.RequestException as e:
            import logging
            logging.getLogger(__name__).error(f"Error getting agent statistics: {e}")
            return []

    def get_threat_actor_aggregations(self,
                                       time_range_hours: int = 24,
                                       min_severity: str = 'High',
                                       limit: int = 100) -> Dict[str, Any]:
        """
        Get threat actor data using Elasticsearch aggregations instead of fetching all alerts.
        Aggregates by source IP with severity counts, signatures, and timestamps.

        Args:
            time_range_hours: Time range in hours to look back
            min_severity: Minimum severity level ('Critical' or 'High')
            limit: Maximum number of source IPs to return

        Returns:
            Dict with aggregated threat actor data
        """
        # Build base query with high severity filter
        rule_level_min = 12 if min_severity == 'Critical' else 7  # Critical=12+, High=7+
        query = self._build_base_query(
            rule_level_min=rule_level_min,
            time_range_hours=time_range_hours
        )

        # No documents needed, only aggregations
        query["size"] = 0
        query["track_total_hits"] = True

        # Aggregate by source IP (data.srcip) with nested aggregations
        query["aggs"] = {
            "by_source_ip": {
                "terms": {
                    "field": "data.srcip",
                    "size": limit,
                    "order": {"_count": "desc"}
                },
                "aggs": {
                    "severity_breakdown": {
                        "terms": {
                            "field": "rule.level",
                            "size": 20
                        }
                    },
                    "signatures": {
                        "terms": {
                            "field": "rule.description.keyword",
                            "size": 10
                        }
                    },
                    "targets": {
                        "terms": {
                            "field": "data.dstip",
                            "size": 10
                        }
                    },
                    "first_seen": {
                        "min": {"field": "@timestamp"}
                    },
                    "last_seen": {
                        "max": {"field": "@timestamp"}
                    }
                }
            }
        }

        try:
            response = requests.post(
                f"{self.base_url}/wazuh-alerts-*/_search",
                auth=(self.username, self.password),
                json=query,
                verify=self.verify_ssl,
                timeout=30
            )

            if response.status_code == 200:
                result = response.json()
                total = result.get('hits', {}).get('total', {})
                total_count = total.get('value', 0) if isinstance(total, dict) else total

                ip_buckets = result.get('aggregations', {}).get('by_source_ip', {}).get('buckets', [])

                threat_actors = []
                for bucket in ip_buckets:
                    src_ip = bucket.get('key', 'Unknown')
                    alert_count = bucket.get('doc_count', 0)

                    # Process severity breakdown
                    severity_buckets = bucket.get('severity_breakdown', {}).get('buckets', [])
                    critical_count = 0
                    high_count = 0
                    for sev_bucket in severity_buckets:
                        level = sev_bucket.get('key', 0)
                        count = sev_bucket.get('doc_count', 0)
                        if level >= 12:
                            critical_count += count
                        elif level >= 7:
                            high_count += count

                    # Get signatures
                    sig_buckets = bucket.get('signatures', {}).get('buckets', [])
                    signatures = [s.get('key', '') for s in sig_buckets]

                    # Get targets
                    target_buckets = bucket.get('targets', {}).get('buckets', [])
                    targets = [t.get('key', '') for t in target_buckets]

                    # Get timestamps
                    first_seen = bucket.get('first_seen', {}).get('value_as_string')
                    last_seen = bucket.get('last_seen', {}).get('value_as_string')

                    threat_actors.append({
                        'ip': src_ip,
                        'alert_count': alert_count,
                        'critical_count': critical_count,
                        'high_count': high_count,
                        'signatures': signatures,
                        'targets': targets,
                        'first_seen': first_seen,
                        'last_seen': last_seen,
                        'source': 'wazuh'
                    })

                return {
                    'threat_actors': threat_actors,
                    'total_alerts': total_count,
                    'source': 'wazuh'
                }
            else:
                return {'threat_actors': [], 'total_alerts': 0, 'source': 'wazuh'}

        except requests.exceptions.RequestException as e:
            import logging
            logging.getLogger(__name__).error(f"Error getting threat actor aggregations: {e}")
            return {'threat_actors': [], 'total_alerts': 0, 'source': 'wazuh'}

    def get_normalized_alerts(self, 
                             limit: int = 100,
                             offset: int = 0,
                             rule_level: Optional[int] = None,
                             rule_level_min: Optional[int] = None,
                             rule_level_max: Optional[int] = None,
                             time_range_hours: int = 24,
                             search: Optional[str] = None,
                             search_after: Optional[List[Any]] = None) -> Dict[str, Any]:
        """
        Get alerts in normalized format for unified API with pagination support
        
        Args:
            limit: Maximum number of alerts
            offset: Number of alerts to skip (for pagination)
            rule_level: Filter by rule level (backward compatibility)
            rule_level_min: Minimum rule level (inclusive)
            rule_level_max: Maximum rule level (exclusive)
            time_range_hours: Time range in hours
            search: Search term to filter alerts
            search_after: For pagination beyond 10k
            
        Returns:
            Dict with 'alerts' list, 'total' count, and pagination info
        """
        result = self.get_alerts(
            limit=limit,
            offset=offset,
            rule_level=rule_level,
            rule_level_min=rule_level_min,
            rule_level_max=rule_level_max,
            time_range_hours=time_range_hours,
            search=search,
            search_after=search_after
        )
        
        raw_alerts = result.get('alerts', [])
        normalized_alerts = []
        for alert in raw_alerts:
            rule = alert.get('rule', {})
            agent = alert.get('agent', {})
            data = alert.get('data', {})

            # Extract IP addresses from data fields (if present)
            # Wazuh alerts may have srcip, dstip, src_ip, or dst_ip depending on the decoder
            # For non-network alerts (like SCA, policy, etc.), these fields won't exist
            src_ip = (data.get('srcip') or data.get('src_ip') or
                     alert.get('srcip') or alert.get('src_ip'))
            dest_ip = (data.get('dstip') or data.get('dst_ip') or data.get('destip') or
                      alert.get('dstip') or alert.get('dst_ip') or alert.get('destip'))

            # Only set to 'Unknown' if there's an indication this should be a network alert
            # (e.g., has srcport or dstport but no IP)
            if not src_ip and (data.get('srcport') or data.get('src_port')):
                src_ip = 'Unknown'
            if not dest_ip and (data.get('dstport') or data.get('dst_port') or data.get('destport')):
                dest_ip = 'Unknown'

            # Extract ports if available (None if not present, not 0)
            src_port = data.get('srcport') or data.get('src_port')
            dest_port = data.get('dstport') or data.get('dst_port') or data.get('destport')

            normalized = {
                'id': alert.get('id'),  # Elasticsearch document ID
                'source': 'wazuh',
                'timestamp': alert.get('timestamp'),
                'rule_id': rule.get('id'),
                'rule_description': rule.get('description'),
                'rule_level': rule.get('level', 0),
                'normalized_severity': self._normalize_severity(rule.get('level', 0)),
                'agent_name': agent.get('name'),
                'agent_id': agent.get('id'),
                'location': alert.get('location'),
                'full_log': alert.get('full_log', ''),
                'decoder_name': alert.get('decoder', {}).get('name'),
                'src_ip': src_ip,  # Normalized IP fields like Suricata
                'dest_ip': dest_ip,
                'src_port': src_port,
                'dest_port': dest_port,
                'data': data,
                'raw': alert
            }
            normalized_alerts.append(normalized)
        
        return {
            'alerts': normalized_alerts,
            'total': result.get('total', 0),
            'next_search_after': result.get('next_search_after'),
            'has_more': result.get('has_more', False)
        }
    
    def get_statistics(self, alerts: List[Dict[str, Any]]) -> Dict[str, Any]:
        """
        Generate statistics from alerts
        
        Args:
            alerts: List of alert dictionaries
            
        Returns:
            Dictionary containing statistics
        """
        if not alerts:
            return {
                'total': 0,
                'by_severity': {},
                'by_agent': {},
                'by_rule': {}
            }
        
        stats = {
            'total': len(alerts),
            'by_severity': {},
            'by_agent': {},
            'by_rule': {}
        }
        
        for alert in alerts:
            # Count by severity
            rule = alert.get('rule', {})
            level = rule.get('level', 0)
            severity = self._normalize_severity(level)
            stats['by_severity'][severity] = stats['by_severity'].get(severity, 0) + 1
            
            # Count by agent
            agent = alert.get('agent', {})
            agent_name = agent.get('name', 'Unknown')
            stats['by_agent'][agent_name] = stats['by_agent'].get(agent_name, 0) + 1
            
            # Count by rule
            rule_desc = rule.get('description', 'Unknown')
            stats['by_rule'][rule_desc] = stats['by_rule'].get(rule_desc, 0) + 1
        
        return stats
    
    @staticmethod
    def _normalize_severity(level: int) -> str:
        """
        Normalize Wazuh alert level to standard severity
        
        Wazuh Levels:
        - Critical: ≥ 15
        - High: 12-14
        - Medium: 7-11
        - Low: 0-6
        
        Args:
            level: Wazuh rule level
            
        Returns:
            Normalized severity string
        """
        if level >= 15:
            return "Critical"
        elif level >= 12:
            return "High"
        elif level >= 7:
            return "Medium"
        else:
            return "Low"
    
    def get_indices(self) -> Optional[str]:
        """Get list of wazuh-alerts indices"""
        try:
            response = requests.get(
                f"{self.base_url}/_cat/indices/wazuh-alerts-*?v",
                auth=(self.username, self.password),
                verify=self.verify_ssl,
                timeout=10
            )
            
            if response.status_code == 200:
                return response.text
            return None
                
        except requests.exceptions.RequestException as e:
            return None


