"""
Alerts Module
Provides unified interface for fetching and managing security alerts from Wazuh and Suricata.
"""

from .wazuh_alerts import WazuhAlertsManager
from .suricata_alerts import SuricataAlertsManager
from .unified_alerts import UnifiedAlertsManager, SeverityMapper

__all__ = [
    'WazuhAlertsManager',
    'SuricataAlertsManager',
    'UnifiedAlertsManager',
    'SeverityMapper'
]


