"""
Alerts Configuration
Configuration for Wazuh and Suricata alert sources.
"""

import os
from pathlib import Path
from dotenv import load_dotenv

# Load environment variables from project root
project_root = Path(__file__).parent.parent.parent
env_path = project_root / '.env'
load_dotenv(dotenv_path=env_path)

# Wazuh Indexer Configuration
WAZUH_HOST = os.getenv('WAZUH_HOST', 'localhost')
WAZUH_PORT = int(os.getenv('WAZUH_PORT', '9200'))
WAZUH_USERNAME = os.getenv('WAZUH_USERNAME', 'admin')
WAZUH_PASSWORD = os.getenv('WAZUH_PASSWORD', 'admin')
WAZUH_VERIFY_SSL = os.getenv('WAZUH_VERIFY_SSL', 'false').lower() == 'true'

# Suricata Configuration (File-based - DEPRECATED)
SURICATA_LOG_FILE = os.getenv('SURICATA_LOG_FILE', '/var/log/suricata/eve.json')

# Suricata Elasticsearch Configuration (NEW - Primary method)
SURICATA_ES_HOST = os.getenv('SURICATA_ES_HOST', 'localhost')
SURICATA_ES_PORT = int(os.getenv('SURICATA_ES_PORT', '9220'))
SURICATA_ES_USERNAME = os.getenv('SURICATA_ES_USERNAME', None)
SURICATA_ES_PASSWORD = os.getenv('SURICATA_ES_PASSWORD', None)
SURICATA_ES_VERIFY_SSL = os.getenv('SURICATA_ES_VERIFY_SSL', 'false').lower() == 'true'
SURICATA_ES_INDEX_PATTERN = os.getenv('SURICATA_ES_INDEX_PATTERN', 'suricata-alerts-*')

# Toggle between file-based and Elasticsearch-based Suricata (set to 'elasticsearch' or 'file')
SURICATA_DATA_SOURCE = os.getenv('SURICATA_DATA_SOURCE', 'elasticsearch')

# Alerts Defaults
DEFAULT_ALERTS_LIMIT = int(os.getenv('DEFAULT_ALERTS_LIMIT', '1000'))
DEFAULT_TIME_RANGE_HOURS = int(os.getenv('DEFAULT_TIME_RANGE_HOURS', '720'))  # 30 days


