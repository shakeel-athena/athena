#!/usr/bin/env python3
"""
Unified Alerts Manager
Merges and normalizes alerts from both Wazuh and Suricata sources.
"""

from datetime import datetime
from typing import List, Dict, Any, Optional
import os
import sys
from pathlib import Path

from .wazuh_alerts import WazuhAlertsManager
from .suricata_alerts import SuricataAlertsManager
from .suricata_alerts_elasticsearch import SuricataAlertsElasticsearchManager
from .config import (
    WAZUH_HOST, WAZUH_PORT, WAZUH_USERNAME, WAZUH_PASSWORD, WAZUH_VERIFY_SSL,
    SURICATA_LOG_FILE, SURICATA_DATA_SOURCE,
    SURICATA_ES_HOST, SURICATA_ES_PORT, SURICATA_ES_USERNAME, SURICATA_ES_PASSWORD,
    SURICATA_ES_VERIFY_SSL, SURICATA_ES_INDEX_PATTERN
)

# Add backend root to path for MuteManager import
BACKEND_ROOT = Path(__file__).resolve().parent.parent
if str(BACKEND_ROOT) not in sys.path:
    sys.path.insert(0, str(BACKEND_ROOT))

# Import MuteManager for alert suppression
try:
    from response.mute_manager import MuteManager
    MUTE_MANAGER_AVAILABLE = True
except ImportError:
    print("Warning: MuteManager not available - mute filtering disabled")
    MUTE_MANAGER_AVAILABLE = False


class SeverityMapper:
    """Maps different severity scales to a normalized scale and provides sorting"""
    
    @staticmethod
    def get_severity_priority(severity: str) -> int:
        """
        Get numeric priority for sorting (lower = more severe)
        
        Args:
            severity: Normalized severity string
            
        Returns:
            Integer priority for sorting
        """
        priorities = {
            "Critical": 1,
            "High": 2,
            "Medium": 3,
            "Low": 4
        }
        return priorities.get(severity, 5)


class UnifiedAlertsManager:
    """Manager class for unified alerts from multiple sources"""
    
    def __init__(self,
                 wazuh_host=None,
                 wazuh_port=None,
                 wazuh_user=None,
                 wazuh_pass=None,
                 suricata_log=None,
                 suricata_data_source=None,
                 verify_ssl=None):
        """
        Initialize Unified Alerts Manager
        
        Args:
            wazuh_host: Wazuh indexer hostname (defaults to config)
            wazuh_port: Wazuh indexer port (defaults to config)
            wazuh_user: Wazuh indexer username (defaults to config)
            wazuh_pass: Wazuh indexer password (defaults to config)
            suricata_log: Path to Suricata eve.json log file (defaults to config) - DEPRECATED
            suricata_data_source: 'elasticsearch' or 'file' (defaults to config)
            verify_ssl: Verify SSL certificates (defaults to config)
        """
        # Use config values if not provided
        self.wazuh_manager = WazuhAlertsManager(
            host=wazuh_host or WAZUH_HOST,
            port=wazuh_port or WAZUH_PORT,
            username=wazuh_user or WAZUH_USERNAME,
            password=wazuh_pass or WAZUH_PASSWORD,
            verify_ssl=verify_ssl if verify_ssl is not None else WAZUH_VERIFY_SSL
        )
        
        # Determine which Suricata manager to use
        data_source = suricata_data_source or SURICATA_DATA_SOURCE
        
        if data_source == 'elasticsearch':
            self.suricata_manager = SuricataAlertsElasticsearchManager(
                es_host=SURICATA_ES_HOST,
                es_port=SURICATA_ES_PORT,
                es_username=SURICATA_ES_USERNAME,
                es_password=SURICATA_ES_PASSWORD,
                verify_ssl=SURICATA_ES_VERIFY_SSL,
                index_pattern=SURICATA_ES_INDEX_PATTERN
            )
            self.suricata_data_source = 'elasticsearch'
        else:
            self.suricata_manager = SuricataAlertsManager(
                log_file=suricata_log or SURICATA_LOG_FILE
            )
            self.suricata_data_source = 'file'
    
    def test_connections(self) -> Dict[str, bool]:
        """
        Test connections to alert sources
        
        Returns:
            Dictionary with connection status for each source
        """
        return {
            'wazuh': self.wazuh_manager.test_connection(),
            'suricata': self.suricata_manager.test_connection()
        }
    
    def fetch_all_alerts(self,
                        limit_per_source: int = 100,
                        offset: int = 0,
                        time_range_hours: int = 24,
                        severity_filter: Optional[str] = None,
                        source_filter: Optional[str] = None,
                        search: Optional[str] = None,
                        return_total: bool = False,
                        apply_mute_rules: bool = True,
                        analyst: Optional[str] = None,
                        mute_scope: str = 'global',
                        sort_field: Optional[str] = None,
                        sort_direction: Optional[str] = 'desc') -> Dict[str, Any]:
        """
        Fetch alerts from all sources and return normalized, merged results

        Strategy:
        - Use real Wazuh and Suricata sources
        - If return_total=True: Use aggregations to get accurate counts without fetching all alerts
        - Fetch only the paginated alerts needed for display
        - Merge and sort results for display
        - Apply mute rules to filter out suppressed alerts (if enabled)

        Args:
            limit_per_source: Page size for pagination (e.g., 20 alerts per page)
            offset: Number of alerts to skip (for pagination)
            time_range_hours: Time range in hours to fetch alerts from
            severity_filter: Filter by normalized severity (Critical, High, Medium, Low)
            source_filter: Filter by source ('wazuh' or 'suricata')
            search: Search term to filter alerts across all fields
            return_total: Whether to return total count and accurate statistics
            apply_mute_rules: Whether to apply mute rules (default: True)
            analyst: Current analyst username (for personal mute scope)
            mute_scope: Mute scope filter ('personal', 'team', 'global')

        Returns:
            Dictionary with metadata, statistics, and merged alerts
        """
        import time

        all_alerts = []
        sources_used = []
        total_count = 0
        statistics_by_severity = {'Critical': 0, 'High': 0, 'Medium': 0, 'Low': 0}
        statistics_by_source = {'wazuh': 0, 'suricata': 0}
        
        # If return_total=True, use aggregations to get accurate counts
        if return_total:
            start_time = time.time()
            
            # Get aggregations from Wazuh for accurate counts
            if source_filter is None or source_filter == 'wazuh':
                try:
                    wazuh_start = time.time()
                    # Map Wazuh severity filter to rule_level ranges
                    # Critical: >= 15, High: 12-14, Medium: 7-11, Low: 0-6
                    rule_level_min = None
                    rule_level_max = None
                    if severity_filter == 'Critical':
                        rule_level_min = 15
                        rule_level_max = None  # No upper limit
                    elif severity_filter == 'High':
                        rule_level_min = 12
                        rule_level_max = 15  # Exclusive: 12 <= level < 15
                    elif severity_filter == 'Medium':
                        rule_level_min = 7
                        rule_level_max = 12  # Exclusive: 7 <= level < 12
                    elif severity_filter == 'Low':
                        rule_level_min = 0
                        rule_level_max = 7  # Exclusive: 0 <= level < 7
                    
                    # Get aggregations with appropriate filters
                    wazuh_aggs = self.wazuh_manager.get_aggregations(
                        rule_level_min=rule_level_min,
                        rule_level_max=rule_level_max,
                        time_range_hours=time_range_hours,
                        search=search
                    )
                    
                    wazuh_total = wazuh_aggs.get('total', 0)
                    total_count += wazuh_total
                    statistics_by_source['wazuh'] = wazuh_total
                    
                    # Merge severity counts
                    wazuh_severity_counts = wazuh_aggs.get('by_severity', {})
                    for sev in statistics_by_severity:
                        statistics_by_severity[sev] += wazuh_severity_counts.get(sev, 0)
                    
                except Exception as e:
                    import logging
                    logging.getLogger(__name__).error(f"Error getting Wazuh aggregations: {e}")
            
            # Get counts from Suricata
            if source_filter is None or source_filter == 'suricata':
                try:
                    suricata_start = time.time()
                    suricata_severity = self._severity_to_suricata_level(severity_filter) if severity_filter else None
                    
                    # Use appropriate method based on data source
                    if self.suricata_data_source == 'elasticsearch':
                        # Use Elasticsearch aggregations (fast)
                        suricata_result = self.suricata_manager.get_aggregations(
                            severity=suricata_severity,
                            time_range_hours=time_range_hours,
                            search=search
                        )
                    else:
                        # Use file-based counting (slower but works for file-based systems)
                        suricata_result = self.suricata_manager.get_counts_and_breakdown(
                            time_range_hours=time_range_hours,
                            search=search,
                            severity=suricata_severity
                        )
                    
                    suricata_total = suricata_result.get('total', 0)
                    total_count += suricata_total
                    statistics_by_source['suricata'] = suricata_total
                    
                    # Merge severity breakdown
                    suricata_sev_counts = suricata_result.get('by_severity', {})
                    if severity_filter:
                        # If severity filter applied, add all to that severity
                        statistics_by_severity[severity_filter] = statistics_by_severity.get(severity_filter, 0) + suricata_total
                    else:
                        # No severity filter, use the breakdown
                        for sev, count in suricata_sev_counts.items():
                            statistics_by_severity[sev] = statistics_by_severity.get(sev, 0) + count
                    
                except Exception as e:
                    import logging
                    logging.getLogger(__name__).error(f"Error getting Suricata counts: {e}")
        
        # Now fetch only the alerts needed for this page
        fetch_start = time.time()
        # Calculate how many alerts we need to fetch per source
        # Since we merge and sort alerts from multiple sources, we need to fetch enough
        # to cover the offset + limit range. For safety, fetch offset + limit from each source.
        # This ensures we have enough alerts after merging to fill the requested page.
        fetch_limit = offset + limit_per_source  # Fetch enough to cover the requested page range
        
        # Fetch from Wazuh
        if source_filter is None or source_filter == 'wazuh':
            try:
                # Map severity filter to rule_level ranges
                # Critical: >= 15, High: 12-14, Medium: 7-11, Low: 0-6
                rule_level_min = None
                rule_level_max = None
                if severity_filter == 'Critical':
                    rule_level_min = 15
                    rule_level_max = None  # No upper limit
                elif severity_filter == 'High':
                    rule_level_min = 12
                    rule_level_max = 15  # Exclusive: 12 <= level < 15
                elif severity_filter == 'Medium':
                    rule_level_min = 7
                    rule_level_max = 12  # Exclusive: 7 <= level < 12
                elif severity_filter == 'Low':
                    rule_level_min = 0
                    rule_level_max = 7  # Exclusive: 0 <= level < 7
                
                wazuh_result = self.wazuh_manager.get_normalized_alerts(
                    limit=fetch_limit,
                    offset=0,  # We'll paginate after merge
                    rule_level_min=rule_level_min,
                    rule_level_max=rule_level_max,
                    time_range_hours=time_range_hours,
                    search=search
                )

                # Handle both dict and list return types (for backward compat)
                if isinstance(wazuh_result, dict):
                    wazuh_alerts = wazuh_result.get('alerts', [])
                else:
                    wazuh_alerts = wazuh_result

                all_alerts.extend(wazuh_alerts)
                sources_used.append('wazuh')
            except Exception as e:
                import logging
                logging.getLogger(__name__).error(f"Error fetching Wazuh alerts: {e}")

        # Fetch from Suricata
        if source_filter is None or source_filter == 'suricata':
            try:
                suricata_severity = self._severity_to_suricata_level(severity_filter) if severity_filter else None
                suricata_result = self.suricata_manager.get_normalized_alerts(
                    limit=fetch_limit,
                    offset=0,
                    severity=suricata_severity,
                    time_range_hours=time_range_hours,
                    search=search,
                    return_total=False
                )

                # Handle both dict and list return types
                if isinstance(suricata_result, dict):
                    suricata_alerts = suricata_result.get('alerts', [])
                else:
                    suricata_alerts = suricata_result

                all_alerts.extend(suricata_alerts)
                sources_used.append('suricata')
            except Exception as e:
                import logging
                logging.getLogger(__name__).error(f"Error fetching Suricata alerts: {e}")
        
        # Sort alerts based on sort_field and sort_direction parameters
        # Default: sort by severity (most severe first), then by timestamp (newest first)
        def get_sort_key(alert):
            if sort_field == 'timestamp':
                # Sort by timestamp only
                timestamp_str = alert.get('timestamp') or alert.get('@timestamp', '')
                try:
                    if timestamp_str:
                        ts = timestamp_str.replace('Z', '+00:00') if timestamp_str.endswith('Z') else timestamp_str
                        dt = datetime.fromisoformat(ts)
                        return dt.timestamp()
                    else:
                        return 0
                except (ValueError, AttributeError):
                    return 0
            elif sort_field == 'normalized_severity':
                # Sort by severity priority
                priority = SeverityMapper.get_severity_priority(alert.get('normalized_severity', 'Low'))
                return priority
            elif sort_field == 'source':
                # Sort by source (alphabetically)
                return alert.get('source', '')
            else:
                # Default: sort by severity first, then timestamp
                priority = SeverityMapper.get_severity_priority(alert.get('normalized_severity', 'Low'))
                timestamp_str = alert.get('timestamp') or alert.get('@timestamp', '')
                try:
                    if timestamp_str:
                        ts = timestamp_str.replace('Z', '+00:00') if timestamp_str.endswith('Z') else timestamp_str
                        dt = datetime.fromisoformat(ts)
                        timestamp_sort = -dt.timestamp()  # Negative for descending (newest first)
                    else:
                        timestamp_sort = 0
                except (ValueError, AttributeError):
                    timestamp_sort = 0
                return (priority, timestamp_sort)

        # Apply sorting with direction
        reverse_sort = (sort_direction == 'desc')
        all_alerts.sort(key=get_sort_key, reverse=reverse_sort)

        # Apply mute rules filtering (if enabled)
        pre_mute_count = len(all_alerts)
        muted_count = 0

        if apply_mute_rules and MUTE_MANAGER_AVAILABLE and all_alerts:
            try:
                mute_manager = MuteManager()
                filtered_alerts = mute_manager.apply_mute_rules(
                    all_alerts,
                    analyst=analyst,
                    scope=mute_scope
                )
                muted_count = pre_mute_count - len(filtered_alerts)
                all_alerts = filtered_alerts
            except Exception as e:
                import logging
                logging.getLogger(__name__).error(f"Error applying mute rules: {e}")

        # If return_total=False, use fetched alerts to calculate statistics
        if not return_total:
            # Calculate statistics from fetched alerts
            for alert in all_alerts:
                sev = alert.get('normalized_severity', 'Low')
                statistics_by_severity[sev] = statistics_by_severity.get(sev, 0) + 1
            total_count = len(all_alerts)

        # Generate full statistics (including by_source, by_category, etc.)
        statistics = self._generate_statistics(all_alerts)

        # Override severity and source counts with accurate ones if return_total=True
        if return_total:
            statistics['by_severity'] = statistics_by_severity
            statistics['by_source'] = statistics_by_source

            # IMPORTANT: Use Elasticsearch aggregations for accurate by_agent stats
            # This ensures ALL agents are included, not just those in the fetched alerts
            try:
                accurate_agent_stats = self.wazuh_manager.get_agent_statistics(
                    time_range_hours=time_range_hours,
                    search=search
                )
                if accurate_agent_stats:
                    statistics['by_agent'] = accurate_agent_stats
            except Exception as e:
                import logging
                logging.getLogger(__name__).warning(f"Failed to get accurate agent stats: {e}")
        
        # Apply pagination (offset and limit)
        # Use limit_per_source directly - frontend controls the page size (default 1000)
        page_size = limit_per_source
        
        if return_total:
            # Apply offset and limit after sorting
            paginated_alerts = all_alerts[offset:offset + page_size]
        else:
            # Limit to requested size
            paginated_alerts = all_alerts[:page_size]
        
        result = {
            'metadata': {
                'total_alerts': total_count if return_total else len(paginated_alerts),
                'loaded_alerts': len(paginated_alerts),
                'time_range_hours': time_range_hours,
                'timestamp': datetime.now().isoformat(),
                'sources': sources_used,
                'severity_filter': severity_filter,
                'source_filter': source_filter,
                'muted_count': muted_count if apply_mute_rules else 0,
                'mute_rules_applied': apply_mute_rules
            },
            'statistics': statistics,
            'alerts': paginated_alerts
        }
        
        # Add total count if requested
        if return_total:
            result['total'] = total_count
            result['metadata']['offset'] = offset
            result['metadata']['limit'] = limit_per_source

        return result
    
    @staticmethod
    def _severity_to_suricata_level(severity: str) -> Optional[int]:
        """
        Convert normalized severity to Suricata severity level
        
        Suricata severity levels:
        1 = Critical/High (most severe)
        2 = High/Medium
        3 = Medium/Low
        4+ = Low
        
        Our normalization (in _normalize_severity):
        1 → Critical
        2 → High
        3 → Medium
        4+ → Low
        """
        mapping = {
            'Critical': 1,
            'High': 2,      # Fixed: was 1, should be 2
            'Medium': 3,    # Fixed: was 2, should be 3
            'Low': 4        # Fixed: was 3, should be 4
        }
        return mapping.get(severity)
    
    def _generate_statistics(self, alerts: List[Dict[str, Any]]) -> Dict[str, Any]:
        """
        Generate statistics from merged alerts

        Args:
            alerts: List of normalized alert dictionaries

        Returns:
            Dictionary containing statistics
        """
        stats = {
            'by_severity': {'Critical': 0, 'High': 0, 'Medium': 0, 'Low': 0},
            'by_source': {'wazuh': 0, 'suricata': 0},
            'by_category': {},
            'top_agents': {},
            'top_signatures': {},
            'top_src_ips': {},
            'top_dest_ips': {}
        }

        # Track per-agent severity breakdown for frontend topology
        agent_severity_breakdown = {}

        for alert in alerts:
            # Count by severity
            severity = alert.get('normalized_severity', 'Low')
            stats['by_severity'][severity] = stats['by_severity'].get(severity, 0) + 1

            # Count by source
            source = alert.get('source', 'unknown')
            stats['by_source'][source] = stats['by_source'].get(source, 0) + 1

            # Count by category/rule description
            if source == 'wazuh':
                category = alert.get('rule_description', 'Unknown')
                agent = alert.get('agent_name', 'Unknown')
                # Extract agent_ip and agent_os from raw alert data
                raw_agent = alert.get('raw', {}).get('agent', {})
                agent_ip = raw_agent.get('ip', 'Unknown')
                agent_os = raw_agent.get('os', {}).get('platform', 'Unknown') if raw_agent.get('os') else 'Unknown'
                agent_id = alert.get('agent_id', raw_agent.get('id', 'Unknown'))
                stats['top_agents'][agent] = stats['top_agents'].get(agent, 0) + 1

                # Track severity breakdown per agent
                if agent not in agent_severity_breakdown:
                    agent_severity_breakdown[agent] = {
                        'agent': agent,
                        'agent_id': agent_id,
                        'agent_ip': agent_ip,
                        'agent_os': agent_os,
                        'Critical': 0,
                        'High': 0,
                        'Medium': 0,
                        'Low': 0,
                        'total': 0
                    }
                # Update IP and OS if we find better values (in case first alert had Unknown)
                if agent_severity_breakdown[agent]['agent_ip'] == 'Unknown' and agent_ip != 'Unknown':
                    agent_severity_breakdown[agent]['agent_ip'] = agent_ip
                if agent_severity_breakdown[agent]['agent_os'] == 'Unknown' and agent_os != 'Unknown':
                    agent_severity_breakdown[agent]['agent_os'] = agent_os
                agent_severity_breakdown[agent][severity] = agent_severity_breakdown[agent].get(severity, 0) + 1
                agent_severity_breakdown[agent]['total'] += 1
            else:  # suricata
                category = alert.get('category', 'Unknown')
                signature = alert.get('signature', 'Unknown')
                stats['top_signatures'][signature] = stats['top_signatures'].get(signature, 0) + 1

                # Track IPs for Suricata
                src_ip = alert.get('src_ip', 'Unknown')
                dest_ip = alert.get('dest_ip', 'Unknown')
                stats['top_src_ips'][src_ip] = stats['top_src_ips'].get(src_ip, 0) + 1
                stats['top_dest_ips'][dest_ip] = stats['top_dest_ips'].get(dest_ip, 0) + 1

            stats['by_category'][category] = stats['by_category'].get(category, 0) + 1

        # Sort and limit top items to top 5
        stats['by_category'] = dict(sorted(stats['by_category'].items(), key=lambda x: x[1], reverse=True)[:5])
        stats['top_agents'] = dict(sorted(stats['top_agents'].items(), key=lambda x: x[1], reverse=True)[:5])
        stats['top_signatures'] = dict(sorted(stats['top_signatures'].items(), key=lambda x: x[1], reverse=True)[:5])
        stats['top_src_ips'] = dict(sorted(stats['top_src_ips'].items(), key=lambda x: x[1], reverse=True)[:5])
        stats['top_dest_ips'] = dict(sorted(stats['top_dest_ips'].items(), key=lambda x: x[1], reverse=True)[:5])

        # Convert agent severity breakdown to array sorted by total alerts (for frontend topology)
        stats['by_agent'] = sorted(
            agent_severity_breakdown.values(),
            key=lambda x: x['total'],
            reverse=True
        )

        return stats
    
    def get_wazuh_alerts(self,
                        limit: int = 100,
                        rule_level: Optional[int] = None,
                        time_range_hours: int = 24) -> Dict[str, Any]:
        """
        Get Wazuh alerts only
        
        Args:
            limit: Maximum number of alerts
            rule_level: Filter by rule level
            time_range_hours: Time range in hours
            
        Returns:
            Dictionary with Wazuh alerts and statistics
        """
        # Get normalized alerts (includes source field)
        normalized_alerts = self.wazuh_manager.get_normalized_alerts(
            limit=limit,
            rule_level=rule_level,
            time_range_hours=time_range_hours
        )
        
        # Get raw alerts for statistics
        raw_alerts = self.wazuh_manager.get_alerts(
            limit=limit,
            rule_level=rule_level,
            time_range_hours=time_range_hours
        )
        
        statistics = self.wazuh_manager.get_statistics(raw_alerts)
        
        return {
            'metadata': {
                'total_alerts': len(normalized_alerts),
                'source': 'wazuh',
                'time_range_hours': time_range_hours,
                'timestamp': datetime.now().isoformat(),
                'data_source': 'real'
            },
            'statistics': statistics,
            'alerts': normalized_alerts
        }
    
    def get_suricata_alerts(self,
                           limit: int = 100,
                           severity: Optional[int] = None,
                           time_range_hours: int = 24) -> Dict[str, Any]:
        """
        Get Suricata alerts only
        
        Args:
            limit: Maximum number of alerts
            severity: Filter by severity (1=high, 2=medium, 3=low)
            time_range_hours: Time range in hours
            
        Returns:
            Dictionary with Suricata alerts and statistics
        """
        # Get normalized alerts (includes source field)
        normalized_alerts = self.suricata_manager.get_normalized_alerts(
            limit=limit,
            severity=severity,
            time_range_hours=time_range_hours
        )
        
        # Get raw alerts for statistics
        raw_alerts = self.suricata_manager.get_alerts(
            limit=limit,
            severity=severity,
            time_range_hours=time_range_hours
        )
        
        statistics = self.suricata_manager.get_statistics(raw_alerts)
        
        return {
            'metadata': {
                'total_alerts': len(normalized_alerts),
                'source': 'suricata',
                'time_range_hours': time_range_hours,
                'timestamp': datetime.now().isoformat(),
                'data_source': 'real'
            },
            'statistics': statistics,
            'alerts': normalized_alerts
        }

    def get_threat_actor_aggregations(self,
                                       time_range_hours: int = 24,
                                       min_severity: str = 'High',
                                       limit: int = 50) -> Dict[str, Any]:
        """
        Get threat actor data using ES aggregations from both Wazuh and Suricata.
        This is much faster than fetching all alerts and aggregating in Python.

        Args:
            time_range_hours: Time range in hours to look back
            min_severity: Minimum severity level ('Critical' or 'High')
            limit: Maximum number of source IPs to return per source

        Returns:
            Dict with combined threat actor data from both sources
        """
        import logging
        logger = logging.getLogger(__name__)

        all_threat_actors = []
        total_alerts = 0

        # Get Wazuh threat actors
        try:
            wazuh_result = self.wazuh_manager.get_threat_actor_aggregations(
                time_range_hours=time_range_hours,
                min_severity=min_severity,
                limit=limit
            )
            all_threat_actors.extend(wazuh_result.get('threat_actors', []))
            total_alerts += wazuh_result.get('total_alerts', 0)
            logger.info(f"[ThreatActors] Wazuh: {len(wazuh_result.get('threat_actors', []))} IPs from {wazuh_result.get('total_alerts', 0)} alerts")
        except Exception as e:
            logger.warning(f"[ThreatActors] Wazuh aggregation failed: {e}")

        # Get Suricata threat actors
        try:
            if hasattr(self.suricata_manager, 'get_threat_actor_aggregations'):
                suricata_result = self.suricata_manager.get_threat_actor_aggregations(
                    time_range_hours=time_range_hours,
                    min_severity=min_severity,
                    limit=limit
                )
                all_threat_actors.extend(suricata_result.get('threat_actors', []))
                total_alerts += suricata_result.get('total_alerts', 0)
                logger.info(f"[ThreatActors] Suricata: {len(suricata_result.get('threat_actors', []))} IPs from {suricata_result.get('total_alerts', 0)} alerts")
        except Exception as e:
            logger.warning(f"[ThreatActors] Suricata aggregation failed: {e}")

        # Merge duplicate IPs from both sources
        merged_actors = {}
        for actor in all_threat_actors:
            ip = actor.get('ip')
            if ip in merged_actors:
                # Merge counts
                existing = merged_actors[ip]
                existing['alert_count'] += actor.get('alert_count', 0)
                existing['critical_count'] += actor.get('critical_count', 0)
                existing['high_count'] += actor.get('high_count', 0)
                # Merge signatures and targets (dedupe)
                existing['signatures'] = list(set(existing.get('signatures', []) + actor.get('signatures', [])))[:10]
                existing['targets'] = list(set(existing.get('targets', []) + actor.get('targets', [])))[:10]
                # Update timestamps
                if actor.get('first_seen') and (not existing.get('first_seen') or actor['first_seen'] < existing['first_seen']):
                    existing['first_seen'] = actor['first_seen']
                if actor.get('last_seen') and (not existing.get('last_seen') or actor['last_seen'] > existing['last_seen']):
                    existing['last_seen'] = actor['last_seen']
                # Mark as multi-source
                existing['source'] = 'both'
            else:
                merged_actors[ip] = actor.copy()

        # Calculate risk scores and sort
        result_actors = []
        for ip, data in merged_actors.items():
            risk_score = min(100,
                (data.get('critical_count', 0) * 30) +
                (data.get('high_count', 0) * 15) +
                (data.get('alert_count', 0) * 2)
            )
            data['risk_score'] = risk_score
            result_actors.append(data)

        # Sort by risk score descending
        result_actors.sort(key=lambda x: (-x.get('risk_score', 0), -x.get('alert_count', 0)))

        # Limit to requested number
        result_actors = result_actors[:limit]

        return {
            'threat_actors': result_actors,
            'total_unique_ips': len(merged_actors),
            'total_alerts': total_alerts,
            'time_range_hours': time_range_hours,
            'min_severity': min_severity
        }
