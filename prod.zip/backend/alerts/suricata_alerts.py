#!/usr/bin/env python3
"""
Suricata Alerts Manager
Fetches and manages network security alerts from Suricata eve.json log file.
"""

import json
import os
import time
import sys
from datetime import datetime, timedelta
from typing import List, Dict, Any, Optional
from collections import defaultdict


class SuricataAlertsManager:
    """Manager class for Suricata network security alerts"""
    
    def __init__(self, log_file='/var/log/suricata/eve.json'):
        """
        Initialize Suricata Alerts Manager
        
        Args:
            log_file: Path to Suricata eve.json log file
        """
        self.log_file = log_file
        self._log_exists = os.path.exists(log_file)
        
    def test_connection(self) -> bool:
        """
        Test if Suricata log file exists and is readable
        
        Returns:
            bool: True if log file exists and is readable
        """
        try:
            if not os.path.exists(self.log_file):
                return False
            
            # Try to read the file
            with open(self.log_file, 'r') as f:
                # Read just one line to test
                f.readline()
            return True
        except Exception as e:
            return False
    
    def get_alerts(self,
                   limit: Optional[int] = 100,
                   offset: Optional[int] = 0,
                   severity: Optional[int] = None,
                   time_range_hours: Optional[int] = 24,
                   src_ip: Optional[str] = None,
                   dest_ip: Optional[str] = None,
                   signature: Optional[str] = None,
                   category: Optional[str] = None,
                   search: Optional[str] = None,
                   return_total: bool = False) -> Dict[str, Any]:
        """
        Parse alerts from Suricata eve.json
        
        Args:
            limit: Maximum number of alerts to return
            offset: Number of alerts to skip (for pagination)
            severity: Filter by severity (1=high, 2=medium, 3=low)
            time_range_hours: Only include alerts from last N hours
            src_ip: Filter by source IP
            dest_ip: Filter by destination IP
            signature: Filter by signature name (substring match)
            category: Filter by category (substring match)
            search: General search term (searches signature, category, src_ip, dest_ip)
            return_total: If True, return dict with alerts and total count
            
        Returns:
            Dict with 'alerts' list and 'total' count if return_total=True, else just list
        """
        if not os.path.exists(self.log_file):
            return {'alerts': [], 'total': 0} if return_total else []
        
        alerts = []
        time_cutoff = None
        
        if time_range_hours:
            time_cutoff = datetime.now() - timedelta(hours=time_range_hours)
        
        try:
            # Read file in reverse to get most recent alerts first
            # For large files, we need to read enough lines to cover the time range
            import subprocess
            
            # First, get file size to determine reading strategy
            file_size = os.path.getsize(self.log_file) if os.path.exists(self.log_file) else 0
            file_size_mb = file_size / (1024 * 1024)
            
            # Estimate lines: assume ~100 bytes per line on average
            estimated_lines = int(file_size / 100) if file_size > 0 else 0
            
            # For time-based reading, we need to ensure we read enough to cover the time range
            # Strategy: Read the entire file if it's reasonable size (< 1GB), otherwise use tail
            # For 30 days, read the entire file to ensure we don't miss older alerts
            if file_size_mb < 1024 and time_range_hours and time_range_hours >= 720:  # 30 days, file < 1GB
                # Read entire file for comprehensive coverage
                print(f"DEBUG: Reading entire file ({file_size_mb:.1f} MB, ~{estimated_lines} lines) for 30-day range")
                with open(self.log_file, 'r') as f:
                    lines = f.readlines()
                lines.reverse()
            elif time_range_hours and time_range_hours >= 720:  # 30 days, large file
                # For very large files (>1GB), use a larger tail buffer
                # Use min of estimated lines or 1 million lines
                line_count = str(min(estimated_lines, 1000000))
                print(f"DEBUG: Using tail -n {line_count} (file has ~{estimated_lines} lines)")
                try:
                    result = subprocess.run(
                        ['tail', '-n', line_count, self.log_file],
                        capture_output=True,
                        text=True,
                        timeout=60  # Increased timeout for very large files
                    )
                    lines = result.stdout.strip().split('\n') if result.returncode == 0 else []
                    lines.reverse()
                except Exception as e:
                    print(f"DEBUG: Tail failed, reading entire file: {e}")
                    with open(self.log_file, 'r') as f:
                        lines = f.readlines()
                    lines.reverse()
            else:
                # For shorter time ranges, use tail with appropriate line count
                if time_range_hours and time_range_hours >= 168:  # 7 days
                    line_count = '500000'  # Increased for larger files
                elif time_range_hours and time_range_hours <= 24:  # 24 hours
                    line_count = '50000'
                else:
                    line_count = '200000'
                
                try:
                    result = subprocess.run(
                        ['tail', '-n', line_count, self.log_file],
                        capture_output=True,
                        text=True,
                        timeout=30
                    )
                    lines = result.stdout.strip().split('\n') if result.returncode == 0 else []
                    lines.reverse()
                except:
                    # Fallback to reading entire file if tail fails
                    with open(self.log_file, 'r') as f:
                        lines = f.readlines()
                    lines.reverse()
            
            matched_count = 0  # Track total matches for pagination
            skipped_count = 0  # Track skipped alerts for offset
            
            for line in lines:
                try:
                    event = json.loads(line.strip())
                    
                    # Only process alert events
                    if event.get('event_type') != 'alert':
                        continue
                    
                    # Apply filters
                    if severity and event.get('alert', {}).get('severity') != severity:
                        continue
                    
                    if src_ip and event.get('src_ip') != src_ip:
                        continue
                    
                    if dest_ip and event.get('dest_ip') != dest_ip:
                        continue
                    
                    if signature:
                        sig = event.get('alert', {}).get('signature', '')
                        if signature.lower() not in sig.lower():
                            continue
                    
                    if category:
                        cat = event.get('alert', {}).get('category', '')
                        if category.lower() not in cat.lower():
                            continue
                    
                    # General search filter (searches across multiple fields)
                    if search:
                        search_lower = search.lower()
                        sig = event.get('alert', {}).get('signature', '').lower()
                        cat = event.get('alert', {}).get('category', '').lower()
                        src = event.get('src_ip', '')
                        dst = event.get('dest_ip', '')
                        
                        # Check if search term matches any field
                        if not (search_lower in sig or 
                                search_lower in cat or 
                                search in src or 
                                search in dst):
                            continue
                    
                    # Time filter
                    if time_cutoff:
                        try:
                            ts_str = event.get('timestamp', '')
                            # Handle timezone-aware timestamps
                            if '+' in ts_str or 'Z' in ts_str:
                                # Split at decimal and timezone
                                ts_str = ts_str.split('.')[0] if '.' in ts_str else ts_str.split('+')[0].split('Z')[0]
                            event_time = datetime.strptime(ts_str, '%Y-%m-%dT%H:%M:%S')
                            if event_time < time_cutoff:
                                continue
                        except:
                            pass  # If we can't parse time, include the event
                    
                    # This alert matches all filters
                    matched_count += 1
                    
                    # Skip alerts for offset (pagination)
                    if offset and skipped_count < offset:
                        skipped_count += 1
                        continue
                    
                    # Add to results
                    alerts.append(event)
                    
                    # Check limit (but keep counting for total if needed)
                    if limit and len(alerts) >= limit:
                        # If we don't need total, we can break early
                        if not return_total:
                            break
                        # Otherwise continue counting but don't add more alerts
                        
                except json.JSONDecodeError:
                    continue  # Skip malformed lines
            
            # Already in newest-first order since we reversed the lines
            if return_total:
                return {'alerts': alerts, 'total': matched_count}
            return alerts
            
        except Exception as e:
            if return_total:
                return {'alerts': [], 'total': 0}
            return []
    
    def get_counts_and_breakdown(self, time_range_hours: int = 720, search: Optional[str] = None, severity: Optional[int] = None) -> Dict[str, Any]:
        """
        OPTIMIZED: Get total count AND severity breakdown in ONE pass through file
        
        Args:
            time_range_hours: Number of hours to look back
            search: Optional search term
            severity: Optional severity filter (1-5)
            
        Returns:
            {'total': N, 'by_severity': {'Critical': N, 'High': N, 'Medium': N, 'Low': N}}
        """
        import subprocess
        
        start_time = time.time()
        print(f"[{time.strftime('%H:%M:%S')}] OPTIMIZED: Single-pass count (total + severity breakdown)", flush=True)
        
        if not os.path.exists(self.log_file):
            return {'total': 0, 'by_severity': {'Critical': 0, 'High': 0, 'Medium': 0, 'Low': 0}}
        
        try:
            # Read file (entire file for 30-day, tail for shorter)
            file_size = os.path.getsize(self.log_file)
            file_size_gb = file_size / (1024 * 1024 * 1024)
            
            # Choose reading strategy
            if time_range_hours >= 720:  # 30+ days
                if file_size_gb < 1.0:
                    read_start = time.time()
                    print(f"[{time.strftime('%H:%M:%S')}] Reading entire file ({file_size_gb:.2f}GB)", flush=True)
                    with open(self.log_file, 'r') as f:
                        lines = f.readlines()
                    print(f"[{time.strftime('%H:%M:%S')}] Read {len(lines):,} lines in {time.time()-read_start:.2f}s", flush=True)
                else:
                    line_count = 1000000  # 1M lines for large files
                    read_start = time.time()
                    print(f"[{time.strftime('%H:%M:%S')}] Using tail -n {line_count}", flush=True)
                    result = subprocess.run(
                        ['tail', '-n', str(line_count), self.log_file],
                        capture_output=True,
                        text=True,
                        timeout=30
                    )
                    lines = result.stdout.strip().split('\n') if result.returncode == 0 else []
                    print(f"[{time.strftime('%H:%M:%S')}] Read {len(lines):,} lines in {time.time()-read_start:.2f}s", flush=True)
            else:
                # Shorter time range, use tail
                line_count = 500000 if time_range_hours >= 168 else 200000
                read_start = time.time()
                print(f"[{time.strftime('%H:%M:%S')}] Using tail -n {line_count}", flush=True)
                result = subprocess.run(
                    ['tail', '-n', str(line_count), self.log_file],
                    capture_output=True,
                    text=True,
                    timeout=30
                )
                lines = result.stdout.strip().split('\n') if result.returncode == 0 else []
                print(f"[{time.strftime('%H:%M:%S')}] Read {len(lines):,} lines in {time.time()-read_start:.2f}s", flush=True)
            
            # SINGLE PASS: Count total AND breakdown
            cutoff_time = datetime.now() - timedelta(hours=time_range_hours)
            severity_counts = defaultdict(int)
            total = 0
            
            parse_start = time.time()
            for line in lines:
                try:
                    event = json.loads(line.strip())
                    if event.get('event_type') != 'alert':
                        continue
                    
                    # Time filter
                    timestamp_str = event.get('timestamp', '')
                    if timestamp_str:
                        try:
                            if '+' in timestamp_str or 'Z' in timestamp_str:
                                timestamp_str = timestamp_str.split('.')[0] if '.' in timestamp_str else timestamp_str.split('+')[0].split('Z')[0]
                            event_time = datetime.strptime(timestamp_str, '%Y-%m-%dT%H:%M:%S')
                            if event_time < cutoff_time:
                                continue
                        except ValueError:
                            pass
                    
                    # Search filter
                    if search:
                        search_lower = search.lower()
                        alert_info = event.get('alert', {})
                        src_ip = event.get('src_ip', '')
                        dest_ip = event.get('dest_ip', '')
                        signature = alert_info.get('signature', '')
                        category = alert_info.get('category', '')
                        
                        if not any(search_lower in str(field).lower() for field in [src_ip, dest_ip, signature, category]):
                            continue
                    
                    # Get severity
                    alert_severity = event.get('alert', {}).get('severity', 5)
                    
                    # Severity filter (if specified)
                    if severity is not None and alert_severity != severity:
                        continue
                    
                    # Count this alert
                    total += 1
                    severity_counts[alert_severity] += 1
                    
                except (json.JSONDecodeError, KeyError, ValueError):
                    continue
            
            parse_time = time.time() - parse_start
            
            # Normalize severity counts
            result = {
                'total': total,
                'by_severity': {
                    'Critical': severity_counts.get(1, 0),
                    'High': severity_counts.get(2, 0),
                    'Medium': severity_counts.get(3, 0),
                    'Low': severity_counts.get(4, 0) + severity_counts.get(5, 0)
                }
            }
            
            total_time = time.time() - start_time
            print(f"[{time.strftime('%H:%M:%S')}] OPTIMIZED complete - parse: {parse_time:.2f}s, total: {total_time:.2f}s, counted: {total:,}", flush=True)
            
            return result
            
        except Exception as e:
            print(f"ERROR in get_counts_and_breakdown: {e}", flush=True)
            import traceback
            traceback.print_exc()
            return {'total': 0, 'by_severity': {'Critical': 0, 'High': 0, 'Medium': 0, 'Low': 0}}
    
    def get_counts_by_severity(self,
                               time_range_hours: int = 24,
                               search: Optional[str] = None) -> Dict[str, int]:
        """
        Efficiently count alerts by severity without loading all alerts into memory
        Single pass through the file to count all severities
        
        Args:
            time_range_hours: Time range in hours
            search: Search term to filter alerts
            
        Returns:
            Dict with counts by normalized severity
        """
        if not os.path.exists(self.log_file):
            return {'Critical': 0, 'High': 0, 'Medium': 0, 'Low': 0}
        
        counts = {'Critical': 0, 'High': 0, 'Medium': 0, 'Low': 0}
        time_cutoff = None
        
        if time_range_hours:
            time_cutoff = datetime.now() - timedelta(hours=time_range_hours)
        
        try:
            import subprocess
            
            # Read entire file for 30-day queries
            file_size = os.path.getsize(self.log_file) if os.path.exists(self.log_file) else 0
            file_size_mb = file_size / (1024 * 1024)
            
            if file_size_mb < 1024 and time_range_hours and time_range_hours >= 720:
                with open(self.log_file, 'r') as f:
                    lines = f.readlines()
            else:
                line_count = '500000' if time_range_hours >= 168 else '200000'
                result = subprocess.run(
                    ['tail', '-n', line_count, self.log_file],
                    capture_output=True,
                    text=True,
                    timeout=30
                )
                lines = result.stdout.strip().split('\n') if result.returncode == 0 else []
            
            # Single pass to count all severities
            for line in lines:
                try:
                    event = json.loads(line.strip())
                    
                    if event.get('event_type') != 'alert':
                        continue
                    
                    # Apply time filter
                    if time_cutoff:
                        try:
                            ts_str = event.get('timestamp', '')
                            if '+' in ts_str or 'Z' in ts_str:
                                ts_str = ts_str.split('.')[0] if '.' in ts_str else ts_str.split('+')[0].split('Z')[0]
                            event_time = datetime.strptime(ts_str, '%Y-%m-%dT%H:%M:%S')
                            if event_time < time_cutoff:
                                continue
                        except:
                            pass
                    
                    # Apply search filter
                    if search:
                        search_lower = search.lower()
                        sig = event.get('alert', {}).get('signature', '').lower()
                        cat = event.get('alert', {}).get('category', '').lower()
                        src = event.get('src_ip', '')
                        dst = event.get('dest_ip', '')
                        
                        if not (search_lower in sig or search_lower in cat or search in src or search in dst):
                            continue
                    
                    # Count by severity
                    severity = event.get('alert', {}).get('severity', 5)
                    normalized_sev = self._normalize_severity(severity)
                    counts[normalized_sev] += 1
                    
                except json.JSONDecodeError:
                    continue
            
            return counts
            
        except Exception as e:
            return {'Critical': 0, 'High': 0, 'Medium': 0, 'Low': 0}
    
    def get_normalized_alerts(self,
                             limit: int = 100,
                             offset: int = 0,
                             severity: Optional[int] = None,
                             time_range_hours: int = 24,
                             search: Optional[str] = None,
                             return_total: bool = False) -> Dict[str, Any]:
        """
        Get alerts in normalized format for unified API with pagination support
        
        Args:
            limit: Maximum number of alerts
            offset: Number of alerts to skip (for pagination)
            severity: Filter by severity (1=high, 2=medium, 3=low)
            time_range_hours: Time range in hours
            search: Search term to filter alerts
            return_total: Whether to return total count
            
        Returns:
            Dict with 'alerts' list and 'total' count if return_total=True, else just list (for backward compat)
        """
        result = self.get_alerts(
            limit=limit,
            offset=offset,
            severity=severity,
            time_range_hours=time_range_hours,
            search=search,
            return_total=return_total
        )
        
        if return_total:
            raw_alerts = result.get('alerts', [])
            total = result.get('total', 0)
        else:
            raw_alerts = result if isinstance(result, list) else result.get('alerts', [])
            total = 0
        
        normalized_alerts = []
        for event in raw_alerts:
            alert_info = event.get('alert', {})
            
            normalized = {
                'source': 'suricata',
                'timestamp': event.get('timestamp'),
                'alert_id': f"suricata_{event.get('flow_id')}_{alert_info.get('signature_id')}",
                'signature_id': alert_info.get('signature_id'),
                'signature': alert_info.get('signature'),
                'category': alert_info.get('category'),
                'severity': alert_info.get('severity', 5),
                'normalized_severity': self._normalize_severity(alert_info.get('severity', 5)),
                'action': alert_info.get('action'),
                'src_ip': event.get('src_ip'),
                'src_port': event.get('src_port'),
                'dest_ip': event.get('dest_ip'),
                'dest_port': event.get('dest_port'),
                'protocol': event.get('proto'),
                'app_proto': event.get('app_proto'),
                'flow_id': event.get('flow_id'),
                'raw': event
            }
            normalized_alerts.append(normalized)
        
        if return_total:
            return {
                'alerts': normalized_alerts,
                'total': total
            }
        else:
            # Backward compatibility: return list if not requesting total
            return normalized_alerts
    
    def get_statistics(self, alerts: List[Dict[str, Any]]) -> Dict[str, Any]:
        """
        Generate statistics from alerts
        
        Args:
            alerts: List of alert dictionaries
            
        Returns:
            Dictionary containing statistics
        """
        if not alerts:
            return {
                'total': 0,
                'by_severity': {},
                'by_category': {},
                'by_signature': {},
                'by_src_ip': {},
                'by_dest_ip': {},
                'by_proto': {}
            }
        
        stats = {
            'total': len(alerts),
            'by_severity': defaultdict(int),
            'by_category': defaultdict(int),
            'by_signature': defaultdict(int),
            'by_src_ip': defaultdict(int),
            'by_dest_ip': defaultdict(int),
            'by_proto': defaultdict(int),
        }
        
        for alert in alerts:
            alert_info = alert.get('alert', {})
            severity = alert_info.get('severity', 0)
            normalized_sev = self._normalize_severity(severity)
            stats['by_severity'][normalized_sev] += 1
            
            category = alert_info.get('category', 'Unknown')
            stats['by_category'][category] += 1
            
            signature = alert_info.get('signature', 'Unknown')
            stats['by_signature'][signature] += 1
            
            src_ip = alert.get('src_ip', 'Unknown')
            stats['by_src_ip'][src_ip] += 1
            
            dest_ip = alert.get('dest_ip', 'Unknown')
            stats['by_dest_ip'][dest_ip] += 1
            
            proto = alert.get('proto', 'Unknown')
            stats['by_proto'][proto] += 1
        
        # Convert defaultdict to dict
        stats['by_severity'] = dict(stats['by_severity'])
        stats['by_category'] = dict(stats['by_category'])
        stats['by_signature'] = dict(stats['by_signature'])
        stats['by_src_ip'] = dict(stats['by_src_ip'])
        stats['by_dest_ip'] = dict(stats['by_dest_ip'])
        stats['by_proto'] = dict(stats['by_proto'])
        
        return stats
    
    @staticmethod
    def _normalize_severity(severity: int) -> str:
        """
        Normalize Suricata severity to standard severity
        
        Suricata Severity:
        - Critical/High: 1
        - High/Medium: 2
        - Medium/Low: 3
        - Low: 4+
        
        Args:
            severity: Suricata severity level
            
        Returns:
            Normalized severity string
        """
        if severity == 1:
            return "Critical"
        elif severity == 2:
            return "High"
        elif severity == 3:
            return "Medium"
        else:  # 4, 5 or higher
            return "Low"


