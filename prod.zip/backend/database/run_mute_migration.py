#!/usr/bin/env python3
"""
Athena Security Platform - Mute Rules Database Migration
Run this script to create mute_rules and mute_audit_log tables
"""

import psycopg2
import os
import sys
from pathlib import Path

# Database connection details (adjust as needed)
DB_CONFIG = {
    'host': os.getenv('DB_HOST', 'localhost'),
    'database': os.getenv('DB_NAME', 'athena_db'),
    'user': os.getenv('DB_USER', 'athena_user'),
    'password': os.getenv('DB_PASSWORD', 'athena_password'),
    'port': os.getenv('DB_PORT', '5432')
}

def run_migration():
    """Execute the mute schema SQL migration"""

    print("=" * 70)
    print("Athena Mute Rules - Database Migration")
    print("=" * 70)
    print()

    # Get SQL file path
    script_dir = Path(__file__).parent
    sql_file = script_dir / 'mute_schema.sql'

    if not sql_file.exists():
        print(f"[-] ERROR: SQL file not found: {sql_file}")
        sys.exit(1)

    print(f"[*] SQL File: {sql_file}")
    print(f"[*] Database: {DB_CONFIG['database']} @ {DB_CONFIG['host']}")
    print()

    # Read SQL file
    with open(sql_file, 'r', encoding='utf-8') as f:
        sql_script = f.read()

    # Connect to database
    try:
        print("[*] Connecting to PostgreSQL...")
        conn = psycopg2.connect(**DB_CONFIG)
        conn.autocommit = True
        cursor = conn.cursor()
        print("[+] Connected successfully")
        print()

    except psycopg2.Error as e:
        print(f"[-] Connection failed: {e}")
        print()
        print("[!] Make sure PostgreSQL is running and credentials are correct")
        print("   You can set environment variables:")
        print("   - DB_HOST, DB_NAME, DB_USER, DB_PASSWORD, DB_PORT")
        sys.exit(1)

    # Execute migration
    try:
        print("[*] Running migration...")
        print()

        cursor.execute(sql_script)

        print("[+] Migration completed successfully!")
        print()

        # Verify tables created
        print("[*] Verifying tables...")
        cursor.execute("""
            SELECT table_name,
                   (SELECT COUNT(*) FROM information_schema.columns
                    WHERE table_name = t.table_name) as column_count
            FROM information_schema.tables t
            WHERE table_schema = 'public'
            AND table_name IN ('mute_rules', 'mute_audit_log')
            ORDER BY table_name
        """)

        tables = cursor.fetchall()

        if len(tables) == 2:
            print("[+] Tables created:")
            for table_name, col_count in tables:
                print(f"   - {table_name} ({col_count} columns)")
            print()
        else:
            print("[!] Warning: Expected 2 tables, found", len(tables))
            print()

        # Verify indexes
        print("[*] Verifying indexes...")
        cursor.execute("""
            SELECT tablename, COUNT(*) as index_count
            FROM pg_indexes
            WHERE tablename IN ('mute_rules', 'mute_audit_log')
            GROUP BY tablename
            ORDER BY tablename
        """)

        indexes = cursor.fetchall()
        for table_name, index_count in indexes:
            print(f"   - {table_name}: {index_count} indexes")
        print()

        # Check sample data
        cursor.execute("SELECT COUNT(*) FROM mute_rules")
        mute_count = cursor.fetchone()[0]

        cursor.execute("SELECT COUNT(*) FROM mute_audit_log")
        audit_count = cursor.fetchone()[0]

        print(f"[*] Sample data inserted:")
        print(f"   - {mute_count} mute rules")
        print(f"   - {audit_count} audit log entries")
        print()

        print("=" * 70)
        print("[+] MIGRATION COMPLETE!")
        print("=" * 70)
        print()
        print("Next steps:")
        print("1. Implement MuteManager backend class")
        print("2. Create API endpoints")
        print("3. Integrate with unified alerts endpoint")
        print()

    except psycopg2.Error as e:
        print(f"[-] Migration failed: {e}")
        print()
        conn.rollback()
        sys.exit(1)

    finally:
        cursor.close()
        conn.close()

if __name__ == '__main__':
    run_migration()
