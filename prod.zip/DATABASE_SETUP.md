# Athena Database Setup Guide

## Overview

PostgreSQL database setup for the Athena Security Platform.

## Prerequisites

1. **PostgreSQL 15+** installed and running
2. **Python 3.9+** with pip

## Quick Start

### 1. Install PostgreSQL

**Ubuntu/Debian:**
```bash
sudo apt update
sudo apt install postgresql postgresql-contrib
sudo systemctl start postgresql
sudo systemctl enable postgresql
```

**Windows:**
Download from https://www.postgresql.org/download/windows/

### 2. Create Database

```bash
# Switch to postgres user
sudo -u postgres psql

# Create database and user
CREATE DATABASE athena_db;
CREATE USER athena_user WITH PASSWORD 'athena_pass';
GRANT ALL PRIVILEGES ON DATABASE athena_db TO athena_user;

# Grant schema permissions
\c athena_db
GRANT ALL ON SCHEMA public TO athena_user;
\q
```

### 3. Configure Environment

Create/edit `.env` in project root:

```env
POSTGRES_HOST=localhost
POSTGRES_PORT=5432
POSTGRES_DB=athena_db
POSTGRES_USER=athena_user
POSTGRES_PASSWORD=athena_pass
```

### 4. Install Python Dependencies

```bash
cd backend/response
pip install -r requirements.txt
```

### 5. Run Migrations

```bash
cd database

# Apply RBAC tables
psql -U athena_user -d athena_db -f migrations/001_create_rbac_tables.sql

# Seed default data
psql -U athena_user -d athena_db -f seeds/001_seed_pages.sql
psql -U athena_user -d athena_db -f seeds/002_seed_default_roles.sql
```

### 6. Verify Setup

```bash
# Test connection
psql -U athena_user -h localhost -d athena_db -c "SELECT version();"

# Check tables
psql -U athena_user -h localhost -d athena_db -c "\dt"
```

## Database Schema

### Core Tables

| Table | Purpose |
|-------|---------|
| `users` | User accounts (synced from Keycloak) |
| `roles` | RBAC roles |
| `pages` | Application pages/routes |
| `user_roles` | User-role assignments |
| `role_pages` | Role-page permissions |
| `audit_log` | Action audit trail |
| `mute_rules` | Alert suppression rules |
| `blocked_ips` | IP blocklist |

### Connection String

```
postgresql://athena_user:athena_pass@localhost:5432/athena_db
```

## Troubleshooting

### Connection Refused

```bash
# Check PostgreSQL is running
sudo systemctl status postgresql

# Start if needed
sudo systemctl start postgresql
```

### Permission Denied

```bash
# Reconnect as postgres and re-grant
sudo -u postgres psql
\c athena_db
GRANT ALL ON ALL TABLES IN SCHEMA public TO athena_user;
GRANT ALL ON ALL SEQUENCES IN SCHEMA public TO athena_user;
```

### pg_hba.conf Issues

Edit `/etc/postgresql/15/main/pg_hba.conf`:
```
# Allow local connections with password
local   all   athena_user   md5
host    all   athena_user   127.0.0.1/32   md5
```

Then reload:
```bash
sudo systemctl reload postgresql
```

## Windows-Specific Setup

```powershell
# Using psql from command prompt
psql -U postgres
CREATE DATABASE athena_db;
CREATE USER athena_user WITH PASSWORD 'athena_pass';
GRANT ALL PRIVILEGES ON DATABASE athena_db TO athena_user;
```
