# Keycloak Automatic Setup

## Problem

Previously, every time you ran `scripts/start_all.py`, you had to manually:
1. Import the `athena-security` realm
2. Create users
3. Assign roles

This was because the realm wasn't automatically imported on startup.

## Solution

The `start_all.py` script now **automatically**:
1. ✅ Checks if the `athena-security` realm exists
2. ✅ Imports it if it doesn't exist
3. ✅ Creates default users (admin, analyst) if they don't exist
4. ✅ Assigns roles to users automatically

## How It Works

When you run `scripts/start_all.py`:

1. **Database Persistence**: PostgreSQL data is stored in Docker volume `keycloak-postgres-data`, so it persists across restarts

2. **Realm Check**: Script checks if `athena-security` realm exists by querying Keycloak API

3. **Auto-Import**: If realm doesn't exist:
   - Copies `docs/support/realm-export.json` to container
   - Uses Keycloak Admin CLI to import realm
   - Creates default users
   - Assigns roles

4. **No Re-import**: If realm already exists, it skips import (preserves your customizations)

## Default Configuration

### Realm
- **Name**: `athena-security`
- **File**: `docs/support/realm-export.json`

### Default Users

**Admin User:**
- Username: `admin`
- Password: `Admin@123`
- Roles: `admin`, `security-analyst`, `security-viewer`

**Analyst User:**
- Username: `analyst`
- Password: `Analyst@123`
- Roles: `security-analyst`, `security-viewer`

## Persistence

✅ **Database persists**: Docker volume `keycloak-postgres-data` keeps all data  
✅ **Realm persists**: Once imported, realm stays in database  
✅ **Users persist**: Once created, users stay in database  
✅ **Roles persist**: Role assignments stay in database  

**You only need to import/reconfigure if:**
- You delete the Docker volume
- You explicitly reset Keycloak database
- First time setup (automatic)

## Manual Override

If you want to manually import or reconfigure:

1. **Access Admin Console**: http://localhost:8080/admin
2. **Login**: admin / AdminKeycloak@2024!
3. **Select Realm**: Use dropdown to select/create realm
4. **Import**: Create Realm → Browse → Select `docs/support/realm-export.json`

## Troubleshooting

### Realm Not Importing

1. Check if Keycloak is healthy:
   ```bash
   curl http://localhost:8080/health/ready
   ```

2. Check logs:
   ```bash
   docker logs athena-keycloak
   ```

3. Manually import:
   ```bash
   docker cp docs/support/realm-export.json athena-keycloak:/tmp/
   docker exec athena-keycloak /opt/keycloak/bin/kcadm.sh config credentials --server http://localhost:8080 --realm master --user admin --password "AdminKeycloak@2024!"
   docker exec athena-keycloak /opt/keycloak/bin/kcadm.sh create realms -f /tmp/realm-export.json
   ```

### Database Volume Issues

To reset everything (WARNING: Deletes all data):
```bash
docker compose -f docker-compose.keycloak.yml down -v
```

To check volume:
```bash
docker volume ls | grep keycloak
docker volume inspect athena-network-response-management_keycloak-postgres-data
```

