# Quick Start Guide

## 1. Setup Database (One-time)

```bash
# Option A: Automated setup (recommended)
cd database
./setup_database.sh

# Option B: Manual setup
sudo -u postgres psql
CREATE DATABASE athena_db;
CREATE USER athena_user WITH PASSWORD 'athena_pass';
GRANT ALL PRIVILEGES ON DATABASE athena_db TO athena_user;
\c athena_db
GRANT ALL ON SCHEMA public TO athena_user;
\q
```

## 2. Install Python Dependencies

```bash
cd backend/response
pip install -r requirements.txt
```

## 3. Configure Environment

```bash
# Copy example config
cp .env.example .env

# Edit with your values
nano .env
```

Key variables:
```env
POSTGRES_HOST=localhost
POSTGRES_PORT=5432
POSTGRES_DB=athena_db
POSTGRES_USER=athena_user
POSTGRES_PASSWORD=athena_pass

ELASTICSEARCH_HOST=localhost
ELASTICSEARCH_PORT=9220

KEYCLOAK_URL=http://localhost:8080
KEYCLOAK_REALM=athena-security
```

## 4. Start Backend

```bash
cd backend/response
python src/app_factory.py
```

Backend runs on: http://localhost:5000

## 5. Start Frontend

```bash
cd frontend
npm install
npm start
```

Frontend runs on: http://localhost:3000

## 6. Verify Services

```bash
# Backend health
curl http://localhost:5000/health

# Comprehensive health check
curl http://localhost:5000/api/health/comprehensive
```

## Connection String

```
postgresql://athena_user:athena_pass@localhost:5432/athena_db
```

## Common Commands

```bash
# Connect with psql
psql -U athena_user -h localhost -d athena_db

# Check PostgreSQL status
sudo systemctl status postgresql

# Start PostgreSQL
sudo systemctl start postgresql

# Check backend logs
tail -f backend/response/logs/athena.log
```

## Service Ports

| Service | Port |
|---------|------|
| Frontend | 3000 |
| Backend | 5000 |
| PostgreSQL | 5432 |
| Elasticsearch | 9220 |
| Keycloak | 8080 |

## Need Help?

1. See `docs/06-starting-services.md` for detailed startup guide
2. See `docs/05-backend-architecture.md` for API structure
3. Check `docs/README.md` for complete documentation index
