#!/bin/bash
# =============================================================================
# Athena Security Platform - Production Deployment Script
# =============================================================================
# Target Server: 172.16.129.133
# Frontend Port: 8088
# Backend Port: 5000
# Keycloak Port: 8080
# =============================================================================

set -e

echo "=========================================="
echo "Athena Production Deployment"
echo "=========================================="

# Check if running on production server
EXPECTED_IP="172.16.129.133"
CURRENT_IP=$(hostname -I | awk '{print $1}')

echo "Current server IP: $CURRENT_IP"
echo "Expected server IP: $EXPECTED_IP"

# Navigate to project directory
cd /opt/athena

# Stop existing containers
echo ""
echo "[1/6] Stopping existing containers..."
docker-compose -f docker-compose.production.yml --env-file .env.docker.production down 2>/dev/null || true

# Pull latest images
echo ""
echo "[2/6] Building images..."
docker-compose -f docker-compose.production.yml --env-file .env.docker.production build --no-cache

# Start services
echo ""
echo "[3/6] Starting services..."
docker-compose -f docker-compose.production.yml --env-file .env.docker.production up -d

# Wait for services to be healthy
echo ""
echo "[4/6] Waiting for services to start..."
sleep 30

# Check service status
echo ""
echo "[5/6] Checking service status..."
docker-compose -f docker-compose.production.yml --env-file .env.docker.production ps

# Run health checks
echo ""
echo "[6/6] Running health checks..."
echo ""
echo "Backend health:"
curl -s http://localhost:5000/health | head -c 200
echo ""
echo ""
echo "Keycloak health:"
curl -s http://localhost:8080/health/ready || echo "Keycloak still starting..."
echo ""

# Setup admin user (first-time only)
echo ""
echo "=========================================="
echo "Post-deployment setup (run once):"
echo "=========================================="
echo ""
echo "1. Set admin user as system administrator:"
echo "   docker exec athena-app-db psql -U athena_user -d athena_db -c \"UPDATE users SET is_admin = TRUE WHERE username = 'admin';\""
echo ""
echo "2. Assign system-admin role:"
echo "   docker exec athena-app-db psql -U athena_user -d athena_db -c \"INSERT INTO user_roles (user_id, role_id, assigned_by) SELECT u.id, r.id, u.id FROM users u, roles r WHERE u.username = 'admin' AND r.role_name = 'system-admin' ON CONFLICT DO NOTHING;\""
echo ""
echo "3. Add missing mute_rules columns (if needed):"
echo "   docker exec athena-app-db psql -U athena_user -d athena_db -c \"ALTER TABLE mute_rules ADD COLUMN IF NOT EXISTS conditions JSONB DEFAULT '{}', ADD COLUMN IF NOT EXISTS active BOOLEAN DEFAULT TRUE, ADD COLUMN IF NOT EXISTS approval_status VARCHAR(20) DEFAULT 'auto_approved', ADD COLUMN IF NOT EXISTS scope VARCHAR(20) DEFAULT 'global', ADD COLUMN IF NOT EXISTS hit_count INTEGER DEFAULT 0;\""
echo ""

echo "=========================================="
echo "Deployment Complete!"
echo "=========================================="
echo ""
echo "Access URLs:"
echo "  Frontend:  http://172.16.129.133:8088"
echo "  Backend:   http://172.16.129.133:5000"
echo "  Keycloak:  http://172.16.129.133:8080/admin"
echo ""
echo "Default Keycloak Admin:"
echo "  Username: admin"
echo "  Password: AthenaKeycloak@2026!"
echo ""
