# Athena Security Platform - Dependencies

## Technology Stack

### Frontend
| Package | Version | Purpose |
|---------|---------|---------|
| react | 18.2.0 | UI framework |
| react-router-dom | 6.26.1 | Routing |
| @elastic/eui | 109.0.0 | UI component library |
| @tanstack/react-query | 5.87.1 | Data fetching |
| @react-keycloak/web | 3.4.0 | Authentication |
| three.js | 0.182.0 | 3D visualization |
| d3 | 7.9.0 | 2D visualization |
| recharts | 2.5.0 | Charts |
| leaflet | 1.9.4 | Maps |

### Backend
| Package | Version | Purpose |
|---------|---------|---------|
| Flask | 3.0.0 | Web framework |
| SQLAlchemy | 2.0.23 | ORM |
| psycopg2-binary | 2.9.9 | PostgreSQL adapter |
| boto3 | 1.40.24 | AWS SDK |
| python-keycloak | 3.9.1 | Keycloak integration |
| paramiko | 3.4.0 | SSH client |
| requests | 2.31.0 | HTTP client |
| flask-cors | 4.0.0 | CORS support |

### Infrastructure
| Component | Version |
|-----------|---------|
| PostgreSQL | 15+ |
| Elasticsearch | 7.17+ |
| Keycloak | 24+ |
| Wazuh | 4.14.0 |
| Suricata | 7.0+ |

### AWS Services
- AWS WAF v2
- AWS Network Firewall
- AWS Secrets Manager (optional)

### Threat Intelligence APIs
- AbuseIPDB
- VirusTotal
- OTX (AlienVault)

## Installation

### Frontend Dependencies
```bash
cd frontend
npm install
```

### Backend Dependencies
```bash
cd backend/response
pip install -r requirements.txt
```

## Development Tools
| Tool | Purpose |
|------|---------|
| uv | Python package manager |
| npm | Node package manager |
| Docker | Container runtime |
