"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.UiLogsCtrl = void 0;
var _errorResponse = require("../../lib/error-response");
/*
 * Wazuh app - Class for UI Logs functions
 * Copyright (C) 2015-2022 Wazuh, Inc.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * Find more information about this on the LICENSE file.
 */

// Require some libraries

class UiLogsCtrl {
  /**
   * Constructor
   * @param {*} server
   */
  constructor() {}

  /**
   * Add new UI Log entry to the platform logs
   * @param context
   * @param request
   * @param response
   * @returns success message or ErrorResponse
   */
  async createUiLogs(context, request, response) {
    try {
      const {
        location,
        message,
        level
      } = request.body;
      const loggerUI = context.wazuh.logger.get('ui');
      const loggerLevel = loggerUI !== null && loggerUI !== void 0 && loggerUI[level] ? level : 'error';
      loggerUI[loggerLevel](`${location}: ${message}`);
      return response.ok({
        body: {
          statusCode: 200,
          error: 0,
          message: 'Log has been added'
        }
      });
    } catch (error) {
      return (0, _errorResponse.ErrorResponse)(error.message || error, 3021, 500, response);
    }
  }
}
exports.UiLogsCtrl = UiLogsCtrl;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfZXJyb3JSZXNwb25zZSIsInJlcXVpcmUiLCJVaUxvZ3NDdHJsIiwiY29uc3RydWN0b3IiLCJjcmVhdGVVaUxvZ3MiLCJjb250ZXh0IiwicmVxdWVzdCIsInJlc3BvbnNlIiwibG9jYXRpb24iLCJtZXNzYWdlIiwibGV2ZWwiLCJib2R5IiwibG9nZ2VyVUkiLCJ3YXp1aCIsImxvZ2dlciIsImdldCIsImxvZ2dlckxldmVsIiwib2siLCJzdGF0dXNDb2RlIiwiZXJyb3IiLCJFcnJvclJlc3BvbnNlIiwiZXhwb3J0cyJdLCJzb3VyY2VzIjpbInVpLWxvZ3MuY29udHJvbGxlci50cyJdLCJzb3VyY2VzQ29udGVudCI6WyIvKlxuICogV2F6dWggYXBwIC0gQ2xhc3MgZm9yIFVJIExvZ3MgZnVuY3Rpb25zXG4gKiBDb3B5cmlnaHQgKEMpIDIwMTUtMjAyMiBXYXp1aCwgSW5jLlxuICpcbiAqIFRoaXMgcHJvZ3JhbSBpcyBmcmVlIHNvZnR3YXJlOyB5b3UgY2FuIHJlZGlzdHJpYnV0ZSBpdCBhbmQvb3IgbW9kaWZ5XG4gKiBpdCB1bmRlciB0aGUgdGVybXMgb2YgdGhlIEdOVSBHZW5lcmFsIFB1YmxpYyBMaWNlbnNlIGFzIHB1Ymxpc2hlZCBieVxuICogdGhlIEZyZWUgU29mdHdhcmUgRm91bmRhdGlvbjsgZWl0aGVyIHZlcnNpb24gMiBvZiB0aGUgTGljZW5zZSwgb3JcbiAqIChhdCB5b3VyIG9wdGlvbikgYW55IGxhdGVyIHZlcnNpb24uXG4gKlxuICogRmluZCBtb3JlIGluZm9ybWF0aW9uIGFib3V0IHRoaXMgb24gdGhlIExJQ0VOU0UgZmlsZS5cbiAqL1xuXG4vLyBSZXF1aXJlIHNvbWUgbGlicmFyaWVzXG5pbXBvcnQgeyBFcnJvclJlc3BvbnNlIH0gZnJvbSAnLi4vLi4vbGliL2Vycm9yLXJlc3BvbnNlJztcbmltcG9ydCB7XG4gIE9wZW5TZWFyY2hEYXNoYm9hcmRzUmVxdWVzdCxcbiAgT3BlblNlYXJjaERhc2hib2FyZHNSZXNwb25zZUZhY3RvcnksXG4gIFJlcXVlc3RIYW5kbGVyQ29udGV4dCxcbn0gZnJvbSAnc3JjL2NvcmUvc2VydmVyJztcblxuZXhwb3J0IGNsYXNzIFVpTG9nc0N0cmwge1xuICAvKipcbiAgICogQ29uc3RydWN0b3JcbiAgICogQHBhcmFtIHsqfSBzZXJ2ZXJcbiAgICovXG4gIGNvbnN0cnVjdG9yKCkge31cblxuICAvKipcbiAgICogQWRkIG5ldyBVSSBMb2cgZW50cnkgdG8gdGhlIHBsYXRmb3JtIGxvZ3NcbiAgICogQHBhcmFtIGNvbnRleHRcbiAgICogQHBhcmFtIHJlcXVlc3RcbiAgICogQHBhcmFtIHJlc3BvbnNlXG4gICAqIEByZXR1cm5zIHN1Y2Nlc3MgbWVzc2FnZSBvciBFcnJvclJlc3BvbnNlXG4gICAqL1xuICBhc3luYyBjcmVhdGVVaUxvZ3MoXG4gICAgY29udGV4dDogUmVxdWVzdEhhbmRsZXJDb250ZXh0LFxuICAgIHJlcXVlc3Q6IE9wZW5TZWFyY2hEYXNoYm9hcmRzUmVxdWVzdCxcbiAgICByZXNwb25zZTogT3BlblNlYXJjaERhc2hib2FyZHNSZXNwb25zZUZhY3RvcnksXG4gICkge1xuICAgIHRyeSB7XG4gICAgICBjb25zdCB7IGxvY2F0aW9uLCBtZXNzYWdlLCBsZXZlbCB9ID0gcmVxdWVzdC5ib2R5O1xuICAgICAgY29uc3QgbG9nZ2VyVUkgPSBjb250ZXh0LndhenVoLmxvZ2dlci5nZXQoJ3VpJyk7XG4gICAgICBjb25zdCBsb2dnZXJMZXZlbCA9IGxvZ2dlclVJPy5bbGV2ZWxdID8gbGV2ZWwgOiAnZXJyb3InO1xuICAgICAgbG9nZ2VyVUlbbG9nZ2VyTGV2ZWxdKGAke2xvY2F0aW9ufTogJHttZXNzYWdlfWApO1xuICAgICAgcmV0dXJuIHJlc3BvbnNlLm9rKHtcbiAgICAgICAgYm9keToge1xuICAgICAgICAgIHN0YXR1c0NvZGU6IDIwMCxcbiAgICAgICAgICBlcnJvcjogMCxcbiAgICAgICAgICBtZXNzYWdlOiAnTG9nIGhhcyBiZWVuIGFkZGVkJyxcbiAgICAgICAgfSxcbiAgICAgIH0pO1xuICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICByZXR1cm4gRXJyb3JSZXNwb25zZShlcnJvci5tZXNzYWdlIHx8IGVycm9yLCAzMDIxLCA1MDAsIHJlc3BvbnNlKTtcbiAgICB9XG4gIH1cbn1cbiJdLCJtYXBwaW5ncyI6Ijs7Ozs7O0FBYUEsSUFBQUEsY0FBQSxHQUFBQyxPQUFBO0FBYkE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTs7QUFRTyxNQUFNQyxVQUFVLENBQUM7RUFDdEI7QUFDRjtBQUNBO0FBQ0E7RUFDRUMsV0FBV0EsQ0FBQSxFQUFHLENBQUM7O0VBRWY7QUFDRjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7RUFDRSxNQUFNQyxZQUFZQSxDQUNoQkMsT0FBOEIsRUFDOUJDLE9BQW9DLEVBQ3BDQyxRQUE2QyxFQUM3QztJQUNBLElBQUk7TUFDRixNQUFNO1FBQUVDLFFBQVE7UUFBRUMsT0FBTztRQUFFQztNQUFNLENBQUMsR0FBR0osT0FBTyxDQUFDSyxJQUFJO01BQ2pELE1BQU1DLFFBQVEsR0FBR1AsT0FBTyxDQUFDUSxLQUFLLENBQUNDLE1BQU0sQ0FBQ0MsR0FBRyxDQUFDLElBQUksQ0FBQztNQUMvQyxNQUFNQyxXQUFXLEdBQUdKLFFBQVEsYUFBUkEsUUFBUSxlQUFSQSxRQUFRLENBQUdGLEtBQUssQ0FBQyxHQUFHQSxLQUFLLEdBQUcsT0FBTztNQUN2REUsUUFBUSxDQUFDSSxXQUFXLENBQUMsQ0FBRSxHQUFFUixRQUFTLEtBQUlDLE9BQVEsRUFBQyxDQUFDO01BQ2hELE9BQU9GLFFBQVEsQ0FBQ1UsRUFBRSxDQUFDO1FBQ2pCTixJQUFJLEVBQUU7VUFDSk8sVUFBVSxFQUFFLEdBQUc7VUFDZkMsS0FBSyxFQUFFLENBQUM7VUFDUlYsT0FBTyxFQUFFO1FBQ1g7TUFDRixDQUFDLENBQUM7SUFDSixDQUFDLENBQUMsT0FBT1UsS0FBSyxFQUFFO01BQ2QsT0FBTyxJQUFBQyw0QkFBYSxFQUFDRCxLQUFLLENBQUNWLE9BQU8sSUFBSVUsS0FBSyxFQUFFLElBQUksRUFBRSxHQUFHLEVBQUVaLFFBQVEsQ0FBQztJQUNuRTtFQUNGO0FBQ0Y7QUFBQ2MsT0FBQSxDQUFBbkIsVUFBQSxHQUFBQSxVQUFBIn0=