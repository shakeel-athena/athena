"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.WazuhElasticCtrl = void 0;
var _errorResponse = require("../lib/error-response");
var _constants = require("../../common/constants");
var _decorators = require("./decorators");
var _generateSampleData = require("../lib/generate-sample-data");
function _defineProperty(e, r, t) { return (r = _toPropertyKey(r)) in e ? Object.defineProperty(e, r, { value: t, enumerable: !0, configurable: !0, writable: !0 }) : e[r] = t, e; }
function _toPropertyKey(t) { var i = _toPrimitive(t, "string"); return "symbol" == typeof i ? i : i + ""; }
function _toPrimitive(t, r) { if ("object" != typeof t || !t) return t; var e = t[Symbol.toPrimitive]; if (void 0 !== e) { var i = e.call(t, r || "default"); if ("object" != typeof i) return i; throw new TypeError("@@toPrimitive must return a primitive value."); } return ("string" === r ? String : Number)(t); } /*
 * Wazuh app - Class for Wazuh-Elastic functions
 * Copyright (C) 2015-2022 Wazuh, Inc.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * Find more information about this on the LICENSE file.
 */
/**
 * Get the an array of unique objects by settingIndexPattern-dataSet par
 * @param arr
 * @returns
 */
function getUniqueEntriesByIndiceDatasetPar(array) {
  const seen = new Set();
  return array.filter(item => {
    // Create a unique key by combining the two property values.
    const key = `${item.settingIndexPattern}::${item.dataSet}`;
    if (seen.has(key)) {
      return false;
    }
    seen.add(key);
    return true;
  });
}
class WazuhElasticCtrl {
  constructor() {
    /**
     * This creates sample data in wazuh-sample-data
     * POST /indexer/sampledata/{category}
     * {
     *   "manager": {
     *      "name": "manager_name"
     *    },
     *    cluster: {
     *      name: "mycluster",
     *      node: "mynode"
     *    }
     * }
     * @param {*} context
     * @param {*} request
     * @param {*} response
     * {index: string, data: [...], count: number} or ErrorResponse
     */
    _defineProperty(this, "createSampleData", (0, _decorators.routeDecoratorProtectedAdministrator)(1000)(async (context, request, response) => {
      const sampleIndexNames = await this.buildSampleIndexByCategory(context, request.params.category);
      const sampleDocumentsResponse = [];
      try {
        await Promise.all(sampleIndexNames.map(async ({
          indexName,
          dataSet
        }) => {
          try {
            const bulkPrefix = JSON.stringify({
              index: {
                _index: indexName
              }
            });
            const sampleDataGenerateParams = request.body && request.body.params || {};
            const mappedData = _constants.WAZUH_SAMPLE_DATA_CATEGORIES_TYPE_DATA[request.params.category].filter(item => item.dataSet === dataSet).map(typeSample => {
              return (0, _generateSampleData.generateSampleData)({
                ...typeSample,
                ...sampleDataGenerateParams
              }, request.body.count || typeSample.count || _constants.WAZUH_SAMPLE_ALERTS_DEFAULT_NUMBER_DOCUMENTS, context);
            });
            let sampleDataAndTemplate = {
              sampleData: []
            };
            if (mappedData.length > 1) {
              mappedData.forEach(item => sampleDataAndTemplate.sampleData.push(...item.sampleData));
            }
            if (mappedData.length === 1 && mappedData[0].template) {
              sampleDataAndTemplate = mappedData[0];
            }
            const {
              sampleData
            } = sampleDataAndTemplate;
            const bulk = sampleData.map(document => `${bulkPrefix}\n${JSON.stringify(document)}\n`).join('');

            // Index data

            // Check if wazuh sample data index exists
            const existsSampleIndex = await context.core.opensearch.client.asCurrentUser.indices.exists({
              index: indexName
            });
            if (existsSampleIndex.body === false) {
              var _sampleDataAndTemplat;
              // Create wazuh sample data index
              let configuration;
              if ((_sampleDataAndTemplat = sampleDataAndTemplate) !== null && _sampleDataAndTemplat !== void 0 && _sampleDataAndTemplat.template) {
                configuration = sampleDataAndTemplate.template.template;
                delete configuration.index_patterns;
                delete configuration.priority;
                configuration.settings.index.number_of_shards = _constants.WAZUH_SAMPLE_ALERTS_INDEX_SHARDS;
                configuration.settings.index.number_of_replicas = _constants.WAZUH_SAMPLE_ALERTS_INDEX_REPLICAS;
              } else {
                configuration = {
                  settings: {
                    index: {
                      number_of_shards: _constants.WAZUH_SAMPLE_ALERTS_INDEX_SHARDS,
                      number_of_replicas: _constants.WAZUH_SAMPLE_ALERTS_INDEX_REPLICAS
                    }
                  }
                };
              }
              await context.core.opensearch.client.asCurrentUser.indices.create({
                index: indexName,
                body: configuration
              });
              context.wazuh.logger.info(`Index ${indexName} created`);
            }
            await context.core.opensearch.client.asCurrentUser.bulk({
              index: indexName,
              body: bulk
            });
            context.wazuh.logger.info(`Added sample data to ${indexName} index`);
            sampleDocumentsResponse.push({
              index: indexName,
              sampleDataCount: sampleData.length
            });
          } catch (error) {
            context.wazuh.logger.error(`Error adding sample data to ${indexName} index: ${error.message || error}`);
            const [statusCode, errorMessage] = this.getErrorDetails(error);
            throw {
              statusCode,
              errorMessage
            };
          }
        }));

        // Only return response after all operations are complete
        return response.ok({
          body: {
            sampleDocumentsResponse
          }
        });
      } catch (error) {
        const statusCode = (error === null || error === void 0 ? void 0 : error.statusCode) || _constants.HTTP_STATUS_CODES.INTERNAL_SERVER_ERROR;
        const errorMessage = (error === null || error === void 0 ? void 0 : error.errorMessage) || error.message || error;
        return (0, _errorResponse.ErrorResponse)(errorMessage, _errorResponse.WAZUH_STATUS_CODES.UNKNOWN, statusCode, response);
      }
    }));
    /**
     * This deletes sample data
     * @param {*} context
     * @param {*} request
     * @param {*} response
     * {result: "deleted", index: string} or ErrorResponse
     */
    _defineProperty(this, "deleteSampleData", (0, _decorators.routeDecoratorProtectedAdministrator)(_errorResponse.WAZUH_STATUS_CODES.UNKNOWN)(async (context, request, response) => {
      try {
        // Get sample data indexes
        const sampleDataIndexAndDataSet = await this.buildSampleIndexByCategory(context, request.params.category);

        // Get only index names
        const sampleDataIndex = sampleDataIndexAndDataSet.map(({
          indexName
        }) => indexName);
        if (!sampleDataIndex.length) {
          return (0, _errorResponse.ErrorResponse)(`No indices found for category ${request.params.category}`, 1000, 404, response);
        }

        // Delete sample data indexes
        // return success or error for each index
        const results = await Promise.all(sampleDataIndex.map(async index => {
          try {
            // Check if Wazuh sample data index exists
            const existsSampleIndex = await context.core.opensearch.client.asCurrentUser.indices.exists({
              index
            });
            if (existsSampleIndex.body) {
              // Delete Wazuh sample data index
              await context.core.opensearch.client.asCurrentUser.indices.delete({
                index: [index]
              });
              context.wazuh.logger.info(`Deleted ${index} index`);
              return {
                success: true,
                index,
                message: 'deleted'
              };
            } else {
              return {
                success: false,
                index,
                message: `Index doesn't exist`
              };
            }
          } catch (error) {
            context.wazuh.logger.error(`Error deleting sample data of ${index} index: ${error.message || error}`);
            const [statusCode, errorMessage] = this.getErrorDetails(error);
            return {
              success: false,
              index,
              message: errorMessage || error,
              statusCode
            };
          }
        }));

        // Check if all results are successful
        const successResults = results.filter(result => result.success);
        const failedResults = results.filter(result => !result.success);
        if (successResults.length > 0) {
          context.wazuh.logger.info(`Deleted ${successResults.length} indices: ${successResults.map(r => r.index).join(', ')}`);
          if (failedResults.length > 0) {
            context.wazuh.logger.error(`Failed to delete ${failedResults.length} indices: ${failedResults.map(r => r.index).join(', ')}`);
          }
          return response.ok({
            body: {
              result: 'deleted',
              successCount: successResults.length,
              failedCount: failedResults.length,
              indices: successResults.map(r => r.index),
              errors: failedResults.length ? failedResults : undefined
            }
          });
        } else {
          const firstError = failedResults[0];
          return (0, _errorResponse.ErrorResponse)(`Failed to delete indices: ${firstError.message}`, 1000, firstError.statusCode || 500, response);
        }
      } catch (error) {
        context.wazuh.logger.error(`Error deleting sample data: ${error.message || error}`);
        const [statusCode, errorMessage] = this.getErrorDetails(error);
        return (0, _errorResponse.ErrorResponse)(errorMessage || error, 1000, statusCode, response);
      }
    }));
  }

  /**
   * This returns the index according the category
   * @param {string} category
   */
  async buildSampleIndexByCategory(context, category) {
    const indexNames = await Promise.all(_constants.WAZUH_SAMPLE_DATA_CATEGORIES_TYPE_DATA[category].map(async item => ({
      indexName: `${item.settingIndexPattern ? await context.wazuh_core.configuration.get(item.settingIndexPattern) : item.indexPatternPrefix}sample-${category}`,
      dataSet: item === null || item === void 0 ? void 0 : item.dataSet
    })));
    return getUniqueEntriesByIndiceDatasetPar(indexNames);
  }

  /**
   * This retrieves a template from Elasticsearch
   * @param {Object} context
   * @param {Object} request
   * @param {Object} response
   * @returns {Object} template or ErrorResponse
   */
  async getTemplate(context, request, response) {
    try {
      const data = await context.core.opensearch.client.asInternalUser.cat.templates();
      const templates = data.body;
      if (!templates || typeof templates !== 'string') {
        throw new Error(`An unknown error occurred when fetching templates from ${_constants.WAZUH_INDEXER_NAME}`);
      }
      const lastChar = request.params.pattern[request.params.pattern.length - 1];

      // Split into separate patterns
      const tmpdata = templates.match(/\[.*\]/g);
      const tmparray = [];
      for (let item of tmpdata) {
        // A template might use more than one pattern
        if (item.includes(',')) {
          item = item.substr(1).slice(0, -1);
          const subItems = item.split(',');
          for (const subitem of subItems) {
            tmparray.push(`[${subitem.trim()}]`);
          }
        } else {
          tmparray.push(item);
        }
      }

      // Ensure we are handling just patterns
      const array = tmparray.filter(item => item.includes('[') && item.includes(']'));
      const pattern = lastChar === '*' ? request.params.pattern.slice(0, -1) : request.params.pattern;
      const isIncluded = array.filter(item => {
        item = item.slice(1, -1);
        const lastChar = item[item.length - 1];
        item = lastChar === '*' ? item.slice(0, -1) : item;
        return item.includes(pattern) || pattern.includes(item);
      });
      context.wazuh.logger.debug(`Template is valid: ${isIncluded && Array.isArray(isIncluded) && isIncluded.length ? 'yes' : 'no'}`);
      return isIncluded && Array.isArray(isIncluded) && isIncluded.length ? response.ok({
        body: {
          statusCode: 200,
          status: true,
          data: `Template found for ${request.params.pattern}`
        }
      }) : response.ok({
        body: {
          statusCode: 200,
          status: false,
          data: `No template found for ${request.params.pattern}`
        }
      });
    } catch (error) {
      context.wazuh.logger.error(error.message || error);
      return (0, _errorResponse.ErrorResponse)(`Could not retrieve templates from ${_constants.WAZUH_INDEXER_NAME} due to ${error.message || error}`, 4002, 500, response);
    }
  }

  /**
   * This check index-pattern
   * @param {Object} context
   * @param {Object} request
   * @param {Object} response
   * @returns {Object} status obj or ErrorResponse
   */

  /**
   * This get the fields keys
   * @param {Object} context
   * @param {Object} request
   * @param {Object} response
   * @returns {Array<Object>} fields or ErrorResponse
   */
  async getFieldTop(context, request, response) {
    try {
      // Top field payload
      let payload = {
        size: 1,
        query: {
          bool: {
            must: [],
            must_not: {
              term: {
                'agent.id': '000'
              }
            },
            filter: [{
              range: {
                timestamp: {}
              }
            }]
          }
        },
        aggs: {
          '2': {
            terms: {
              field: '',
              size: 1,
              order: {
                _count: 'desc'
              }
            }
          }
        }
      };

      // Set up time interval, default to Last 24h
      const timeGTE = 'now-1d';
      const timeLT = 'now';
      payload.query.bool.filter[0].range['timestamp']['gte'] = timeGTE;
      payload.query.bool.filter[0].range['timestamp']['lt'] = timeLT;

      // Set up match for default cluster name
      payload.query.bool.must.push(request.params.mode === 'cluster' ? {
        match: {
          'cluster.name': request.params.cluster
        }
      } : {
        match: {
          'manager.name': request.params.cluster
        }
      });
      if (request.query.agentsList) payload.query.bool.filter.push({
        terms: {
          'agent.id': request.query.agentsList.split(',')
        }
      });
      payload.aggs['2'].terms.field = request.params.field;
      const data = await context.core.opensearch.client.asCurrentUser.search({
        size: 1,
        index: request.params.pattern,
        body: payload
      });
      return data.body.hits.total.value === 0 || typeof data.body.aggregations['2'].buckets[0] === 'undefined' ? response.ok({
        body: {
          statusCode: 200,
          data: ''
        }
      }) : response.ok({
        body: {
          statusCode: 200,
          data: data.body.aggregations['2'].buckets[0].key
        }
      });
    } catch (error) {
      context.wazuh.logger.error(error.message || error);
      return (0, _errorResponse.ErrorResponse)(error.message || error, 4004, 500, response);
    }
  }

  /**
   * Checks for minimum index pattern fields in a list of index patterns.
   * @param {Array<Object>} indexPatternList List of index patterns
   */
  validateIndexPattern(indexPatternList) {
    const minimum = ['timestamp', 'rule.groups', 'manager.name', 'agent.id'];
    let list = [];
    for (const index of indexPatternList) {
      let valid, parsed;
      try {
        parsed = JSON.parse(index.attributes.fields);
      } catch (error) {
        continue;
      }
      valid = parsed.filter(item => minimum.includes(item.name));
      if (valid.length === 4) {
        list.push({
          id: index.id,
          title: index.attributes.title
        });
      }
    }
    return list;
  }

  /**
   * Returns current security platform
   * @param {Object} req
   * @param {Object} reply
   * @returns {String}
   */
  async getCurrentPlatform(context, request, response) {
    try {
      return response.ok({
        body: {
          platform: context.wazuh.security.platform
        }
      });
    } catch (error) {
      context.wazuh.logger.error(error.message || error);
      return (0, _errorResponse.ErrorResponse)(error.message || error, 4011, 500, response);
    }
  }

  /**
   * This creates sample data in wazuh-sample-data
   * GET /indexer/sampledata/{category}
   * @param {*} context
   * @param {*} request
   * @param {*} response
   * {alerts: [...]} or ErrorResponse
   */
  async haveSampleDataOfCategory(context, request, response) {
    try {
      const sampleDataIndex = await this.buildSampleIndexByCategory(context, request.params.category);
      // Check if wazuh sample data index exists
      const existsSampleIndex = await Promise.all(sampleDataIndex.map(async ({
        indexName
      }) => {
        return await context.core.opensearch.client.asCurrentUser.indices.exists({
          index: indexName
        });
      }));
      return response.ok({
        body: {
          index: sampleDataIndex,
          exists: existsSampleIndex.some(result => result.body)
        }
      });
    } catch (error) {
      context.wazuh.logger.error(`Error checking if there are sample data indices: ${error.message || error}`);
      const [statusCode, errorMessage] = this.getErrorDetails(error);
      return (0, _errorResponse.ErrorResponse)(`Error checking if there are sample data indices: ${errorMessage || error}`, 1000, statusCode, response);
    }
  }
  async alerts(context, request, response) {
    try {
      const data = await context.core.opensearch.client.asCurrentUser.search(request.body);
      return response.ok({
        body: data.body
      });
    } catch (error) {
      context.wazuh.logger.error(error.message || error);
      return (0, _errorResponse.ErrorResponse)(error.message || error, 4010, 500, response);
    }
  }
  getErrorDetails(error) {
    var _error$meta;
    const statusCode = (error === null || error === void 0 || (_error$meta = error.meta) === null || _error$meta === void 0 ? void 0 : _error$meta.statusCode) || 500;
    let errorMessage = error.message;
    if (statusCode === 403) {
      var _error$meta2;
      errorMessage = (error === null || error === void 0 || (_error$meta2 = error.meta) === null || _error$meta2 === void 0 || (_error$meta2 = _error$meta2.body) === null || _error$meta2 === void 0 || (_error$meta2 = _error$meta2.error) === null || _error$meta2 === void 0 ? void 0 : _error$meta2.reason) || 'Permission denied';
    }
    return [statusCode, errorMessage];
  }
}
exports.WazuhElasticCtrl = WazuhElasticCtrl;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfZXJyb3JSZXNwb25zZSIsInJlcXVpcmUiLCJfY29uc3RhbnRzIiwiX2RlY29yYXRvcnMiLCJfZ2VuZXJhdGVTYW1wbGVEYXRhIiwiX2RlZmluZVByb3BlcnR5IiwiZSIsInIiLCJ0IiwiX3RvUHJvcGVydHlLZXkiLCJPYmplY3QiLCJkZWZpbmVQcm9wZXJ0eSIsInZhbHVlIiwiZW51bWVyYWJsZSIsImNvbmZpZ3VyYWJsZSIsIndyaXRhYmxlIiwiaSIsIl90b1ByaW1pdGl2ZSIsIlN5bWJvbCIsInRvUHJpbWl0aXZlIiwiY2FsbCIsIlR5cGVFcnJvciIsIlN0cmluZyIsIk51bWJlciIsImdldFVuaXF1ZUVudHJpZXNCeUluZGljZURhdGFzZXRQYXIiLCJhcnJheSIsInNlZW4iLCJTZXQiLCJmaWx0ZXIiLCJpdGVtIiwia2V5Iiwic2V0dGluZ0luZGV4UGF0dGVybiIsImRhdGFTZXQiLCJoYXMiLCJhZGQiLCJXYXp1aEVsYXN0aWNDdHJsIiwiY29uc3RydWN0b3IiLCJyb3V0ZURlY29yYXRvclByb3RlY3RlZEFkbWluaXN0cmF0b3IiLCJjb250ZXh0IiwicmVxdWVzdCIsInJlc3BvbnNlIiwic2FtcGxlSW5kZXhOYW1lcyIsImJ1aWxkU2FtcGxlSW5kZXhCeUNhdGVnb3J5IiwicGFyYW1zIiwiY2F0ZWdvcnkiLCJzYW1wbGVEb2N1bWVudHNSZXNwb25zZSIsIlByb21pc2UiLCJhbGwiLCJtYXAiLCJpbmRleE5hbWUiLCJidWxrUHJlZml4IiwiSlNPTiIsInN0cmluZ2lmeSIsImluZGV4IiwiX2luZGV4Iiwic2FtcGxlRGF0YUdlbmVyYXRlUGFyYW1zIiwiYm9keSIsIm1hcHBlZERhdGEiLCJXQVpVSF9TQU1QTEVfREFUQV9DQVRFR09SSUVTX1RZUEVfREFUQSIsInR5cGVTYW1wbGUiLCJnZW5lcmF0ZVNhbXBsZURhdGEiLCJjb3VudCIsIldBWlVIX1NBTVBMRV9BTEVSVFNfREVGQVVMVF9OVU1CRVJfRE9DVU1FTlRTIiwic2FtcGxlRGF0YUFuZFRlbXBsYXRlIiwic2FtcGxlRGF0YSIsImxlbmd0aCIsImZvckVhY2giLCJwdXNoIiwidGVtcGxhdGUiLCJidWxrIiwiZG9jdW1lbnQiLCJqb2luIiwiZXhpc3RzU2FtcGxlSW5kZXgiLCJjb3JlIiwib3BlbnNlYXJjaCIsImNsaWVudCIsImFzQ3VycmVudFVzZXIiLCJpbmRpY2VzIiwiZXhpc3RzIiwiX3NhbXBsZURhdGFBbmRUZW1wbGF0IiwiY29uZmlndXJhdGlvbiIsImluZGV4X3BhdHRlcm5zIiwicHJpb3JpdHkiLCJzZXR0aW5ncyIsIm51bWJlcl9vZl9zaGFyZHMiLCJXQVpVSF9TQU1QTEVfQUxFUlRTX0lOREVYX1NIQVJEUyIsIm51bWJlcl9vZl9yZXBsaWNhcyIsIldBWlVIX1NBTVBMRV9BTEVSVFNfSU5ERVhfUkVQTElDQVMiLCJjcmVhdGUiLCJ3YXp1aCIsImxvZ2dlciIsImluZm8iLCJzYW1wbGVEYXRhQ291bnQiLCJlcnJvciIsIm1lc3NhZ2UiLCJzdGF0dXNDb2RlIiwiZXJyb3JNZXNzYWdlIiwiZ2V0RXJyb3JEZXRhaWxzIiwib2siLCJIVFRQX1NUQVRVU19DT0RFUyIsIklOVEVSTkFMX1NFUlZFUl9FUlJPUiIsIkVycm9yUmVzcG9uc2UiLCJXQVpVSF9TVEFUVVNfQ09ERVMiLCJVTktOT1dOIiwic2FtcGxlRGF0YUluZGV4QW5kRGF0YVNldCIsInNhbXBsZURhdGFJbmRleCIsInJlc3VsdHMiLCJkZWxldGUiLCJzdWNjZXNzIiwic3VjY2Vzc1Jlc3VsdHMiLCJyZXN1bHQiLCJmYWlsZWRSZXN1bHRzIiwic3VjY2Vzc0NvdW50IiwiZmFpbGVkQ291bnQiLCJlcnJvcnMiLCJ1bmRlZmluZWQiLCJmaXJzdEVycm9yIiwiaW5kZXhOYW1lcyIsIndhenVoX2NvcmUiLCJnZXQiLCJpbmRleFBhdHRlcm5QcmVmaXgiLCJnZXRUZW1wbGF0ZSIsImRhdGEiLCJhc0ludGVybmFsVXNlciIsImNhdCIsInRlbXBsYXRlcyIsIkVycm9yIiwiV0FaVUhfSU5ERVhFUl9OQU1FIiwibGFzdENoYXIiLCJwYXR0ZXJuIiwidG1wZGF0YSIsIm1hdGNoIiwidG1wYXJyYXkiLCJpbmNsdWRlcyIsInN1YnN0ciIsInNsaWNlIiwic3ViSXRlbXMiLCJzcGxpdCIsInN1Yml0ZW0iLCJ0cmltIiwiaXNJbmNsdWRlZCIsImRlYnVnIiwiQXJyYXkiLCJpc0FycmF5Iiwic3RhdHVzIiwiZ2V0RmllbGRUb3AiLCJwYXlsb2FkIiwic2l6ZSIsInF1ZXJ5IiwiYm9vbCIsIm11c3QiLCJtdXN0X25vdCIsInRlcm0iLCJyYW5nZSIsInRpbWVzdGFtcCIsImFnZ3MiLCJ0ZXJtcyIsImZpZWxkIiwib3JkZXIiLCJfY291bnQiLCJ0aW1lR1RFIiwidGltZUxUIiwibW9kZSIsImNsdXN0ZXIiLCJhZ2VudHNMaXN0Iiwic2VhcmNoIiwiaGl0cyIsInRvdGFsIiwiYWdncmVnYXRpb25zIiwiYnVja2V0cyIsInZhbGlkYXRlSW5kZXhQYXR0ZXJuIiwiaW5kZXhQYXR0ZXJuTGlzdCIsIm1pbmltdW0iLCJsaXN0IiwidmFsaWQiLCJwYXJzZWQiLCJwYXJzZSIsImF0dHJpYnV0ZXMiLCJmaWVsZHMiLCJuYW1lIiwiaWQiLCJ0aXRsZSIsImdldEN1cnJlbnRQbGF0Zm9ybSIsInBsYXRmb3JtIiwic2VjdXJpdHkiLCJoYXZlU2FtcGxlRGF0YU9mQ2F0ZWdvcnkiLCJzb21lIiwiYWxlcnRzIiwiX2Vycm9yJG1ldGEiLCJtZXRhIiwiX2Vycm9yJG1ldGEyIiwicmVhc29uIiwiZXhwb3J0cyJdLCJzb3VyY2VzIjpbIndhenVoLWVsYXN0aWMudHMiXSwic291cmNlc0NvbnRlbnQiOlsiLypcbiAqIFdhenVoIGFwcCAtIENsYXNzIGZvciBXYXp1aC1FbGFzdGljIGZ1bmN0aW9uc1xuICogQ29weXJpZ2h0IChDKSAyMDE1LTIwMjIgV2F6dWgsIEluYy5cbiAqXG4gKiBUaGlzIHByb2dyYW0gaXMgZnJlZSBzb2Z0d2FyZTsgeW91IGNhbiByZWRpc3RyaWJ1dGUgaXQgYW5kL29yIG1vZGlmeVxuICogaXQgdW5kZXIgdGhlIHRlcm1zIG9mIHRoZSBHTlUgR2VuZXJhbCBQdWJsaWMgTGljZW5zZSBhcyBwdWJsaXNoZWQgYnlcbiAqIHRoZSBGcmVlIFNvZnR3YXJlIEZvdW5kYXRpb247IGVpdGhlciB2ZXJzaW9uIDIgb2YgdGhlIExpY2Vuc2UsIG9yXG4gKiAoYXQgeW91ciBvcHRpb24pIGFueSBsYXRlciB2ZXJzaW9uLlxuICpcbiAqIEZpbmQgbW9yZSBpbmZvcm1hdGlvbiBhYm91dCB0aGlzIG9uIHRoZSBMSUNFTlNFIGZpbGUuXG4gKi9cbmltcG9ydCB7IEVycm9yUmVzcG9uc2UsIFdBWlVIX1NUQVRVU19DT0RFUyB9IGZyb20gJy4uL2xpYi9lcnJvci1yZXNwb25zZSc7XG5pbXBvcnQge1xuICBXQVpVSF9TQU1QTEVfQUxFUlRTX0lOREVYX1NIQVJEUyxcbiAgV0FaVUhfU0FNUExFX0FMRVJUU19JTkRFWF9SRVBMSUNBUyxcbiAgV0FaVUhfQUxFUlRTX1BSRUZJWCxcbiAgV0FaVUhfU0FNUExFX0RBVEFfQ0FURUdPUklFU19UWVBFX0RBVEEsXG4gIFdBWlVIX1NBTVBMRV9BTEVSVFNfREVGQVVMVF9OVU1CRVJfRE9DVU1FTlRTLFxuICBXQVpVSF9JTkRFWEVSX05BTUUsXG4gIEhUVFBfU1RBVFVTX0NPREVTLFxufSBmcm9tICcuLi8uLi9jb21tb24vY29uc3RhbnRzJztcbmltcG9ydCB7XG4gIE9wZW5TZWFyY2hEYXNoYm9hcmRzUmVxdWVzdCxcbiAgUmVxdWVzdEhhbmRsZXJDb250ZXh0LFxuICBPcGVuU2VhcmNoRGFzaGJvYXJkc1Jlc3BvbnNlRmFjdG9yeSxcbn0gZnJvbSAnc3JjL2NvcmUvc2VydmVyJztcbmltcG9ydCB7IHJvdXRlRGVjb3JhdG9yUHJvdGVjdGVkQWRtaW5pc3RyYXRvciB9IGZyb20gJy4vZGVjb3JhdG9ycyc7XG5pbXBvcnQgeyBnZW5lcmF0ZVNhbXBsZURhdGEgfSBmcm9tICcuLi9saWIvZ2VuZXJhdGUtc2FtcGxlLWRhdGEnO1xuXG4vKipcbiAqIEdldCB0aGUgYW4gYXJyYXkgb2YgdW5pcXVlIG9iamVjdHMgYnkgc2V0dGluZ0luZGV4UGF0dGVybi1kYXRhU2V0IHBhclxuICogQHBhcmFtIGFyclxuICogQHJldHVybnNcbiAqL1xuZnVuY3Rpb24gZ2V0VW5pcXVlRW50cmllc0J5SW5kaWNlRGF0YXNldFBhcihcbiAgYXJyYXk6IHsgc2V0dGluZ0luZGV4UGF0dGVybjogc3RyaW5nOyBkYXRhU2V0OiBzdHJpbmcgfVtdLFxuKSB7XG4gIGNvbnN0IHNlZW4gPSBuZXcgU2V0KCk7XG4gIHJldHVybiBhcnJheS5maWx0ZXIoaXRlbSA9PiB7XG4gICAgLy8gQ3JlYXRlIGEgdW5pcXVlIGtleSBieSBjb21iaW5pbmcgdGhlIHR3byBwcm9wZXJ0eSB2YWx1ZXMuXG4gICAgY29uc3Qga2V5ID0gYCR7aXRlbS5zZXR0aW5nSW5kZXhQYXR0ZXJufTo6JHtpdGVtLmRhdGFTZXR9YDtcbiAgICBpZiAoc2Vlbi5oYXMoa2V5KSkge1xuICAgICAgcmV0dXJuIGZhbHNlO1xuICAgIH1cbiAgICBzZWVuLmFkZChrZXkpO1xuICAgIHJldHVybiB0cnVlO1xuICB9KTtcbn1cblxuZXhwb3J0IGNsYXNzIFdhenVoRWxhc3RpY0N0cmwge1xuICBjb25zdHJ1Y3RvcigpIHt9XG5cbiAgLyoqXG4gICAqIFRoaXMgcmV0dXJucyB0aGUgaW5kZXggYWNjb3JkaW5nIHRoZSBjYXRlZ29yeVxuICAgKiBAcGFyYW0ge3N0cmluZ30gY2F0ZWdvcnlcbiAgICovXG4gIGFzeW5jIGJ1aWxkU2FtcGxlSW5kZXhCeUNhdGVnb3J5KFxuICAgIGNvbnRleHQ6IFJlcXVlc3RIYW5kbGVyQ29udGV4dCxcbiAgICBjYXRlZ29yeTogc3RyaW5nLFxuICApOiBQcm9taXNlPHsgaW5kZXhOYW1lOiBzdHJpbmc7IGRhdGFTZXQ6IHN0cmluZyB9W10+IHtcbiAgICBjb25zdCBpbmRleE5hbWVzID0gYXdhaXQgUHJvbWlzZS5hbGwoXG4gICAgICBXQVpVSF9TQU1QTEVfREFUQV9DQVRFR09SSUVTX1RZUEVfREFUQVtjYXRlZ29yeV0ubWFwKGFzeW5jIGl0ZW0gPT4gKHtcbiAgICAgICAgaW5kZXhOYW1lOiBgJHtcbiAgICAgICAgICBpdGVtLnNldHRpbmdJbmRleFBhdHRlcm5cbiAgICAgICAgICAgID8gYXdhaXQgY29udGV4dC53YXp1aF9jb3JlLmNvbmZpZ3VyYXRpb24uZ2V0KFxuICAgICAgICAgICAgICAgIGl0ZW0uc2V0dGluZ0luZGV4UGF0dGVybixcbiAgICAgICAgICAgICAgKVxuICAgICAgICAgICAgOiBpdGVtLmluZGV4UGF0dGVyblByZWZpeFxuICAgICAgICB9c2FtcGxlLSR7Y2F0ZWdvcnl9YCxcbiAgICAgICAgZGF0YVNldDogaXRlbT8uZGF0YVNldCxcbiAgICAgIH0pKSxcbiAgICApO1xuICAgIHJldHVybiBnZXRVbmlxdWVFbnRyaWVzQnlJbmRpY2VEYXRhc2V0UGFyKGluZGV4TmFtZXMpO1xuICB9XG5cbiAgLyoqXG4gICAqIFRoaXMgcmV0cmlldmVzIGEgdGVtcGxhdGUgZnJvbSBFbGFzdGljc2VhcmNoXG4gICAqIEBwYXJhbSB7T2JqZWN0fSBjb250ZXh0XG4gICAqIEBwYXJhbSB7T2JqZWN0fSByZXF1ZXN0XG4gICAqIEBwYXJhbSB7T2JqZWN0fSByZXNwb25zZVxuICAgKiBAcmV0dXJucyB7T2JqZWN0fSB0ZW1wbGF0ZSBvciBFcnJvclJlc3BvbnNlXG4gICAqL1xuICBhc3luYyBnZXRUZW1wbGF0ZShcbiAgICBjb250ZXh0OiBSZXF1ZXN0SGFuZGxlckNvbnRleHQsXG4gICAgcmVxdWVzdDogT3BlblNlYXJjaERhc2hib2FyZHNSZXF1ZXN0PHsgcGF0dGVybjogc3RyaW5nIH0+LFxuICAgIHJlc3BvbnNlOiBPcGVuU2VhcmNoRGFzaGJvYXJkc1Jlc3BvbnNlRmFjdG9yeSxcbiAgKSB7XG4gICAgdHJ5IHtcbiAgICAgIGNvbnN0IGRhdGEgPVxuICAgICAgICBhd2FpdCBjb250ZXh0LmNvcmUub3BlbnNlYXJjaC5jbGllbnQuYXNJbnRlcm5hbFVzZXIuY2F0LnRlbXBsYXRlcygpO1xuXG4gICAgICBjb25zdCB0ZW1wbGF0ZXMgPSBkYXRhLmJvZHk7XG4gICAgICBpZiAoIXRlbXBsYXRlcyB8fCB0eXBlb2YgdGVtcGxhdGVzICE9PSAnc3RyaW5nJykge1xuICAgICAgICB0aHJvdyBuZXcgRXJyb3IoXG4gICAgICAgICAgYEFuIHVua25vd24gZXJyb3Igb2NjdXJyZWQgd2hlbiBmZXRjaGluZyB0ZW1wbGF0ZXMgZnJvbSAke1dBWlVIX0lOREVYRVJfTkFNRX1gLFxuICAgICAgICApO1xuICAgICAgfVxuXG4gICAgICBjb25zdCBsYXN0Q2hhciA9XG4gICAgICAgIHJlcXVlc3QucGFyYW1zLnBhdHRlcm5bcmVxdWVzdC5wYXJhbXMucGF0dGVybi5sZW5ndGggLSAxXTtcblxuICAgICAgLy8gU3BsaXQgaW50byBzZXBhcmF0ZSBwYXR0ZXJuc1xuICAgICAgY29uc3QgdG1wZGF0YSA9IHRlbXBsYXRlcy5tYXRjaCgvXFxbLipcXF0vZyk7XG4gICAgICBjb25zdCB0bXBhcnJheSA9IFtdO1xuICAgICAgZm9yIChsZXQgaXRlbSBvZiB0bXBkYXRhKSB7XG4gICAgICAgIC8vIEEgdGVtcGxhdGUgbWlnaHQgdXNlIG1vcmUgdGhhbiBvbmUgcGF0dGVyblxuICAgICAgICBpZiAoaXRlbS5pbmNsdWRlcygnLCcpKSB7XG4gICAgICAgICAgaXRlbSA9IGl0ZW0uc3Vic3RyKDEpLnNsaWNlKDAsIC0xKTtcbiAgICAgICAgICBjb25zdCBzdWJJdGVtcyA9IGl0ZW0uc3BsaXQoJywnKTtcbiAgICAgICAgICBmb3IgKGNvbnN0IHN1Yml0ZW0gb2Ygc3ViSXRlbXMpIHtcbiAgICAgICAgICAgIHRtcGFycmF5LnB1c2goYFske3N1Yml0ZW0udHJpbSgpfV1gKTtcbiAgICAgICAgICB9XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgdG1wYXJyYXkucHVzaChpdGVtKTtcbiAgICAgICAgfVxuICAgICAgfVxuXG4gICAgICAvLyBFbnN1cmUgd2UgYXJlIGhhbmRsaW5nIGp1c3QgcGF0dGVybnNcbiAgICAgIGNvbnN0IGFycmF5ID0gdG1wYXJyYXkuZmlsdGVyKFxuICAgICAgICBpdGVtID0+IGl0ZW0uaW5jbHVkZXMoJ1snKSAmJiBpdGVtLmluY2x1ZGVzKCddJyksXG4gICAgICApO1xuXG4gICAgICBjb25zdCBwYXR0ZXJuID1cbiAgICAgICAgbGFzdENoYXIgPT09ICcqJ1xuICAgICAgICAgID8gcmVxdWVzdC5wYXJhbXMucGF0dGVybi5zbGljZSgwLCAtMSlcbiAgICAgICAgICA6IHJlcXVlc3QucGFyYW1zLnBhdHRlcm47XG4gICAgICBjb25zdCBpc0luY2x1ZGVkID0gYXJyYXkuZmlsdGVyKGl0ZW0gPT4ge1xuICAgICAgICBpdGVtID0gaXRlbS5zbGljZSgxLCAtMSk7XG4gICAgICAgIGNvbnN0IGxhc3RDaGFyID0gaXRlbVtpdGVtLmxlbmd0aCAtIDFdO1xuICAgICAgICBpdGVtID0gbGFzdENoYXIgPT09ICcqJyA/IGl0ZW0uc2xpY2UoMCwgLTEpIDogaXRlbTtcbiAgICAgICAgcmV0dXJuIGl0ZW0uaW5jbHVkZXMocGF0dGVybikgfHwgcGF0dGVybi5pbmNsdWRlcyhpdGVtKTtcbiAgICAgIH0pO1xuICAgICAgY29udGV4dC53YXp1aC5sb2dnZXIuZGVidWcoXG4gICAgICAgIGBUZW1wbGF0ZSBpcyB2YWxpZDogJHtcbiAgICAgICAgICBpc0luY2x1ZGVkICYmIEFycmF5LmlzQXJyYXkoaXNJbmNsdWRlZCkgJiYgaXNJbmNsdWRlZC5sZW5ndGhcbiAgICAgICAgICAgID8gJ3llcydcbiAgICAgICAgICAgIDogJ25vJ1xuICAgICAgICB9YCxcbiAgICAgICk7XG4gICAgICByZXR1cm4gaXNJbmNsdWRlZCAmJiBBcnJheS5pc0FycmF5KGlzSW5jbHVkZWQpICYmIGlzSW5jbHVkZWQubGVuZ3RoXG4gICAgICAgID8gcmVzcG9uc2Uub2soe1xuICAgICAgICAgICAgYm9keToge1xuICAgICAgICAgICAgICBzdGF0dXNDb2RlOiAyMDAsXG4gICAgICAgICAgICAgIHN0YXR1czogdHJ1ZSxcbiAgICAgICAgICAgICAgZGF0YTogYFRlbXBsYXRlIGZvdW5kIGZvciAke3JlcXVlc3QucGFyYW1zLnBhdHRlcm59YCxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgfSlcbiAgICAgICAgOiByZXNwb25zZS5vayh7XG4gICAgICAgICAgICBib2R5OiB7XG4gICAgICAgICAgICAgIHN0YXR1c0NvZGU6IDIwMCxcbiAgICAgICAgICAgICAgc3RhdHVzOiBmYWxzZSxcbiAgICAgICAgICAgICAgZGF0YTogYE5vIHRlbXBsYXRlIGZvdW5kIGZvciAke3JlcXVlc3QucGFyYW1zLnBhdHRlcm59YCxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgfSk7XG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgIGNvbnRleHQud2F6dWgubG9nZ2VyLmVycm9yKGVycm9yLm1lc3NhZ2UgfHwgZXJyb3IpO1xuICAgICAgcmV0dXJuIEVycm9yUmVzcG9uc2UoXG4gICAgICAgIGBDb3VsZCBub3QgcmV0cmlldmUgdGVtcGxhdGVzIGZyb20gJHtXQVpVSF9JTkRFWEVSX05BTUV9IGR1ZSB0byAke1xuICAgICAgICAgIGVycm9yLm1lc3NhZ2UgfHwgZXJyb3JcbiAgICAgICAgfWAsXG4gICAgICAgIDQwMDIsXG4gICAgICAgIDUwMCxcbiAgICAgICAgcmVzcG9uc2UsXG4gICAgICApO1xuICAgIH1cbiAgfVxuXG4gIC8qKlxuICAgKiBUaGlzIGNoZWNrIGluZGV4LXBhdHRlcm5cbiAgICogQHBhcmFtIHtPYmplY3R9IGNvbnRleHRcbiAgICogQHBhcmFtIHtPYmplY3R9IHJlcXVlc3RcbiAgICogQHBhcmFtIHtPYmplY3R9IHJlc3BvbnNlXG4gICAqIEByZXR1cm5zIHtPYmplY3R9IHN0YXR1cyBvYmogb3IgRXJyb3JSZXNwb25zZVxuICAgKi9cblxuICAvKipcbiAgICogVGhpcyBnZXQgdGhlIGZpZWxkcyBrZXlzXG4gICAqIEBwYXJhbSB7T2JqZWN0fSBjb250ZXh0XG4gICAqIEBwYXJhbSB7T2JqZWN0fSByZXF1ZXN0XG4gICAqIEBwYXJhbSB7T2JqZWN0fSByZXNwb25zZVxuICAgKiBAcmV0dXJucyB7QXJyYXk8T2JqZWN0Pn0gZmllbGRzIG9yIEVycm9yUmVzcG9uc2VcbiAgICovXG4gIGFzeW5jIGdldEZpZWxkVG9wKFxuICAgIGNvbnRleHQ6IFJlcXVlc3RIYW5kbGVyQ29udGV4dCxcbiAgICByZXF1ZXN0OiBPcGVuU2VhcmNoRGFzaGJvYXJkc1JlcXVlc3Q8XG4gICAgICB7IG1vZGU6IHN0cmluZzsgY2x1c3Rlcjogc3RyaW5nOyBmaWVsZDogc3RyaW5nOyBwYXR0ZXJuOiBzdHJpbmcgfSxcbiAgICAgIHsgYWdlbnRzTGlzdDogc3RyaW5nIH1cbiAgICA+LFxuICAgIHJlc3BvbnNlOiBPcGVuU2VhcmNoRGFzaGJvYXJkc1Jlc3BvbnNlRmFjdG9yeSxcbiAgKSB7XG4gICAgdHJ5IHtcbiAgICAgIC8vIFRvcCBmaWVsZCBwYXlsb2FkXG4gICAgICBsZXQgcGF5bG9hZCA9IHtcbiAgICAgICAgc2l6ZTogMSxcbiAgICAgICAgcXVlcnk6IHtcbiAgICAgICAgICBib29sOiB7XG4gICAgICAgICAgICBtdXN0OiBbXSxcbiAgICAgICAgICAgIG11c3Rfbm90OiB7XG4gICAgICAgICAgICAgIHRlcm06IHtcbiAgICAgICAgICAgICAgICAnYWdlbnQuaWQnOiAnMDAwJyxcbiAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICBmaWx0ZXI6IFtcbiAgICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgIHJhbmdlOiB7IHRpbWVzdGFtcDoge30gfSxcbiAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIF0sXG4gICAgICAgICAgfSxcbiAgICAgICAgfSxcbiAgICAgICAgYWdnczoge1xuICAgICAgICAgICcyJzoge1xuICAgICAgICAgICAgdGVybXM6IHtcbiAgICAgICAgICAgICAgZmllbGQ6ICcnLFxuICAgICAgICAgICAgICBzaXplOiAxLFxuICAgICAgICAgICAgICBvcmRlcjogeyBfY291bnQ6ICdkZXNjJyB9LFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICB9LFxuICAgICAgICB9LFxuICAgICAgfTtcblxuICAgICAgLy8gU2V0IHVwIHRpbWUgaW50ZXJ2YWwsIGRlZmF1bHQgdG8gTGFzdCAyNGhcbiAgICAgIGNvbnN0IHRpbWVHVEUgPSAnbm93LTFkJztcbiAgICAgIGNvbnN0IHRpbWVMVCA9ICdub3cnO1xuICAgICAgcGF5bG9hZC5xdWVyeS5ib29sLmZpbHRlclswXS5yYW5nZVsndGltZXN0YW1wJ11bJ2d0ZSddID0gdGltZUdURTtcbiAgICAgIHBheWxvYWQucXVlcnkuYm9vbC5maWx0ZXJbMF0ucmFuZ2VbJ3RpbWVzdGFtcCddWydsdCddID0gdGltZUxUO1xuXG4gICAgICAvLyBTZXQgdXAgbWF0Y2ggZm9yIGRlZmF1bHQgY2x1c3RlciBuYW1lXG4gICAgICBwYXlsb2FkLnF1ZXJ5LmJvb2wubXVzdC5wdXNoKFxuICAgICAgICByZXF1ZXN0LnBhcmFtcy5tb2RlID09PSAnY2x1c3RlcidcbiAgICAgICAgICA/IHsgbWF0Y2g6IHsgJ2NsdXN0ZXIubmFtZSc6IHJlcXVlc3QucGFyYW1zLmNsdXN0ZXIgfSB9XG4gICAgICAgICAgOiB7IG1hdGNoOiB7ICdtYW5hZ2VyLm5hbWUnOiByZXF1ZXN0LnBhcmFtcy5jbHVzdGVyIH0gfSxcbiAgICAgICk7XG5cbiAgICAgIGlmIChyZXF1ZXN0LnF1ZXJ5LmFnZW50c0xpc3QpXG4gICAgICAgIHBheWxvYWQucXVlcnkuYm9vbC5maWx0ZXIucHVzaCh7XG4gICAgICAgICAgdGVybXM6IHtcbiAgICAgICAgICAgICdhZ2VudC5pZCc6IHJlcXVlc3QucXVlcnkuYWdlbnRzTGlzdC5zcGxpdCgnLCcpLFxuICAgICAgICAgIH0sXG4gICAgICAgIH0pO1xuICAgICAgcGF5bG9hZC5hZ2dzWycyJ10udGVybXMuZmllbGQgPSByZXF1ZXN0LnBhcmFtcy5maWVsZDtcblxuICAgICAgY29uc3QgZGF0YSA9IGF3YWl0IGNvbnRleHQuY29yZS5vcGVuc2VhcmNoLmNsaWVudC5hc0N1cnJlbnRVc2VyLnNlYXJjaCh7XG4gICAgICAgIHNpemU6IDEsXG4gICAgICAgIGluZGV4OiByZXF1ZXN0LnBhcmFtcy5wYXR0ZXJuLFxuICAgICAgICBib2R5OiBwYXlsb2FkLFxuICAgICAgfSk7XG5cbiAgICAgIHJldHVybiBkYXRhLmJvZHkuaGl0cy50b3RhbC52YWx1ZSA9PT0gMCB8fFxuICAgICAgICB0eXBlb2YgZGF0YS5ib2R5LmFnZ3JlZ2F0aW9uc1snMiddLmJ1Y2tldHNbMF0gPT09ICd1bmRlZmluZWQnXG4gICAgICAgID8gcmVzcG9uc2Uub2soe1xuICAgICAgICAgICAgYm9keTogeyBzdGF0dXNDb2RlOiAyMDAsIGRhdGE6ICcnIH0sXG4gICAgICAgICAgfSlcbiAgICAgICAgOiByZXNwb25zZS5vayh7XG4gICAgICAgICAgICBib2R5OiB7XG4gICAgICAgICAgICAgIHN0YXR1c0NvZGU6IDIwMCxcbiAgICAgICAgICAgICAgZGF0YTogZGF0YS5ib2R5LmFnZ3JlZ2F0aW9uc1snMiddLmJ1Y2tldHNbMF0ua2V5LFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICB9KTtcbiAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgY29udGV4dC53YXp1aC5sb2dnZXIuZXJyb3IoZXJyb3IubWVzc2FnZSB8fCBlcnJvcik7XG4gICAgICByZXR1cm4gRXJyb3JSZXNwb25zZShlcnJvci5tZXNzYWdlIHx8IGVycm9yLCA0MDA0LCA1MDAsIHJlc3BvbnNlKTtcbiAgICB9XG4gIH1cblxuICAvKipcbiAgICogQ2hlY2tzIGZvciBtaW5pbXVtIGluZGV4IHBhdHRlcm4gZmllbGRzIGluIGEgbGlzdCBvZiBpbmRleCBwYXR0ZXJucy5cbiAgICogQHBhcmFtIHtBcnJheTxPYmplY3Q+fSBpbmRleFBhdHRlcm5MaXN0IExpc3Qgb2YgaW5kZXggcGF0dGVybnNcbiAgICovXG4gIHZhbGlkYXRlSW5kZXhQYXR0ZXJuKGluZGV4UGF0dGVybkxpc3QpIHtcbiAgICBjb25zdCBtaW5pbXVtID0gWyd0aW1lc3RhbXAnLCAncnVsZS5ncm91cHMnLCAnbWFuYWdlci5uYW1lJywgJ2FnZW50LmlkJ107XG4gICAgbGV0IGxpc3QgPSBbXTtcbiAgICBmb3IgKGNvbnN0IGluZGV4IG9mIGluZGV4UGF0dGVybkxpc3QpIHtcbiAgICAgIGxldCB2YWxpZCwgcGFyc2VkO1xuICAgICAgdHJ5IHtcbiAgICAgICAgcGFyc2VkID0gSlNPTi5wYXJzZShpbmRleC5hdHRyaWJ1dGVzLmZpZWxkcyk7XG4gICAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgICBjb250aW51ZTtcbiAgICAgIH1cblxuICAgICAgdmFsaWQgPSBwYXJzZWQuZmlsdGVyKGl0ZW0gPT4gbWluaW11bS5pbmNsdWRlcyhpdGVtLm5hbWUpKTtcbiAgICAgIGlmICh2YWxpZC5sZW5ndGggPT09IDQpIHtcbiAgICAgICAgbGlzdC5wdXNoKHtcbiAgICAgICAgICBpZDogaW5kZXguaWQsXG4gICAgICAgICAgdGl0bGU6IGluZGV4LmF0dHJpYnV0ZXMudGl0bGUsXG4gICAgICAgIH0pO1xuICAgICAgfVxuICAgIH1cbiAgICByZXR1cm4gbGlzdDtcbiAgfVxuXG4gIC8qKlxuICAgKiBSZXR1cm5zIGN1cnJlbnQgc2VjdXJpdHkgcGxhdGZvcm1cbiAgICogQHBhcmFtIHtPYmplY3R9IHJlcVxuICAgKiBAcGFyYW0ge09iamVjdH0gcmVwbHlcbiAgICogQHJldHVybnMge1N0cmluZ31cbiAgICovXG4gIGFzeW5jIGdldEN1cnJlbnRQbGF0Zm9ybShcbiAgICBjb250ZXh0OiBSZXF1ZXN0SGFuZGxlckNvbnRleHQsXG4gICAgcmVxdWVzdDogT3BlblNlYXJjaERhc2hib2FyZHNSZXF1ZXN0PHsgdXNlcjogc3RyaW5nIH0+LFxuICAgIHJlc3BvbnNlOiBPcGVuU2VhcmNoRGFzaGJvYXJkc1Jlc3BvbnNlRmFjdG9yeSxcbiAgKSB7XG4gICAgdHJ5IHtcbiAgICAgIHJldHVybiByZXNwb25zZS5vayh7XG4gICAgICAgIGJvZHk6IHtcbiAgICAgICAgICBwbGF0Zm9ybTogY29udGV4dC53YXp1aC5zZWN1cml0eS5wbGF0Zm9ybSxcbiAgICAgICAgfSxcbiAgICAgIH0pO1xuICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICBjb250ZXh0LndhenVoLmxvZ2dlci5lcnJvcihlcnJvci5tZXNzYWdlIHx8IGVycm9yKTtcbiAgICAgIHJldHVybiBFcnJvclJlc3BvbnNlKGVycm9yLm1lc3NhZ2UgfHwgZXJyb3IsIDQwMTEsIDUwMCwgcmVzcG9uc2UpO1xuICAgIH1cbiAgfVxuXG4gIC8qKlxuICAgKiBUaGlzIGNyZWF0ZXMgc2FtcGxlIGRhdGEgaW4gd2F6dWgtc2FtcGxlLWRhdGFcbiAgICogR0VUIC9pbmRleGVyL3NhbXBsZWRhdGEve2NhdGVnb3J5fVxuICAgKiBAcGFyYW0geyp9IGNvbnRleHRcbiAgICogQHBhcmFtIHsqfSByZXF1ZXN0XG4gICAqIEBwYXJhbSB7Kn0gcmVzcG9uc2VcbiAgICoge2FsZXJ0czogWy4uLl19IG9yIEVycm9yUmVzcG9uc2VcbiAgICovXG4gIGFzeW5jIGhhdmVTYW1wbGVEYXRhT2ZDYXRlZ29yeShcbiAgICBjb250ZXh0OiBSZXF1ZXN0SGFuZGxlckNvbnRleHQsXG4gICAgcmVxdWVzdDogT3BlblNlYXJjaERhc2hib2FyZHNSZXF1ZXN0PHsgY2F0ZWdvcnk6IHN0cmluZyB9PixcbiAgICByZXNwb25zZTogT3BlblNlYXJjaERhc2hib2FyZHNSZXNwb25zZUZhY3RvcnksXG4gICkge1xuICAgIHRyeSB7XG4gICAgICBjb25zdCBzYW1wbGVEYXRhSW5kZXggPSBhd2FpdCB0aGlzLmJ1aWxkU2FtcGxlSW5kZXhCeUNhdGVnb3J5KFxuICAgICAgICBjb250ZXh0LFxuICAgICAgICByZXF1ZXN0LnBhcmFtcy5jYXRlZ29yeSxcbiAgICAgICk7XG4gICAgICAvLyBDaGVjayBpZiB3YXp1aCBzYW1wbGUgZGF0YSBpbmRleCBleGlzdHNcbiAgICAgIGNvbnN0IGV4aXN0c1NhbXBsZUluZGV4ID0gYXdhaXQgUHJvbWlzZS5hbGwoXG4gICAgICAgIHNhbXBsZURhdGFJbmRleC5tYXAoYXN5bmMgKHsgaW5kZXhOYW1lIH0pID0+IHtcbiAgICAgICAgICByZXR1cm4gYXdhaXQgY29udGV4dC5jb3JlLm9wZW5zZWFyY2guY2xpZW50LmFzQ3VycmVudFVzZXIuaW5kaWNlcy5leGlzdHMoXG4gICAgICAgICAgICB7XG4gICAgICAgICAgICAgIGluZGV4OiBpbmRleE5hbWUsXG4gICAgICAgICAgICB9LFxuICAgICAgICAgICk7XG4gICAgICAgIH0pLFxuICAgICAgKTtcbiAgICAgIHJldHVybiByZXNwb25zZS5vayh7XG4gICAgICAgIGJvZHk6IHtcbiAgICAgICAgICBpbmRleDogc2FtcGxlRGF0YUluZGV4LFxuICAgICAgICAgIGV4aXN0czogZXhpc3RzU2FtcGxlSW5kZXguc29tZShyZXN1bHQgPT4gcmVzdWx0LmJvZHkpLFxuICAgICAgICB9LFxuICAgICAgfSk7XG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgIGNvbnRleHQud2F6dWgubG9nZ2VyLmVycm9yKFxuICAgICAgICBgRXJyb3IgY2hlY2tpbmcgaWYgdGhlcmUgYXJlIHNhbXBsZSBkYXRhIGluZGljZXM6ICR7XG4gICAgICAgICAgZXJyb3IubWVzc2FnZSB8fCBlcnJvclxuICAgICAgICB9YCxcbiAgICAgICk7XG5cbiAgICAgIGNvbnN0IFtzdGF0dXNDb2RlLCBlcnJvck1lc3NhZ2VdID0gdGhpcy5nZXRFcnJvckRldGFpbHMoZXJyb3IpO1xuICAgICAgcmV0dXJuIEVycm9yUmVzcG9uc2UoXG4gICAgICAgIGBFcnJvciBjaGVja2luZyBpZiB0aGVyZSBhcmUgc2FtcGxlIGRhdGEgaW5kaWNlczogJHtcbiAgICAgICAgICBlcnJvck1lc3NhZ2UgfHwgZXJyb3JcbiAgICAgICAgfWAsXG4gICAgICAgIDEwMDAsXG4gICAgICAgIHN0YXR1c0NvZGUsXG4gICAgICAgIHJlc3BvbnNlLFxuICAgICAgKTtcbiAgICB9XG4gIH1cbiAgLyoqXG4gICAqIFRoaXMgY3JlYXRlcyBzYW1wbGUgZGF0YSBpbiB3YXp1aC1zYW1wbGUtZGF0YVxuICAgKiBQT1NUIC9pbmRleGVyL3NhbXBsZWRhdGEve2NhdGVnb3J5fVxuICAgKiB7XG4gICAqICAgXCJtYW5hZ2VyXCI6IHtcbiAgICogICAgICBcIm5hbWVcIjogXCJtYW5hZ2VyX25hbWVcIlxuICAgKiAgICB9LFxuICAgKiAgICBjbHVzdGVyOiB7XG4gICAqICAgICAgbmFtZTogXCJteWNsdXN0ZXJcIixcbiAgICogICAgICBub2RlOiBcIm15bm9kZVwiXG4gICAqICAgIH1cbiAgICogfVxuICAgKiBAcGFyYW0geyp9IGNvbnRleHRcbiAgICogQHBhcmFtIHsqfSByZXF1ZXN0XG4gICAqIEBwYXJhbSB7Kn0gcmVzcG9uc2VcbiAgICoge2luZGV4OiBzdHJpbmcsIGRhdGE6IFsuLi5dLCBjb3VudDogbnVtYmVyfSBvciBFcnJvclJlc3BvbnNlXG4gICAqL1xuICBjcmVhdGVTYW1wbGVEYXRhID0gcm91dGVEZWNvcmF0b3JQcm90ZWN0ZWRBZG1pbmlzdHJhdG9yKDEwMDApKFxuICAgIGFzeW5jIChcbiAgICAgIGNvbnRleHQ6IFJlcXVlc3RIYW5kbGVyQ29udGV4dCxcbiAgICAgIHJlcXVlc3Q6IE9wZW5TZWFyY2hEYXNoYm9hcmRzUmVxdWVzdDx7IGNhdGVnb3J5OiBzdHJpbmcgfT4sXG4gICAgICByZXNwb25zZTogT3BlblNlYXJjaERhc2hib2FyZHNSZXNwb25zZUZhY3RvcnksXG4gICAgKSA9PiB7XG4gICAgICBjb25zdCBzYW1wbGVJbmRleE5hbWVzID0gYXdhaXQgdGhpcy5idWlsZFNhbXBsZUluZGV4QnlDYXRlZ29yeShcbiAgICAgICAgY29udGV4dCxcbiAgICAgICAgcmVxdWVzdC5wYXJhbXMuY2F0ZWdvcnksXG4gICAgICApO1xuXG4gICAgICBjb25zdCBzYW1wbGVEb2N1bWVudHNSZXNwb25zZTogQXJyYXk8e1xuICAgICAgICBpbmRleDogc3RyaW5nO1xuICAgICAgICBzYW1wbGVEYXRhQ291bnQ6IG51bWJlcjtcbiAgICAgIH0+ID0gW107XG5cbiAgICAgIHRyeSB7XG4gICAgICAgIGF3YWl0IFByb21pc2UuYWxsKFxuICAgICAgICAgIHNhbXBsZUluZGV4TmFtZXMubWFwKGFzeW5jICh7IGluZGV4TmFtZSwgZGF0YVNldCB9KSA9PiB7XG4gICAgICAgICAgICB0cnkge1xuICAgICAgICAgICAgICBjb25zdCBidWxrUHJlZml4ID0gSlNPTi5zdHJpbmdpZnkoe1xuICAgICAgICAgICAgICAgIGluZGV4OiB7XG4gICAgICAgICAgICAgICAgICBfaW5kZXg6IGluZGV4TmFtZSxcbiAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgY29uc3Qgc2FtcGxlRGF0YUdlbmVyYXRlUGFyYW1zID1cbiAgICAgICAgICAgICAgICAocmVxdWVzdC5ib2R5ICYmIHJlcXVlc3QuYm9keS5wYXJhbXMpIHx8IHt9O1xuXG4gICAgICAgICAgICAgIGNvbnN0IG1hcHBlZERhdGEgPSBXQVpVSF9TQU1QTEVfREFUQV9DQVRFR09SSUVTX1RZUEVfREFUQVtcbiAgICAgICAgICAgICAgICByZXF1ZXN0LnBhcmFtcy5jYXRlZ29yeVxuICAgICAgICAgICAgICBdXG4gICAgICAgICAgICAgICAgLmZpbHRlcigoaXRlbTogeyBkYXRhU2V0OiBzdHJpbmcgfSkgPT4gaXRlbS5kYXRhU2V0ID09PSBkYXRhU2V0KVxuICAgICAgICAgICAgICAgIC5tYXAoKHR5cGVTYW1wbGU6IHsgZGF0YVNldD86IHN0cmluZzsgY291bnQ/OiBudW1iZXIgfSkgPT4ge1xuICAgICAgICAgICAgICAgICAgcmV0dXJuIGdlbmVyYXRlU2FtcGxlRGF0YShcbiAgICAgICAgICAgICAgICAgICAgeyAuLi50eXBlU2FtcGxlLCAuLi5zYW1wbGVEYXRhR2VuZXJhdGVQYXJhbXMgfSxcbiAgICAgICAgICAgICAgICAgICAgcmVxdWVzdC5ib2R5LmNvdW50IHx8XG4gICAgICAgICAgICAgICAgICAgICAgdHlwZVNhbXBsZS5jb3VudCB8fFxuICAgICAgICAgICAgICAgICAgICAgIFdBWlVIX1NBTVBMRV9BTEVSVFNfREVGQVVMVF9OVU1CRVJfRE9DVU1FTlRTLFxuICAgICAgICAgICAgICAgICAgICBjb250ZXh0LFxuICAgICAgICAgICAgICAgICAgKTtcbiAgICAgICAgICAgICAgICB9KTtcblxuICAgICAgICAgICAgICBsZXQgc2FtcGxlRGF0YUFuZFRlbXBsYXRlOiB7XG4gICAgICAgICAgICAgICAgc2FtcGxlRGF0YTogW107XG4gICAgICAgICAgICAgICAgdGVtcGxhdGU/OiB7XG4gICAgICAgICAgICAgICAgICBpbmRleF9wYXR0ZXJuczogc3RyaW5nO1xuICAgICAgICAgICAgICAgICAgcHJpb3JpdHk6IG51bWJlcjtcbiAgICAgICAgICAgICAgICAgIHRlbXBsYXRlOiBhbnk7XG4gICAgICAgICAgICAgICAgfTtcbiAgICAgICAgICAgICAgfSA9IHsgc2FtcGxlRGF0YTogW10gfTtcblxuICAgICAgICAgICAgICBpZiAobWFwcGVkRGF0YS5sZW5ndGggPiAxKSB7XG4gICAgICAgICAgICAgICAgbWFwcGVkRGF0YS5mb3JFYWNoKChpdGVtOiB7IHNhbXBsZURhdGE6IFtdIH0pID0+XG4gICAgICAgICAgICAgICAgICBzYW1wbGVEYXRhQW5kVGVtcGxhdGUuc2FtcGxlRGF0YS5wdXNoKC4uLml0ZW0uc2FtcGxlRGF0YSksXG4gICAgICAgICAgICAgICAgKTtcbiAgICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAgIGlmIChtYXBwZWREYXRhLmxlbmd0aCA9PT0gMSAmJiBtYXBwZWREYXRhWzBdLnRlbXBsYXRlKSB7XG4gICAgICAgICAgICAgICAgc2FtcGxlRGF0YUFuZFRlbXBsYXRlID0gbWFwcGVkRGF0YVswXTtcbiAgICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAgIGNvbnN0IHsgc2FtcGxlRGF0YSB9ID0gc2FtcGxlRGF0YUFuZFRlbXBsYXRlO1xuXG4gICAgICAgICAgICAgIGNvbnN0IGJ1bGsgPSBzYW1wbGVEYXRhXG4gICAgICAgICAgICAgICAgLm1hcChkb2N1bWVudCA9PiBgJHtidWxrUHJlZml4fVxcbiR7SlNPTi5zdHJpbmdpZnkoZG9jdW1lbnQpfVxcbmApXG4gICAgICAgICAgICAgICAgLmpvaW4oJycpO1xuXG4gICAgICAgICAgICAgIC8vIEluZGV4IGRhdGFcblxuICAgICAgICAgICAgICAvLyBDaGVjayBpZiB3YXp1aCBzYW1wbGUgZGF0YSBpbmRleCBleGlzdHNcbiAgICAgICAgICAgICAgY29uc3QgZXhpc3RzU2FtcGxlSW5kZXggPVxuICAgICAgICAgICAgICAgIGF3YWl0IGNvbnRleHQuY29yZS5vcGVuc2VhcmNoLmNsaWVudC5hc0N1cnJlbnRVc2VyLmluZGljZXMuZXhpc3RzKFxuICAgICAgICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgICAgICBpbmRleDogaW5kZXhOYW1lLFxuICAgICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgICApO1xuICAgICAgICAgICAgICBpZiAoZXhpc3RzU2FtcGxlSW5kZXguYm9keSA9PT0gZmFsc2UpIHtcbiAgICAgICAgICAgICAgICAvLyBDcmVhdGUgd2F6dWggc2FtcGxlIGRhdGEgaW5kZXhcbiAgICAgICAgICAgICAgICBsZXQgY29uZmlndXJhdGlvbjtcblxuICAgICAgICAgICAgICAgIGlmIChzYW1wbGVEYXRhQW5kVGVtcGxhdGU/LnRlbXBsYXRlKSB7XG4gICAgICAgICAgICAgICAgICBjb25maWd1cmF0aW9uID0gc2FtcGxlRGF0YUFuZFRlbXBsYXRlLnRlbXBsYXRlLnRlbXBsYXRlO1xuXG4gICAgICAgICAgICAgICAgICBkZWxldGUgY29uZmlndXJhdGlvbi5pbmRleF9wYXR0ZXJucztcbiAgICAgICAgICAgICAgICAgIGRlbGV0ZSBjb25maWd1cmF0aW9uLnByaW9yaXR5O1xuXG4gICAgICAgICAgICAgICAgICBjb25maWd1cmF0aW9uLnNldHRpbmdzLmluZGV4Lm51bWJlcl9vZl9zaGFyZHMgPVxuICAgICAgICAgICAgICAgICAgICBXQVpVSF9TQU1QTEVfQUxFUlRTX0lOREVYX1NIQVJEUztcbiAgICAgICAgICAgICAgICAgIGNvbmZpZ3VyYXRpb24uc2V0dGluZ3MuaW5kZXgubnVtYmVyX29mX3JlcGxpY2FzID1cbiAgICAgICAgICAgICAgICAgICAgV0FaVUhfU0FNUExFX0FMRVJUU19JTkRFWF9SRVBMSUNBUztcbiAgICAgICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAgICAgY29uZmlndXJhdGlvbiA9IHtcbiAgICAgICAgICAgICAgICAgICAgc2V0dGluZ3M6IHtcbiAgICAgICAgICAgICAgICAgICAgICBpbmRleDoge1xuICAgICAgICAgICAgICAgICAgICAgICAgbnVtYmVyX29mX3NoYXJkczogV0FaVUhfU0FNUExFX0FMRVJUU19JTkRFWF9TSEFSRFMsXG4gICAgICAgICAgICAgICAgICAgICAgICBudW1iZXJfb2ZfcmVwbGljYXM6IFdBWlVIX1NBTVBMRV9BTEVSVFNfSU5ERVhfUkVQTElDQVMsXG4gICAgICAgICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgICAgIH07XG4gICAgICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAgICAgYXdhaXQgY29udGV4dC5jb3JlLm9wZW5zZWFyY2guY2xpZW50LmFzQ3VycmVudFVzZXIuaW5kaWNlcy5jcmVhdGUoXG4gICAgICAgICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgICAgIGluZGV4OiBpbmRleE5hbWUsXG4gICAgICAgICAgICAgICAgICAgIGJvZHk6IGNvbmZpZ3VyYXRpb24sXG4gICAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICAgICk7XG4gICAgICAgICAgICAgICAgY29udGV4dC53YXp1aC5sb2dnZXIuaW5mbyhgSW5kZXggJHtpbmRleE5hbWV9IGNyZWF0ZWRgKTtcbiAgICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAgIGF3YWl0IGNvbnRleHQuY29yZS5vcGVuc2VhcmNoLmNsaWVudC5hc0N1cnJlbnRVc2VyLmJ1bGsoe1xuICAgICAgICAgICAgICAgIGluZGV4OiBpbmRleE5hbWUsXG4gICAgICAgICAgICAgICAgYm9keTogYnVsayxcbiAgICAgICAgICAgICAgfSk7XG5cbiAgICAgICAgICAgICAgY29udGV4dC53YXp1aC5sb2dnZXIuaW5mbyhcbiAgICAgICAgICAgICAgICBgQWRkZWQgc2FtcGxlIGRhdGEgdG8gJHtpbmRleE5hbWV9IGluZGV4YCxcbiAgICAgICAgICAgICAgKTtcblxuICAgICAgICAgICAgICBzYW1wbGVEb2N1bWVudHNSZXNwb25zZS5wdXNoKHtcbiAgICAgICAgICAgICAgICBpbmRleDogaW5kZXhOYW1lLFxuICAgICAgICAgICAgICAgIHNhbXBsZURhdGFDb3VudDogc2FtcGxlRGF0YS5sZW5ndGgsXG4gICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgICAgICAgICAgY29udGV4dC53YXp1aC5sb2dnZXIuZXJyb3IoXG4gICAgICAgICAgICAgICAgYEVycm9yIGFkZGluZyBzYW1wbGUgZGF0YSB0byAke2luZGV4TmFtZX0gaW5kZXg6ICR7XG4gICAgICAgICAgICAgICAgICBlcnJvci5tZXNzYWdlIHx8IGVycm9yXG4gICAgICAgICAgICAgICAgfWAsXG4gICAgICAgICAgICAgICk7XG5cbiAgICAgICAgICAgICAgY29uc3QgW3N0YXR1c0NvZGUsIGVycm9yTWVzc2FnZV0gPSB0aGlzLmdldEVycm9yRGV0YWlscyhlcnJvcik7XG4gICAgICAgICAgICAgIHRocm93IHsgc3RhdHVzQ29kZSwgZXJyb3JNZXNzYWdlIH07XG4gICAgICAgICAgICB9XG4gICAgICAgICAgfSksXG4gICAgICAgICk7XG5cbiAgICAgICAgLy8gT25seSByZXR1cm4gcmVzcG9uc2UgYWZ0ZXIgYWxsIG9wZXJhdGlvbnMgYXJlIGNvbXBsZXRlXG4gICAgICAgIHJldHVybiByZXNwb25zZS5vayh7XG4gICAgICAgICAgYm9keTogeyBzYW1wbGVEb2N1bWVudHNSZXNwb25zZSB9LFxuICAgICAgICB9KTtcbiAgICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICAgIGNvbnN0IHN0YXR1c0NvZGUgPVxuICAgICAgICAgIGVycm9yPy5zdGF0dXNDb2RlIHx8IEhUVFBfU1RBVFVTX0NPREVTLklOVEVSTkFMX1NFUlZFUl9FUlJPUjtcbiAgICAgICAgY29uc3QgZXJyb3JNZXNzYWdlID0gZXJyb3I/LmVycm9yTWVzc2FnZSB8fCBlcnJvci5tZXNzYWdlIHx8IGVycm9yO1xuICAgICAgICByZXR1cm4gRXJyb3JSZXNwb25zZShcbiAgICAgICAgICBlcnJvck1lc3NhZ2UsXG4gICAgICAgICAgV0FaVUhfU1RBVFVTX0NPREVTLlVOS05PV04sXG4gICAgICAgICAgc3RhdHVzQ29kZSxcbiAgICAgICAgICByZXNwb25zZSxcbiAgICAgICAgKTtcbiAgICAgIH1cbiAgICB9LFxuICApO1xuICAvKipcbiAgICogVGhpcyBkZWxldGVzIHNhbXBsZSBkYXRhXG4gICAqIEBwYXJhbSB7Kn0gY29udGV4dFxuICAgKiBAcGFyYW0geyp9IHJlcXVlc3RcbiAgICogQHBhcmFtIHsqfSByZXNwb25zZVxuICAgKiB7cmVzdWx0OiBcImRlbGV0ZWRcIiwgaW5kZXg6IHN0cmluZ30gb3IgRXJyb3JSZXNwb25zZVxuICAgKi9cbiAgZGVsZXRlU2FtcGxlRGF0YSA9IHJvdXRlRGVjb3JhdG9yUHJvdGVjdGVkQWRtaW5pc3RyYXRvcihcbiAgICBXQVpVSF9TVEFUVVNfQ09ERVMuVU5LTk9XTixcbiAgKShcbiAgICBhc3luYyAoXG4gICAgICBjb250ZXh0OiBSZXF1ZXN0SGFuZGxlckNvbnRleHQsXG4gICAgICByZXF1ZXN0OiBPcGVuU2VhcmNoRGFzaGJvYXJkc1JlcXVlc3Q8eyBjYXRlZ29yeTogc3RyaW5nIH0+LFxuICAgICAgcmVzcG9uc2U6IE9wZW5TZWFyY2hEYXNoYm9hcmRzUmVzcG9uc2VGYWN0b3J5LFxuICAgICkgPT4ge1xuICAgICAgdHJ5IHtcbiAgICAgICAgLy8gR2V0IHNhbXBsZSBkYXRhIGluZGV4ZXNcbiAgICAgICAgY29uc3Qgc2FtcGxlRGF0YUluZGV4QW5kRGF0YVNldCA9IGF3YWl0IHRoaXMuYnVpbGRTYW1wbGVJbmRleEJ5Q2F0ZWdvcnkoXG4gICAgICAgICAgY29udGV4dCxcbiAgICAgICAgICByZXF1ZXN0LnBhcmFtcy5jYXRlZ29yeSxcbiAgICAgICAgKTtcblxuICAgICAgICAvLyBHZXQgb25seSBpbmRleCBuYW1lc1xuICAgICAgICBjb25zdCBzYW1wbGVEYXRhSW5kZXggPSBzYW1wbGVEYXRhSW5kZXhBbmREYXRhU2V0Lm1hcChcbiAgICAgICAgICAoeyBpbmRleE5hbWUgfSkgPT4gaW5kZXhOYW1lLFxuICAgICAgICApO1xuXG4gICAgICAgIGlmICghc2FtcGxlRGF0YUluZGV4Lmxlbmd0aCkge1xuICAgICAgICAgIHJldHVybiBFcnJvclJlc3BvbnNlKFxuICAgICAgICAgICAgYE5vIGluZGljZXMgZm91bmQgZm9yIGNhdGVnb3J5ICR7cmVxdWVzdC5wYXJhbXMuY2F0ZWdvcnl9YCxcbiAgICAgICAgICAgIDEwMDAsXG4gICAgICAgICAgICA0MDQsXG4gICAgICAgICAgICByZXNwb25zZSxcbiAgICAgICAgICApO1xuICAgICAgICB9XG5cbiAgICAgICAgLy8gRGVsZXRlIHNhbXBsZSBkYXRhIGluZGV4ZXNcbiAgICAgICAgLy8gcmV0dXJuIHN1Y2Nlc3Mgb3IgZXJyb3IgZm9yIGVhY2ggaW5kZXhcbiAgICAgICAgY29uc3QgcmVzdWx0cyA9IGF3YWl0IFByb21pc2UuYWxsKFxuICAgICAgICAgIHNhbXBsZURhdGFJbmRleC5tYXAoYXN5bmMgaW5kZXggPT4ge1xuICAgICAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgICAgLy8gQ2hlY2sgaWYgV2F6dWggc2FtcGxlIGRhdGEgaW5kZXggZXhpc3RzXG4gICAgICAgICAgICAgIGNvbnN0IGV4aXN0c1NhbXBsZUluZGV4ID1cbiAgICAgICAgICAgICAgICBhd2FpdCBjb250ZXh0LmNvcmUub3BlbnNlYXJjaC5jbGllbnQuYXNDdXJyZW50VXNlci5pbmRpY2VzLmV4aXN0cyhcbiAgICAgICAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICAgICAgaW5kZXgsXG4gICAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICAgICk7XG5cbiAgICAgICAgICAgICAgaWYgKGV4aXN0c1NhbXBsZUluZGV4LmJvZHkpIHtcbiAgICAgICAgICAgICAgICAvLyBEZWxldGUgV2F6dWggc2FtcGxlIGRhdGEgaW5kZXhcbiAgICAgICAgICAgICAgICBhd2FpdCBjb250ZXh0LmNvcmUub3BlbnNlYXJjaC5jbGllbnQuYXNDdXJyZW50VXNlci5pbmRpY2VzLmRlbGV0ZShcbiAgICAgICAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICAgICAgaW5kZXg6IFtpbmRleF0sXG4gICAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICAgICk7XG4gICAgICAgICAgICAgICAgY29udGV4dC53YXp1aC5sb2dnZXIuaW5mbyhgRGVsZXRlZCAke2luZGV4fSBpbmRleGApO1xuICAgICAgICAgICAgICAgIHJldHVybiB7IHN1Y2Nlc3M6IHRydWUsIGluZGV4LCBtZXNzYWdlOiAnZGVsZXRlZCcgfTtcbiAgICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgICByZXR1cm4ge1xuICAgICAgICAgICAgICAgICAgc3VjY2VzczogZmFsc2UsXG4gICAgICAgICAgICAgICAgICBpbmRleCxcbiAgICAgICAgICAgICAgICAgIG1lc3NhZ2U6IGBJbmRleCBkb2Vzbid0IGV4aXN0YCxcbiAgICAgICAgICAgICAgICB9O1xuICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgICAgICAgICBjb250ZXh0LndhenVoLmxvZ2dlci5lcnJvcihcbiAgICAgICAgICAgICAgICBgRXJyb3IgZGVsZXRpbmcgc2FtcGxlIGRhdGEgb2YgJHtpbmRleH0gaW5kZXg6ICR7XG4gICAgICAgICAgICAgICAgICBlcnJvci5tZXNzYWdlIHx8IGVycm9yXG4gICAgICAgICAgICAgICAgfWAsXG4gICAgICAgICAgICAgICk7XG4gICAgICAgICAgICAgIGNvbnN0IFtzdGF0dXNDb2RlLCBlcnJvck1lc3NhZ2VdID0gdGhpcy5nZXRFcnJvckRldGFpbHMoZXJyb3IpO1xuICAgICAgICAgICAgICByZXR1cm4ge1xuICAgICAgICAgICAgICAgIHN1Y2Nlc3M6IGZhbHNlLFxuICAgICAgICAgICAgICAgIGluZGV4LFxuICAgICAgICAgICAgICAgIG1lc3NhZ2U6IGVycm9yTWVzc2FnZSB8fCBlcnJvcixcbiAgICAgICAgICAgICAgICBzdGF0dXNDb2RlLFxuICAgICAgICAgICAgICB9O1xuICAgICAgICAgICAgfVxuICAgICAgICAgIH0pLFxuICAgICAgICApO1xuXG4gICAgICAgIC8vIENoZWNrIGlmIGFsbCByZXN1bHRzIGFyZSBzdWNjZXNzZnVsXG4gICAgICAgIGNvbnN0IHN1Y2Nlc3NSZXN1bHRzID0gcmVzdWx0cy5maWx0ZXIocmVzdWx0ID0+IHJlc3VsdC5zdWNjZXNzKTtcbiAgICAgICAgY29uc3QgZmFpbGVkUmVzdWx0cyA9IHJlc3VsdHMuZmlsdGVyKHJlc3VsdCA9PiAhcmVzdWx0LnN1Y2Nlc3MpO1xuXG4gICAgICAgIGlmIChzdWNjZXNzUmVzdWx0cy5sZW5ndGggPiAwKSB7XG4gICAgICAgICAgY29udGV4dC53YXp1aC5sb2dnZXIuaW5mbyhcbiAgICAgICAgICAgIGBEZWxldGVkICR7c3VjY2Vzc1Jlc3VsdHMubGVuZ3RofSBpbmRpY2VzOiAke3N1Y2Nlc3NSZXN1bHRzXG4gICAgICAgICAgICAgIC5tYXAociA9PiByLmluZGV4KVxuICAgICAgICAgICAgICAuam9pbignLCAnKX1gLFxuICAgICAgICAgICk7XG4gICAgICAgICAgaWYgKGZhaWxlZFJlc3VsdHMubGVuZ3RoID4gMCkge1xuICAgICAgICAgICAgY29udGV4dC53YXp1aC5sb2dnZXIuZXJyb3IoXG4gICAgICAgICAgICAgIGBGYWlsZWQgdG8gZGVsZXRlICR7ZmFpbGVkUmVzdWx0cy5sZW5ndGh9IGluZGljZXM6ICR7ZmFpbGVkUmVzdWx0c1xuICAgICAgICAgICAgICAgIC5tYXAociA9PiByLmluZGV4KVxuICAgICAgICAgICAgICAgIC5qb2luKCcsICcpfWAsXG4gICAgICAgICAgICApO1xuICAgICAgICAgIH1cblxuICAgICAgICAgIHJldHVybiByZXNwb25zZS5vayh7XG4gICAgICAgICAgICBib2R5OiB7XG4gICAgICAgICAgICAgIHJlc3VsdDogJ2RlbGV0ZWQnLFxuICAgICAgICAgICAgICBzdWNjZXNzQ291bnQ6IHN1Y2Nlc3NSZXN1bHRzLmxlbmd0aCxcbiAgICAgICAgICAgICAgZmFpbGVkQ291bnQ6IGZhaWxlZFJlc3VsdHMubGVuZ3RoLFxuICAgICAgICAgICAgICBpbmRpY2VzOiBzdWNjZXNzUmVzdWx0cy5tYXAociA9PiByLmluZGV4KSxcbiAgICAgICAgICAgICAgZXJyb3JzOiBmYWlsZWRSZXN1bHRzLmxlbmd0aCA/IGZhaWxlZFJlc3VsdHMgOiB1bmRlZmluZWQsXG4gICAgICAgICAgICB9LFxuICAgICAgICAgIH0pO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgIGNvbnN0IGZpcnN0RXJyb3IgPSBmYWlsZWRSZXN1bHRzWzBdO1xuICAgICAgICAgIHJldHVybiBFcnJvclJlc3BvbnNlKFxuICAgICAgICAgICAgYEZhaWxlZCB0byBkZWxldGUgaW5kaWNlczogJHtmaXJzdEVycm9yLm1lc3NhZ2V9YCxcbiAgICAgICAgICAgIDEwMDAsXG4gICAgICAgICAgICBmaXJzdEVycm9yLnN0YXR1c0NvZGUgfHwgNTAwLFxuICAgICAgICAgICAgcmVzcG9uc2UsXG4gICAgICAgICAgKTtcbiAgICAgICAgfVxuICAgICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgICAgY29udGV4dC53YXp1aC5sb2dnZXIuZXJyb3IoXG4gICAgICAgICAgYEVycm9yIGRlbGV0aW5nIHNhbXBsZSBkYXRhOiAke2Vycm9yLm1lc3NhZ2UgfHwgZXJyb3J9YCxcbiAgICAgICAgKTtcbiAgICAgICAgY29uc3QgW3N0YXR1c0NvZGUsIGVycm9yTWVzc2FnZV0gPSB0aGlzLmdldEVycm9yRGV0YWlscyhlcnJvcik7XG4gICAgICAgIHJldHVybiBFcnJvclJlc3BvbnNlKGVycm9yTWVzc2FnZSB8fCBlcnJvciwgMTAwMCwgc3RhdHVzQ29kZSwgcmVzcG9uc2UpO1xuICAgICAgfVxuICAgIH0sXG4gICk7XG5cbiAgYXN5bmMgYWxlcnRzKFxuICAgIGNvbnRleHQ6IFJlcXVlc3RIYW5kbGVyQ29udGV4dCxcbiAgICByZXF1ZXN0OiBPcGVuU2VhcmNoRGFzaGJvYXJkc1JlcXVlc3QsXG4gICAgcmVzcG9uc2U6IE9wZW5TZWFyY2hEYXNoYm9hcmRzUmVzcG9uc2VGYWN0b3J5LFxuICApIHtcbiAgICB0cnkge1xuICAgICAgY29uc3QgZGF0YSA9IGF3YWl0IGNvbnRleHQuY29yZS5vcGVuc2VhcmNoLmNsaWVudC5hc0N1cnJlbnRVc2VyLnNlYXJjaChcbiAgICAgICAgcmVxdWVzdC5ib2R5LFxuICAgICAgKTtcbiAgICAgIHJldHVybiByZXNwb25zZS5vayh7XG4gICAgICAgIGJvZHk6IGRhdGEuYm9keSxcbiAgICAgIH0pO1xuICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICBjb250ZXh0LndhenVoLmxvZ2dlci5lcnJvcihlcnJvci5tZXNzYWdlIHx8IGVycm9yKTtcbiAgICAgIHJldHVybiBFcnJvclJlc3BvbnNlKGVycm9yLm1lc3NhZ2UgfHwgZXJyb3IsIDQwMTAsIDUwMCwgcmVzcG9uc2UpO1xuICAgIH1cbiAgfVxuXG4gIGdldEVycm9yRGV0YWlscyhlcnJvcikge1xuICAgIGNvbnN0IHN0YXR1c0NvZGUgPSBlcnJvcj8ubWV0YT8uc3RhdHVzQ29kZSB8fCA1MDA7XG4gICAgbGV0IGVycm9yTWVzc2FnZSA9IGVycm9yLm1lc3NhZ2U7XG5cbiAgICBpZiAoc3RhdHVzQ29kZSA9PT0gNDAzKSB7XG4gICAgICBlcnJvck1lc3NhZ2UgPSBlcnJvcj8ubWV0YT8uYm9keT8uZXJyb3I/LnJlYXNvbiB8fCAnUGVybWlzc2lvbiBkZW5pZWQnO1xuICAgIH1cblxuICAgIHJldHVybiBbc3RhdHVzQ29kZSwgZXJyb3JNZXNzYWdlXTtcbiAgfVxufVxuIl0sIm1hcHBpbmdzIjoiOzs7Ozs7QUFXQSxJQUFBQSxjQUFBLEdBQUFDLE9BQUE7QUFDQSxJQUFBQyxVQUFBLEdBQUFELE9BQUE7QUFjQSxJQUFBRSxXQUFBLEdBQUFGLE9BQUE7QUFDQSxJQUFBRyxtQkFBQSxHQUFBSCxPQUFBO0FBQWlFLFNBQUFJLGdCQUFBQyxDQUFBLEVBQUFDLENBQUEsRUFBQUMsQ0FBQSxZQUFBRCxDQUFBLEdBQUFFLGNBQUEsQ0FBQUYsQ0FBQSxNQUFBRCxDQUFBLEdBQUFJLE1BQUEsQ0FBQUMsY0FBQSxDQUFBTCxDQUFBLEVBQUFDLENBQUEsSUFBQUssS0FBQSxFQUFBSixDQUFBLEVBQUFLLFVBQUEsTUFBQUMsWUFBQSxNQUFBQyxRQUFBLFVBQUFULENBQUEsQ0FBQUMsQ0FBQSxJQUFBQyxDQUFBLEVBQUFGLENBQUE7QUFBQSxTQUFBRyxlQUFBRCxDQUFBLFFBQUFRLENBQUEsR0FBQUMsWUFBQSxDQUFBVCxDQUFBLHVDQUFBUSxDQUFBLEdBQUFBLENBQUEsR0FBQUEsQ0FBQTtBQUFBLFNBQUFDLGFBQUFULENBQUEsRUFBQUQsQ0FBQSwyQkFBQUMsQ0FBQSxLQUFBQSxDQUFBLFNBQUFBLENBQUEsTUFBQUYsQ0FBQSxHQUFBRSxDQUFBLENBQUFVLE1BQUEsQ0FBQUMsV0FBQSxrQkFBQWIsQ0FBQSxRQUFBVSxDQUFBLEdBQUFWLENBQUEsQ0FBQWMsSUFBQSxDQUFBWixDQUFBLEVBQUFELENBQUEsdUNBQUFTLENBQUEsU0FBQUEsQ0FBQSxZQUFBSyxTQUFBLHlFQUFBZCxDQUFBLEdBQUFlLE1BQUEsR0FBQUMsTUFBQSxFQUFBZixDQUFBLEtBM0JqRTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBbUJBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxTQUFTZ0Isa0NBQWtDQSxDQUN6Q0MsS0FBeUQsRUFDekQ7RUFDQSxNQUFNQyxJQUFJLEdBQUcsSUFBSUMsR0FBRyxDQUFDLENBQUM7RUFDdEIsT0FBT0YsS0FBSyxDQUFDRyxNQUFNLENBQUNDLElBQUksSUFBSTtJQUMxQjtJQUNBLE1BQU1DLEdBQUcsR0FBSSxHQUFFRCxJQUFJLENBQUNFLG1CQUFvQixLQUFJRixJQUFJLENBQUNHLE9BQVEsRUFBQztJQUMxRCxJQUFJTixJQUFJLENBQUNPLEdBQUcsQ0FBQ0gsR0FBRyxDQUFDLEVBQUU7TUFDakIsT0FBTyxLQUFLO0lBQ2Q7SUFDQUosSUFBSSxDQUFDUSxHQUFHLENBQUNKLEdBQUcsQ0FBQztJQUNiLE9BQU8sSUFBSTtFQUNiLENBQUMsQ0FBQztBQUNKO0FBRU8sTUFBTUssZ0JBQWdCLENBQUM7RUFDNUJDLFdBQVdBLENBQUEsRUFBRztJQTJUZDtBQUNGO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0lBaEJFL0IsZUFBQSwyQkFpQm1CLElBQUFnQyxnREFBb0MsRUFBQyxJQUFJLENBQUMsQ0FDM0QsT0FDRUMsT0FBOEIsRUFDOUJDLE9BQTBELEVBQzFEQyxRQUE2QyxLQUMxQztNQUNILE1BQU1DLGdCQUFnQixHQUFHLE1BQU0sSUFBSSxDQUFDQywwQkFBMEIsQ0FDNURKLE9BQU8sRUFDUEMsT0FBTyxDQUFDSSxNQUFNLENBQUNDLFFBQ2pCLENBQUM7TUFFRCxNQUFNQyx1QkFHSixHQUFHLEVBQUU7TUFFUCxJQUFJO1FBQ0YsTUFBTUMsT0FBTyxDQUFDQyxHQUFHLENBQ2ZOLGdCQUFnQixDQUFDTyxHQUFHLENBQUMsT0FBTztVQUFFQyxTQUFTO1VBQUVqQjtRQUFRLENBQUMsS0FBSztVQUNyRCxJQUFJO1lBQ0YsTUFBTWtCLFVBQVUsR0FBR0MsSUFBSSxDQUFDQyxTQUFTLENBQUM7Y0FDaENDLEtBQUssRUFBRTtnQkFDTEMsTUFBTSxFQUFFTDtjQUNWO1lBQ0YsQ0FBQyxDQUFDO1lBQ0YsTUFBTU0sd0JBQXdCLEdBQzNCaEIsT0FBTyxDQUFDaUIsSUFBSSxJQUFJakIsT0FBTyxDQUFDaUIsSUFBSSxDQUFDYixNQUFNLElBQUssQ0FBQyxDQUFDO1lBRTdDLE1BQU1jLFVBQVUsR0FBR0MsaURBQXNDLENBQ3ZEbkIsT0FBTyxDQUFDSSxNQUFNLENBQUNDLFFBQVEsQ0FDeEIsQ0FDRWhCLE1BQU0sQ0FBRUMsSUFBeUIsSUFBS0EsSUFBSSxDQUFDRyxPQUFPLEtBQUtBLE9BQU8sQ0FBQyxDQUMvRGdCLEdBQUcsQ0FBRVcsVUFBZ0QsSUFBSztjQUN6RCxPQUFPLElBQUFDLHNDQUFrQixFQUN2QjtnQkFBRSxHQUFHRCxVQUFVO2dCQUFFLEdBQUdKO2NBQXlCLENBQUMsRUFDOUNoQixPQUFPLENBQUNpQixJQUFJLENBQUNLLEtBQUssSUFDaEJGLFVBQVUsQ0FBQ0UsS0FBSyxJQUNoQkMsdURBQTRDLEVBQzlDeEIsT0FDRixDQUFDO1lBQ0gsQ0FBQyxDQUFDO1lBRUosSUFBSXlCLHFCQU9ILEdBQUc7Y0FBRUMsVUFBVSxFQUFFO1lBQUcsQ0FBQztZQUV0QixJQUFJUCxVQUFVLENBQUNRLE1BQU0sR0FBRyxDQUFDLEVBQUU7Y0FDekJSLFVBQVUsQ0FBQ1MsT0FBTyxDQUFFckMsSUFBd0IsSUFDMUNrQyxxQkFBcUIsQ0FBQ0MsVUFBVSxDQUFDRyxJQUFJLENBQUMsR0FBR3RDLElBQUksQ0FBQ21DLFVBQVUsQ0FDMUQsQ0FBQztZQUNIO1lBRUEsSUFBSVAsVUFBVSxDQUFDUSxNQUFNLEtBQUssQ0FBQyxJQUFJUixVQUFVLENBQUMsQ0FBQyxDQUFDLENBQUNXLFFBQVEsRUFBRTtjQUNyREwscUJBQXFCLEdBQUdOLFVBQVUsQ0FBQyxDQUFDLENBQUM7WUFDdkM7WUFFQSxNQUFNO2NBQUVPO1lBQVcsQ0FBQyxHQUFHRCxxQkFBcUI7WUFFNUMsTUFBTU0sSUFBSSxHQUFHTCxVQUFVLENBQ3BCaEIsR0FBRyxDQUFDc0IsUUFBUSxJQUFLLEdBQUVwQixVQUFXLEtBQUlDLElBQUksQ0FBQ0MsU0FBUyxDQUFDa0IsUUFBUSxDQUFFLElBQUcsQ0FBQyxDQUMvREMsSUFBSSxDQUFDLEVBQUUsQ0FBQzs7WUFFWDs7WUFFQTtZQUNBLE1BQU1DLGlCQUFpQixHQUNyQixNQUFNbEMsT0FBTyxDQUFDbUMsSUFBSSxDQUFDQyxVQUFVLENBQUNDLE1BQU0sQ0FBQ0MsYUFBYSxDQUFDQyxPQUFPLENBQUNDLE1BQU0sQ0FDL0Q7Y0FDRXpCLEtBQUssRUFBRUo7WUFDVCxDQUNGLENBQUM7WUFDSCxJQUFJdUIsaUJBQWlCLENBQUNoQixJQUFJLEtBQUssS0FBSyxFQUFFO2NBQUEsSUFBQXVCLHFCQUFBO2NBQ3BDO2NBQ0EsSUFBSUMsYUFBYTtjQUVqQixLQUFBRCxxQkFBQSxHQUFJaEIscUJBQXFCLGNBQUFnQixxQkFBQSxlQUFyQkEscUJBQUEsQ0FBdUJYLFFBQVEsRUFBRTtnQkFDbkNZLGFBQWEsR0FBR2pCLHFCQUFxQixDQUFDSyxRQUFRLENBQUNBLFFBQVE7Z0JBRXZELE9BQU9ZLGFBQWEsQ0FBQ0MsY0FBYztnQkFDbkMsT0FBT0QsYUFBYSxDQUFDRSxRQUFRO2dCQUU3QkYsYUFBYSxDQUFDRyxRQUFRLENBQUM5QixLQUFLLENBQUMrQixnQkFBZ0IsR0FDM0NDLDJDQUFnQztnQkFDbENMLGFBQWEsQ0FBQ0csUUFBUSxDQUFDOUIsS0FBSyxDQUFDaUMsa0JBQWtCLEdBQzdDQyw2Q0FBa0M7Y0FDdEMsQ0FBQyxNQUFNO2dCQUNMUCxhQUFhLEdBQUc7a0JBQ2RHLFFBQVEsRUFBRTtvQkFDUjlCLEtBQUssRUFBRTtzQkFDTCtCLGdCQUFnQixFQUFFQywyQ0FBZ0M7c0JBQ2xEQyxrQkFBa0IsRUFBRUM7b0JBQ3RCO2tCQUNGO2dCQUNGLENBQUM7Y0FDSDtjQUVBLE1BQU1qRCxPQUFPLENBQUNtQyxJQUFJLENBQUNDLFVBQVUsQ0FBQ0MsTUFBTSxDQUFDQyxhQUFhLENBQUNDLE9BQU8sQ0FBQ1csTUFBTSxDQUMvRDtnQkFDRW5DLEtBQUssRUFBRUosU0FBUztnQkFDaEJPLElBQUksRUFBRXdCO2NBQ1IsQ0FDRixDQUFDO2NBQ0QxQyxPQUFPLENBQUNtRCxLQUFLLENBQUNDLE1BQU0sQ0FBQ0MsSUFBSSxDQUFFLFNBQVExQyxTQUFVLFVBQVMsQ0FBQztZQUN6RDtZQUVBLE1BQU1YLE9BQU8sQ0FBQ21DLElBQUksQ0FBQ0MsVUFBVSxDQUFDQyxNQUFNLENBQUNDLGFBQWEsQ0FBQ1AsSUFBSSxDQUFDO2NBQ3REaEIsS0FBSyxFQUFFSixTQUFTO2NBQ2hCTyxJQUFJLEVBQUVhO1lBQ1IsQ0FBQyxDQUFDO1lBRUYvQixPQUFPLENBQUNtRCxLQUFLLENBQUNDLE1BQU0sQ0FBQ0MsSUFBSSxDQUN0Qix3QkFBdUIxQyxTQUFVLFFBQ3BDLENBQUM7WUFFREosdUJBQXVCLENBQUNzQixJQUFJLENBQUM7Y0FDM0JkLEtBQUssRUFBRUosU0FBUztjQUNoQjJDLGVBQWUsRUFBRTVCLFVBQVUsQ0FBQ0M7WUFDOUIsQ0FBQyxDQUFDO1VBQ0osQ0FBQyxDQUFDLE9BQU80QixLQUFLLEVBQUU7WUFDZHZELE9BQU8sQ0FBQ21ELEtBQUssQ0FBQ0MsTUFBTSxDQUFDRyxLQUFLLENBQ3ZCLCtCQUE4QjVDLFNBQVUsV0FDdkM0QyxLQUFLLENBQUNDLE9BQU8sSUFBSUQsS0FDbEIsRUFDSCxDQUFDO1lBRUQsTUFBTSxDQUFDRSxVQUFVLEVBQUVDLFlBQVksQ0FBQyxHQUFHLElBQUksQ0FBQ0MsZUFBZSxDQUFDSixLQUFLLENBQUM7WUFDOUQsTUFBTTtjQUFFRSxVQUFVO2NBQUVDO1lBQWEsQ0FBQztVQUNwQztRQUNGLENBQUMsQ0FDSCxDQUFDOztRQUVEO1FBQ0EsT0FBT3hELFFBQVEsQ0FBQzBELEVBQUUsQ0FBQztVQUNqQjFDLElBQUksRUFBRTtZQUFFWDtVQUF3QjtRQUNsQyxDQUFDLENBQUM7TUFDSixDQUFDLENBQUMsT0FBT2dELEtBQUssRUFBRTtRQUNkLE1BQU1FLFVBQVUsR0FDZCxDQUFBRixLQUFLLGFBQUxBLEtBQUssdUJBQUxBLEtBQUssQ0FBRUUsVUFBVSxLQUFJSSw0QkFBaUIsQ0FBQ0MscUJBQXFCO1FBQzlELE1BQU1KLFlBQVksR0FBRyxDQUFBSCxLQUFLLGFBQUxBLEtBQUssdUJBQUxBLEtBQUssQ0FBRUcsWUFBWSxLQUFJSCxLQUFLLENBQUNDLE9BQU8sSUFBSUQsS0FBSztRQUNsRSxPQUFPLElBQUFRLDRCQUFhLEVBQ2xCTCxZQUFZLEVBQ1pNLGlDQUFrQixDQUFDQyxPQUFPLEVBQzFCUixVQUFVLEVBQ1Z2RCxRQUNGLENBQUM7TUFDSDtJQUNGLENBQ0YsQ0FBQztJQUNEO0FBQ0Y7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0lBTkVuQyxlQUFBLDJCQU9tQixJQUFBZ0MsZ0RBQW9DLEVBQ3JEaUUsaUNBQWtCLENBQUNDLE9BQ3JCLENBQUMsQ0FDQyxPQUNFakUsT0FBOEIsRUFDOUJDLE9BQTBELEVBQzFEQyxRQUE2QyxLQUMxQztNQUNILElBQUk7UUFDRjtRQUNBLE1BQU1nRSx5QkFBeUIsR0FBRyxNQUFNLElBQUksQ0FBQzlELDBCQUEwQixDQUNyRUosT0FBTyxFQUNQQyxPQUFPLENBQUNJLE1BQU0sQ0FBQ0MsUUFDakIsQ0FBQzs7UUFFRDtRQUNBLE1BQU02RCxlQUFlLEdBQUdELHlCQUF5QixDQUFDeEQsR0FBRyxDQUNuRCxDQUFDO1VBQUVDO1FBQVUsQ0FBQyxLQUFLQSxTQUNyQixDQUFDO1FBRUQsSUFBSSxDQUFDd0QsZUFBZSxDQUFDeEMsTUFBTSxFQUFFO1VBQzNCLE9BQU8sSUFBQW9DLDRCQUFhLEVBQ2pCLGlDQUFnQzlELE9BQU8sQ0FBQ0ksTUFBTSxDQUFDQyxRQUFTLEVBQUMsRUFDMUQsSUFBSSxFQUNKLEdBQUcsRUFDSEosUUFDRixDQUFDO1FBQ0g7O1FBRUE7UUFDQTtRQUNBLE1BQU1rRSxPQUFPLEdBQUcsTUFBTTVELE9BQU8sQ0FBQ0MsR0FBRyxDQUMvQjBELGVBQWUsQ0FBQ3pELEdBQUcsQ0FBQyxNQUFNSyxLQUFLLElBQUk7VUFDakMsSUFBSTtZQUNGO1lBQ0EsTUFBTW1CLGlCQUFpQixHQUNyQixNQUFNbEMsT0FBTyxDQUFDbUMsSUFBSSxDQUFDQyxVQUFVLENBQUNDLE1BQU0sQ0FBQ0MsYUFBYSxDQUFDQyxPQUFPLENBQUNDLE1BQU0sQ0FDL0Q7Y0FDRXpCO1lBQ0YsQ0FDRixDQUFDO1lBRUgsSUFBSW1CLGlCQUFpQixDQUFDaEIsSUFBSSxFQUFFO2NBQzFCO2NBQ0EsTUFBTWxCLE9BQU8sQ0FBQ21DLElBQUksQ0FBQ0MsVUFBVSxDQUFDQyxNQUFNLENBQUNDLGFBQWEsQ0FBQ0MsT0FBTyxDQUFDOEIsTUFBTSxDQUMvRDtnQkFDRXRELEtBQUssRUFBRSxDQUFDQSxLQUFLO2NBQ2YsQ0FDRixDQUFDO2NBQ0RmLE9BQU8sQ0FBQ21ELEtBQUssQ0FBQ0MsTUFBTSxDQUFDQyxJQUFJLENBQUUsV0FBVXRDLEtBQU0sUUFBTyxDQUFDO2NBQ25ELE9BQU87Z0JBQUV1RCxPQUFPLEVBQUUsSUFBSTtnQkFBRXZELEtBQUs7Z0JBQUV5QyxPQUFPLEVBQUU7Y0FBVSxDQUFDO1lBQ3JELENBQUMsTUFBTTtjQUNMLE9BQU87Z0JBQ0xjLE9BQU8sRUFBRSxLQUFLO2dCQUNkdkQsS0FBSztnQkFDTHlDLE9BQU8sRUFBRztjQUNaLENBQUM7WUFDSDtVQUNGLENBQUMsQ0FBQyxPQUFPRCxLQUFLLEVBQUU7WUFDZHZELE9BQU8sQ0FBQ21ELEtBQUssQ0FBQ0MsTUFBTSxDQUFDRyxLQUFLLENBQ3ZCLGlDQUFnQ3hDLEtBQU0sV0FDckN3QyxLQUFLLENBQUNDLE9BQU8sSUFBSUQsS0FDbEIsRUFDSCxDQUFDO1lBQ0QsTUFBTSxDQUFDRSxVQUFVLEVBQUVDLFlBQVksQ0FBQyxHQUFHLElBQUksQ0FBQ0MsZUFBZSxDQUFDSixLQUFLLENBQUM7WUFDOUQsT0FBTztjQUNMZSxPQUFPLEVBQUUsS0FBSztjQUNkdkQsS0FBSztjQUNMeUMsT0FBTyxFQUFFRSxZQUFZLElBQUlILEtBQUs7Y0FDOUJFO1lBQ0YsQ0FBQztVQUNIO1FBQ0YsQ0FBQyxDQUNILENBQUM7O1FBRUQ7UUFDQSxNQUFNYyxjQUFjLEdBQUdILE9BQU8sQ0FBQzlFLE1BQU0sQ0FBQ2tGLE1BQU0sSUFBSUEsTUFBTSxDQUFDRixPQUFPLENBQUM7UUFDL0QsTUFBTUcsYUFBYSxHQUFHTCxPQUFPLENBQUM5RSxNQUFNLENBQUNrRixNQUFNLElBQUksQ0FBQ0EsTUFBTSxDQUFDRixPQUFPLENBQUM7UUFFL0QsSUFBSUMsY0FBYyxDQUFDNUMsTUFBTSxHQUFHLENBQUMsRUFBRTtVQUM3QjNCLE9BQU8sQ0FBQ21ELEtBQUssQ0FBQ0MsTUFBTSxDQUFDQyxJQUFJLENBQ3RCLFdBQVVrQixjQUFjLENBQUM1QyxNQUFPLGFBQVk0QyxjQUFjLENBQ3hEN0QsR0FBRyxDQUFDekMsQ0FBQyxJQUFJQSxDQUFDLENBQUM4QyxLQUFLLENBQUMsQ0FDakJrQixJQUFJLENBQUMsSUFBSSxDQUFFLEVBQ2hCLENBQUM7VUFDRCxJQUFJd0MsYUFBYSxDQUFDOUMsTUFBTSxHQUFHLENBQUMsRUFBRTtZQUM1QjNCLE9BQU8sQ0FBQ21ELEtBQUssQ0FBQ0MsTUFBTSxDQUFDRyxLQUFLLENBQ3ZCLG9CQUFtQmtCLGFBQWEsQ0FBQzlDLE1BQU8sYUFBWThDLGFBQWEsQ0FDL0QvRCxHQUFHLENBQUN6QyxDQUFDLElBQUlBLENBQUMsQ0FBQzhDLEtBQUssQ0FBQyxDQUNqQmtCLElBQUksQ0FBQyxJQUFJLENBQUUsRUFDaEIsQ0FBQztVQUNIO1VBRUEsT0FBTy9CLFFBQVEsQ0FBQzBELEVBQUUsQ0FBQztZQUNqQjFDLElBQUksRUFBRTtjQUNKc0QsTUFBTSxFQUFFLFNBQVM7Y0FDakJFLFlBQVksRUFBRUgsY0FBYyxDQUFDNUMsTUFBTTtjQUNuQ2dELFdBQVcsRUFBRUYsYUFBYSxDQUFDOUMsTUFBTTtjQUNqQ1ksT0FBTyxFQUFFZ0MsY0FBYyxDQUFDN0QsR0FBRyxDQUFDekMsQ0FBQyxJQUFJQSxDQUFDLENBQUM4QyxLQUFLLENBQUM7Y0FDekM2RCxNQUFNLEVBQUVILGFBQWEsQ0FBQzlDLE1BQU0sR0FBRzhDLGFBQWEsR0FBR0k7WUFDakQ7VUFDRixDQUFDLENBQUM7UUFDSixDQUFDLE1BQU07VUFDTCxNQUFNQyxVQUFVLEdBQUdMLGFBQWEsQ0FBQyxDQUFDLENBQUM7VUFDbkMsT0FBTyxJQUFBViw0QkFBYSxFQUNqQiw2QkFBNEJlLFVBQVUsQ0FBQ3RCLE9BQVEsRUFBQyxFQUNqRCxJQUFJLEVBQ0pzQixVQUFVLENBQUNyQixVQUFVLElBQUksR0FBRyxFQUM1QnZELFFBQ0YsQ0FBQztRQUNIO01BQ0YsQ0FBQyxDQUFDLE9BQU9xRCxLQUFLLEVBQUU7UUFDZHZELE9BQU8sQ0FBQ21ELEtBQUssQ0FBQ0MsTUFBTSxDQUFDRyxLQUFLLENBQ3ZCLCtCQUE4QkEsS0FBSyxDQUFDQyxPQUFPLElBQUlELEtBQU0sRUFDeEQsQ0FBQztRQUNELE1BQU0sQ0FBQ0UsVUFBVSxFQUFFQyxZQUFZLENBQUMsR0FBRyxJQUFJLENBQUNDLGVBQWUsQ0FBQ0osS0FBSyxDQUFDO1FBQzlELE9BQU8sSUFBQVEsNEJBQWEsRUFBQ0wsWUFBWSxJQUFJSCxLQUFLLEVBQUUsSUFBSSxFQUFFRSxVQUFVLEVBQUV2RCxRQUFRLENBQUM7TUFDekU7SUFDRixDQUNGLENBQUM7RUFubUJjOztFQUVmO0FBQ0Y7QUFDQTtBQUNBO0VBQ0UsTUFBTUUsMEJBQTBCQSxDQUM5QkosT0FBOEIsRUFDOUJNLFFBQWdCLEVBQ21DO0lBQ25ELE1BQU15RSxVQUFVLEdBQUcsTUFBTXZFLE9BQU8sQ0FBQ0MsR0FBRyxDQUNsQ1csaURBQXNDLENBQUNkLFFBQVEsQ0FBQyxDQUFDSSxHQUFHLENBQUMsTUFBTW5CLElBQUksS0FBSztNQUNsRW9CLFNBQVMsRUFBRyxHQUNWcEIsSUFBSSxDQUFDRSxtQkFBbUIsR0FDcEIsTUFBTU8sT0FBTyxDQUFDZ0YsVUFBVSxDQUFDdEMsYUFBYSxDQUFDdUMsR0FBRyxDQUN4QzFGLElBQUksQ0FBQ0UsbUJBQ1AsQ0FBQyxHQUNERixJQUFJLENBQUMyRixrQkFDVixVQUFTNUUsUUFBUyxFQUFDO01BQ3BCWixPQUFPLEVBQUVILElBQUksYUFBSkEsSUFBSSx1QkFBSkEsSUFBSSxDQUFFRztJQUNqQixDQUFDLENBQUMsQ0FDSixDQUFDO0lBQ0QsT0FBT1Isa0NBQWtDLENBQUM2RixVQUFVLENBQUM7RUFDdkQ7O0VBRUE7QUFDRjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7RUFDRSxNQUFNSSxXQUFXQSxDQUNmbkYsT0FBOEIsRUFDOUJDLE9BQXlELEVBQ3pEQyxRQUE2QyxFQUM3QztJQUNBLElBQUk7TUFDRixNQUFNa0YsSUFBSSxHQUNSLE1BQU1wRixPQUFPLENBQUNtQyxJQUFJLENBQUNDLFVBQVUsQ0FBQ0MsTUFBTSxDQUFDZ0QsY0FBYyxDQUFDQyxHQUFHLENBQUNDLFNBQVMsQ0FBQyxDQUFDO01BRXJFLE1BQU1BLFNBQVMsR0FBR0gsSUFBSSxDQUFDbEUsSUFBSTtNQUMzQixJQUFJLENBQUNxRSxTQUFTLElBQUksT0FBT0EsU0FBUyxLQUFLLFFBQVEsRUFBRTtRQUMvQyxNQUFNLElBQUlDLEtBQUssQ0FDWiwwREFBeURDLDZCQUFtQixFQUMvRSxDQUFDO01BQ0g7TUFFQSxNQUFNQyxRQUFRLEdBQ1p6RixPQUFPLENBQUNJLE1BQU0sQ0FBQ3NGLE9BQU8sQ0FBQzFGLE9BQU8sQ0FBQ0ksTUFBTSxDQUFDc0YsT0FBTyxDQUFDaEUsTUFBTSxHQUFHLENBQUMsQ0FBQzs7TUFFM0Q7TUFDQSxNQUFNaUUsT0FBTyxHQUFHTCxTQUFTLENBQUNNLEtBQUssQ0FBQyxTQUFTLENBQUM7TUFDMUMsTUFBTUMsUUFBUSxHQUFHLEVBQUU7TUFDbkIsS0FBSyxJQUFJdkcsSUFBSSxJQUFJcUcsT0FBTyxFQUFFO1FBQ3hCO1FBQ0EsSUFBSXJHLElBQUksQ0FBQ3dHLFFBQVEsQ0FBQyxHQUFHLENBQUMsRUFBRTtVQUN0QnhHLElBQUksR0FBR0EsSUFBSSxDQUFDeUcsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDQyxLQUFLLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDO1VBQ2xDLE1BQU1DLFFBQVEsR0FBRzNHLElBQUksQ0FBQzRHLEtBQUssQ0FBQyxHQUFHLENBQUM7VUFDaEMsS0FBSyxNQUFNQyxPQUFPLElBQUlGLFFBQVEsRUFBRTtZQUM5QkosUUFBUSxDQUFDakUsSUFBSSxDQUFFLElBQUd1RSxPQUFPLENBQUNDLElBQUksQ0FBQyxDQUFFLEdBQUUsQ0FBQztVQUN0QztRQUNGLENBQUMsTUFBTTtVQUNMUCxRQUFRLENBQUNqRSxJQUFJLENBQUN0QyxJQUFJLENBQUM7UUFDckI7TUFDRjs7TUFFQTtNQUNBLE1BQU1KLEtBQUssR0FBRzJHLFFBQVEsQ0FBQ3hHLE1BQU0sQ0FDM0JDLElBQUksSUFBSUEsSUFBSSxDQUFDd0csUUFBUSxDQUFDLEdBQUcsQ0FBQyxJQUFJeEcsSUFBSSxDQUFDd0csUUFBUSxDQUFDLEdBQUcsQ0FDakQsQ0FBQztNQUVELE1BQU1KLE9BQU8sR0FDWEQsUUFBUSxLQUFLLEdBQUcsR0FDWnpGLE9BQU8sQ0FBQ0ksTUFBTSxDQUFDc0YsT0FBTyxDQUFDTSxLQUFLLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLEdBQ25DaEcsT0FBTyxDQUFDSSxNQUFNLENBQUNzRixPQUFPO01BQzVCLE1BQU1XLFVBQVUsR0FBR25ILEtBQUssQ0FBQ0csTUFBTSxDQUFDQyxJQUFJLElBQUk7UUFDdENBLElBQUksR0FBR0EsSUFBSSxDQUFDMEcsS0FBSyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQztRQUN4QixNQUFNUCxRQUFRLEdBQUduRyxJQUFJLENBQUNBLElBQUksQ0FBQ29DLE1BQU0sR0FBRyxDQUFDLENBQUM7UUFDdENwQyxJQUFJLEdBQUdtRyxRQUFRLEtBQUssR0FBRyxHQUFHbkcsSUFBSSxDQUFDMEcsS0FBSyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxHQUFHMUcsSUFBSTtRQUNsRCxPQUFPQSxJQUFJLENBQUN3RyxRQUFRLENBQUNKLE9BQU8sQ0FBQyxJQUFJQSxPQUFPLENBQUNJLFFBQVEsQ0FBQ3hHLElBQUksQ0FBQztNQUN6RCxDQUFDLENBQUM7TUFDRlMsT0FBTyxDQUFDbUQsS0FBSyxDQUFDQyxNQUFNLENBQUNtRCxLQUFLLENBQ3ZCLHNCQUNDRCxVQUFVLElBQUlFLEtBQUssQ0FBQ0MsT0FBTyxDQUFDSCxVQUFVLENBQUMsSUFBSUEsVUFBVSxDQUFDM0UsTUFBTSxHQUN4RCxLQUFLLEdBQ0wsSUFDTCxFQUNILENBQUM7TUFDRCxPQUFPMkUsVUFBVSxJQUFJRSxLQUFLLENBQUNDLE9BQU8sQ0FBQ0gsVUFBVSxDQUFDLElBQUlBLFVBQVUsQ0FBQzNFLE1BQU0sR0FDL0R6QixRQUFRLENBQUMwRCxFQUFFLENBQUM7UUFDVjFDLElBQUksRUFBRTtVQUNKdUMsVUFBVSxFQUFFLEdBQUc7VUFDZmlELE1BQU0sRUFBRSxJQUFJO1VBQ1p0QixJQUFJLEVBQUcsc0JBQXFCbkYsT0FBTyxDQUFDSSxNQUFNLENBQUNzRixPQUFRO1FBQ3JEO01BQ0YsQ0FBQyxDQUFDLEdBQ0Z6RixRQUFRLENBQUMwRCxFQUFFLENBQUM7UUFDVjFDLElBQUksRUFBRTtVQUNKdUMsVUFBVSxFQUFFLEdBQUc7VUFDZmlELE1BQU0sRUFBRSxLQUFLO1VBQ2J0QixJQUFJLEVBQUcseUJBQXdCbkYsT0FBTyxDQUFDSSxNQUFNLENBQUNzRixPQUFRO1FBQ3hEO01BQ0YsQ0FBQyxDQUFDO0lBQ1IsQ0FBQyxDQUFDLE9BQU9wQyxLQUFLLEVBQUU7TUFDZHZELE9BQU8sQ0FBQ21ELEtBQUssQ0FBQ0MsTUFBTSxDQUFDRyxLQUFLLENBQUNBLEtBQUssQ0FBQ0MsT0FBTyxJQUFJRCxLQUFLLENBQUM7TUFDbEQsT0FBTyxJQUFBUSw0QkFBYSxFQUNqQixxQ0FBb0MwQiw2QkFBbUIsV0FDdERsQyxLQUFLLENBQUNDLE9BQU8sSUFBSUQsS0FDbEIsRUFBQyxFQUNGLElBQUksRUFDSixHQUFHLEVBQ0hyRCxRQUNGLENBQUM7SUFDSDtFQUNGOztFQUVBO0FBQ0Y7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztFQUVFO0FBQ0Y7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0VBQ0UsTUFBTXlHLFdBQVdBLENBQ2YzRyxPQUE4QixFQUM5QkMsT0FHQyxFQUNEQyxRQUE2QyxFQUM3QztJQUNBLElBQUk7TUFDRjtNQUNBLElBQUkwRyxPQUFPLEdBQUc7UUFDWkMsSUFBSSxFQUFFLENBQUM7UUFDUEMsS0FBSyxFQUFFO1VBQ0xDLElBQUksRUFBRTtZQUNKQyxJQUFJLEVBQUUsRUFBRTtZQUNSQyxRQUFRLEVBQUU7Y0FDUkMsSUFBSSxFQUFFO2dCQUNKLFVBQVUsRUFBRTtjQUNkO1lBQ0YsQ0FBQztZQUNENUgsTUFBTSxFQUFFLENBQ047Y0FDRTZILEtBQUssRUFBRTtnQkFBRUMsU0FBUyxFQUFFLENBQUM7Y0FBRTtZQUN6QixDQUFDO1VBRUw7UUFDRixDQUFDO1FBQ0RDLElBQUksRUFBRTtVQUNKLEdBQUcsRUFBRTtZQUNIQyxLQUFLLEVBQUU7Y0FDTEMsS0FBSyxFQUFFLEVBQUU7Y0FDVFYsSUFBSSxFQUFFLENBQUM7Y0FDUFcsS0FBSyxFQUFFO2dCQUFFQyxNQUFNLEVBQUU7Y0FBTztZQUMxQjtVQUNGO1FBQ0Y7TUFDRixDQUFDOztNQUVEO01BQ0EsTUFBTUMsT0FBTyxHQUFHLFFBQVE7TUFDeEIsTUFBTUMsTUFBTSxHQUFHLEtBQUs7TUFDcEJmLE9BQU8sQ0FBQ0UsS0FBSyxDQUFDQyxJQUFJLENBQUN6SCxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUM2SCxLQUFLLENBQUMsV0FBVyxDQUFDLENBQUMsS0FBSyxDQUFDLEdBQUdPLE9BQU87TUFDaEVkLE9BQU8sQ0FBQ0UsS0FBSyxDQUFDQyxJQUFJLENBQUN6SCxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUM2SCxLQUFLLENBQUMsV0FBVyxDQUFDLENBQUMsSUFBSSxDQUFDLEdBQUdRLE1BQU07O01BRTlEO01BQ0FmLE9BQU8sQ0FBQ0UsS0FBSyxDQUFDQyxJQUFJLENBQUNDLElBQUksQ0FBQ25GLElBQUksQ0FDMUI1QixPQUFPLENBQUNJLE1BQU0sQ0FBQ3VILElBQUksS0FBSyxTQUFTLEdBQzdCO1FBQUUvQixLQUFLLEVBQUU7VUFBRSxjQUFjLEVBQUU1RixPQUFPLENBQUNJLE1BQU0sQ0FBQ3dIO1FBQVE7TUFBRSxDQUFDLEdBQ3JEO1FBQUVoQyxLQUFLLEVBQUU7VUFBRSxjQUFjLEVBQUU1RixPQUFPLENBQUNJLE1BQU0sQ0FBQ3dIO1FBQVE7TUFBRSxDQUMxRCxDQUFDO01BRUQsSUFBSTVILE9BQU8sQ0FBQzZHLEtBQUssQ0FBQ2dCLFVBQVUsRUFDMUJsQixPQUFPLENBQUNFLEtBQUssQ0FBQ0MsSUFBSSxDQUFDekgsTUFBTSxDQUFDdUMsSUFBSSxDQUFDO1FBQzdCeUYsS0FBSyxFQUFFO1VBQ0wsVUFBVSxFQUFFckgsT0FBTyxDQUFDNkcsS0FBSyxDQUFDZ0IsVUFBVSxDQUFDM0IsS0FBSyxDQUFDLEdBQUc7UUFDaEQ7TUFDRixDQUFDLENBQUM7TUFDSlMsT0FBTyxDQUFDUyxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUNDLEtBQUssQ0FBQ0MsS0FBSyxHQUFHdEgsT0FBTyxDQUFDSSxNQUFNLENBQUNrSCxLQUFLO01BRXBELE1BQU1uQyxJQUFJLEdBQUcsTUFBTXBGLE9BQU8sQ0FBQ21DLElBQUksQ0FBQ0MsVUFBVSxDQUFDQyxNQUFNLENBQUNDLGFBQWEsQ0FBQ3lGLE1BQU0sQ0FBQztRQUNyRWxCLElBQUksRUFBRSxDQUFDO1FBQ1A5RixLQUFLLEVBQUVkLE9BQU8sQ0FBQ0ksTUFBTSxDQUFDc0YsT0FBTztRQUM3QnpFLElBQUksRUFBRTBGO01BQ1IsQ0FBQyxDQUFDO01BRUYsT0FBT3hCLElBQUksQ0FBQ2xFLElBQUksQ0FBQzhHLElBQUksQ0FBQ0MsS0FBSyxDQUFDM0osS0FBSyxLQUFLLENBQUMsSUFDckMsT0FBTzhHLElBQUksQ0FBQ2xFLElBQUksQ0FBQ2dILFlBQVksQ0FBQyxHQUFHLENBQUMsQ0FBQ0MsT0FBTyxDQUFDLENBQUMsQ0FBQyxLQUFLLFdBQVcsR0FDM0RqSSxRQUFRLENBQUMwRCxFQUFFLENBQUM7UUFDVjFDLElBQUksRUFBRTtVQUFFdUMsVUFBVSxFQUFFLEdBQUc7VUFBRTJCLElBQUksRUFBRTtRQUFHO01BQ3BDLENBQUMsQ0FBQyxHQUNGbEYsUUFBUSxDQUFDMEQsRUFBRSxDQUFDO1FBQ1YxQyxJQUFJLEVBQUU7VUFDSnVDLFVBQVUsRUFBRSxHQUFHO1VBQ2YyQixJQUFJLEVBQUVBLElBQUksQ0FBQ2xFLElBQUksQ0FBQ2dILFlBQVksQ0FBQyxHQUFHLENBQUMsQ0FBQ0MsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDM0k7UUFDL0M7TUFDRixDQUFDLENBQUM7SUFDUixDQUFDLENBQUMsT0FBTytELEtBQUssRUFBRTtNQUNkdkQsT0FBTyxDQUFDbUQsS0FBSyxDQUFDQyxNQUFNLENBQUNHLEtBQUssQ0FBQ0EsS0FBSyxDQUFDQyxPQUFPLElBQUlELEtBQUssQ0FBQztNQUNsRCxPQUFPLElBQUFRLDRCQUFhLEVBQUNSLEtBQUssQ0FBQ0MsT0FBTyxJQUFJRCxLQUFLLEVBQUUsSUFBSSxFQUFFLEdBQUcsRUFBRXJELFFBQVEsQ0FBQztJQUNuRTtFQUNGOztFQUVBO0FBQ0Y7QUFDQTtBQUNBO0VBQ0VrSSxvQkFBb0JBLENBQUNDLGdCQUFnQixFQUFFO0lBQ3JDLE1BQU1DLE9BQU8sR0FBRyxDQUFDLFdBQVcsRUFBRSxhQUFhLEVBQUUsY0FBYyxFQUFFLFVBQVUsQ0FBQztJQUN4RSxJQUFJQyxJQUFJLEdBQUcsRUFBRTtJQUNiLEtBQUssTUFBTXhILEtBQUssSUFBSXNILGdCQUFnQixFQUFFO01BQ3BDLElBQUlHLEtBQUssRUFBRUMsTUFBTTtNQUNqQixJQUFJO1FBQ0ZBLE1BQU0sR0FBRzVILElBQUksQ0FBQzZILEtBQUssQ0FBQzNILEtBQUssQ0FBQzRILFVBQVUsQ0FBQ0MsTUFBTSxDQUFDO01BQzlDLENBQUMsQ0FBQyxPQUFPckYsS0FBSyxFQUFFO1FBQ2Q7TUFDRjtNQUVBaUYsS0FBSyxHQUFHQyxNQUFNLENBQUNuSixNQUFNLENBQUNDLElBQUksSUFBSStJLE9BQU8sQ0FBQ3ZDLFFBQVEsQ0FBQ3hHLElBQUksQ0FBQ3NKLElBQUksQ0FBQyxDQUFDO01BQzFELElBQUlMLEtBQUssQ0FBQzdHLE1BQU0sS0FBSyxDQUFDLEVBQUU7UUFDdEI0RyxJQUFJLENBQUMxRyxJQUFJLENBQUM7VUFDUmlILEVBQUUsRUFBRS9ILEtBQUssQ0FBQytILEVBQUU7VUFDWkMsS0FBSyxFQUFFaEksS0FBSyxDQUFDNEgsVUFBVSxDQUFDSTtRQUMxQixDQUFDLENBQUM7TUFDSjtJQUNGO0lBQ0EsT0FBT1IsSUFBSTtFQUNiOztFQUVBO0FBQ0Y7QUFDQTtBQUNBO0FBQ0E7QUFDQTtFQUNFLE1BQU1TLGtCQUFrQkEsQ0FDdEJoSixPQUE4QixFQUM5QkMsT0FBc0QsRUFDdERDLFFBQTZDLEVBQzdDO0lBQ0EsSUFBSTtNQUNGLE9BQU9BLFFBQVEsQ0FBQzBELEVBQUUsQ0FBQztRQUNqQjFDLElBQUksRUFBRTtVQUNKK0gsUUFBUSxFQUFFakosT0FBTyxDQUFDbUQsS0FBSyxDQUFDK0YsUUFBUSxDQUFDRDtRQUNuQztNQUNGLENBQUMsQ0FBQztJQUNKLENBQUMsQ0FBQyxPQUFPMUYsS0FBSyxFQUFFO01BQ2R2RCxPQUFPLENBQUNtRCxLQUFLLENBQUNDLE1BQU0sQ0FBQ0csS0FBSyxDQUFDQSxLQUFLLENBQUNDLE9BQU8sSUFBSUQsS0FBSyxDQUFDO01BQ2xELE9BQU8sSUFBQVEsNEJBQWEsRUFBQ1IsS0FBSyxDQUFDQyxPQUFPLElBQUlELEtBQUssRUFBRSxJQUFJLEVBQUUsR0FBRyxFQUFFckQsUUFBUSxDQUFDO0lBQ25FO0VBQ0Y7O0VBRUE7QUFDRjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtFQUNFLE1BQU1pSix3QkFBd0JBLENBQzVCbkosT0FBOEIsRUFDOUJDLE9BQTBELEVBQzFEQyxRQUE2QyxFQUM3QztJQUNBLElBQUk7TUFDRixNQUFNaUUsZUFBZSxHQUFHLE1BQU0sSUFBSSxDQUFDL0QsMEJBQTBCLENBQzNESixPQUFPLEVBQ1BDLE9BQU8sQ0FBQ0ksTUFBTSxDQUFDQyxRQUNqQixDQUFDO01BQ0Q7TUFDQSxNQUFNNEIsaUJBQWlCLEdBQUcsTUFBTTFCLE9BQU8sQ0FBQ0MsR0FBRyxDQUN6QzBELGVBQWUsQ0FBQ3pELEdBQUcsQ0FBQyxPQUFPO1FBQUVDO01BQVUsQ0FBQyxLQUFLO1FBQzNDLE9BQU8sTUFBTVgsT0FBTyxDQUFDbUMsSUFBSSxDQUFDQyxVQUFVLENBQUNDLE1BQU0sQ0FBQ0MsYUFBYSxDQUFDQyxPQUFPLENBQUNDLE1BQU0sQ0FDdEU7VUFDRXpCLEtBQUssRUFBRUo7UUFDVCxDQUNGLENBQUM7TUFDSCxDQUFDLENBQ0gsQ0FBQztNQUNELE9BQU9ULFFBQVEsQ0FBQzBELEVBQUUsQ0FBQztRQUNqQjFDLElBQUksRUFBRTtVQUNKSCxLQUFLLEVBQUVvRCxlQUFlO1VBQ3RCM0IsTUFBTSxFQUFFTixpQkFBaUIsQ0FBQ2tILElBQUksQ0FBQzVFLE1BQU0sSUFBSUEsTUFBTSxDQUFDdEQsSUFBSTtRQUN0RDtNQUNGLENBQUMsQ0FBQztJQUNKLENBQUMsQ0FBQyxPQUFPcUMsS0FBSyxFQUFFO01BQ2R2RCxPQUFPLENBQUNtRCxLQUFLLENBQUNDLE1BQU0sQ0FBQ0csS0FBSyxDQUN2QixvREFDQ0EsS0FBSyxDQUFDQyxPQUFPLElBQUlELEtBQ2xCLEVBQ0gsQ0FBQztNQUVELE1BQU0sQ0FBQ0UsVUFBVSxFQUFFQyxZQUFZLENBQUMsR0FBRyxJQUFJLENBQUNDLGVBQWUsQ0FBQ0osS0FBSyxDQUFDO01BQzlELE9BQU8sSUFBQVEsNEJBQWEsRUFDakIsb0RBQ0NMLFlBQVksSUFBSUgsS0FDakIsRUFBQyxFQUNGLElBQUksRUFDSkUsVUFBVSxFQUNWdkQsUUFDRixDQUFDO0lBQ0g7RUFDRjtFQTJTQSxNQUFNbUosTUFBTUEsQ0FDVnJKLE9BQThCLEVBQzlCQyxPQUFvQyxFQUNwQ0MsUUFBNkMsRUFDN0M7SUFDQSxJQUFJO01BQ0YsTUFBTWtGLElBQUksR0FBRyxNQUFNcEYsT0FBTyxDQUFDbUMsSUFBSSxDQUFDQyxVQUFVLENBQUNDLE1BQU0sQ0FBQ0MsYUFBYSxDQUFDeUYsTUFBTSxDQUNwRTlILE9BQU8sQ0FBQ2lCLElBQ1YsQ0FBQztNQUNELE9BQU9oQixRQUFRLENBQUMwRCxFQUFFLENBQUM7UUFDakIxQyxJQUFJLEVBQUVrRSxJQUFJLENBQUNsRTtNQUNiLENBQUMsQ0FBQztJQUNKLENBQUMsQ0FBQyxPQUFPcUMsS0FBSyxFQUFFO01BQ2R2RCxPQUFPLENBQUNtRCxLQUFLLENBQUNDLE1BQU0sQ0FBQ0csS0FBSyxDQUFDQSxLQUFLLENBQUNDLE9BQU8sSUFBSUQsS0FBSyxDQUFDO01BQ2xELE9BQU8sSUFBQVEsNEJBQWEsRUFBQ1IsS0FBSyxDQUFDQyxPQUFPLElBQUlELEtBQUssRUFBRSxJQUFJLEVBQUUsR0FBRyxFQUFFckQsUUFBUSxDQUFDO0lBQ25FO0VBQ0Y7RUFFQXlELGVBQWVBLENBQUNKLEtBQUssRUFBRTtJQUFBLElBQUErRixXQUFBO0lBQ3JCLE1BQU03RixVQUFVLEdBQUcsQ0FBQUYsS0FBSyxhQUFMQSxLQUFLLGdCQUFBK0YsV0FBQSxHQUFML0YsS0FBSyxDQUFFZ0csSUFBSSxjQUFBRCxXQUFBLHVCQUFYQSxXQUFBLENBQWE3RixVQUFVLEtBQUksR0FBRztJQUNqRCxJQUFJQyxZQUFZLEdBQUdILEtBQUssQ0FBQ0MsT0FBTztJQUVoQyxJQUFJQyxVQUFVLEtBQUssR0FBRyxFQUFFO01BQUEsSUFBQStGLFlBQUE7TUFDdEI5RixZQUFZLEdBQUcsQ0FBQUgsS0FBSyxhQUFMQSxLQUFLLGdCQUFBaUcsWUFBQSxHQUFMakcsS0FBSyxDQUFFZ0csSUFBSSxjQUFBQyxZQUFBLGdCQUFBQSxZQUFBLEdBQVhBLFlBQUEsQ0FBYXRJLElBQUksY0FBQXNJLFlBQUEsZ0JBQUFBLFlBQUEsR0FBakJBLFlBQUEsQ0FBbUJqRyxLQUFLLGNBQUFpRyxZQUFBLHVCQUF4QkEsWUFBQSxDQUEwQkMsTUFBTSxLQUFJLG1CQUFtQjtJQUN4RTtJQUVBLE9BQU8sQ0FBQ2hHLFVBQVUsRUFBRUMsWUFBWSxDQUFDO0VBQ25DO0FBQ0Y7QUFBQ2dHLE9BQUEsQ0FBQTdKLGdCQUFBLEdBQUFBLGdCQUFBIn0=