"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.WazuhApiCtrl = void 0;
var _errorResponse = require("../lib/error-response");
var _json2Csv = _interopRequireDefault(require("json-2-csv"));
var _csvKeyEquivalence = require("../../common/csv-key-equivalence");
var _apiErrorsEquivalence = require("../lib/api-errors-equivalence");
var _endpoints = _interopRequireDefault(require("../../common/api-info/endpoints"));
var _constants = require("../../common/constants");
var _queue = require("../start/queue");
var _jwtDecode = _interopRequireDefault(require("jwt-decode"));
var _cookie = require("../lib/cookie");
var _package = require("../../package.json");
var _extractErrorMessage = require("../lib/extract-error-message");
function _interopRequireDefault(e) { return e && e.__esModule ? e : { default: e }; }
/*
 * Wazuh app - Class for Wazuh-API functions
 * Copyright (C) 2015-2022 Wazuh, Inc.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * Find more information about this on the LICENSE file.
 */

// Require some libraries

class WazuhApiCtrl {
  constructor() {}
  async getToken(context, request, response) {
    try {
      const {
        force,
        idHost
      } = request.body;
      const {
        username
      } = await context.wazuh.security.getCurrentUser(request, context);
      if (!force && request.headers.cookie && username === decodeURIComponent((0, _cookie.getCookieValueByName)(request.headers.cookie, 'wz-user')) && idHost === (0, _cookie.getCookieValueByName)(request.headers.cookie, 'wz-api')) {
        const wzToken = (0, _cookie.getCookieValueByName)(request.headers.cookie, 'wz-token');
        if (wzToken) {
          try {
            // if the current token is not a valid jwt token we ask for a new one
            const decodedToken = (0, _jwtDecode.default)(wzToken);
            const expirationTime = decodedToken.exp - Date.now() / 1000;
            if (wzToken && expirationTime > 0) {
              return response.ok({
                body: {
                  token: wzToken
                }
              });
            }
          } catch (error) {
            context.wazuh.logger.error(`Error decoding the API host entry token: ${error.message}`);
          }
        }
      }
      const token = await context.wazuh.api.client.asCurrentUser.authenticate(idHost);
      let textSecure = '';
      if (context.wazuh.server.info.protocol === 'https') {
        textSecure = ';Secure';
      }
      const encodedUser = encodeURIComponent(username);
      return response.ok({
        headers: {
          'set-cookie': [`wz-token=${token};Path=/;HttpOnly${textSecure}`, `wz-user=${encodedUser};Path=/;HttpOnly${textSecure}`, `wz-api=${idHost};Path=/;HttpOnly`]
        },
        body: {
          token
        }
      });
    } catch (error) {
      var _error$response;
      const errorMessage = `Error getting the authorization token: ${(0, _extractErrorMessage.extractErrorMessage)(error)}`;
      context.wazuh.logger.error(errorMessage);
      return (0, _errorResponse.ErrorResponse)(errorMessage, 3000, (error === null || error === void 0 || (_error$response = error.response) === null || _error$response === void 0 ? void 0 : _error$response.status) || _constants.HTTP_STATUS_CODES.INTERNAL_SERVER_ERROR, response);
    }
  }

  /**
   * Returns if the wazuh-api configuration is working
   * @param {Object} context
   * @param {Object} request
   * @param {Object} response
   * @returns {Object} status obj or ErrorResponse
   */
  async checkStoredAPI(context, request, response) {
    try {
      // Get config from configuration
      const id = request.body.id;
      context.wazuh.logger.debug(`Getting server API host by ID: ${id}`);
      const apiHostData = await context.wazuh_core.manageHosts.get(id, {
        excludePassword: true
      });
      const api = {
        ...apiHostData
      };
      context.wazuh.logger.debug(`Server API host data: ${JSON.stringify(api)}`);
      context.wazuh.logger.debug(`${id} exists`);

      // Fetch needed information about the cluster and the manager itself
      const responseManagerInfo = await context.wazuh.api.client.asInternalUser.request('get', `/manager/info`, {}, {
        apiHostID: id,
        forceRefresh: true
      });

      // Look for socket-related errors
      if (this.checkResponseIsDown(context, responseManagerInfo)) {
        return (0, _errorResponse.ErrorResponse)(`ERROR3099 - ${responseManagerInfo.data.detail || 'Server not ready yet'}`, 3099, _constants.HTTP_STATUS_CODES.SERVICE_UNAVAILABLE, response);
      }

      // If we have a valid response from the Wazuh API
      try {
        const {
          status,
          manager,
          node,
          cluster
        } = await context.wazuh_core.manageHosts.getRegistryDataByHost(apiHostData, {
          throwError: true
        });
        api.cluster_info = {
          status,
          manager,
          node,
          cluster
        };
        return response.ok({
          body: {
            statusCode: _constants.HTTP_STATUS_CODES.OK,
            data: api,
            idChanged: request.body.idChanged || null
          }
        });
      } catch (error) {
        // If we have an invalid response from the Wazuh API
        throw new Error(responseManagerInfo.data.detail || `${api.url}:${api.port} is unreachable`);
      }
    } catch (error) {
      if (error.code === 'EPROTO') {
        return response.ok({
          body: {
            statusCode: _constants.HTTP_STATUS_CODES.OK,
            data: {
              apiIsDown: true
            }
          }
        });
      } else if (error.code === 'ECONNREFUSED') {
        return response.ok({
          body: {
            statusCode: _constants.HTTP_STATUS_CODES.OK,
            data: {
              apiIsDown: true
            }
          }
        });
      } else {
        var _error$response3;
        try {
          const apis = await context.wazuh_core.manageHosts.get();
          for (const api of apis) {
            try {
              const {
                id
              } = api;
              const responseManagerInfo = await context.wazuh.api.client.asInternalUser.request('GET', `/manager/info`, {}, {
                apiHostID: id
              });
              if (this.checkResponseIsDown(context, responseManagerInfo)) {
                return (0, _errorResponse.ErrorResponse)(`ERROR3099 - ${response.data.detail || 'Server not ready yet'}`, 3099, _constants.HTTP_STATUS_CODES.SERVICE_UNAVAILABLE, response);
              }
              if (responseManagerInfo.status === _constants.HTTP_STATUS_CODES.OK) {
                request.body.id = id;
                request.body.idChanged = id;
                return await this.checkStoredAPI(context, request, response);
              }
            } catch (error) {} // eslint-disable-line
          }
        } catch (error) {
          var _error$response2;
          context.wazuh.logger.error(error.message || error);
          return (0, _errorResponse.ErrorResponse)(error.message || error, 3020, (error === null || error === void 0 || (_error$response2 = error.response) === null || _error$response2 === void 0 ? void 0 : _error$response2.status) || _constants.HTTP_STATUS_CODES.INTERNAL_SERVER_ERROR, response);
        }
        context.wazuh.logger.error(error.message || error);
        return (0, _errorResponse.ErrorResponse)(error.message || error, 3002, (error === null || error === void 0 || (_error$response3 = error.response) === null || _error$response3 === void 0 ? void 0 : _error$response3.status) || _constants.HTTP_STATUS_CODES.INTERNAL_SERVER_ERROR, response);
      }
    }
  }

  /**
   * This perfoms a validation of API params
   * @param {Object} body API params
   */
  validateCheckApiParams(body) {
    if (!('username' in body)) {
      return 'Missing param: API USERNAME';
    }
    if (!('password' in body) && !('id' in body)) {
      return 'Missing param: API PASSWORD';
    }
    if (!('url' in body)) {
      return 'Missing param: API URL';
    }
    if (!('port' in body)) {
      return 'Missing param: API PORT';
    }
    if (!body.url.includes('https://') && !body.url.includes('http://')) {
      return 'protocol_error';
    }
    return false;
  }

  /**
   * This check the wazuh-api configuration received in the POST body will work
   * @param {Object} context
   * @param {Object} request
   * @param {Object} response
   * @returns {Object} status obj or ErrorResponse
   */
  async checkAPI(context, request, response) {
    try {
      let apiAvailable = null;
      // const notValid = this.validateCheckApiParams(request.body);
      // if (notValid) return ErrorResponse(notValid, 3003, HTTP_STATUS_CODES.INTERNAL_SERVER_ERROR, response);
      context.wazuh.logger.debug(`${request.body.id} is valid`);
      // Check if a Wazuh API id is given (already stored API)
      const data = await context.wazuh_core.manageHosts.get(request.body.id, {
        excludePassword: true
      });
      if (data) {
        apiAvailable = data;
      } else {
        const errorMessage = `The server API host entry with ID ${request.body.id} was not found`;
        context.wazuh.logger.debug(errorMessage);
        return (0, _errorResponse.ErrorResponse)(errorMessage, 3029, _constants.HTTP_STATUS_CODES.INTERNAL_SERVER_ERROR, response);
      }
      const options = {
        apiHostID: request.body.id
      };
      if (request.body.forceRefresh) {
        options['forceRefresh'] = request.body.forceRefresh;
      }
      let responseManagerInfo;
      try {
        responseManagerInfo = await context.wazuh.api.client.asInternalUser.request('GET', `/manager/info`, {}, options);
      } catch (error) {
        var _error$response4, _error$response5;
        return (0, _errorResponse.ErrorResponse)(`ERROR3099 - ${((_error$response4 = error.response) === null || _error$response4 === void 0 || (_error$response4 = _error$response4.data) === null || _error$response4 === void 0 ? void 0 : _error$response4.detail) || 'Server not ready yet'}`, 3099, (error === null || error === void 0 || (_error$response5 = error.response) === null || _error$response5 === void 0 ? void 0 : _error$response5.status) || _constants.HTTP_STATUS_CODES.SERVICE_UNAVAILABLE, response);
      }
      context.wazuh.logger.debug(`${request.body.id} credentials are valid`);
      if (responseManagerInfo.status === _constants.HTTP_STATUS_CODES.OK && responseManagerInfo.data) {
        var _responseManagerInfo$;
        // Check if UUID exists in the response
        if ((_responseManagerInfo$ = responseManagerInfo.data) !== null && _responseManagerInfo$ !== void 0 && (_responseManagerInfo$ = _responseManagerInfo$.data) !== null && _responseManagerInfo$ !== void 0 && (_responseManagerInfo$ = _responseManagerInfo$.affected_items) !== null && _responseManagerInfo$ !== void 0 && (_responseManagerInfo$ = _responseManagerInfo$[0]) !== null && _responseManagerInfo$ !== void 0 && _responseManagerInfo$.uuid) {
          const uuid = responseManagerInfo.data.data.affected_items[0].uuid;
          const result = await context.wazuh_core.manageHosts.getRegistryDataByHost(data);
          return response.ok({
            body: {
              ...result,
              uuid
            }
          });
        } else {
          context.wazuh.logger.warn('Could not obtain manager UUID');
          return (0, _errorResponse.ErrorResponse)('Could not obtain manager UUID', null, _constants.HTTP_STATUS_CODES.INTERNAL_SERVER_ERROR, response);
        }
      }
    } catch (error) {
      var _error$response6;
      context.wazuh.logger.warn(error.message || error);
      if (error && error.response && error.response.status === _constants.HTTP_STATUS_CODES.UNAUTHORIZED) {
        return (0, _errorResponse.ErrorResponse)(`Unathorized. Please check API credentials. ${error.response.data.message}`, _constants.HTTP_STATUS_CODES.UNAUTHORIZED, _constants.HTTP_STATUS_CODES.UNAUTHORIZED, response);
      }
      if (error && error.response && error.response.data && error.response.data.detail) {
        return (0, _errorResponse.ErrorResponse)(error.response.data.detail, error.response.status || _constants.HTTP_STATUS_CODES.SERVICE_UNAVAILABLE, error.response.status || _constants.HTTP_STATUS_CODES.SERVICE_UNAVAILABLE, response);
      }
      if (error.code === 'EPROTO') {
        return (0, _errorResponse.ErrorResponse)('Wrong protocol being used to connect to the API', 3005, _constants.HTTP_STATUS_CODES.BAD_REQUEST, response);
      }
      return (0, _errorResponse.ErrorResponse)(error.message || error, 3005, (error === null || error === void 0 || (_error$response6 = error.response) === null || _error$response6 === void 0 ? void 0 : _error$response6.status) || _constants.HTTP_STATUS_CODES.INTERNAL_SERVER_ERROR, response);
    }
  }
  checkResponseIsDown(context, response) {
    if (response.status !== _constants.HTTP_STATUS_CODES.OK) {
      // Avoid "Error communicating with socket" like errors
      const socketErrorCodes = [1013, 1014, 1017, 1018, 1019];
      const status = (response.data || {}).status || 1;
      const isDown = socketErrorCodes.includes(status);
      isDown && context.wazuh.logger.error('Server API is online but the server is not ready yet');
      return isDown;
    }
    return false;
  }

  /**
   * Check main Wazuh daemons status
   * @param {*} context Endpoint context
   * @param {*} api API entry stored in .wazuh
   * @param {*} path Optional. Wazuh API target path.
   */
  async checkDaemons(context, api, path) {
    try {
      const response = await context.wazuh.api.client.asInternalUser.request('GET', '/manager/status', {}, {
        apiHostID: api.id
      });
      const daemons = ((((response || {}).data || {}).data || {}).affected_items || [])[0] || {};
      const isCluster = ((api || {}).cluster_info || {}).status === 'enabled' && typeof daemons['wazuh-clusterd'] !== 'undefined';
      const wazuhdbExists = typeof daemons['wazuh-db'] !== 'undefined';
      const execd = daemons['wazuh-execd'] === 'running';
      const modulesd = daemons['wazuh-modulesd'] === 'running';
      const wazuhdb = wazuhdbExists ? daemons['wazuh-db'] === 'running' : true;
      const clusterd = isCluster ? daemons['wazuh-clusterd'] === 'running' : true;
      const isValid = execd && modulesd && wazuhdb && clusterd;
      isValid && context.wazuh.logger.debug('Wazuh is ready');
      if (path === '/ping') {
        return {
          isValid
        };
      }
      if (!isValid) {
        throw new Error('Server not ready yet');
      }
    } catch (error) {
      context.wazuh.logger.error(error.message || error);
      return Promise.reject(error);
    }
  }
  sleep(timeMs) {
    // eslint-disable-next-line
    return new Promise((resolve, reject) => {
      setTimeout(resolve, timeMs);
    });
  }

  /**
   * This performs a request over Wazuh API and returns its response
   * @param {String} method Method: GET, PUT, POST, DELETE
   * @param {String} path API route
   * @param {Object} data data and params to perform the request
   * @param {String} id API id
   * @param {Object} response
   * @returns {Object} API response or ErrorResponse
   */
  async makeRequest(context, method, path, data, id, response) {
    const devTools = !!(data || {}).devTools;
    try {
      let api;
      try {
        api = await context.wazuh_core.manageHosts.get(id, {
          excludePassword: true
        });
      } catch (error) {
        context.wazuh.logger.error('Could not get host credentials');
        //Can not get credentials from wazuh-hosts
        return (0, _errorResponse.ErrorResponse)('Could not get host credentials', 3011, _constants.HTTP_STATUS_CODES.NOT_FOUND, response);
      }
      if (devTools) {
        delete data.devTools;
      }
      if (!data) {
        data = {};
      }
      if (!data.headers) {
        data.headers = {};
      }
      const options = {
        apiHostID: id
      };

      // Set content type application/xml if needed
      if (typeof (data || {}).body === 'string' && (data || {}).origin === 'xmleditor') {
        data.headers['content-type'] = 'application/xml';
        delete data.origin;
      }
      if (typeof (data || {}).body === 'string' && (data || {}).origin === 'json') {
        data.headers['content-type'] = 'application/json';
        delete data.origin;
      }
      if (typeof (data || {}).body === 'string' && (data || {}).origin === 'raw') {
        data.headers['content-type'] = 'application/octet-stream';
        delete data.origin;
      }
      const delay = (data || {}).delay || 0;
      if (delay) {
        // Remove the delay parameter that is used to add the sever API request to the queue job.
        // This assumes the delay parameter is not used as part of the server API request. If it
        // was expected to do a request with a 'delay' parameter then we would have to search a
        // way to differenciate if the parameter is related to job queue or API request.
        delete data.delay;
        (0, _queue.addJobToQueue)({
          startAt: new Date(Date.now() + delay),
          run: async contextJob => {
            try {
              await context.wazuh.api.client.asCurrentUser.request(method, path, data, options);
            } catch (error) {
              contextJob.wazuh.logger.error(`An error ocurred in the delayed request: "${method} ${path}": ${error.message || error}`);
            }
          }
        });
        return response.ok({
          body: {
            error: 0,
            message: 'Success'
          }
        });
      }
      if (path === '/ping') {
        try {
          const check = await this.checkDaemons(context, api, path);
          return check;
        } catch (error) {
          const isDown = (error || {}).code === 'ECONNREFUSED';
          if (!isDown) {
            context.wazuh.logger.error('Server API is online but the server is not ready yet');
            return (0, _errorResponse.ErrorResponse)(`ERROR3099 - ${error.message || 'Server not ready yet'}`, 3099, _constants.HTTP_STATUS_CODES.INTERNAL_SERVER_ERROR, response);
          }
        }
      }
      context.wazuh.logger.debug(`${method} ${path}`);
      const responseToken = await context.wazuh.api.client.asCurrentUser.request(method, path, data, options);
      const responseIsDown = this.checkResponseIsDown(context, responseToken);
      if (responseIsDown) {
        return (0, _errorResponse.ErrorResponse)(`ERROR3099 - ${response.body.message || 'Server not ready yet'}`, 3099, _constants.HTTP_STATUS_CODES.INTERNAL_SERVER_ERROR, response);
      }
      let responseBody = (responseToken || {}).data || {};
      if (!responseBody) {
        responseBody = typeof responseBody === 'string' && path.includes('/files') && method === 'GET' ? ' ' : false;
        response.data = responseBody;
      }
      const responseError = response.status !== _constants.HTTP_STATUS_CODES.OK ? response.status : false;
      if (!responseError && responseBody) {
        return response.ok({
          body: responseToken.data
        });
      }
      if (responseError && devTools) {
        return response.ok({
          body: response.data
        });
      }
      throw responseError && responseBody.detail ? {
        message: responseBody.detail,
        code: responseError
      } : new Error('Unexpected error fetching data from the API');
    } catch (error) {
      var _error$response7;
      // If the request comes from DevTools, surface the upstream API
      // response as-is so the console can show the real payload and
      // status code (e.g. 404 for unknown endpoints), instead of a 500.
      if (devTools && error !== null && error !== void 0 && error.response) {
        try {
          const statusCode = error.response.status || _constants.HTTP_STATUS_CODES.INTERNAL_SERVER_ERROR;
          const body = error.response.data || {
            message: error.message || 'Unexpected error'
          };
          return response.custom({
            statusCode,
            body
          });
        } catch (_) {
          // fall through to the default error handling below if something goes wrong
        }
      }
      if ((error === null || error === void 0 || (_error$response7 = error.response) === null || _error$response7 === void 0 ? void 0 : _error$response7.status) === _constants.HTTP_STATUS_CODES.UNAUTHORIZED) {
        return (0, _errorResponse.ErrorResponse)(error.message || error, error.code ? `API error: ${error.code}` : 3013, _constants.HTTP_STATUS_CODES.UNAUTHORIZED, response);
      }
      // when the error is an axios error the object will be always error.response.data
      const errorMessage = (0, _extractErrorMessage.extractErrorMessage)(error);
      context.wazuh.logger.error(errorMessage);
      if ((error || {}).code && _apiErrorsEquivalence.ApiErrorEquivalence[error.code]) {
        error.message = _apiErrorsEquivalence.ApiErrorEquivalence[error.code];
      }
      return (0, _errorResponse.ErrorResponse)(errorMessage, error.code ? `API error: ${error.code}` : 3013, _constants.HTTP_STATUS_CODES.INTERNAL_SERVER_ERROR, response);
    }
  }

  /**
   * This make a request to API
   * @param {Object} context
   * @param {Object} request
   * @param {Object} response
   * @returns {Object} api response or ErrorResponse
   */
  requestApi(context, request, response) {
    const idApi = (0, _cookie.getCookieValueByName)(request.headers.cookie, 'wz-api');
    if (idApi !== request.body.id) {
      // if the current token belongs to a different API id, we relogin to obtain a new token
      return (0, _errorResponse.ErrorResponse)('status code 401', _constants.HTTP_STATUS_CODES.UNAUTHORIZED, _constants.HTTP_STATUS_CODES.UNAUTHORIZED, response);
    }
    if (!request.body.method) {
      return (0, _errorResponse.ErrorResponse)('Missing param: method', 3015, _constants.HTTP_STATUS_CODES.BAD_REQUEST, response);
    } else if (!request.body.method.match(/^(?:GET|PUT|POST|DELETE)$/)) {
      context.wazuh.logger.error('Request method is not valid.');
      //Method is not a valid HTTP request method
      return (0, _errorResponse.ErrorResponse)('Request method is not valid.', 3015, _constants.HTTP_STATUS_CODES.BAD_REQUEST, response);
    } else if (!request.body.path) {
      return (0, _errorResponse.ErrorResponse)('Missing param: path', 3016, _constants.HTTP_STATUS_CODES.BAD_REQUEST, response);
    } else if (!request.body.path.startsWith('/')) {
      context.wazuh.logger.error('Request path is not valid.');
      //Path doesn't start with '/'
      return (0, _errorResponse.ErrorResponse)('Request path is not valid.', 3015, _constants.HTTP_STATUS_CODES.BAD_REQUEST, response);
    } else {
      return this.makeRequest(context, request.body.method, request.body.path, request.body.body, request.body.id, response);
    }
  }

  /**
   * Get full data on CSV format from a list Wazuh API endpoint
   * @param {Object} ctx
   * @param {Object} request
   * @param {Object} response
   * @returns {Object} csv or ErrorResponse
   */
  async csv(context, request, response) {
    const appConfig = await context.wazuh_core.configuration.get();
    const reportMaxRows = appConfig['reports.csv.maxRows'];
    try {
      if (!request.body || !request.body.path) throw new Error('Field path is required');
      if (!request.body.id) throw new Error('Field id is required');
      const filters = Array.isArray(((request || {}).body || {}).filters) ? request.body.filters : [];
      let tmpPath = request.body.path;
      if (tmpPath && typeof tmpPath === 'string') {
        tmpPath = tmpPath[0] === '/' ? tmpPath.substr(1) : tmpPath;
      }
      if (!tmpPath) throw new Error('An error occurred parsing path field');
      context.wazuh.logger.debug(`Report ${tmpPath}`);
      // Real limit, regardless the user query
      const params = {
        limit: 500
      };
      if (filters.length) {
        for (const filter of filters) {
          if (!filter.name || !filter.value) continue;
          params[filter.name] = filter.value;
        }
      }
      let itemsArray = [];
      const output = await context.wazuh.api.client.asCurrentUser.request('GET', `/${tmpPath}`, {
        params: params
      }, {
        apiHostID: request.body.id
      });
      const isList = request.body.path.includes('/lists') && request.body.filters && request.body.filters.length && request.body.filters.find(filter => filter._isCDBList);
      const totalItems = (((output || {}).data || {}).data || {}).total_affected_items;
      if (totalItems && !isList) {
        params.offset = 0;
        while (itemsArray.length < Math.min(totalItems, reportMaxRows) && params.offset < Math.min(totalItems, reportMaxRows)) {
          const tmpData = await context.wazuh.api.client.asCurrentUser.request('GET', `/${tmpPath}`, {
            params: params
          }, {
            apiHostID: request.body.id
          });
          const affectedItems = tmpData.data.data.affected_items;
          const remainingItems = reportMaxRows - itemsArray.length;
          if (itemsArray.length + affectedItems.length > reportMaxRows) {
            itemsArray.push(...affectedItems.slice(0, remainingItems));
            break;
          }
          itemsArray.push(...affectedItems);
          params.offset += params.limit;
        }
      }
      if (totalItems) {
        const {
          path,
          filters
        } = request.body;
        const isArrayOfLists = path.includes('/lists') && !isList;
        const isAgents = path.includes('/agents') && !path.includes('groups');
        const isAgentsOfGroup = path.startsWith('/agents/groups/');
        const isFiles = path.endsWith('/files');
        let fields = Object.keys(output.data.data.affected_items[0]);
        if (isAgents || isAgentsOfGroup) {
          if (isFiles) {
            fields = ['filename', 'hash'];
          } else {
            fields = ['id', 'status', 'name', 'ip', 'group', 'manager', 'node_name', 'dateAdd', 'version', 'lastKeepAlive', 'os.arch', 'os.build', 'os.codename', 'os.major', 'os.minor', 'os.name', 'os.platform', 'os.uname', 'os.version'];
          }
        }
        if (isArrayOfLists) {
          const flatLists = [];
          for (const list of itemsArray) {
            const {
              relative_dirname,
              items
            } = list;
            flatLists.push(...items.map(item => ({
              relative_dirname,
              key: item.key,
              value: item.value
            })));
          }
          fields = ['relative_dirname', 'key', 'value'];
          itemsArray = [...flatLists];
        }
        if (isList) {
          fields = ['key', 'value'];
          itemsArray = output.data.data.affected_items[0].items;
        }
        fields = fields.map(item => ({
          // WORKAROUND: This defines an alternative name for the size property for some server API responses (FIM) that is incompatible with json2csvAsync
          value: item === 'size' ? _csvKeyEquivalence.UnsupportedKeysJson2CsvAsyncSize : item,
          default: '-'
        }));
        const options = {
          emptyFieldValue: '',
          keys: fields.map(field => ({
            field: field.value,
            title: _csvKeyEquivalence.KeyEquivalence[field.value] || field.value
          }))
        };
        itemsArray = itemsArray.map(({
          size,
          ...rest
        }) => ({
          ...rest,
          // WORKAROUND: This defines an alternative name for the size property for some server API responses (FIM) that is incompatible with json2csvAsync
          ...(size !== undefined ? {
            [_csvKeyEquivalence.UnsupportedKeysJson2CsvAsyncSize]: size
          } : {})
        }));
        let csv = await _json2Csv.default.json2csvAsync(itemsArray, options);
        return response.ok({
          headers: {
            'Content-Type': 'text/csv'
          },
          body: csv
        });
      } else if (output && output.data && output.data.data && !output.data.data.total_affected_items) {
        throw new Error('No results');
      } else {
        throw new Error(`An error occurred fetching data from the Wazuh API${output && output.data && output.data.detail ? `: ${output.body.detail}` : ''}`);
      }
    } catch (error) {
      context.wazuh.logger.error(error.message || error);
      return (0, _errorResponse.ErrorResponse)(error.message || error, 3034, _constants.HTTP_STATUS_CODES.INTERNAL_SERVER_ERROR, response);
    }
  }

  // Get de list of available requests in the API
  getRequestList(context, request, response) {
    //Read a static JSON until the api call has implemented
    return response.ok({
      body: _endpoints.default
    });
  }

  /**
   * This get the wazuh setup settings
   * @param {Object} context
   * @param {Object} request
   * @param {Object} response
   * @returns {Object} setup info or ErrorResponse
   */
  async getSetupInfo(context, request, response) {
    try {
      return response.ok({
        body: {
          statusCode: _constants.HTTP_STATUS_CODES.OK,
          data: {
            'app-version': _package.version,
            revision: _package.revision,
            configuration_file: context.wazuh_core.configuration.store.file
          }
        }
      });
    } catch (error) {
      context.wazuh.logger.error(error.message || error);
      return (0, _errorResponse.ErrorResponse)(`Could not get data from wazuh-version registry due to ${error.message || error}`, 4005, _constants.HTTP_STATUS_CODES.INTERNAL_SERVER_ERROR, response);
    }
  }

  /**
   * Gets custom logos configuration (path)
   * @param context
   * @param request
   * @param response
   */
  async getAppLogos(context, request, response) {
    try {
      const APP_LOGO = 'customization.logo.app';
      const HEALTHCHECK_LOGO = 'customization.logo.healthcheck';
      const logos = {
        [APP_LOGO]: await context.wazuh_core.configuration.getCustomizationSetting(APP_LOGO),
        [HEALTHCHECK_LOGO]: await context.wazuh_core.configuration.getCustomizationSetting(HEALTHCHECK_LOGO)
      };
      return response.ok({
        body: {
          logos
        }
      });
    } catch (error) {
      context.wazuh.logger.error(error.message || error);
      return (0, _errorResponse.ErrorResponse)(error.message || error, 3035, _constants.HTTP_STATUS_CODES.INTERNAL_SERVER_ERROR, response);
    }
  }
}
exports.WazuhApiCtrl = WazuhApiCtrl;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfZXJyb3JSZXNwb25zZSIsInJlcXVpcmUiLCJfanNvbjJDc3YiLCJfaW50ZXJvcFJlcXVpcmVEZWZhdWx0IiwiX2NzdktleUVxdWl2YWxlbmNlIiwiX2FwaUVycm9yc0VxdWl2YWxlbmNlIiwiX2VuZHBvaW50cyIsIl9jb25zdGFudHMiLCJfcXVldWUiLCJfand0RGVjb2RlIiwiX2Nvb2tpZSIsIl9wYWNrYWdlIiwiX2V4dHJhY3RFcnJvck1lc3NhZ2UiLCJlIiwiX19lc01vZHVsZSIsImRlZmF1bHQiLCJXYXp1aEFwaUN0cmwiLCJjb25zdHJ1Y3RvciIsImdldFRva2VuIiwiY29udGV4dCIsInJlcXVlc3QiLCJyZXNwb25zZSIsImZvcmNlIiwiaWRIb3N0IiwiYm9keSIsInVzZXJuYW1lIiwid2F6dWgiLCJzZWN1cml0eSIsImdldEN1cnJlbnRVc2VyIiwiaGVhZGVycyIsImNvb2tpZSIsImRlY29kZVVSSUNvbXBvbmVudCIsImdldENvb2tpZVZhbHVlQnlOYW1lIiwid3pUb2tlbiIsImRlY29kZWRUb2tlbiIsImp3dERlY29kZSIsImV4cGlyYXRpb25UaW1lIiwiZXhwIiwiRGF0ZSIsIm5vdyIsIm9rIiwidG9rZW4iLCJlcnJvciIsImxvZ2dlciIsIm1lc3NhZ2UiLCJhcGkiLCJjbGllbnQiLCJhc0N1cnJlbnRVc2VyIiwiYXV0aGVudGljYXRlIiwidGV4dFNlY3VyZSIsInNlcnZlciIsImluZm8iLCJwcm90b2NvbCIsImVuY29kZWRVc2VyIiwiZW5jb2RlVVJJQ29tcG9uZW50IiwiX2Vycm9yJHJlc3BvbnNlIiwiZXJyb3JNZXNzYWdlIiwiZXh0cmFjdEVycm9yTWVzc2FnZSIsIkVycm9yUmVzcG9uc2UiLCJzdGF0dXMiLCJIVFRQX1NUQVRVU19DT0RFUyIsIklOVEVSTkFMX1NFUlZFUl9FUlJPUiIsImNoZWNrU3RvcmVkQVBJIiwiaWQiLCJkZWJ1ZyIsImFwaUhvc3REYXRhIiwid2F6dWhfY29yZSIsIm1hbmFnZUhvc3RzIiwiZ2V0IiwiZXhjbHVkZVBhc3N3b3JkIiwiSlNPTiIsInN0cmluZ2lmeSIsInJlc3BvbnNlTWFuYWdlckluZm8iLCJhc0ludGVybmFsVXNlciIsImFwaUhvc3RJRCIsImZvcmNlUmVmcmVzaCIsImNoZWNrUmVzcG9uc2VJc0Rvd24iLCJkYXRhIiwiZGV0YWlsIiwiU0VSVklDRV9VTkFWQUlMQUJMRSIsIm1hbmFnZXIiLCJub2RlIiwiY2x1c3RlciIsImdldFJlZ2lzdHJ5RGF0YUJ5SG9zdCIsInRocm93RXJyb3IiLCJjbHVzdGVyX2luZm8iLCJzdGF0dXNDb2RlIiwiT0siLCJpZENoYW5nZWQiLCJFcnJvciIsInVybCIsInBvcnQiLCJjb2RlIiwiYXBpSXNEb3duIiwiX2Vycm9yJHJlc3BvbnNlMyIsImFwaXMiLCJfZXJyb3IkcmVzcG9uc2UyIiwidmFsaWRhdGVDaGVja0FwaVBhcmFtcyIsImluY2x1ZGVzIiwiY2hlY2tBUEkiLCJhcGlBdmFpbGFibGUiLCJvcHRpb25zIiwiX2Vycm9yJHJlc3BvbnNlNCIsIl9lcnJvciRyZXNwb25zZTUiLCJfcmVzcG9uc2VNYW5hZ2VySW5mbyQiLCJhZmZlY3RlZF9pdGVtcyIsInV1aWQiLCJyZXN1bHQiLCJ3YXJuIiwiX2Vycm9yJHJlc3BvbnNlNiIsIlVOQVVUSE9SSVpFRCIsIkJBRF9SRVFVRVNUIiwic29ja2V0RXJyb3JDb2RlcyIsImlzRG93biIsImNoZWNrRGFlbW9ucyIsInBhdGgiLCJkYWVtb25zIiwiaXNDbHVzdGVyIiwid2F6dWhkYkV4aXN0cyIsImV4ZWNkIiwibW9kdWxlc2QiLCJ3YXp1aGRiIiwiY2x1c3RlcmQiLCJpc1ZhbGlkIiwiUHJvbWlzZSIsInJlamVjdCIsInNsZWVwIiwidGltZU1zIiwicmVzb2x2ZSIsInNldFRpbWVvdXQiLCJtYWtlUmVxdWVzdCIsIm1ldGhvZCIsImRldlRvb2xzIiwiTk9UX0ZPVU5EIiwib3JpZ2luIiwiZGVsYXkiLCJhZGRKb2JUb1F1ZXVlIiwic3RhcnRBdCIsInJ1biIsImNvbnRleHRKb2IiLCJjaGVjayIsInJlc3BvbnNlVG9rZW4iLCJyZXNwb25zZUlzRG93biIsInJlc3BvbnNlQm9keSIsInJlc3BvbnNlRXJyb3IiLCJfZXJyb3IkcmVzcG9uc2U3IiwiY3VzdG9tIiwiXyIsIkFwaUVycm9yRXF1aXZhbGVuY2UiLCJyZXF1ZXN0QXBpIiwiaWRBcGkiLCJtYXRjaCIsInN0YXJ0c1dpdGgiLCJjc3YiLCJhcHBDb25maWciLCJjb25maWd1cmF0aW9uIiwicmVwb3J0TWF4Um93cyIsImZpbHRlcnMiLCJBcnJheSIsImlzQXJyYXkiLCJ0bXBQYXRoIiwic3Vic3RyIiwicGFyYW1zIiwibGltaXQiLCJsZW5ndGgiLCJmaWx0ZXIiLCJuYW1lIiwidmFsdWUiLCJpdGVtc0FycmF5Iiwib3V0cHV0IiwiaXNMaXN0IiwiZmluZCIsIl9pc0NEQkxpc3QiLCJ0b3RhbEl0ZW1zIiwidG90YWxfYWZmZWN0ZWRfaXRlbXMiLCJvZmZzZXQiLCJNYXRoIiwibWluIiwidG1wRGF0YSIsImFmZmVjdGVkSXRlbXMiLCJyZW1haW5pbmdJdGVtcyIsInB1c2giLCJzbGljZSIsImlzQXJyYXlPZkxpc3RzIiwiaXNBZ2VudHMiLCJpc0FnZW50c09mR3JvdXAiLCJpc0ZpbGVzIiwiZW5kc1dpdGgiLCJmaWVsZHMiLCJPYmplY3QiLCJrZXlzIiwiZmxhdExpc3RzIiwibGlzdCIsInJlbGF0aXZlX2Rpcm5hbWUiLCJpdGVtcyIsIm1hcCIsIml0ZW0iLCJrZXkiLCJVbnN1cHBvcnRlZEtleXNKc29uMkNzdkFzeW5jU2l6ZSIsImVtcHR5RmllbGRWYWx1ZSIsImZpZWxkIiwidGl0bGUiLCJLZXlFcXVpdmFsZW5jZSIsInNpemUiLCJyZXN0IiwidW5kZWZpbmVkIiwiY29udmVydGVyIiwianNvbjJjc3ZBc3luYyIsImdldFJlcXVlc3RMaXN0IiwiYXBpUmVxdWVzdExpc3QiLCJnZXRTZXR1cEluZm8iLCJwbHVnaW5WZXJzaW9uIiwicmV2aXNpb24iLCJwbHVnaW5SZXZpc2lvbiIsImNvbmZpZ3VyYXRpb25fZmlsZSIsInN0b3JlIiwiZmlsZSIsImdldEFwcExvZ29zIiwiQVBQX0xPR08iLCJIRUFMVEhDSEVDS19MT0dPIiwibG9nb3MiLCJnZXRDdXN0b21pemF0aW9uU2V0dGluZyIsImV4cG9ydHMiXSwic291cmNlcyI6WyJ3YXp1aC1hcGkudHMiXSwic291cmNlc0NvbnRlbnQiOlsiLypcbiAqIFdhenVoIGFwcCAtIENsYXNzIGZvciBXYXp1aC1BUEkgZnVuY3Rpb25zXG4gKiBDb3B5cmlnaHQgKEMpIDIwMTUtMjAyMiBXYXp1aCwgSW5jLlxuICpcbiAqIFRoaXMgcHJvZ3JhbSBpcyBmcmVlIHNvZnR3YXJlOyB5b3UgY2FuIHJlZGlzdHJpYnV0ZSBpdCBhbmQvb3IgbW9kaWZ5XG4gKiBpdCB1bmRlciB0aGUgdGVybXMgb2YgdGhlIEdOVSBHZW5lcmFsIFB1YmxpYyBMaWNlbnNlIGFzIHB1Ymxpc2hlZCBieVxuICogdGhlIEZyZWUgU29mdHdhcmUgRm91bmRhdGlvbjsgZWl0aGVyIHZlcnNpb24gMiBvZiB0aGUgTGljZW5zZSwgb3JcbiAqIChhdCB5b3VyIG9wdGlvbikgYW55IGxhdGVyIHZlcnNpb24uXG4gKlxuICogRmluZCBtb3JlIGluZm9ybWF0aW9uIGFib3V0IHRoaXMgb24gdGhlIExJQ0VOU0UgZmlsZS5cbiAqL1xuXG4vLyBSZXF1aXJlIHNvbWUgbGlicmFyaWVzXG5pbXBvcnQgeyBFcnJvclJlc3BvbnNlIH0gZnJvbSAnLi4vbGliL2Vycm9yLXJlc3BvbnNlJztcbmltcG9ydCBjb252ZXJ0ZXIgZnJvbSAnanNvbi0yLWNzdic7XG5pbXBvcnQge1xuICBLZXlFcXVpdmFsZW5jZSxcbiAgVW5zdXBwb3J0ZWRLZXlzSnNvbjJDc3ZBc3luY1NpemUsXG59IGZyb20gJy4uLy4uL2NvbW1vbi9jc3Yta2V5LWVxdWl2YWxlbmNlJztcbmltcG9ydCB7IEFwaUVycm9yRXF1aXZhbGVuY2UgfSBmcm9tICcuLi9saWIvYXBpLWVycm9ycy1lcXVpdmFsZW5jZSc7XG5pbXBvcnQgYXBpUmVxdWVzdExpc3QgZnJvbSAnLi4vLi4vY29tbW9uL2FwaS1pbmZvL2VuZHBvaW50cyc7XG5pbXBvcnQgeyBIVFRQX1NUQVRVU19DT0RFUyB9IGZyb20gJy4uLy4uL2NvbW1vbi9jb25zdGFudHMnO1xuaW1wb3J0IHsgYWRkSm9iVG9RdWV1ZSB9IGZyb20gJy4uL3N0YXJ0L3F1ZXVlJztcbmltcG9ydCBqd3REZWNvZGUgZnJvbSAnand0LWRlY29kZSc7XG5pbXBvcnQge1xuICBPcGVuU2VhcmNoRGFzaGJvYXJkc1JlcXVlc3QsXG4gIFJlcXVlc3RIYW5kbGVyQ29udGV4dCxcbiAgT3BlblNlYXJjaERhc2hib2FyZHNSZXNwb25zZUZhY3RvcnksXG59IGZyb20gJ3NyYy9jb3JlL3NlcnZlcic7XG5pbXBvcnQgeyBnZXRDb29raWVWYWx1ZUJ5TmFtZSB9IGZyb20gJy4uL2xpYi9jb29raWUnO1xuaW1wb3J0IHtcbiAgdmVyc2lvbiBhcyBwbHVnaW5WZXJzaW9uLFxuICByZXZpc2lvbiBhcyBwbHVnaW5SZXZpc2lvbixcbn0gZnJvbSAnLi4vLi4vcGFja2FnZS5qc29uJztcbmltcG9ydCB7IGV4dHJhY3RFcnJvck1lc3NhZ2UgfSBmcm9tICcuLi9saWIvZXh0cmFjdC1lcnJvci1tZXNzYWdlJztcblxuZXhwb3J0IGNsYXNzIFdhenVoQXBpQ3RybCB7XG4gIGNvbnN0cnVjdG9yKCkge31cblxuICBhc3luYyBnZXRUb2tlbihcbiAgICBjb250ZXh0OiBSZXF1ZXN0SGFuZGxlckNvbnRleHQsXG4gICAgcmVxdWVzdDogT3BlblNlYXJjaERhc2hib2FyZHNSZXF1ZXN0LFxuICAgIHJlc3BvbnNlOiBPcGVuU2VhcmNoRGFzaGJvYXJkc1Jlc3BvbnNlRmFjdG9yeSxcbiAgKSB7XG4gICAgdHJ5IHtcbiAgICAgIGNvbnN0IHsgZm9yY2UsIGlkSG9zdCB9ID0gcmVxdWVzdC5ib2R5O1xuICAgICAgY29uc3QgeyB1c2VybmFtZSB9ID0gYXdhaXQgY29udGV4dC53YXp1aC5zZWN1cml0eS5nZXRDdXJyZW50VXNlcihcbiAgICAgICAgcmVxdWVzdCxcbiAgICAgICAgY29udGV4dCxcbiAgICAgICk7XG4gICAgICBpZiAoXG4gICAgICAgICFmb3JjZSAmJlxuICAgICAgICByZXF1ZXN0LmhlYWRlcnMuY29va2llICYmXG4gICAgICAgIHVzZXJuYW1lID09PVxuICAgICAgICAgIGRlY29kZVVSSUNvbXBvbmVudChcbiAgICAgICAgICAgIGdldENvb2tpZVZhbHVlQnlOYW1lKHJlcXVlc3QuaGVhZGVycy5jb29raWUsICd3ei11c2VyJyksXG4gICAgICAgICAgKSAmJlxuICAgICAgICBpZEhvc3QgPT09IGdldENvb2tpZVZhbHVlQnlOYW1lKHJlcXVlc3QuaGVhZGVycy5jb29raWUsICd3ei1hcGknKVxuICAgICAgKSB7XG4gICAgICAgIGNvbnN0IHd6VG9rZW4gPSBnZXRDb29raWVWYWx1ZUJ5TmFtZShcbiAgICAgICAgICByZXF1ZXN0LmhlYWRlcnMuY29va2llLFxuICAgICAgICAgICd3ei10b2tlbicsXG4gICAgICAgICk7XG4gICAgICAgIGlmICh3elRva2VuKSB7XG4gICAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgIC8vIGlmIHRoZSBjdXJyZW50IHRva2VuIGlzIG5vdCBhIHZhbGlkIGp3dCB0b2tlbiB3ZSBhc2sgZm9yIGEgbmV3IG9uZVxuICAgICAgICAgICAgY29uc3QgZGVjb2RlZFRva2VuID0gand0RGVjb2RlKHd6VG9rZW4pO1xuICAgICAgICAgICAgY29uc3QgZXhwaXJhdGlvblRpbWUgPSBkZWNvZGVkVG9rZW4uZXhwIC0gRGF0ZS5ub3coKSAvIDEwMDA7XG4gICAgICAgICAgICBpZiAod3pUb2tlbiAmJiBleHBpcmF0aW9uVGltZSA+IDApIHtcbiAgICAgICAgICAgICAgcmV0dXJuIHJlc3BvbnNlLm9rKHtcbiAgICAgICAgICAgICAgICBib2R5OiB7IHRva2VuOiB3elRva2VuIH0sXG4gICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgfVxuICAgICAgICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICAgICAgICBjb250ZXh0LndhenVoLmxvZ2dlci5lcnJvcihcbiAgICAgICAgICAgICAgYEVycm9yIGRlY29kaW5nIHRoZSBBUEkgaG9zdCBlbnRyeSB0b2tlbjogJHtlcnJvci5tZXNzYWdlfWAsXG4gICAgICAgICAgICApO1xuICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgfVxuICAgICAgY29uc3QgdG9rZW4gPSBhd2FpdCBjb250ZXh0LndhenVoLmFwaS5jbGllbnQuYXNDdXJyZW50VXNlci5hdXRoZW50aWNhdGUoXG4gICAgICAgIGlkSG9zdCxcbiAgICAgICk7XG5cbiAgICAgIGxldCB0ZXh0U2VjdXJlID0gJyc7XG4gICAgICBpZiAoY29udGV4dC53YXp1aC5zZXJ2ZXIuaW5mby5wcm90b2NvbCA9PT0gJ2h0dHBzJykge1xuICAgICAgICB0ZXh0U2VjdXJlID0gJztTZWN1cmUnO1xuICAgICAgfVxuICAgICAgY29uc3QgZW5jb2RlZFVzZXIgPSBlbmNvZGVVUklDb21wb25lbnQodXNlcm5hbWUpO1xuICAgICAgcmV0dXJuIHJlc3BvbnNlLm9rKHtcbiAgICAgICAgaGVhZGVyczoge1xuICAgICAgICAgICdzZXQtY29va2llJzogW1xuICAgICAgICAgICAgYHd6LXRva2VuPSR7dG9rZW59O1BhdGg9LztIdHRwT25seSR7dGV4dFNlY3VyZX1gLFxuICAgICAgICAgICAgYHd6LXVzZXI9JHtlbmNvZGVkVXNlcn07UGF0aD0vO0h0dHBPbmx5JHt0ZXh0U2VjdXJlfWAsXG4gICAgICAgICAgICBgd3otYXBpPSR7aWRIb3N0fTtQYXRoPS87SHR0cE9ubHlgLFxuICAgICAgICAgIF0sXG4gICAgICAgIH0sXG4gICAgICAgIGJvZHk6IHsgdG9rZW4gfSxcbiAgICAgIH0pO1xuICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICBjb25zdCBlcnJvck1lc3NhZ2UgPSBgRXJyb3IgZ2V0dGluZyB0aGUgYXV0aG9yaXphdGlvbiB0b2tlbjogJHtleHRyYWN0RXJyb3JNZXNzYWdlKFxuICAgICAgICBlcnJvcixcbiAgICAgICl9YDtcbiAgICAgIGNvbnRleHQud2F6dWgubG9nZ2VyLmVycm9yKGVycm9yTWVzc2FnZSk7XG4gICAgICByZXR1cm4gRXJyb3JSZXNwb25zZShcbiAgICAgICAgZXJyb3JNZXNzYWdlLFxuICAgICAgICAzMDAwLFxuICAgICAgICBlcnJvcj8ucmVzcG9uc2U/LnN0YXR1cyB8fCBIVFRQX1NUQVRVU19DT0RFUy5JTlRFUk5BTF9TRVJWRVJfRVJST1IsXG4gICAgICAgIHJlc3BvbnNlLFxuICAgICAgKTtcbiAgICB9XG4gIH1cblxuICAvKipcbiAgICogUmV0dXJucyBpZiB0aGUgd2F6dWgtYXBpIGNvbmZpZ3VyYXRpb24gaXMgd29ya2luZ1xuICAgKiBAcGFyYW0ge09iamVjdH0gY29udGV4dFxuICAgKiBAcGFyYW0ge09iamVjdH0gcmVxdWVzdFxuICAgKiBAcGFyYW0ge09iamVjdH0gcmVzcG9uc2VcbiAgICogQHJldHVybnMge09iamVjdH0gc3RhdHVzIG9iaiBvciBFcnJvclJlc3BvbnNlXG4gICAqL1xuICBhc3luYyBjaGVja1N0b3JlZEFQSShcbiAgICBjb250ZXh0OiBSZXF1ZXN0SGFuZGxlckNvbnRleHQsXG4gICAgcmVxdWVzdDogT3BlblNlYXJjaERhc2hib2FyZHNSZXF1ZXN0LFxuICAgIHJlc3BvbnNlOiBPcGVuU2VhcmNoRGFzaGJvYXJkc1Jlc3BvbnNlRmFjdG9yeSxcbiAgKSB7XG4gICAgdHJ5IHtcbiAgICAgIC8vIEdldCBjb25maWcgZnJvbSBjb25maWd1cmF0aW9uXG4gICAgICBjb25zdCBpZCA9IHJlcXVlc3QuYm9keS5pZDtcbiAgICAgIGNvbnRleHQud2F6dWgubG9nZ2VyLmRlYnVnKGBHZXR0aW5nIHNlcnZlciBBUEkgaG9zdCBieSBJRDogJHtpZH1gKTtcbiAgICAgIGNvbnN0IGFwaUhvc3REYXRhID0gYXdhaXQgY29udGV4dC53YXp1aF9jb3JlLm1hbmFnZUhvc3RzLmdldChpZCwge1xuICAgICAgICBleGNsdWRlUGFzc3dvcmQ6IHRydWUsXG4gICAgICB9KTtcbiAgICAgIGNvbnN0IGFwaSA9IHsgLi4uYXBpSG9zdERhdGEgfTtcbiAgICAgIGNvbnRleHQud2F6dWgubG9nZ2VyLmRlYnVnKFxuICAgICAgICBgU2VydmVyIEFQSSBob3N0IGRhdGE6ICR7SlNPTi5zdHJpbmdpZnkoYXBpKX1gLFxuICAgICAgKTtcblxuICAgICAgY29udGV4dC53YXp1aC5sb2dnZXIuZGVidWcoYCR7aWR9IGV4aXN0c2ApO1xuXG4gICAgICAvLyBGZXRjaCBuZWVkZWQgaW5mb3JtYXRpb24gYWJvdXQgdGhlIGNsdXN0ZXIgYW5kIHRoZSBtYW5hZ2VyIGl0c2VsZlxuICAgICAgY29uc3QgcmVzcG9uc2VNYW5hZ2VySW5mbyA9XG4gICAgICAgIGF3YWl0IGNvbnRleHQud2F6dWguYXBpLmNsaWVudC5hc0ludGVybmFsVXNlci5yZXF1ZXN0KFxuICAgICAgICAgICdnZXQnLFxuICAgICAgICAgIGAvbWFuYWdlci9pbmZvYCxcbiAgICAgICAgICB7fSxcbiAgICAgICAgICB7IGFwaUhvc3RJRDogaWQsIGZvcmNlUmVmcmVzaDogdHJ1ZSB9LFxuICAgICAgICApO1xuXG4gICAgICAvLyBMb29rIGZvciBzb2NrZXQtcmVsYXRlZCBlcnJvcnNcbiAgICAgIGlmICh0aGlzLmNoZWNrUmVzcG9uc2VJc0Rvd24oY29udGV4dCwgcmVzcG9uc2VNYW5hZ2VySW5mbykpIHtcbiAgICAgICAgcmV0dXJuIEVycm9yUmVzcG9uc2UoXG4gICAgICAgICAgYEVSUk9SMzA5OSAtICR7XG4gICAgICAgICAgICByZXNwb25zZU1hbmFnZXJJbmZvLmRhdGEuZGV0YWlsIHx8ICdTZXJ2ZXIgbm90IHJlYWR5IHlldCdcbiAgICAgICAgICB9YCxcbiAgICAgICAgICAzMDk5LFxuICAgICAgICAgIEhUVFBfU1RBVFVTX0NPREVTLlNFUlZJQ0VfVU5BVkFJTEFCTEUsXG4gICAgICAgICAgcmVzcG9uc2UsXG4gICAgICAgICk7XG4gICAgICB9XG5cbiAgICAgIC8vIElmIHdlIGhhdmUgYSB2YWxpZCByZXNwb25zZSBmcm9tIHRoZSBXYXp1aCBBUElcbiAgICAgIHRyeSB7XG4gICAgICAgIGNvbnN0IHsgc3RhdHVzLCBtYW5hZ2VyLCBub2RlLCBjbHVzdGVyIH0gPVxuICAgICAgICAgIGF3YWl0IGNvbnRleHQud2F6dWhfY29yZS5tYW5hZ2VIb3N0cy5nZXRSZWdpc3RyeURhdGFCeUhvc3QoXG4gICAgICAgICAgICBhcGlIb3N0RGF0YSxcbiAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgdGhyb3dFcnJvcjogdHJ1ZSxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgKTtcblxuICAgICAgICBhcGkuY2x1c3Rlcl9pbmZvID0geyBzdGF0dXMsIG1hbmFnZXIsIG5vZGUsIGNsdXN0ZXIgfTtcblxuICAgICAgICByZXR1cm4gcmVzcG9uc2Uub2soe1xuICAgICAgICAgIGJvZHk6IHtcbiAgICAgICAgICAgIHN0YXR1c0NvZGU6IEhUVFBfU1RBVFVTX0NPREVTLk9LLFxuICAgICAgICAgICAgZGF0YTogYXBpLFxuICAgICAgICAgICAgaWRDaGFuZ2VkOiByZXF1ZXN0LmJvZHkuaWRDaGFuZ2VkIHx8IG51bGwsXG4gICAgICAgICAgfSxcbiAgICAgICAgfSk7XG4gICAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgICAvLyBJZiB3ZSBoYXZlIGFuIGludmFsaWQgcmVzcG9uc2UgZnJvbSB0aGUgV2F6dWggQVBJXG4gICAgICAgIHRocm93IG5ldyBFcnJvcihcbiAgICAgICAgICByZXNwb25zZU1hbmFnZXJJbmZvLmRhdGEuZGV0YWlsIHx8XG4gICAgICAgICAgICBgJHthcGkudXJsfToke2FwaS5wb3J0fSBpcyB1bnJlYWNoYWJsZWAsXG4gICAgICAgICk7XG4gICAgICB9XG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgIGlmIChlcnJvci5jb2RlID09PSAnRVBST1RPJykge1xuICAgICAgICByZXR1cm4gcmVzcG9uc2Uub2soe1xuICAgICAgICAgIGJvZHk6IHtcbiAgICAgICAgICAgIHN0YXR1c0NvZGU6IEhUVFBfU1RBVFVTX0NPREVTLk9LLFxuICAgICAgICAgICAgZGF0YTogeyBhcGlJc0Rvd246IHRydWUgfSxcbiAgICAgICAgICB9LFxuICAgICAgICB9KTtcbiAgICAgIH0gZWxzZSBpZiAoZXJyb3IuY29kZSA9PT0gJ0VDT05OUkVGVVNFRCcpIHtcbiAgICAgICAgcmV0dXJuIHJlc3BvbnNlLm9rKHtcbiAgICAgICAgICBib2R5OiB7XG4gICAgICAgICAgICBzdGF0dXNDb2RlOiBIVFRQX1NUQVRVU19DT0RFUy5PSyxcbiAgICAgICAgICAgIGRhdGE6IHsgYXBpSXNEb3duOiB0cnVlIH0sXG4gICAgICAgICAgfSxcbiAgICAgICAgfSk7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICB0cnkge1xuICAgICAgICAgIGNvbnN0IGFwaXMgPSBhd2FpdCBjb250ZXh0LndhenVoX2NvcmUubWFuYWdlSG9zdHMuZ2V0KCk7XG4gICAgICAgICAgZm9yIChjb25zdCBhcGkgb2YgYXBpcykge1xuICAgICAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgICAgY29uc3QgeyBpZCB9ID0gYXBpO1xuXG4gICAgICAgICAgICAgIGNvbnN0IHJlc3BvbnNlTWFuYWdlckluZm8gPVxuICAgICAgICAgICAgICAgIGF3YWl0IGNvbnRleHQud2F6dWguYXBpLmNsaWVudC5hc0ludGVybmFsVXNlci5yZXF1ZXN0KFxuICAgICAgICAgICAgICAgICAgJ0dFVCcsXG4gICAgICAgICAgICAgICAgICBgL21hbmFnZXIvaW5mb2AsXG4gICAgICAgICAgICAgICAgICB7fSxcbiAgICAgICAgICAgICAgICAgIHsgYXBpSG9zdElEOiBpZCB9LFxuICAgICAgICAgICAgICAgICk7XG5cbiAgICAgICAgICAgICAgaWYgKHRoaXMuY2hlY2tSZXNwb25zZUlzRG93bihjb250ZXh0LCByZXNwb25zZU1hbmFnZXJJbmZvKSkge1xuICAgICAgICAgICAgICAgIHJldHVybiBFcnJvclJlc3BvbnNlKFxuICAgICAgICAgICAgICAgICAgYEVSUk9SMzA5OSAtICR7XG4gICAgICAgICAgICAgICAgICAgIHJlc3BvbnNlLmRhdGEuZGV0YWlsIHx8ICdTZXJ2ZXIgbm90IHJlYWR5IHlldCdcbiAgICAgICAgICAgICAgICAgIH1gLFxuICAgICAgICAgICAgICAgICAgMzA5OSxcbiAgICAgICAgICAgICAgICAgIEhUVFBfU1RBVFVTX0NPREVTLlNFUlZJQ0VfVU5BVkFJTEFCTEUsXG4gICAgICAgICAgICAgICAgICByZXNwb25zZSxcbiAgICAgICAgICAgICAgICApO1xuICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgIGlmIChyZXNwb25zZU1hbmFnZXJJbmZvLnN0YXR1cyA9PT0gSFRUUF9TVEFUVVNfQ09ERVMuT0spIHtcbiAgICAgICAgICAgICAgICByZXF1ZXN0LmJvZHkuaWQgPSBpZDtcbiAgICAgICAgICAgICAgICByZXF1ZXN0LmJvZHkuaWRDaGFuZ2VkID0gaWQ7XG4gICAgICAgICAgICAgICAgcmV0dXJuIGF3YWl0IHRoaXMuY2hlY2tTdG9yZWRBUEkoY29udGV4dCwgcmVxdWVzdCwgcmVzcG9uc2UpO1xuICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9IGNhdGNoIChlcnJvcikge30gLy8gZXNsaW50LWRpc2FibGUtbGluZVxuICAgICAgICAgIH1cbiAgICAgICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgICAgICBjb250ZXh0LndhenVoLmxvZ2dlci5lcnJvcihlcnJvci5tZXNzYWdlIHx8IGVycm9yKTtcbiAgICAgICAgICByZXR1cm4gRXJyb3JSZXNwb25zZShcbiAgICAgICAgICAgIGVycm9yLm1lc3NhZ2UgfHwgZXJyb3IsXG4gICAgICAgICAgICAzMDIwLFxuICAgICAgICAgICAgZXJyb3I/LnJlc3BvbnNlPy5zdGF0dXMgfHwgSFRUUF9TVEFUVVNfQ09ERVMuSU5URVJOQUxfU0VSVkVSX0VSUk9SLFxuICAgICAgICAgICAgcmVzcG9uc2UsXG4gICAgICAgICAgKTtcbiAgICAgICAgfVxuICAgICAgICBjb250ZXh0LndhenVoLmxvZ2dlci5lcnJvcihlcnJvci5tZXNzYWdlIHx8IGVycm9yKTtcbiAgICAgICAgcmV0dXJuIEVycm9yUmVzcG9uc2UoXG4gICAgICAgICAgZXJyb3IubWVzc2FnZSB8fCBlcnJvcixcbiAgICAgICAgICAzMDAyLFxuICAgICAgICAgIGVycm9yPy5yZXNwb25zZT8uc3RhdHVzIHx8IEhUVFBfU1RBVFVTX0NPREVTLklOVEVSTkFMX1NFUlZFUl9FUlJPUixcbiAgICAgICAgICByZXNwb25zZSxcbiAgICAgICAgKTtcbiAgICAgIH1cbiAgICB9XG4gIH1cblxuICAvKipcbiAgICogVGhpcyBwZXJmb21zIGEgdmFsaWRhdGlvbiBvZiBBUEkgcGFyYW1zXG4gICAqIEBwYXJhbSB7T2JqZWN0fSBib2R5IEFQSSBwYXJhbXNcbiAgICovXG4gIHZhbGlkYXRlQ2hlY2tBcGlQYXJhbXMoYm9keSkge1xuICAgIGlmICghKCd1c2VybmFtZScgaW4gYm9keSkpIHtcbiAgICAgIHJldHVybiAnTWlzc2luZyBwYXJhbTogQVBJIFVTRVJOQU1FJztcbiAgICB9XG5cbiAgICBpZiAoISgncGFzc3dvcmQnIGluIGJvZHkpICYmICEoJ2lkJyBpbiBib2R5KSkge1xuICAgICAgcmV0dXJuICdNaXNzaW5nIHBhcmFtOiBBUEkgUEFTU1dPUkQnO1xuICAgIH1cblxuICAgIGlmICghKCd1cmwnIGluIGJvZHkpKSB7XG4gICAgICByZXR1cm4gJ01pc3NpbmcgcGFyYW06IEFQSSBVUkwnO1xuICAgIH1cblxuICAgIGlmICghKCdwb3J0JyBpbiBib2R5KSkge1xuICAgICAgcmV0dXJuICdNaXNzaW5nIHBhcmFtOiBBUEkgUE9SVCc7XG4gICAgfVxuXG4gICAgaWYgKCFib2R5LnVybC5pbmNsdWRlcygnaHR0cHM6Ly8nKSAmJiAhYm9keS51cmwuaW5jbHVkZXMoJ2h0dHA6Ly8nKSkge1xuICAgICAgcmV0dXJuICdwcm90b2NvbF9lcnJvcic7XG4gICAgfVxuXG4gICAgcmV0dXJuIGZhbHNlO1xuICB9XG5cbiAgLyoqXG4gICAqIFRoaXMgY2hlY2sgdGhlIHdhenVoLWFwaSBjb25maWd1cmF0aW9uIHJlY2VpdmVkIGluIHRoZSBQT1NUIGJvZHkgd2lsbCB3b3JrXG4gICAqIEBwYXJhbSB7T2JqZWN0fSBjb250ZXh0XG4gICAqIEBwYXJhbSB7T2JqZWN0fSByZXF1ZXN0XG4gICAqIEBwYXJhbSB7T2JqZWN0fSByZXNwb25zZVxuICAgKiBAcmV0dXJucyB7T2JqZWN0fSBzdGF0dXMgb2JqIG9yIEVycm9yUmVzcG9uc2VcbiAgICovXG4gIGFzeW5jIGNoZWNrQVBJKFxuICAgIGNvbnRleHQ6IFJlcXVlc3RIYW5kbGVyQ29udGV4dCxcbiAgICByZXF1ZXN0OiBPcGVuU2VhcmNoRGFzaGJvYXJkc1JlcXVlc3QsXG4gICAgcmVzcG9uc2U6IE9wZW5TZWFyY2hEYXNoYm9hcmRzUmVzcG9uc2VGYWN0b3J5LFxuICApIHtcbiAgICB0cnkge1xuICAgICAgbGV0IGFwaUF2YWlsYWJsZSA9IG51bGw7XG4gICAgICAvLyBjb25zdCBub3RWYWxpZCA9IHRoaXMudmFsaWRhdGVDaGVja0FwaVBhcmFtcyhyZXF1ZXN0LmJvZHkpO1xuICAgICAgLy8gaWYgKG5vdFZhbGlkKSByZXR1cm4gRXJyb3JSZXNwb25zZShub3RWYWxpZCwgMzAwMywgSFRUUF9TVEFUVVNfQ09ERVMuSU5URVJOQUxfU0VSVkVSX0VSUk9SLCByZXNwb25zZSk7XG4gICAgICBjb250ZXh0LndhenVoLmxvZ2dlci5kZWJ1ZyhgJHtyZXF1ZXN0LmJvZHkuaWR9IGlzIHZhbGlkYCk7XG4gICAgICAvLyBDaGVjayBpZiBhIFdhenVoIEFQSSBpZCBpcyBnaXZlbiAoYWxyZWFkeSBzdG9yZWQgQVBJKVxuICAgICAgY29uc3QgZGF0YSA9IGF3YWl0IGNvbnRleHQud2F6dWhfY29yZS5tYW5hZ2VIb3N0cy5nZXQocmVxdWVzdC5ib2R5LmlkLCB7XG4gICAgICAgIGV4Y2x1ZGVQYXNzd29yZDogdHJ1ZSxcbiAgICAgIH0pO1xuICAgICAgaWYgKGRhdGEpIHtcbiAgICAgICAgYXBpQXZhaWxhYmxlID0gZGF0YTtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIGNvbnN0IGVycm9yTWVzc2FnZSA9IGBUaGUgc2VydmVyIEFQSSBob3N0IGVudHJ5IHdpdGggSUQgJHtyZXF1ZXN0LmJvZHkuaWR9IHdhcyBub3QgZm91bmRgO1xuICAgICAgICBjb250ZXh0LndhenVoLmxvZ2dlci5kZWJ1ZyhlcnJvck1lc3NhZ2UpO1xuICAgICAgICByZXR1cm4gRXJyb3JSZXNwb25zZShcbiAgICAgICAgICBlcnJvck1lc3NhZ2UsXG4gICAgICAgICAgMzAyOSxcbiAgICAgICAgICBIVFRQX1NUQVRVU19DT0RFUy5JTlRFUk5BTF9TRVJWRVJfRVJST1IsXG4gICAgICAgICAgcmVzcG9uc2UsXG4gICAgICAgICk7XG4gICAgICB9XG4gICAgICBjb25zdCBvcHRpb25zID0geyBhcGlIb3N0SUQ6IHJlcXVlc3QuYm9keS5pZCB9O1xuICAgICAgaWYgKHJlcXVlc3QuYm9keS5mb3JjZVJlZnJlc2gpIHtcbiAgICAgICAgb3B0aW9uc1snZm9yY2VSZWZyZXNoJ10gPSByZXF1ZXN0LmJvZHkuZm9yY2VSZWZyZXNoO1xuICAgICAgfVxuICAgICAgbGV0IHJlc3BvbnNlTWFuYWdlckluZm87XG4gICAgICB0cnkge1xuICAgICAgICByZXNwb25zZU1hbmFnZXJJbmZvID1cbiAgICAgICAgICBhd2FpdCBjb250ZXh0LndhenVoLmFwaS5jbGllbnQuYXNJbnRlcm5hbFVzZXIucmVxdWVzdChcbiAgICAgICAgICAgICdHRVQnLFxuICAgICAgICAgICAgYC9tYW5hZ2VyL2luZm9gLFxuICAgICAgICAgICAge30sXG4gICAgICAgICAgICBvcHRpb25zLFxuICAgICAgICAgICk7XG4gICAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgICByZXR1cm4gRXJyb3JSZXNwb25zZShcbiAgICAgICAgICBgRVJST1IzMDk5IC0gJHtcbiAgICAgICAgICAgIGVycm9yLnJlc3BvbnNlPy5kYXRhPy5kZXRhaWwgfHwgJ1NlcnZlciBub3QgcmVhZHkgeWV0J1xuICAgICAgICAgIH1gLFxuICAgICAgICAgIDMwOTksXG4gICAgICAgICAgZXJyb3I/LnJlc3BvbnNlPy5zdGF0dXMgfHwgSFRUUF9TVEFUVVNfQ09ERVMuU0VSVklDRV9VTkFWQUlMQUJMRSxcbiAgICAgICAgICByZXNwb25zZSxcbiAgICAgICAgKTtcbiAgICAgIH1cbiAgICAgIGNvbnRleHQud2F6dWgubG9nZ2VyLmRlYnVnKGAke3JlcXVlc3QuYm9keS5pZH0gY3JlZGVudGlhbHMgYXJlIHZhbGlkYCk7XG4gICAgICBpZiAoXG4gICAgICAgIHJlc3BvbnNlTWFuYWdlckluZm8uc3RhdHVzID09PSBIVFRQX1NUQVRVU19DT0RFUy5PSyAmJlxuICAgICAgICByZXNwb25zZU1hbmFnZXJJbmZvLmRhdGFcbiAgICAgICkge1xuICAgICAgICAvLyBDaGVjayBpZiBVVUlEIGV4aXN0cyBpbiB0aGUgcmVzcG9uc2VcbiAgICAgICAgaWYgKHJlc3BvbnNlTWFuYWdlckluZm8uZGF0YT8uZGF0YT8uYWZmZWN0ZWRfaXRlbXM/LlswXT8udXVpZCkge1xuICAgICAgICAgIGNvbnN0IHV1aWQgPSByZXNwb25zZU1hbmFnZXJJbmZvLmRhdGEuZGF0YS5hZmZlY3RlZF9pdGVtc1swXS51dWlkO1xuICAgICAgICAgIGNvbnN0IHJlc3VsdCA9XG4gICAgICAgICAgICBhd2FpdCBjb250ZXh0LndhenVoX2NvcmUubWFuYWdlSG9zdHMuZ2V0UmVnaXN0cnlEYXRhQnlIb3N0KGRhdGEpO1xuICAgICAgICAgIHJldHVybiByZXNwb25zZS5vayh7XG4gICAgICAgICAgICBib2R5OiB7XG4gICAgICAgICAgICAgIC4uLnJlc3VsdCxcbiAgICAgICAgICAgICAgdXVpZCxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgfSk7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgY29udGV4dC53YXp1aC5sb2dnZXIud2FybignQ291bGQgbm90IG9idGFpbiBtYW5hZ2VyIFVVSUQnKTtcbiAgICAgICAgICByZXR1cm4gRXJyb3JSZXNwb25zZShcbiAgICAgICAgICAgICdDb3VsZCBub3Qgb2J0YWluIG1hbmFnZXIgVVVJRCcsXG4gICAgICAgICAgICBudWxsLFxuICAgICAgICAgICAgSFRUUF9TVEFUVVNfQ09ERVMuSU5URVJOQUxfU0VSVkVSX0VSUk9SLFxuICAgICAgICAgICAgcmVzcG9uc2UsXG4gICAgICAgICAgKTtcbiAgICAgICAgfVxuICAgICAgfVxuICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICBjb250ZXh0LndhenVoLmxvZ2dlci53YXJuKGVycm9yLm1lc3NhZ2UgfHwgZXJyb3IpO1xuXG4gICAgICBpZiAoXG4gICAgICAgIGVycm9yICYmXG4gICAgICAgIGVycm9yLnJlc3BvbnNlICYmXG4gICAgICAgIGVycm9yLnJlc3BvbnNlLnN0YXR1cyA9PT0gSFRUUF9TVEFUVVNfQ09ERVMuVU5BVVRIT1JJWkVEXG4gICAgICApIHtcbiAgICAgICAgcmV0dXJuIEVycm9yUmVzcG9uc2UoXG4gICAgICAgICAgYFVuYXRob3JpemVkLiBQbGVhc2UgY2hlY2sgQVBJIGNyZWRlbnRpYWxzLiAke2Vycm9yLnJlc3BvbnNlLmRhdGEubWVzc2FnZX1gLFxuICAgICAgICAgIEhUVFBfU1RBVFVTX0NPREVTLlVOQVVUSE9SSVpFRCxcbiAgICAgICAgICBIVFRQX1NUQVRVU19DT0RFUy5VTkFVVEhPUklaRUQsXG4gICAgICAgICAgcmVzcG9uc2UsXG4gICAgICAgICk7XG4gICAgICB9XG4gICAgICBpZiAoXG4gICAgICAgIGVycm9yICYmXG4gICAgICAgIGVycm9yLnJlc3BvbnNlICYmXG4gICAgICAgIGVycm9yLnJlc3BvbnNlLmRhdGEgJiZcbiAgICAgICAgZXJyb3IucmVzcG9uc2UuZGF0YS5kZXRhaWxcbiAgICAgICkge1xuICAgICAgICByZXR1cm4gRXJyb3JSZXNwb25zZShcbiAgICAgICAgICBlcnJvci5yZXNwb25zZS5kYXRhLmRldGFpbCxcbiAgICAgICAgICBlcnJvci5yZXNwb25zZS5zdGF0dXMgfHwgSFRUUF9TVEFUVVNfQ09ERVMuU0VSVklDRV9VTkFWQUlMQUJMRSxcbiAgICAgICAgICBlcnJvci5yZXNwb25zZS5zdGF0dXMgfHwgSFRUUF9TVEFUVVNfQ09ERVMuU0VSVklDRV9VTkFWQUlMQUJMRSxcbiAgICAgICAgICByZXNwb25zZSxcbiAgICAgICAgKTtcbiAgICAgIH1cbiAgICAgIGlmIChlcnJvci5jb2RlID09PSAnRVBST1RPJykge1xuICAgICAgICByZXR1cm4gRXJyb3JSZXNwb25zZShcbiAgICAgICAgICAnV3JvbmcgcHJvdG9jb2wgYmVpbmcgdXNlZCB0byBjb25uZWN0IHRvIHRoZSBBUEknLFxuICAgICAgICAgIDMwMDUsXG4gICAgICAgICAgSFRUUF9TVEFUVVNfQ09ERVMuQkFEX1JFUVVFU1QsXG4gICAgICAgICAgcmVzcG9uc2UsXG4gICAgICAgICk7XG4gICAgICB9XG4gICAgICByZXR1cm4gRXJyb3JSZXNwb25zZShcbiAgICAgICAgZXJyb3IubWVzc2FnZSB8fCBlcnJvcixcbiAgICAgICAgMzAwNSxcbiAgICAgICAgZXJyb3I/LnJlc3BvbnNlPy5zdGF0dXMgfHwgSFRUUF9TVEFUVVNfQ09ERVMuSU5URVJOQUxfU0VSVkVSX0VSUk9SLFxuICAgICAgICByZXNwb25zZSxcbiAgICAgICk7XG4gICAgfVxuICB9XG5cbiAgY2hlY2tSZXNwb25zZUlzRG93bihjb250ZXh0LCByZXNwb25zZSkge1xuICAgIGlmIChyZXNwb25zZS5zdGF0dXMgIT09IEhUVFBfU1RBVFVTX0NPREVTLk9LKSB7XG4gICAgICAvLyBBdm9pZCBcIkVycm9yIGNvbW11bmljYXRpbmcgd2l0aCBzb2NrZXRcIiBsaWtlIGVycm9yc1xuICAgICAgY29uc3Qgc29ja2V0RXJyb3JDb2RlcyA9IFsxMDEzLCAxMDE0LCAxMDE3LCAxMDE4LCAxMDE5XTtcbiAgICAgIGNvbnN0IHN0YXR1cyA9IChyZXNwb25zZS5kYXRhIHx8IHt9KS5zdGF0dXMgfHwgMTtcbiAgICAgIGNvbnN0IGlzRG93biA9IHNvY2tldEVycm9yQ29kZXMuaW5jbHVkZXMoc3RhdHVzKTtcblxuICAgICAgaXNEb3duICYmXG4gICAgICAgIGNvbnRleHQud2F6dWgubG9nZ2VyLmVycm9yKFxuICAgICAgICAgICdTZXJ2ZXIgQVBJIGlzIG9ubGluZSBidXQgdGhlIHNlcnZlciBpcyBub3QgcmVhZHkgeWV0JyxcbiAgICAgICAgKTtcblxuICAgICAgcmV0dXJuIGlzRG93bjtcbiAgICB9XG4gICAgcmV0dXJuIGZhbHNlO1xuICB9XG5cbiAgLyoqXG4gICAqIENoZWNrIG1haW4gV2F6dWggZGFlbW9ucyBzdGF0dXNcbiAgICogQHBhcmFtIHsqfSBjb250ZXh0IEVuZHBvaW50IGNvbnRleHRcbiAgICogQHBhcmFtIHsqfSBhcGkgQVBJIGVudHJ5IHN0b3JlZCBpbiAud2F6dWhcbiAgICogQHBhcmFtIHsqfSBwYXRoIE9wdGlvbmFsLiBXYXp1aCBBUEkgdGFyZ2V0IHBhdGguXG4gICAqL1xuICBhc3luYyBjaGVja0RhZW1vbnMoY29udGV4dCwgYXBpLCBwYXRoKSB7XG4gICAgdHJ5IHtcbiAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgY29udGV4dC53YXp1aC5hcGkuY2xpZW50LmFzSW50ZXJuYWxVc2VyLnJlcXVlc3QoXG4gICAgICAgICdHRVQnLFxuICAgICAgICAnL21hbmFnZXIvc3RhdHVzJyxcbiAgICAgICAge30sXG4gICAgICAgIHsgYXBpSG9zdElEOiBhcGkuaWQgfSxcbiAgICAgICk7XG5cbiAgICAgIGNvbnN0IGRhZW1vbnMgPVxuICAgICAgICAoKCgocmVzcG9uc2UgfHwge30pLmRhdGEgfHwge30pLmRhdGEgfHwge30pLmFmZmVjdGVkX2l0ZW1zIHx8IFtdKVswXSB8fFxuICAgICAgICB7fTtcblxuICAgICAgY29uc3QgaXNDbHVzdGVyID1cbiAgICAgICAgKChhcGkgfHwge30pLmNsdXN0ZXJfaW5mbyB8fCB7fSkuc3RhdHVzID09PSAnZW5hYmxlZCcgJiZcbiAgICAgICAgdHlwZW9mIGRhZW1vbnNbJ3dhenVoLWNsdXN0ZXJkJ10gIT09ICd1bmRlZmluZWQnO1xuICAgICAgY29uc3Qgd2F6dWhkYkV4aXN0cyA9IHR5cGVvZiBkYWVtb25zWyd3YXp1aC1kYiddICE9PSAndW5kZWZpbmVkJztcblxuICAgICAgY29uc3QgZXhlY2QgPSBkYWVtb25zWyd3YXp1aC1leGVjZCddID09PSAncnVubmluZyc7XG4gICAgICBjb25zdCBtb2R1bGVzZCA9IGRhZW1vbnNbJ3dhenVoLW1vZHVsZXNkJ10gPT09ICdydW5uaW5nJztcbiAgICAgIGNvbnN0IHdhenVoZGIgPSB3YXp1aGRiRXhpc3RzID8gZGFlbW9uc1snd2F6dWgtZGInXSA9PT0gJ3J1bm5pbmcnIDogdHJ1ZTtcbiAgICAgIGNvbnN0IGNsdXN0ZXJkID0gaXNDbHVzdGVyXG4gICAgICAgID8gZGFlbW9uc1snd2F6dWgtY2x1c3RlcmQnXSA9PT0gJ3J1bm5pbmcnXG4gICAgICAgIDogdHJ1ZTtcblxuICAgICAgY29uc3QgaXNWYWxpZCA9IGV4ZWNkICYmIG1vZHVsZXNkICYmIHdhenVoZGIgJiYgY2x1c3RlcmQ7XG5cbiAgICAgIGlzVmFsaWQgJiYgY29udGV4dC53YXp1aC5sb2dnZXIuZGVidWcoJ1dhenVoIGlzIHJlYWR5Jyk7XG5cbiAgICAgIGlmIChwYXRoID09PSAnL3BpbmcnKSB7XG4gICAgICAgIHJldHVybiB7IGlzVmFsaWQgfTtcbiAgICAgIH1cblxuICAgICAgaWYgKCFpc1ZhbGlkKSB7XG4gICAgICAgIHRocm93IG5ldyBFcnJvcignU2VydmVyIG5vdCByZWFkeSB5ZXQnKTtcbiAgICAgIH1cbiAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgY29udGV4dC53YXp1aC5sb2dnZXIuZXJyb3IoZXJyb3IubWVzc2FnZSB8fCBlcnJvcik7XG4gICAgICByZXR1cm4gUHJvbWlzZS5yZWplY3QoZXJyb3IpO1xuICAgIH1cbiAgfVxuXG4gIHNsZWVwKHRpbWVNcykge1xuICAgIC8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZVxuICAgIHJldHVybiBuZXcgUHJvbWlzZSgocmVzb2x2ZSwgcmVqZWN0KSA9PiB7XG4gICAgICBzZXRUaW1lb3V0KHJlc29sdmUsIHRpbWVNcyk7XG4gICAgfSk7XG4gIH1cblxuICAvKipcbiAgICogVGhpcyBwZXJmb3JtcyBhIHJlcXVlc3Qgb3ZlciBXYXp1aCBBUEkgYW5kIHJldHVybnMgaXRzIHJlc3BvbnNlXG4gICAqIEBwYXJhbSB7U3RyaW5nfSBtZXRob2QgTWV0aG9kOiBHRVQsIFBVVCwgUE9TVCwgREVMRVRFXG4gICAqIEBwYXJhbSB7U3RyaW5nfSBwYXRoIEFQSSByb3V0ZVxuICAgKiBAcGFyYW0ge09iamVjdH0gZGF0YSBkYXRhIGFuZCBwYXJhbXMgdG8gcGVyZm9ybSB0aGUgcmVxdWVzdFxuICAgKiBAcGFyYW0ge1N0cmluZ30gaWQgQVBJIGlkXG4gICAqIEBwYXJhbSB7T2JqZWN0fSByZXNwb25zZVxuICAgKiBAcmV0dXJucyB7T2JqZWN0fSBBUEkgcmVzcG9uc2Ugb3IgRXJyb3JSZXNwb25zZVxuICAgKi9cbiAgYXN5bmMgbWFrZVJlcXVlc3QoY29udGV4dCwgbWV0aG9kLCBwYXRoLCBkYXRhLCBpZCwgcmVzcG9uc2UpIHtcbiAgICBjb25zdCBkZXZUb29scyA9ICEhKGRhdGEgfHwge30pLmRldlRvb2xzO1xuICAgIHRyeSB7XG4gICAgICBsZXQgYXBpO1xuICAgICAgdHJ5IHtcbiAgICAgICAgYXBpID0gYXdhaXQgY29udGV4dC53YXp1aF9jb3JlLm1hbmFnZUhvc3RzLmdldChpZCwge1xuICAgICAgICAgIGV4Y2x1ZGVQYXNzd29yZDogdHJ1ZSxcbiAgICAgICAgfSk7XG4gICAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgICBjb250ZXh0LndhenVoLmxvZ2dlci5lcnJvcignQ291bGQgbm90IGdldCBob3N0IGNyZWRlbnRpYWxzJyk7XG4gICAgICAgIC8vQ2FuIG5vdCBnZXQgY3JlZGVudGlhbHMgZnJvbSB3YXp1aC1ob3N0c1xuICAgICAgICByZXR1cm4gRXJyb3JSZXNwb25zZShcbiAgICAgICAgICAnQ291bGQgbm90IGdldCBob3N0IGNyZWRlbnRpYWxzJyxcbiAgICAgICAgICAzMDExLFxuICAgICAgICAgIEhUVFBfU1RBVFVTX0NPREVTLk5PVF9GT1VORCxcbiAgICAgICAgICByZXNwb25zZSxcbiAgICAgICAgKTtcbiAgICAgIH1cblxuICAgICAgaWYgKGRldlRvb2xzKSB7XG4gICAgICAgIGRlbGV0ZSBkYXRhLmRldlRvb2xzO1xuICAgICAgfVxuXG4gICAgICBpZiAoIWRhdGEpIHtcbiAgICAgICAgZGF0YSA9IHt9O1xuICAgICAgfVxuXG4gICAgICBpZiAoIWRhdGEuaGVhZGVycykge1xuICAgICAgICBkYXRhLmhlYWRlcnMgPSB7fTtcbiAgICAgIH1cblxuICAgICAgY29uc3Qgb3B0aW9ucyA9IHtcbiAgICAgICAgYXBpSG9zdElEOiBpZCxcbiAgICAgIH07XG5cbiAgICAgIC8vIFNldCBjb250ZW50IHR5cGUgYXBwbGljYXRpb24veG1sIGlmIG5lZWRlZFxuICAgICAgaWYgKFxuICAgICAgICB0eXBlb2YgKGRhdGEgfHwge30pLmJvZHkgPT09ICdzdHJpbmcnICYmXG4gICAgICAgIChkYXRhIHx8IHt9KS5vcmlnaW4gPT09ICd4bWxlZGl0b3InXG4gICAgICApIHtcbiAgICAgICAgZGF0YS5oZWFkZXJzWydjb250ZW50LXR5cGUnXSA9ICdhcHBsaWNhdGlvbi94bWwnO1xuICAgICAgICBkZWxldGUgZGF0YS5vcmlnaW47XG4gICAgICB9XG5cbiAgICAgIGlmIChcbiAgICAgICAgdHlwZW9mIChkYXRhIHx8IHt9KS5ib2R5ID09PSAnc3RyaW5nJyAmJlxuICAgICAgICAoZGF0YSB8fCB7fSkub3JpZ2luID09PSAnanNvbidcbiAgICAgICkge1xuICAgICAgICBkYXRhLmhlYWRlcnNbJ2NvbnRlbnQtdHlwZSddID0gJ2FwcGxpY2F0aW9uL2pzb24nO1xuICAgICAgICBkZWxldGUgZGF0YS5vcmlnaW47XG4gICAgICB9XG5cbiAgICAgIGlmIChcbiAgICAgICAgdHlwZW9mIChkYXRhIHx8IHt9KS5ib2R5ID09PSAnc3RyaW5nJyAmJlxuICAgICAgICAoZGF0YSB8fCB7fSkub3JpZ2luID09PSAncmF3J1xuICAgICAgKSB7XG4gICAgICAgIGRhdGEuaGVhZGVyc1snY29udGVudC10eXBlJ10gPSAnYXBwbGljYXRpb24vb2N0ZXQtc3RyZWFtJztcbiAgICAgICAgZGVsZXRlIGRhdGEub3JpZ2luO1xuICAgICAgfVxuICAgICAgY29uc3QgZGVsYXkgPSAoZGF0YSB8fCB7fSkuZGVsYXkgfHwgMDtcbiAgICAgIGlmIChkZWxheSkge1xuICAgICAgICAvLyBSZW1vdmUgdGhlIGRlbGF5IHBhcmFtZXRlciB0aGF0IGlzIHVzZWQgdG8gYWRkIHRoZSBzZXZlciBBUEkgcmVxdWVzdCB0byB0aGUgcXVldWUgam9iLlxuICAgICAgICAvLyBUaGlzIGFzc3VtZXMgdGhlIGRlbGF5IHBhcmFtZXRlciBpcyBub3QgdXNlZCBhcyBwYXJ0IG9mIHRoZSBzZXJ2ZXIgQVBJIHJlcXVlc3QuIElmIGl0XG4gICAgICAgIC8vIHdhcyBleHBlY3RlZCB0byBkbyBhIHJlcXVlc3Qgd2l0aCBhICdkZWxheScgcGFyYW1ldGVyIHRoZW4gd2Ugd291bGQgaGF2ZSB0byBzZWFyY2ggYVxuICAgICAgICAvLyB3YXkgdG8gZGlmZmVyZW5jaWF0ZSBpZiB0aGUgcGFyYW1ldGVyIGlzIHJlbGF0ZWQgdG8gam9iIHF1ZXVlIG9yIEFQSSByZXF1ZXN0LlxuICAgICAgICBkZWxldGUgZGF0YS5kZWxheTtcbiAgICAgICAgYWRkSm9iVG9RdWV1ZSh7XG4gICAgICAgICAgc3RhcnRBdDogbmV3IERhdGUoRGF0ZS5ub3coKSArIGRlbGF5KSxcbiAgICAgICAgICBydW46IGFzeW5jIGNvbnRleHRKb2IgPT4ge1xuICAgICAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgICAgYXdhaXQgY29udGV4dC53YXp1aC5hcGkuY2xpZW50LmFzQ3VycmVudFVzZXIucmVxdWVzdChcbiAgICAgICAgICAgICAgICBtZXRob2QsXG4gICAgICAgICAgICAgICAgcGF0aCxcbiAgICAgICAgICAgICAgICBkYXRhLFxuICAgICAgICAgICAgICAgIG9wdGlvbnMsXG4gICAgICAgICAgICAgICk7XG4gICAgICAgICAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgICAgICAgICBjb250ZXh0Sm9iLndhenVoLmxvZ2dlci5lcnJvcihcbiAgICAgICAgICAgICAgICBgQW4gZXJyb3Igb2N1cnJlZCBpbiB0aGUgZGVsYXllZCByZXF1ZXN0OiBcIiR7bWV0aG9kfSAke3BhdGh9XCI6ICR7XG4gICAgICAgICAgICAgICAgICBlcnJvci5tZXNzYWdlIHx8IGVycm9yXG4gICAgICAgICAgICAgICAgfWAsXG4gICAgICAgICAgICAgICk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgfSxcbiAgICAgICAgfSk7XG4gICAgICAgIHJldHVybiByZXNwb25zZS5vayh7XG4gICAgICAgICAgYm9keTogeyBlcnJvcjogMCwgbWVzc2FnZTogJ1N1Y2Nlc3MnIH0sXG4gICAgICAgIH0pO1xuICAgICAgfVxuXG4gICAgICBpZiAocGF0aCA9PT0gJy9waW5nJykge1xuICAgICAgICB0cnkge1xuICAgICAgICAgIGNvbnN0IGNoZWNrID0gYXdhaXQgdGhpcy5jaGVja0RhZW1vbnMoY29udGV4dCwgYXBpLCBwYXRoKTtcbiAgICAgICAgICByZXR1cm4gY2hlY2s7XG4gICAgICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICAgICAgY29uc3QgaXNEb3duID0gKGVycm9yIHx8IHt9KS5jb2RlID09PSAnRUNPTk5SRUZVU0VEJztcbiAgICAgICAgICBpZiAoIWlzRG93bikge1xuICAgICAgICAgICAgY29udGV4dC53YXp1aC5sb2dnZXIuZXJyb3IoXG4gICAgICAgICAgICAgICdTZXJ2ZXIgQVBJIGlzIG9ubGluZSBidXQgdGhlIHNlcnZlciBpcyBub3QgcmVhZHkgeWV0JyxcbiAgICAgICAgICAgICk7XG4gICAgICAgICAgICByZXR1cm4gRXJyb3JSZXNwb25zZShcbiAgICAgICAgICAgICAgYEVSUk9SMzA5OSAtICR7ZXJyb3IubWVzc2FnZSB8fCAnU2VydmVyIG5vdCByZWFkeSB5ZXQnfWAsXG4gICAgICAgICAgICAgIDMwOTksXG4gICAgICAgICAgICAgIEhUVFBfU1RBVFVTX0NPREVTLklOVEVSTkFMX1NFUlZFUl9FUlJPUixcbiAgICAgICAgICAgICAgcmVzcG9uc2UsXG4gICAgICAgICAgICApO1xuICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgfVxuXG4gICAgICBjb250ZXh0LndhenVoLmxvZ2dlci5kZWJ1ZyhgJHttZXRob2R9ICR7cGF0aH1gKTtcblxuICAgICAgY29uc3QgcmVzcG9uc2VUb2tlbiA9XG4gICAgICAgIGF3YWl0IGNvbnRleHQud2F6dWguYXBpLmNsaWVudC5hc0N1cnJlbnRVc2VyLnJlcXVlc3QoXG4gICAgICAgICAgbWV0aG9kLFxuICAgICAgICAgIHBhdGgsXG4gICAgICAgICAgZGF0YSxcbiAgICAgICAgICBvcHRpb25zLFxuICAgICAgICApO1xuICAgICAgY29uc3QgcmVzcG9uc2VJc0Rvd24gPSB0aGlzLmNoZWNrUmVzcG9uc2VJc0Rvd24oY29udGV4dCwgcmVzcG9uc2VUb2tlbik7XG4gICAgICBpZiAocmVzcG9uc2VJc0Rvd24pIHtcbiAgICAgICAgcmV0dXJuIEVycm9yUmVzcG9uc2UoXG4gICAgICAgICAgYEVSUk9SMzA5OSAtICR7cmVzcG9uc2UuYm9keS5tZXNzYWdlIHx8ICdTZXJ2ZXIgbm90IHJlYWR5IHlldCd9YCxcbiAgICAgICAgICAzMDk5LFxuICAgICAgICAgIEhUVFBfU1RBVFVTX0NPREVTLklOVEVSTkFMX1NFUlZFUl9FUlJPUixcbiAgICAgICAgICByZXNwb25zZSxcbiAgICAgICAgKTtcbiAgICAgIH1cbiAgICAgIGxldCByZXNwb25zZUJvZHkgPSAocmVzcG9uc2VUb2tlbiB8fCB7fSkuZGF0YSB8fCB7fTtcbiAgICAgIGlmICghcmVzcG9uc2VCb2R5KSB7XG4gICAgICAgIHJlc3BvbnNlQm9keSA9XG4gICAgICAgICAgdHlwZW9mIHJlc3BvbnNlQm9keSA9PT0gJ3N0cmluZycgJiZcbiAgICAgICAgICBwYXRoLmluY2x1ZGVzKCcvZmlsZXMnKSAmJlxuICAgICAgICAgIG1ldGhvZCA9PT0gJ0dFVCdcbiAgICAgICAgICAgID8gJyAnXG4gICAgICAgICAgICA6IGZhbHNlO1xuICAgICAgICByZXNwb25zZS5kYXRhID0gcmVzcG9uc2VCb2R5O1xuICAgICAgfVxuICAgICAgY29uc3QgcmVzcG9uc2VFcnJvciA9XG4gICAgICAgIHJlc3BvbnNlLnN0YXR1cyAhPT0gSFRUUF9TVEFUVVNfQ09ERVMuT0sgPyByZXNwb25zZS5zdGF0dXMgOiBmYWxzZTtcblxuICAgICAgaWYgKCFyZXNwb25zZUVycm9yICYmIHJlc3BvbnNlQm9keSkge1xuICAgICAgICByZXR1cm4gcmVzcG9uc2Uub2soe1xuICAgICAgICAgIGJvZHk6IHJlc3BvbnNlVG9rZW4uZGF0YSxcbiAgICAgICAgfSk7XG4gICAgICB9XG5cbiAgICAgIGlmIChyZXNwb25zZUVycm9yICYmIGRldlRvb2xzKSB7XG4gICAgICAgIHJldHVybiByZXNwb25zZS5vayh7XG4gICAgICAgICAgYm9keTogcmVzcG9uc2UuZGF0YSxcbiAgICAgICAgfSk7XG4gICAgICB9XG4gICAgICB0aHJvdyByZXNwb25zZUVycm9yICYmIHJlc3BvbnNlQm9keS5kZXRhaWxcbiAgICAgICAgPyB7IG1lc3NhZ2U6IHJlc3BvbnNlQm9keS5kZXRhaWwsIGNvZGU6IHJlc3BvbnNlRXJyb3IgfVxuICAgICAgICA6IG5ldyBFcnJvcignVW5leHBlY3RlZCBlcnJvciBmZXRjaGluZyBkYXRhIGZyb20gdGhlIEFQSScpO1xuICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICAvLyBJZiB0aGUgcmVxdWVzdCBjb21lcyBmcm9tIERldlRvb2xzLCBzdXJmYWNlIHRoZSB1cHN0cmVhbSBBUElcbiAgICAgIC8vIHJlc3BvbnNlIGFzLWlzIHNvIHRoZSBjb25zb2xlIGNhbiBzaG93IHRoZSByZWFsIHBheWxvYWQgYW5kXG4gICAgICAvLyBzdGF0dXMgY29kZSAoZS5nLiA0MDQgZm9yIHVua25vd24gZW5kcG9pbnRzKSwgaW5zdGVhZCBvZiBhIDUwMC5cbiAgICAgIGlmIChkZXZUb29scyAmJiBlcnJvcj8ucmVzcG9uc2UpIHtcbiAgICAgICAgdHJ5IHtcbiAgICAgICAgICBjb25zdCBzdGF0dXNDb2RlID1cbiAgICAgICAgICAgIGVycm9yLnJlc3BvbnNlLnN0YXR1cyB8fCBIVFRQX1NUQVRVU19DT0RFUy5JTlRFUk5BTF9TRVJWRVJfRVJST1I7XG4gICAgICAgICAgY29uc3QgYm9keSA9IGVycm9yLnJlc3BvbnNlLmRhdGEgfHwge1xuICAgICAgICAgICAgbWVzc2FnZTogZXJyb3IubWVzc2FnZSB8fCAnVW5leHBlY3RlZCBlcnJvcicsXG4gICAgICAgICAgfTtcbiAgICAgICAgICByZXR1cm4gcmVzcG9uc2UuY3VzdG9tKHsgc3RhdHVzQ29kZSwgYm9keSB9KTtcbiAgICAgICAgfSBjYXRjaCAoXykge1xuICAgICAgICAgIC8vIGZhbGwgdGhyb3VnaCB0byB0aGUgZGVmYXVsdCBlcnJvciBoYW5kbGluZyBiZWxvdyBpZiBzb21ldGhpbmcgZ29lcyB3cm9uZ1xuICAgICAgICB9XG4gICAgICB9XG5cbiAgICAgIGlmIChlcnJvcj8ucmVzcG9uc2U/LnN0YXR1cyA9PT0gSFRUUF9TVEFUVVNfQ09ERVMuVU5BVVRIT1JJWkVEKSB7XG4gICAgICAgIHJldHVybiBFcnJvclJlc3BvbnNlKFxuICAgICAgICAgIGVycm9yLm1lc3NhZ2UgfHwgZXJyb3IsXG4gICAgICAgICAgZXJyb3IuY29kZSA/IGBBUEkgZXJyb3I6ICR7ZXJyb3IuY29kZX1gIDogMzAxMyxcbiAgICAgICAgICBIVFRQX1NUQVRVU19DT0RFUy5VTkFVVEhPUklaRUQsXG4gICAgICAgICAgcmVzcG9uc2UsXG4gICAgICAgICk7XG4gICAgICB9XG4gICAgICAvLyB3aGVuIHRoZSBlcnJvciBpcyBhbiBheGlvcyBlcnJvciB0aGUgb2JqZWN0IHdpbGwgYmUgYWx3YXlzIGVycm9yLnJlc3BvbnNlLmRhdGFcbiAgICAgIGNvbnN0IGVycm9yTWVzc2FnZSA9IGV4dHJhY3RFcnJvck1lc3NhZ2UoZXJyb3IpO1xuICAgICAgY29udGV4dC53YXp1aC5sb2dnZXIuZXJyb3IoZXJyb3JNZXNzYWdlKTtcbiAgICAgIGlmICgoZXJyb3IgfHwge30pLmNvZGUgJiYgQXBpRXJyb3JFcXVpdmFsZW5jZVtlcnJvci5jb2RlXSkge1xuICAgICAgICBlcnJvci5tZXNzYWdlID0gQXBpRXJyb3JFcXVpdmFsZW5jZVtlcnJvci5jb2RlXTtcbiAgICAgIH1cbiAgICAgIHJldHVybiBFcnJvclJlc3BvbnNlKFxuICAgICAgICBlcnJvck1lc3NhZ2UsXG4gICAgICAgIGVycm9yLmNvZGUgPyBgQVBJIGVycm9yOiAke2Vycm9yLmNvZGV9YCA6IDMwMTMsXG4gICAgICAgIEhUVFBfU1RBVFVTX0NPREVTLklOVEVSTkFMX1NFUlZFUl9FUlJPUixcbiAgICAgICAgcmVzcG9uc2UsXG4gICAgICApO1xuICAgIH1cbiAgfVxuXG4gIC8qKlxuICAgKiBUaGlzIG1ha2UgYSByZXF1ZXN0IHRvIEFQSVxuICAgKiBAcGFyYW0ge09iamVjdH0gY29udGV4dFxuICAgKiBAcGFyYW0ge09iamVjdH0gcmVxdWVzdFxuICAgKiBAcGFyYW0ge09iamVjdH0gcmVzcG9uc2VcbiAgICogQHJldHVybnMge09iamVjdH0gYXBpIHJlc3BvbnNlIG9yIEVycm9yUmVzcG9uc2VcbiAgICovXG4gIHJlcXVlc3RBcGkoXG4gICAgY29udGV4dDogUmVxdWVzdEhhbmRsZXJDb250ZXh0LFxuICAgIHJlcXVlc3Q6IE9wZW5TZWFyY2hEYXNoYm9hcmRzUmVxdWVzdCxcbiAgICByZXNwb25zZTogT3BlblNlYXJjaERhc2hib2FyZHNSZXNwb25zZUZhY3RvcnksXG4gICkge1xuICAgIGNvbnN0IGlkQXBpID0gZ2V0Q29va2llVmFsdWVCeU5hbWUocmVxdWVzdC5oZWFkZXJzLmNvb2tpZSwgJ3d6LWFwaScpO1xuICAgIGlmIChpZEFwaSAhPT0gcmVxdWVzdC5ib2R5LmlkKSB7XG4gICAgICAvLyBpZiB0aGUgY3VycmVudCB0b2tlbiBiZWxvbmdzIHRvIGEgZGlmZmVyZW50IEFQSSBpZCwgd2UgcmVsb2dpbiB0byBvYnRhaW4gYSBuZXcgdG9rZW5cbiAgICAgIHJldHVybiBFcnJvclJlc3BvbnNlKFxuICAgICAgICAnc3RhdHVzIGNvZGUgNDAxJyxcbiAgICAgICAgSFRUUF9TVEFUVVNfQ09ERVMuVU5BVVRIT1JJWkVELFxuICAgICAgICBIVFRQX1NUQVRVU19DT0RFUy5VTkFVVEhPUklaRUQsXG4gICAgICAgIHJlc3BvbnNlLFxuICAgICAgKTtcbiAgICB9XG4gICAgaWYgKCFyZXF1ZXN0LmJvZHkubWV0aG9kKSB7XG4gICAgICByZXR1cm4gRXJyb3JSZXNwb25zZShcbiAgICAgICAgJ01pc3NpbmcgcGFyYW06IG1ldGhvZCcsXG4gICAgICAgIDMwMTUsXG4gICAgICAgIEhUVFBfU1RBVFVTX0NPREVTLkJBRF9SRVFVRVNULFxuICAgICAgICByZXNwb25zZSxcbiAgICAgICk7XG4gICAgfSBlbHNlIGlmICghcmVxdWVzdC5ib2R5Lm1ldGhvZC5tYXRjaCgvXig/OkdFVHxQVVR8UE9TVHxERUxFVEUpJC8pKSB7XG4gICAgICBjb250ZXh0LndhenVoLmxvZ2dlci5lcnJvcignUmVxdWVzdCBtZXRob2QgaXMgbm90IHZhbGlkLicpO1xuICAgICAgLy9NZXRob2QgaXMgbm90IGEgdmFsaWQgSFRUUCByZXF1ZXN0IG1ldGhvZFxuICAgICAgcmV0dXJuIEVycm9yUmVzcG9uc2UoXG4gICAgICAgICdSZXF1ZXN0IG1ldGhvZCBpcyBub3QgdmFsaWQuJyxcbiAgICAgICAgMzAxNSxcbiAgICAgICAgSFRUUF9TVEFUVVNfQ09ERVMuQkFEX1JFUVVFU1QsXG4gICAgICAgIHJlc3BvbnNlLFxuICAgICAgKTtcbiAgICB9IGVsc2UgaWYgKCFyZXF1ZXN0LmJvZHkucGF0aCkge1xuICAgICAgcmV0dXJuIEVycm9yUmVzcG9uc2UoXG4gICAgICAgICdNaXNzaW5nIHBhcmFtOiBwYXRoJyxcbiAgICAgICAgMzAxNixcbiAgICAgICAgSFRUUF9TVEFUVVNfQ09ERVMuQkFEX1JFUVVFU1QsXG4gICAgICAgIHJlc3BvbnNlLFxuICAgICAgKTtcbiAgICB9IGVsc2UgaWYgKCFyZXF1ZXN0LmJvZHkucGF0aC5zdGFydHNXaXRoKCcvJykpIHtcbiAgICAgIGNvbnRleHQud2F6dWgubG9nZ2VyLmVycm9yKCdSZXF1ZXN0IHBhdGggaXMgbm90IHZhbGlkLicpO1xuICAgICAgLy9QYXRoIGRvZXNuJ3Qgc3RhcnQgd2l0aCAnLydcbiAgICAgIHJldHVybiBFcnJvclJlc3BvbnNlKFxuICAgICAgICAnUmVxdWVzdCBwYXRoIGlzIG5vdCB2YWxpZC4nLFxuICAgICAgICAzMDE1LFxuICAgICAgICBIVFRQX1NUQVRVU19DT0RFUy5CQURfUkVRVUVTVCxcbiAgICAgICAgcmVzcG9uc2UsXG4gICAgICApO1xuICAgIH0gZWxzZSB7XG4gICAgICByZXR1cm4gdGhpcy5tYWtlUmVxdWVzdChcbiAgICAgICAgY29udGV4dCxcbiAgICAgICAgcmVxdWVzdC5ib2R5Lm1ldGhvZCxcbiAgICAgICAgcmVxdWVzdC5ib2R5LnBhdGgsXG4gICAgICAgIHJlcXVlc3QuYm9keS5ib2R5LFxuICAgICAgICByZXF1ZXN0LmJvZHkuaWQsXG4gICAgICAgIHJlc3BvbnNlLFxuICAgICAgKTtcbiAgICB9XG4gIH1cblxuICAvKipcbiAgICogR2V0IGZ1bGwgZGF0YSBvbiBDU1YgZm9ybWF0IGZyb20gYSBsaXN0IFdhenVoIEFQSSBlbmRwb2ludFxuICAgKiBAcGFyYW0ge09iamVjdH0gY3R4XG4gICAqIEBwYXJhbSB7T2JqZWN0fSByZXF1ZXN0XG4gICAqIEBwYXJhbSB7T2JqZWN0fSByZXNwb25zZVxuICAgKiBAcmV0dXJucyB7T2JqZWN0fSBjc3Ygb3IgRXJyb3JSZXNwb25zZVxuICAgKi9cbiAgYXN5bmMgY3N2KFxuICAgIGNvbnRleHQ6IFJlcXVlc3RIYW5kbGVyQ29udGV4dCxcbiAgICByZXF1ZXN0OiBPcGVuU2VhcmNoRGFzaGJvYXJkc1JlcXVlc3QsXG4gICAgcmVzcG9uc2U6IE9wZW5TZWFyY2hEYXNoYm9hcmRzUmVzcG9uc2VGYWN0b3J5LFxuICApIHtcbiAgICBjb25zdCBhcHBDb25maWcgPSBhd2FpdCBjb250ZXh0LndhenVoX2NvcmUuY29uZmlndXJhdGlvbi5nZXQoKTtcbiAgICBjb25zdCByZXBvcnRNYXhSb3dzID0gYXBwQ29uZmlnWydyZXBvcnRzLmNzdi5tYXhSb3dzJ107XG4gICAgdHJ5IHtcbiAgICAgIGlmICghcmVxdWVzdC5ib2R5IHx8ICFyZXF1ZXN0LmJvZHkucGF0aClcbiAgICAgICAgdGhyb3cgbmV3IEVycm9yKCdGaWVsZCBwYXRoIGlzIHJlcXVpcmVkJyk7XG4gICAgICBpZiAoIXJlcXVlc3QuYm9keS5pZCkgdGhyb3cgbmV3IEVycm9yKCdGaWVsZCBpZCBpcyByZXF1aXJlZCcpO1xuXG4gICAgICBjb25zdCBmaWx0ZXJzID0gQXJyYXkuaXNBcnJheSgoKHJlcXVlc3QgfHwge30pLmJvZHkgfHwge30pLmZpbHRlcnMpXG4gICAgICAgID8gcmVxdWVzdC5ib2R5LmZpbHRlcnNcbiAgICAgICAgOiBbXTtcblxuICAgICAgbGV0IHRtcFBhdGggPSByZXF1ZXN0LmJvZHkucGF0aDtcblxuICAgICAgaWYgKHRtcFBhdGggJiYgdHlwZW9mIHRtcFBhdGggPT09ICdzdHJpbmcnKSB7XG4gICAgICAgIHRtcFBhdGggPSB0bXBQYXRoWzBdID09PSAnLycgPyB0bXBQYXRoLnN1YnN0cigxKSA6IHRtcFBhdGg7XG4gICAgICB9XG5cbiAgICAgIGlmICghdG1wUGF0aCkgdGhyb3cgbmV3IEVycm9yKCdBbiBlcnJvciBvY2N1cnJlZCBwYXJzaW5nIHBhdGggZmllbGQnKTtcblxuICAgICAgY29udGV4dC53YXp1aC5sb2dnZXIuZGVidWcoYFJlcG9ydCAke3RtcFBhdGh9YCk7XG4gICAgICAvLyBSZWFsIGxpbWl0LCByZWdhcmRsZXNzIHRoZSB1c2VyIHF1ZXJ5XG4gICAgICBjb25zdCBwYXJhbXMgPSB7IGxpbWl0OiA1MDAgfTtcblxuICAgICAgaWYgKGZpbHRlcnMubGVuZ3RoKSB7XG4gICAgICAgIGZvciAoY29uc3QgZmlsdGVyIG9mIGZpbHRlcnMpIHtcbiAgICAgICAgICBpZiAoIWZpbHRlci5uYW1lIHx8ICFmaWx0ZXIudmFsdWUpIGNvbnRpbnVlO1xuICAgICAgICAgIHBhcmFtc1tmaWx0ZXIubmFtZV0gPSBmaWx0ZXIudmFsdWU7XG4gICAgICAgIH1cbiAgICAgIH1cblxuICAgICAgbGV0IGl0ZW1zQXJyYXkgPSBbXTtcblxuICAgICAgY29uc3Qgb3V0cHV0ID0gYXdhaXQgY29udGV4dC53YXp1aC5hcGkuY2xpZW50LmFzQ3VycmVudFVzZXIucmVxdWVzdChcbiAgICAgICAgJ0dFVCcsXG4gICAgICAgIGAvJHt0bXBQYXRofWAsXG4gICAgICAgIHsgcGFyYW1zOiBwYXJhbXMgfSxcbiAgICAgICAgeyBhcGlIb3N0SUQ6IHJlcXVlc3QuYm9keS5pZCB9LFxuICAgICAgKTtcblxuICAgICAgY29uc3QgaXNMaXN0ID1cbiAgICAgICAgcmVxdWVzdC5ib2R5LnBhdGguaW5jbHVkZXMoJy9saXN0cycpICYmXG4gICAgICAgIHJlcXVlc3QuYm9keS5maWx0ZXJzICYmXG4gICAgICAgIHJlcXVlc3QuYm9keS5maWx0ZXJzLmxlbmd0aCAmJlxuICAgICAgICByZXF1ZXN0LmJvZHkuZmlsdGVycy5maW5kKGZpbHRlciA9PiBmaWx0ZXIuX2lzQ0RCTGlzdCk7XG5cbiAgICAgIGNvbnN0IHRvdGFsSXRlbXMgPSAoKChvdXRwdXQgfHwge30pLmRhdGEgfHwge30pLmRhdGEgfHwge30pXG4gICAgICAgIC50b3RhbF9hZmZlY3RlZF9pdGVtcztcblxuICAgICAgaWYgKHRvdGFsSXRlbXMgJiYgIWlzTGlzdCkge1xuICAgICAgICBwYXJhbXMub2Zmc2V0ID0gMDtcbiAgICAgICAgd2hpbGUgKFxuICAgICAgICAgIGl0ZW1zQXJyYXkubGVuZ3RoIDwgTWF0aC5taW4odG90YWxJdGVtcywgcmVwb3J0TWF4Um93cykgJiZcbiAgICAgICAgICBwYXJhbXMub2Zmc2V0IDwgTWF0aC5taW4odG90YWxJdGVtcywgcmVwb3J0TWF4Um93cylcbiAgICAgICAgKSB7XG4gICAgICAgICAgY29uc3QgdG1wRGF0YSA9IGF3YWl0IGNvbnRleHQud2F6dWguYXBpLmNsaWVudC5hc0N1cnJlbnRVc2VyLnJlcXVlc3QoXG4gICAgICAgICAgICAnR0VUJyxcbiAgICAgICAgICAgIGAvJHt0bXBQYXRofWAsXG4gICAgICAgICAgICB7IHBhcmFtczogcGFyYW1zIH0sXG4gICAgICAgICAgICB7IGFwaUhvc3RJRDogcmVxdWVzdC5ib2R5LmlkIH0sXG4gICAgICAgICAgKTtcblxuICAgICAgICAgIGNvbnN0IGFmZmVjdGVkSXRlbXMgPSB0bXBEYXRhLmRhdGEuZGF0YS5hZmZlY3RlZF9pdGVtcztcbiAgICAgICAgICBjb25zdCByZW1haW5pbmdJdGVtcyA9IHJlcG9ydE1heFJvd3MgLSBpdGVtc0FycmF5Lmxlbmd0aDtcbiAgICAgICAgICBpZiAoaXRlbXNBcnJheS5sZW5ndGggKyBhZmZlY3RlZEl0ZW1zLmxlbmd0aCA+IHJlcG9ydE1heFJvd3MpIHtcbiAgICAgICAgICAgIGl0ZW1zQXJyYXkucHVzaCguLi5hZmZlY3RlZEl0ZW1zLnNsaWNlKDAsIHJlbWFpbmluZ0l0ZW1zKSk7XG4gICAgICAgICAgICBicmVhaztcbiAgICAgICAgICB9XG4gICAgICAgICAgaXRlbXNBcnJheS5wdXNoKC4uLmFmZmVjdGVkSXRlbXMpO1xuICAgICAgICAgIHBhcmFtcy5vZmZzZXQgKz0gcGFyYW1zLmxpbWl0O1xuICAgICAgICB9XG4gICAgICB9XG5cbiAgICAgIGlmICh0b3RhbEl0ZW1zKSB7XG4gICAgICAgIGNvbnN0IHsgcGF0aCwgZmlsdGVycyB9ID0gcmVxdWVzdC5ib2R5O1xuICAgICAgICBjb25zdCBpc0FycmF5T2ZMaXN0cyA9IHBhdGguaW5jbHVkZXMoJy9saXN0cycpICYmICFpc0xpc3Q7XG4gICAgICAgIGNvbnN0IGlzQWdlbnRzID0gcGF0aC5pbmNsdWRlcygnL2FnZW50cycpICYmICFwYXRoLmluY2x1ZGVzKCdncm91cHMnKTtcbiAgICAgICAgY29uc3QgaXNBZ2VudHNPZkdyb3VwID0gcGF0aC5zdGFydHNXaXRoKCcvYWdlbnRzL2dyb3Vwcy8nKTtcbiAgICAgICAgY29uc3QgaXNGaWxlcyA9IHBhdGguZW5kc1dpdGgoJy9maWxlcycpO1xuICAgICAgICBsZXQgZmllbGRzID0gT2JqZWN0LmtleXMob3V0cHV0LmRhdGEuZGF0YS5hZmZlY3RlZF9pdGVtc1swXSk7XG5cbiAgICAgICAgaWYgKGlzQWdlbnRzIHx8IGlzQWdlbnRzT2ZHcm91cCkge1xuICAgICAgICAgIGlmIChpc0ZpbGVzKSB7XG4gICAgICAgICAgICBmaWVsZHMgPSBbJ2ZpbGVuYW1lJywgJ2hhc2gnXTtcbiAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgZmllbGRzID0gW1xuICAgICAgICAgICAgICAnaWQnLFxuICAgICAgICAgICAgICAnc3RhdHVzJyxcbiAgICAgICAgICAgICAgJ25hbWUnLFxuICAgICAgICAgICAgICAnaXAnLFxuICAgICAgICAgICAgICAnZ3JvdXAnLFxuICAgICAgICAgICAgICAnbWFuYWdlcicsXG4gICAgICAgICAgICAgICdub2RlX25hbWUnLFxuICAgICAgICAgICAgICAnZGF0ZUFkZCcsXG4gICAgICAgICAgICAgICd2ZXJzaW9uJyxcbiAgICAgICAgICAgICAgJ2xhc3RLZWVwQWxpdmUnLFxuICAgICAgICAgICAgICAnb3MuYXJjaCcsXG4gICAgICAgICAgICAgICdvcy5idWlsZCcsXG4gICAgICAgICAgICAgICdvcy5jb2RlbmFtZScsXG4gICAgICAgICAgICAgICdvcy5tYWpvcicsXG4gICAgICAgICAgICAgICdvcy5taW5vcicsXG4gICAgICAgICAgICAgICdvcy5uYW1lJyxcbiAgICAgICAgICAgICAgJ29zLnBsYXRmb3JtJyxcbiAgICAgICAgICAgICAgJ29zLnVuYW1lJyxcbiAgICAgICAgICAgICAgJ29zLnZlcnNpb24nLFxuICAgICAgICAgICAgXTtcbiAgICAgICAgICB9XG4gICAgICAgIH1cblxuICAgICAgICBpZiAoaXNBcnJheU9mTGlzdHMpIHtcbiAgICAgICAgICBjb25zdCBmbGF0TGlzdHMgPSBbXTtcbiAgICAgICAgICBmb3IgKGNvbnN0IGxpc3Qgb2YgaXRlbXNBcnJheSkge1xuICAgICAgICAgICAgY29uc3QgeyByZWxhdGl2ZV9kaXJuYW1lLCBpdGVtcyB9ID0gbGlzdDtcbiAgICAgICAgICAgIGZsYXRMaXN0cy5wdXNoKFxuICAgICAgICAgICAgICAuLi5pdGVtcy5tYXAoaXRlbSA9PiAoe1xuICAgICAgICAgICAgICAgIHJlbGF0aXZlX2Rpcm5hbWUsXG4gICAgICAgICAgICAgICAga2V5OiBpdGVtLmtleSxcbiAgICAgICAgICAgICAgICB2YWx1ZTogaXRlbS52YWx1ZSxcbiAgICAgICAgICAgICAgfSkpLFxuICAgICAgICAgICAgKTtcbiAgICAgICAgICB9XG4gICAgICAgICAgZmllbGRzID0gWydyZWxhdGl2ZV9kaXJuYW1lJywgJ2tleScsICd2YWx1ZSddO1xuICAgICAgICAgIGl0ZW1zQXJyYXkgPSBbLi4uZmxhdExpc3RzXTtcbiAgICAgICAgfVxuXG4gICAgICAgIGlmIChpc0xpc3QpIHtcbiAgICAgICAgICBmaWVsZHMgPSBbJ2tleScsICd2YWx1ZSddO1xuICAgICAgICAgIGl0ZW1zQXJyYXkgPSBvdXRwdXQuZGF0YS5kYXRhLmFmZmVjdGVkX2l0ZW1zWzBdLml0ZW1zO1xuICAgICAgICB9XG4gICAgICAgIGZpZWxkcyA9IGZpZWxkcy5tYXAoaXRlbSA9PiAoe1xuICAgICAgICAgIC8vIFdPUktBUk9VTkQ6IFRoaXMgZGVmaW5lcyBhbiBhbHRlcm5hdGl2ZSBuYW1lIGZvciB0aGUgc2l6ZSBwcm9wZXJ0eSBmb3Igc29tZSBzZXJ2ZXIgQVBJIHJlc3BvbnNlcyAoRklNKSB0aGF0IGlzIGluY29tcGF0aWJsZSB3aXRoIGpzb24yY3N2QXN5bmNcbiAgICAgICAgICB2YWx1ZTogaXRlbSA9PT0gJ3NpemUnID8gVW5zdXBwb3J0ZWRLZXlzSnNvbjJDc3ZBc3luY1NpemUgOiBpdGVtLFxuICAgICAgICAgIGRlZmF1bHQ6ICctJyxcbiAgICAgICAgfSkpO1xuICAgICAgICBjb25zdCBvcHRpb25zID0ge1xuICAgICAgICAgIGVtcHR5RmllbGRWYWx1ZTogJycsXG4gICAgICAgICAga2V5czogZmllbGRzLm1hcChmaWVsZCA9PiAoe1xuICAgICAgICAgICAgZmllbGQ6IGZpZWxkLnZhbHVlLFxuICAgICAgICAgICAgdGl0bGU6IEtleUVxdWl2YWxlbmNlW2ZpZWxkLnZhbHVlXSB8fCBmaWVsZC52YWx1ZSxcbiAgICAgICAgICB9KSksXG4gICAgICAgIH07XG4gICAgICAgIGl0ZW1zQXJyYXkgPSBpdGVtc0FycmF5Lm1hcCgoeyBzaXplLCAuLi5yZXN0IH0pID0+ICh7XG4gICAgICAgICAgLi4ucmVzdCxcbiAgICAgICAgICAvLyBXT1JLQVJPVU5EOiBUaGlzIGRlZmluZXMgYW4gYWx0ZXJuYXRpdmUgbmFtZSBmb3IgdGhlIHNpemUgcHJvcGVydHkgZm9yIHNvbWUgc2VydmVyIEFQSSByZXNwb25zZXMgKEZJTSkgdGhhdCBpcyBpbmNvbXBhdGlibGUgd2l0aCBqc29uMmNzdkFzeW5jXG4gICAgICAgICAgLi4uKHNpemUgIT09IHVuZGVmaW5lZFxuICAgICAgICAgICAgPyB7IFtVbnN1cHBvcnRlZEtleXNKc29uMkNzdkFzeW5jU2l6ZV06IHNpemUgfVxuICAgICAgICAgICAgOiB7fSksXG4gICAgICAgIH0pKTtcbiAgICAgICAgbGV0IGNzdiA9IGF3YWl0IGNvbnZlcnRlci5qc29uMmNzdkFzeW5jKGl0ZW1zQXJyYXksIG9wdGlvbnMpO1xuXG4gICAgICAgIHJldHVybiByZXNwb25zZS5vayh7XG4gICAgICAgICAgaGVhZGVyczogeyAnQ29udGVudC1UeXBlJzogJ3RleHQvY3N2JyB9LFxuICAgICAgICAgIGJvZHk6IGNzdixcbiAgICAgICAgfSk7XG4gICAgICB9IGVsc2UgaWYgKFxuICAgICAgICBvdXRwdXQgJiZcbiAgICAgICAgb3V0cHV0LmRhdGEgJiZcbiAgICAgICAgb3V0cHV0LmRhdGEuZGF0YSAmJlxuICAgICAgICAhb3V0cHV0LmRhdGEuZGF0YS50b3RhbF9hZmZlY3RlZF9pdGVtc1xuICAgICAgKSB7XG4gICAgICAgIHRocm93IG5ldyBFcnJvcignTm8gcmVzdWx0cycpO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgdGhyb3cgbmV3IEVycm9yKFxuICAgICAgICAgIGBBbiBlcnJvciBvY2N1cnJlZCBmZXRjaGluZyBkYXRhIGZyb20gdGhlIFdhenVoIEFQSSR7XG4gICAgICAgICAgICBvdXRwdXQgJiYgb3V0cHV0LmRhdGEgJiYgb3V0cHV0LmRhdGEuZGV0YWlsXG4gICAgICAgICAgICAgID8gYDogJHtvdXRwdXQuYm9keS5kZXRhaWx9YFxuICAgICAgICAgICAgICA6ICcnXG4gICAgICAgICAgfWAsXG4gICAgICAgICk7XG4gICAgICB9XG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgIGNvbnRleHQud2F6dWgubG9nZ2VyLmVycm9yKGVycm9yLm1lc3NhZ2UgfHwgZXJyb3IpO1xuICAgICAgcmV0dXJuIEVycm9yUmVzcG9uc2UoXG4gICAgICAgIGVycm9yLm1lc3NhZ2UgfHwgZXJyb3IsXG4gICAgICAgIDMwMzQsXG4gICAgICAgIEhUVFBfU1RBVFVTX0NPREVTLklOVEVSTkFMX1NFUlZFUl9FUlJPUixcbiAgICAgICAgcmVzcG9uc2UsXG4gICAgICApO1xuICAgIH1cbiAgfVxuXG4gIC8vIEdldCBkZSBsaXN0IG9mIGF2YWlsYWJsZSByZXF1ZXN0cyBpbiB0aGUgQVBJXG4gIGdldFJlcXVlc3RMaXN0KFxuICAgIGNvbnRleHQ6IFJlcXVlc3RIYW5kbGVyQ29udGV4dCxcbiAgICByZXF1ZXN0OiBPcGVuU2VhcmNoRGFzaGJvYXJkc1JlcXVlc3QsXG4gICAgcmVzcG9uc2U6IE9wZW5TZWFyY2hEYXNoYm9hcmRzUmVzcG9uc2VGYWN0b3J5LFxuICApIHtcbiAgICAvL1JlYWQgYSBzdGF0aWMgSlNPTiB1bnRpbCB0aGUgYXBpIGNhbGwgaGFzIGltcGxlbWVudGVkXG4gICAgcmV0dXJuIHJlc3BvbnNlLm9rKHtcbiAgICAgIGJvZHk6IGFwaVJlcXVlc3RMaXN0LFxuICAgIH0pO1xuICB9XG5cbiAgLyoqXG4gICAqIFRoaXMgZ2V0IHRoZSB3YXp1aCBzZXR1cCBzZXR0aW5nc1xuICAgKiBAcGFyYW0ge09iamVjdH0gY29udGV4dFxuICAgKiBAcGFyYW0ge09iamVjdH0gcmVxdWVzdFxuICAgKiBAcGFyYW0ge09iamVjdH0gcmVzcG9uc2VcbiAgICogQHJldHVybnMge09iamVjdH0gc2V0dXAgaW5mbyBvciBFcnJvclJlc3BvbnNlXG4gICAqL1xuICBhc3luYyBnZXRTZXR1cEluZm8oXG4gICAgY29udGV4dDogUmVxdWVzdEhhbmRsZXJDb250ZXh0LFxuICAgIHJlcXVlc3Q6IE9wZW5TZWFyY2hEYXNoYm9hcmRzUmVxdWVzdCxcbiAgICByZXNwb25zZTogT3BlblNlYXJjaERhc2hib2FyZHNSZXNwb25zZUZhY3RvcnksXG4gICkge1xuICAgIHRyeSB7XG4gICAgICByZXR1cm4gcmVzcG9uc2Uub2soe1xuICAgICAgICBib2R5OiB7XG4gICAgICAgICAgc3RhdHVzQ29kZTogSFRUUF9TVEFUVVNfQ09ERVMuT0ssXG4gICAgICAgICAgZGF0YToge1xuICAgICAgICAgICAgJ2FwcC12ZXJzaW9uJzogcGx1Z2luVmVyc2lvbixcbiAgICAgICAgICAgIHJldmlzaW9uOiBwbHVnaW5SZXZpc2lvbixcbiAgICAgICAgICAgIGNvbmZpZ3VyYXRpb25fZmlsZTogY29udGV4dC53YXp1aF9jb3JlLmNvbmZpZ3VyYXRpb24uc3RvcmUuZmlsZSxcbiAgICAgICAgICB9LFxuICAgICAgICB9LFxuICAgICAgfSk7XG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgIGNvbnRleHQud2F6dWgubG9nZ2VyLmVycm9yKGVycm9yLm1lc3NhZ2UgfHwgZXJyb3IpO1xuICAgICAgcmV0dXJuIEVycm9yUmVzcG9uc2UoXG4gICAgICAgIGBDb3VsZCBub3QgZ2V0IGRhdGEgZnJvbSB3YXp1aC12ZXJzaW9uIHJlZ2lzdHJ5IGR1ZSB0byAke1xuICAgICAgICAgIGVycm9yLm1lc3NhZ2UgfHwgZXJyb3JcbiAgICAgICAgfWAsXG4gICAgICAgIDQwMDUsXG4gICAgICAgIEhUVFBfU1RBVFVTX0NPREVTLklOVEVSTkFMX1NFUlZFUl9FUlJPUixcbiAgICAgICAgcmVzcG9uc2UsXG4gICAgICApO1xuICAgIH1cbiAgfVxuXG4gIC8qKlxuICAgKiBHZXRzIGN1c3RvbSBsb2dvcyBjb25maWd1cmF0aW9uIChwYXRoKVxuICAgKiBAcGFyYW0gY29udGV4dFxuICAgKiBAcGFyYW0gcmVxdWVzdFxuICAgKiBAcGFyYW0gcmVzcG9uc2VcbiAgICovXG4gIGFzeW5jIGdldEFwcExvZ29zKFxuICAgIGNvbnRleHQ6IFJlcXVlc3RIYW5kbGVyQ29udGV4dCxcbiAgICByZXF1ZXN0OiBPcGVuU2VhcmNoRGFzaGJvYXJkc1JlcXVlc3QsXG4gICAgcmVzcG9uc2U6IE9wZW5TZWFyY2hEYXNoYm9hcmRzUmVzcG9uc2VGYWN0b3J5LFxuICApIHtcbiAgICB0cnkge1xuICAgICAgY29uc3QgQVBQX0xPR08gPSAnY3VzdG9taXphdGlvbi5sb2dvLmFwcCc7XG4gICAgICBjb25zdCBIRUFMVEhDSEVDS19MT0dPID0gJ2N1c3RvbWl6YXRpb24ubG9nby5oZWFsdGhjaGVjayc7XG5cbiAgICAgIGNvbnN0IGxvZ29zID0ge1xuICAgICAgICBbQVBQX0xPR09dOlxuICAgICAgICAgIGF3YWl0IGNvbnRleHQud2F6dWhfY29yZS5jb25maWd1cmF0aW9uLmdldEN1c3RvbWl6YXRpb25TZXR0aW5nKFxuICAgICAgICAgICAgQVBQX0xPR08sXG4gICAgICAgICAgKSxcbiAgICAgICAgW0hFQUxUSENIRUNLX0xPR09dOlxuICAgICAgICAgIGF3YWl0IGNvbnRleHQud2F6dWhfY29yZS5jb25maWd1cmF0aW9uLmdldEN1c3RvbWl6YXRpb25TZXR0aW5nKFxuICAgICAgICAgICAgSEVBTFRIQ0hFQ0tfTE9HTyxcbiAgICAgICAgICApLFxuICAgICAgfTtcblxuICAgICAgcmV0dXJuIHJlc3BvbnNlLm9rKHtcbiAgICAgICAgYm9keTogeyBsb2dvcyB9LFxuICAgICAgfSk7XG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgIGNvbnRleHQud2F6dWgubG9nZ2VyLmVycm9yKGVycm9yLm1lc3NhZ2UgfHwgZXJyb3IpO1xuICAgICAgcmV0dXJuIEVycm9yUmVzcG9uc2UoXG4gICAgICAgIGVycm9yLm1lc3NhZ2UgfHwgZXJyb3IsXG4gICAgICAgIDMwMzUsXG4gICAgICAgIEhUVFBfU1RBVFVTX0NPREVTLklOVEVSTkFMX1NFUlZFUl9FUlJPUixcbiAgICAgICAgcmVzcG9uc2UsXG4gICAgICApO1xuICAgIH1cbiAgfVxufVxuIl0sIm1hcHBpbmdzIjoiOzs7Ozs7QUFhQSxJQUFBQSxjQUFBLEdBQUFDLE9BQUE7QUFDQSxJQUFBQyxTQUFBLEdBQUFDLHNCQUFBLENBQUFGLE9BQUE7QUFDQSxJQUFBRyxrQkFBQSxHQUFBSCxPQUFBO0FBSUEsSUFBQUkscUJBQUEsR0FBQUosT0FBQTtBQUNBLElBQUFLLFVBQUEsR0FBQUgsc0JBQUEsQ0FBQUYsT0FBQTtBQUNBLElBQUFNLFVBQUEsR0FBQU4sT0FBQTtBQUNBLElBQUFPLE1BQUEsR0FBQVAsT0FBQTtBQUNBLElBQUFRLFVBQUEsR0FBQU4sc0JBQUEsQ0FBQUYsT0FBQTtBQU1BLElBQUFTLE9BQUEsR0FBQVQsT0FBQTtBQUNBLElBQUFVLFFBQUEsR0FBQVYsT0FBQTtBQUlBLElBQUFXLG9CQUFBLEdBQUFYLE9BQUE7QUFBbUUsU0FBQUUsdUJBQUFVLENBQUEsV0FBQUEsQ0FBQSxJQUFBQSxDQUFBLENBQUFDLFVBQUEsR0FBQUQsQ0FBQSxLQUFBRSxPQUFBLEVBQUFGLENBQUE7QUFsQ25FO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7O0FBd0JPLE1BQU1HLFlBQVksQ0FBQztFQUN4QkMsV0FBV0EsQ0FBQSxFQUFHLENBQUM7RUFFZixNQUFNQyxRQUFRQSxDQUNaQyxPQUE4QixFQUM5QkMsT0FBb0MsRUFDcENDLFFBQTZDLEVBQzdDO0lBQ0EsSUFBSTtNQUNGLE1BQU07UUFBRUMsS0FBSztRQUFFQztNQUFPLENBQUMsR0FBR0gsT0FBTyxDQUFDSSxJQUFJO01BQ3RDLE1BQU07UUFBRUM7TUFBUyxDQUFDLEdBQUcsTUFBTU4sT0FBTyxDQUFDTyxLQUFLLENBQUNDLFFBQVEsQ0FBQ0MsY0FBYyxDQUM5RFIsT0FBTyxFQUNQRCxPQUNGLENBQUM7TUFDRCxJQUNFLENBQUNHLEtBQUssSUFDTkYsT0FBTyxDQUFDUyxPQUFPLENBQUNDLE1BQU0sSUFDdEJMLFFBQVEsS0FDTk0sa0JBQWtCLENBQ2hCLElBQUFDLDRCQUFvQixFQUFDWixPQUFPLENBQUNTLE9BQU8sQ0FBQ0MsTUFBTSxFQUFFLFNBQVMsQ0FDeEQsQ0FBQyxJQUNIUCxNQUFNLEtBQUssSUFBQVMsNEJBQW9CLEVBQUNaLE9BQU8sQ0FBQ1MsT0FBTyxDQUFDQyxNQUFNLEVBQUUsUUFBUSxDQUFDLEVBQ2pFO1FBQ0EsTUFBTUcsT0FBTyxHQUFHLElBQUFELDRCQUFvQixFQUNsQ1osT0FBTyxDQUFDUyxPQUFPLENBQUNDLE1BQU0sRUFDdEIsVUFDRixDQUFDO1FBQ0QsSUFBSUcsT0FBTyxFQUFFO1VBQ1gsSUFBSTtZQUNGO1lBQ0EsTUFBTUMsWUFBWSxHQUFHLElBQUFDLGtCQUFTLEVBQUNGLE9BQU8sQ0FBQztZQUN2QyxNQUFNRyxjQUFjLEdBQUdGLFlBQVksQ0FBQ0csR0FBRyxHQUFHQyxJQUFJLENBQUNDLEdBQUcsQ0FBQyxDQUFDLEdBQUcsSUFBSTtZQUMzRCxJQUFJTixPQUFPLElBQUlHLGNBQWMsR0FBRyxDQUFDLEVBQUU7Y0FDakMsT0FBT2YsUUFBUSxDQUFDbUIsRUFBRSxDQUFDO2dCQUNqQmhCLElBQUksRUFBRTtrQkFBRWlCLEtBQUssRUFBRVI7Z0JBQVE7Y0FDekIsQ0FBQyxDQUFDO1lBQ0o7VUFDRixDQUFDLENBQUMsT0FBT1MsS0FBSyxFQUFFO1lBQ2R2QixPQUFPLENBQUNPLEtBQUssQ0FBQ2lCLE1BQU0sQ0FBQ0QsS0FBSyxDQUN2Qiw0Q0FBMkNBLEtBQUssQ0FBQ0UsT0FBUSxFQUM1RCxDQUFDO1VBQ0g7UUFDRjtNQUNGO01BQ0EsTUFBTUgsS0FBSyxHQUFHLE1BQU10QixPQUFPLENBQUNPLEtBQUssQ0FBQ21CLEdBQUcsQ0FBQ0MsTUFBTSxDQUFDQyxhQUFhLENBQUNDLFlBQVksQ0FDckV6QixNQUNGLENBQUM7TUFFRCxJQUFJMEIsVUFBVSxHQUFHLEVBQUU7TUFDbkIsSUFBSTlCLE9BQU8sQ0FBQ08sS0FBSyxDQUFDd0IsTUFBTSxDQUFDQyxJQUFJLENBQUNDLFFBQVEsS0FBSyxPQUFPLEVBQUU7UUFDbERILFVBQVUsR0FBRyxTQUFTO01BQ3hCO01BQ0EsTUFBTUksV0FBVyxHQUFHQyxrQkFBa0IsQ0FBQzdCLFFBQVEsQ0FBQztNQUNoRCxPQUFPSixRQUFRLENBQUNtQixFQUFFLENBQUM7UUFDakJYLE9BQU8sRUFBRTtVQUNQLFlBQVksRUFBRSxDQUNYLFlBQVdZLEtBQU0sbUJBQWtCUSxVQUFXLEVBQUMsRUFDL0MsV0FBVUksV0FBWSxtQkFBa0JKLFVBQVcsRUFBQyxFQUNwRCxVQUFTMUIsTUFBTyxrQkFBaUI7UUFFdEMsQ0FBQztRQUNEQyxJQUFJLEVBQUU7VUFBRWlCO1FBQU07TUFDaEIsQ0FBQyxDQUFDO0lBQ0osQ0FBQyxDQUFDLE9BQU9DLEtBQUssRUFBRTtNQUFBLElBQUFhLGVBQUE7TUFDZCxNQUFNQyxZQUFZLEdBQUksMENBQXlDLElBQUFDLHdDQUFtQixFQUNoRmYsS0FDRixDQUFFLEVBQUM7TUFDSHZCLE9BQU8sQ0FBQ08sS0FBSyxDQUFDaUIsTUFBTSxDQUFDRCxLQUFLLENBQUNjLFlBQVksQ0FBQztNQUN4QyxPQUFPLElBQUFFLDRCQUFhLEVBQ2xCRixZQUFZLEVBQ1osSUFBSSxFQUNKLENBQUFkLEtBQUssYUFBTEEsS0FBSyxnQkFBQWEsZUFBQSxHQUFMYixLQUFLLENBQUVyQixRQUFRLGNBQUFrQyxlQUFBLHVCQUFmQSxlQUFBLENBQWlCSSxNQUFNLEtBQUlDLDRCQUFpQixDQUFDQyxxQkFBcUIsRUFDbEV4QyxRQUNGLENBQUM7SUFDSDtFQUNGOztFQUVBO0FBQ0Y7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0VBQ0UsTUFBTXlDLGNBQWNBLENBQ2xCM0MsT0FBOEIsRUFDOUJDLE9BQW9DLEVBQ3BDQyxRQUE2QyxFQUM3QztJQUNBLElBQUk7TUFDRjtNQUNBLE1BQU0wQyxFQUFFLEdBQUczQyxPQUFPLENBQUNJLElBQUksQ0FBQ3VDLEVBQUU7TUFDMUI1QyxPQUFPLENBQUNPLEtBQUssQ0FBQ2lCLE1BQU0sQ0FBQ3FCLEtBQUssQ0FBRSxrQ0FBaUNELEVBQUcsRUFBQyxDQUFDO01BQ2xFLE1BQU1FLFdBQVcsR0FBRyxNQUFNOUMsT0FBTyxDQUFDK0MsVUFBVSxDQUFDQyxXQUFXLENBQUNDLEdBQUcsQ0FBQ0wsRUFBRSxFQUFFO1FBQy9ETSxlQUFlLEVBQUU7TUFDbkIsQ0FBQyxDQUFDO01BQ0YsTUFBTXhCLEdBQUcsR0FBRztRQUFFLEdBQUdvQjtNQUFZLENBQUM7TUFDOUI5QyxPQUFPLENBQUNPLEtBQUssQ0FBQ2lCLE1BQU0sQ0FBQ3FCLEtBQUssQ0FDdkIseUJBQXdCTSxJQUFJLENBQUNDLFNBQVMsQ0FBQzFCLEdBQUcsQ0FBRSxFQUMvQyxDQUFDO01BRUQxQixPQUFPLENBQUNPLEtBQUssQ0FBQ2lCLE1BQU0sQ0FBQ3FCLEtBQUssQ0FBRSxHQUFFRCxFQUFHLFNBQVEsQ0FBQzs7TUFFMUM7TUFDQSxNQUFNUyxtQkFBbUIsR0FDdkIsTUFBTXJELE9BQU8sQ0FBQ08sS0FBSyxDQUFDbUIsR0FBRyxDQUFDQyxNQUFNLENBQUMyQixjQUFjLENBQUNyRCxPQUFPLENBQ25ELEtBQUssRUFDSixlQUFjLEVBQ2YsQ0FBQyxDQUFDLEVBQ0Y7UUFBRXNELFNBQVMsRUFBRVgsRUFBRTtRQUFFWSxZQUFZLEVBQUU7TUFBSyxDQUN0QyxDQUFDOztNQUVIO01BQ0EsSUFBSSxJQUFJLENBQUNDLG1CQUFtQixDQUFDekQsT0FBTyxFQUFFcUQsbUJBQW1CLENBQUMsRUFBRTtRQUMxRCxPQUFPLElBQUFkLDRCQUFhLEVBQ2pCLGVBQ0NjLG1CQUFtQixDQUFDSyxJQUFJLENBQUNDLE1BQU0sSUFBSSxzQkFDcEMsRUFBQyxFQUNGLElBQUksRUFDSmxCLDRCQUFpQixDQUFDbUIsbUJBQW1CLEVBQ3JDMUQsUUFDRixDQUFDO01BQ0g7O01BRUE7TUFDQSxJQUFJO1FBQ0YsTUFBTTtVQUFFc0MsTUFBTTtVQUFFcUIsT0FBTztVQUFFQyxJQUFJO1VBQUVDO1FBQVEsQ0FBQyxHQUN0QyxNQUFNL0QsT0FBTyxDQUFDK0MsVUFBVSxDQUFDQyxXQUFXLENBQUNnQixxQkFBcUIsQ0FDeERsQixXQUFXLEVBQ1g7VUFDRW1CLFVBQVUsRUFBRTtRQUNkLENBQ0YsQ0FBQztRQUVIdkMsR0FBRyxDQUFDd0MsWUFBWSxHQUFHO1VBQUUxQixNQUFNO1VBQUVxQixPQUFPO1VBQUVDLElBQUk7VUFBRUM7UUFBUSxDQUFDO1FBRXJELE9BQU83RCxRQUFRLENBQUNtQixFQUFFLENBQUM7VUFDakJoQixJQUFJLEVBQUU7WUFDSjhELFVBQVUsRUFBRTFCLDRCQUFpQixDQUFDMkIsRUFBRTtZQUNoQ1YsSUFBSSxFQUFFaEMsR0FBRztZQUNUMkMsU0FBUyxFQUFFcEUsT0FBTyxDQUFDSSxJQUFJLENBQUNnRSxTQUFTLElBQUk7VUFDdkM7UUFDRixDQUFDLENBQUM7TUFDSixDQUFDLENBQUMsT0FBTzlDLEtBQUssRUFBRTtRQUNkO1FBQ0EsTUFBTSxJQUFJK0MsS0FBSyxDQUNiakIsbUJBQW1CLENBQUNLLElBQUksQ0FBQ0MsTUFBTSxJQUM1QixHQUFFakMsR0FBRyxDQUFDNkMsR0FBSSxJQUFHN0MsR0FBRyxDQUFDOEMsSUFBSyxpQkFDM0IsQ0FBQztNQUNIO0lBQ0YsQ0FBQyxDQUFDLE9BQU9qRCxLQUFLLEVBQUU7TUFDZCxJQUFJQSxLQUFLLENBQUNrRCxJQUFJLEtBQUssUUFBUSxFQUFFO1FBQzNCLE9BQU92RSxRQUFRLENBQUNtQixFQUFFLENBQUM7VUFDakJoQixJQUFJLEVBQUU7WUFDSjhELFVBQVUsRUFBRTFCLDRCQUFpQixDQUFDMkIsRUFBRTtZQUNoQ1YsSUFBSSxFQUFFO2NBQUVnQixTQUFTLEVBQUU7WUFBSztVQUMxQjtRQUNGLENBQUMsQ0FBQztNQUNKLENBQUMsTUFBTSxJQUFJbkQsS0FBSyxDQUFDa0QsSUFBSSxLQUFLLGNBQWMsRUFBRTtRQUN4QyxPQUFPdkUsUUFBUSxDQUFDbUIsRUFBRSxDQUFDO1VBQ2pCaEIsSUFBSSxFQUFFO1lBQ0o4RCxVQUFVLEVBQUUxQiw0QkFBaUIsQ0FBQzJCLEVBQUU7WUFDaENWLElBQUksRUFBRTtjQUFFZ0IsU0FBUyxFQUFFO1lBQUs7VUFDMUI7UUFDRixDQUFDLENBQUM7TUFDSixDQUFDLE1BQU07UUFBQSxJQUFBQyxnQkFBQTtRQUNMLElBQUk7VUFDRixNQUFNQyxJQUFJLEdBQUcsTUFBTTVFLE9BQU8sQ0FBQytDLFVBQVUsQ0FBQ0MsV0FBVyxDQUFDQyxHQUFHLENBQUMsQ0FBQztVQUN2RCxLQUFLLE1BQU12QixHQUFHLElBQUlrRCxJQUFJLEVBQUU7WUFDdEIsSUFBSTtjQUNGLE1BQU07Z0JBQUVoQztjQUFHLENBQUMsR0FBR2xCLEdBQUc7Y0FFbEIsTUFBTTJCLG1CQUFtQixHQUN2QixNQUFNckQsT0FBTyxDQUFDTyxLQUFLLENBQUNtQixHQUFHLENBQUNDLE1BQU0sQ0FBQzJCLGNBQWMsQ0FBQ3JELE9BQU8sQ0FDbkQsS0FBSyxFQUNKLGVBQWMsRUFDZixDQUFDLENBQUMsRUFDRjtnQkFBRXNELFNBQVMsRUFBRVg7Y0FBRyxDQUNsQixDQUFDO2NBRUgsSUFBSSxJQUFJLENBQUNhLG1CQUFtQixDQUFDekQsT0FBTyxFQUFFcUQsbUJBQW1CLENBQUMsRUFBRTtnQkFDMUQsT0FBTyxJQUFBZCw0QkFBYSxFQUNqQixlQUNDckMsUUFBUSxDQUFDd0QsSUFBSSxDQUFDQyxNQUFNLElBQUksc0JBQ3pCLEVBQUMsRUFDRixJQUFJLEVBQ0psQiw0QkFBaUIsQ0FBQ21CLG1CQUFtQixFQUNyQzFELFFBQ0YsQ0FBQztjQUNIO2NBQ0EsSUFBSW1ELG1CQUFtQixDQUFDYixNQUFNLEtBQUtDLDRCQUFpQixDQUFDMkIsRUFBRSxFQUFFO2dCQUN2RG5FLE9BQU8sQ0FBQ0ksSUFBSSxDQUFDdUMsRUFBRSxHQUFHQSxFQUFFO2dCQUNwQjNDLE9BQU8sQ0FBQ0ksSUFBSSxDQUFDZ0UsU0FBUyxHQUFHekIsRUFBRTtnQkFDM0IsT0FBTyxNQUFNLElBQUksQ0FBQ0QsY0FBYyxDQUFDM0MsT0FBTyxFQUFFQyxPQUFPLEVBQUVDLFFBQVEsQ0FBQztjQUM5RDtZQUNGLENBQUMsQ0FBQyxPQUFPcUIsS0FBSyxFQUFFLENBQUMsQ0FBQyxDQUFDO1VBQ3JCO1FBQ0YsQ0FBQyxDQUFDLE9BQU9BLEtBQUssRUFBRTtVQUFBLElBQUFzRCxnQkFBQTtVQUNkN0UsT0FBTyxDQUFDTyxLQUFLLENBQUNpQixNQUFNLENBQUNELEtBQUssQ0FBQ0EsS0FBSyxDQUFDRSxPQUFPLElBQUlGLEtBQUssQ0FBQztVQUNsRCxPQUFPLElBQUFnQiw0QkFBYSxFQUNsQmhCLEtBQUssQ0FBQ0UsT0FBTyxJQUFJRixLQUFLLEVBQ3RCLElBQUksRUFDSixDQUFBQSxLQUFLLGFBQUxBLEtBQUssZ0JBQUFzRCxnQkFBQSxHQUFMdEQsS0FBSyxDQUFFckIsUUFBUSxjQUFBMkUsZ0JBQUEsdUJBQWZBLGdCQUFBLENBQWlCckMsTUFBTSxLQUFJQyw0QkFBaUIsQ0FBQ0MscUJBQXFCLEVBQ2xFeEMsUUFDRixDQUFDO1FBQ0g7UUFDQUYsT0FBTyxDQUFDTyxLQUFLLENBQUNpQixNQUFNLENBQUNELEtBQUssQ0FBQ0EsS0FBSyxDQUFDRSxPQUFPLElBQUlGLEtBQUssQ0FBQztRQUNsRCxPQUFPLElBQUFnQiw0QkFBYSxFQUNsQmhCLEtBQUssQ0FBQ0UsT0FBTyxJQUFJRixLQUFLLEVBQ3RCLElBQUksRUFDSixDQUFBQSxLQUFLLGFBQUxBLEtBQUssZ0JBQUFvRCxnQkFBQSxHQUFMcEQsS0FBSyxDQUFFckIsUUFBUSxjQUFBeUUsZ0JBQUEsdUJBQWZBLGdCQUFBLENBQWlCbkMsTUFBTSxLQUFJQyw0QkFBaUIsQ0FBQ0MscUJBQXFCLEVBQ2xFeEMsUUFDRixDQUFDO01BQ0g7SUFDRjtFQUNGOztFQUVBO0FBQ0Y7QUFDQTtBQUNBO0VBQ0U0RSxzQkFBc0JBLENBQUN6RSxJQUFJLEVBQUU7SUFDM0IsSUFBSSxFQUFFLFVBQVUsSUFBSUEsSUFBSSxDQUFDLEVBQUU7TUFDekIsT0FBTyw2QkFBNkI7SUFDdEM7SUFFQSxJQUFJLEVBQUUsVUFBVSxJQUFJQSxJQUFJLENBQUMsSUFBSSxFQUFFLElBQUksSUFBSUEsSUFBSSxDQUFDLEVBQUU7TUFDNUMsT0FBTyw2QkFBNkI7SUFDdEM7SUFFQSxJQUFJLEVBQUUsS0FBSyxJQUFJQSxJQUFJLENBQUMsRUFBRTtNQUNwQixPQUFPLHdCQUF3QjtJQUNqQztJQUVBLElBQUksRUFBRSxNQUFNLElBQUlBLElBQUksQ0FBQyxFQUFFO01BQ3JCLE9BQU8seUJBQXlCO0lBQ2xDO0lBRUEsSUFBSSxDQUFDQSxJQUFJLENBQUNrRSxHQUFHLENBQUNRLFFBQVEsQ0FBQyxVQUFVLENBQUMsSUFBSSxDQUFDMUUsSUFBSSxDQUFDa0UsR0FBRyxDQUFDUSxRQUFRLENBQUMsU0FBUyxDQUFDLEVBQUU7TUFDbkUsT0FBTyxnQkFBZ0I7SUFDekI7SUFFQSxPQUFPLEtBQUs7RUFDZDs7RUFFQTtBQUNGO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtFQUNFLE1BQU1DLFFBQVFBLENBQ1poRixPQUE4QixFQUM5QkMsT0FBb0MsRUFDcENDLFFBQTZDLEVBQzdDO0lBQ0EsSUFBSTtNQUNGLElBQUkrRSxZQUFZLEdBQUcsSUFBSTtNQUN2QjtNQUNBO01BQ0FqRixPQUFPLENBQUNPLEtBQUssQ0FBQ2lCLE1BQU0sQ0FBQ3FCLEtBQUssQ0FBRSxHQUFFNUMsT0FBTyxDQUFDSSxJQUFJLENBQUN1QyxFQUFHLFdBQVUsQ0FBQztNQUN6RDtNQUNBLE1BQU1jLElBQUksR0FBRyxNQUFNMUQsT0FBTyxDQUFDK0MsVUFBVSxDQUFDQyxXQUFXLENBQUNDLEdBQUcsQ0FBQ2hELE9BQU8sQ0FBQ0ksSUFBSSxDQUFDdUMsRUFBRSxFQUFFO1FBQ3JFTSxlQUFlLEVBQUU7TUFDbkIsQ0FBQyxDQUFDO01BQ0YsSUFBSVEsSUFBSSxFQUFFO1FBQ1J1QixZQUFZLEdBQUd2QixJQUFJO01BQ3JCLENBQUMsTUFBTTtRQUNMLE1BQU1yQixZQUFZLEdBQUkscUNBQW9DcEMsT0FBTyxDQUFDSSxJQUFJLENBQUN1QyxFQUFHLGdCQUFlO1FBQ3pGNUMsT0FBTyxDQUFDTyxLQUFLLENBQUNpQixNQUFNLENBQUNxQixLQUFLLENBQUNSLFlBQVksQ0FBQztRQUN4QyxPQUFPLElBQUFFLDRCQUFhLEVBQ2xCRixZQUFZLEVBQ1osSUFBSSxFQUNKSSw0QkFBaUIsQ0FBQ0MscUJBQXFCLEVBQ3ZDeEMsUUFDRixDQUFDO01BQ0g7TUFDQSxNQUFNZ0YsT0FBTyxHQUFHO1FBQUUzQixTQUFTLEVBQUV0RCxPQUFPLENBQUNJLElBQUksQ0FBQ3VDO01BQUcsQ0FBQztNQUM5QyxJQUFJM0MsT0FBTyxDQUFDSSxJQUFJLENBQUNtRCxZQUFZLEVBQUU7UUFDN0IwQixPQUFPLENBQUMsY0FBYyxDQUFDLEdBQUdqRixPQUFPLENBQUNJLElBQUksQ0FBQ21ELFlBQVk7TUFDckQ7TUFDQSxJQUFJSCxtQkFBbUI7TUFDdkIsSUFBSTtRQUNGQSxtQkFBbUIsR0FDakIsTUFBTXJELE9BQU8sQ0FBQ08sS0FBSyxDQUFDbUIsR0FBRyxDQUFDQyxNQUFNLENBQUMyQixjQUFjLENBQUNyRCxPQUFPLENBQ25ELEtBQUssRUFDSixlQUFjLEVBQ2YsQ0FBQyxDQUFDLEVBQ0ZpRixPQUNGLENBQUM7TUFDTCxDQUFDLENBQUMsT0FBTzNELEtBQUssRUFBRTtRQUFBLElBQUE0RCxnQkFBQSxFQUFBQyxnQkFBQTtRQUNkLE9BQU8sSUFBQTdDLDRCQUFhLEVBQ2pCLGVBQ0MsRUFBQTRDLGdCQUFBLEdBQUE1RCxLQUFLLENBQUNyQixRQUFRLGNBQUFpRixnQkFBQSxnQkFBQUEsZ0JBQUEsR0FBZEEsZ0JBQUEsQ0FBZ0J6QixJQUFJLGNBQUF5QixnQkFBQSx1QkFBcEJBLGdCQUFBLENBQXNCeEIsTUFBTSxLQUFJLHNCQUNqQyxFQUFDLEVBQ0YsSUFBSSxFQUNKLENBQUFwQyxLQUFLLGFBQUxBLEtBQUssZ0JBQUE2RCxnQkFBQSxHQUFMN0QsS0FBSyxDQUFFckIsUUFBUSxjQUFBa0YsZ0JBQUEsdUJBQWZBLGdCQUFBLENBQWlCNUMsTUFBTSxLQUFJQyw0QkFBaUIsQ0FBQ21CLG1CQUFtQixFQUNoRTFELFFBQ0YsQ0FBQztNQUNIO01BQ0FGLE9BQU8sQ0FBQ08sS0FBSyxDQUFDaUIsTUFBTSxDQUFDcUIsS0FBSyxDQUFFLEdBQUU1QyxPQUFPLENBQUNJLElBQUksQ0FBQ3VDLEVBQUcsd0JBQXVCLENBQUM7TUFDdEUsSUFDRVMsbUJBQW1CLENBQUNiLE1BQU0sS0FBS0MsNEJBQWlCLENBQUMyQixFQUFFLElBQ25EZixtQkFBbUIsQ0FBQ0ssSUFBSSxFQUN4QjtRQUFBLElBQUEyQixxQkFBQTtRQUNBO1FBQ0EsS0FBQUEscUJBQUEsR0FBSWhDLG1CQUFtQixDQUFDSyxJQUFJLGNBQUEyQixxQkFBQSxnQkFBQUEscUJBQUEsR0FBeEJBLHFCQUFBLENBQTBCM0IsSUFBSSxjQUFBMkIscUJBQUEsZ0JBQUFBLHFCQUFBLEdBQTlCQSxxQkFBQSxDQUFnQ0MsY0FBYyxjQUFBRCxxQkFBQSxnQkFBQUEscUJBQUEsR0FBOUNBLHFCQUFBLENBQWlELENBQUMsQ0FBQyxjQUFBQSxxQkFBQSxlQUFuREEscUJBQUEsQ0FBcURFLElBQUksRUFBRTtVQUM3RCxNQUFNQSxJQUFJLEdBQUdsQyxtQkFBbUIsQ0FBQ0ssSUFBSSxDQUFDQSxJQUFJLENBQUM0QixjQUFjLENBQUMsQ0FBQyxDQUFDLENBQUNDLElBQUk7VUFDakUsTUFBTUMsTUFBTSxHQUNWLE1BQU14RixPQUFPLENBQUMrQyxVQUFVLENBQUNDLFdBQVcsQ0FBQ2dCLHFCQUFxQixDQUFDTixJQUFJLENBQUM7VUFDbEUsT0FBT3hELFFBQVEsQ0FBQ21CLEVBQUUsQ0FBQztZQUNqQmhCLElBQUksRUFBRTtjQUNKLEdBQUdtRixNQUFNO2NBQ1REO1lBQ0Y7VUFDRixDQUFDLENBQUM7UUFDSixDQUFDLE1BQU07VUFDTHZGLE9BQU8sQ0FBQ08sS0FBSyxDQUFDaUIsTUFBTSxDQUFDaUUsSUFBSSxDQUFDLCtCQUErQixDQUFDO1VBQzFELE9BQU8sSUFBQWxELDRCQUFhLEVBQ2xCLCtCQUErQixFQUMvQixJQUFJLEVBQ0pFLDRCQUFpQixDQUFDQyxxQkFBcUIsRUFDdkN4QyxRQUNGLENBQUM7UUFDSDtNQUNGO0lBQ0YsQ0FBQyxDQUFDLE9BQU9xQixLQUFLLEVBQUU7TUFBQSxJQUFBbUUsZ0JBQUE7TUFDZDFGLE9BQU8sQ0FBQ08sS0FBSyxDQUFDaUIsTUFBTSxDQUFDaUUsSUFBSSxDQUFDbEUsS0FBSyxDQUFDRSxPQUFPLElBQUlGLEtBQUssQ0FBQztNQUVqRCxJQUNFQSxLQUFLLElBQ0xBLEtBQUssQ0FBQ3JCLFFBQVEsSUFDZHFCLEtBQUssQ0FBQ3JCLFFBQVEsQ0FBQ3NDLE1BQU0sS0FBS0MsNEJBQWlCLENBQUNrRCxZQUFZLEVBQ3hEO1FBQ0EsT0FBTyxJQUFBcEQsNEJBQWEsRUFDakIsOENBQTZDaEIsS0FBSyxDQUFDckIsUUFBUSxDQUFDd0QsSUFBSSxDQUFDakMsT0FBUSxFQUFDLEVBQzNFZ0IsNEJBQWlCLENBQUNrRCxZQUFZLEVBQzlCbEQsNEJBQWlCLENBQUNrRCxZQUFZLEVBQzlCekYsUUFDRixDQUFDO01BQ0g7TUFDQSxJQUNFcUIsS0FBSyxJQUNMQSxLQUFLLENBQUNyQixRQUFRLElBQ2RxQixLQUFLLENBQUNyQixRQUFRLENBQUN3RCxJQUFJLElBQ25CbkMsS0FBSyxDQUFDckIsUUFBUSxDQUFDd0QsSUFBSSxDQUFDQyxNQUFNLEVBQzFCO1FBQ0EsT0FBTyxJQUFBcEIsNEJBQWEsRUFDbEJoQixLQUFLLENBQUNyQixRQUFRLENBQUN3RCxJQUFJLENBQUNDLE1BQU0sRUFDMUJwQyxLQUFLLENBQUNyQixRQUFRLENBQUNzQyxNQUFNLElBQUlDLDRCQUFpQixDQUFDbUIsbUJBQW1CLEVBQzlEckMsS0FBSyxDQUFDckIsUUFBUSxDQUFDc0MsTUFBTSxJQUFJQyw0QkFBaUIsQ0FBQ21CLG1CQUFtQixFQUM5RDFELFFBQ0YsQ0FBQztNQUNIO01BQ0EsSUFBSXFCLEtBQUssQ0FBQ2tELElBQUksS0FBSyxRQUFRLEVBQUU7UUFDM0IsT0FBTyxJQUFBbEMsNEJBQWEsRUFDbEIsaURBQWlELEVBQ2pELElBQUksRUFDSkUsNEJBQWlCLENBQUNtRCxXQUFXLEVBQzdCMUYsUUFDRixDQUFDO01BQ0g7TUFDQSxPQUFPLElBQUFxQyw0QkFBYSxFQUNsQmhCLEtBQUssQ0FBQ0UsT0FBTyxJQUFJRixLQUFLLEVBQ3RCLElBQUksRUFDSixDQUFBQSxLQUFLLGFBQUxBLEtBQUssZ0JBQUFtRSxnQkFBQSxHQUFMbkUsS0FBSyxDQUFFckIsUUFBUSxjQUFBd0YsZ0JBQUEsdUJBQWZBLGdCQUFBLENBQWlCbEQsTUFBTSxLQUFJQyw0QkFBaUIsQ0FBQ0MscUJBQXFCLEVBQ2xFeEMsUUFDRixDQUFDO0lBQ0g7RUFDRjtFQUVBdUQsbUJBQW1CQSxDQUFDekQsT0FBTyxFQUFFRSxRQUFRLEVBQUU7SUFDckMsSUFBSUEsUUFBUSxDQUFDc0MsTUFBTSxLQUFLQyw0QkFBaUIsQ0FBQzJCLEVBQUUsRUFBRTtNQUM1QztNQUNBLE1BQU15QixnQkFBZ0IsR0FBRyxDQUFDLElBQUksRUFBRSxJQUFJLEVBQUUsSUFBSSxFQUFFLElBQUksRUFBRSxJQUFJLENBQUM7TUFDdkQsTUFBTXJELE1BQU0sR0FBRyxDQUFDdEMsUUFBUSxDQUFDd0QsSUFBSSxJQUFJLENBQUMsQ0FBQyxFQUFFbEIsTUFBTSxJQUFJLENBQUM7TUFDaEQsTUFBTXNELE1BQU0sR0FBR0QsZ0JBQWdCLENBQUNkLFFBQVEsQ0FBQ3ZDLE1BQU0sQ0FBQztNQUVoRHNELE1BQU0sSUFDSjlGLE9BQU8sQ0FBQ08sS0FBSyxDQUFDaUIsTUFBTSxDQUFDRCxLQUFLLENBQ3hCLHNEQUNGLENBQUM7TUFFSCxPQUFPdUUsTUFBTTtJQUNmO0lBQ0EsT0FBTyxLQUFLO0VBQ2Q7O0VBRUE7QUFDRjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0VBQ0UsTUFBTUMsWUFBWUEsQ0FBQy9GLE9BQU8sRUFBRTBCLEdBQUcsRUFBRXNFLElBQUksRUFBRTtJQUNyQyxJQUFJO01BQ0YsTUFBTTlGLFFBQVEsR0FBRyxNQUFNRixPQUFPLENBQUNPLEtBQUssQ0FBQ21CLEdBQUcsQ0FBQ0MsTUFBTSxDQUFDMkIsY0FBYyxDQUFDckQsT0FBTyxDQUNwRSxLQUFLLEVBQ0wsaUJBQWlCLEVBQ2pCLENBQUMsQ0FBQyxFQUNGO1FBQUVzRCxTQUFTLEVBQUU3QixHQUFHLENBQUNrQjtNQUFHLENBQ3RCLENBQUM7TUFFRCxNQUFNcUQsT0FBTyxHQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMvRixRQUFRLElBQUksQ0FBQyxDQUFDLEVBQUV3RCxJQUFJLElBQUksQ0FBQyxDQUFDLEVBQUVBLElBQUksSUFBSSxDQUFDLENBQUMsRUFBRTRCLGNBQWMsSUFBSSxFQUFFLEVBQUUsQ0FBQyxDQUFDLElBQ3BFLENBQUMsQ0FBQztNQUVKLE1BQU1ZLFNBQVMsR0FDYixDQUFDLENBQUN4RSxHQUFHLElBQUksQ0FBQyxDQUFDLEVBQUV3QyxZQUFZLElBQUksQ0FBQyxDQUFDLEVBQUUxQixNQUFNLEtBQUssU0FBUyxJQUNyRCxPQUFPeUQsT0FBTyxDQUFDLGdCQUFnQixDQUFDLEtBQUssV0FBVztNQUNsRCxNQUFNRSxhQUFhLEdBQUcsT0FBT0YsT0FBTyxDQUFDLFVBQVUsQ0FBQyxLQUFLLFdBQVc7TUFFaEUsTUFBTUcsS0FBSyxHQUFHSCxPQUFPLENBQUMsYUFBYSxDQUFDLEtBQUssU0FBUztNQUNsRCxNQUFNSSxRQUFRLEdBQUdKLE9BQU8sQ0FBQyxnQkFBZ0IsQ0FBQyxLQUFLLFNBQVM7TUFDeEQsTUFBTUssT0FBTyxHQUFHSCxhQUFhLEdBQUdGLE9BQU8sQ0FBQyxVQUFVLENBQUMsS0FBSyxTQUFTLEdBQUcsSUFBSTtNQUN4RSxNQUFNTSxRQUFRLEdBQUdMLFNBQVMsR0FDdEJELE9BQU8sQ0FBQyxnQkFBZ0IsQ0FBQyxLQUFLLFNBQVMsR0FDdkMsSUFBSTtNQUVSLE1BQU1PLE9BQU8sR0FBR0osS0FBSyxJQUFJQyxRQUFRLElBQUlDLE9BQU8sSUFBSUMsUUFBUTtNQUV4REMsT0FBTyxJQUFJeEcsT0FBTyxDQUFDTyxLQUFLLENBQUNpQixNQUFNLENBQUNxQixLQUFLLENBQUMsZ0JBQWdCLENBQUM7TUFFdkQsSUFBSW1ELElBQUksS0FBSyxPQUFPLEVBQUU7UUFDcEIsT0FBTztVQUFFUTtRQUFRLENBQUM7TUFDcEI7TUFFQSxJQUFJLENBQUNBLE9BQU8sRUFBRTtRQUNaLE1BQU0sSUFBSWxDLEtBQUssQ0FBQyxzQkFBc0IsQ0FBQztNQUN6QztJQUNGLENBQUMsQ0FBQyxPQUFPL0MsS0FBSyxFQUFFO01BQ2R2QixPQUFPLENBQUNPLEtBQUssQ0FBQ2lCLE1BQU0sQ0FBQ0QsS0FBSyxDQUFDQSxLQUFLLENBQUNFLE9BQU8sSUFBSUYsS0FBSyxDQUFDO01BQ2xELE9BQU9rRixPQUFPLENBQUNDLE1BQU0sQ0FBQ25GLEtBQUssQ0FBQztJQUM5QjtFQUNGO0VBRUFvRixLQUFLQSxDQUFDQyxNQUFNLEVBQUU7SUFDWjtJQUNBLE9BQU8sSUFBSUgsT0FBTyxDQUFDLENBQUNJLE9BQU8sRUFBRUgsTUFBTSxLQUFLO01BQ3RDSSxVQUFVLENBQUNELE9BQU8sRUFBRUQsTUFBTSxDQUFDO0lBQzdCLENBQUMsQ0FBQztFQUNKOztFQUVBO0FBQ0Y7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtFQUNFLE1BQU1HLFdBQVdBLENBQUMvRyxPQUFPLEVBQUVnSCxNQUFNLEVBQUVoQixJQUFJLEVBQUV0QyxJQUFJLEVBQUVkLEVBQUUsRUFBRTFDLFFBQVEsRUFBRTtJQUMzRCxNQUFNK0csUUFBUSxHQUFHLENBQUMsQ0FBQyxDQUFDdkQsSUFBSSxJQUFJLENBQUMsQ0FBQyxFQUFFdUQsUUFBUTtJQUN4QyxJQUFJO01BQ0YsSUFBSXZGLEdBQUc7TUFDUCxJQUFJO1FBQ0ZBLEdBQUcsR0FBRyxNQUFNMUIsT0FBTyxDQUFDK0MsVUFBVSxDQUFDQyxXQUFXLENBQUNDLEdBQUcsQ0FBQ0wsRUFBRSxFQUFFO1VBQ2pETSxlQUFlLEVBQUU7UUFDbkIsQ0FBQyxDQUFDO01BQ0osQ0FBQyxDQUFDLE9BQU8zQixLQUFLLEVBQUU7UUFDZHZCLE9BQU8sQ0FBQ08sS0FBSyxDQUFDaUIsTUFBTSxDQUFDRCxLQUFLLENBQUMsZ0NBQWdDLENBQUM7UUFDNUQ7UUFDQSxPQUFPLElBQUFnQiw0QkFBYSxFQUNsQixnQ0FBZ0MsRUFDaEMsSUFBSSxFQUNKRSw0QkFBaUIsQ0FBQ3lFLFNBQVMsRUFDM0JoSCxRQUNGLENBQUM7TUFDSDtNQUVBLElBQUkrRyxRQUFRLEVBQUU7UUFDWixPQUFPdkQsSUFBSSxDQUFDdUQsUUFBUTtNQUN0QjtNQUVBLElBQUksQ0FBQ3ZELElBQUksRUFBRTtRQUNUQSxJQUFJLEdBQUcsQ0FBQyxDQUFDO01BQ1g7TUFFQSxJQUFJLENBQUNBLElBQUksQ0FBQ2hELE9BQU8sRUFBRTtRQUNqQmdELElBQUksQ0FBQ2hELE9BQU8sR0FBRyxDQUFDLENBQUM7TUFDbkI7TUFFQSxNQUFNd0UsT0FBTyxHQUFHO1FBQ2QzQixTQUFTLEVBQUVYO01BQ2IsQ0FBQzs7TUFFRDtNQUNBLElBQ0UsT0FBTyxDQUFDYyxJQUFJLElBQUksQ0FBQyxDQUFDLEVBQUVyRCxJQUFJLEtBQUssUUFBUSxJQUNyQyxDQUFDcUQsSUFBSSxJQUFJLENBQUMsQ0FBQyxFQUFFeUQsTUFBTSxLQUFLLFdBQVcsRUFDbkM7UUFDQXpELElBQUksQ0FBQ2hELE9BQU8sQ0FBQyxjQUFjLENBQUMsR0FBRyxpQkFBaUI7UUFDaEQsT0FBT2dELElBQUksQ0FBQ3lELE1BQU07TUFDcEI7TUFFQSxJQUNFLE9BQU8sQ0FBQ3pELElBQUksSUFBSSxDQUFDLENBQUMsRUFBRXJELElBQUksS0FBSyxRQUFRLElBQ3JDLENBQUNxRCxJQUFJLElBQUksQ0FBQyxDQUFDLEVBQUV5RCxNQUFNLEtBQUssTUFBTSxFQUM5QjtRQUNBekQsSUFBSSxDQUFDaEQsT0FBTyxDQUFDLGNBQWMsQ0FBQyxHQUFHLGtCQUFrQjtRQUNqRCxPQUFPZ0QsSUFBSSxDQUFDeUQsTUFBTTtNQUNwQjtNQUVBLElBQ0UsT0FBTyxDQUFDekQsSUFBSSxJQUFJLENBQUMsQ0FBQyxFQUFFckQsSUFBSSxLQUFLLFFBQVEsSUFDckMsQ0FBQ3FELElBQUksSUFBSSxDQUFDLENBQUMsRUFBRXlELE1BQU0sS0FBSyxLQUFLLEVBQzdCO1FBQ0F6RCxJQUFJLENBQUNoRCxPQUFPLENBQUMsY0FBYyxDQUFDLEdBQUcsMEJBQTBCO1FBQ3pELE9BQU9nRCxJQUFJLENBQUN5RCxNQUFNO01BQ3BCO01BQ0EsTUFBTUMsS0FBSyxHQUFHLENBQUMxRCxJQUFJLElBQUksQ0FBQyxDQUFDLEVBQUUwRCxLQUFLLElBQUksQ0FBQztNQUNyQyxJQUFJQSxLQUFLLEVBQUU7UUFDVDtRQUNBO1FBQ0E7UUFDQTtRQUNBLE9BQU8xRCxJQUFJLENBQUMwRCxLQUFLO1FBQ2pCLElBQUFDLG9CQUFhLEVBQUM7VUFDWkMsT0FBTyxFQUFFLElBQUluRyxJQUFJLENBQUNBLElBQUksQ0FBQ0MsR0FBRyxDQUFDLENBQUMsR0FBR2dHLEtBQUssQ0FBQztVQUNyQ0csR0FBRyxFQUFFLE1BQU1DLFVBQVUsSUFBSTtZQUN2QixJQUFJO2NBQ0YsTUFBTXhILE9BQU8sQ0FBQ08sS0FBSyxDQUFDbUIsR0FBRyxDQUFDQyxNQUFNLENBQUNDLGFBQWEsQ0FBQzNCLE9BQU8sQ0FDbEQrRyxNQUFNLEVBQ05oQixJQUFJLEVBQ0p0QyxJQUFJLEVBQ0p3QixPQUNGLENBQUM7WUFDSCxDQUFDLENBQUMsT0FBTzNELEtBQUssRUFBRTtjQUNkaUcsVUFBVSxDQUFDakgsS0FBSyxDQUFDaUIsTUFBTSxDQUFDRCxLQUFLLENBQzFCLDZDQUE0Q3lGLE1BQU8sSUFBR2hCLElBQUssTUFDMUR6RSxLQUFLLENBQUNFLE9BQU8sSUFBSUYsS0FDbEIsRUFDSCxDQUFDO1lBQ0g7VUFDRjtRQUNGLENBQUMsQ0FBQztRQUNGLE9BQU9yQixRQUFRLENBQUNtQixFQUFFLENBQUM7VUFDakJoQixJQUFJLEVBQUU7WUFBRWtCLEtBQUssRUFBRSxDQUFDO1lBQUVFLE9BQU8sRUFBRTtVQUFVO1FBQ3ZDLENBQUMsQ0FBQztNQUNKO01BRUEsSUFBSXVFLElBQUksS0FBSyxPQUFPLEVBQUU7UUFDcEIsSUFBSTtVQUNGLE1BQU15QixLQUFLLEdBQUcsTUFBTSxJQUFJLENBQUMxQixZQUFZLENBQUMvRixPQUFPLEVBQUUwQixHQUFHLEVBQUVzRSxJQUFJLENBQUM7VUFDekQsT0FBT3lCLEtBQUs7UUFDZCxDQUFDLENBQUMsT0FBT2xHLEtBQUssRUFBRTtVQUNkLE1BQU11RSxNQUFNLEdBQUcsQ0FBQ3ZFLEtBQUssSUFBSSxDQUFDLENBQUMsRUFBRWtELElBQUksS0FBSyxjQUFjO1VBQ3BELElBQUksQ0FBQ3FCLE1BQU0sRUFBRTtZQUNYOUYsT0FBTyxDQUFDTyxLQUFLLENBQUNpQixNQUFNLENBQUNELEtBQUssQ0FDeEIsc0RBQ0YsQ0FBQztZQUNELE9BQU8sSUFBQWdCLDRCQUFhLEVBQ2pCLGVBQWNoQixLQUFLLENBQUNFLE9BQU8sSUFBSSxzQkFBdUIsRUFBQyxFQUN4RCxJQUFJLEVBQ0pnQiw0QkFBaUIsQ0FBQ0MscUJBQXFCLEVBQ3ZDeEMsUUFDRixDQUFDO1VBQ0g7UUFDRjtNQUNGO01BRUFGLE9BQU8sQ0FBQ08sS0FBSyxDQUFDaUIsTUFBTSxDQUFDcUIsS0FBSyxDQUFFLEdBQUVtRSxNQUFPLElBQUdoQixJQUFLLEVBQUMsQ0FBQztNQUUvQyxNQUFNMEIsYUFBYSxHQUNqQixNQUFNMUgsT0FBTyxDQUFDTyxLQUFLLENBQUNtQixHQUFHLENBQUNDLE1BQU0sQ0FBQ0MsYUFBYSxDQUFDM0IsT0FBTyxDQUNsRCtHLE1BQU0sRUFDTmhCLElBQUksRUFDSnRDLElBQUksRUFDSndCLE9BQ0YsQ0FBQztNQUNILE1BQU15QyxjQUFjLEdBQUcsSUFBSSxDQUFDbEUsbUJBQW1CLENBQUN6RCxPQUFPLEVBQUUwSCxhQUFhLENBQUM7TUFDdkUsSUFBSUMsY0FBYyxFQUFFO1FBQ2xCLE9BQU8sSUFBQXBGLDRCQUFhLEVBQ2pCLGVBQWNyQyxRQUFRLENBQUNHLElBQUksQ0FBQ29CLE9BQU8sSUFBSSxzQkFBdUIsRUFBQyxFQUNoRSxJQUFJLEVBQ0pnQiw0QkFBaUIsQ0FBQ0MscUJBQXFCLEVBQ3ZDeEMsUUFDRixDQUFDO01BQ0g7TUFDQSxJQUFJMEgsWUFBWSxHQUFHLENBQUNGLGFBQWEsSUFBSSxDQUFDLENBQUMsRUFBRWhFLElBQUksSUFBSSxDQUFDLENBQUM7TUFDbkQsSUFBSSxDQUFDa0UsWUFBWSxFQUFFO1FBQ2pCQSxZQUFZLEdBQ1YsT0FBT0EsWUFBWSxLQUFLLFFBQVEsSUFDaEM1QixJQUFJLENBQUNqQixRQUFRLENBQUMsUUFBUSxDQUFDLElBQ3ZCaUMsTUFBTSxLQUFLLEtBQUssR0FDWixHQUFHLEdBQ0gsS0FBSztRQUNYOUcsUUFBUSxDQUFDd0QsSUFBSSxHQUFHa0UsWUFBWTtNQUM5QjtNQUNBLE1BQU1DLGFBQWEsR0FDakIzSCxRQUFRLENBQUNzQyxNQUFNLEtBQUtDLDRCQUFpQixDQUFDMkIsRUFBRSxHQUFHbEUsUUFBUSxDQUFDc0MsTUFBTSxHQUFHLEtBQUs7TUFFcEUsSUFBSSxDQUFDcUYsYUFBYSxJQUFJRCxZQUFZLEVBQUU7UUFDbEMsT0FBTzFILFFBQVEsQ0FBQ21CLEVBQUUsQ0FBQztVQUNqQmhCLElBQUksRUFBRXFILGFBQWEsQ0FBQ2hFO1FBQ3RCLENBQUMsQ0FBQztNQUNKO01BRUEsSUFBSW1FLGFBQWEsSUFBSVosUUFBUSxFQUFFO1FBQzdCLE9BQU8vRyxRQUFRLENBQUNtQixFQUFFLENBQUM7VUFDakJoQixJQUFJLEVBQUVILFFBQVEsQ0FBQ3dEO1FBQ2pCLENBQUMsQ0FBQztNQUNKO01BQ0EsTUFBTW1FLGFBQWEsSUFBSUQsWUFBWSxDQUFDakUsTUFBTSxHQUN0QztRQUFFbEMsT0FBTyxFQUFFbUcsWUFBWSxDQUFDakUsTUFBTTtRQUFFYyxJQUFJLEVBQUVvRDtNQUFjLENBQUMsR0FDckQsSUFBSXZELEtBQUssQ0FBQyw2Q0FBNkMsQ0FBQztJQUM5RCxDQUFDLENBQUMsT0FBTy9DLEtBQUssRUFBRTtNQUFBLElBQUF1RyxnQkFBQTtNQUNkO01BQ0E7TUFDQTtNQUNBLElBQUliLFFBQVEsSUFBSTFGLEtBQUssYUFBTEEsS0FBSyxlQUFMQSxLQUFLLENBQUVyQixRQUFRLEVBQUU7UUFDL0IsSUFBSTtVQUNGLE1BQU1pRSxVQUFVLEdBQ2Q1QyxLQUFLLENBQUNyQixRQUFRLENBQUNzQyxNQUFNLElBQUlDLDRCQUFpQixDQUFDQyxxQkFBcUI7VUFDbEUsTUFBTXJDLElBQUksR0FBR2tCLEtBQUssQ0FBQ3JCLFFBQVEsQ0FBQ3dELElBQUksSUFBSTtZQUNsQ2pDLE9BQU8sRUFBRUYsS0FBSyxDQUFDRSxPQUFPLElBQUk7VUFDNUIsQ0FBQztVQUNELE9BQU92QixRQUFRLENBQUM2SCxNQUFNLENBQUM7WUFBRTVELFVBQVU7WUFBRTlEO1VBQUssQ0FBQyxDQUFDO1FBQzlDLENBQUMsQ0FBQyxPQUFPMkgsQ0FBQyxFQUFFO1VBQ1Y7UUFBQTtNQUVKO01BRUEsSUFBSSxDQUFBekcsS0FBSyxhQUFMQSxLQUFLLGdCQUFBdUcsZ0JBQUEsR0FBTHZHLEtBQUssQ0FBRXJCLFFBQVEsY0FBQTRILGdCQUFBLHVCQUFmQSxnQkFBQSxDQUFpQnRGLE1BQU0sTUFBS0MsNEJBQWlCLENBQUNrRCxZQUFZLEVBQUU7UUFDOUQsT0FBTyxJQUFBcEQsNEJBQWEsRUFDbEJoQixLQUFLLENBQUNFLE9BQU8sSUFBSUYsS0FBSyxFQUN0QkEsS0FBSyxDQUFDa0QsSUFBSSxHQUFJLGNBQWFsRCxLQUFLLENBQUNrRCxJQUFLLEVBQUMsR0FBRyxJQUFJLEVBQzlDaEMsNEJBQWlCLENBQUNrRCxZQUFZLEVBQzlCekYsUUFDRixDQUFDO01BQ0g7TUFDQTtNQUNBLE1BQU1tQyxZQUFZLEdBQUcsSUFBQUMsd0NBQW1CLEVBQUNmLEtBQUssQ0FBQztNQUMvQ3ZCLE9BQU8sQ0FBQ08sS0FBSyxDQUFDaUIsTUFBTSxDQUFDRCxLQUFLLENBQUNjLFlBQVksQ0FBQztNQUN4QyxJQUFJLENBQUNkLEtBQUssSUFBSSxDQUFDLENBQUMsRUFBRWtELElBQUksSUFBSXdELHlDQUFtQixDQUFDMUcsS0FBSyxDQUFDa0QsSUFBSSxDQUFDLEVBQUU7UUFDekRsRCxLQUFLLENBQUNFLE9BQU8sR0FBR3dHLHlDQUFtQixDQUFDMUcsS0FBSyxDQUFDa0QsSUFBSSxDQUFDO01BQ2pEO01BQ0EsT0FBTyxJQUFBbEMsNEJBQWEsRUFDbEJGLFlBQVksRUFDWmQsS0FBSyxDQUFDa0QsSUFBSSxHQUFJLGNBQWFsRCxLQUFLLENBQUNrRCxJQUFLLEVBQUMsR0FBRyxJQUFJLEVBQzlDaEMsNEJBQWlCLENBQUNDLHFCQUFxQixFQUN2Q3hDLFFBQ0YsQ0FBQztJQUNIO0VBQ0Y7O0VBRUE7QUFDRjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7RUFDRWdJLFVBQVVBLENBQ1JsSSxPQUE4QixFQUM5QkMsT0FBb0MsRUFDcENDLFFBQTZDLEVBQzdDO0lBQ0EsTUFBTWlJLEtBQUssR0FBRyxJQUFBdEgsNEJBQW9CLEVBQUNaLE9BQU8sQ0FBQ1MsT0FBTyxDQUFDQyxNQUFNLEVBQUUsUUFBUSxDQUFDO0lBQ3BFLElBQUl3SCxLQUFLLEtBQUtsSSxPQUFPLENBQUNJLElBQUksQ0FBQ3VDLEVBQUUsRUFBRTtNQUM3QjtNQUNBLE9BQU8sSUFBQUwsNEJBQWEsRUFDbEIsaUJBQWlCLEVBQ2pCRSw0QkFBaUIsQ0FBQ2tELFlBQVksRUFDOUJsRCw0QkFBaUIsQ0FBQ2tELFlBQVksRUFDOUJ6RixRQUNGLENBQUM7SUFDSDtJQUNBLElBQUksQ0FBQ0QsT0FBTyxDQUFDSSxJQUFJLENBQUMyRyxNQUFNLEVBQUU7TUFDeEIsT0FBTyxJQUFBekUsNEJBQWEsRUFDbEIsdUJBQXVCLEVBQ3ZCLElBQUksRUFDSkUsNEJBQWlCLENBQUNtRCxXQUFXLEVBQzdCMUYsUUFDRixDQUFDO0lBQ0gsQ0FBQyxNQUFNLElBQUksQ0FBQ0QsT0FBTyxDQUFDSSxJQUFJLENBQUMyRyxNQUFNLENBQUNvQixLQUFLLENBQUMsMkJBQTJCLENBQUMsRUFBRTtNQUNsRXBJLE9BQU8sQ0FBQ08sS0FBSyxDQUFDaUIsTUFBTSxDQUFDRCxLQUFLLENBQUMsOEJBQThCLENBQUM7TUFDMUQ7TUFDQSxPQUFPLElBQUFnQiw0QkFBYSxFQUNsQiw4QkFBOEIsRUFDOUIsSUFBSSxFQUNKRSw0QkFBaUIsQ0FBQ21ELFdBQVcsRUFDN0IxRixRQUNGLENBQUM7SUFDSCxDQUFDLE1BQU0sSUFBSSxDQUFDRCxPQUFPLENBQUNJLElBQUksQ0FBQzJGLElBQUksRUFBRTtNQUM3QixPQUFPLElBQUF6RCw0QkFBYSxFQUNsQixxQkFBcUIsRUFDckIsSUFBSSxFQUNKRSw0QkFBaUIsQ0FBQ21ELFdBQVcsRUFDN0IxRixRQUNGLENBQUM7SUFDSCxDQUFDLE1BQU0sSUFBSSxDQUFDRCxPQUFPLENBQUNJLElBQUksQ0FBQzJGLElBQUksQ0FBQ3FDLFVBQVUsQ0FBQyxHQUFHLENBQUMsRUFBRTtNQUM3Q3JJLE9BQU8sQ0FBQ08sS0FBSyxDQUFDaUIsTUFBTSxDQUFDRCxLQUFLLENBQUMsNEJBQTRCLENBQUM7TUFDeEQ7TUFDQSxPQUFPLElBQUFnQiw0QkFBYSxFQUNsQiw0QkFBNEIsRUFDNUIsSUFBSSxFQUNKRSw0QkFBaUIsQ0FBQ21ELFdBQVcsRUFDN0IxRixRQUNGLENBQUM7SUFDSCxDQUFDLE1BQU07TUFDTCxPQUFPLElBQUksQ0FBQzZHLFdBQVcsQ0FDckIvRyxPQUFPLEVBQ1BDLE9BQU8sQ0FBQ0ksSUFBSSxDQUFDMkcsTUFBTSxFQUNuQi9HLE9BQU8sQ0FBQ0ksSUFBSSxDQUFDMkYsSUFBSSxFQUNqQi9GLE9BQU8sQ0FBQ0ksSUFBSSxDQUFDQSxJQUFJLEVBQ2pCSixPQUFPLENBQUNJLElBQUksQ0FBQ3VDLEVBQUUsRUFDZjFDLFFBQ0YsQ0FBQztJQUNIO0VBQ0Y7O0VBRUE7QUFDRjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7RUFDRSxNQUFNb0ksR0FBR0EsQ0FDUHRJLE9BQThCLEVBQzlCQyxPQUFvQyxFQUNwQ0MsUUFBNkMsRUFDN0M7SUFDQSxNQUFNcUksU0FBUyxHQUFHLE1BQU12SSxPQUFPLENBQUMrQyxVQUFVLENBQUN5RixhQUFhLENBQUN2RixHQUFHLENBQUMsQ0FBQztJQUM5RCxNQUFNd0YsYUFBYSxHQUFHRixTQUFTLENBQUMscUJBQXFCLENBQUM7SUFDdEQsSUFBSTtNQUNGLElBQUksQ0FBQ3RJLE9BQU8sQ0FBQ0ksSUFBSSxJQUFJLENBQUNKLE9BQU8sQ0FBQ0ksSUFBSSxDQUFDMkYsSUFBSSxFQUNyQyxNQUFNLElBQUkxQixLQUFLLENBQUMsd0JBQXdCLENBQUM7TUFDM0MsSUFBSSxDQUFDckUsT0FBTyxDQUFDSSxJQUFJLENBQUN1QyxFQUFFLEVBQUUsTUFBTSxJQUFJMEIsS0FBSyxDQUFDLHNCQUFzQixDQUFDO01BRTdELE1BQU1vRSxPQUFPLEdBQUdDLEtBQUssQ0FBQ0MsT0FBTyxDQUFDLENBQUMsQ0FBQzNJLE9BQU8sSUFBSSxDQUFDLENBQUMsRUFBRUksSUFBSSxJQUFJLENBQUMsQ0FBQyxFQUFFcUksT0FBTyxDQUFDLEdBQy9EekksT0FBTyxDQUFDSSxJQUFJLENBQUNxSSxPQUFPLEdBQ3BCLEVBQUU7TUFFTixJQUFJRyxPQUFPLEdBQUc1SSxPQUFPLENBQUNJLElBQUksQ0FBQzJGLElBQUk7TUFFL0IsSUFBSTZDLE9BQU8sSUFBSSxPQUFPQSxPQUFPLEtBQUssUUFBUSxFQUFFO1FBQzFDQSxPQUFPLEdBQUdBLE9BQU8sQ0FBQyxDQUFDLENBQUMsS0FBSyxHQUFHLEdBQUdBLE9BQU8sQ0FBQ0MsTUFBTSxDQUFDLENBQUMsQ0FBQyxHQUFHRCxPQUFPO01BQzVEO01BRUEsSUFBSSxDQUFDQSxPQUFPLEVBQUUsTUFBTSxJQUFJdkUsS0FBSyxDQUFDLHNDQUFzQyxDQUFDO01BRXJFdEUsT0FBTyxDQUFDTyxLQUFLLENBQUNpQixNQUFNLENBQUNxQixLQUFLLENBQUUsVUFBU2dHLE9BQVEsRUFBQyxDQUFDO01BQy9DO01BQ0EsTUFBTUUsTUFBTSxHQUFHO1FBQUVDLEtBQUssRUFBRTtNQUFJLENBQUM7TUFFN0IsSUFBSU4sT0FBTyxDQUFDTyxNQUFNLEVBQUU7UUFDbEIsS0FBSyxNQUFNQyxNQUFNLElBQUlSLE9BQU8sRUFBRTtVQUM1QixJQUFJLENBQUNRLE1BQU0sQ0FBQ0MsSUFBSSxJQUFJLENBQUNELE1BQU0sQ0FBQ0UsS0FBSyxFQUFFO1VBQ25DTCxNQUFNLENBQUNHLE1BQU0sQ0FBQ0MsSUFBSSxDQUFDLEdBQUdELE1BQU0sQ0FBQ0UsS0FBSztRQUNwQztNQUNGO01BRUEsSUFBSUMsVUFBVSxHQUFHLEVBQUU7TUFFbkIsTUFBTUMsTUFBTSxHQUFHLE1BQU10SixPQUFPLENBQUNPLEtBQUssQ0FBQ21CLEdBQUcsQ0FBQ0MsTUFBTSxDQUFDQyxhQUFhLENBQUMzQixPQUFPLENBQ2pFLEtBQUssRUFDSixJQUFHNEksT0FBUSxFQUFDLEVBQ2I7UUFBRUUsTUFBTSxFQUFFQTtNQUFPLENBQUMsRUFDbEI7UUFBRXhGLFNBQVMsRUFBRXRELE9BQU8sQ0FBQ0ksSUFBSSxDQUFDdUM7TUFBRyxDQUMvQixDQUFDO01BRUQsTUFBTTJHLE1BQU0sR0FDVnRKLE9BQU8sQ0FBQ0ksSUFBSSxDQUFDMkYsSUFBSSxDQUFDakIsUUFBUSxDQUFDLFFBQVEsQ0FBQyxJQUNwQzlFLE9BQU8sQ0FBQ0ksSUFBSSxDQUFDcUksT0FBTyxJQUNwQnpJLE9BQU8sQ0FBQ0ksSUFBSSxDQUFDcUksT0FBTyxDQUFDTyxNQUFNLElBQzNCaEosT0FBTyxDQUFDSSxJQUFJLENBQUNxSSxPQUFPLENBQUNjLElBQUksQ0FBQ04sTUFBTSxJQUFJQSxNQUFNLENBQUNPLFVBQVUsQ0FBQztNQUV4RCxNQUFNQyxVQUFVLEdBQUcsQ0FBQyxDQUFDLENBQUNKLE1BQU0sSUFBSSxDQUFDLENBQUMsRUFBRTVGLElBQUksSUFBSSxDQUFDLENBQUMsRUFBRUEsSUFBSSxJQUFJLENBQUMsQ0FBQyxFQUN2RGlHLG9CQUFvQjtNQUV2QixJQUFJRCxVQUFVLElBQUksQ0FBQ0gsTUFBTSxFQUFFO1FBQ3pCUixNQUFNLENBQUNhLE1BQU0sR0FBRyxDQUFDO1FBQ2pCLE9BQ0VQLFVBQVUsQ0FBQ0osTUFBTSxHQUFHWSxJQUFJLENBQUNDLEdBQUcsQ0FBQ0osVUFBVSxFQUFFakIsYUFBYSxDQUFDLElBQ3ZETSxNQUFNLENBQUNhLE1BQU0sR0FBR0MsSUFBSSxDQUFDQyxHQUFHLENBQUNKLFVBQVUsRUFBRWpCLGFBQWEsQ0FBQyxFQUNuRDtVQUNBLE1BQU1zQixPQUFPLEdBQUcsTUFBTS9KLE9BQU8sQ0FBQ08sS0FBSyxDQUFDbUIsR0FBRyxDQUFDQyxNQUFNLENBQUNDLGFBQWEsQ0FBQzNCLE9BQU8sQ0FDbEUsS0FBSyxFQUNKLElBQUc0SSxPQUFRLEVBQUMsRUFDYjtZQUFFRSxNQUFNLEVBQUVBO1VBQU8sQ0FBQyxFQUNsQjtZQUFFeEYsU0FBUyxFQUFFdEQsT0FBTyxDQUFDSSxJQUFJLENBQUN1QztVQUFHLENBQy9CLENBQUM7VUFFRCxNQUFNb0gsYUFBYSxHQUFHRCxPQUFPLENBQUNyRyxJQUFJLENBQUNBLElBQUksQ0FBQzRCLGNBQWM7VUFDdEQsTUFBTTJFLGNBQWMsR0FBR3hCLGFBQWEsR0FBR1ksVUFBVSxDQUFDSixNQUFNO1VBQ3hELElBQUlJLFVBQVUsQ0FBQ0osTUFBTSxHQUFHZSxhQUFhLENBQUNmLE1BQU0sR0FBR1IsYUFBYSxFQUFFO1lBQzVEWSxVQUFVLENBQUNhLElBQUksQ0FBQyxHQUFHRixhQUFhLENBQUNHLEtBQUssQ0FBQyxDQUFDLEVBQUVGLGNBQWMsQ0FBQyxDQUFDO1lBQzFEO1VBQ0Y7VUFDQVosVUFBVSxDQUFDYSxJQUFJLENBQUMsR0FBR0YsYUFBYSxDQUFDO1VBQ2pDakIsTUFBTSxDQUFDYSxNQUFNLElBQUliLE1BQU0sQ0FBQ0MsS0FBSztRQUMvQjtNQUNGO01BRUEsSUFBSVUsVUFBVSxFQUFFO1FBQ2QsTUFBTTtVQUFFMUQsSUFBSTtVQUFFMEM7UUFBUSxDQUFDLEdBQUd6SSxPQUFPLENBQUNJLElBQUk7UUFDdEMsTUFBTStKLGNBQWMsR0FBR3BFLElBQUksQ0FBQ2pCLFFBQVEsQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDd0UsTUFBTTtRQUN6RCxNQUFNYyxRQUFRLEdBQUdyRSxJQUFJLENBQUNqQixRQUFRLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBQ2lCLElBQUksQ0FBQ2pCLFFBQVEsQ0FBQyxRQUFRLENBQUM7UUFDckUsTUFBTXVGLGVBQWUsR0FBR3RFLElBQUksQ0FBQ3FDLFVBQVUsQ0FBQyxpQkFBaUIsQ0FBQztRQUMxRCxNQUFNa0MsT0FBTyxHQUFHdkUsSUFBSSxDQUFDd0UsUUFBUSxDQUFDLFFBQVEsQ0FBQztRQUN2QyxJQUFJQyxNQUFNLEdBQUdDLE1BQU0sQ0FBQ0MsSUFBSSxDQUFDckIsTUFBTSxDQUFDNUYsSUFBSSxDQUFDQSxJQUFJLENBQUM0QixjQUFjLENBQUMsQ0FBQyxDQUFDLENBQUM7UUFFNUQsSUFBSStFLFFBQVEsSUFBSUMsZUFBZSxFQUFFO1VBQy9CLElBQUlDLE9BQU8sRUFBRTtZQUNYRSxNQUFNLEdBQUcsQ0FBQyxVQUFVLEVBQUUsTUFBTSxDQUFDO1VBQy9CLENBQUMsTUFBTTtZQUNMQSxNQUFNLEdBQUcsQ0FDUCxJQUFJLEVBQ0osUUFBUSxFQUNSLE1BQU0sRUFDTixJQUFJLEVBQ0osT0FBTyxFQUNQLFNBQVMsRUFDVCxXQUFXLEVBQ1gsU0FBUyxFQUNULFNBQVMsRUFDVCxlQUFlLEVBQ2YsU0FBUyxFQUNULFVBQVUsRUFDVixhQUFhLEVBQ2IsVUFBVSxFQUNWLFVBQVUsRUFDVixTQUFTLEVBQ1QsYUFBYSxFQUNiLFVBQVUsRUFDVixZQUFZLENBQ2I7VUFDSDtRQUNGO1FBRUEsSUFBSUwsY0FBYyxFQUFFO1VBQ2xCLE1BQU1RLFNBQVMsR0FBRyxFQUFFO1VBQ3BCLEtBQUssTUFBTUMsSUFBSSxJQUFJeEIsVUFBVSxFQUFFO1lBQzdCLE1BQU07Y0FBRXlCLGdCQUFnQjtjQUFFQztZQUFNLENBQUMsR0FBR0YsSUFBSTtZQUN4Q0QsU0FBUyxDQUFDVixJQUFJLENBQ1osR0FBR2EsS0FBSyxDQUFDQyxHQUFHLENBQUNDLElBQUksS0FBSztjQUNwQkgsZ0JBQWdCO2NBQ2hCSSxHQUFHLEVBQUVELElBQUksQ0FBQ0MsR0FBRztjQUNiOUIsS0FBSyxFQUFFNkIsSUFBSSxDQUFDN0I7WUFDZCxDQUFDLENBQUMsQ0FDSixDQUFDO1VBQ0g7VUFDQXFCLE1BQU0sR0FBRyxDQUFDLGtCQUFrQixFQUFFLEtBQUssRUFBRSxPQUFPLENBQUM7VUFDN0NwQixVQUFVLEdBQUcsQ0FBQyxHQUFHdUIsU0FBUyxDQUFDO1FBQzdCO1FBRUEsSUFBSXJCLE1BQU0sRUFBRTtVQUNWa0IsTUFBTSxHQUFHLENBQUMsS0FBSyxFQUFFLE9BQU8sQ0FBQztVQUN6QnBCLFVBQVUsR0FBR0MsTUFBTSxDQUFDNUYsSUFBSSxDQUFDQSxJQUFJLENBQUM0QixjQUFjLENBQUMsQ0FBQyxDQUFDLENBQUN5RixLQUFLO1FBQ3ZEO1FBQ0FOLE1BQU0sR0FBR0EsTUFBTSxDQUFDTyxHQUFHLENBQUNDLElBQUksS0FBSztVQUMzQjtVQUNBN0IsS0FBSyxFQUFFNkIsSUFBSSxLQUFLLE1BQU0sR0FBR0UsbURBQWdDLEdBQUdGLElBQUk7VUFDaEVyTCxPQUFPLEVBQUU7UUFDWCxDQUFDLENBQUMsQ0FBQztRQUNILE1BQU1zRixPQUFPLEdBQUc7VUFDZGtHLGVBQWUsRUFBRSxFQUFFO1VBQ25CVCxJQUFJLEVBQUVGLE1BQU0sQ0FBQ08sR0FBRyxDQUFDSyxLQUFLLEtBQUs7WUFDekJBLEtBQUssRUFBRUEsS0FBSyxDQUFDakMsS0FBSztZQUNsQmtDLEtBQUssRUFBRUMsaUNBQWMsQ0FBQ0YsS0FBSyxDQUFDakMsS0FBSyxDQUFDLElBQUlpQyxLQUFLLENBQUNqQztVQUM5QyxDQUFDLENBQUM7UUFDSixDQUFDO1FBQ0RDLFVBQVUsR0FBR0EsVUFBVSxDQUFDMkIsR0FBRyxDQUFDLENBQUM7VUFBRVEsSUFBSTtVQUFFLEdBQUdDO1FBQUssQ0FBQyxNQUFNO1VBQ2xELEdBQUdBLElBQUk7VUFDUDtVQUNBLElBQUlELElBQUksS0FBS0UsU0FBUyxHQUNsQjtZQUFFLENBQUNQLG1EQUFnQyxHQUFHSztVQUFLLENBQUMsR0FDNUMsQ0FBQyxDQUFDO1FBQ1IsQ0FBQyxDQUFDLENBQUM7UUFDSCxJQUFJbEQsR0FBRyxHQUFHLE1BQU1xRCxpQkFBUyxDQUFDQyxhQUFhLENBQUN2QyxVQUFVLEVBQUVuRSxPQUFPLENBQUM7UUFFNUQsT0FBT2hGLFFBQVEsQ0FBQ21CLEVBQUUsQ0FBQztVQUNqQlgsT0FBTyxFQUFFO1lBQUUsY0FBYyxFQUFFO1VBQVcsQ0FBQztVQUN2Q0wsSUFBSSxFQUFFaUk7UUFDUixDQUFDLENBQUM7TUFDSixDQUFDLE1BQU0sSUFDTGdCLE1BQU0sSUFDTkEsTUFBTSxDQUFDNUYsSUFBSSxJQUNYNEYsTUFBTSxDQUFDNUYsSUFBSSxDQUFDQSxJQUFJLElBQ2hCLENBQUM0RixNQUFNLENBQUM1RixJQUFJLENBQUNBLElBQUksQ0FBQ2lHLG9CQUFvQixFQUN0QztRQUNBLE1BQU0sSUFBSXJGLEtBQUssQ0FBQyxZQUFZLENBQUM7TUFDL0IsQ0FBQyxNQUFNO1FBQ0wsTUFBTSxJQUFJQSxLQUFLLENBQ1oscURBQ0NnRixNQUFNLElBQUlBLE1BQU0sQ0FBQzVGLElBQUksSUFBSTRGLE1BQU0sQ0FBQzVGLElBQUksQ0FBQ0MsTUFBTSxHQUN0QyxLQUFJMkYsTUFBTSxDQUFDakosSUFBSSxDQUFDc0QsTUFBTyxFQUFDLEdBQ3pCLEVBQ0wsRUFDSCxDQUFDO01BQ0g7SUFDRixDQUFDLENBQUMsT0FBT3BDLEtBQUssRUFBRTtNQUNkdkIsT0FBTyxDQUFDTyxLQUFLLENBQUNpQixNQUFNLENBQUNELEtBQUssQ0FBQ0EsS0FBSyxDQUFDRSxPQUFPLElBQUlGLEtBQUssQ0FBQztNQUNsRCxPQUFPLElBQUFnQiw0QkFBYSxFQUNsQmhCLEtBQUssQ0FBQ0UsT0FBTyxJQUFJRixLQUFLLEVBQ3RCLElBQUksRUFDSmtCLDRCQUFpQixDQUFDQyxxQkFBcUIsRUFDdkN4QyxRQUNGLENBQUM7SUFDSDtFQUNGOztFQUVBO0VBQ0EyTCxjQUFjQSxDQUNaN0wsT0FBOEIsRUFDOUJDLE9BQW9DLEVBQ3BDQyxRQUE2QyxFQUM3QztJQUNBO0lBQ0EsT0FBT0EsUUFBUSxDQUFDbUIsRUFBRSxDQUFDO01BQ2pCaEIsSUFBSSxFQUFFeUw7SUFDUixDQUFDLENBQUM7RUFDSjs7RUFFQTtBQUNGO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtFQUNFLE1BQU1DLFlBQVlBLENBQ2hCL0wsT0FBOEIsRUFDOUJDLE9BQW9DLEVBQ3BDQyxRQUE2QyxFQUM3QztJQUNBLElBQUk7TUFDRixPQUFPQSxRQUFRLENBQUNtQixFQUFFLENBQUM7UUFDakJoQixJQUFJLEVBQUU7VUFDSjhELFVBQVUsRUFBRTFCLDRCQUFpQixDQUFDMkIsRUFBRTtVQUNoQ1YsSUFBSSxFQUFFO1lBQ0osYUFBYSxFQUFFc0ksZ0JBQWE7WUFDNUJDLFFBQVEsRUFBRUMsaUJBQWM7WUFDeEJDLGtCQUFrQixFQUFFbk0sT0FBTyxDQUFDK0MsVUFBVSxDQUFDeUYsYUFBYSxDQUFDNEQsS0FBSyxDQUFDQztVQUM3RDtRQUNGO01BQ0YsQ0FBQyxDQUFDO0lBQ0osQ0FBQyxDQUFDLE9BQU85SyxLQUFLLEVBQUU7TUFDZHZCLE9BQU8sQ0FBQ08sS0FBSyxDQUFDaUIsTUFBTSxDQUFDRCxLQUFLLENBQUNBLEtBQUssQ0FBQ0UsT0FBTyxJQUFJRixLQUFLLENBQUM7TUFDbEQsT0FBTyxJQUFBZ0IsNEJBQWEsRUFDakIseURBQ0NoQixLQUFLLENBQUNFLE9BQU8sSUFBSUYsS0FDbEIsRUFBQyxFQUNGLElBQUksRUFDSmtCLDRCQUFpQixDQUFDQyxxQkFBcUIsRUFDdkN4QyxRQUNGLENBQUM7SUFDSDtFQUNGOztFQUVBO0FBQ0Y7QUFDQTtBQUNBO0FBQ0E7QUFDQTtFQUNFLE1BQU1vTSxXQUFXQSxDQUNmdE0sT0FBOEIsRUFDOUJDLE9BQW9DLEVBQ3BDQyxRQUE2QyxFQUM3QztJQUNBLElBQUk7TUFDRixNQUFNcU0sUUFBUSxHQUFHLHdCQUF3QjtNQUN6QyxNQUFNQyxnQkFBZ0IsR0FBRyxnQ0FBZ0M7TUFFekQsTUFBTUMsS0FBSyxHQUFHO1FBQ1osQ0FBQ0YsUUFBUSxHQUNQLE1BQU12TSxPQUFPLENBQUMrQyxVQUFVLENBQUN5RixhQUFhLENBQUNrRSx1QkFBdUIsQ0FDNURILFFBQ0YsQ0FBQztRQUNILENBQUNDLGdCQUFnQixHQUNmLE1BQU14TSxPQUFPLENBQUMrQyxVQUFVLENBQUN5RixhQUFhLENBQUNrRSx1QkFBdUIsQ0FDNURGLGdCQUNGO01BQ0osQ0FBQztNQUVELE9BQU90TSxRQUFRLENBQUNtQixFQUFFLENBQUM7UUFDakJoQixJQUFJLEVBQUU7VUFBRW9NO1FBQU07TUFDaEIsQ0FBQyxDQUFDO0lBQ0osQ0FBQyxDQUFDLE9BQU9sTCxLQUFLLEVBQUU7TUFDZHZCLE9BQU8sQ0FBQ08sS0FBSyxDQUFDaUIsTUFBTSxDQUFDRCxLQUFLLENBQUNBLEtBQUssQ0FBQ0UsT0FBTyxJQUFJRixLQUFLLENBQUM7TUFDbEQsT0FBTyxJQUFBZ0IsNEJBQWEsRUFDbEJoQixLQUFLLENBQUNFLE9BQU8sSUFBSUYsS0FBSyxFQUN0QixJQUFJLEVBQ0prQiw0QkFBaUIsQ0FBQ0MscUJBQXFCLEVBQ3ZDeEMsUUFDRixDQUFDO0lBQ0g7RUFDRjtBQUNGO0FBQUN5TSxPQUFBLENBQUE5TSxZQUFBLEdBQUFBLFlBQUEifQ==