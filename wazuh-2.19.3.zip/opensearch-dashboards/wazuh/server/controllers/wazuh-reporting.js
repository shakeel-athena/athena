"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.WazuhReportingCtrl = void 0;
var _path = _interopRequireDefault(require("path"));
var _fs = _interopRequireDefault(require("fs"));
var _wazuhModules = require("../../common/wazuh-modules");
var TimSort = _interopRequireWildcard(require("timsort"));
var _errorResponse = require("../lib/error-response");
var _csvKeyEquivalence = require("../../common/csv-key-equivalence");
var _agentConfiguration = require("../lib/reporting/agent-configuration");
var _extendedInformation = require("../lib/reporting/extended-information");
var _printer = require("../lib/reporting/printer");
var _constants = require("../../common/constants");
var _wz_agent_status = require("../../common/services/wz_agent_status");
function _getRequireWildcardCache(e) { if ("function" != typeof WeakMap) return null; var r = new WeakMap(), t = new WeakMap(); return (_getRequireWildcardCache = function (e) { return e ? t : r; })(e); }
function _interopRequireWildcard(e, r) { if (!r && e && e.__esModule) return e; if (null === e || "object" != typeof e && "function" != typeof e) return { default: e }; var t = _getRequireWildcardCache(r); if (t && t.has(e)) return t.get(e); var n = { __proto__: null }, a = Object.defineProperty && Object.getOwnPropertyDescriptor; for (var u in e) if ("default" !== u && {}.hasOwnProperty.call(e, u)) { var i = a ? Object.getOwnPropertyDescriptor(e, u) : null; i && (i.get || i.set) ? Object.defineProperty(n, u, i) : n[u] = e[u]; } return n.default = e, t && t.set(e, n), n; }
function _interopRequireDefault(e) { return e && e.__esModule ? e : { default: e }; }
function _defineProperty(e, r, t) { return (r = _toPropertyKey(r)) in e ? Object.defineProperty(e, r, { value: t, enumerable: !0, configurable: !0, writable: !0 }) : e[r] = t, e; }
function _toPropertyKey(t) { var i = _toPrimitive(t, "string"); return "symbol" == typeof i ? i : i + ""; }
function _toPrimitive(t, r) { if ("object" != typeof t || !t) return t; var e = t[Symbol.toPrimitive]; if (void 0 !== e) { var i = e.call(t, r || "default"); if ("object" != typeof i) return i; throw new TypeError("@@toPrimitive must return a primitive value."); } return ("string" === r ? String : Number)(t); } /*
 * Wazuh app - Class for Wazuh reporting controller
 * Copyright (C) 2015-2022 Wazuh, Inc.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * Find more information about this on the LICENSE file.
 */
class WazuhReportingCtrl {
  constructor() {
    /**
     * Create a report for the modules
     * @param {Object} context
     * @param {Object} request
     * @param {Object} response
     * @returns {*} reports list or ErrorResponse
     */
    _defineProperty(this, "createReportsModules", this.checkReportsUserDirectoryIsValidRouteDecorator(async (context, request, response) => {
      try {
        context.wazuh.logger.debug('Report started');
        const {
          array,
          agents,
          browserTimezone,
          searchBar,
          filters,
          serverSideQuery,
          time,
          tables,
          section,
          indexPatternTitle,
          apiId
        } = request.body;
        const {
          moduleID
        } = request.params;
        const {
          from,
          to
        } = time || {};
        let additionalTables = [];
        // Init
        const printer = new _printer.ReportPrinter(context.wazuh.logger.get('report-printer'), context.wazuh_core.configuration);
        context.wazuh_core.dataPathService.createDataDirectoryIfNotExists(`downloads/reports/${context.wazuhEndpointParams.hashUsername}`);
        await this.renderHeader(context, printer, section, moduleID, agents, apiId);
        const [sanitizedFilters, agentsFilter] = filters ? this.sanitizeKibanaFilters(context, filters, searchBar) : [false, null];
        if (time && sanitizedFilters) {
          printer.addTimeRangeAndFilters(from, to, sanitizedFilters, browserTimezone);
        }
        if (time) {
          additionalTables = await (0, _extendedInformation.extendedInformation)(context, printer, section, moduleID, apiId, new Date(from).getTime(), new Date(to).getTime(), serverSideQuery, indexPatternTitle || context.wazuh_core.configuration.getSettingValue('pattern'), agents);
        }
        printer.addVisualizations(array, agents, moduleID);
        if (tables) {
          printer.addTables([...tables, ...(additionalTables || [])]);
        }
        await printer.print(context.wazuhEndpointParams.pathFilename);
        return response.ok({
          body: {
            success: true,
            message: `Report ${context.wazuhEndpointParams.filename} was created`,
            filename: context.wazuhEndpointParams.filename
          }
        });
      } catch (error) {
        return (0, _errorResponse.ErrorResponse)(error.message || error, 5029, 500, response);
      }
    }, ({
      body: {
        agents
      },
      params: {
        moduleID
      }
    }) => `wazuh-module-${agents ? `agents-${agents}` : 'overview'}-${moduleID}-${this.generateReportTimestamp()}.pdf`));
    /**
     * Create a report for the groups
     * @param {Object} context
     * @param {Object} request
     * @param {Object} response
     * @returns {*} reports list or ErrorResponse
     */
    _defineProperty(this, "createReportsGroups", this.checkReportsUserDirectoryIsValidRouteDecorator(async (context, request, response) => {
      try {
        context.wazuh.logger.debug('Report started');
        const {
          components,
          apiId
        } = request.body;
        const {
          groupID
        } = request.params;
        // Init
        const printer = new _printer.ReportPrinter(context.wazuh.logger.get('report-printer'), context.wazuh_core.configuration);
        context.wazuh_core.dataPathService.createDataDirectoryIfNotExists(`downloads/reports/${context.wazuhEndpointParams.hashUsername}`);
        let tables = [];
        const equivalences = {
          localfile: 'Local files',
          osquery: 'Osquery',
          command: 'Command',
          syscheck: 'Syscheck',
          'open-scap': 'OpenSCAP',
          'cis-cat': 'CIS-CAT',
          syscollector: 'Syscollector',
          rootcheck: 'Rootcheck',
          labels: 'Labels',
          sca: 'Security configuration assessment'
        };
        printer.addContent({
          text: `Group ${groupID} configuration`,
          style: 'h1'
        });

        // Group configuration
        if (components['0']) {
          const {
            data: {
              data: configuration
            }
          } = await context.wazuh.api.client.asCurrentUser.request('GET', `/groups/${groupID}/configuration`, {}, {
            apiHostID: apiId
          });
          if (configuration.affected_items.length > 0 && Object.keys(configuration.affected_items[0].config).length) {
            printer.addContent({
              text: 'Configurations',
              style: {
                fontSize: 14,
                color: '#000'
              },
              margin: [0, 10, 0, 15]
            });
            const section = {
              labels: [],
              isGroupConfig: true
            };
            for (let config of configuration.affected_items) {
              let filterTitle = '';
              let index = 0;
              for (let filter of Object.keys(config.filters)) {
                filterTitle = filterTitle.concat(`${filter}: ${config.filters[filter]}`);
                if (index < Object.keys(config.filters).length - 1) {
                  filterTitle = filterTitle.concat(' | ');
                }
                index++;
              }
              printer.addContent({
                text: filterTitle,
                style: 'h4',
                margin: [0, 0, 0, 10]
              });
              let idx = 0;
              section.tabs = [];
              for (let _d of Object.keys(config.config)) {
                for (let c of _agentConfiguration.AgentConfiguration.configurations) {
                  for (let s of c.sections) {
                    section.opts = s.opts || {};
                    for (let cn of s.config || []) {
                      if (cn.configuration === _d) {
                        section.labels = s.labels || [[]];
                      }
                    }
                    for (let wo of s.wodle || []) {
                      if (wo.name === _d) {
                        section.labels = s.labels || [[]];
                      }
                    }
                  }
                }
                section.labels[0]['pack'] = 'Packs';
                section.labels[0]['content'] = 'Evaluations';
                section.labels[0]['7'] = 'Scan listening netwotk ports';
                section.tabs.push(equivalences[_d]);
                if (Array.isArray(config.config[_d])) {
                  /* LOG COLLECTOR */
                  if (_d === 'localfile') {
                    let groups = [];
                    config.config[_d].forEach(obj => {
                      if (!groups[obj.logformat]) {
                        groups[obj.logformat] = [];
                      }
                      groups[obj.logformat].push(obj);
                    });
                    Object.keys(groups).forEach(group => {
                      let saveidx = 0;
                      groups[group].forEach((x, i) => {
                        if (Object.keys(x).length > Object.keys(groups[group][saveidx]).length) {
                          saveidx = i;
                        }
                      });
                      const columns = Object.keys(groups[group][saveidx]);
                      const rows = groups[group].map(x => {
                        let row = [];
                        columns.forEach(key => {
                          row.push(typeof x[key] !== 'object' ? x[key] : Array.isArray(x[key]) ? x[key].map(x => {
                            return x + '\n';
                          }) : JSON.stringify(x[key]));
                        });
                        return row;
                      });
                      columns.forEach((col, i) => {
                        columns[i] = col[0].toUpperCase() + col.slice(1);
                      });
                      tables.push({
                        title: 'Local files',
                        type: 'table',
                        columns,
                        rows
                      });
                    });
                  } else if (_d === 'labels') {
                    const obj = config.config[_d][0].label;
                    const columns = Object.keys(obj[0]);
                    if (!columns.includes('hidden')) {
                      columns.push('hidden');
                    }
                    const rows = obj.map(x => {
                      let row = [];
                      columns.forEach(key => {
                        row.push(x[key]);
                      });
                      return row;
                    });
                    columns.forEach((col, i) => {
                      columns[i] = col[0].toUpperCase() + col.slice(1);
                    });
                    tables.push({
                      title: 'Labels',
                      type: 'table',
                      columns,
                      rows
                    });
                  } else {
                    for (let _d2 of config.config[_d]) {
                      tables.push(...this.getConfigTables(context, _d2, section, idx));
                    }
                  }
                } else {
                  /*INTEGRITY MONITORING MONITORED DIRECTORIES */
                  if (config.config[_d].directories) {
                    const directories = config.config[_d].directories;
                    delete config.config[_d].directories;
                    tables.push(...this.getConfigTables(context, config.config[_d], section, idx));
                    let diffOpts = [];
                    Object.keys(section.opts).forEach(x => {
                      diffOpts.push(x);
                    });
                    const columns = ['', ...diffOpts.filter(x => x !== 'check_all' && x !== 'check_sum')];
                    let rows = [];
                    directories.forEach(x => {
                      let row = [];
                      row.push(x.path);
                      columns.forEach(y => {
                        if (y !== '') {
                          y = y !== 'check_whodata' ? y : 'whodata';
                          row.push(x[y] ? x[y] : 'no');
                        }
                      });
                      row.push(x.recursion_level);
                      rows.push(row);
                    });
                    columns.forEach((x, idx) => {
                      columns[idx] = section.opts[x];
                    });
                    columns.push('RL');
                    tables.push({
                      title: 'Monitored directories',
                      type: 'table',
                      columns,
                      rows
                    });
                  } else {
                    tables.push(...this.getConfigTables(context, config.config[_d], section, idx));
                  }
                }
                for (const table of tables) {
                  printer.addConfigTables([table]);
                }
                idx++;
                tables = [];
              }
              tables = [];
            }
          } else {
            printer.addContent({
              text: 'A configuration for this group has not yet been set up.',
              style: {
                fontSize: 12,
                color: '#000'
              },
              margin: [0, 10, 0, 15]
            });
          }
        }

        // Agents in group
        if (components['1']) {
          await this.renderHeader(context, printer, 'groupConfig', groupID, [], apiId);
        }
        await printer.print(context.wazuhEndpointParams.pathFilename);
        return response.ok({
          body: {
            success: true,
            message: `Report ${context.wazuhEndpointParams.filename} was created`,
            filename: context.wazuhEndpointParams.filename
          }
        });
      } catch (error) {
        context.wazuh.logger.error(error.message || error);
        return (0, _errorResponse.ErrorResponse)(error.message || error, 5029, 500, response);
      }
    }, ({
      params: {
        groupID
      }
    }) => `wazuh-group-configuration-${groupID}-${this.generateReportTimestamp()}.pdf`));
    /**
     * Create a report for the agents
     * @param {Object} context
     * @param {Object} request
     * @param {Object} response
     * @returns {*} reports list or ErrorResponse
     */
    _defineProperty(this, "createReportsAgentsConfiguration", this.checkReportsUserDirectoryIsValidRouteDecorator(async (context, request, response) => {
      try {
        context.wazuh.logger.debug('Report started');
        const {
          components,
          apiId
        } = request.body;
        const {
          agentID
        } = request.params;
        const printer = new _printer.ReportPrinter(context.wazuh.logger.get('report-printer'), context.wazuh_core.configuration);
        context.wazuh_core.dataPathService.createDataDirectoryIfNotExists(`downloads/reports/${context.wazuhEndpointParams.hashUsername}`);
        let wmodulesResponse = {};
        let tables = [];
        try {
          wmodulesResponse = await context.wazuh.api.client.asCurrentUser.request('GET', `/agents/${agentID}/config/wmodules/wmodules`, {}, {
            apiHostID: apiId
          });
        } catch (error) {
          context.wazuh.logger.debug(error.message || error);
        }
        await this.renderHeader(context, printer, 'agentConfig', 'agentConfig', agentID, apiId);
        let idxComponent = 0;
        for (let config of _agentConfiguration.AgentConfiguration.configurations) {
          let titleOfSection = false;
          context.wazuh.logger.debug(`Iterate over ${config.sections.length} configuration sections`);
          for (let section of config.sections) {
            let titleOfSubsection = false;
            if (components[idxComponent] && (section.config || section.wodle)) {
              let idx = 0;
              const configs = (section.config || []).concat(section.wodle || []);
              context.wazuh.logger.debug(`Iterate over ${configs.length} configuration blocks`);
              for (let conf of configs) {
                let agentConfigResponse = {};
                try {
                  if (!conf['name']) {
                    agentConfigResponse = await context.wazuh.api.client.asCurrentUser.request('GET', `/agents/${agentID}/config/${conf.component}/${conf.configuration}`, {}, {
                      apiHostID: apiId
                    });
                  } else {
                    for (let wodle of wmodulesResponse.data.data['wmodules']) {
                      if (Object.keys(wodle)[0] === conf['name']) {
                        agentConfigResponse.data = {
                          data: wodle
                        };
                      }
                    }
                  }
                  const agentConfig = agentConfigResponse && agentConfigResponse.data && agentConfigResponse.data.data;
                  if (!titleOfSection) {
                    printer.addContent({
                      text: config.title,
                      style: 'h1',
                      margin: [0, 0, 0, 15]
                    });
                    titleOfSection = true;
                  }
                  if (!titleOfSubsection) {
                    printer.addContent({
                      text: section.subtitle,
                      style: 'h4'
                    });
                    printer.addContent({
                      text: section.desc,
                      style: {
                        fontSize: 12,
                        color: '#000'
                      },
                      margin: [0, 0, 0, 10]
                    });
                    titleOfSubsection = true;
                  }
                  if (agentConfig) {
                    for (let agentConfigKey of Object.keys(agentConfig)) {
                      if (Array.isArray(agentConfig[agentConfigKey])) {
                        /* LOG COLLECTOR */
                        if (conf.filterBy) {
                          let groups = [];
                          agentConfig[agentConfigKey].forEach(obj => {
                            if (!groups[obj.logformat]) {
                              groups[obj.logformat] = [];
                            }
                            groups[obj.logformat].push(obj);
                          });
                          Object.keys(groups).forEach(group => {
                            let saveidx = 0;
                            groups[group].forEach((x, i) => {
                              if (Object.keys(x).length > Object.keys(groups[group][saveidx]).length) {
                                saveidx = i;
                              }
                            });
                            const columns = Object.keys(groups[group][saveidx]);
                            const rows = groups[group].map(x => {
                              let row = [];
                              columns.forEach(key => {
                                row.push(typeof x[key] !== 'object' ? x[key] : Array.isArray(x[key]) ? x[key].map(x => {
                                  return x + '\n';
                                }) : JSON.stringify(x[key]));
                              });
                              return row;
                            });
                            columns.forEach((col, i) => {
                              columns[i] = col[0].toUpperCase() + col.slice(1);
                            });
                            tables.push({
                              title: section.labels[0][group],
                              type: 'table',
                              columns,
                              rows
                            });
                          });
                        } else if (agentConfigKey.configuration !== 'socket') {
                          tables.push(...this.getConfigTables(context, agentConfig[agentConfigKey], section, idx));
                        } else {
                          for (let _d2 of agentConfig[agentConfigKey]) {
                            tables.push(...this.getConfigTables(context, _d2, section, idx));
                          }
                        }
                      } else {
                        /* INTEGRITY MONITORING MONITORED DIRECTORIES */
                        if (conf.matrix) {
                          const {
                            directories,
                            diff,
                            synchronization,
                            file_limit,
                            ...rest
                          } = agentConfig[agentConfigKey];
                          tables.push(...this.getConfigTables(context, rest, section, idx), ...(diff && diff.disk_quota ? this.getConfigTables(context, diff.disk_quota, {
                            tabs: ['Disk quota']
                          }, 0) : []), ...(diff && diff.file_size ? this.getConfigTables(context, diff.file_size, {
                            tabs: ['File size']
                          }, 0) : []), ...(synchronization ? this.getConfigTables(context, synchronization, {
                            tabs: ['Synchronization']
                          }, 0) : []), ...(file_limit ? this.getConfigTables(context, file_limit, {
                            tabs: ['File limit']
                          }, 0) : []));
                          let diffOpts = [];
                          Object.keys(section.opts).forEach(x => {
                            diffOpts.push(x);
                          });
                          const columns = ['', ...diffOpts.filter(x => x !== 'check_all' && x !== 'check_sum')];
                          let rows = [];
                          directories.forEach(x => {
                            let row = [];
                            row.push(x.dir);
                            columns.forEach(y => {
                              if (y !== '') {
                                row.push(x.opts.indexOf(y) > -1 ? 'yes' : 'no');
                              }
                            });
                            row.push(x.recursion_level);
                            rows.push(row);
                          });
                          columns.forEach((x, idx) => {
                            columns[idx] = section.opts[x];
                          });
                          columns.push('RL');
                          tables.push({
                            title: 'Monitored directories',
                            type: 'table',
                            columns,
                            rows
                          });
                        } else {
                          tables.push(...this.getConfigTables(context, agentConfig[agentConfigKey], section, idx));
                        }
                      }
                    }
                  } else {
                    // Print no configured module and link to the documentation
                    printer.addContent({
                      text: ['This module is not configured. Please take a look on how to configure it in ', {
                        text: `${section.subtitle.toLowerCase()} configuration.`,
                        link: section.docuLink,
                        style: {
                          fontSize: 12,
                          color: '#1a0dab'
                        }
                      }],
                      margin: [0, 0, 0, 20]
                    });
                  }
                } catch (error) {
                  context.wazuh.logger.debug(error.message || error);
                }
                idx++;
              }
              for (const table of tables) {
                printer.addConfigTables([table]);
              }
            }
            idxComponent++;
            tables = [];
          }
        }
        await printer.print(context.wazuhEndpointParams.pathFilename);
        return response.ok({
          body: {
            success: true,
            message: `Report ${context.wazuhEndpointParams.filename} was created`,
            filename: context.wazuhEndpointParams.filename
          }
        });
      } catch (error) {
        context.wazuh.logger.debug(error.message || error);
        return (0, _errorResponse.ErrorResponse)(error.message || error, 5029, 500, response);
      }
    }, ({
      params: {
        agentID
      }
    }) => `wazuh-agent-configuration-${agentID}-${this.generateReportTimestamp()}.pdf`));
    /**
     * Fetch specific report
     * @param {Object} context
     * @param {Object} request
     * @param {Object} response
     * @returns {Object} report or ErrorResponse
     */
    _defineProperty(this, "getReportByName", this.checkReportsUserDirectoryIsValidRouteDecorator(async (context, request, response) => {
      try {
        context.wazuh.logger.debug(`Getting ${context.wazuhEndpointParams.pathFilename} report`);
        const reportFileBuffer = _fs.default.readFileSync(context.wazuhEndpointParams.pathFilename);
        return response.ok({
          headers: {
            'Content-Type': 'application/pdf'
          },
          body: reportFileBuffer
        });
      } catch (error) {
        context.wazuh.logger.error(error.message || error);
        return (0, _errorResponse.ErrorResponse)(error.message || error, 5030, 500, response);
      }
    }, request => request.params.name));
    /**
     * Delete specific report
     * @param {Object} context
     * @param {Object} request
     * @param {Object} response
     * @returns {Object} status obj or ErrorResponse
     */
    _defineProperty(this, "deleteReportByName", this.checkReportsUserDirectoryIsValidRouteDecorator(async (context, request, response) => {
      try {
        context.wazuh.logger.debug(`Deleting ${context.wazuhEndpointParams.pathFilename} report`);
        _fs.default.unlinkSync(context.wazuhEndpointParams.pathFilename);
        context.wazuh.logger.info(`${context.wazuhEndpointParams.pathFilename} report was deleted`);
        return response.ok({
          body: {
            error: 0
          }
        });
      } catch (error) {
        context.wazuh.logger.error(error.message || error);
        return (0, _errorResponse.ErrorResponse)(error.message || error, 5032, 500, response);
      }
    }, request => request.params.name));
  }
  /**
   * This do format to filters
   * @param {String} filters E.g: cluster.name: wazuh AND rule.groups: vulnerability
   * @param {String} searchBar search term
   */
  sanitizeKibanaFilters(context, filters, searchBar) {
    context.wazuh.logger.debug(`Started to sanitize filters. filters: ${filters.length}, searchBar: ${searchBar}`);
    let str = '';
    const agentsFilter = {
      query: {},
      agentsText: ''
    };
    const agentsList = [];

    //separate agents filter
    filters = filters.filter(filter => {
      if (filter.meta.controlledBy === _constants.AUTHORIZED_AGENTS) {
        agentsFilter.query = filter.query;
        agentsList.push(filter);
        return false;
      }
      return filter;
    });
    const len = filters.length;
    for (let i = 0; i < len; i++) {
      const {
        negate,
        key,
        value,
        params,
        type
      } = filters[i].meta;
      str += `${negate ? 'NOT ' : ''}`;
      str += `${key}: `;
      str += `${type === 'range' ? `${params.gte}-${params.lt}` : type === 'phrases' ? '(' + params.join(' OR ') + ')' : type === 'exists' ? '*' : !!value ? value : (params || {}).query}`;
      str += `${i === len - 1 ? '' : ' AND '}`;
    }
    if (searchBar) {
      str += ` AND (${searchBar})`;
    }
    agentsFilter.agentsText = agentsList.map(filter => filter.meta.value).join(',');
    context.wazuh.logger.debug(`str: ${str}, agentsFilterStr: ${agentsFilter.agentsText}`);
    return [str, agentsFilter];
  }

  /**
   * This performs the rendering of given header
   * @param {String} printer section target
   * @param {String} section section target
   * @param {Object} tab tab target
   * @param {Boolean} isAgents is agents section
   * @param {String} apiId ID of API
   */
  async renderHeader(context, printer, section, tab, isAgents, apiId) {
    try {
      context.wazuh.logger.debug(`section: ${section}, tab: ${tab}, isAgents: ${isAgents}, apiId: ${apiId}`);
      if (section && typeof section === 'string') {
        if (!['agentConfig', 'groupConfig'].includes(section)) {
          printer.addContent({
            text: _wazuhModules.WAZUH_MODULES[tab].title + ' report',
            style: 'h1'
          });
        } else if (section === 'agentConfig') {
          printer.addContent({
            text: `Agent ${isAgents} configuration`,
            style: 'h1'
          });
        } else if (section === 'groupConfig') {
          printer.addContent({
            text: 'Agents in group',
            style: 'h1'
          });
        }
        printer.addNewLine();
      }
      if (isAgents && typeof isAgents === 'object') {
        await (0, _extendedInformation.buildAgentsTable)(context, printer, isAgents, apiId, section === 'groupConfig' ? tab : '');
      }
      if (isAgents && typeof isAgents === 'string') {
        const agentResponse = await context.wazuh.api.client.asCurrentUser.request('GET', `/agents`, {
          params: {
            agents_list: isAgents
          }
        }, {
          apiHostID: apiId
        });
        const agentData = agentResponse.data.data.affected_items[0];
        if (agentData && agentData.status !== _constants.API_NAME_AGENT_STATUS.ACTIVE) {
          printer.addContentWithNewLine({
            text: `Warning. Agent is ${(0, _wz_agent_status.agentStatusLabelByAgentStatus)(agentData.status).toLowerCase()}`,
            style: 'standard'
          });
        }
        await (0, _extendedInformation.buildAgentsTable)(context, printer, [isAgents], apiId);
        if (agentData && agentData.group) {
          const agentGroups = agentData.group.join(', ');
          printer.addContentWithNewLine({
            text: `Group${agentData.group.length > 1 ? 's' : ''}: ${agentGroups}`,
            style: 'standard'
          });
        }
      }
      if (_wazuhModules.WAZUH_MODULES[tab] && _wazuhModules.WAZUH_MODULES[tab].description) {
        printer.addContentWithNewLine({
          text: _wazuhModules.WAZUH_MODULES[tab].description,
          style: 'standard'
        });
      }
    } catch (error) {
      context.wazuh.logger.error(error.message || error);
      return Promise.reject(error);
    }
  }
  getConfigRows(context, data, labels) {
    context.wazuh.logger.debug('Building configuration rows');
    const result = [];
    for (let prop in data || []) {
      if (Array.isArray(data[prop])) {
        data[prop].forEach((x, idx) => {
          if (typeof x === 'object') data[prop][idx] = JSON.stringify(x);
        });
      }
      result.push([(labels || {})[prop] || _csvKeyEquivalence.KeyEquivalence[prop] || prop, data[prop] || '-']);
    }
    return result;
  }
  getConfigTables(context, data, section, tab, array = []) {
    context.wazuh.logger.debug('Building configuration tables');
    let plainData = {};
    const nestedData = [];
    const tableData = [];
    if (data.length === 1 && Array.isArray(data)) {
      tableData[section.config[tab].configuration] = data;
    } else {
      for (let key in data) {
        if (typeof data[key] !== 'object' && !Array.isArray(data[key]) || Array.isArray(data[key]) && typeof data[key][0] !== 'object') {
          plainData[key] = Array.isArray(data[key]) && typeof data[key][0] !== 'object' ? data[key].map(x => {
            return typeof x === 'object' ? JSON.stringify(x) : x + '\n';
          }) : data[key];
        } else if (Array.isArray(data[key]) && typeof data[key][0] === 'object') {
          tableData[key] = data[key];
        } else {
          if (section.isGroupConfig && ['pack', 'content'].includes(key)) {
            tableData[key] = [data[key]];
          } else {
            nestedData.push(data[key]);
          }
        }
      }
    }
    array.push({
      title: (section.options || {}).hideHeader ? '' : (section.tabs || [])[tab] || (section.isGroupConfig ? ((section.labels || [])[0] || [])[tab] : ''),
      columns: ['', ''],
      type: 'config',
      rows: this.getConfigRows(context, plainData, (section.labels || [])[0])
    });
    for (let key in tableData) {
      const columns = Object.keys(tableData[key][0]);
      columns.forEach((col, i) => {
        columns[i] = col[0].toUpperCase() + col.slice(1);
      });
      const rows = tableData[key].map(x => {
        let row = [];
        for (let key in x) {
          row.push(typeof x[key] !== 'object' ? x[key] : Array.isArray(x[key]) ? x[key].map(x => {
            return x + '\n';
          }) : JSON.stringify(x[key]));
        }
        while (row.length < columns.length) {
          row.push('-');
        }
        return row;
      });
      array.push({
        title: ((section.labels || [])[0] || [])[key] || '',
        type: 'table',
        columns,
        rows
      });
    }
    nestedData.forEach(nest => {
      this.getConfigTables(context, nest, section, tab + 1, array);
    });
    return array;
  }
  /**
   * Fetch the reports list
   * @param {Object} context
   * @param {Object} request
   * @param {Object} response
   * @returns {Array<Object>} reports list or ErrorResponse
   */
  async getReports(context, request, response) {
    try {
      context.wazuh.logger.debug('Fetching created reports');
      const {
        hashUsername
      } = await context.wazuh.security.getCurrentUser(request, context);
      const userReportsDirectoryPath = context.wazuh_core.dataPathService.createDataDirectoryIfNotExists(`downloads/reports/${hashUsername}`);
      context.wazuh.logger.debug(`Directory: ${userReportsDirectoryPath}`);
      const sortReportsByDate = (a, b) => a.date < b.date ? 1 : a.date > b.date ? -1 : 0;
      const reports = _fs.default.readdirSync(userReportsDirectoryPath).map(file => {
        const stats = _fs.default.statSync(userReportsDirectoryPath + '/' + file);
        // Get the file creation time (bithtime). It returns the first value that is a truthy value of next file stats: birthtime, mtime, ctime and atime.
        // This solves some OSs can have the bithtimeMs equal to 0 and returns the date like 1970-01-01
        const birthTimeField = ['birthtime', 'mtime', 'ctime', 'atime'].find(time => stats[`${time}Ms`]);
        return {
          name: file,
          size: stats.size,
          date: stats[birthTimeField]
        };
      });
      context.wazuh.logger.debug(`Using TimSort for sorting ${reports.length} items`);
      TimSort.sort(reports, sortReportsByDate);
      context.wazuh.logger.debug(`Total reports: ${reports.length}`);
      return response.ok({
        body: {
          reports
        }
      });
    } catch (error) {
      context.wazuh.logger.error(error.message || error);
      return (0, _errorResponse.ErrorResponse)(error.message || error, 5031, 500, response);
    }
  }
  checkReportsUserDirectoryIsValidRouteDecorator(routeHandler, reportFileNameAccessor) {
    return async (context, request, response) => {
      try {
        const {
          username,
          hashUsername
        } = await context.wazuh.security.getCurrentUser(request, context);
        const userReportsDirectoryPath = _path.default.join(context.wazuh_core.dataPathService.getDataDirectoryRelative('downloads/reports'), hashUsername);
        const filename = reportFileNameAccessor(request);
        const pathFilename = _path.default.join(userReportsDirectoryPath, filename);
        context.wazuh.logger.debug(`Checking the user ${username}(${hashUsername}) can do actions in the reports file: ${pathFilename}`);
        if (!pathFilename.startsWith(userReportsDirectoryPath) || pathFilename.includes('../')) {
          context.wazuh.logger.warn(`User ${username}(${hashUsername}) tried to access to a non user report file: ${pathFilename}`);
          return response.badRequest({
            body: {
              message: '5040 - You shall not pass!'
            }
          });
        }
        context.wazuh.logger.debug('Checking the user can do actions in the reports file');
        return await routeHandler.bind(this)({
          ...context,
          wazuhEndpointParams: {
            hashUsername,
            filename,
            pathFilename
          }
        }, request, response);
      } catch (error) {
        context.wazuh.logger.error(error.message || error);
        return (0, _errorResponse.ErrorResponse)(error.message || error, 5040, 500, response);
      }
    };
  }
  generateReportTimestamp() {
    return `${Date.now() / 1000 | 0}`;
  }
}
exports.WazuhReportingCtrl = WazuhReportingCtrl;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfcGF0aCIsIl9pbnRlcm9wUmVxdWlyZURlZmF1bHQiLCJyZXF1aXJlIiwiX2ZzIiwiX3dhenVoTW9kdWxlcyIsIlRpbVNvcnQiLCJfaW50ZXJvcFJlcXVpcmVXaWxkY2FyZCIsIl9lcnJvclJlc3BvbnNlIiwiX2NzdktleUVxdWl2YWxlbmNlIiwiX2FnZW50Q29uZmlndXJhdGlvbiIsIl9leHRlbmRlZEluZm9ybWF0aW9uIiwiX3ByaW50ZXIiLCJfY29uc3RhbnRzIiwiX3d6X2FnZW50X3N0YXR1cyIsIl9nZXRSZXF1aXJlV2lsZGNhcmRDYWNoZSIsImUiLCJXZWFrTWFwIiwiciIsInQiLCJfX2VzTW9kdWxlIiwiZGVmYXVsdCIsImhhcyIsImdldCIsIm4iLCJfX3Byb3RvX18iLCJhIiwiT2JqZWN0IiwiZGVmaW5lUHJvcGVydHkiLCJnZXRPd25Qcm9wZXJ0eURlc2NyaXB0b3IiLCJ1IiwiaGFzT3duUHJvcGVydHkiLCJjYWxsIiwiaSIsInNldCIsIl9kZWZpbmVQcm9wZXJ0eSIsIl90b1Byb3BlcnR5S2V5IiwidmFsdWUiLCJlbnVtZXJhYmxlIiwiY29uZmlndXJhYmxlIiwid3JpdGFibGUiLCJfdG9QcmltaXRpdmUiLCJTeW1ib2wiLCJ0b1ByaW1pdGl2ZSIsIlR5cGVFcnJvciIsIlN0cmluZyIsIk51bWJlciIsIldhenVoUmVwb3J0aW5nQ3RybCIsImNvbnN0cnVjdG9yIiwiY2hlY2tSZXBvcnRzVXNlckRpcmVjdG9yeUlzVmFsaWRSb3V0ZURlY29yYXRvciIsImNvbnRleHQiLCJyZXF1ZXN0IiwicmVzcG9uc2UiLCJ3YXp1aCIsImxvZ2dlciIsImRlYnVnIiwiYXJyYXkiLCJhZ2VudHMiLCJicm93c2VyVGltZXpvbmUiLCJzZWFyY2hCYXIiLCJmaWx0ZXJzIiwic2VydmVyU2lkZVF1ZXJ5IiwidGltZSIsInRhYmxlcyIsInNlY3Rpb24iLCJpbmRleFBhdHRlcm5UaXRsZSIsImFwaUlkIiwiYm9keSIsIm1vZHVsZUlEIiwicGFyYW1zIiwiZnJvbSIsInRvIiwiYWRkaXRpb25hbFRhYmxlcyIsInByaW50ZXIiLCJSZXBvcnRQcmludGVyIiwid2F6dWhfY29yZSIsImNvbmZpZ3VyYXRpb24iLCJkYXRhUGF0aFNlcnZpY2UiLCJjcmVhdGVEYXRhRGlyZWN0b3J5SWZOb3RFeGlzdHMiLCJ3YXp1aEVuZHBvaW50UGFyYW1zIiwiaGFzaFVzZXJuYW1lIiwicmVuZGVySGVhZGVyIiwic2FuaXRpemVkRmlsdGVycyIsImFnZW50c0ZpbHRlciIsInNhbml0aXplS2liYW5hRmlsdGVycyIsImFkZFRpbWVSYW5nZUFuZEZpbHRlcnMiLCJleHRlbmRlZEluZm9ybWF0aW9uIiwiRGF0ZSIsImdldFRpbWUiLCJnZXRTZXR0aW5nVmFsdWUiLCJhZGRWaXN1YWxpemF0aW9ucyIsImFkZFRhYmxlcyIsInByaW50IiwicGF0aEZpbGVuYW1lIiwib2siLCJzdWNjZXNzIiwibWVzc2FnZSIsImZpbGVuYW1lIiwiZXJyb3IiLCJFcnJvclJlc3BvbnNlIiwiZ2VuZXJhdGVSZXBvcnRUaW1lc3RhbXAiLCJjb21wb25lbnRzIiwiZ3JvdXBJRCIsImVxdWl2YWxlbmNlcyIsImxvY2FsZmlsZSIsIm9zcXVlcnkiLCJjb21tYW5kIiwic3lzY2hlY2siLCJzeXNjb2xsZWN0b3IiLCJyb290Y2hlY2siLCJsYWJlbHMiLCJzY2EiLCJhZGRDb250ZW50IiwidGV4dCIsInN0eWxlIiwiZGF0YSIsImFwaSIsImNsaWVudCIsImFzQ3VycmVudFVzZXIiLCJhcGlIb3N0SUQiLCJhZmZlY3RlZF9pdGVtcyIsImxlbmd0aCIsImtleXMiLCJjb25maWciLCJmb250U2l6ZSIsImNvbG9yIiwibWFyZ2luIiwiaXNHcm91cENvbmZpZyIsImZpbHRlclRpdGxlIiwiaW5kZXgiLCJmaWx0ZXIiLCJjb25jYXQiLCJpZHgiLCJ0YWJzIiwiX2QiLCJjIiwiQWdlbnRDb25maWd1cmF0aW9uIiwiY29uZmlndXJhdGlvbnMiLCJzIiwic2VjdGlvbnMiLCJvcHRzIiwiY24iLCJ3byIsIndvZGxlIiwibmFtZSIsInB1c2giLCJBcnJheSIsImlzQXJyYXkiLCJncm91cHMiLCJmb3JFYWNoIiwib2JqIiwibG9nZm9ybWF0IiwiZ3JvdXAiLCJzYXZlaWR4IiwieCIsImNvbHVtbnMiLCJyb3dzIiwibWFwIiwicm93Iiwia2V5IiwiSlNPTiIsInN0cmluZ2lmeSIsImNvbCIsInRvVXBwZXJDYXNlIiwic2xpY2UiLCJ0aXRsZSIsInR5cGUiLCJsYWJlbCIsImluY2x1ZGVzIiwiX2QyIiwiZ2V0Q29uZmlnVGFibGVzIiwiZGlyZWN0b3JpZXMiLCJkaWZmT3B0cyIsInBhdGgiLCJ5IiwicmVjdXJzaW9uX2xldmVsIiwidGFibGUiLCJhZGRDb25maWdUYWJsZXMiLCJhZ2VudElEIiwid21vZHVsZXNSZXNwb25zZSIsImlkeENvbXBvbmVudCIsInRpdGxlT2ZTZWN0aW9uIiwidGl0bGVPZlN1YnNlY3Rpb24iLCJjb25maWdzIiwiY29uZiIsImFnZW50Q29uZmlnUmVzcG9uc2UiLCJjb21wb25lbnQiLCJhZ2VudENvbmZpZyIsInN1YnRpdGxlIiwiZGVzYyIsImFnZW50Q29uZmlnS2V5IiwiZmlsdGVyQnkiLCJtYXRyaXgiLCJkaWZmIiwic3luY2hyb25pemF0aW9uIiwiZmlsZV9saW1pdCIsInJlc3QiLCJkaXNrX3F1b3RhIiwiZmlsZV9zaXplIiwiZGlyIiwiaW5kZXhPZiIsInRvTG93ZXJDYXNlIiwibGluayIsImRvY3VMaW5rIiwicmVwb3J0RmlsZUJ1ZmZlciIsImZzIiwicmVhZEZpbGVTeW5jIiwiaGVhZGVycyIsInVubGlua1N5bmMiLCJpbmZvIiwic3RyIiwicXVlcnkiLCJhZ2VudHNUZXh0IiwiYWdlbnRzTGlzdCIsIm1ldGEiLCJjb250cm9sbGVkQnkiLCJBVVRIT1JJWkVEX0FHRU5UUyIsImxlbiIsIm5lZ2F0ZSIsImd0ZSIsImx0Iiwiam9pbiIsInRhYiIsImlzQWdlbnRzIiwiV0FaVUhfTU9EVUxFUyIsImFkZE5ld0xpbmUiLCJidWlsZEFnZW50c1RhYmxlIiwiYWdlbnRSZXNwb25zZSIsImFnZW50c19saXN0IiwiYWdlbnREYXRhIiwic3RhdHVzIiwiQVBJX05BTUVfQUdFTlRfU1RBVFVTIiwiQUNUSVZFIiwiYWRkQ29udGVudFdpdGhOZXdMaW5lIiwiYWdlbnRTdGF0dXNMYWJlbEJ5QWdlbnRTdGF0dXMiLCJhZ2VudEdyb3VwcyIsImRlc2NyaXB0aW9uIiwiUHJvbWlzZSIsInJlamVjdCIsImdldENvbmZpZ1Jvd3MiLCJyZXN1bHQiLCJwcm9wIiwiS2V5RXF1aXZhbGVuY2UiLCJwbGFpbkRhdGEiLCJuZXN0ZWREYXRhIiwidGFibGVEYXRhIiwib3B0aW9ucyIsImhpZGVIZWFkZXIiLCJuZXN0IiwiZ2V0UmVwb3J0cyIsInNlY3VyaXR5IiwiZ2V0Q3VycmVudFVzZXIiLCJ1c2VyUmVwb3J0c0RpcmVjdG9yeVBhdGgiLCJzb3J0UmVwb3J0c0J5RGF0ZSIsImIiLCJkYXRlIiwicmVwb3J0cyIsInJlYWRkaXJTeW5jIiwiZmlsZSIsInN0YXRzIiwic3RhdFN5bmMiLCJiaXJ0aFRpbWVGaWVsZCIsImZpbmQiLCJzaXplIiwic29ydCIsInJvdXRlSGFuZGxlciIsInJlcG9ydEZpbGVOYW1lQWNjZXNzb3IiLCJ1c2VybmFtZSIsImdldERhdGFEaXJlY3RvcnlSZWxhdGl2ZSIsInN0YXJ0c1dpdGgiLCJ3YXJuIiwiYmFkUmVxdWVzdCIsImJpbmQiLCJub3ciLCJleHBvcnRzIl0sInNvdXJjZXMiOlsid2F6dWgtcmVwb3J0aW5nLnRzIl0sInNvdXJjZXNDb250ZW50IjpbIi8qXG4gKiBXYXp1aCBhcHAgLSBDbGFzcyBmb3IgV2F6dWggcmVwb3J0aW5nIGNvbnRyb2xsZXJcbiAqIENvcHlyaWdodCAoQykgMjAxNS0yMDIyIFdhenVoLCBJbmMuXG4gKlxuICogVGhpcyBwcm9ncmFtIGlzIGZyZWUgc29mdHdhcmU7IHlvdSBjYW4gcmVkaXN0cmlidXRlIGl0IGFuZC9vciBtb2RpZnlcbiAqIGl0IHVuZGVyIHRoZSB0ZXJtcyBvZiB0aGUgR05VIEdlbmVyYWwgUHVibGljIExpY2Vuc2UgYXMgcHVibGlzaGVkIGJ5XG4gKiB0aGUgRnJlZSBTb2Z0d2FyZSBGb3VuZGF0aW9uOyBlaXRoZXIgdmVyc2lvbiAyIG9mIHRoZSBMaWNlbnNlLCBvclxuICogKGF0IHlvdXIgb3B0aW9uKSBhbnkgbGF0ZXIgdmVyc2lvbi5cbiAqXG4gKiBGaW5kIG1vcmUgaW5mb3JtYXRpb24gYWJvdXQgdGhpcyBvbiB0aGUgTElDRU5TRSBmaWxlLlxuICovXG5pbXBvcnQgcGF0aCBmcm9tICdwYXRoJztcbmltcG9ydCBmcyBmcm9tICdmcyc7XG5pbXBvcnQgeyBXQVpVSF9NT0RVTEVTIH0gZnJvbSAnLi4vLi4vY29tbW9uL3dhenVoLW1vZHVsZXMnO1xuaW1wb3J0ICogYXMgVGltU29ydCBmcm9tICd0aW1zb3J0JztcbmltcG9ydCB7IEVycm9yUmVzcG9uc2UgfSBmcm9tICcuLi9saWIvZXJyb3ItcmVzcG9uc2UnO1xuaW1wb3J0IHsgS2V5RXF1aXZhbGVuY2UgfSBmcm9tICcuLi8uLi9jb21tb24vY3N2LWtleS1lcXVpdmFsZW5jZSc7XG5pbXBvcnQgeyBBZ2VudENvbmZpZ3VyYXRpb24gfSBmcm9tICcuLi9saWIvcmVwb3J0aW5nL2FnZW50LWNvbmZpZ3VyYXRpb24nO1xuaW1wb3J0IHtcbiAgT3BlblNlYXJjaERhc2hib2FyZHNSZXF1ZXN0LFxuICBSZXF1ZXN0SGFuZGxlckNvbnRleHQsXG4gIE9wZW5TZWFyY2hEYXNoYm9hcmRzUmVzcG9uc2VGYWN0b3J5LFxufSBmcm9tICdzcmMvY29yZS9zZXJ2ZXInO1xuaW1wb3J0IHtcbiAgZXh0ZW5kZWRJbmZvcm1hdGlvbixcbiAgYnVpbGRBZ2VudHNUYWJsZSxcbn0gZnJvbSAnLi4vbGliL3JlcG9ydGluZy9leHRlbmRlZC1pbmZvcm1hdGlvbic7XG5pbXBvcnQgeyBSZXBvcnRQcmludGVyIH0gZnJvbSAnLi4vbGliL3JlcG9ydGluZy9wcmludGVyJztcbmltcG9ydCB7XG4gIEFVVEhPUklaRURfQUdFTlRTLFxuICBBUElfTkFNRV9BR0VOVF9TVEFUVVMsXG59IGZyb20gJy4uLy4uL2NvbW1vbi9jb25zdGFudHMnO1xuXG5pbXBvcnQgeyBhZ2VudFN0YXR1c0xhYmVsQnlBZ2VudFN0YXR1cyB9IGZyb20gJy4uLy4uL2NvbW1vbi9zZXJ2aWNlcy93el9hZ2VudF9zdGF0dXMnO1xuXG5pbnRlcmZhY2UgQWdlbnRzRmlsdGVyIHtcbiAgcXVlcnk6IGFueTtcbiAgYWdlbnRzVGV4dDogc3RyaW5nO1xufVxuXG5leHBvcnQgY2xhc3MgV2F6dWhSZXBvcnRpbmdDdHJsIHtcbiAgY29uc3RydWN0b3IoKSB7fVxuICAvKipcbiAgICogVGhpcyBkbyBmb3JtYXQgdG8gZmlsdGVyc1xuICAgKiBAcGFyYW0ge1N0cmluZ30gZmlsdGVycyBFLmc6IGNsdXN0ZXIubmFtZTogd2F6dWggQU5EIHJ1bGUuZ3JvdXBzOiB2dWxuZXJhYmlsaXR5XG4gICAqIEBwYXJhbSB7U3RyaW5nfSBzZWFyY2hCYXIgc2VhcmNoIHRlcm1cbiAgICovXG4gIHByaXZhdGUgc2FuaXRpemVLaWJhbmFGaWx0ZXJzKFxuICAgIGNvbnRleHQ6IGFueSxcbiAgICBmaWx0ZXJzOiBhbnksXG4gICAgc2VhcmNoQmFyPzogc3RyaW5nLFxuICApOiBbc3RyaW5nLCBBZ2VudHNGaWx0ZXJdIHtcbiAgICBjb250ZXh0LndhenVoLmxvZ2dlci5kZWJ1ZyhcbiAgICAgIGBTdGFydGVkIHRvIHNhbml0aXplIGZpbHRlcnMuIGZpbHRlcnM6ICR7ZmlsdGVycy5sZW5ndGh9LCBzZWFyY2hCYXI6ICR7c2VhcmNoQmFyfWAsXG4gICAgKTtcbiAgICBsZXQgc3RyID0gJyc7XG5cbiAgICBjb25zdCBhZ2VudHNGaWx0ZXI6IEFnZW50c0ZpbHRlciA9IHsgcXVlcnk6IHt9LCBhZ2VudHNUZXh0OiAnJyB9O1xuICAgIGNvbnN0IGFnZW50c0xpc3Q6IHN0cmluZ1tdID0gW107XG5cbiAgICAvL3NlcGFyYXRlIGFnZW50cyBmaWx0ZXJcbiAgICBmaWx0ZXJzID0gZmlsdGVycy5maWx0ZXIoZmlsdGVyID0+IHtcbiAgICAgIGlmIChmaWx0ZXIubWV0YS5jb250cm9sbGVkQnkgPT09IEFVVEhPUklaRURfQUdFTlRTKSB7XG4gICAgICAgIGFnZW50c0ZpbHRlci5xdWVyeSA9IGZpbHRlci5xdWVyeTtcbiAgICAgICAgYWdlbnRzTGlzdC5wdXNoKGZpbHRlcik7XG4gICAgICAgIHJldHVybiBmYWxzZTtcbiAgICAgIH1cbiAgICAgIHJldHVybiBmaWx0ZXI7XG4gICAgfSk7XG5cbiAgICBjb25zdCBsZW4gPSBmaWx0ZXJzLmxlbmd0aDtcblxuICAgIGZvciAobGV0IGkgPSAwOyBpIDwgbGVuOyBpKyspIHtcbiAgICAgIGNvbnN0IHsgbmVnYXRlLCBrZXksIHZhbHVlLCBwYXJhbXMsIHR5cGUgfSA9IGZpbHRlcnNbaV0ubWV0YTtcbiAgICAgIHN0ciArPSBgJHtuZWdhdGUgPyAnTk9UICcgOiAnJ31gO1xuICAgICAgc3RyICs9IGAke2tleX06IGA7XG4gICAgICBzdHIgKz0gYCR7XG4gICAgICAgIHR5cGUgPT09ICdyYW5nZSdcbiAgICAgICAgICA/IGAke3BhcmFtcy5ndGV9LSR7cGFyYW1zLmx0fWBcbiAgICAgICAgICA6IHR5cGUgPT09ICdwaHJhc2VzJ1xuICAgICAgICAgID8gJygnICsgcGFyYW1zLmpvaW4oJyBPUiAnKSArICcpJ1xuICAgICAgICAgIDogdHlwZSA9PT0gJ2V4aXN0cydcbiAgICAgICAgICA/ICcqJ1xuICAgICAgICAgIDogISF2YWx1ZVxuICAgICAgICAgID8gdmFsdWVcbiAgICAgICAgICA6IChwYXJhbXMgfHwge30pLnF1ZXJ5XG4gICAgICB9YDtcbiAgICAgIHN0ciArPSBgJHtpID09PSBsZW4gLSAxID8gJycgOiAnIEFORCAnfWA7XG4gICAgfVxuXG4gICAgaWYgKHNlYXJjaEJhcikge1xuICAgICAgc3RyICs9IGAgQU5EICgke3NlYXJjaEJhcn0pYDtcbiAgICB9XG5cbiAgICBhZ2VudHNGaWx0ZXIuYWdlbnRzVGV4dCA9IGFnZW50c0xpc3RcbiAgICAgIC5tYXAoZmlsdGVyID0+IGZpbHRlci5tZXRhLnZhbHVlKVxuICAgICAgLmpvaW4oJywnKTtcblxuICAgIGNvbnRleHQud2F6dWgubG9nZ2VyLmRlYnVnKFxuICAgICAgYHN0cjogJHtzdHJ9LCBhZ2VudHNGaWx0ZXJTdHI6ICR7YWdlbnRzRmlsdGVyLmFnZW50c1RleHR9YCxcbiAgICApO1xuXG4gICAgcmV0dXJuIFtzdHIsIGFnZW50c0ZpbHRlcl07XG4gIH1cblxuICAvKipcbiAgICogVGhpcyBwZXJmb3JtcyB0aGUgcmVuZGVyaW5nIG9mIGdpdmVuIGhlYWRlclxuICAgKiBAcGFyYW0ge1N0cmluZ30gcHJpbnRlciBzZWN0aW9uIHRhcmdldFxuICAgKiBAcGFyYW0ge1N0cmluZ30gc2VjdGlvbiBzZWN0aW9uIHRhcmdldFxuICAgKiBAcGFyYW0ge09iamVjdH0gdGFiIHRhYiB0YXJnZXRcbiAgICogQHBhcmFtIHtCb29sZWFufSBpc0FnZW50cyBpcyBhZ2VudHMgc2VjdGlvblxuICAgKiBAcGFyYW0ge1N0cmluZ30gYXBpSWQgSUQgb2YgQVBJXG4gICAqL1xuICBwcml2YXRlIGFzeW5jIHJlbmRlckhlYWRlcihjb250ZXh0LCBwcmludGVyLCBzZWN0aW9uLCB0YWIsIGlzQWdlbnRzLCBhcGlJZCkge1xuICAgIHRyeSB7XG4gICAgICBjb250ZXh0LndhenVoLmxvZ2dlci5kZWJ1ZyhcbiAgICAgICAgYHNlY3Rpb246ICR7c2VjdGlvbn0sIHRhYjogJHt0YWJ9LCBpc0FnZW50czogJHtpc0FnZW50c30sIGFwaUlkOiAke2FwaUlkfWAsXG4gICAgICApO1xuICAgICAgaWYgKHNlY3Rpb24gJiYgdHlwZW9mIHNlY3Rpb24gPT09ICdzdHJpbmcnKSB7XG4gICAgICAgIGlmICghWydhZ2VudENvbmZpZycsICdncm91cENvbmZpZyddLmluY2x1ZGVzKHNlY3Rpb24pKSB7XG4gICAgICAgICAgcHJpbnRlci5hZGRDb250ZW50KHtcbiAgICAgICAgICAgIHRleHQ6IFdBWlVIX01PRFVMRVNbdGFiXS50aXRsZSArICcgcmVwb3J0JyxcbiAgICAgICAgICAgIHN0eWxlOiAnaDEnLFxuICAgICAgICAgIH0pO1xuICAgICAgICB9IGVsc2UgaWYgKHNlY3Rpb24gPT09ICdhZ2VudENvbmZpZycpIHtcbiAgICAgICAgICBwcmludGVyLmFkZENvbnRlbnQoe1xuICAgICAgICAgICAgdGV4dDogYEFnZW50ICR7aXNBZ2VudHN9IGNvbmZpZ3VyYXRpb25gLFxuICAgICAgICAgICAgc3R5bGU6ICdoMScsXG4gICAgICAgICAgfSk7XG4gICAgICAgIH0gZWxzZSBpZiAoc2VjdGlvbiA9PT0gJ2dyb3VwQ29uZmlnJykge1xuICAgICAgICAgIHByaW50ZXIuYWRkQ29udGVudCh7XG4gICAgICAgICAgICB0ZXh0OiAnQWdlbnRzIGluIGdyb3VwJyxcbiAgICAgICAgICAgIHN0eWxlOiAnaDEnLFxuICAgICAgICAgIH0pO1xuICAgICAgICB9XG4gICAgICAgIHByaW50ZXIuYWRkTmV3TGluZSgpO1xuICAgICAgfVxuXG4gICAgICBpZiAoaXNBZ2VudHMgJiYgdHlwZW9mIGlzQWdlbnRzID09PSAnb2JqZWN0Jykge1xuICAgICAgICBhd2FpdCBidWlsZEFnZW50c1RhYmxlKFxuICAgICAgICAgIGNvbnRleHQsXG4gICAgICAgICAgcHJpbnRlcixcbiAgICAgICAgICBpc0FnZW50cyxcbiAgICAgICAgICBhcGlJZCxcbiAgICAgICAgICBzZWN0aW9uID09PSAnZ3JvdXBDb25maWcnID8gdGFiIDogJycsXG4gICAgICAgICk7XG4gICAgICB9XG5cbiAgICAgIGlmIChpc0FnZW50cyAmJiB0eXBlb2YgaXNBZ2VudHMgPT09ICdzdHJpbmcnKSB7XG4gICAgICAgIGNvbnN0IGFnZW50UmVzcG9uc2UgPVxuICAgICAgICAgIGF3YWl0IGNvbnRleHQud2F6dWguYXBpLmNsaWVudC5hc0N1cnJlbnRVc2VyLnJlcXVlc3QoXG4gICAgICAgICAgICAnR0VUJyxcbiAgICAgICAgICAgIGAvYWdlbnRzYCxcbiAgICAgICAgICAgIHsgcGFyYW1zOiB7IGFnZW50c19saXN0OiBpc0FnZW50cyB9IH0sXG4gICAgICAgICAgICB7IGFwaUhvc3RJRDogYXBpSWQgfSxcbiAgICAgICAgICApO1xuICAgICAgICBjb25zdCBhZ2VudERhdGEgPSBhZ2VudFJlc3BvbnNlLmRhdGEuZGF0YS5hZmZlY3RlZF9pdGVtc1swXTtcbiAgICAgICAgaWYgKGFnZW50RGF0YSAmJiBhZ2VudERhdGEuc3RhdHVzICE9PSBBUElfTkFNRV9BR0VOVF9TVEFUVVMuQUNUSVZFKSB7XG4gICAgICAgICAgcHJpbnRlci5hZGRDb250ZW50V2l0aE5ld0xpbmUoe1xuICAgICAgICAgICAgdGV4dDogYFdhcm5pbmcuIEFnZW50IGlzICR7YWdlbnRTdGF0dXNMYWJlbEJ5QWdlbnRTdGF0dXMoXG4gICAgICAgICAgICAgIGFnZW50RGF0YS5zdGF0dXMsXG4gICAgICAgICAgICApLnRvTG93ZXJDYXNlKCl9YCxcbiAgICAgICAgICAgIHN0eWxlOiAnc3RhbmRhcmQnLFxuICAgICAgICAgIH0pO1xuICAgICAgICB9XG4gICAgICAgIGF3YWl0IGJ1aWxkQWdlbnRzVGFibGUoY29udGV4dCwgcHJpbnRlciwgW2lzQWdlbnRzXSwgYXBpSWQpO1xuXG4gICAgICAgIGlmIChhZ2VudERhdGEgJiYgYWdlbnREYXRhLmdyb3VwKSB7XG4gICAgICAgICAgY29uc3QgYWdlbnRHcm91cHMgPSBhZ2VudERhdGEuZ3JvdXAuam9pbignLCAnKTtcbiAgICAgICAgICBwcmludGVyLmFkZENvbnRlbnRXaXRoTmV3TGluZSh7XG4gICAgICAgICAgICB0ZXh0OiBgR3JvdXAke1xuICAgICAgICAgICAgICBhZ2VudERhdGEuZ3JvdXAubGVuZ3RoID4gMSA/ICdzJyA6ICcnXG4gICAgICAgICAgICB9OiAke2FnZW50R3JvdXBzfWAsXG4gICAgICAgICAgICBzdHlsZTogJ3N0YW5kYXJkJyxcbiAgICAgICAgICB9KTtcbiAgICAgICAgfVxuICAgICAgfVxuICAgICAgaWYgKFdBWlVIX01PRFVMRVNbdGFiXSAmJiBXQVpVSF9NT0RVTEVTW3RhYl0uZGVzY3JpcHRpb24pIHtcbiAgICAgICAgcHJpbnRlci5hZGRDb250ZW50V2l0aE5ld0xpbmUoe1xuICAgICAgICAgIHRleHQ6IFdBWlVIX01PRFVMRVNbdGFiXS5kZXNjcmlwdGlvbixcbiAgICAgICAgICBzdHlsZTogJ3N0YW5kYXJkJyxcbiAgICAgICAgfSk7XG4gICAgICB9XG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgIGNvbnRleHQud2F6dWgubG9nZ2VyLmVycm9yKGVycm9yLm1lc3NhZ2UgfHwgZXJyb3IpO1xuICAgICAgcmV0dXJuIFByb21pc2UucmVqZWN0KGVycm9yKTtcbiAgICB9XG4gIH1cblxuICBwcml2YXRlIGdldENvbmZpZ1Jvd3MoY29udGV4dCwgZGF0YSwgbGFiZWxzKSB7XG4gICAgY29udGV4dC53YXp1aC5sb2dnZXIuZGVidWcoJ0J1aWxkaW5nIGNvbmZpZ3VyYXRpb24gcm93cycpO1xuICAgIGNvbnN0IHJlc3VsdCA9IFtdO1xuICAgIGZvciAobGV0IHByb3AgaW4gZGF0YSB8fCBbXSkge1xuICAgICAgaWYgKEFycmF5LmlzQXJyYXkoZGF0YVtwcm9wXSkpIHtcbiAgICAgICAgZGF0YVtwcm9wXS5mb3JFYWNoKCh4LCBpZHgpID0+IHtcbiAgICAgICAgICBpZiAodHlwZW9mIHggPT09ICdvYmplY3QnKSBkYXRhW3Byb3BdW2lkeF0gPSBKU09OLnN0cmluZ2lmeSh4KTtcbiAgICAgICAgfSk7XG4gICAgICB9XG4gICAgICByZXN1bHQucHVzaChbXG4gICAgICAgIChsYWJlbHMgfHwge30pW3Byb3BdIHx8IEtleUVxdWl2YWxlbmNlW3Byb3BdIHx8IHByb3AsXG4gICAgICAgIGRhdGFbcHJvcF0gfHwgJy0nLFxuICAgICAgXSk7XG4gICAgfVxuICAgIHJldHVybiByZXN1bHQ7XG4gIH1cblxuICBwcml2YXRlIGdldENvbmZpZ1RhYmxlcyhjb250ZXh0LCBkYXRhLCBzZWN0aW9uLCB0YWIsIGFycmF5ID0gW10pIHtcbiAgICBjb250ZXh0LndhenVoLmxvZ2dlci5kZWJ1ZygnQnVpbGRpbmcgY29uZmlndXJhdGlvbiB0YWJsZXMnKTtcbiAgICBsZXQgcGxhaW5EYXRhID0ge307XG4gICAgY29uc3QgbmVzdGVkRGF0YSA9IFtdO1xuICAgIGNvbnN0IHRhYmxlRGF0YSA9IFtdO1xuXG4gICAgaWYgKGRhdGEubGVuZ3RoID09PSAxICYmIEFycmF5LmlzQXJyYXkoZGF0YSkpIHtcbiAgICAgIHRhYmxlRGF0YVtzZWN0aW9uLmNvbmZpZ1t0YWJdLmNvbmZpZ3VyYXRpb25dID0gZGF0YTtcbiAgICB9IGVsc2Uge1xuICAgICAgZm9yIChsZXQga2V5IGluIGRhdGEpIHtcbiAgICAgICAgaWYgKFxuICAgICAgICAgICh0eXBlb2YgZGF0YVtrZXldICE9PSAnb2JqZWN0JyAmJiAhQXJyYXkuaXNBcnJheShkYXRhW2tleV0pKSB8fFxuICAgICAgICAgIChBcnJheS5pc0FycmF5KGRhdGFba2V5XSkgJiYgdHlwZW9mIGRhdGFba2V5XVswXSAhPT0gJ29iamVjdCcpXG4gICAgICAgICkge1xuICAgICAgICAgIHBsYWluRGF0YVtrZXldID1cbiAgICAgICAgICAgIEFycmF5LmlzQXJyYXkoZGF0YVtrZXldKSAmJiB0eXBlb2YgZGF0YVtrZXldWzBdICE9PSAnb2JqZWN0J1xuICAgICAgICAgICAgICA/IGRhdGFba2V5XS5tYXAoeCA9PiB7XG4gICAgICAgICAgICAgICAgICByZXR1cm4gdHlwZW9mIHggPT09ICdvYmplY3QnID8gSlNPTi5zdHJpbmdpZnkoeCkgOiB4ICsgJ1xcbic7XG4gICAgICAgICAgICAgICAgfSlcbiAgICAgICAgICAgICAgOiBkYXRhW2tleV07XG4gICAgICAgIH0gZWxzZSBpZiAoXG4gICAgICAgICAgQXJyYXkuaXNBcnJheShkYXRhW2tleV0pICYmXG4gICAgICAgICAgdHlwZW9mIGRhdGFba2V5XVswXSA9PT0gJ29iamVjdCdcbiAgICAgICAgKSB7XG4gICAgICAgICAgdGFibGVEYXRhW2tleV0gPSBkYXRhW2tleV07XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgaWYgKHNlY3Rpb24uaXNHcm91cENvbmZpZyAmJiBbJ3BhY2snLCAnY29udGVudCddLmluY2x1ZGVzKGtleSkpIHtcbiAgICAgICAgICAgIHRhYmxlRGF0YVtrZXldID0gW2RhdGFba2V5XV07XG4gICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIG5lc3RlZERhdGEucHVzaChkYXRhW2tleV0pO1xuICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgfVxuICAgIH1cbiAgICBhcnJheS5wdXNoKHtcbiAgICAgIHRpdGxlOiAoc2VjdGlvbi5vcHRpb25zIHx8IHt9KS5oaWRlSGVhZGVyXG4gICAgICAgID8gJydcbiAgICAgICAgOiAoc2VjdGlvbi50YWJzIHx8IFtdKVt0YWJdIHx8XG4gICAgICAgICAgKHNlY3Rpb24uaXNHcm91cENvbmZpZyA/ICgoc2VjdGlvbi5sYWJlbHMgfHwgW10pWzBdIHx8IFtdKVt0YWJdIDogJycpLFxuICAgICAgY29sdW1uczogWycnLCAnJ10sXG4gICAgICB0eXBlOiAnY29uZmlnJyxcbiAgICAgIHJvd3M6IHRoaXMuZ2V0Q29uZmlnUm93cyhjb250ZXh0LCBwbGFpbkRhdGEsIChzZWN0aW9uLmxhYmVscyB8fCBbXSlbMF0pLFxuICAgIH0pO1xuICAgIGZvciAobGV0IGtleSBpbiB0YWJsZURhdGEpIHtcbiAgICAgIGNvbnN0IGNvbHVtbnMgPSBPYmplY3Qua2V5cyh0YWJsZURhdGFba2V5XVswXSk7XG4gICAgICBjb2x1bW5zLmZvckVhY2goKGNvbCwgaSkgPT4ge1xuICAgICAgICBjb2x1bW5zW2ldID0gY29sWzBdLnRvVXBwZXJDYXNlKCkgKyBjb2wuc2xpY2UoMSk7XG4gICAgICB9KTtcblxuICAgICAgY29uc3Qgcm93cyA9IHRhYmxlRGF0YVtrZXldLm1hcCh4ID0+IHtcbiAgICAgICAgbGV0IHJvdyA9IFtdO1xuICAgICAgICBmb3IgKGxldCBrZXkgaW4geCkge1xuICAgICAgICAgIHJvdy5wdXNoKFxuICAgICAgICAgICAgdHlwZW9mIHhba2V5XSAhPT0gJ29iamVjdCdcbiAgICAgICAgICAgICAgPyB4W2tleV1cbiAgICAgICAgICAgICAgOiBBcnJheS5pc0FycmF5KHhba2V5XSlcbiAgICAgICAgICAgICAgPyB4W2tleV0ubWFwKHggPT4ge1xuICAgICAgICAgICAgICAgICAgcmV0dXJuIHggKyAnXFxuJztcbiAgICAgICAgICAgICAgICB9KVxuICAgICAgICAgICAgICA6IEpTT04uc3RyaW5naWZ5KHhba2V5XSksXG4gICAgICAgICAgKTtcbiAgICAgICAgfVxuICAgICAgICB3aGlsZSAocm93Lmxlbmd0aCA8IGNvbHVtbnMubGVuZ3RoKSB7XG4gICAgICAgICAgcm93LnB1c2goJy0nKTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gcm93O1xuICAgICAgfSk7XG4gICAgICBhcnJheS5wdXNoKHtcbiAgICAgICAgdGl0bGU6ICgoc2VjdGlvbi5sYWJlbHMgfHwgW10pWzBdIHx8IFtdKVtrZXldIHx8ICcnLFxuICAgICAgICB0eXBlOiAndGFibGUnLFxuICAgICAgICBjb2x1bW5zLFxuICAgICAgICByb3dzLFxuICAgICAgfSk7XG4gICAgfVxuICAgIG5lc3RlZERhdGEuZm9yRWFjaChuZXN0ID0+IHtcbiAgICAgIHRoaXMuZ2V0Q29uZmlnVGFibGVzKGNvbnRleHQsIG5lc3QsIHNlY3Rpb24sIHRhYiArIDEsIGFycmF5KTtcbiAgICB9KTtcbiAgICByZXR1cm4gYXJyYXk7XG4gIH1cblxuICAvKipcbiAgICogQ3JlYXRlIGEgcmVwb3J0IGZvciB0aGUgbW9kdWxlc1xuICAgKiBAcGFyYW0ge09iamVjdH0gY29udGV4dFxuICAgKiBAcGFyYW0ge09iamVjdH0gcmVxdWVzdFxuICAgKiBAcGFyYW0ge09iamVjdH0gcmVzcG9uc2VcbiAgICogQHJldHVybnMgeyp9IHJlcG9ydHMgbGlzdCBvciBFcnJvclJlc3BvbnNlXG4gICAqL1xuICBjcmVhdGVSZXBvcnRzTW9kdWxlcyA9IHRoaXMuY2hlY2tSZXBvcnRzVXNlckRpcmVjdG9yeUlzVmFsaWRSb3V0ZURlY29yYXRvcihcbiAgICBhc3luYyAoXG4gICAgICBjb250ZXh0OiBSZXF1ZXN0SGFuZGxlckNvbnRleHQsXG4gICAgICByZXF1ZXN0OiBPcGVuU2VhcmNoRGFzaGJvYXJkc1JlcXVlc3QsXG4gICAgICByZXNwb25zZTogT3BlblNlYXJjaERhc2hib2FyZHNSZXNwb25zZUZhY3RvcnksXG4gICAgKSA9PiB7XG4gICAgICB0cnkge1xuICAgICAgICBjb250ZXh0LndhenVoLmxvZ2dlci5kZWJ1ZygnUmVwb3J0IHN0YXJ0ZWQnKTtcbiAgICAgICAgY29uc3Qge1xuICAgICAgICAgIGFycmF5LFxuICAgICAgICAgIGFnZW50cyxcbiAgICAgICAgICBicm93c2VyVGltZXpvbmUsXG4gICAgICAgICAgc2VhcmNoQmFyLFxuICAgICAgICAgIGZpbHRlcnMsXG4gICAgICAgICAgc2VydmVyU2lkZVF1ZXJ5LFxuICAgICAgICAgIHRpbWUsXG4gICAgICAgICAgdGFibGVzLFxuICAgICAgICAgIHNlY3Rpb24sXG4gICAgICAgICAgaW5kZXhQYXR0ZXJuVGl0bGUsXG4gICAgICAgICAgYXBpSWQsXG4gICAgICAgIH0gPSByZXF1ZXN0LmJvZHk7XG4gICAgICAgIGNvbnN0IHsgbW9kdWxlSUQgfSA9IHJlcXVlc3QucGFyYW1zO1xuICAgICAgICBjb25zdCB7IGZyb20sIHRvIH0gPSB0aW1lIHx8IHt9O1xuICAgICAgICBsZXQgYWRkaXRpb25hbFRhYmxlcyA9IFtdO1xuICAgICAgICAvLyBJbml0XG4gICAgICAgIGNvbnN0IHByaW50ZXIgPSBuZXcgUmVwb3J0UHJpbnRlcihcbiAgICAgICAgICBjb250ZXh0LndhenVoLmxvZ2dlci5nZXQoJ3JlcG9ydC1wcmludGVyJyksXG4gICAgICAgICAgY29udGV4dC53YXp1aF9jb3JlLmNvbmZpZ3VyYXRpb24sXG4gICAgICAgICk7XG5cbiAgICAgICAgY29udGV4dC53YXp1aF9jb3JlLmRhdGFQYXRoU2VydmljZS5jcmVhdGVEYXRhRGlyZWN0b3J5SWZOb3RFeGlzdHMoXG4gICAgICAgICAgYGRvd25sb2Fkcy9yZXBvcnRzLyR7Y29udGV4dC53YXp1aEVuZHBvaW50UGFyYW1zLmhhc2hVc2VybmFtZX1gLFxuICAgICAgICApO1xuXG4gICAgICAgIGF3YWl0IHRoaXMucmVuZGVySGVhZGVyKFxuICAgICAgICAgIGNvbnRleHQsXG4gICAgICAgICAgcHJpbnRlcixcbiAgICAgICAgICBzZWN0aW9uLFxuICAgICAgICAgIG1vZHVsZUlELFxuICAgICAgICAgIGFnZW50cyxcbiAgICAgICAgICBhcGlJZCxcbiAgICAgICAgKTtcblxuICAgICAgICBjb25zdCBbc2FuaXRpemVkRmlsdGVycywgYWdlbnRzRmlsdGVyXSA9IGZpbHRlcnNcbiAgICAgICAgICA/IHRoaXMuc2FuaXRpemVLaWJhbmFGaWx0ZXJzKGNvbnRleHQsIGZpbHRlcnMsIHNlYXJjaEJhcilcbiAgICAgICAgICA6IFtmYWxzZSwgbnVsbF07XG5cbiAgICAgICAgaWYgKHRpbWUgJiYgc2FuaXRpemVkRmlsdGVycykge1xuICAgICAgICAgIHByaW50ZXIuYWRkVGltZVJhbmdlQW5kRmlsdGVycyhcbiAgICAgICAgICAgIGZyb20sXG4gICAgICAgICAgICB0byxcbiAgICAgICAgICAgIHNhbml0aXplZEZpbHRlcnMsXG4gICAgICAgICAgICBicm93c2VyVGltZXpvbmUsXG4gICAgICAgICAgKTtcbiAgICAgICAgfVxuXG4gICAgICAgIGlmICh0aW1lKSB7XG4gICAgICAgICAgYWRkaXRpb25hbFRhYmxlcyA9IGF3YWl0IGV4dGVuZGVkSW5mb3JtYXRpb24oXG4gICAgICAgICAgICBjb250ZXh0LFxuICAgICAgICAgICAgcHJpbnRlcixcbiAgICAgICAgICAgIHNlY3Rpb24sXG4gICAgICAgICAgICBtb2R1bGVJRCxcbiAgICAgICAgICAgIGFwaUlkLFxuICAgICAgICAgICAgbmV3IERhdGUoZnJvbSkuZ2V0VGltZSgpLFxuICAgICAgICAgICAgbmV3IERhdGUodG8pLmdldFRpbWUoKSxcbiAgICAgICAgICAgIHNlcnZlclNpZGVRdWVyeSxcbiAgICAgICAgICAgIGluZGV4UGF0dGVyblRpdGxlIHx8XG4gICAgICAgICAgICAgIGNvbnRleHQud2F6dWhfY29yZS5jb25maWd1cmF0aW9uLmdldFNldHRpbmdWYWx1ZSgncGF0dGVybicpLFxuICAgICAgICAgICAgYWdlbnRzLFxuICAgICAgICAgICk7XG4gICAgICAgIH1cblxuICAgICAgICBwcmludGVyLmFkZFZpc3VhbGl6YXRpb25zKGFycmF5LCBhZ2VudHMsIG1vZHVsZUlEKTtcblxuICAgICAgICBpZiAodGFibGVzKSB7XG4gICAgICAgICAgcHJpbnRlci5hZGRUYWJsZXMoWy4uLnRhYmxlcywgLi4uKGFkZGl0aW9uYWxUYWJsZXMgfHwgW10pXSk7XG4gICAgICAgIH1cblxuICAgICAgICBhd2FpdCBwcmludGVyLnByaW50KGNvbnRleHQud2F6dWhFbmRwb2ludFBhcmFtcy5wYXRoRmlsZW5hbWUpO1xuXG4gICAgICAgIHJldHVybiByZXNwb25zZS5vayh7XG4gICAgICAgICAgYm9keToge1xuICAgICAgICAgICAgc3VjY2VzczogdHJ1ZSxcbiAgICAgICAgICAgIG1lc3NhZ2U6IGBSZXBvcnQgJHtjb250ZXh0LndhenVoRW5kcG9pbnRQYXJhbXMuZmlsZW5hbWV9IHdhcyBjcmVhdGVkYCxcbiAgICAgICAgICAgIGZpbGVuYW1lOiBjb250ZXh0LndhenVoRW5kcG9pbnRQYXJhbXMuZmlsZW5hbWUsXG4gICAgICAgICAgfSxcbiAgICAgICAgfSk7XG4gICAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgICByZXR1cm4gRXJyb3JSZXNwb25zZShlcnJvci5tZXNzYWdlIHx8IGVycm9yLCA1MDI5LCA1MDAsIHJlc3BvbnNlKTtcbiAgICAgIH1cbiAgICB9LFxuICAgICh7IGJvZHk6IHsgYWdlbnRzIH0sIHBhcmFtczogeyBtb2R1bGVJRCB9IH0pID0+XG4gICAgICBgd2F6dWgtbW9kdWxlLSR7XG4gICAgICAgIGFnZW50cyA/IGBhZ2VudHMtJHthZ2VudHN9YCA6ICdvdmVydmlldydcbiAgICAgIH0tJHttb2R1bGVJRH0tJHt0aGlzLmdlbmVyYXRlUmVwb3J0VGltZXN0YW1wKCl9LnBkZmAsXG4gICk7XG5cbiAgLyoqXG4gICAqIENyZWF0ZSBhIHJlcG9ydCBmb3IgdGhlIGdyb3Vwc1xuICAgKiBAcGFyYW0ge09iamVjdH0gY29udGV4dFxuICAgKiBAcGFyYW0ge09iamVjdH0gcmVxdWVzdFxuICAgKiBAcGFyYW0ge09iamVjdH0gcmVzcG9uc2VcbiAgICogQHJldHVybnMgeyp9IHJlcG9ydHMgbGlzdCBvciBFcnJvclJlc3BvbnNlXG4gICAqL1xuICBjcmVhdGVSZXBvcnRzR3JvdXBzID0gdGhpcy5jaGVja1JlcG9ydHNVc2VyRGlyZWN0b3J5SXNWYWxpZFJvdXRlRGVjb3JhdG9yKFxuICAgIGFzeW5jIChcbiAgICAgIGNvbnRleHQ6IFJlcXVlc3RIYW5kbGVyQ29udGV4dCxcbiAgICAgIHJlcXVlc3Q6IE9wZW5TZWFyY2hEYXNoYm9hcmRzUmVxdWVzdCxcbiAgICAgIHJlc3BvbnNlOiBPcGVuU2VhcmNoRGFzaGJvYXJkc1Jlc3BvbnNlRmFjdG9yeSxcbiAgICApID0+IHtcbiAgICAgIHRyeSB7XG4gICAgICAgIGNvbnRleHQud2F6dWgubG9nZ2VyLmRlYnVnKCdSZXBvcnQgc3RhcnRlZCcpO1xuICAgICAgICBjb25zdCB7IGNvbXBvbmVudHMsIGFwaUlkIH0gPSByZXF1ZXN0LmJvZHk7XG4gICAgICAgIGNvbnN0IHsgZ3JvdXBJRCB9ID0gcmVxdWVzdC5wYXJhbXM7XG4gICAgICAgIC8vIEluaXRcbiAgICAgICAgY29uc3QgcHJpbnRlciA9IG5ldyBSZXBvcnRQcmludGVyKFxuICAgICAgICAgIGNvbnRleHQud2F6dWgubG9nZ2VyLmdldCgncmVwb3J0LXByaW50ZXInKSxcbiAgICAgICAgICBjb250ZXh0LndhenVoX2NvcmUuY29uZmlndXJhdGlvbixcbiAgICAgICAgKTtcbiAgICAgICAgY29udGV4dC53YXp1aF9jb3JlLmRhdGFQYXRoU2VydmljZS5jcmVhdGVEYXRhRGlyZWN0b3J5SWZOb3RFeGlzdHMoXG4gICAgICAgICAgYGRvd25sb2Fkcy9yZXBvcnRzLyR7Y29udGV4dC53YXp1aEVuZHBvaW50UGFyYW1zLmhhc2hVc2VybmFtZX1gLFxuICAgICAgICApO1xuXG4gICAgICAgIGxldCB0YWJsZXMgPSBbXTtcbiAgICAgICAgY29uc3QgZXF1aXZhbGVuY2VzID0ge1xuICAgICAgICAgIGxvY2FsZmlsZTogJ0xvY2FsIGZpbGVzJyxcbiAgICAgICAgICBvc3F1ZXJ5OiAnT3NxdWVyeScsXG4gICAgICAgICAgY29tbWFuZDogJ0NvbW1hbmQnLFxuICAgICAgICAgIHN5c2NoZWNrOiAnU3lzY2hlY2snLFxuICAgICAgICAgICdvcGVuLXNjYXAnOiAnT3BlblNDQVAnLFxuICAgICAgICAgICdjaXMtY2F0JzogJ0NJUy1DQVQnLFxuICAgICAgICAgIHN5c2NvbGxlY3RvcjogJ1N5c2NvbGxlY3RvcicsXG4gICAgICAgICAgcm9vdGNoZWNrOiAnUm9vdGNoZWNrJyxcbiAgICAgICAgICBsYWJlbHM6ICdMYWJlbHMnLFxuICAgICAgICAgIHNjYTogJ1NlY3VyaXR5IGNvbmZpZ3VyYXRpb24gYXNzZXNzbWVudCcsXG4gICAgICAgIH07XG4gICAgICAgIHByaW50ZXIuYWRkQ29udGVudCh7XG4gICAgICAgICAgdGV4dDogYEdyb3VwICR7Z3JvdXBJRH0gY29uZmlndXJhdGlvbmAsXG4gICAgICAgICAgc3R5bGU6ICdoMScsXG4gICAgICAgIH0pO1xuXG4gICAgICAgIC8vIEdyb3VwIGNvbmZpZ3VyYXRpb25cbiAgICAgICAgaWYgKGNvbXBvbmVudHNbJzAnXSkge1xuICAgICAgICAgIGNvbnN0IHtcbiAgICAgICAgICAgIGRhdGE6IHsgZGF0YTogY29uZmlndXJhdGlvbiB9LFxuICAgICAgICAgIH0gPSBhd2FpdCBjb250ZXh0LndhenVoLmFwaS5jbGllbnQuYXNDdXJyZW50VXNlci5yZXF1ZXN0KFxuICAgICAgICAgICAgJ0dFVCcsXG4gICAgICAgICAgICBgL2dyb3Vwcy8ke2dyb3VwSUR9L2NvbmZpZ3VyYXRpb25gLFxuICAgICAgICAgICAge30sXG4gICAgICAgICAgICB7IGFwaUhvc3RJRDogYXBpSWQgfSxcbiAgICAgICAgICApO1xuXG4gICAgICAgICAgaWYgKFxuICAgICAgICAgICAgY29uZmlndXJhdGlvbi5hZmZlY3RlZF9pdGVtcy5sZW5ndGggPiAwICYmXG4gICAgICAgICAgICBPYmplY3Qua2V5cyhjb25maWd1cmF0aW9uLmFmZmVjdGVkX2l0ZW1zWzBdLmNvbmZpZykubGVuZ3RoXG4gICAgICAgICAgKSB7XG4gICAgICAgICAgICBwcmludGVyLmFkZENvbnRlbnQoe1xuICAgICAgICAgICAgICB0ZXh0OiAnQ29uZmlndXJhdGlvbnMnLFxuICAgICAgICAgICAgICBzdHlsZTogeyBmb250U2l6ZTogMTQsIGNvbG9yOiAnIzAwMCcgfSxcbiAgICAgICAgICAgICAgbWFyZ2luOiBbMCwgMTAsIDAsIDE1XSxcbiAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgY29uc3Qgc2VjdGlvbiA9IHtcbiAgICAgICAgICAgICAgbGFiZWxzOiBbXSxcbiAgICAgICAgICAgICAgaXNHcm91cENvbmZpZzogdHJ1ZSxcbiAgICAgICAgICAgIH07XG4gICAgICAgICAgICBmb3IgKGxldCBjb25maWcgb2YgY29uZmlndXJhdGlvbi5hZmZlY3RlZF9pdGVtcykge1xuICAgICAgICAgICAgICBsZXQgZmlsdGVyVGl0bGUgPSAnJztcbiAgICAgICAgICAgICAgbGV0IGluZGV4ID0gMDtcbiAgICAgICAgICAgICAgZm9yIChsZXQgZmlsdGVyIG9mIE9iamVjdC5rZXlzKGNvbmZpZy5maWx0ZXJzKSkge1xuICAgICAgICAgICAgICAgIGZpbHRlclRpdGxlID0gZmlsdGVyVGl0bGUuY29uY2F0KFxuICAgICAgICAgICAgICAgICAgYCR7ZmlsdGVyfTogJHtjb25maWcuZmlsdGVyc1tmaWx0ZXJdfWAsXG4gICAgICAgICAgICAgICAgKTtcbiAgICAgICAgICAgICAgICBpZiAoaW5kZXggPCBPYmplY3Qua2V5cyhjb25maWcuZmlsdGVycykubGVuZ3RoIC0gMSkge1xuICAgICAgICAgICAgICAgICAgZmlsdGVyVGl0bGUgPSBmaWx0ZXJUaXRsZS5jb25jYXQoJyB8ICcpO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBpbmRleCsrO1xuICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgIHByaW50ZXIuYWRkQ29udGVudCh7XG4gICAgICAgICAgICAgICAgdGV4dDogZmlsdGVyVGl0bGUsXG4gICAgICAgICAgICAgICAgc3R5bGU6ICdoNCcsXG4gICAgICAgICAgICAgICAgbWFyZ2luOiBbMCwgMCwgMCwgMTBdLFxuICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgbGV0IGlkeCA9IDA7XG4gICAgICAgICAgICAgIHNlY3Rpb24udGFicyA9IFtdO1xuICAgICAgICAgICAgICBmb3IgKGxldCBfZCBvZiBPYmplY3Qua2V5cyhjb25maWcuY29uZmlnKSkge1xuICAgICAgICAgICAgICAgIGZvciAobGV0IGMgb2YgQWdlbnRDb25maWd1cmF0aW9uLmNvbmZpZ3VyYXRpb25zKSB7XG4gICAgICAgICAgICAgICAgICBmb3IgKGxldCBzIG9mIGMuc2VjdGlvbnMpIHtcbiAgICAgICAgICAgICAgICAgICAgc2VjdGlvbi5vcHRzID0gcy5vcHRzIHx8IHt9O1xuICAgICAgICAgICAgICAgICAgICBmb3IgKGxldCBjbiBvZiBzLmNvbmZpZyB8fCBbXSkge1xuICAgICAgICAgICAgICAgICAgICAgIGlmIChjbi5jb25maWd1cmF0aW9uID09PSBfZCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgc2VjdGlvbi5sYWJlbHMgPSBzLmxhYmVscyB8fCBbW11dO1xuICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICBmb3IgKGxldCB3byBvZiBzLndvZGxlIHx8IFtdKSB7XG4gICAgICAgICAgICAgICAgICAgICAgaWYgKHdvLm5hbWUgPT09IF9kKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICBzZWN0aW9uLmxhYmVscyA9IHMubGFiZWxzIHx8IFtbXV07XG4gICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIHNlY3Rpb24ubGFiZWxzWzBdWydwYWNrJ10gPSAnUGFja3MnO1xuICAgICAgICAgICAgICAgIHNlY3Rpb24ubGFiZWxzWzBdWydjb250ZW50J10gPSAnRXZhbHVhdGlvbnMnO1xuICAgICAgICAgICAgICAgIHNlY3Rpb24ubGFiZWxzWzBdWyc3J10gPSAnU2NhbiBsaXN0ZW5pbmcgbmV0d290ayBwb3J0cyc7XG4gICAgICAgICAgICAgICAgc2VjdGlvbi50YWJzLnB1c2goZXF1aXZhbGVuY2VzW19kXSk7XG5cbiAgICAgICAgICAgICAgICBpZiAoQXJyYXkuaXNBcnJheShjb25maWcuY29uZmlnW19kXSkpIHtcbiAgICAgICAgICAgICAgICAgIC8qIExPRyBDT0xMRUNUT1IgKi9cbiAgICAgICAgICAgICAgICAgIGlmIChfZCA9PT0gJ2xvY2FsZmlsZScpIHtcbiAgICAgICAgICAgICAgICAgICAgbGV0IGdyb3VwcyA9IFtdO1xuICAgICAgICAgICAgICAgICAgICBjb25maWcuY29uZmlnW19kXS5mb3JFYWNoKG9iaiA9PiB7XG4gICAgICAgICAgICAgICAgICAgICAgaWYgKCFncm91cHNbb2JqLmxvZ2Zvcm1hdF0pIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGdyb3Vwc1tvYmoubG9nZm9ybWF0XSA9IFtdO1xuICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICBncm91cHNbb2JqLmxvZ2Zvcm1hdF0ucHVzaChvYmopO1xuICAgICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICAgICAgT2JqZWN0LmtleXMoZ3JvdXBzKS5mb3JFYWNoKGdyb3VwID0+IHtcbiAgICAgICAgICAgICAgICAgICAgICBsZXQgc2F2ZWlkeCA9IDA7XG4gICAgICAgICAgICAgICAgICAgICAgZ3JvdXBzW2dyb3VwXS5mb3JFYWNoKCh4LCBpKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgIE9iamVjdC5rZXlzKHgpLmxlbmd0aCA+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIE9iamVjdC5rZXlzKGdyb3Vwc1tncm91cF1bc2F2ZWlkeF0pLmxlbmd0aFxuICAgICAgICAgICAgICAgICAgICAgICAgKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgIHNhdmVpZHggPSBpO1xuICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IGNvbHVtbnMgPSBPYmplY3Qua2V5cyhncm91cHNbZ3JvdXBdW3NhdmVpZHhdKTtcbiAgICAgICAgICAgICAgICAgICAgICBjb25zdCByb3dzID0gZ3JvdXBzW2dyb3VwXS5tYXAoeCA9PiB7XG4gICAgICAgICAgICAgICAgICAgICAgICBsZXQgcm93ID0gW107XG4gICAgICAgICAgICAgICAgICAgICAgICBjb2x1bW5zLmZvckVhY2goa2V5ID0+IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgcm93LnB1c2goXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZW9mIHhba2V5XSAhPT0gJ29iamVjdCdcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID8geFtrZXldXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA6IEFycmF5LmlzQXJyYXkoeFtrZXldKVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPyB4W2tleV0ubWFwKHggPT4ge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiB4ICsgJ1xcbic7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0pXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA6IEpTT04uc3RyaW5naWZ5KHhba2V5XSksXG4gICAgICAgICAgICAgICAgICAgICAgICAgICk7XG4gICAgICAgICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiByb3c7XG4gICAgICAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgICAgICAgY29sdW1ucy5mb3JFYWNoKChjb2wsIGkpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbHVtbnNbaV0gPSBjb2xbMF0udG9VcHBlckNhc2UoKSArIGNvbC5zbGljZSgxKTtcbiAgICAgICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICAgICAgICB0YWJsZXMucHVzaCh7XG4gICAgICAgICAgICAgICAgICAgICAgICB0aXRsZTogJ0xvY2FsIGZpbGVzJyxcbiAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU6ICd0YWJsZScsXG4gICAgICAgICAgICAgICAgICAgICAgICBjb2x1bW5zLFxuICAgICAgICAgICAgICAgICAgICAgICAgcm93cyxcbiAgICAgICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgICB9IGVsc2UgaWYgKF9kID09PSAnbGFiZWxzJykge1xuICAgICAgICAgICAgICAgICAgICBjb25zdCBvYmogPSBjb25maWcuY29uZmlnW19kXVswXS5sYWJlbDtcbiAgICAgICAgICAgICAgICAgICAgY29uc3QgY29sdW1ucyA9IE9iamVjdC5rZXlzKG9ialswXSk7XG4gICAgICAgICAgICAgICAgICAgIGlmICghY29sdW1ucy5pbmNsdWRlcygnaGlkZGVuJykpIHtcbiAgICAgICAgICAgICAgICAgICAgICBjb2x1bW5zLnB1c2goJ2hpZGRlbicpO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIGNvbnN0IHJvd3MgPSBvYmoubWFwKHggPT4ge1xuICAgICAgICAgICAgICAgICAgICAgIGxldCByb3cgPSBbXTtcbiAgICAgICAgICAgICAgICAgICAgICBjb2x1bW5zLmZvckVhY2goa2V5ID0+IHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHJvdy5wdXNoKHhba2V5XSk7XG4gICAgICAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIHJvdztcbiAgICAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgICAgIGNvbHVtbnMuZm9yRWFjaCgoY29sLCBpKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgICAgY29sdW1uc1tpXSA9IGNvbFswXS50b1VwcGVyQ2FzZSgpICsgY29sLnNsaWNlKDEpO1xuICAgICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICAgICAgdGFibGVzLnB1c2goe1xuICAgICAgICAgICAgICAgICAgICAgIHRpdGxlOiAnTGFiZWxzJyxcbiAgICAgICAgICAgICAgICAgICAgICB0eXBlOiAndGFibGUnLFxuICAgICAgICAgICAgICAgICAgICAgIGNvbHVtbnMsXG4gICAgICAgICAgICAgICAgICAgICAgcm93cyxcbiAgICAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAgICAgICBmb3IgKGxldCBfZDIgb2YgY29uZmlnLmNvbmZpZ1tfZF0pIHtcbiAgICAgICAgICAgICAgICAgICAgICB0YWJsZXMucHVzaChcbiAgICAgICAgICAgICAgICAgICAgICAgIC4uLnRoaXMuZ2V0Q29uZmlnVGFibGVzKGNvbnRleHQsIF9kMiwgc2VjdGlvbiwgaWR4KSxcbiAgICAgICAgICAgICAgICAgICAgICApO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgICAgIC8qSU5URUdSSVRZIE1PTklUT1JJTkcgTU9OSVRPUkVEIERJUkVDVE9SSUVTICovXG4gICAgICAgICAgICAgICAgICBpZiAoY29uZmlnLmNvbmZpZ1tfZF0uZGlyZWN0b3JpZXMpIHtcbiAgICAgICAgICAgICAgICAgICAgY29uc3QgZGlyZWN0b3JpZXMgPSBjb25maWcuY29uZmlnW19kXS5kaXJlY3RvcmllcztcbiAgICAgICAgICAgICAgICAgICAgZGVsZXRlIGNvbmZpZy5jb25maWdbX2RdLmRpcmVjdG9yaWVzO1xuICAgICAgICAgICAgICAgICAgICB0YWJsZXMucHVzaChcbiAgICAgICAgICAgICAgICAgICAgICAuLi50aGlzLmdldENvbmZpZ1RhYmxlcyhcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbnRleHQsXG4gICAgICAgICAgICAgICAgICAgICAgICBjb25maWcuY29uZmlnW19kXSxcbiAgICAgICAgICAgICAgICAgICAgICAgIHNlY3Rpb24sXG4gICAgICAgICAgICAgICAgICAgICAgICBpZHgsXG4gICAgICAgICAgICAgICAgICAgICAgKSxcbiAgICAgICAgICAgICAgICAgICAgKTtcbiAgICAgICAgICAgICAgICAgICAgbGV0IGRpZmZPcHRzID0gW107XG4gICAgICAgICAgICAgICAgICAgIE9iamVjdC5rZXlzKHNlY3Rpb24ub3B0cykuZm9yRWFjaCh4ID0+IHtcbiAgICAgICAgICAgICAgICAgICAgICBkaWZmT3B0cy5wdXNoKHgpO1xuICAgICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICAgICAgY29uc3QgY29sdW1ucyA9IFtcbiAgICAgICAgICAgICAgICAgICAgICAnJyxcbiAgICAgICAgICAgICAgICAgICAgICAuLi5kaWZmT3B0cy5maWx0ZXIoXG4gICAgICAgICAgICAgICAgICAgICAgICB4ID0+IHggIT09ICdjaGVja19hbGwnICYmIHggIT09ICdjaGVja19zdW0nLFxuICAgICAgICAgICAgICAgICAgICAgICksXG4gICAgICAgICAgICAgICAgICAgIF07XG4gICAgICAgICAgICAgICAgICAgIGxldCByb3dzID0gW107XG4gICAgICAgICAgICAgICAgICAgIGRpcmVjdG9yaWVzLmZvckVhY2goeCA9PiB7XG4gICAgICAgICAgICAgICAgICAgICAgbGV0IHJvdyA9IFtdO1xuICAgICAgICAgICAgICAgICAgICAgIHJvdy5wdXNoKHgucGF0aCk7XG4gICAgICAgICAgICAgICAgICAgICAgY29sdW1ucy5mb3JFYWNoKHkgPT4ge1xuICAgICAgICAgICAgICAgICAgICAgICAgaWYgKHkgIT09ICcnKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgIHkgPSB5ICE9PSAnY2hlY2tfd2hvZGF0YScgPyB5IDogJ3dob2RhdGEnO1xuICAgICAgICAgICAgICAgICAgICAgICAgICByb3cucHVzaCh4W3ldID8geFt5XSA6ICdubycpO1xuICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgICAgICAgIHJvdy5wdXNoKHgucmVjdXJzaW9uX2xldmVsKTtcbiAgICAgICAgICAgICAgICAgICAgICByb3dzLnB1c2gocm93KTtcbiAgICAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgICAgIGNvbHVtbnMuZm9yRWFjaCgoeCwgaWR4KSA9PiB7XG4gICAgICAgICAgICAgICAgICAgICAgY29sdW1uc1tpZHhdID0gc2VjdGlvbi5vcHRzW3hdO1xuICAgICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICAgICAgY29sdW1ucy5wdXNoKCdSTCcpO1xuICAgICAgICAgICAgICAgICAgICB0YWJsZXMucHVzaCh7XG4gICAgICAgICAgICAgICAgICAgICAgdGl0bGU6ICdNb25pdG9yZWQgZGlyZWN0b3JpZXMnLFxuICAgICAgICAgICAgICAgICAgICAgIHR5cGU6ICd0YWJsZScsXG4gICAgICAgICAgICAgICAgICAgICAgY29sdW1ucyxcbiAgICAgICAgICAgICAgICAgICAgICByb3dzLFxuICAgICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgICAgIHRhYmxlcy5wdXNoKFxuICAgICAgICAgICAgICAgICAgICAgIC4uLnRoaXMuZ2V0Q29uZmlnVGFibGVzKFxuICAgICAgICAgICAgICAgICAgICAgICAgY29udGV4dCxcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbmZpZy5jb25maWdbX2RdLFxuICAgICAgICAgICAgICAgICAgICAgICAgc2VjdGlvbixcbiAgICAgICAgICAgICAgICAgICAgICAgIGlkeCxcbiAgICAgICAgICAgICAgICAgICAgICApLFxuICAgICAgICAgICAgICAgICAgICApO1xuICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBmb3IgKGNvbnN0IHRhYmxlIG9mIHRhYmxlcykge1xuICAgICAgICAgICAgICAgICAgcHJpbnRlci5hZGRDb25maWdUYWJsZXMoW3RhYmxlXSk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGlkeCsrO1xuICAgICAgICAgICAgICAgIHRhYmxlcyA9IFtdO1xuICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgIHRhYmxlcyA9IFtdO1xuICAgICAgICAgICAgfVxuICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICBwcmludGVyLmFkZENvbnRlbnQoe1xuICAgICAgICAgICAgICB0ZXh0OiAnQSBjb25maWd1cmF0aW9uIGZvciB0aGlzIGdyb3VwIGhhcyBub3QgeWV0IGJlZW4gc2V0IHVwLicsXG4gICAgICAgICAgICAgIHN0eWxlOiB7IGZvbnRTaXplOiAxMiwgY29sb3I6ICcjMDAwJyB9LFxuICAgICAgICAgICAgICBtYXJnaW46IFswLCAxMCwgMCwgMTVdLFxuICAgICAgICAgICAgfSk7XG4gICAgICAgICAgfVxuICAgICAgICB9XG5cbiAgICAgICAgLy8gQWdlbnRzIGluIGdyb3VwXG4gICAgICAgIGlmIChjb21wb25lbnRzWycxJ10pIHtcbiAgICAgICAgICBhd2FpdCB0aGlzLnJlbmRlckhlYWRlcihcbiAgICAgICAgICAgIGNvbnRleHQsXG4gICAgICAgICAgICBwcmludGVyLFxuICAgICAgICAgICAgJ2dyb3VwQ29uZmlnJyxcbiAgICAgICAgICAgIGdyb3VwSUQsXG4gICAgICAgICAgICBbXSxcbiAgICAgICAgICAgIGFwaUlkLFxuICAgICAgICAgICk7XG4gICAgICAgIH1cblxuICAgICAgICBhd2FpdCBwcmludGVyLnByaW50KGNvbnRleHQud2F6dWhFbmRwb2ludFBhcmFtcy5wYXRoRmlsZW5hbWUpO1xuXG4gICAgICAgIHJldHVybiByZXNwb25zZS5vayh7XG4gICAgICAgICAgYm9keToge1xuICAgICAgICAgICAgc3VjY2VzczogdHJ1ZSxcbiAgICAgICAgICAgIG1lc3NhZ2U6IGBSZXBvcnQgJHtjb250ZXh0LndhenVoRW5kcG9pbnRQYXJhbXMuZmlsZW5hbWV9IHdhcyBjcmVhdGVkYCxcbiAgICAgICAgICAgIGZpbGVuYW1lOiBjb250ZXh0LndhenVoRW5kcG9pbnRQYXJhbXMuZmlsZW5hbWUsXG4gICAgICAgICAgfSxcbiAgICAgICAgfSk7XG4gICAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgICBjb250ZXh0LndhenVoLmxvZ2dlci5lcnJvcihlcnJvci5tZXNzYWdlIHx8IGVycm9yKTtcbiAgICAgICAgcmV0dXJuIEVycm9yUmVzcG9uc2UoZXJyb3IubWVzc2FnZSB8fCBlcnJvciwgNTAyOSwgNTAwLCByZXNwb25zZSk7XG4gICAgICB9XG4gICAgfSxcbiAgICAoeyBwYXJhbXM6IHsgZ3JvdXBJRCB9IH0pID0+XG4gICAgICBgd2F6dWgtZ3JvdXAtY29uZmlndXJhdGlvbi0ke2dyb3VwSUR9LSR7dGhpcy5nZW5lcmF0ZVJlcG9ydFRpbWVzdGFtcCgpfS5wZGZgLFxuICApO1xuXG4gIC8qKlxuICAgKiBDcmVhdGUgYSByZXBvcnQgZm9yIHRoZSBhZ2VudHNcbiAgICogQHBhcmFtIHtPYmplY3R9IGNvbnRleHRcbiAgICogQHBhcmFtIHtPYmplY3R9IHJlcXVlc3RcbiAgICogQHBhcmFtIHtPYmplY3R9IHJlc3BvbnNlXG4gICAqIEByZXR1cm5zIHsqfSByZXBvcnRzIGxpc3Qgb3IgRXJyb3JSZXNwb25zZVxuICAgKi9cbiAgY3JlYXRlUmVwb3J0c0FnZW50c0NvbmZpZ3VyYXRpb24gPVxuICAgIHRoaXMuY2hlY2tSZXBvcnRzVXNlckRpcmVjdG9yeUlzVmFsaWRSb3V0ZURlY29yYXRvcihcbiAgICAgIGFzeW5jIChcbiAgICAgICAgY29udGV4dDogUmVxdWVzdEhhbmRsZXJDb250ZXh0LFxuICAgICAgICByZXF1ZXN0OiBPcGVuU2VhcmNoRGFzaGJvYXJkc1JlcXVlc3QsXG4gICAgICAgIHJlc3BvbnNlOiBPcGVuU2VhcmNoRGFzaGJvYXJkc1Jlc3BvbnNlRmFjdG9yeSxcbiAgICAgICkgPT4ge1xuICAgICAgICB0cnkge1xuICAgICAgICAgIGNvbnRleHQud2F6dWgubG9nZ2VyLmRlYnVnKCdSZXBvcnQgc3RhcnRlZCcpO1xuICAgICAgICAgIGNvbnN0IHsgY29tcG9uZW50cywgYXBpSWQgfSA9IHJlcXVlc3QuYm9keTtcbiAgICAgICAgICBjb25zdCB7IGFnZW50SUQgfSA9IHJlcXVlc3QucGFyYW1zO1xuXG4gICAgICAgICAgY29uc3QgcHJpbnRlciA9IG5ldyBSZXBvcnRQcmludGVyKFxuICAgICAgICAgICAgY29udGV4dC53YXp1aC5sb2dnZXIuZ2V0KCdyZXBvcnQtcHJpbnRlcicpLFxuICAgICAgICAgICAgY29udGV4dC53YXp1aF9jb3JlLmNvbmZpZ3VyYXRpb24sXG4gICAgICAgICAgKTtcblxuICAgICAgICAgIGNvbnRleHQud2F6dWhfY29yZS5kYXRhUGF0aFNlcnZpY2UuY3JlYXRlRGF0YURpcmVjdG9yeUlmTm90RXhpc3RzKFxuICAgICAgICAgICAgYGRvd25sb2Fkcy9yZXBvcnRzLyR7Y29udGV4dC53YXp1aEVuZHBvaW50UGFyYW1zLmhhc2hVc2VybmFtZX1gLFxuICAgICAgICAgICk7XG5cbiAgICAgICAgICBsZXQgd21vZHVsZXNSZXNwb25zZSA9IHt9O1xuICAgICAgICAgIGxldCB0YWJsZXMgPSBbXTtcbiAgICAgICAgICB0cnkge1xuICAgICAgICAgICAgd21vZHVsZXNSZXNwb25zZSA9XG4gICAgICAgICAgICAgIGF3YWl0IGNvbnRleHQud2F6dWguYXBpLmNsaWVudC5hc0N1cnJlbnRVc2VyLnJlcXVlc3QoXG4gICAgICAgICAgICAgICAgJ0dFVCcsXG4gICAgICAgICAgICAgICAgYC9hZ2VudHMvJHthZ2VudElEfS9jb25maWcvd21vZHVsZXMvd21vZHVsZXNgLFxuICAgICAgICAgICAgICAgIHt9LFxuICAgICAgICAgICAgICAgIHsgYXBpSG9zdElEOiBhcGlJZCB9LFxuICAgICAgICAgICAgICApO1xuICAgICAgICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICAgICAgICBjb250ZXh0LndhenVoLmxvZ2dlci5kZWJ1ZyhlcnJvci5tZXNzYWdlIHx8IGVycm9yKTtcbiAgICAgICAgICB9XG5cbiAgICAgICAgICBhd2FpdCB0aGlzLnJlbmRlckhlYWRlcihcbiAgICAgICAgICAgIGNvbnRleHQsXG4gICAgICAgICAgICBwcmludGVyLFxuICAgICAgICAgICAgJ2FnZW50Q29uZmlnJyxcbiAgICAgICAgICAgICdhZ2VudENvbmZpZycsXG4gICAgICAgICAgICBhZ2VudElELFxuICAgICAgICAgICAgYXBpSWQsXG4gICAgICAgICAgKTtcblxuICAgICAgICAgIGxldCBpZHhDb21wb25lbnQgPSAwO1xuICAgICAgICAgIGZvciAobGV0IGNvbmZpZyBvZiBBZ2VudENvbmZpZ3VyYXRpb24uY29uZmlndXJhdGlvbnMpIHtcbiAgICAgICAgICAgIGxldCB0aXRsZU9mU2VjdGlvbiA9IGZhbHNlO1xuICAgICAgICAgICAgY29udGV4dC53YXp1aC5sb2dnZXIuZGVidWcoXG4gICAgICAgICAgICAgIGBJdGVyYXRlIG92ZXIgJHtjb25maWcuc2VjdGlvbnMubGVuZ3RofSBjb25maWd1cmF0aW9uIHNlY3Rpb25zYCxcbiAgICAgICAgICAgICk7XG4gICAgICAgICAgICBmb3IgKGxldCBzZWN0aW9uIG9mIGNvbmZpZy5zZWN0aW9ucykge1xuICAgICAgICAgICAgICBsZXQgdGl0bGVPZlN1YnNlY3Rpb24gPSBmYWxzZTtcbiAgICAgICAgICAgICAgaWYgKFxuICAgICAgICAgICAgICAgIGNvbXBvbmVudHNbaWR4Q29tcG9uZW50XSAmJlxuICAgICAgICAgICAgICAgIChzZWN0aW9uLmNvbmZpZyB8fCBzZWN0aW9uLndvZGxlKVxuICAgICAgICAgICAgICApIHtcbiAgICAgICAgICAgICAgICBsZXQgaWR4ID0gMDtcbiAgICAgICAgICAgICAgICBjb25zdCBjb25maWdzID0gKHNlY3Rpb24uY29uZmlnIHx8IFtdKS5jb25jYXQoXG4gICAgICAgICAgICAgICAgICBzZWN0aW9uLndvZGxlIHx8IFtdLFxuICAgICAgICAgICAgICAgICk7XG4gICAgICAgICAgICAgICAgY29udGV4dC53YXp1aC5sb2dnZXIuZGVidWcoXG4gICAgICAgICAgICAgICAgICBgSXRlcmF0ZSBvdmVyICR7Y29uZmlncy5sZW5ndGh9IGNvbmZpZ3VyYXRpb24gYmxvY2tzYCxcbiAgICAgICAgICAgICAgICApO1xuICAgICAgICAgICAgICAgIGZvciAobGV0IGNvbmYgb2YgY29uZmlncykge1xuICAgICAgICAgICAgICAgICAgbGV0IGFnZW50Q29uZmlnUmVzcG9uc2UgPSB7fTtcbiAgICAgICAgICAgICAgICAgIHRyeSB7XG4gICAgICAgICAgICAgICAgICAgIGlmICghY29uZlsnbmFtZSddKSB7XG4gICAgICAgICAgICAgICAgICAgICAgYWdlbnRDb25maWdSZXNwb25zZSA9XG4gICAgICAgICAgICAgICAgICAgICAgICBhd2FpdCBjb250ZXh0LndhenVoLmFwaS5jbGllbnQuYXNDdXJyZW50VXNlci5yZXF1ZXN0KFxuICAgICAgICAgICAgICAgICAgICAgICAgICAnR0VUJyxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgYC9hZ2VudHMvJHthZ2VudElEfS9jb25maWcvJHtjb25mLmNvbXBvbmVudH0vJHtjb25mLmNvbmZpZ3VyYXRpb259YCxcbiAgICAgICAgICAgICAgICAgICAgICAgICAge30sXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHsgYXBpSG9zdElEOiBhcGlJZCB9LFxuICAgICAgICAgICAgICAgICAgICAgICAgKTtcbiAgICAgICAgICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgICAgICAgICBmb3IgKGxldCB3b2RsZSBvZiB3bW9kdWxlc1Jlc3BvbnNlLmRhdGEuZGF0YVtcbiAgICAgICAgICAgICAgICAgICAgICAgICd3bW9kdWxlcydcbiAgICAgICAgICAgICAgICAgICAgICBdKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAoT2JqZWN0LmtleXMod29kbGUpWzBdID09PSBjb25mWyduYW1lJ10pIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgYWdlbnRDb25maWdSZXNwb25zZS5kYXRhID0ge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGRhdGE6IHdvZGxlLFxuICAgICAgICAgICAgICAgICAgICAgICAgICB9O1xuICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAgICAgICAgIGNvbnN0IGFnZW50Q29uZmlnID1cbiAgICAgICAgICAgICAgICAgICAgICBhZ2VudENvbmZpZ1Jlc3BvbnNlICYmXG4gICAgICAgICAgICAgICAgICAgICAgYWdlbnRDb25maWdSZXNwb25zZS5kYXRhICYmXG4gICAgICAgICAgICAgICAgICAgICAgYWdlbnRDb25maWdSZXNwb25zZS5kYXRhLmRhdGE7XG4gICAgICAgICAgICAgICAgICAgIGlmICghdGl0bGVPZlNlY3Rpb24pIHtcbiAgICAgICAgICAgICAgICAgICAgICBwcmludGVyLmFkZENvbnRlbnQoe1xuICAgICAgICAgICAgICAgICAgICAgICAgdGV4dDogY29uZmlnLnRpdGxlLFxuICAgICAgICAgICAgICAgICAgICAgICAgc3R5bGU6ICdoMScsXG4gICAgICAgICAgICAgICAgICAgICAgICBtYXJnaW46IFswLCAwLCAwLCAxNV0sXG4gICAgICAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgICAgICAgdGl0bGVPZlNlY3Rpb24gPSB0cnVlO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIGlmICghdGl0bGVPZlN1YnNlY3Rpb24pIHtcbiAgICAgICAgICAgICAgICAgICAgICBwcmludGVyLmFkZENvbnRlbnQoe1xuICAgICAgICAgICAgICAgICAgICAgICAgdGV4dDogc2VjdGlvbi5zdWJ0aXRsZSxcbiAgICAgICAgICAgICAgICAgICAgICAgIHN0eWxlOiAnaDQnLFxuICAgICAgICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgICAgICAgIHByaW50ZXIuYWRkQ29udGVudCh7XG4gICAgICAgICAgICAgICAgICAgICAgICB0ZXh0OiBzZWN0aW9uLmRlc2MsXG4gICAgICAgICAgICAgICAgICAgICAgICBzdHlsZTogeyBmb250U2l6ZTogMTIsIGNvbG9yOiAnIzAwMCcgfSxcbiAgICAgICAgICAgICAgICAgICAgICAgIG1hcmdpbjogWzAsIDAsIDAsIDEwXSxcbiAgICAgICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICAgICAgICB0aXRsZU9mU3Vic2VjdGlvbiA9IHRydWU7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgaWYgKGFnZW50Q29uZmlnKSB7XG4gICAgICAgICAgICAgICAgICAgICAgZm9yIChsZXQgYWdlbnRDb25maWdLZXkgb2YgT2JqZWN0LmtleXMoYWdlbnRDb25maWcpKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAoQXJyYXkuaXNBcnJheShhZ2VudENvbmZpZ1thZ2VudENvbmZpZ0tleV0pKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgIC8qIExPRyBDT0xMRUNUT1IgKi9cbiAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKGNvbmYuZmlsdGVyQnkpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBsZXQgZ3JvdXBzID0gW107XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgYWdlbnRDb25maWdbYWdlbnRDb25maWdLZXldLmZvckVhY2gob2JqID0+IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmICghZ3JvdXBzW29iai5sb2dmb3JtYXRdKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGdyb3Vwc1tvYmoubG9nZm9ybWF0XSA9IFtdO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZ3JvdXBzW29iai5sb2dmb3JtYXRdLnB1c2gob2JqKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBPYmplY3Qua2V5cyhncm91cHMpLmZvckVhY2goZ3JvdXAgPT4ge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbGV0IHNhdmVpZHggPSAwO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZ3JvdXBzW2dyb3VwXS5mb3JFYWNoKCh4LCBpKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmIChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBPYmplY3Qua2V5cyh4KS5sZW5ndGggPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIE9iamVjdC5rZXlzKGdyb3Vwc1tncm91cF1bc2F2ZWlkeF0pLmxlbmd0aFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzYXZlaWR4ID0gaTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb25zdCBjb2x1bW5zID0gT2JqZWN0LmtleXMoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGdyb3Vwc1tncm91cF1bc2F2ZWlkeF0sXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICApO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc3Qgcm93cyA9IGdyb3Vwc1tncm91cF0ubWFwKHggPT4ge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBsZXQgcm93ID0gW107XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbHVtbnMuZm9yRWFjaChrZXkgPT4ge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJvdy5wdXNoKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZW9mIHhba2V5XSAhPT0gJ29iamVjdCdcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPyB4W2tleV1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgOiBBcnJheS5pc0FycmF5KHhba2V5XSlcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPyB4W2tleV0ubWFwKHggPT4ge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIHggKyAnXFxuJztcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9KVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA6IEpTT04uc3RyaW5naWZ5KHhba2V5XSksXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiByb3c7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbHVtbnMuZm9yRWFjaCgoY29sLCBpKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbHVtbnNbaV0gPVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbFswXS50b1VwcGVyQ2FzZSgpICsgY29sLnNsaWNlKDEpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0YWJsZXMucHVzaCh7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRpdGxlOiBzZWN0aW9uLmxhYmVsc1swXVtncm91cF0sXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU6ICd0YWJsZScsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbHVtbnMsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJvd3MsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgfSBlbHNlIGlmIChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBhZ2VudENvbmZpZ0tleS5jb25maWd1cmF0aW9uICE9PSAnc29ja2V0J1xuICAgICAgICAgICAgICAgICAgICAgICAgICApIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0YWJsZXMucHVzaChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC4uLnRoaXMuZ2V0Q29uZmlnVGFibGVzKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb250ZXh0LFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBhZ2VudENvbmZpZ1thZ2VudENvbmZpZ0tleV0sXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNlY3Rpb24sXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlkeCxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICksXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBmb3IgKGxldCBfZDIgb2YgYWdlbnRDb25maWdbYWdlbnRDb25maWdLZXldKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0YWJsZXMucHVzaChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLi4udGhpcy5nZXRDb25maWdUYWJsZXMoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29udGV4dCxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBfZDIsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc2VjdGlvbixcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZHgsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICksXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICApO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgLyogSU5URUdSSVRZIE1PTklUT1JJTkcgTU9OSVRPUkVEIERJUkVDVE9SSUVTICovXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGlmIChjb25mLm1hdHJpeCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGRpcmVjdG9yaWVzLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZGlmZixcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHN5bmNocm9uaXphdGlvbixcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGZpbGVfbGltaXQsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAuLi5yZXN0XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfSA9IGFnZW50Q29uZmlnW2FnZW50Q29uZmlnS2V5XTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0YWJsZXMucHVzaChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC4uLnRoaXMuZ2V0Q29uZmlnVGFibGVzKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb250ZXh0LFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXN0LFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzZWN0aW9uLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZHgsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICApLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLi4uKGRpZmYgJiYgZGlmZi5kaXNrX3F1b3RhXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID8gdGhpcy5nZXRDb25maWdUYWJsZXMoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb250ZXh0LFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZGlmZi5kaXNrX3F1b3RhLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgeyB0YWJzOiBbJ0Rpc2sgcXVvdGEnXSB9LFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgMCxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDogW10pLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLi4uKGRpZmYgJiYgZGlmZi5maWxlX3NpemVcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPyB0aGlzLmdldENvbmZpZ1RhYmxlcyhcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnRleHQsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBkaWZmLmZpbGVfc2l6ZSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHsgdGFiczogWydGaWxlIHNpemUnXSB9LFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgMCxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDogW10pLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLi4uKHN5bmNocm9uaXphdGlvblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA/IHRoaXMuZ2V0Q29uZmlnVGFibGVzKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29udGV4dCxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHN5bmNocm9uaXphdGlvbixcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHsgdGFiczogWydTeW5jaHJvbml6YXRpb24nXSB9LFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgMCxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDogW10pLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLi4uKGZpbGVfbGltaXRcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPyB0aGlzLmdldENvbmZpZ1RhYmxlcyhcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnRleHQsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBmaWxlX2xpbWl0LFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgeyB0YWJzOiBbJ0ZpbGUgbGltaXQnXSB9LFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgMCxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDogW10pLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgbGV0IGRpZmZPcHRzID0gW107XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgT2JqZWN0LmtleXMoc2VjdGlvbi5vcHRzKS5mb3JFYWNoKHggPT4ge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZGlmZk9wdHMucHVzaCh4KTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb25zdCBjb2x1bW5zID0gW1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgJycsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAuLi5kaWZmT3B0cy5maWx0ZXIoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHggPT4geCAhPT0gJ2NoZWNrX2FsbCcgJiYgeCAhPT0gJ2NoZWNrX3N1bScsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICApLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIF07XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgbGV0IHJvd3MgPSBbXTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBkaXJlY3Rvcmllcy5mb3JFYWNoKHggPT4ge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbGV0IHJvdyA9IFtdO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcm93LnB1c2goeC5kaXIpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29sdW1ucy5mb3JFYWNoKHkgPT4ge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAoeSAhPT0gJycpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICByb3cucHVzaChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHgub3B0cy5pbmRleE9mKHkpID4gLTEgPyAneWVzJyA6ICdubycsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICByb3cucHVzaCh4LnJlY3Vyc2lvbl9sZXZlbCk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICByb3dzLnB1c2gocm93KTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb2x1bW5zLmZvckVhY2goKHgsIGlkeCkgPT4ge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29sdW1uc1tpZHhdID0gc2VjdGlvbi5vcHRzW3hdO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbHVtbnMucHVzaCgnUkwnKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0YWJsZXMucHVzaCh7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0aXRsZTogJ01vbml0b3JlZCBkaXJlY3RvcmllcycsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlOiAndGFibGUnLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29sdW1ucyxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJvd3MsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdGFibGVzLnB1c2goXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAuLi50aGlzLmdldENvbmZpZ1RhYmxlcyhcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29udGV4dCxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYWdlbnRDb25maWdbYWdlbnRDb25maWdLZXldLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzZWN0aW9uLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZHgsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICApLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgICAgICAgLy8gUHJpbnQgbm8gY29uZmlndXJlZCBtb2R1bGUgYW5kIGxpbmsgdG8gdGhlIGRvY3VtZW50YXRpb25cbiAgICAgICAgICAgICAgICAgICAgICBwcmludGVyLmFkZENvbnRlbnQoe1xuICAgICAgICAgICAgICAgICAgICAgICAgdGV4dDogW1xuICAgICAgICAgICAgICAgICAgICAgICAgICAnVGhpcyBtb2R1bGUgaXMgbm90IGNvbmZpZ3VyZWQuIFBsZWFzZSB0YWtlIGEgbG9vayBvbiBob3cgdG8gY29uZmlndXJlIGl0IGluICcsXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0ZXh0OiBgJHtzZWN0aW9uLnN1YnRpdGxlLnRvTG93ZXJDYXNlKCl9IGNvbmZpZ3VyYXRpb24uYCxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBsaW5rOiBzZWN0aW9uLmRvY3VMaW5rLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHN0eWxlOiB7IGZvbnRTaXplOiAxMiwgY29sb3I6ICcjMWEwZGFiJyB9LFxuICAgICAgICAgICAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICAgICAgICAgICAgXSxcbiAgICAgICAgICAgICAgICAgICAgICAgIG1hcmdpbjogWzAsIDAsIDAsIDIwXSxcbiAgICAgICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgICAgICAgICAgICAgICAgY29udGV4dC53YXp1aC5sb2dnZXIuZGVidWcoZXJyb3IubWVzc2FnZSB8fCBlcnJvcik7XG4gICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICBpZHgrKztcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgZm9yIChjb25zdCB0YWJsZSBvZiB0YWJsZXMpIHtcbiAgICAgICAgICAgICAgICAgIHByaW50ZXIuYWRkQ29uZmlnVGFibGVzKFt0YWJsZV0pO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICBpZHhDb21wb25lbnQrKztcbiAgICAgICAgICAgICAgdGFibGVzID0gW107XG4gICAgICAgICAgICB9XG4gICAgICAgICAgfVxuXG4gICAgICAgICAgYXdhaXQgcHJpbnRlci5wcmludChjb250ZXh0LndhenVoRW5kcG9pbnRQYXJhbXMucGF0aEZpbGVuYW1lKTtcblxuICAgICAgICAgIHJldHVybiByZXNwb25zZS5vayh7XG4gICAgICAgICAgICBib2R5OiB7XG4gICAgICAgICAgICAgIHN1Y2Nlc3M6IHRydWUsXG4gICAgICAgICAgICAgIG1lc3NhZ2U6IGBSZXBvcnQgJHtjb250ZXh0LndhenVoRW5kcG9pbnRQYXJhbXMuZmlsZW5hbWV9IHdhcyBjcmVhdGVkYCxcbiAgICAgICAgICAgICAgZmlsZW5hbWU6IGNvbnRleHQud2F6dWhFbmRwb2ludFBhcmFtcy5maWxlbmFtZSxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgfSk7XG4gICAgICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICAgICAgY29udGV4dC53YXp1aC5sb2dnZXIuZGVidWcoZXJyb3IubWVzc2FnZSB8fCBlcnJvcik7XG4gICAgICAgICAgcmV0dXJuIEVycm9yUmVzcG9uc2UoZXJyb3IubWVzc2FnZSB8fCBlcnJvciwgNTAyOSwgNTAwLCByZXNwb25zZSk7XG4gICAgICAgIH1cbiAgICAgIH0sXG4gICAgICAoeyBwYXJhbXM6IHsgYWdlbnRJRCB9IH0pID0+XG4gICAgICAgIGB3YXp1aC1hZ2VudC1jb25maWd1cmF0aW9uLSR7YWdlbnRJRH0tJHt0aGlzLmdlbmVyYXRlUmVwb3J0VGltZXN0YW1wKCl9LnBkZmAsXG4gICAgKTtcblxuICAvKipcbiAgICogRmV0Y2ggdGhlIHJlcG9ydHMgbGlzdFxuICAgKiBAcGFyYW0ge09iamVjdH0gY29udGV4dFxuICAgKiBAcGFyYW0ge09iamVjdH0gcmVxdWVzdFxuICAgKiBAcGFyYW0ge09iamVjdH0gcmVzcG9uc2VcbiAgICogQHJldHVybnMge0FycmF5PE9iamVjdD59IHJlcG9ydHMgbGlzdCBvciBFcnJvclJlc3BvbnNlXG4gICAqL1xuICBhc3luYyBnZXRSZXBvcnRzKFxuICAgIGNvbnRleHQ6IFJlcXVlc3RIYW5kbGVyQ29udGV4dCxcbiAgICByZXF1ZXN0OiBPcGVuU2VhcmNoRGFzaGJvYXJkc1JlcXVlc3QsXG4gICAgcmVzcG9uc2U6IE9wZW5TZWFyY2hEYXNoYm9hcmRzUmVzcG9uc2VGYWN0b3J5LFxuICApIHtcbiAgICB0cnkge1xuICAgICAgY29udGV4dC53YXp1aC5sb2dnZXIuZGVidWcoJ0ZldGNoaW5nIGNyZWF0ZWQgcmVwb3J0cycpO1xuICAgICAgY29uc3QgeyBoYXNoVXNlcm5hbWUgfSA9IGF3YWl0IGNvbnRleHQud2F6dWguc2VjdXJpdHkuZ2V0Q3VycmVudFVzZXIoXG4gICAgICAgIHJlcXVlc3QsXG4gICAgICAgIGNvbnRleHQsXG4gICAgICApO1xuXG4gICAgICBjb25zdCB1c2VyUmVwb3J0c0RpcmVjdG9yeVBhdGggPVxuICAgICAgICBjb250ZXh0LndhenVoX2NvcmUuZGF0YVBhdGhTZXJ2aWNlLmNyZWF0ZURhdGFEaXJlY3RvcnlJZk5vdEV4aXN0cyhcbiAgICAgICAgICBgZG93bmxvYWRzL3JlcG9ydHMvJHtoYXNoVXNlcm5hbWV9YCxcbiAgICAgICAgKTtcblxuICAgICAgY29udGV4dC53YXp1aC5sb2dnZXIuZGVidWcoYERpcmVjdG9yeTogJHt1c2VyUmVwb3J0c0RpcmVjdG9yeVBhdGh9YCk7XG5cbiAgICAgIGNvbnN0IHNvcnRSZXBvcnRzQnlEYXRlID0gKGEsIGIpID0+XG4gICAgICAgIGEuZGF0ZSA8IGIuZGF0ZSA/IDEgOiBhLmRhdGUgPiBiLmRhdGUgPyAtMSA6IDA7XG5cbiAgICAgIGNvbnN0IHJlcG9ydHMgPSBmcy5yZWFkZGlyU3luYyh1c2VyUmVwb3J0c0RpcmVjdG9yeVBhdGgpLm1hcChmaWxlID0+IHtcbiAgICAgICAgY29uc3Qgc3RhdHMgPSBmcy5zdGF0U3luYyh1c2VyUmVwb3J0c0RpcmVjdG9yeVBhdGggKyAnLycgKyBmaWxlKTtcbiAgICAgICAgLy8gR2V0IHRoZSBmaWxlIGNyZWF0aW9uIHRpbWUgKGJpdGh0aW1lKS4gSXQgcmV0dXJucyB0aGUgZmlyc3QgdmFsdWUgdGhhdCBpcyBhIHRydXRoeSB2YWx1ZSBvZiBuZXh0IGZpbGUgc3RhdHM6IGJpcnRodGltZSwgbXRpbWUsIGN0aW1lIGFuZCBhdGltZS5cbiAgICAgICAgLy8gVGhpcyBzb2x2ZXMgc29tZSBPU3MgY2FuIGhhdmUgdGhlIGJpdGh0aW1lTXMgZXF1YWwgdG8gMCBhbmQgcmV0dXJucyB0aGUgZGF0ZSBsaWtlIDE5NzAtMDEtMDFcbiAgICAgICAgY29uc3QgYmlydGhUaW1lRmllbGQgPSBbJ2JpcnRodGltZScsICdtdGltZScsICdjdGltZScsICdhdGltZSddLmZpbmQoXG4gICAgICAgICAgdGltZSA9PiBzdGF0c1tgJHt0aW1lfU1zYF0sXG4gICAgICAgICk7XG4gICAgICAgIHJldHVybiB7XG4gICAgICAgICAgbmFtZTogZmlsZSxcbiAgICAgICAgICBzaXplOiBzdGF0cy5zaXplLFxuICAgICAgICAgIGRhdGU6IHN0YXRzW2JpcnRoVGltZUZpZWxkXSxcbiAgICAgICAgfTtcbiAgICAgIH0pO1xuICAgICAgY29udGV4dC53YXp1aC5sb2dnZXIuZGVidWcoXG4gICAgICAgIGBVc2luZyBUaW1Tb3J0IGZvciBzb3J0aW5nICR7cmVwb3J0cy5sZW5ndGh9IGl0ZW1zYCxcbiAgICAgICk7XG4gICAgICBUaW1Tb3J0LnNvcnQocmVwb3J0cywgc29ydFJlcG9ydHNCeURhdGUpO1xuICAgICAgY29udGV4dC53YXp1aC5sb2dnZXIuZGVidWcoYFRvdGFsIHJlcG9ydHM6ICR7cmVwb3J0cy5sZW5ndGh9YCk7XG4gICAgICByZXR1cm4gcmVzcG9uc2Uub2soe1xuICAgICAgICBib2R5OiB7IHJlcG9ydHMgfSxcbiAgICAgIH0pO1xuICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICBjb250ZXh0LndhenVoLmxvZ2dlci5lcnJvcihlcnJvci5tZXNzYWdlIHx8IGVycm9yKTtcbiAgICAgIHJldHVybiBFcnJvclJlc3BvbnNlKGVycm9yLm1lc3NhZ2UgfHwgZXJyb3IsIDUwMzEsIDUwMCwgcmVzcG9uc2UpO1xuICAgIH1cbiAgfVxuXG4gIC8qKlxuICAgKiBGZXRjaCBzcGVjaWZpYyByZXBvcnRcbiAgICogQHBhcmFtIHtPYmplY3R9IGNvbnRleHRcbiAgICogQHBhcmFtIHtPYmplY3R9IHJlcXVlc3RcbiAgICogQHBhcmFtIHtPYmplY3R9IHJlc3BvbnNlXG4gICAqIEByZXR1cm5zIHtPYmplY3R9IHJlcG9ydCBvciBFcnJvclJlc3BvbnNlXG4gICAqL1xuICBnZXRSZXBvcnRCeU5hbWUgPSB0aGlzLmNoZWNrUmVwb3J0c1VzZXJEaXJlY3RvcnlJc1ZhbGlkUm91dGVEZWNvcmF0b3IoXG4gICAgYXN5bmMgKFxuICAgICAgY29udGV4dDogUmVxdWVzdEhhbmRsZXJDb250ZXh0LFxuICAgICAgcmVxdWVzdDogT3BlblNlYXJjaERhc2hib2FyZHNSZXF1ZXN0LFxuICAgICAgcmVzcG9uc2U6IE9wZW5TZWFyY2hEYXNoYm9hcmRzUmVzcG9uc2VGYWN0b3J5LFxuICAgICkgPT4ge1xuICAgICAgdHJ5IHtcbiAgICAgICAgY29udGV4dC53YXp1aC5sb2dnZXIuZGVidWcoXG4gICAgICAgICAgYEdldHRpbmcgJHtjb250ZXh0LndhenVoRW5kcG9pbnRQYXJhbXMucGF0aEZpbGVuYW1lfSByZXBvcnRgLFxuICAgICAgICApO1xuICAgICAgICBjb25zdCByZXBvcnRGaWxlQnVmZmVyID0gZnMucmVhZEZpbGVTeW5jKFxuICAgICAgICAgIGNvbnRleHQud2F6dWhFbmRwb2ludFBhcmFtcy5wYXRoRmlsZW5hbWUsXG4gICAgICAgICk7XG4gICAgICAgIHJldHVybiByZXNwb25zZS5vayh7XG4gICAgICAgICAgaGVhZGVyczogeyAnQ29udGVudC1UeXBlJzogJ2FwcGxpY2F0aW9uL3BkZicgfSxcbiAgICAgICAgICBib2R5OiByZXBvcnRGaWxlQnVmZmVyLFxuICAgICAgICB9KTtcbiAgICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICAgIGNvbnRleHQud2F6dWgubG9nZ2VyLmVycm9yKGVycm9yLm1lc3NhZ2UgfHwgZXJyb3IpO1xuICAgICAgICByZXR1cm4gRXJyb3JSZXNwb25zZShlcnJvci5tZXNzYWdlIHx8IGVycm9yLCA1MDMwLCA1MDAsIHJlc3BvbnNlKTtcbiAgICAgIH1cbiAgICB9LFxuICAgIHJlcXVlc3QgPT4gcmVxdWVzdC5wYXJhbXMubmFtZSxcbiAgKTtcblxuICAvKipcbiAgICogRGVsZXRlIHNwZWNpZmljIHJlcG9ydFxuICAgKiBAcGFyYW0ge09iamVjdH0gY29udGV4dFxuICAgKiBAcGFyYW0ge09iamVjdH0gcmVxdWVzdFxuICAgKiBAcGFyYW0ge09iamVjdH0gcmVzcG9uc2VcbiAgICogQHJldHVybnMge09iamVjdH0gc3RhdHVzIG9iaiBvciBFcnJvclJlc3BvbnNlXG4gICAqL1xuICBkZWxldGVSZXBvcnRCeU5hbWUgPSB0aGlzLmNoZWNrUmVwb3J0c1VzZXJEaXJlY3RvcnlJc1ZhbGlkUm91dGVEZWNvcmF0b3IoXG4gICAgYXN5bmMgKFxuICAgICAgY29udGV4dDogUmVxdWVzdEhhbmRsZXJDb250ZXh0LFxuICAgICAgcmVxdWVzdDogT3BlblNlYXJjaERhc2hib2FyZHNSZXF1ZXN0LFxuICAgICAgcmVzcG9uc2U6IE9wZW5TZWFyY2hEYXNoYm9hcmRzUmVzcG9uc2VGYWN0b3J5LFxuICAgICkgPT4ge1xuICAgICAgdHJ5IHtcbiAgICAgICAgY29udGV4dC53YXp1aC5sb2dnZXIuZGVidWcoXG4gICAgICAgICAgYERlbGV0aW5nICR7Y29udGV4dC53YXp1aEVuZHBvaW50UGFyYW1zLnBhdGhGaWxlbmFtZX0gcmVwb3J0YCxcbiAgICAgICAgKTtcbiAgICAgICAgZnMudW5saW5rU3luYyhjb250ZXh0LndhenVoRW5kcG9pbnRQYXJhbXMucGF0aEZpbGVuYW1lKTtcbiAgICAgICAgY29udGV4dC53YXp1aC5sb2dnZXIuaW5mbyhcbiAgICAgICAgICBgJHtjb250ZXh0LndhenVoRW5kcG9pbnRQYXJhbXMucGF0aEZpbGVuYW1lfSByZXBvcnQgd2FzIGRlbGV0ZWRgLFxuICAgICAgICApO1xuICAgICAgICByZXR1cm4gcmVzcG9uc2Uub2soe1xuICAgICAgICAgIGJvZHk6IHsgZXJyb3I6IDAgfSxcbiAgICAgICAgfSk7XG4gICAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgICBjb250ZXh0LndhenVoLmxvZ2dlci5lcnJvcihlcnJvci5tZXNzYWdlIHx8IGVycm9yKTtcbiAgICAgICAgcmV0dXJuIEVycm9yUmVzcG9uc2UoZXJyb3IubWVzc2FnZSB8fCBlcnJvciwgNTAzMiwgNTAwLCByZXNwb25zZSk7XG4gICAgICB9XG4gICAgfSxcbiAgICByZXF1ZXN0ID0+IHJlcXVlc3QucGFyYW1zLm5hbWUsXG4gICk7XG5cbiAgY2hlY2tSZXBvcnRzVXNlckRpcmVjdG9yeUlzVmFsaWRSb3V0ZURlY29yYXRvcihcbiAgICByb3V0ZUhhbmRsZXIsXG4gICAgcmVwb3J0RmlsZU5hbWVBY2Nlc3NvcixcbiAgKSB7XG4gICAgcmV0dXJuIGFzeW5jIChcbiAgICAgIGNvbnRleHQ6IFJlcXVlc3RIYW5kbGVyQ29udGV4dCxcbiAgICAgIHJlcXVlc3Q6IE9wZW5TZWFyY2hEYXNoYm9hcmRzUmVxdWVzdCxcbiAgICAgIHJlc3BvbnNlOiBPcGVuU2VhcmNoRGFzaGJvYXJkc1Jlc3BvbnNlRmFjdG9yeSxcbiAgICApID0+IHtcbiAgICAgIHRyeSB7XG4gICAgICAgIGNvbnN0IHsgdXNlcm5hbWUsIGhhc2hVc2VybmFtZSB9ID1cbiAgICAgICAgICBhd2FpdCBjb250ZXh0LndhenVoLnNlY3VyaXR5LmdldEN1cnJlbnRVc2VyKHJlcXVlc3QsIGNvbnRleHQpO1xuICAgICAgICBjb25zdCB1c2VyUmVwb3J0c0RpcmVjdG9yeVBhdGggPSBwYXRoLmpvaW4oXG4gICAgICAgICAgY29udGV4dC53YXp1aF9jb3JlLmRhdGFQYXRoU2VydmljZS5nZXREYXRhRGlyZWN0b3J5UmVsYXRpdmUoXG4gICAgICAgICAgICAnZG93bmxvYWRzL3JlcG9ydHMnLFxuICAgICAgICAgICksXG4gICAgICAgICAgaGFzaFVzZXJuYW1lLFxuICAgICAgICApO1xuICAgICAgICBjb25zdCBmaWxlbmFtZSA9IHJlcG9ydEZpbGVOYW1lQWNjZXNzb3IocmVxdWVzdCk7XG4gICAgICAgIGNvbnN0IHBhdGhGaWxlbmFtZSA9IHBhdGguam9pbih1c2VyUmVwb3J0c0RpcmVjdG9yeVBhdGgsIGZpbGVuYW1lKTtcbiAgICAgICAgY29udGV4dC53YXp1aC5sb2dnZXIuZGVidWcoXG4gICAgICAgICAgYENoZWNraW5nIHRoZSB1c2VyICR7dXNlcm5hbWV9KCR7aGFzaFVzZXJuYW1lfSkgY2FuIGRvIGFjdGlvbnMgaW4gdGhlIHJlcG9ydHMgZmlsZTogJHtwYXRoRmlsZW5hbWV9YCxcbiAgICAgICAgKTtcbiAgICAgICAgaWYgKFxuICAgICAgICAgICFwYXRoRmlsZW5hbWUuc3RhcnRzV2l0aCh1c2VyUmVwb3J0c0RpcmVjdG9yeVBhdGgpIHx8XG4gICAgICAgICAgcGF0aEZpbGVuYW1lLmluY2x1ZGVzKCcuLi8nKVxuICAgICAgICApIHtcbiAgICAgICAgICBjb250ZXh0LndhenVoLmxvZ2dlci53YXJuKFxuICAgICAgICAgICAgYFVzZXIgJHt1c2VybmFtZX0oJHtoYXNoVXNlcm5hbWV9KSB0cmllZCB0byBhY2Nlc3MgdG8gYSBub24gdXNlciByZXBvcnQgZmlsZTogJHtwYXRoRmlsZW5hbWV9YCxcbiAgICAgICAgICApO1xuICAgICAgICAgIHJldHVybiByZXNwb25zZS5iYWRSZXF1ZXN0KHtcbiAgICAgICAgICAgIGJvZHk6IHtcbiAgICAgICAgICAgICAgbWVzc2FnZTogJzUwNDAgLSBZb3Ugc2hhbGwgbm90IHBhc3MhJyxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgfSk7XG4gICAgICAgIH1cbiAgICAgICAgY29udGV4dC53YXp1aC5sb2dnZXIuZGVidWcoXG4gICAgICAgICAgJ0NoZWNraW5nIHRoZSB1c2VyIGNhbiBkbyBhY3Rpb25zIGluIHRoZSByZXBvcnRzIGZpbGUnLFxuICAgICAgICApO1xuICAgICAgICByZXR1cm4gYXdhaXQgcm91dGVIYW5kbGVyLmJpbmQodGhpcykoXG4gICAgICAgICAge1xuICAgICAgICAgICAgLi4uY29udGV4dCxcbiAgICAgICAgICAgIHdhenVoRW5kcG9pbnRQYXJhbXM6IHsgaGFzaFVzZXJuYW1lLCBmaWxlbmFtZSwgcGF0aEZpbGVuYW1lIH0sXG4gICAgICAgICAgfSxcbiAgICAgICAgICByZXF1ZXN0LFxuICAgICAgICAgIHJlc3BvbnNlLFxuICAgICAgICApO1xuICAgICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgICAgY29udGV4dC53YXp1aC5sb2dnZXIuZXJyb3IoZXJyb3IubWVzc2FnZSB8fCBlcnJvcik7XG4gICAgICAgIHJldHVybiBFcnJvclJlc3BvbnNlKGVycm9yLm1lc3NhZ2UgfHwgZXJyb3IsIDUwNDAsIDUwMCwgcmVzcG9uc2UpO1xuICAgICAgfVxuICAgIH07XG4gIH1cblxuICBwcml2YXRlIGdlbmVyYXRlUmVwb3J0VGltZXN0YW1wKCkge1xuICAgIHJldHVybiBgJHsoRGF0ZS5ub3coKSAvIDEwMDApIHwgMH1gO1xuICB9XG59XG4iXSwibWFwcGluZ3MiOiI7Ozs7OztBQVdBLElBQUFBLEtBQUEsR0FBQUMsc0JBQUEsQ0FBQUMsT0FBQTtBQUNBLElBQUFDLEdBQUEsR0FBQUYsc0JBQUEsQ0FBQUMsT0FBQTtBQUNBLElBQUFFLGFBQUEsR0FBQUYsT0FBQTtBQUNBLElBQUFHLE9BQUEsR0FBQUMsdUJBQUEsQ0FBQUosT0FBQTtBQUNBLElBQUFLLGNBQUEsR0FBQUwsT0FBQTtBQUNBLElBQUFNLGtCQUFBLEdBQUFOLE9BQUE7QUFDQSxJQUFBTyxtQkFBQSxHQUFBUCxPQUFBO0FBTUEsSUFBQVEsb0JBQUEsR0FBQVIsT0FBQTtBQUlBLElBQUFTLFFBQUEsR0FBQVQsT0FBQTtBQUNBLElBQUFVLFVBQUEsR0FBQVYsT0FBQTtBQUtBLElBQUFXLGdCQUFBLEdBQUFYLE9BQUE7QUFBc0YsU0FBQVkseUJBQUFDLENBQUEsNkJBQUFDLE9BQUEsbUJBQUFDLENBQUEsT0FBQUQsT0FBQSxJQUFBRSxDQUFBLE9BQUFGLE9BQUEsWUFBQUYsd0JBQUEsWUFBQUEsQ0FBQUMsQ0FBQSxXQUFBQSxDQUFBLEdBQUFHLENBQUEsR0FBQUQsQ0FBQSxLQUFBRixDQUFBO0FBQUEsU0FBQVQsd0JBQUFTLENBQUEsRUFBQUUsQ0FBQSxTQUFBQSxDQUFBLElBQUFGLENBQUEsSUFBQUEsQ0FBQSxDQUFBSSxVQUFBLFNBQUFKLENBQUEsZUFBQUEsQ0FBQSx1QkFBQUEsQ0FBQSx5QkFBQUEsQ0FBQSxXQUFBSyxPQUFBLEVBQUFMLENBQUEsUUFBQUcsQ0FBQSxHQUFBSix3QkFBQSxDQUFBRyxDQUFBLE9BQUFDLENBQUEsSUFBQUEsQ0FBQSxDQUFBRyxHQUFBLENBQUFOLENBQUEsVUFBQUcsQ0FBQSxDQUFBSSxHQUFBLENBQUFQLENBQUEsT0FBQVEsQ0FBQSxLQUFBQyxTQUFBLFVBQUFDLENBQUEsR0FBQUMsTUFBQSxDQUFBQyxjQUFBLElBQUFELE1BQUEsQ0FBQUUsd0JBQUEsV0FBQUMsQ0FBQSxJQUFBZCxDQUFBLG9CQUFBYyxDQUFBLE9BQUFDLGNBQUEsQ0FBQUMsSUFBQSxDQUFBaEIsQ0FBQSxFQUFBYyxDQUFBLFNBQUFHLENBQUEsR0FBQVAsQ0FBQSxHQUFBQyxNQUFBLENBQUFFLHdCQUFBLENBQUFiLENBQUEsRUFBQWMsQ0FBQSxVQUFBRyxDQUFBLEtBQUFBLENBQUEsQ0FBQVYsR0FBQSxJQUFBVSxDQUFBLENBQUFDLEdBQUEsSUFBQVAsTUFBQSxDQUFBQyxjQUFBLENBQUFKLENBQUEsRUFBQU0sQ0FBQSxFQUFBRyxDQUFBLElBQUFULENBQUEsQ0FBQU0sQ0FBQSxJQUFBZCxDQUFBLENBQUFjLENBQUEsWUFBQU4sQ0FBQSxDQUFBSCxPQUFBLEdBQUFMLENBQUEsRUFBQUcsQ0FBQSxJQUFBQSxDQUFBLENBQUFlLEdBQUEsQ0FBQWxCLENBQUEsRUFBQVEsQ0FBQSxHQUFBQSxDQUFBO0FBQUEsU0FBQXRCLHVCQUFBYyxDQUFBLFdBQUFBLENBQUEsSUFBQUEsQ0FBQSxDQUFBSSxVQUFBLEdBQUFKLENBQUEsS0FBQUssT0FBQSxFQUFBTCxDQUFBO0FBQUEsU0FBQW1CLGdCQUFBbkIsQ0FBQSxFQUFBRSxDQUFBLEVBQUFDLENBQUEsWUFBQUQsQ0FBQSxHQUFBa0IsY0FBQSxDQUFBbEIsQ0FBQSxNQUFBRixDQUFBLEdBQUFXLE1BQUEsQ0FBQUMsY0FBQSxDQUFBWixDQUFBLEVBQUFFLENBQUEsSUFBQW1CLEtBQUEsRUFBQWxCLENBQUEsRUFBQW1CLFVBQUEsTUFBQUMsWUFBQSxNQUFBQyxRQUFBLFVBQUF4QixDQUFBLENBQUFFLENBQUEsSUFBQUMsQ0FBQSxFQUFBSCxDQUFBO0FBQUEsU0FBQW9CLGVBQUFqQixDQUFBLFFBQUFjLENBQUEsR0FBQVEsWUFBQSxDQUFBdEIsQ0FBQSx1Q0FBQWMsQ0FBQSxHQUFBQSxDQUFBLEdBQUFBLENBQUE7QUFBQSxTQUFBUSxhQUFBdEIsQ0FBQSxFQUFBRCxDQUFBLDJCQUFBQyxDQUFBLEtBQUFBLENBQUEsU0FBQUEsQ0FBQSxNQUFBSCxDQUFBLEdBQUFHLENBQUEsQ0FBQXVCLE1BQUEsQ0FBQUMsV0FBQSxrQkFBQTNCLENBQUEsUUFBQWlCLENBQUEsR0FBQWpCLENBQUEsQ0FBQWdCLElBQUEsQ0FBQWIsQ0FBQSxFQUFBRCxDQUFBLHVDQUFBZSxDQUFBLFNBQUFBLENBQUEsWUFBQVcsU0FBQSx5RUFBQTFCLENBQUEsR0FBQTJCLE1BQUEsR0FBQUMsTUFBQSxFQUFBM0IsQ0FBQSxLQWpDdEY7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQThCTyxNQUFNNEIsa0JBQWtCLENBQUM7RUFDOUJDLFdBQVdBLENBQUEsRUFBRztJQXFQZDtBQUNGO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtJQU5FYixlQUFBLCtCQU91QixJQUFJLENBQUNjLDhDQUE4QyxDQUN4RSxPQUNFQyxPQUE4QixFQUM5QkMsT0FBb0MsRUFDcENDLFFBQTZDLEtBQzFDO01BQ0gsSUFBSTtRQUNGRixPQUFPLENBQUNHLEtBQUssQ0FBQ0MsTUFBTSxDQUFDQyxLQUFLLENBQUMsZ0JBQWdCLENBQUM7UUFDNUMsTUFBTTtVQUNKQyxLQUFLO1VBQ0xDLE1BQU07VUFDTkMsZUFBZTtVQUNmQyxTQUFTO1VBQ1RDLE9BQU87VUFDUEMsZUFBZTtVQUNmQyxJQUFJO1VBQ0pDLE1BQU07VUFDTkMsT0FBTztVQUNQQyxpQkFBaUI7VUFDakJDO1FBQ0YsQ0FBQyxHQUFHZixPQUFPLENBQUNnQixJQUFJO1FBQ2hCLE1BQU07VUFBRUM7UUFBUyxDQUFDLEdBQUdqQixPQUFPLENBQUNrQixNQUFNO1FBQ25DLE1BQU07VUFBRUMsSUFBSTtVQUFFQztRQUFHLENBQUMsR0FBR1QsSUFBSSxJQUFJLENBQUMsQ0FBQztRQUMvQixJQUFJVSxnQkFBZ0IsR0FBRyxFQUFFO1FBQ3pCO1FBQ0EsTUFBTUMsT0FBTyxHQUFHLElBQUlDLHNCQUFhLENBQy9CeEIsT0FBTyxDQUFDRyxLQUFLLENBQUNDLE1BQU0sQ0FBQy9CLEdBQUcsQ0FBQyxnQkFBZ0IsQ0FBQyxFQUMxQzJCLE9BQU8sQ0FBQ3lCLFVBQVUsQ0FBQ0MsYUFDckIsQ0FBQztRQUVEMUIsT0FBTyxDQUFDeUIsVUFBVSxDQUFDRSxlQUFlLENBQUNDLDhCQUE4QixDQUM5RCxxQkFBb0I1QixPQUFPLENBQUM2QixtQkFBbUIsQ0FBQ0MsWUFBYSxFQUNoRSxDQUFDO1FBRUQsTUFBTSxJQUFJLENBQUNDLFlBQVksQ0FDckIvQixPQUFPLEVBQ1B1QixPQUFPLEVBQ1BULE9BQU8sRUFDUEksUUFBUSxFQUNSWCxNQUFNLEVBQ05TLEtBQ0YsQ0FBQztRQUVELE1BQU0sQ0FBQ2dCLGdCQUFnQixFQUFFQyxZQUFZLENBQUMsR0FBR3ZCLE9BQU8sR0FDNUMsSUFBSSxDQUFDd0IscUJBQXFCLENBQUNsQyxPQUFPLEVBQUVVLE9BQU8sRUFBRUQsU0FBUyxDQUFDLEdBQ3ZELENBQUMsS0FBSyxFQUFFLElBQUksQ0FBQztRQUVqQixJQUFJRyxJQUFJLElBQUlvQixnQkFBZ0IsRUFBRTtVQUM1QlQsT0FBTyxDQUFDWSxzQkFBc0IsQ0FDNUJmLElBQUksRUFDSkMsRUFBRSxFQUNGVyxnQkFBZ0IsRUFDaEJ4QixlQUNGLENBQUM7UUFDSDtRQUVBLElBQUlJLElBQUksRUFBRTtVQUNSVSxnQkFBZ0IsR0FBRyxNQUFNLElBQUFjLHdDQUFtQixFQUMxQ3BDLE9BQU8sRUFDUHVCLE9BQU8sRUFDUFQsT0FBTyxFQUNQSSxRQUFRLEVBQ1JGLEtBQUssRUFDTCxJQUFJcUIsSUFBSSxDQUFDakIsSUFBSSxDQUFDLENBQUNrQixPQUFPLENBQUMsQ0FBQyxFQUN4QixJQUFJRCxJQUFJLENBQUNoQixFQUFFLENBQUMsQ0FBQ2lCLE9BQU8sQ0FBQyxDQUFDLEVBQ3RCM0IsZUFBZSxFQUNmSSxpQkFBaUIsSUFDZmYsT0FBTyxDQUFDeUIsVUFBVSxDQUFDQyxhQUFhLENBQUNhLGVBQWUsQ0FBQyxTQUFTLENBQUMsRUFDN0RoQyxNQUNGLENBQUM7UUFDSDtRQUVBZ0IsT0FBTyxDQUFDaUIsaUJBQWlCLENBQUNsQyxLQUFLLEVBQUVDLE1BQU0sRUFBRVcsUUFBUSxDQUFDO1FBRWxELElBQUlMLE1BQU0sRUFBRTtVQUNWVSxPQUFPLENBQUNrQixTQUFTLENBQUMsQ0FBQyxHQUFHNUIsTUFBTSxFQUFFLElBQUlTLGdCQUFnQixJQUFJLEVBQUUsQ0FBQyxDQUFDLENBQUM7UUFDN0Q7UUFFQSxNQUFNQyxPQUFPLENBQUNtQixLQUFLLENBQUMxQyxPQUFPLENBQUM2QixtQkFBbUIsQ0FBQ2MsWUFBWSxDQUFDO1FBRTdELE9BQU96QyxRQUFRLENBQUMwQyxFQUFFLENBQUM7VUFDakIzQixJQUFJLEVBQUU7WUFDSjRCLE9BQU8sRUFBRSxJQUFJO1lBQ2JDLE9BQU8sRUFBRyxVQUFTOUMsT0FBTyxDQUFDNkIsbUJBQW1CLENBQUNrQixRQUFTLGNBQWE7WUFDckVBLFFBQVEsRUFBRS9DLE9BQU8sQ0FBQzZCLG1CQUFtQixDQUFDa0I7VUFDeEM7UUFDRixDQUFDLENBQUM7TUFDSixDQUFDLENBQUMsT0FBT0MsS0FBSyxFQUFFO1FBQ2QsT0FBTyxJQUFBQyw0QkFBYSxFQUFDRCxLQUFLLENBQUNGLE9BQU8sSUFBSUUsS0FBSyxFQUFFLElBQUksRUFBRSxHQUFHLEVBQUU5QyxRQUFRLENBQUM7TUFDbkU7SUFDRixDQUFDLEVBQ0QsQ0FBQztNQUFFZSxJQUFJLEVBQUU7UUFBRVY7TUFBTyxDQUFDO01BQUVZLE1BQU0sRUFBRTtRQUFFRDtNQUFTO0lBQUUsQ0FBQyxLQUN4QyxnQkFDQ1gsTUFBTSxHQUFJLFVBQVNBLE1BQU8sRUFBQyxHQUFHLFVBQy9CLElBQUdXLFFBQVMsSUFBRyxJQUFJLENBQUNnQyx1QkFBdUIsQ0FBQyxDQUFFLE1BQ25ELENBQUM7SUFFRDtBQUNGO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtJQU5FakUsZUFBQSw4QkFPc0IsSUFBSSxDQUFDYyw4Q0FBOEMsQ0FDdkUsT0FDRUMsT0FBOEIsRUFDOUJDLE9BQW9DLEVBQ3BDQyxRQUE2QyxLQUMxQztNQUNILElBQUk7UUFDRkYsT0FBTyxDQUFDRyxLQUFLLENBQUNDLE1BQU0sQ0FBQ0MsS0FBSyxDQUFDLGdCQUFnQixDQUFDO1FBQzVDLE1BQU07VUFBRThDLFVBQVU7VUFBRW5DO1FBQU0sQ0FBQyxHQUFHZixPQUFPLENBQUNnQixJQUFJO1FBQzFDLE1BQU07VUFBRW1DO1FBQVEsQ0FBQyxHQUFHbkQsT0FBTyxDQUFDa0IsTUFBTTtRQUNsQztRQUNBLE1BQU1JLE9BQU8sR0FBRyxJQUFJQyxzQkFBYSxDQUMvQnhCLE9BQU8sQ0FBQ0csS0FBSyxDQUFDQyxNQUFNLENBQUMvQixHQUFHLENBQUMsZ0JBQWdCLENBQUMsRUFDMUMyQixPQUFPLENBQUN5QixVQUFVLENBQUNDLGFBQ3JCLENBQUM7UUFDRDFCLE9BQU8sQ0FBQ3lCLFVBQVUsQ0FBQ0UsZUFBZSxDQUFDQyw4QkFBOEIsQ0FDOUQscUJBQW9CNUIsT0FBTyxDQUFDNkIsbUJBQW1CLENBQUNDLFlBQWEsRUFDaEUsQ0FBQztRQUVELElBQUlqQixNQUFNLEdBQUcsRUFBRTtRQUNmLE1BQU13QyxZQUFZLEdBQUc7VUFDbkJDLFNBQVMsRUFBRSxhQUFhO1VBQ3hCQyxPQUFPLEVBQUUsU0FBUztVQUNsQkMsT0FBTyxFQUFFLFNBQVM7VUFDbEJDLFFBQVEsRUFBRSxVQUFVO1VBQ3BCLFdBQVcsRUFBRSxVQUFVO1VBQ3ZCLFNBQVMsRUFBRSxTQUFTO1VBQ3BCQyxZQUFZLEVBQUUsY0FBYztVQUM1QkMsU0FBUyxFQUFFLFdBQVc7VUFDdEJDLE1BQU0sRUFBRSxRQUFRO1VBQ2hCQyxHQUFHLEVBQUU7UUFDUCxDQUFDO1FBQ0R0QyxPQUFPLENBQUN1QyxVQUFVLENBQUM7VUFDakJDLElBQUksRUFBRyxTQUFRWCxPQUFRLGdCQUFlO1VBQ3RDWSxLQUFLLEVBQUU7UUFDVCxDQUFDLENBQUM7O1FBRUY7UUFDQSxJQUFJYixVQUFVLENBQUMsR0FBRyxDQUFDLEVBQUU7VUFDbkIsTUFBTTtZQUNKYyxJQUFJLEVBQUU7Y0FBRUEsSUFBSSxFQUFFdkM7WUFBYztVQUM5QixDQUFDLEdBQUcsTUFBTTFCLE9BQU8sQ0FBQ0csS0FBSyxDQUFDK0QsR0FBRyxDQUFDQyxNQUFNLENBQUNDLGFBQWEsQ0FBQ25FLE9BQU8sQ0FDdEQsS0FBSyxFQUNKLFdBQVVtRCxPQUFRLGdCQUFlLEVBQ2xDLENBQUMsQ0FBQyxFQUNGO1lBQUVpQixTQUFTLEVBQUVyRDtVQUFNLENBQ3JCLENBQUM7VUFFRCxJQUNFVSxhQUFhLENBQUM0QyxjQUFjLENBQUNDLE1BQU0sR0FBRyxDQUFDLElBQ3ZDOUYsTUFBTSxDQUFDK0YsSUFBSSxDQUFDOUMsYUFBYSxDQUFDNEMsY0FBYyxDQUFDLENBQUMsQ0FBQyxDQUFDRyxNQUFNLENBQUMsQ0FBQ0YsTUFBTSxFQUMxRDtZQUNBaEQsT0FBTyxDQUFDdUMsVUFBVSxDQUFDO2NBQ2pCQyxJQUFJLEVBQUUsZ0JBQWdCO2NBQ3RCQyxLQUFLLEVBQUU7Z0JBQUVVLFFBQVEsRUFBRSxFQUFFO2dCQUFFQyxLQUFLLEVBQUU7Y0FBTyxDQUFDO2NBQ3RDQyxNQUFNLEVBQUUsQ0FBQyxDQUFDLEVBQUUsRUFBRSxFQUFFLENBQUMsRUFBRSxFQUFFO1lBQ3ZCLENBQUMsQ0FBQztZQUNGLE1BQU05RCxPQUFPLEdBQUc7Y0FDZDhDLE1BQU0sRUFBRSxFQUFFO2NBQ1ZpQixhQUFhLEVBQUU7WUFDakIsQ0FBQztZQUNELEtBQUssSUFBSUosTUFBTSxJQUFJL0MsYUFBYSxDQUFDNEMsY0FBYyxFQUFFO2NBQy9DLElBQUlRLFdBQVcsR0FBRyxFQUFFO2NBQ3BCLElBQUlDLEtBQUssR0FBRyxDQUFDO2NBQ2IsS0FBSyxJQUFJQyxNQUFNLElBQUl2RyxNQUFNLENBQUMrRixJQUFJLENBQUNDLE1BQU0sQ0FBQy9ELE9BQU8sQ0FBQyxFQUFFO2dCQUM5Q29FLFdBQVcsR0FBR0EsV0FBVyxDQUFDRyxNQUFNLENBQzdCLEdBQUVELE1BQU8sS0FBSVAsTUFBTSxDQUFDL0QsT0FBTyxDQUFDc0UsTUFBTSxDQUFFLEVBQ3ZDLENBQUM7Z0JBQ0QsSUFBSUQsS0FBSyxHQUFHdEcsTUFBTSxDQUFDK0YsSUFBSSxDQUFDQyxNQUFNLENBQUMvRCxPQUFPLENBQUMsQ0FBQzZELE1BQU0sR0FBRyxDQUFDLEVBQUU7a0JBQ2xETyxXQUFXLEdBQUdBLFdBQVcsQ0FBQ0csTUFBTSxDQUFDLEtBQUssQ0FBQztnQkFDekM7Z0JBQ0FGLEtBQUssRUFBRTtjQUNUO2NBQ0F4RCxPQUFPLENBQUN1QyxVQUFVLENBQUM7Z0JBQ2pCQyxJQUFJLEVBQUVlLFdBQVc7Z0JBQ2pCZCxLQUFLLEVBQUUsSUFBSTtnQkFDWFksTUFBTSxFQUFFLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxDQUFDLEVBQUUsRUFBRTtjQUN0QixDQUFDLENBQUM7Y0FDRixJQUFJTSxHQUFHLEdBQUcsQ0FBQztjQUNYcEUsT0FBTyxDQUFDcUUsSUFBSSxHQUFHLEVBQUU7Y0FDakIsS0FBSyxJQUFJQyxFQUFFLElBQUkzRyxNQUFNLENBQUMrRixJQUFJLENBQUNDLE1BQU0sQ0FBQ0EsTUFBTSxDQUFDLEVBQUU7Z0JBQ3pDLEtBQUssSUFBSVksQ0FBQyxJQUFJQyxzQ0FBa0IsQ0FBQ0MsY0FBYyxFQUFFO2tCQUMvQyxLQUFLLElBQUlDLENBQUMsSUFBSUgsQ0FBQyxDQUFDSSxRQUFRLEVBQUU7b0JBQ3hCM0UsT0FBTyxDQUFDNEUsSUFBSSxHQUFHRixDQUFDLENBQUNFLElBQUksSUFBSSxDQUFDLENBQUM7b0JBQzNCLEtBQUssSUFBSUMsRUFBRSxJQUFJSCxDQUFDLENBQUNmLE1BQU0sSUFBSSxFQUFFLEVBQUU7c0JBQzdCLElBQUlrQixFQUFFLENBQUNqRSxhQUFhLEtBQUswRCxFQUFFLEVBQUU7d0JBQzNCdEUsT0FBTyxDQUFDOEMsTUFBTSxHQUFHNEIsQ0FBQyxDQUFDNUIsTUFBTSxJQUFJLENBQUMsRUFBRSxDQUFDO3NCQUNuQztvQkFDRjtvQkFDQSxLQUFLLElBQUlnQyxFQUFFLElBQUlKLENBQUMsQ0FBQ0ssS0FBSyxJQUFJLEVBQUUsRUFBRTtzQkFDNUIsSUFBSUQsRUFBRSxDQUFDRSxJQUFJLEtBQUtWLEVBQUUsRUFBRTt3QkFDbEJ0RSxPQUFPLENBQUM4QyxNQUFNLEdBQUc0QixDQUFDLENBQUM1QixNQUFNLElBQUksQ0FBQyxFQUFFLENBQUM7c0JBQ25DO29CQUNGO2tCQUNGO2dCQUNGO2dCQUNBOUMsT0FBTyxDQUFDOEMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxHQUFHLE9BQU87Z0JBQ25DOUMsT0FBTyxDQUFDOEMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxHQUFHLGFBQWE7Z0JBQzVDOUMsT0FBTyxDQUFDOEMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxHQUFHLDhCQUE4QjtnQkFDdkQ5QyxPQUFPLENBQUNxRSxJQUFJLENBQUNZLElBQUksQ0FBQzFDLFlBQVksQ0FBQytCLEVBQUUsQ0FBQyxDQUFDO2dCQUVuQyxJQUFJWSxLQUFLLENBQUNDLE9BQU8sQ0FBQ3hCLE1BQU0sQ0FBQ0EsTUFBTSxDQUFDVyxFQUFFLENBQUMsQ0FBQyxFQUFFO2tCQUNwQztrQkFDQSxJQUFJQSxFQUFFLEtBQUssV0FBVyxFQUFFO29CQUN0QixJQUFJYyxNQUFNLEdBQUcsRUFBRTtvQkFDZnpCLE1BQU0sQ0FBQ0EsTUFBTSxDQUFDVyxFQUFFLENBQUMsQ0FBQ2UsT0FBTyxDQUFDQyxHQUFHLElBQUk7c0JBQy9CLElBQUksQ0FBQ0YsTUFBTSxDQUFDRSxHQUFHLENBQUNDLFNBQVMsQ0FBQyxFQUFFO3dCQUMxQkgsTUFBTSxDQUFDRSxHQUFHLENBQUNDLFNBQVMsQ0FBQyxHQUFHLEVBQUU7c0JBQzVCO3NCQUNBSCxNQUFNLENBQUNFLEdBQUcsQ0FBQ0MsU0FBUyxDQUFDLENBQUNOLElBQUksQ0FBQ0ssR0FBRyxDQUFDO29CQUNqQyxDQUFDLENBQUM7b0JBQ0YzSCxNQUFNLENBQUMrRixJQUFJLENBQUMwQixNQUFNLENBQUMsQ0FBQ0MsT0FBTyxDQUFDRyxLQUFLLElBQUk7c0JBQ25DLElBQUlDLE9BQU8sR0FBRyxDQUFDO3NCQUNmTCxNQUFNLENBQUNJLEtBQUssQ0FBQyxDQUFDSCxPQUFPLENBQUMsQ0FBQ0ssQ0FBQyxFQUFFekgsQ0FBQyxLQUFLO3dCQUM5QixJQUNFTixNQUFNLENBQUMrRixJQUFJLENBQUNnQyxDQUFDLENBQUMsQ0FBQ2pDLE1BQU0sR0FDckI5RixNQUFNLENBQUMrRixJQUFJLENBQUMwQixNQUFNLENBQUNJLEtBQUssQ0FBQyxDQUFDQyxPQUFPLENBQUMsQ0FBQyxDQUFDaEMsTUFBTSxFQUMxQzswQkFDQWdDLE9BQU8sR0FBR3hILENBQUM7d0JBQ2I7c0JBQ0YsQ0FBQyxDQUFDO3NCQUNGLE1BQU0wSCxPQUFPLEdBQUdoSSxNQUFNLENBQUMrRixJQUFJLENBQUMwQixNQUFNLENBQUNJLEtBQUssQ0FBQyxDQUFDQyxPQUFPLENBQUMsQ0FBQztzQkFDbkQsTUFBTUcsSUFBSSxHQUFHUixNQUFNLENBQUNJLEtBQUssQ0FBQyxDQUFDSyxHQUFHLENBQUNILENBQUMsSUFBSTt3QkFDbEMsSUFBSUksR0FBRyxHQUFHLEVBQUU7d0JBQ1pILE9BQU8sQ0FBQ04sT0FBTyxDQUFDVSxHQUFHLElBQUk7MEJBQ3JCRCxHQUFHLENBQUNiLElBQUksQ0FDTixPQUFPUyxDQUFDLENBQUNLLEdBQUcsQ0FBQyxLQUFLLFFBQVEsR0FDdEJMLENBQUMsQ0FBQ0ssR0FBRyxDQUFDLEdBQ05iLEtBQUssQ0FBQ0MsT0FBTyxDQUFDTyxDQUFDLENBQUNLLEdBQUcsQ0FBQyxDQUFDLEdBQ3JCTCxDQUFDLENBQUNLLEdBQUcsQ0FBQyxDQUFDRixHQUFHLENBQUNILENBQUMsSUFBSTs0QkFDZCxPQUFPQSxDQUFDLEdBQUcsSUFBSTswQkFDakIsQ0FBQyxDQUFDLEdBQ0ZNLElBQUksQ0FBQ0MsU0FBUyxDQUFDUCxDQUFDLENBQUNLLEdBQUcsQ0FBQyxDQUMzQixDQUFDO3dCQUNILENBQUMsQ0FBQzt3QkFDRixPQUFPRCxHQUFHO3NCQUNaLENBQUMsQ0FBQztzQkFDRkgsT0FBTyxDQUFDTixPQUFPLENBQUMsQ0FBQ2EsR0FBRyxFQUFFakksQ0FBQyxLQUFLO3dCQUMxQjBILE9BQU8sQ0FBQzFILENBQUMsQ0FBQyxHQUFHaUksR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDQyxXQUFXLENBQUMsQ0FBQyxHQUFHRCxHQUFHLENBQUNFLEtBQUssQ0FBQyxDQUFDLENBQUM7c0JBQ2xELENBQUMsQ0FBQztzQkFDRnJHLE1BQU0sQ0FBQ2tGLElBQUksQ0FBQzt3QkFDVm9CLEtBQUssRUFBRSxhQUFhO3dCQUNwQkMsSUFBSSxFQUFFLE9BQU87d0JBQ2JYLE9BQU87d0JBQ1BDO3NCQUNGLENBQUMsQ0FBQztvQkFDSixDQUFDLENBQUM7a0JBQ0osQ0FBQyxNQUFNLElBQUl0QixFQUFFLEtBQUssUUFBUSxFQUFFO29CQUMxQixNQUFNZ0IsR0FBRyxHQUFHM0IsTUFBTSxDQUFDQSxNQUFNLENBQUNXLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDaUMsS0FBSztvQkFDdEMsTUFBTVosT0FBTyxHQUFHaEksTUFBTSxDQUFDK0YsSUFBSSxDQUFDNEIsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDO29CQUNuQyxJQUFJLENBQUNLLE9BQU8sQ0FBQ2EsUUFBUSxDQUFDLFFBQVEsQ0FBQyxFQUFFO3NCQUMvQmIsT0FBTyxDQUFDVixJQUFJLENBQUMsUUFBUSxDQUFDO29CQUN4QjtvQkFDQSxNQUFNVyxJQUFJLEdBQUdOLEdBQUcsQ0FBQ08sR0FBRyxDQUFDSCxDQUFDLElBQUk7c0JBQ3hCLElBQUlJLEdBQUcsR0FBRyxFQUFFO3NCQUNaSCxPQUFPLENBQUNOLE9BQU8sQ0FBQ1UsR0FBRyxJQUFJO3dCQUNyQkQsR0FBRyxDQUFDYixJQUFJLENBQUNTLENBQUMsQ0FBQ0ssR0FBRyxDQUFDLENBQUM7c0JBQ2xCLENBQUMsQ0FBQztzQkFDRixPQUFPRCxHQUFHO29CQUNaLENBQUMsQ0FBQztvQkFDRkgsT0FBTyxDQUFDTixPQUFPLENBQUMsQ0FBQ2EsR0FBRyxFQUFFakksQ0FBQyxLQUFLO3NCQUMxQjBILE9BQU8sQ0FBQzFILENBQUMsQ0FBQyxHQUFHaUksR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDQyxXQUFXLENBQUMsQ0FBQyxHQUFHRCxHQUFHLENBQUNFLEtBQUssQ0FBQyxDQUFDLENBQUM7b0JBQ2xELENBQUMsQ0FBQztvQkFDRnJHLE1BQU0sQ0FBQ2tGLElBQUksQ0FBQztzQkFDVm9CLEtBQUssRUFBRSxRQUFRO3NCQUNmQyxJQUFJLEVBQUUsT0FBTztzQkFDYlgsT0FBTztzQkFDUEM7b0JBQ0YsQ0FBQyxDQUFDO2tCQUNKLENBQUMsTUFBTTtvQkFDTCxLQUFLLElBQUlhLEdBQUcsSUFBSTlDLE1BQU0sQ0FBQ0EsTUFBTSxDQUFDVyxFQUFFLENBQUMsRUFBRTtzQkFDakN2RSxNQUFNLENBQUNrRixJQUFJLENBQ1QsR0FBRyxJQUFJLENBQUN5QixlQUFlLENBQUN4SCxPQUFPLEVBQUV1SCxHQUFHLEVBQUV6RyxPQUFPLEVBQUVvRSxHQUFHLENBQ3BELENBQUM7b0JBQ0g7a0JBQ0Y7Z0JBQ0YsQ0FBQyxNQUFNO2tCQUNMO2tCQUNBLElBQUlULE1BQU0sQ0FBQ0EsTUFBTSxDQUFDVyxFQUFFLENBQUMsQ0FBQ3FDLFdBQVcsRUFBRTtvQkFDakMsTUFBTUEsV0FBVyxHQUFHaEQsTUFBTSxDQUFDQSxNQUFNLENBQUNXLEVBQUUsQ0FBQyxDQUFDcUMsV0FBVztvQkFDakQsT0FBT2hELE1BQU0sQ0FBQ0EsTUFBTSxDQUFDVyxFQUFFLENBQUMsQ0FBQ3FDLFdBQVc7b0JBQ3BDNUcsTUFBTSxDQUFDa0YsSUFBSSxDQUNULEdBQUcsSUFBSSxDQUFDeUIsZUFBZSxDQUNyQnhILE9BQU8sRUFDUHlFLE1BQU0sQ0FBQ0EsTUFBTSxDQUFDVyxFQUFFLENBQUMsRUFDakJ0RSxPQUFPLEVBQ1BvRSxHQUNGLENBQ0YsQ0FBQztvQkFDRCxJQUFJd0MsUUFBUSxHQUFHLEVBQUU7b0JBQ2pCakosTUFBTSxDQUFDK0YsSUFBSSxDQUFDMUQsT0FBTyxDQUFDNEUsSUFBSSxDQUFDLENBQUNTLE9BQU8sQ0FBQ0ssQ0FBQyxJQUFJO3NCQUNyQ2tCLFFBQVEsQ0FBQzNCLElBQUksQ0FBQ1MsQ0FBQyxDQUFDO29CQUNsQixDQUFDLENBQUM7b0JBQ0YsTUFBTUMsT0FBTyxHQUFHLENBQ2QsRUFBRSxFQUNGLEdBQUdpQixRQUFRLENBQUMxQyxNQUFNLENBQ2hCd0IsQ0FBQyxJQUFJQSxDQUFDLEtBQUssV0FBVyxJQUFJQSxDQUFDLEtBQUssV0FDbEMsQ0FBQyxDQUNGO29CQUNELElBQUlFLElBQUksR0FBRyxFQUFFO29CQUNiZSxXQUFXLENBQUN0QixPQUFPLENBQUNLLENBQUMsSUFBSTtzQkFDdkIsSUFBSUksR0FBRyxHQUFHLEVBQUU7c0JBQ1pBLEdBQUcsQ0FBQ2IsSUFBSSxDQUFDUyxDQUFDLENBQUNtQixJQUFJLENBQUM7c0JBQ2hCbEIsT0FBTyxDQUFDTixPQUFPLENBQUN5QixDQUFDLElBQUk7d0JBQ25CLElBQUlBLENBQUMsS0FBSyxFQUFFLEVBQUU7MEJBQ1pBLENBQUMsR0FBR0EsQ0FBQyxLQUFLLGVBQWUsR0FBR0EsQ0FBQyxHQUFHLFNBQVM7MEJBQ3pDaEIsR0FBRyxDQUFDYixJQUFJLENBQUNTLENBQUMsQ0FBQ29CLENBQUMsQ0FBQyxHQUFHcEIsQ0FBQyxDQUFDb0IsQ0FBQyxDQUFDLEdBQUcsSUFBSSxDQUFDO3dCQUM5QjtzQkFDRixDQUFDLENBQUM7c0JBQ0ZoQixHQUFHLENBQUNiLElBQUksQ0FBQ1MsQ0FBQyxDQUFDcUIsZUFBZSxDQUFDO3NCQUMzQm5CLElBQUksQ0FBQ1gsSUFBSSxDQUFDYSxHQUFHLENBQUM7b0JBQ2hCLENBQUMsQ0FBQztvQkFDRkgsT0FBTyxDQUFDTixPQUFPLENBQUMsQ0FBQ0ssQ0FBQyxFQUFFdEIsR0FBRyxLQUFLO3NCQUMxQnVCLE9BQU8sQ0FBQ3ZCLEdBQUcsQ0FBQyxHQUFHcEUsT0FBTyxDQUFDNEUsSUFBSSxDQUFDYyxDQUFDLENBQUM7b0JBQ2hDLENBQUMsQ0FBQztvQkFDRkMsT0FBTyxDQUFDVixJQUFJLENBQUMsSUFBSSxDQUFDO29CQUNsQmxGLE1BQU0sQ0FBQ2tGLElBQUksQ0FBQztzQkFDVm9CLEtBQUssRUFBRSx1QkFBdUI7c0JBQzlCQyxJQUFJLEVBQUUsT0FBTztzQkFDYlgsT0FBTztzQkFDUEM7b0JBQ0YsQ0FBQyxDQUFDO2tCQUNKLENBQUMsTUFBTTtvQkFDTDdGLE1BQU0sQ0FBQ2tGLElBQUksQ0FDVCxHQUFHLElBQUksQ0FBQ3lCLGVBQWUsQ0FDckJ4SCxPQUFPLEVBQ1B5RSxNQUFNLENBQUNBLE1BQU0sQ0FBQ1csRUFBRSxDQUFDLEVBQ2pCdEUsT0FBTyxFQUNQb0UsR0FDRixDQUNGLENBQUM7a0JBQ0g7Z0JBQ0Y7Z0JBQ0EsS0FBSyxNQUFNNEMsS0FBSyxJQUFJakgsTUFBTSxFQUFFO2tCQUMxQlUsT0FBTyxDQUFDd0csZUFBZSxDQUFDLENBQUNELEtBQUssQ0FBQyxDQUFDO2dCQUNsQztnQkFDQTVDLEdBQUcsRUFBRTtnQkFDTHJFLE1BQU0sR0FBRyxFQUFFO2NBQ2I7Y0FDQUEsTUFBTSxHQUFHLEVBQUU7WUFDYjtVQUNGLENBQUMsTUFBTTtZQUNMVSxPQUFPLENBQUN1QyxVQUFVLENBQUM7Y0FDakJDLElBQUksRUFBRSx5REFBeUQ7Y0FDL0RDLEtBQUssRUFBRTtnQkFBRVUsUUFBUSxFQUFFLEVBQUU7Z0JBQUVDLEtBQUssRUFBRTtjQUFPLENBQUM7Y0FDdENDLE1BQU0sRUFBRSxDQUFDLENBQUMsRUFBRSxFQUFFLEVBQUUsQ0FBQyxFQUFFLEVBQUU7WUFDdkIsQ0FBQyxDQUFDO1VBQ0o7UUFDRjs7UUFFQTtRQUNBLElBQUl6QixVQUFVLENBQUMsR0FBRyxDQUFDLEVBQUU7VUFDbkIsTUFBTSxJQUFJLENBQUNwQixZQUFZLENBQ3JCL0IsT0FBTyxFQUNQdUIsT0FBTyxFQUNQLGFBQWEsRUFDYjZCLE9BQU8sRUFDUCxFQUFFLEVBQ0ZwQyxLQUNGLENBQUM7UUFDSDtRQUVBLE1BQU1PLE9BQU8sQ0FBQ21CLEtBQUssQ0FBQzFDLE9BQU8sQ0FBQzZCLG1CQUFtQixDQUFDYyxZQUFZLENBQUM7UUFFN0QsT0FBT3pDLFFBQVEsQ0FBQzBDLEVBQUUsQ0FBQztVQUNqQjNCLElBQUksRUFBRTtZQUNKNEIsT0FBTyxFQUFFLElBQUk7WUFDYkMsT0FBTyxFQUFHLFVBQVM5QyxPQUFPLENBQUM2QixtQkFBbUIsQ0FBQ2tCLFFBQVMsY0FBYTtZQUNyRUEsUUFBUSxFQUFFL0MsT0FBTyxDQUFDNkIsbUJBQW1CLENBQUNrQjtVQUN4QztRQUNGLENBQUMsQ0FBQztNQUNKLENBQUMsQ0FBQyxPQUFPQyxLQUFLLEVBQUU7UUFDZGhELE9BQU8sQ0FBQ0csS0FBSyxDQUFDQyxNQUFNLENBQUM0QyxLQUFLLENBQUNBLEtBQUssQ0FBQ0YsT0FBTyxJQUFJRSxLQUFLLENBQUM7UUFDbEQsT0FBTyxJQUFBQyw0QkFBYSxFQUFDRCxLQUFLLENBQUNGLE9BQU8sSUFBSUUsS0FBSyxFQUFFLElBQUksRUFBRSxHQUFHLEVBQUU5QyxRQUFRLENBQUM7TUFDbkU7SUFDRixDQUFDLEVBQ0QsQ0FBQztNQUFFaUIsTUFBTSxFQUFFO1FBQUVpQztNQUFRO0lBQUUsQ0FBQyxLQUNyQiw2QkFBNEJBLE9BQVEsSUFBRyxJQUFJLENBQUNGLHVCQUF1QixDQUFDLENBQUUsTUFDM0UsQ0FBQztJQUVEO0FBQ0Y7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0lBTkVqRSxlQUFBLDJDQVFFLElBQUksQ0FBQ2MsOENBQThDLENBQ2pELE9BQ0VDLE9BQThCLEVBQzlCQyxPQUFvQyxFQUNwQ0MsUUFBNkMsS0FDMUM7TUFDSCxJQUFJO1FBQ0ZGLE9BQU8sQ0FBQ0csS0FBSyxDQUFDQyxNQUFNLENBQUNDLEtBQUssQ0FBQyxnQkFBZ0IsQ0FBQztRQUM1QyxNQUFNO1VBQUU4QyxVQUFVO1VBQUVuQztRQUFNLENBQUMsR0FBR2YsT0FBTyxDQUFDZ0IsSUFBSTtRQUMxQyxNQUFNO1VBQUUrRztRQUFRLENBQUMsR0FBRy9ILE9BQU8sQ0FBQ2tCLE1BQU07UUFFbEMsTUFBTUksT0FBTyxHQUFHLElBQUlDLHNCQUFhLENBQy9CeEIsT0FBTyxDQUFDRyxLQUFLLENBQUNDLE1BQU0sQ0FBQy9CLEdBQUcsQ0FBQyxnQkFBZ0IsQ0FBQyxFQUMxQzJCLE9BQU8sQ0FBQ3lCLFVBQVUsQ0FBQ0MsYUFDckIsQ0FBQztRQUVEMUIsT0FBTyxDQUFDeUIsVUFBVSxDQUFDRSxlQUFlLENBQUNDLDhCQUE4QixDQUM5RCxxQkFBb0I1QixPQUFPLENBQUM2QixtQkFBbUIsQ0FBQ0MsWUFBYSxFQUNoRSxDQUFDO1FBRUQsSUFBSW1HLGdCQUFnQixHQUFHLENBQUMsQ0FBQztRQUN6QixJQUFJcEgsTUFBTSxHQUFHLEVBQUU7UUFDZixJQUFJO1VBQ0ZvSCxnQkFBZ0IsR0FDZCxNQUFNakksT0FBTyxDQUFDRyxLQUFLLENBQUMrRCxHQUFHLENBQUNDLE1BQU0sQ0FBQ0MsYUFBYSxDQUFDbkUsT0FBTyxDQUNsRCxLQUFLLEVBQ0osV0FBVStILE9BQVEsMkJBQTBCLEVBQzdDLENBQUMsQ0FBQyxFQUNGO1lBQUUzRCxTQUFTLEVBQUVyRDtVQUFNLENBQ3JCLENBQUM7UUFDTCxDQUFDLENBQUMsT0FBT2dDLEtBQUssRUFBRTtVQUNkaEQsT0FBTyxDQUFDRyxLQUFLLENBQUNDLE1BQU0sQ0FBQ0MsS0FBSyxDQUFDMkMsS0FBSyxDQUFDRixPQUFPLElBQUlFLEtBQUssQ0FBQztRQUNwRDtRQUVBLE1BQU0sSUFBSSxDQUFDakIsWUFBWSxDQUNyQi9CLE9BQU8sRUFDUHVCLE9BQU8sRUFDUCxhQUFhLEVBQ2IsYUFBYSxFQUNieUcsT0FBTyxFQUNQaEgsS0FDRixDQUFDO1FBRUQsSUFBSWtILFlBQVksR0FBRyxDQUFDO1FBQ3BCLEtBQUssSUFBSXpELE1BQU0sSUFBSWEsc0NBQWtCLENBQUNDLGNBQWMsRUFBRTtVQUNwRCxJQUFJNEMsY0FBYyxHQUFHLEtBQUs7VUFDMUJuSSxPQUFPLENBQUNHLEtBQUssQ0FBQ0MsTUFBTSxDQUFDQyxLQUFLLENBQ3ZCLGdCQUFlb0UsTUFBTSxDQUFDZ0IsUUFBUSxDQUFDbEIsTUFBTyx5QkFDekMsQ0FBQztVQUNELEtBQUssSUFBSXpELE9BQU8sSUFBSTJELE1BQU0sQ0FBQ2dCLFFBQVEsRUFBRTtZQUNuQyxJQUFJMkMsaUJBQWlCLEdBQUcsS0FBSztZQUM3QixJQUNFakYsVUFBVSxDQUFDK0UsWUFBWSxDQUFDLEtBQ3ZCcEgsT0FBTyxDQUFDMkQsTUFBTSxJQUFJM0QsT0FBTyxDQUFDK0UsS0FBSyxDQUFDLEVBQ2pDO2NBQ0EsSUFBSVgsR0FBRyxHQUFHLENBQUM7Y0FDWCxNQUFNbUQsT0FBTyxHQUFHLENBQUN2SCxPQUFPLENBQUMyRCxNQUFNLElBQUksRUFBRSxFQUFFUSxNQUFNLENBQzNDbkUsT0FBTyxDQUFDK0UsS0FBSyxJQUFJLEVBQ25CLENBQUM7Y0FDRDdGLE9BQU8sQ0FBQ0csS0FBSyxDQUFDQyxNQUFNLENBQUNDLEtBQUssQ0FDdkIsZ0JBQWVnSSxPQUFPLENBQUM5RCxNQUFPLHVCQUNqQyxDQUFDO2NBQ0QsS0FBSyxJQUFJK0QsSUFBSSxJQUFJRCxPQUFPLEVBQUU7Z0JBQ3hCLElBQUlFLG1CQUFtQixHQUFHLENBQUMsQ0FBQztnQkFDNUIsSUFBSTtrQkFDRixJQUFJLENBQUNELElBQUksQ0FBQyxNQUFNLENBQUMsRUFBRTtvQkFDakJDLG1CQUFtQixHQUNqQixNQUFNdkksT0FBTyxDQUFDRyxLQUFLLENBQUMrRCxHQUFHLENBQUNDLE1BQU0sQ0FBQ0MsYUFBYSxDQUFDbkUsT0FBTyxDQUNsRCxLQUFLLEVBQ0osV0FBVStILE9BQVEsV0FBVU0sSUFBSSxDQUFDRSxTQUFVLElBQUdGLElBQUksQ0FBQzVHLGFBQWMsRUFBQyxFQUNuRSxDQUFDLENBQUMsRUFDRjtzQkFBRTJDLFNBQVMsRUFBRXJEO29CQUFNLENBQ3JCLENBQUM7a0JBQ0wsQ0FBQyxNQUFNO29CQUNMLEtBQUssSUFBSTZFLEtBQUssSUFBSW9DLGdCQUFnQixDQUFDaEUsSUFBSSxDQUFDQSxJQUFJLENBQzFDLFVBQVUsQ0FDWCxFQUFFO3NCQUNELElBQUl4RixNQUFNLENBQUMrRixJQUFJLENBQUNxQixLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBS3lDLElBQUksQ0FBQyxNQUFNLENBQUMsRUFBRTt3QkFDMUNDLG1CQUFtQixDQUFDdEUsSUFBSSxHQUFHOzBCQUN6QkEsSUFBSSxFQUFFNEI7d0JBQ1IsQ0FBQztzQkFDSDtvQkFDRjtrQkFDRjtrQkFFQSxNQUFNNEMsV0FBVyxHQUNmRixtQkFBbUIsSUFDbkJBLG1CQUFtQixDQUFDdEUsSUFBSSxJQUN4QnNFLG1CQUFtQixDQUFDdEUsSUFBSSxDQUFDQSxJQUFJO2tCQUMvQixJQUFJLENBQUNrRSxjQUFjLEVBQUU7b0JBQ25CNUcsT0FBTyxDQUFDdUMsVUFBVSxDQUFDO3NCQUNqQkMsSUFBSSxFQUFFVSxNQUFNLENBQUMwQyxLQUFLO3NCQUNsQm5ELEtBQUssRUFBRSxJQUFJO3NCQUNYWSxNQUFNLEVBQUUsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLENBQUMsRUFBRSxFQUFFO29CQUN0QixDQUFDLENBQUM7b0JBQ0Z1RCxjQUFjLEdBQUcsSUFBSTtrQkFDdkI7a0JBQ0EsSUFBSSxDQUFDQyxpQkFBaUIsRUFBRTtvQkFDdEI3RyxPQUFPLENBQUN1QyxVQUFVLENBQUM7c0JBQ2pCQyxJQUFJLEVBQUVqRCxPQUFPLENBQUM0SCxRQUFRO3NCQUN0QjFFLEtBQUssRUFBRTtvQkFDVCxDQUFDLENBQUM7b0JBQ0Z6QyxPQUFPLENBQUN1QyxVQUFVLENBQUM7c0JBQ2pCQyxJQUFJLEVBQUVqRCxPQUFPLENBQUM2SCxJQUFJO3NCQUNsQjNFLEtBQUssRUFBRTt3QkFBRVUsUUFBUSxFQUFFLEVBQUU7d0JBQUVDLEtBQUssRUFBRTtzQkFBTyxDQUFDO3NCQUN0Q0MsTUFBTSxFQUFFLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxDQUFDLEVBQUUsRUFBRTtvQkFDdEIsQ0FBQyxDQUFDO29CQUNGd0QsaUJBQWlCLEdBQUcsSUFBSTtrQkFDMUI7a0JBQ0EsSUFBSUssV0FBVyxFQUFFO29CQUNmLEtBQUssSUFBSUcsY0FBYyxJQUFJbkssTUFBTSxDQUFDK0YsSUFBSSxDQUFDaUUsV0FBVyxDQUFDLEVBQUU7c0JBQ25ELElBQUl6QyxLQUFLLENBQUNDLE9BQU8sQ0FBQ3dDLFdBQVcsQ0FBQ0csY0FBYyxDQUFDLENBQUMsRUFBRTt3QkFDOUM7d0JBQ0EsSUFBSU4sSUFBSSxDQUFDTyxRQUFRLEVBQUU7MEJBQ2pCLElBQUkzQyxNQUFNLEdBQUcsRUFBRTswQkFDZnVDLFdBQVcsQ0FBQ0csY0FBYyxDQUFDLENBQUN6QyxPQUFPLENBQUNDLEdBQUcsSUFBSTs0QkFDekMsSUFBSSxDQUFDRixNQUFNLENBQUNFLEdBQUcsQ0FBQ0MsU0FBUyxDQUFDLEVBQUU7OEJBQzFCSCxNQUFNLENBQUNFLEdBQUcsQ0FBQ0MsU0FBUyxDQUFDLEdBQUcsRUFBRTs0QkFDNUI7NEJBQ0FILE1BQU0sQ0FBQ0UsR0FBRyxDQUFDQyxTQUFTLENBQUMsQ0FBQ04sSUFBSSxDQUFDSyxHQUFHLENBQUM7MEJBQ2pDLENBQUMsQ0FBQzswQkFDRjNILE1BQU0sQ0FBQytGLElBQUksQ0FBQzBCLE1BQU0sQ0FBQyxDQUFDQyxPQUFPLENBQUNHLEtBQUssSUFBSTs0QkFDbkMsSUFBSUMsT0FBTyxHQUFHLENBQUM7NEJBQ2ZMLE1BQU0sQ0FBQ0ksS0FBSyxDQUFDLENBQUNILE9BQU8sQ0FBQyxDQUFDSyxDQUFDLEVBQUV6SCxDQUFDLEtBQUs7OEJBQzlCLElBQ0VOLE1BQU0sQ0FBQytGLElBQUksQ0FBQ2dDLENBQUMsQ0FBQyxDQUFDakMsTUFBTSxHQUNyQjlGLE1BQU0sQ0FBQytGLElBQUksQ0FBQzBCLE1BQU0sQ0FBQ0ksS0FBSyxDQUFDLENBQUNDLE9BQU8sQ0FBQyxDQUFDLENBQUNoQyxNQUFNLEVBQzFDO2dDQUNBZ0MsT0FBTyxHQUFHeEgsQ0FBQzs4QkFDYjs0QkFDRixDQUFDLENBQUM7NEJBQ0YsTUFBTTBILE9BQU8sR0FBR2hJLE1BQU0sQ0FBQytGLElBQUksQ0FDekIwQixNQUFNLENBQUNJLEtBQUssQ0FBQyxDQUFDQyxPQUFPLENBQ3ZCLENBQUM7NEJBQ0QsTUFBTUcsSUFBSSxHQUFHUixNQUFNLENBQUNJLEtBQUssQ0FBQyxDQUFDSyxHQUFHLENBQUNILENBQUMsSUFBSTs4QkFDbEMsSUFBSUksR0FBRyxHQUFHLEVBQUU7OEJBQ1pILE9BQU8sQ0FBQ04sT0FBTyxDQUFDVSxHQUFHLElBQUk7Z0NBQ3JCRCxHQUFHLENBQUNiLElBQUksQ0FDTixPQUFPUyxDQUFDLENBQUNLLEdBQUcsQ0FBQyxLQUFLLFFBQVEsR0FDdEJMLENBQUMsQ0FBQ0ssR0FBRyxDQUFDLEdBQ05iLEtBQUssQ0FBQ0MsT0FBTyxDQUFDTyxDQUFDLENBQUNLLEdBQUcsQ0FBQyxDQUFDLEdBQ3JCTCxDQUFDLENBQUNLLEdBQUcsQ0FBQyxDQUFDRixHQUFHLENBQUNILENBQUMsSUFBSTtrQ0FDZCxPQUFPQSxDQUFDLEdBQUcsSUFBSTtnQ0FDakIsQ0FBQyxDQUFDLEdBQ0ZNLElBQUksQ0FBQ0MsU0FBUyxDQUFDUCxDQUFDLENBQUNLLEdBQUcsQ0FBQyxDQUMzQixDQUFDOzhCQUNILENBQUMsQ0FBQzs4QkFDRixPQUFPRCxHQUFHOzRCQUNaLENBQUMsQ0FBQzs0QkFDRkgsT0FBTyxDQUFDTixPQUFPLENBQUMsQ0FBQ2EsR0FBRyxFQUFFakksQ0FBQyxLQUFLOzhCQUMxQjBILE9BQU8sQ0FBQzFILENBQUMsQ0FBQyxHQUNSaUksR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDQyxXQUFXLENBQUMsQ0FBQyxHQUFHRCxHQUFHLENBQUNFLEtBQUssQ0FBQyxDQUFDLENBQUM7NEJBQ3ZDLENBQUMsQ0FBQzs0QkFDRnJHLE1BQU0sQ0FBQ2tGLElBQUksQ0FBQzs4QkFDVm9CLEtBQUssRUFBRXJHLE9BQU8sQ0FBQzhDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQzBDLEtBQUssQ0FBQzs4QkFDL0JjLElBQUksRUFBRSxPQUFPOzhCQUNiWCxPQUFPOzhCQUNQQzs0QkFDRixDQUFDLENBQUM7MEJBQ0osQ0FBQyxDQUFDO3dCQUNKLENBQUMsTUFBTSxJQUNMa0MsY0FBYyxDQUFDbEgsYUFBYSxLQUFLLFFBQVEsRUFDekM7MEJBQ0FiLE1BQU0sQ0FBQ2tGLElBQUksQ0FDVCxHQUFHLElBQUksQ0FBQ3lCLGVBQWUsQ0FDckJ4SCxPQUFPLEVBQ1B5SSxXQUFXLENBQUNHLGNBQWMsQ0FBQyxFQUMzQjlILE9BQU8sRUFDUG9FLEdBQ0YsQ0FDRixDQUFDO3dCQUNILENBQUMsTUFBTTswQkFDTCxLQUFLLElBQUlxQyxHQUFHLElBQUlrQixXQUFXLENBQUNHLGNBQWMsQ0FBQyxFQUFFOzRCQUMzQy9ILE1BQU0sQ0FBQ2tGLElBQUksQ0FDVCxHQUFHLElBQUksQ0FBQ3lCLGVBQWUsQ0FDckJ4SCxPQUFPLEVBQ1B1SCxHQUFHLEVBQ0h6RyxPQUFPLEVBQ1BvRSxHQUNGLENBQ0YsQ0FBQzswQkFDSDt3QkFDRjtzQkFDRixDQUFDLE1BQU07d0JBQ0w7d0JBQ0EsSUFBSW9ELElBQUksQ0FBQ1EsTUFBTSxFQUFFOzBCQUNmLE1BQU07NEJBQ0pyQixXQUFXOzRCQUNYc0IsSUFBSTs0QkFDSkMsZUFBZTs0QkFDZkMsVUFBVTs0QkFDVixHQUFHQzswQkFDTCxDQUFDLEdBQUdULFdBQVcsQ0FBQ0csY0FBYyxDQUFDOzBCQUMvQi9ILE1BQU0sQ0FBQ2tGLElBQUksQ0FDVCxHQUFHLElBQUksQ0FBQ3lCLGVBQWUsQ0FDckJ4SCxPQUFPLEVBQ1BrSixJQUFJLEVBQ0pwSSxPQUFPLEVBQ1BvRSxHQUNGLENBQUMsRUFDRCxJQUFJNkQsSUFBSSxJQUFJQSxJQUFJLENBQUNJLFVBQVUsR0FDdkIsSUFBSSxDQUFDM0IsZUFBZSxDQUNsQnhILE9BQU8sRUFDUCtJLElBQUksQ0FBQ0ksVUFBVSxFQUNmOzRCQUFFaEUsSUFBSSxFQUFFLENBQUMsWUFBWTswQkFBRSxDQUFDLEVBQ3hCLENBQ0YsQ0FBQyxHQUNELEVBQUUsQ0FBQyxFQUNQLElBQUk0RCxJQUFJLElBQUlBLElBQUksQ0FBQ0ssU0FBUyxHQUN0QixJQUFJLENBQUM1QixlQUFlLENBQ2xCeEgsT0FBTyxFQUNQK0ksSUFBSSxDQUFDSyxTQUFTLEVBQ2Q7NEJBQUVqRSxJQUFJLEVBQUUsQ0FBQyxXQUFXOzBCQUFFLENBQUMsRUFDdkIsQ0FDRixDQUFDLEdBQ0QsRUFBRSxDQUFDLEVBQ1AsSUFBSTZELGVBQWUsR0FDZixJQUFJLENBQUN4QixlQUFlLENBQ2xCeEgsT0FBTyxFQUNQZ0osZUFBZSxFQUNmOzRCQUFFN0QsSUFBSSxFQUFFLENBQUMsaUJBQWlCOzBCQUFFLENBQUMsRUFDN0IsQ0FDRixDQUFDLEdBQ0QsRUFBRSxDQUFDLEVBQ1AsSUFBSThELFVBQVUsR0FDVixJQUFJLENBQUN6QixlQUFlLENBQ2xCeEgsT0FBTyxFQUNQaUosVUFBVSxFQUNWOzRCQUFFOUQsSUFBSSxFQUFFLENBQUMsWUFBWTswQkFBRSxDQUFDLEVBQ3hCLENBQ0YsQ0FBQyxHQUNELEVBQUUsQ0FDUixDQUFDOzBCQUNELElBQUl1QyxRQUFRLEdBQUcsRUFBRTswQkFDakJqSixNQUFNLENBQUMrRixJQUFJLENBQUMxRCxPQUFPLENBQUM0RSxJQUFJLENBQUMsQ0FBQ1MsT0FBTyxDQUFDSyxDQUFDLElBQUk7NEJBQ3JDa0IsUUFBUSxDQUFDM0IsSUFBSSxDQUFDUyxDQUFDLENBQUM7MEJBQ2xCLENBQUMsQ0FBQzswQkFDRixNQUFNQyxPQUFPLEdBQUcsQ0FDZCxFQUFFLEVBQ0YsR0FBR2lCLFFBQVEsQ0FBQzFDLE1BQU0sQ0FDaEJ3QixDQUFDLElBQUlBLENBQUMsS0FBSyxXQUFXLElBQUlBLENBQUMsS0FBSyxXQUNsQyxDQUFDLENBQ0Y7MEJBQ0QsSUFBSUUsSUFBSSxHQUFHLEVBQUU7MEJBQ2JlLFdBQVcsQ0FBQ3RCLE9BQU8sQ0FBQ0ssQ0FBQyxJQUFJOzRCQUN2QixJQUFJSSxHQUFHLEdBQUcsRUFBRTs0QkFDWkEsR0FBRyxDQUFDYixJQUFJLENBQUNTLENBQUMsQ0FBQzZDLEdBQUcsQ0FBQzs0QkFDZjVDLE9BQU8sQ0FBQ04sT0FBTyxDQUFDeUIsQ0FBQyxJQUFJOzhCQUNuQixJQUFJQSxDQUFDLEtBQUssRUFBRSxFQUFFO2dDQUNaaEIsR0FBRyxDQUFDYixJQUFJLENBQ05TLENBQUMsQ0FBQ2QsSUFBSSxDQUFDNEQsT0FBTyxDQUFDMUIsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLEdBQUcsS0FBSyxHQUFHLElBQ25DLENBQUM7OEJBQ0g7NEJBQ0YsQ0FBQyxDQUFDOzRCQUNGaEIsR0FBRyxDQUFDYixJQUFJLENBQUNTLENBQUMsQ0FBQ3FCLGVBQWUsQ0FBQzs0QkFDM0JuQixJQUFJLENBQUNYLElBQUksQ0FBQ2EsR0FBRyxDQUFDOzBCQUNoQixDQUFDLENBQUM7MEJBQ0ZILE9BQU8sQ0FBQ04sT0FBTyxDQUFDLENBQUNLLENBQUMsRUFBRXRCLEdBQUcsS0FBSzs0QkFDMUJ1QixPQUFPLENBQUN2QixHQUFHLENBQUMsR0FBR3BFLE9BQU8sQ0FBQzRFLElBQUksQ0FBQ2MsQ0FBQyxDQUFDOzBCQUNoQyxDQUFDLENBQUM7MEJBQ0ZDLE9BQU8sQ0FBQ1YsSUFBSSxDQUFDLElBQUksQ0FBQzswQkFDbEJsRixNQUFNLENBQUNrRixJQUFJLENBQUM7NEJBQ1ZvQixLQUFLLEVBQUUsdUJBQXVCOzRCQUM5QkMsSUFBSSxFQUFFLE9BQU87NEJBQ2JYLE9BQU87NEJBQ1BDOzBCQUNGLENBQUMsQ0FBQzt3QkFDSixDQUFDLE1BQU07MEJBQ0w3RixNQUFNLENBQUNrRixJQUFJLENBQ1QsR0FBRyxJQUFJLENBQUN5QixlQUFlLENBQ3JCeEgsT0FBTyxFQUNQeUksV0FBVyxDQUFDRyxjQUFjLENBQUMsRUFDM0I5SCxPQUFPLEVBQ1BvRSxHQUNGLENBQ0YsQ0FBQzt3QkFDSDtzQkFDRjtvQkFDRjtrQkFDRixDQUFDLE1BQU07b0JBQ0w7b0JBQ0EzRCxPQUFPLENBQUN1QyxVQUFVLENBQUM7c0JBQ2pCQyxJQUFJLEVBQUUsQ0FDSiw4RUFBOEUsRUFDOUU7d0JBQ0VBLElBQUksRUFBRyxHQUFFakQsT0FBTyxDQUFDNEgsUUFBUSxDQUFDYSxXQUFXLENBQUMsQ0FBRSxpQkFBZ0I7d0JBQ3hEQyxJQUFJLEVBQUUxSSxPQUFPLENBQUMySSxRQUFRO3dCQUN0QnpGLEtBQUssRUFBRTswQkFBRVUsUUFBUSxFQUFFLEVBQUU7MEJBQUVDLEtBQUssRUFBRTt3QkFBVTtzQkFDMUMsQ0FBQyxDQUNGO3NCQUNEQyxNQUFNLEVBQUUsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLENBQUMsRUFBRSxFQUFFO29CQUN0QixDQUFDLENBQUM7a0JBQ0o7Z0JBQ0YsQ0FBQyxDQUFDLE9BQU81QixLQUFLLEVBQUU7a0JBQ2RoRCxPQUFPLENBQUNHLEtBQUssQ0FBQ0MsTUFBTSxDQUFDQyxLQUFLLENBQUMyQyxLQUFLLENBQUNGLE9BQU8sSUFBSUUsS0FBSyxDQUFDO2dCQUNwRDtnQkFDQWtDLEdBQUcsRUFBRTtjQUNQO2NBQ0EsS0FBSyxNQUFNNEMsS0FBSyxJQUFJakgsTUFBTSxFQUFFO2dCQUMxQlUsT0FBTyxDQUFDd0csZUFBZSxDQUFDLENBQUNELEtBQUssQ0FBQyxDQUFDO2NBQ2xDO1lBQ0Y7WUFDQUksWUFBWSxFQUFFO1lBQ2RySCxNQUFNLEdBQUcsRUFBRTtVQUNiO1FBQ0Y7UUFFQSxNQUFNVSxPQUFPLENBQUNtQixLQUFLLENBQUMxQyxPQUFPLENBQUM2QixtQkFBbUIsQ0FBQ2MsWUFBWSxDQUFDO1FBRTdELE9BQU96QyxRQUFRLENBQUMwQyxFQUFFLENBQUM7VUFDakIzQixJQUFJLEVBQUU7WUFDSjRCLE9BQU8sRUFBRSxJQUFJO1lBQ2JDLE9BQU8sRUFBRyxVQUFTOUMsT0FBTyxDQUFDNkIsbUJBQW1CLENBQUNrQixRQUFTLGNBQWE7WUFDckVBLFFBQVEsRUFBRS9DLE9BQU8sQ0FBQzZCLG1CQUFtQixDQUFDa0I7VUFDeEM7UUFDRixDQUFDLENBQUM7TUFDSixDQUFDLENBQUMsT0FBT0MsS0FBSyxFQUFFO1FBQ2RoRCxPQUFPLENBQUNHLEtBQUssQ0FBQ0MsTUFBTSxDQUFDQyxLQUFLLENBQUMyQyxLQUFLLENBQUNGLE9BQU8sSUFBSUUsS0FBSyxDQUFDO1FBQ2xELE9BQU8sSUFBQUMsNEJBQWEsRUFBQ0QsS0FBSyxDQUFDRixPQUFPLElBQUlFLEtBQUssRUFBRSxJQUFJLEVBQUUsR0FBRyxFQUFFOUMsUUFBUSxDQUFDO01BQ25FO0lBQ0YsQ0FBQyxFQUNELENBQUM7TUFBRWlCLE1BQU0sRUFBRTtRQUFFNkc7TUFBUTtJQUFFLENBQUMsS0FDckIsNkJBQTRCQSxPQUFRLElBQUcsSUFBSSxDQUFDOUUsdUJBQXVCLENBQUMsQ0FBRSxNQUMzRSxDQUFDO0lBMERIO0FBQ0Y7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0lBTkVqRSxlQUFBLDBCQU9rQixJQUFJLENBQUNjLDhDQUE4QyxDQUNuRSxPQUNFQyxPQUE4QixFQUM5QkMsT0FBb0MsRUFDcENDLFFBQTZDLEtBQzFDO01BQ0gsSUFBSTtRQUNGRixPQUFPLENBQUNHLEtBQUssQ0FBQ0MsTUFBTSxDQUFDQyxLQUFLLENBQ3ZCLFdBQVVMLE9BQU8sQ0FBQzZCLG1CQUFtQixDQUFDYyxZQUFhLFNBQ3RELENBQUM7UUFDRCxNQUFNK0csZ0JBQWdCLEdBQUdDLFdBQUUsQ0FBQ0MsWUFBWSxDQUN0QzVKLE9BQU8sQ0FBQzZCLG1CQUFtQixDQUFDYyxZQUM5QixDQUFDO1FBQ0QsT0FBT3pDLFFBQVEsQ0FBQzBDLEVBQUUsQ0FBQztVQUNqQmlILE9BQU8sRUFBRTtZQUFFLGNBQWMsRUFBRTtVQUFrQixDQUFDO1VBQzlDNUksSUFBSSxFQUFFeUk7UUFDUixDQUFDLENBQUM7TUFDSixDQUFDLENBQUMsT0FBTzFHLEtBQUssRUFBRTtRQUNkaEQsT0FBTyxDQUFDRyxLQUFLLENBQUNDLE1BQU0sQ0FBQzRDLEtBQUssQ0FBQ0EsS0FBSyxDQUFDRixPQUFPLElBQUlFLEtBQUssQ0FBQztRQUNsRCxPQUFPLElBQUFDLDRCQUFhLEVBQUNELEtBQUssQ0FBQ0YsT0FBTyxJQUFJRSxLQUFLLEVBQUUsSUFBSSxFQUFFLEdBQUcsRUFBRTlDLFFBQVEsQ0FBQztNQUNuRTtJQUNGLENBQUMsRUFDREQsT0FBTyxJQUFJQSxPQUFPLENBQUNrQixNQUFNLENBQUMyRSxJQUM1QixDQUFDO0lBRUQ7QUFDRjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7SUFORTdHLGVBQUEsNkJBT3FCLElBQUksQ0FBQ2MsOENBQThDLENBQ3RFLE9BQ0VDLE9BQThCLEVBQzlCQyxPQUFvQyxFQUNwQ0MsUUFBNkMsS0FDMUM7TUFDSCxJQUFJO1FBQ0ZGLE9BQU8sQ0FBQ0csS0FBSyxDQUFDQyxNQUFNLENBQUNDLEtBQUssQ0FDdkIsWUFBV0wsT0FBTyxDQUFDNkIsbUJBQW1CLENBQUNjLFlBQWEsU0FDdkQsQ0FBQztRQUNEZ0gsV0FBRSxDQUFDRyxVQUFVLENBQUM5SixPQUFPLENBQUM2QixtQkFBbUIsQ0FBQ2MsWUFBWSxDQUFDO1FBQ3ZEM0MsT0FBTyxDQUFDRyxLQUFLLENBQUNDLE1BQU0sQ0FBQzJKLElBQUksQ0FDdEIsR0FBRS9KLE9BQU8sQ0FBQzZCLG1CQUFtQixDQUFDYyxZQUFhLHFCQUM5QyxDQUFDO1FBQ0QsT0FBT3pDLFFBQVEsQ0FBQzBDLEVBQUUsQ0FBQztVQUNqQjNCLElBQUksRUFBRTtZQUFFK0IsS0FBSyxFQUFFO1VBQUU7UUFDbkIsQ0FBQyxDQUFDO01BQ0osQ0FBQyxDQUFDLE9BQU9BLEtBQUssRUFBRTtRQUNkaEQsT0FBTyxDQUFDRyxLQUFLLENBQUNDLE1BQU0sQ0FBQzRDLEtBQUssQ0FBQ0EsS0FBSyxDQUFDRixPQUFPLElBQUlFLEtBQUssQ0FBQztRQUNsRCxPQUFPLElBQUFDLDRCQUFhLEVBQUNELEtBQUssQ0FBQ0YsT0FBTyxJQUFJRSxLQUFLLEVBQUUsSUFBSSxFQUFFLEdBQUcsRUFBRTlDLFFBQVEsQ0FBQztNQUNuRTtJQUNGLENBQUMsRUFDREQsT0FBTyxJQUFJQSxPQUFPLENBQUNrQixNQUFNLENBQUMyRSxJQUM1QixDQUFDO0VBL2pDYztFQUNmO0FBQ0Y7QUFDQTtBQUNBO0FBQ0E7RUFDVTVELHFCQUFxQkEsQ0FDM0JsQyxPQUFZLEVBQ1pVLE9BQVksRUFDWkQsU0FBa0IsRUFDTTtJQUN4QlQsT0FBTyxDQUFDRyxLQUFLLENBQUNDLE1BQU0sQ0FBQ0MsS0FBSyxDQUN2Qix5Q0FBd0NLLE9BQU8sQ0FBQzZELE1BQU8sZ0JBQWU5RCxTQUFVLEVBQ25GLENBQUM7SUFDRCxJQUFJdUosR0FBRyxHQUFHLEVBQUU7SUFFWixNQUFNL0gsWUFBMEIsR0FBRztNQUFFZ0ksS0FBSyxFQUFFLENBQUMsQ0FBQztNQUFFQyxVQUFVLEVBQUU7SUFBRyxDQUFDO0lBQ2hFLE1BQU1DLFVBQW9CLEdBQUcsRUFBRTs7SUFFL0I7SUFDQXpKLE9BQU8sR0FBR0EsT0FBTyxDQUFDc0UsTUFBTSxDQUFDQSxNQUFNLElBQUk7TUFDakMsSUFBSUEsTUFBTSxDQUFDb0YsSUFBSSxDQUFDQyxZQUFZLEtBQUtDLDRCQUFpQixFQUFFO1FBQ2xEckksWUFBWSxDQUFDZ0ksS0FBSyxHQUFHakYsTUFBTSxDQUFDaUYsS0FBSztRQUNqQ0UsVUFBVSxDQUFDcEUsSUFBSSxDQUFDZixNQUFNLENBQUM7UUFDdkIsT0FBTyxLQUFLO01BQ2Q7TUFDQSxPQUFPQSxNQUFNO0lBQ2YsQ0FBQyxDQUFDO0lBRUYsTUFBTXVGLEdBQUcsR0FBRzdKLE9BQU8sQ0FBQzZELE1BQU07SUFFMUIsS0FBSyxJQUFJeEYsQ0FBQyxHQUFHLENBQUMsRUFBRUEsQ0FBQyxHQUFHd0wsR0FBRyxFQUFFeEwsQ0FBQyxFQUFFLEVBQUU7TUFDNUIsTUFBTTtRQUFFeUwsTUFBTTtRQUFFM0QsR0FBRztRQUFFMUgsS0FBSztRQUFFZ0MsTUFBTTtRQUFFaUc7TUFBSyxDQUFDLEdBQUcxRyxPQUFPLENBQUMzQixDQUFDLENBQUMsQ0FBQ3FMLElBQUk7TUFDNURKLEdBQUcsSUFBSyxHQUFFUSxNQUFNLEdBQUcsTUFBTSxHQUFHLEVBQUcsRUFBQztNQUNoQ1IsR0FBRyxJQUFLLEdBQUVuRCxHQUFJLElBQUc7TUFDakJtRCxHQUFHLElBQUssR0FDTjVDLElBQUksS0FBSyxPQUFPLEdBQ1gsR0FBRWpHLE1BQU0sQ0FBQ3NKLEdBQUksSUFBR3RKLE1BQU0sQ0FBQ3VKLEVBQUcsRUFBQyxHQUM1QnRELElBQUksS0FBSyxTQUFTLEdBQ2xCLEdBQUcsR0FBR2pHLE1BQU0sQ0FBQ3dKLElBQUksQ0FBQyxNQUFNLENBQUMsR0FBRyxHQUFHLEdBQy9CdkQsSUFBSSxLQUFLLFFBQVEsR0FDakIsR0FBRyxHQUNILENBQUMsQ0FBQ2pJLEtBQUssR0FDUEEsS0FBSyxHQUNMLENBQUNnQyxNQUFNLElBQUksQ0FBQyxDQUFDLEVBQUU4SSxLQUNwQixFQUFDO01BQ0ZELEdBQUcsSUFBSyxHQUFFakwsQ0FBQyxLQUFLd0wsR0FBRyxHQUFHLENBQUMsR0FBRyxFQUFFLEdBQUcsT0FBUSxFQUFDO0lBQzFDO0lBRUEsSUFBSTlKLFNBQVMsRUFBRTtNQUNidUosR0FBRyxJQUFLLFNBQVF2SixTQUFVLEdBQUU7SUFDOUI7SUFFQXdCLFlBQVksQ0FBQ2lJLFVBQVUsR0FBR0MsVUFBVSxDQUNqQ3hELEdBQUcsQ0FBQzNCLE1BQU0sSUFBSUEsTUFBTSxDQUFDb0YsSUFBSSxDQUFDakwsS0FBSyxDQUFDLENBQ2hDd0wsSUFBSSxDQUFDLEdBQUcsQ0FBQztJQUVaM0ssT0FBTyxDQUFDRyxLQUFLLENBQUNDLE1BQU0sQ0FBQ0MsS0FBSyxDQUN2QixRQUFPMkosR0FBSSxzQkFBcUIvSCxZQUFZLENBQUNpSSxVQUFXLEVBQzNELENBQUM7SUFFRCxPQUFPLENBQUNGLEdBQUcsRUFBRS9ILFlBQVksQ0FBQztFQUM1Qjs7RUFFQTtBQUNGO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0VBQ0UsTUFBY0YsWUFBWUEsQ0FBQy9CLE9BQU8sRUFBRXVCLE9BQU8sRUFBRVQsT0FBTyxFQUFFOEosR0FBRyxFQUFFQyxRQUFRLEVBQUU3SixLQUFLLEVBQUU7SUFDMUUsSUFBSTtNQUNGaEIsT0FBTyxDQUFDRyxLQUFLLENBQUNDLE1BQU0sQ0FBQ0MsS0FBSyxDQUN2QixZQUFXUyxPQUFRLFVBQVM4SixHQUFJLGVBQWNDLFFBQVMsWUFBVzdKLEtBQU0sRUFDM0UsQ0FBQztNQUNELElBQUlGLE9BQU8sSUFBSSxPQUFPQSxPQUFPLEtBQUssUUFBUSxFQUFFO1FBQzFDLElBQUksQ0FBQyxDQUFDLGFBQWEsRUFBRSxhQUFhLENBQUMsQ0FBQ3dHLFFBQVEsQ0FBQ3hHLE9BQU8sQ0FBQyxFQUFFO1VBQ3JEUyxPQUFPLENBQUN1QyxVQUFVLENBQUM7WUFDakJDLElBQUksRUFBRStHLDJCQUFhLENBQUNGLEdBQUcsQ0FBQyxDQUFDekQsS0FBSyxHQUFHLFNBQVM7WUFDMUNuRCxLQUFLLEVBQUU7VUFDVCxDQUFDLENBQUM7UUFDSixDQUFDLE1BQU0sSUFBSWxELE9BQU8sS0FBSyxhQUFhLEVBQUU7VUFDcENTLE9BQU8sQ0FBQ3VDLFVBQVUsQ0FBQztZQUNqQkMsSUFBSSxFQUFHLFNBQVE4RyxRQUFTLGdCQUFlO1lBQ3ZDN0csS0FBSyxFQUFFO1VBQ1QsQ0FBQyxDQUFDO1FBQ0osQ0FBQyxNQUFNLElBQUlsRCxPQUFPLEtBQUssYUFBYSxFQUFFO1VBQ3BDUyxPQUFPLENBQUN1QyxVQUFVLENBQUM7WUFDakJDLElBQUksRUFBRSxpQkFBaUI7WUFDdkJDLEtBQUssRUFBRTtVQUNULENBQUMsQ0FBQztRQUNKO1FBQ0F6QyxPQUFPLENBQUN3SixVQUFVLENBQUMsQ0FBQztNQUN0QjtNQUVBLElBQUlGLFFBQVEsSUFBSSxPQUFPQSxRQUFRLEtBQUssUUFBUSxFQUFFO1FBQzVDLE1BQU0sSUFBQUcscUNBQWdCLEVBQ3BCaEwsT0FBTyxFQUNQdUIsT0FBTyxFQUNQc0osUUFBUSxFQUNSN0osS0FBSyxFQUNMRixPQUFPLEtBQUssYUFBYSxHQUFHOEosR0FBRyxHQUFHLEVBQ3BDLENBQUM7TUFDSDtNQUVBLElBQUlDLFFBQVEsSUFBSSxPQUFPQSxRQUFRLEtBQUssUUFBUSxFQUFFO1FBQzVDLE1BQU1JLGFBQWEsR0FDakIsTUFBTWpMLE9BQU8sQ0FBQ0csS0FBSyxDQUFDK0QsR0FBRyxDQUFDQyxNQUFNLENBQUNDLGFBQWEsQ0FBQ25FLE9BQU8sQ0FDbEQsS0FBSyxFQUNKLFNBQVEsRUFDVDtVQUFFa0IsTUFBTSxFQUFFO1lBQUUrSixXQUFXLEVBQUVMO1VBQVM7UUFBRSxDQUFDLEVBQ3JDO1VBQUV4RyxTQUFTLEVBQUVyRDtRQUFNLENBQ3JCLENBQUM7UUFDSCxNQUFNbUssU0FBUyxHQUFHRixhQUFhLENBQUNoSCxJQUFJLENBQUNBLElBQUksQ0FBQ0ssY0FBYyxDQUFDLENBQUMsQ0FBQztRQUMzRCxJQUFJNkcsU0FBUyxJQUFJQSxTQUFTLENBQUNDLE1BQU0sS0FBS0MsZ0NBQXFCLENBQUNDLE1BQU0sRUFBRTtVQUNsRS9KLE9BQU8sQ0FBQ2dLLHFCQUFxQixDQUFDO1lBQzVCeEgsSUFBSSxFQUFHLHFCQUFvQixJQUFBeUgsOENBQTZCLEVBQ3RETCxTQUFTLENBQUNDLE1BQ1osQ0FBQyxDQUFDN0IsV0FBVyxDQUFDLENBQUUsRUFBQztZQUNqQnZGLEtBQUssRUFBRTtVQUNULENBQUMsQ0FBQztRQUNKO1FBQ0EsTUFBTSxJQUFBZ0gscUNBQWdCLEVBQUNoTCxPQUFPLEVBQUV1QixPQUFPLEVBQUUsQ0FBQ3NKLFFBQVEsQ0FBQyxFQUFFN0osS0FBSyxDQUFDO1FBRTNELElBQUltSyxTQUFTLElBQUlBLFNBQVMsQ0FBQzdFLEtBQUssRUFBRTtVQUNoQyxNQUFNbUYsV0FBVyxHQUFHTixTQUFTLENBQUM3RSxLQUFLLENBQUNxRSxJQUFJLENBQUMsSUFBSSxDQUFDO1VBQzlDcEosT0FBTyxDQUFDZ0sscUJBQXFCLENBQUM7WUFDNUJ4SCxJQUFJLEVBQUcsUUFDTG9ILFNBQVMsQ0FBQzdFLEtBQUssQ0FBQy9CLE1BQU0sR0FBRyxDQUFDLEdBQUcsR0FBRyxHQUFHLEVBQ3BDLEtBQUlrSCxXQUFZLEVBQUM7WUFDbEJ6SCxLQUFLLEVBQUU7VUFDVCxDQUFDLENBQUM7UUFDSjtNQUNGO01BQ0EsSUFBSThHLDJCQUFhLENBQUNGLEdBQUcsQ0FBQyxJQUFJRSwyQkFBYSxDQUFDRixHQUFHLENBQUMsQ0FBQ2MsV0FBVyxFQUFFO1FBQ3hEbkssT0FBTyxDQUFDZ0sscUJBQXFCLENBQUM7VUFDNUJ4SCxJQUFJLEVBQUUrRywyQkFBYSxDQUFDRixHQUFHLENBQUMsQ0FBQ2MsV0FBVztVQUNwQzFILEtBQUssRUFBRTtRQUNULENBQUMsQ0FBQztNQUNKO0lBQ0YsQ0FBQyxDQUFDLE9BQU9oQixLQUFLLEVBQUU7TUFDZGhELE9BQU8sQ0FBQ0csS0FBSyxDQUFDQyxNQUFNLENBQUM0QyxLQUFLLENBQUNBLEtBQUssQ0FBQ0YsT0FBTyxJQUFJRSxLQUFLLENBQUM7TUFDbEQsT0FBTzJJLE9BQU8sQ0FBQ0MsTUFBTSxDQUFDNUksS0FBSyxDQUFDO0lBQzlCO0VBQ0Y7RUFFUTZJLGFBQWFBLENBQUM3TCxPQUFPLEVBQUVpRSxJQUFJLEVBQUVMLE1BQU0sRUFBRTtJQUMzQzVELE9BQU8sQ0FBQ0csS0FBSyxDQUFDQyxNQUFNLENBQUNDLEtBQUssQ0FBQyw2QkFBNkIsQ0FBQztJQUN6RCxNQUFNeUwsTUFBTSxHQUFHLEVBQUU7SUFDakIsS0FBSyxJQUFJQyxJQUFJLElBQUk5SCxJQUFJLElBQUksRUFBRSxFQUFFO01BQzNCLElBQUkrQixLQUFLLENBQUNDLE9BQU8sQ0FBQ2hDLElBQUksQ0FBQzhILElBQUksQ0FBQyxDQUFDLEVBQUU7UUFDN0I5SCxJQUFJLENBQUM4SCxJQUFJLENBQUMsQ0FBQzVGLE9BQU8sQ0FBQyxDQUFDSyxDQUFDLEVBQUV0QixHQUFHLEtBQUs7VUFDN0IsSUFBSSxPQUFPc0IsQ0FBQyxLQUFLLFFBQVEsRUFBRXZDLElBQUksQ0FBQzhILElBQUksQ0FBQyxDQUFDN0csR0FBRyxDQUFDLEdBQUc0QixJQUFJLENBQUNDLFNBQVMsQ0FBQ1AsQ0FBQyxDQUFDO1FBQ2hFLENBQUMsQ0FBQztNQUNKO01BQ0FzRixNQUFNLENBQUMvRixJQUFJLENBQUMsQ0FDVixDQUFDbkMsTUFBTSxJQUFJLENBQUMsQ0FBQyxFQUFFbUksSUFBSSxDQUFDLElBQUlDLGlDQUFjLENBQUNELElBQUksQ0FBQyxJQUFJQSxJQUFJLEVBQ3BEOUgsSUFBSSxDQUFDOEgsSUFBSSxDQUFDLElBQUksR0FBRyxDQUNsQixDQUFDO0lBQ0o7SUFDQSxPQUFPRCxNQUFNO0VBQ2Y7RUFFUXRFLGVBQWVBLENBQUN4SCxPQUFPLEVBQUVpRSxJQUFJLEVBQUVuRCxPQUFPLEVBQUU4SixHQUFHLEVBQUV0SyxLQUFLLEdBQUcsRUFBRSxFQUFFO0lBQy9ETixPQUFPLENBQUNHLEtBQUssQ0FBQ0MsTUFBTSxDQUFDQyxLQUFLLENBQUMsK0JBQStCLENBQUM7SUFDM0QsSUFBSTRMLFNBQVMsR0FBRyxDQUFDLENBQUM7SUFDbEIsTUFBTUMsVUFBVSxHQUFHLEVBQUU7SUFDckIsTUFBTUMsU0FBUyxHQUFHLEVBQUU7SUFFcEIsSUFBSWxJLElBQUksQ0FBQ00sTUFBTSxLQUFLLENBQUMsSUFBSXlCLEtBQUssQ0FBQ0MsT0FBTyxDQUFDaEMsSUFBSSxDQUFDLEVBQUU7TUFDNUNrSSxTQUFTLENBQUNyTCxPQUFPLENBQUMyRCxNQUFNLENBQUNtRyxHQUFHLENBQUMsQ0FBQ2xKLGFBQWEsQ0FBQyxHQUFHdUMsSUFBSTtJQUNyRCxDQUFDLE1BQU07TUFDTCxLQUFLLElBQUk0QyxHQUFHLElBQUk1QyxJQUFJLEVBQUU7UUFDcEIsSUFDRyxPQUFPQSxJQUFJLENBQUM0QyxHQUFHLENBQUMsS0FBSyxRQUFRLElBQUksQ0FBQ2IsS0FBSyxDQUFDQyxPQUFPLENBQUNoQyxJQUFJLENBQUM0QyxHQUFHLENBQUMsQ0FBQyxJQUMxRGIsS0FBSyxDQUFDQyxPQUFPLENBQUNoQyxJQUFJLENBQUM0QyxHQUFHLENBQUMsQ0FBQyxJQUFJLE9BQU81QyxJQUFJLENBQUM0QyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxRQUFTLEVBQzlEO1VBQ0FvRixTQUFTLENBQUNwRixHQUFHLENBQUMsR0FDWmIsS0FBSyxDQUFDQyxPQUFPLENBQUNoQyxJQUFJLENBQUM0QyxHQUFHLENBQUMsQ0FBQyxJQUFJLE9BQU81QyxJQUFJLENBQUM0QyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxRQUFRLEdBQ3hENUMsSUFBSSxDQUFDNEMsR0FBRyxDQUFDLENBQUNGLEdBQUcsQ0FBQ0gsQ0FBQyxJQUFJO1lBQ2pCLE9BQU8sT0FBT0EsQ0FBQyxLQUFLLFFBQVEsR0FBR00sSUFBSSxDQUFDQyxTQUFTLENBQUNQLENBQUMsQ0FBQyxHQUFHQSxDQUFDLEdBQUcsSUFBSTtVQUM3RCxDQUFDLENBQUMsR0FDRnZDLElBQUksQ0FBQzRDLEdBQUcsQ0FBQztRQUNqQixDQUFDLE1BQU0sSUFDTGIsS0FBSyxDQUFDQyxPQUFPLENBQUNoQyxJQUFJLENBQUM0QyxHQUFHLENBQUMsQ0FBQyxJQUN4QixPQUFPNUMsSUFBSSxDQUFDNEMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssUUFBUSxFQUNoQztVQUNBc0YsU0FBUyxDQUFDdEYsR0FBRyxDQUFDLEdBQUc1QyxJQUFJLENBQUM0QyxHQUFHLENBQUM7UUFDNUIsQ0FBQyxNQUFNO1VBQ0wsSUFBSS9GLE9BQU8sQ0FBQytELGFBQWEsSUFBSSxDQUFDLE1BQU0sRUFBRSxTQUFTLENBQUMsQ0FBQ3lDLFFBQVEsQ0FBQ1QsR0FBRyxDQUFDLEVBQUU7WUFDOURzRixTQUFTLENBQUN0RixHQUFHLENBQUMsR0FBRyxDQUFDNUMsSUFBSSxDQUFDNEMsR0FBRyxDQUFDLENBQUM7VUFDOUIsQ0FBQyxNQUFNO1lBQ0xxRixVQUFVLENBQUNuRyxJQUFJLENBQUM5QixJQUFJLENBQUM0QyxHQUFHLENBQUMsQ0FBQztVQUM1QjtRQUNGO01BQ0Y7SUFDRjtJQUNBdkcsS0FBSyxDQUFDeUYsSUFBSSxDQUFDO01BQ1RvQixLQUFLLEVBQUUsQ0FBQ3JHLE9BQU8sQ0FBQ3NMLE9BQU8sSUFBSSxDQUFDLENBQUMsRUFBRUMsVUFBVSxHQUNyQyxFQUFFLEdBQ0YsQ0FBQ3ZMLE9BQU8sQ0FBQ3FFLElBQUksSUFBSSxFQUFFLEVBQUV5RixHQUFHLENBQUMsS0FDeEI5SixPQUFPLENBQUMrRCxhQUFhLEdBQUcsQ0FBQyxDQUFDL0QsT0FBTyxDQUFDOEMsTUFBTSxJQUFJLEVBQUUsRUFBRSxDQUFDLENBQUMsSUFBSSxFQUFFLEVBQUVnSCxHQUFHLENBQUMsR0FBRyxFQUFFLENBQUM7TUFDekVuRSxPQUFPLEVBQUUsQ0FBQyxFQUFFLEVBQUUsRUFBRSxDQUFDO01BQ2pCVyxJQUFJLEVBQUUsUUFBUTtNQUNkVixJQUFJLEVBQUUsSUFBSSxDQUFDbUYsYUFBYSxDQUFDN0wsT0FBTyxFQUFFaU0sU0FBUyxFQUFFLENBQUNuTCxPQUFPLENBQUM4QyxNQUFNLElBQUksRUFBRSxFQUFFLENBQUMsQ0FBQztJQUN4RSxDQUFDLENBQUM7SUFDRixLQUFLLElBQUlpRCxHQUFHLElBQUlzRixTQUFTLEVBQUU7TUFDekIsTUFBTTFGLE9BQU8sR0FBR2hJLE1BQU0sQ0FBQytGLElBQUksQ0FBQzJILFNBQVMsQ0FBQ3RGLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO01BQzlDSixPQUFPLENBQUNOLE9BQU8sQ0FBQyxDQUFDYSxHQUFHLEVBQUVqSSxDQUFDLEtBQUs7UUFDMUIwSCxPQUFPLENBQUMxSCxDQUFDLENBQUMsR0FBR2lJLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQ0MsV0FBVyxDQUFDLENBQUMsR0FBR0QsR0FBRyxDQUFDRSxLQUFLLENBQUMsQ0FBQyxDQUFDO01BQ2xELENBQUMsQ0FBQztNQUVGLE1BQU1SLElBQUksR0FBR3lGLFNBQVMsQ0FBQ3RGLEdBQUcsQ0FBQyxDQUFDRixHQUFHLENBQUNILENBQUMsSUFBSTtRQUNuQyxJQUFJSSxHQUFHLEdBQUcsRUFBRTtRQUNaLEtBQUssSUFBSUMsR0FBRyxJQUFJTCxDQUFDLEVBQUU7VUFDakJJLEdBQUcsQ0FBQ2IsSUFBSSxDQUNOLE9BQU9TLENBQUMsQ0FBQ0ssR0FBRyxDQUFDLEtBQUssUUFBUSxHQUN0QkwsQ0FBQyxDQUFDSyxHQUFHLENBQUMsR0FDTmIsS0FBSyxDQUFDQyxPQUFPLENBQUNPLENBQUMsQ0FBQ0ssR0FBRyxDQUFDLENBQUMsR0FDckJMLENBQUMsQ0FBQ0ssR0FBRyxDQUFDLENBQUNGLEdBQUcsQ0FBQ0gsQ0FBQyxJQUFJO1lBQ2QsT0FBT0EsQ0FBQyxHQUFHLElBQUk7VUFDakIsQ0FBQyxDQUFDLEdBQ0ZNLElBQUksQ0FBQ0MsU0FBUyxDQUFDUCxDQUFDLENBQUNLLEdBQUcsQ0FBQyxDQUMzQixDQUFDO1FBQ0g7UUFDQSxPQUFPRCxHQUFHLENBQUNyQyxNQUFNLEdBQUdrQyxPQUFPLENBQUNsQyxNQUFNLEVBQUU7VUFDbENxQyxHQUFHLENBQUNiLElBQUksQ0FBQyxHQUFHLENBQUM7UUFDZjtRQUNBLE9BQU9hLEdBQUc7TUFDWixDQUFDLENBQUM7TUFDRnRHLEtBQUssQ0FBQ3lGLElBQUksQ0FBQztRQUNUb0IsS0FBSyxFQUFFLENBQUMsQ0FBQ3JHLE9BQU8sQ0FBQzhDLE1BQU0sSUFBSSxFQUFFLEVBQUUsQ0FBQyxDQUFDLElBQUksRUFBRSxFQUFFaUQsR0FBRyxDQUFDLElBQUksRUFBRTtRQUNuRE8sSUFBSSxFQUFFLE9BQU87UUFDYlgsT0FBTztRQUNQQztNQUNGLENBQUMsQ0FBQztJQUNKO0lBQ0F3RixVQUFVLENBQUMvRixPQUFPLENBQUNtRyxJQUFJLElBQUk7TUFDekIsSUFBSSxDQUFDOUUsZUFBZSxDQUFDeEgsT0FBTyxFQUFFc00sSUFBSSxFQUFFeEwsT0FBTyxFQUFFOEosR0FBRyxHQUFHLENBQUMsRUFBRXRLLEtBQUssQ0FBQztJQUM5RCxDQUFDLENBQUM7SUFDRixPQUFPQSxLQUFLO0VBQ2Q7RUFzdEJBO0FBQ0Y7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0VBQ0UsTUFBTWlNLFVBQVVBLENBQ2R2TSxPQUE4QixFQUM5QkMsT0FBb0MsRUFDcENDLFFBQTZDLEVBQzdDO0lBQ0EsSUFBSTtNQUNGRixPQUFPLENBQUNHLEtBQUssQ0FBQ0MsTUFBTSxDQUFDQyxLQUFLLENBQUMsMEJBQTBCLENBQUM7TUFDdEQsTUFBTTtRQUFFeUI7TUFBYSxDQUFDLEdBQUcsTUFBTTlCLE9BQU8sQ0FBQ0csS0FBSyxDQUFDcU0sUUFBUSxDQUFDQyxjQUFjLENBQ2xFeE0sT0FBTyxFQUNQRCxPQUNGLENBQUM7TUFFRCxNQUFNME0sd0JBQXdCLEdBQzVCMU0sT0FBTyxDQUFDeUIsVUFBVSxDQUFDRSxlQUFlLENBQUNDLDhCQUE4QixDQUM5RCxxQkFBb0JFLFlBQWEsRUFDcEMsQ0FBQztNQUVIOUIsT0FBTyxDQUFDRyxLQUFLLENBQUNDLE1BQU0sQ0FBQ0MsS0FBSyxDQUFFLGNBQWFxTSx3QkFBeUIsRUFBQyxDQUFDO01BRXBFLE1BQU1DLGlCQUFpQixHQUFHQSxDQUFDbk8sQ0FBQyxFQUFFb08sQ0FBQyxLQUM3QnBPLENBQUMsQ0FBQ3FPLElBQUksR0FBR0QsQ0FBQyxDQUFDQyxJQUFJLEdBQUcsQ0FBQyxHQUFHck8sQ0FBQyxDQUFDcU8sSUFBSSxHQUFHRCxDQUFDLENBQUNDLElBQUksR0FBRyxDQUFDLENBQUMsR0FBRyxDQUFDO01BRWhELE1BQU1DLE9BQU8sR0FBR25ELFdBQUUsQ0FBQ29ELFdBQVcsQ0FBQ0wsd0JBQXdCLENBQUMsQ0FBQy9GLEdBQUcsQ0FBQ3FHLElBQUksSUFBSTtRQUNuRSxNQUFNQyxLQUFLLEdBQUd0RCxXQUFFLENBQUN1RCxRQUFRLENBQUNSLHdCQUF3QixHQUFHLEdBQUcsR0FBR00sSUFBSSxDQUFDO1FBQ2hFO1FBQ0E7UUFDQSxNQUFNRyxjQUFjLEdBQUcsQ0FBQyxXQUFXLEVBQUUsT0FBTyxFQUFFLE9BQU8sRUFBRSxPQUFPLENBQUMsQ0FBQ0MsSUFBSSxDQUNsRXhNLElBQUksSUFBSXFNLEtBQUssQ0FBRSxHQUFFck0sSUFBSyxJQUFHLENBQzNCLENBQUM7UUFDRCxPQUFPO1VBQ0xrRixJQUFJLEVBQUVrSCxJQUFJO1VBQ1ZLLElBQUksRUFBRUosS0FBSyxDQUFDSSxJQUFJO1VBQ2hCUixJQUFJLEVBQUVJLEtBQUssQ0FBQ0UsY0FBYztRQUM1QixDQUFDO01BQ0gsQ0FBQyxDQUFDO01BQ0ZuTixPQUFPLENBQUNHLEtBQUssQ0FBQ0MsTUFBTSxDQUFDQyxLQUFLLENBQ3ZCLDZCQUE0QnlNLE9BQU8sQ0FBQ3ZJLE1BQU8sUUFDOUMsQ0FBQztNQUNEbkgsT0FBTyxDQUFDa1EsSUFBSSxDQUFDUixPQUFPLEVBQUVILGlCQUFpQixDQUFDO01BQ3hDM00sT0FBTyxDQUFDRyxLQUFLLENBQUNDLE1BQU0sQ0FBQ0MsS0FBSyxDQUFFLGtCQUFpQnlNLE9BQU8sQ0FBQ3ZJLE1BQU8sRUFBQyxDQUFDO01BQzlELE9BQU9yRSxRQUFRLENBQUMwQyxFQUFFLENBQUM7UUFDakIzQixJQUFJLEVBQUU7VUFBRTZMO1FBQVE7TUFDbEIsQ0FBQyxDQUFDO0lBQ0osQ0FBQyxDQUFDLE9BQU85SixLQUFLLEVBQUU7TUFDZGhELE9BQU8sQ0FBQ0csS0FBSyxDQUFDQyxNQUFNLENBQUM0QyxLQUFLLENBQUNBLEtBQUssQ0FBQ0YsT0FBTyxJQUFJRSxLQUFLLENBQUM7TUFDbEQsT0FBTyxJQUFBQyw0QkFBYSxFQUFDRCxLQUFLLENBQUNGLE9BQU8sSUFBSUUsS0FBSyxFQUFFLElBQUksRUFBRSxHQUFHLEVBQUU5QyxRQUFRLENBQUM7SUFDbkU7RUFDRjtFQWtFQUgsOENBQThDQSxDQUM1Q3dOLFlBQVksRUFDWkMsc0JBQXNCLEVBQ3RCO0lBQ0EsT0FBTyxPQUNMeE4sT0FBOEIsRUFDOUJDLE9BQW9DLEVBQ3BDQyxRQUE2QyxLQUMxQztNQUNILElBQUk7UUFDRixNQUFNO1VBQUV1TixRQUFRO1VBQUUzTDtRQUFhLENBQUMsR0FDOUIsTUFBTTlCLE9BQU8sQ0FBQ0csS0FBSyxDQUFDcU0sUUFBUSxDQUFDQyxjQUFjLENBQUN4TSxPQUFPLEVBQUVELE9BQU8sQ0FBQztRQUMvRCxNQUFNME0sd0JBQXdCLEdBQUcvRSxhQUFJLENBQUNnRCxJQUFJLENBQ3hDM0ssT0FBTyxDQUFDeUIsVUFBVSxDQUFDRSxlQUFlLENBQUMrTCx3QkFBd0IsQ0FDekQsbUJBQ0YsQ0FBQyxFQUNENUwsWUFDRixDQUFDO1FBQ0QsTUFBTWlCLFFBQVEsR0FBR3lLLHNCQUFzQixDQUFDdk4sT0FBTyxDQUFDO1FBQ2hELE1BQU0wQyxZQUFZLEdBQUdnRixhQUFJLENBQUNnRCxJQUFJLENBQUMrQix3QkFBd0IsRUFBRTNKLFFBQVEsQ0FBQztRQUNsRS9DLE9BQU8sQ0FBQ0csS0FBSyxDQUFDQyxNQUFNLENBQUNDLEtBQUssQ0FDdkIscUJBQW9Cb04sUUFBUyxJQUFHM0wsWUFBYSx5Q0FBd0NhLFlBQWEsRUFDckcsQ0FBQztRQUNELElBQ0UsQ0FBQ0EsWUFBWSxDQUFDZ0wsVUFBVSxDQUFDakIsd0JBQXdCLENBQUMsSUFDbEQvSixZQUFZLENBQUMyRSxRQUFRLENBQUMsS0FBSyxDQUFDLEVBQzVCO1VBQ0F0SCxPQUFPLENBQUNHLEtBQUssQ0FBQ0MsTUFBTSxDQUFDd04sSUFBSSxDQUN0QixRQUFPSCxRQUFTLElBQUczTCxZQUFhLGdEQUErQ2EsWUFBYSxFQUMvRixDQUFDO1VBQ0QsT0FBT3pDLFFBQVEsQ0FBQzJOLFVBQVUsQ0FBQztZQUN6QjVNLElBQUksRUFBRTtjQUNKNkIsT0FBTyxFQUFFO1lBQ1g7VUFDRixDQUFDLENBQUM7UUFDSjtRQUNBOUMsT0FBTyxDQUFDRyxLQUFLLENBQUNDLE1BQU0sQ0FBQ0MsS0FBSyxDQUN4QixzREFDRixDQUFDO1FBQ0QsT0FBTyxNQUFNa04sWUFBWSxDQUFDTyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQ2xDO1VBQ0UsR0FBRzlOLE9BQU87VUFDVjZCLG1CQUFtQixFQUFFO1lBQUVDLFlBQVk7WUFBRWlCLFFBQVE7WUFBRUo7VUFBYTtRQUM5RCxDQUFDLEVBQ0QxQyxPQUFPLEVBQ1BDLFFBQ0YsQ0FBQztNQUNILENBQUMsQ0FBQyxPQUFPOEMsS0FBSyxFQUFFO1FBQ2RoRCxPQUFPLENBQUNHLEtBQUssQ0FBQ0MsTUFBTSxDQUFDNEMsS0FBSyxDQUFDQSxLQUFLLENBQUNGLE9BQU8sSUFBSUUsS0FBSyxDQUFDO1FBQ2xELE9BQU8sSUFBQUMsNEJBQWEsRUFBQ0QsS0FBSyxDQUFDRixPQUFPLElBQUlFLEtBQUssRUFBRSxJQUFJLEVBQUUsR0FBRyxFQUFFOUMsUUFBUSxDQUFDO01BQ25FO0lBQ0YsQ0FBQztFQUNIO0VBRVFnRCx1QkFBdUJBLENBQUEsRUFBRztJQUNoQyxPQUFRLEdBQUdiLElBQUksQ0FBQzBMLEdBQUcsQ0FBQyxDQUFDLEdBQUcsSUFBSSxHQUFJLENBQUUsRUFBQztFQUNyQztBQUNGO0FBQUNDLE9BQUEsQ0FBQW5PLGtCQUFBLEdBQUFBLGtCQUFBIn0=