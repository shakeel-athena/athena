"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.jobMonitoringRun = jobMonitoringRun;
var _nodeCron = _interopRequireDefault(require("node-cron"));
var _monitoringTemplate = require("../../integration-files/monitoring-template");
var _parseCron = require("../../lib/parse-cron");
var _indexDate = require("../../lib/index-date");
var _constants = require("../../../common/constants");
var _tryCatchForIndexPermissionError = require("../tryCatchForIndexPermissionError");
var _utils = require("../../../common/utils");
function _interopRequireDefault(e) { return e && e.__esModule ? e : { default: e }; }
/*
 * Wazuh app - Module for agent info fetching functions
 * Copyright (C) 2015-2022 Wazuh, Inc.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * Find more information about this on the LICENSE file.
 */

let MONITORING_ENABLED, MONITORING_FREQUENCY, MONITORING_CRON_FREQ, MONITORING_CREATION, MONITORING_INDEX_PATTERN, MONITORING_INDEX_PREFIX;

/**
 * Set the monitoring variables
 * @param context
 */
async function initMonitoringConfiguration(context) {
  try {
    context.wazuh.logger.debug('Reading configuration');
    const appConfig = await context.wazuh_core.configuration.get();
    MONITORING_ENABLED = appConfig['wazuh.monitoring.enabled'] && appConfig['wazuh.monitoring.enabled'] !== 'worker' || appConfig['wazuh.monitoring.enabled'];
    MONITORING_FREQUENCY = appConfig['wazuh.monitoring.frequency'];
    try {
      MONITORING_CRON_FREQ = (0, _parseCron.parseCron)(MONITORING_FREQUENCY);
    } catch (error) {
      context.wazuh.logger.warn(`Using default value ${_constants.WAZUH_MONITORING_DEFAULT_CRON_FREQ} due to: ${error.message || error}`);
      MONITORING_CRON_FREQ = _constants.WAZUH_MONITORING_DEFAULT_CRON_FREQ;
    }
    MONITORING_CREATION = appConfig['wazuh.monitoring.creation'];
    MONITORING_INDEX_PATTERN = appConfig['wazuh.monitoring.pattern'];
    const lastCharIndexPattern = MONITORING_INDEX_PATTERN[MONITORING_INDEX_PATTERN.length - 1];
    if (lastCharIndexPattern !== '*') {
      MONITORING_INDEX_PATTERN += '*';
    }
    MONITORING_INDEX_PREFIX = MONITORING_INDEX_PATTERN.slice(0, MONITORING_INDEX_PATTERN.length - 1);
    context.wazuh.logger.debug(`wazuh.monitoring.enabled: ${MONITORING_ENABLED}`);
    context.wazuh.logger.debug(`wazuh.monitoring.frequency: ${MONITORING_FREQUENCY} (${MONITORING_CRON_FREQ})`);
    context.wazuh.logger.debug(`wazuh.monitoring.creation: ${MONITORING_CREATION}`);
    context.wazuh.logger.debug(`wazuh.monitoring.pattern: ${MONITORING_INDEX_PATTERN} (index prefix: ${MONITORING_INDEX_PREFIX})`);
  } catch (error) {
    context.wazuh.logger.error(error.message);
  }
}

/**
 * Main. First execution when installing / loading App.
 * @param context
 */
async function init(context) {
  try {
    if (MONITORING_ENABLED) {
      await checkTemplate(context);
    }
  } catch (error) {
    const errorMessage = error.message || error;
    context.wazuh.logger.error(errorMessage);
  }
}

/**
 * Verify wazuh-agent template
 */
async function checkTemplate(context) {
  try {
    try {
      context.wazuh.logger.debug(`Getting the ${_constants.WAZUH_MONITORING_TEMPLATE_NAME} template`);
      // Check if the template already exists
      const currentTemplate = await context.core.opensearch.client.asInternalUser.indices.getTemplate({
        name: _constants.WAZUH_MONITORING_TEMPLATE_NAME
      });
      // Copy already created index patterns
      _monitoringTemplate.monitoringTemplate.index_patterns = currentTemplate.body[_constants.WAZUH_MONITORING_TEMPLATE_NAME].index_patterns;
    } catch (error) {
      // Init with the default index pattern
      _monitoringTemplate.monitoringTemplate.index_patterns = [await context.wazuh_core.configuration.get('wazuh.monitoring.pattern')];
    }

    // Check if the user is using a custom pattern and add it to the template if it does
    if (!_monitoringTemplate.monitoringTemplate.index_patterns.includes(MONITORING_INDEX_PATTERN)) {
      _monitoringTemplate.monitoringTemplate.index_patterns.push(MONITORING_INDEX_PATTERN);
    }

    // Update the monitoring template
    context.wazuh.logger.debug(`Updating the ${_constants.WAZUH_MONITORING_TEMPLATE_NAME} template`);
    await context.core.opensearch.client.asInternalUser.indices.putTemplate({
      name: _constants.WAZUH_MONITORING_TEMPLATE_NAME,
      body: _monitoringTemplate.monitoringTemplate
    });
    context.wazuh.logger.info(`Updated the ${_constants.WAZUH_MONITORING_TEMPLATE_NAME} template`);
  } catch (error) {
    const errorMessage = `Something went wrong updating the ${_constants.WAZUH_MONITORING_TEMPLATE_NAME} template ${error.message || error}`;
    context.wazuh.logger.error(errorMessage);
    throw error;
  }
}

/**
 * Save agent status into elasticsearch, create index and/or insert document
 * @param {*} context
 * @param {*} data
 */
async function insertMonitoringDataElasticsearch(context, data) {
  const monitoringIndexName = MONITORING_INDEX_PREFIX + (0, _indexDate.indexDate)(MONITORING_CREATION);
  if (!MONITORING_ENABLED) {
    return;
  }
  try {
    await (0, _tryCatchForIndexPermissionError.tryCatchForIndexPermissionError)(monitoringIndexName)(async () => {
      context.wazuh.logger.debug(`Checking the existence of ${monitoringIndexName} index`);
      const exists = await context.core.opensearch.client.asInternalUser.indices.exists({
        index: monitoringIndexName
      });
      if (!exists.body) {
        context.wazuh.logger.debug(`The ${monitoringIndexName} index does not exist`);
        await createIndex(context, monitoringIndexName);
      } else {
        context.wazuh.logger.debug(`The ${monitoringIndexName} index exists`);
      }

      // Update the index configuration
      const appConfig = await context.wazuh_core.configuration.get('wazuh.monitoring.shards', 'wazuh.monitoring.replicas');
      const indexConfiguration = {
        settings: {
          index: {
            number_of_shards: appConfig['wazuh.monitoring.shards'],
            number_of_replicas: appConfig['wazuh.monitoring.replicas']
          }
        }
      };

      // To update the index settings with this client is required close the index, update the settings and open it
      // Number of shards is not dynamic so delete that setting if it's given
      delete indexConfiguration.settings.index.number_of_shards;
      context.wazuh.logger.debug(`Adding settings to ${monitoringIndexName} index`);
      await context.core.opensearch.client.asInternalUser.indices.putSettings({
        index: monitoringIndexName,
        body: indexConfiguration
      });
      context.wazuh.logger.info(`Settings added to ${monitoringIndexName} index`);

      // Insert data to the monitoring index
      await insertDataToIndex(context, monitoringIndexName, data);
    })();
  } catch (error) {
    context.wazuh.logger.error(error.message || error);
  }
}

/**
 * Inserting one document per agent into Elastic. Bulk.
 * @param {*} context Endpoint
 * @param {String} indexName The name for the index (e.g. daily: wazuh-monitoring-YYYY.MM.DD)
 * @param {*} data
 */
async function insertDataToIndex(context, indexName, data) {
  const {
    agents,
    apiHost
  } = data;
  try {
    if (agents.length > 0) {
      context.wazuh.logger.debug(`Bulk data to index ${indexName} for ${agents.length} agents`);
      const bodyBulk = agents.map(agent => {
        const agentInfo = {
          ...agent
        };
        agentInfo['timestamp'] = new Date(Date.now()).toISOString();
        agentInfo.host = agent.manager;
        agentInfo.cluster = {
          name: apiHost.clusterName ? apiHost.clusterName : 'disabled'
        };
        return `{ "index":  { "_index": "${indexName}" } }\n${JSON.stringify(agentInfo)}\n`;
      }).join('');
      await context.core.opensearch.client.asInternalUser.bulk({
        index: indexName,
        body: bodyBulk
      });
      context.wazuh.logger.info(`Bulk data to index ${indexName} for ${agents.length} agents completed`);
    }
  } catch (error) {
    context.wazuh.logger.error(`Error inserting agent data into elasticsearch. Bulk request failed due to ${error.message || error}`);
  }
}

/**
 * Create the wazuh-monitoring index
 * @param {*} context context
 * @param {String} indexName The name for the index (e.g. daily: wazuh-monitoring-YYYY.MM.DD)
 */
async function createIndex(context, indexName) {
  try {
    if (!MONITORING_ENABLED) return;
    const appConfig = await context.wazuh_core.configuration.get('wazuh.monitoring.shards', 'wazuh.monitoring.replicas');
    const IndexConfiguration = {
      settings: {
        index: {
          number_of_shards: appConfig['wazuh.monitoring.shards'],
          number_of_replicas: appConfig['wazuh.monitoring.replicas']
        }
      }
    };
    context.wazuh.logger.debug(`Creating ${indexName} index`);
    await context.core.opensearch.client.asInternalUser.indices.create({
      index: indexName,
      body: IndexConfiguration
    });
    context.wazuh.logger.info(`${indexName} index created`);
  } catch (error) {
    context.wazuh.logger.error(`Could not create ${indexName} index: ${error.message || error}`);
  }
}

/**
 * Wait until Kibana server is ready
 */
async function checkPluginPlatformStatus(context) {
  try {
    context.wazuh.logger.debug('Waiting for platform servers to be ready...');
    await checkElasticsearchServer(context);
    await init(context);
  } catch (error) {
    context.wazuh.logger.error(error.message || error);
    try {
      await (0, _utils.delayAsPromise)(3000);
      await checkPluginPlatformStatus(context);
    } catch (error) {}
  }
}

/**
 * Check Elasticsearch Server status and Kibana index presence
 */
async function checkElasticsearchServer(context) {
  try {
    context.wazuh.logger.debug(`Checking the existence of ${context.server.config.opensearchDashboards.index} index`);
    const data = await context.core.opensearch.client.asInternalUser.indices.exists({
      index: context.server.config.opensearchDashboards.index
    });
    return data.body;
    // TODO: check if Elasticsearch can receive requests
    // if (data) {
    //   const pluginsData = await this.server.plugins.elasticsearch.waitUntilReady();
    //   return pluginsData;
    // }
    return Promise.reject(data);
  } catch (error) {
    context.wazuh.logger.error(error.message || error);
    return Promise.reject(error);
  }
}

/**
 * Task used by the cron job.
 */
async function cronTask(context) {
  try {
    const templateMonitoring = await context.core.opensearch.client.asInternalUser.indices.getTemplate({
      name: _constants.WAZUH_MONITORING_TEMPLATE_NAME
    });
    const apiHosts = await context.wazuh_core.manageHosts.getEntries({
      excludePassword: true
    });
    if (!apiHosts.length) {
      context.wazuh.logger.warn('There are no API host entries. Skip.');
      return;
    }
    const apiHostsUnique = (apiHosts || []).filter((apiHost, index, self) => index === self.findIndex(t => t.user === apiHost.user && t.password === apiHost.password && t.url === apiHost.url && t.port === apiHost.port));
    for (let apiHost of apiHostsUnique) {
      try {
        const {
          agents,
          apiHost: host
        } = await getApiInfo(context, apiHost);
        await insertMonitoringDataElasticsearch(context, {
          agents,
          apiHost: host
        });
      } catch (error) {}
    }
  } catch (error) {
    // Retry to call itself again if Kibana index is not ready yet
    // try {
    //   if (
    //     this.wzWrapper.buildingKibanaIndex ||
    //     ((error || {}).status === 404 &&
    //       (error || {}).displayName === 'NotFound')
    //   ) {
    //     await delayAsPromise(1000);
    //     return cronTask(context);
    //   }
    // } catch (error) {} //eslint-disable-line
    context.wazuh.logger.error(error.message || error);
  }
}

/**
 * Get API and agents info
 * @param context
 * @param apiHost
 */
async function getApiInfo(context, apiHost) {
  try {
    context.wazuh.logger.debug(`Getting API info for ${apiHost.id}`);
    const responseIsCluster = await context.wazuh.api.client.asInternalUser.request('GET', '/cluster/status', {}, {
      apiHostID: apiHost.id
    });
    const isCluster = (((responseIsCluster || {}).data || {}).data || {}).enabled === 'yes';
    if (isCluster) {
      const responseClusterInfo = await context.wazuh.api.client.asInternalUser.request('GET', `/cluster/local/info`, {}, {
        apiHostID: apiHost.id
      });
      apiHost.clusterName = responseClusterInfo.data.data.affected_items[0].cluster;
    }
    const agents = await fetchAllAgentsFromApiHost(context, apiHost);
    return {
      agents,
      apiHost
    };
  } catch (error) {
    context.wazuh.logger.error(error.message || error);
    throw error;
  }
}

/**
 * Fetch all agents for the API provided
 * @param context
 * @param apiHost
 */
async function fetchAllAgentsFromApiHost(context, apiHost) {
  let agents = [];
  try {
    context.wazuh.logger.debug(`Getting all agents from ApiID: ${apiHost.id}`);
    const responseAgentsCount = await context.wazuh.api.client.asInternalUser.request('GET', '/agents', {
      params: {
        offset: 0,
        limit: 1,
        q: 'id!=000'
      }
    }, {
      apiHostID: apiHost.id
    });
    const agentsCount = responseAgentsCount.data.data.total_affected_items;
    context.wazuh.logger.debug(`ApiID: ${apiHost.id}, Agent count: ${agentsCount}`);
    let payload = {
      offset: 0,
      limit: 500,
      q: 'id!=000'
    };
    while (agents.length < agentsCount && payload.offset < agentsCount) {
      try {
        /*
        TODO: Improve the performance of request with:
          - Reduce the number of requests to the Wazuh API
          - Reduce (if possible) the quantity of data to index by document
         Requirements:
          - Research about the necessary data to index.
         How to do:
          - Wazuh API request:
            - select the required data to retrieve depending on is required to index (using the `select` query param)
            - increase the limit of results to retrieve (currently, the requests use the recommended value: 500).
              See the allowed values. This depends on the selected data because the response could fail if contains a lot of data
        */
        const responseAgents = await context.wazuh.api.client.asInternalUser.request('GET', `/agents`, {
          params: payload
        }, {
          apiHostID: apiHost.id
        });
        agents = [...agents, ...responseAgents.data.data.affected_items];
        payload.offset += payload.limit;
      } catch (error) {
        context.wazuh.logger.error(`ApiID: ${apiHost.id}, Error request with offset/limit ${payload.offset}/${payload.limit}: ${error.message || error}`);
        throw error;
      }
    }
    return agents;
  } catch (error) {
    context.wazuh.logger.error(`ApiID: ${apiHost.id}. Error: ${error.message || error}`);
    throw error;
  }
}

/**
 * Start the cron job
 */
async function jobMonitoringRun(context) {
  context.wazuh.logger.debug('Task:Monitoring initializing');
  // Init the monitoring variables
  await initMonitoringConfiguration(context);
  // Check Kibana index and if it is prepared, start the initialization of Wazuh App.
  await checkPluginPlatformStatus(context);
  // // Run the cron job only it it's enabled
  if (MONITORING_ENABLED) {
    cronTask(context);
    _nodeCron.default.schedule(MONITORING_CRON_FREQ, () => cronTask(context));
  }
}
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfbm9kZUNyb24iLCJfaW50ZXJvcFJlcXVpcmVEZWZhdWx0IiwicmVxdWlyZSIsIl9tb25pdG9yaW5nVGVtcGxhdGUiLCJfcGFyc2VDcm9uIiwiX2luZGV4RGF0ZSIsIl9jb25zdGFudHMiLCJfdHJ5Q2F0Y2hGb3JJbmRleFBlcm1pc3Npb25FcnJvciIsIl91dGlscyIsImUiLCJfX2VzTW9kdWxlIiwiZGVmYXVsdCIsIk1PTklUT1JJTkdfRU5BQkxFRCIsIk1PTklUT1JJTkdfRlJFUVVFTkNZIiwiTU9OSVRPUklOR19DUk9OX0ZSRVEiLCJNT05JVE9SSU5HX0NSRUFUSU9OIiwiTU9OSVRPUklOR19JTkRFWF9QQVRURVJOIiwiTU9OSVRPUklOR19JTkRFWF9QUkVGSVgiLCJpbml0TW9uaXRvcmluZ0NvbmZpZ3VyYXRpb24iLCJjb250ZXh0Iiwid2F6dWgiLCJsb2dnZXIiLCJkZWJ1ZyIsImFwcENvbmZpZyIsIndhenVoX2NvcmUiLCJjb25maWd1cmF0aW9uIiwiZ2V0IiwicGFyc2VDcm9uIiwiZXJyb3IiLCJ3YXJuIiwiV0FaVUhfTU9OSVRPUklOR19ERUZBVUxUX0NST05fRlJFUSIsIm1lc3NhZ2UiLCJsYXN0Q2hhckluZGV4UGF0dGVybiIsImxlbmd0aCIsInNsaWNlIiwiaW5pdCIsImNoZWNrVGVtcGxhdGUiLCJlcnJvck1lc3NhZ2UiLCJXQVpVSF9NT05JVE9SSU5HX1RFTVBMQVRFX05BTUUiLCJjdXJyZW50VGVtcGxhdGUiLCJjb3JlIiwib3BlbnNlYXJjaCIsImNsaWVudCIsImFzSW50ZXJuYWxVc2VyIiwiaW5kaWNlcyIsImdldFRlbXBsYXRlIiwibmFtZSIsIm1vbml0b3JpbmdUZW1wbGF0ZSIsImluZGV4X3BhdHRlcm5zIiwiYm9keSIsImluY2x1ZGVzIiwicHVzaCIsInB1dFRlbXBsYXRlIiwiaW5mbyIsImluc2VydE1vbml0b3JpbmdEYXRhRWxhc3RpY3NlYXJjaCIsImRhdGEiLCJtb25pdG9yaW5nSW5kZXhOYW1lIiwiaW5kZXhEYXRlIiwidHJ5Q2F0Y2hGb3JJbmRleFBlcm1pc3Npb25FcnJvciIsImV4aXN0cyIsImluZGV4IiwiY3JlYXRlSW5kZXgiLCJpbmRleENvbmZpZ3VyYXRpb24iLCJzZXR0aW5ncyIsIm51bWJlcl9vZl9zaGFyZHMiLCJudW1iZXJfb2ZfcmVwbGljYXMiLCJwdXRTZXR0aW5ncyIsImluc2VydERhdGFUb0luZGV4IiwiaW5kZXhOYW1lIiwiYWdlbnRzIiwiYXBpSG9zdCIsImJvZHlCdWxrIiwibWFwIiwiYWdlbnQiLCJhZ2VudEluZm8iLCJEYXRlIiwibm93IiwidG9JU09TdHJpbmciLCJob3N0IiwibWFuYWdlciIsImNsdXN0ZXIiLCJjbHVzdGVyTmFtZSIsIkpTT04iLCJzdHJpbmdpZnkiLCJqb2luIiwiYnVsayIsIkluZGV4Q29uZmlndXJhdGlvbiIsImNyZWF0ZSIsImNoZWNrUGx1Z2luUGxhdGZvcm1TdGF0dXMiLCJjaGVja0VsYXN0aWNzZWFyY2hTZXJ2ZXIiLCJkZWxheUFzUHJvbWlzZSIsInNlcnZlciIsImNvbmZpZyIsIm9wZW5zZWFyY2hEYXNoYm9hcmRzIiwiUHJvbWlzZSIsInJlamVjdCIsImNyb25UYXNrIiwidGVtcGxhdGVNb25pdG9yaW5nIiwiYXBpSG9zdHMiLCJtYW5hZ2VIb3N0cyIsImdldEVudHJpZXMiLCJleGNsdWRlUGFzc3dvcmQiLCJhcGlIb3N0c1VuaXF1ZSIsImZpbHRlciIsInNlbGYiLCJmaW5kSW5kZXgiLCJ0IiwidXNlciIsInBhc3N3b3JkIiwidXJsIiwicG9ydCIsImdldEFwaUluZm8iLCJpZCIsInJlc3BvbnNlSXNDbHVzdGVyIiwiYXBpIiwicmVxdWVzdCIsImFwaUhvc3RJRCIsImlzQ2x1c3RlciIsImVuYWJsZWQiLCJyZXNwb25zZUNsdXN0ZXJJbmZvIiwiYWZmZWN0ZWRfaXRlbXMiLCJmZXRjaEFsbEFnZW50c0Zyb21BcGlIb3N0IiwicmVzcG9uc2VBZ2VudHNDb3VudCIsInBhcmFtcyIsIm9mZnNldCIsImxpbWl0IiwicSIsImFnZW50c0NvdW50IiwidG90YWxfYWZmZWN0ZWRfaXRlbXMiLCJwYXlsb2FkIiwicmVzcG9uc2VBZ2VudHMiLCJqb2JNb25pdG9yaW5nUnVuIiwiY3JvbiIsInNjaGVkdWxlIl0sInNvdXJjZXMiOlsiaW5kZXgudHMiXSwic291cmNlc0NvbnRlbnQiOlsiLypcbiAqIFdhenVoIGFwcCAtIE1vZHVsZSBmb3IgYWdlbnQgaW5mbyBmZXRjaGluZyBmdW5jdGlvbnNcbiAqIENvcHlyaWdodCAoQykgMjAxNS0yMDIyIFdhenVoLCBJbmMuXG4gKlxuICogVGhpcyBwcm9ncmFtIGlzIGZyZWUgc29mdHdhcmU7IHlvdSBjYW4gcmVkaXN0cmlidXRlIGl0IGFuZC9vciBtb2RpZnlcbiAqIGl0IHVuZGVyIHRoZSB0ZXJtcyBvZiB0aGUgR05VIEdlbmVyYWwgUHVibGljIExpY2Vuc2UgYXMgcHVibGlzaGVkIGJ5XG4gKiB0aGUgRnJlZSBTb2Z0d2FyZSBGb3VuZGF0aW9uOyBlaXRoZXIgdmVyc2lvbiAyIG9mIHRoZSBMaWNlbnNlLCBvclxuICogKGF0IHlvdXIgb3B0aW9uKSBhbnkgbGF0ZXIgdmVyc2lvbi5cbiAqXG4gKiBGaW5kIG1vcmUgaW5mb3JtYXRpb24gYWJvdXQgdGhpcyBvbiB0aGUgTElDRU5TRSBmaWxlLlxuICovXG5pbXBvcnQgY3JvbiBmcm9tICdub2RlLWNyb24nO1xuaW1wb3J0IHsgbW9uaXRvcmluZ1RlbXBsYXRlIH0gZnJvbSAnLi4vLi4vaW50ZWdyYXRpb24tZmlsZXMvbW9uaXRvcmluZy10ZW1wbGF0ZSc7XG5pbXBvcnQgeyBwYXJzZUNyb24gfSBmcm9tICcuLi8uLi9saWIvcGFyc2UtY3Jvbic7XG5pbXBvcnQgeyBpbmRleERhdGUgfSBmcm9tICcuLi8uLi9saWIvaW5kZXgtZGF0ZSc7XG5pbXBvcnQge1xuICBXQVpVSF9NT05JVE9SSU5HX0RFRkFVTFRfQ1JPTl9GUkVRLFxuICBXQVpVSF9NT05JVE9SSU5HX1RFTVBMQVRFX05BTUUsXG59IGZyb20gJy4uLy4uLy4uL2NvbW1vbi9jb25zdGFudHMnO1xuaW1wb3J0IHsgdHJ5Q2F0Y2hGb3JJbmRleFBlcm1pc3Npb25FcnJvciB9IGZyb20gJy4uL3RyeUNhdGNoRm9ySW5kZXhQZXJtaXNzaW9uRXJyb3InO1xuaW1wb3J0IHsgZGVsYXlBc1Byb21pc2UgfSBmcm9tICcuLi8uLi8uLi9jb21tb24vdXRpbHMnO1xuXG5sZXQgTU9OSVRPUklOR19FTkFCTEVELFxuICBNT05JVE9SSU5HX0ZSRVFVRU5DWSxcbiAgTU9OSVRPUklOR19DUk9OX0ZSRVEsXG4gIE1PTklUT1JJTkdfQ1JFQVRJT04sXG4gIE1PTklUT1JJTkdfSU5ERVhfUEFUVEVSTixcbiAgTU9OSVRPUklOR19JTkRFWF9QUkVGSVg7XG5cbi8qKlxuICogU2V0IHRoZSBtb25pdG9yaW5nIHZhcmlhYmxlc1xuICogQHBhcmFtIGNvbnRleHRcbiAqL1xuYXN5bmMgZnVuY3Rpb24gaW5pdE1vbml0b3JpbmdDb25maWd1cmF0aW9uKGNvbnRleHQpIHtcbiAgdHJ5IHtcbiAgICBjb250ZXh0LndhenVoLmxvZ2dlci5kZWJ1ZygnUmVhZGluZyBjb25maWd1cmF0aW9uJyk7XG4gICAgY29uc3QgYXBwQ29uZmlnID0gYXdhaXQgY29udGV4dC53YXp1aF9jb3JlLmNvbmZpZ3VyYXRpb24uZ2V0KCk7XG4gICAgTU9OSVRPUklOR19FTkFCTEVEID1cbiAgICAgIChhcHBDb25maWdbJ3dhenVoLm1vbml0b3JpbmcuZW5hYmxlZCddICYmXG4gICAgICAgIGFwcENvbmZpZ1snd2F6dWgubW9uaXRvcmluZy5lbmFibGVkJ10gIT09ICd3b3JrZXInKSB8fFxuICAgICAgYXBwQ29uZmlnWyd3YXp1aC5tb25pdG9yaW5nLmVuYWJsZWQnXTtcbiAgICBNT05JVE9SSU5HX0ZSRVFVRU5DWSA9IGFwcENvbmZpZ1snd2F6dWgubW9uaXRvcmluZy5mcmVxdWVuY3knXTtcbiAgICB0cnkge1xuICAgICAgTU9OSVRPUklOR19DUk9OX0ZSRVEgPSBwYXJzZUNyb24oTU9OSVRPUklOR19GUkVRVUVOQ1kpO1xuICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICBjb250ZXh0LndhenVoLmxvZ2dlci53YXJuKFxuICAgICAgICBgVXNpbmcgZGVmYXVsdCB2YWx1ZSAke1dBWlVIX01PTklUT1JJTkdfREVGQVVMVF9DUk9OX0ZSRVF9IGR1ZSB0bzogJHtcbiAgICAgICAgICBlcnJvci5tZXNzYWdlIHx8IGVycm9yXG4gICAgICAgIH1gLFxuICAgICAgKTtcbiAgICAgIE1PTklUT1JJTkdfQ1JPTl9GUkVRID0gV0FaVUhfTU9OSVRPUklOR19ERUZBVUxUX0NST05fRlJFUTtcbiAgICB9XG4gICAgTU9OSVRPUklOR19DUkVBVElPTiA9IGFwcENvbmZpZ1snd2F6dWgubW9uaXRvcmluZy5jcmVhdGlvbiddO1xuXG4gICAgTU9OSVRPUklOR19JTkRFWF9QQVRURVJOID0gYXBwQ29uZmlnWyd3YXp1aC5tb25pdG9yaW5nLnBhdHRlcm4nXTtcblxuICAgIGNvbnN0IGxhc3RDaGFySW5kZXhQYXR0ZXJuID1cbiAgICAgIE1PTklUT1JJTkdfSU5ERVhfUEFUVEVSTltNT05JVE9SSU5HX0lOREVYX1BBVFRFUk4ubGVuZ3RoIC0gMV07XG4gICAgaWYgKGxhc3RDaGFySW5kZXhQYXR0ZXJuICE9PSAnKicpIHtcbiAgICAgIE1PTklUT1JJTkdfSU5ERVhfUEFUVEVSTiArPSAnKic7XG4gICAgfVxuICAgIE1PTklUT1JJTkdfSU5ERVhfUFJFRklYID0gTU9OSVRPUklOR19JTkRFWF9QQVRURVJOLnNsaWNlKFxuICAgICAgMCxcbiAgICAgIE1PTklUT1JJTkdfSU5ERVhfUEFUVEVSTi5sZW5ndGggLSAxLFxuICAgICk7XG5cbiAgICBjb250ZXh0LndhenVoLmxvZ2dlci5kZWJ1ZyhcbiAgICAgIGB3YXp1aC5tb25pdG9yaW5nLmVuYWJsZWQ6ICR7TU9OSVRPUklOR19FTkFCTEVEfWAsXG4gICAgKTtcblxuICAgIGNvbnRleHQud2F6dWgubG9nZ2VyLmRlYnVnKFxuICAgICAgYHdhenVoLm1vbml0b3JpbmcuZnJlcXVlbmN5OiAke01PTklUT1JJTkdfRlJFUVVFTkNZfSAoJHtNT05JVE9SSU5HX0NST05fRlJFUX0pYCxcbiAgICApO1xuXG4gICAgY29udGV4dC53YXp1aC5sb2dnZXIuZGVidWcoXG4gICAgICBgd2F6dWgubW9uaXRvcmluZy5jcmVhdGlvbjogJHtNT05JVE9SSU5HX0NSRUFUSU9OfWAsXG4gICAgKTtcblxuICAgIGNvbnRleHQud2F6dWgubG9nZ2VyLmRlYnVnKFxuICAgICAgYHdhenVoLm1vbml0b3JpbmcucGF0dGVybjogJHtNT05JVE9SSU5HX0lOREVYX1BBVFRFUk59IChpbmRleCBwcmVmaXg6ICR7TU9OSVRPUklOR19JTkRFWF9QUkVGSVh9KWAsXG4gICAgKTtcbiAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICBjb250ZXh0LndhenVoLmxvZ2dlci5lcnJvcihlcnJvci5tZXNzYWdlKTtcbiAgfVxufVxuXG4vKipcbiAqIE1haW4uIEZpcnN0IGV4ZWN1dGlvbiB3aGVuIGluc3RhbGxpbmcgLyBsb2FkaW5nIEFwcC5cbiAqIEBwYXJhbSBjb250ZXh0XG4gKi9cbmFzeW5jIGZ1bmN0aW9uIGluaXQoY29udGV4dCkge1xuICB0cnkge1xuICAgIGlmIChNT05JVE9SSU5HX0VOQUJMRUQpIHtcbiAgICAgIGF3YWl0IGNoZWNrVGVtcGxhdGUoY29udGV4dCk7XG4gICAgfVxuICB9IGNhdGNoIChlcnJvcikge1xuICAgIGNvbnN0IGVycm9yTWVzc2FnZSA9IGVycm9yLm1lc3NhZ2UgfHwgZXJyb3I7XG4gICAgY29udGV4dC53YXp1aC5sb2dnZXIuZXJyb3IoZXJyb3JNZXNzYWdlKTtcbiAgfVxufVxuXG4vKipcbiAqIFZlcmlmeSB3YXp1aC1hZ2VudCB0ZW1wbGF0ZVxuICovXG5hc3luYyBmdW5jdGlvbiBjaGVja1RlbXBsYXRlKGNvbnRleHQpIHtcbiAgdHJ5IHtcbiAgICB0cnkge1xuICAgICAgY29udGV4dC53YXp1aC5sb2dnZXIuZGVidWcoXG4gICAgICAgIGBHZXR0aW5nIHRoZSAke1dBWlVIX01PTklUT1JJTkdfVEVNUExBVEVfTkFNRX0gdGVtcGxhdGVgLFxuICAgICAgKTtcbiAgICAgIC8vIENoZWNrIGlmIHRoZSB0ZW1wbGF0ZSBhbHJlYWR5IGV4aXN0c1xuICAgICAgY29uc3QgY3VycmVudFRlbXBsYXRlID1cbiAgICAgICAgYXdhaXQgY29udGV4dC5jb3JlLm9wZW5zZWFyY2guY2xpZW50LmFzSW50ZXJuYWxVc2VyLmluZGljZXMuZ2V0VGVtcGxhdGUoXG4gICAgICAgICAge1xuICAgICAgICAgICAgbmFtZTogV0FaVUhfTU9OSVRPUklOR19URU1QTEFURV9OQU1FLFxuICAgICAgICAgIH0sXG4gICAgICAgICk7XG4gICAgICAvLyBDb3B5IGFscmVhZHkgY3JlYXRlZCBpbmRleCBwYXR0ZXJuc1xuICAgICAgbW9uaXRvcmluZ1RlbXBsYXRlLmluZGV4X3BhdHRlcm5zID1cbiAgICAgICAgY3VycmVudFRlbXBsYXRlLmJvZHlbV0FaVUhfTU9OSVRPUklOR19URU1QTEFURV9OQU1FXS5pbmRleF9wYXR0ZXJucztcbiAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgLy8gSW5pdCB3aXRoIHRoZSBkZWZhdWx0IGluZGV4IHBhdHRlcm5cbiAgICAgIG1vbml0b3JpbmdUZW1wbGF0ZS5pbmRleF9wYXR0ZXJucyA9IFtcbiAgICAgICAgYXdhaXQgY29udGV4dC53YXp1aF9jb3JlLmNvbmZpZ3VyYXRpb24uZ2V0KCd3YXp1aC5tb25pdG9yaW5nLnBhdHRlcm4nKSxcbiAgICAgIF07XG4gICAgfVxuXG4gICAgLy8gQ2hlY2sgaWYgdGhlIHVzZXIgaXMgdXNpbmcgYSBjdXN0b20gcGF0dGVybiBhbmQgYWRkIGl0IHRvIHRoZSB0ZW1wbGF0ZSBpZiBpdCBkb2VzXG4gICAgaWYgKCFtb25pdG9yaW5nVGVtcGxhdGUuaW5kZXhfcGF0dGVybnMuaW5jbHVkZXMoTU9OSVRPUklOR19JTkRFWF9QQVRURVJOKSkge1xuICAgICAgbW9uaXRvcmluZ1RlbXBsYXRlLmluZGV4X3BhdHRlcm5zLnB1c2goTU9OSVRPUklOR19JTkRFWF9QQVRURVJOKTtcbiAgICB9XG5cbiAgICAvLyBVcGRhdGUgdGhlIG1vbml0b3JpbmcgdGVtcGxhdGVcbiAgICBjb250ZXh0LndhenVoLmxvZ2dlci5kZWJ1ZyhcbiAgICAgIGBVcGRhdGluZyB0aGUgJHtXQVpVSF9NT05JVE9SSU5HX1RFTVBMQVRFX05BTUV9IHRlbXBsYXRlYCxcbiAgICApO1xuICAgIGF3YWl0IGNvbnRleHQuY29yZS5vcGVuc2VhcmNoLmNsaWVudC5hc0ludGVybmFsVXNlci5pbmRpY2VzLnB1dFRlbXBsYXRlKHtcbiAgICAgIG5hbWU6IFdBWlVIX01PTklUT1JJTkdfVEVNUExBVEVfTkFNRSxcbiAgICAgIGJvZHk6IG1vbml0b3JpbmdUZW1wbGF0ZSxcbiAgICB9KTtcbiAgICBjb250ZXh0LndhenVoLmxvZ2dlci5pbmZvKFxuICAgICAgYFVwZGF0ZWQgdGhlICR7V0FaVUhfTU9OSVRPUklOR19URU1QTEFURV9OQU1FfSB0ZW1wbGF0ZWAsXG4gICAgKTtcbiAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICBjb25zdCBlcnJvck1lc3NhZ2UgPSBgU29tZXRoaW5nIHdlbnQgd3JvbmcgdXBkYXRpbmcgdGhlICR7V0FaVUhfTU9OSVRPUklOR19URU1QTEFURV9OQU1FfSB0ZW1wbGF0ZSAke1xuICAgICAgZXJyb3IubWVzc2FnZSB8fCBlcnJvclxuICAgIH1gO1xuICAgIGNvbnRleHQud2F6dWgubG9nZ2VyLmVycm9yKGVycm9yTWVzc2FnZSk7XG4gICAgdGhyb3cgZXJyb3I7XG4gIH1cbn1cblxuLyoqXG4gKiBTYXZlIGFnZW50IHN0YXR1cyBpbnRvIGVsYXN0aWNzZWFyY2gsIGNyZWF0ZSBpbmRleCBhbmQvb3IgaW5zZXJ0IGRvY3VtZW50XG4gKiBAcGFyYW0geyp9IGNvbnRleHRcbiAqIEBwYXJhbSB7Kn0gZGF0YVxuICovXG5hc3luYyBmdW5jdGlvbiBpbnNlcnRNb25pdG9yaW5nRGF0YUVsYXN0aWNzZWFyY2goY29udGV4dCwgZGF0YSkge1xuICBjb25zdCBtb25pdG9yaW5nSW5kZXhOYW1lID1cbiAgICBNT05JVE9SSU5HX0lOREVYX1BSRUZJWCArIGluZGV4RGF0ZShNT05JVE9SSU5HX0NSRUFUSU9OKTtcbiAgaWYgKCFNT05JVE9SSU5HX0VOQUJMRUQpIHtcbiAgICByZXR1cm47XG4gIH1cbiAgdHJ5IHtcbiAgICBhd2FpdCB0cnlDYXRjaEZvckluZGV4UGVybWlzc2lvbkVycm9yKG1vbml0b3JpbmdJbmRleE5hbWUpKGFzeW5jICgpID0+IHtcbiAgICAgIGNvbnRleHQud2F6dWgubG9nZ2VyLmRlYnVnKFxuICAgICAgICBgQ2hlY2tpbmcgdGhlIGV4aXN0ZW5jZSBvZiAke21vbml0b3JpbmdJbmRleE5hbWV9IGluZGV4YCxcbiAgICAgICk7XG4gICAgICBjb25zdCBleGlzdHMgPVxuICAgICAgICBhd2FpdCBjb250ZXh0LmNvcmUub3BlbnNlYXJjaC5jbGllbnQuYXNJbnRlcm5hbFVzZXIuaW5kaWNlcy5leGlzdHMoe1xuICAgICAgICAgIGluZGV4OiBtb25pdG9yaW5nSW5kZXhOYW1lLFxuICAgICAgICB9KTtcbiAgICAgIGlmICghZXhpc3RzLmJvZHkpIHtcbiAgICAgICAgY29udGV4dC53YXp1aC5sb2dnZXIuZGVidWcoXG4gICAgICAgICAgYFRoZSAke21vbml0b3JpbmdJbmRleE5hbWV9IGluZGV4IGRvZXMgbm90IGV4aXN0YCxcbiAgICAgICAgKTtcbiAgICAgICAgYXdhaXQgY3JlYXRlSW5kZXgoY29udGV4dCwgbW9uaXRvcmluZ0luZGV4TmFtZSk7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICBjb250ZXh0LndhenVoLmxvZ2dlci5kZWJ1ZyhgVGhlICR7bW9uaXRvcmluZ0luZGV4TmFtZX0gaW5kZXggZXhpc3RzYCk7XG4gICAgICB9XG5cbiAgICAgIC8vIFVwZGF0ZSB0aGUgaW5kZXggY29uZmlndXJhdGlvblxuICAgICAgY29uc3QgYXBwQ29uZmlnID0gYXdhaXQgY29udGV4dC53YXp1aF9jb3JlLmNvbmZpZ3VyYXRpb24uZ2V0KFxuICAgICAgICAnd2F6dWgubW9uaXRvcmluZy5zaGFyZHMnLFxuICAgICAgICAnd2F6dWgubW9uaXRvcmluZy5yZXBsaWNhcycsXG4gICAgICApO1xuXG4gICAgICBjb25zdCBpbmRleENvbmZpZ3VyYXRpb24gPSB7XG4gICAgICAgIHNldHRpbmdzOiB7XG4gICAgICAgICAgaW5kZXg6IHtcbiAgICAgICAgICAgIG51bWJlcl9vZl9zaGFyZHM6IGFwcENvbmZpZ1snd2F6dWgubW9uaXRvcmluZy5zaGFyZHMnXSxcbiAgICAgICAgICAgIG51bWJlcl9vZl9yZXBsaWNhczogYXBwQ29uZmlnWyd3YXp1aC5tb25pdG9yaW5nLnJlcGxpY2FzJ10sXG4gICAgICAgICAgfSxcbiAgICAgICAgfSxcbiAgICAgIH07XG5cbiAgICAgIC8vIFRvIHVwZGF0ZSB0aGUgaW5kZXggc2V0dGluZ3Mgd2l0aCB0aGlzIGNsaWVudCBpcyByZXF1aXJlZCBjbG9zZSB0aGUgaW5kZXgsIHVwZGF0ZSB0aGUgc2V0dGluZ3MgYW5kIG9wZW4gaXRcbiAgICAgIC8vIE51bWJlciBvZiBzaGFyZHMgaXMgbm90IGR5bmFtaWMgc28gZGVsZXRlIHRoYXQgc2V0dGluZyBpZiBpdCdzIGdpdmVuXG4gICAgICBkZWxldGUgaW5kZXhDb25maWd1cmF0aW9uLnNldHRpbmdzLmluZGV4Lm51bWJlcl9vZl9zaGFyZHM7XG4gICAgICBjb250ZXh0LndhenVoLmxvZ2dlci5kZWJ1ZyhcbiAgICAgICAgYEFkZGluZyBzZXR0aW5ncyB0byAke21vbml0b3JpbmdJbmRleE5hbWV9IGluZGV4YCxcbiAgICAgICk7XG4gICAgICBhd2FpdCBjb250ZXh0LmNvcmUub3BlbnNlYXJjaC5jbGllbnQuYXNJbnRlcm5hbFVzZXIuaW5kaWNlcy5wdXRTZXR0aW5ncyh7XG4gICAgICAgIGluZGV4OiBtb25pdG9yaW5nSW5kZXhOYW1lLFxuICAgICAgICBib2R5OiBpbmRleENvbmZpZ3VyYXRpb24sXG4gICAgICB9KTtcblxuICAgICAgY29udGV4dC53YXp1aC5sb2dnZXIuaW5mbyhcbiAgICAgICAgYFNldHRpbmdzIGFkZGVkIHRvICR7bW9uaXRvcmluZ0luZGV4TmFtZX0gaW5kZXhgLFxuICAgICAgKTtcblxuICAgICAgLy8gSW5zZXJ0IGRhdGEgdG8gdGhlIG1vbml0b3JpbmcgaW5kZXhcbiAgICAgIGF3YWl0IGluc2VydERhdGFUb0luZGV4KGNvbnRleHQsIG1vbml0b3JpbmdJbmRleE5hbWUsIGRhdGEpO1xuICAgIH0pKCk7XG4gIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgY29udGV4dC53YXp1aC5sb2dnZXIuZXJyb3IoZXJyb3IubWVzc2FnZSB8fCBlcnJvcik7XG4gIH1cbn1cblxuLyoqXG4gKiBJbnNlcnRpbmcgb25lIGRvY3VtZW50IHBlciBhZ2VudCBpbnRvIEVsYXN0aWMuIEJ1bGsuXG4gKiBAcGFyYW0geyp9IGNvbnRleHQgRW5kcG9pbnRcbiAqIEBwYXJhbSB7U3RyaW5nfSBpbmRleE5hbWUgVGhlIG5hbWUgZm9yIHRoZSBpbmRleCAoZS5nLiBkYWlseTogd2F6dWgtbW9uaXRvcmluZy1ZWVlZLk1NLkREKVxuICogQHBhcmFtIHsqfSBkYXRhXG4gKi9cbmFzeW5jIGZ1bmN0aW9uIGluc2VydERhdGFUb0luZGV4KFxuICBjb250ZXh0LFxuICBpbmRleE5hbWU6IHN0cmluZyxcbiAgZGF0YTogeyBhZ2VudHM6IGFueVtdOyBhcGlIb3N0IH0sXG4pIHtcbiAgY29uc3QgeyBhZ2VudHMsIGFwaUhvc3QgfSA9IGRhdGE7XG4gIHRyeSB7XG4gICAgaWYgKGFnZW50cy5sZW5ndGggPiAwKSB7XG4gICAgICBjb250ZXh0LndhenVoLmxvZ2dlci5kZWJ1ZyhcbiAgICAgICAgYEJ1bGsgZGF0YSB0byBpbmRleCAke2luZGV4TmFtZX0gZm9yICR7YWdlbnRzLmxlbmd0aH0gYWdlbnRzYCxcbiAgICAgICk7XG5cbiAgICAgIGNvbnN0IGJvZHlCdWxrID0gYWdlbnRzXG4gICAgICAgIC5tYXAoYWdlbnQgPT4ge1xuICAgICAgICAgIGNvbnN0IGFnZW50SW5mbyA9IHsgLi4uYWdlbnQgfTtcbiAgICAgICAgICBhZ2VudEluZm9bJ3RpbWVzdGFtcCddID0gbmV3IERhdGUoRGF0ZS5ub3coKSkudG9JU09TdHJpbmcoKTtcbiAgICAgICAgICBhZ2VudEluZm8uaG9zdCA9IGFnZW50Lm1hbmFnZXI7XG4gICAgICAgICAgYWdlbnRJbmZvLmNsdXN0ZXIgPSB7XG4gICAgICAgICAgICBuYW1lOiBhcGlIb3N0LmNsdXN0ZXJOYW1lID8gYXBpSG9zdC5jbHVzdGVyTmFtZSA6ICdkaXNhYmxlZCcsXG4gICAgICAgICAgfTtcbiAgICAgICAgICByZXR1cm4gYHsgXCJpbmRleFwiOiAgeyBcIl9pbmRleFwiOiBcIiR7aW5kZXhOYW1lfVwiIH0gfVxcbiR7SlNPTi5zdHJpbmdpZnkoXG4gICAgICAgICAgICBhZ2VudEluZm8sXG4gICAgICAgICAgKX1cXG5gO1xuICAgICAgICB9KVxuICAgICAgICAuam9pbignJyk7XG5cbiAgICAgIGF3YWl0IGNvbnRleHQuY29yZS5vcGVuc2VhcmNoLmNsaWVudC5hc0ludGVybmFsVXNlci5idWxrKHtcbiAgICAgICAgaW5kZXg6IGluZGV4TmFtZSxcbiAgICAgICAgYm9keTogYm9keUJ1bGssXG4gICAgICB9KTtcbiAgICAgIGNvbnRleHQud2F6dWgubG9nZ2VyLmluZm8oXG4gICAgICAgIGBCdWxrIGRhdGEgdG8gaW5kZXggJHtpbmRleE5hbWV9IGZvciAke2FnZW50cy5sZW5ndGh9IGFnZW50cyBjb21wbGV0ZWRgLFxuICAgICAgKTtcbiAgICB9XG4gIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgY29udGV4dC53YXp1aC5sb2dnZXIuZXJyb3IoXG4gICAgICBgRXJyb3IgaW5zZXJ0aW5nIGFnZW50IGRhdGEgaW50byBlbGFzdGljc2VhcmNoLiBCdWxrIHJlcXVlc3QgZmFpbGVkIGR1ZSB0byAke1xuICAgICAgICBlcnJvci5tZXNzYWdlIHx8IGVycm9yXG4gICAgICB9YCxcbiAgICApO1xuICB9XG59XG5cbi8qKlxuICogQ3JlYXRlIHRoZSB3YXp1aC1tb25pdG9yaW5nIGluZGV4XG4gKiBAcGFyYW0geyp9IGNvbnRleHQgY29udGV4dFxuICogQHBhcmFtIHtTdHJpbmd9IGluZGV4TmFtZSBUaGUgbmFtZSBmb3IgdGhlIGluZGV4IChlLmcuIGRhaWx5OiB3YXp1aC1tb25pdG9yaW5nLVlZWVkuTU0uREQpXG4gKi9cbmFzeW5jIGZ1bmN0aW9uIGNyZWF0ZUluZGV4KGNvbnRleHQsIGluZGV4TmFtZTogc3RyaW5nKSB7XG4gIHRyeSB7XG4gICAgaWYgKCFNT05JVE9SSU5HX0VOQUJMRUQpIHJldHVybjtcbiAgICBjb25zdCBhcHBDb25maWcgPSBhd2FpdCBjb250ZXh0LndhenVoX2NvcmUuY29uZmlndXJhdGlvbi5nZXQoXG4gICAgICAnd2F6dWgubW9uaXRvcmluZy5zaGFyZHMnLFxuICAgICAgJ3dhenVoLm1vbml0b3JpbmcucmVwbGljYXMnLFxuICAgICk7XG5cbiAgICBjb25zdCBJbmRleENvbmZpZ3VyYXRpb24gPSB7XG4gICAgICBzZXR0aW5nczoge1xuICAgICAgICBpbmRleDoge1xuICAgICAgICAgIG51bWJlcl9vZl9zaGFyZHM6IGFwcENvbmZpZ1snd2F6dWgubW9uaXRvcmluZy5zaGFyZHMnXSxcbiAgICAgICAgICBudW1iZXJfb2ZfcmVwbGljYXM6IGFwcENvbmZpZ1snd2F6dWgubW9uaXRvcmluZy5yZXBsaWNhcyddLFxuICAgICAgICB9LFxuICAgICAgfSxcbiAgICB9O1xuXG4gICAgY29udGV4dC53YXp1aC5sb2dnZXIuZGVidWcoYENyZWF0aW5nICR7aW5kZXhOYW1lfSBpbmRleGApO1xuXG4gICAgYXdhaXQgY29udGV4dC5jb3JlLm9wZW5zZWFyY2guY2xpZW50LmFzSW50ZXJuYWxVc2VyLmluZGljZXMuY3JlYXRlKHtcbiAgICAgIGluZGV4OiBpbmRleE5hbWUsXG4gICAgICBib2R5OiBJbmRleENvbmZpZ3VyYXRpb24sXG4gICAgfSk7XG5cbiAgICBjb250ZXh0LndhenVoLmxvZ2dlci5pbmZvKGAke2luZGV4TmFtZX0gaW5kZXggY3JlYXRlZGApO1xuICB9IGNhdGNoIChlcnJvcikge1xuICAgIGNvbnRleHQud2F6dWgubG9nZ2VyLmVycm9yKFxuICAgICAgYENvdWxkIG5vdCBjcmVhdGUgJHtpbmRleE5hbWV9IGluZGV4OiAke2Vycm9yLm1lc3NhZ2UgfHwgZXJyb3J9YCxcbiAgICApO1xuICB9XG59XG5cbi8qKlxuICogV2FpdCB1bnRpbCBLaWJhbmEgc2VydmVyIGlzIHJlYWR5XG4gKi9cbmFzeW5jIGZ1bmN0aW9uIGNoZWNrUGx1Z2luUGxhdGZvcm1TdGF0dXMoY29udGV4dCkge1xuICB0cnkge1xuICAgIGNvbnRleHQud2F6dWgubG9nZ2VyLmRlYnVnKCdXYWl0aW5nIGZvciBwbGF0Zm9ybSBzZXJ2ZXJzIHRvIGJlIHJlYWR5Li4uJyk7XG5cbiAgICBhd2FpdCBjaGVja0VsYXN0aWNzZWFyY2hTZXJ2ZXIoY29udGV4dCk7XG4gICAgYXdhaXQgaW5pdChjb250ZXh0KTtcbiAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICBjb250ZXh0LndhenVoLmxvZ2dlci5lcnJvcihlcnJvci5tZXNzYWdlIHx8IGVycm9yKTtcbiAgICB0cnkge1xuICAgICAgYXdhaXQgZGVsYXlBc1Byb21pc2UoMzAwMCk7XG4gICAgICBhd2FpdCBjaGVja1BsdWdpblBsYXRmb3JtU3RhdHVzKGNvbnRleHQpO1xuICAgIH0gY2F0Y2ggKGVycm9yKSB7fVxuICB9XG59XG5cbi8qKlxuICogQ2hlY2sgRWxhc3RpY3NlYXJjaCBTZXJ2ZXIgc3RhdHVzIGFuZCBLaWJhbmEgaW5kZXggcHJlc2VuY2VcbiAqL1xuYXN5bmMgZnVuY3Rpb24gY2hlY2tFbGFzdGljc2VhcmNoU2VydmVyKGNvbnRleHQpIHtcbiAgdHJ5IHtcbiAgICBjb250ZXh0LndhenVoLmxvZ2dlci5kZWJ1ZyhcbiAgICAgIGBDaGVja2luZyB0aGUgZXhpc3RlbmNlIG9mICR7Y29udGV4dC5zZXJ2ZXIuY29uZmlnLm9wZW5zZWFyY2hEYXNoYm9hcmRzLmluZGV4fSBpbmRleGAsXG4gICAgKTtcbiAgICBjb25zdCBkYXRhID1cbiAgICAgIGF3YWl0IGNvbnRleHQuY29yZS5vcGVuc2VhcmNoLmNsaWVudC5hc0ludGVybmFsVXNlci5pbmRpY2VzLmV4aXN0cyh7XG4gICAgICAgIGluZGV4OiBjb250ZXh0LnNlcnZlci5jb25maWcub3BlbnNlYXJjaERhc2hib2FyZHMuaW5kZXgsXG4gICAgICB9KTtcblxuICAgIHJldHVybiBkYXRhLmJvZHk7XG4gICAgLy8gVE9ETzogY2hlY2sgaWYgRWxhc3RpY3NlYXJjaCBjYW4gcmVjZWl2ZSByZXF1ZXN0c1xuICAgIC8vIGlmIChkYXRhKSB7XG4gICAgLy8gICBjb25zdCBwbHVnaW5zRGF0YSA9IGF3YWl0IHRoaXMuc2VydmVyLnBsdWdpbnMuZWxhc3RpY3NlYXJjaC53YWl0VW50aWxSZWFkeSgpO1xuICAgIC8vICAgcmV0dXJuIHBsdWdpbnNEYXRhO1xuICAgIC8vIH1cbiAgICByZXR1cm4gUHJvbWlzZS5yZWplY3QoZGF0YSk7XG4gIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgY29udGV4dC53YXp1aC5sb2dnZXIuZXJyb3IoZXJyb3IubWVzc2FnZSB8fCBlcnJvcik7XG4gICAgcmV0dXJuIFByb21pc2UucmVqZWN0KGVycm9yKTtcbiAgfVxufVxuXG4vKipcbiAqIFRhc2sgdXNlZCBieSB0aGUgY3JvbiBqb2IuXG4gKi9cbmFzeW5jIGZ1bmN0aW9uIGNyb25UYXNrKGNvbnRleHQpIHtcbiAgdHJ5IHtcbiAgICBjb25zdCB0ZW1wbGF0ZU1vbml0b3JpbmcgPVxuICAgICAgYXdhaXQgY29udGV4dC5jb3JlLm9wZW5zZWFyY2guY2xpZW50LmFzSW50ZXJuYWxVc2VyLmluZGljZXMuZ2V0VGVtcGxhdGUoe1xuICAgICAgICBuYW1lOiBXQVpVSF9NT05JVE9SSU5HX1RFTVBMQVRFX05BTUUsXG4gICAgICB9KTtcblxuICAgIGNvbnN0IGFwaUhvc3RzID0gYXdhaXQgY29udGV4dC53YXp1aF9jb3JlLm1hbmFnZUhvc3RzLmdldEVudHJpZXMoe1xuICAgICAgZXhjbHVkZVBhc3N3b3JkOiB0cnVlLFxuICAgIH0pO1xuXG4gICAgaWYgKCFhcGlIb3N0cy5sZW5ndGgpIHtcbiAgICAgIGNvbnRleHQud2F6dWgubG9nZ2VyLndhcm4oJ1RoZXJlIGFyZSBubyBBUEkgaG9zdCBlbnRyaWVzLiBTa2lwLicpO1xuICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICBjb25zdCBhcGlIb3N0c1VuaXF1ZSA9IChhcGlIb3N0cyB8fCBbXSkuZmlsdGVyKFxuICAgICAgKGFwaUhvc3QsIGluZGV4LCBzZWxmKSA9PlxuICAgICAgICBpbmRleCA9PT1cbiAgICAgICAgc2VsZi5maW5kSW5kZXgoXG4gICAgICAgICAgdCA9PlxuICAgICAgICAgICAgdC51c2VyID09PSBhcGlIb3N0LnVzZXIgJiZcbiAgICAgICAgICAgIHQucGFzc3dvcmQgPT09IGFwaUhvc3QucGFzc3dvcmQgJiZcbiAgICAgICAgICAgIHQudXJsID09PSBhcGlIb3N0LnVybCAmJlxuICAgICAgICAgICAgdC5wb3J0ID09PSBhcGlIb3N0LnBvcnQsXG4gICAgICAgICksXG4gICAgKTtcbiAgICBmb3IgKGxldCBhcGlIb3N0IG9mIGFwaUhvc3RzVW5pcXVlKSB7XG4gICAgICB0cnkge1xuICAgICAgICBjb25zdCB7IGFnZW50cywgYXBpSG9zdDogaG9zdCB9ID0gYXdhaXQgZ2V0QXBpSW5mbyhjb250ZXh0LCBhcGlIb3N0KTtcbiAgICAgICAgYXdhaXQgaW5zZXJ0TW9uaXRvcmluZ0RhdGFFbGFzdGljc2VhcmNoKGNvbnRleHQsIHtcbiAgICAgICAgICBhZ2VudHMsXG4gICAgICAgICAgYXBpSG9zdDogaG9zdCxcbiAgICAgICAgfSk7XG4gICAgICB9IGNhdGNoIChlcnJvcikge31cbiAgICB9XG4gIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgLy8gUmV0cnkgdG8gY2FsbCBpdHNlbGYgYWdhaW4gaWYgS2liYW5hIGluZGV4IGlzIG5vdCByZWFkeSB5ZXRcbiAgICAvLyB0cnkge1xuICAgIC8vICAgaWYgKFxuICAgIC8vICAgICB0aGlzLnd6V3JhcHBlci5idWlsZGluZ0tpYmFuYUluZGV4IHx8XG4gICAgLy8gICAgICgoZXJyb3IgfHwge30pLnN0YXR1cyA9PT0gNDA0ICYmXG4gICAgLy8gICAgICAgKGVycm9yIHx8IHt9KS5kaXNwbGF5TmFtZSA9PT0gJ05vdEZvdW5kJylcbiAgICAvLyAgICkge1xuICAgIC8vICAgICBhd2FpdCBkZWxheUFzUHJvbWlzZSgxMDAwKTtcbiAgICAvLyAgICAgcmV0dXJuIGNyb25UYXNrKGNvbnRleHQpO1xuICAgIC8vICAgfVxuICAgIC8vIH0gY2F0Y2ggKGVycm9yKSB7fSAvL2VzbGludC1kaXNhYmxlLWxpbmVcbiAgICBjb250ZXh0LndhenVoLmxvZ2dlci5lcnJvcihlcnJvci5tZXNzYWdlIHx8IGVycm9yKTtcbiAgfVxufVxuXG4vKipcbiAqIEdldCBBUEkgYW5kIGFnZW50cyBpbmZvXG4gKiBAcGFyYW0gY29udGV4dFxuICogQHBhcmFtIGFwaUhvc3RcbiAqL1xuYXN5bmMgZnVuY3Rpb24gZ2V0QXBpSW5mbyhjb250ZXh0LCBhcGlIb3N0KSB7XG4gIHRyeSB7XG4gICAgY29udGV4dC53YXp1aC5sb2dnZXIuZGVidWcoYEdldHRpbmcgQVBJIGluZm8gZm9yICR7YXBpSG9zdC5pZH1gKTtcbiAgICBjb25zdCByZXNwb25zZUlzQ2x1c3RlciA9XG4gICAgICBhd2FpdCBjb250ZXh0LndhenVoLmFwaS5jbGllbnQuYXNJbnRlcm5hbFVzZXIucmVxdWVzdChcbiAgICAgICAgJ0dFVCcsXG4gICAgICAgICcvY2x1c3Rlci9zdGF0dXMnLFxuICAgICAgICB7fSxcbiAgICAgICAgeyBhcGlIb3N0SUQ6IGFwaUhvc3QuaWQgfSxcbiAgICAgICk7XG4gICAgY29uc3QgaXNDbHVzdGVyID1cbiAgICAgICgoKHJlc3BvbnNlSXNDbHVzdGVyIHx8IHt9KS5kYXRhIHx8IHt9KS5kYXRhIHx8IHt9KS5lbmFibGVkID09PSAneWVzJztcbiAgICBpZiAoaXNDbHVzdGVyKSB7XG4gICAgICBjb25zdCByZXNwb25zZUNsdXN0ZXJJbmZvID1cbiAgICAgICAgYXdhaXQgY29udGV4dC53YXp1aC5hcGkuY2xpZW50LmFzSW50ZXJuYWxVc2VyLnJlcXVlc3QoXG4gICAgICAgICAgJ0dFVCcsXG4gICAgICAgICAgYC9jbHVzdGVyL2xvY2FsL2luZm9gLFxuICAgICAgICAgIHt9LFxuICAgICAgICAgIHsgYXBpSG9zdElEOiBhcGlIb3N0LmlkIH0sXG4gICAgICAgICk7XG4gICAgICBhcGlIb3N0LmNsdXN0ZXJOYW1lID1cbiAgICAgICAgcmVzcG9uc2VDbHVzdGVySW5mby5kYXRhLmRhdGEuYWZmZWN0ZWRfaXRlbXNbMF0uY2x1c3RlcjtcbiAgICB9XG4gICAgY29uc3QgYWdlbnRzID0gYXdhaXQgZmV0Y2hBbGxBZ2VudHNGcm9tQXBpSG9zdChjb250ZXh0LCBhcGlIb3N0KTtcbiAgICByZXR1cm4geyBhZ2VudHMsIGFwaUhvc3QgfTtcbiAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICBjb250ZXh0LndhenVoLmxvZ2dlci5lcnJvcihlcnJvci5tZXNzYWdlIHx8IGVycm9yKTtcbiAgICB0aHJvdyBlcnJvcjtcbiAgfVxufVxuXG4vKipcbiAqIEZldGNoIGFsbCBhZ2VudHMgZm9yIHRoZSBBUEkgcHJvdmlkZWRcbiAqIEBwYXJhbSBjb250ZXh0XG4gKiBAcGFyYW0gYXBpSG9zdFxuICovXG5hc3luYyBmdW5jdGlvbiBmZXRjaEFsbEFnZW50c0Zyb21BcGlIb3N0KGNvbnRleHQsIGFwaUhvc3QpIHtcbiAgbGV0IGFnZW50cyA9IFtdO1xuICB0cnkge1xuICAgIGNvbnRleHQud2F6dWgubG9nZ2VyLmRlYnVnKGBHZXR0aW5nIGFsbCBhZ2VudHMgZnJvbSBBcGlJRDogJHthcGlIb3N0LmlkfWApO1xuICAgIGNvbnN0IHJlc3BvbnNlQWdlbnRzQ291bnQgPVxuICAgICAgYXdhaXQgY29udGV4dC53YXp1aC5hcGkuY2xpZW50LmFzSW50ZXJuYWxVc2VyLnJlcXVlc3QoXG4gICAgICAgICdHRVQnLFxuICAgICAgICAnL2FnZW50cycsXG4gICAgICAgIHtcbiAgICAgICAgICBwYXJhbXM6IHtcbiAgICAgICAgICAgIG9mZnNldDogMCxcbiAgICAgICAgICAgIGxpbWl0OiAxLFxuICAgICAgICAgICAgcTogJ2lkIT0wMDAnLFxuICAgICAgICAgIH0sXG4gICAgICAgIH0sXG4gICAgICAgIHsgYXBpSG9zdElEOiBhcGlIb3N0LmlkIH0sXG4gICAgICApO1xuXG4gICAgY29uc3QgYWdlbnRzQ291bnQgPSByZXNwb25zZUFnZW50c0NvdW50LmRhdGEuZGF0YS50b3RhbF9hZmZlY3RlZF9pdGVtcztcbiAgICBjb250ZXh0LndhenVoLmxvZ2dlci5kZWJ1ZyhcbiAgICAgIGBBcGlJRDogJHthcGlIb3N0LmlkfSwgQWdlbnQgY291bnQ6ICR7YWdlbnRzQ291bnR9YCxcbiAgICApO1xuXG4gICAgbGV0IHBheWxvYWQgPSB7XG4gICAgICBvZmZzZXQ6IDAsXG4gICAgICBsaW1pdDogNTAwLFxuICAgICAgcTogJ2lkIT0wMDAnLFxuICAgIH07XG5cbiAgICB3aGlsZSAoYWdlbnRzLmxlbmd0aCA8IGFnZW50c0NvdW50ICYmIHBheWxvYWQub2Zmc2V0IDwgYWdlbnRzQ291bnQpIHtcbiAgICAgIHRyeSB7XG4gICAgICAgIC8qXG4gICAgICAgIFRPRE86IEltcHJvdmUgdGhlIHBlcmZvcm1hbmNlIG9mIHJlcXVlc3Qgd2l0aDpcbiAgICAgICAgICAtIFJlZHVjZSB0aGUgbnVtYmVyIG9mIHJlcXVlc3RzIHRvIHRoZSBXYXp1aCBBUElcbiAgICAgICAgICAtIFJlZHVjZSAoaWYgcG9zc2libGUpIHRoZSBxdWFudGl0eSBvZiBkYXRhIHRvIGluZGV4IGJ5IGRvY3VtZW50XG5cbiAgICAgICAgUmVxdWlyZW1lbnRzOlxuICAgICAgICAgIC0gUmVzZWFyY2ggYWJvdXQgdGhlIG5lY2Vzc2FyeSBkYXRhIHRvIGluZGV4LlxuXG4gICAgICAgIEhvdyB0byBkbzpcbiAgICAgICAgICAtIFdhenVoIEFQSSByZXF1ZXN0OlxuICAgICAgICAgICAgLSBzZWxlY3QgdGhlIHJlcXVpcmVkIGRhdGEgdG8gcmV0cmlldmUgZGVwZW5kaW5nIG9uIGlzIHJlcXVpcmVkIHRvIGluZGV4ICh1c2luZyB0aGUgYHNlbGVjdGAgcXVlcnkgcGFyYW0pXG4gICAgICAgICAgICAtIGluY3JlYXNlIHRoZSBsaW1pdCBvZiByZXN1bHRzIHRvIHJldHJpZXZlIChjdXJyZW50bHksIHRoZSByZXF1ZXN0cyB1c2UgdGhlIHJlY29tbWVuZGVkIHZhbHVlOiA1MDApLlxuICAgICAgICAgICAgICBTZWUgdGhlIGFsbG93ZWQgdmFsdWVzLiBUaGlzIGRlcGVuZHMgb24gdGhlIHNlbGVjdGVkIGRhdGEgYmVjYXVzZSB0aGUgcmVzcG9uc2UgY291bGQgZmFpbCBpZiBjb250YWlucyBhIGxvdCBvZiBkYXRhXG4gICAgICAgICovXG4gICAgICAgIGNvbnN0IHJlc3BvbnNlQWdlbnRzID1cbiAgICAgICAgICBhd2FpdCBjb250ZXh0LndhenVoLmFwaS5jbGllbnQuYXNJbnRlcm5hbFVzZXIucmVxdWVzdChcbiAgICAgICAgICAgICdHRVQnLFxuICAgICAgICAgICAgYC9hZ2VudHNgLFxuICAgICAgICAgICAgeyBwYXJhbXM6IHBheWxvYWQgfSxcbiAgICAgICAgICAgIHsgYXBpSG9zdElEOiBhcGlIb3N0LmlkIH0sXG4gICAgICAgICAgKTtcbiAgICAgICAgYWdlbnRzID0gWy4uLmFnZW50cywgLi4ucmVzcG9uc2VBZ2VudHMuZGF0YS5kYXRhLmFmZmVjdGVkX2l0ZW1zXTtcbiAgICAgICAgcGF5bG9hZC5vZmZzZXQgKz0gcGF5bG9hZC5saW1pdDtcbiAgICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICAgIGNvbnRleHQud2F6dWgubG9nZ2VyLmVycm9yKFxuICAgICAgICAgIGBBcGlJRDogJHthcGlIb3N0LmlkfSwgRXJyb3IgcmVxdWVzdCB3aXRoIG9mZnNldC9saW1pdCAke1xuICAgICAgICAgICAgcGF5bG9hZC5vZmZzZXRcbiAgICAgICAgICB9LyR7cGF5bG9hZC5saW1pdH06ICR7ZXJyb3IubWVzc2FnZSB8fCBlcnJvcn1gLFxuICAgICAgICApO1xuICAgICAgICB0aHJvdyBlcnJvcjtcbiAgICAgIH1cbiAgICB9XG4gICAgcmV0dXJuIGFnZW50cztcbiAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICBjb250ZXh0LndhenVoLmxvZ2dlci5lcnJvcihcbiAgICAgIGBBcGlJRDogJHthcGlIb3N0LmlkfS4gRXJyb3I6ICR7ZXJyb3IubWVzc2FnZSB8fCBlcnJvcn1gLFxuICAgICk7XG4gICAgdGhyb3cgZXJyb3I7XG4gIH1cbn1cblxuLyoqXG4gKiBTdGFydCB0aGUgY3JvbiBqb2JcbiAqL1xuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGpvYk1vbml0b3JpbmdSdW4oY29udGV4dCkge1xuICBjb250ZXh0LndhenVoLmxvZ2dlci5kZWJ1ZygnVGFzazpNb25pdG9yaW5nIGluaXRpYWxpemluZycpO1xuICAvLyBJbml0IHRoZSBtb25pdG9yaW5nIHZhcmlhYmxlc1xuICBhd2FpdCBpbml0TW9uaXRvcmluZ0NvbmZpZ3VyYXRpb24oY29udGV4dCk7XG4gIC8vIENoZWNrIEtpYmFuYSBpbmRleCBhbmQgaWYgaXQgaXMgcHJlcGFyZWQsIHN0YXJ0IHRoZSBpbml0aWFsaXphdGlvbiBvZiBXYXp1aCBBcHAuXG4gIGF3YWl0IGNoZWNrUGx1Z2luUGxhdGZvcm1TdGF0dXMoY29udGV4dCk7XG4gIC8vIC8vIFJ1biB0aGUgY3JvbiBqb2Igb25seSBpdCBpdCdzIGVuYWJsZWRcbiAgaWYgKE1PTklUT1JJTkdfRU5BQkxFRCkge1xuICAgIGNyb25UYXNrKGNvbnRleHQpO1xuICAgIGNyb24uc2NoZWR1bGUoTU9OSVRPUklOR19DUk9OX0ZSRVEsICgpID0+IGNyb25UYXNrKGNvbnRleHQpKTtcbiAgfVxufVxuIl0sIm1hcHBpbmdzIjoiOzs7Ozs7QUFXQSxJQUFBQSxTQUFBLEdBQUFDLHNCQUFBLENBQUFDLE9BQUE7QUFDQSxJQUFBQyxtQkFBQSxHQUFBRCxPQUFBO0FBQ0EsSUFBQUUsVUFBQSxHQUFBRixPQUFBO0FBQ0EsSUFBQUcsVUFBQSxHQUFBSCxPQUFBO0FBQ0EsSUFBQUksVUFBQSxHQUFBSixPQUFBO0FBSUEsSUFBQUssZ0NBQUEsR0FBQUwsT0FBQTtBQUNBLElBQUFNLE1BQUEsR0FBQU4sT0FBQTtBQUF1RCxTQUFBRCx1QkFBQVEsQ0FBQSxXQUFBQSxDQUFBLElBQUFBLENBQUEsQ0FBQUMsVUFBQSxHQUFBRCxDQUFBLEtBQUFFLE9BQUEsRUFBQUYsQ0FBQTtBQXBCdkQ7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFZQSxJQUFJRyxrQkFBa0IsRUFDcEJDLG9CQUFvQixFQUNwQkMsb0JBQW9CLEVBQ3BCQyxtQkFBbUIsRUFDbkJDLHdCQUF3QixFQUN4QkMsdUJBQXVCOztBQUV6QjtBQUNBO0FBQ0E7QUFDQTtBQUNBLGVBQWVDLDJCQUEyQkEsQ0FBQ0MsT0FBTyxFQUFFO0VBQ2xELElBQUk7SUFDRkEsT0FBTyxDQUFDQyxLQUFLLENBQUNDLE1BQU0sQ0FBQ0MsS0FBSyxDQUFDLHVCQUF1QixDQUFDO0lBQ25ELE1BQU1DLFNBQVMsR0FBRyxNQUFNSixPQUFPLENBQUNLLFVBQVUsQ0FBQ0MsYUFBYSxDQUFDQyxHQUFHLENBQUMsQ0FBQztJQUM5RGQsa0JBQWtCLEdBQ2ZXLFNBQVMsQ0FBQywwQkFBMEIsQ0FBQyxJQUNwQ0EsU0FBUyxDQUFDLDBCQUEwQixDQUFDLEtBQUssUUFBUSxJQUNwREEsU0FBUyxDQUFDLDBCQUEwQixDQUFDO0lBQ3ZDVixvQkFBb0IsR0FBR1UsU0FBUyxDQUFDLDRCQUE0QixDQUFDO0lBQzlELElBQUk7TUFDRlQsb0JBQW9CLEdBQUcsSUFBQWEsb0JBQVMsRUFBQ2Qsb0JBQW9CLENBQUM7SUFDeEQsQ0FBQyxDQUFDLE9BQU9lLEtBQUssRUFBRTtNQUNkVCxPQUFPLENBQUNDLEtBQUssQ0FBQ0MsTUFBTSxDQUFDUSxJQUFJLENBQ3RCLHVCQUFzQkMsNkNBQW1DLFlBQ3hERixLQUFLLENBQUNHLE9BQU8sSUFBSUgsS0FDbEIsRUFDSCxDQUFDO01BQ0RkLG9CQUFvQixHQUFHZ0IsNkNBQWtDO0lBQzNEO0lBQ0FmLG1CQUFtQixHQUFHUSxTQUFTLENBQUMsMkJBQTJCLENBQUM7SUFFNURQLHdCQUF3QixHQUFHTyxTQUFTLENBQUMsMEJBQTBCLENBQUM7SUFFaEUsTUFBTVMsb0JBQW9CLEdBQ3hCaEIsd0JBQXdCLENBQUNBLHdCQUF3QixDQUFDaUIsTUFBTSxHQUFHLENBQUMsQ0FBQztJQUMvRCxJQUFJRCxvQkFBb0IsS0FBSyxHQUFHLEVBQUU7TUFDaENoQix3QkFBd0IsSUFBSSxHQUFHO0lBQ2pDO0lBQ0FDLHVCQUF1QixHQUFHRCx3QkFBd0IsQ0FBQ2tCLEtBQUssQ0FDdEQsQ0FBQyxFQUNEbEIsd0JBQXdCLENBQUNpQixNQUFNLEdBQUcsQ0FDcEMsQ0FBQztJQUVEZCxPQUFPLENBQUNDLEtBQUssQ0FBQ0MsTUFBTSxDQUFDQyxLQUFLLENBQ3ZCLDZCQUE0QlYsa0JBQW1CLEVBQ2xELENBQUM7SUFFRE8sT0FBTyxDQUFDQyxLQUFLLENBQUNDLE1BQU0sQ0FBQ0MsS0FBSyxDQUN2QiwrQkFBOEJULG9CQUFxQixLQUFJQyxvQkFBcUIsR0FDL0UsQ0FBQztJQUVESyxPQUFPLENBQUNDLEtBQUssQ0FBQ0MsTUFBTSxDQUFDQyxLQUFLLENBQ3ZCLDhCQUE2QlAsbUJBQW9CLEVBQ3BELENBQUM7SUFFREksT0FBTyxDQUFDQyxLQUFLLENBQUNDLE1BQU0sQ0FBQ0MsS0FBSyxDQUN2Qiw2QkFBNEJOLHdCQUF5QixtQkFBa0JDLHVCQUF3QixHQUNsRyxDQUFDO0VBQ0gsQ0FBQyxDQUFDLE9BQU9XLEtBQUssRUFBRTtJQUNkVCxPQUFPLENBQUNDLEtBQUssQ0FBQ0MsTUFBTSxDQUFDTyxLQUFLLENBQUNBLEtBQUssQ0FBQ0csT0FBTyxDQUFDO0VBQzNDO0FBQ0Y7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQSxlQUFlSSxJQUFJQSxDQUFDaEIsT0FBTyxFQUFFO0VBQzNCLElBQUk7SUFDRixJQUFJUCxrQkFBa0IsRUFBRTtNQUN0QixNQUFNd0IsYUFBYSxDQUFDakIsT0FBTyxDQUFDO0lBQzlCO0VBQ0YsQ0FBQyxDQUFDLE9BQU9TLEtBQUssRUFBRTtJQUNkLE1BQU1TLFlBQVksR0FBR1QsS0FBSyxDQUFDRyxPQUFPLElBQUlILEtBQUs7SUFDM0NULE9BQU8sQ0FBQ0MsS0FBSyxDQUFDQyxNQUFNLENBQUNPLEtBQUssQ0FBQ1MsWUFBWSxDQUFDO0VBQzFDO0FBQ0Y7O0FBRUE7QUFDQTtBQUNBO0FBQ0EsZUFBZUQsYUFBYUEsQ0FBQ2pCLE9BQU8sRUFBRTtFQUNwQyxJQUFJO0lBQ0YsSUFBSTtNQUNGQSxPQUFPLENBQUNDLEtBQUssQ0FBQ0MsTUFBTSxDQUFDQyxLQUFLLENBQ3ZCLGVBQWNnQix5Q0FBK0IsV0FDaEQsQ0FBQztNQUNEO01BQ0EsTUFBTUMsZUFBZSxHQUNuQixNQUFNcEIsT0FBTyxDQUFDcUIsSUFBSSxDQUFDQyxVQUFVLENBQUNDLE1BQU0sQ0FBQ0MsY0FBYyxDQUFDQyxPQUFPLENBQUNDLFdBQVcsQ0FDckU7UUFDRUMsSUFBSSxFQUFFUjtNQUNSLENBQ0YsQ0FBQztNQUNIO01BQ0FTLHNDQUFrQixDQUFDQyxjQUFjLEdBQy9CVCxlQUFlLENBQUNVLElBQUksQ0FBQ1gseUNBQThCLENBQUMsQ0FBQ1UsY0FBYztJQUN2RSxDQUFDLENBQUMsT0FBT3BCLEtBQUssRUFBRTtNQUNkO01BQ0FtQixzQ0FBa0IsQ0FBQ0MsY0FBYyxHQUFHLENBQ2xDLE1BQU03QixPQUFPLENBQUNLLFVBQVUsQ0FBQ0MsYUFBYSxDQUFDQyxHQUFHLENBQUMsMEJBQTBCLENBQUMsQ0FDdkU7SUFDSDs7SUFFQTtJQUNBLElBQUksQ0FBQ3FCLHNDQUFrQixDQUFDQyxjQUFjLENBQUNFLFFBQVEsQ0FBQ2xDLHdCQUF3QixDQUFDLEVBQUU7TUFDekUrQixzQ0FBa0IsQ0FBQ0MsY0FBYyxDQUFDRyxJQUFJLENBQUNuQyx3QkFBd0IsQ0FBQztJQUNsRTs7SUFFQTtJQUNBRyxPQUFPLENBQUNDLEtBQUssQ0FBQ0MsTUFBTSxDQUFDQyxLQUFLLENBQ3ZCLGdCQUFlZ0IseUNBQStCLFdBQ2pELENBQUM7SUFDRCxNQUFNbkIsT0FBTyxDQUFDcUIsSUFBSSxDQUFDQyxVQUFVLENBQUNDLE1BQU0sQ0FBQ0MsY0FBYyxDQUFDQyxPQUFPLENBQUNRLFdBQVcsQ0FBQztNQUN0RU4sSUFBSSxFQUFFUix5Q0FBOEI7TUFDcENXLElBQUksRUFBRUY7SUFDUixDQUFDLENBQUM7SUFDRjVCLE9BQU8sQ0FBQ0MsS0FBSyxDQUFDQyxNQUFNLENBQUNnQyxJQUFJLENBQ3RCLGVBQWNmLHlDQUErQixXQUNoRCxDQUFDO0VBQ0gsQ0FBQyxDQUFDLE9BQU9WLEtBQUssRUFBRTtJQUNkLE1BQU1TLFlBQVksR0FBSSxxQ0FBb0NDLHlDQUErQixhQUN2RlYsS0FBSyxDQUFDRyxPQUFPLElBQUlILEtBQ2xCLEVBQUM7SUFDRlQsT0FBTyxDQUFDQyxLQUFLLENBQUNDLE1BQU0sQ0FBQ08sS0FBSyxDQUFDUyxZQUFZLENBQUM7SUFDeEMsTUFBTVQsS0FBSztFQUNiO0FBQ0Y7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGVBQWUwQixpQ0FBaUNBLENBQUNuQyxPQUFPLEVBQUVvQyxJQUFJLEVBQUU7RUFDOUQsTUFBTUMsbUJBQW1CLEdBQ3ZCdkMsdUJBQXVCLEdBQUcsSUFBQXdDLG9CQUFTLEVBQUMxQyxtQkFBbUIsQ0FBQztFQUMxRCxJQUFJLENBQUNILGtCQUFrQixFQUFFO0lBQ3ZCO0VBQ0Y7RUFDQSxJQUFJO0lBQ0YsTUFBTSxJQUFBOEMsZ0VBQStCLEVBQUNGLG1CQUFtQixDQUFDLENBQUMsWUFBWTtNQUNyRXJDLE9BQU8sQ0FBQ0MsS0FBSyxDQUFDQyxNQUFNLENBQUNDLEtBQUssQ0FDdkIsNkJBQTRCa0MsbUJBQW9CLFFBQ25ELENBQUM7TUFDRCxNQUFNRyxNQUFNLEdBQ1YsTUFBTXhDLE9BQU8sQ0FBQ3FCLElBQUksQ0FBQ0MsVUFBVSxDQUFDQyxNQUFNLENBQUNDLGNBQWMsQ0FBQ0MsT0FBTyxDQUFDZSxNQUFNLENBQUM7UUFDakVDLEtBQUssRUFBRUo7TUFDVCxDQUFDLENBQUM7TUFDSixJQUFJLENBQUNHLE1BQU0sQ0FBQ1YsSUFBSSxFQUFFO1FBQ2hCOUIsT0FBTyxDQUFDQyxLQUFLLENBQUNDLE1BQU0sQ0FBQ0MsS0FBSyxDQUN2QixPQUFNa0MsbUJBQW9CLHVCQUM3QixDQUFDO1FBQ0QsTUFBTUssV0FBVyxDQUFDMUMsT0FBTyxFQUFFcUMsbUJBQW1CLENBQUM7TUFDakQsQ0FBQyxNQUFNO1FBQ0xyQyxPQUFPLENBQUNDLEtBQUssQ0FBQ0MsTUFBTSxDQUFDQyxLQUFLLENBQUUsT0FBTWtDLG1CQUFvQixlQUFjLENBQUM7TUFDdkU7O01BRUE7TUFDQSxNQUFNakMsU0FBUyxHQUFHLE1BQU1KLE9BQU8sQ0FBQ0ssVUFBVSxDQUFDQyxhQUFhLENBQUNDLEdBQUcsQ0FDMUQseUJBQXlCLEVBQ3pCLDJCQUNGLENBQUM7TUFFRCxNQUFNb0Msa0JBQWtCLEdBQUc7UUFDekJDLFFBQVEsRUFBRTtVQUNSSCxLQUFLLEVBQUU7WUFDTEksZ0JBQWdCLEVBQUV6QyxTQUFTLENBQUMseUJBQXlCLENBQUM7WUFDdEQwQyxrQkFBa0IsRUFBRTFDLFNBQVMsQ0FBQywyQkFBMkI7VUFDM0Q7UUFDRjtNQUNGLENBQUM7O01BRUQ7TUFDQTtNQUNBLE9BQU91QyxrQkFBa0IsQ0FBQ0MsUUFBUSxDQUFDSCxLQUFLLENBQUNJLGdCQUFnQjtNQUN6RDdDLE9BQU8sQ0FBQ0MsS0FBSyxDQUFDQyxNQUFNLENBQUNDLEtBQUssQ0FDdkIsc0JBQXFCa0MsbUJBQW9CLFFBQzVDLENBQUM7TUFDRCxNQUFNckMsT0FBTyxDQUFDcUIsSUFBSSxDQUFDQyxVQUFVLENBQUNDLE1BQU0sQ0FBQ0MsY0FBYyxDQUFDQyxPQUFPLENBQUNzQixXQUFXLENBQUM7UUFDdEVOLEtBQUssRUFBRUosbUJBQW1CO1FBQzFCUCxJQUFJLEVBQUVhO01BQ1IsQ0FBQyxDQUFDO01BRUYzQyxPQUFPLENBQUNDLEtBQUssQ0FBQ0MsTUFBTSxDQUFDZ0MsSUFBSSxDQUN0QixxQkFBb0JHLG1CQUFvQixRQUMzQyxDQUFDOztNQUVEO01BQ0EsTUFBTVcsaUJBQWlCLENBQUNoRCxPQUFPLEVBQUVxQyxtQkFBbUIsRUFBRUQsSUFBSSxDQUFDO0lBQzdELENBQUMsQ0FBQyxDQUFDLENBQUM7RUFDTixDQUFDLENBQUMsT0FBTzNCLEtBQUssRUFBRTtJQUNkVCxPQUFPLENBQUNDLEtBQUssQ0FBQ0MsTUFBTSxDQUFDTyxLQUFLLENBQUNBLEtBQUssQ0FBQ0csT0FBTyxJQUFJSCxLQUFLLENBQUM7RUFDcEQ7QUFDRjs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxlQUFldUMsaUJBQWlCQSxDQUM5QmhELE9BQU8sRUFDUGlELFNBQWlCLEVBQ2pCYixJQUFnQyxFQUNoQztFQUNBLE1BQU07SUFBRWMsTUFBTTtJQUFFQztFQUFRLENBQUMsR0FBR2YsSUFBSTtFQUNoQyxJQUFJO0lBQ0YsSUFBSWMsTUFBTSxDQUFDcEMsTUFBTSxHQUFHLENBQUMsRUFBRTtNQUNyQmQsT0FBTyxDQUFDQyxLQUFLLENBQUNDLE1BQU0sQ0FBQ0MsS0FBSyxDQUN2QixzQkFBcUI4QyxTQUFVLFFBQU9DLE1BQU0sQ0FBQ3BDLE1BQU8sU0FDdkQsQ0FBQztNQUVELE1BQU1zQyxRQUFRLEdBQUdGLE1BQU0sQ0FDcEJHLEdBQUcsQ0FBQ0MsS0FBSyxJQUFJO1FBQ1osTUFBTUMsU0FBUyxHQUFHO1VBQUUsR0FBR0Q7UUFBTSxDQUFDO1FBQzlCQyxTQUFTLENBQUMsV0FBVyxDQUFDLEdBQUcsSUFBSUMsSUFBSSxDQUFDQSxJQUFJLENBQUNDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQ0MsV0FBVyxDQUFDLENBQUM7UUFDM0RILFNBQVMsQ0FBQ0ksSUFBSSxHQUFHTCxLQUFLLENBQUNNLE9BQU87UUFDOUJMLFNBQVMsQ0FBQ00sT0FBTyxHQUFHO1VBQ2xCbEMsSUFBSSxFQUFFd0IsT0FBTyxDQUFDVyxXQUFXLEdBQUdYLE9BQU8sQ0FBQ1csV0FBVyxHQUFHO1FBQ3BELENBQUM7UUFDRCxPQUFRLDRCQUEyQmIsU0FBVSxVQUFTYyxJQUFJLENBQUNDLFNBQVMsQ0FDbEVULFNBQ0YsQ0FBRSxJQUFHO01BQ1AsQ0FBQyxDQUFDLENBQ0RVLElBQUksQ0FBQyxFQUFFLENBQUM7TUFFWCxNQUFNakUsT0FBTyxDQUFDcUIsSUFBSSxDQUFDQyxVQUFVLENBQUNDLE1BQU0sQ0FBQ0MsY0FBYyxDQUFDMEMsSUFBSSxDQUFDO1FBQ3ZEekIsS0FBSyxFQUFFUSxTQUFTO1FBQ2hCbkIsSUFBSSxFQUFFc0I7TUFDUixDQUFDLENBQUM7TUFDRnBELE9BQU8sQ0FBQ0MsS0FBSyxDQUFDQyxNQUFNLENBQUNnQyxJQUFJLENBQ3RCLHNCQUFxQmUsU0FBVSxRQUFPQyxNQUFNLENBQUNwQyxNQUFPLG1CQUN2RCxDQUFDO0lBQ0g7RUFDRixDQUFDLENBQUMsT0FBT0wsS0FBSyxFQUFFO0lBQ2RULE9BQU8sQ0FBQ0MsS0FBSyxDQUFDQyxNQUFNLENBQUNPLEtBQUssQ0FDdkIsNkVBQ0NBLEtBQUssQ0FBQ0csT0FBTyxJQUFJSCxLQUNsQixFQUNILENBQUM7RUFDSDtBQUNGOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxlQUFlaUMsV0FBV0EsQ0FBQzFDLE9BQU8sRUFBRWlELFNBQWlCLEVBQUU7RUFDckQsSUFBSTtJQUNGLElBQUksQ0FBQ3hELGtCQUFrQixFQUFFO0lBQ3pCLE1BQU1XLFNBQVMsR0FBRyxNQUFNSixPQUFPLENBQUNLLFVBQVUsQ0FBQ0MsYUFBYSxDQUFDQyxHQUFHLENBQzFELHlCQUF5QixFQUN6QiwyQkFDRixDQUFDO0lBRUQsTUFBTTRELGtCQUFrQixHQUFHO01BQ3pCdkIsUUFBUSxFQUFFO1FBQ1JILEtBQUssRUFBRTtVQUNMSSxnQkFBZ0IsRUFBRXpDLFNBQVMsQ0FBQyx5QkFBeUIsQ0FBQztVQUN0RDBDLGtCQUFrQixFQUFFMUMsU0FBUyxDQUFDLDJCQUEyQjtRQUMzRDtNQUNGO0lBQ0YsQ0FBQztJQUVESixPQUFPLENBQUNDLEtBQUssQ0FBQ0MsTUFBTSxDQUFDQyxLQUFLLENBQUUsWUFBVzhDLFNBQVUsUUFBTyxDQUFDO0lBRXpELE1BQU1qRCxPQUFPLENBQUNxQixJQUFJLENBQUNDLFVBQVUsQ0FBQ0MsTUFBTSxDQUFDQyxjQUFjLENBQUNDLE9BQU8sQ0FBQzJDLE1BQU0sQ0FBQztNQUNqRTNCLEtBQUssRUFBRVEsU0FBUztNQUNoQm5CLElBQUksRUFBRXFDO0lBQ1IsQ0FBQyxDQUFDO0lBRUZuRSxPQUFPLENBQUNDLEtBQUssQ0FBQ0MsTUFBTSxDQUFDZ0MsSUFBSSxDQUFFLEdBQUVlLFNBQVUsZ0JBQWUsQ0FBQztFQUN6RCxDQUFDLENBQUMsT0FBT3hDLEtBQUssRUFBRTtJQUNkVCxPQUFPLENBQUNDLEtBQUssQ0FBQ0MsTUFBTSxDQUFDTyxLQUFLLENBQ3ZCLG9CQUFtQndDLFNBQVUsV0FBVXhDLEtBQUssQ0FBQ0csT0FBTyxJQUFJSCxLQUFNLEVBQ2pFLENBQUM7RUFDSDtBQUNGOztBQUVBO0FBQ0E7QUFDQTtBQUNBLGVBQWU0RCx5QkFBeUJBLENBQUNyRSxPQUFPLEVBQUU7RUFDaEQsSUFBSTtJQUNGQSxPQUFPLENBQUNDLEtBQUssQ0FBQ0MsTUFBTSxDQUFDQyxLQUFLLENBQUMsNkNBQTZDLENBQUM7SUFFekUsTUFBTW1FLHdCQUF3QixDQUFDdEUsT0FBTyxDQUFDO0lBQ3ZDLE1BQU1nQixJQUFJLENBQUNoQixPQUFPLENBQUM7RUFDckIsQ0FBQyxDQUFDLE9BQU9TLEtBQUssRUFBRTtJQUNkVCxPQUFPLENBQUNDLEtBQUssQ0FBQ0MsTUFBTSxDQUFDTyxLQUFLLENBQUNBLEtBQUssQ0FBQ0csT0FBTyxJQUFJSCxLQUFLLENBQUM7SUFDbEQsSUFBSTtNQUNGLE1BQU0sSUFBQThELHFCQUFjLEVBQUMsSUFBSSxDQUFDO01BQzFCLE1BQU1GLHlCQUF5QixDQUFDckUsT0FBTyxDQUFDO0lBQzFDLENBQUMsQ0FBQyxPQUFPUyxLQUFLLEVBQUUsQ0FBQztFQUNuQjtBQUNGOztBQUVBO0FBQ0E7QUFDQTtBQUNBLGVBQWU2RCx3QkFBd0JBLENBQUN0RSxPQUFPLEVBQUU7RUFDL0MsSUFBSTtJQUNGQSxPQUFPLENBQUNDLEtBQUssQ0FBQ0MsTUFBTSxDQUFDQyxLQUFLLENBQ3ZCLDZCQUE0QkgsT0FBTyxDQUFDd0UsTUFBTSxDQUFDQyxNQUFNLENBQUNDLG9CQUFvQixDQUFDakMsS0FBTSxRQUNoRixDQUFDO0lBQ0QsTUFBTUwsSUFBSSxHQUNSLE1BQU1wQyxPQUFPLENBQUNxQixJQUFJLENBQUNDLFVBQVUsQ0FBQ0MsTUFBTSxDQUFDQyxjQUFjLENBQUNDLE9BQU8sQ0FBQ2UsTUFBTSxDQUFDO01BQ2pFQyxLQUFLLEVBQUV6QyxPQUFPLENBQUN3RSxNQUFNLENBQUNDLE1BQU0sQ0FBQ0Msb0JBQW9CLENBQUNqQztJQUNwRCxDQUFDLENBQUM7SUFFSixPQUFPTCxJQUFJLENBQUNOLElBQUk7SUFDaEI7SUFDQTtJQUNBO0lBQ0E7SUFDQTtJQUNBLE9BQU82QyxPQUFPLENBQUNDLE1BQU0sQ0FBQ3hDLElBQUksQ0FBQztFQUM3QixDQUFDLENBQUMsT0FBTzNCLEtBQUssRUFBRTtJQUNkVCxPQUFPLENBQUNDLEtBQUssQ0FBQ0MsTUFBTSxDQUFDTyxLQUFLLENBQUNBLEtBQUssQ0FBQ0csT0FBTyxJQUFJSCxLQUFLLENBQUM7SUFDbEQsT0FBT2tFLE9BQU8sQ0FBQ0MsTUFBTSxDQUFDbkUsS0FBSyxDQUFDO0VBQzlCO0FBQ0Y7O0FBRUE7QUFDQTtBQUNBO0FBQ0EsZUFBZW9FLFFBQVFBLENBQUM3RSxPQUFPLEVBQUU7RUFDL0IsSUFBSTtJQUNGLE1BQU04RSxrQkFBa0IsR0FDdEIsTUFBTTlFLE9BQU8sQ0FBQ3FCLElBQUksQ0FBQ0MsVUFBVSxDQUFDQyxNQUFNLENBQUNDLGNBQWMsQ0FBQ0MsT0FBTyxDQUFDQyxXQUFXLENBQUM7TUFDdEVDLElBQUksRUFBRVI7SUFDUixDQUFDLENBQUM7SUFFSixNQUFNNEQsUUFBUSxHQUFHLE1BQU0vRSxPQUFPLENBQUNLLFVBQVUsQ0FBQzJFLFdBQVcsQ0FBQ0MsVUFBVSxDQUFDO01BQy9EQyxlQUFlLEVBQUU7SUFDbkIsQ0FBQyxDQUFDO0lBRUYsSUFBSSxDQUFDSCxRQUFRLENBQUNqRSxNQUFNLEVBQUU7TUFDcEJkLE9BQU8sQ0FBQ0MsS0FBSyxDQUFDQyxNQUFNLENBQUNRLElBQUksQ0FBQyxzQ0FBc0MsQ0FBQztNQUNqRTtJQUNGO0lBQ0EsTUFBTXlFLGNBQWMsR0FBRyxDQUFDSixRQUFRLElBQUksRUFBRSxFQUFFSyxNQUFNLENBQzVDLENBQUNqQyxPQUFPLEVBQUVWLEtBQUssRUFBRTRDLElBQUksS0FDbkI1QyxLQUFLLEtBQ0w0QyxJQUFJLENBQUNDLFNBQVMsQ0FDWkMsQ0FBQyxJQUNDQSxDQUFDLENBQUNDLElBQUksS0FBS3JDLE9BQU8sQ0FBQ3FDLElBQUksSUFDdkJELENBQUMsQ0FBQ0UsUUFBUSxLQUFLdEMsT0FBTyxDQUFDc0MsUUFBUSxJQUMvQkYsQ0FBQyxDQUFDRyxHQUFHLEtBQUt2QyxPQUFPLENBQUN1QyxHQUFHLElBQ3JCSCxDQUFDLENBQUNJLElBQUksS0FBS3hDLE9BQU8sQ0FBQ3dDLElBQ3ZCLENBQ0osQ0FBQztJQUNELEtBQUssSUFBSXhDLE9BQU8sSUFBSWdDLGNBQWMsRUFBRTtNQUNsQyxJQUFJO1FBQ0YsTUFBTTtVQUFFakMsTUFBTTtVQUFFQyxPQUFPLEVBQUVRO1FBQUssQ0FBQyxHQUFHLE1BQU1pQyxVQUFVLENBQUM1RixPQUFPLEVBQUVtRCxPQUFPLENBQUM7UUFDcEUsTUFBTWhCLGlDQUFpQyxDQUFDbkMsT0FBTyxFQUFFO1VBQy9Da0QsTUFBTTtVQUNOQyxPQUFPLEVBQUVRO1FBQ1gsQ0FBQyxDQUFDO01BQ0osQ0FBQyxDQUFDLE9BQU9sRCxLQUFLLEVBQUUsQ0FBQztJQUNuQjtFQUNGLENBQUMsQ0FBQyxPQUFPQSxLQUFLLEVBQUU7SUFDZDtJQUNBO0lBQ0E7SUFDQTtJQUNBO0lBQ0E7SUFDQTtJQUNBO0lBQ0E7SUFDQTtJQUNBO0lBQ0FULE9BQU8sQ0FBQ0MsS0FBSyxDQUFDQyxNQUFNLENBQUNPLEtBQUssQ0FBQ0EsS0FBSyxDQUFDRyxPQUFPLElBQUlILEtBQUssQ0FBQztFQUNwRDtBQUNGOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxlQUFlbUYsVUFBVUEsQ0FBQzVGLE9BQU8sRUFBRW1ELE9BQU8sRUFBRTtFQUMxQyxJQUFJO0lBQ0ZuRCxPQUFPLENBQUNDLEtBQUssQ0FBQ0MsTUFBTSxDQUFDQyxLQUFLLENBQUUsd0JBQXVCZ0QsT0FBTyxDQUFDMEMsRUFBRyxFQUFDLENBQUM7SUFDaEUsTUFBTUMsaUJBQWlCLEdBQ3JCLE1BQU05RixPQUFPLENBQUNDLEtBQUssQ0FBQzhGLEdBQUcsQ0FBQ3hFLE1BQU0sQ0FBQ0MsY0FBYyxDQUFDd0UsT0FBTyxDQUNuRCxLQUFLLEVBQ0wsaUJBQWlCLEVBQ2pCLENBQUMsQ0FBQyxFQUNGO01BQUVDLFNBQVMsRUFBRTlDLE9BQU8sQ0FBQzBDO0lBQUcsQ0FDMUIsQ0FBQztJQUNILE1BQU1LLFNBQVMsR0FDYixDQUFDLENBQUMsQ0FBQ0osaUJBQWlCLElBQUksQ0FBQyxDQUFDLEVBQUUxRCxJQUFJLElBQUksQ0FBQyxDQUFDLEVBQUVBLElBQUksSUFBSSxDQUFDLENBQUMsRUFBRStELE9BQU8sS0FBSyxLQUFLO0lBQ3ZFLElBQUlELFNBQVMsRUFBRTtNQUNiLE1BQU1FLG1CQUFtQixHQUN2QixNQUFNcEcsT0FBTyxDQUFDQyxLQUFLLENBQUM4RixHQUFHLENBQUN4RSxNQUFNLENBQUNDLGNBQWMsQ0FBQ3dFLE9BQU8sQ0FDbkQsS0FBSyxFQUNKLHFCQUFvQixFQUNyQixDQUFDLENBQUMsRUFDRjtRQUFFQyxTQUFTLEVBQUU5QyxPQUFPLENBQUMwQztNQUFHLENBQzFCLENBQUM7TUFDSDFDLE9BQU8sQ0FBQ1csV0FBVyxHQUNqQnNDLG1CQUFtQixDQUFDaEUsSUFBSSxDQUFDQSxJQUFJLENBQUNpRSxjQUFjLENBQUMsQ0FBQyxDQUFDLENBQUN4QyxPQUFPO0lBQzNEO0lBQ0EsTUFBTVgsTUFBTSxHQUFHLE1BQU1vRCx5QkFBeUIsQ0FBQ3RHLE9BQU8sRUFBRW1ELE9BQU8sQ0FBQztJQUNoRSxPQUFPO01BQUVELE1BQU07TUFBRUM7SUFBUSxDQUFDO0VBQzVCLENBQUMsQ0FBQyxPQUFPMUMsS0FBSyxFQUFFO0lBQ2RULE9BQU8sQ0FBQ0MsS0FBSyxDQUFDQyxNQUFNLENBQUNPLEtBQUssQ0FBQ0EsS0FBSyxDQUFDRyxPQUFPLElBQUlILEtBQUssQ0FBQztJQUNsRCxNQUFNQSxLQUFLO0VBQ2I7QUFDRjs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsZUFBZTZGLHlCQUF5QkEsQ0FBQ3RHLE9BQU8sRUFBRW1ELE9BQU8sRUFBRTtFQUN6RCxJQUFJRCxNQUFNLEdBQUcsRUFBRTtFQUNmLElBQUk7SUFDRmxELE9BQU8sQ0FBQ0MsS0FBSyxDQUFDQyxNQUFNLENBQUNDLEtBQUssQ0FBRSxrQ0FBaUNnRCxPQUFPLENBQUMwQyxFQUFHLEVBQUMsQ0FBQztJQUMxRSxNQUFNVSxtQkFBbUIsR0FDdkIsTUFBTXZHLE9BQU8sQ0FBQ0MsS0FBSyxDQUFDOEYsR0FBRyxDQUFDeEUsTUFBTSxDQUFDQyxjQUFjLENBQUN3RSxPQUFPLENBQ25ELEtBQUssRUFDTCxTQUFTLEVBQ1Q7TUFDRVEsTUFBTSxFQUFFO1FBQ05DLE1BQU0sRUFBRSxDQUFDO1FBQ1RDLEtBQUssRUFBRSxDQUFDO1FBQ1JDLENBQUMsRUFBRTtNQUNMO0lBQ0YsQ0FBQyxFQUNEO01BQUVWLFNBQVMsRUFBRTlDLE9BQU8sQ0FBQzBDO0lBQUcsQ0FDMUIsQ0FBQztJQUVILE1BQU1lLFdBQVcsR0FBR0wsbUJBQW1CLENBQUNuRSxJQUFJLENBQUNBLElBQUksQ0FBQ3lFLG9CQUFvQjtJQUN0RTdHLE9BQU8sQ0FBQ0MsS0FBSyxDQUFDQyxNQUFNLENBQUNDLEtBQUssQ0FDdkIsVUFBU2dELE9BQU8sQ0FBQzBDLEVBQUcsa0JBQWlCZSxXQUFZLEVBQ3BELENBQUM7SUFFRCxJQUFJRSxPQUFPLEdBQUc7TUFDWkwsTUFBTSxFQUFFLENBQUM7TUFDVEMsS0FBSyxFQUFFLEdBQUc7TUFDVkMsQ0FBQyxFQUFFO0lBQ0wsQ0FBQztJQUVELE9BQU96RCxNQUFNLENBQUNwQyxNQUFNLEdBQUc4RixXQUFXLElBQUlFLE9BQU8sQ0FBQ0wsTUFBTSxHQUFHRyxXQUFXLEVBQUU7TUFDbEUsSUFBSTtRQUNGO0FBQ1I7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtRQUdRLE1BQU1HLGNBQWMsR0FDbEIsTUFBTS9HLE9BQU8sQ0FBQ0MsS0FBSyxDQUFDOEYsR0FBRyxDQUFDeEUsTUFBTSxDQUFDQyxjQUFjLENBQUN3RSxPQUFPLENBQ25ELEtBQUssRUFDSixTQUFRLEVBQ1Q7VUFBRVEsTUFBTSxFQUFFTTtRQUFRLENBQUMsRUFDbkI7VUFBRWIsU0FBUyxFQUFFOUMsT0FBTyxDQUFDMEM7UUFBRyxDQUMxQixDQUFDO1FBQ0gzQyxNQUFNLEdBQUcsQ0FBQyxHQUFHQSxNQUFNLEVBQUUsR0FBRzZELGNBQWMsQ0FBQzNFLElBQUksQ0FBQ0EsSUFBSSxDQUFDaUUsY0FBYyxDQUFDO1FBQ2hFUyxPQUFPLENBQUNMLE1BQU0sSUFBSUssT0FBTyxDQUFDSixLQUFLO01BQ2pDLENBQUMsQ0FBQyxPQUFPakcsS0FBSyxFQUFFO1FBQ2RULE9BQU8sQ0FBQ0MsS0FBSyxDQUFDQyxNQUFNLENBQUNPLEtBQUssQ0FDdkIsVUFBUzBDLE9BQU8sQ0FBQzBDLEVBQUcscUNBQ25CaUIsT0FBTyxDQUFDTCxNQUNULElBQUdLLE9BQU8sQ0FBQ0osS0FBTSxLQUFJakcsS0FBSyxDQUFDRyxPQUFPLElBQUlILEtBQU0sRUFDL0MsQ0FBQztRQUNELE1BQU1BLEtBQUs7TUFDYjtJQUNGO0lBQ0EsT0FBT3lDLE1BQU07RUFDZixDQUFDLENBQUMsT0FBT3pDLEtBQUssRUFBRTtJQUNkVCxPQUFPLENBQUNDLEtBQUssQ0FBQ0MsTUFBTSxDQUFDTyxLQUFLLENBQ3ZCLFVBQVMwQyxPQUFPLENBQUMwQyxFQUFHLFlBQVdwRixLQUFLLENBQUNHLE9BQU8sSUFBSUgsS0FBTSxFQUN6RCxDQUFDO0lBQ0QsTUFBTUEsS0FBSztFQUNiO0FBQ0Y7O0FBRUE7QUFDQTtBQUNBO0FBQ08sZUFBZXVHLGdCQUFnQkEsQ0FBQ2hILE9BQU8sRUFBRTtFQUM5Q0EsT0FBTyxDQUFDQyxLQUFLLENBQUNDLE1BQU0sQ0FBQ0MsS0FBSyxDQUFDLDhCQUE4QixDQUFDO0VBQzFEO0VBQ0EsTUFBTUosMkJBQTJCLENBQUNDLE9BQU8sQ0FBQztFQUMxQztFQUNBLE1BQU1xRSx5QkFBeUIsQ0FBQ3JFLE9BQU8sQ0FBQztFQUN4QztFQUNBLElBQUlQLGtCQUFrQixFQUFFO0lBQ3RCb0YsUUFBUSxDQUFDN0UsT0FBTyxDQUFDO0lBQ2pCaUgsaUJBQUksQ0FBQ0MsUUFBUSxDQUFDdkgsb0JBQW9CLEVBQUUsTUFBTWtGLFFBQVEsQ0FBQzdFLE9BQU8sQ0FBQyxDQUFDO0VBQzlEO0FBQ0YifQ==