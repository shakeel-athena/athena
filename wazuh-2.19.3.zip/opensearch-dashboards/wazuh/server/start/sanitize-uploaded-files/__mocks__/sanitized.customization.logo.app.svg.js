"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;
var _default = exports.default = `<svg xml:space="preserve" style="enable-background:new 0 0 100 100;" viewBox="0 0 100 100" height="100px" width="100px" y="0px" x="0px" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns="http://www.w3.org/2000/svg" id="Layer_1" version="1.1">\n\n  <circle id="foo" fill="green" r="45" cy="50" cx="50"></circle>\n\n  \n\n</svg>\n`;
module.exports = exports.default;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJtb2R1bGUiLCJleHBvcnRzIiwiZGVmYXVsdCJdLCJzb3VyY2VzIjpbInNhbml0aXplZC5jdXN0b21pemF0aW9uLmxvZ28uYXBwLnN2Zy50cyJdLCJzb3VyY2VzQ29udGVudCI6WyJleHBvcnQgZGVmYXVsdCBgPHN2ZyB4bWw6c3BhY2U9XCJwcmVzZXJ2ZVwiIHN0eWxlPVwiZW5hYmxlLWJhY2tncm91bmQ6bmV3IDAgMCAxMDAgMTAwO1wiIHZpZXdCb3g9XCIwIDAgMTAwIDEwMFwiIGhlaWdodD1cIjEwMHB4XCIgd2lkdGg9XCIxMDBweFwiIHk9XCIwcHhcIiB4PVwiMHB4XCIgeG1sbnM6eGxpbms9XCJodHRwOi8vd3d3LnczLm9yZy8xOTk5L3hsaW5rXCIgeG1sbnM9XCJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2Z1wiIGlkPVwiTGF5ZXJfMVwiIHZlcnNpb249XCIxLjFcIj5cXG5cXG4gIDxjaXJjbGUgaWQ9XCJmb29cIiBmaWxsPVwiZ3JlZW5cIiByPVwiNDVcIiBjeT1cIjUwXCIgY3g9XCI1MFwiPjwvY2lyY2xlPlxcblxcbiAgXFxuXFxuPC9zdmc+XFxuYDtcbiJdLCJtYXBwaW5ncyI6Ijs7Ozs7O2lDQUFnQix5VUFBd1U7QUFBQUEsTUFBQSxDQUFBQyxPQUFBLEdBQUFBLE9BQUEsQ0FBQUMsT0FBQSJ9