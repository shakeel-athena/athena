"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.WazuhApiRoutes = WazuhApiRoutes;
var _controllers = require("../controllers");
var _configSchema = require("@osd/config-schema");
function WazuhApiRoutes(router) {
  const ctrl = new _controllers.WazuhApiCtrl();

  // Returns if the wazuh-api configuration is working
  router.post({
    path: '/api/check-stored-api',
    validate: {
      body: _configSchema.schema.object({
        id: _configSchema.schema.string(),
        idChanged: _configSchema.schema.maybe(_configSchema.schema.string())
      })
    }
  }, async (context, request, response) => ctrl.checkStoredAPI(context, request, response));

  // Check if credentials on POST connect to Wazuh API. Not storing them!
  // Returns if the wazuh-api configuration received in the POST body will work
  router.post({
    path: '/api/check-api',
    validate: {
      body: _configSchema.schema.any({
        // TODO: not ready
        //id: schema.string(),
        // url: schema.string(),
        // port: schema.number(),
        // username: schema.string(),
        //forceRefresh: schema.boolean({defaultValue:false}),
        // cluster_info: schema.object({
        //   status: schema.string(),
        //   manager: schema.string(),
        //   node: schema.string(),
        //   cluster: schema.string()
        // }),
        // run_as: schema.boolean(),
        // allow_run_as: schema.number()
      })
    }
  }, async (context, request, response) => ctrl.checkAPI(context, request, response));
  router.post({
    path: '/api/login',
    validate: {
      body: _configSchema.schema.object({
        idHost: _configSchema.schema.string(),
        force: _configSchema.schema.boolean({
          defaultValue: false
        })
      })
    }
  }, async (context, request, response) => ctrl.getToken(context, request, response));

  // Returns the request result (With error control)
  router.post({
    path: '/api/request',
    validate: {
      body: _configSchema.schema.object({
        id: _configSchema.schema.string(),
        method: _configSchema.schema.string(),
        path: _configSchema.schema.string(),
        body: _configSchema.schema.any()
      })
    }
  }, async (context, request, response) => ctrl.requestApi(context, request, response));

  // Returns data from the Wazuh API on CSV readable format
  router.post({
    path: '/api/csv',
    validate: {
      body: _configSchema.schema.object({
        id: _configSchema.schema.string(),
        path: _configSchema.schema.string(),
        filters: _configSchema.schema.maybe(_configSchema.schema.any())
      })
    }
  }, async (context, request, response) => ctrl.csv(context, request, response));

  // Returns a route list used by the Dev Tools
  router.get({
    path: '/api/routes',
    validate: false
  }, async (context, request, response) => ctrl.getRequestList(context, request, response));

  // Return Wazuh Appsetup info
  router.get({
    path: '/api/setup',
    validate: false
  }, async (context, request, response) => ctrl.getSetupInfo(context, request, response));

  // Return app logos configuration
  router.get({
    path: '/api/logos',
    validate: false,
    options: {
      authRequired: false
    }
  }, async (context, request, response) => ctrl.getAppLogos(context, request, response));
}
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfY29udHJvbGxlcnMiLCJyZXF1aXJlIiwiX2NvbmZpZ1NjaGVtYSIsIldhenVoQXBpUm91dGVzIiwicm91dGVyIiwiY3RybCIsIldhenVoQXBpQ3RybCIsInBvc3QiLCJwYXRoIiwidmFsaWRhdGUiLCJib2R5Iiwic2NoZW1hIiwib2JqZWN0IiwiaWQiLCJzdHJpbmciLCJpZENoYW5nZWQiLCJtYXliZSIsImNvbnRleHQiLCJyZXF1ZXN0IiwicmVzcG9uc2UiLCJjaGVja1N0b3JlZEFQSSIsImFueSIsImNoZWNrQVBJIiwiaWRIb3N0IiwiZm9yY2UiLCJib29sZWFuIiwiZGVmYXVsdFZhbHVlIiwiZ2V0VG9rZW4iLCJtZXRob2QiLCJyZXF1ZXN0QXBpIiwiZmlsdGVycyIsImNzdiIsImdldCIsImdldFJlcXVlc3RMaXN0IiwiZ2V0U2V0dXBJbmZvIiwib3B0aW9ucyIsImF1dGhSZXF1aXJlZCIsImdldEFwcExvZ29zIl0sInNvdXJjZXMiOlsid2F6dWgtYXBpLnRzIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IElSb3V0ZXIgfSBmcm9tICdvcGVuc2VhcmNoX2Rhc2hib2FyZHMvc2VydmVyJztcbmltcG9ydCB7IFdhenVoQXBpQ3RybCB9IGZyb20gJy4uL2NvbnRyb2xsZXJzJztcbmltcG9ydCB7IHNjaGVtYSB9IGZyb20gJ0Bvc2QvY29uZmlnLXNjaGVtYSc7XG5cbmV4cG9ydCBmdW5jdGlvbiBXYXp1aEFwaVJvdXRlcyhyb3V0ZXI6IElSb3V0ZXIpIHtcbiAgY29uc3QgY3RybCA9IG5ldyBXYXp1aEFwaUN0cmwoKTtcblxuICAvLyBSZXR1cm5zIGlmIHRoZSB3YXp1aC1hcGkgY29uZmlndXJhdGlvbiBpcyB3b3JraW5nXG4gIHJvdXRlci5wb3N0KFxuICAgIHtcbiAgICAgIHBhdGg6ICcvYXBpL2NoZWNrLXN0b3JlZC1hcGknLFxuICAgICAgdmFsaWRhdGU6IHtcbiAgICAgICAgYm9keTogc2NoZW1hLm9iamVjdCh7XG4gICAgICAgICAgaWQ6IHNjaGVtYS5zdHJpbmcoKSxcbiAgICAgICAgICBpZENoYW5nZWQ6IHNjaGVtYS5tYXliZShzY2hlbWEuc3RyaW5nKCkpLFxuICAgICAgICB9KSxcbiAgICAgIH0sXG4gICAgfSxcbiAgICBhc3luYyAoY29udGV4dCwgcmVxdWVzdCwgcmVzcG9uc2UpID0+XG4gICAgICBjdHJsLmNoZWNrU3RvcmVkQVBJKGNvbnRleHQsIHJlcXVlc3QsIHJlc3BvbnNlKSxcbiAgKTtcblxuICAvLyBDaGVjayBpZiBjcmVkZW50aWFscyBvbiBQT1NUIGNvbm5lY3QgdG8gV2F6dWggQVBJLiBOb3Qgc3RvcmluZyB0aGVtIVxuICAvLyBSZXR1cm5zIGlmIHRoZSB3YXp1aC1hcGkgY29uZmlndXJhdGlvbiByZWNlaXZlZCBpbiB0aGUgUE9TVCBib2R5IHdpbGwgd29ya1xuICByb3V0ZXIucG9zdChcbiAgICB7XG4gICAgICBwYXRoOiAnL2FwaS9jaGVjay1hcGknLFxuICAgICAgdmFsaWRhdGU6IHtcbiAgICAgICAgYm9keTogc2NoZW1hLmFueSh7XG4gICAgICAgICAgLy8gVE9ETzogbm90IHJlYWR5XG4gICAgICAgICAgLy9pZDogc2NoZW1hLnN0cmluZygpLFxuICAgICAgICAgIC8vIHVybDogc2NoZW1hLnN0cmluZygpLFxuICAgICAgICAgIC8vIHBvcnQ6IHNjaGVtYS5udW1iZXIoKSxcbiAgICAgICAgICAvLyB1c2VybmFtZTogc2NoZW1hLnN0cmluZygpLFxuICAgICAgICAgIC8vZm9yY2VSZWZyZXNoOiBzY2hlbWEuYm9vbGVhbih7ZGVmYXVsdFZhbHVlOmZhbHNlfSksXG4gICAgICAgICAgLy8gY2x1c3Rlcl9pbmZvOiBzY2hlbWEub2JqZWN0KHtcbiAgICAgICAgICAvLyAgIHN0YXR1czogc2NoZW1hLnN0cmluZygpLFxuICAgICAgICAgIC8vICAgbWFuYWdlcjogc2NoZW1hLnN0cmluZygpLFxuICAgICAgICAgIC8vICAgbm9kZTogc2NoZW1hLnN0cmluZygpLFxuICAgICAgICAgIC8vICAgY2x1c3Rlcjogc2NoZW1hLnN0cmluZygpXG4gICAgICAgICAgLy8gfSksXG4gICAgICAgICAgLy8gcnVuX2FzOiBzY2hlbWEuYm9vbGVhbigpLFxuICAgICAgICAgIC8vIGFsbG93X3J1bl9hczogc2NoZW1hLm51bWJlcigpXG4gICAgICAgIH0pLFxuICAgICAgfSxcbiAgICB9LFxuICAgIGFzeW5jIChjb250ZXh0LCByZXF1ZXN0LCByZXNwb25zZSkgPT5cbiAgICAgIGN0cmwuY2hlY2tBUEkoY29udGV4dCwgcmVxdWVzdCwgcmVzcG9uc2UpLFxuICApO1xuXG4gIHJvdXRlci5wb3N0KFxuICAgIHtcbiAgICAgIHBhdGg6ICcvYXBpL2xvZ2luJyxcbiAgICAgIHZhbGlkYXRlOiB7XG4gICAgICAgIGJvZHk6IHNjaGVtYS5vYmplY3Qoe1xuICAgICAgICAgIGlkSG9zdDogc2NoZW1hLnN0cmluZygpLFxuICAgICAgICAgIGZvcmNlOiBzY2hlbWEuYm9vbGVhbih7IGRlZmF1bHRWYWx1ZTogZmFsc2UgfSksXG4gICAgICAgIH0pLFxuICAgICAgfSxcbiAgICB9LFxuICAgIGFzeW5jIChjb250ZXh0LCByZXF1ZXN0LCByZXNwb25zZSkgPT5cbiAgICAgIGN0cmwuZ2V0VG9rZW4oY29udGV4dCwgcmVxdWVzdCwgcmVzcG9uc2UpLFxuICApO1xuXG4gIC8vIFJldHVybnMgdGhlIHJlcXVlc3QgcmVzdWx0IChXaXRoIGVycm9yIGNvbnRyb2wpXG4gIHJvdXRlci5wb3N0KFxuICAgIHtcbiAgICAgIHBhdGg6ICcvYXBpL3JlcXVlc3QnLFxuICAgICAgdmFsaWRhdGU6IHtcbiAgICAgICAgYm9keTogc2NoZW1hLm9iamVjdCh7XG4gICAgICAgICAgaWQ6IHNjaGVtYS5zdHJpbmcoKSxcbiAgICAgICAgICBtZXRob2Q6IHNjaGVtYS5zdHJpbmcoKSxcbiAgICAgICAgICBwYXRoOiBzY2hlbWEuc3RyaW5nKCksXG4gICAgICAgICAgYm9keTogc2NoZW1hLmFueSgpLFxuICAgICAgICB9KSxcbiAgICAgIH0sXG4gICAgfSxcbiAgICBhc3luYyAoY29udGV4dCwgcmVxdWVzdCwgcmVzcG9uc2UpID0+XG4gICAgICBjdHJsLnJlcXVlc3RBcGkoY29udGV4dCwgcmVxdWVzdCwgcmVzcG9uc2UpLFxuICApO1xuXG4gIC8vIFJldHVybnMgZGF0YSBmcm9tIHRoZSBXYXp1aCBBUEkgb24gQ1NWIHJlYWRhYmxlIGZvcm1hdFxuICByb3V0ZXIucG9zdChcbiAgICB7XG4gICAgICBwYXRoOiAnL2FwaS9jc3YnLFxuICAgICAgdmFsaWRhdGU6IHtcbiAgICAgICAgYm9keTogc2NoZW1hLm9iamVjdCh7XG4gICAgICAgICAgaWQ6IHNjaGVtYS5zdHJpbmcoKSxcbiAgICAgICAgICBwYXRoOiBzY2hlbWEuc3RyaW5nKCksXG4gICAgICAgICAgZmlsdGVyczogc2NoZW1hLm1heWJlKHNjaGVtYS5hbnkoKSksXG4gICAgICAgIH0pLFxuICAgICAgfSxcbiAgICB9LFxuICAgIGFzeW5jIChjb250ZXh0LCByZXF1ZXN0LCByZXNwb25zZSkgPT4gY3RybC5jc3YoY29udGV4dCwgcmVxdWVzdCwgcmVzcG9uc2UpLFxuICApO1xuXG4gIC8vIFJldHVybnMgYSByb3V0ZSBsaXN0IHVzZWQgYnkgdGhlIERldiBUb29sc1xuICByb3V0ZXIuZ2V0KFxuICAgIHtcbiAgICAgIHBhdGg6ICcvYXBpL3JvdXRlcycsXG4gICAgICB2YWxpZGF0ZTogZmFsc2UsXG4gICAgfSxcbiAgICBhc3luYyAoY29udGV4dCwgcmVxdWVzdCwgcmVzcG9uc2UpID0+XG4gICAgICBjdHJsLmdldFJlcXVlc3RMaXN0KGNvbnRleHQsIHJlcXVlc3QsIHJlc3BvbnNlKSxcbiAgKTtcblxuICAvLyBSZXR1cm4gV2F6dWggQXBwc2V0dXAgaW5mb1xuICByb3V0ZXIuZ2V0KFxuICAgIHtcbiAgICAgIHBhdGg6ICcvYXBpL3NldHVwJyxcbiAgICAgIHZhbGlkYXRlOiBmYWxzZSxcbiAgICB9LFxuICAgIGFzeW5jIChjb250ZXh0LCByZXF1ZXN0LCByZXNwb25zZSkgPT5cbiAgICAgIGN0cmwuZ2V0U2V0dXBJbmZvKGNvbnRleHQsIHJlcXVlc3QsIHJlc3BvbnNlKSxcbiAgKTtcblxuICAvLyBSZXR1cm4gYXBwIGxvZ29zIGNvbmZpZ3VyYXRpb25cbiAgcm91dGVyLmdldChcbiAgICB7XG4gICAgICBwYXRoOiAnL2FwaS9sb2dvcycsXG4gICAgICB2YWxpZGF0ZTogZmFsc2UsXG4gICAgICBvcHRpb25zOiB7IGF1dGhSZXF1aXJlZDogZmFsc2UgfSxcbiAgICB9LFxuICAgIGFzeW5jIChjb250ZXh0LCByZXF1ZXN0LCByZXNwb25zZSkgPT5cbiAgICAgIGN0cmwuZ2V0QXBwTG9nb3MoY29udGV4dCwgcmVxdWVzdCwgcmVzcG9uc2UpLFxuICApO1xufVxuIl0sIm1hcHBpbmdzIjoiOzs7Ozs7QUFDQSxJQUFBQSxZQUFBLEdBQUFDLE9BQUE7QUFDQSxJQUFBQyxhQUFBLEdBQUFELE9BQUE7QUFFTyxTQUFTRSxjQUFjQSxDQUFDQyxNQUFlLEVBQUU7RUFDOUMsTUFBTUMsSUFBSSxHQUFHLElBQUlDLHlCQUFZLENBQUMsQ0FBQzs7RUFFL0I7RUFDQUYsTUFBTSxDQUFDRyxJQUFJLENBQ1Q7SUFDRUMsSUFBSSxFQUFFLHVCQUF1QjtJQUM3QkMsUUFBUSxFQUFFO01BQ1JDLElBQUksRUFBRUMsb0JBQU0sQ0FBQ0MsTUFBTSxDQUFDO1FBQ2xCQyxFQUFFLEVBQUVGLG9CQUFNLENBQUNHLE1BQU0sQ0FBQyxDQUFDO1FBQ25CQyxTQUFTLEVBQUVKLG9CQUFNLENBQUNLLEtBQUssQ0FBQ0wsb0JBQU0sQ0FBQ0csTUFBTSxDQUFDLENBQUM7TUFDekMsQ0FBQztJQUNIO0VBQ0YsQ0FBQyxFQUNELE9BQU9HLE9BQU8sRUFBRUMsT0FBTyxFQUFFQyxRQUFRLEtBQy9CZCxJQUFJLENBQUNlLGNBQWMsQ0FBQ0gsT0FBTyxFQUFFQyxPQUFPLEVBQUVDLFFBQVEsQ0FDbEQsQ0FBQzs7RUFFRDtFQUNBO0VBQ0FmLE1BQU0sQ0FBQ0csSUFBSSxDQUNUO0lBQ0VDLElBQUksRUFBRSxnQkFBZ0I7SUFDdEJDLFFBQVEsRUFBRTtNQUNSQyxJQUFJLEVBQUVDLG9CQUFNLENBQUNVLEdBQUcsQ0FBQztRQUNmO1FBQ0E7UUFDQTtRQUNBO1FBQ0E7UUFDQTtRQUNBO1FBQ0E7UUFDQTtRQUNBO1FBQ0E7UUFDQTtRQUNBO1FBQ0E7TUFBQSxDQUNEO0lBQ0g7RUFDRixDQUFDLEVBQ0QsT0FBT0osT0FBTyxFQUFFQyxPQUFPLEVBQUVDLFFBQVEsS0FDL0JkLElBQUksQ0FBQ2lCLFFBQVEsQ0FBQ0wsT0FBTyxFQUFFQyxPQUFPLEVBQUVDLFFBQVEsQ0FDNUMsQ0FBQztFQUVEZixNQUFNLENBQUNHLElBQUksQ0FDVDtJQUNFQyxJQUFJLEVBQUUsWUFBWTtJQUNsQkMsUUFBUSxFQUFFO01BQ1JDLElBQUksRUFBRUMsb0JBQU0sQ0FBQ0MsTUFBTSxDQUFDO1FBQ2xCVyxNQUFNLEVBQUVaLG9CQUFNLENBQUNHLE1BQU0sQ0FBQyxDQUFDO1FBQ3ZCVSxLQUFLLEVBQUViLG9CQUFNLENBQUNjLE9BQU8sQ0FBQztVQUFFQyxZQUFZLEVBQUU7UUFBTSxDQUFDO01BQy9DLENBQUM7SUFDSDtFQUNGLENBQUMsRUFDRCxPQUFPVCxPQUFPLEVBQUVDLE9BQU8sRUFBRUMsUUFBUSxLQUMvQmQsSUFBSSxDQUFDc0IsUUFBUSxDQUFDVixPQUFPLEVBQUVDLE9BQU8sRUFBRUMsUUFBUSxDQUM1QyxDQUFDOztFQUVEO0VBQ0FmLE1BQU0sQ0FBQ0csSUFBSSxDQUNUO0lBQ0VDLElBQUksRUFBRSxjQUFjO0lBQ3BCQyxRQUFRLEVBQUU7TUFDUkMsSUFBSSxFQUFFQyxvQkFBTSxDQUFDQyxNQUFNLENBQUM7UUFDbEJDLEVBQUUsRUFBRUYsb0JBQU0sQ0FBQ0csTUFBTSxDQUFDLENBQUM7UUFDbkJjLE1BQU0sRUFBRWpCLG9CQUFNLENBQUNHLE1BQU0sQ0FBQyxDQUFDO1FBQ3ZCTixJQUFJLEVBQUVHLG9CQUFNLENBQUNHLE1BQU0sQ0FBQyxDQUFDO1FBQ3JCSixJQUFJLEVBQUVDLG9CQUFNLENBQUNVLEdBQUcsQ0FBQztNQUNuQixDQUFDO0lBQ0g7RUFDRixDQUFDLEVBQ0QsT0FBT0osT0FBTyxFQUFFQyxPQUFPLEVBQUVDLFFBQVEsS0FDL0JkLElBQUksQ0FBQ3dCLFVBQVUsQ0FBQ1osT0FBTyxFQUFFQyxPQUFPLEVBQUVDLFFBQVEsQ0FDOUMsQ0FBQzs7RUFFRDtFQUNBZixNQUFNLENBQUNHLElBQUksQ0FDVDtJQUNFQyxJQUFJLEVBQUUsVUFBVTtJQUNoQkMsUUFBUSxFQUFFO01BQ1JDLElBQUksRUFBRUMsb0JBQU0sQ0FBQ0MsTUFBTSxDQUFDO1FBQ2xCQyxFQUFFLEVBQUVGLG9CQUFNLENBQUNHLE1BQU0sQ0FBQyxDQUFDO1FBQ25CTixJQUFJLEVBQUVHLG9CQUFNLENBQUNHLE1BQU0sQ0FBQyxDQUFDO1FBQ3JCZ0IsT0FBTyxFQUFFbkIsb0JBQU0sQ0FBQ0ssS0FBSyxDQUFDTCxvQkFBTSxDQUFDVSxHQUFHLENBQUMsQ0FBQztNQUNwQyxDQUFDO0lBQ0g7RUFDRixDQUFDLEVBQ0QsT0FBT0osT0FBTyxFQUFFQyxPQUFPLEVBQUVDLFFBQVEsS0FBS2QsSUFBSSxDQUFDMEIsR0FBRyxDQUFDZCxPQUFPLEVBQUVDLE9BQU8sRUFBRUMsUUFBUSxDQUMzRSxDQUFDOztFQUVEO0VBQ0FmLE1BQU0sQ0FBQzRCLEdBQUcsQ0FDUjtJQUNFeEIsSUFBSSxFQUFFLGFBQWE7SUFDbkJDLFFBQVEsRUFBRTtFQUNaLENBQUMsRUFDRCxPQUFPUSxPQUFPLEVBQUVDLE9BQU8sRUFBRUMsUUFBUSxLQUMvQmQsSUFBSSxDQUFDNEIsY0FBYyxDQUFDaEIsT0FBTyxFQUFFQyxPQUFPLEVBQUVDLFFBQVEsQ0FDbEQsQ0FBQzs7RUFFRDtFQUNBZixNQUFNLENBQUM0QixHQUFHLENBQ1I7SUFDRXhCLElBQUksRUFBRSxZQUFZO0lBQ2xCQyxRQUFRLEVBQUU7RUFDWixDQUFDLEVBQ0QsT0FBT1EsT0FBTyxFQUFFQyxPQUFPLEVBQUVDLFFBQVEsS0FDL0JkLElBQUksQ0FBQzZCLFlBQVksQ0FBQ2pCLE9BQU8sRUFBRUMsT0FBTyxFQUFFQyxRQUFRLENBQ2hELENBQUM7O0VBRUQ7RUFDQWYsTUFBTSxDQUFDNEIsR0FBRyxDQUNSO0lBQ0V4QixJQUFJLEVBQUUsWUFBWTtJQUNsQkMsUUFBUSxFQUFFLEtBQUs7SUFDZjBCLE9BQU8sRUFBRTtNQUFFQyxZQUFZLEVBQUU7SUFBTTtFQUNqQyxDQUFDLEVBQ0QsT0FBT25CLE9BQU8sRUFBRUMsT0FBTyxFQUFFQyxRQUFRLEtBQy9CZCxJQUFJLENBQUNnQyxXQUFXLENBQUNwQixPQUFPLEVBQUVDLE9BQU8sRUFBRUMsUUFBUSxDQUMvQyxDQUFDO0FBQ0gifQ==