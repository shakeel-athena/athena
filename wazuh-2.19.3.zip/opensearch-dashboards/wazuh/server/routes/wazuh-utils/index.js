"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
Object.defineProperty(exports, "UiLogsRoutes", {
  enumerable: true,
  get: function () {
    return _uiLogs.UiLogsRoutes;
  }
});
Object.defineProperty(exports, "WazuhUtilsRoutes", {
  enumerable: true,
  get: function () {
    return _wazuhUtils.WazuhUtilsRoutes;
  }
});
var _wazuhUtils = require("./wazuh-utils");
var _uiLogs = require("./ui-logs");
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfd2F6dWhVdGlscyIsInJlcXVpcmUiLCJfdWlMb2dzIl0sInNvdXJjZXMiOlsiaW5kZXgudHMiXSwic291cmNlc0NvbnRlbnQiOlsiZXhwb3J0IHsgV2F6dWhVdGlsc1JvdXRlcyB9IGZyb20gXCIuL3dhenVoLXV0aWxzXCI7XG5leHBvcnQgeyBVaUxvZ3NSb3V0ZXMgfSBmcm9tICcuL3VpLWxvZ3MnOyJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQSxJQUFBQSxXQUFBLEdBQUFDLE9BQUE7QUFDQSxJQUFBQyxPQUFBLEdBQUFELE9BQUEifQ==