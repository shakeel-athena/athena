"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.monitoringTemplate = void 0;
/*
 * Wazuh app - Module for monitoring template
 * Copyright (C) 2015-2022 Wazuh, Inc.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * Find more information about this on the LICENSE file.
 */
const monitoringTemplate = exports.monitoringTemplate = {
  order: 0,
  settings: {
    'index.refresh_interval': '5s'
  },
  mappings: {
    properties: {
      timestamp: {
        type: 'date',
        format: 'dateOptionalTime'
      },
      status: {
        type: 'keyword'
      },
      ip: {
        type: 'keyword'
      },
      host: {
        type: 'keyword'
      },
      name: {
        type: 'keyword'
      },
      id: {
        type: 'keyword'
      },
      cluster: {
        properties: {
          name: {
            type: 'keyword'
          }
        }
      }
    }
  }
};
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJtb25pdG9yaW5nVGVtcGxhdGUiLCJleHBvcnRzIiwib3JkZXIiLCJzZXR0aW5ncyIsIm1hcHBpbmdzIiwicHJvcGVydGllcyIsInRpbWVzdGFtcCIsInR5cGUiLCJmb3JtYXQiLCJzdGF0dXMiLCJpcCIsImhvc3QiLCJuYW1lIiwiaWQiLCJjbHVzdGVyIl0sInNvdXJjZXMiOlsibW9uaXRvcmluZy10ZW1wbGF0ZS50cyJdLCJzb3VyY2VzQ29udGVudCI6WyIvKlxuICogV2F6dWggYXBwIC0gTW9kdWxlIGZvciBtb25pdG9yaW5nIHRlbXBsYXRlXG4gKiBDb3B5cmlnaHQgKEMpIDIwMTUtMjAyMiBXYXp1aCwgSW5jLlxuICpcbiAqIFRoaXMgcHJvZ3JhbSBpcyBmcmVlIHNvZnR3YXJlOyB5b3UgY2FuIHJlZGlzdHJpYnV0ZSBpdCBhbmQvb3IgbW9kaWZ5XG4gKiBpdCB1bmRlciB0aGUgdGVybXMgb2YgdGhlIEdOVSBHZW5lcmFsIFB1YmxpYyBMaWNlbnNlIGFzIHB1Ymxpc2hlZCBieVxuICogdGhlIEZyZWUgU29mdHdhcmUgRm91bmRhdGlvbjsgZWl0aGVyIHZlcnNpb24gMiBvZiB0aGUgTGljZW5zZSwgb3JcbiAqIChhdCB5b3VyIG9wdGlvbikgYW55IGxhdGVyIHZlcnNpb24uXG4gKlxuICogRmluZCBtb3JlIGluZm9ybWF0aW9uIGFib3V0IHRoaXMgb24gdGhlIExJQ0VOU0UgZmlsZS5cbiAqL1xuZXhwb3J0IGNvbnN0IG1vbml0b3JpbmdUZW1wbGF0ZSA9IHtcbiAgb3JkZXI6IDAsXG4gIHNldHRpbmdzOiB7XG4gICAgJ2luZGV4LnJlZnJlc2hfaW50ZXJ2YWwnOiAnNXMnLFxuICB9LFxuICBtYXBwaW5nczoge1xuICAgIHByb3BlcnRpZXM6IHtcbiAgICAgIHRpbWVzdGFtcDoge1xuICAgICAgICB0eXBlOiAnZGF0ZScsXG4gICAgICAgIGZvcm1hdDogJ2RhdGVPcHRpb25hbFRpbWUnLFxuICAgICAgfSxcbiAgICAgIHN0YXR1czoge1xuICAgICAgICB0eXBlOiAna2V5d29yZCcsXG4gICAgICB9LFxuICAgICAgaXA6IHtcbiAgICAgICAgdHlwZTogJ2tleXdvcmQnLFxuICAgICAgfSxcbiAgICAgIGhvc3Q6IHtcbiAgICAgICAgdHlwZTogJ2tleXdvcmQnLFxuICAgICAgfSxcbiAgICAgIG5hbWU6IHtcbiAgICAgICAgdHlwZTogJ2tleXdvcmQnLFxuICAgICAgfSxcbiAgICAgIGlkOiB7XG4gICAgICAgIHR5cGU6ICdrZXl3b3JkJyxcbiAgICAgIH0sXG4gICAgICBjbHVzdGVyOiB7XG4gICAgICAgIHByb3BlcnRpZXM6IHtcbiAgICAgICAgICBuYW1lOiB7XG4gICAgICAgICAgICB0eXBlOiAna2V5d29yZCcsXG4gICAgICAgICAgfSxcbiAgICAgICAgfSxcbiAgICAgIH0sXG4gICAgfSxcbiAgfSxcbn07XG4iXSwibWFwcGluZ3MiOiI7Ozs7OztBQUFBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDTyxNQUFNQSxrQkFBa0IsR0FBQUMsT0FBQSxDQUFBRCxrQkFBQSxHQUFHO0VBQ2hDRSxLQUFLLEVBQUUsQ0FBQztFQUNSQyxRQUFRLEVBQUU7SUFDUix3QkFBd0IsRUFBRTtFQUM1QixDQUFDO0VBQ0RDLFFBQVEsRUFBRTtJQUNSQyxVQUFVLEVBQUU7TUFDVkMsU0FBUyxFQUFFO1FBQ1RDLElBQUksRUFBRSxNQUFNO1FBQ1pDLE1BQU0sRUFBRTtNQUNWLENBQUM7TUFDREMsTUFBTSxFQUFFO1FBQ05GLElBQUksRUFBRTtNQUNSLENBQUM7TUFDREcsRUFBRSxFQUFFO1FBQ0ZILElBQUksRUFBRTtNQUNSLENBQUM7TUFDREksSUFBSSxFQUFFO1FBQ0pKLElBQUksRUFBRTtNQUNSLENBQUM7TUFDREssSUFBSSxFQUFFO1FBQ0pMLElBQUksRUFBRTtNQUNSLENBQUM7TUFDRE0sRUFBRSxFQUFFO1FBQ0ZOLElBQUksRUFBRTtNQUNSLENBQUM7TUFDRE8sT0FBTyxFQUFFO1FBQ1BULFVBQVUsRUFBRTtVQUNWTyxJQUFJLEVBQUU7WUFDSkwsSUFBSSxFQUFFO1VBQ1I7UUFDRjtNQUNGO0lBQ0Y7RUFDRjtBQUNGLENBQUMifQ==