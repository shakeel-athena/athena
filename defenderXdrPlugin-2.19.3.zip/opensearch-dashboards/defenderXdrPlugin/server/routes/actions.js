"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.registerDefenderActionRoutes = registerDefenderActionRoutes;
var _configSchema = require("@osd/config-schema");
var _constants = require("../../common/constants");
var _mdeClient = require("../lib/mde-client");
var _otp = require("../lib/otp");
/*
 * Defender plugin — MDE actions + OTP for response operations
 */

function getUserFromRequest(req) {
  var _req$headers, _req$headers2;
  const user = ((_req$headers = req.headers) === null || _req$headers === void 0 ? void 0 : _req$headers['x-defender-user']) || 'dashboard-user';
  const role = ((_req$headers2 = req.headers) === null || _req$headers2 === void 0 ? void 0 : _req$headers2['x-defender-role']) || 'defender_operator';
  return {
    user,
    role
  };
}
function getOTPConfig() {
  return {
    smtpHost: process.env.SMTP_HOST,
    smtpPort: process.env.SMTP_PORT ? parseInt(process.env.SMTP_PORT, 10) : 587,
    smtpUser: process.env.SMTP_USER,
    smtpPass: process.env.SMTP_PASS,
    otpRecipientEmail: process.env.OTP_RECIPIENT_EMAIL,
    smtpSecure: process.env.SMTP_SECURE === 'true'
  };
}
function otpContext(body) {
  const c = (body.otp_context_id || body.machine_id || '').trim();
  return c;
}
async function writeAuditLog(client, entry) {
  try {
    await client.index({
      index: _constants.DEFENDER_AUDIT_LOG_INDEX,
      body: {
        ...entry,
        timestamp: new Date().toISOString()
      }
    });
  } catch (err) {
    console.error('[Defender] Audit log write failed:', err);
  }
}
const scanTypeSchema = _configSchema.schema.oneOf([_configSchema.schema.literal('Quick'), _configSchema.schema.literal('Full')]);
const isolationTypeSchema = _configSchema.schema.oneOf([_configSchema.schema.literal('Full'), _configSchema.schema.literal('Selective'), _configSchema.schema.literal('UnManagedDevice')]);

/** Machine-scoped actions: OTP + required comment */
const machineActionBody = _configSchema.schema.object({
  machine_id: _configSchema.schema.string(),
  computer_dns_name: _configSchema.schema.maybe(_configSchema.schema.string()),
  comment: _configSchema.schema.string(),
  otp: _configSchema.schema.string(),
  otp_context_id: _configSchema.schema.maybe(_configSchema.schema.string()),
  scan_type: _configSchema.schema.maybe(scanTypeSchema),
  isolation_type: _configSchema.schema.maybe(isolationTypeSchema)
});
function registerDefenderActionRoutes(router) {
  const runMachineAction = (path, actionName, fn) => {
    router.post({
      path,
      validate: {
        body: machineActionBody
      }
    }, async (context, req, res) => {
      const config = (0, _mdeClient.getMdeConfig)();
      if (!config) {
        return res.customError({
          statusCode: 503,
          body: 'Defender credentials not configured.'
        });
      }
      const {
        user,
        role
      } = getUserFromRequest(req);
      const client = context.core.opensearch.client.asCurrentUser;
      const body = req.body;
      const comment = (body.comment || '').trim();
      if (!comment) {
        return res.customError({
          statusCode: 400,
          body: 'Comment is required.'
        });
      }
      const ctx = otpContext(body);
      if (!ctx) {
        return res.customError({
          statusCode: 400,
          body: 'machine_id or otp_context_id required.'
        });
      }
      const otpCheck = (0, _otp.validateOTP)(ctx, actionName, body.otp || '');
      if (!otpCheck.valid) {
        return res.customError({
          statusCode: 400,
          body: otpCheck.reason || 'OTP required'
        });
      }
      const deviceName = body.computer_dns_name || body.machine_id;
      try {
        var _info;
        const result = await fn(config, {
          machine_id: body.machine_id,
          comment,
          scan_type: body.scan_type,
          isolation_type: body.isolation_type
        });
        const message = JSON.stringify(result).slice(0, 2000);
        await writeAuditLog(client, {
          action: actionName,
          machine_id: body.machine_id,
          computer_dns_name: deviceName,
          performed_by: user,
          role,
          status: 'success',
          message,
          source_ip: (_info = req.info) === null || _info === void 0 ? void 0 : _info.remoteAddress,
          otp_verified: true,
          comment
        });
        return res.ok({
          body: {
            success: true,
            action: actionName,
            machine_id: body.machine_id,
            message,
            timestamp: new Date().toISOString()
          }
        });
      } catch (err) {
        var _info2;
        const mdeHttpStatus = err != null && err.status != null ? err.status : null;
        const mdeErrorDetail = err && err.responseText ? String(err.responseText).slice(0, 1000) : null;
        const errorType = err && (err.name || err.constructor && err.constructor.name) || 'Error';
        const errorMessage = err instanceof Error ? err.message : String(err);
        console.error('[Defender Action] ' + actionName + ' failed — type:' + errorType + ' http:' + mdeHttpStatus + ' msg:' + errorMessage);
        await writeAuditLog(client, {
          action: actionName,
          machine_id: body.machine_id,
          computer_dns_name: deviceName,
          performed_by: user,
          role,
          status: 'failure',
          message: errorMessage,
          mde_http_status: mdeHttpStatus,
          mde_error_detail: mdeErrorDetail || errorType,
          source_ip: (_info2 = req.info) === null || _info2 === void 0 ? void 0 : _info2.remoteAddress,
          otp_verified: true,
          comment
        });
        return res.customError({
          statusCode: (0, _mdeClient.mdeErrorStatus)(err),
          body: errorMessage
        });
      }
    });
  };
  runMachineAction('/api/defender_xdr/actions/antivirus-scan', 'antivirus_scan', (cfg, b) => (0, _mdeClient.runAntivirusScan)(cfg, b.machine_id, b.comment, b.scan_type || 'Quick'));
  runMachineAction('/api/defender_xdr/actions/isolate', 'isolate', (cfg, b) => (0, _mdeClient.isolateMachine)(cfg, b.machine_id, b.comment, b.isolation_type || 'Full'));
  runMachineAction('/api/defender_xdr/actions/unisolate', 'unisolate', (cfg, b) => (0, _mdeClient.unisolateMachine)(cfg, b.machine_id, b.comment));
  runMachineAction('/api/defender_xdr/actions/restrict-code-execution', 'restrict_code_execution', (cfg, b) => (0, _mdeClient.restrictCodeExecution)(cfg, b.machine_id, b.comment));
  runMachineAction('/api/defender_xdr/actions/unrestrict-code-execution', 'unrestrict_code_execution', (cfg, b) => (0, _mdeClient.unrestrictCodeExecution)(cfg, b.machine_id, b.comment));
  runMachineAction('/api/defender_xdr/actions/collect-investigation-package', 'collect_investigation_package', (cfg, b) => (0, _mdeClient.collectInvestigationPackage)(cfg, b.machine_id, b.comment));
  runMachineAction('/api/defender_xdr/actions/offboard', 'offboard_machine', (cfg, b) => (0, _mdeClient.offboardMachine)(cfg, b.machine_id, b.comment));
  const stopQuarantineBody = _configSchema.schema.object({
    machine_id: _configSchema.schema.string(),
    computer_dns_name: _configSchema.schema.maybe(_configSchema.schema.string()),
    sha1: _configSchema.schema.string(),
    comment: _configSchema.schema.string(),
    otp: _configSchema.schema.string(),
    otp_context_id: _configSchema.schema.maybe(_configSchema.schema.string())
  });
  router.post({
    path: '/api/defender_xdr/actions/stop-and-quarantine',
    validate: {
      body: stopQuarantineBody
    }
  }, async (context, req, res) => {
    const config = (0, _mdeClient.getMdeConfig)();
    if (!config) {
      return res.customError({
        statusCode: 503,
        body: 'Defender not configured.'
      });
    }
    const {
      user,
      role
    } = getUserFromRequest(req);
    const client = context.core.opensearch.client.asCurrentUser;
    const body = req.body;
    const comment = (body.comment || '').trim();
    if (!comment) {
      return res.customError({
        statusCode: 400,
        body: 'Comment is required.'
      });
    }
    const ctx = otpContext(body);
    if (!ctx) {
      return res.customError({
        statusCode: 400,
        body: 'machine_id or otp_context_id required.'
      });
    }
    const otpCheck = (0, _otp.validateOTP)(ctx, 'stop_and_quarantine', body.otp || '');
    if (!otpCheck.valid) {
      return res.customError({
        statusCode: 400,
        body: otpCheck.reason || 'OTP required'
      });
    }
    const deviceName = body.computer_dns_name || body.machine_id;
    try {
      var _info3;
      const result = await (0, _mdeClient.stopAndQuarantineFile)(config, body.machine_id, comment, body.sha1.trim());
      const message = JSON.stringify(result).slice(0, 2000);
      await writeAuditLog(client, {
        action: 'stop_and_quarantine',
        machine_id: body.machine_id,
        computer_dns_name: deviceName,
        performed_by: user,
        role,
        status: 'success',
        message,
        source_ip: (_info3 = req.info) === null || _info3 === void 0 ? void 0 : _info3.remoteAddress,
        otp_verified: true,
        comment
      });
      return res.ok({
        body: {
          success: true,
          action: 'stop_and_quarantine',
          machine_id: body.machine_id,
          message
        }
      });
    } catch (err) {
      var _info4;
      await writeAuditLog(client, {
        action: 'stop_and_quarantine',
        machine_id: body.machine_id,
        computer_dns_name: deviceName,
        performed_by: user,
        role,
        status: 'failure',
        message: err instanceof Error ? err.message : String(err),
        source_ip: (_info4 = req.info) === null || _info4 === void 0 ? void 0 : _info4.remoteAddress,
        otp_verified: true,
        comment
      });
      return res.customError({
        statusCode: (0, _mdeClient.mdeErrorStatus)(err),
        body: err instanceof Error ? err.message : String(err)
      });
    }
  });
  const cancelActionBody = _configSchema.schema.object({
    action_id: _configSchema.schema.string(),
    machine_id: _configSchema.schema.maybe(_configSchema.schema.string()),
    computer_dns_name: _configSchema.schema.maybe(_configSchema.schema.string()),
    comment: _configSchema.schema.string(),
    otp: _configSchema.schema.string()
  });
  router.post({
    path: '/api/defender_xdr/actions/cancel-machine-action',
    validate: {
      body: cancelActionBody
    }
  }, async (context, req, res) => {
    const config = (0, _mdeClient.getMdeConfig)();
    if (!config) {
      return res.customError({
        statusCode: 503,
        body: 'Defender not configured.'
      });
    }
    const {
      user,
      role
    } = getUserFromRequest(req);
    const client = context.core.opensearch.client.asCurrentUser;
    const body = req.body;
    const comment = (body.comment || '').trim();
    if (!comment) {
      return res.customError({
        statusCode: 400,
        body: 'Comment is required.'
      });
    }
    const otpCheck = (0, _otp.validateOTP)(body.action_id, 'cancel_machine_action', body.otp || '');
    if (!otpCheck.valid) {
      return res.customError({
        statusCode: 400,
        body: otpCheck.reason || 'OTP required'
      });
    }
    const deviceName = body.computer_dns_name || body.machine_id || body.action_id;
    try {
      var _info5;
      const result = await (0, _mdeClient.cancelMachineAction)(config, body.action_id);
      const message = JSON.stringify(result).slice(0, 2000);
      await writeAuditLog(client, {
        action: 'cancel_machine_action',
        machine_id: body.machine_id || body.action_id,
        computer_dns_name: deviceName,
        performed_by: user,
        role,
        status: 'success',
        message,
        source_ip: (_info5 = req.info) === null || _info5 === void 0 ? void 0 : _info5.remoteAddress,
        otp_verified: true,
        comment
      });
      return res.ok({
        body: {
          success: true,
          action: 'cancel_machine_action',
          action_id: body.action_id,
          message
        }
      });
    } catch (err) {
      var _info6;
      await writeAuditLog(client, {
        action: 'cancel_machine_action',
        machine_id: body.machine_id || body.action_id,
        computer_dns_name: deviceName,
        performed_by: user,
        role,
        status: 'failure',
        message: err instanceof Error ? err.message : String(err),
        source_ip: (_info6 = req.info) === null || _info6 === void 0 ? void 0 : _info6.remoteAddress,
        otp_verified: true,
        comment
      });
      return res.customError({
        statusCode: (0, _mdeClient.mdeErrorStatus)(err),
        body: err instanceof Error ? err.message : String(err)
      });
    }
  });
  router.post({
    path: '/api/defender_xdr/actions/request-otp',
    validate: {
      body: _configSchema.schema.object({
        action: _configSchema.schema.string(),
        machine_id: _configSchema.schema.maybe(_configSchema.schema.string()),
        computer_dns_name: _configSchema.schema.maybe(_configSchema.schema.string()),
        otp_context_id: _configSchema.schema.maybe(_configSchema.schema.string())
      })
    }
  }, async (_context, req, res) => {
    const {
      machine_id,
      action,
      computer_dns_name,
      otp_context_id
    } = req.body;
    if (!_constants.DESTRUCTIVE_ACTIONS.includes(action)) {
      return res.customError({
        statusCode: 400,
        body: 'This action does not use this OTP flow.'
      });
    }
    const ctx = (otp_context_id || machine_id || '').trim();
    if (!ctx) {
      return res.customError({
        statusCode: 400,
        body: 'Provide machine_id or otp_context_id (e.g. action id for cancel).'
      });
    }
    const otp = (0, _otp.generateOTP)();
    (0, _otp.storeOTP)(ctx, action, otp);
    const emailResult = await (0, _otp.sendOTPEmail)(getOTPConfig(), otp, computer_dns_name || ctx, action);
    return res.ok({
      body: {
        success: true,
        message: emailResult.sent ? 'OTP sent to configured recipient.' : 'OTP generated (configure SMTP for email delivery).',
        dev_mode: emailResult.devMode,
        otp: emailResult.devMode ? emailResult.otp : undefined
      }
    });
  });
  const indicatorCreateBody = _configSchema.schema.object({
    machine_id: _configSchema.schema.string(),
    computer_dns_name: _configSchema.schema.maybe(_configSchema.schema.string()),
    comment: _configSchema.schema.string(),
    otp: _configSchema.schema.string(),
    otp_context_id: _configSchema.schema.maybe(_configSchema.schema.string()),
    indicator_type: _configSchema.schema.oneOf([_configSchema.schema.literal('FileSha1'), _configSchema.schema.literal('FileSha256'), _configSchema.schema.literal('IpAddress'), _configSchema.schema.literal('DomainName'), _configSchema.schema.literal('Url')]),
    indicator_value: _configSchema.schema.string(),
    title: _configSchema.schema.string(),
    description: _configSchema.schema.maybe(_configSchema.schema.string()),
    expiration_time: _configSchema.schema.maybe(_configSchema.schema.string()),
    action: _configSchema.schema.oneOf([_configSchema.schema.literal('Alert'), _configSchema.schema.literal('AlertAndBlock'), _configSchema.schema.literal('Allowed'), _configSchema.schema.literal('Block'), _configSchema.schema.literal('Audit')]),
    severity: _configSchema.schema.oneOf([_configSchema.schema.literal('Informational'), _configSchema.schema.literal('Low'), _configSchema.schema.literal('Medium'), _configSchema.schema.literal('High')])
  });
  router.post({
    path: '/api/defender_xdr/actions/create-indicator',
    validate: {
      body: indicatorCreateBody
    }
  }, async (context, req, res) => {
    const config = (0, _mdeClient.getMdeConfig)();
    if (!config) {
      return res.customError({
        statusCode: 503,
        body: 'Defender not configured.'
      });
    }
    const {
      user,
      role
    } = getUserFromRequest(req);
    const client = context.core.opensearch.client.asCurrentUser;
    const b = req.body;
    const comment = (b.comment || '').trim();
    if (!comment) {
      return res.customError({
        statusCode: 400,
        body: 'Comment is required.'
      });
    }
    const ctx = otpContext(b);
    if (!ctx) {
      return res.customError({
        statusCode: 400,
        body: 'machine_id or otp_context_id required.'
      });
    }
    const otpCheck = (0, _otp.validateOTP)(ctx, 'create_indicator', b.otp || '');
    if (!otpCheck.valid) {
      return res.customError({
        statusCode: 400,
        body: otpCheck.reason || 'OTP required'
      });
    }
    const deviceName = b.computer_dns_name || b.machine_id;
    try {
      var _info7;
      const payload = {
        indicatorValue: b.indicator_value,
        indicatorType: b.indicator_type,
        title: b.title,
        description: b.description,
        expirationTime: b.expiration_time,
        action: b.action,
        severity: b.severity
      };
      const result = await (0, _mdeClient.createIndicator)(config, payload);
      const message = JSON.stringify(result).slice(0, 2000);
      await writeAuditLog(client, {
        action: 'create_indicator',
        machine_id: b.machine_id,
        computer_dns_name: deviceName,
        performed_by: user,
        role,
        status: 'success',
        message,
        source_ip: (_info7 = req.info) === null || _info7 === void 0 ? void 0 : _info7.remoteAddress,
        otp_verified: true,
        comment
      });
      return res.ok({
        body: {
          success: true,
          action: 'create_indicator',
          machine_id: b.machine_id,
          message,
          timestamp: new Date().toISOString()
        }
      });
    } catch (err) {
      var _info8;
      await writeAuditLog(client, {
        action: 'create_indicator',
        machine_id: b.machine_id,
        computer_dns_name: deviceName,
        performed_by: user,
        role,
        status: 'failure',
        message: err instanceof Error ? err.message : String(err),
        source_ip: (_info8 = req.info) === null || _info8 === void 0 ? void 0 : _info8.remoteAddress,
        otp_verified: true,
        comment
      });
      return res.customError({
        statusCode: (0, _mdeClient.mdeErrorStatus)(err),
        body: err instanceof Error ? err.message : String(err)
      });
    }
  });
  const updateIndicatorBody = _configSchema.schema.object({
    indicator_id: _configSchema.schema.string(),
    machine_id: _configSchema.schema.maybe(_configSchema.schema.string()),
    computer_dns_name: _configSchema.schema.maybe(_configSchema.schema.string()),
    comment: _configSchema.schema.string(),
    otp: _configSchema.schema.string(),
    title: _configSchema.schema.maybe(_configSchema.schema.string()),
    description: _configSchema.schema.maybe(_configSchema.schema.string()),
    action: _configSchema.schema.maybe(_configSchema.schema.oneOf([_configSchema.schema.literal('Alert'), _configSchema.schema.literal('AlertAndBlock'), _configSchema.schema.literal('Allowed'), _configSchema.schema.literal('Block'), _configSchema.schema.literal('Audit')])),
    severity: _configSchema.schema.maybe(_configSchema.schema.oneOf([_configSchema.schema.literal('Informational'), _configSchema.schema.literal('Low'), _configSchema.schema.literal('Medium'), _configSchema.schema.literal('High')])),
    expiration_time: _configSchema.schema.maybe(_configSchema.schema.string())
  });
  router.post({
    path: '/api/defender_xdr/actions/update-indicator',
    validate: {
      body: updateIndicatorBody
    }
  }, async (context, req, res) => {
    const config = (0, _mdeClient.getMdeConfig)();
    if (!config) {
      return res.customError({
        statusCode: 503,
        body: 'Defender not configured.'
      });
    }
    const {
      user,
      role
    } = getUserFromRequest(req);
    const client = context.core.opensearch.client.asCurrentUser;
    const b = req.body;
    const comment = (b.comment || '').trim();
    if (!comment) {
      return res.customError({
        statusCode: 400,
        body: 'Comment is required.'
      });
    }
    const otpCheck = (0, _otp.validateOTP)(b.indicator_id, 'update_indicator', b.otp || '');
    if (!otpCheck.valid) {
      return res.customError({
        statusCode: 400,
        body: otpCheck.reason || 'OTP required'
      });
    }
    const deviceName = b.computer_dns_name || b.machine_id || b.indicator_id;
    const patch = {};
    if (b.title != null) patch.title = b.title;
    if (b.description != null) patch.description = b.description;
    if (b.action != null) patch.action = b.action;
    if (b.severity != null) patch.severity = b.severity;
    if (b.expiration_time != null) patch.expirationTime = b.expiration_time;
    if (Object.keys(patch).length === 0) {
      return res.customError({
        statusCode: 400,
        body: 'Provide at least one field to update.'
      });
    }
    try {
      var _info9;
      const result = await (0, _mdeClient.updateIndicator)(config, b.indicator_id, patch);
      const message = JSON.stringify(result).slice(0, 2000);
      await writeAuditLog(client, {
        action: 'update_indicator',
        machine_id: b.machine_id || b.indicator_id,
        computer_dns_name: deviceName,
        performed_by: user,
        role,
        status: 'success',
        message,
        source_ip: (_info9 = req.info) === null || _info9 === void 0 ? void 0 : _info9.remoteAddress,
        otp_verified: true,
        comment
      });
      return res.ok({
        body: {
          success: true,
          action: 'update_indicator',
          indicator_id: b.indicator_id,
          message,
          timestamp: new Date().toISOString()
        }
      });
    } catch (err) {
      var _info10;
      await writeAuditLog(client, {
        action: 'update_indicator',
        machine_id: b.machine_id || b.indicator_id,
        computer_dns_name: deviceName,
        performed_by: user,
        role,
        status: 'failure',
        message: err instanceof Error ? err.message : String(err),
        source_ip: (_info10 = req.info) === null || _info10 === void 0 ? void 0 : _info10.remoteAddress,
        otp_verified: true,
        comment
      });
      return res.customError({
        statusCode: (0, _mdeClient.mdeErrorStatus)(err),
        body: err instanceof Error ? err.message : String(err)
      });
    }
  });
  router.post({
    path: '/api/defender_xdr/actions/request-otp-indicator',
    validate: {
      body: _configSchema.schema.object({
        machine_id: _configSchema.schema.string(),
        computer_dns_name: _configSchema.schema.maybe(_configSchema.schema.string()),
        otp_context_id: _configSchema.schema.maybe(_configSchema.schema.string())
      })
    }
  }, async (_context, req, res) => {
    const {
      machine_id,
      computer_dns_name,
      otp_context_id
    } = req.body;
    const ctx = (otp_context_id || machine_id).trim();
    const otp = (0, _otp.generateOTP)();
    (0, _otp.storeOTP)(ctx, 'create_indicator', otp);
    const emailResult = await (0, _otp.sendOTPEmail)(getOTPConfig(), otp, computer_dns_name || machine_id, 'create_indicator');
    return res.ok({
      body: {
        success: true,
        message: emailResult.sent ? 'OTP sent.' : 'OTP generated.',
        dev_mode: emailResult.devMode,
        otp: emailResult.devMode ? emailResult.otp : undefined
      }
    });
  });
  const deleteIndicatorBody = _configSchema.schema.object({
    indicator_id: _configSchema.schema.string(),
    machine_id: _configSchema.schema.maybe(_configSchema.schema.string()),
    computer_dns_name: _configSchema.schema.maybe(_configSchema.schema.string()),
    comment: _configSchema.schema.string(),
    otp: _configSchema.schema.string()
  });
  router.post({
    path: '/api/defender_xdr/actions/delete-indicator',
    validate: {
      body: deleteIndicatorBody
    }
  }, async (context, req, res) => {
    const config = (0, _mdeClient.getMdeConfig)();
    if (!config) {
      return res.customError({
        statusCode: 503,
        body: 'Defender not configured.'
      });
    }
    const {
      user,
      role
    } = getUserFromRequest(req);
    const client = context.core.opensearch.client.asCurrentUser;
    const b = req.body;
    const comment = (b.comment || '').trim();
    if (!comment) {
      return res.customError({
        statusCode: 400,
        body: 'Comment is required.'
      });
    }
    const otpCheck = (0, _otp.validateOTP)(b.indicator_id, 'delete_indicator', b.otp || '');
    if (!otpCheck.valid) {
      return res.customError({
        statusCode: 400,
        body: otpCheck.reason || 'OTP required'
      });
    }
    const deviceName = b.computer_dns_name || b.machine_id || b.indicator_id;
    try {
      var _info11;
      const result = await (0, _mdeClient.deleteIndicator)(config, b.indicator_id);
      const message = JSON.stringify(result).slice(0, 2000);
      await writeAuditLog(client, {
        action: 'delete_indicator',
        machine_id: b.machine_id || b.indicator_id,
        computer_dns_name: deviceName,
        performed_by: user,
        role,
        status: 'success',
        message,
        source_ip: (_info11 = req.info) === null || _info11 === void 0 ? void 0 : _info11.remoteAddress,
        otp_verified: true,
        comment
      });
      return res.ok({
        body: {
          success: true,
          action: 'delete_indicator',
          machine_id: b.machine_id || b.indicator_id,
          message,
          timestamp: new Date().toISOString()
        }
      });
    } catch (err) {
      var _info12;
      await writeAuditLog(client, {
        action: 'delete_indicator',
        machine_id: b.machine_id || b.indicator_id,
        computer_dns_name: deviceName,
        performed_by: user,
        role,
        status: 'failure',
        message: err instanceof Error ? err.message : String(err),
        source_ip: (_info12 = req.info) === null || _info12 === void 0 ? void 0 : _info12.remoteAddress,
        otp_verified: true,
        comment
      });
      return res.customError({
        statusCode: (0, _mdeClient.mdeErrorStatus)(err),
        body: err instanceof Error ? err.message : String(err)
      });
    }
  });
  router.post({
    path: '/api/defender_xdr/actions/request-otp-delete-indicator',
    validate: {
      body: _configSchema.schema.object({
        indicator_id: _configSchema.schema.string(),
        computer_dns_name: _configSchema.schema.maybe(_configSchema.schema.string())
      })
    }
  }, async (_context, req, res) => {
    const {
      indicator_id,
      computer_dns_name
    } = req.body;
    const otp = (0, _otp.generateOTP)();
    (0, _otp.storeOTP)(indicator_id, 'delete_indicator', otp);
    const emailResult = await (0, _otp.sendOTPEmail)(getOTPConfig(), otp, computer_dns_name || indicator_id, 'delete_indicator');
    return res.ok({
      body: {
        success: true,
        dev_mode: emailResult.devMode,
        otp: emailResult.devMode ? emailResult.otp : undefined
      }
    });
  });
  router.post({
    path: '/api/defender_xdr/actions/request-otp-update-indicator',
    validate: {
      body: _configSchema.schema.object({
        indicator_id: _configSchema.schema.string(),
        computer_dns_name: _configSchema.schema.maybe(_configSchema.schema.string())
      })
    }
  }, async (_context, req, res) => {
    const {
      indicator_id,
      computer_dns_name
    } = req.body;
    const otp = (0, _otp.generateOTP)();
    (0, _otp.storeOTP)(indicator_id, 'update_indicator', otp);
    const emailResult = await (0, _otp.sendOTPEmail)(getOTPConfig(), otp, computer_dns_name || indicator_id, 'update_indicator');
    return res.ok({
      body: {
        success: true,
        dev_mode: emailResult.devMode,
        otp: emailResult.devMode ? emailResult.otp : undefined
      }
    });
  });
}
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfY29uZmlnU2NoZW1hIiwicmVxdWlyZSIsIl9jb25zdGFudHMiLCJfbWRlQ2xpZW50IiwiX290cCIsImdldFVzZXJGcm9tUmVxdWVzdCIsInJlcSIsIl9yZXEkaGVhZGVycyIsIl9yZXEkaGVhZGVyczIiLCJ1c2VyIiwiaGVhZGVycyIsInJvbGUiLCJnZXRPVFBDb25maWciLCJzbXRwSG9zdCIsInByb2Nlc3MiLCJlbnYiLCJTTVRQX0hPU1QiLCJzbXRwUG9ydCIsIlNNVFBfUE9SVCIsInBhcnNlSW50Iiwic210cFVzZXIiLCJTTVRQX1VTRVIiLCJzbXRwUGFzcyIsIlNNVFBfUEFTUyIsIm90cFJlY2lwaWVudEVtYWlsIiwiT1RQX1JFQ0lQSUVOVF9FTUFJTCIsInNtdHBTZWN1cmUiLCJTTVRQX1NFQ1VSRSIsIm90cENvbnRleHQiLCJib2R5IiwiYyIsIm90cF9jb250ZXh0X2lkIiwibWFjaGluZV9pZCIsInRyaW0iLCJ3cml0ZUF1ZGl0TG9nIiwiY2xpZW50IiwiZW50cnkiLCJpbmRleCIsIkRFRkVOREVSX0FVRElUX0xPR19JTkRFWCIsInRpbWVzdGFtcCIsIkRhdGUiLCJ0b0lTT1N0cmluZyIsImVyciIsImNvbnNvbGUiLCJlcnJvciIsInNjYW5UeXBlU2NoZW1hIiwic2NoZW1hIiwib25lT2YiLCJsaXRlcmFsIiwiaXNvbGF0aW9uVHlwZVNjaGVtYSIsIm1hY2hpbmVBY3Rpb25Cb2R5Iiwib2JqZWN0Iiwic3RyaW5nIiwiY29tcHV0ZXJfZG5zX25hbWUiLCJtYXliZSIsImNvbW1lbnQiLCJvdHAiLCJzY2FuX3R5cGUiLCJpc29sYXRpb25fdHlwZSIsInJlZ2lzdGVyRGVmZW5kZXJBY3Rpb25Sb3V0ZXMiLCJyb3V0ZXIiLCJydW5NYWNoaW5lQWN0aW9uIiwicGF0aCIsImFjdGlvbk5hbWUiLCJmbiIsInBvc3QiLCJ2YWxpZGF0ZSIsImNvbnRleHQiLCJyZXMiLCJjb25maWciLCJnZXRNZGVDb25maWciLCJjdXN0b21FcnJvciIsInN0YXR1c0NvZGUiLCJjb3JlIiwib3BlbnNlYXJjaCIsImFzQ3VycmVudFVzZXIiLCJjdHgiLCJvdHBDaGVjayIsInZhbGlkYXRlT1RQIiwidmFsaWQiLCJyZWFzb24iLCJkZXZpY2VOYW1lIiwiX2luZm8iLCJyZXN1bHQiLCJtZXNzYWdlIiwiSlNPTiIsInN0cmluZ2lmeSIsInNsaWNlIiwiYWN0aW9uIiwicGVyZm9ybWVkX2J5Iiwic3RhdHVzIiwic291cmNlX2lwIiwiaW5mbyIsInJlbW90ZUFkZHJlc3MiLCJvdHBfdmVyaWZpZWQiLCJvayIsInN1Y2Nlc3MiLCJfaW5mbzIiLCJtZGVIdHRwU3RhdHVzIiwibWRlRXJyb3JEZXRhaWwiLCJyZXNwb25zZVRleHQiLCJTdHJpbmciLCJlcnJvclR5cGUiLCJuYW1lIiwiY29uc3RydWN0b3IiLCJlcnJvck1lc3NhZ2UiLCJFcnJvciIsIm1kZV9odHRwX3N0YXR1cyIsIm1kZV9lcnJvcl9kZXRhaWwiLCJtZGVFcnJvclN0YXR1cyIsImNmZyIsImIiLCJydW5BbnRpdmlydXNTY2FuIiwiaXNvbGF0ZU1hY2hpbmUiLCJ1bmlzb2xhdGVNYWNoaW5lIiwicmVzdHJpY3RDb2RlRXhlY3V0aW9uIiwidW5yZXN0cmljdENvZGVFeGVjdXRpb24iLCJjb2xsZWN0SW52ZXN0aWdhdGlvblBhY2thZ2UiLCJvZmZib2FyZE1hY2hpbmUiLCJzdG9wUXVhcmFudGluZUJvZHkiLCJzaGExIiwiX2luZm8zIiwic3RvcEFuZFF1YXJhbnRpbmVGaWxlIiwiX2luZm80IiwiY2FuY2VsQWN0aW9uQm9keSIsImFjdGlvbl9pZCIsIl9pbmZvNSIsImNhbmNlbE1hY2hpbmVBY3Rpb24iLCJfaW5mbzYiLCJfY29udGV4dCIsIkRFU1RSVUNUSVZFX0FDVElPTlMiLCJpbmNsdWRlcyIsImdlbmVyYXRlT1RQIiwic3RvcmVPVFAiLCJlbWFpbFJlc3VsdCIsInNlbmRPVFBFbWFpbCIsInNlbnQiLCJkZXZfbW9kZSIsImRldk1vZGUiLCJ1bmRlZmluZWQiLCJpbmRpY2F0b3JDcmVhdGVCb2R5IiwiaW5kaWNhdG9yX3R5cGUiLCJpbmRpY2F0b3JfdmFsdWUiLCJ0aXRsZSIsImRlc2NyaXB0aW9uIiwic2V2ZXJpdHkiLCJfaW5mbzciLCJwYXlsb2FkIiwiaW5kaWNhdG9yVmFsdWUiLCJpbmRpY2F0b3JUeXBlIiwiZXhwaXJhdGlvblRpbWUiLCJleHBpcmF0aW9uX3RpbWUiLCJjcmVhdGVJbmRpY2F0b3IiLCJfaW5mbzgiLCJ1cGRhdGVJbmRpY2F0b3JCb2R5IiwiaW5kaWNhdG9yX2lkIiwicGF0Y2giLCJPYmplY3QiLCJrZXlzIiwibGVuZ3RoIiwiX2luZm85IiwidXBkYXRlSW5kaWNhdG9yIiwiX2luZm8xMCIsImRlbGV0ZUluZGljYXRvckJvZHkiLCJfaW5mbzExIiwiZGVsZXRlSW5kaWNhdG9yIiwiX2luZm8xMiJdLCJzb3VyY2VzIjpbImFjdGlvbnMudHMiXSwic291cmNlc0NvbnRlbnQiOlsiLypcbiAqIERlZmVuZGVyIHBsdWdpbiDigJQgTURFIGFjdGlvbnMgKyBPVFAgZm9yIHJlc3BvbnNlIG9wZXJhdGlvbnNcbiAqL1xuXG5pbXBvcnQgeyBJUm91dGVyIH0gZnJvbSAnb3BlbnNlYXJjaC1kYXNoYm9hcmRzL3NlcnZlcic7XG5pbXBvcnQgeyBzY2hlbWEgfSBmcm9tICdAb3NkL2NvbmZpZy1zY2hlbWEnO1xuaW1wb3J0IHsgREVGRU5ERVJfQVVESVRfTE9HX0lOREVYLCBERVNUUlVDVElWRV9BQ1RJT05TIH0gZnJvbSAnLi4vLi4vY29tbW9uL2NvbnN0YW50cyc7XG5pbXBvcnQge1xuICBnZXRNZGVDb25maWcsXG4gIHJ1bkFudGl2aXJ1c1NjYW4sXG4gIGlzb2xhdGVNYWNoaW5lLFxuICB1bmlzb2xhdGVNYWNoaW5lLFxuICByZXN0cmljdENvZGVFeGVjdXRpb24sXG4gIHVucmVzdHJpY3RDb2RlRXhlY3V0aW9uLFxuICBjb2xsZWN0SW52ZXN0aWdhdGlvblBhY2thZ2UsXG4gIG9mZmJvYXJkTWFjaGluZSxcbiAgc3RvcEFuZFF1YXJhbnRpbmVGaWxlLFxuICBjYW5jZWxNYWNoaW5lQWN0aW9uLFxuICBjcmVhdGVJbmRpY2F0b3IsXG4gIGRlbGV0ZUluZGljYXRvcixcbiAgdXBkYXRlSW5kaWNhdG9yLFxuICB0eXBlIENyZWF0ZUluZGljYXRvclBheWxvYWQsXG4gIG1kZUVycm9yU3RhdHVzLFxufSBmcm9tICcuLi9saWIvbWRlLWNsaWVudCc7XG5pbXBvcnQgeyBnZW5lcmF0ZU9UUCwgc3RvcmVPVFAsIHZhbGlkYXRlT1RQLCBzZW5kT1RQRW1haWwsIHR5cGUgT1RQRW1haWxDb25maWcgfSBmcm9tICcuLi9saWIvb3RwJztcblxuZnVuY3Rpb24gZ2V0VXNlckZyb21SZXF1ZXN0KHJlcTogYW55KTogeyB1c2VyOiBzdHJpbmc7IHJvbGU6IHN0cmluZyB9IHtcbiAgY29uc3QgdXNlciA9IChyZXEuaGVhZGVycz8uWyd4LWRlZmVuZGVyLXVzZXInXSBhcyBzdHJpbmcpIHx8ICdkYXNoYm9hcmQtdXNlcic7XG4gIGNvbnN0IHJvbGUgPSAocmVxLmhlYWRlcnM/LlsneC1kZWZlbmRlci1yb2xlJ10gYXMgc3RyaW5nKSB8fCAnZGVmZW5kZXJfb3BlcmF0b3InO1xuICByZXR1cm4geyB1c2VyLCByb2xlIH07XG59XG5cbmZ1bmN0aW9uIGdldE9UUENvbmZpZygpOiBPVFBFbWFpbENvbmZpZyB7XG4gIHJldHVybiB7XG4gICAgc210cEhvc3Q6IHByb2Nlc3MuZW52LlNNVFBfSE9TVCxcbiAgICBzbXRwUG9ydDogcHJvY2Vzcy5lbnYuU01UUF9QT1JUID8gcGFyc2VJbnQocHJvY2Vzcy5lbnYuU01UUF9QT1JULCAxMCkgOiA1ODcsXG4gICAgc210cFVzZXI6IHByb2Nlc3MuZW52LlNNVFBfVVNFUixcbiAgICBzbXRwUGFzczogcHJvY2Vzcy5lbnYuU01UUF9QQVNTLFxuICAgIG90cFJlY2lwaWVudEVtYWlsOiBwcm9jZXNzLmVudi5PVFBfUkVDSVBJRU5UX0VNQUlMLFxuICAgIHNtdHBTZWN1cmU6IHByb2Nlc3MuZW52LlNNVFBfU0VDVVJFID09PSAndHJ1ZScsXG4gIH07XG59XG5cbmZ1bmN0aW9uIG90cENvbnRleHQoYm9keTogeyBvdHBfY29udGV4dF9pZD86IHN0cmluZzsgbWFjaGluZV9pZD86IHN0cmluZyB9KTogc3RyaW5nIHtcbiAgY29uc3QgYyA9IChib2R5Lm90cF9jb250ZXh0X2lkIHx8IGJvZHkubWFjaGluZV9pZCB8fCAnJykudHJpbSgpO1xuICByZXR1cm4gYztcbn1cblxuYXN5bmMgZnVuY3Rpb24gd3JpdGVBdWRpdExvZyhcbiAgY2xpZW50OiBhbnksXG4gIGVudHJ5OiB7XG4gICAgYWN0aW9uOiBzdHJpbmc7XG4gICAgbWFjaGluZV9pZDogc3RyaW5nO1xuICAgIGNvbXB1dGVyX2Ruc19uYW1lOiBzdHJpbmc7XG4gICAgcGVyZm9ybWVkX2J5OiBzdHJpbmc7XG4gICAgcm9sZTogc3RyaW5nO1xuICAgIHN0YXR1czogc3RyaW5nO1xuICAgIG1lc3NhZ2U6IHN0cmluZztcbiAgICBzb3VyY2VfaXA/OiBzdHJpbmc7XG4gICAgb3RwX3ZlcmlmaWVkPzogYm9vbGVhbjtcbiAgICBjb21tZW50Pzogc3RyaW5nO1xuICB9XG4pIHtcbiAgdHJ5IHtcbiAgICBhd2FpdCBjbGllbnQuaW5kZXgoe1xuICAgICAgaW5kZXg6IERFRkVOREVSX0FVRElUX0xPR19JTkRFWCxcbiAgICAgIGJvZHk6IHsgLi4uZW50cnksIHRpbWVzdGFtcDogbmV3IERhdGUoKS50b0lTT1N0cmluZygpIH0sXG4gICAgfSk7XG4gIH0gY2F0Y2ggKGVycikge1xuICAgIGNvbnNvbGUuZXJyb3IoJ1tEZWZlbmRlcl0gQXVkaXQgbG9nIHdyaXRlIGZhaWxlZDonLCBlcnIpO1xuICB9XG59XG5cbmNvbnN0IHNjYW5UeXBlU2NoZW1hID0gc2NoZW1hLm9uZU9mKFtzY2hlbWEubGl0ZXJhbCgnUXVpY2snKSwgc2NoZW1hLmxpdGVyYWwoJ0Z1bGwnKV0pO1xuY29uc3QgaXNvbGF0aW9uVHlwZVNjaGVtYSA9IHNjaGVtYS5vbmVPZihbXG4gIHNjaGVtYS5saXRlcmFsKCdGdWxsJyksXG4gIHNjaGVtYS5saXRlcmFsKCdTZWxlY3RpdmUnKSxcbiAgc2NoZW1hLmxpdGVyYWwoJ1VuTWFuYWdlZERldmljZScpLFxuXSk7XG5cbi8qKiBNYWNoaW5lLXNjb3BlZCBhY3Rpb25zOiBPVFAgKyByZXF1aXJlZCBjb21tZW50ICovXG5jb25zdCBtYWNoaW5lQWN0aW9uQm9keSA9IHNjaGVtYS5vYmplY3Qoe1xuICBtYWNoaW5lX2lkOiBzY2hlbWEuc3RyaW5nKCksXG4gIGNvbXB1dGVyX2Ruc19uYW1lOiBzY2hlbWEubWF5YmUoc2NoZW1hLnN0cmluZygpKSxcbiAgY29tbWVudDogc2NoZW1hLnN0cmluZygpLFxuICBvdHA6IHNjaGVtYS5zdHJpbmcoKSxcbiAgb3RwX2NvbnRleHRfaWQ6IHNjaGVtYS5tYXliZShzY2hlbWEuc3RyaW5nKCkpLFxuICBzY2FuX3R5cGU6IHNjaGVtYS5tYXliZShzY2FuVHlwZVNjaGVtYSksXG4gIGlzb2xhdGlvbl90eXBlOiBzY2hlbWEubWF5YmUoaXNvbGF0aW9uVHlwZVNjaGVtYSksXG59KTtcblxuZXhwb3J0IGZ1bmN0aW9uIHJlZ2lzdGVyRGVmZW5kZXJBY3Rpb25Sb3V0ZXMocm91dGVyOiBJUm91dGVyKSB7XG4gIGNvbnN0IHJ1bk1hY2hpbmVBY3Rpb24gPSAoXG4gICAgcGF0aDogc3RyaW5nLFxuICAgIGFjdGlvbk5hbWU6IHN0cmluZyxcbiAgICBmbjogKFxuICAgICAgY2ZnOiBOb25OdWxsYWJsZTxSZXR1cm5UeXBlPHR5cGVvZiBnZXRNZGVDb25maWc+PixcbiAgICAgIGJvZHk6IHtcbiAgICAgICAgbWFjaGluZV9pZDogc3RyaW5nO1xuICAgICAgICBjb21tZW50OiBzdHJpbmc7XG4gICAgICAgIHNjYW5fdHlwZT86ICdRdWljaycgfCAnRnVsbCc7XG4gICAgICAgIGlzb2xhdGlvbl90eXBlPzogJ0Z1bGwnIHwgJ1NlbGVjdGl2ZScgfCAnVW5NYW5hZ2VkRGV2aWNlJztcbiAgICAgIH1cbiAgICApID0+IFByb21pc2U8dW5rbm93bj5cbiAgKSA9PiB7XG4gICAgcm91dGVyLnBvc3QoXG4gICAgICB7IHBhdGgsIHZhbGlkYXRlOiB7IGJvZHk6IG1hY2hpbmVBY3Rpb25Cb2R5IH0gfSxcbiAgICAgIGFzeW5jIChjb250ZXh0LCByZXEsIHJlcykgPT4ge1xuICAgICAgICBjb25zdCBjb25maWcgPSBnZXRNZGVDb25maWcoKTtcbiAgICAgICAgaWYgKCFjb25maWcpIHtcbiAgICAgICAgICByZXR1cm4gcmVzLmN1c3RvbUVycm9yKHtcbiAgICAgICAgICAgIHN0YXR1c0NvZGU6IDUwMyxcbiAgICAgICAgICAgIGJvZHk6ICdEZWZlbmRlciBjcmVkZW50aWFscyBub3QgY29uZmlndXJlZC4nLFxuICAgICAgICAgIH0pO1xuICAgICAgICB9XG4gICAgICAgIGNvbnN0IHsgdXNlciwgcm9sZSB9ID0gZ2V0VXNlckZyb21SZXF1ZXN0KHJlcSk7XG4gICAgICAgIGNvbnN0IGNsaWVudCA9IGNvbnRleHQuY29yZS5vcGVuc2VhcmNoLmNsaWVudC5hc0N1cnJlbnRVc2VyO1xuICAgICAgICBjb25zdCBib2R5ID0gcmVxLmJvZHkgYXMge1xuICAgICAgICAgIG1hY2hpbmVfaWQ6IHN0cmluZztcbiAgICAgICAgICBjb21wdXRlcl9kbnNfbmFtZT86IHN0cmluZztcbiAgICAgICAgICBjb21tZW50OiBzdHJpbmc7XG4gICAgICAgICAgb3RwOiBzdHJpbmc7XG4gICAgICAgICAgb3RwX2NvbnRleHRfaWQ/OiBzdHJpbmc7XG4gICAgICAgICAgc2Nhbl90eXBlPzogJ1F1aWNrJyB8ICdGdWxsJztcbiAgICAgICAgICBpc29sYXRpb25fdHlwZT86ICdGdWxsJyB8ICdTZWxlY3RpdmUnIHwgJ1VuTWFuYWdlZERldmljZSc7XG4gICAgICAgIH07XG4gICAgICAgIGNvbnN0IGNvbW1lbnQgPSAoYm9keS5jb21tZW50IHx8ICcnKS50cmltKCk7XG4gICAgICAgIGlmICghY29tbWVudCkge1xuICAgICAgICAgIHJldHVybiByZXMuY3VzdG9tRXJyb3IoeyBzdGF0dXNDb2RlOiA0MDAsIGJvZHk6ICdDb21tZW50IGlzIHJlcXVpcmVkLicgfSk7XG4gICAgICAgIH1cbiAgICAgICAgY29uc3QgY3R4ID0gb3RwQ29udGV4dChib2R5KTtcbiAgICAgICAgaWYgKCFjdHgpIHtcbiAgICAgICAgICByZXR1cm4gcmVzLmN1c3RvbUVycm9yKHsgc3RhdHVzQ29kZTogNDAwLCBib2R5OiAnbWFjaGluZV9pZCBvciBvdHBfY29udGV4dF9pZCByZXF1aXJlZC4nIH0pO1xuICAgICAgICB9XG4gICAgICAgIGNvbnN0IG90cENoZWNrID0gdmFsaWRhdGVPVFAoY3R4LCBhY3Rpb25OYW1lLCBib2R5Lm90cCB8fCAnJyk7XG4gICAgICAgIGlmICghb3RwQ2hlY2sudmFsaWQpIHtcbiAgICAgICAgICByZXR1cm4gcmVzLmN1c3RvbUVycm9yKHsgc3RhdHVzQ29kZTogNDAwLCBib2R5OiBvdHBDaGVjay5yZWFzb24gfHwgJ09UUCByZXF1aXJlZCcgfSk7XG4gICAgICAgIH1cbiAgICAgICAgY29uc3QgZGV2aWNlTmFtZSA9IGJvZHkuY29tcHV0ZXJfZG5zX25hbWUgfHwgYm9keS5tYWNoaW5lX2lkO1xuXG4gICAgICAgIHRyeSB7XG4gICAgICAgICAgY29uc3QgcmVzdWx0ID0gYXdhaXQgZm4oY29uZmlnLCB7XG4gICAgICAgICAgICBtYWNoaW5lX2lkOiBib2R5Lm1hY2hpbmVfaWQsXG4gICAgICAgICAgICBjb21tZW50LFxuICAgICAgICAgICAgc2Nhbl90eXBlOiBib2R5LnNjYW5fdHlwZSxcbiAgICAgICAgICAgIGlzb2xhdGlvbl90eXBlOiBib2R5Lmlzb2xhdGlvbl90eXBlLFxuICAgICAgICAgIH0pO1xuICAgICAgICAgIGNvbnN0IG1lc3NhZ2UgPSBKU09OLnN0cmluZ2lmeShyZXN1bHQpLnNsaWNlKDAsIDIwMDApO1xuICAgICAgICAgIGF3YWl0IHdyaXRlQXVkaXRMb2coY2xpZW50LCB7XG4gICAgICAgICAgICBhY3Rpb246IGFjdGlvbk5hbWUsXG4gICAgICAgICAgICBtYWNoaW5lX2lkOiBib2R5Lm1hY2hpbmVfaWQsXG4gICAgICAgICAgICBjb21wdXRlcl9kbnNfbmFtZTogZGV2aWNlTmFtZSxcbiAgICAgICAgICAgIHBlcmZvcm1lZF9ieTogdXNlcixcbiAgICAgICAgICAgIHJvbGUsXG4gICAgICAgICAgICBzdGF0dXM6ICdzdWNjZXNzJyxcbiAgICAgICAgICAgIG1lc3NhZ2UsXG4gICAgICAgICAgICBzb3VyY2VfaXA6IChyZXEgYXMgYW55KS5pbmZvPy5yZW1vdGVBZGRyZXNzLFxuICAgICAgICAgICAgb3RwX3ZlcmlmaWVkOiB0cnVlLFxuICAgICAgICAgICAgY29tbWVudCxcbiAgICAgICAgICB9KTtcbiAgICAgICAgICByZXR1cm4gcmVzLm9rKHtcbiAgICAgICAgICAgIGJvZHk6IHtcbiAgICAgICAgICAgICAgc3VjY2VzczogdHJ1ZSxcbiAgICAgICAgICAgICAgYWN0aW9uOiBhY3Rpb25OYW1lLFxuICAgICAgICAgICAgICBtYWNoaW5lX2lkOiBib2R5Lm1hY2hpbmVfaWQsXG4gICAgICAgICAgICAgIG1lc3NhZ2UsXG4gICAgICAgICAgICAgIHRpbWVzdGFtcDogbmV3IERhdGUoKS50b0lTT1N0cmluZygpLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICB9KTtcbiAgICAgICAgfSBjYXRjaCAoZXJyOiB1bmtub3duKSB7XG4gICAgICAgICAgYXdhaXQgd3JpdGVBdWRpdExvZyhjbGllbnQsIHtcbiAgICAgICAgICAgIGFjdGlvbjogYWN0aW9uTmFtZSxcbiAgICAgICAgICAgIG1hY2hpbmVfaWQ6IGJvZHkubWFjaGluZV9pZCxcbiAgICAgICAgICAgIGNvbXB1dGVyX2Ruc19uYW1lOiBkZXZpY2VOYW1lLFxuICAgICAgICAgICAgcGVyZm9ybWVkX2J5OiB1c2VyLFxuICAgICAgICAgICAgcm9sZSxcbiAgICAgICAgICAgIHN0YXR1czogJ2ZhaWx1cmUnLFxuICAgICAgICAgICAgbWVzc2FnZTogZXJyIGluc3RhbmNlb2YgRXJyb3IgPyBlcnIubWVzc2FnZSA6IFN0cmluZyhlcnIpLFxuICAgICAgICAgICAgc291cmNlX2lwOiAocmVxIGFzIGFueSkuaW5mbz8ucmVtb3RlQWRkcmVzcyxcbiAgICAgICAgICAgIG90cF92ZXJpZmllZDogdHJ1ZSxcbiAgICAgICAgICAgIGNvbW1lbnQsXG4gICAgICAgICAgfSk7XG4gICAgICAgICAgcmV0dXJuIHJlcy5jdXN0b21FcnJvcih7XG4gICAgICAgICAgICBzdGF0dXNDb2RlOiBtZGVFcnJvclN0YXR1cyhlcnIpLFxuICAgICAgICAgICAgYm9keTogZXJyIGluc3RhbmNlb2YgRXJyb3IgPyBlcnIubWVzc2FnZSA6IFN0cmluZyhlcnIpLFxuICAgICAgICAgIH0pO1xuICAgICAgICB9XG4gICAgICB9XG4gICAgKTtcbiAgfTtcblxuICBydW5NYWNoaW5lQWN0aW9uKCcvYXBpL2RlZmVuZGVyX3BsdWdpbi9hY3Rpb25zL2FudGl2aXJ1cy1zY2FuJywgJ2FudGl2aXJ1c19zY2FuJywgKGNmZywgYikgPT5cbiAgICBydW5BbnRpdmlydXNTY2FuKGNmZywgYi5tYWNoaW5lX2lkLCBiLmNvbW1lbnQsIGIuc2Nhbl90eXBlIHx8ICdRdWljaycpXG4gICk7XG5cbiAgcnVuTWFjaGluZUFjdGlvbignL2FwaS9kZWZlbmRlcl9wbHVnaW4vYWN0aW9ucy9pc29sYXRlJywgJ2lzb2xhdGUnLCAoY2ZnLCBiKSA9PlxuICAgIGlzb2xhdGVNYWNoaW5lKGNmZywgYi5tYWNoaW5lX2lkLCBiLmNvbW1lbnQsIGIuaXNvbGF0aW9uX3R5cGUgfHwgJ0Z1bGwnKVxuICApO1xuXG4gIHJ1bk1hY2hpbmVBY3Rpb24oJy9hcGkvZGVmZW5kZXJfcGx1Z2luL2FjdGlvbnMvdW5pc29sYXRlJywgJ3VuaXNvbGF0ZScsIChjZmcsIGIpID0+XG4gICAgdW5pc29sYXRlTWFjaGluZShjZmcsIGIubWFjaGluZV9pZCwgYi5jb21tZW50KVxuICApO1xuXG4gIHJ1bk1hY2hpbmVBY3Rpb24oXG4gICAgJy9hcGkvZGVmZW5kZXJfcGx1Z2luL2FjdGlvbnMvcmVzdHJpY3QtY29kZS1leGVjdXRpb24nLFxuICAgICdyZXN0cmljdF9jb2RlX2V4ZWN1dGlvbicsXG4gICAgKGNmZywgYikgPT4gcmVzdHJpY3RDb2RlRXhlY3V0aW9uKGNmZywgYi5tYWNoaW5lX2lkLCBiLmNvbW1lbnQpXG4gICk7XG5cbiAgcnVuTWFjaGluZUFjdGlvbihcbiAgICAnL2FwaS9kZWZlbmRlcl9wbHVnaW4vYWN0aW9ucy91bnJlc3RyaWN0LWNvZGUtZXhlY3V0aW9uJyxcbiAgICAndW5yZXN0cmljdF9jb2RlX2V4ZWN1dGlvbicsXG4gICAgKGNmZywgYikgPT4gdW5yZXN0cmljdENvZGVFeGVjdXRpb24oY2ZnLCBiLm1hY2hpbmVfaWQsIGIuY29tbWVudClcbiAgKTtcblxuICBydW5NYWNoaW5lQWN0aW9uKFxuICAgICcvYXBpL2RlZmVuZGVyX3BsdWdpbi9hY3Rpb25zL2NvbGxlY3QtaW52ZXN0aWdhdGlvbi1wYWNrYWdlJyxcbiAgICAnY29sbGVjdF9pbnZlc3RpZ2F0aW9uX3BhY2thZ2UnLFxuICAgIChjZmcsIGIpID0+IGNvbGxlY3RJbnZlc3RpZ2F0aW9uUGFja2FnZShjZmcsIGIubWFjaGluZV9pZCwgYi5jb21tZW50KVxuICApO1xuXG4gIHJ1bk1hY2hpbmVBY3Rpb24oJy9hcGkvZGVmZW5kZXJfcGx1Z2luL2FjdGlvbnMvb2ZmYm9hcmQnLCAnb2ZmYm9hcmRfbWFjaGluZScsIChjZmcsIGIpID0+XG4gICAgb2ZmYm9hcmRNYWNoaW5lKGNmZywgYi5tYWNoaW5lX2lkLCBiLmNvbW1lbnQpXG4gICk7XG5cbiAgY29uc3Qgc3RvcFF1YXJhbnRpbmVCb2R5ID0gc2NoZW1hLm9iamVjdCh7XG4gICAgbWFjaGluZV9pZDogc2NoZW1hLnN0cmluZygpLFxuICAgIGNvbXB1dGVyX2Ruc19uYW1lOiBzY2hlbWEubWF5YmUoc2NoZW1hLnN0cmluZygpKSxcbiAgICBzaGExOiBzY2hlbWEuc3RyaW5nKCksXG4gICAgY29tbWVudDogc2NoZW1hLnN0cmluZygpLFxuICAgIG90cDogc2NoZW1hLnN0cmluZygpLFxuICAgIG90cF9jb250ZXh0X2lkOiBzY2hlbWEubWF5YmUoc2NoZW1hLnN0cmluZygpKSxcbiAgfSk7XG5cbiAgcm91dGVyLnBvc3QoXG4gICAgeyBwYXRoOiAnL2FwaS9kZWZlbmRlcl9wbHVnaW4vYWN0aW9ucy9zdG9wLWFuZC1xdWFyYW50aW5lJywgdmFsaWRhdGU6IHsgYm9keTogc3RvcFF1YXJhbnRpbmVCb2R5IH0gfSxcbiAgICBhc3luYyAoY29udGV4dCwgcmVxLCByZXMpID0+IHtcbiAgICAgIGNvbnN0IGNvbmZpZyA9IGdldE1kZUNvbmZpZygpO1xuICAgICAgaWYgKCFjb25maWcpIHtcbiAgICAgICAgcmV0dXJuIHJlcy5jdXN0b21FcnJvcih7IHN0YXR1c0NvZGU6IDUwMywgYm9keTogJ0RlZmVuZGVyIG5vdCBjb25maWd1cmVkLicgfSk7XG4gICAgICB9XG4gICAgICBjb25zdCB7IHVzZXIsIHJvbGUgfSA9IGdldFVzZXJGcm9tUmVxdWVzdChyZXEpO1xuICAgICAgY29uc3QgY2xpZW50ID0gY29udGV4dC5jb3JlLm9wZW5zZWFyY2guY2xpZW50LmFzQ3VycmVudFVzZXI7XG4gICAgICBjb25zdCBib2R5ID0gcmVxLmJvZHkgYXMge1xuICAgICAgICBtYWNoaW5lX2lkOiBzdHJpbmc7XG4gICAgICAgIGNvbXB1dGVyX2Ruc19uYW1lPzogc3RyaW5nO1xuICAgICAgICBzaGExOiBzdHJpbmc7XG4gICAgICAgIGNvbW1lbnQ6IHN0cmluZztcbiAgICAgICAgb3RwOiBzdHJpbmc7XG4gICAgICAgIG90cF9jb250ZXh0X2lkPzogc3RyaW5nO1xuICAgICAgfTtcbiAgICAgIGNvbnN0IGNvbW1lbnQgPSAoYm9keS5jb21tZW50IHx8ICcnKS50cmltKCk7XG4gICAgICBpZiAoIWNvbW1lbnQpIHtcbiAgICAgICAgcmV0dXJuIHJlcy5jdXN0b21FcnJvcih7IHN0YXR1c0NvZGU6IDQwMCwgYm9keTogJ0NvbW1lbnQgaXMgcmVxdWlyZWQuJyB9KTtcbiAgICAgIH1cbiAgICAgIGNvbnN0IGN0eCA9IG90cENvbnRleHQoYm9keSk7XG4gICAgICBpZiAoIWN0eCkge1xuICAgICAgICByZXR1cm4gcmVzLmN1c3RvbUVycm9yKHsgc3RhdHVzQ29kZTogNDAwLCBib2R5OiAnbWFjaGluZV9pZCBvciBvdHBfY29udGV4dF9pZCByZXF1aXJlZC4nIH0pO1xuICAgICAgfVxuICAgICAgY29uc3Qgb3RwQ2hlY2sgPSB2YWxpZGF0ZU9UUChjdHgsICdzdG9wX2FuZF9xdWFyYW50aW5lJywgYm9keS5vdHAgfHwgJycpO1xuICAgICAgaWYgKCFvdHBDaGVjay52YWxpZCkge1xuICAgICAgICByZXR1cm4gcmVzLmN1c3RvbUVycm9yKHsgc3RhdHVzQ29kZTogNDAwLCBib2R5OiBvdHBDaGVjay5yZWFzb24gfHwgJ09UUCByZXF1aXJlZCcgfSk7XG4gICAgICB9XG4gICAgICBjb25zdCBkZXZpY2VOYW1lID0gYm9keS5jb21wdXRlcl9kbnNfbmFtZSB8fCBib2R5Lm1hY2hpbmVfaWQ7XG4gICAgICB0cnkge1xuICAgICAgICBjb25zdCByZXN1bHQgPSBhd2FpdCBzdG9wQW5kUXVhcmFudGluZUZpbGUoXG4gICAgICAgICAgY29uZmlnLFxuICAgICAgICAgIGJvZHkubWFjaGluZV9pZCxcbiAgICAgICAgICBjb21tZW50LFxuICAgICAgICAgIGJvZHkuc2hhMS50cmltKClcbiAgICAgICAgKTtcbiAgICAgICAgY29uc3QgbWVzc2FnZSA9IEpTT04uc3RyaW5naWZ5KHJlc3VsdCkuc2xpY2UoMCwgMjAwMCk7XG4gICAgICAgIGF3YWl0IHdyaXRlQXVkaXRMb2coY2xpZW50LCB7XG4gICAgICAgICAgYWN0aW9uOiAnc3RvcF9hbmRfcXVhcmFudGluZScsXG4gICAgICAgICAgbWFjaGluZV9pZDogYm9keS5tYWNoaW5lX2lkLFxuICAgICAgICAgIGNvbXB1dGVyX2Ruc19uYW1lOiBkZXZpY2VOYW1lLFxuICAgICAgICAgIHBlcmZvcm1lZF9ieTogdXNlcixcbiAgICAgICAgICByb2xlLFxuICAgICAgICAgIHN0YXR1czogJ3N1Y2Nlc3MnLFxuICAgICAgICAgIG1lc3NhZ2UsXG4gICAgICAgICAgc291cmNlX2lwOiAocmVxIGFzIGFueSkuaW5mbz8ucmVtb3RlQWRkcmVzcyxcbiAgICAgICAgICBvdHBfdmVyaWZpZWQ6IHRydWUsXG4gICAgICAgICAgY29tbWVudCxcbiAgICAgICAgfSk7XG4gICAgICAgIHJldHVybiByZXMub2soe1xuICAgICAgICAgIGJvZHk6IHsgc3VjY2VzczogdHJ1ZSwgYWN0aW9uOiAnc3RvcF9hbmRfcXVhcmFudGluZScsIG1hY2hpbmVfaWQ6IGJvZHkubWFjaGluZV9pZCwgbWVzc2FnZSB9LFxuICAgICAgICB9KTtcbiAgICAgIH0gY2F0Y2ggKGVycjogdW5rbm93bikge1xuICAgICAgICBhd2FpdCB3cml0ZUF1ZGl0TG9nKGNsaWVudCwge1xuICAgICAgICAgIGFjdGlvbjogJ3N0b3BfYW5kX3F1YXJhbnRpbmUnLFxuICAgICAgICAgIG1hY2hpbmVfaWQ6IGJvZHkubWFjaGluZV9pZCxcbiAgICAgICAgICBjb21wdXRlcl9kbnNfbmFtZTogZGV2aWNlTmFtZSxcbiAgICAgICAgICBwZXJmb3JtZWRfYnk6IHVzZXIsXG4gICAgICAgICAgcm9sZSxcbiAgICAgICAgICBzdGF0dXM6ICdmYWlsdXJlJyxcbiAgICAgICAgICBtZXNzYWdlOiBlcnIgaW5zdGFuY2VvZiBFcnJvciA/IGVyci5tZXNzYWdlIDogU3RyaW5nKGVyciksXG4gICAgICAgICAgc291cmNlX2lwOiAocmVxIGFzIGFueSkuaW5mbz8ucmVtb3RlQWRkcmVzcyxcbiAgICAgICAgICBvdHBfdmVyaWZpZWQ6IHRydWUsXG4gICAgICAgICAgY29tbWVudCxcbiAgICAgICAgfSk7XG4gICAgICAgIHJldHVybiByZXMuY3VzdG9tRXJyb3Ioe1xuICAgICAgICAgIHN0YXR1c0NvZGU6IG1kZUVycm9yU3RhdHVzKGVyciksXG4gICAgICAgICAgYm9keTogZXJyIGluc3RhbmNlb2YgRXJyb3IgPyBlcnIubWVzc2FnZSA6IFN0cmluZyhlcnIpLFxuICAgICAgICB9KTtcbiAgICAgIH1cbiAgICB9XG4gICk7XG5cbiAgY29uc3QgY2FuY2VsQWN0aW9uQm9keSA9IHNjaGVtYS5vYmplY3Qoe1xuICAgIGFjdGlvbl9pZDogc2NoZW1hLnN0cmluZygpLFxuICAgIG1hY2hpbmVfaWQ6IHNjaGVtYS5tYXliZShzY2hlbWEuc3RyaW5nKCkpLFxuICAgIGNvbXB1dGVyX2Ruc19uYW1lOiBzY2hlbWEubWF5YmUoc2NoZW1hLnN0cmluZygpKSxcbiAgICBjb21tZW50OiBzY2hlbWEuc3RyaW5nKCksXG4gICAgb3RwOiBzY2hlbWEuc3RyaW5nKCksXG4gIH0pO1xuXG4gIHJvdXRlci5wb3N0KFxuICAgIHsgcGF0aDogJy9hcGkvZGVmZW5kZXJfcGx1Z2luL2FjdGlvbnMvY2FuY2VsLW1hY2hpbmUtYWN0aW9uJywgdmFsaWRhdGU6IHsgYm9keTogY2FuY2VsQWN0aW9uQm9keSB9IH0sXG4gICAgYXN5bmMgKGNvbnRleHQsIHJlcSwgcmVzKSA9PiB7XG4gICAgICBjb25zdCBjb25maWcgPSBnZXRNZGVDb25maWcoKTtcbiAgICAgIGlmICghY29uZmlnKSB7XG4gICAgICAgIHJldHVybiByZXMuY3VzdG9tRXJyb3IoeyBzdGF0dXNDb2RlOiA1MDMsIGJvZHk6ICdEZWZlbmRlciBub3QgY29uZmlndXJlZC4nIH0pO1xuICAgICAgfVxuICAgICAgY29uc3QgeyB1c2VyLCByb2xlIH0gPSBnZXRVc2VyRnJvbVJlcXVlc3QocmVxKTtcbiAgICAgIGNvbnN0IGNsaWVudCA9IGNvbnRleHQuY29yZS5vcGVuc2VhcmNoLmNsaWVudC5hc0N1cnJlbnRVc2VyO1xuICAgICAgY29uc3QgYm9keSA9IHJlcS5ib2R5IGFzIHtcbiAgICAgICAgYWN0aW9uX2lkOiBzdHJpbmc7XG4gICAgICAgIG1hY2hpbmVfaWQ/OiBzdHJpbmc7XG4gICAgICAgIGNvbXB1dGVyX2Ruc19uYW1lPzogc3RyaW5nO1xuICAgICAgICBjb21tZW50OiBzdHJpbmc7XG4gICAgICAgIG90cDogc3RyaW5nO1xuICAgICAgfTtcbiAgICAgIGNvbnN0IGNvbW1lbnQgPSAoYm9keS5jb21tZW50IHx8ICcnKS50cmltKCk7XG4gICAgICBpZiAoIWNvbW1lbnQpIHtcbiAgICAgICAgcmV0dXJuIHJlcy5jdXN0b21FcnJvcih7IHN0YXR1c0NvZGU6IDQwMCwgYm9keTogJ0NvbW1lbnQgaXMgcmVxdWlyZWQuJyB9KTtcbiAgICAgIH1cbiAgICAgIGNvbnN0IG90cENoZWNrID0gdmFsaWRhdGVPVFAoYm9keS5hY3Rpb25faWQsICdjYW5jZWxfbWFjaGluZV9hY3Rpb24nLCBib2R5Lm90cCB8fCAnJyk7XG4gICAgICBpZiAoIW90cENoZWNrLnZhbGlkKSB7XG4gICAgICAgIHJldHVybiByZXMuY3VzdG9tRXJyb3IoeyBzdGF0dXNDb2RlOiA0MDAsIGJvZHk6IG90cENoZWNrLnJlYXNvbiB8fCAnT1RQIHJlcXVpcmVkJyB9KTtcbiAgICAgIH1cbiAgICAgIGNvbnN0IGRldmljZU5hbWUgPSBib2R5LmNvbXB1dGVyX2Ruc19uYW1lIHx8IGJvZHkubWFjaGluZV9pZCB8fCBib2R5LmFjdGlvbl9pZDtcbiAgICAgIHRyeSB7XG4gICAgICAgIGNvbnN0IHJlc3VsdCA9IGF3YWl0IGNhbmNlbE1hY2hpbmVBY3Rpb24oY29uZmlnLCBib2R5LmFjdGlvbl9pZCk7XG4gICAgICAgIGNvbnN0IG1lc3NhZ2UgPSBKU09OLnN0cmluZ2lmeShyZXN1bHQpLnNsaWNlKDAsIDIwMDApO1xuICAgICAgICBhd2FpdCB3cml0ZUF1ZGl0TG9nKGNsaWVudCwge1xuICAgICAgICAgIGFjdGlvbjogJ2NhbmNlbF9tYWNoaW5lX2FjdGlvbicsXG4gICAgICAgICAgbWFjaGluZV9pZDogYm9keS5tYWNoaW5lX2lkIHx8IGJvZHkuYWN0aW9uX2lkLFxuICAgICAgICAgIGNvbXB1dGVyX2Ruc19uYW1lOiBkZXZpY2VOYW1lLFxuICAgICAgICAgIHBlcmZvcm1lZF9ieTogdXNlcixcbiAgICAgICAgICByb2xlLFxuICAgICAgICAgIHN0YXR1czogJ3N1Y2Nlc3MnLFxuICAgICAgICAgIG1lc3NhZ2UsXG4gICAgICAgICAgc291cmNlX2lwOiAocmVxIGFzIGFueSkuaW5mbz8ucmVtb3RlQWRkcmVzcyxcbiAgICAgICAgICBvdHBfdmVyaWZpZWQ6IHRydWUsXG4gICAgICAgICAgY29tbWVudCxcbiAgICAgICAgfSk7XG4gICAgICAgIHJldHVybiByZXMub2soe1xuICAgICAgICAgIGJvZHk6IHsgc3VjY2VzczogdHJ1ZSwgYWN0aW9uOiAnY2FuY2VsX21hY2hpbmVfYWN0aW9uJywgYWN0aW9uX2lkOiBib2R5LmFjdGlvbl9pZCwgbWVzc2FnZSB9LFxuICAgICAgICB9KTtcbiAgICAgIH0gY2F0Y2ggKGVycjogdW5rbm93bikge1xuICAgICAgICBhd2FpdCB3cml0ZUF1ZGl0TG9nKGNsaWVudCwge1xuICAgICAgICAgIGFjdGlvbjogJ2NhbmNlbF9tYWNoaW5lX2FjdGlvbicsXG4gICAgICAgICAgbWFjaGluZV9pZDogYm9keS5tYWNoaW5lX2lkIHx8IGJvZHkuYWN0aW9uX2lkLFxuICAgICAgICAgIGNvbXB1dGVyX2Ruc19uYW1lOiBkZXZpY2VOYW1lLFxuICAgICAgICAgIHBlcmZvcm1lZF9ieTogdXNlcixcbiAgICAgICAgICByb2xlLFxuICAgICAgICAgIHN0YXR1czogJ2ZhaWx1cmUnLFxuICAgICAgICAgIG1lc3NhZ2U6IGVyciBpbnN0YW5jZW9mIEVycm9yID8gZXJyLm1lc3NhZ2UgOiBTdHJpbmcoZXJyKSxcbiAgICAgICAgICBzb3VyY2VfaXA6IChyZXEgYXMgYW55KS5pbmZvPy5yZW1vdGVBZGRyZXNzLFxuICAgICAgICAgIG90cF92ZXJpZmllZDogdHJ1ZSxcbiAgICAgICAgICBjb21tZW50LFxuICAgICAgICB9KTtcbiAgICAgICAgcmV0dXJuIHJlcy5jdXN0b21FcnJvcih7XG4gICAgICAgICAgc3RhdHVzQ29kZTogbWRlRXJyb3JTdGF0dXMoZXJyKSxcbiAgICAgICAgICBib2R5OiBlcnIgaW5zdGFuY2VvZiBFcnJvciA/IGVyci5tZXNzYWdlIDogU3RyaW5nKGVyciksXG4gICAgICAgIH0pO1xuICAgICAgfVxuICAgIH1cbiAgKTtcblxuICByb3V0ZXIucG9zdChcbiAgICB7XG4gICAgICBwYXRoOiAnL2FwaS9kZWZlbmRlcl9wbHVnaW4vYWN0aW9ucy9yZXF1ZXN0LW90cCcsXG4gICAgICB2YWxpZGF0ZToge1xuICAgICAgICBib2R5OiBzY2hlbWEub2JqZWN0KHtcbiAgICAgICAgICBhY3Rpb246IHNjaGVtYS5zdHJpbmcoKSxcbiAgICAgICAgICBtYWNoaW5lX2lkOiBzY2hlbWEubWF5YmUoc2NoZW1hLnN0cmluZygpKSxcbiAgICAgICAgICBjb21wdXRlcl9kbnNfbmFtZTogc2NoZW1hLm1heWJlKHNjaGVtYS5zdHJpbmcoKSksXG4gICAgICAgICAgb3RwX2NvbnRleHRfaWQ6IHNjaGVtYS5tYXliZShzY2hlbWEuc3RyaW5nKCkpLFxuICAgICAgICB9KSxcbiAgICAgIH0sXG4gICAgfSxcbiAgICBhc3luYyAoX2NvbnRleHQsIHJlcSwgcmVzKSA9PiB7XG4gICAgICBjb25zdCB7IG1hY2hpbmVfaWQsIGFjdGlvbiwgY29tcHV0ZXJfZG5zX25hbWUsIG90cF9jb250ZXh0X2lkIH0gPSByZXEuYm9keSBhcyB7XG4gICAgICAgIG1hY2hpbmVfaWQ/OiBzdHJpbmc7XG4gICAgICAgIGFjdGlvbjogc3RyaW5nO1xuICAgICAgICBjb21wdXRlcl9kbnNfbmFtZT86IHN0cmluZztcbiAgICAgICAgb3RwX2NvbnRleHRfaWQ/OiBzdHJpbmc7XG4gICAgICB9O1xuICAgICAgaWYgKCFERVNUUlVDVElWRV9BQ1RJT05TLmluY2x1ZGVzKGFjdGlvbikpIHtcbiAgICAgICAgcmV0dXJuIHJlcy5jdXN0b21FcnJvcih7XG4gICAgICAgICAgc3RhdHVzQ29kZTogNDAwLFxuICAgICAgICAgIGJvZHk6ICdUaGlzIGFjdGlvbiBkb2VzIG5vdCB1c2UgdGhpcyBPVFAgZmxvdy4nLFxuICAgICAgICB9KTtcbiAgICAgIH1cbiAgICAgIGNvbnN0IGN0eCA9IChvdHBfY29udGV4dF9pZCB8fCBtYWNoaW5lX2lkIHx8ICcnKS50cmltKCk7XG4gICAgICBpZiAoIWN0eCkge1xuICAgICAgICByZXR1cm4gcmVzLmN1c3RvbUVycm9yKHtcbiAgICAgICAgICBzdGF0dXNDb2RlOiA0MDAsXG4gICAgICAgICAgYm9keTogJ1Byb3ZpZGUgbWFjaGluZV9pZCBvciBvdHBfY29udGV4dF9pZCAoZS5nLiBhY3Rpb24gaWQgZm9yIGNhbmNlbCkuJyxcbiAgICAgICAgfSk7XG4gICAgICB9XG4gICAgICBjb25zdCBvdHAgPSBnZW5lcmF0ZU9UUCgpO1xuICAgICAgc3RvcmVPVFAoY3R4LCBhY3Rpb24sIG90cCk7XG4gICAgICBjb25zdCBlbWFpbFJlc3VsdCA9IGF3YWl0IHNlbmRPVFBFbWFpbChcbiAgICAgICAgZ2V0T1RQQ29uZmlnKCksXG4gICAgICAgIG90cCxcbiAgICAgICAgY29tcHV0ZXJfZG5zX25hbWUgfHwgY3R4LFxuICAgICAgICBhY3Rpb25cbiAgICAgICk7XG4gICAgICByZXR1cm4gcmVzLm9rKHtcbiAgICAgICAgYm9keToge1xuICAgICAgICAgIHN1Y2Nlc3M6IHRydWUsXG4gICAgICAgICAgbWVzc2FnZTogZW1haWxSZXN1bHQuc2VudFxuICAgICAgICAgICAgPyAnT1RQIHNlbnQgdG8gY29uZmlndXJlZCByZWNpcGllbnQuJ1xuICAgICAgICAgICAgOiAnT1RQIGdlbmVyYXRlZCAoY29uZmlndXJlIFNNVFAgZm9yIGVtYWlsIGRlbGl2ZXJ5KS4nLFxuICAgICAgICAgIGRldl9tb2RlOiBlbWFpbFJlc3VsdC5kZXZNb2RlLFxuICAgICAgICAgIG90cDogZW1haWxSZXN1bHQuZGV2TW9kZSA/IGVtYWlsUmVzdWx0Lm90cCA6IHVuZGVmaW5lZCxcbiAgICAgICAgfSxcbiAgICAgIH0pO1xuICAgIH1cbiAgKTtcblxuICBjb25zdCBpbmRpY2F0b3JDcmVhdGVCb2R5ID0gc2NoZW1hLm9iamVjdCh7XG4gICAgbWFjaGluZV9pZDogc2NoZW1hLnN0cmluZygpLFxuICAgIGNvbXB1dGVyX2Ruc19uYW1lOiBzY2hlbWEubWF5YmUoc2NoZW1hLnN0cmluZygpKSxcbiAgICBjb21tZW50OiBzY2hlbWEuc3RyaW5nKCksXG4gICAgb3RwOiBzY2hlbWEuc3RyaW5nKCksXG4gICAgb3RwX2NvbnRleHRfaWQ6IHNjaGVtYS5tYXliZShzY2hlbWEuc3RyaW5nKCkpLFxuICAgIGluZGljYXRvcl90eXBlOiBzY2hlbWEub25lT2YoW1xuICAgICAgc2NoZW1hLmxpdGVyYWwoJ0ZpbGVTaGExJyksXG4gICAgICBzY2hlbWEubGl0ZXJhbCgnRmlsZVNoYTI1NicpLFxuICAgICAgc2NoZW1hLmxpdGVyYWwoJ0lwQWRkcmVzcycpLFxuICAgICAgc2NoZW1hLmxpdGVyYWwoJ0RvbWFpbk5hbWUnKSxcbiAgICAgIHNjaGVtYS5saXRlcmFsKCdVcmwnKSxcbiAgICBdKSxcbiAgICBpbmRpY2F0b3JfdmFsdWU6IHNjaGVtYS5zdHJpbmcoKSxcbiAgICB0aXRsZTogc2NoZW1hLnN0cmluZygpLFxuICAgIGRlc2NyaXB0aW9uOiBzY2hlbWEubWF5YmUoc2NoZW1hLnN0cmluZygpKSxcbiAgICBleHBpcmF0aW9uX3RpbWU6IHNjaGVtYS5tYXliZShzY2hlbWEuc3RyaW5nKCkpLFxuICAgIGFjdGlvbjogc2NoZW1hLm9uZU9mKFtcbiAgICAgIHNjaGVtYS5saXRlcmFsKCdBbGVydCcpLFxuICAgICAgc2NoZW1hLmxpdGVyYWwoJ0FsZXJ0QW5kQmxvY2snKSxcbiAgICAgIHNjaGVtYS5saXRlcmFsKCdBbGxvd2VkJyksXG4gICAgICBzY2hlbWEubGl0ZXJhbCgnQmxvY2snKSxcbiAgICAgIHNjaGVtYS5saXRlcmFsKCdBdWRpdCcpLFxuICAgIF0pLFxuICAgIHNldmVyaXR5OiBzY2hlbWEub25lT2YoW1xuICAgICAgc2NoZW1hLmxpdGVyYWwoJ0luZm9ybWF0aW9uYWwnKSxcbiAgICAgIHNjaGVtYS5saXRlcmFsKCdMb3cnKSxcbiAgICAgIHNjaGVtYS5saXRlcmFsKCdNZWRpdW0nKSxcbiAgICAgIHNjaGVtYS5saXRlcmFsKCdIaWdoJyksXG4gICAgXSksXG4gIH0pO1xuXG4gIHJvdXRlci5wb3N0KFxuICAgIHsgcGF0aDogJy9hcGkvZGVmZW5kZXJfcGx1Z2luL2FjdGlvbnMvY3JlYXRlLWluZGljYXRvcicsIHZhbGlkYXRlOiB7IGJvZHk6IGluZGljYXRvckNyZWF0ZUJvZHkgfSB9LFxuICAgIGFzeW5jIChjb250ZXh0LCByZXEsIHJlcykgPT4ge1xuICAgICAgY29uc3QgY29uZmlnID0gZ2V0TWRlQ29uZmlnKCk7XG4gICAgICBpZiAoIWNvbmZpZykge1xuICAgICAgICByZXR1cm4gcmVzLmN1c3RvbUVycm9yKHsgc3RhdHVzQ29kZTogNTAzLCBib2R5OiAnRGVmZW5kZXIgbm90IGNvbmZpZ3VyZWQuJyB9KTtcbiAgICAgIH1cbiAgICAgIGNvbnN0IHsgdXNlciwgcm9sZSB9ID0gZ2V0VXNlckZyb21SZXF1ZXN0KHJlcSk7XG4gICAgICBjb25zdCBjbGllbnQgPSBjb250ZXh0LmNvcmUub3BlbnNlYXJjaC5jbGllbnQuYXNDdXJyZW50VXNlcjtcbiAgICAgIGNvbnN0IGIgPSByZXEuYm9keSBhcyB7XG4gICAgICAgIG1hY2hpbmVfaWQ6IHN0cmluZztcbiAgICAgICAgY29tcHV0ZXJfZG5zX25hbWU/OiBzdHJpbmc7XG4gICAgICAgIGNvbW1lbnQ6IHN0cmluZztcbiAgICAgICAgb3RwOiBzdHJpbmc7XG4gICAgICAgIG90cF9jb250ZXh0X2lkPzogc3RyaW5nO1xuICAgICAgICBpbmRpY2F0b3JfdHlwZTogQ3JlYXRlSW5kaWNhdG9yUGF5bG9hZFsnaW5kaWNhdG9yVHlwZSddO1xuICAgICAgICBpbmRpY2F0b3JfdmFsdWU6IHN0cmluZztcbiAgICAgICAgdGl0bGU6IHN0cmluZztcbiAgICAgICAgZGVzY3JpcHRpb24/OiBzdHJpbmc7XG4gICAgICAgIGV4cGlyYXRpb25fdGltZT86IHN0cmluZztcbiAgICAgICAgYWN0aW9uOiBDcmVhdGVJbmRpY2F0b3JQYXlsb2FkWydhY3Rpb24nXTtcbiAgICAgICAgc2V2ZXJpdHk6IENyZWF0ZUluZGljYXRvclBheWxvYWRbJ3NldmVyaXR5J107XG4gICAgICB9O1xuICAgICAgY29uc3QgY29tbWVudCA9IChiLmNvbW1lbnQgfHwgJycpLnRyaW0oKTtcbiAgICAgIGlmICghY29tbWVudCkge1xuICAgICAgICByZXR1cm4gcmVzLmN1c3RvbUVycm9yKHsgc3RhdHVzQ29kZTogNDAwLCBib2R5OiAnQ29tbWVudCBpcyByZXF1aXJlZC4nIH0pO1xuICAgICAgfVxuICAgICAgY29uc3QgY3R4ID0gb3RwQ29udGV4dChiKTtcbiAgICAgIGlmICghY3R4KSB7XG4gICAgICAgIHJldHVybiByZXMuY3VzdG9tRXJyb3IoeyBzdGF0dXNDb2RlOiA0MDAsIGJvZHk6ICdtYWNoaW5lX2lkIG9yIG90cF9jb250ZXh0X2lkIHJlcXVpcmVkLicgfSk7XG4gICAgICB9XG4gICAgICBjb25zdCBvdHBDaGVjayA9IHZhbGlkYXRlT1RQKGN0eCwgJ2NyZWF0ZV9pbmRpY2F0b3InLCBiLm90cCB8fCAnJyk7XG4gICAgICBpZiAoIW90cENoZWNrLnZhbGlkKSB7XG4gICAgICAgIHJldHVybiByZXMuY3VzdG9tRXJyb3IoeyBzdGF0dXNDb2RlOiA0MDAsIGJvZHk6IG90cENoZWNrLnJlYXNvbiB8fCAnT1RQIHJlcXVpcmVkJyB9KTtcbiAgICAgIH1cbiAgICAgIGNvbnN0IGRldmljZU5hbWUgPSBiLmNvbXB1dGVyX2Ruc19uYW1lIHx8IGIubWFjaGluZV9pZDtcbiAgICAgIHRyeSB7XG4gICAgICAgIGNvbnN0IHBheWxvYWQ6IENyZWF0ZUluZGljYXRvclBheWxvYWQgPSB7XG4gICAgICAgICAgaW5kaWNhdG9yVmFsdWU6IGIuaW5kaWNhdG9yX3ZhbHVlLFxuICAgICAgICAgIGluZGljYXRvclR5cGU6IGIuaW5kaWNhdG9yX3R5cGUsXG4gICAgICAgICAgdGl0bGU6IGIudGl0bGUsXG4gICAgICAgICAgZGVzY3JpcHRpb246IGIuZGVzY3JpcHRpb24sXG4gICAgICAgICAgZXhwaXJhdGlvblRpbWU6IGIuZXhwaXJhdGlvbl90aW1lLFxuICAgICAgICAgIGFjdGlvbjogYi5hY3Rpb24sXG4gICAgICAgICAgc2V2ZXJpdHk6IGIuc2V2ZXJpdHksXG4gICAgICAgIH07XG4gICAgICAgIGNvbnN0IHJlc3VsdCA9IGF3YWl0IGNyZWF0ZUluZGljYXRvcihjb25maWcsIHBheWxvYWQpO1xuICAgICAgICBjb25zdCBtZXNzYWdlID0gSlNPTi5zdHJpbmdpZnkocmVzdWx0KS5zbGljZSgwLCAyMDAwKTtcbiAgICAgICAgYXdhaXQgd3JpdGVBdWRpdExvZyhjbGllbnQsIHtcbiAgICAgICAgICBhY3Rpb246ICdjcmVhdGVfaW5kaWNhdG9yJyxcbiAgICAgICAgICBtYWNoaW5lX2lkOiBiLm1hY2hpbmVfaWQsXG4gICAgICAgICAgY29tcHV0ZXJfZG5zX25hbWU6IGRldmljZU5hbWUsXG4gICAgICAgICAgcGVyZm9ybWVkX2J5OiB1c2VyLFxuICAgICAgICAgIHJvbGUsXG4gICAgICAgICAgc3RhdHVzOiAnc3VjY2VzcycsXG4gICAgICAgICAgbWVzc2FnZSxcbiAgICAgICAgICBzb3VyY2VfaXA6IChyZXEgYXMgYW55KS5pbmZvPy5yZW1vdGVBZGRyZXNzLFxuICAgICAgICAgIG90cF92ZXJpZmllZDogdHJ1ZSxcbiAgICAgICAgICBjb21tZW50LFxuICAgICAgICB9KTtcbiAgICAgICAgcmV0dXJuIHJlcy5vayh7XG4gICAgICAgICAgYm9keToge1xuICAgICAgICAgICAgc3VjY2VzczogdHJ1ZSxcbiAgICAgICAgICAgIGFjdGlvbjogJ2NyZWF0ZV9pbmRpY2F0b3InLFxuICAgICAgICAgICAgbWFjaGluZV9pZDogYi5tYWNoaW5lX2lkLFxuICAgICAgICAgICAgbWVzc2FnZSxcbiAgICAgICAgICAgIHRpbWVzdGFtcDogbmV3IERhdGUoKS50b0lTT1N0cmluZygpLFxuICAgICAgICAgIH0sXG4gICAgICAgIH0pO1xuICAgICAgfSBjYXRjaCAoZXJyOiB1bmtub3duKSB7XG4gICAgICAgIGF3YWl0IHdyaXRlQXVkaXRMb2coY2xpZW50LCB7XG4gICAgICAgICAgYWN0aW9uOiAnY3JlYXRlX2luZGljYXRvcicsXG4gICAgICAgICAgbWFjaGluZV9pZDogYi5tYWNoaW5lX2lkLFxuICAgICAgICAgIGNvbXB1dGVyX2Ruc19uYW1lOiBkZXZpY2VOYW1lLFxuICAgICAgICAgIHBlcmZvcm1lZF9ieTogdXNlcixcbiAgICAgICAgICByb2xlLFxuICAgICAgICAgIHN0YXR1czogJ2ZhaWx1cmUnLFxuICAgICAgICAgIG1lc3NhZ2U6IGVyciBpbnN0YW5jZW9mIEVycm9yID8gZXJyLm1lc3NhZ2UgOiBTdHJpbmcoZXJyKSxcbiAgICAgICAgICBzb3VyY2VfaXA6IChyZXEgYXMgYW55KS5pbmZvPy5yZW1vdGVBZGRyZXNzLFxuICAgICAgICAgIG90cF92ZXJpZmllZDogdHJ1ZSxcbiAgICAgICAgICBjb21tZW50LFxuICAgICAgICB9KTtcbiAgICAgICAgcmV0dXJuIHJlcy5jdXN0b21FcnJvcih7XG4gICAgICAgICAgc3RhdHVzQ29kZTogbWRlRXJyb3JTdGF0dXMoZXJyKSxcbiAgICAgICAgICBib2R5OiBlcnIgaW5zdGFuY2VvZiBFcnJvciA/IGVyci5tZXNzYWdlIDogU3RyaW5nKGVyciksXG4gICAgICAgIH0pO1xuICAgICAgfVxuICAgIH1cbiAgKTtcblxuICBjb25zdCB1cGRhdGVJbmRpY2F0b3JCb2R5ID0gc2NoZW1hLm9iamVjdCh7XG4gICAgaW5kaWNhdG9yX2lkOiBzY2hlbWEuc3RyaW5nKCksXG4gICAgbWFjaGluZV9pZDogc2NoZW1hLm1heWJlKHNjaGVtYS5zdHJpbmcoKSksXG4gICAgY29tcHV0ZXJfZG5zX25hbWU6IHNjaGVtYS5tYXliZShzY2hlbWEuc3RyaW5nKCkpLFxuICAgIGNvbW1lbnQ6IHNjaGVtYS5zdHJpbmcoKSxcbiAgICBvdHA6IHNjaGVtYS5zdHJpbmcoKSxcbiAgICB0aXRsZTogc2NoZW1hLm1heWJlKHNjaGVtYS5zdHJpbmcoKSksXG4gICAgZGVzY3JpcHRpb246IHNjaGVtYS5tYXliZShzY2hlbWEuc3RyaW5nKCkpLFxuICAgIGFjdGlvbjogc2NoZW1hLm1heWJlKFxuICAgICAgc2NoZW1hLm9uZU9mKFtcbiAgICAgICAgc2NoZW1hLmxpdGVyYWwoJ0FsZXJ0JyksXG4gICAgICAgIHNjaGVtYS5saXRlcmFsKCdBbGVydEFuZEJsb2NrJyksXG4gICAgICAgIHNjaGVtYS5saXRlcmFsKCdBbGxvd2VkJyksXG4gICAgICAgIHNjaGVtYS5saXRlcmFsKCdCbG9jaycpLFxuICAgICAgICBzY2hlbWEubGl0ZXJhbCgnQXVkaXQnKSxcbiAgICAgIF0pXG4gICAgKSxcbiAgICBzZXZlcml0eTogc2NoZW1hLm1heWJlKFxuICAgICAgc2NoZW1hLm9uZU9mKFtcbiAgICAgICAgc2NoZW1hLmxpdGVyYWwoJ0luZm9ybWF0aW9uYWwnKSxcbiAgICAgICAgc2NoZW1hLmxpdGVyYWwoJ0xvdycpLFxuICAgICAgICBzY2hlbWEubGl0ZXJhbCgnTWVkaXVtJyksXG4gICAgICAgIHNjaGVtYS5saXRlcmFsKCdIaWdoJyksXG4gICAgICBdKVxuICAgICksXG4gICAgZXhwaXJhdGlvbl90aW1lOiBzY2hlbWEubWF5YmUoc2NoZW1hLnN0cmluZygpKSxcbiAgfSk7XG5cbiAgcm91dGVyLnBvc3QoXG4gICAgeyBwYXRoOiAnL2FwaS9kZWZlbmRlcl9wbHVnaW4vYWN0aW9ucy91cGRhdGUtaW5kaWNhdG9yJywgdmFsaWRhdGU6IHsgYm9keTogdXBkYXRlSW5kaWNhdG9yQm9keSB9IH0sXG4gICAgYXN5bmMgKGNvbnRleHQsIHJlcSwgcmVzKSA9PiB7XG4gICAgICBjb25zdCBjb25maWcgPSBnZXRNZGVDb25maWcoKTtcbiAgICAgIGlmICghY29uZmlnKSB7XG4gICAgICAgIHJldHVybiByZXMuY3VzdG9tRXJyb3IoeyBzdGF0dXNDb2RlOiA1MDMsIGJvZHk6ICdEZWZlbmRlciBub3QgY29uZmlndXJlZC4nIH0pO1xuICAgICAgfVxuICAgICAgY29uc3QgeyB1c2VyLCByb2xlIH0gPSBnZXRVc2VyRnJvbVJlcXVlc3QocmVxKTtcbiAgICAgIGNvbnN0IGNsaWVudCA9IGNvbnRleHQuY29yZS5vcGVuc2VhcmNoLmNsaWVudC5hc0N1cnJlbnRVc2VyO1xuICAgICAgY29uc3QgYiA9IHJlcS5ib2R5IGFzIHtcbiAgICAgICAgaW5kaWNhdG9yX2lkOiBzdHJpbmc7XG4gICAgICAgIG1hY2hpbmVfaWQ/OiBzdHJpbmc7XG4gICAgICAgIGNvbXB1dGVyX2Ruc19uYW1lPzogc3RyaW5nO1xuICAgICAgICBjb21tZW50OiBzdHJpbmc7XG4gICAgICAgIG90cDogc3RyaW5nO1xuICAgICAgICB0aXRsZT86IHN0cmluZztcbiAgICAgICAgZGVzY3JpcHRpb24/OiBzdHJpbmc7XG4gICAgICAgIGFjdGlvbj86IHN0cmluZztcbiAgICAgICAgc2V2ZXJpdHk/OiBzdHJpbmc7XG4gICAgICAgIGV4cGlyYXRpb25fdGltZT86IHN0cmluZztcbiAgICAgIH07XG4gICAgICBjb25zdCBjb21tZW50ID0gKGIuY29tbWVudCB8fCAnJykudHJpbSgpO1xuICAgICAgaWYgKCFjb21tZW50KSB7XG4gICAgICAgIHJldHVybiByZXMuY3VzdG9tRXJyb3IoeyBzdGF0dXNDb2RlOiA0MDAsIGJvZHk6ICdDb21tZW50IGlzIHJlcXVpcmVkLicgfSk7XG4gICAgICB9XG4gICAgICBjb25zdCBvdHBDaGVjayA9IHZhbGlkYXRlT1RQKGIuaW5kaWNhdG9yX2lkLCAndXBkYXRlX2luZGljYXRvcicsIGIub3RwIHx8ICcnKTtcbiAgICAgIGlmICghb3RwQ2hlY2sudmFsaWQpIHtcbiAgICAgICAgcmV0dXJuIHJlcy5jdXN0b21FcnJvcih7IHN0YXR1c0NvZGU6IDQwMCwgYm9keTogb3RwQ2hlY2sucmVhc29uIHx8ICdPVFAgcmVxdWlyZWQnIH0pO1xuICAgICAgfVxuICAgICAgY29uc3QgZGV2aWNlTmFtZSA9IGIuY29tcHV0ZXJfZG5zX25hbWUgfHwgYi5tYWNoaW5lX2lkIHx8IGIuaW5kaWNhdG9yX2lkO1xuICAgICAgY29uc3QgcGF0Y2g6IFJlY29yZDxzdHJpbmcsIHVua25vd24+ID0ge307XG4gICAgICBpZiAoYi50aXRsZSAhPSBudWxsKSBwYXRjaC50aXRsZSA9IGIudGl0bGU7XG4gICAgICBpZiAoYi5kZXNjcmlwdGlvbiAhPSBudWxsKSBwYXRjaC5kZXNjcmlwdGlvbiA9IGIuZGVzY3JpcHRpb247XG4gICAgICBpZiAoYi5hY3Rpb24gIT0gbnVsbCkgcGF0Y2guYWN0aW9uID0gYi5hY3Rpb247XG4gICAgICBpZiAoYi5zZXZlcml0eSAhPSBudWxsKSBwYXRjaC5zZXZlcml0eSA9IGIuc2V2ZXJpdHk7XG4gICAgICBpZiAoYi5leHBpcmF0aW9uX3RpbWUgIT0gbnVsbCkgcGF0Y2guZXhwaXJhdGlvblRpbWUgPSBiLmV4cGlyYXRpb25fdGltZTtcbiAgICAgIGlmIChPYmplY3Qua2V5cyhwYXRjaCkubGVuZ3RoID09PSAwKSB7XG4gICAgICAgIHJldHVybiByZXMuY3VzdG9tRXJyb3IoeyBzdGF0dXNDb2RlOiA0MDAsIGJvZHk6ICdQcm92aWRlIGF0IGxlYXN0IG9uZSBmaWVsZCB0byB1cGRhdGUuJyB9KTtcbiAgICAgIH1cbiAgICAgIHRyeSB7XG4gICAgICAgIGNvbnN0IHJlc3VsdCA9IGF3YWl0IHVwZGF0ZUluZGljYXRvcihjb25maWcsIGIuaW5kaWNhdG9yX2lkLCBwYXRjaCk7XG4gICAgICAgIGNvbnN0IG1lc3NhZ2UgPSBKU09OLnN0cmluZ2lmeShyZXN1bHQpLnNsaWNlKDAsIDIwMDApO1xuICAgICAgICBhd2FpdCB3cml0ZUF1ZGl0TG9nKGNsaWVudCwge1xuICAgICAgICAgIGFjdGlvbjogJ3VwZGF0ZV9pbmRpY2F0b3InLFxuICAgICAgICAgIG1hY2hpbmVfaWQ6IGIubWFjaGluZV9pZCB8fCBiLmluZGljYXRvcl9pZCxcbiAgICAgICAgICBjb21wdXRlcl9kbnNfbmFtZTogZGV2aWNlTmFtZSxcbiAgICAgICAgICBwZXJmb3JtZWRfYnk6IHVzZXIsXG4gICAgICAgICAgcm9sZSxcbiAgICAgICAgICBzdGF0dXM6ICdzdWNjZXNzJyxcbiAgICAgICAgICBtZXNzYWdlLFxuICAgICAgICAgIHNvdXJjZV9pcDogKHJlcSBhcyBhbnkpLmluZm8/LnJlbW90ZUFkZHJlc3MsXG4gICAgICAgICAgb3RwX3ZlcmlmaWVkOiB0cnVlLFxuICAgICAgICAgIGNvbW1lbnQsXG4gICAgICAgIH0pO1xuICAgICAgICByZXR1cm4gcmVzLm9rKHtcbiAgICAgICAgICBib2R5OiB7XG4gICAgICAgICAgICBzdWNjZXNzOiB0cnVlLFxuICAgICAgICAgICAgYWN0aW9uOiAndXBkYXRlX2luZGljYXRvcicsXG4gICAgICAgICAgICBpbmRpY2F0b3JfaWQ6IGIuaW5kaWNhdG9yX2lkLFxuICAgICAgICAgICAgbWVzc2FnZSxcbiAgICAgICAgICAgIHRpbWVzdGFtcDogbmV3IERhdGUoKS50b0lTT1N0cmluZygpLFxuICAgICAgICAgIH0sXG4gICAgICAgIH0pO1xuICAgICAgfSBjYXRjaCAoZXJyOiB1bmtub3duKSB7XG4gICAgICAgIGF3YWl0IHdyaXRlQXVkaXRMb2coY2xpZW50LCB7XG4gICAgICAgICAgYWN0aW9uOiAndXBkYXRlX2luZGljYXRvcicsXG4gICAgICAgICAgbWFjaGluZV9pZDogYi5tYWNoaW5lX2lkIHx8IGIuaW5kaWNhdG9yX2lkLFxuICAgICAgICAgIGNvbXB1dGVyX2Ruc19uYW1lOiBkZXZpY2VOYW1lLFxuICAgICAgICAgIHBlcmZvcm1lZF9ieTogdXNlcixcbiAgICAgICAgICByb2xlLFxuICAgICAgICAgIHN0YXR1czogJ2ZhaWx1cmUnLFxuICAgICAgICAgIG1lc3NhZ2U6IGVyciBpbnN0YW5jZW9mIEVycm9yID8gZXJyLm1lc3NhZ2UgOiBTdHJpbmcoZXJyKSxcbiAgICAgICAgICBzb3VyY2VfaXA6IChyZXEgYXMgYW55KS5pbmZvPy5yZW1vdGVBZGRyZXNzLFxuICAgICAgICAgIG90cF92ZXJpZmllZDogdHJ1ZSxcbiAgICAgICAgICBjb21tZW50LFxuICAgICAgICB9KTtcbiAgICAgICAgcmV0dXJuIHJlcy5jdXN0b21FcnJvcih7XG4gICAgICAgICAgc3RhdHVzQ29kZTogbWRlRXJyb3JTdGF0dXMoZXJyKSxcbiAgICAgICAgICBib2R5OiBlcnIgaW5zdGFuY2VvZiBFcnJvciA/IGVyci5tZXNzYWdlIDogU3RyaW5nKGVyciksXG4gICAgICAgIH0pO1xuICAgICAgfVxuICAgIH1cbiAgKTtcblxuICByb3V0ZXIucG9zdChcbiAgICB7XG4gICAgICBwYXRoOiAnL2FwaS9kZWZlbmRlcl9wbHVnaW4vYWN0aW9ucy9yZXF1ZXN0LW90cC1pbmRpY2F0b3InLFxuICAgICAgdmFsaWRhdGU6IHtcbiAgICAgICAgYm9keTogc2NoZW1hLm9iamVjdCh7XG4gICAgICAgICAgbWFjaGluZV9pZDogc2NoZW1hLnN0cmluZygpLFxuICAgICAgICAgIGNvbXB1dGVyX2Ruc19uYW1lOiBzY2hlbWEubWF5YmUoc2NoZW1hLnN0cmluZygpKSxcbiAgICAgICAgICBvdHBfY29udGV4dF9pZDogc2NoZW1hLm1heWJlKHNjaGVtYS5zdHJpbmcoKSksXG4gICAgICAgIH0pLFxuICAgICAgfSxcbiAgICB9LFxuICAgIGFzeW5jIChfY29udGV4dCwgcmVxLCByZXMpID0+IHtcbiAgICAgIGNvbnN0IHsgbWFjaGluZV9pZCwgY29tcHV0ZXJfZG5zX25hbWUsIG90cF9jb250ZXh0X2lkIH0gPSByZXEuYm9keSBhcyB7XG4gICAgICAgIG1hY2hpbmVfaWQ6IHN0cmluZztcbiAgICAgICAgY29tcHV0ZXJfZG5zX25hbWU/OiBzdHJpbmc7XG4gICAgICAgIG90cF9jb250ZXh0X2lkPzogc3RyaW5nO1xuICAgICAgfTtcbiAgICAgIGNvbnN0IGN0eCA9IChvdHBfY29udGV4dF9pZCB8fCBtYWNoaW5lX2lkKS50cmltKCk7XG4gICAgICBjb25zdCBvdHAgPSBnZW5lcmF0ZU9UUCgpO1xuICAgICAgc3RvcmVPVFAoY3R4LCAnY3JlYXRlX2luZGljYXRvcicsIG90cCk7XG4gICAgICBjb25zdCBlbWFpbFJlc3VsdCA9IGF3YWl0IHNlbmRPVFBFbWFpbChcbiAgICAgICAgZ2V0T1RQQ29uZmlnKCksXG4gICAgICAgIG90cCxcbiAgICAgICAgY29tcHV0ZXJfZG5zX25hbWUgfHwgbWFjaGluZV9pZCxcbiAgICAgICAgJ2NyZWF0ZV9pbmRpY2F0b3InXG4gICAgICApO1xuICAgICAgcmV0dXJuIHJlcy5vayh7XG4gICAgICAgIGJvZHk6IHtcbiAgICAgICAgICBzdWNjZXNzOiB0cnVlLFxuICAgICAgICAgIG1lc3NhZ2U6IGVtYWlsUmVzdWx0LnNlbnQgPyAnT1RQIHNlbnQuJyA6ICdPVFAgZ2VuZXJhdGVkLicsXG4gICAgICAgICAgZGV2X21vZGU6IGVtYWlsUmVzdWx0LmRldk1vZGUsXG4gICAgICAgICAgb3RwOiBlbWFpbFJlc3VsdC5kZXZNb2RlID8gZW1haWxSZXN1bHQub3RwIDogdW5kZWZpbmVkLFxuICAgICAgICB9LFxuICAgICAgfSk7XG4gICAgfVxuICApO1xuXG4gIGNvbnN0IGRlbGV0ZUluZGljYXRvckJvZHkgPSBzY2hlbWEub2JqZWN0KHtcbiAgICBpbmRpY2F0b3JfaWQ6IHNjaGVtYS5zdHJpbmcoKSxcbiAgICBtYWNoaW5lX2lkOiBzY2hlbWEubWF5YmUoc2NoZW1hLnN0cmluZygpKSxcbiAgICBjb21wdXRlcl9kbnNfbmFtZTogc2NoZW1hLm1heWJlKHNjaGVtYS5zdHJpbmcoKSksXG4gICAgY29tbWVudDogc2NoZW1hLnN0cmluZygpLFxuICAgIG90cDogc2NoZW1hLnN0cmluZygpLFxuICB9KTtcblxuICByb3V0ZXIucG9zdChcbiAgICB7IHBhdGg6ICcvYXBpL2RlZmVuZGVyX3BsdWdpbi9hY3Rpb25zL2RlbGV0ZS1pbmRpY2F0b3InLCB2YWxpZGF0ZTogeyBib2R5OiBkZWxldGVJbmRpY2F0b3JCb2R5IH0gfSxcbiAgICBhc3luYyAoY29udGV4dCwgcmVxLCByZXMpID0+IHtcbiAgICAgIGNvbnN0IGNvbmZpZyA9IGdldE1kZUNvbmZpZygpO1xuICAgICAgaWYgKCFjb25maWcpIHtcbiAgICAgICAgcmV0dXJuIHJlcy5jdXN0b21FcnJvcih7IHN0YXR1c0NvZGU6IDUwMywgYm9keTogJ0RlZmVuZGVyIG5vdCBjb25maWd1cmVkLicgfSk7XG4gICAgICB9XG4gICAgICBjb25zdCB7IHVzZXIsIHJvbGUgfSA9IGdldFVzZXJGcm9tUmVxdWVzdChyZXEpO1xuICAgICAgY29uc3QgY2xpZW50ID0gY29udGV4dC5jb3JlLm9wZW5zZWFyY2guY2xpZW50LmFzQ3VycmVudFVzZXI7XG4gICAgICBjb25zdCBiID0gcmVxLmJvZHkgYXMge1xuICAgICAgICBpbmRpY2F0b3JfaWQ6IHN0cmluZztcbiAgICAgICAgbWFjaGluZV9pZD86IHN0cmluZztcbiAgICAgICAgY29tcHV0ZXJfZG5zX25hbWU/OiBzdHJpbmc7XG4gICAgICAgIGNvbW1lbnQ6IHN0cmluZztcbiAgICAgICAgb3RwOiBzdHJpbmc7XG4gICAgICB9O1xuICAgICAgY29uc3QgY29tbWVudCA9IChiLmNvbW1lbnQgfHwgJycpLnRyaW0oKTtcbiAgICAgIGlmICghY29tbWVudCkge1xuICAgICAgICByZXR1cm4gcmVzLmN1c3RvbUVycm9yKHsgc3RhdHVzQ29kZTogNDAwLCBib2R5OiAnQ29tbWVudCBpcyByZXF1aXJlZC4nIH0pO1xuICAgICAgfVxuICAgICAgY29uc3Qgb3RwQ2hlY2sgPSB2YWxpZGF0ZU9UUChiLmluZGljYXRvcl9pZCwgJ2RlbGV0ZV9pbmRpY2F0b3InLCBiLm90cCB8fCAnJyk7XG4gICAgICBpZiAoIW90cENoZWNrLnZhbGlkKSB7XG4gICAgICAgIHJldHVybiByZXMuY3VzdG9tRXJyb3IoeyBzdGF0dXNDb2RlOiA0MDAsIGJvZHk6IG90cENoZWNrLnJlYXNvbiB8fCAnT1RQIHJlcXVpcmVkJyB9KTtcbiAgICAgIH1cbiAgICAgIGNvbnN0IGRldmljZU5hbWUgPSBiLmNvbXB1dGVyX2Ruc19uYW1lIHx8IGIubWFjaGluZV9pZCB8fCBiLmluZGljYXRvcl9pZDtcbiAgICAgIHRyeSB7XG4gICAgICAgIGNvbnN0IHJlc3VsdCA9IGF3YWl0IGRlbGV0ZUluZGljYXRvcihjb25maWcsIGIuaW5kaWNhdG9yX2lkKTtcbiAgICAgICAgY29uc3QgbWVzc2FnZSA9IEpTT04uc3RyaW5naWZ5KHJlc3VsdCkuc2xpY2UoMCwgMjAwMCk7XG4gICAgICAgIGF3YWl0IHdyaXRlQXVkaXRMb2coY2xpZW50LCB7XG4gICAgICAgICAgYWN0aW9uOiAnZGVsZXRlX2luZGljYXRvcicsXG4gICAgICAgICAgbWFjaGluZV9pZDogYi5tYWNoaW5lX2lkIHx8IGIuaW5kaWNhdG9yX2lkLFxuICAgICAgICAgIGNvbXB1dGVyX2Ruc19uYW1lOiBkZXZpY2VOYW1lLFxuICAgICAgICAgIHBlcmZvcm1lZF9ieTogdXNlcixcbiAgICAgICAgICByb2xlLFxuICAgICAgICAgIHN0YXR1czogJ3N1Y2Nlc3MnLFxuICAgICAgICAgIG1lc3NhZ2UsXG4gICAgICAgICAgc291cmNlX2lwOiAocmVxIGFzIGFueSkuaW5mbz8ucmVtb3RlQWRkcmVzcyxcbiAgICAgICAgICBvdHBfdmVyaWZpZWQ6IHRydWUsXG4gICAgICAgICAgY29tbWVudCxcbiAgICAgICAgfSk7XG4gICAgICAgIHJldHVybiByZXMub2soe1xuICAgICAgICAgIGJvZHk6IHtcbiAgICAgICAgICAgIHN1Y2Nlc3M6IHRydWUsXG4gICAgICAgICAgICBhY3Rpb246ICdkZWxldGVfaW5kaWNhdG9yJyxcbiAgICAgICAgICAgIG1hY2hpbmVfaWQ6IGIubWFjaGluZV9pZCB8fCBiLmluZGljYXRvcl9pZCxcbiAgICAgICAgICAgIG1lc3NhZ2UsXG4gICAgICAgICAgICB0aW1lc3RhbXA6IG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKSxcbiAgICAgICAgICB9LFxuICAgICAgICB9KTtcbiAgICAgIH0gY2F0Y2ggKGVycjogdW5rbm93bikge1xuICAgICAgICBhd2FpdCB3cml0ZUF1ZGl0TG9nKGNsaWVudCwge1xuICAgICAgICAgIGFjdGlvbjogJ2RlbGV0ZV9pbmRpY2F0b3InLFxuICAgICAgICAgIG1hY2hpbmVfaWQ6IGIubWFjaGluZV9pZCB8fCBiLmluZGljYXRvcl9pZCxcbiAgICAgICAgICBjb21wdXRlcl9kbnNfbmFtZTogZGV2aWNlTmFtZSxcbiAgICAgICAgICBwZXJmb3JtZWRfYnk6IHVzZXIsXG4gICAgICAgICAgcm9sZSxcbiAgICAgICAgICBzdGF0dXM6ICdmYWlsdXJlJyxcbiAgICAgICAgICBtZXNzYWdlOiBlcnIgaW5zdGFuY2VvZiBFcnJvciA/IGVyci5tZXNzYWdlIDogU3RyaW5nKGVyciksXG4gICAgICAgICAgc291cmNlX2lwOiAocmVxIGFzIGFueSkuaW5mbz8ucmVtb3RlQWRkcmVzcyxcbiAgICAgICAgICBvdHBfdmVyaWZpZWQ6IHRydWUsXG4gICAgICAgICAgY29tbWVudCxcbiAgICAgICAgfSk7XG4gICAgICAgIHJldHVybiByZXMuY3VzdG9tRXJyb3Ioe1xuICAgICAgICAgIHN0YXR1c0NvZGU6IG1kZUVycm9yU3RhdHVzKGVyciksXG4gICAgICAgICAgYm9keTogZXJyIGluc3RhbmNlb2YgRXJyb3IgPyBlcnIubWVzc2FnZSA6IFN0cmluZyhlcnIpLFxuICAgICAgICB9KTtcbiAgICAgIH1cbiAgICB9XG4gICk7XG5cbiAgcm91dGVyLnBvc3QoXG4gICAge1xuICAgICAgcGF0aDogJy9hcGkvZGVmZW5kZXJfcGx1Z2luL2FjdGlvbnMvcmVxdWVzdC1vdHAtZGVsZXRlLWluZGljYXRvcicsXG4gICAgICB2YWxpZGF0ZToge1xuICAgICAgICBib2R5OiBzY2hlbWEub2JqZWN0KHtcbiAgICAgICAgICBpbmRpY2F0b3JfaWQ6IHNjaGVtYS5zdHJpbmcoKSxcbiAgICAgICAgICBjb21wdXRlcl9kbnNfbmFtZTogc2NoZW1hLm1heWJlKHNjaGVtYS5zdHJpbmcoKSksXG4gICAgICAgIH0pLFxuICAgICAgfSxcbiAgICB9LFxuICAgIGFzeW5jIChfY29udGV4dCwgcmVxLCByZXMpID0+IHtcbiAgICAgIGNvbnN0IHsgaW5kaWNhdG9yX2lkLCBjb21wdXRlcl9kbnNfbmFtZSB9ID0gcmVxLmJvZHkgYXMge1xuICAgICAgICBpbmRpY2F0b3JfaWQ6IHN0cmluZztcbiAgICAgICAgY29tcHV0ZXJfZG5zX25hbWU/OiBzdHJpbmc7XG4gICAgICB9O1xuICAgICAgY29uc3Qgb3RwID0gZ2VuZXJhdGVPVFAoKTtcbiAgICAgIHN0b3JlT1RQKGluZGljYXRvcl9pZCwgJ2RlbGV0ZV9pbmRpY2F0b3InLCBvdHApO1xuICAgICAgY29uc3QgZW1haWxSZXN1bHQgPSBhd2FpdCBzZW5kT1RQRW1haWwoXG4gICAgICAgIGdldE9UUENvbmZpZygpLFxuICAgICAgICBvdHAsXG4gICAgICAgIGNvbXB1dGVyX2Ruc19uYW1lIHx8IGluZGljYXRvcl9pZCxcbiAgICAgICAgJ2RlbGV0ZV9pbmRpY2F0b3InXG4gICAgICApO1xuICAgICAgcmV0dXJuIHJlcy5vayh7XG4gICAgICAgIGJvZHk6IHtcbiAgICAgICAgICBzdWNjZXNzOiB0cnVlLFxuICAgICAgICAgIGRldl9tb2RlOiBlbWFpbFJlc3VsdC5kZXZNb2RlLFxuICAgICAgICAgIG90cDogZW1haWxSZXN1bHQuZGV2TW9kZSA/IGVtYWlsUmVzdWx0Lm90cCA6IHVuZGVmaW5lZCxcbiAgICAgICAgfSxcbiAgICAgIH0pO1xuICAgIH1cbiAgKTtcblxuICByb3V0ZXIucG9zdChcbiAgICB7XG4gICAgICBwYXRoOiAnL2FwaS9kZWZlbmRlcl9wbHVnaW4vYWN0aW9ucy9yZXF1ZXN0LW90cC11cGRhdGUtaW5kaWNhdG9yJyxcbiAgICAgIHZhbGlkYXRlOiB7XG4gICAgICAgIGJvZHk6IHNjaGVtYS5vYmplY3Qoe1xuICAgICAgICAgIGluZGljYXRvcl9pZDogc2NoZW1hLnN0cmluZygpLFxuICAgICAgICAgIGNvbXB1dGVyX2Ruc19uYW1lOiBzY2hlbWEubWF5YmUoc2NoZW1hLnN0cmluZygpKSxcbiAgICAgICAgfSksXG4gICAgICB9LFxuICAgIH0sXG4gICAgYXN5bmMgKF9jb250ZXh0LCByZXEsIHJlcykgPT4ge1xuICAgICAgY29uc3QgeyBpbmRpY2F0b3JfaWQsIGNvbXB1dGVyX2Ruc19uYW1lIH0gPSByZXEuYm9keSBhcyB7XG4gICAgICAgIGluZGljYXRvcl9pZDogc3RyaW5nO1xuICAgICAgICBjb21wdXRlcl9kbnNfbmFtZT86IHN0cmluZztcbiAgICAgIH07XG4gICAgICBjb25zdCBvdHAgPSBnZW5lcmF0ZU9UUCgpO1xuICAgICAgc3RvcmVPVFAoaW5kaWNhdG9yX2lkLCAndXBkYXRlX2luZGljYXRvcicsIG90cCk7XG4gICAgICBjb25zdCBlbWFpbFJlc3VsdCA9IGF3YWl0IHNlbmRPVFBFbWFpbChcbiAgICAgICAgZ2V0T1RQQ29uZmlnKCksXG4gICAgICAgIG90cCxcbiAgICAgICAgY29tcHV0ZXJfZG5zX25hbWUgfHwgaW5kaWNhdG9yX2lkLFxuICAgICAgICAndXBkYXRlX2luZGljYXRvcidcbiAgICAgICk7XG4gICAgICByZXR1cm4gcmVzLm9rKHtcbiAgICAgICAgYm9keToge1xuICAgICAgICAgIHN1Y2Nlc3M6IHRydWUsXG4gICAgICAgICAgZGV2X21vZGU6IGVtYWlsUmVzdWx0LmRldk1vZGUsXG4gICAgICAgICAgb3RwOiBlbWFpbFJlc3VsdC5kZXZNb2RlID8gZW1haWxSZXN1bHQub3RwIDogdW5kZWZpbmVkLFxuICAgICAgICB9LFxuICAgICAgfSk7XG4gICAgfVxuICApO1xufVxuIl0sIm1hcHBpbmdzIjoiOzs7Ozs7QUFLQSxJQUFBQSxhQUFBLEdBQUFDLE9BQUE7QUFDQSxJQUFBQyxVQUFBLEdBQUFELE9BQUE7QUFDQSxJQUFBRSxVQUFBLEdBQUFGLE9BQUE7QUFpQkEsSUFBQUcsSUFBQSxHQUFBSCxPQUFBO0FBeEJBO0FBQ0E7QUFDQTs7QUF3QkEsU0FBU0ksa0JBQWtCQSxDQUFDQyxHQUFRLEVBQWtDO0VBQUEsSUFBQUMsWUFBQSxFQUFBQyxhQUFBO0VBQ3BFLE1BQU1DLElBQUksR0FBRyxFQUFBRixZQUFBLEdBQUNELEdBQUcsQ0FBQ0ksT0FBTyxjQUFBSCxZQUFBLHVCQUFYQSxZQUFBLENBQWMsaUJBQWlCLENBQUMsS0FBZSxnQkFBZ0I7RUFDN0UsTUFBTUksSUFBSSxHQUFHLEVBQUFILGFBQUEsR0FBQ0YsR0FBRyxDQUFDSSxPQUFPLGNBQUFGLGFBQUEsdUJBQVhBLGFBQUEsQ0FBYyxpQkFBaUIsQ0FBQyxLQUFlLG1CQUFtQjtFQUNoRixPQUFPO0lBQUVDLElBQUk7SUFBRUU7RUFBSyxDQUFDO0FBQ3ZCO0FBRUEsU0FBU0MsWUFBWUEsQ0FBQSxFQUFtQjtFQUN0QyxPQUFPO0lBQ0xDLFFBQVEsRUFBRUMsT0FBTyxDQUFDQyxHQUFHLENBQUNDLFNBQVM7SUFDL0JDLFFBQVEsRUFBRUgsT0FBTyxDQUFDQyxHQUFHLENBQUNHLFNBQVMsR0FBR0MsUUFBUSxDQUFDTCxPQUFPLENBQUNDLEdBQUcsQ0FBQ0csU0FBUyxFQUFFLEVBQUUsQ0FBQyxHQUFHLEdBQUc7SUFDM0VFLFFBQVEsRUFBRU4sT0FBTyxDQUFDQyxHQUFHLENBQUNNLFNBQVM7SUFDL0JDLFFBQVEsRUFBRVIsT0FBTyxDQUFDQyxHQUFHLENBQUNRLFNBQVM7SUFDL0JDLGlCQUFpQixFQUFFVixPQUFPLENBQUNDLEdBQUcsQ0FBQ1UsbUJBQW1CO0lBQ2xEQyxVQUFVLEVBQUVaLE9BQU8sQ0FBQ0MsR0FBRyxDQUFDWSxXQUFXLEtBQUs7RUFDMUMsQ0FBQztBQUNIO0FBRUEsU0FBU0MsVUFBVUEsQ0FBQ0MsSUFBc0QsRUFBVTtFQUNsRixNQUFNQyxDQUFDLEdBQUcsQ0FBQ0QsSUFBSSxDQUFDRSxjQUFjLElBQUlGLElBQUksQ0FBQ0csVUFBVSxJQUFJLEVBQUUsRUFBRUMsSUFBSSxDQUFDLENBQUM7RUFDL0QsT0FBT0gsQ0FBQztBQUNWO0FBRUEsZUFBZUksYUFBYUEsQ0FDMUJDLE1BQVcsRUFDWEMsS0FXQyxFQUNEO0VBQ0EsSUFBSTtJQUNGLE1BQU1ELE1BQU0sQ0FBQ0UsS0FBSyxDQUFDO01BQ2pCQSxLQUFLLEVBQUVuQyxVQUFBLENBQUFvQyx3QkFBd0I7TUFDL0JULElBQUksRUFBRTtRQUFFLEdBQUdPLEtBQUs7UUFBRUcsU0FBUyxFQUFFLElBQUlDLElBQUksQ0FBQyxDQUFDLENBQUNDLFdBQVcsQ0FBQztNQUFFO0lBQ3hELENBQUMsQ0FBQztFQUNKLENBQUMsQ0FBQyxPQUFPQyxHQUFHLEVBQUU7SUFDWkMsT0FBTyxDQUFDQyxLQUFLLENBQUMsb0NBQW9DLEVBQUVGLEdBQUcsQ0FBQztFQUMxRDtBQUNGO0FBRUEsTUFBTUcsY0FBYyxHQUFHN0MsYUFBQSxDQUFBOEMsTUFBTSxDQUFDQyxLQUFLLENBQUMsQ0FBQy9DLGFBQUEsQ0FBQThDLE1BQU0sQ0FBQ0UsT0FBTyxDQUFDLE9BQU8sQ0FBQyxFQUFFaEQsYUFBQSxDQUFBOEMsTUFBTSxDQUFDRSxPQUFPLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQztBQUN0RixNQUFNQyxtQkFBbUIsR0FBR2pELGFBQUEsQ0FBQThDLE1BQU0sQ0FBQ0MsS0FBSyxDQUFDLENBQ3ZDL0MsYUFBQSxDQUFBOEMsTUFBTSxDQUFDRSxPQUFPLENBQUMsTUFBTSxDQUFDLEVBQ3RCaEQsYUFBQSxDQUFBOEMsTUFBTSxDQUFDRSxPQUFPLENBQUMsV0FBVyxDQUFDLEVBQzNCaEQsYUFBQSxDQUFBOEMsTUFBTSxDQUFDRSxPQUFPLENBQUMsaUJBQWlCLENBQUMsQ0FDbEMsQ0FBQzs7QUFFRjtBQUNBLE1BQU1FLGlCQUFpQixHQUFHbEQsYUFBQSxDQUFBOEMsTUFBTSxDQUFDSyxNQUFNLENBQUM7RUFDdENuQixVQUFVLEVBQUVoQyxhQUFBLENBQUE4QyxNQUFNLENBQUNNLE1BQU0sQ0FBQyxDQUFDO0VBQzNCQyxpQkFBaUIsRUFBRXJELGFBQUEsQ0FBQThDLE1BQU0sQ0FBQ1EsS0FBSyxDQUFDdEQsYUFBQSxDQUFBOEMsTUFBTSxDQUFDTSxNQUFNLENBQUMsQ0FBQyxDQUFDO0VBQ2hERyxPQUFPLEVBQUV2RCxhQUFBLENBQUE4QyxNQUFNLENBQUNNLE1BQU0sQ0FBQyxDQUFDO0VBQ3hCSSxHQUFHLEVBQUV4RCxhQUFBLENBQUE4QyxNQUFNLENBQUNNLE1BQU0sQ0FBQyxDQUFDO0VBQ3BCckIsY0FBYyxFQUFFL0IsYUFBQSxDQUFBOEMsTUFBTSxDQUFDUSxLQUFLLENBQUN0RCxhQUFBLENBQUE4QyxNQUFNLENBQUNNLE1BQU0sQ0FBQyxDQUFDLENBQUM7RUFDN0NLLFNBQVMsRUFBRXpELGFBQUEsQ0FBQThDLE1BQU0sQ0FBQ1EsS0FBSyxDQUFDVCxjQUFjLENBQUM7RUFDdkNhLGNBQWMsRUFBRTFELGFBQUEsQ0FBQThDLE1BQU0sQ0FBQ1EsS0FBSyxDQUFDTCxtQkFBbUI7QUFDbEQsQ0FBQyxDQUFDO0FBRUssU0FBU1UsNEJBQTRCQSxDQUFDQyxNQUFlLEVBQUU7RUFDNUQsTUFBTUMsZ0JBQWdCLEdBQUdBLENBQ3ZCQyxJQUFZLEVBQ1pDLFVBQWtCLEVBQ2xCQyxFQVFxQixLQUNsQjtJQUNISixNQUFNLENBQUNLLElBQUksQ0FDVDtNQUFFSCxJQUFJO01BQUVJLFFBQVEsRUFBRTtRQUFFckMsSUFBSSxFQUFFcUI7TUFBa0I7SUFBRSxDQUFDLEVBQy9DLE9BQU9pQixPQUFPLEVBQUU3RCxHQUFHLEVBQUU4RCxHQUFHLEtBQUs7TUFDM0IsTUFBTUMsTUFBTSxHQUFHLElBQUFsRSxVQUFBLENBQUFtRSxZQUFZLEVBQUMsQ0FBQztNQUM3QixJQUFJLENBQUNELE1BQU0sRUFBRTtRQUNYLE9BQU9ELEdBQUcsQ0FBQ0csV0FBVyxDQUFDO1VBQ3JCQyxVQUFVLEVBQUUsR0FBRztVQUNmM0MsSUFBSSxFQUFFO1FBQ1IsQ0FBQyxDQUFDO01BQ0o7TUFDQSxNQUFNO1FBQUVwQixJQUFJO1FBQUVFO01BQUssQ0FBQyxHQUFHTixrQkFBa0IsQ0FBQ0MsR0FBRyxDQUFDO01BQzlDLE1BQU02QixNQUFNLEdBQUdnQyxPQUFPLENBQUNNLElBQUksQ0FBQ0MsVUFBVSxDQUFDdkMsTUFBTSxDQUFDd0MsYUFBYTtNQUMzRCxNQUFNOUMsSUFBSSxHQUFHdkIsR0FBRyxDQUFDdUIsSUFRaEI7TUFDRCxNQUFNMEIsT0FBTyxHQUFHLENBQUMxQixJQUFJLENBQUMwQixPQUFPLElBQUksRUFBRSxFQUFFdEIsSUFBSSxDQUFDLENBQUM7TUFDM0MsSUFBSSxDQUFDc0IsT0FBTyxFQUFFO1FBQ1osT0FBT2EsR0FBRyxDQUFDRyxXQUFXLENBQUM7VUFBRUMsVUFBVSxFQUFFLEdBQUc7VUFBRTNDLElBQUksRUFBRTtRQUF1QixDQUFDLENBQUM7TUFDM0U7TUFDQSxNQUFNK0MsR0FBRyxHQUFHaEQsVUFBVSxDQUFDQyxJQUFJLENBQUM7TUFDNUIsSUFBSSxDQUFDK0MsR0FBRyxFQUFFO1FBQ1IsT0FBT1IsR0FBRyxDQUFDRyxXQUFXLENBQUM7VUFBRUMsVUFBVSxFQUFFLEdBQUc7VUFBRTNDLElBQUksRUFBRTtRQUF5QyxDQUFDLENBQUM7TUFDN0Y7TUFDQSxNQUFNZ0QsUUFBUSxHQUFHLElBQUF6RSxJQUFBLENBQUEwRSxXQUFXLEVBQUNGLEdBQUcsRUFBRWIsVUFBVSxFQUFFbEMsSUFBSSxDQUFDMkIsR0FBRyxJQUFJLEVBQUUsQ0FBQztNQUM3RCxJQUFJLENBQUNxQixRQUFRLENBQUNFLEtBQUssRUFBRTtRQUNuQixPQUFPWCxHQUFHLENBQUNHLFdBQVcsQ0FBQztVQUFFQyxVQUFVLEVBQUUsR0FBRztVQUFFM0MsSUFBSSxFQUFFZ0QsUUFBUSxDQUFDRyxNQUFNLElBQUk7UUFBZSxDQUFDLENBQUM7TUFDdEY7TUFDQSxNQUFNQyxVQUFVLEdBQUdwRCxJQUFJLENBQUN3QixpQkFBaUIsSUFBSXhCLElBQUksQ0FBQ0csVUFBVTtNQUU1RCxJQUFJO1FBQUEsSUFBQWtELEtBQUE7UUFDRixNQUFNQyxNQUFNLEdBQUcsTUFBTW5CLEVBQUUsQ0FBQ0ssTUFBTSxFQUFFO1VBQzlCckMsVUFBVSxFQUFFSCxJQUFJLENBQUNHLFVBQVU7VUFDM0J1QixPQUFPO1VBQ1BFLFNBQVMsRUFBRTVCLElBQUksQ0FBQzRCLFNBQVM7VUFDekJDLGNBQWMsRUFBRTdCLElBQUksQ0FBQzZCO1FBQ3ZCLENBQUMsQ0FBQztRQUNGLE1BQU0wQixPQUFPLEdBQUdDLElBQUksQ0FBQ0MsU0FBUyxDQUFDSCxNQUFNLENBQUMsQ0FBQ0ksS0FBSyxDQUFDLENBQUMsRUFBRSxJQUFJLENBQUM7UUFDckQsTUFBTXJELGFBQWEsQ0FBQ0MsTUFBTSxFQUFFO1VBQzFCcUQsTUFBTSxFQUFFekIsVUFBVTtVQUNsQi9CLFVBQVUsRUFBRUgsSUFBSSxDQUFDRyxVQUFVO1VBQzNCcUIsaUJBQWlCLEVBQUU0QixVQUFVO1VBQzdCUSxZQUFZLEVBQUVoRixJQUFJO1VBQ2xCRSxJQUFJO1VBQ0orRSxNQUFNLEVBQUUsU0FBUztVQUNqQk4sT0FBTztVQUNQTyxTQUFTLEdBQUFULEtBQUEsR0FBRzVFLEdBQUcsQ0FBU3NGLElBQUksY0FBQVYsS0FBQSx1QkFBakJBLEtBQUEsQ0FBbUJXLGFBQWE7VUFDM0NDLFlBQVksRUFBRSxJQUFJO1VBQ2xCdkM7UUFDRixDQUFDLENBQUM7UUFDRixPQUFPYSxHQUFHLENBQUMyQixFQUFFLENBQUM7VUFDWmxFLElBQUksRUFBRTtZQUNKbUUsT0FBTyxFQUFFLElBQUk7WUFDYlIsTUFBTSxFQUFFekIsVUFBVTtZQUNsQi9CLFVBQVUsRUFBRUgsSUFBSSxDQUFDRyxVQUFVO1lBQzNCb0QsT0FBTztZQUNQN0MsU0FBUyxFQUFFLElBQUlDLElBQUksQ0FBQyxDQUFDLENBQUNDLFdBQVcsQ0FBQztVQUNwQztRQUNGLENBQUMsQ0FBQztNQUNKLENBQUMsQ0FBQyxPQUFPQyxHQUFZLEVBQUU7UUFBQSxJQUFBdUQsTUFBQTtRQUNyQixNQUFNQyxhQUFhLEdBQUN4RCxHQUFBLElBQVEsUUFBQUEsR0FBQSxDQUFBZ0QsTUFBQSxXQUFBaEQsR0FBQSxDQUFBZ0QsTUFBQTtjQUMxQlMsY0FBa0IsR0FBQXpELEdBQUEsSUFBQUEsR0FBQSxDQUFBMEQsWUFBQSxHQUFBQyxNQUFBLENBQUEzRCxHQUFBLENBQUEwRCxZQUFBLEVBQUFiLEtBQUE7Y0FDbEJlLFNBQVksR0FBSzVELEdBQUEsS0FBQUEsR0FBVSxDQUFBNkQsSUFBQSxJQUFBN0QsR0FBQSxDQUFBOEQsV0FBQSxJQUFBOUQsR0FBQSxDQUFBOEQsV0FBQSxDQUFBRCxJQUFBO2NBQzNCRSxZQUFBLEdBQW1CL0QsR0FBQSxZQUFVZ0UsS0FBQSxHQUFBaEUsR0FBQSxDQUFBMEMsT0FBQSxHQUFBaUIsTUFBQSxDQUFBM0QsR0FBQTtlQUM3QixDQUFBRSxLQUFBLENBQVksb0JBQU0sR0FBQW1CLFVBQUEsdUJBQUF1QyxTQUFBLGNBQUFKLGFBQUEsYUFBQU8sWUFBQTtjQUNkdkUsYUFBQSxDQUFBQyxNQUFBO1VBQ0pxRCxNQUFNLEVBQUV6QixVQUFTO1VBQ2pCL0IsVUFBUyxFQUFHSCxJQUFBLENBQUFHLFVBQVk7VUFDeEJxQixpQkFBUyxFQUFBNEIsVUFBbUI7VUFDNUJRLFlBQVksRUFBRWhGLElBQUk7VUFDbEJFLElBQUE7VUFDQStFLE1BQUE7VUFDRk4sT0FBTyxFQUFJcUIsWUFBWTtVQUNyQkUsZUFBWSxFQUFBVCxhQUFBO1VBQ1pVLGdCQUFTLEVBQUFULGNBQXVCLElBQUNHLFNBQVU7VUFDM0NYLFNBQUEsR0FBQU0sTUFBQSxHQUFBM0YsR0FBQSxDQUFBc0YsSUFBQSxjQUFBSyxNQUFBLHVCQUFBQSxNQUFBLENBQUFKLGFBQUE7VUFDSkMsWUFBQTtVQUVIdkM7UUFDRjtRQUVELE9BQUFhLEdBQWdCLENBQUNHLFdBQUE7VUFJakJDLFVBQWlCLE1BQUFyRSxVQUFBLENBQUEwRyxjQUFBLEVBQUFuRSxHQUFBLENBQXNDO1VBSXZEYixJQUFBLEVBQUE0RTtRQUlBO01BTUE7SUFNQTtFQU1BO0VBSUE1QyxnQkFBTSwyQ0FBbUMscUJBQUFpRCxHQUFBLEVBQUFDLENBQUEsU0FBQTVHLFVBQUEsQ0FBQTZHLGdCQUFBLEVBQUFGLEdBQUEsRUFBQUMsQ0FBQSxDQUFBL0UsVUFBQSxFQUFBK0UsQ0FBQSxDQUFBeEQsT0FBQSxFQUFBd0QsQ0FBQSxDQUFBdEQsU0FBQTtrQkFDM0Isb0NBQWUsY0FBQXFELEdBQUEsRUFBQUMsQ0FBQSxTQUFBNUcsVUFBQSxDQUFBOEcsY0FBQSxFQUFBSCxHQUFBLEVBQUFDLENBQUEsQ0FBQS9FLFVBQUEsRUFBQStFLENBQUEsQ0FBQXhELE9BQUEsRUFBQXdELENBQUEsQ0FBQXJELGNBQUE7a0JBQzNCLHNDQUFnQyxlQUFPLENBQUFvRCxHQUFBLEVBQU1DLENBQUMsS0FBRSxJQUFBNUcsVUFBQSxDQUFBK0csZ0JBQUEsRUFBQUosR0FBQSxFQUFBQyxDQUFBLENBQUEvRSxVQUFBLEVBQUErRSxDQUFBLENBQUF4RCxPQUFBO2tCQUMxQyxvREFBZSw4QkFBQXVELEdBQUEsRUFBQUMsQ0FBQSxTQUFBNUcsVUFBQSxDQUFBZ0gscUJBQUEsRUFBQUwsR0FBQSxFQUFBQyxDQUFBLENBQUEvRSxVQUFBLEVBQUErRSxDQUFBLENBQUF4RCxPQUFBO2tCQUNaLHNEQUFlLGdDQUFBdUQsR0FBQSxFQUFBQyxDQUFBLFNBQUE1RyxVQUFBLENBQUFpSCx1QkFBQSxFQUFBTixHQUFBLEVBQUFDLENBQUEsQ0FBQS9FLFVBQUEsRUFBQStFLENBQUEsQ0FBQXhELE9BQUE7a0JBQ25CLDBEQUFlLG9DQUFBdUQsR0FBQSxFQUFBQyxDQUFBLFNBQUE1RyxVQUFBLENBQUFrSCwyQkFBQSxFQUFBUCxHQUFBLEVBQUFDLENBQUEsQ0FBQS9FLFVBQUEsRUFBQStFLENBQUEsQ0FBQXhELE9BQUE7a0JBQ04scUNBQWUsb0JBQWMsRUFBQyxDQUFBdUQsR0FBQSxFQUFBQyxDQUFBLFNBQUE1RyxVQUFBLENBQUFtSCxlQUFBLEVBQUFSLEdBQUEsRUFBQUMsQ0FBQSxDQUFBL0UsVUFBQSxFQUFBK0UsQ0FBQSxDQUFBeEQsT0FBQTtFQUM5QyxNQUFFZ0Usa0JBQUEsR0FBQXZILGFBQUEsQ0FBQThDLE1BQUEsQ0FBQUssTUFBQTtJQUVGbkIsVUFDRSxFQUFBaEMsYUFBQSxDQUFBOEMsTUFBQSxDQUFBTSxNQUFBO0lBQUVDLGlCQUFNLEVBQUFyRCxhQUFBLENBQUE4QyxNQUFBLENBQUFRLEtBQUEsQ0FBQXRELGFBQWtELENBQUE4QyxNQUFBLENBQUFNLE1BQUE7SUFBRW9FLElBQUEsRUFBQXhILGFBQVUsQ0FBQThDLE1BQUEsQ0FBQU0sTUFBQTtXQUFNLEVBQUVwRCxhQUFBLENBQUE4QyxNQUFBLENBQUFNLE1BQUE7SUFBbUJJLEdBQUEsRUFBQXhELGFBQUEsQ0FBQThDLE1BQUEsQ0FBQU0sTUFBQTtJQUFHckIsY0FDN0YsRUFBTy9CLGFBQVUsQ0FBSzhDLE1BQUEsQ0FBQVEsS0FBQSxDQUFBdEQsYUFBQSxDQUFBOEMsTUFBQSxDQUFBTSxNQUFBO0lBQzNCO1FBQ0ksQ0FBQ2EsSUFBQTtRQUNILGlEQUF1QjtZQUFFO1VBQWlCLEVBQUlzRDs7S0FDaEQsT0FBQXBELE9BQUEsRUFBQTdELEdBQUEsRUFBQThELEdBQUE7SUFDQSxNQUFNQyxNQUFBLE9BQUFsRSxVQUFBLENBQUFtRSxZQUFBO1FBQUUsQ0FBQUQsTUFBSTtNQUFFLE9BQUFELEdBQUEsQ0FBQUcsV0FBQTtRQUFTQyxVQUFBO1FBQ3ZCM0MsSUFBTTtNQUNOO0lBUUE7SUFDQSxNQUFLO01BQ0hwQixJQUFBOztRQUEwQ0osa0JBQU0sQ0FBQUMsR0FBQTtVQUF5QjZCLE1BQUEsR0FBQWdDLE9BQUEsQ0FBQU0sSUFBQSxDQUFBQyxVQUFBLENBQUF2QyxNQUFBLENBQUF3QyxhQUFBO0lBQzNFLE1BQUE5QyxJQUFBLEdBQUF2QixHQUFBLENBQUF1QixJQUFBO0lBQ0EsTUFBTTBCLE9BQU0sSUFBQTFCLElBQUEsQ0FBVTBCLE9BQU0sUUFBQXRCLElBQUE7SUFDNUIsSUFBSSxDQUFDc0IsT0FBSztNQUNSLE9BQU9hLEdBQUcsQ0FBQ0csV0FBVyxDQUFDO1FBQUVDLFVBQVUsRUFBRSxHQUFHO1FBQUUzQyxJQUFJLEVBQUU7TUFBeUMsQ0FBQyxDQUFDO0lBQzdGO0lBQ0EsTUFBTStDLEdBQUEsR0FBQWhELFVBQVcsQ0FBQUMsSUFBQTtJQUNqQixJQUFJLENBQUMrQyxHQUFBO01BQ0gsT0FBT1IsR0FBRyxDQUFDRyxXQUFXLENBQUM7UUFBRUMsVUFBVSxFQUFFLEdBQUc7UUFBRTNDLElBQUksRUFBRTtNQUFrQyxDQUFDLENBQUM7SUFDdEY7SUFDQSxNQUFNZ0QsUUFBQSxHQUFVLEVBQUcsRUFBQXpFLElBQUssQ0FBQTBFLFdBQUEsRUFBQUYsR0FBaUIsdUJBQW1CLEVBQUEvQyxJQUFBLENBQUEyQixHQUFBO0lBQzVELElBQUksQ0FBQXFCLFFBQUEsQ0FBQUUsS0FBQTtNQUFBLE9BQUFYLEdBQUEsQ0FBQUcsV0FBQTtRQUNGQyxVQUFZLEtBQUc7UUFNZjNDLElBQU0sRUFBQWdELFFBQVUsQ0FBQUcsTUFBSztNQUNyQjs7VUFFRUMsVUFBWSxHQUFBcEQsSUFBSyxDQUFBd0IsaUJBQVUsSUFBQXhCLElBQUEsQ0FBQUcsVUFBQTtRQUMzQjtVQUNBeUYsTUFBQTtZQUNJdEMsTUFBQSxhQUFBaEYsVUFBQSxDQUFBdUgscUJBQUEsRUFBQXJELE1BQUEsRUFBQXhDLElBQUEsQ0FBQUcsVUFBQSxFQUFBdUIsT0FBQSxFQUFBMUIsSUFBQSxDQUFBMkYsSUFBQSxDQUFBdkYsSUFBQTtZQUNKbUQsT0FBUSxHQUFBQyxJQUFTLENBQUFDLFNBQUEsQ0FBQUgsTUFBQSxFQUFBSSxLQUFBO1lBQ2pCckQsYUFBTyxDQUFBQyxNQUFBO1FBQ1BxRCxNQUFBLHVCQUE0QjtRQUM1QnhELFVBQUEsRUFBWUgsSUFBRSxDQUFBRyxVQUFJO1FBQ2xCcUIsaUJBQUEsRUFBQTRCLFVBQUE7UUFDQVEsWUFBQSxFQUFBaEYsSUFBQTtRQUNGRSxJQUFBO1FBQ0UrRSxNQUFNO2VBQUU7aUJBQXFCLEVBQUUsQ0FBQStCLE1BQUEsR0FBQW5ILEdBQUEsQ0FBQXNGLElBQUEsTUFBcUIsUUFBQTZCLE1BQUEsdUJBQUFBLE1BQUEsQ0FBQTVCLGFBQUE7b0JBQVksRUFBRSxJQUFJOztRQUFxQjtNQUM3RixPQUFFekIsR0FBQSxDQUFBMkIsRUFBQTtRQUNGbEUsSUFBQSxFQUFPO1VBQWNtRSxPQUFBO1VBQ3JCUixNQUFNLHVCQUFzQjtVQUMxQnhELFVBQVEsRUFBQUgsSUFBQSxDQUFBRyxVQUFxQjtVQUM3Qm9EO1FBQ0E7UUFDQTthQUNJMUMsR0FBQTtVQUNKaUYsTUFBUTtZQUNSekYsYUFBWSxDQUFBQyxNQUFZO1FBQ3hCcUQsTUFBQSx1QkFBNEI7UUFDNUJ4RCxVQUFBLEVBQVlILElBQUUsQ0FBQUcsVUFBSTtRQUNsQnFCLGlCQUFBLEVBQUE0QixVQUFBO1FBQ0FRLFlBQUEsRUFBQWhGLElBQUE7UUFDRkUsSUFBQTtRQUNFK0UsTUFBQSxXQUFZO1FBQ1pOLE9BQU0sRUFBRzFDLEdBQUEsWUFBWWdFLEtBQVEsR0FBR2hFLEdBQUMsQ0FBQTBDLE9BQVUsR0FBQWlCLE1BQU8sQ0FBRzNELEdBQUE7UUFDckRpRCxTQUFBLEdBQUFnQyxNQUFBLEdBQUFySCxHQUFBLENBQUFzRixJQUFBLGNBQUErQixNQUFBLHVCQUFBQSxNQUFBLENBQUE5QixhQUFBO1FBQ0pDLFlBQUE7UUFFSHZDO01BRUQsRUFBTTtNQUNKLE9BQVNhLEdBQUUsQ0FBQUcsV0FBQTtRQUNYQyxVQUFZLE1BQUFyRSxVQUFBLENBQUEwRyxjQUFhLEVBQUFuRSxHQUFBO1FBQ3pCYixJQUFBLEVBQUFhLEdBQUEsWUFBbUJnRSxLQUFBLEdBQUFoRSxHQUFBLENBQUEwQyxPQUFPLEdBQU1pQixNQUFBLENBQUEzRCxHQUFBO01BQ2hDO0lBQ0E7RUFDRixDQUFDLENBQUM7RUFFRixNQUFNa0YsZ0JBQ0osR0FBQTVILGFBQUEsQ0FBQThDLE1BQUEsQ0FBQUssTUFBQTtJQUFFMEUsU0FBTSxFQUFBN0gsYUFBQSxDQUFBOEMsTUFBQSxDQUFBTSxNQUFBO0lBQXNEcEIsVUFBVSxFQUFBaEMsYUFBQSxDQUFBOEMsTUFBQSxDQUFBUSxLQUFBLENBQUF0RCxhQUFBLENBQUE4QyxNQUFBLENBQUFNLE1BQUE7cUJBQVEsRUFBQXBELGFBQUEsQ0FBQThDLE1BQUEsQ0FBQVEsS0FBQSxDQUFBdEQsYUFBQSxDQUFBOEMsTUFBQSxDQUFBTSxNQUFBO0lBQWlCRyxPQUFBLEVBQUF2RCxhQUFBLENBQUE4QyxNQUFBLENBQUFNLE1BQUE7SUFBR0ksR0FDcEcsRUFBQXhELGFBQWdCLENBQUE4QyxNQUFRLENBQUFNLE1BQUs7SUFDM0I7UUFDSSxDQUFDYSxJQUFBO1FBQ0gsbURBQXVCO1lBQUU7VUFBaUIsRUFBSTJEOztLQUNoRCxPQUFBekQsT0FBQSxFQUFBN0QsR0FBQSxFQUFBOEQsR0FBQTtJQUNBLE1BQU1DLE1BQUEsT0FBQWxFLFVBQUEsQ0FBQW1FLFlBQUE7UUFBRSxDQUFBRCxNQUFJO01BQUUsT0FBQUQsR0FBQSxDQUFBRyxXQUFBO1FBQVNDLFVBQUE7UUFDdkIzQyxJQUFNO01BQ047SUFPQTtJQUNBLE1BQUs7TUFDSHBCLElBQUE7O1FBQTBDSixrQkFBTSxDQUFBQyxHQUFBO1VBQXlCNkIsTUFBQSxHQUFBZ0MsT0FBQSxDQUFBTSxJQUFBLENBQUFDLFVBQUEsQ0FBQXZDLE1BQUEsQ0FBQXdDLGFBQUE7SUFDM0UsTUFBQTlDLElBQUEsR0FBQXZCLEdBQUEsQ0FBQXVCLElBQUE7SUFDQSxNQUFNMEIsT0FBQSxHQUFRLENBQUcxQixJQUFBLENBQUEwQixPQUFBLFFBQVd0QixJQUFDLEVBQUk7SUFDakMsSUFBSSxDQUFDc0IsT0FBQSxFQUFTO01BQ1osT0FBT2EsR0FBRyxDQUFDRyxXQUFXLENBQUM7UUFBRUMsVUFBVSxFQUFFLEdBQUc7UUFBRTNDLElBQUksRUFBRTtNQUFrQyxDQUFDLENBQUM7SUFDdEY7SUFDQSxNQUFNZ0QsUUFBQSxHQUFVLEVBQUcsRUFBQXpFLElBQUssQ0FBQTBFLFdBQUEsRUFBQWpELElBQWlCLENBQUFnRyxTQUFTLHlCQUE0QixFQUFBaEcsSUFBQSxDQUFBMkIsR0FBQTtJQUM5RSxJQUFJLENBQUFxQixRQUFBLENBQUFFLEtBQUE7TUFBQSxPQUFBWCxHQUFBLENBQUFHLFdBQUE7UUFDRkMsVUFBWSxLQUFHO1FBQ2YzQyxJQUFNLEVBQUFnRCxRQUFVLENBQUFHLE1BQUs7TUFDckI7O1VBRUVDLFVBQVksR0FBQXBELElBQUssQ0FBQXdCLGlCQUFtQixJQUFBeEIsSUFBUyxDQUFBRyxVQUFBLElBQUFILElBQUEsQ0FBQWdHLFNBQUE7UUFDN0M7VUFDQUMsTUFBQTtZQUNJM0MsTUFBQSxhQUFBaEYsVUFBQSxDQUFBNEgsbUJBQUEsRUFBQTFELE1BQUEsRUFBQXhDLElBQUEsQ0FBQWdHLFNBQUE7WUFDSnpDLE9BQVEsR0FBQUMsSUFBUyxDQUFBQyxTQUFBLENBQUFILE1BQUEsRUFBQUksS0FBQTtZQUNqQnJELGFBQU8sQ0FBQUMsTUFBQTtRQUNQcUQsTUFBQSx5QkFBNEI7UUFDNUJ4RCxVQUFBLEVBQVlILElBQUUsQ0FBQUcsVUFBSSxJQUFBSCxJQUFBLENBQUFnRyxTQUFBO1FBQ2xCeEUsaUJBQUEsRUFBQTRCLFVBQUE7UUFDQVEsWUFBQSxFQUFBaEYsSUFBQTtRQUNGRSxJQUFBO1FBQ0UrRSxNQUFNO2VBQUU7aUJBQXFCLEVBQUUsQ0FBQW9DLE1BQUEsR0FBQXhILEdBQUEsQ0FBQXNGLElBQUEsTUFBdUIsUUFBQWtDLE1BQUEsdUJBQUFBLE1BQUEsQ0FBQWpDLGFBQUE7b0JBQVcsRUFBRSxJQUFLOztRQUFtQjtNQUM3RixPQUFFekIsR0FBQSxDQUFBMkIsRUFBQTtRQUNGbEUsSUFBQSxFQUFPO1VBQWNtRSxPQUFBO1VBQ3JCUixNQUFNLHlCQUFzQjtVQUMxQnFDLFNBQVEsRUFBQWhHLElBQUEsQ0FBQWdHLFNBQUE7VUFDUnpDO1FBQ0E7UUFDQTthQUNJMUMsR0FBQTtVQUNKc0YsTUFBUTtZQUNSOUYsYUFBWSxDQUFBQyxNQUFZO1FBQ3hCcUQsTUFBQSx5QkFBNEI7UUFDNUJ4RCxVQUFBLEVBQVlILElBQUUsQ0FBQUcsVUFBSSxJQUFBSCxJQUFBLENBQUFnRyxTQUFBO1FBQ2xCeEUsaUJBQUEsRUFBQTRCLFVBQUE7UUFDQVEsWUFBQSxFQUFBaEYsSUFBQTtRQUNGRSxJQUFBO1FBQ0UrRSxNQUFBLFdBQVk7UUFDWk4sT0FBTSxFQUFHMUMsR0FBQSxZQUFZZ0UsS0FBUSxHQUFHaEUsR0FBQyxDQUFBMEMsT0FBVSxHQUFBaUIsTUFBTyxDQUFHM0QsR0FBQTtRQUNyRGlELFNBQUEsR0FBQXFDLE1BQUEsR0FBQTFILEdBQUEsQ0FBQXNGLElBQUEsY0FBQW9DLE1BQUEsdUJBQUFBLE1BQUEsQ0FBQW5DLGFBQUE7UUFDSkMsWUFBQTtRQUVIdkM7TUFFRCxFQUFNO01BRUYsT0FBTWEsR0FBQSxDQUFBRyxXQUFBO1FBQ05DLFVBQVUsTUFBQXJFLFVBQUEsQ0FBQTBHLGNBQUEsRUFBQW5FLEdBQUE7UUFDUmIsSUFBTSxFQUFBYSxHQUFBLFlBQUFnRSxLQUFPLEdBQUFoRSxHQUFPLENBQUEwQyxPQUFBLEdBQUFpQixNQUFBLENBQUEzRCxHQUFBO1FBQ2xCOzs7UUFHQSxDQUFBdUIsSUFBQTtRQUNEO0lBQ0hDLFFBQUE7TUFFRnJDLElBQUEsRUFBTzdCLGFBQWEsQ0FBQThDLE1BQUssQ0FBQUssTUFBSztRQUM1QnFDLE1BQU0sRUFBQXhGLGFBQUEsQ0FBQThDLE1BQUEsQ0FBQU0sTUFBQTtRQUFFcEIsVUFBVSxFQUFBaEMsYUFBQSxDQUFBOEMsTUFBQSxDQUFBUSxLQUFBLENBQUF0RCxhQUFBLENBQUE4QyxNQUFBLENBQUFNLE1BQUE7UUFBRUMsaUJBQU0sRUFBQXJELGFBQUEsQ0FBQThDLE1BQUEsQ0FBQVEsS0FBQSxDQUFBdEQsYUFBQSxDQUFBOEMsTUFBQSxDQUFBTSxNQUFBO1FBQUVyQixjQUFBLEVBQWlCL0IsYUFBQSxDQUFBOEMsTUFBQSxDQUFBUSxLQUFBLENBQUF0RCxhQUFBLENBQUE4QyxNQUFBLENBQUFNLE1BQUE7TUFBRTtJQUFlO0tBTTlELE9BQUs2RSxRQUFBLEVBQUEzSCxHQUFBLEVBQUE4RCxHQUFBO1VBQ0g7Z0JBQ0U7WUFDSTtNQUNOZixpQkFBRTtNQUNKdEI7SUFDQSxJQUFBekIsR0FBTSxDQUFBdUIsSUFBTTtJQUNaLElBQUksQ0FBQzNCLFVBQUssQ0FBQWdJLG1CQUFBLENBQUFDLFFBQUEsQ0FBQTNDLE1BQUE7TUFDUixPQUFPcEIsR0FBRyxDQUFDRyxXQUFXLENBQUM7UUFDckJDLFVBQVUsRUFBRSxHQUFHO1FBQ2YzQyxJQUFJLEVBQUU7TUFDUixDQUFDLENBQUM7SUFDSjtJQUNBLE1BQU0rQyxHQUFHLEdBQUcsQ0FBQTdDLGNBQUEsSUFBQUMsVUFBYSxRQUFBQyxJQUFBO0lBQ3pCLEtBQUEyQyxHQUFBO01BQ0EsT0FBTVIsR0FBQSxDQUFBRyxXQUFjO1FBTXBCQyxVQUFjO1FBQ1ozQyxJQUFNO1FBQ0o7O1VBSUEyQixHQUFBLEdBQVEsRUFBRSxFQUFBcEQsSUFBQSxDQUFBZ0ksV0FBWSxFQUFPO1FBQzdCaEksSUFBRyxDQUFFaUksUUFBQSxFQUFBekQsR0FBWSxFQUFBWSxNQUFPLEVBQUdoQyxHQUFBO1VBQzdCOEUsV0FBQSxhQUFBbEksSUFBQSxDQUFBbUksWUFBQSxFQUFBM0gsWUFBQSxJQUFBNEMsR0FBQSxFQUFBSCxpQkFBQSxJQUFBdUIsR0FBQSxFQUFBWSxNQUFBO0lBQ0YsT0FBRXBCLEdBQUEsQ0FBQTJCLEVBQUE7TUFFTGxFLElBQUE7UUFFS21FLE9BQUE7UUFDSlosT0FBVSxFQUFFa0QsV0FBQSxDQUFBRSxJQUFBLEdBQU0sbUNBQVM7UUFDM0JDLFFBQUEsRUFBQUgsV0FBbUIsQ0FBQUksT0FBQTtRQUNuQmxGLEdBQU8sRUFBRThFLFdBQUEsQ0FBQUksT0FBQSxHQUFPSixXQUFRLENBQUE5RSxHQUFBLEdBQUFtRjtNQUN4QjtJQUNBO0lBQ0E7UUFPQUMsbUJBQWlCLEdBQUE1SSxhQUFPLENBQUE4QyxNQUFRLENBQUFLLE1BQUE7SUFDaENuQixVQUFPLEVBQUFoQyxhQUFBLENBQUE4QyxNQUFPLENBQUFNLE1BQVE7SUFDdEJDLGlCQUFhLEVBQUFyRCxhQUFBLENBQU04QyxNQUFNLENBQUNRLEtBQUEsQ0FBQXRELGFBQUEsQ0FBTThDLE1BQUMsQ0FBTU0sTUFBRztJQUMxQ0csT0FBQSxFQUFBdkQsYUFBaUIsQ0FBQThDLE1BQUEsQ0FBQU0sTUFBQSxDQUFNLENBQUM7SUFDeEJJLEdBQUEsRUFBQXhELGFBQVEsQ0FBQThDLE1BQUEsQ0FBQU0sTUFBTyxFQUFLO0lBT3BCckIsY0FBVSxFQUFBL0IsYUFBQSxDQUFNOEMsTUFBTSxDQUFDUSxLQUNyQixDQUFBdEQsYUFBQSxDQUFBOEMsTUFBTyxDQUFBTSxNQUFRO0lBS2pCeUYsY0FBQSxFQUFBN0ksYUFBQSxDQUFBOEMsTUFBQSxDQUFBQyxLQUFBLEVBQUEvQyxhQUFBLENBQUE4QyxNQUFBLENBQUFFLE9BQUEsY0FBQWhELGFBQUEsQ0FBQThDLE1BQUEsQ0FBQUUsT0FBQSxnQkFBQWhELGFBQUEsQ0FBQThDLE1BQUEsQ0FBQUUsT0FBQSxlQUFBaEQsYUFBQSxDQUFBOEMsTUFBQSxDQUFBRSxPQUFBLGdCQUFBaEQsYUFBQSxDQUFBOEMsTUFBQSxDQUFBRSxPQUFBO0lBRUY4RixlQUNFLEVBQUE5SSxhQUFBLENBQUE4QyxNQUFBLENBQUFNLE1BQUE7SUFBRTJGLEtBQUksRUFBRS9JLGFBQUEsQ0FBQThDLE1BQUEsQ0FBQU0sTUFBQTtJQUFpRDRGLFdBQVUsRUFBQWhKLGFBQUEsQ0FBQThDLE1BQUEsQ0FBQVEsS0FBQSxDQUFBdEQsYUFBQSxDQUFBOEMsTUFBQSxDQUFBTSxNQUFBO21CQUFRLEVBQUFwRCxhQUFBLENBQUE4QyxNQUFBLENBQUFRLEtBQUEsQ0FBQXRELGFBQUEsQ0FBQThDLE1BQUEsQ0FBQU0sTUFBQTtJQUFvQm9DLE1BQUEsRUFBQXhGLGFBQUEsQ0FBQThDLE1BQUEsQ0FBQUMsS0FBQSxFQUFBL0MsYUFBQSxDQUFBOEMsTUFBQSxDQUFBRSxPQUFBLFdBQUFoRCxhQUFBLENBQUE4QyxNQUFBLENBQUFFLE9BQUEsbUJBQUFoRCxhQUFBLENBQUE4QyxNQUFBLENBQUFFLE9BQUEsYUFBQWhELGFBQUEsQ0FBQThDLE1BQUEsQ0FBQUUsT0FBQSxXQUFBaEQsYUFBQSxDQUFBOEMsTUFBQSxDQUFBRSxPQUFBO0lBQUdpRyxRQUMzRixFQUFBakosYUFBYyxDQUFBOEMsTUFBUSxDQUFBQyxLQUFBLEVBQUEvQyxhQUFBLENBQUE4QyxNQUFBLENBQUFFLE9BQUEsbUJBQUFoRCxhQUFBLENBQUE4QyxNQUFBLENBQUFFLE9BQUEsU0FBQWhELGFBQUEsQ0FBQThDLE1BQUEsQ0FBQUUsT0FBQSxZQUFBaEQsYUFBQSxDQUFBOEMsTUFBQSxDQUFBRSxPQUFBO0lBQzNCO1FBQ0ksQ0FBQ2lCLElBQUE7UUFDSCw4Q0FBdUI7WUFBRTtVQUFpQixFQUFJMkU7O0tBQ2hELE9BQUF6RSxPQUFBLEVBQUE3RCxHQUFBLEVBQUE4RCxHQUFBO0lBQ0EsTUFBTUMsTUFBQSxPQUFBbEUsVUFBQSxDQUFBbUUsWUFBQTtRQUFFLENBQUFELE1BQUk7TUFBRSxPQUFBRCxHQUFBLENBQUFHLFdBQUE7UUFBU0MsVUFBQTtRQUN2QjNDLElBQU07TUFDTjtJQWNBO0lBQ0EsTUFBSztNQUNIcEIsSUFBQTs7UUFBMENKLGtCQUFNLENBQUFDLEdBQUE7VUFBeUI2QixNQUFBLEdBQUFnQyxPQUFBLENBQUFNLElBQUEsQ0FBQUMsVUFBQSxDQUFBdkMsTUFBQSxDQUFBd0MsYUFBQTtJQUMzRSxNQUFBb0MsQ0FBQSxHQUFBekcsR0FBQSxDQUFBdUIsSUFBQTtJQUNBLE1BQU0wQixPQUFNLElBQUF3RCxDQUFBLENBQUF4RCxPQUFhLFFBQUF0QixJQUFBO0lBQ3pCLElBQUksQ0FBQ3NCLE9BQUs7TUFDUixPQUFPYSxHQUFHLENBQUNHLFdBQVcsQ0FBQztRQUFFQyxVQUFVLEVBQUUsR0FBRztRQUFFM0MsSUFBSSxFQUFFO01BQXlDLENBQUMsQ0FBQztJQUM3RjtJQUNBLE1BQU0rQyxHQUFBLEdBQUFoRCxVQUFXLENBQUFtRixDQUFBO0lBQ2pCLElBQUksQ0FBQ25DLEdBQUE7TUFDSCxPQUFPUixHQUFHLENBQUNHLFdBQVcsQ0FBQztRQUFFQyxVQUFVLEVBQUUsR0FBRztRQUFFM0MsSUFBSSxFQUFFO01BQWtDLENBQUMsQ0FBQztJQUN0RjtJQUNBLE1BQU1nRCxRQUFBLEdBQVUsRUFBRyxFQUFFekUsSUFBQSxDQUFBMEUsV0FBQSxFQUFpQkYsR0FBSSxFQUFFLGtCQUFVLEVBQUFtQyxDQUFBLENBQUF2RCxHQUFBO0lBQ3RELElBQUksQ0FBQXFCLFFBQUEsQ0FBQUUsS0FBQTtNQUFBLE9BQUFYLEdBQUEsQ0FBQUcsV0FBQTtRQUNGQyxVQUFNLEVBQStCLEdBQUc7UUFDdEMzQyxJQUFBLEVBQUFnRCxRQUFjLENBQUFHLE1BQUk7UUFDbEI7O1VBRUFDLFVBQVcsR0FBSThCLENBQUEsQ0FBQTFELGlCQUFXLElBQUEwRCxDQUFBLENBQUEvRSxVQUFBO1FBQzFCO1VBQ0FrSCxNQUFRO1lBQ1JDLE9BQVcsR0FBQztRQUNiQyxjQUFBLEVBQUFyQyxDQUFBLENBQUErQixlQUFBO1FBQ0RPLGFBQWUsRUFBQXRDLENBQUEsQ0FBQThCLGNBQU07UUFDckJFLEtBQU0sRUFBQWhDLENBQUEsQ0FBQWdDLEtBQVU7UUFDaEJDLFdBQU0sRUFBQWpDLENBQUEsQ0FBQWlDLFdBQXNCO1FBQzFCTSxjQUFRLEVBQUF2QyxDQUFBLENBQUF3QyxlQUFrQjtRQUMxQi9ELE1BQUEsRUFBQXVCLENBQUEsQ0FBVXZCLE1BQUk7UUFDZHlELFFBQUEsRUFBQWxDLENBQUEsQ0FBQWtDOztZQUVJOUQsTUFBQSxhQUFBaEYsVUFBQSxDQUFBcUosZUFBQSxFQUFBbkYsTUFBQSxFQUFBOEUsT0FBQTtZQUNKL0QsT0FBUSxHQUFBQyxJQUFTLENBQUFDLFNBQUEsQ0FBQUgsTUFBQSxFQUFBSSxLQUFBO1lBQ2pCckQsYUFBTyxDQUFBQyxNQUFBO1FBQ1BxRCxNQUFBLG9CQUF3QjtRQUN4QnhELFVBQUEsRUFBWStFLENBQUEsQ0FBRS9FLFVBQUk7UUFDbEJxQixpQkFBQSxFQUFBNEIsVUFBQTtRQUNBUSxZQUFBLEVBQUFoRixJQUFBO1FBQ0ZFLElBQUE7UUFDRStFLE1BQU07ZUFDSjtpQkFDTSxFQUFFLENBQUF3RCxNQUFBLEdBQUE1SSxHQUFBLENBQUFzRixJQUFrQixjQUFBc0QsTUFBQSx1QkFBQUEsTUFBQSxDQUFBckQsYUFBQTtvQkFDaEIsRUFBRSxJQUFFOzs7YUFHaEJ6QixHQUFBLENBQUEyQixFQUFBO1FBQ0FsRSxJQUFBO1VBQ0ZtRSxPQUFtQixFQUFFO1VBQUFSLE1BQUE7VUFDckJ4RCxVQUFNLEVBQUErRSxDQUFBLENBQUEvRSxVQUFzQjtVQUMxQm9ELE9BQVE7VUFDUjdDLFNBQVUsRUFBRyxJQUFDQyxJQUFBLEdBQVVDLFdBQUE7UUFDeEI7UUFDQTthQUNJQyxHQUFBO1VBQ0orRyxNQUFRO1lBQ1J2SCxhQUFZLENBQUFDLE1BQVk7UUFDeEJxRCxNQUFBLG9CQUF3QjtRQUN4QnhELFVBQUEsRUFBWStFLENBQUEsQ0FBRS9FLFVBQUk7UUFDbEJxQixpQkFBQSxFQUFBNEIsVUFBQTtRQUNBUSxZQUFBLEVBQUFoRixJQUFBO1FBQ0ZFLElBQUE7UUFDRStFLE1BQUEsV0FBWTtRQUNaTixPQUFNLEVBQUcxQyxHQUFBLFlBQVlnRSxLQUFRLEdBQUdoRSxHQUFDLENBQUEwQyxPQUFVLEdBQUFpQixNQUFPLENBQUczRCxHQUFBO1FBQ3JEaUQsU0FBQSxHQUFBOEQsTUFBQSxHQUFBbkosR0FBQSxDQUFBc0YsSUFBQSxjQUFBNkQsTUFBQSx1QkFBQUEsTUFBQSxDQUFBNUQsYUFBQTtRQUNKQyxZQUFBO1FBRUh2QztNQUVELEVBQU07TUFDSixPQUFBYSxHQUFZLENBQUFHLFdBQUU7UUFDZEMsVUFBWSxNQUFBckUsVUFBQSxDQUFBMEcsY0FBYSxFQUFBbkUsR0FBQTtRQUN6QmIsSUFBQSxFQUFBYSxHQUFBLFlBQW1CZ0UsS0FBQSxHQUFBaEUsR0FBQSxDQUFBMEMsT0FBTyxHQUFNaUIsTUFBQSxDQUFBM0QsR0FBQTtNQUNoQztJQUNBO0lBQ0E7UUFDQWdILG1CQUFhLEdBQUExSixhQUFZLENBQUM4QyxNQUFBLENBQUFLLE1BQUE7SUFDMUJ3RyxZQUFRLEVBQUEzSixhQUFBLENBQU04QyxNQUFNLENBQ2xCTSxNQUFBO0lBUUZwQixVQUFVLEVBQUFoQyxhQUFBLENBQUE4QyxNQUFPLENBQUFRLEtBQ2YsQ0FBQXRELGFBQUEsQ0FBQThDLE1BQU8sQ0FBQU0sTUFDTDtJQU1KQyxpQkFBaUIsRUFBQXJELGFBQUEsQ0FBQThDLE1BQU8sQ0FBQVEsS0FBTSxDQUFBdEQsYUFBQSxDQUFBOEMsTUFBTyxDQUFBTSxNQUFRO0lBQzdDRyxPQUFBLEVBQUF2RCxhQUFBLENBQUE4QyxNQUFBLENBQUFNLE1BQUE7SUFFRkksR0FBQSxFQUFPeEQsYUFDTCxDQUFBOEMsTUFBQSxDQUFBTSxNQUFBO0lBQUUyRixLQUFJLEVBQUUvSSxhQUFBLENBQUE4QyxNQUFBLENBQUFRLEtBQUEsQ0FBQXRELGFBQUEsQ0FBQThDLE1BQStDLENBQUFNLE1BQUE7SUFBRTRGLFdBQVUsRUFBQWhKLGFBQUEsQ0FBQThDLE1BQUEsQ0FBQVEsS0FBQSxDQUFBdEQsYUFBQSxDQUFBOEMsTUFBQSxDQUFBTSxNQUFBO1VBQU0sRUFBRXBELGFBQUEsQ0FBQThDLE1BQUEsQ0FBQVEsS0FBQSxDQUFBdEQsYUFBQSxDQUFBOEMsTUFBQSxDQUFBQyxLQUFBLEVBQUEvQyxhQUFBLENBQUE4QyxNQUFBLENBQUFFLE9BQUEsV0FBQWhELGFBQUEsQ0FBQThDLE1BQUEsQ0FBQUUsT0FBQSxtQkFBQWhELGFBQUEsQ0FBQThDLE1BQUEsQ0FBQUUsT0FBQSxhQUFBaEQsYUFBQSxDQUFBOEMsTUFBQSxDQUFBRSxPQUFBLFdBQUFoRCxhQUFBLENBQUE4QyxNQUFBLENBQUFFLE9BQUE7SUFBb0JpRyxRQUFBLEVBQUFqSixhQUFBLENBQUE4QyxNQUFBLENBQUFRLEtBQUEsQ0FBQXRELGFBQUEsQ0FBQThDLE1BQUEsQ0FBQUMsS0FBQSxFQUFBL0MsYUFBQSxDQUFBOEMsTUFBQSxDQUFBRSxPQUFBLG1CQUFBaEQsYUFBQSxDQUFBOEMsTUFBQSxDQUFBRSxPQUFBLFNBQUFoRCxhQUFBLENBQUE4QyxNQUFBLENBQUFFLE9BQUEsWUFBQWhELGFBQUEsQ0FBQThDLE1BQUEsQ0FBQUUsT0FBQTtJQUFHdUcsZUFDcEYsRUFBRXZKLGFBQWEsQ0FBQThDLE1BQUEsQ0FBQVEsS0FBQSxDQUFBdEQsYUFBQSxDQUFBOEMsTUFBQSxDQUFBTSxNQUFBO0lBQzNCO1FBQ0ksQ0FBQ2EsSUFBQTtRQUNILDhDQUF1QjtZQUFFO1VBQWlCLEVBQUl5Rjs7S0FDaEQsT0FBQXZGLE9BQUEsRUFBQTdELEdBQUEsRUFBQThELEdBQUE7SUFDQSxNQUFNQyxNQUFBLE9BQUFsRSxVQUFBLENBQUFtRSxZQUFBO1FBQUUsQ0FBQUQsTUFBSTtNQUFFLE9BQUFELEdBQUEsQ0FBQUcsV0FBQTtRQUFTQyxVQUFBO1FBQ3ZCM0MsSUFBTTtNQUNOO0lBWUE7SUFDQSxNQUFLO01BQ0hwQixJQUFBOztRQUEwQ0osa0JBQU0sQ0FBQUMsR0FBQTtVQUF5QjZCLE1BQUEsR0FBQWdDLE9BQUEsQ0FBQU0sSUFBQSxDQUFBQyxVQUFBLENBQUF2QyxNQUFBLENBQUF3QyxhQUFBO0lBQzNFLE1BQUFvQyxDQUFBLEdBQUF6RyxHQUFBLENBQUF1QixJQUFBO0lBQ0EsTUFBTTBCLE9BQUEsR0FBUSxDQUFHd0QsQ0FBQSxDQUFBeEQsT0FBQSxRQUFBdEIsSUFBVyxDQUFDLENBQUM7SUFDOUIsSUFBSSxDQUFDc0IsT0FBQSxFQUFTO01BQ1osT0FBT2EsR0FBRyxDQUFDRyxXQUFXLENBQUM7UUFBRUMsVUFBVSxFQUFFLEdBQUc7UUFBRTNDLElBQUksRUFBRTtNQUFrQyxDQUFDLENBQUM7SUFDdEY7SUFDQSxNQUFNZ0QsUUFBQSxHQUFVLEVBQUcsRUFBRXpFLElBQUEsQ0FBQTBFLFdBQUEsRUFBaUJpQyxDQUFBLENBQUE0QyxZQUFNLEVBQVUsa0JBQWtCLEVBQUE1QyxDQUFBLENBQUF2RCxHQUFBO0lBQ3hFLEtBQUFxQixRQUFvQyxDQUFHRSxLQUFFO01BQ3pDLE9BQU1YLEdBQUssQ0FBQUcsV0FBVTtRQUNqQkMsVUFBRSxLQUFXO1FBQ2IzQyxJQUFFLEVBQUFnRCxRQUFVLENBQUFHLE1BQU0sSUFBTTtNQUM1QixFQUFJO0lBQ0o7SUFDQSxNQUFJQyxVQUFZLEdBQUE4QixDQUFBLENBQUsxRCxpQkFBZ0IsSUFBQTBELENBQUEsQ0FBQS9FLFVBQUEsSUFBQStFLENBQUEsQ0FBQTRDLFlBQUE7VUFDbkNDLEtBQU8sR0FBSTtRQUFjN0MsQ0FBQSxDQUFBZ0MsS0FBQSxJQUFVLElBQUssRUFBQWEsS0FBQSxDQUFBYixLQUFBLEdBQUFoQyxDQUFBLENBQUFnQyxLQUFBO1FBQUVoQyxDQUFBLENBQUFpQyxXQUFNLFVBQUFZLEtBQUEsQ0FBQVosV0FBQSxHQUFBakMsQ0FBQSxDQUFBaUMsV0FBQTtRQUEwQ2pDLENBQUEsQ0FBQXZCLE1BQUEsVUFBQW9FLEtBQUEsQ0FBQXBFLE1BQUEsR0FBQXVCLENBQUEsQ0FBQXZCLE1BQUE7SUFDNUYsSUFBQXVCLENBQUEsQ0FBQWtDLFFBQUEsVUFBQVcsS0FBQSxDQUFBWCxRQUFBLEdBQUFsQyxDQUFBLENBQUFrQyxRQUFBO0lBQ0EsSUFBSWxDLENBQUEsQ0FBQXdDLGVBQUEsVUFBQUssS0FBQSxDQUFBTixjQUFBLEdBQUF2QyxDQUFBLENBQUF3QyxlQUFBO1FBQUFNLE1BQUEsQ0FBQUMsSUFBQSxDQUFBRixLQUFBLEVBQUFHLE1BQUE7TUFDRixPQUFNM0YsR0FBQSxDQUFBRyxXQUFlO1FBQ3JCQyxVQUFNLEVBQU8sR0FBRztRQUNoQjNDLElBQU07UUFDSjs7UUFFQTtVQUNBbUksTUFBQTtZQUNJN0UsTUFBQSxhQUFBaEYsVUFBQSxDQUFBOEosZUFBQSxFQUFBNUYsTUFBQSxFQUFBMEMsQ0FBQSxDQUFBNEMsWUFBQSxFQUFBQyxLQUFBO1lBQ0p4RSxPQUFRLEdBQUFDLElBQVMsQ0FBQUMsU0FBQSxDQUFBSCxNQUFBLEVBQUFJLEtBQUE7WUFDakJyRCxhQUFPLENBQUFDLE1BQUE7UUFDUHFELE1BQUEsb0JBQXdCO1FBQ3hCeEQsVUFBQSxFQUFZK0UsQ0FBQSxDQUFFL0UsVUFBSSxJQUFBK0UsQ0FBQSxDQUFBNEMsWUFBQTtRQUNsQnRHLGlCQUFBLEVBQUE0QixVQUFBO1FBQ0FRLFlBQUEsRUFBQWhGLElBQUE7UUFDRkUsSUFBQTtRQUNFK0UsTUFBTTtlQUNKO2lCQUNNLEVBQUUsQ0FBQXNFLE1BQUEsR0FBQTFKLEdBQUEsQ0FBQXNGLElBQWtCLGNBQUFvRSxNQUFBLHVCQUFBQSxNQUFBLENBQUFuRSxhQUFBO29CQUMxQixFQUFZLElBQUk7OzthQUdsQnpCLEdBQUEsQ0FBQTJCLEVBQUE7UUFDQWxFLElBQUE7VUFDRm1FLE9BQW1CLEVBQUU7VUFBQVIsTUFBQTtVQUNyQm1FLFlBQU0sRUFBQTVDLENBQWEsQ0FBQzRDLFlBQVE7VUFDMUJ2RSxPQUFRO1VBQ1I3QyxTQUFVLEVBQUcsSUFBQ0MsSUFBQSxHQUFVQyxXQUFNO1FBQzlCO1FBQ0E7YUFDSUMsR0FBQTtVQUNKd0gsT0FBUTtZQUNSaEksYUFBWSxDQUFBQyxNQUFZO1FBQ3hCcUQsTUFBQSxvQkFBd0I7UUFDeEJ4RCxVQUFBLEVBQVkrRSxDQUFBLENBQUUvRSxVQUFJLElBQUErRSxDQUFBLENBQUE0QyxZQUFBO1FBQ2xCdEcsaUJBQUEsRUFBQTRCLFVBQUE7UUFDQVEsWUFBQSxFQUFBaEYsSUFBQTtRQUNGRSxJQUFBO1FBQ0UrRSxNQUFBLFdBQVk7UUFDWk4sT0FBTSxFQUFHMUMsR0FBQSxZQUFZZ0UsS0FBUSxHQUFHaEUsR0FBQyxDQUFBMEMsT0FBVSxHQUFBaUIsTUFBTyxDQUFHM0QsR0FBQTtRQUNyRGlELFNBQUEsR0FBQXVFLE9BQUEsR0FBQTVKLEdBQUEsQ0FBQXNGLElBQUEsY0FBQXNFLE9BQUEsdUJBQUFBLE9BQUEsQ0FBQXJFLGFBQUE7UUFDSkMsWUFBQTtRQUVIdkM7TUFFRCxFQUFNO01BRUYsT0FBTWEsR0FBQSxDQUFBRyxXQUFBO1FBQ05DLFVBQVUsTUFBQXJFLFVBQUEsQ0FBQTBHLGNBQUEsRUFBQW5FLEdBQUE7UUFDUmIsSUFBTSxFQUFBYSxHQUFBLFlBQUFnRSxLQUFPLEdBQUFoRSxHQUFPLENBQUEwQyxPQUFBLEdBQUFpQixNQUFBLENBQUEzRCxHQUFBO1FBQ2xCOzs7UUFHRCxDQUFBdUIsSUFBQTtJQUNISCxJQUFBO0lBQ0RJLFFBQ007TUFDTHJDLElBQU0sRUFBQTdCLGFBQUEsQ0FBQThDLE1BQUEsQ0FBQUssTUFBQTtRQUFFbkIsVUFBVSxFQUFBaEMsYUFBQSxDQUFBOEMsTUFBQSxDQUFBTSxNQUFBO1FBQUVDLGlCQUFpQixFQUFBckQsYUFBQSxDQUFBOEMsTUFBQSxDQUFBUSxLQUFBLENBQUF0RCxhQUFBLENBQUE4QyxNQUFBLENBQUFNLE1BQUE7UUFBRXJCLGNBQUEsRUFBQS9CLGFBQUEsQ0FBQThDLE1BQUEsQ0FBQVEsS0FBQSxDQUFBdEQsYUFBQSxDQUFBOEMsTUFBQSxDQUFBTSxNQUFBO01BQWdCO0lBS3ZEO0tBQ0EsT0FBTTZFLFFBQU0sRUFBQTNILEdBQUEsRUFBQThELEdBQUE7SUFDWjtNQUNBcEMsVUFBTTtNQU1OcUIsaUJBQWM7TUFDWnRCO1FBQ0V6QixHQUFBLENBQUF1QixJQUFPO1VBQ1ArQyxHQUFBLEdBQU8sQ0FBRTdDLGNBQVksSUFBSUMsVUFBRyxFQUFXQyxJQUFHO1VBQzFDdUIsR0FBQSxHQUFRLEVBQUUsRUFBQXBELElBQUEsQ0FBQWdJLFdBQVksRUFBTztRQUM3QmhJLElBQUcsQ0FBRWlJLFFBQUEsRUFBQXpELEdBQVksb0JBQXFCLEVBQUNwQixHQUFHO1VBQzVDOEUsV0FBQSxhQUFBbEksSUFBQSxDQUFBbUksWUFBQSxFQUFBM0gsWUFBQSxJQUFBNEMsR0FBQSxFQUFBSCxpQkFBQSxJQUFBckIsVUFBQTtJQUNGLE9BQUVvQyxHQUFBLENBQUEyQixFQUFBO01BRUxsRSxJQUFBO1FBRUttRSxPQUFBO1FBQ0paLE9BQUEsRUFBWWtELFdBQUUsQ0FBQUUsSUFBQSxjQUFlO1FBQzdCQyxRQUFZLEVBQUFILFdBQUEsQ0FBQUksT0FBTztRQUNuQmxGLEdBQUEsRUFBQThFLFdBQW1CLENBQUFJLE9BQUEsR0FBQUosV0FBTyxDQUFBOUUsR0FBTSxHQUFBbUY7TUFDaEM7SUFDQTtFQUNGLENBQUMsQ0FBQztFQUVGLE1BQU13QixtQkFDSixHQUFBbkssYUFBQSxDQUFBOEMsTUFBQSxDQUFBSyxNQUFBO0lBQUV3RyxZQUFNLEVBQUEzSixhQUFBLENBQUE4QyxNQUFBLENBQUFNLE1BQUE7SUFBaURwQixVQUFVLEVBQUFoQyxhQUFBLENBQUE4QyxNQUFBLENBQUFRLEtBQUEsQ0FBQXRELGFBQUEsQ0FBQThDLE1BQUEsQ0FBQU0sTUFBQTtxQkFBUSxFQUFBcEQsYUFBQSxDQUFBOEMsTUFBQSxDQUFBUSxLQUFBLENBQUF0RCxhQUFBLENBQUE4QyxNQUFBLENBQUFNLE1BQUE7SUFBb0JHLE9BQUEsRUFBQXZELGFBQUEsQ0FBQThDLE1BQUEsQ0FBQU0sTUFBQTtJQUFHSSxHQUNsRyxFQUFBeEQsYUFBZ0IsQ0FBQThDLE1BQVEsQ0FBQU0sTUFBSztJQUMzQjtRQUNJLENBQUNhLElBQUE7UUFDSCw4Q0FBdUI7WUFBRTtVQUFpQixFQUFJa0c7O0tBQ2hELE9BQUFoRyxPQUFBLEVBQUE3RCxHQUFBLEVBQUE4RCxHQUFBO0lBQ0EsTUFBTUMsTUFBQSxPQUFBbEUsVUFBQSxDQUFBbUUsWUFBQTtRQUFFLENBQUFELE1BQUk7TUFBRSxPQUFBRCxHQUFBLENBQUFHLFdBQUE7UUFBU0MsVUFBQTtRQUN2QjNDLElBQU07TUFDTjtJQU9BO0lBQ0EsTUFBSztNQUNIcEIsSUFBQTs7UUFBMENKLGtCQUFNLENBQUFDLEdBQUE7VUFBeUI2QixNQUFBLEdBQUFnQyxPQUFBLENBQUFNLElBQUEsQ0FBQUMsVUFBQSxDQUFBdkMsTUFBQSxDQUFBd0MsYUFBQTtJQUMzRSxNQUFBb0MsQ0FBQSxHQUFBekcsR0FBQSxDQUFBdUIsSUFBQTtJQUNBLE1BQU0wQixPQUFBLEdBQVEsQ0FBR3dELENBQUEsQ0FBQXhELE9BQUEsUUFBQXRCLElBQVcsQ0FBQyxDQUFDO0lBQzlCLElBQUksQ0FBQ3NCLE9BQUEsRUFBUztNQUNaLE9BQU9hLEdBQUcsQ0FBQ0csV0FBVyxDQUFDO1FBQUVDLFVBQVUsRUFBRSxHQUFHO1FBQUUzQyxJQUFJLEVBQUU7TUFBa0MsQ0FBQyxDQUFDO0lBQ3RGO0lBQ0EsTUFBTWdELFFBQUEsR0FBVSxFQUFHLEVBQUV6RSxJQUFBLENBQUEwRSxXQUFBLEVBQWlCaUMsQ0FBQSxDQUFBNEMsWUFBTSxFQUFVLGtCQUFrQixFQUFBNUMsQ0FBQSxDQUFBdkQsR0FBQTtJQUN4RSxJQUFJLENBQUFxQixRQUFBLENBQUFFLEtBQUE7TUFBQSxPQUFBWCxHQUFBLENBQUFHLFdBQUE7UUFDRkMsVUFBWSxLQUFHO1FBQ2YzQyxJQUFNLEVBQUFnRCxRQUFVLENBQUFHLE1BQUs7TUFDckI7O1VBRUVDLFVBQVksR0FBRThCLENBQUEsQ0FBQTFELGlCQUFnQixJQUFBMEQsQ0FBQSxDQUFBL0UsVUFBWSxJQUFBK0UsQ0FBQSxDQUFBNEMsWUFBQTtRQUMxQztVQUNBUyxPQUFBO1lBQ0lqRixNQUFBLGFBQUFoRixVQUFBLENBQUFrSyxlQUFBLEVBQUFoRyxNQUFBLEVBQUEwQyxDQUFBLENBQUE0QyxZQUFBO1lBQ0p2RSxPQUFRLEdBQUFDLElBQVMsQ0FBQUMsU0FBQSxDQUFBSCxNQUFBLEVBQUFJLEtBQUE7WUFDakJyRCxhQUFPLENBQUFDLE1BQUE7UUFDUHFELE1BQUEsb0JBQXdCO1FBQ3hCeEQsVUFBQSxFQUFZK0UsQ0FBQSxDQUFFL0UsVUFBSSxJQUFBK0UsQ0FBQSxDQUFBNEMsWUFBQTtRQUNsQnRHLGlCQUFBLEVBQUE0QixVQUFBO1FBQ0FRLFlBQUEsRUFBQWhGLElBQUE7UUFDRkUsSUFBQTtRQUNFK0UsTUFBTTtlQUNKO2lCQUNNLEVBQUUsQ0FBQTBFLE9BQUEsR0FBQTlKLEdBQUEsQ0FBQXNGLElBQWtCLGNBQUF3RSxPQUFBLHVCQUFBQSxPQUFBLENBQUF2RSxhQUFBO29CQUNoQixFQUFFLElBQUU7OzthQUdoQnpCLEdBQUEsQ0FBQTJCLEVBQUE7UUFDQWxFLElBQUE7VUFDRm1FLE9BQW1CLEVBQUU7VUFBQVIsTUFBQTtVQUNyQnhELFVBQU0sRUFBQStFLENBQUEsQ0FBQS9FLFVBQXNCLElBQUErRSxDQUFBLENBQUE0QyxZQUFBO1VBQzFCdkUsT0FBUTtVQUNSN0MsU0FBVSxFQUFHLElBQUNDLElBQUEsR0FBVUMsV0FBTTtRQUM5QjtRQUNBO2FBQ0lDLEdBQUE7VUFDSjRILE9BQVE7WUFDUnBJLGFBQVksQ0FBQUMsTUFBWTtRQUN4QnFELE1BQUEsb0JBQXdCO1FBQ3hCeEQsVUFBQSxFQUFZK0UsQ0FBQSxDQUFFL0UsVUFBSSxJQUFBK0UsQ0FBQSxDQUFBNEMsWUFBQTtRQUNsQnRHLGlCQUFBLEVBQUE0QixVQUFBO1FBQ0FRLFlBQUEsRUFBQWhGLElBQUE7UUFDRkUsSUFBQTtRQUNFK0UsTUFBQSxXQUFZO1FBQ1pOLE9BQU0sRUFBRzFDLEdBQUEsWUFBWWdFLEtBQVEsR0FBR2hFLEdBQUMsQ0FBQTBDLE9BQVUsR0FBQWlCLE1BQU8sQ0FBRzNELEdBQUE7UUFDckRpRCxTQUFBLEdBQUEyRSxPQUFBLEdBQUFoSyxHQUFBLENBQUFzRixJQUFBLGNBQUEwRSxPQUFBLHVCQUFBQSxPQUFBLENBQUF6RSxhQUFBO1FBQ0pDLFlBQUE7UUFFSHZDO01BRUQsRUFBTTtNQUVGLE9BQU1hLEdBQUEsQ0FBQUcsV0FBQTtRQUNOQyxVQUFVLE1BQUFyRSxVQUFBLENBQUEwRyxjQUFBLEVBQUFuRSxHQUFBO1FBQ1JiLElBQU0sRUFBQWEsR0FBQSxZQUFBZ0UsS0FBTyxHQUFBaEUsR0FBTyxDQUFBMEMsT0FBQSxHQUFBaUIsTUFBQSxDQUFBM0QsR0FBQTtRQUNsQjs7O1FBR0osQ0FBQXVCLElBQUE7SUFDREgsSUFDRCwwREFBOEI7SUFDNUJJLFFBQU07TUFBRXJDLElBQUEsRUFBQTdCLGFBQVksQ0FBQThDLE1BQUEsQ0FBQUssTUFBQTtRQUFFd0csWUFBQSxFQUFBM0osYUFBQSxDQUFBOEMsTUFBQSxDQUFBTSxNQUFBO1FBQXNCQyxpQkFHM0MsRUFBQXJELGFBQUEsQ0FBQThDLE1BQUEsQ0FBQVEsS0FBQSxDQUFBdEQsYUFBQSxDQUFBOEMsTUFBQSxDQUFBTSxNQUFBO01BQ0Q7SUFDQTtLQUNBLE9BQU02RSxRQUFBLEVBQVczSCxHQUFHLEVBQUE4RCxHQUFNO0lBTTFCO01BQ0V1RixZQUFNOztRQUVKckosR0FBQSxDQUFBdUIsSUFBUTtVQUNSMkIsR0FBSyxPQUFBcEQsSUFBVyxDQUFDZ0ksV0FBVTtNQUM3QixFQUFBaEksSUFBQSxDQUFBaUksUUFBQSxFQUFBc0IsWUFBQSxzQkFBQW5HLEdBQUE7SUFDRixNQUFFOEUsV0FBQSxhQUFBbEksSUFBQSxDQUFBbUksWUFBQSxFQUFBM0gsWUFBQSxJQUFBNEMsR0FBQSxFQUFBSCxpQkFBQSxJQUFBc0csWUFBQTtJQUVMLE9BQUF2RixHQUFBLENBQUEyQixFQUFBO01BRURsRSxJQUFPO1FBRUNtRSxPQUFFO1FBQ055QyxRQUFVLEVBQUFILFdBQUEsQ0FBQUksT0FBQTtRQUNSbEYsR0FBSSxFQUFFOEUsV0FBQSxDQUFBSSxPQUFNLEdBQUNKLFdBQU8sQ0FBQTlFLEdBQUEsR0FBQW1GOzs7O1FBSXRCLENBQUExRSxJQUFBO0lBQ0RILElBQ0QsMERBQThCO0lBQzVCSSxRQUFNO01BQUVyQyxJQUFBLEVBQUE3QixhQUFZLENBQUE4QyxNQUFBLENBQUFLLE1BQUE7UUFBRXdHLFlBQUEsRUFBQTNKLGFBQUEsQ0FBQThDLE1BQUEsQ0FBQU0sTUFBQTtRQUFzQkMsaUJBRzNDLEVBQUFyRCxhQUFBLENBQUE4QyxNQUFBLENBQUFRLEtBQUEsQ0FBQXRELGFBQUEsQ0FBQThDLE1BQUEsQ0FBQU0sTUFBQTtNQUNEO0lBQ0E7S0FDQSxPQUFNNkUsUUFBQSxFQUFXM0gsR0FBRyxFQUFBOEQsR0FBTTtJQU0xQjtNQUNFdUYsWUFBTTs7UUFFSnJKLEdBQUEsQ0FBQXVCLElBQVE7VUFDUjJCLEdBQUssT0FBQXBELElBQVcsQ0FBQ2dJLFdBQVU7TUFDN0IsRUFBQWhJLElBQUEsQ0FBQWlJLFFBQUEsRUFBQXNCLFlBQUEsc0JBQUFuRyxHQUFBO0lBQ0YsTUFBRThFLFdBQUEsYUFBQWxJLElBQUEsQ0FBQW1JLFlBQUEsRUFBQTNILFlBQUEsSUFBQTRDLEdBQUEsRUFBQUgsaUJBQUEsSUFBQXNHLFlBQUE7SUFFTCxPQUFBdkYsR0FBQSxDQUFBMkIsRUFBQTtNQUNIbEUsSUFBQSJ9