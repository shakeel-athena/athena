"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.registerDefenderSearchRoutes = registerDefenderSearchRoutes;
var _configSchema = require("@osd/config-schema");
var _constants = require("../../common/constants");
var _mdeClient = require("../lib/mde-client");
var _graphSecurityClient = require("../lib/graph-security-client");
/*
 * Defender plugin — OpenSearch reads + Graph/MDE proxies
 */

function mapGraphErr(err) {
  if (err instanceof _graphSecurityClient.GraphApiError) {
    return {
      status: err.status >= 400 && err.status < 600 ? err.status : 502,
      body: err.message
    };
  }
  return {
    status: 502,
    body: err instanceof Error ? err.message : String(err)
  };
}
function normalizeMdeMachine(m, tenantId) {
  return {
    tenant_id: tenantId,
    machine_id: m.id,
    computer_dns_name: m.computerDnsName || '',
    os_platform: m.osPlatform || '',
    os_version: m.osVersion || '',
    last_seen: m.lastSeen || null,
    first_seen: m.firstSeen || null,
    aad_device_id: m.aadDeviceId || '',
    risk_score: m.riskScore != null ? String(m.riskScore) : '',
    exposure_level: m.exposureLevel || '',
    onboarding_status: m.onboardingStatus || m.onboardingstatus || '',
    health_status: m.healthStatus || '',
    isolation_status: m.isolationStatus || '',
    last_ip_address: m.lastIpAddress || '',
    rbac_group_name: m.rbacGroupName || ''
  };
}
function getClient(context) {
  return context.core.opensearch.client.asCurrentUser;
}
function registerDefenderSearchRoutes(router) {
  router.get({
    path: '/api/defender_xdr/health',
    validate: false
  }, async (_context, _req, res) => {
    const mde = !!(0, _mdeClient.getMdeConfig)();
    const graph = !!(0, _graphSecurityClient.getGraphSecurityConfig)();
    return res.ok({
      body: {
        ok: mde || graph,
        mde_configured: mde,
        graph_security_configured: graph,
        timestamp: new Date().toISOString()
      }
    });
  });
  router.get({
    path: '/api/defender_xdr/machines',
    validate: {
      query: _configSchema.schema.object({
        size: _configSchema.schema.maybe(_configSchema.schema.number()),
        from: _configSchema.schema.maybe(_configSchema.schema.number()),
        os_platform: _configSchema.schema.maybe(_configSchema.schema.string()),
        exposure_level: _configSchema.schema.maybe(_configSchema.schema.string()),
        source: _configSchema.schema.maybe(_configSchema.schema.string())
      })
    }
  }, async (context, req, res) => {
    const q = req.query;
    if (q.source === 'live') {
      const mcfg = (0, _mdeClient.getMdeConfig)();
      if (!mcfg) {
        return res.customError({
          statusCode: 503,
          body: 'MDE not configured.'
        });
      }
      try {
        var _q$from, _q$size;
        const raw = await (0, _mdeClient.fetchAllMachinesLimited)(mcfg, 15);
        const tenantId = mcfg.tenantId;
        let rows = raw.map(m => normalizeMdeMachine(m, tenantId));
        if (q.os_platform) {
          rows = rows.filter(r => String(r.os_platform) === q.os_platform);
        }
        if (q.exposure_level) {
          rows = rows.filter(r => String(r.exposure_level) === q.exposure_level);
        }
        rows.sort((a, b) => {
          const ta = a.last_seen ? new Date(String(a.last_seen)).getTime() : 0;
          const tb = b.last_seen ? new Date(String(b.last_seen)).getTime() : 0;
          return tb - ta;
        });
        const from = (_q$from = q.from) !== null && _q$from !== void 0 ? _q$from : 0;
        const size = (_q$size = q.size) !== null && _q$size !== void 0 ? _q$size : 50;
        const slice = rows.slice(from, from + size);
        const hits = slice.map(src => ({
          _source: src,
          _id: src.machine_id
        }));
        return res.ok({
          body: {
            hits,
            total: {
              value: rows.length,
              relation: 'eq'
            },
            source: 'mde'
          }
        });
      } catch (err) {
        var _err$message;
        return res.customError({
          statusCode: (0, _mdeClient.mdeErrorStatus)(err),
          body: (_err$message = err === null || err === void 0 ? void 0 : err.message) !== null && _err$message !== void 0 ? _err$message : String(err)
        });
      }
    }
    try {
      var _hits, _response$body, _hits$hits;
      const client = getClient(context);
      const {
        size = 50,
        from = 0,
        os_platform,
        exposure_level
      } = q;
      const must = [];
      if (os_platform) must.push({
        term: {
          os_platform
        }
      });
      if (exposure_level) must.push({
        term: {
          exposure_level
        }
      });
      const response = await client.search({
        index: _constants.DEFENDER_MACHINES_INDEX,
        ignore_unavailable: true,
        body: {
          size,
          from,
          sort: [{
            last_seen: {
              order: 'desc',
              missing: '_last'
            }
          }, {
            computer_dns_name: 'asc'
          }],
          query: must.length ? {
            bool: {
              must
            }
          } : {
            match_all: {}
          }
        }
      });
      const hits = (_hits = (_response$body = response.body) === null || _response$body === void 0 ? void 0 : _response$body.hits) !== null && _hits !== void 0 ? _hits : {};
      return res.ok({
        body: {
          hits: (_hits$hits = hits.hits) !== null && _hits$hits !== void 0 ? _hits$hits : [],
          total: hits.total,
          source: 'index'
        }
      });
    } catch (err) {
      var _err$statusCode, _err$message2;
      return res.customError({
        statusCode: (_err$statusCode = err.statusCode) !== null && _err$statusCode !== void 0 ? _err$statusCode : 500,
        body: (_err$message2 = err.message) !== null && _err$message2 !== void 0 ? _err$message2 : String(err)
      });
    }
  });
  router.get({
    path: '/api/defender_xdr/machines/{id}/live',
    validate: {
      params: _configSchema.schema.object({
        id: _configSchema.schema.string()
      })
    }
  }, async (_context, _req, res) => {
    const config = (0, _mdeClient.getMdeConfig)();
    if (!config) {
      return res.customError({
        statusCode: 503,
        body: 'Defender MDE not configured (DEFENDER_TENANT_ID, DEFENDER_CLIENT_ID, DEFENDER_CLIENT_SECRET).'
      });
    }
    try {
      const id = _req.params.id;
      const data = await (0, _mdeClient.getMachine)(config, id);
      return res.ok({
        body: data
      });
    } catch (err) {
      var _err$message3;
      return res.customError({
        statusCode: (0, _mdeClient.mdeErrorStatus)(err),
        body: (_err$message3 = err === null || err === void 0 ? void 0 : err.message) !== null && _err$message3 !== void 0 ? _err$message3 : String(err)
      });
    }
  });
  const mdeMachineSub = (pathSuffix, fn) => {
    router.get({
      path: `/api/defender_xdr/machines/{id}/live/${pathSuffix}`,
      validate: {
        params: _configSchema.schema.object({
          id: _configSchema.schema.string()
        })
      }
    }, async (_context, req, res) => {
      const mcfg = (0, _mdeClient.getMdeConfig)();
      if (!mcfg) {
        return res.customError({
          statusCode: 503,
          body: 'MDE not configured.'
        });
      }
      try {
        const id = req.params.id;
        const data = await fn(mcfg, id);
        return res.ok({
          body: data
        });
      } catch (err) {
        var _err$message4;
        return res.customError({
          statusCode: (0, _mdeClient.mdeErrorStatus)(err),
          body: (_err$message4 = err === null || err === void 0 ? void 0 : err.message) !== null && _err$message4 !== void 0 ? _err$message4 : String(err)
        });
      }
    });
  };
  mdeMachineSub('recommendations', _mdeClient.getMachineRecommendations);
  mdeMachineSub('vulnerabilities', _mdeClient.getMachineVulnerabilities);
  mdeMachineSub('alerts', _mdeClient.getMachineAlerts);
  mdeMachineSub('logonusers', _mdeClient.getMachineLogonUsers);
  mdeMachineSub('software', _mdeClient.getMachineSoftware);
  router.get({
    path: '/api/defender_xdr/mde/vulnerabilities',
    validate: {
      query: _configSchema.schema.object({
        top: _configSchema.schema.maybe(_configSchema.schema.number())
      })
    }
  }, async (_context, req, res) => {
    const mcfg = (0, _mdeClient.getMdeConfig)();
    if (!mcfg) return res.customError({
      statusCode: 503,
      body: 'MDE not configured.'
    });
    try {
      var _top;
      const top = (_top = req.query.top) !== null && _top !== void 0 ? _top : 200;
      const data = await (0, _mdeClient.listOrgVulnerabilities)(mcfg, top);
      return res.ok({
        body: data
      });
    } catch (err) {
      var _err$message5;
      return res.customError({
        statusCode: (0, _mdeClient.mdeErrorStatus)(err),
        body: (_err$message5 = err === null || err === void 0 ? void 0 : err.message) !== null && _err$message5 !== void 0 ? _err$message5 : String(err)
      });
    }
  });
  router.get({
    path: '/api/defender_xdr/mde/alerts-legacy',
    validate: {
      query: _configSchema.schema.object({
        top: _configSchema.schema.maybe(_configSchema.schema.number())
      })
    }
  }, async (_context, req, res) => {
    const mcfg = (0, _mdeClient.getMdeConfig)();
    if (!mcfg) return res.customError({
      statusCode: 503,
      body: 'MDE not configured.'
    });
    try {
      var _top2;
      const top = (_top2 = req.query.top) !== null && _top2 !== void 0 ? _top2 : 100;
      const data = await (0, _mdeClient.listLegacyAlerts)(mcfg, top);
      return res.ok({
        body: data
      });
    } catch (err) {
      var _err$message6;
      return res.customError({
        statusCode: (0, _mdeClient.mdeErrorStatus)(err),
        body: (_err$message6 = err === null || err === void 0 ? void 0 : err.message) !== null && _err$message6 !== void 0 ? _err$message6 : String(err)
      });
    }
  });
  router.get({
    path: '/api/defender_xdr/mde/machineactions',
    validate: {
      query: _configSchema.schema.object({
        top: _configSchema.schema.maybe(_configSchema.schema.number())
      })
    }
  }, async (_context, req, res) => {
    const mcfg = (0, _mdeClient.getMdeConfig)();
    if (!mcfg) return res.customError({
      statusCode: 503,
      body: 'MDE not configured.'
    });
    try {
      var _top3;
      const top = (_top3 = req.query.top) !== null && _top3 !== void 0 ? _top3 : 100;
      const data = await (0, _mdeClient.listMachineActions)(mcfg, top);
      return res.ok({
        body: data
      });
    } catch (err) {
      var _err$message7;
      return res.customError({
        statusCode: (0, _mdeClient.mdeErrorStatus)(err),
        body: (_err$message7 = err === null || err === void 0 ? void 0 : err.message) !== null && _err$message7 !== void 0 ? _err$message7 : String(err)
      });
    }
  });
  router.get({
    path: '/api/defender_xdr/mde/machineactions/{actionId}/package-uri',
    validate: {
      params: _configSchema.schema.object({
        actionId: _configSchema.schema.string()
      })
    }
  }, async (_context, req, res) => {
    const mcfg = (0, _mdeClient.getMdeConfig)();
    if (!mcfg) return res.customError({
      statusCode: 503,
      body: 'MDE not configured.'
    });
    try {
      const actionId = req.params.actionId;
      const data = await (0, _mdeClient.getMachineActionPackageUri)(mcfg, actionId);
      return res.ok({
        body: data
      });
    } catch (err) {
      var _err$message8;
      return res.customError({
        statusCode: (0, _mdeClient.mdeErrorStatus)(err),
        body: (_err$message8 = err === null || err === void 0 ? void 0 : err.message) !== null && _err$message8 !== void 0 ? _err$message8 : String(err)
      });
    }
  });
  router.get({
    path: '/api/defender_xdr/overview',
    validate: false
  }, async (context, _req, res) => {
    try {
      var _hits2, _machinesRes$body, _aggregations, _machinesRes$body2, _hitsBody$hits, _hitsBody$total$value, _hitsBody$total, _hitsBody$total2, _aggs$by_os$buckets, _aggs$by_os, _aggs$by_exposure$buc, _aggs$by_exposure, _aggs$by_health$bucke, _aggs$by_health, _aggs$by_risk$buckets, _aggs$by_risk;
      const client = getClient(context);
      const staleDate = new Date(Date.now() - 7 * 24 * 60 * 60 * 1000).toISOString();
      const machinesRes = await client.search({
        index: _constants.DEFENDER_MACHINES_INDEX,
        ignore_unavailable: true,
        body: {
          size: 8,
          track_total_hits: true,
          sort: [{
            last_seen: {
              order: 'desc',
              missing: '_last'
            }
          }],
          query: {
            match_all: {}
          },
          aggs: {
            by_os: {
              terms: {
                field: 'os_platform',
                size: 15
              }
            },
            by_exposure: {
              terms: {
                field: 'exposure_level',
                size: 10
              }
            },
            by_health: {
              terms: {
                field: 'health_status',
                size: 10
              }
            },
            by_risk: {
              terms: {
                field: 'risk_score',
                size: 15
              }
            }
          }
        }
      });
      let incidentsCount = 0;
      let alertsCount = 0;
      let vulnCount = 0;
      let linkedAgents = 0;
      let staleCount = 0;
      try {
        var _count, _ic$body, _count2, _ac$body, _count3, _vc$body, _count4, _idRes$body, _ref, _hits$total$value, _staleRes$body, _staleRes$body2;
        const [ic, ac, vc, idRes, staleRes] = await Promise.all([client.count({
          index: _constants.DEFENDER_INCIDENTS_INDEX,
          ignore_unavailable: true
        }), client.count({
          index: _constants.DEFENDER_ALERTS_INDEX,
          ignore_unavailable: true
        }), client.count({
          index: _constants.DEFENDER_VULNERABILITIES_INDEX,
          ignore_unavailable: true
        }), client.count({
          index: _constants.DEFENDER_MACHINE_IDENTITY_INDEX,
          ignore_unavailable: true
        }), client.search({
          index: _constants.DEFENDER_MACHINES_INDEX,
          ignore_unavailable: true,
          body: {
            size: 0,
            query: {
              bool: {
                filter: [{
                  range: {
                    last_seen: {
                      lt: staleDate
                    }
                  }
                }]
              }
            },
            track_total_hits: true
          }
        })]);
        incidentsCount = (_count = (_ic$body = ic.body) === null || _ic$body === void 0 ? void 0 : _ic$body.count) !== null && _count !== void 0 ? _count : 0;
        alertsCount = (_count2 = (_ac$body = ac.body) === null || _ac$body === void 0 ? void 0 : _ac$body.count) !== null && _count2 !== void 0 ? _count2 : 0;
        vulnCount = (_count3 = (_vc$body = vc.body) === null || _vc$body === void 0 ? void 0 : _vc$body.count) !== null && _count3 !== void 0 ? _count3 : 0;
        linkedAgents = (_count4 = (_idRes$body = idRes.body) === null || _idRes$body === void 0 ? void 0 : _idRes$body.count) !== null && _count4 !== void 0 ? _count4 : 0;
        staleCount = (_ref = (_hits$total$value = (_staleRes$body = staleRes.body) === null || _staleRes$body === void 0 || (_staleRes$body = _staleRes$body.hits) === null || _staleRes$body === void 0 || (_staleRes$body = _staleRes$body.total) === null || _staleRes$body === void 0 ? void 0 : _staleRes$body.value) !== null && _hits$total$value !== void 0 ? _hits$total$value : (_staleRes$body2 = staleRes.body) === null || _staleRes$body2 === void 0 || (_staleRes$body2 = _staleRes$body2.hits) === null || _staleRes$body2 === void 0 ? void 0 : _staleRes$body2.total) !== null && _ref !== void 0 ? _ref : 0;
      } catch {
        /* optional indices */
      }
      const hitsBody = (_hits2 = (_machinesRes$body = machinesRes.body) === null || _machinesRes$body === void 0 ? void 0 : _machinesRes$body.hits) !== null && _hits2 !== void 0 ? _hits2 : {};
      const aggs = (_aggregations = (_machinesRes$body2 = machinesRes.body) === null || _machinesRes$body2 === void 0 ? void 0 : _machinesRes$body2.aggregations) !== null && _aggregations !== void 0 ? _aggregations : {};
      const recent_machines = ((_hitsBody$hits = hitsBody.hits) !== null && _hitsBody$hits !== void 0 ? _hitsBody$hits : []).map(h => h._source).filter(Boolean);
      const totalMachines = typeof hitsBody.total === 'object' ? (_hitsBody$total$value = (_hitsBody$total = hitsBody.total) === null || _hitsBody$total === void 0 ? void 0 : _hitsBody$total.value) !== null && _hitsBody$total$value !== void 0 ? _hitsBody$total$value : 0 : (_hitsBody$total2 = hitsBody.total) !== null && _hitsBody$total2 !== void 0 ? _hitsBody$total2 : recent_machines.length;
      let byOsBuckets = (_aggs$by_os$buckets = (_aggs$by_os = aggs.by_os) === null || _aggs$by_os === void 0 ? void 0 : _aggs$by_os.buckets) !== null && _aggs$by_os$buckets !== void 0 ? _aggs$by_os$buckets : [];
      let byExposureBuckets = (_aggs$by_exposure$buc = (_aggs$by_exposure = aggs.by_exposure) === null || _aggs$by_exposure === void 0 ? void 0 : _aggs$by_exposure.buckets) !== null && _aggs$by_exposure$buc !== void 0 ? _aggs$by_exposure$buc : [];
      let byHealthBuckets = (_aggs$by_health$bucke = (_aggs$by_health = aggs.by_health) === null || _aggs$by_health === void 0 ? void 0 : _aggs$by_health.buckets) !== null && _aggs$by_health$bucke !== void 0 ? _aggs$by_health$bucke : [];
      let byRiskBuckets = (_aggs$by_risk$buckets = (_aggs$by_risk = aggs.by_risk) === null || _aggs$by_risk === void 0 ? void 0 : _aggs$by_risk.buckets) !== null && _aggs$by_risk$buckets !== void 0 ? _aggs$by_risk$buckets : [];
      let recentList = recent_machines;
      let total = totalMachines;
      let dataSource = 'index';
      const mcfg = (0, _mdeClient.getMdeConfig)();
      if (total === 0 && mcfg) {
        try {
          const raw = await (0, _mdeClient.fetchAllMachinesLimited)(mcfg, 10);
          const tid = mcfg.tenantId;
          const normalized = raw.map(m => normalizeMdeMachine(m, tid));
          if (normalized.length > 0) {
            dataSource = 'mde';
            total = normalized.length;
            recentList = normalized.slice().sort((a, b) => {
              const ta = a.last_seen ? new Date(String(a.last_seen)).getTime() : 0;
              const tb = b.last_seen ? new Date(String(b.last_seen)).getTime() : 0;
              return tb - ta;
            }).slice(0, 10);
            const osMap = {};
            const exMap = {};
            const healthMap = {};
            const riskMap = {};
            normalized.forEach(r => {
              const os = String(r.os_platform || 'Unknown');
              osMap[os] = (osMap[os] || 0) + 1;
              const ex = String(r.exposure_level || 'unknown');
              exMap[ex] = (exMap[ex] || 0) + 1;
              const hs = String(r.health_status || 'unknown');
              healthMap[hs] = (healthMap[hs] || 0) + 1;
              const rs = String(r.risk_score || 'unknown');
              riskMap[rs] = (riskMap[rs] || 0) + 1;
            });
            byOsBuckets = Object.entries(osMap).map(([key, doc_count]) => ({
              key,
              doc_count
            }));
            byExposureBuckets = Object.entries(exMap).map(([key, doc_count]) => ({
              key,
              doc_count
            }));
            byHealthBuckets = Object.entries(healthMap).map(([key, doc_count]) => ({
              key,
              doc_count
            }));
            byRiskBuckets = Object.entries(riskMap).map(([key, doc_count]) => ({
              key,
              doc_count
            }));
            staleCount = normalized.filter(r => !r.last_seen || new Date(String(r.last_seen)) < new Date(staleDate)).length;
          }
        } catch {
          /* keep index empty state */
        }
      }
      let liveIncidentsCount = null;
      let liveAlertsCount = null;
      let graphError = null;
      const gcfg = (0, _graphSecurityClient.getGraphSecurityConfig)();
      if (gcfg) {
        try {
          liveIncidentsCount = await (0, _graphSecurityClient.countSecurityCollection)(gcfg, 'incidents');
        } catch (e) {
          graphError = mapGraphErr(e).body;
          liveIncidentsCount = null;
        }
        try {
          liveAlertsCount = await (0, _graphSecurityClient.countSecurityCollection)(gcfg, 'alerts_v2');
        } catch (e) {
          if (!graphError) graphError = mapGraphErr(e).body;
          liveAlertsCount = null;
        }
      }
      return res.ok({
        body: {
          total_machines: total,
          by_os: byOsBuckets,
          by_exposure: byExposureBuckets,
          by_health: byHealthBuckets,
          by_risk: byRiskBuckets,
          recent_machines: recentList,
          incidents_index_count: incidentsCount,
          alerts_index_count: alertsCount,
          vulnerabilities_index_count: vulnCount,
          linked_agents_count: linkedAgents,
          stale_machines_count: staleCount,
          graph_incidents_live_count: liveIncidentsCount,
          graph_alerts_live_count: liveAlertsCount,
          graph_error_hint: graphError,
          data_source: dataSource
        }
      });
    } catch (err) {
      var _err$statusCode2, _err$message9;
      return res.customError({
        statusCode: (_err$statusCode2 = err.statusCode) !== null && _err$statusCode2 !== void 0 ? _err$statusCode2 : 500,
        body: (_err$message9 = err.message) !== null && _err$message9 !== void 0 ? _err$message9 : String(err)
      });
    }
  });
  router.get({
    path: '/api/defender_xdr/vulnerabilities',
    validate: {
      query: _configSchema.schema.object({
        size: _configSchema.schema.maybe(_configSchema.schema.number()),
        from: _configSchema.schema.maybe(_configSchema.schema.number()),
        source: _configSchema.schema.maybe(_configSchema.schema.string())
      })
    }
  }, async (context, req, res) => {
    const q = req.query;
    if (q.source === 'mde') {
      const mcfg = (0, _mdeClient.getMdeConfig)();
      if (!mcfg) return res.customError({
        statusCode: 503,
        body: 'MDE not configured.'
      });
      try {
        var _q$size2, _data$value, _q$from2, _q$size3;
        const data = await (0, _mdeClient.listOrgVulnerabilities)(mcfg, (_q$size2 = q.size) !== null && _q$size2 !== void 0 ? _q$size2 : 200);
        const rows = (_data$value = data === null || data === void 0 ? void 0 : data.value) !== null && _data$value !== void 0 ? _data$value : [];
        const from = (_q$from2 = q.from) !== null && _q$from2 !== void 0 ? _q$from2 : 0;
        const size = (_q$size3 = q.size) !== null && _q$size3 !== void 0 ? _q$size3 : 50;
        const slice = rows.slice(from, from + size);
        const hits = slice.map((row, i) => {
          var _ref2, _row$id;
          return {
            _id: String((_ref2 = (_row$id = row.id) !== null && _row$id !== void 0 ? _row$id : row.cveId) !== null && _ref2 !== void 0 ? _ref2 : i),
            _source: typeof row === 'object' ? row : {
              raw: row
            }
          };
        });
        return res.ok({
          body: {
            hits,
            total: {
              value: rows.length,
              relation: 'eq'
            },
            source: 'mde'
          }
        });
      } catch (err) {
        var _err$message10;
        return res.customError({
          statusCode: (0, _mdeClient.mdeErrorStatus)(err),
          body: (_err$message10 = err === null || err === void 0 ? void 0 : err.message) !== null && _err$message10 !== void 0 ? _err$message10 : String(err)
        });
      }
    }
    try {
      var _hits3, _response$body2, _hits$hits2;
      const client = getClient(context);
      const {
        size = 50,
        from = 0
      } = q;
      const response = await client.search({
        index: _constants.DEFENDER_VULNERABILITIES_INDEX,
        ignore_unavailable: true,
        body: {
          size,
          from,
          sort: [{
            sync_ts: {
              order: 'desc'
            }
          }],
          query: {
            match_all: {}
          }
        }
      });
      const hits = (_hits3 = (_response$body2 = response.body) === null || _response$body2 === void 0 ? void 0 : _response$body2.hits) !== null && _hits3 !== void 0 ? _hits3 : {};
      return res.ok({
        body: {
          hits: (_hits$hits2 = hits.hits) !== null && _hits$hits2 !== void 0 ? _hits$hits2 : [],
          total: hits.total,
          source: 'index'
        }
      });
    } catch (err) {
      var _err$statusCode3, _err$message11;
      return res.customError({
        statusCode: (_err$statusCode3 = err.statusCode) !== null && _err$statusCode3 !== void 0 ? _err$statusCode3 : 500,
        body: (_err$message11 = err.message) !== null && _err$message11 !== void 0 ? _err$message11 : String(err)
      });
    }
  });
  router.get({
    path: '/api/defender_xdr/incidents/live',
    validate: {
      query: _configSchema.schema.object({
        top: _configSchema.schema.maybe(_configSchema.schema.number())
      })
    }
  }, async (_context, req, res) => {
    const config = (0, _graphSecurityClient.getGraphSecurityConfig)();
    if (!config) {
      return res.customError({
        statusCode: 503,
        body: 'Graph security not configured.'
      });
    }
    try {
      var _top4;
      const top = (_top4 = req.query.top) !== null && _top4 !== void 0 ? _top4 : 25;
      const data = await (0, _graphSecurityClient.listIncidents)(config, top);
      return res.ok({
        body: data
      });
    } catch (err) {
      const {
        status,
        body
      } = mapGraphErr(err);
      return res.customError({
        statusCode: status,
        body
      });
    }
  });
  router.get({
    path: '/api/defender_xdr/alerts/live',
    validate: {
      query: _configSchema.schema.object({
        top: _configSchema.schema.maybe(_configSchema.schema.number())
      })
    }
  }, async (_context, req, res) => {
    const config = (0, _graphSecurityClient.getGraphSecurityConfig)();
    if (!config) {
      return res.customError({
        statusCode: 503,
        body: 'Graph security not configured.'
      });
    }
    try {
      var _top5;
      const top = (_top5 = req.query.top) !== null && _top5 !== void 0 ? _top5 : 25;
      const data = await (0, _graphSecurityClient.listAlertsV2)(config, top);
      return res.ok({
        body: data
      });
    } catch (err) {
      const {
        status,
        body
      } = mapGraphErr(err);
      return res.customError({
        statusCode: status,
        body
      });
    }
  });
  router.post({
    path: '/api/defender_xdr/hunting',
    validate: {
      body: _configSchema.schema.object({
        query: _configSchema.schema.string(),
        timespan: _configSchema.schema.maybe(_configSchema.schema.string())
      })
    }
  }, async (_context, req, res) => {
    const config = (0, _graphSecurityClient.getGraphSecurityConfig)();
    if (!config) {
      return res.customError({
        statusCode: 503,
        body: 'Graph security not configured.'
      });
    }
    try {
      const {
        query,
        timespan
      } = req.body;
      const started = Date.now();
      const data = await (0, _graphSecurityClient.runHuntingQuery)(config, query, timespan || 'P7D');
      const rowCount = Array.isArray(data === null || data === void 0 ? void 0 : data.results) ? data.results.length : 0;
      return res.ok({
        body: {
          ...(data || {}),
          executionTimeMs: Date.now() - started,
          rowCount
        }
      });
    } catch (err) {
      const {
        status,
        body
      } = mapGraphErr(err);
      return res.customError({
        statusCode: status,
        body
      });
    }
  });
  router.get({
    path: '/api/defender_xdr/indicators/live',
    validate: {
      query: _configSchema.schema.object({
        top: _configSchema.schema.maybe(_configSchema.schema.number())
      })
    }
  }, async (_context, req, res) => {
    const config = (0, _mdeClient.getMdeConfig)();
    if (!config) {
      return res.customError({
        statusCode: 503,
        body: 'MDE not configured.'
      });
    }
    try {
      var _top6;
      const top = (_top6 = req.query.top) !== null && _top6 !== void 0 ? _top6 : 100;
      const data = await (0, _mdeClient.listIndicators)(config, top);
      return res.ok({
        body: data
      });
    } catch (err) {
      var _err$message12;
      return res.customError({
        statusCode: (0, _mdeClient.mdeErrorStatus)(err),
        body: (_err$message12 = err === null || err === void 0 ? void 0 : err.message) !== null && _err$message12 !== void 0 ? _err$message12 : String(err)
      });
    }
  });
  router.get({
    path: '/api/defender_xdr/audit-log',
    validate: {
      query: _configSchema.schema.object({
        size: _configSchema.schema.maybe(_configSchema.schema.number())
      })
    }
  }, async (context, req, res) => {
    try {
      var _size, _hits$hits3, _response$body3;
      const client = getClient(context);
      const size = (_size = req.query.size) !== null && _size !== void 0 ? _size : 50;
      const response = await client.search({
        index: _constants.DEFENDER_AUDIT_LOG_INDEX,
        ignore_unavailable: true,
        body: {
          size,
          sort: [{
            timestamp: {
              order: 'desc'
            }
          }],
          query: {
            match_all: {}
          }
        }
      });
      const hits = (_hits$hits3 = (_response$body3 = response.body) === null || _response$body3 === void 0 || (_response$body3 = _response$body3.hits) === null || _response$body3 === void 0 ? void 0 : _response$body3.hits) !== null && _hits$hits3 !== void 0 ? _hits$hits3 : [];
      return res.ok({
        body: {
          entries: hits.map(h => h._source)
        }
      });
    } catch (err) {
      var _err$statusCode4, _err$message13;
      return res.customError({
        statusCode: (_err$statusCode4 = err.statusCode) !== null && _err$statusCode4 !== void 0 ? _err$statusCode4 : 500,
        body: (_err$message13 = err.message) !== null && _err$message13 !== void 0 ? _err$message13 : String(err)
      });
    }
  });
  router.post({
    path: '/api/defender_xdr/alerts_enrichment',
    validate: {
      body: _configSchema.schema.object({
        size: _configSchema.schema.maybe(_configSchema.schema.number()),
        from: _configSchema.schema.maybe(_configSchema.schema.number()),
        time_from: _configSchema.schema.maybe(_configSchema.schema.string()),
        time_to: _configSchema.schema.maybe(_configSchema.schema.string()),
        defender_correlated_only: _configSchema.schema.maybe(_configSchema.schema.boolean())
      })
    }
  }, async (context, req, res) => {
    try {
      var _hits$hits5, _alertsResponse$body, _ref3, _hits$total$value2, _countResponse$body, _countResponse$body2;
      const client = getClient(context);
      const {
        size = 25,
        from = 0,
        time_from,
        time_to,
        defender_correlated_only = true
      } = req.body;
      const now = new Date();
      const defaultTo = now.toISOString();
      const defaultFrom = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000).toISOString();
      const timeGte = time_from || defaultFrom;
      const timeLte = time_to || defaultTo;
      const timeRangeFilter = {
        range: {
          timestamp: {
            gte: timeGte,
            lte: timeLte
          }
        }
      };
      let agentIdsToQuery = null;
      const agentToDefender = {};
      if (defender_correlated_only) {
        var _hits$hits4, _identityRes$body;
        const identityRes = await client.search({
          index: _constants.DEFENDER_MACHINE_IDENTITY_INDEX,
          ignore_unavailable: true,
          body: {
            size: 1000,
            _source: ['wazuh_agent_id', 'defender_machine_id', 'computer_dns_name'],
            query: {
              match_all: {}
            }
          }
        });
        const identityHits = (_hits$hits4 = (_identityRes$body = identityRes.body) === null || _identityRes$body === void 0 || (_identityRes$body = _identityRes$body.hits) === null || _identityRes$body === void 0 ? void 0 : _identityRes$body.hits) !== null && _hits$hits4 !== void 0 ? _hits$hits4 : [];
        agentIdsToQuery = identityHits.map(h => {
          var _h$_source;
          return (_h$_source = h._source) === null || _h$_source === void 0 ? void 0 : _h$_source.wazuh_agent_id;
        }).filter(id => id && id !== '000');
        if (agentIdsToQuery.length === 0) {
          return res.ok({
            body: {
              alerts: [],
              enrichments: {},
              total: 0,
              identity_count: 0
            }
          });
        }
        identityHits.forEach(h => {
          const s = h._source;
          if (s !== null && s !== void 0 && s.wazuh_agent_id) agentToDefender[s.wazuh_agent_id] = s.defender_machine_id;
        });
      }
      const must = [timeRangeFilter];
      must.push({
        bool: {
          must_not: [{
            term: {
              'agent.id': '000'
            }
          }]
        }
      });
      if (agentIdsToQuery && agentIdsToQuery.length > 0) {
        must.push({
          terms: {
            'agent.id': agentIdsToQuery
          }
        });
      }
      const alertsBody = {
        from,
        size,
        sort: [{
          timestamp: {
            order: 'desc'
          }
        }],
        _source: ['agent.id', 'agent.name', 'rule.description', 'rule.level', 'timestamp'],
        query: {
          bool: {
            must
          }
        }
      };
      const [alertsResponse, countResponse] = await Promise.all([client.search({
        index: _constants.WAZUH_ALERTS_PATTERN,
        ignore_unavailable: true,
        body: alertsBody
      }), client.search({
        index: _constants.WAZUH_ALERTS_PATTERN,
        ignore_unavailable: true,
        body: {
          size: 0,
          query: alertsBody.query,
          track_total_hits: true
        }
      })]);
      const alertHits = (_hits$hits5 = (_alertsResponse$body = alertsResponse.body) === null || _alertsResponse$body === void 0 || (_alertsResponse$body = _alertsResponse$body.hits) === null || _alertsResponse$body === void 0 ? void 0 : _alertsResponse$body.hits) !== null && _hits$hits5 !== void 0 ? _hits$hits5 : [];
      const total = (_ref3 = (_hits$total$value2 = (_countResponse$body = countResponse.body) === null || _countResponse$body === void 0 || (_countResponse$body = _countResponse$body.hits) === null || _countResponse$body === void 0 || (_countResponse$body = _countResponse$body.total) === null || _countResponse$body === void 0 ? void 0 : _countResponse$body.value) !== null && _hits$total$value2 !== void 0 ? _hits$total$value2 : (_countResponse$body2 = countResponse.body) === null || _countResponse$body2 === void 0 || (_countResponse$body2 = _countResponse$body2.hits) === null || _countResponse$body2 === void 0 ? void 0 : _countResponse$body2.total) !== null && _ref3 !== void 0 ? _ref3 : alertHits.length;
      const enrichments = {};
      alertHits.forEach(h => {
        var _h$_source2;
        const aid = (_h$_source2 = h._source) === null || _h$_source2 === void 0 || (_h$_source2 = _h$_source2.agent) === null || _h$_source2 === void 0 ? void 0 : _h$_source2.id;
        if (aid && agentToDefender[aid]) {
          enrichments[h._id] = {
            defender_machine_id: agentToDefender[aid]
          };
        }
      });
      return res.ok({
        body: {
          alerts: alertHits.map(h => ({
            id: h._id,
            ...h._source
          })),
          enrichments,
          total,
          identity_count: Object.keys(agentToDefender).length
        }
      });
    } catch (err) {
      var _err$statusCode5, _err$message14;
      return res.customError({
        statusCode: (_err$statusCode5 = err.statusCode) !== null && _err$statusCode5 !== void 0 ? _err$statusCode5 : 500,
        body: (_err$message14 = err.message) !== null && _err$message14 !== void 0 ? _err$message14 : String(err)
      });
    }
  });
}
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfY29uZmlnU2NoZW1hIiwicmVxdWlyZSIsIl9jb25zdGFudHMiLCJfbWRlQ2xpZW50IiwiX2dyYXBoU2VjdXJpdHlDbGllbnQiLCJtYXBHcmFwaEVyciIsImVyciIsIkdyYXBoQXBpRXJyb3IiLCJzdGF0dXMiLCJib2R5IiwibWVzc2FnZSIsIkVycm9yIiwiU3RyaW5nIiwibm9ybWFsaXplTWRlTWFjaGluZSIsIm0iLCJ0ZW5hbnRJZCIsInRlbmFudF9pZCIsIm1hY2hpbmVfaWQiLCJpZCIsImNvbXB1dGVyX2Ruc19uYW1lIiwiY29tcHV0ZXJEbnNOYW1lIiwib3NfcGxhdGZvcm0iLCJvc1BsYXRmb3JtIiwib3NfdmVyc2lvbiIsIm9zVmVyc2lvbiIsImxhc3Rfc2VlbiIsImxhc3RTZWVuIiwiZmlyc3Rfc2VlbiIsImZpcnN0U2VlbiIsImFhZF9kZXZpY2VfaWQiLCJhYWREZXZpY2VJZCIsInJpc2tfc2NvcmUiLCJyaXNrU2NvcmUiLCJleHBvc3VyZV9sZXZlbCIsImV4cG9zdXJlTGV2ZWwiLCJvbmJvYXJkaW5nX3N0YXR1cyIsIm9uYm9hcmRpbmdTdGF0dXMiLCJvbmJvYXJkaW5nc3RhdHVzIiwiaGVhbHRoX3N0YXR1cyIsImhlYWx0aFN0YXR1cyIsImlzb2xhdGlvbl9zdGF0dXMiLCJpc29sYXRpb25TdGF0dXMiLCJsYXN0X2lwX2FkZHJlc3MiLCJsYXN0SXBBZGRyZXNzIiwicmJhY19ncm91cF9uYW1lIiwicmJhY0dyb3VwTmFtZSIsImdldENsaWVudCIsImNvbnRleHQiLCJjb3JlIiwib3BlbnNlYXJjaCIsImNsaWVudCIsImFzQ3VycmVudFVzZXIiLCJyZWdpc3RlckRlZmVuZGVyU2VhcmNoUm91dGVzIiwicm91dGVyIiwiZ2V0IiwicGF0aCIsInZhbGlkYXRlIiwiX2NvbnRleHQiLCJfcmVxIiwicmVzIiwibWRlIiwiZ2V0TWRlQ29uZmlnIiwiZ3JhcGgiLCJnZXRHcmFwaFNlY3VyaXR5Q29uZmlnIiwib2siLCJtZGVfY29uZmlndXJlZCIsImdyYXBoX3NlY3VyaXR5X2NvbmZpZ3VyZWQiLCJ0aW1lc3RhbXAiLCJEYXRlIiwidG9JU09TdHJpbmciLCJxdWVyeSIsInNjaGVtYSIsIm9iamVjdCIsInNpemUiLCJtYXliZSIsIm51bWJlciIsImZyb20iLCJzdHJpbmciLCJzb3VyY2UiLCJyZXEiLCJxIiwibWNmZyIsImN1c3RvbUVycm9yIiwic3RhdHVzQ29kZSIsIl9xJGZyb20iLCJfcSRzaXplIiwicmF3IiwiZmV0Y2hBbGxNYWNoaW5lc0xpbWl0ZWQiLCJyb3dzIiwibWFwIiwiZmlsdGVyIiwiciIsInNvcnQiLCJhIiwiYiIsInRhIiwiZ2V0VGltZSIsInRiIiwic2xpY2UiLCJoaXRzIiwic3JjIiwiX3NvdXJjZSIsIl9pZCIsInRvdGFsIiwidmFsdWUiLCJsZW5ndGgiLCJyZWxhdGlvbiIsIl9lcnIkbWVzc2FnZSIsIm1kZUVycm9yU3RhdHVzIiwiX2hpdHMiLCJfcmVzcG9uc2UkYm9keSIsIl9oaXRzJGhpdHMiLCJtdXN0IiwicHVzaCIsInRlcm0iLCJyZXNwb25zZSIsInNlYXJjaCIsImluZGV4IiwiREVGRU5ERVJfTUFDSElORVNfSU5ERVgiLCJpZ25vcmVfdW5hdmFpbGFibGUiLCJvcmRlciIsIm1pc3NpbmciLCJib29sIiwibWF0Y2hfYWxsIiwiX2VyciRzdGF0dXNDb2RlIiwiX2VyciRtZXNzYWdlMiIsInBhcmFtcyIsImNvbmZpZyIsImRhdGEiLCJnZXRNYWNoaW5lIiwiX2VyciRtZXNzYWdlMyIsIm1kZU1hY2hpbmVTdWIiLCJwYXRoU3VmZml4IiwiZm4iLCJfZXJyJG1lc3NhZ2U0IiwiZ2V0TWFjaGluZVJlY29tbWVuZGF0aW9ucyIsImdldE1hY2hpbmVWdWxuZXJhYmlsaXRpZXMiLCJnZXRNYWNoaW5lQWxlcnRzIiwiZ2V0TWFjaGluZUxvZ29uVXNlcnMiLCJnZXRNYWNoaW5lU29mdHdhcmUiLCJ0b3AiLCJfdG9wIiwibGlzdE9yZ1Z1bG5lcmFiaWxpdGllcyIsIl9lcnIkbWVzc2FnZTUiLCJfdG9wMiIsImxpc3RMZWdhY3lBbGVydHMiLCJfZXJyJG1lc3NhZ2U2IiwiX3RvcDMiLCJsaXN0TWFjaGluZUFjdGlvbnMiLCJfZXJyJG1lc3NhZ2U3IiwiYWN0aW9uSWQiLCJnZXRNYWNoaW5lQWN0aW9uUGFja2FnZVVyaSIsIl9lcnIkbWVzc2FnZTgiLCJfaGl0czIiLCJfbWFjaGluZXNSZXMkYm9keSIsIl9hZ2dyZWdhdGlvbnMiLCJfbWFjaGluZXNSZXMkYm9keTIiLCJfaGl0c0JvZHkkaGl0cyIsIl9oaXRzQm9keSR0b3RhbCR2YWx1ZSIsIl9oaXRzQm9keSR0b3RhbCIsIl9oaXRzQm9keSR0b3RhbDIiLCJfYWdncyRieV9vcyRidWNrZXRzIiwiX2FnZ3MkYnlfb3MiLCJfYWdncyRieV9leHBvc3VyZSRidWMiLCJfYWdncyRieV9leHBvc3VyZSIsIl9hZ2dzJGJ5X2hlYWx0aCRidWNrZSIsIl9hZ2dzJGJ5X2hlYWx0aCIsIl9hZ2dzJGJ5X3Jpc2skYnVja2V0cyIsIl9hZ2dzJGJ5X3Jpc2siLCJzdGFsZURhdGUiLCJub3ciLCJtYWNoaW5lc1JlcyIsInRyYWNrX3RvdGFsX2hpdHMiLCJhZ2dzIiwiYnlfb3MiLCJ0ZXJtcyIsImZpZWxkIiwiYnlfZXhwb3N1cmUiLCJieV9oZWFsdGgiLCJieV9yaXNrIiwiaW5jaWRlbnRzQ291bnQiLCJhbGVydHNDb3VudCIsInZ1bG5Db3VudCIsImxpbmtlZEFnZW50cyIsInN0YWxlQ291bnQiLCJfY291bnQiLCJfaWMkYm9keSIsIl9jb3VudDIiLCJfYWMkYm9keSIsIl9jb3VudDMiLCJfdmMkYm9keSIsIl9jb3VudDQiLCJfaWRSZXMkYm9keSIsIl9yZWYiLCJfaGl0cyR0b3RhbCR2YWx1ZSIsIl9zdGFsZVJlcyRib2R5IiwiX3N0YWxlUmVzJGJvZHkyIiwiaWMiLCJhYyIsInZjIiwiaWRSZXMiLCJzdGFsZVJlcyIsIlByb21pc2UiLCJhbGwiLCJjb3VudCIsIkRFRkVOREVSX0lOQ0lERU5UU19JTkRFWCIsIkRFRkVOREVSX0FMRVJUU19JTkRFWCIsIkRFRkVOREVSX1ZVTE5FUkFCSUxJVElFU19JTkRFWCIsIkRFRkVOREVSX01BQ0hJTkVfSURFTlRJVFlfSU5ERVgiLCJyYW5nZSIsImx0IiwiaGl0c0JvZHkiLCJhZ2dyZWdhdGlvbnMiLCJyZWNlbnRfbWFjaGluZXMiLCJoIiwiQm9vbGVhbiIsInRvdGFsTWFjaGluZXMiLCJieU9zQnVja2V0cyIsImJ1Y2tldHMiLCJieUV4cG9zdXJlQnVja2V0cyIsImJ5SGVhbHRoQnVja2V0cyIsImJ5Umlza0J1Y2tldHMiLCJyZWNlbnRMaXN0IiwiZGF0YVNvdXJjZSIsInRpZCIsIm5vcm1hbGl6ZWQiLCJvc01hcCIsImV4TWFwIiwiaGVhbHRoTWFwIiwicmlza01hcCIsImZvckVhY2giLCJvcyIsImV4IiwiaHMiLCJycyIsIk9iamVjdCIsImVudHJpZXMiLCJrZXkiLCJkb2NfY291bnQiLCJsaXZlSW5jaWRlbnRzQ291bnQiLCJsaXZlQWxlcnRzQ291bnQiLCJncmFwaEVycm9yIiwiZ2NmZyIsImNvdW50U2VjdXJpdHlDb2xsZWN0aW9uIiwiZSIsInRvdGFsX21hY2hpbmVzIiwiaW5jaWRlbnRzX2luZGV4X2NvdW50IiwiYWxlcnRzX2luZGV4X2NvdW50IiwidnVsbmVyYWJpbGl0aWVzX2luZGV4X2NvdW50IiwibGlua2VkX2FnZW50c19jb3VudCIsInN0YWxlX21hY2hpbmVzX2NvdW50IiwiZ3JhcGhfaW5jaWRlbnRzX2xpdmVfY291bnQiLCJncmFwaF9hbGVydHNfbGl2ZV9jb3VudCIsImdyYXBoX2Vycm9yX2hpbnQiLCJkYXRhX3NvdXJjZSIsIl9lcnIkc3RhdHVzQ29kZTIiLCJfZXJyJG1lc3NhZ2U5IiwiX3Ekc2l6ZTIiLCJfZGF0YSR2YWx1ZSIsIl9xJGZyb20yIiwiX3Ekc2l6ZTMiLCJyb3ciLCJpIiwiX3JlZjIiLCJfcm93JGlkIiwiY3ZlSWQiLCJfZXJyJG1lc3NhZ2UxMCIsIl9oaXRzMyIsIl9yZXNwb25zZSRib2R5MiIsIl9oaXRzJGhpdHMyIiwic3luY190cyIsIl9lcnIkc3RhdHVzQ29kZTMiLCJfZXJyJG1lc3NhZ2UxMSIsIl90b3A0IiwibGlzdEluY2lkZW50cyIsIl90b3A1IiwibGlzdEFsZXJ0c1YyIiwicG9zdCIsInRpbWVzcGFuIiwic3RhcnRlZCIsInJ1bkh1bnRpbmdRdWVyeSIsInJvd0NvdW50IiwiQXJyYXkiLCJpc0FycmF5IiwicmVzdWx0cyIsImV4ZWN1dGlvblRpbWVNcyIsIl90b3A2IiwibGlzdEluZGljYXRvcnMiLCJfZXJyJG1lc3NhZ2UxMiIsIl9zaXplIiwiX2hpdHMkaGl0czMiLCJfcmVzcG9uc2UkYm9keTMiLCJERUZFTkRFUl9BVURJVF9MT0dfSU5ERVgiLCJfZXJyJHN0YXR1c0NvZGU0IiwiX2VyciRtZXNzYWdlMTMiLCJ0aW1lX2Zyb20iLCJ0aW1lX3RvIiwiZGVmZW5kZXJfY29ycmVsYXRlZF9vbmx5IiwiYm9vbGVhbiIsIl9oaXRzJGhpdHM1IiwiX2FsZXJ0c1Jlc3BvbnNlJGJvZHkiLCJfcmVmMyIsIl9oaXRzJHRvdGFsJHZhbHVlMiIsIl9jb3VudFJlc3BvbnNlJGJvZHkiLCJfY291bnRSZXNwb25zZSRib2R5MiIsImRlZmF1bHRUbyIsImRlZmF1bHRGcm9tIiwidGltZUd0ZSIsInRpbWVMdGUiLCJ0aW1lUmFuZ2VGaWx0ZXIiLCJndGUiLCJsdGUiLCJhZ2VudElkc1RvUXVlcnkiLCJhZ2VudFRvRGVmZW5kZXIiLCJfaGl0cyRoaXRzNCIsIl9pZGVudGl0eVJlcyRib2R5IiwiaWRlbnRpdHlSZXMiLCJpZGVudGl0eUhpdHMiLCJfaCRfc291cmNlIiwid2F6dWhfYWdlbnRfaWQiLCJhbGVydHMiLCJlbnJpY2htZW50cyIsImlkZW50aXR5X2NvdW50IiwicyIsImRlZmVuZGVyX21hY2hpbmVfaWQiLCJtdXN0X25vdCIsImFsZXJ0c0JvZHkiLCJhbGVydHNSZXNwb25zZSIsImNvdW50UmVzcG9uc2UiLCJXQVpVSF9BTEVSVFNfUEFUVEVSTiIsImFsZXJ0SGl0cyIsIl9oJF9zb3VyY2UyIiwiYWlkIiwiYWdlbnQiLCJrZXlzIiwiX2VyciRzdGF0dXNDb2RlNSIsIl9lcnIkbWVzc2FnZTE0Il0sInNvdXJjZXMiOlsic2VhcmNoLnRzIl0sInNvdXJjZXNDb250ZW50IjpbIi8qXG4gKiBEZWZlbmRlciBwbHVnaW4g4oCUIE9wZW5TZWFyY2ggcmVhZHMgKyBHcmFwaC9NREUgcHJveGllc1xuICovXG5cbmltcG9ydCB7IElSb3V0ZXIgfSBmcm9tICdvcGVuc2VhcmNoLWRhc2hib2FyZHMvc2VydmVyJztcbmltcG9ydCB7IHNjaGVtYSB9IGZyb20gJ0Bvc2QvY29uZmlnLXNjaGVtYSc7XG5pbXBvcnQge1xuICBERUZFTkRFUl9NQUNISU5FU19JTkRFWCxcbiAgREVGRU5ERVJfTUFDSElORV9JREVOVElUWV9JTkRFWCxcbiAgREVGRU5ERVJfVlVMTkVSQUJJTElUSUVTX0lOREVYLFxuICBERUZFTkRFUl9JTkNJREVOVFNfSU5ERVgsXG4gIERFRkVOREVSX0FMRVJUU19JTkRFWCxcbiAgREVGRU5ERVJfQVVESVRfTE9HX0lOREVYLFxuICBXQVpVSF9BTEVSVFNfUEFUVEVSTixcbn0gZnJvbSAnLi4vLi4vY29tbW9uL2NvbnN0YW50cyc7XG5pbXBvcnQge1xuICBnZXRNZGVDb25maWcsXG4gIGdldE1hY2hpbmUsXG4gIGxpc3RJbmRpY2F0b3JzLFxuICBmZXRjaEFsbE1hY2hpbmVzTGltaXRlZCxcbiAgZ2V0TWFjaGluZVJlY29tbWVuZGF0aW9ucyxcbiAgZ2V0TWFjaGluZVZ1bG5lcmFiaWxpdGllcyxcbiAgZ2V0TWFjaGluZUFsZXJ0cyxcbiAgZ2V0TWFjaGluZUxvZ29uVXNlcnMsXG4gIGdldE1hY2hpbmVTb2Z0d2FyZSxcbiAgbGlzdE9yZ1Z1bG5lcmFiaWxpdGllcyxcbiAgbGlzdExlZ2FjeUFsZXJ0cyxcbiAgbGlzdE1hY2hpbmVBY3Rpb25zLFxuICBnZXRNYWNoaW5lQWN0aW9uUGFja2FnZVVyaSxcbiAgbWRlRXJyb3JTdGF0dXMsXG59IGZyb20gJy4uL2xpYi9tZGUtY2xpZW50JztcbmltcG9ydCB7XG4gIGdldEdyYXBoU2VjdXJpdHlDb25maWcsXG4gIGxpc3RJbmNpZGVudHMsXG4gIGxpc3RBbGVydHNWMixcbiAgcnVuSHVudGluZ1F1ZXJ5LFxuICBjb3VudFNlY3VyaXR5Q29sbGVjdGlvbixcbiAgR3JhcGhBcGlFcnJvcixcbn0gZnJvbSAnLi4vbGliL2dyYXBoLXNlY3VyaXR5LWNsaWVudCc7XG5cbmZ1bmN0aW9uIG1hcEdyYXBoRXJyKGVycjogdW5rbm93bik6IHsgc3RhdHVzOiBudW1iZXI7IGJvZHk6IHN0cmluZyB9IHtcbiAgaWYgKGVyciBpbnN0YW5jZW9mIEdyYXBoQXBpRXJyb3IpIHtcbiAgICByZXR1cm4geyBzdGF0dXM6IGVyci5zdGF0dXMgPj0gNDAwICYmIGVyci5zdGF0dXMgPCA2MDAgPyBlcnIuc3RhdHVzIDogNTAyLCBib2R5OiBlcnIubWVzc2FnZSB9O1xuICB9XG4gIHJldHVybiB7IHN0YXR1czogNTAyLCBib2R5OiBlcnIgaW5zdGFuY2VvZiBFcnJvciA/IGVyci5tZXNzYWdlIDogU3RyaW5nKGVycikgfTtcbn1cblxuZnVuY3Rpb24gbm9ybWFsaXplTWRlTWFjaGluZShtOiBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPiwgdGVuYW50SWQ6IHN0cmluZykge1xuICByZXR1cm4ge1xuICAgIHRlbmFudF9pZDogdGVuYW50SWQsXG4gICAgbWFjaGluZV9pZDogbS5pZCxcbiAgICBjb21wdXRlcl9kbnNfbmFtZTogbS5jb21wdXRlckRuc05hbWUgfHwgJycsXG4gICAgb3NfcGxhdGZvcm06IG0ub3NQbGF0Zm9ybSB8fCAnJyxcbiAgICBvc192ZXJzaW9uOiBtLm9zVmVyc2lvbiB8fCAnJyxcbiAgICBsYXN0X3NlZW46IG0ubGFzdFNlZW4gfHwgbnVsbCxcbiAgICBmaXJzdF9zZWVuOiBtLmZpcnN0U2VlbiB8fCBudWxsLFxuICAgIGFhZF9kZXZpY2VfaWQ6IG0uYWFkRGV2aWNlSWQgfHwgJycsXG4gICAgcmlza19zY29yZTogbS5yaXNrU2NvcmUgIT0gbnVsbCA/IFN0cmluZyhtLnJpc2tTY29yZSkgOiAnJyxcbiAgICBleHBvc3VyZV9sZXZlbDogbS5leHBvc3VyZUxldmVsIHx8ICcnLFxuICAgIG9uYm9hcmRpbmdfc3RhdHVzOiBtLm9uYm9hcmRpbmdTdGF0dXMgfHwgbS5vbmJvYXJkaW5nc3RhdHVzIHx8ICcnLFxuICAgIGhlYWx0aF9zdGF0dXM6IG0uaGVhbHRoU3RhdHVzIHx8ICcnLFxuICAgIGlzb2xhdGlvbl9zdGF0dXM6IG0uaXNvbGF0aW9uU3RhdHVzIHx8ICcnLFxuICAgIGxhc3RfaXBfYWRkcmVzczogbS5sYXN0SXBBZGRyZXNzIHx8ICcnLFxuICAgIHJiYWNfZ3JvdXBfbmFtZTogbS5yYmFjR3JvdXBOYW1lIHx8ICcnLFxuICB9O1xufVxuXG5mdW5jdGlvbiBnZXRDbGllbnQoY29udGV4dDogYW55KSB7XG4gIHJldHVybiBjb250ZXh0LmNvcmUub3BlbnNlYXJjaC5jbGllbnQuYXNDdXJyZW50VXNlcjtcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIHJlZ2lzdGVyRGVmZW5kZXJTZWFyY2hSb3V0ZXMocm91dGVyOiBJUm91dGVyKSB7XG4gIHJvdXRlci5nZXQoeyBwYXRoOiAnL2FwaS9kZWZlbmRlcl9wbHVnaW4vaGVhbHRoJywgdmFsaWRhdGU6IGZhbHNlIH0sIGFzeW5jIChfY29udGV4dCwgX3JlcSwgcmVzKSA9PiB7XG4gICAgY29uc3QgbWRlID0gISFnZXRNZGVDb25maWcoKTtcbiAgICBjb25zdCBncmFwaCA9ICEhZ2V0R3JhcGhTZWN1cml0eUNvbmZpZygpO1xuICAgIHJldHVybiByZXMub2soe1xuICAgICAgYm9keToge1xuICAgICAgICBvazogbWRlIHx8IGdyYXBoLFxuICAgICAgICBtZGVfY29uZmlndXJlZDogbWRlLFxuICAgICAgICBncmFwaF9zZWN1cml0eV9jb25maWd1cmVkOiBncmFwaCxcbiAgICAgICAgdGltZXN0YW1wOiBuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCksXG4gICAgICB9LFxuICAgIH0pO1xuICB9KTtcblxuICByb3V0ZXIuZ2V0KFxuICAgIHtcbiAgICAgIHBhdGg6ICcvYXBpL2RlZmVuZGVyX3BsdWdpbi9tYWNoaW5lcycsXG4gICAgICB2YWxpZGF0ZToge1xuICAgICAgICBxdWVyeTogc2NoZW1hLm9iamVjdCh7XG4gICAgICAgICAgc2l6ZTogc2NoZW1hLm1heWJlKHNjaGVtYS5udW1iZXIoKSksXG4gICAgICAgICAgZnJvbTogc2NoZW1hLm1heWJlKHNjaGVtYS5udW1iZXIoKSksXG4gICAgICAgICAgb3NfcGxhdGZvcm06IHNjaGVtYS5tYXliZShzY2hlbWEuc3RyaW5nKCkpLFxuICAgICAgICAgIGV4cG9zdXJlX2xldmVsOiBzY2hlbWEubWF5YmUoc2NoZW1hLnN0cmluZygpKSxcbiAgICAgICAgICBzb3VyY2U6IHNjaGVtYS5tYXliZShzY2hlbWEuc3RyaW5nKCkpLFxuICAgICAgICB9KSxcbiAgICAgIH0sXG4gICAgfSxcbiAgICBhc3luYyAoY29udGV4dCwgcmVxLCByZXMpID0+IHtcbiAgICAgIGNvbnN0IHEgPSByZXEucXVlcnkgYXMge1xuICAgICAgICBzaXplPzogbnVtYmVyO1xuICAgICAgICBmcm9tPzogbnVtYmVyO1xuICAgICAgICBvc19wbGF0Zm9ybT86IHN0cmluZztcbiAgICAgICAgZXhwb3N1cmVfbGV2ZWw/OiBzdHJpbmc7XG4gICAgICAgIHNvdXJjZT86IHN0cmluZztcbiAgICAgIH07XG4gICAgICBpZiAocS5zb3VyY2UgPT09ICdsaXZlJykge1xuICAgICAgICBjb25zdCBtY2ZnID0gZ2V0TWRlQ29uZmlnKCk7XG4gICAgICAgIGlmICghbWNmZykge1xuICAgICAgICAgIHJldHVybiByZXMuY3VzdG9tRXJyb3IoeyBzdGF0dXNDb2RlOiA1MDMsIGJvZHk6ICdNREUgbm90IGNvbmZpZ3VyZWQuJyB9KTtcbiAgICAgICAgfVxuICAgICAgICB0cnkge1xuICAgICAgICAgIGNvbnN0IHJhdyA9IGF3YWl0IGZldGNoQWxsTWFjaGluZXNMaW1pdGVkKG1jZmcsIDE1KTtcbiAgICAgICAgICBjb25zdCB0ZW5hbnRJZCA9IG1jZmcudGVuYW50SWQ7XG4gICAgICAgICAgbGV0IHJvd3MgPSByYXcubWFwKChtKSA9PiBub3JtYWxpemVNZGVNYWNoaW5lKG0gYXMgUmVjb3JkPHN0cmluZywgdW5rbm93bj4sIHRlbmFudElkKSk7XG4gICAgICAgICAgaWYgKHEub3NfcGxhdGZvcm0pIHtcbiAgICAgICAgICAgIHJvd3MgPSByb3dzLmZpbHRlcigocikgPT4gU3RyaW5nKHIub3NfcGxhdGZvcm0pID09PSBxLm9zX3BsYXRmb3JtKTtcbiAgICAgICAgICB9XG4gICAgICAgICAgaWYgKHEuZXhwb3N1cmVfbGV2ZWwpIHtcbiAgICAgICAgICAgIHJvd3MgPSByb3dzLmZpbHRlcigocikgPT4gU3RyaW5nKHIuZXhwb3N1cmVfbGV2ZWwpID09PSBxLmV4cG9zdXJlX2xldmVsKTtcbiAgICAgICAgICB9XG4gICAgICAgICAgcm93cy5zb3J0KChhLCBiKSA9PiB7XG4gICAgICAgICAgICBjb25zdCB0YSA9IGEubGFzdF9zZWVuID8gbmV3IERhdGUoU3RyaW5nKGEubGFzdF9zZWVuKSkuZ2V0VGltZSgpIDogMDtcbiAgICAgICAgICAgIGNvbnN0IHRiID0gYi5sYXN0X3NlZW4gPyBuZXcgRGF0ZShTdHJpbmcoYi5sYXN0X3NlZW4pKS5nZXRUaW1lKCkgOiAwO1xuICAgICAgICAgICAgcmV0dXJuIHRiIC0gdGE7XG4gICAgICAgICAgfSk7XG4gICAgICAgICAgY29uc3QgZnJvbSA9IHEuZnJvbSA/PyAwO1xuICAgICAgICAgIGNvbnN0IHNpemUgPSBxLnNpemUgPz8gNTA7XG4gICAgICAgICAgY29uc3Qgc2xpY2UgPSByb3dzLnNsaWNlKGZyb20sIGZyb20gKyBzaXplKTtcbiAgICAgICAgICBjb25zdCBoaXRzID0gc2xpY2UubWFwKChzcmMpID0+ICh7IF9zb3VyY2U6IHNyYywgX2lkOiBzcmMubWFjaGluZV9pZCB9KSk7XG4gICAgICAgICAgcmV0dXJuIHJlcy5vayh7XG4gICAgICAgICAgICBib2R5OiB7XG4gICAgICAgICAgICAgIGhpdHMsXG4gICAgICAgICAgICAgIHRvdGFsOiB7IHZhbHVlOiByb3dzLmxlbmd0aCwgcmVsYXRpb246ICdlcScgfSxcbiAgICAgICAgICAgICAgc291cmNlOiAnbWRlJyxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgfSk7XG4gICAgICAgIH0gY2F0Y2ggKGVycjogYW55KSB7XG4gICAgICAgICAgcmV0dXJuIHJlcy5jdXN0b21FcnJvcih7XG4gICAgICAgICAgICBzdGF0dXNDb2RlOiBtZGVFcnJvclN0YXR1cyhlcnIpLFxuICAgICAgICAgICAgYm9keTogZXJyPy5tZXNzYWdlID8/IFN0cmluZyhlcnIpLFxuICAgICAgICAgIH0pO1xuICAgICAgICB9XG4gICAgICB9XG4gICAgICB0cnkge1xuICAgICAgICBjb25zdCBjbGllbnQgPSBnZXRDbGllbnQoY29udGV4dCk7XG4gICAgICAgIGNvbnN0IHsgc2l6ZSA9IDUwLCBmcm9tID0gMCwgb3NfcGxhdGZvcm0sIGV4cG9zdXJlX2xldmVsIH0gPSBxO1xuICAgICAgICBjb25zdCBtdXN0OiBhbnlbXSA9IFtdO1xuICAgICAgICBpZiAob3NfcGxhdGZvcm0pIG11c3QucHVzaCh7IHRlcm06IHsgb3NfcGxhdGZvcm0gfSB9KTtcbiAgICAgICAgaWYgKGV4cG9zdXJlX2xldmVsKSBtdXN0LnB1c2goeyB0ZXJtOiB7IGV4cG9zdXJlX2xldmVsIH0gfSk7XG4gICAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgY2xpZW50LnNlYXJjaCh7XG4gICAgICAgICAgaW5kZXg6IERFRkVOREVSX01BQ0hJTkVTX0lOREVYLFxuICAgICAgICAgIGlnbm9yZV91bmF2YWlsYWJsZTogdHJ1ZSxcbiAgICAgICAgICBib2R5OiB7XG4gICAgICAgICAgICBzaXplLFxuICAgICAgICAgICAgZnJvbSxcbiAgICAgICAgICAgIHNvcnQ6IFt7IGxhc3Rfc2VlbjogeyBvcmRlcjogJ2Rlc2MnLCBtaXNzaW5nOiAnX2xhc3QnIH0gfSwgeyBjb21wdXRlcl9kbnNfbmFtZTogJ2FzYycgfV0sXG4gICAgICAgICAgICBxdWVyeTogbXVzdC5sZW5ndGggPyB7IGJvb2w6IHsgbXVzdCB9IH0gOiB7IG1hdGNoX2FsbDoge30gfSxcbiAgICAgICAgICB9LFxuICAgICAgICB9KTtcbiAgICAgICAgY29uc3QgaGl0cyA9IChyZXNwb25zZS5ib2R5IGFzIGFueSk/LmhpdHMgPz8ge307XG4gICAgICAgIHJldHVybiByZXMub2soeyBib2R5OiB7IGhpdHM6IGhpdHMuaGl0cyA/PyBbXSwgdG90YWw6IGhpdHMudG90YWwsIHNvdXJjZTogJ2luZGV4JyB9IH0pO1xuICAgICAgfSBjYXRjaCAoZXJyOiBhbnkpIHtcbiAgICAgICAgcmV0dXJuIHJlcy5jdXN0b21FcnJvcih7XG4gICAgICAgICAgc3RhdHVzQ29kZTogZXJyLnN0YXR1c0NvZGUgPz8gNTAwLFxuICAgICAgICAgIGJvZHk6IGVyci5tZXNzYWdlID8/IFN0cmluZyhlcnIpLFxuICAgICAgICB9KTtcbiAgICAgIH1cbiAgICB9XG4gICk7XG5cbiAgcm91dGVyLmdldChcbiAgICB7XG4gICAgICBwYXRoOiAnL2FwaS9kZWZlbmRlcl9wbHVnaW4vbWFjaGluZXMve2lkfS9saXZlJyxcbiAgICAgIHZhbGlkYXRlOiB7IHBhcmFtczogc2NoZW1hLm9iamVjdCh7IGlkOiBzY2hlbWEuc3RyaW5nKCkgfSkgfSxcbiAgICB9LFxuICAgIGFzeW5jIChfY29udGV4dCwgX3JlcSwgcmVzKSA9PiB7XG4gICAgICBjb25zdCBjb25maWcgPSBnZXRNZGVDb25maWcoKTtcbiAgICAgIGlmICghY29uZmlnKSB7XG4gICAgICAgIHJldHVybiByZXMuY3VzdG9tRXJyb3Ioe1xuICAgICAgICAgIHN0YXR1c0NvZGU6IDUwMyxcbiAgICAgICAgICBib2R5OiAnRGVmZW5kZXIgTURFIG5vdCBjb25maWd1cmVkIChERUZFTkRFUl9URU5BTlRfSUQsIERFRkVOREVSX0NMSUVOVF9JRCwgREVGRU5ERVJfQ0xJRU5UX1NFQ1JFVCkuJyxcbiAgICAgICAgfSk7XG4gICAgICB9XG4gICAgICB0cnkge1xuICAgICAgICBjb25zdCBpZCA9IChfcmVxLnBhcmFtcyBhcyB7IGlkOiBzdHJpbmcgfSkuaWQ7XG4gICAgICAgIGNvbnN0IGRhdGEgPSBhd2FpdCBnZXRNYWNoaW5lKGNvbmZpZywgaWQpO1xuICAgICAgICByZXR1cm4gcmVzLm9rKHsgYm9keTogZGF0YSB9KTtcbiAgICAgIH0gY2F0Y2ggKGVycjogYW55KSB7XG4gICAgICAgIHJldHVybiByZXMuY3VzdG9tRXJyb3Ioe1xuICAgICAgICAgIHN0YXR1c0NvZGU6IG1kZUVycm9yU3RhdHVzKGVyciksXG4gICAgICAgICAgYm9keTogZXJyPy5tZXNzYWdlID8/IFN0cmluZyhlcnIpLFxuICAgICAgICB9KTtcbiAgICAgIH1cbiAgICB9XG4gICk7XG5cbiAgY29uc3QgbWRlTWFjaGluZVN1YiA9IChwYXRoU3VmZml4OiBzdHJpbmcsIGZuOiAoYzogYW55LCBpZDogc3RyaW5nKSA9PiBQcm9taXNlPHVua25vd24+KSA9PiB7XG4gICAgcm91dGVyLmdldChcbiAgICAgIHtcbiAgICAgICAgcGF0aDogYC9hcGkvZGVmZW5kZXJfcGx1Z2luL21hY2hpbmVzL3tpZH0vbGl2ZS8ke3BhdGhTdWZmaXh9YCxcbiAgICAgICAgdmFsaWRhdGU6IHsgcGFyYW1zOiBzY2hlbWEub2JqZWN0KHsgaWQ6IHNjaGVtYS5zdHJpbmcoKSB9KSB9LFxuICAgICAgfSxcbiAgICAgIGFzeW5jIChfY29udGV4dCwgcmVxLCByZXMpID0+IHtcbiAgICAgICAgY29uc3QgbWNmZyA9IGdldE1kZUNvbmZpZygpO1xuICAgICAgICBpZiAoIW1jZmcpIHtcbiAgICAgICAgICByZXR1cm4gcmVzLmN1c3RvbUVycm9yKHsgc3RhdHVzQ29kZTogNTAzLCBib2R5OiAnTURFIG5vdCBjb25maWd1cmVkLicgfSk7XG4gICAgICAgIH1cbiAgICAgICAgdHJ5IHtcbiAgICAgICAgICBjb25zdCBpZCA9IChyZXEucGFyYW1zIGFzIHsgaWQ6IHN0cmluZyB9KS5pZDtcbiAgICAgICAgICBjb25zdCBkYXRhID0gYXdhaXQgZm4obWNmZywgaWQpO1xuICAgICAgICAgIHJldHVybiByZXMub2soeyBib2R5OiBkYXRhIH0pO1xuICAgICAgICB9IGNhdGNoIChlcnI6IGFueSkge1xuICAgICAgICAgIHJldHVybiByZXMuY3VzdG9tRXJyb3IoeyBzdGF0dXNDb2RlOiBtZGVFcnJvclN0YXR1cyhlcnIpLCBib2R5OiBlcnI/Lm1lc3NhZ2UgPz8gU3RyaW5nKGVycikgfSk7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICApO1xuICB9O1xuXG4gIG1kZU1hY2hpbmVTdWIoJ3JlY29tbWVuZGF0aW9ucycsIGdldE1hY2hpbmVSZWNvbW1lbmRhdGlvbnMpO1xuICBtZGVNYWNoaW5lU3ViKCd2dWxuZXJhYmlsaXRpZXMnLCBnZXRNYWNoaW5lVnVsbmVyYWJpbGl0aWVzKTtcbiAgbWRlTWFjaGluZVN1YignYWxlcnRzJywgZ2V0TWFjaGluZUFsZXJ0cyk7XG4gIG1kZU1hY2hpbmVTdWIoJ2xvZ29udXNlcnMnLCBnZXRNYWNoaW5lTG9nb25Vc2Vycyk7XG4gIG1kZU1hY2hpbmVTdWIoJ3NvZnR3YXJlJywgZ2V0TWFjaGluZVNvZnR3YXJlKTtcblxuICByb3V0ZXIuZ2V0KFxuICAgIHtcbiAgICAgIHBhdGg6ICcvYXBpL2RlZmVuZGVyX3BsdWdpbi9tZGUvdnVsbmVyYWJpbGl0aWVzJyxcbiAgICAgIHZhbGlkYXRlOiB7IHF1ZXJ5OiBzY2hlbWEub2JqZWN0KHsgdG9wOiBzY2hlbWEubWF5YmUoc2NoZW1hLm51bWJlcigpKSB9KSB9LFxuICAgIH0sXG4gICAgYXN5bmMgKF9jb250ZXh0LCByZXEsIHJlcykgPT4ge1xuICAgICAgY29uc3QgbWNmZyA9IGdldE1kZUNvbmZpZygpO1xuICAgICAgaWYgKCFtY2ZnKSByZXR1cm4gcmVzLmN1c3RvbUVycm9yKHsgc3RhdHVzQ29kZTogNTAzLCBib2R5OiAnTURFIG5vdCBjb25maWd1cmVkLicgfSk7XG4gICAgICB0cnkge1xuICAgICAgICBjb25zdCB0b3AgPSAocmVxLnF1ZXJ5IGFzIHsgdG9wPzogbnVtYmVyIH0pLnRvcCA/PyAyMDA7XG4gICAgICAgIGNvbnN0IGRhdGEgPSBhd2FpdCBsaXN0T3JnVnVsbmVyYWJpbGl0aWVzKG1jZmcsIHRvcCk7XG4gICAgICAgIHJldHVybiByZXMub2soeyBib2R5OiBkYXRhIH0pO1xuICAgICAgfSBjYXRjaCAoZXJyOiBhbnkpIHtcbiAgICAgICAgcmV0dXJuIHJlcy5jdXN0b21FcnJvcih7IHN0YXR1c0NvZGU6IG1kZUVycm9yU3RhdHVzKGVyciksIGJvZHk6IGVycj8ubWVzc2FnZSA/PyBTdHJpbmcoZXJyKSB9KTtcbiAgICAgIH1cbiAgICB9XG4gICk7XG5cbiAgcm91dGVyLmdldChcbiAgICB7XG4gICAgICBwYXRoOiAnL2FwaS9kZWZlbmRlcl9wbHVnaW4vbWRlL2FsZXJ0cy1sZWdhY3knLFxuICAgICAgdmFsaWRhdGU6IHsgcXVlcnk6IHNjaGVtYS5vYmplY3QoeyB0b3A6IHNjaGVtYS5tYXliZShzY2hlbWEubnVtYmVyKCkpIH0pIH0sXG4gICAgfSxcbiAgICBhc3luYyAoX2NvbnRleHQsIHJlcSwgcmVzKSA9PiB7XG4gICAgICBjb25zdCBtY2ZnID0gZ2V0TWRlQ29uZmlnKCk7XG4gICAgICBpZiAoIW1jZmcpIHJldHVybiByZXMuY3VzdG9tRXJyb3IoeyBzdGF0dXNDb2RlOiA1MDMsIGJvZHk6ICdNREUgbm90IGNvbmZpZ3VyZWQuJyB9KTtcbiAgICAgIHRyeSB7XG4gICAgICAgIGNvbnN0IHRvcCA9IChyZXEucXVlcnkgYXMgeyB0b3A/OiBudW1iZXIgfSkudG9wID8/IDEwMDtcbiAgICAgICAgY29uc3QgZGF0YSA9IGF3YWl0IGxpc3RMZWdhY3lBbGVydHMobWNmZywgdG9wKTtcbiAgICAgICAgcmV0dXJuIHJlcy5vayh7IGJvZHk6IGRhdGEgfSk7XG4gICAgICB9IGNhdGNoIChlcnI6IGFueSkge1xuICAgICAgICByZXR1cm4gcmVzLmN1c3RvbUVycm9yKHsgc3RhdHVzQ29kZTogbWRlRXJyb3JTdGF0dXMoZXJyKSwgYm9keTogZXJyPy5tZXNzYWdlID8/IFN0cmluZyhlcnIpIH0pO1xuICAgICAgfVxuICAgIH1cbiAgKTtcblxuICByb3V0ZXIuZ2V0KFxuICAgIHtcbiAgICAgIHBhdGg6ICcvYXBpL2RlZmVuZGVyX3BsdWdpbi9tZGUvbWFjaGluZWFjdGlvbnMnLFxuICAgICAgdmFsaWRhdGU6IHsgcXVlcnk6IHNjaGVtYS5vYmplY3QoeyB0b3A6IHNjaGVtYS5tYXliZShzY2hlbWEubnVtYmVyKCkpIH0pIH0sXG4gICAgfSxcbiAgICBhc3luYyAoX2NvbnRleHQsIHJlcSwgcmVzKSA9PiB7XG4gICAgICBjb25zdCBtY2ZnID0gZ2V0TWRlQ29uZmlnKCk7XG4gICAgICBpZiAoIW1jZmcpIHJldHVybiByZXMuY3VzdG9tRXJyb3IoeyBzdGF0dXNDb2RlOiA1MDMsIGJvZHk6ICdNREUgbm90IGNvbmZpZ3VyZWQuJyB9KTtcbiAgICAgIHRyeSB7XG4gICAgICAgIGNvbnN0IHRvcCA9IChyZXEucXVlcnkgYXMgeyB0b3A/OiBudW1iZXIgfSkudG9wID8/IDEwMDtcbiAgICAgICAgY29uc3QgZGF0YSA9IGF3YWl0IGxpc3RNYWNoaW5lQWN0aW9ucyhtY2ZnLCB0b3ApO1xuICAgICAgICByZXR1cm4gcmVzLm9rKHsgYm9keTogZGF0YSB9KTtcbiAgICAgIH0gY2F0Y2ggKGVycjogYW55KSB7XG4gICAgICAgIHJldHVybiByZXMuY3VzdG9tRXJyb3IoeyBzdGF0dXNDb2RlOiBtZGVFcnJvclN0YXR1cyhlcnIpLCBib2R5OiBlcnI/Lm1lc3NhZ2UgPz8gU3RyaW5nKGVycikgfSk7XG4gICAgICB9XG4gICAgfVxuICApO1xuXG4gIHJvdXRlci5nZXQoXG4gICAge1xuICAgICAgcGF0aDogJy9hcGkvZGVmZW5kZXJfcGx1Z2luL21kZS9tYWNoaW5lYWN0aW9ucy97YWN0aW9uSWR9L3BhY2thZ2UtdXJpJyxcbiAgICAgIHZhbGlkYXRlOiB7IHBhcmFtczogc2NoZW1hLm9iamVjdCh7IGFjdGlvbklkOiBzY2hlbWEuc3RyaW5nKCkgfSkgfSxcbiAgICB9LFxuICAgIGFzeW5jIChfY29udGV4dCwgcmVxLCByZXMpID0+IHtcbiAgICAgIGNvbnN0IG1jZmcgPSBnZXRNZGVDb25maWcoKTtcbiAgICAgIGlmICghbWNmZykgcmV0dXJuIHJlcy5jdXN0b21FcnJvcih7IHN0YXR1c0NvZGU6IDUwMywgYm9keTogJ01ERSBub3QgY29uZmlndXJlZC4nIH0pO1xuICAgICAgdHJ5IHtcbiAgICAgICAgY29uc3QgYWN0aW9uSWQgPSAocmVxLnBhcmFtcyBhcyB7IGFjdGlvbklkOiBzdHJpbmcgfSkuYWN0aW9uSWQ7XG4gICAgICAgIGNvbnN0IGRhdGEgPSBhd2FpdCBnZXRNYWNoaW5lQWN0aW9uUGFja2FnZVVyaShtY2ZnLCBhY3Rpb25JZCk7XG4gICAgICAgIHJldHVybiByZXMub2soeyBib2R5OiBkYXRhIH0pO1xuICAgICAgfSBjYXRjaCAoZXJyOiBhbnkpIHtcbiAgICAgICAgcmV0dXJuIHJlcy5jdXN0b21FcnJvcih7IHN0YXR1c0NvZGU6IG1kZUVycm9yU3RhdHVzKGVyciksIGJvZHk6IGVycj8ubWVzc2FnZSA/PyBTdHJpbmcoZXJyKSB9KTtcbiAgICAgIH1cbiAgICB9XG4gICk7XG5cbiAgcm91dGVyLmdldCh7IHBhdGg6ICcvYXBpL2RlZmVuZGVyX3BsdWdpbi9vdmVydmlldycsIHZhbGlkYXRlOiBmYWxzZSB9LCBhc3luYyAoY29udGV4dCwgX3JlcSwgcmVzKSA9PiB7XG4gICAgdHJ5IHtcbiAgICAgIGNvbnN0IGNsaWVudCA9IGdldENsaWVudChjb250ZXh0KTtcbiAgICAgIGNvbnN0IHN0YWxlRGF0ZSA9IG5ldyBEYXRlKERhdGUubm93KCkgLSA3ICogMjQgKiA2MCAqIDYwICogMTAwMCkudG9JU09TdHJpbmcoKTtcblxuICAgICAgY29uc3QgbWFjaGluZXNSZXMgPSBhd2FpdCBjbGllbnQuc2VhcmNoKHtcbiAgICAgICAgaW5kZXg6IERFRkVOREVSX01BQ0hJTkVTX0lOREVYLFxuICAgICAgICBpZ25vcmVfdW5hdmFpbGFibGU6IHRydWUsXG4gICAgICAgIGJvZHk6IHtcbiAgICAgICAgICBzaXplOiA4LFxuICAgICAgICAgIHRyYWNrX3RvdGFsX2hpdHM6IHRydWUsXG4gICAgICAgICAgc29ydDogW3sgbGFzdF9zZWVuOiB7IG9yZGVyOiAnZGVzYycsIG1pc3Npbmc6ICdfbGFzdCcgfSB9XSxcbiAgICAgICAgICBxdWVyeTogeyBtYXRjaF9hbGw6IHt9IH0sXG4gICAgICAgICAgYWdnczoge1xuICAgICAgICAgICAgYnlfb3M6IHsgdGVybXM6IHsgZmllbGQ6ICdvc19wbGF0Zm9ybScsIHNpemU6IDE1IH0gfSxcbiAgICAgICAgICAgIGJ5X2V4cG9zdXJlOiB7IHRlcm1zOiB7IGZpZWxkOiAnZXhwb3N1cmVfbGV2ZWwnLCBzaXplOiAxMCB9IH0sXG4gICAgICAgICAgICBieV9oZWFsdGg6IHsgdGVybXM6IHsgZmllbGQ6ICdoZWFsdGhfc3RhdHVzJywgc2l6ZTogMTAgfSB9LFxuICAgICAgICAgICAgYnlfcmlzazogeyB0ZXJtczogeyBmaWVsZDogJ3Jpc2tfc2NvcmUnLCBzaXplOiAxNSB9IH0sXG4gICAgICAgICAgfSxcbiAgICAgICAgfSxcbiAgICAgIH0pO1xuXG4gICAgICBsZXQgaW5jaWRlbnRzQ291bnQgPSAwO1xuICAgICAgbGV0IGFsZXJ0c0NvdW50ID0gMDtcbiAgICAgIGxldCB2dWxuQ291bnQgPSAwO1xuICAgICAgbGV0IGxpbmtlZEFnZW50cyA9IDA7XG4gICAgICBsZXQgc3RhbGVDb3VudCA9IDA7XG4gICAgICB0cnkge1xuICAgICAgICBjb25zdCBbaWMsIGFjLCB2YywgaWRSZXMsIHN0YWxlUmVzXSA9IGF3YWl0IFByb21pc2UuYWxsKFtcbiAgICAgICAgICBjbGllbnQuY291bnQoeyBpbmRleDogREVGRU5ERVJfSU5DSURFTlRTX0lOREVYLCBpZ25vcmVfdW5hdmFpbGFibGU6IHRydWUgfSksXG4gICAgICAgICAgY2xpZW50LmNvdW50KHsgaW5kZXg6IERFRkVOREVSX0FMRVJUU19JTkRFWCwgaWdub3JlX3VuYXZhaWxhYmxlOiB0cnVlIH0pLFxuICAgICAgICAgIGNsaWVudC5jb3VudCh7IGluZGV4OiBERUZFTkRFUl9WVUxORVJBQklMSVRJRVNfSU5ERVgsIGlnbm9yZV91bmF2YWlsYWJsZTogdHJ1ZSB9KSxcbiAgICAgICAgICBjbGllbnQuY291bnQoeyBpbmRleDogREVGRU5ERVJfTUFDSElORV9JREVOVElUWV9JTkRFWCwgaWdub3JlX3VuYXZhaWxhYmxlOiB0cnVlIH0pLFxuICAgICAgICAgIGNsaWVudC5zZWFyY2goe1xuICAgICAgICAgICAgaW5kZXg6IERFRkVOREVSX01BQ0hJTkVTX0lOREVYLFxuICAgICAgICAgICAgaWdub3JlX3VuYXZhaWxhYmxlOiB0cnVlLFxuICAgICAgICAgICAgYm9keToge1xuICAgICAgICAgICAgICBzaXplOiAwLFxuICAgICAgICAgICAgICBxdWVyeToge1xuICAgICAgICAgICAgICAgIGJvb2w6IHtcbiAgICAgICAgICAgICAgICAgIGZpbHRlcjogW3sgcmFuZ2U6IHsgbGFzdF9zZWVuOiB7IGx0OiBzdGFsZURhdGUgfSB9IH1dLFxuICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgIHRyYWNrX3RvdGFsX2hpdHM6IHRydWUsXG4gICAgICAgICAgICB9LFxuICAgICAgICAgIH0pLFxuICAgICAgICBdKTtcbiAgICAgICAgaW5jaWRlbnRzQ291bnQgPSAoaWMuYm9keSBhcyBhbnkpPy5jb3VudCA/PyAwO1xuICAgICAgICBhbGVydHNDb3VudCA9IChhYy5ib2R5IGFzIGFueSk/LmNvdW50ID8/IDA7XG4gICAgICAgIHZ1bG5Db3VudCA9ICh2Yy5ib2R5IGFzIGFueSk/LmNvdW50ID8/IDA7XG4gICAgICAgIGxpbmtlZEFnZW50cyA9IChpZFJlcy5ib2R5IGFzIGFueSk/LmNvdW50ID8/IDA7XG4gICAgICAgIHN0YWxlQ291bnQgPVxuICAgICAgICAgIChzdGFsZVJlcy5ib2R5IGFzIGFueSk/LmhpdHM/LnRvdGFsPy52YWx1ZSA/P1xuICAgICAgICAgIChzdGFsZVJlcy5ib2R5IGFzIGFueSk/LmhpdHM/LnRvdGFsID8/XG4gICAgICAgICAgMDtcbiAgICAgIH0gY2F0Y2gge1xuICAgICAgICAvKiBvcHRpb25hbCBpbmRpY2VzICovXG4gICAgICB9XG5cbiAgICAgIGNvbnN0IGhpdHNCb2R5ID0gKG1hY2hpbmVzUmVzLmJvZHkgYXMgYW55KT8uaGl0cyA/PyB7fTtcbiAgICAgIGNvbnN0IGFnZ3MgPSAobWFjaGluZXNSZXMuYm9keSBhcyBhbnkpPy5hZ2dyZWdhdGlvbnMgPz8ge307XG4gICAgICBjb25zdCByZWNlbnRfbWFjaGluZXMgPSAoaGl0c0JvZHkuaGl0cyA/PyBbXSkubWFwKChoOiBhbnkpID0+IGguX3NvdXJjZSkuZmlsdGVyKEJvb2xlYW4pO1xuICAgICAgY29uc3QgdG90YWxNYWNoaW5lcyA9XG4gICAgICAgIHR5cGVvZiBoaXRzQm9keS50b3RhbCA9PT0gJ29iamVjdCdcbiAgICAgICAgICA/IGhpdHNCb2R5LnRvdGFsPy52YWx1ZSA/PyAwXG4gICAgICAgICAgOiBoaXRzQm9keS50b3RhbCA/PyByZWNlbnRfbWFjaGluZXMubGVuZ3RoO1xuXG4gICAgICBsZXQgYnlPc0J1Y2tldHMgPSBhZ2dzLmJ5X29zPy5idWNrZXRzID8/IFtdO1xuICAgICAgbGV0IGJ5RXhwb3N1cmVCdWNrZXRzID0gYWdncy5ieV9leHBvc3VyZT8uYnVja2V0cyA/PyBbXTtcbiAgICAgIGxldCBieUhlYWx0aEJ1Y2tldHMgPSBhZ2dzLmJ5X2hlYWx0aD8uYnVja2V0cyA/PyBbXTtcbiAgICAgIGxldCBieVJpc2tCdWNrZXRzID0gYWdncy5ieV9yaXNrPy5idWNrZXRzID8/IFtdO1xuICAgICAgbGV0IHJlY2VudExpc3QgPSByZWNlbnRfbWFjaGluZXM7XG4gICAgICBsZXQgdG90YWwgPSB0b3RhbE1hY2hpbmVzO1xuICAgICAgbGV0IGRhdGFTb3VyY2U6ICdpbmRleCcgfCAnbWRlJyA9ICdpbmRleCc7XG5cbiAgICAgIGNvbnN0IG1jZmcgPSBnZXRNZGVDb25maWcoKTtcbiAgICAgIGlmICh0b3RhbCA9PT0gMCAmJiBtY2ZnKSB7XG4gICAgICAgIHRyeSB7XG4gICAgICAgICAgY29uc3QgcmF3ID0gYXdhaXQgZmV0Y2hBbGxNYWNoaW5lc0xpbWl0ZWQobWNmZywgMTApO1xuICAgICAgICAgIGNvbnN0IHRpZCA9IG1jZmcudGVuYW50SWQ7XG4gICAgICAgICAgY29uc3Qgbm9ybWFsaXplZCA9IHJhdy5tYXAoKG0pID0+XG4gICAgICAgICAgICBub3JtYWxpemVNZGVNYWNoaW5lKG0gYXMgUmVjb3JkPHN0cmluZywgdW5rbm93bj4sIHRpZClcbiAgICAgICAgICApO1xuICAgICAgICAgIGlmIChub3JtYWxpemVkLmxlbmd0aCA+IDApIHtcbiAgICAgICAgICAgIGRhdGFTb3VyY2UgPSAnbWRlJztcbiAgICAgICAgICAgIHRvdGFsID0gbm9ybWFsaXplZC5sZW5ndGg7XG4gICAgICAgICAgICByZWNlbnRMaXN0ID0gbm9ybWFsaXplZFxuICAgICAgICAgICAgICAuc2xpY2UoKVxuICAgICAgICAgICAgICAuc29ydCgoYSwgYikgPT4ge1xuICAgICAgICAgICAgICAgIGNvbnN0IHRhID0gYS5sYXN0X3NlZW4gPyBuZXcgRGF0ZShTdHJpbmcoYS5sYXN0X3NlZW4pKS5nZXRUaW1lKCkgOiAwO1xuICAgICAgICAgICAgICAgIGNvbnN0IHRiID0gYi5sYXN0X3NlZW4gPyBuZXcgRGF0ZShTdHJpbmcoYi5sYXN0X3NlZW4pKS5nZXRUaW1lKCkgOiAwO1xuICAgICAgICAgICAgICAgIHJldHVybiB0YiAtIHRhO1xuICAgICAgICAgICAgICB9KVxuICAgICAgICAgICAgICAuc2xpY2UoMCwgMTApO1xuICAgICAgICAgICAgY29uc3Qgb3NNYXA6IFJlY29yZDxzdHJpbmcsIG51bWJlcj4gPSB7fTtcbiAgICAgICAgICAgIGNvbnN0IGV4TWFwOiBSZWNvcmQ8c3RyaW5nLCBudW1iZXI+ID0ge307XG4gICAgICAgICAgICBjb25zdCBoZWFsdGhNYXA6IFJlY29yZDxzdHJpbmcsIG51bWJlcj4gPSB7fTtcbiAgICAgICAgICAgIGNvbnN0IHJpc2tNYXA6IFJlY29yZDxzdHJpbmcsIG51bWJlcj4gPSB7fTtcbiAgICAgICAgICAgIG5vcm1hbGl6ZWQuZm9yRWFjaCgocikgPT4ge1xuICAgICAgICAgICAgICBjb25zdCBvcyA9IFN0cmluZyhyLm9zX3BsYXRmb3JtIHx8ICdVbmtub3duJyk7XG4gICAgICAgICAgICAgIG9zTWFwW29zXSA9IChvc01hcFtvc10gfHwgMCkgKyAxO1xuICAgICAgICAgICAgICBjb25zdCBleCA9IFN0cmluZyhyLmV4cG9zdXJlX2xldmVsIHx8ICd1bmtub3duJyk7XG4gICAgICAgICAgICAgIGV4TWFwW2V4XSA9IChleE1hcFtleF0gfHwgMCkgKyAxO1xuICAgICAgICAgICAgICBjb25zdCBocyA9IFN0cmluZyhyLmhlYWx0aF9zdGF0dXMgfHwgJ3Vua25vd24nKTtcbiAgICAgICAgICAgICAgaGVhbHRoTWFwW2hzXSA9IChoZWFsdGhNYXBbaHNdIHx8IDApICsgMTtcbiAgICAgICAgICAgICAgY29uc3QgcnMgPSBTdHJpbmcoci5yaXNrX3Njb3JlIHx8ICd1bmtub3duJyk7XG4gICAgICAgICAgICAgIHJpc2tNYXBbcnNdID0gKHJpc2tNYXBbcnNdIHx8IDApICsgMTtcbiAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgYnlPc0J1Y2tldHMgPSBPYmplY3QuZW50cmllcyhvc01hcCkubWFwKChba2V5LCBkb2NfY291bnRdKSA9PiAoeyBrZXksIGRvY19jb3VudCB9KSk7XG4gICAgICAgICAgICBieUV4cG9zdXJlQnVja2V0cyA9IE9iamVjdC5lbnRyaWVzKGV4TWFwKS5tYXAoKFtrZXksIGRvY19jb3VudF0pID0+ICh7IGtleSwgZG9jX2NvdW50IH0pKTtcbiAgICAgICAgICAgIGJ5SGVhbHRoQnVja2V0cyA9IE9iamVjdC5lbnRyaWVzKGhlYWx0aE1hcCkubWFwKChba2V5LCBkb2NfY291bnRdKSA9PiAoe1xuICAgICAgICAgICAgICBrZXksXG4gICAgICAgICAgICAgIGRvY19jb3VudCxcbiAgICAgICAgICAgIH0pKTtcbiAgICAgICAgICAgIGJ5Umlza0J1Y2tldHMgPSBPYmplY3QuZW50cmllcyhyaXNrTWFwKS5tYXAoKFtrZXksIGRvY19jb3VudF0pID0+ICh7XG4gICAgICAgICAgICAgIGtleSxcbiAgICAgICAgICAgICAgZG9jX2NvdW50LFxuICAgICAgICAgICAgfSkpO1xuICAgICAgICAgICAgc3RhbGVDb3VudCA9IG5vcm1hbGl6ZWQuZmlsdGVyKFxuICAgICAgICAgICAgICAocikgPT4gIXIubGFzdF9zZWVuIHx8IG5ldyBEYXRlKFN0cmluZyhyLmxhc3Rfc2VlbikpIDwgbmV3IERhdGUoc3RhbGVEYXRlKVxuICAgICAgICAgICAgKS5sZW5ndGg7XG4gICAgICAgICAgfVxuICAgICAgICB9IGNhdGNoIHtcbiAgICAgICAgICAvKiBrZWVwIGluZGV4IGVtcHR5IHN0YXRlICovXG4gICAgICAgIH1cbiAgICAgIH1cblxuICAgICAgbGV0IGxpdmVJbmNpZGVudHNDb3VudDogbnVtYmVyIHwgbnVsbCA9IG51bGw7XG4gICAgICBsZXQgbGl2ZUFsZXJ0c0NvdW50OiBudW1iZXIgfCBudWxsID0gbnVsbDtcbiAgICAgIGxldCBncmFwaEVycm9yOiBzdHJpbmcgfCBudWxsID0gbnVsbDtcbiAgICAgIGNvbnN0IGdjZmcgPSBnZXRHcmFwaFNlY3VyaXR5Q29uZmlnKCk7XG4gICAgICBpZiAoZ2NmZykge1xuICAgICAgICB0cnkge1xuICAgICAgICAgIGxpdmVJbmNpZGVudHNDb3VudCA9IGF3YWl0IGNvdW50U2VjdXJpdHlDb2xsZWN0aW9uKGdjZmcsICdpbmNpZGVudHMnKTtcbiAgICAgICAgfSBjYXRjaCAoZSkge1xuICAgICAgICAgIGdyYXBoRXJyb3IgPSBtYXBHcmFwaEVycihlKS5ib2R5O1xuICAgICAgICAgIGxpdmVJbmNpZGVudHNDb3VudCA9IG51bGw7XG4gICAgICAgIH1cbiAgICAgICAgdHJ5IHtcbiAgICAgICAgICBsaXZlQWxlcnRzQ291bnQgPSBhd2FpdCBjb3VudFNlY3VyaXR5Q29sbGVjdGlvbihnY2ZnLCAnYWxlcnRzX3YyJyk7XG4gICAgICAgIH0gY2F0Y2ggKGUpIHtcbiAgICAgICAgICBpZiAoIWdyYXBoRXJyb3IpIGdyYXBoRXJyb3IgPSBtYXBHcmFwaEVycihlKS5ib2R5O1xuICAgICAgICAgIGxpdmVBbGVydHNDb3VudCA9IG51bGw7XG4gICAgICAgIH1cbiAgICAgIH1cblxuICAgICAgcmV0dXJuIHJlcy5vayh7XG4gICAgICAgIGJvZHk6IHtcbiAgICAgICAgICB0b3RhbF9tYWNoaW5lczogdG90YWwsXG4gICAgICAgICAgYnlfb3M6IGJ5T3NCdWNrZXRzLFxuICAgICAgICAgIGJ5X2V4cG9zdXJlOiBieUV4cG9zdXJlQnVja2V0cyxcbiAgICAgICAgICBieV9oZWFsdGg6IGJ5SGVhbHRoQnVja2V0cyxcbiAgICAgICAgICBieV9yaXNrOiBieVJpc2tCdWNrZXRzLFxuICAgICAgICAgIHJlY2VudF9tYWNoaW5lczogcmVjZW50TGlzdCxcbiAgICAgICAgICBpbmNpZGVudHNfaW5kZXhfY291bnQ6IGluY2lkZW50c0NvdW50LFxuICAgICAgICAgIGFsZXJ0c19pbmRleF9jb3VudDogYWxlcnRzQ291bnQsXG4gICAgICAgICAgdnVsbmVyYWJpbGl0aWVzX2luZGV4X2NvdW50OiB2dWxuQ291bnQsXG4gICAgICAgICAgbGlua2VkX2FnZW50c19jb3VudDogbGlua2VkQWdlbnRzLFxuICAgICAgICAgIHN0YWxlX21hY2hpbmVzX2NvdW50OiBzdGFsZUNvdW50LFxuICAgICAgICAgIGdyYXBoX2luY2lkZW50c19saXZlX2NvdW50OiBsaXZlSW5jaWRlbnRzQ291bnQsXG4gICAgICAgICAgZ3JhcGhfYWxlcnRzX2xpdmVfY291bnQ6IGxpdmVBbGVydHNDb3VudCxcbiAgICAgICAgICBncmFwaF9lcnJvcl9oaW50OiBncmFwaEVycm9yLFxuICAgICAgICAgIGRhdGFfc291cmNlOiBkYXRhU291cmNlLFxuICAgICAgICB9LFxuICAgICAgfSk7XG4gICAgfSBjYXRjaCAoZXJyOiBhbnkpIHtcbiAgICAgIHJldHVybiByZXMuY3VzdG9tRXJyb3Ioe1xuICAgICAgICBzdGF0dXNDb2RlOiBlcnIuc3RhdHVzQ29kZSA/PyA1MDAsXG4gICAgICAgIGJvZHk6IGVyci5tZXNzYWdlID8/IFN0cmluZyhlcnIpLFxuICAgICAgfSk7XG4gICAgfVxuICB9KTtcblxuICByb3V0ZXIuZ2V0KFxuICAgIHtcbiAgICAgIHBhdGg6ICcvYXBpL2RlZmVuZGVyX3BsdWdpbi92dWxuZXJhYmlsaXRpZXMnLFxuICAgICAgdmFsaWRhdGU6IHtcbiAgICAgICAgcXVlcnk6IHNjaGVtYS5vYmplY3Qoe1xuICAgICAgICAgIHNpemU6IHNjaGVtYS5tYXliZShzY2hlbWEubnVtYmVyKCkpLFxuICAgICAgICAgIGZyb206IHNjaGVtYS5tYXliZShzY2hlbWEubnVtYmVyKCkpLFxuICAgICAgICAgIHNvdXJjZTogc2NoZW1hLm1heWJlKHNjaGVtYS5zdHJpbmcoKSksXG4gICAgICAgIH0pLFxuICAgICAgfSxcbiAgICB9LFxuICAgIGFzeW5jIChjb250ZXh0LCByZXEsIHJlcykgPT4ge1xuICAgICAgY29uc3QgcSA9IHJlcS5xdWVyeSBhcyB7IHNpemU/OiBudW1iZXI7IGZyb20/OiBudW1iZXI7IHNvdXJjZT86IHN0cmluZyB9O1xuICAgICAgaWYgKHEuc291cmNlID09PSAnbWRlJykge1xuICAgICAgICBjb25zdCBtY2ZnID0gZ2V0TWRlQ29uZmlnKCk7XG4gICAgICAgIGlmICghbWNmZykgcmV0dXJuIHJlcy5jdXN0b21FcnJvcih7IHN0YXR1c0NvZGU6IDUwMywgYm9keTogJ01ERSBub3QgY29uZmlndXJlZC4nIH0pO1xuICAgICAgICB0cnkge1xuICAgICAgICAgIGNvbnN0IGRhdGEgPSAoYXdhaXQgbGlzdE9yZ1Z1bG5lcmFiaWxpdGllcyhtY2ZnLCBxLnNpemUgPz8gMjAwKSkgYXMge1xuICAgICAgICAgICAgdmFsdWU/OiB1bmtub3duW107XG4gICAgICAgICAgfTtcbiAgICAgICAgICBjb25zdCByb3dzID0gZGF0YT8udmFsdWUgPz8gW107XG4gICAgICAgICAgY29uc3QgZnJvbSA9IHEuZnJvbSA/PyAwO1xuICAgICAgICAgIGNvbnN0IHNpemUgPSBxLnNpemUgPz8gNTA7XG4gICAgICAgICAgY29uc3Qgc2xpY2UgPSByb3dzLnNsaWNlKGZyb20sIGZyb20gKyBzaXplKTtcbiAgICAgICAgICBjb25zdCBoaXRzID0gc2xpY2UubWFwKChyb3c6IGFueSwgaTogbnVtYmVyKSA9PiAoe1xuICAgICAgICAgICAgX2lkOiBTdHJpbmcocm93LmlkID8/IHJvdy5jdmVJZCA/PyBpKSxcbiAgICAgICAgICAgIF9zb3VyY2U6IHR5cGVvZiByb3cgPT09ICdvYmplY3QnID8gcm93IDogeyByYXc6IHJvdyB9LFxuICAgICAgICAgIH0pKTtcbiAgICAgICAgICByZXR1cm4gcmVzLm9rKHtcbiAgICAgICAgICAgIGJvZHk6IHtcbiAgICAgICAgICAgICAgaGl0cyxcbiAgICAgICAgICAgICAgdG90YWw6IHsgdmFsdWU6IHJvd3MubGVuZ3RoLCByZWxhdGlvbjogJ2VxJyB9LFxuICAgICAgICAgICAgICBzb3VyY2U6ICdtZGUnLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICB9KTtcbiAgICAgICAgfSBjYXRjaCAoZXJyOiBhbnkpIHtcbiAgICAgICAgICByZXR1cm4gcmVzLmN1c3RvbUVycm9yKHtcbiAgICAgICAgICAgIHN0YXR1c0NvZGU6IG1kZUVycm9yU3RhdHVzKGVyciksXG4gICAgICAgICAgICBib2R5OiBlcnI/Lm1lc3NhZ2UgPz8gU3RyaW5nKGVyciksXG4gICAgICAgICAgfSk7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICAgIHRyeSB7XG4gICAgICAgIGNvbnN0IGNsaWVudCA9IGdldENsaWVudChjb250ZXh0KTtcbiAgICAgICAgY29uc3QgeyBzaXplID0gNTAsIGZyb20gPSAwIH0gPSBxO1xuICAgICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGNsaWVudC5zZWFyY2goe1xuICAgICAgICAgIGluZGV4OiBERUZFTkRFUl9WVUxORVJBQklMSVRJRVNfSU5ERVgsXG4gICAgICAgICAgaWdub3JlX3VuYXZhaWxhYmxlOiB0cnVlLFxuICAgICAgICAgIGJvZHk6IHtcbiAgICAgICAgICAgIHNpemUsXG4gICAgICAgICAgICBmcm9tLFxuICAgICAgICAgICAgc29ydDogW3sgc3luY190czogeyBvcmRlcjogJ2Rlc2MnIH0gfV0sXG4gICAgICAgICAgICBxdWVyeTogeyBtYXRjaF9hbGw6IHt9IH0sXG4gICAgICAgICAgfSxcbiAgICAgICAgfSk7XG4gICAgICAgIGNvbnN0IGhpdHMgPSAocmVzcG9uc2UuYm9keSBhcyBhbnkpPy5oaXRzID8/IHt9O1xuICAgICAgICByZXR1cm4gcmVzLm9rKHsgYm9keTogeyBoaXRzOiBoaXRzLmhpdHMgPz8gW10sIHRvdGFsOiBoaXRzLnRvdGFsLCBzb3VyY2U6ICdpbmRleCcgfSB9KTtcbiAgICAgIH0gY2F0Y2ggKGVycjogYW55KSB7XG4gICAgICAgIHJldHVybiByZXMuY3VzdG9tRXJyb3Ioe1xuICAgICAgICAgIHN0YXR1c0NvZGU6IGVyci5zdGF0dXNDb2RlID8/IDUwMCxcbiAgICAgICAgICBib2R5OiBlcnIubWVzc2FnZSA/PyBTdHJpbmcoZXJyKSxcbiAgICAgICAgfSk7XG4gICAgICB9XG4gICAgfVxuICApO1xuXG4gIHJvdXRlci5nZXQoXG4gICAge1xuICAgICAgcGF0aDogJy9hcGkvZGVmZW5kZXJfcGx1Z2luL2luY2lkZW50cy9saXZlJyxcbiAgICAgIHZhbGlkYXRlOiB7XG4gICAgICAgIHF1ZXJ5OiBzY2hlbWEub2JqZWN0KHtcbiAgICAgICAgICB0b3A6IHNjaGVtYS5tYXliZShzY2hlbWEubnVtYmVyKCkpLFxuICAgICAgICB9KSxcbiAgICAgIH0sXG4gICAgfSxcbiAgICBhc3luYyAoX2NvbnRleHQsIHJlcSwgcmVzKSA9PiB7XG4gICAgICBjb25zdCBjb25maWcgPSBnZXRHcmFwaFNlY3VyaXR5Q29uZmlnKCk7XG4gICAgICBpZiAoIWNvbmZpZykge1xuICAgICAgICByZXR1cm4gcmVzLmN1c3RvbUVycm9yKHtcbiAgICAgICAgICBzdGF0dXNDb2RlOiA1MDMsXG4gICAgICAgICAgYm9keTogJ0dyYXBoIHNlY3VyaXR5IG5vdCBjb25maWd1cmVkLicsXG4gICAgICAgIH0pO1xuICAgICAgfVxuICAgICAgdHJ5IHtcbiAgICAgICAgY29uc3QgdG9wID0gKHJlcS5xdWVyeSBhcyB7IHRvcD86IG51bWJlciB9KS50b3AgPz8gMjU7XG4gICAgICAgIGNvbnN0IGRhdGEgPSBhd2FpdCBsaXN0SW5jaWRlbnRzKGNvbmZpZywgdG9wKTtcbiAgICAgICAgcmV0dXJuIHJlcy5vayh7IGJvZHk6IGRhdGEgfSk7XG4gICAgICB9IGNhdGNoIChlcnI6IHVua25vd24pIHtcbiAgICAgICAgY29uc3QgeyBzdGF0dXMsIGJvZHkgfSA9IG1hcEdyYXBoRXJyKGVycik7XG4gICAgICAgIHJldHVybiByZXMuY3VzdG9tRXJyb3IoeyBzdGF0dXNDb2RlOiBzdGF0dXMsIGJvZHkgfSk7XG4gICAgICB9XG4gICAgfVxuICApO1xuXG4gIHJvdXRlci5nZXQoXG4gICAge1xuICAgICAgcGF0aDogJy9hcGkvZGVmZW5kZXJfcGx1Z2luL2FsZXJ0cy9saXZlJyxcbiAgICAgIHZhbGlkYXRlOiB7XG4gICAgICAgIHF1ZXJ5OiBzY2hlbWEub2JqZWN0KHtcbiAgICAgICAgICB0b3A6IHNjaGVtYS5tYXliZShzY2hlbWEubnVtYmVyKCkpLFxuICAgICAgICB9KSxcbiAgICAgIH0sXG4gICAgfSxcbiAgICBhc3luYyAoX2NvbnRleHQsIHJlcSwgcmVzKSA9PiB7XG4gICAgICBjb25zdCBjb25maWcgPSBnZXRHcmFwaFNlY3VyaXR5Q29uZmlnKCk7XG4gICAgICBpZiAoIWNvbmZpZykge1xuICAgICAgICByZXR1cm4gcmVzLmN1c3RvbUVycm9yKHtcbiAgICAgICAgICBzdGF0dXNDb2RlOiA1MDMsXG4gICAgICAgICAgYm9keTogJ0dyYXBoIHNlY3VyaXR5IG5vdCBjb25maWd1cmVkLicsXG4gICAgICAgIH0pO1xuICAgICAgfVxuICAgICAgdHJ5IHtcbiAgICAgICAgY29uc3QgdG9wID0gKHJlcS5xdWVyeSBhcyB7IHRvcD86IG51bWJlciB9KS50b3AgPz8gMjU7XG4gICAgICAgIGNvbnN0IGRhdGEgPSBhd2FpdCBsaXN0QWxlcnRzVjIoY29uZmlnLCB0b3ApO1xuICAgICAgICByZXR1cm4gcmVzLm9rKHsgYm9keTogZGF0YSB9KTtcbiAgICAgIH0gY2F0Y2ggKGVycjogdW5rbm93bikge1xuICAgICAgICBjb25zdCB7IHN0YXR1cywgYm9keSB9ID0gbWFwR3JhcGhFcnIoZXJyKTtcbiAgICAgICAgcmV0dXJuIHJlcy5jdXN0b21FcnJvcih7IHN0YXR1c0NvZGU6IHN0YXR1cywgYm9keSB9KTtcbiAgICAgIH1cbiAgICB9XG4gICk7XG5cbiAgcm91dGVyLnBvc3QoXG4gICAge1xuICAgICAgcGF0aDogJy9hcGkvZGVmZW5kZXJfcGx1Z2luL2h1bnRpbmcnLFxuICAgICAgdmFsaWRhdGU6IHtcbiAgICAgICAgYm9keTogc2NoZW1hLm9iamVjdCh7XG4gICAgICAgICAgcXVlcnk6IHNjaGVtYS5zdHJpbmcoKSxcbiAgICAgICAgICB0aW1lc3Bhbjogc2NoZW1hLm1heWJlKHNjaGVtYS5zdHJpbmcoKSksXG4gICAgICAgIH0pLFxuICAgICAgfSxcbiAgICB9LFxuICAgIGFzeW5jIChfY29udGV4dCwgcmVxLCByZXMpID0+IHtcbiAgICAgIGNvbnN0IGNvbmZpZyA9IGdldEdyYXBoU2VjdXJpdHlDb25maWcoKTtcbiAgICAgIGlmICghY29uZmlnKSB7XG4gICAgICAgIHJldHVybiByZXMuY3VzdG9tRXJyb3Ioe1xuICAgICAgICAgIHN0YXR1c0NvZGU6IDUwMyxcbiAgICAgICAgICBib2R5OiAnR3JhcGggc2VjdXJpdHkgbm90IGNvbmZpZ3VyZWQuJyxcbiAgICAgICAgfSk7XG4gICAgICB9XG4gICAgICB0cnkge1xuICAgICAgICBjb25zdCB7IHF1ZXJ5LCB0aW1lc3BhbiB9ID0gcmVxLmJvZHkgYXMgeyBxdWVyeTogc3RyaW5nOyB0aW1lc3Bhbj86IHN0cmluZyB9O1xuICAgICAgICBjb25zdCBzdGFydGVkID0gRGF0ZS5ub3coKTtcbiAgICAgICAgY29uc3QgZGF0YSA9IGF3YWl0IHJ1bkh1bnRpbmdRdWVyeShjb25maWcsIHF1ZXJ5LCB0aW1lc3BhbiB8fCAnUDdEJyk7XG4gICAgICAgIGNvbnN0IHJvd0NvdW50ID0gQXJyYXkuaXNBcnJheSgoZGF0YSBhcyBhbnkpPy5yZXN1bHRzKVxuICAgICAgICAgID8gKGRhdGEgYXMgYW55KS5yZXN1bHRzLmxlbmd0aFxuICAgICAgICAgIDogMDtcbiAgICAgICAgcmV0dXJuIHJlcy5vayh7XG4gICAgICAgICAgYm9keToge1xuICAgICAgICAgICAgLi4uKChkYXRhIGFzIG9iamVjdCkgfHwge30pLFxuICAgICAgICAgICAgZXhlY3V0aW9uVGltZU1zOiBEYXRlLm5vdygpIC0gc3RhcnRlZCxcbiAgICAgICAgICAgIHJvd0NvdW50LFxuICAgICAgICAgIH0sXG4gICAgICAgIH0pO1xuICAgICAgfSBjYXRjaCAoZXJyOiB1bmtub3duKSB7XG4gICAgICAgIGNvbnN0IHsgc3RhdHVzLCBib2R5IH0gPSBtYXBHcmFwaEVycihlcnIpO1xuICAgICAgICByZXR1cm4gcmVzLmN1c3RvbUVycm9yKHsgc3RhdHVzQ29kZTogc3RhdHVzLCBib2R5IH0pO1xuICAgICAgfVxuICAgIH1cbiAgKTtcblxuICByb3V0ZXIuZ2V0KFxuICAgIHtcbiAgICAgIHBhdGg6ICcvYXBpL2RlZmVuZGVyX3BsdWdpbi9pbmRpY2F0b3JzL2xpdmUnLFxuICAgICAgdmFsaWRhdGU6IHtcbiAgICAgICAgcXVlcnk6IHNjaGVtYS5vYmplY3Qoe1xuICAgICAgICAgIHRvcDogc2NoZW1hLm1heWJlKHNjaGVtYS5udW1iZXIoKSksXG4gICAgICAgIH0pLFxuICAgICAgfSxcbiAgICB9LFxuICAgIGFzeW5jIChfY29udGV4dCwgcmVxLCByZXMpID0+IHtcbiAgICAgIGNvbnN0IGNvbmZpZyA9IGdldE1kZUNvbmZpZygpO1xuICAgICAgaWYgKCFjb25maWcpIHtcbiAgICAgICAgcmV0dXJuIHJlcy5jdXN0b21FcnJvcih7IHN0YXR1c0NvZGU6IDUwMywgYm9keTogJ01ERSBub3QgY29uZmlndXJlZC4nIH0pO1xuICAgICAgfVxuICAgICAgdHJ5IHtcbiAgICAgICAgY29uc3QgdG9wID0gKHJlcS5xdWVyeSBhcyB7IHRvcD86IG51bWJlciB9KS50b3AgPz8gMTAwO1xuICAgICAgICBjb25zdCBkYXRhID0gYXdhaXQgbGlzdEluZGljYXRvcnMoY29uZmlnLCB0b3ApO1xuICAgICAgICByZXR1cm4gcmVzLm9rKHsgYm9keTogZGF0YSB9KTtcbiAgICAgIH0gY2F0Y2ggKGVycjogYW55KSB7XG4gICAgICAgIHJldHVybiByZXMuY3VzdG9tRXJyb3IoeyBzdGF0dXNDb2RlOiBtZGVFcnJvclN0YXR1cyhlcnIpLCBib2R5OiBlcnI/Lm1lc3NhZ2UgPz8gU3RyaW5nKGVycikgfSk7XG4gICAgICB9XG4gICAgfVxuICApO1xuXG4gIHJvdXRlci5nZXQoXG4gICAge1xuICAgICAgcGF0aDogJy9hcGkvZGVmZW5kZXJfcGx1Z2luL2F1ZGl0LWxvZycsXG4gICAgICB2YWxpZGF0ZToge1xuICAgICAgICBxdWVyeTogc2NoZW1hLm9iamVjdCh7XG4gICAgICAgICAgc2l6ZTogc2NoZW1hLm1heWJlKHNjaGVtYS5udW1iZXIoKSksXG4gICAgICAgIH0pLFxuICAgICAgfSxcbiAgICB9LFxuICAgIGFzeW5jIChjb250ZXh0LCByZXEsIHJlcykgPT4ge1xuICAgICAgdHJ5IHtcbiAgICAgICAgY29uc3QgY2xpZW50ID0gZ2V0Q2xpZW50KGNvbnRleHQpO1xuICAgICAgICBjb25zdCBzaXplID0gKHJlcS5xdWVyeSBhcyB7IHNpemU/OiBudW1iZXIgfSkuc2l6ZSA/PyA1MDtcbiAgICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBjbGllbnQuc2VhcmNoKHtcbiAgICAgICAgICBpbmRleDogREVGRU5ERVJfQVVESVRfTE9HX0lOREVYLFxuICAgICAgICAgIGlnbm9yZV91bmF2YWlsYWJsZTogdHJ1ZSxcbiAgICAgICAgICBib2R5OiB7XG4gICAgICAgICAgICBzaXplLFxuICAgICAgICAgICAgc29ydDogW3sgdGltZXN0YW1wOiB7IG9yZGVyOiAnZGVzYycgfSB9XSxcbiAgICAgICAgICAgIHF1ZXJ5OiB7IG1hdGNoX2FsbDoge30gfSxcbiAgICAgICAgICB9LFxuICAgICAgICB9KTtcbiAgICAgICAgY29uc3QgaGl0cyA9IChyZXNwb25zZS5ib2R5IGFzIGFueSk/LmhpdHM/LmhpdHMgPz8gW107XG4gICAgICAgIHJldHVybiByZXMub2soeyBib2R5OiB7IGVudHJpZXM6IGhpdHMubWFwKChoOiBhbnkpID0+IGguX3NvdXJjZSkgfSB9KTtcbiAgICAgIH0gY2F0Y2ggKGVycjogYW55KSB7XG4gICAgICAgIHJldHVybiByZXMuY3VzdG9tRXJyb3Ioe1xuICAgICAgICAgIHN0YXR1c0NvZGU6IGVyci5zdGF0dXNDb2RlID8/IDUwMCxcbiAgICAgICAgICBib2R5OiBlcnIubWVzc2FnZSA/PyBTdHJpbmcoZXJyKSxcbiAgICAgICAgfSk7XG4gICAgICB9XG4gICAgfVxuICApO1xuXG4gIHJvdXRlci5wb3N0KFxuICAgIHtcbiAgICAgIHBhdGg6ICcvYXBpL2RlZmVuZGVyX3BsdWdpbi9hbGVydHNfZW5yaWNobWVudCcsXG4gICAgICB2YWxpZGF0ZToge1xuICAgICAgICBib2R5OiBzY2hlbWEub2JqZWN0KHtcbiAgICAgICAgICBzaXplOiBzY2hlbWEubWF5YmUoc2NoZW1hLm51bWJlcigpKSxcbiAgICAgICAgICBmcm9tOiBzY2hlbWEubWF5YmUoc2NoZW1hLm51bWJlcigpKSxcbiAgICAgICAgICB0aW1lX2Zyb206IHNjaGVtYS5tYXliZShzY2hlbWEuc3RyaW5nKCkpLFxuICAgICAgICAgIHRpbWVfdG86IHNjaGVtYS5tYXliZShzY2hlbWEuc3RyaW5nKCkpLFxuICAgICAgICAgIGRlZmVuZGVyX2NvcnJlbGF0ZWRfb25seTogc2NoZW1hLm1heWJlKHNjaGVtYS5ib29sZWFuKCkpLFxuICAgICAgICB9KSxcbiAgICAgIH0sXG4gICAgfSxcbiAgICBhc3luYyAoY29udGV4dCwgcmVxLCByZXMpID0+IHtcbiAgICAgIHRyeSB7XG4gICAgICAgIGNvbnN0IGNsaWVudCA9IGdldENsaWVudChjb250ZXh0KTtcbiAgICAgICAgY29uc3Qge1xuICAgICAgICAgIHNpemUgPSAyNSxcbiAgICAgICAgICBmcm9tID0gMCxcbiAgICAgICAgICB0aW1lX2Zyb20sXG4gICAgICAgICAgdGltZV90byxcbiAgICAgICAgICBkZWZlbmRlcl9jb3JyZWxhdGVkX29ubHkgPSB0cnVlLFxuICAgICAgICB9ID0gcmVxLmJvZHk7XG5cbiAgICAgICAgY29uc3Qgbm93ID0gbmV3IERhdGUoKTtcbiAgICAgICAgY29uc3QgZGVmYXVsdFRvID0gbm93LnRvSVNPU3RyaW5nKCk7XG4gICAgICAgIGNvbnN0IGRlZmF1bHRGcm9tID0gbmV3IERhdGUobm93LmdldFRpbWUoKSAtIDcgKiAyNCAqIDYwICogNjAgKiAxMDAwKS50b0lTT1N0cmluZygpO1xuICAgICAgICBjb25zdCB0aW1lR3RlID0gdGltZV9mcm9tIHx8IGRlZmF1bHRGcm9tO1xuICAgICAgICBjb25zdCB0aW1lTHRlID0gdGltZV90byB8fCBkZWZhdWx0VG87XG4gICAgICAgIGNvbnN0IHRpbWVSYW5nZUZpbHRlciA9IHsgcmFuZ2U6IHsgdGltZXN0YW1wOiB7IGd0ZTogdGltZUd0ZSwgbHRlOiB0aW1lTHRlIH0gfSB9O1xuXG4gICAgICAgIGxldCBhZ2VudElkc1RvUXVlcnk6IHN0cmluZ1tdIHwgbnVsbCA9IG51bGw7XG4gICAgICAgIGNvbnN0IGFnZW50VG9EZWZlbmRlcjogUmVjb3JkPHN0cmluZywgc3RyaW5nPiA9IHt9O1xuXG4gICAgICAgIGlmIChkZWZlbmRlcl9jb3JyZWxhdGVkX29ubHkpIHtcbiAgICAgICAgICBjb25zdCBpZGVudGl0eVJlcyA9IGF3YWl0IGNsaWVudC5zZWFyY2goe1xuICAgICAgICAgICAgaW5kZXg6IERFRkVOREVSX01BQ0hJTkVfSURFTlRJVFlfSU5ERVgsXG4gICAgICAgICAgICBpZ25vcmVfdW5hdmFpbGFibGU6IHRydWUsXG4gICAgICAgICAgICBib2R5OiB7XG4gICAgICAgICAgICAgIHNpemU6IDEwMDAsXG4gICAgICAgICAgICAgIF9zb3VyY2U6IFsnd2F6dWhfYWdlbnRfaWQnLCAnZGVmZW5kZXJfbWFjaGluZV9pZCcsICdjb21wdXRlcl9kbnNfbmFtZSddLFxuICAgICAgICAgICAgICBxdWVyeTogeyBtYXRjaF9hbGw6IHt9IH0sXG4gICAgICAgICAgICB9LFxuICAgICAgICAgIH0pO1xuICAgICAgICAgIGNvbnN0IGlkZW50aXR5SGl0cyA9IChpZGVudGl0eVJlcy5ib2R5IGFzIGFueSk/LmhpdHM/LmhpdHMgPz8gW107XG4gICAgICAgICAgYWdlbnRJZHNUb1F1ZXJ5ID0gaWRlbnRpdHlIaXRzXG4gICAgICAgICAgICAubWFwKChoOiBhbnkpID0+IGguX3NvdXJjZT8ud2F6dWhfYWdlbnRfaWQpXG4gICAgICAgICAgICAuZmlsdGVyKChpZDogc3RyaW5nKSA9PiBpZCAmJiBpZCAhPT0gJzAwMCcpO1xuICAgICAgICAgIGlmIChhZ2VudElkc1RvUXVlcnkubGVuZ3RoID09PSAwKSB7XG4gICAgICAgICAgICByZXR1cm4gcmVzLm9rKHtcbiAgICAgICAgICAgICAgYm9keToge1xuICAgICAgICAgICAgICAgIGFsZXJ0czogW10sXG4gICAgICAgICAgICAgICAgZW5yaWNobWVudHM6IHt9LFxuICAgICAgICAgICAgICAgIHRvdGFsOiAwLFxuICAgICAgICAgICAgICAgIGlkZW50aXR5X2NvdW50OiAwLFxuICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgfSk7XG4gICAgICAgICAgfVxuICAgICAgICAgIGlkZW50aXR5SGl0cy5mb3JFYWNoKChoOiBhbnkpID0+IHtcbiAgICAgICAgICAgIGNvbnN0IHMgPSBoLl9zb3VyY2U7XG4gICAgICAgICAgICBpZiAocz8ud2F6dWhfYWdlbnRfaWQpIGFnZW50VG9EZWZlbmRlcltzLndhenVoX2FnZW50X2lkXSA9IHMuZGVmZW5kZXJfbWFjaGluZV9pZDtcbiAgICAgICAgICB9KTtcbiAgICAgICAgfVxuXG4gICAgICAgIGNvbnN0IG11c3Q6IGFueVtdID0gW3RpbWVSYW5nZUZpbHRlcl07XG4gICAgICAgIG11c3QucHVzaCh7IGJvb2w6IHsgbXVzdF9ub3Q6IFt7IHRlcm06IHsgJ2FnZW50LmlkJzogJzAwMCcgfSB9XSB9IH0pO1xuICAgICAgICBpZiAoYWdlbnRJZHNUb1F1ZXJ5ICYmIGFnZW50SWRzVG9RdWVyeS5sZW5ndGggPiAwKSB7XG4gICAgICAgICAgbXVzdC5wdXNoKHsgdGVybXM6IHsgJ2FnZW50LmlkJzogYWdlbnRJZHNUb1F1ZXJ5IH0gfSk7XG4gICAgICAgIH1cblxuICAgICAgICBjb25zdCBhbGVydHNCb2R5ID0ge1xuICAgICAgICAgIGZyb20sXG4gICAgICAgICAgc2l6ZSxcbiAgICAgICAgICBzb3J0OiBbeyB0aW1lc3RhbXA6IHsgb3JkZXI6ICdkZXNjJyB9IH1dLFxuICAgICAgICAgIF9zb3VyY2U6IFsnYWdlbnQuaWQnLCAnYWdlbnQubmFtZScsICdydWxlLmRlc2NyaXB0aW9uJywgJ3J1bGUubGV2ZWwnLCAndGltZXN0YW1wJ10sXG4gICAgICAgICAgcXVlcnk6IHsgYm9vbDogeyBtdXN0IH0gfSxcbiAgICAgICAgfTtcblxuICAgICAgICBjb25zdCBbYWxlcnRzUmVzcG9uc2UsIGNvdW50UmVzcG9uc2VdID0gYXdhaXQgUHJvbWlzZS5hbGwoW1xuICAgICAgICAgIGNsaWVudC5zZWFyY2goe1xuICAgICAgICAgICAgaW5kZXg6IFdBWlVIX0FMRVJUU19QQVRURVJOLFxuICAgICAgICAgICAgaWdub3JlX3VuYXZhaWxhYmxlOiB0cnVlLFxuICAgICAgICAgICAgYm9keTogYWxlcnRzQm9keSxcbiAgICAgICAgICB9KSxcbiAgICAgICAgICBjbGllbnQuc2VhcmNoKHtcbiAgICAgICAgICAgIGluZGV4OiBXQVpVSF9BTEVSVFNfUEFUVEVSTixcbiAgICAgICAgICAgIGlnbm9yZV91bmF2YWlsYWJsZTogdHJ1ZSxcbiAgICAgICAgICAgIGJvZHk6IHtcbiAgICAgICAgICAgICAgc2l6ZTogMCxcbiAgICAgICAgICAgICAgcXVlcnk6IGFsZXJ0c0JvZHkucXVlcnksXG4gICAgICAgICAgICAgIHRyYWNrX3RvdGFsX2hpdHM6IHRydWUsXG4gICAgICAgICAgICB9LFxuICAgICAgICAgIH0pLFxuICAgICAgICBdKTtcblxuICAgICAgICBjb25zdCBhbGVydEhpdHMgPSAoYWxlcnRzUmVzcG9uc2UuYm9keSBhcyBhbnkpPy5oaXRzPy5oaXRzID8/IFtdO1xuICAgICAgICBjb25zdCB0b3RhbCA9XG4gICAgICAgICAgKGNvdW50UmVzcG9uc2UuYm9keSBhcyBhbnkpPy5oaXRzPy50b3RhbD8udmFsdWUgPz9cbiAgICAgICAgICAoY291bnRSZXNwb25zZS5ib2R5IGFzIGFueSk/LmhpdHM/LnRvdGFsID8/XG4gICAgICAgICAgYWxlcnRIaXRzLmxlbmd0aDtcblxuICAgICAgICBjb25zdCBlbnJpY2htZW50czogUmVjb3JkPHN0cmluZywgeyBkZWZlbmRlcl9tYWNoaW5lX2lkPzogc3RyaW5nIH0+ID0ge307XG4gICAgICAgIGFsZXJ0SGl0cy5mb3JFYWNoKChoOiBhbnkpID0+IHtcbiAgICAgICAgICBjb25zdCBhaWQgPSBoLl9zb3VyY2U/LmFnZW50Py5pZDtcbiAgICAgICAgICBpZiAoYWlkICYmIGFnZW50VG9EZWZlbmRlclthaWRdKSB7XG4gICAgICAgICAgICBlbnJpY2htZW50c1toLl9pZF0gPSB7IGRlZmVuZGVyX21hY2hpbmVfaWQ6IGFnZW50VG9EZWZlbmRlclthaWRdIH07XG4gICAgICAgICAgfVxuICAgICAgICB9KTtcblxuICAgICAgICByZXR1cm4gcmVzLm9rKHtcbiAgICAgICAgICBib2R5OiB7XG4gICAgICAgICAgICBhbGVydHM6IGFsZXJ0SGl0cy5tYXAoKGg6IGFueSkgPT4gKHtcbiAgICAgICAgICAgICAgaWQ6IGguX2lkLFxuICAgICAgICAgICAgICAuLi5oLl9zb3VyY2UsXG4gICAgICAgICAgICB9KSksXG4gICAgICAgICAgICBlbnJpY2htZW50cyxcbiAgICAgICAgICAgIHRvdGFsLFxuICAgICAgICAgICAgaWRlbnRpdHlfY291bnQ6IE9iamVjdC5rZXlzKGFnZW50VG9EZWZlbmRlcikubGVuZ3RoLFxuICAgICAgICAgIH0sXG4gICAgICAgIH0pO1xuICAgICAgfSBjYXRjaCAoZXJyOiBhbnkpIHtcbiAgICAgICAgcmV0dXJuIHJlcy5jdXN0b21FcnJvcih7XG4gICAgICAgICAgc3RhdHVzQ29kZTogZXJyLnN0YXR1c0NvZGUgPz8gNTAwLFxuICAgICAgICAgIGJvZHk6IGVyci5tZXNzYWdlID8/IFN0cmluZyhlcnIpLFxuICAgICAgICB9KTtcbiAgICAgIH1cbiAgICB9XG4gICk7XG59XG4iXSwibWFwcGluZ3MiOiI7Ozs7OztBQUtBLElBQUFBLGFBQUEsR0FBQUMsT0FBQTtBQUNBLElBQUFDLFVBQUEsR0FBQUQsT0FBQTtBQVNBLElBQUFFLFVBQUEsR0FBQUYsT0FBQTtBQWdCQSxJQUFBRyxvQkFBQSxHQUFBSCxPQUFBO0FBL0JBO0FBQ0E7QUFDQTs7QUFzQ0EsU0FBU0ksV0FBV0EsQ0FBQ0MsR0FBWSxFQUFvQztFQUNuRSxJQUFJQSxHQUFHLFlBQVlGLG9CQUFBLENBQUFHLGFBQWEsRUFBRTtJQUNoQyxPQUFPO01BQUVDLE1BQU0sRUFBRUYsR0FBRyxDQUFDRSxNQUFNLElBQUksR0FBRyxJQUFJRixHQUFHLENBQUNFLE1BQU0sR0FBRyxHQUFHLEdBQUdGLEdBQUcsQ0FBQ0UsTUFBTSxHQUFHLEdBQUc7TUFBRUMsSUFBSSxFQUFFSCxHQUFHLENBQUNJO0lBQVEsQ0FBQztFQUNoRztFQUNBLE9BQU87SUFBRUYsTUFBTSxFQUFFLEdBQUc7SUFBRUMsSUFBSSxFQUFFSCxHQUFHLFlBQVlLLEtBQUssR0FBR0wsR0FBRyxDQUFDSSxPQUFPLEdBQUdFLE1BQU0sQ0FBQ04sR0FBRztFQUFFLENBQUM7QUFDaEY7QUFFQSxTQUFTTyxtQkFBbUJBLENBQUNDLENBQTBCLEVBQUVDLFFBQWdCLEVBQUU7RUFDekUsT0FBTztJQUNMQyxTQUFTLEVBQUVELFFBQVE7SUFDbkJFLFVBQVUsRUFBRUgsQ0FBQyxDQUFDSSxFQUFFO0lBQ2hCQyxpQkFBaUIsRUFBRUwsQ0FBQyxDQUFDTSxlQUFlLElBQUksRUFBRTtJQUMxQ0MsV0FBVyxFQUFFUCxDQUFDLENBQUNRLFVBQVUsSUFBSSxFQUFFO0lBQy9CQyxVQUFVLEVBQUVULENBQUMsQ0FBQ1UsU0FBUyxJQUFJLEVBQUU7SUFDN0JDLFNBQVMsRUFBRVgsQ0FBQyxDQUFDWSxRQUFRLElBQUksSUFBSTtJQUM3QkMsVUFBVSxFQUFFYixDQUFDLENBQUNjLFNBQVMsSUFBSSxJQUFJO0lBQy9CQyxhQUFhLEVBQUVmLENBQUMsQ0FBQ2dCLFdBQVcsSUFBSSxFQUFFO0lBQ2xDQyxVQUFVLEVBQUVqQixDQUFDLENBQUNrQixTQUFTLElBQUksSUFBSSxHQUFHcEIsTUFBTSxDQUFDRSxDQUFDLENBQUNrQixTQUFTLENBQUMsR0FBRyxFQUFFO0lBQzFEQyxjQUFjLEVBQUVuQixDQUFDLENBQUNvQixhQUFhLElBQUksRUFBRTtJQUNyQ0MsaUJBQWlCLEVBQUVyQixDQUFDLENBQUNzQixnQkFBZ0IsSUFBSXRCLENBQUMsQ0FBQ3VCLGdCQUFnQixJQUFJLEVBQUU7SUFDakVDLGFBQWEsRUFBRXhCLENBQUMsQ0FBQ3lCLFlBQVksSUFBSSxFQUFFO0lBQ25DQyxnQkFBZ0IsRUFBRTFCLENBQUMsQ0FBQzJCLGVBQWUsSUFBSSxFQUFFO0lBQ3pDQyxlQUFlLEVBQUU1QixDQUFDLENBQUM2QixhQUFhLElBQUksRUFBRTtJQUN0Q0MsZUFBZSxFQUFFOUIsQ0FBQyxDQUFDK0IsYUFBYSxJQUFJO0VBQ3RDLENBQUM7QUFDSDtBQUVBLFNBQVNDLFNBQVNBLENBQUNDLE9BQVksRUFBRTtFQUMvQixPQUFPQSxPQUFPLENBQUNDLElBQUksQ0FBQ0MsVUFBVSxDQUFDQyxNQUFNLENBQUNDLGFBQWE7QUFDckQ7QUFFTyxTQUFTQyw0QkFBNEJBLENBQUNDLE1BQWUsRUFBRTtFQUM1REEsTUFBTSxDQUFDQyxHQUFHLENBQUM7SUFBRUMsSUFBSSxFQUFFO0lBQStCQyxRQUFRLEVBQUU7RUFBTSxDQUFDLEVBQUUsT0FBT0MsUUFBUSxFQUFFQyxJQUFJLEVBQUVDLEdBQUcsS0FBSztJQUNsRyxNQUFNQyxHQUFHLEdBQUcsQ0FBQyxDQUFDLElBQUF6RCxVQUFBLENBQUEwRCxZQUFZLEVBQUMsQ0FBQztJQUM1QixNQUFNQyxLQUFLLEdBQUcsQ0FBQyxDQUFDLElBQUExRCxvQkFBQSxDQUFBMkQsc0JBQXNCLEVBQUMsQ0FBQztJQUN4QyxPQUFPSixHQUFHLENBQUNLLEVBQUUsQ0FBQztNQUNadkQsSUFBSSxFQUFFO1FBQ0p1RCxFQUFFLEVBQUVKLEdBQUcsSUFBSUUsS0FBSztRQUNoQkcsY0FBYyxFQUFFTCxHQUFHO1FBQ25CTSx5QkFBeUIsRUFBRUosS0FBSztRQUNoQ0ssU0FBUyxFQUFFLElBQUlDLElBQUksQ0FBQyxDQUFDLENBQUNDLFdBQVcsQ0FBQztNQUNwQztJQUNGLENBQUMsQ0FBQztFQUNKLENBQUMsQ0FBQztFQUVGaEIsTUFBTSxDQUFDQyxHQUFHLENBQ1I7SUFDRUMsSUFBSSxFQUFFO0lBQ05DLFFBQVEsRUFBRTtNQUNSYyxLQUFLLEVBQUV0RSxhQUFBLENBQUF1RSxNQUFNLENBQUNDLE1BQU0sQ0FBQztRQUNuQkMsSUFBSSxFQUFFekUsYUFBQSxDQUFBdUUsTUFBTSxDQUFDRyxLQUFLLENBQUMxRSxhQUFBLENBQUF1RSxNQUFNLENBQUNJLE1BQU0sQ0FBQyxDQUFDLENBQUM7UUFDbkNDLElBQUksRUFBRTVFLGFBQUEsQ0FBQXVFLE1BQU0sQ0FBQ0csS0FBSyxDQUFDMUUsYUFBQSxDQUFBdUUsTUFBTSxDQUFDSSxNQUFNLENBQUMsQ0FBQyxDQUFDO1FBQ25DdEQsV0FBVyxFQUFFckIsYUFBQSxDQUFBdUUsTUFBTSxDQUFDRyxLQUFLLENBQUMxRSxhQUFBLENBQUF1RSxNQUFNLENBQUNNLE1BQU0sQ0FBQyxDQUFDLENBQUM7UUFDMUM1QyxjQUFjLEVBQUVqQyxhQUFBLENBQUF1RSxNQUFNLENBQUNHLEtBQUssQ0FBQzFFLGFBQUEsQ0FBQXVFLE1BQU0sQ0FBQ00sTUFBTSxDQUFDLENBQUMsQ0FBQztRQUM3Q0MsTUFBTSxFQUFFOUUsYUFBQSxDQUFBdUUsTUFBTSxDQUFDRyxLQUFLLENBQUMxRSxhQUFBLENBQUF1RSxNQUFNLENBQUNNLE1BQU0sQ0FBQyxDQUFDO01BQ3RDLENBQUM7SUFDSDtFQUNGLENBQUMsRUFDRCxPQUFPOUIsT0FBTyxFQUFFZ0MsR0FBRyxFQUFFcEIsR0FBRyxLQUFLO0lBQzNCLE1BQU1xQixDQUFDLEdBQUdELEdBQUcsQ0FBQ1QsS0FNYjtJQUNELElBQUlVLENBQUMsQ0FBQ0YsTUFBTSxLQUFLLE1BQU0sRUFBRTtNQUN2QixNQUFNRyxJQUFJLEdBQUcsSUFBQTlFLFVBQUEsQ0FBQTBELFlBQVksRUFBQyxDQUFDO01BQzNCLElBQUksQ0FBQ29CLElBQUksRUFBRTtRQUNULE9BQU90QixHQUFHLENBQUN1QixXQUFXLENBQUM7VUFBRUMsVUFBVSxFQUFFLEdBQUc7VUFBRTFFLElBQUksRUFBRTtRQUFzQixDQUFDLENBQUM7TUFDMUU7TUFDQSxJQUFJO1FBQUEsSUFBQTJFLE9BQUEsRUFBQUMsT0FBQTtRQUNGLE1BQU1DLEdBQUcsR0FBRyxNQUFNLElBQUFuRixVQUFBLENBQUFvRix1QkFBdUIsRUFBQ04sSUFBSSxFQUFFLEVBQUUsQ0FBQztRQUNuRCxNQUFNbEUsUUFBUSxHQUFHa0UsSUFBSSxDQUFDbEUsUUFBUTtRQUM5QixJQUFJeUUsSUFBSSxHQUFHRixHQUFHLENBQUNHLEdBQUcsQ0FBRTNFLENBQUMsSUFBS0QsbUJBQW1CLENBQUNDLENBQUMsRUFBNkJDLFFBQVEsQ0FBQyxDQUFDO1FBQ3RGLElBQUlpRSxDQUFDLENBQUMzRCxXQUFXLEVBQUU7VUFDakJtRSxJQUFJLEdBQUdBLElBQUksQ0FBQ0UsTUFBTSxDQUFFQyxDQUFDLElBQUsvRSxNQUFNLENBQUMrRSxDQUFDLENBQUN0RSxXQUFXLENBQUMsS0FBSzJELENBQUMsQ0FBQzNELFdBQVcsQ0FBQztRQUNwRTtRQUNBLElBQUkyRCxDQUFDLENBQUMvQyxjQUFjLEVBQUU7VUFDcEJ1RCxJQUFJLEdBQUdBLElBQUksQ0FBQ0UsTUFBTSxDQUFFQyxDQUFDLElBQUsvRSxNQUFNLENBQUMrRSxDQUFDLENBQUMxRCxjQUFjLENBQUMsS0FBSytDLENBQUMsQ0FBQy9DLGNBQWMsQ0FBQztRQUMxRTtRQUNBdUQsSUFBSSxDQUFDSSxJQUFJLENBQUMsQ0FBQ0MsQ0FBQyxFQUFFQyxDQUFDLEtBQUs7VUFDbEIsTUFBTUMsRUFBRSxHQUFHRixDQUFDLENBQUNwRSxTQUFTLEdBQUcsSUFBSTJDLElBQUksQ0FBQ3hELE1BQU0sQ0FBQ2lGLENBQUMsQ0FBQ3BFLFNBQVMsQ0FBQyxDQUFDLENBQUN1RSxPQUFPLENBQUMsQ0FBQyxHQUFHLENBQUM7VUFDcEUsTUFBTUMsRUFBRSxHQUFHSCxDQUFDLENBQUNyRSxTQUFTLEdBQUcsSUFBSTJDLElBQUksQ0FBQ3hELE1BQU0sQ0FBQ2tGLENBQUMsQ0FBQ3JFLFNBQVMsQ0FBQyxDQUFDLENBQUN1RSxPQUFPLENBQUMsQ0FBQyxHQUFHLENBQUM7VUFDcEUsT0FBT0MsRUFBRSxHQUFHRixFQUFFO1FBQ2hCLENBQUMsQ0FBQztRQUNGLE1BQU1uQixJQUFJLElBQUFRLE9BQUEsR0FBR0osQ0FBQyxDQUFDSixJQUFJLGNBQUFRLE9BQUEsY0FBQUEsT0FBQSxHQUFJLENBQUM7UUFDeEIsTUFBTVgsSUFBSSxJQUFBWSxPQUFBLEdBQUdMLENBQUMsQ0FBQ1AsSUFBSSxjQUFBWSxPQUFBLGNBQUFBLE9BQUEsR0FBSSxFQUFFO1FBQ3pCLE1BQU1hLEtBQUssR0FBR1YsSUFBSSxDQUFDVSxLQUFLLENBQUN0QixJQUFJLEVBQUVBLElBQUksR0FBR0gsSUFBSSxDQUFDO1FBQzNDLE1BQU0wQixJQUFJLEdBQUdELEtBQUssQ0FBQ1QsR0FBRyxDQUFFVyxHQUFHLEtBQU07VUFBRUMsT0FBTyxFQUFFRCxHQUFHO1VBQUVFLEdBQUcsRUFBRUYsR0FBRyxDQUFDbkY7UUFBVyxDQUFDLENBQUMsQ0FBQztRQUN4RSxPQUFPMEMsR0FBRyxDQUFDSyxFQUFFLENBQUM7VUFDWnZELElBQUksRUFBRTtZQUNKMEYsSUFBSTtZQUNKSSxLQUFLLEVBQUU7Y0FBRUMsS0FBSyxFQUFFaEIsSUFBSSxDQUFDaUIsTUFBTTtjQUFFQyxRQUFRLEVBQUU7WUFBSyxDQUFDO1lBQzdDNUIsTUFBTSxFQUFFO1VBQ1Y7UUFDRixDQUFDLENBQUM7TUFDSixDQUFDLENBQUMsT0FBT3hFLEdBQVEsRUFBRTtRQUFBLElBQUFxRyxZQUFBO1FBQ2pCLE9BQU9oRCxHQUFHLENBQUN1QixXQUFXLENBQUM7VUFDckJDLFVBQVUsRUFBRSxJQUFBaEYsVUFBQSxDQUFBeUcsY0FBYyxFQUFDdEcsR0FBRyxDQUFDO1VBQy9CRyxJQUFJLEdBQUFrRyxZQUFBLEdBQUVyRyxHQUFHLGFBQUhBLEdBQUcsdUJBQUhBLEdBQUcsQ0FBRUksT0FBTyxjQUFBaUcsWUFBQSxjQUFBQSxZQUFBLEdBQUkvRixNQUFNLENBQUNOLEdBQUc7UUFDbEMsQ0FBQyxDQUFDO01BQ0o7SUFDRjtJQUNBLElBQUk7TUFBQSxJQUFBdUcsS0FBQSxFQUFBQyxjQUFBLEVBQUFDLFVBQUE7TUFDRixNQUFNN0QsTUFBTSxHQUFHSixTQUFTLENBQUNDLE9BQU8sQ0FBQztNQUNqQyxNQUFNO1FBQUUwQixJQUFJLEdBQUcsRUFBRTtRQUFFRyxJQUFJLEdBQUcsQ0FBQztRQUFFdkQsV0FBVztRQUFFWTtNQUFlLENBQUMsR0FBRytDLENBQUM7TUFDOUQsTUFBTWdDLElBQVcsR0FBRyxFQUFFO01BQ3RCLElBQUkzRixXQUFXLEVBQUUyRixJQUFJLENBQUNDLElBQUksQ0FBQztRQUFFQyxJQUFJLEVBQUU7VUFBRTdGO1FBQVk7TUFBRSxDQUFDLENBQUM7TUFDckQsSUFBSVksY0FBYyxFQUFFK0UsSUFBSSxDQUFDQyxJQUFJLENBQUM7UUFBRUMsSUFBSSxFQUFFO1VBQUVqRjtRQUFlO01BQUUsQ0FBQyxDQUFDO01BQzNELE1BQU1rRixRQUFRLEdBQUcsTUFBTWpFLE1BQU0sQ0FBQ2tFLE1BQU0sQ0FBQztRQUNuQ0MsS0FBSyxFQUFFbkgsVUFBQSxDQUFBb0gsdUJBQXVCO1FBQzlCQyxrQkFBa0IsRUFBRSxJQUFJO1FBQ3hCOUcsSUFBSSxFQUFFO1VBQ0pnRSxJQUFJO1VBQ0pHLElBQUk7VUFDSmdCLElBQUksRUFBRSxDQUFDO1lBQUVuRSxTQUFTLEVBQUU7Y0FBRStGLEtBQUssRUFBRSxNQUFNO2NBQUVDLE9BQU8sRUFBRTtZQUFRO1VBQUUsQ0FBQyxFQUFFO1lBQUV0RyxpQkFBaUIsRUFBRTtVQUFNLENBQUMsQ0FBQztVQUN4Rm1ELEtBQUssRUFBRTBDLElBQUksQ0FBQ1AsTUFBTSxHQUFHO1lBQUVpQixJQUFJLEVBQUU7Y0FBRVY7WUFBSztVQUFFLENBQUMsR0FBRztZQUFFVyxTQUFTLEVBQUUsQ0FBQztVQUFFO1FBQzVEO01BQ0YsQ0FBQyxDQUFDO01BQ0YsTUFBTXhCLElBQUksSUFBQVUsS0FBQSxJQUFBQyxjQUFBLEdBQUlLLFFBQVEsQ0FBQzFHLElBQUksY0FBQXFHLGNBQUEsdUJBQWRBLGNBQUEsQ0FBd0JYLElBQUksY0FBQVUsS0FBQSxjQUFBQSxLQUFBLEdBQUksQ0FBQyxDQUFDO01BQy9DLE9BQU9sRCxHQUFHLENBQUNLLEVBQUUsQ0FBQztRQUFFdkQsSUFBSSxFQUFFO1VBQUUwRixJQUFJLEdBQUFZLFVBQUEsR0FBRVosSUFBSSxDQUFDQSxJQUFJLGNBQUFZLFVBQUEsY0FBQUEsVUFBQSxHQUFJLEVBQUU7VUFBRVIsS0FBSyxFQUFFSixJQUFJLENBQUNJLEtBQUs7VUFBRXpCLE1BQU0sRUFBRTtRQUFRO01BQUUsQ0FBQyxDQUFDO0lBQ3hGLENBQUMsQ0FBQyxPQUFPeEUsR0FBUSxFQUFFO01BQUEsSUFBQXNILGVBQUEsRUFBQUMsYUFBQTtNQUNqQixPQUFPbEUsR0FBRyxDQUFDdUIsV0FBVyxDQUFDO1FBQ3JCQyxVQUFVLEdBQUF5QyxlQUFBLEdBQUV0SCxHQUFHLENBQUM2RSxVQUFVLGNBQUF5QyxlQUFBLGNBQUFBLGVBQUEsR0FBSSxHQUFHO1FBQ2pDbkgsSUFBSSxHQUFBb0gsYUFBQSxHQUFFdkgsR0FBRyxDQUFDSSxPQUFPLGNBQUFtSCxhQUFBLGNBQUFBLGFBQUEsR0FBSWpILE1BQU0sQ0FBQ04sR0FBRztNQUNqQyxDQUFDLENBQUM7SUFDSjtFQUNGLENBQ0YsQ0FBQztFQUVEK0MsTUFBTSxDQUFDQyxHQUFHLENBQ1I7SUFDRUMsSUFBSSxFQUFFO0lBQ05DLFFBQVEsRUFBRTtNQUFFc0UsTUFBTSxFQUFFOUgsYUFBQSxDQUFBdUUsTUFBTSxDQUFDQyxNQUFNLENBQUM7UUFBRXRELEVBQUUsRUFBRWxCLGFBQUEsQ0FBQXVFLE1BQU0sQ0FBQ00sTUFBTSxDQUFDO01BQUUsQ0FBQztJQUFFO0VBQzdELENBQUMsRUFDRCxPQUFPcEIsUUFBUSxFQUFFQyxJQUFJLEVBQUVDLEdBQUcsS0FBSztJQUM3QixNQUFNb0UsTUFBTSxHQUFHLElBQUE1SCxVQUFBLENBQUEwRCxZQUFZLEVBQUMsQ0FBQztJQUM3QixJQUFJLENBQUNrRSxNQUFNLEVBQUU7TUFDWCxPQUFPcEUsR0FBRyxDQUFDdUIsV0FBVyxDQUFDO1FBQ3JCQyxVQUFVLEVBQUUsR0FBRztRQUNmMUUsSUFBSSxFQUFFO01BQ1IsQ0FBQyxDQUFDO0lBQ0o7SUFDQSxJQUFJO01BQ0YsTUFBTVMsRUFBRSxHQUFJd0MsSUFBSSxDQUFDb0UsTUFBTSxDQUFvQjVHLEVBQUU7TUFDN0MsTUFBTThHLElBQUksR0FBRyxNQUFNLElBQUE3SCxVQUFBLENBQUE4SCxVQUFVLEVBQUNGLE1BQU0sRUFBRTdHLEVBQUUsQ0FBQztNQUN6QyxPQUFPeUMsR0FBRyxDQUFDSyxFQUFFLENBQUM7UUFBRXZELElBQUksRUFBRXVIO01BQUssQ0FBQyxDQUFDO0lBQy9CLENBQUMsQ0FBQyxPQUFPMUgsR0FBUSxFQUFFO01BQUEsSUFBQTRILGFBQUE7TUFDakIsT0FBT3ZFLEdBQUcsQ0FBQ3VCLFdBQVcsQ0FBQztRQUNyQkMsVUFBVSxFQUFFLElBQUFoRixVQUFBLENBQUF5RyxjQUFjLEVBQUN0RyxHQUFHLENBQUM7UUFDL0JHLElBQUksR0FBQXlILGFBQUEsR0FBRTVILEdBQUcsYUFBSEEsR0FBRyx1QkFBSEEsR0FBRyxDQUFFSSxPQUFPLGNBQUF3SCxhQUFBLGNBQUFBLGFBQUEsR0FBSXRILE1BQU0sQ0FBQ04sR0FBRztNQUNsQyxDQUFDLENBQUM7SUFDSjtFQUNGLENBQ0YsQ0FBQztFQUVELE1BQU02SCxhQUFhLEdBQUdBLENBQUNDLFVBQWtCLEVBQUVDLEVBQTRDLEtBQUs7SUFDMUZoRixNQUFNLENBQUNDLEdBQUcsQ0FDUjtNQUNFQyxJQUFJLEVBQUcsd0NBQUE2RSxVQUEwQztNQUNqRDVFLFFBQVEsRUFBRTtRQUFFc0UsTUFBTSxFQUFFOUgsYUFBQSxDQUFBdUUsTUFBTSxDQUFDQyxNQUFNLENBQUM7VUFBRXRELEVBQUUsRUFBRWxCLGFBQUEsQ0FBQXVFLE1BQU0sQ0FBQ00sTUFBTSxDQUFDO1FBQUUsQ0FBQztNQUFFO0lBQzdELENBQUMsRUFDRCxPQUFPcEIsUUFBUSxFQUFFc0IsR0FBRyxFQUFFcEIsR0FBRyxLQUFLO01BQzVCLE1BQU1zQixJQUFJLEdBQUcsSUFBQTlFLFVBQUEsQ0FBQTBELFlBQVksRUFBQyxDQUFDO01BQzNCLElBQUksQ0FBQ29CLElBQUksRUFBRTtRQUNULE9BQU90QixHQUFHLENBQUN1QixXQUFXLENBQUM7VUFBRUMsVUFBVSxFQUFFLEdBQUc7VUFBRTFFLElBQUksRUFBRTtRQUFzQixDQUFDLENBQUM7TUFDMUU7TUFDQSxJQUFJO1FBQ0YsTUFBTVMsRUFBRSxHQUFJNkQsR0FBRyxDQUFDK0MsTUFBTSxDQUFvQjVHLEVBQUU7UUFDNUMsTUFBTThHLElBQUksR0FBRyxNQUFNSyxFQUFFLENBQUNwRCxJQUFJLEVBQUUvRCxFQUFFLENBQUM7UUFDL0IsT0FBT3lDLEdBQUcsQ0FBQ0ssRUFBRSxDQUFDO1VBQUV2RCxJQUFJLEVBQUV1SDtRQUFLLENBQUMsQ0FBQztNQUMvQixDQUFDLENBQUMsT0FBTzFILEdBQVEsRUFBRTtRQUFBLElBQUFnSSxhQUFBO1FBQ2pCLE9BQU8zRSxHQUFHLENBQUN1QixXQUFXLENBQUM7VUFBRUMsVUFBVSxFQUFFLElBQUFoRixVQUFBLENBQUF5RyxjQUFjLEVBQUN0RyxHQUFHLENBQUM7VUFBRUcsSUFBSSxHQUFBNkgsYUFBQSxHQUFFaEksR0FBRyxhQUFIQSxHQUFHLHVCQUFIQSxHQUFHLENBQUVJLE9BQU8sY0FBQTRILGFBQUEsY0FBQUEsYUFBQSxHQUFJMUgsTUFBTSxDQUFDTixHQUFHO1FBQUUsQ0FBQyxDQUFDO01BQ2hHO0lBQ0YsQ0FDRixDQUFDO0VBQ0gsQ0FBQztFQUVENkgsYUFBYSxDQUFDLGlCQUFpQixFQUFFaEksVUFBQSxDQUFBb0kseUJBQXlCLENBQUM7RUFDM0RKLGFBQWEsQ0FBQyxpQkFBaUIsRUFBRWhJLFVBQUEsQ0FBQXFJLHlCQUF5QixDQUFDO0VBQzNETCxhQUFhLENBQUMsUUFBUSxFQUFFaEksVUFBQSxDQUFBc0ksZ0JBQWdCLENBQUM7RUFDekNOLGFBQWEsQ0FBQyxZQUFZLEVBQUVoSSxVQUFBLENBQUF1SSxvQkFBb0IsQ0FBQztFQUNqRFAsYUFBYSxDQUFDLFVBQVUsRUFBRWhJLFVBQUEsQ0FBQXdJLGtCQUFrQixDQUFDO0VBRTdDdEYsTUFBTSxDQUFDQyxHQUFHLENBQ1I7SUFDRUMsSUFBSSxFQUFFO0lBQ05DLFFBQVEsRUFBRTtNQUFFYyxLQUFLLEVBQUV0RSxhQUFBLENBQUF1RSxNQUFNLENBQUNDLE1BQU0sQ0FBQztRQUFFb0UsR0FBRyxFQUFFNUksYUFBQSxDQUFBdUUsTUFBTSxDQUFDRyxLQUFLLENBQUMxRSxhQUFBLENBQUF1RSxNQUFNLENBQUNJLE1BQU0sQ0FBQyxDQUFDO01BQUUsQ0FBQztJQUFFO0VBQzNFLENBQUMsRUFDRCxPQUFPbEIsUUFBUSxFQUFFc0IsR0FBRyxFQUFFcEIsR0FBRyxLQUFLO0lBQzVCLE1BQU1zQixJQUFJLEdBQUcsSUFBQTlFLFVBQUEsQ0FBQTBELFlBQVksRUFBQyxDQUFDO0lBQzNCLElBQUksQ0FBQ29CLElBQUksRUFBRSxPQUFPdEIsR0FBRyxDQUFDdUIsV0FBVyxDQUFDO01BQUVDLFVBQVUsRUFBRSxHQUFHO01BQUUxRSxJQUFJLEVBQUU7SUFBc0IsQ0FBQyxDQUFDO0lBQ25GLElBQUk7TUFBQSxJQUFBb0ksSUFBQTtNQUNGLE1BQU1ELEdBQUcsSUFBQUMsSUFBQSxHQUFJOUQsR0FBRyxDQUFDVCxLQUFLLENBQXNCc0UsR0FBRyxjQUFBQyxJQUFBLGNBQUFBLElBQUEsR0FBSSxHQUFHO01BQ3RELE1BQU1iLElBQUksR0FBRyxNQUFNLElBQUE3SCxVQUFBLENBQUEySSxzQkFBc0IsRUFBQzdELElBQUksRUFBRTJELEdBQUcsQ0FBQztNQUNwRCxPQUFPakYsR0FBRyxDQUFDSyxFQUFFLENBQUM7UUFBRXZELElBQUksRUFBRXVIO01BQUssQ0FBQyxDQUFDO0lBQy9CLENBQUMsQ0FBQyxPQUFPMUgsR0FBUSxFQUFFO01BQUEsSUFBQXlJLGFBQUE7TUFDakIsT0FBT3BGLEdBQUcsQ0FBQ3VCLFdBQVcsQ0FBQztRQUFFQyxVQUFVLEVBQUUsSUFBQWhGLFVBQUEsQ0FBQXlHLGNBQWMsRUFBQ3RHLEdBQUcsQ0FBQztRQUFFRyxJQUFJLEdBQUFzSSxhQUFBLEdBQUV6SSxHQUFHLGFBQUhBLEdBQUcsdUJBQUhBLEdBQUcsQ0FBRUksT0FBTyxjQUFBcUksYUFBQSxjQUFBQSxhQUFBLEdBQUluSSxNQUFNLENBQUNOLEdBQUc7TUFBRSxDQUFDLENBQUM7SUFDaEc7RUFDRixDQUNGLENBQUM7RUFFRCtDLE1BQU0sQ0FBQ0MsR0FBRyxDQUNSO0lBQ0VDLElBQUksRUFBRTtJQUNOQyxRQUFRLEVBQUU7TUFBRWMsS0FBSyxFQUFFdEUsYUFBQSxDQUFBdUUsTUFBTSxDQUFDQyxNQUFNLENBQUM7UUFBRW9FLEdBQUcsRUFBRTVJLGFBQUEsQ0FBQXVFLE1BQU0sQ0FBQ0csS0FBSyxDQUFDMUUsYUFBQSxDQUFBdUUsTUFBTSxDQUFDSSxNQUFNLENBQUMsQ0FBQztNQUFFLENBQUM7SUFBRTtFQUMzRSxDQUFDLEVBQ0QsT0FBT2xCLFFBQVEsRUFBRXNCLEdBQUcsRUFBRXBCLEdBQUcsS0FBSztJQUM1QixNQUFNc0IsSUFBSSxHQUFHLElBQUE5RSxVQUFBLENBQUEwRCxZQUFZLEVBQUMsQ0FBQztJQUMzQixJQUFJLENBQUNvQixJQUFJLEVBQUUsT0FBT3RCLEdBQUcsQ0FBQ3VCLFdBQVcsQ0FBQztNQUFFQyxVQUFVLEVBQUUsR0FBRztNQUFFMUUsSUFBSSxFQUFFO0lBQXNCLENBQUMsQ0FBQztJQUNuRixJQUFJO01BQUEsSUFBQXVJLEtBQUE7TUFDRixNQUFNSixHQUFHLElBQUFJLEtBQUEsR0FBSWpFLEdBQUcsQ0FBQ1QsS0FBSyxDQUFzQnNFLEdBQUcsY0FBQUksS0FBQSxjQUFBQSxLQUFBLEdBQUksR0FBRztNQUN0RCxNQUFNaEIsSUFBSSxHQUFHLE1BQU0sSUFBQTdILFVBQUEsQ0FBQThJLGdCQUFnQixFQUFDaEUsSUFBSSxFQUFFMkQsR0FBRyxDQUFDO01BQzlDLE9BQU9qRixHQUFHLENBQUNLLEVBQUUsQ0FBQztRQUFFdkQsSUFBSSxFQUFFdUg7TUFBSyxDQUFDLENBQUM7SUFDL0IsQ0FBQyxDQUFDLE9BQU8xSCxHQUFRLEVBQUU7TUFBQSxJQUFBNEksYUFBQTtNQUNqQixPQUFPdkYsR0FBRyxDQUFDdUIsV0FBVyxDQUFDO1FBQUVDLFVBQVUsRUFBRSxJQUFBaEYsVUFBQSxDQUFBeUcsY0FBYyxFQUFDdEcsR0FBRyxDQUFDO1FBQUVHLElBQUksR0FBQXlJLGFBQUEsR0FBRTVJLEdBQUcsYUFBSEEsR0FBRyx1QkFBSEEsR0FBRyxDQUFFSSxPQUFPLGNBQUF3SSxhQUFBLGNBQUFBLGFBQUEsR0FBSXRJLE1BQU0sQ0FBQ04sR0FBRztNQUFFLENBQUMsQ0FBQztJQUNoRztFQUNGLENBQ0YsQ0FBQztFQUVEK0MsTUFBTSxDQUFDQyxHQUFHLENBQ1I7SUFDRUMsSUFBSSxFQUFFO0lBQ05DLFFBQVEsRUFBRTtNQUFFYyxLQUFLLEVBQUV0RSxhQUFBLENBQUF1RSxNQUFNLENBQUNDLE1BQU0sQ0FBQztRQUFFb0UsR0FBRyxFQUFFNUksYUFBQSxDQUFBdUUsTUFBTSxDQUFDRyxLQUFLLENBQUMxRSxhQUFBLENBQUF1RSxNQUFNLENBQUNJLE1BQU0sQ0FBQyxDQUFDO01BQUUsQ0FBQztJQUFFO0VBQzNFLENBQUMsRUFDRCxPQUFPbEIsUUFBUSxFQUFFc0IsR0FBRyxFQUFFcEIsR0FBRyxLQUFLO0lBQzVCLE1BQU1zQixJQUFJLEdBQUcsSUFBQTlFLFVBQUEsQ0FBQTBELFlBQVksRUFBQyxDQUFDO0lBQzNCLElBQUksQ0FBQ29CLElBQUksRUFBRSxPQUFPdEIsR0FBRyxDQUFDdUIsV0FBVyxDQUFDO01BQUVDLFVBQVUsRUFBRSxHQUFHO01BQUUxRSxJQUFJLEVBQUU7SUFBc0IsQ0FBQyxDQUFDO0lBQ25GLElBQUk7TUFBQSxJQUFBMEksS0FBQTtNQUNGLE1BQU1QLEdBQUcsSUFBQU8sS0FBQSxHQUFJcEUsR0FBRyxDQUFDVCxLQUFLLENBQXNCc0UsR0FBRyxjQUFBTyxLQUFBLGNBQUFBLEtBQUEsR0FBSSxHQUFHO01BQ3RELE1BQU1uQixJQUFJLEdBQUcsTUFBTSxJQUFBN0gsVUFBQSxDQUFBaUosa0JBQWtCLEVBQUNuRSxJQUFJLEVBQUUyRCxHQUFHLENBQUM7TUFDaEQsT0FBT2pGLEdBQUcsQ0FBQ0ssRUFBRSxDQUFDO1FBQUV2RCxJQUFJLEVBQUV1SDtNQUFLLENBQUMsQ0FBQztJQUMvQixDQUFDLENBQUMsT0FBTzFILEdBQVEsRUFBRTtNQUFBLElBQUErSSxhQUFBO01BQ2pCLE9BQU8xRixHQUFHLENBQUN1QixXQUFXLENBQUM7UUFBRUMsVUFBVSxFQUFFLElBQUFoRixVQUFBLENBQUF5RyxjQUFjLEVBQUN0RyxHQUFHLENBQUM7UUFBRUcsSUFBSSxHQUFBNEksYUFBQSxHQUFFL0ksR0FBRyxhQUFIQSxHQUFHLHVCQUFIQSxHQUFHLENBQUVJLE9BQU8sY0FBQTJJLGFBQUEsY0FBQUEsYUFBQSxHQUFJekksTUFBTSxDQUFDTixHQUFHO01BQUUsQ0FBQyxDQUFDO0lBQ2hHO0VBQ0YsQ0FDRixDQUFDO0VBRUQrQyxNQUFNLENBQUNDLEdBQUcsQ0FDUjtJQUNFQyxJQUFJLEVBQUU7SUFDTkMsUUFBUSxFQUFFO01BQUVzRSxNQUFNLEVBQUU5SCxhQUFBLENBQUF1RSxNQUFNLENBQUNDLE1BQU0sQ0FBQztRQUFFOEUsUUFBUSxFQUFFdEosYUFBQSxDQUFBdUUsTUFBTSxDQUFDTSxNQUFNLENBQUM7TUFBRSxDQUFDO0lBQUU7RUFDbkUsQ0FBQyxFQUNELE9BQU9wQixRQUFRLEVBQUVzQixHQUFHLEVBQUVwQixHQUFHLEtBQUs7SUFDNUIsTUFBTXNCLElBQUksR0FBRyxJQUFBOUUsVUFBQSxDQUFBMEQsWUFBWSxFQUFDLENBQUM7SUFDM0IsSUFBSSxDQUFDb0IsSUFBSSxFQUFFLE9BQU90QixHQUFHLENBQUN1QixXQUFXLENBQUM7TUFBRUMsVUFBVSxFQUFFLEdBQUc7TUFBRTFFLElBQUksRUFBRTtJQUFzQixDQUFDLENBQUM7SUFDbkYsSUFBSTtNQUNGLE1BQU02SSxRQUFRLEdBQUl2RSxHQUFHLENBQUMrQyxNQUFNLENBQTBCd0IsUUFBUTtNQUM5RCxNQUFNdEIsSUFBSSxHQUFHLE1BQU0sSUFBQTdILFVBQUEsQ0FBQW9KLDBCQUEwQixFQUFDdEUsSUFBSSxFQUFFcUUsUUFBUSxDQUFDO01BQzdELE9BQU8zRixHQUFHLENBQUNLLEVBQUUsQ0FBQztRQUFFdkQsSUFBSSxFQUFFdUg7TUFBSyxDQUFDLENBQUM7SUFDL0IsQ0FBQyxDQUFDLE9BQU8xSCxHQUFRLEVBQUU7TUFBQSxJQUFBa0osYUFBQTtNQUNqQixPQUFPN0YsR0FBRyxDQUFDdUIsV0FBVyxDQUFDO1FBQUVDLFVBQVUsRUFBRSxJQUFBaEYsVUFBQSxDQUFBeUcsY0FBYyxFQUFDdEcsR0FBRyxDQUFDO1FBQUVHLElBQUksR0FBQStJLGFBQUEsR0FBRWxKLEdBQUcsYUFBSEEsR0FBRyx1QkFBSEEsR0FBRyxDQUFFSSxPQUFPLGNBQUE4SSxhQUFBLGNBQUFBLGFBQUEsR0FBSTVJLE1BQU0sQ0FBQ04sR0FBRztNQUFFLENBQUMsQ0FBQztJQUNoRztFQUNGLENBQ0YsQ0FBQztFQUVEK0MsTUFBTSxDQUFDQyxHQUFHLENBQUM7SUFBRUMsSUFBSSxFQUFFO0lBQWlDQyxRQUFRLEVBQUU7RUFBTSxDQUFDLEVBQUUsT0FBT1QsT0FBTyxFQUFFVyxJQUFJLEVBQUVDLEdBQUcsS0FBSztJQUNuRyxJQUFJO01BQUEsSUFBQThGLE1BQUEsRUFBQUMsaUJBQUEsRUFBQUMsYUFBQSxFQUFBQyxrQkFBQSxFQUFBQyxjQUFBLEVBQUFDLHFCQUFBLEVBQUFDLGVBQUEsRUFBQUMsZ0JBQUEsRUFBQUMsbUJBQUEsRUFBQUMsV0FBQSxFQUFBQyxxQkFBQSxFQUFBQyxpQkFBQSxFQUFBQyxxQkFBQSxFQUFBQyxlQUFBLEVBQUFDLHFCQUFBLEVBQUFDLGFBQUE7TUFDRixNQUFNdEgsTUFBTSxHQUFHSixTQUFTLENBQUNDLE9BQU8sQ0FBQztNQUNqQyxNQUFNMEgsU0FBUyxHQUFHLElBQUlyRyxJQUFJLENBQUNBLElBQUksQ0FBQ3NHLEdBQUcsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxHQUFHLEVBQUUsR0FBRyxFQUFFLEdBQUcsRUFBRSxHQUFHLElBQUksQ0FBQyxDQUFDckcsV0FBVyxDQUFDLENBQUM7TUFFOUUsTUFBTXNHLFdBQVcsR0FBRyxNQUFNekgsTUFBTSxDQUFDa0UsTUFBTSxDQUFDO1FBQ3RDQyxLQUFLLEVBQUVuSCxVQUFBLENBQUFvSCx1QkFBdUI7UUFDOUJDLGtCQUFrQixFQUFFLElBQUk7UUFDeEI5RyxJQUFJLEVBQUU7VUFDSmdFLElBQUksRUFBRSxDQUFDO1VBQ1BtRyxnQkFBZ0IsRUFBRSxJQUFJO1VBQ3RCaEYsSUFBSSxFQUFFLENBQUM7WUFBRW5FLFNBQVMsRUFBRTtjQUFFK0YsS0FBSyxFQUFFLE1BQU07Y0FBRUMsT0FBTyxFQUFFO1lBQVE7VUFBRSxDQUFDLENBQUM7VUFDMURuRCxLQUFLLEVBQUU7WUFBRXFELFNBQVMsRUFBRSxDQUFDO1VBQUUsQ0FBQztVQUN4QmtELElBQUksRUFBRTtZQUNKQyxLQUFLLEVBQUU7Y0FBRUMsS0FBSyxFQUFFO2dCQUFFQyxLQUFLLEVBQUUsYUFBYTtnQkFBRXZHLElBQUksRUFBRTtjQUFHO1lBQUUsQ0FBQztZQUNwRHdHLFdBQVcsRUFBRTtjQUFFRixLQUFLLEVBQUU7Z0JBQUVDLEtBQUssRUFBRSxnQkFBZ0I7Z0JBQUV2RyxJQUFJLEVBQUU7Y0FBRztZQUFFLENBQUM7WUFDN0R5RyxTQUFTLEVBQUU7Y0FBRUgsS0FBSyxFQUFFO2dCQUFFQyxLQUFLLEVBQUUsZUFBZTtnQkFBRXZHLElBQUksRUFBRTtjQUFHO1lBQUUsQ0FBQztZQUMxRDBHLE9BQU8sRUFBRTtjQUFFSixLQUFLLEVBQUU7Z0JBQUVDLEtBQUssRUFBRSxZQUFZO2dCQUFFdkcsSUFBSSxFQUFFO2NBQUc7WUFBRTtVQUN0RDtRQUNGO01BQ0YsQ0FBQyxDQUFDO01BRUYsSUFBSTJHLGNBQWMsR0FBRyxDQUFDO01BQ3RCLElBQUlDLFdBQVcsR0FBRyxDQUFDO01BQ25CLElBQUlDLFNBQVMsR0FBRyxDQUFDO01BQ2pCLElBQUlDLFlBQVksR0FBRyxDQUFDO01BQ3BCLElBQUlDLFVBQVUsR0FBRyxDQUFDO01BQ2xCLElBQUk7UUFBQSxJQUFBQyxNQUFBLEVBQUFDLFFBQUEsRUFBQUMsT0FBQSxFQUFBQyxRQUFBLEVBQUFDLE9BQUEsRUFBQUMsUUFBQSxFQUFBQyxPQUFBLEVBQUFDLFdBQUEsRUFBQUMsSUFBQSxFQUFBQyxpQkFBQSxFQUFBQyxjQUFBLEVBQUFDLGVBQUE7UUFDRixNQUFNLENBQUNDLEVBQUUsRUFBRUMsRUFBRSxFQUFFQyxFQUFFLEVBQUVDLEtBQUssRUFBRUMsUUFBUSxDQUFDLEdBQUcsTUFBTUMsT0FBTyxDQUFDQyxHQUFHLENBQUMsQ0FDdER6SixNQUFNLENBQUMwSixLQUFLLENBQUM7VUFBRXZGLEtBQUssRUFBRW5ILFVBQUEsQ0FBQTJNLHdCQUF3QjtVQUFFdEYsa0JBQWtCLEVBQUU7UUFBSyxDQUFDLENBQUMsRUFDM0VyRSxNQUFNLENBQUMwSixLQUFLLENBQUM7VUFBRXZGLEtBQUssRUFBRW5ILFVBQUEsQ0FBQTRNLHFCQUFxQjtVQUFFdkYsa0JBQWtCLEVBQUU7UUFBSyxDQUFDLENBQUMsRUFDeEVyRSxNQUFNLENBQUMwSixLQUFLLENBQUM7VUFBRXZGLEtBQUssRUFBRW5ILFVBQUEsQ0FBQTZNLDhCQUE4QjtVQUFFeEYsa0JBQWtCLEVBQUU7UUFBSyxDQUFDLENBQUMsRUFDakZyRSxNQUFNLENBQUMwSixLQUFLLENBQUM7VUFBRXZGLEtBQUssRUFBRW5ILFVBQUEsQ0FBQThNLCtCQUErQjtVQUFFekYsa0JBQWtCLEVBQUU7UUFBSyxDQUFDLENBQUMsRUFDbEZyRSxNQUFNLENBQUNrRSxNQUFNLENBQUM7VUFDWkMsS0FBSyxFQUFFbkgsVUFBQSxDQUFBb0gsdUJBQXVCO1VBQzlCQyxrQkFBa0IsRUFBRSxJQUFJO1VBQ3hCOUcsSUFBSSxFQUFFO1lBQ0pnRSxJQUFJLEVBQUUsQ0FBQztZQUNQSCxLQUFLLEVBQUU7Y0FDTG9ELElBQUksRUFBRTtnQkFDSmhDLE1BQU0sRUFBRSxDQUFDO2tCQUFFdUgsS0FBSyxFQUFFO29CQUFFeEwsU0FBUyxFQUFFO3NCQUFFeUwsRUFBRSxFQUFFekM7b0JBQVU7a0JBQUU7Z0JBQUUsQ0FBQztjQUN0RDtZQUNGLENBQUM7WUFDREcsZ0JBQWdCLEVBQUU7VUFDcEI7UUFDRixDQUFDLENBQUMsQ0FDSCxDQUFDO1FBQ0ZRLGNBQWMsSUFBQUssTUFBQSxJQUFBQyxRQUFBLEdBQUlXLEVBQUUsQ0FBQzVMLElBQUksY0FBQWlMLFFBQUEsdUJBQVJBLFFBQUEsQ0FBa0JrQixLQUFLLGNBQUFuQixNQUFBLGNBQUFBLE1BQUEsR0FBSSxDQUFDO1FBQzdDSixXQUFXLElBQUFNLE9BQUEsSUFBQUMsUUFBQSxHQUFJVSxFQUFFLENBQUM3TCxJQUFJLGNBQUFtTCxRQUFBLHVCQUFSQSxRQUFBLENBQWtCZ0IsS0FBSyxjQUFBakIsT0FBQSxjQUFBQSxPQUFBLEdBQUksQ0FBQztRQUMxQ0wsU0FBUyxJQUFBTyxPQUFBLElBQUFDLFFBQUEsR0FBSVMsRUFBRSxDQUFDOUwsSUFBSSxjQUFBcUwsUUFBQSx1QkFBUkEsUUFBQSxDQUFrQmMsS0FBSyxjQUFBZixPQUFBLGNBQUFBLE9BQUEsR0FBSSxDQUFDO1FBQ3hDTixZQUFZLElBQUFRLE9BQUEsSUFBQUMsV0FBQSxHQUFJUSxLQUFLLENBQUMvTCxJQUFJLGNBQUF1TCxXQUFBLHVCQUFYQSxXQUFBLENBQXFCWSxLQUFLLGNBQUFiLE9BQUEsY0FBQUEsT0FBQSxHQUFJLENBQUM7UUFDOUNQLFVBQVUsSUFBQVMsSUFBQSxJQUFBQyxpQkFBQSxJQUFBQyxjQUFBLEdBQ1BNLFFBQVEsQ0FBQ2hNLElBQUksY0FBQTBMLGNBQUEsZ0JBQUFBLGNBQUEsR0FBZEEsY0FBQSxDQUF3QmhHLElBQUksY0FBQWdHLGNBQUEsZ0JBQUFBLGNBQUEsR0FBNUJBLGNBQUEsQ0FBOEI1RixLQUFLLGNBQUE0RixjQUFBLHVCQUFuQ0EsY0FBQSxDQUFxQzNGLEtBQUssY0FBQTBGLGlCQUFBLGNBQUFBLGlCQUFBLElBQUFFLGVBQUEsR0FDekNLLFFBQVEsQ0FBQ2hNLElBQUksY0FBQTJMLGVBQUEsZ0JBQUFBLGVBQUEsR0FBZEEsZUFBQSxDQUF3QmpHLElBQUksY0FBQWlHLGVBQUEsdUJBQTVCQSxlQUFBLENBQThCN0YsS0FBSyxjQUFBMEYsSUFBQSxjQUFBQSxJQUFBLEdBQ25DLENBQUM7TUFDTCxDQUFDLENBQUMsTUFBTTtRQUNOO01BQUE7TUFHRixNQUFNa0IsUUFBUSxJQUFBMUQsTUFBQSxJQUFBQyxpQkFBQSxHQUFJaUIsV0FBVyxDQUFDbEssSUFBSSxjQUFBaUosaUJBQUEsdUJBQWpCQSxpQkFBQSxDQUEyQnZELElBQUksY0FBQXNELE1BQUEsY0FBQUEsTUFBQSxHQUFJLENBQUMsQ0FBQztNQUN0RCxNQUFNb0IsSUFBSSxJQUFBbEIsYUFBQSxJQUFBQyxrQkFBQSxHQUFJZSxXQUFXLENBQUNsSyxJQUFJLGNBQUFtSixrQkFBQSx1QkFBakJBLGtCQUFBLENBQTJCd0QsWUFBWSxjQUFBekQsYUFBQSxjQUFBQSxhQUFBLEdBQUksQ0FBQyxDQUFDO01BQzFELE1BQU0wRCxlQUFlLEdBQUcsRUFBQXhELGNBQUEsR0FBQ3NELFFBQVEsQ0FBQ2hILElBQUksY0FBQTBELGNBQUEsY0FBQUEsY0FBQSxHQUFJLEVBQUUsRUFBRXBFLEdBQUcsQ0FBRTZILENBQU0sSUFBS0EsQ0FBQyxDQUFDakgsT0FBTyxDQUFDLENBQUNYLE1BQU0sQ0FBQzZILE9BQU8sQ0FBQztNQUN4RixNQUFNQyxhQUFhLEdBQ2pCLE9BQU9MLFFBQVEsQ0FBQzVHLEtBQUssS0FBSyxRQUFRLElBQUF1RCxxQkFBQSxJQUFBQyxlQUFBLEdBQzlCb0QsUUFBUSxDQUFDNUcsS0FBSyxjQUFBd0QsZUFBQSx1QkFBZEEsZUFBQSxDQUFnQnZELEtBQUssY0FBQXNELHFCQUFBLGNBQUFBLHFCQUFBLEdBQUksQ0FBQyxJQUFBRSxnQkFBQSxHQUMxQm1ELFFBQVEsQ0FBQzVHLEtBQUssY0FBQXlELGdCQUFBLGNBQUFBLGdCQUFBLEdBQUlxRCxlQUFlLENBQUM1RyxNQUFNO01BRTlDLElBQUlnSCxXQUFXLElBQUF4RCxtQkFBQSxJQUFBQyxXQUFBLEdBQUdXLElBQUksQ0FBQ0MsS0FBSyxjQUFBWixXQUFBLHVCQUFWQSxXQUFBLENBQVl3RCxPQUFPLGNBQUF6RCxtQkFBQSxjQUFBQSxtQkFBQSxHQUFJLEVBQUU7TUFDM0MsSUFBSTBELGlCQUFpQixJQUFBeEQscUJBQUEsSUFBQUMsaUJBQUEsR0FBR1MsSUFBSSxDQUFDSSxXQUFXLGNBQUFiLGlCQUFBLHVCQUFoQkEsaUJBQUEsQ0FBa0JzRCxPQUFPLGNBQUF2RCxxQkFBQSxjQUFBQSxxQkFBQSxHQUFJLEVBQUU7TUFDdkQsSUFBSXlELGVBQWUsSUFBQXZELHFCQUFBLElBQUFDLGVBQUEsR0FBR08sSUFBSSxDQUFDSyxTQUFTLGNBQUFaLGVBQUEsdUJBQWRBLGVBQUEsQ0FBZ0JvRCxPQUFPLGNBQUFyRCxxQkFBQSxjQUFBQSxxQkFBQSxHQUFJLEVBQUU7TUFDbkQsSUFBSXdELGFBQWEsSUFBQXRELHFCQUFBLElBQUFDLGFBQUEsR0FBR0ssSUFBSSxDQUFDTSxPQUFPLGNBQUFYLGFBQUEsdUJBQVpBLGFBQUEsQ0FBY2tELE9BQU8sY0FBQW5ELHFCQUFBLGNBQUFBLHFCQUFBLEdBQUksRUFBRTtNQUMvQyxJQUFJdUQsVUFBVSxHQUFHVCxlQUFlO01BQ2hDLElBQUk5RyxLQUFLLEdBQUdpSCxhQUFhO01BQ3pCLElBQUlPLFVBQTJCLEdBQUcsT0FBTztNQUV6QyxNQUFNOUksSUFBSSxHQUFHLElBQUE5RSxVQUFBLENBQUEwRCxZQUFZLEVBQUMsQ0FBQztNQUMzQixJQUFJMEMsS0FBSyxLQUFLLENBQUMsSUFBSXRCLElBQUksRUFBRTtRQUN2QixJQUFJO1VBQ0YsTUFBTUssR0FBRyxHQUFHLE1BQU0sSUFBQW5GLFVBQUEsQ0FBQW9GLHVCQUF1QixFQUFDTixJQUFJLEVBQUUsRUFBRSxDQUFDO1VBQ25ELE1BQU0rSSxHQUFHLEdBQUcvSSxJQUFJLENBQUNsRSxRQUFRO1VBQ3pCLE1BQU1rTixVQUFVLEdBQUczSSxHQUFHLENBQUNHLEdBQUcsQ0FBRTNFLENBQUMsSUFDM0JELG1CQUFtQixDQUFDQyxDQUFDLEVBQTZCa04sR0FBRyxDQUN2RCxDQUFDO1VBQ0QsSUFBSUMsVUFBVSxDQUFDeEgsTUFBTSxHQUFHLENBQUMsRUFBRTtZQUN6QnNILFVBQVUsR0FBRyxLQUFLO1lBQ2xCeEgsS0FBSyxHQUFHMEgsVUFBVSxDQUFDeEgsTUFBTTtZQUN6QnFILFVBQVUsR0FBR0csVUFBVSxDQUNwQi9ILEtBQUssQ0FBQyxDQUFDLENBQ1BOLElBQUksQ0FBQyxDQUFDQyxDQUFDLEVBQUVDLENBQUMsS0FBSztjQUNkLE1BQU1DLEVBQUUsR0FBR0YsQ0FBQyxDQUFDcEUsU0FBUyxHQUFHLElBQUkyQyxJQUFJLENBQUN4RCxNQUFNLENBQUNpRixDQUFDLENBQUNwRSxTQUFTLENBQUMsQ0FBQyxDQUFDdUUsT0FBTyxDQUFDLENBQUMsR0FBRyxDQUFDO2NBQ3BFLE1BQU1DLEVBQUUsR0FBR0gsQ0FBQyxDQUFDckUsU0FBUyxHQUFHLElBQUkyQyxJQUFJLENBQUN4RCxNQUFNLENBQUNrRixDQUFDLENBQUNyRSxTQUFTLENBQUMsQ0FBQyxDQUFDdUUsT0FBTyxDQUFDLENBQUMsR0FBRyxDQUFDO2NBQ3BFLE9BQU9DLEVBQUUsR0FBR0YsRUFBRTtZQUNoQixDQUFDLENBQUMsQ0FDREcsS0FBSyxDQUFDLENBQUMsRUFBRSxFQUFFLENBQUM7WUFDZixNQUFNZ0ksS0FBNkIsR0FBRyxDQUFDLENBQUM7WUFDeEMsTUFBTUMsS0FBNkIsR0FBRyxDQUFDLENBQUM7WUFDeEMsTUFBTUMsU0FBaUMsR0FBRyxDQUFDLENBQUM7WUFDNUMsTUFBTUMsT0FBK0IsR0FBRyxDQUFDLENBQUM7WUFDMUNKLFVBQVUsQ0FBQ0ssT0FBTyxDQUFFM0ksQ0FBQyxJQUFLO2NBQ3hCLE1BQU00SSxFQUFFLEdBQUczTixNQUFNLENBQUMrRSxDQUFDLENBQUN0RSxXQUFXLElBQUksU0FBUyxDQUFDO2NBQzdDNk0sS0FBSyxDQUFDSyxFQUFFLENBQUMsR0FBRyxDQUFDTCxLQUFLLENBQUNLLEVBQUUsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDO2NBQ2hDLE1BQU1DLEVBQUUsR0FBRzVOLE1BQU0sQ0FBQytFLENBQUMsQ0FBQzFELGNBQWMsSUFBSSxTQUFTLENBQUM7Y0FDaERrTSxLQUFLLENBQUNLLEVBQUUsQ0FBQyxHQUFHLENBQUNMLEtBQUssQ0FBQ0ssRUFBRSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUM7Y0FDaEMsTUFBTUMsRUFBRSxHQUFHN04sTUFBTSxDQUFDK0UsQ0FBQyxDQUFDckQsYUFBYSxJQUFJLFNBQVMsQ0FBQztjQUMvQzhMLFNBQVMsQ0FBQ0ssRUFBRSxDQUFDLEdBQUcsQ0FBQ0wsU0FBUyxDQUFDSyxFQUFFLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQztjQUN4QyxNQUFNQyxFQUFFLEdBQUc5TixNQUFNLENBQUMrRSxDQUFDLENBQUM1RCxVQUFVLElBQUksU0FBUyxDQUFDO2NBQzVDc00sT0FBTyxDQUFDSyxFQUFFLENBQUMsR0FBRyxDQUFDTCxPQUFPLENBQUNLLEVBQUUsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDO1lBQ3RDLENBQUMsQ0FBQztZQUNGakIsV0FBVyxHQUFHa0IsTUFBTSxDQUFDQyxPQUFPLENBQUNWLEtBQUssQ0FBQyxDQUFDekksR0FBRyxDQUFDLENBQUMsQ0FBQ29KLEdBQUcsRUFBRUMsU0FBUyxDQUFDLE1BQU07Y0FBRUQsR0FBRztjQUFFQztZQUFVLENBQUMsQ0FBQyxDQUFDO1lBQ25GbkIsaUJBQWlCLEdBQUdnQixNQUFNLENBQUNDLE9BQU8sQ0FBQ1QsS0FBSyxDQUFDLENBQUMxSSxHQUFHLENBQUMsQ0FBQyxDQUFDb0osR0FBRyxFQUFFQyxTQUFTLENBQUMsTUFBTTtjQUFFRCxHQUFHO2NBQUVDO1lBQVUsQ0FBQyxDQUFDLENBQUM7WUFDekZsQixlQUFlLEdBQUdlLE1BQU0sQ0FBQ0MsT0FBTyxDQUFDUixTQUFTLENBQUMsQ0FBQzNJLEdBQUcsQ0FBQyxDQUFDLENBQUNvSixHQUFHLEVBQUVDLFNBQVMsQ0FBQyxNQUFNO2NBQ3JFRCxHQUFHO2NBQ0hDO1lBQ0YsQ0FBQyxDQUFDLENBQUM7WUFDSGpCLGFBQWEsR0FBR2MsTUFBTSxDQUFDQyxPQUFPLENBQUNQLE9BQU8sQ0FBQyxDQUFDNUksR0FBRyxDQUFDLENBQUMsQ0FBQ29KLEdBQUcsRUFBRUMsU0FBUyxDQUFDLE1BQU07Y0FDakVELEdBQUc7Y0FDSEM7WUFDRixDQUFDLENBQUMsQ0FBQztZQUNIdEQsVUFBVSxHQUFHeUMsVUFBVSxDQUFDdkksTUFBTSxDQUMzQkMsQ0FBQyxJQUFLLENBQUNBLENBQUMsQ0FBQ2xFLFNBQVMsSUFBSSxJQUFJMkMsSUFBSSxDQUFDeEQsTUFBTSxDQUFDK0UsQ0FBQyxDQUFDbEUsU0FBUyxDQUFDLENBQUMsR0FBRyxJQUFJMkMsSUFBSSxDQUFDcUcsU0FBUyxDQUMzRSxDQUFDLENBQUNoRSxNQUFNO1VBQ1Y7UUFDRixDQUFDLENBQUMsTUFBTTtVQUNOO1FBQUE7TUFFSjtNQUVBLElBQUlzSSxrQkFBaUMsR0FBRyxJQUFJO01BQzVDLElBQUlDLGVBQThCLEdBQUcsSUFBSTtNQUN6QyxJQUFJQyxVQUF5QixHQUFHLElBQUk7TUFDcEMsTUFBTUMsSUFBSSxHQUFHLElBQUE5TyxvQkFBQSxDQUFBMkQsc0JBQXNCLEVBQUMsQ0FBQztNQUNyQyxJQUFJbUwsSUFBSSxFQUFFO1FBQ1IsSUFBSTtVQUNGSCxrQkFBa0IsR0FBRyxNQUFNLElBQUEzTyxvQkFBQSxDQUFBK08sdUJBQXVCLEVBQUNELElBQUksRUFBRSxXQUFXLENBQUM7UUFDdkUsQ0FBQyxDQUFDLE9BQU9FLENBQUMsRUFBRTtVQUNWSCxVQUFVLEdBQUc1TyxXQUFXLENBQUMrTyxDQUFDLENBQUMsQ0FBQzNPLElBQUk7VUFDaENzTyxrQkFBa0IsR0FBRyxJQUFJO1FBQzNCO1FBQ0EsSUFBSTtVQUNGQyxlQUFlLEdBQUcsTUFBTSxJQUFBNU8sb0JBQUEsQ0FBQStPLHVCQUF1QixFQUFDRCxJQUFJLEVBQUUsV0FBVyxDQUFDO1FBQ3BFLENBQUMsQ0FBQyxPQUFPRSxDQUFDLEVBQUU7VUFDVixJQUFJLENBQUNILFVBQVUsRUFBRUEsVUFBVSxHQUFHNU8sV0FBVyxDQUFDK08sQ0FBQyxDQUFDLENBQUMzTyxJQUFJO1VBQ2pEdU8sZUFBZSxHQUFHLElBQUk7UUFDeEI7TUFDRjtNQUVBLE9BQU9yTCxHQUFHLENBQUNLLEVBQUUsQ0FBQztRQUNadkQsSUFBSSxFQUFFO1VBQ0o0TyxjQUFjLEVBQUU5SSxLQUFLO1VBQ3JCdUUsS0FBSyxFQUFFMkMsV0FBVztVQUNsQnhDLFdBQVcsRUFBRTBDLGlCQUFpQjtVQUM5QnpDLFNBQVMsRUFBRTBDLGVBQWU7VUFDMUJ6QyxPQUFPLEVBQUUwQyxhQUFhO1VBQ3RCUixlQUFlLEVBQUVTLFVBQVU7VUFDM0J3QixxQkFBcUIsRUFBRWxFLGNBQWM7VUFDckNtRSxrQkFBa0IsRUFBRWxFLFdBQVc7VUFDL0JtRSwyQkFBMkIsRUFBRWxFLFNBQVM7VUFDdENtRSxtQkFBbUIsRUFBRWxFLFlBQVk7VUFDakNtRSxvQkFBb0IsRUFBRWxFLFVBQVU7VUFDaENtRSwwQkFBMEIsRUFBRVosa0JBQWtCO1VBQzlDYSx1QkFBdUIsRUFBRVosZUFBZTtVQUN4Q2EsZ0JBQWdCLEVBQUVaLFVBQVU7VUFDNUJhLFdBQVcsRUFBRS9CO1FBQ2Y7TUFDRixDQUFDLENBQUM7SUFDSixDQUFDLENBQUMsT0FBT3pOLEdBQVEsRUFBRTtNQUFBLElBQUF5UCxnQkFBQSxFQUFBQyxhQUFBO01BQ2pCLE9BQU9yTSxHQUFHLENBQUN1QixXQUFXLENBQUM7UUFDckJDLFVBQVUsR0FBQTRLLGdCQUFBLEdBQUV6UCxHQUFHLENBQUM2RSxVQUFVLGNBQUE0SyxnQkFBQSxjQUFBQSxnQkFBQSxHQUFJLEdBQUc7UUFDakN0UCxJQUFJLEdBQUF1UCxhQUFBLEdBQUUxUCxHQUFHLENBQUNJLE9BQU8sY0FBQXNQLGFBQUEsY0FBQUEsYUFBQSxHQUFJcFAsTUFBTSxDQUFDTixHQUFHO01BQ2pDLENBQUMsQ0FBQztJQUNKO0VBQ0YsQ0FBQyxDQUFDO0VBRUYrQyxNQUFNLENBQUNDLEdBQUcsQ0FDUjtJQUNFQyxJQUFJLEVBQUU7SUFDTkMsUUFBUSxFQUFFO01BQ1JjLEtBQUssRUFBRXRFLGFBQUEsQ0FBQXVFLE1BQU0sQ0FBQ0MsTUFBTSxDQUFDO1FBQ25CQyxJQUFJLEVBQUV6RSxhQUFBLENBQUF1RSxNQUFNLENBQUNHLEtBQUssQ0FBQzFFLGFBQUEsQ0FBQXVFLE1BQU0sQ0FBQ0ksTUFBTSxDQUFDLENBQUMsQ0FBQztRQUNuQ0MsSUFBSSxFQUFFNUUsYUFBQSxDQUFBdUUsTUFBTSxDQUFDRyxLQUFLLENBQUMxRSxhQUFBLENBQUF1RSxNQUFNLENBQUNJLE1BQU0sQ0FBQyxDQUFDLENBQUM7UUFDbkNHLE1BQU0sRUFBRTlFLGFBQUEsQ0FBQXVFLE1BQU0sQ0FBQ0csS0FBSyxDQUFDMUUsYUFBQSxDQUFBdUUsTUFBTSxDQUFDTSxNQUFNLENBQUMsQ0FBQztNQUN0QyxDQUFDO0lBQ0g7RUFDRixDQUFDLEVBQ0QsT0FBTzlCLE9BQU8sRUFBRWdDLEdBQUcsRUFBRXBCLEdBQUcsS0FBSztJQUMzQixNQUFNcUIsQ0FBQyxHQUFHRCxHQUFHLENBQUNULEtBQTBEO0lBQ3hFLElBQUlVLENBQUMsQ0FBQ0YsTUFBTSxLQUFLLEtBQUssRUFBRTtNQUN0QixNQUFNRyxJQUFJLEdBQUcsSUFBQTlFLFVBQUEsQ0FBQTBELFlBQVksRUFBQyxDQUFDO01BQzNCLElBQUksQ0FBQ29CLElBQUksRUFBRSxPQUFPdEIsR0FBRyxDQUFDdUIsV0FBVyxDQUFDO1FBQUVDLFVBQVUsRUFBRSxHQUFHO1FBQUUxRSxJQUFJLEVBQUU7TUFBc0IsQ0FBQyxDQUFDO01BQ25GLElBQUk7UUFBQSxJQUFBd1AsUUFBQSxFQUFBQyxXQUFBLEVBQUFDLFFBQUEsRUFBQUMsUUFBQTtRQUNGLE1BQU1wSSxJQUFJLEdBQUksTUFBTSxJQUFBN0gsVUFBQSxDQUFBMkksc0JBQXNCLEVBQUM3RCxJQUFJLEdBQUFnTCxRQUFBLEdBQUVqTCxDQUFDLENBQUNQLElBQUksY0FBQXdMLFFBQUEsY0FBQUEsUUFBQSxHQUFJLEdBQUcsQ0FFN0Q7UUFDRCxNQUFNekssSUFBSSxJQUFBMEssV0FBQSxHQUFHbEksSUFBSSxhQUFKQSxJQUFJLHVCQUFKQSxJQUFJLENBQUV4QixLQUFLLGNBQUEwSixXQUFBLGNBQUFBLFdBQUEsR0FBSSxFQUFFO1FBQzlCLE1BQU10TCxJQUFJLElBQUF1TCxRQUFBLEdBQUduTCxDQUFDLENBQUNKLElBQUksY0FBQXVMLFFBQUEsY0FBQUEsUUFBQSxHQUFJLENBQUM7UUFDeEIsTUFBTTFMLElBQUksSUFBQTJMLFFBQUEsR0FBR3BMLENBQUMsQ0FBQ1AsSUFBSSxjQUFBMkwsUUFBQSxjQUFBQSxRQUFBLEdBQUksRUFBRTtRQUN6QixNQUFNbEssS0FBSyxHQUFHVixJQUFJLENBQUNVLEtBQUssQ0FBQ3RCLElBQUksRUFBRUEsSUFBSSxHQUFHSCxJQUFJLENBQUM7UUFDM0MsTUFBTTBCLElBQUksR0FBR0QsS0FBSyxDQUFDVCxHQUFHLENBQUMsQ0FBQzRLLEdBQVEsRUFBRUMsQ0FBUztVQUFBLElBQUFDLEtBQUEsRUFBQUMsT0FBQTtVQUFBLE9BQU07WUFDL0NsSyxHQUFHLEVBQUUxRixNQUFNLEVBQUEyUCxLQUFBLElBQUFDLE9BQUEsR0FBQ0gsR0FBRyxDQUFDblAsRUFBRSxjQUFBc1AsT0FBQSxjQUFBQSxPQUFBLEdBQUlILEdBQUcsQ0FBQ0ksS0FBSyxjQUFBRixLQUFBLGNBQUFBLEtBQUEsR0FBSUQsQ0FBQyxDQUFDO1lBQ3JDakssT0FBTyxFQUFFLE9BQU9nSyxHQUFHLEtBQUssUUFBUSxHQUFHQSxHQUFHLEdBQUc7Y0FBRS9LLEdBQUcsRUFBRStLO1lBQUk7VUFDdEQsQ0FBQztRQUFBLENBQUMsQ0FBQztRQUNILE9BQU8xTSxHQUFHLENBQUNLLEVBQUUsQ0FBQztVQUNadkQsSUFBSSxFQUFFO1lBQ0owRixJQUFJO1lBQ0pJLEtBQUssRUFBRTtjQUFFQyxLQUFLLEVBQUVoQixJQUFJLENBQUNpQixNQUFNO2NBQUVDLFFBQVEsRUFBRTtZQUFLLENBQUM7WUFDN0M1QixNQUFNLEVBQUU7VUFDVjtRQUNGLENBQUMsQ0FBQztNQUNKLENBQUMsQ0FBQyxPQUFPeEUsR0FBUSxFQUFFO1FBQUEsSUFBQW9RLGNBQUE7UUFDakIsT0FBTy9NLEdBQUcsQ0FBQ3VCLFdBQVcsQ0FBQztVQUNyQkMsVUFBVSxFQUFFLElBQUFoRixVQUFBLENBQUF5RyxjQUFjLEVBQUN0RyxHQUFHLENBQUM7VUFDL0JHLElBQUksR0FBQWlRLGNBQUEsR0FBRXBRLEdBQUcsYUFBSEEsR0FBRyx1QkFBSEEsR0FBRyxDQUFFSSxPQUFPLGNBQUFnUSxjQUFBLGNBQUFBLGNBQUEsR0FBSTlQLE1BQU0sQ0FBQ04sR0FBRztRQUNsQyxDQUFDLENBQUM7TUFDSjtJQUNGO0lBQ0EsSUFBSTtNQUFBLElBQUFxUSxNQUFBLEVBQUFDLGVBQUEsRUFBQUMsV0FBQTtNQUNGLE1BQU0zTixNQUFNLEdBQUdKLFNBQVMsQ0FBQ0MsT0FBTyxDQUFDO01BQ2pDLE1BQU07UUFBRTBCLElBQUksR0FBRyxFQUFFO1FBQUVHLElBQUksR0FBRztNQUFFLENBQUMsR0FBR0ksQ0FBQztNQUNqQyxNQUFNbUMsUUFBUSxHQUFHLE1BQU1qRSxNQUFNLENBQUNrRSxNQUFNLENBQUM7UUFDbkNDLEtBQUssRUFBRW5ILFVBQUEsQ0FBQTZNLDhCQUE4QjtRQUNyQ3hGLGtCQUFrQixFQUFFLElBQUk7UUFDeEI5RyxJQUFJLEVBQUU7VUFDSmdFLElBQUk7VUFDSkcsSUFBSTtVQUNKZ0IsSUFBSSxFQUFFLENBQUM7WUFBRWtMLE9BQU8sRUFBRTtjQUFFdEosS0FBSyxFQUFFO1lBQU87VUFBRSxDQUFDLENBQUM7VUFDdENsRCxLQUFLLEVBQUU7WUFBRXFELFNBQVMsRUFBRSxDQUFDO1VBQUU7UUFDekI7TUFDRixDQUFDLENBQUM7TUFDRixNQUFNeEIsSUFBSSxJQUFBd0ssTUFBQSxJQUFBQyxlQUFBLEdBQUl6SixRQUFRLENBQUMxRyxJQUFJLGNBQUFtUSxlQUFBLHVCQUFkQSxlQUFBLENBQXdCekssSUFBSSxjQUFBd0ssTUFBQSxjQUFBQSxNQUFBLEdBQUksQ0FBQyxDQUFDO01BQy9DLE9BQU9oTixHQUFHLENBQUNLLEVBQUUsQ0FBQztRQUFFdkQsSUFBSSxFQUFFO1VBQUUwRixJQUFJLEdBQUEwSyxXQUFBLEdBQUUxSyxJQUFJLENBQUNBLElBQUksY0FBQTBLLFdBQUEsY0FBQUEsV0FBQSxHQUFJLEVBQUU7VUFBRXRLLEtBQUssRUFBRUosSUFBSSxDQUFDSSxLQUFLO1VBQUV6QixNQUFNLEVBQUU7UUFBUTtNQUFFLENBQUMsQ0FBQztJQUN4RixDQUFDLENBQUMsT0FBT3hFLEdBQVEsRUFBRTtNQUFBLElBQUF5USxnQkFBQSxFQUFBQyxjQUFBO01BQ2pCLE9BQU9yTixHQUFHLENBQUN1QixXQUFXLENBQUM7UUFDckJDLFVBQVUsR0FBQTRMLGdCQUFBLEdBQUV6USxHQUFHLENBQUM2RSxVQUFVLGNBQUE0TCxnQkFBQSxjQUFBQSxnQkFBQSxHQUFJLEdBQUc7UUFDakN0USxJQUFJLEdBQUF1USxjQUFBLEdBQUUxUSxHQUFHLENBQUNJLE9BQU8sY0FBQXNRLGNBQUEsY0FBQUEsY0FBQSxHQUFJcFEsTUFBTSxDQUFDTixHQUFHO01BQ2pDLENBQUMsQ0FBQztJQUNKO0VBQ0YsQ0FDRixDQUFDO0VBRUQrQyxNQUFNLENBQUNDLEdBQUcsQ0FDUjtJQUNFQyxJQUFJLEVBQUU7SUFDTkMsUUFBUSxFQUFFO01BQ1JjLEtBQUssRUFBRXRFLGFBQUEsQ0FBQXVFLE1BQU0sQ0FBQ0MsTUFBTSxDQUFDO1FBQ25Cb0UsR0FBRyxFQUFFNUksYUFBQSxDQUFBdUUsTUFBTSxDQUFDRyxLQUFLLENBQUMxRSxhQUFBLENBQUF1RSxNQUFNLENBQUNJLE1BQU0sQ0FBQyxDQUFDO01BQ25DLENBQUM7SUFDSDtFQUNGLENBQUMsRUFDRCxPQUFPbEIsUUFBUSxFQUFFc0IsR0FBRyxFQUFFcEIsR0FBRyxLQUFLO0lBQzVCLE1BQU1vRSxNQUFNLEdBQUcsSUFBQTNILG9CQUFBLENBQUEyRCxzQkFBc0IsRUFBQyxDQUFDO0lBQ3ZDLElBQUksQ0FBQ2dFLE1BQU0sRUFBRTtNQUNYLE9BQU9wRSxHQUFHLENBQUN1QixXQUFXLENBQUM7UUFDckJDLFVBQVUsRUFBRSxHQUFHO1FBQ2YxRSxJQUFJLEVBQUU7TUFDUixDQUFDLENBQUM7SUFDSjtJQUNBLElBQUk7TUFBQSxJQUFBd1EsS0FBQTtNQUNGLE1BQU1ySSxHQUFHLElBQUFxSSxLQUFBLEdBQUlsTSxHQUFHLENBQUNULEtBQUssQ0FBc0JzRSxHQUFHLGNBQUFxSSxLQUFBLGNBQUFBLEtBQUEsR0FBSSxFQUFFO01BQ3JELE1BQU1qSixJQUFJLEdBQUcsTUFBTSxJQUFBNUgsb0JBQUEsQ0FBQThRLGFBQWEsRUFBQ25KLE1BQU0sRUFBRWEsR0FBRyxDQUFDO01BQzdDLE9BQU9qRixHQUFHLENBQUNLLEVBQUUsQ0FBQztRQUFFdkQsSUFBSSxFQUFFdUg7TUFBSyxDQUFDLENBQUM7SUFDL0IsQ0FBQyxDQUFDLE9BQU8xSCxHQUFZLEVBQUU7TUFDckIsTUFBTTtRQUFFRSxNQUFNO1FBQUVDO01BQUssQ0FBQyxHQUFHSixXQUFXLENBQUNDLEdBQUcsQ0FBQztNQUN6QyxPQUFPcUQsR0FBRyxDQUFDdUIsV0FBVyxDQUFDO1FBQUVDLFVBQVUsRUFBRTNFLE1BQU07UUFBRUM7TUFBSyxDQUFDLENBQUM7SUFDdEQ7RUFDRixDQUNGLENBQUM7RUFFRDRDLE1BQU0sQ0FBQ0MsR0FBRyxDQUNSO0lBQ0VDLElBQUksRUFBRTtJQUNOQyxRQUFRLEVBQUU7TUFDUmMsS0FBSyxFQUFFdEUsYUFBQSxDQUFBdUUsTUFBTSxDQUFDQyxNQUFNLENBQUM7UUFDbkJvRSxHQUFHLEVBQUU1SSxhQUFBLENBQUF1RSxNQUFNLENBQUNHLEtBQUssQ0FBQzFFLGFBQUEsQ0FBQXVFLE1BQU0sQ0FBQ0ksTUFBTSxDQUFDLENBQUM7TUFDbkMsQ0FBQztJQUNIO0VBQ0YsQ0FBQyxFQUNELE9BQU9sQixRQUFRLEVBQUVzQixHQUFHLEVBQUVwQixHQUFHLEtBQUs7SUFDNUIsTUFBTW9FLE1BQU0sR0FBRyxJQUFBM0gsb0JBQUEsQ0FBQTJELHNCQUFzQixFQUFDLENBQUM7SUFDdkMsSUFBSSxDQUFDZ0UsTUFBTSxFQUFFO01BQ1gsT0FBT3BFLEdBQUcsQ0FBQ3VCLFdBQVcsQ0FBQztRQUNyQkMsVUFBVSxFQUFFLEdBQUc7UUFDZjFFLElBQUksRUFBRTtNQUNSLENBQUMsQ0FBQztJQUNKO0lBQ0EsSUFBSTtNQUFBLElBQUEwUSxLQUFBO01BQ0YsTUFBTXZJLEdBQUcsSUFBQXVJLEtBQUEsR0FBSXBNLEdBQUcsQ0FBQ1QsS0FBSyxDQUFzQnNFLEdBQUcsY0FBQXVJLEtBQUEsY0FBQUEsS0FBQSxHQUFJLEVBQUU7TUFDckQsTUFBTW5KLElBQUksR0FBRyxNQUFNLElBQUE1SCxvQkFBQSxDQUFBZ1IsWUFBWSxFQUFDckosTUFBTSxFQUFFYSxHQUFHLENBQUM7TUFDNUMsT0FBT2pGLEdBQUcsQ0FBQ0ssRUFBRSxDQUFDO1FBQUV2RCxJQUFJLEVBQUV1SDtNQUFLLENBQUMsQ0FBQztJQUMvQixDQUFDLENBQUMsT0FBTzFILEdBQVksRUFBRTtNQUNyQixNQUFNO1FBQUVFLE1BQU07UUFBRUM7TUFBSyxDQUFDLEdBQUdKLFdBQVcsQ0FBQ0MsR0FBRyxDQUFDO01BQ3pDLE9BQU9xRCxHQUFHLENBQUN1QixXQUFXLENBQUM7UUFBRUMsVUFBVSxFQUFFM0UsTUFBTTtRQUFFQztNQUFLLENBQUMsQ0FBQztJQUN0RDtFQUNGLENBQ0YsQ0FBQztFQUVENEMsTUFBTSxDQUFDZ08sSUFBSSxDQUNUO0lBQ0U5TixJQUFJLEVBQUU7SUFDTkMsUUFBUSxFQUFFO01BQ1IvQyxJQUFJLEVBQUVULGFBQUEsQ0FBQXVFLE1BQU0sQ0FBQ0MsTUFBTSxDQUFDO1FBQ2xCRixLQUFLLEVBQUV0RSxhQUFBLENBQUF1RSxNQUFNLENBQUNNLE1BQU0sQ0FBQyxDQUFDO1FBQ3RCeU0sUUFBUSxFQUFFdFIsYUFBQSxDQUFBdUUsTUFBTSxDQUFDRyxLQUFLLENBQUMxRSxhQUFBLENBQUF1RSxNQUFNLENBQUNNLE1BQU0sQ0FBQyxDQUFDO01BQ3hDLENBQUM7SUFDSDtFQUNGLENBQUMsRUFDRCxPQUFPcEIsUUFBUSxFQUFFc0IsR0FBRyxFQUFFcEIsR0FBRyxLQUFLO0lBQzVCLE1BQU1vRSxNQUFNLEdBQUcsSUFBQTNILG9CQUFBLENBQUEyRCxzQkFBc0IsRUFBQyxDQUFDO0lBQ3ZDLElBQUksQ0FBQ2dFLE1BQU0sRUFBRTtNQUNYLE9BQU9wRSxHQUFHLENBQUN1QixXQUFXLENBQUM7UUFDckJDLFVBQVUsRUFBRSxHQUFHO1FBQ2YxRSxJQUFJLEVBQUU7TUFDUixDQUFDLENBQUM7SUFDSjtJQUNBLElBQUk7TUFDRixNQUFNO1FBQUU2RCxLQUFLO1FBQUVnTjtNQUFTLENBQUMsR0FBR3ZNLEdBQUcsQ0FBQ3RFLElBQTRDO01BQzVFLE1BQU04USxPQUFPLEdBQUduTixJQUFJLENBQUNzRyxHQUFHLENBQUMsQ0FBQztNQUMxQixNQUFNMUMsSUFBSSxHQUFHLE1BQU0sSUFBQTVILG9CQUFBLENBQUFvUixlQUFlLEVBQUN6SixNQUFNLEVBQUV6RCxLQUFLLEVBQUVnTixRQUFRLElBQUksS0FBSyxDQUFDO01BQ3BFLE1BQU1HLFFBQVEsR0FBR0MsS0FBSyxDQUFDQyxPQUFPLENBQUUzSixJQUFJLGFBQUpBLElBQUksdUJBQUpBLElBQUksQ0FBVTRKLE9BQU8sQ0FBQyxHQUNqRDVKLElBQUksQ0FBUzRKLE9BQU8sQ0FBQ25MLE1BQU0sR0FDNUIsQ0FBQztNQUNMLE9BQU85QyxHQUFHLENBQUNLLEVBQUUsQ0FBQztRQUNadkQsSUFBSSxFQUFFO1VBQ0osSUFBS3VILElBQUksSUFBZSxDQUFDLENBQUMsQ0FBQztVQUMzQjZKLGVBQWUsRUFBRXpOLElBQUksQ0FBQ3NHLEdBQUcsQ0FBQyxDQUFDLEdBQUc2RyxPQUFPO1VBQ3JDRTtRQUNGO01BQ0YsQ0FBQyxDQUFDO0lBQ0osQ0FBQyxDQUFDLE9BQU9uUixHQUFZLEVBQUU7TUFDckIsTUFBTTtRQUFFRSxNQUFNO1FBQUVDO01BQUssQ0FBQyxHQUFHSixXQUFXLENBQUNDLEdBQUcsQ0FBQztNQUN6QyxPQUFPcUQsR0FBRyxDQUFDdUIsV0FBVyxDQUFDO1FBQUVDLFVBQVUsRUFBRTNFLE1BQU07UUFBRUM7TUFBSyxDQUFDLENBQUM7SUFDdEQ7RUFDRixDQUNGLENBQUM7RUFFRDRDLE1BQU0sQ0FBQ0MsR0FBRyxDQUNSO0lBQ0VDLElBQUksRUFBRTtJQUNOQyxRQUFRLEVBQUU7TUFDUmMsS0FBSyxFQUFFdEUsYUFBQSxDQUFBdUUsTUFBTSxDQUFDQyxNQUFNLENBQUM7UUFDbkJvRSxHQUFHLEVBQUU1SSxhQUFBLENBQUF1RSxNQUFNLENBQUNHLEtBQUssQ0FBQzFFLGFBQUEsQ0FBQXVFLE1BQU0sQ0FBQ0ksTUFBTSxDQUFDLENBQUM7TUFDbkMsQ0FBQztJQUNIO0VBQ0YsQ0FBQyxFQUNELE9BQU9sQixRQUFRLEVBQUVzQixHQUFHLEVBQUVwQixHQUFHLEtBQUs7SUFDNUIsTUFBTW9FLE1BQU0sR0FBRyxJQUFBNUgsVUFBQSxDQUFBMEQsWUFBWSxFQUFDLENBQUM7SUFDN0IsSUFBSSxDQUFDa0UsTUFBTSxFQUFFO01BQ1gsT0FBT3BFLEdBQUcsQ0FBQ3VCLFdBQVcsQ0FBQztRQUFFQyxVQUFVLEVBQUUsR0FBRztRQUFFMUUsSUFBSSxFQUFFO01BQXNCLENBQUMsQ0FBQztJQUMxRTtJQUNBLElBQUk7TUFBQSxJQUFBcVIsS0FBQTtNQUNGLE1BQU1sSixHQUFHLElBQUFrSixLQUFBLEdBQUkvTSxHQUFHLENBQUNULEtBQUssQ0FBc0JzRSxHQUFHLGNBQUFrSixLQUFBLGNBQUFBLEtBQUEsR0FBSSxHQUFHO01BQ3RELE1BQU05SixJQUFJLEdBQUcsTUFBTSxJQUFBN0gsVUFBQSxDQUFBNFIsY0FBYyxFQUFDaEssTUFBTSxFQUFFYSxHQUFHLENBQUM7TUFDOUMsT0FBT2pGLEdBQUcsQ0FBQ0ssRUFBRSxDQUFDO1FBQUV2RCxJQUFJLEVBQUV1SDtNQUFLLENBQUMsQ0FBQztJQUMvQixDQUFDLENBQUMsT0FBTzFILEdBQVEsRUFBRTtNQUFBLElBQUEwUixjQUFBO01BQ2pCLE9BQU9yTyxHQUFHLENBQUN1QixXQUFXLENBQUM7UUFBRUMsVUFBVSxFQUFFLElBQUFoRixVQUFBLENBQUF5RyxjQUFjLEVBQUN0RyxHQUFHLENBQUM7UUFBRUcsSUFBSSxHQUFBdVIsY0FBQSxHQUFFMVIsR0FBRyxhQUFIQSxHQUFHLHVCQUFIQSxHQUFHLENBQUVJLE9BQU8sY0FBQXNSLGNBQUEsY0FBQUEsY0FBQSxHQUFJcFIsTUFBTSxDQUFDTixHQUFHO01BQUUsQ0FBQyxDQUFDO0lBQ2hHO0VBQ0YsQ0FDRixDQUFDO0VBRUQrQyxNQUFNLENBQUNDLEdBQUcsQ0FDUjtJQUNFQyxJQUFJLEVBQUU7SUFDTkMsUUFBUSxFQUFFO01BQ1JjLEtBQUssRUFBRXRFLGFBQUEsQ0FBQXVFLE1BQU0sQ0FBQ0MsTUFBTSxDQUFDO1FBQ25CQyxJQUFJLEVBQUV6RSxhQUFBLENBQUF1RSxNQUFNLENBQUNHLEtBQUssQ0FBQzFFLGFBQUEsQ0FBQXVFLE1BQU0sQ0FBQ0ksTUFBTSxDQUFDLENBQUM7TUFDcEMsQ0FBQztJQUNIO0VBQ0YsQ0FBQyxFQUNELE9BQU81QixPQUFPLEVBQUVnQyxHQUFHLEVBQUVwQixHQUFHLEtBQUs7SUFDM0IsSUFBSTtNQUFBLElBQUFzTyxLQUFBLEVBQUFDLFdBQUEsRUFBQUMsZUFBQTtNQUNGLE1BQU1qUCxNQUFNLEdBQUdKLFNBQVMsQ0FBQ0MsT0FBTyxDQUFDO01BQ2pDLE1BQU0wQixJQUFJLElBQUF3TixLQUFBLEdBQUlsTixHQUFHLENBQUNULEtBQUssQ0FBdUJHLElBQUksY0FBQXdOLEtBQUEsY0FBQUEsS0FBQSxHQUFJLEVBQUU7TUFDeEQsTUFBTTlLLFFBQVEsR0FBRyxNQUFNakUsTUFBTSxDQUFDa0UsTUFBTSxDQUFDO1FBQ25DQyxLQUFLLEVBQUVuSCxVQUFBLENBQUFrUyx3QkFBd0I7UUFDL0I3SyxrQkFBa0IsRUFBRSxJQUFJO1FBQ3hCOUcsSUFBSSxFQUFFO1VBQ0pnRSxJQUFJO1VBQ0ptQixJQUFJLEVBQUUsQ0FBQztZQUFFekIsU0FBUyxFQUFFO2NBQUVxRCxLQUFLLEVBQUU7WUFBTztVQUFFLENBQUMsQ0FBQztVQUN4Q2xELEtBQUssRUFBRTtZQUFFcUQsU0FBUyxFQUFFLENBQUM7VUFBRTtRQUN6QjtNQUNGLENBQUMsQ0FBQztNQUNGLE1BQU14QixJQUFJLElBQUErTCxXQUFBLElBQUFDLGVBQUEsR0FBSWhMLFFBQVEsQ0FBQzFHLElBQUksY0FBQTBSLGVBQUEsZ0JBQUFBLGVBQUEsR0FBZEEsZUFBQSxDQUF3QmhNLElBQUksY0FBQWdNLGVBQUEsdUJBQTVCQSxlQUFBLENBQThCaE0sSUFBSSxjQUFBK0wsV0FBQSxjQUFBQSxXQUFBLEdBQUksRUFBRTtNQUNyRCxPQUFPdk8sR0FBRyxDQUFDSyxFQUFFLENBQUM7UUFBRXZELElBQUksRUFBRTtVQUFFbU8sT0FBTyxFQUFFekksSUFBSSxDQUFDVixHQUFHLENBQUU2SCxDQUFNLElBQUtBLENBQUMsQ0FBQ2pILE9BQU87UUFBRTtNQUFFLENBQUMsQ0FBQztJQUN2RSxDQUFDLENBQUMsT0FBTy9GLEdBQVEsRUFBRTtNQUFBLElBQUErUixnQkFBQSxFQUFBQyxjQUFBO01BQ2pCLE9BQU8zTyxHQUFHLENBQUN1QixXQUFXLENBQUM7UUFDckJDLFVBQVUsR0FBQWtOLGdCQUFBLEdBQUUvUixHQUFHLENBQUM2RSxVQUFVLGNBQUFrTixnQkFBQSxjQUFBQSxnQkFBQSxHQUFJLEdBQUc7UUFDakM1UixJQUFJLEdBQUE2UixjQUFBLEdBQUVoUyxHQUFHLENBQUNJLE9BQU8sY0FBQTRSLGNBQUEsY0FBQUEsY0FBQSxHQUFJMVIsTUFBTSxDQUFDTixHQUFHO01BQ2pDLENBQUMsQ0FBQztJQUNKO0VBQ0YsQ0FDRixDQUFDO0VBRUQrQyxNQUFNLENBQUNnTyxJQUFJLENBQ1Q7SUFDRTlOLElBQUksRUFBRTtJQUNOQyxRQUFRLEVBQUU7TUFDUi9DLElBQUksRUFBRVQsYUFBQSxDQUFBdUUsTUFBTSxDQUFDQyxNQUFNLENBQUM7UUFDbEJDLElBQUksRUFBRXpFLGFBQUEsQ0FBQXVFLE1BQU0sQ0FBQ0csS0FBSyxDQUFDMUUsYUFBQSxDQUFBdUUsTUFBTSxDQUFDSSxNQUFNLENBQUMsQ0FBQyxDQUFDO1FBQ25DQyxJQUFJLEVBQUU1RSxhQUFBLENBQUF1RSxNQUFNLENBQUNHLEtBQUssQ0FBQzFFLGFBQUEsQ0FBQXVFLE1BQU0sQ0FBQ0ksTUFBTSxDQUFDLENBQUMsQ0FBQztRQUNuQzROLFNBQVMsRUFBRXZTLGFBQUEsQ0FBQXVFLE1BQU0sQ0FBQ0csS0FBSyxDQUFDMUUsYUFBQSxDQUFBdUUsTUFBTSxDQUFDTSxNQUFNLENBQUMsQ0FBQyxDQUFDO1FBQ3hDMk4sT0FBTyxFQUFFeFMsYUFBQSxDQUFBdUUsTUFBTSxDQUFDRyxLQUFLLENBQUMxRSxhQUFBLENBQUF1RSxNQUFNLENBQUNNLE1BQU0sQ0FBQyxDQUFDLENBQUM7UUFDdEM0Tix3QkFBd0IsRUFBRXpTLGFBQUEsQ0FBQXVFLE1BQU0sQ0FBQ0csS0FBSyxDQUFDMUUsYUFBQSxDQUFBdUUsTUFBTSxDQUFDbU8sT0FBTyxDQUFDLENBQUM7TUFDekQsQ0FBQztJQUNIO0VBQ0YsQ0FBQyxFQUNELE9BQU8zUCxPQUFPLEVBQUVnQyxHQUFHLEVBQUVwQixHQUFHLEtBQUs7SUFDM0IsSUFBSTtNQUFBLElBQUFnUCxXQUFBLEVBQUFDLG9CQUFBLEVBQUFDLEtBQUEsRUFBQUMsa0JBQUEsRUFBQUMsbUJBQUEsRUFBQUMsb0JBQUE7TUFDRixNQUFNOVAsTUFBTSxHQUFHSixTQUFTLENBQUNDLE9BQU8sQ0FBQztNQUNqQyxNQUFNO1FBQ0owQixJQUFJLEdBQUcsRUFBRTtRQUNURyxJQUFJLEdBQUcsQ0FBQztRQUNSMk4sU0FBUztRQUNUQyxPQUFPO1FBQ1BDLHdCQUF3QixHQUFHO01BQzdCLENBQUMsR0FBRzFOLEdBQUcsQ0FBQ3RFLElBQUk7TUFFWixNQUFNaUssR0FBRyxHQUFHLElBQUl0RyxJQUFJLENBQUMsQ0FBQztNQUN0QixNQUFNNk8sU0FBUyxHQUFHdkksR0FBRyxDQUFDckcsV0FBVyxDQUFDLENBQUM7TUFDbkMsTUFBTTZPLFdBQVcsR0FBRyxJQUFJOU8sSUFBSSxDQUFDc0csR0FBRyxDQUFDMUUsT0FBTyxDQUFDLENBQUMsR0FBRyxDQUFDLEdBQUcsRUFBRSxHQUFHLEVBQUUsR0FBRyxFQUFFLEdBQUcsSUFBSSxDQUFDLENBQUMzQixXQUFXLENBQUMsQ0FBQztNQUNuRixNQUFNOE8sT0FBTyxHQUFHWixTQUFTLElBQUlXLFdBQVc7TUFDeEMsTUFBTUUsT0FBTyxHQUFHWixPQUFPLElBQUlTLFNBQVM7TUFDcEMsTUFBTUksZUFBZSxHQUFHO1FBQUVwRyxLQUFLLEVBQUU7VUFBRTlJLFNBQVMsRUFBRTtZQUFFbVAsR0FBRyxFQUFFSCxPQUFPO1lBQUVJLEdBQUcsRUFBRUg7VUFBUTtRQUFFO01BQUUsQ0FBQztNQUVoRixJQUFJSSxlQUFnQyxHQUFHLElBQUk7TUFDM0MsTUFBTUMsZUFBdUMsR0FBRyxDQUFDLENBQUM7TUFFbEQsSUFBSWhCLHdCQUF3QixFQUFFO1FBQUEsSUFBQWlCLFdBQUEsRUFBQUMsaUJBQUE7UUFDNUIsTUFBTUMsV0FBVyxHQUFHLE1BQU0xUSxNQUFNLENBQUNrRSxNQUFNLENBQUM7VUFDdENDLEtBQUssRUFBRW5ILFVBQUEsQ0FBQThNLCtCQUErQjtVQUN0Q3pGLGtCQUFrQixFQUFFLElBQUk7VUFDeEI5RyxJQUFJLEVBQUU7WUFDSmdFLElBQUksRUFBRSxJQUFJO1lBQ1Y0QixPQUFPLEVBQUUsQ0FBQyxnQkFBZ0IsRUFBRSxxQkFBcUIsRUFBRSxtQkFBbUIsQ0FBQztZQUN2RS9CLEtBQUssRUFBRTtjQUFFcUQsU0FBUyxFQUFFLENBQUM7WUFBRTtVQUN6QjtRQUNGLENBQUMsQ0FBQztRQUNGLE1BQU1rTSxZQUFZLElBQUFILFdBQUEsSUFBQUMsaUJBQUEsR0FBSUMsV0FBVyxDQUFDblQsSUFBSSxjQUFBa1QsaUJBQUEsZ0JBQUFBLGlCQUFBLEdBQWpCQSxpQkFBQSxDQUEyQnhOLElBQUksY0FBQXdOLGlCQUFBLHVCQUEvQkEsaUJBQUEsQ0FBaUN4TixJQUFJLGNBQUF1TixXQUFBLGNBQUFBLFdBQUEsR0FBSSxFQUFFO1FBQ2hFRixlQUFlLEdBQUdLLFlBQVksQ0FDM0JwTyxHQUFHLENBQUU2SCxDQUFNO1VBQUEsSUFBQXdHLFVBQUE7VUFBQSxRQUFBQSxVQUFBLEdBQUt4RyxDQUFDLENBQUNqSCxPQUFPLGNBQUF5TixVQUFBLHVCQUFUQSxVQUFBLENBQVdDLGNBQWM7UUFBQSxFQUFDLENBQzFDck8sTUFBTSxDQUFFeEUsRUFBVSxJQUFLQSxFQUFFLElBQUlBLEVBQUUsS0FBSyxLQUFLLENBQUM7UUFDN0MsSUFBSXNTLGVBQWUsQ0FBQy9NLE1BQU0sS0FBSyxDQUFDLEVBQUU7VUFDaEMsT0FBTzlDLEdBQUcsQ0FBQ0ssRUFBRSxDQUFDO1lBQ1p2RCxJQUFJLEVBQUU7Y0FDSnVULE1BQU0sRUFBRSxFQUFFO2NBQ1ZDLFdBQVcsRUFBRSxDQUFDLENBQUM7Y0FDZjFOLEtBQUssRUFBRSxDQUFDO2NBQ1IyTixjQUFjLEVBQUU7WUFDbEI7VUFDRixDQUFDLENBQUM7UUFDSjtRQUNBTCxZQUFZLENBQUN2RixPQUFPLENBQUVoQixDQUFNLElBQUs7VUFDL0IsTUFBTTZHLENBQUMsR0FBRzdHLENBQUMsQ0FBQ2pILE9BQU87VUFDbkIsSUFBSThOLENBQUMsYUFBREEsQ0FBQyxlQUFEQSxDQUFDLENBQUVKLGNBQWMsRUFBRU4sZUFBZSxDQUFDVSxDQUFDLENBQUNKLGNBQWMsQ0FBQyxHQUFHSSxDQUFDLENBQUNDLG1CQUFtQjtRQUNsRixDQUFDLENBQUM7TUFDSjtNQUVBLE1BQU1wTixJQUFXLEdBQUcsQ0FBQ3FNLGVBQWUsQ0FBQztNQUNyQ3JNLElBQUksQ0FBQ0MsSUFBSSxDQUFDO1FBQUVTLElBQUksRUFBRTtVQUFFMk0sUUFBUSxFQUFFLENBQUM7WUFBRW5OLElBQUksRUFBRTtjQUFFLFVBQVUsRUFBRTtZQUFNO1VBQUUsQ0FBQztRQUFFO01BQUUsQ0FBQyxDQUFDO01BQ3BFLElBQUlzTSxlQUFlLElBQUlBLGVBQWUsQ0FBQy9NLE1BQU0sR0FBRyxDQUFDLEVBQUU7UUFDakRPLElBQUksQ0FBQ0MsSUFBSSxDQUFDO1VBQUU4RCxLQUFLLEVBQUU7WUFBRSxVQUFVLEVBQUV5STtVQUFnQjtRQUFFLENBQUMsQ0FBQztNQUN2RDtNQUVBLE1BQU1jLFVBQVUsR0FBRztRQUNqQjFQLElBQUk7UUFDSkgsSUFBSTtRQUNKbUIsSUFBSSxFQUFFLENBQUM7VUFBRXpCLFNBQVMsRUFBRTtZQUFFcUQsS0FBSyxFQUFFO1VBQU87UUFBRSxDQUFDLENBQUM7UUFDeENuQixPQUFPLEVBQUUsQ0FBQyxVQUFVLEVBQUUsWUFBWSxFQUFFLGtCQUFrQixFQUFFLFlBQVksRUFBRSxXQUFXLENBQUM7UUFDbEYvQixLQUFLLEVBQUU7VUFBRW9ELElBQUksRUFBRTtZQUFFVjtVQUFLO1FBQUU7TUFDMUIsQ0FBQztNQUVELE1BQU0sQ0FBQ3VOLGNBQWMsRUFBRUMsYUFBYSxDQUFDLEdBQUcsTUFBTTlILE9BQU8sQ0FBQ0MsR0FBRyxDQUFDLENBQ3hEekosTUFBTSxDQUFDa0UsTUFBTSxDQUFDO1FBQ1pDLEtBQUssRUFBRW5ILFVBQUEsQ0FBQXVVLG9CQUFvQjtRQUMzQmxOLGtCQUFrQixFQUFFLElBQUk7UUFDeEI5RyxJQUFJLEVBQUU2VDtNQUNSLENBQUMsQ0FBQyxFQUNGcFIsTUFBTSxDQUFDa0UsTUFBTSxDQUFDO1FBQ1pDLEtBQUssRUFBRW5ILFVBQUEsQ0FBQXVVLG9CQUFvQjtRQUMzQmxOLGtCQUFrQixFQUFFLElBQUk7UUFDeEI5RyxJQUFJLEVBQUU7VUFDSmdFLElBQUksRUFBRSxDQUFDO1VBQ1BILEtBQUssRUFBRWdRLFVBQVUsQ0FBQ2hRLEtBQUs7VUFDdkJzRyxnQkFBZ0IsRUFBRTtRQUNwQjtNQUNGLENBQUMsQ0FBQyxDQUNILENBQUM7TUFFRixNQUFNOEosU0FBUyxJQUFBL0IsV0FBQSxJQUFBQyxvQkFBQSxHQUFJMkIsY0FBYyxDQUFDOVQsSUFBSSxjQUFBbVMsb0JBQUEsZ0JBQUFBLG9CQUFBLEdBQXBCQSxvQkFBQSxDQUE4QnpNLElBQUksY0FBQXlNLG9CQUFBLHVCQUFsQ0Esb0JBQUEsQ0FBb0N6TSxJQUFJLGNBQUF3TSxXQUFBLGNBQUFBLFdBQUEsR0FBSSxFQUFFO01BQ2hFLE1BQU1wTSxLQUFLLElBQUFzTSxLQUFBLElBQUFDLGtCQUFBLElBQUFDLG1CQUFBLEdBQ1J5QixhQUFhLENBQUMvVCxJQUFJLGNBQUFzUyxtQkFBQSxnQkFBQUEsbUJBQUEsR0FBbkJBLG1CQUFBLENBQTZCNU0sSUFBSSxjQUFBNE0sbUJBQUEsZ0JBQUFBLG1CQUFBLEdBQWpDQSxtQkFBQSxDQUFtQ3hNLEtBQUssY0FBQXdNLG1CQUFBLHVCQUF4Q0EsbUJBQUEsQ0FBMEN2TSxLQUFLLGNBQUFzTSxrQkFBQSxjQUFBQSxrQkFBQSxJQUFBRSxvQkFBQSxHQUM5Q3dCLGFBQWEsQ0FBQy9ULElBQUksY0FBQXVTLG9CQUFBLGdCQUFBQSxvQkFBQSxHQUFuQkEsb0JBQUEsQ0FBNkI3TSxJQUFJLGNBQUE2TSxvQkFBQSx1QkFBakNBLG9CQUFBLENBQW1Dek0sS0FBSyxjQUFBc00sS0FBQSxjQUFBQSxLQUFBLEdBQ3hDNkIsU0FBUyxDQUFDak8sTUFBTTtNQUVsQixNQUFNd04sV0FBNkQsR0FBRyxDQUFDLENBQUM7TUFDeEVTLFNBQVMsQ0FBQ3BHLE9BQU8sQ0FBRWhCLENBQU0sSUFBSztRQUFBLElBQUFxSCxXQUFBO1FBQzVCLE1BQU1DLEdBQUcsSUFBQUQsV0FBQSxHQUFHckgsQ0FBQyxDQUFDakgsT0FBTyxjQUFBc08sV0FBQSxnQkFBQUEsV0FBQSxHQUFUQSxXQUFBLENBQVdFLEtBQUssY0FBQUYsV0FBQSx1QkFBaEJBLFdBQUEsQ0FBa0J6VCxFQUFFO1FBQ2hDLElBQUkwVCxHQUFHLElBQUluQixlQUFlLENBQUNtQixHQUFHLENBQUMsRUFBRTtVQUMvQlgsV0FBVyxDQUFDM0csQ0FBQyxDQUFDaEgsR0FBRyxDQUFDLEdBQUc7WUFBRThOLG1CQUFtQixFQUFFWCxlQUFlLENBQUNtQixHQUFHO1VBQUUsQ0FBQztRQUNwRTtNQUNGLENBQUMsQ0FBQztNQUVGLE9BQU9qUixHQUFHLENBQUNLLEVBQUUsQ0FBQztRQUNadkQsSUFBSSxFQUFFO1VBQ0p1VCxNQUFNLEVBQUVVLFNBQVMsQ0FBQ2pQLEdBQUcsQ0FBRTZILENBQU0sS0FBTTtZQUNqQ3BNLEVBQUUsRUFBRW9NLENBQUMsQ0FBQ2hILEdBQUc7WUFDVCxHQUFHZ0gsQ0FBQyxDQUFDakg7VUFDUCxDQUFDLENBQUMsQ0FBQztVQUNINE4sV0FBVztVQUNYMU4sS0FBSztVQUNMMk4sY0FBYyxFQUFFdkYsTUFBTSxDQUFDbUcsSUFBSSxDQUFDckIsZUFBZSxDQUFDLENBQUNoTjtRQUMvQztNQUNGLENBQUMsQ0FBQztJQUNKLENBQUMsQ0FBQyxPQUFPbkcsR0FBUSxFQUFFO01BQUEsSUFBQXlVLGdCQUFBLEVBQUFDLGNBQUE7TUFDakIsT0FBT3JSLEdBQUcsQ0FBQ3VCLFdBQVcsQ0FBQztRQUNyQkMsVUFBVSxHQUFBNFAsZ0JBQUEsR0FBRXpVLEdBQUcsQ0FBQzZFLFVBQVUsY0FBQTRQLGdCQUFBLGNBQUFBLGdCQUFBLEdBQUksR0FBRztRQUNqQ3RVLElBQUksR0FBQXVVLGNBQUEsR0FBRTFVLEdBQUcsQ0FBQ0ksT0FBTyxjQUFBc1UsY0FBQSxjQUFBQSxjQUFBLEdBQUlwVSxNQUFNLENBQUNOLEdBQUc7TUFDakMsQ0FBQyxDQUFDO0lBQ0o7RUFDRixDQUNGLENBQUM7QUFDSCJ9