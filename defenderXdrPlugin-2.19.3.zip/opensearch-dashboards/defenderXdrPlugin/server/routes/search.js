"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.registerDefenderSearchRoutes = registerDefenderSearchRoutes;
var _configSchema = require("@osd/config-schema");
var _constants = require("../../common/constants");
var _mdeClient = require("../lib/mde-client");
var _graphSecurityClient = require("../lib/graph-security-client");
/*
 * Defender plugin — OpenSearch reads + Graph/MDE proxies
 */

function mapGraphErr(err) {
  if (err instanceof _graphSecurityClient.GraphApiError) {
    return {
      status: err.status >= 400 && err.status < 600 ? err.status : 502,
      body: err.message
    };
  }
  return {
    status: 502,
    body: err instanceof Error ? err.message : String(err)
  };
}
function normalizeMdeMachine(m, tenantId) {
  return {
    tenant_id: tenantId,
    machine_id: m.id,
    computer_dns_name: m.computerDnsName || '',
    os_platform: m.osPlatform || '',
    os_version: m.osVersion || '',
    last_seen: m.lastSeen || null,
    first_seen: m.firstSeen || null,
    aad_device_id: m.aadDeviceId || '',
    risk_score: m.riskScore != null ? String(m.riskScore) : '',
    exposure_level: m.exposureLevel || '',
    onboarding_status: m.onboardingStatus || m.onboardingstatus || '',
    health_status: m.healthStatus || '',
    isolation_status: m.isolationStatus || '',
    last_ip_address: m.lastIpAddress || '',
    rbac_group_name: m.rbacGroupName || ''
  };
}
function getClient(context) {
  return context.core.opensearch.client.asCurrentUser;
}
function registerDefenderSearchRoutes(router) {
  router.get({
    path: '/api/defender_xdr/health',
    validate: false
  }, async (_context, _req, res) => {
    const mde = !!(0, _mdeClient.getMdeConfig)();
    const graph = !!(0, _graphSecurityClient.getGraphSecurityConfig)();
    const smtp_host = process.env.SMTP_HOST || null;
    const smtp_user = process.env.SMTP_USER || null;
    const smtp_port = process.env.SMTP_PORT || '587';
    const otp_recipient_email = process.env.OTP_RECIPIENT_EMAIL || null;
    const smtp_configured = !!(smtp_host && otp_recipient_email);
    return res.ok({
      body: {
        ok: mde || graph,
        mde_configured: mde,
        graph_security_configured: graph,
        smtp_configured,
        otp_dev_mode: !smtp_configured,
        smtp_host,
        smtp_user,
        smtp_port,
        otp_recipient_email,
        timestamp: new Date().toISOString()
      }
    });
  });
  router.get({
    path: '/api/defender_xdr/machines',
    validate: {
      query: _configSchema.schema.object({
        size: _configSchema.schema.maybe(_configSchema.schema.number()),
        from: _configSchema.schema.maybe(_configSchema.schema.number()),
        os_platform: _configSchema.schema.maybe(_configSchema.schema.string()),
        exposure_level: _configSchema.schema.maybe(_configSchema.schema.string()),
        source: _configSchema.schema.maybe(_configSchema.schema.string())
      })
    }
  }, async (context, req, res) => {
    const q = req.query;
    if (q.source === 'live') {
      const mcfg = (0, _mdeClient.getMdeConfig)();
      if (!mcfg) {
        return res.customError({
          statusCode: 503,
          body: 'MDE not configured.'
        });
      }
      try {
        var _q$from, _q$size;
        const raw = await (0, _mdeClient.fetchAllMachinesLimited)(mcfg, 15);
        const tenantId = mcfg.tenantId;
        let rows = raw.map(m => normalizeMdeMachine(m, tenantId));
        if (q.os_platform) {
          rows = rows.filter(r => String(r.os_platform) === q.os_platform);
        }
        if (q.exposure_level) {
          rows = rows.filter(r => String(r.exposure_level) === q.exposure_level);
        }
        rows.sort((a, b) => {
          const ta = a.last_seen ? new Date(String(a.last_seen)).getTime() : 0;
          const tb = b.last_seen ? new Date(String(b.last_seen)).getTime() : 0;
          return tb - ta;
        });
        const from = (_q$from = q.from) !== null && _q$from !== void 0 ? _q$from : 0;
        const size = (_q$size = q.size) !== null && _q$size !== void 0 ? _q$size : 50;
        const slice = rows.slice(from, from + size);
        const hits = slice.map(src => ({
          _source: src,
          _id: src.machine_id
        }));
        return res.ok({
          body: {
            hits,
            total: {
              value: rows.length,
              relation: 'eq'
            },
            source: 'mde'
          }
        });
      } catch (err) {
        var _err$message;
        return res.customError({
          statusCode: (0, _mdeClient.mdeErrorStatus)(err),
          body: (_err$message = err === null || err === void 0 ? void 0 : err.message) !== null && _err$message !== void 0 ? _err$message : String(err)
        });
      }
    }
    try {
      var _hits, _response$body, _hits$hits;
      const client = getClient(context);
      const {
        size = 50,
        from = 0,
        os_platform,
        exposure_level
      } = q;
      const must = [];
      if (os_platform) must.push({
        term: {
          os_platform
        }
      });
      if (exposure_level) must.push({
        term: {
          exposure_level
        }
      });
      const response = await client.search({
        index: _constants.DEFENDER_MACHINES_INDEX,
        ignore_unavailable: true,
        body: {
          size,
          from,
          sort: [{
            last_seen: {
              order: 'desc',
              missing: '_last'
            }
          }, {
            computer_dns_name: 'asc'
          }],
          query: must.length ? {
            bool: {
              must
            }
          } : {
            match_all: {}
          }
        }
      });
      const hits = (_hits = (_response$body = response.body) === null || _response$body === void 0 ? void 0 : _response$body.hits) !== null && _hits !== void 0 ? _hits : {};
      return res.ok({
        body: {
          hits: (_hits$hits = hits.hits) !== null && _hits$hits !== void 0 ? _hits$hits : [],
          total: hits.total,
          source: 'index'
        }
      });
    } catch (err) {
      var _err$statusCode, _err$message2;
      return res.customError({
        statusCode: (_err$statusCode = err.statusCode) !== null && _err$statusCode !== void 0 ? _err$statusCode : 500,
        body: (_err$message2 = err.message) !== null && _err$message2 !== void 0 ? _err$message2 : String(err)
      });
    }
  });
  router.get({
    path: '/api/defender_xdr/machines/{id}/live',
    validate: {
      params: _configSchema.schema.object({
        id: _configSchema.schema.string()
      })
    }
  }, async (_context, _req, res) => {
    const config = (0, _mdeClient.getMdeConfig)();
    if (!config) {
      return res.customError({
        statusCode: 503,
        body: 'Defender MDE not configured (DEFENDER_TENANT_ID, DEFENDER_CLIENT_ID, DEFENDER_CLIENT_SECRET).'
      });
    }
    try {
      const id = _req.params.id;
      const data = await (0, _mdeClient.getMachine)(config, id);
      return res.ok({
        body: data
      });
    } catch (err) {
      var _err$message3;
      return res.customError({
        statusCode: (0, _mdeClient.mdeErrorStatus)(err),
        body: (_err$message3 = err === null || err === void 0 ? void 0 : err.message) !== null && _err$message3 !== void 0 ? _err$message3 : String(err)
      });
    }
  });
  const mdeMachineSub = (pathSuffix, fn) => {
    router.get({
      path: `/api/defender_xdr/machines/{id}/live/${pathSuffix}`,
      validate: {
        params: _configSchema.schema.object({
          id: _configSchema.schema.string()
        })
      }
    }, async (_context, req, res) => {
      const mcfg = (0, _mdeClient.getMdeConfig)();
      if (!mcfg) {
        return res.customError({
          statusCode: 503,
          body: 'MDE not configured.'
        });
      }
      try {
        const id = req.params.id;
        const data = await fn(mcfg, id);
        return res.ok({
          body: data
        });
      } catch (err) {
        var _err$message4;
        return res.customError({
          statusCode: (0, _mdeClient.mdeErrorStatus)(err),
          body: (_err$message4 = err === null || err === void 0 ? void 0 : err.message) !== null && _err$message4 !== void 0 ? _err$message4 : String(err)
        });
      }
    });
  };
  mdeMachineSub('recommendations', _mdeClient.getMachineRecommendations);
  mdeMachineSub('vulnerabilities', _mdeClient.getMachineVulnerabilities);
  mdeMachineSub('alerts', _mdeClient.getMachineAlerts);
  mdeMachineSub('logonusers', _mdeClient.getMachineLogonUsers);
  mdeMachineSub('software', _mdeClient.getMachineSoftware);
  router.get({
    path: '/api/defender_xdr/mde/vulnerabilities',
    validate: {
      query: _configSchema.schema.object({
        top: _configSchema.schema.maybe(_configSchema.schema.number())
      })
    }
  }, async (_context, req, res) => {
    const mcfg = (0, _mdeClient.getMdeConfig)();
    if (!mcfg) return res.customError({
      statusCode: 503,
      body: 'MDE not configured.'
    });
    try {
      var _top;
      const top = (_top = req.query.top) !== null && _top !== void 0 ? _top : 200;
      const data = await (0, _mdeClient.listOrgVulnerabilities)(mcfg, top);
      return res.ok({
        body: data
      });
    } catch (err) {
      var _err$message5;
      return res.customError({
        statusCode: (0, _mdeClient.mdeErrorStatus)(err),
        body: (_err$message5 = err === null || err === void 0 ? void 0 : err.message) !== null && _err$message5 !== void 0 ? _err$message5 : String(err)
      });
    }
  });
  router.get({
    path: '/api/defender_xdr/mde/alerts-legacy',
    validate: {
      query: _configSchema.schema.object({
        top: _configSchema.schema.maybe(_configSchema.schema.number())
      })
    }
  }, async (_context, req, res) => {
    const mcfg = (0, _mdeClient.getMdeConfig)();
    if (!mcfg) return res.customError({
      statusCode: 503,
      body: 'MDE not configured.'
    });
    try {
      var _top2;
      const top = (_top2 = req.query.top) !== null && _top2 !== void 0 ? _top2 : 100;
      const data = await (0, _mdeClient.listLegacyAlerts)(mcfg, top);
      return res.ok({
        body: data
      });
    } catch (err) {
      var _err$message6;
      return res.customError({
        statusCode: (0, _mdeClient.mdeErrorStatus)(err),
        body: (_err$message6 = err === null || err === void 0 ? void 0 : err.message) !== null && _err$message6 !== void 0 ? _err$message6 : String(err)
      });
    }
  });
  router.get({
    path: '/api/defender_xdr/mde/machineactions',
    validate: {
      query: _configSchema.schema.object({
        top: _configSchema.schema.maybe(_configSchema.schema.number())
      })
    }
  }, async (_context, req, res) => {
    const mcfg = (0, _mdeClient.getMdeConfig)();
    if (!mcfg) return res.customError({
      statusCode: 503,
      body: 'MDE not configured.'
    });
    try {
      var _top3;
      const top = (_top3 = req.query.top) !== null && _top3 !== void 0 ? _top3 : 100;
      const data = await (0, _mdeClient.listMachineActions)(mcfg, top);
      return res.ok({
        body: data
      });
    } catch (err) {
      var _err$message7;
      return res.customError({
        statusCode: (0, _mdeClient.mdeErrorStatus)(err),
        body: (_err$message7 = err === null || err === void 0 ? void 0 : err.message) !== null && _err$message7 !== void 0 ? _err$message7 : String(err)
      });
    }
  });
  router.get({
    path: '/api/defender_xdr/mde/machineactions/{actionId}/package-uri',
    validate: {
      params: _configSchema.schema.object({
        actionId: _configSchema.schema.string()
      })
    }
  }, async (_context, req, res) => {
    const mcfg = (0, _mdeClient.getMdeConfig)();
    if (!mcfg) return res.customError({
      statusCode: 503,
      body: 'MDE not configured.'
    });
    try {
      const actionId = req.params.actionId;
      const data = await (0, _mdeClient.getMachineActionPackageUri)(mcfg, actionId);
      return res.ok({
        body: data
      });
    } catch (err) {
      var _err$message8;
      return res.customError({
        statusCode: (0, _mdeClient.mdeErrorStatus)(err),
        body: (_err$message8 = err === null || err === void 0 ? void 0 : err.message) !== null && _err$message8 !== void 0 ? _err$message8 : String(err)
      });
    }
  });
  router.get({
    path: '/api/defender_xdr/overview',
    validate: false
  }, async (context, _req, res) => {
    try {
      var _hits2, _machinesRes$body, _aggregations, _machinesRes$body2, _hitsBody$hits, _hitsBody$total$value, _hitsBody$total, _hitsBody$total2, _aggs$by_os$buckets, _aggs$by_os, _aggs$by_exposure$buc, _aggs$by_exposure, _aggs$by_health$bucke, _aggs$by_health, _aggs$by_risk$buckets, _aggs$by_risk;
      const client = getClient(context);
      const staleDate = new Date(Date.now() - 7 * 24 * 60 * 60 * 1000).toISOString();
      const machinesRes = await client.search({
        index: _constants.DEFENDER_MACHINES_INDEX,
        ignore_unavailable: true,
        body: {
          size: 8,
          track_total_hits: true,
          sort: [{
            last_seen: {
              order: 'desc',
              missing: '_last'
            }
          }],
          query: {
            match_all: {}
          },
          aggs: {
            by_os: {
              terms: {
                field: 'os_platform',
                size: 15
              }
            },
            by_exposure: {
              terms: {
                field: 'exposure_level',
                size: 10
              }
            },
            by_health: {
              terms: {
                field: 'health_status',
                size: 10
              }
            },
            by_risk: {
              terms: {
                field: 'risk_score',
                size: 15
              }
            }
          }
        }
      });
      let incidentsCount = 0;
      let alertsCount = 0;
      let vulnCount = 0;
      let linkedAgents = 0;
      let staleCount = 0;
      try {
        var _count, _ic$body, _count2, _ac$body, _count3, _vc$body, _count4, _idRes$body, _ref, _hits$total$value, _staleRes$body, _staleRes$body2;
        const [ic, ac, vc, idRes, staleRes] = await Promise.all([client.count({
          index: _constants.DEFENDER_INCIDENTS_INDEX,
          ignore_unavailable: true
        }), client.count({
          index: _constants.DEFENDER_ALERTS_INDEX,
          ignore_unavailable: true
        }), client.count({
          index: _constants.DEFENDER_VULNERABILITIES_INDEX,
          ignore_unavailable: true
        }), client.count({
          index: _constants.DEFENDER_MACHINE_IDENTITY_INDEX,
          ignore_unavailable: true
        }), client.search({
          index: _constants.DEFENDER_MACHINES_INDEX,
          ignore_unavailable: true,
          body: {
            size: 0,
            query: {
              bool: {
                filter: [{
                  range: {
                    last_seen: {
                      lt: staleDate
                    }
                  }
                }]
              }
            },
            track_total_hits: true
          }
        })]);
        incidentsCount = (_count = (_ic$body = ic.body) === null || _ic$body === void 0 ? void 0 : _ic$body.count) !== null && _count !== void 0 ? _count : 0;
        alertsCount = (_count2 = (_ac$body = ac.body) === null || _ac$body === void 0 ? void 0 : _ac$body.count) !== null && _count2 !== void 0 ? _count2 : 0;
        vulnCount = (_count3 = (_vc$body = vc.body) === null || _vc$body === void 0 ? void 0 : _vc$body.count) !== null && _count3 !== void 0 ? _count3 : 0;
        linkedAgents = (_count4 = (_idRes$body = idRes.body) === null || _idRes$body === void 0 ? void 0 : _idRes$body.count) !== null && _count4 !== void 0 ? _count4 : 0;
        staleCount = (_ref = (_hits$total$value = (_staleRes$body = staleRes.body) === null || _staleRes$body === void 0 || (_staleRes$body = _staleRes$body.hits) === null || _staleRes$body === void 0 || (_staleRes$body = _staleRes$body.total) === null || _staleRes$body === void 0 ? void 0 : _staleRes$body.value) !== null && _hits$total$value !== void 0 ? _hits$total$value : (_staleRes$body2 = staleRes.body) === null || _staleRes$body2 === void 0 || (_staleRes$body2 = _staleRes$body2.hits) === null || _staleRes$body2 === void 0 ? void 0 : _staleRes$body2.total) !== null && _ref !== void 0 ? _ref : 0;
      } catch {
        /* optional indices */
      }
      const hitsBody = (_hits2 = (_machinesRes$body = machinesRes.body) === null || _machinesRes$body === void 0 ? void 0 : _machinesRes$body.hits) !== null && _hits2 !== void 0 ? _hits2 : {};
      const aggs = (_aggregations = (_machinesRes$body2 = machinesRes.body) === null || _machinesRes$body2 === void 0 ? void 0 : _machinesRes$body2.aggregations) !== null && _aggregations !== void 0 ? _aggregations : {};
      const recent_machines = ((_hitsBody$hits = hitsBody.hits) !== null && _hitsBody$hits !== void 0 ? _hitsBody$hits : []).map(h => h._source).filter(Boolean);
      const totalMachines = typeof hitsBody.total === 'object' ? (_hitsBody$total$value = (_hitsBody$total = hitsBody.total) === null || _hitsBody$total === void 0 ? void 0 : _hitsBody$total.value) !== null && _hitsBody$total$value !== void 0 ? _hitsBody$total$value : 0 : (_hitsBody$total2 = hitsBody.total) !== null && _hitsBody$total2 !== void 0 ? _hitsBody$total2 : recent_machines.length;
      let byOsBuckets = (_aggs$by_os$buckets = (_aggs$by_os = aggs.by_os) === null || _aggs$by_os === void 0 ? void 0 : _aggs$by_os.buckets) !== null && _aggs$by_os$buckets !== void 0 ? _aggs$by_os$buckets : [];
      let byExposureBuckets = (_aggs$by_exposure$buc = (_aggs$by_exposure = aggs.by_exposure) === null || _aggs$by_exposure === void 0 ? void 0 : _aggs$by_exposure.buckets) !== null && _aggs$by_exposure$buc !== void 0 ? _aggs$by_exposure$buc : [];
      let byHealthBuckets = (_aggs$by_health$bucke = (_aggs$by_health = aggs.by_health) === null || _aggs$by_health === void 0 ? void 0 : _aggs$by_health.buckets) !== null && _aggs$by_health$bucke !== void 0 ? _aggs$by_health$bucke : [];
      let byRiskBuckets = (_aggs$by_risk$buckets = (_aggs$by_risk = aggs.by_risk) === null || _aggs$by_risk === void 0 ? void 0 : _aggs$by_risk.buckets) !== null && _aggs$by_risk$buckets !== void 0 ? _aggs$by_risk$buckets : [];
      let recentList = recent_machines;
      let total = totalMachines;
      let dataSource = 'index';
      const mcfg = (0, _mdeClient.getMdeConfig)();
      if (total === 0 && mcfg) {
        try {
          const raw = await (0, _mdeClient.fetchAllMachinesLimited)(mcfg, 10);
          const tid = mcfg.tenantId;
          const normalized = raw.map(m => normalizeMdeMachine(m, tid));
          if (normalized.length > 0) {
            dataSource = 'mde';
            total = normalized.length;
            recentList = normalized.slice().sort((a, b) => {
              const ta = a.last_seen ? new Date(String(a.last_seen)).getTime() : 0;
              const tb = b.last_seen ? new Date(String(b.last_seen)).getTime() : 0;
              return tb - ta;
            }).slice(0, 10);
            const osMap = {};
            const exMap = {};
            const healthMap = {};
            const riskMap = {};
            normalized.forEach(r => {
              const os = String(r.os_platform || 'Unknown');
              osMap[os] = (osMap[os] || 0) + 1;
              const ex = String(r.exposure_level || 'unknown');
              exMap[ex] = (exMap[ex] || 0) + 1;
              const hs = String(r.health_status || 'unknown');
              healthMap[hs] = (healthMap[hs] || 0) + 1;
              const rs = String(r.risk_score || 'unknown');
              riskMap[rs] = (riskMap[rs] || 0) + 1;
            });
            byOsBuckets = Object.entries(osMap).map(([key, doc_count]) => ({
              key,
              doc_count
            }));
            byExposureBuckets = Object.entries(exMap).map(([key, doc_count]) => ({
              key,
              doc_count
            }));
            byHealthBuckets = Object.entries(healthMap).map(([key, doc_count]) => ({
              key,
              doc_count
            }));
            byRiskBuckets = Object.entries(riskMap).map(([key, doc_count]) => ({
              key,
              doc_count
            }));
            staleCount = normalized.filter(r => !r.last_seen || new Date(String(r.last_seen)) < new Date(staleDate)).length;
          }
        } catch {
          /* keep index empty state */
        }
      }
      let liveIncidentsCount = null;
      let liveAlertsCount = null;
      let graphError = null;
      const gcfg = (0, _graphSecurityClient.getGraphSecurityConfig)();
      if (gcfg) {
        try {
          liveIncidentsCount = await (0, _graphSecurityClient.countSecurityCollection)(gcfg, 'incidents');
        } catch (e) {
          graphError = mapGraphErr(e).body;
          liveIncidentsCount = null;
        }
        try {
          liveAlertsCount = await (0, _graphSecurityClient.countSecurityCollection)(gcfg, 'alerts_v2');
        } catch (e) {
          if (!graphError) graphError = mapGraphErr(e).body;
          liveAlertsCount = null;
        }
      }
      return res.ok({
        body: {
          total_machines: total,
          by_os: byOsBuckets,
          by_exposure: byExposureBuckets,
          by_health: byHealthBuckets,
          by_risk: byRiskBuckets,
          recent_machines: recentList,
          incidents_index_count: incidentsCount,
          alerts_index_count: alertsCount,
          vulnerabilities_index_count: vulnCount,
          linked_agents_count: linkedAgents,
          stale_machines_count: staleCount,
          graph_incidents_live_count: liveIncidentsCount,
          graph_alerts_live_count: liveAlertsCount,
          graph_error_hint: graphError,
          data_source: dataSource
        }
      });
    } catch (err) {
      var _err$statusCode2, _err$message9;
      return res.customError({
        statusCode: (_err$statusCode2 = err.statusCode) !== null && _err$statusCode2 !== void 0 ? _err$statusCode2 : 500,
        body: (_err$message9 = err.message) !== null && _err$message9 !== void 0 ? _err$message9 : String(err)
      });
    }
  });
  router.get({
    path: '/api/defender_xdr/vulnerabilities',
    validate: {
      query: _configSchema.schema.object({
        size: _configSchema.schema.maybe(_configSchema.schema.number()),
        from: _configSchema.schema.maybe(_configSchema.schema.number()),
        source: _configSchema.schema.maybe(_configSchema.schema.string())
      })
    }
  }, async (context, req, res) => {
    const q = req.query;
    if (q.source === 'mde') {
      const mcfg = (0, _mdeClient.getMdeConfig)();
      if (!mcfg) return res.customError({
        statusCode: 503,
        body: 'MDE not configured.'
      });
      try {
        var _q$size2, _data$value, _q$from2, _q$size3;
        const data = await (0, _mdeClient.listOrgVulnerabilities)(mcfg, (_q$size2 = q.size) !== null && _q$size2 !== void 0 ? _q$size2 : 200);
        const rows = (_data$value = data === null || data === void 0 ? void 0 : data.value) !== null && _data$value !== void 0 ? _data$value : [];
        const from = (_q$from2 = q.from) !== null && _q$from2 !== void 0 ? _q$from2 : 0;
        const size = (_q$size3 = q.size) !== null && _q$size3 !== void 0 ? _q$size3 : 50;
        const slice = rows.slice(from, from + size);
        const hits = slice.map((row, i) => {
          var _ref2, _row$id;
          return {
            _id: String((_ref2 = (_row$id = row.id) !== null && _row$id !== void 0 ? _row$id : row.cveId) !== null && _ref2 !== void 0 ? _ref2 : i),
            _source: typeof row === 'object' ? row : {
              raw: row
            }
          };
        });
        return res.ok({
          body: {
            hits,
            total: {
              value: rows.length,
              relation: 'eq'
            },
            source: 'mde'
          }
        });
      } catch (err) {
        var _err$message10;
        return res.customError({
          statusCode: (0, _mdeClient.mdeErrorStatus)(err),
          body: (_err$message10 = err === null || err === void 0 ? void 0 : err.message) !== null && _err$message10 !== void 0 ? _err$message10 : String(err)
        });
      }
    }
    try {
      var _hits3, _response$body2, _hits$hits2;
      const client = getClient(context);
      const {
        size = 50,
        from = 0
      } = q;
      const response = await client.search({
        index: _constants.DEFENDER_VULNERABILITIES_INDEX,
        ignore_unavailable: true,
        body: {
          size,
          from,
          sort: [{
            sync_ts: {
              order: 'desc'
            }
          }],
          query: {
            match_all: {}
          }
        }
      });
      const hits = (_hits3 = (_response$body2 = response.body) === null || _response$body2 === void 0 ? void 0 : _response$body2.hits) !== null && _hits3 !== void 0 ? _hits3 : {};
      return res.ok({
        body: {
          hits: (_hits$hits2 = hits.hits) !== null && _hits$hits2 !== void 0 ? _hits$hits2 : [],
          total: hits.total,
          source: 'index'
        }
      });
    } catch (err) {
      var _err$statusCode3, _err$message11;
      return res.customError({
        statusCode: (_err$statusCode3 = err.statusCode) !== null && _err$statusCode3 !== void 0 ? _err$statusCode3 : 500,
        body: (_err$message11 = err.message) !== null && _err$message11 !== void 0 ? _err$message11 : String(err)
      });
    }
  });
  router.get({
    path: '/api/defender_xdr/incidents/live',
    validate: {
      query: _configSchema.schema.object({
        top: _configSchema.schema.maybe(_configSchema.schema.number())
      })
    }
  }, async (_context, req, res) => {
    const config = (0, _graphSecurityClient.getGraphSecurityConfig)();
    if (!config) {
      return res.customError({
        statusCode: 503,
        body: 'Graph security not configured.'
      });
    }
    try {
      var _top4;
      const top = (_top4 = req.query.top) !== null && _top4 !== void 0 ? _top4 : 25;
      const data = await (0, _graphSecurityClient.listIncidents)(config, top);
      return res.ok({
        body: data
      });
    } catch (err) {
      const {
        status,
        body
      } = mapGraphErr(err);
      return res.customError({
        statusCode: status,
        body
      });
    }
  });
  router.get({
    path: '/api/defender_xdr/incidents/{id}',
    validate: {
      params: _configSchema.schema.object({
        id: _configSchema.schema.string()
      })
    }
  }, async (_context, req, res) => {
    const config = (0, _graphSecurityClient.getGraphSecurityConfig)();
    if (!config) {
      return res.customError({
        statusCode: 503,
        body: 'Graph security not configured.'
      });
    }
    try {
      const data = await (0, _graphSecurityClient.getIncident)(config, req.params.id);
      return res.ok({
        body: data
      });
    } catch (err) {
      const {
        status,
        body
      } = mapGraphErr(err);
      return res.customError({
        statusCode: status,
        body
      });
    }
  });
  router.get({
    path: '/api/defender_xdr/alerts/{id}',
    validate: {
      params: _configSchema.schema.object({
        id: _configSchema.schema.string()
      })
    }
  }, async (_context, req, res) => {
    const config = (0, _graphSecurityClient.getGraphSecurityConfig)();
    if (!config) {
      return res.customError({
        statusCode: 503,
        body: 'Graph security not configured.'
      });
    }
    try {
      const data = await (0, _graphSecurityClient.graphSecurityRequest)(config, 'GET', `/security/alerts_v2/${encodeURIComponent(req.params.id)}`, undefined, {
        ConsistencyLevel: 'eventual'
      });
      return res.ok({
        body: data
      });
    } catch (err) {
      const {
        status,
        body
      } = mapGraphErr(err);
      return res.customError({
        statusCode: status,
        body
      });
    }
  });
  router.get({
    path: '/api/defender_xdr/alerts/live',
    validate: {
      query: _configSchema.schema.object({
        top: _configSchema.schema.maybe(_configSchema.schema.number())
      })
    }
  }, async (_context, req, res) => {
    const config = (0, _graphSecurityClient.getGraphSecurityConfig)();
    if (!config) {
      return res.customError({
        statusCode: 503,
        body: 'Graph security not configured.'
      });
    }
    try {
      var _top5;
      const top = (_top5 = req.query.top) !== null && _top5 !== void 0 ? _top5 : 25;
      const data = await (0, _graphSecurityClient.listAlertsV2)(config, top);
      return res.ok({
        body: data
      });
    } catch (err) {
      const {
        status,
        body
      } = mapGraphErr(err);
      return res.customError({
        statusCode: status,
        body
      });
    }
  });
  router.post({
    path: '/api/defender_xdr/hunting',
    validate: {
      body: _configSchema.schema.object({
        query: _configSchema.schema.string(),
        timespan: _configSchema.schema.maybe(_configSchema.schema.string())
      })
    }
  }, async (_context, req, res) => {
    const config = (0, _graphSecurityClient.getGraphSecurityConfig)();
    if (!config) {
      return res.customError({
        statusCode: 503,
        body: 'Graph security not configured.'
      });
    }
    try {
      const {
        query,
        timespan
      } = req.body;
      const started = Date.now();
      const data = await (0, _graphSecurityClient.runHuntingQuery)(config, query, timespan || 'P7D');
      const rowCount = Array.isArray(data === null || data === void 0 ? void 0 : data.results) ? data.results.length : 0;
      return res.ok({
        body: {
          ...(data || {}),
          executionTimeMs: Date.now() - started,
          rowCount
        }
      });
    } catch (err) {
      const {
        status,
        body
      } = mapGraphErr(err);
      return res.customError({
        statusCode: status,
        body
      });
    }
  });
  router.get({
    path: '/api/defender_xdr/indicators/live',
    validate: {
      query: _configSchema.schema.object({
        top: _configSchema.schema.maybe(_configSchema.schema.number())
      })
    }
  }, async (_context, req, res) => {
    const config = (0, _mdeClient.getMdeConfig)();
    if (!config) {
      return res.customError({
        statusCode: 503,
        body: 'MDE not configured.'
      });
    }
    try {
      var _top6;
      const top = (_top6 = req.query.top) !== null && _top6 !== void 0 ? _top6 : 100;
      const data = await (0, _mdeClient.listIndicators)(config, top);
      return res.ok({
        body: data
      });
    } catch (err) {
      var _err$message12;
      return res.customError({
        statusCode: (0, _mdeClient.mdeErrorStatus)(err),
        body: (_err$message12 = err === null || err === void 0 ? void 0 : err.message) !== null && _err$message12 !== void 0 ? _err$message12 : String(err)
      });
    }
  });
  router.get({
    path: '/api/defender_xdr/audit-log',
    validate: {
      query: _configSchema.schema.object({
        size: _configSchema.schema.maybe(_configSchema.schema.number())
      })
    }
  }, async (context, req, res) => {
    try {
      var _size, _hits$hits3, _response$body3;
      const client = getClient(context);
      const size = (_size = req.query.size) !== null && _size !== void 0 ? _size : 50;
      const response = await client.search({
        index: _constants.DEFENDER_AUDIT_LOG_INDEX,
        ignore_unavailable: true,
        body: {
          size,
          sort: [{
            timestamp: {
              order: 'desc'
            }
          }],
          query: {
            match_all: {}
          }
        }
      });
      const hits = (_hits$hits3 = (_response$body3 = response.body) === null || _response$body3 === void 0 || (_response$body3 = _response$body3.hits) === null || _response$body3 === void 0 ? void 0 : _response$body3.hits) !== null && _hits$hits3 !== void 0 ? _hits$hits3 : [];
      return res.ok({
        body: {
          entries: hits.map(h => h._source)
        }
      });
    } catch (err) {
      var _err$statusCode4, _err$message13;
      return res.customError({
        statusCode: (_err$statusCode4 = err.statusCode) !== null && _err$statusCode4 !== void 0 ? _err$statusCode4 : 500,
        body: (_err$message13 = err.message) !== null && _err$message13 !== void 0 ? _err$message13 : String(err)
      });
    }
  });
  router.get({
    path: '/api/defender_xdr/identity',
    validate: {
      query: _configSchema.schema.object({
        size: _configSchema.schema.maybe(_configSchema.schema.number())
      })
    }
  }, async (context, req, res) => {
    try {
      const client = getClient(context);
      const size = req.query.size != null ? req.query.size : 1000;
      const r = await client.search({
        index: _constants.DEFENDER_MACHINE_IDENTITY_INDEX,
        ignore_unavailable: true,
        body: {
          size,
          query: {
            match_all: {}
          }
        }
      });
      const hits = r && r.body && r.body.hits && r.body.hits.hits || [];
      return res.ok({
        body: {
          value: hits.map(h => ({
            _id: h._id,
            ...(h._source || {})
          }))
        }
      });
    } catch (err) {
      return res.customError({
        statusCode: err.statusCode || 500,
        body: err.message || String(err)
      });
    }
  });
  router.post({
    path: '/api/defender_xdr/identity',
    validate: {
      body: _configSchema.schema.object({
        wazuh_agent_id: _configSchema.schema.string(),
        wazuh_agent_name: _configSchema.schema.maybe(_configSchema.schema.string()),
        defender_machine_id: _configSchema.schema.string(),
        computer_dns_name: _configSchema.schema.maybe(_configSchema.schema.string()),
        aad_device_id: _configSchema.schema.maybe(_configSchema.schema.string()),
        source: _configSchema.schema.maybe(_configSchema.schema.string())
      })
    }
  }, async (context, req, res) => {
    try {
      const client = getClient(context);
      const body = req.body;
      const mcfg = (0, _mdeClient.getMdeConfig)();
      const tenant_id = mcfg ? mcfg.tenantId : 'unknown';
      const allowedSources = ['aad_device_id', 'hostname_match', 'machine_id_match', 'manual'];
      const source = allowedSources.indexOf(body.source) >= 0 ? body.source : 'manual';
      const doc = {
        wazuh_agent_id: body.wazuh_agent_id.trim(),
        wazuh_agent_name: (body.wazuh_agent_name || '').trim(),
        defender_machine_id: body.defender_machine_id,
        computer_dns_name: body.computer_dns_name || '',
        aad_device_id: body.aad_device_id || '',
        linked_at: new Date().toISOString(),
        tenant_id,
        source
      };
      if (!doc.wazuh_agent_id) {
        return res.customError({
          statusCode: 400,
          body: 'wazuh_agent_id is required'
        });
      }
      await client.index({
        index: _constants.DEFENDER_MACHINE_IDENTITY_INDEX,
        id: doc.wazuh_agent_id,
        refresh: 'true',
        body: doc
      });
      return res.ok({
        body: {
          success: true,
          doc
        }
      });
    } catch (err) {
      return res.customError({
        statusCode: err.statusCode || 500,
        body: err.message || String(err)
      });
    }
  });
  router.delete({
    path: '/api/defender_xdr/identity/{wazuh_agent_id}',
    validate: {
      params: _configSchema.schema.object({
        wazuh_agent_id: _configSchema.schema.string()
      })
    }
  }, async (context, req, res) => {
    try {
      const client = getClient(context);
      try {
        await client.delete({
          index: _constants.DEFENDER_MACHINE_IDENTITY_INDEX,
          id: req.params.wazuh_agent_id,
          refresh: 'true'
        });
      } catch (e) {
        if (e && e.statusCode === 404) {
          return res.ok({
            body: {
              success: true,
              message: 'not_found'
            }
          });
        }
        throw e;
      }
      return res.ok({
        body: {
          success: true
        }
      });
    } catch (err) {
      return res.customError({
        statusCode: err.statusCode || 500,
        body: err.message || String(err)
      });
    }
  });
  router.post({
    path: '/api/defender_xdr/alerts_enrichment',
    validate: {
      body: _configSchema.schema.object({
        size: _configSchema.schema.maybe(_configSchema.schema.number()),
        from: _configSchema.schema.maybe(_configSchema.schema.number()),
        time_from: _configSchema.schema.maybe(_configSchema.schema.string()),
        time_to: _configSchema.schema.maybe(_configSchema.schema.string()),
        defender_correlated_only: _configSchema.schema.maybe(_configSchema.schema.boolean())
      })
    }
  }, async (context, req, res) => {
    try {
      var _hits$hits5, _alertsResponse$body, _ref3, _hits$total$value2, _countResponse$body, _countResponse$body2;
      const client = getClient(context);
      const {
        size = 25,
        from = 0,
        time_from,
        time_to,
        defender_correlated_only = true
      } = req.body;
      const now = new Date();
      const defaultTo = now.toISOString();
      const defaultFrom = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000).toISOString();
      const timeGte = time_from || defaultFrom;
      const timeLte = time_to || defaultTo;
      const timeRangeFilter = {
        range: {
          timestamp: {
            gte: timeGte,
            lte: timeLte
          }
        }
      };
      let agentIdsToQuery = null;
      const agentToDefender = {};
      if (defender_correlated_only) {
        var _hits$hits4, _identityRes$body;
        const identityRes = await client.search({
          index: _constants.DEFENDER_MACHINE_IDENTITY_INDEX,
          ignore_unavailable: true,
          body: {
            size: 1000,
            _source: ['wazuh_agent_id', 'defender_machine_id', 'computer_dns_name'],
            query: {
              match_all: {}
            }
          }
        });
        const identityHits = (_hits$hits4 = (_identityRes$body = identityRes.body) === null || _identityRes$body === void 0 || (_identityRes$body = _identityRes$body.hits) === null || _identityRes$body === void 0 ? void 0 : _identityRes$body.hits) !== null && _hits$hits4 !== void 0 ? _hits$hits4 : [];
        agentIdsToQuery = identityHits.map(h => {
          var _h$_source;
          return (_h$_source = h._source) === null || _h$_source === void 0 ? void 0 : _h$_source.wazuh_agent_id;
        }).filter(id => id && id !== '000');
        if (agentIdsToQuery.length === 0) {
          return res.ok({
            body: {
              alerts: [],
              enrichments: {},
              total: 0,
              identity_count: 0
            }
          });
        }
        identityHits.forEach(h => {
          const s = h._source;
          if (s !== null && s !== void 0 && s.wazuh_agent_id) agentToDefender[s.wazuh_agent_id] = s.defender_machine_id;
        });
      }
      const must = [timeRangeFilter];
      must.push({
        bool: {
          must_not: [{
            term: {
              'agent.id': '000'
            }
          }]
        }
      });
      if (agentIdsToQuery && agentIdsToQuery.length > 0) {
        must.push({
          terms: {
            'agent.id': agentIdsToQuery
          }
        });
      }
      const alertsBody = {
        from,
        size,
        sort: [{
          timestamp: {
            order: 'desc'
          }
        }],
        _source: ['agent.id', 'agent.name', 'rule.description', 'rule.level', 'timestamp'],
        query: {
          bool: {
            must
          }
        }
      };
      const [alertsResponse, countResponse] = await Promise.all([client.search({
        index: _constants.WAZUH_ALERTS_PATTERN,
        ignore_unavailable: true,
        body: alertsBody
      }), client.search({
        index: _constants.WAZUH_ALERTS_PATTERN,
        ignore_unavailable: true,
        body: {
          size: 0,
          query: alertsBody.query,
          track_total_hits: true
        }
      })]);
      const alertHits = (_hits$hits5 = (_alertsResponse$body = alertsResponse.body) === null || _alertsResponse$body === void 0 || (_alertsResponse$body = _alertsResponse$body.hits) === null || _alertsResponse$body === void 0 ? void 0 : _alertsResponse$body.hits) !== null && _hits$hits5 !== void 0 ? _hits$hits5 : [];
      const total = (_ref3 = (_hits$total$value2 = (_countResponse$body = countResponse.body) === null || _countResponse$body === void 0 || (_countResponse$body = _countResponse$body.hits) === null || _countResponse$body === void 0 || (_countResponse$body = _countResponse$body.total) === null || _countResponse$body === void 0 ? void 0 : _countResponse$body.value) !== null && _hits$total$value2 !== void 0 ? _hits$total$value2 : (_countResponse$body2 = countResponse.body) === null || _countResponse$body2 === void 0 || (_countResponse$body2 = _countResponse$body2.hits) === null || _countResponse$body2 === void 0 ? void 0 : _countResponse$body2.total) !== null && _ref3 !== void 0 ? _ref3 : alertHits.length;
      const enrichments = {};
      alertHits.forEach(h => {
        var _h$_source2;
        const aid = (_h$_source2 = h._source) === null || _h$_source2 === void 0 || (_h$_source2 = _h$_source2.agent) === null || _h$_source2 === void 0 ? void 0 : _h$_source2.id;
        if (aid && agentToDefender[aid]) {
          enrichments[h._id] = {
            defender_machine_id: agentToDefender[aid]
          };
        }
      });
      return res.ok({
        body: {
          alerts: alertHits.map(h => ({
            id: h._id,
            ...h._source
          })),
          enrichments,
          total,
          identity_count: Object.keys(agentToDefender).length
        }
      });
    } catch (err) {
      var _err$statusCode5, _err$message14;
      return res.customError({
        statusCode: (_err$statusCode5 = err.statusCode) !== null && _err$statusCode5 !== void 0 ? _err$statusCode5 : 500,
        body: (_err$message14 = err.message) !== null && _err$message14 !== void 0 ? _err$message14 : String(err)
      });
    }
  });
}
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfY29uZmlnU2NoZW1hIiwicmVxdWlyZSIsIl9jb25zdGFudHMiLCJfbWRlQ2xpZW50IiwiX2dyYXBoU2VjdXJpdHlDbGllbnQiLCJtYXBHcmFwaEVyciIsImVyciIsIkdyYXBoQXBpRXJyb3IiLCJzdGF0dXMiLCJib2R5IiwibWVzc2FnZSIsIkVycm9yIiwiU3RyaW5nIiwibm9ybWFsaXplTWRlTWFjaGluZSIsIm0iLCJ0ZW5hbnRJZCIsInRlbmFudF9pZCIsIm1hY2hpbmVfaWQiLCJpZCIsImNvbXB1dGVyX2Ruc19uYW1lIiwiY29tcHV0ZXJEbnNOYW1lIiwib3NfcGxhdGZvcm0iLCJvc1BsYXRmb3JtIiwib3NfdmVyc2lvbiIsIm9zVmVyc2lvbiIsImxhc3Rfc2VlbiIsImxhc3RTZWVuIiwiZmlyc3Rfc2VlbiIsImZpcnN0U2VlbiIsImFhZF9kZXZpY2VfaWQiLCJhYWREZXZpY2VJZCIsInJpc2tfc2NvcmUiLCJyaXNrU2NvcmUiLCJleHBvc3VyZV9sZXZlbCIsImV4cG9zdXJlTGV2ZWwiLCJvbmJvYXJkaW5nX3N0YXR1cyIsIm9uYm9hcmRpbmdTdGF0dXMiLCJvbmJvYXJkaW5nc3RhdHVzIiwiaGVhbHRoX3N0YXR1cyIsImhlYWx0aFN0YXR1cyIsImlzb2xhdGlvbl9zdGF0dXMiLCJpc29sYXRpb25TdGF0dXMiLCJsYXN0X2lwX2FkZHJlc3MiLCJsYXN0SXBBZGRyZXNzIiwicmJhY19ncm91cF9uYW1lIiwicmJhY0dyb3VwTmFtZSIsImdldENsaWVudCIsImNvbnRleHQiLCJjb3JlIiwib3BlbnNlYXJjaCIsImNsaWVudCIsImFzQ3VycmVudFVzZXIiLCJyZWdpc3RlckRlZmVuZGVyU2VhcmNoUm91dGVzIiwicm91dGVyIiwiZ2V0IiwicGF0aCIsInZhbGlkYXRlIiwiX2NvbnRleHQiLCJfcmVxIiwicmVzIiwibWRlIiwiZ2V0TWRlQ29uZmlnIiwiZ3JhcGgiLCJnZXRHcmFwaFNlY3VyaXR5Q29uZmlnIiwic210cF9ob3N0IiwicHJvY2VzcyIsImVudiIsIlNNVFBfSE9TVCIsInNtdHBfdXNlciIsIlNNVFBfVVNFUiIsInNtdHBfcG9ydCIsIlNNVFBfUE9SVCIsIm90cF9yZWNpcGllbnRfZW1haWwiLCJPVFBfUkVDSVBJRU5UX0VNQUlMIiwic210cF9jb25maWd1cmVkIiwib2siLCJtZGVfY29uZmlndXJlZCIsImdyYXBoX3NlY3VyaXR5X2NvbmZpZ3VyZWQiLCJvdHBfZGV2X21vZGUiLCJ0aW1lc3RhbXAiLCJEYXRlIiwidG9JU09TdHJpbmciLCJxdWVyeSIsInNjaGVtYSIsIm9iamVjdCIsInNpemUiLCJtYXliZSIsIm51bWJlciIsImZyb20iLCJzdHJpbmciLCJzb3VyY2UiLCJyZXEiLCJxIiwibWNmZyIsImN1c3RvbUVycm9yIiwic3RhdHVzQ29kZSIsIl9xJGZyb20iLCJfcSRzaXplIiwicmF3IiwiZmV0Y2hBbGxNYWNoaW5lc0xpbWl0ZWQiLCJyb3dzIiwibWFwIiwiZmlsdGVyIiwiciIsInNvcnQiLCJhIiwiYiIsInRhIiwiZ2V0VGltZSIsInRiIiwic2xpY2UiLCJoaXRzIiwic3JjIiwiX3NvdXJjZSIsIl9pZCIsInRvdGFsIiwidmFsdWUiLCJsZW5ndGgiLCJyZWxhdGlvbiIsIl9lcnIkbWVzc2FnZSIsIm1kZUVycm9yU3RhdHVzIiwiX2hpdHMiLCJfcmVzcG9uc2UkYm9keSIsIl9oaXRzJGhpdHMiLCJtdXN0IiwicHVzaCIsInRlcm0iLCJyZXNwb25zZSIsInNlYXJjaCIsIkRFRkVOREVSX01BQ0hJTkVTX0lOREVYIiwib3JkZXIiLCJtaXNzaW5nIiwiYm9vbCIsIm1hdGNoX2FsbCIsIl9lcnIkc3RhdHVzQ29kZSIsIl9lcnIkbWVzc2FnZTIiLCJwYXJhbXMiLCJjb25maWciLCJkYXRhIiwiZ2V0TWFjaGluZSIsIl9lcnIkbWVzc2FnZTMiLCJtZGVNYWNoaW5lU3ViIiwicGF0aFN1ZmZpeCIsImZuIiwiX2VyciRtZXNzYWdlNCIsImdldE1hY2hpbmVSZWNvbW1lbmRhdGlvbnMiLCJnZXRNYWNoaW5lVnVsbmVyYWJpbGl0aWVzIiwiZ2V0TWFjaGluZUFsZXJ0cyIsImdldE1hY2hpbmVMb2dvblVzZXJzIiwiZ2V0TWFjaGluZVNvZnR3YXJlIiwidG9wIiwiX3RvcCIsImxpc3RPcmdWdWxuZXJhYmlsaXRpZXMiLCJfZXJyJG1lc3NhZ2U1IiwiX3RvcDIiLCJsaXN0TGVnYWN5QWxlcnRzIiwiX2VyciRtZXNzYWdlNiIsIl90b3AzIiwibGlzdE1hY2hpbmVBY3Rpb25zIiwiX2VyciRtZXNzYWdlNyIsImFjdGlvbklkIiwiZ2V0TWFjaGluZUFjdGlvblBhY2thZ2VVcmkiLCJfZXJyJG1lc3NhZ2U4IiwiX21hY2hpbmVzUmVzJGJvZHkiLCJfYWdncmVnYXRpb25zIiwiX21hY2hpbmVzUmVzJGJvZHkyIiwiX2hpdHNCb2R5JGhpdHMiLCJfaGl0c0JvZHkkdG90YWwkdmFsdWUiLCJfaGl0c0JvZHkkdG90YWwiLCJfaGl0c0JvZHkkdG90YWwyIiwiX2FnZ3MkYnlfb3MkYnVja2V0cyIsIl9hZ2dzJGJ5X29zIiwiX2FnZ3MkYnlfZXhwb3N1cmUkYnVjIiwiX2FnZ3MkYnlfZXhwb3N1cmUiLCJfYWdncyRieV9oZWFsdGgkYnVja2UiLCJfYWdncyRieV9oZWFsdGgiLCJfYWdncyRieV9yaXNrJGJ1Y2tldHMiLCJfYWdncyRieV9yaXNrIiwic3RhbGVEYXRlIiwibm93IiwibWFjaGluZXNSZXMiLCJieV9vcyIsInRlcm1zIiwiZmllbGQiLCJieV9leHBvc3VyZSIsImJ5X2hlYWx0aCIsImJ5X3Jpc2siLCJpbmNpZGVudHNDb3VudCIsImFsZXJ0c0NvdW50IiwidnVsbkNvdW50IiwibGlua2VkQWdlbnRzIiwic3RhbGVDb3VudCIsIl9jb3VudCIsIl9pYyRib2R5IiwiX2NvdW50MiIsIl9hYyRib2R5IiwiX2NvdW50MyIsIl92YyRib2R5IiwiX2NvdW50NCIsIl9pZFJlcyRib2R5IiwiX3JlZiIsIl9oaXRzJHRvdGFsJHZhbHVlIiwiX3N0YWxlUmVzJGJvZHkiLCJfc3RhbGVSZXMkYm9keTIiLCJpYyIsImFjIiwidmMiLCJpZFJlcyIsInN0YWxlUmVzIiwiUHJvbWlzZSIsImFsbCIsImNvdW50IiwiaW5kZXgiLCJERUZFTkRFUl9JTkNJREVOVFNfSU5ERVgiLCJpZ25vcmVfdW5hdmFpbGFibGUiLCJERUZFTkRFUl9BTEVSVFNfSU5ERVgiLCJERUZFTkRFUl9WVUxORVJBQklMSVRJRVNfSU5ERVgiLCJERUZFTkRFUl9NQUNISU5FX0lERU5USVRZX0lOREVYIiwicmFuZ2UiLCJsdCIsInRyYWNrX3RvdGFsX2hpdHMiLCJoaXRzQm9keSIsIl9oaXRzMiIsImFnZ3MiLCJhZ2dyZWdhdGlvbnMiLCJyZWNlbnRfbWFjaGluZXMiLCJoIiwiQm9vbGVhbiIsInRvdGFsTWFjaGluZXMiLCJieU9zQnVja2V0cyIsImJ1Y2tldHMiLCJieUV4cG9zdXJlQnVja2V0cyIsImJ5SGVhbHRoQnVja2V0cyIsInRpZCIsIm5vcm1hbGl6ZWQiLCJkYXRhU291cmNlIiwib3NNYXAiLCJleE1hcCIsImhlYWx0aE1hcCIsInJpc2tNYXAiLCJmb3JFYWNoIiwib3MiLCJleCIsImhzIiwicnMiLCJPYmplY3QiLCJlbnRyaWVzIiwia2V5IiwiZG9jX2NvdW50IiwiYnlSaXNrQnVja2V0cyIsImxpdmVJbmNpZGVudHNDb3VudCIsImxpdmVBbGVydHNDb3VudCIsImdyYXBoRXJyb3IiLCJnY2ZnIiwiY291bnRTZWN1cml0eUNvbGxlY3Rpb24iLCJlIiwidG90YWxfbWFjaGluZXMiLCJyZWNlbnRMaXN0IiwiaW5jaWRlbnRzX2luZGV4X2NvdW50IiwiYWxlcnRzX2luZGV4X2NvdW50IiwidnVsbmVyYWJpbGl0aWVzX2luZGV4X2NvdW50IiwibGlua2VkX2FnZW50c19jb3VudCIsInN0YWxlX21hY2hpbmVzX2NvdW50IiwiZ3JhcGhfaW5jaWRlbnRzX2xpdmVfY291bnQiLCJncmFwaF9hbGVydHNfbGl2ZV9jb3VudCIsImdyYXBoX2Vycm9yX2hpbnQiLCJkYXRhX3NvdXJjZSIsIl9lcnIkc3RhdHVzQ29kZTIiLCJfZXJyJG1lc3NhZ2U5IiwiX2RhdGEkdmFsdWUiLCJfcSRmcm9tMiIsIl9xJHNpemUzIiwiX3Ekc2l6ZTIiLCJyb3ciLCJpIiwiX3JlZjIiLCJfcm93JGlkIiwiY3ZlSWQiLCJfZXJyJG1lc3NhZ2UxMCIsIl9oaXRzMyIsIl9yZXNwb25zZSRib2R5MiIsIl9oaXRzJGhpdHMyIiwic3luY190cyIsIl9lcnIkc3RhdHVzQ29kZTMiLCJfZXJyJG1lc3NhZ2UxMSIsIl90b3A0IiwibGlzdEluY2lkZW50cyIsImdldEluY2lkZW50IiwiZ3JhcGhTZWN1cml0eVJlcXVlc3QiLCJlbmNvZGVVUklDb21wb25lbnQiLCJ1bmRlZmluZWQiLCJDb25zaXN0ZW5jeUxldmVsIiwiX3RvcDUiLCJsaXN0QWxlcnRzVjIiLCJwb3N0IiwidGltZXNwYW4iLCJzdGFydGVkIiwicnVuSHVudGluZ1F1ZXJ5Iiwicm93Q291bnQiLCJBcnJheSIsImlzQXJyYXkiLCJyZXN1bHRzIiwiZXhlY3V0aW9uVGltZU1zIiwiX3RvcDYiLCJsaXN0SW5kaWNhdG9ycyIsIl9lcnIkbWVzc2FnZTEyIiwiX3NpemUiLCJfaGl0cyRoaXRzMyIsIl9yZXNwb25zZSRib2R5MyIsIkRFRkVOREVSX0FVRElUX0xPR19JTkRFWCIsIl9lcnIkc3RhdHVzQ29kZTQiLCJfZXJyJG1lc3NhZ2UxMyIsImRlZmVuZGVyX21hY2hpbmVfaWQiLCJhbGxvd2VkU291cmNlcyIsImluZGV4T2YiLCJkb2MiLCJ3YXp1aF9hZ2VudF9pZCIsInRyaW0iLCJ3YXp1aF9hZ2VudF9uYW1lIiwibGlua2VkX2F0IiwicmVmcmVzaCIsInN1Y2Nlc3MiLCJkZWxldGUiXSwic291cmNlcyI6WyJzZWFyY2gudHMiXSwic291cmNlc0NvbnRlbnQiOlsiLypcbiAqIERlZmVuZGVyIHBsdWdpbiDigJQgT3BlblNlYXJjaCByZWFkcyArIEdyYXBoL01ERSBwcm94aWVzXG4gKi9cblxuaW1wb3J0IHsgSVJvdXRlciB9IGZyb20gJ29wZW5zZWFyY2gtZGFzaGJvYXJkcy9zZXJ2ZXInO1xuaW1wb3J0IHsgc2NoZW1hIH0gZnJvbSAnQG9zZC9jb25maWctc2NoZW1hJztcbmltcG9ydCB7XG4gIERFRkVOREVSX01BQ0hJTkVTX0lOREVYLFxuICBERUZFTkRFUl9NQUNISU5FX0lERU5USVRZX0lOREVYLFxuICBERUZFTkRFUl9WVUxORVJBQklMSVRJRVNfSU5ERVgsXG4gIERFRkVOREVSX0lOQ0lERU5UU19JTkRFWCxcbiAgREVGRU5ERVJfQUxFUlRTX0lOREVYLFxuICBERUZFTkRFUl9BVURJVF9MT0dfSU5ERVgsXG4gIFdBWlVIX0FMRVJUU19QQVRURVJOLFxufSBmcm9tICcuLi8uLi9jb21tb24vY29uc3RhbnRzJztcbmltcG9ydCB7XG4gIGdldE1kZUNvbmZpZyxcbiAgZ2V0TWFjaGluZSxcbiAgbGlzdEluZGljYXRvcnMsXG4gIGZldGNoQWxsTWFjaGluZXNMaW1pdGVkLFxuICBnZXRNYWNoaW5lUmVjb21tZW5kYXRpb25zLFxuICBnZXRNYWNoaW5lVnVsbmVyYWJpbGl0aWVzLFxuICBnZXRNYWNoaW5lQWxlcnRzLFxuICBnZXRNYWNoaW5lTG9nb25Vc2VycyxcbiAgZ2V0TWFjaGluZVNvZnR3YXJlLFxuICBsaXN0T3JnVnVsbmVyYWJpbGl0aWVzLFxuICBsaXN0TGVnYWN5QWxlcnRzLFxuICBsaXN0TWFjaGluZUFjdGlvbnMsXG4gIGdldE1hY2hpbmVBY3Rpb25QYWNrYWdlVXJpLFxuICBtZGVFcnJvclN0YXR1cyxcbn0gZnJvbSAnLi4vbGliL21kZS1jbGllbnQnO1xuaW1wb3J0IHtcbiAgZ2V0R3JhcGhTZWN1cml0eUNvbmZpZyxcbiAgbGlzdEluY2lkZW50cyxcbiAgbGlzdEFsZXJ0c1YyLFxuICBydW5IdW50aW5nUXVlcnksXG4gIGNvdW50U2VjdXJpdHlDb2xsZWN0aW9uLFxuICBHcmFwaEFwaUVycm9yLFxufSBmcm9tICcuLi9saWIvZ3JhcGgtc2VjdXJpdHktY2xpZW50JztcblxuZnVuY3Rpb24gbWFwR3JhcGhFcnIoZXJyOiB1bmtub3duKTogeyBzdGF0dXM6IG51bWJlcjsgYm9keTogc3RyaW5nIH0ge1xuICBpZiAoZXJyIGluc3RhbmNlb2YgR3JhcGhBcGlFcnJvcikge1xuICAgIHJldHVybiB7IHN0YXR1czogZXJyLnN0YXR1cyA+PSA0MDAgJiYgZXJyLnN0YXR1cyA8IDYwMCA/IGVyci5zdGF0dXMgOiA1MDIsIGJvZHk6IGVyci5tZXNzYWdlIH07XG4gIH1cbiAgcmV0dXJuIHsgc3RhdHVzOiA1MDIsIGJvZHk6IGVyciBpbnN0YW5jZW9mIEVycm9yID8gZXJyLm1lc3NhZ2UgOiBTdHJpbmcoZXJyKSB9O1xufVxuXG5mdW5jdGlvbiBub3JtYWxpemVNZGVNYWNoaW5lKG06IFJlY29yZDxzdHJpbmcsIHVua25vd24+LCB0ZW5hbnRJZDogc3RyaW5nKSB7XG4gIHJldHVybiB7XG4gICAgdGVuYW50X2lkOiB0ZW5hbnRJZCxcbiAgICBtYWNoaW5lX2lkOiBtLmlkLFxuICAgIGNvbXB1dGVyX2Ruc19uYW1lOiBtLmNvbXB1dGVyRG5zTmFtZSB8fCAnJyxcbiAgICBvc19wbGF0Zm9ybTogbS5vc1BsYXRmb3JtIHx8ICcnLFxuICAgIG9zX3ZlcnNpb246IG0ub3NWZXJzaW9uIHx8ICcnLFxuICAgIGxhc3Rfc2VlbjogbS5sYXN0U2VlbiB8fCBudWxsLFxuICAgIGZpcnN0X3NlZW46IG0uZmlyc3RTZWVuIHx8IG51bGwsXG4gICAgYWFkX2RldmljZV9pZDogbS5hYWREZXZpY2VJZCB8fCAnJyxcbiAgICByaXNrX3Njb3JlOiBtLnJpc2tTY29yZSAhPSBudWxsID8gU3RyaW5nKG0ucmlza1Njb3JlKSA6ICcnLFxuICAgIGV4cG9zdXJlX2xldmVsOiBtLmV4cG9zdXJlTGV2ZWwgfHwgJycsXG4gICAgb25ib2FyZGluZ19zdGF0dXM6IG0ub25ib2FyZGluZ1N0YXR1cyB8fCBtLm9uYm9hcmRpbmdzdGF0dXMgfHwgJycsXG4gICAgaGVhbHRoX3N0YXR1czogbS5oZWFsdGhTdGF0dXMgfHwgJycsXG4gICAgaXNvbGF0aW9uX3N0YXR1czogbS5pc29sYXRpb25TdGF0dXMgfHwgJycsXG4gICAgbGFzdF9pcF9hZGRyZXNzOiBtLmxhc3RJcEFkZHJlc3MgfHwgJycsXG4gICAgcmJhY19ncm91cF9uYW1lOiBtLnJiYWNHcm91cE5hbWUgfHwgJycsXG4gIH07XG59XG5cbmZ1bmN0aW9uIGdldENsaWVudChjb250ZXh0OiBhbnkpIHtcbiAgcmV0dXJuIGNvbnRleHQuY29yZS5vcGVuc2VhcmNoLmNsaWVudC5hc0N1cnJlbnRVc2VyO1xufVxuXG5leHBvcnQgZnVuY3Rpb24gcmVnaXN0ZXJEZWZlbmRlclNlYXJjaFJvdXRlcyhyb3V0ZXI6IElSb3V0ZXIpIHtcbiAgcm91dGVyLmdldCh7IHBhdGg6ICcvYXBpL2RlZmVuZGVyX3BsdWdpbi9oZWFsdGgnLCB2YWxpZGF0ZTogZmFsc2UgfSwgYXN5bmMgKF9jb250ZXh0LCBfcmVxLCByZXMpID0+IHtcbiAgICBjb25zdCBtZGUgPSAhIWdldE1kZUNvbmZpZygpO1xuICAgIGNvbnN0IGdyYXBoID0gISFnZXRHcmFwaFNlY3VyaXR5Q29uZmlnKCk7XG4gICAgcmV0dXJuIHJlcy5vayh7XG4gICAgICBib2R5OiB7XG4gICAgICAgIG9rOiBtZGUgfHwgZ3JhcGgsXG4gICAgICAgIG1kZV9jb25maWd1cmVkOiBtZGUsXG4gICAgICAgIGdyYXBoX3NlY3VyaXR5X2NvbmZpZ3VyZWQ6IGdyYXBoLFxuICAgICAgICB0aW1lc3RhbXA6IG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKSxcbiAgICAgIH0sXG4gICAgfSk7XG4gIH0pO1xuXG4gIHJvdXRlci5nZXQoXG4gICAge1xuICAgICAgcGF0aDogJy9hcGkvZGVmZW5kZXJfcGx1Z2luL21hY2hpbmVzJyxcbiAgICAgIHZhbGlkYXRlOiB7XG4gICAgICAgIHF1ZXJ5OiBzY2hlbWEub2JqZWN0KHtcbiAgICAgICAgICBzaXplOiBzY2hlbWEubWF5YmUoc2NoZW1hLm51bWJlcigpKSxcbiAgICAgICAgICBmcm9tOiBzY2hlbWEubWF5YmUoc2NoZW1hLm51bWJlcigpKSxcbiAgICAgICAgICBvc19wbGF0Zm9ybTogc2NoZW1hLm1heWJlKHNjaGVtYS5zdHJpbmcoKSksXG4gICAgICAgICAgZXhwb3N1cmVfbGV2ZWw6IHNjaGVtYS5tYXliZShzY2hlbWEuc3RyaW5nKCkpLFxuICAgICAgICAgIHNvdXJjZTogc2NoZW1hLm1heWJlKHNjaGVtYS5zdHJpbmcoKSksXG4gICAgICAgIH0pLFxuICAgICAgfSxcbiAgICB9LFxuICAgIGFzeW5jIChjb250ZXh0LCByZXEsIHJlcykgPT4ge1xuICAgICAgY29uc3QgcSA9IHJlcS5xdWVyeSBhcyB7XG4gICAgICAgIHNpemU/OiBudW1iZXI7XG4gICAgICAgIGZyb20/OiBudW1iZXI7XG4gICAgICAgIG9zX3BsYXRmb3JtPzogc3RyaW5nO1xuICAgICAgICBleHBvc3VyZV9sZXZlbD86IHN0cmluZztcbiAgICAgICAgc291cmNlPzogc3RyaW5nO1xuICAgICAgfTtcbiAgICAgIGlmIChxLnNvdXJjZSA9PT0gJ2xpdmUnKSB7XG4gICAgICAgIGNvbnN0IG1jZmcgPSBnZXRNZGVDb25maWcoKTtcbiAgICAgICAgaWYgKCFtY2ZnKSB7XG4gICAgICAgICAgcmV0dXJuIHJlcy5jdXN0b21FcnJvcih7IHN0YXR1c0NvZGU6IDUwMywgYm9keTogJ01ERSBub3QgY29uZmlndXJlZC4nIH0pO1xuICAgICAgICB9XG4gICAgICAgIHRyeSB7XG4gICAgICAgICAgY29uc3QgcmF3ID0gYXdhaXQgZmV0Y2hBbGxNYWNoaW5lc0xpbWl0ZWQobWNmZywgMTUpO1xuICAgICAgICAgIGNvbnN0IHRlbmFudElkID0gbWNmZy50ZW5hbnRJZDtcbiAgICAgICAgICBsZXQgcm93cyA9IHJhdy5tYXAoKG0pID0+IG5vcm1hbGl6ZU1kZU1hY2hpbmUobSBhcyBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPiwgdGVuYW50SWQpKTtcbiAgICAgICAgICBpZiAocS5vc19wbGF0Zm9ybSkge1xuICAgICAgICAgICAgcm93cyA9IHJvd3MuZmlsdGVyKChyKSA9PiBTdHJpbmcoci5vc19wbGF0Zm9ybSkgPT09IHEub3NfcGxhdGZvcm0pO1xuICAgICAgICAgIH1cbiAgICAgICAgICBpZiAocS5leHBvc3VyZV9sZXZlbCkge1xuICAgICAgICAgICAgcm93cyA9IHJvd3MuZmlsdGVyKChyKSA9PiBTdHJpbmcoci5leHBvc3VyZV9sZXZlbCkgPT09IHEuZXhwb3N1cmVfbGV2ZWwpO1xuICAgICAgICAgIH1cbiAgICAgICAgICByb3dzLnNvcnQoKGEsIGIpID0+IHtcbiAgICAgICAgICAgIGNvbnN0IHRhID0gYS5sYXN0X3NlZW4gPyBuZXcgRGF0ZShTdHJpbmcoYS5sYXN0X3NlZW4pKS5nZXRUaW1lKCkgOiAwO1xuICAgICAgICAgICAgY29uc3QgdGIgPSBiLmxhc3Rfc2VlbiA/IG5ldyBEYXRlKFN0cmluZyhiLmxhc3Rfc2VlbikpLmdldFRpbWUoKSA6IDA7XG4gICAgICAgICAgICByZXR1cm4gdGIgLSB0YTtcbiAgICAgICAgICB9KTtcbiAgICAgICAgICBjb25zdCBmcm9tID0gcS5mcm9tID8/IDA7XG4gICAgICAgICAgY29uc3Qgc2l6ZSA9IHEuc2l6ZSA/PyA1MDtcbiAgICAgICAgICBjb25zdCBzbGljZSA9IHJvd3Muc2xpY2UoZnJvbSwgZnJvbSArIHNpemUpO1xuICAgICAgICAgIGNvbnN0IGhpdHMgPSBzbGljZS5tYXAoKHNyYykgPT4gKHsgX3NvdXJjZTogc3JjLCBfaWQ6IHNyYy5tYWNoaW5lX2lkIH0pKTtcbiAgICAgICAgICByZXR1cm4gcmVzLm9rKHtcbiAgICAgICAgICAgIGJvZHk6IHtcbiAgICAgICAgICAgICAgaGl0cyxcbiAgICAgICAgICAgICAgdG90YWw6IHsgdmFsdWU6IHJvd3MubGVuZ3RoLCByZWxhdGlvbjogJ2VxJyB9LFxuICAgICAgICAgICAgICBzb3VyY2U6ICdtZGUnLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICB9KTtcbiAgICAgICAgfSBjYXRjaCAoZXJyOiBhbnkpIHtcbiAgICAgICAgICByZXR1cm4gcmVzLmN1c3RvbUVycm9yKHtcbiAgICAgICAgICAgIHN0YXR1c0NvZGU6IG1kZUVycm9yU3RhdHVzKGVyciksXG4gICAgICAgICAgICBib2R5OiBlcnI/Lm1lc3NhZ2UgPz8gU3RyaW5nKGVyciksXG4gICAgICAgICAgfSk7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICAgIHRyeSB7XG4gICAgICAgIGNvbnN0IGNsaWVudCA9IGdldENsaWVudChjb250ZXh0KTtcbiAgICAgICAgY29uc3QgeyBzaXplID0gNTAsIGZyb20gPSAwLCBvc19wbGF0Zm9ybSwgZXhwb3N1cmVfbGV2ZWwgfSA9IHE7XG4gICAgICAgIGNvbnN0IG11c3Q6IGFueVtdID0gW107XG4gICAgICAgIGlmIChvc19wbGF0Zm9ybSkgbXVzdC5wdXNoKHsgdGVybTogeyBvc19wbGF0Zm9ybSB9IH0pO1xuICAgICAgICBpZiAoZXhwb3N1cmVfbGV2ZWwpIG11c3QucHVzaCh7IHRlcm06IHsgZXhwb3N1cmVfbGV2ZWwgfSB9KTtcbiAgICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBjbGllbnQuc2VhcmNoKHtcbiAgICAgICAgICBpbmRleDogREVGRU5ERVJfTUFDSElORVNfSU5ERVgsXG4gICAgICAgICAgaWdub3JlX3VuYXZhaWxhYmxlOiB0cnVlLFxuICAgICAgICAgIGJvZHk6IHtcbiAgICAgICAgICAgIHNpemUsXG4gICAgICAgICAgICBmcm9tLFxuICAgICAgICAgICAgc29ydDogW3sgbGFzdF9zZWVuOiB7IG9yZGVyOiAnZGVzYycsIG1pc3Npbmc6ICdfbGFzdCcgfSB9LCB7IGNvbXB1dGVyX2Ruc19uYW1lOiAnYXNjJyB9XSxcbiAgICAgICAgICAgIHF1ZXJ5OiBtdXN0Lmxlbmd0aCA/IHsgYm9vbDogeyBtdXN0IH0gfSA6IHsgbWF0Y2hfYWxsOiB7fSB9LFxuICAgICAgICAgIH0sXG4gICAgICAgIH0pO1xuICAgICAgICBjb25zdCBoaXRzID0gKHJlc3BvbnNlLmJvZHkgYXMgYW55KT8uaGl0cyA/PyB7fTtcbiAgICAgICAgcmV0dXJuIHJlcy5vayh7IGJvZHk6IHsgaGl0czogaGl0cy5oaXRzID8/IFtdLCB0b3RhbDogaGl0cy50b3RhbCwgc291cmNlOiAnaW5kZXgnIH0gfSk7XG4gICAgICB9IGNhdGNoIChlcnI6IGFueSkge1xuICAgICAgICByZXR1cm4gcmVzLmN1c3RvbUVycm9yKHtcbiAgICAgICAgICBzdGF0dXNDb2RlOiBlcnIuc3RhdHVzQ29kZSA/PyA1MDAsXG4gICAgICAgICAgYm9keTogZXJyLm1lc3NhZ2UgPz8gU3RyaW5nKGVyciksXG4gICAgICAgIH0pO1xuICAgICAgfVxuICAgIH1cbiAgKTtcblxuICByb3V0ZXIuZ2V0KFxuICAgIHtcbiAgICAgIHBhdGg6ICcvYXBpL2RlZmVuZGVyX3BsdWdpbi9tYWNoaW5lcy97aWR9L2xpdmUnLFxuICAgICAgdmFsaWRhdGU6IHsgcGFyYW1zOiBzY2hlbWEub2JqZWN0KHsgaWQ6IHNjaGVtYS5zdHJpbmcoKSB9KSB9LFxuICAgIH0sXG4gICAgYXN5bmMgKF9jb250ZXh0LCBfcmVxLCByZXMpID0+IHtcbiAgICAgIGNvbnN0IGNvbmZpZyA9IGdldE1kZUNvbmZpZygpO1xuICAgICAgaWYgKCFjb25maWcpIHtcbiAgICAgICAgcmV0dXJuIHJlcy5jdXN0b21FcnJvcih7XG4gICAgICAgICAgc3RhdHVzQ29kZTogNTAzLFxuICAgICAgICAgIGJvZHk6ICdEZWZlbmRlciBNREUgbm90IGNvbmZpZ3VyZWQgKERFRkVOREVSX1RFTkFOVF9JRCwgREVGRU5ERVJfQ0xJRU5UX0lELCBERUZFTkRFUl9DTElFTlRfU0VDUkVUKS4nLFxuICAgICAgICB9KTtcbiAgICAgIH1cbiAgICAgIHRyeSB7XG4gICAgICAgIGNvbnN0IGlkID0gKF9yZXEucGFyYW1zIGFzIHsgaWQ6IHN0cmluZyB9KS5pZDtcbiAgICAgICAgY29uc3QgZGF0YSA9IGF3YWl0IGdldE1hY2hpbmUoY29uZmlnLCBpZCk7XG4gICAgICAgIHJldHVybiByZXMub2soeyBib2R5OiBkYXRhIH0pO1xuICAgICAgfSBjYXRjaCAoZXJyOiBhbnkpIHtcbiAgICAgICAgcmV0dXJuIHJlcy5jdXN0b21FcnJvcih7XG4gICAgICAgICAgc3RhdHVzQ29kZTogbWRlRXJyb3JTdGF0dXMoZXJyKSxcbiAgICAgICAgICBib2R5OiBlcnI/Lm1lc3NhZ2UgPz8gU3RyaW5nKGVyciksXG4gICAgICAgIH0pO1xuICAgICAgfVxuICAgIH1cbiAgKTtcblxuICBjb25zdCBtZGVNYWNoaW5lU3ViID0gKHBhdGhTdWZmaXg6IHN0cmluZywgZm46IChjOiBhbnksIGlkOiBzdHJpbmcpID0+IFByb21pc2U8dW5rbm93bj4pID0+IHtcbiAgICByb3V0ZXIuZ2V0KFxuICAgICAge1xuICAgICAgICBwYXRoOiBgL2FwaS9kZWZlbmRlcl9wbHVnaW4vbWFjaGluZXMve2lkfS9saXZlLyR7cGF0aFN1ZmZpeH1gLFxuICAgICAgICB2YWxpZGF0ZTogeyBwYXJhbXM6IHNjaGVtYS5vYmplY3QoeyBpZDogc2NoZW1hLnN0cmluZygpIH0pIH0sXG4gICAgICB9LFxuICAgICAgYXN5bmMgKF9jb250ZXh0LCByZXEsIHJlcykgPT4ge1xuICAgICAgICBjb25zdCBtY2ZnID0gZ2V0TWRlQ29uZmlnKCk7XG4gICAgICAgIGlmICghbWNmZykge1xuICAgICAgICAgIHJldHVybiByZXMuY3VzdG9tRXJyb3IoeyBzdGF0dXNDb2RlOiA1MDMsIGJvZHk6ICdNREUgbm90IGNvbmZpZ3VyZWQuJyB9KTtcbiAgICAgICAgfVxuICAgICAgICB0cnkge1xuICAgICAgICAgIGNvbnN0IGlkID0gKHJlcS5wYXJhbXMgYXMgeyBpZDogc3RyaW5nIH0pLmlkO1xuICAgICAgICAgIGNvbnN0IGRhdGEgPSBhd2FpdCBmbihtY2ZnLCBpZCk7XG4gICAgICAgICAgcmV0dXJuIHJlcy5vayh7IGJvZHk6IGRhdGEgfSk7XG4gICAgICAgIH0gY2F0Y2ggKGVycjogYW55KSB7XG4gICAgICAgICAgcmV0dXJuIHJlcy5jdXN0b21FcnJvcih7IHN0YXR1c0NvZGU6IG1kZUVycm9yU3RhdHVzKGVyciksIGJvZHk6IGVycj8ubWVzc2FnZSA/PyBTdHJpbmcoZXJyKSB9KTtcbiAgICAgICAgfVxuICAgICAgfVxuICAgICk7XG4gIH07XG5cbiAgbWRlTWFjaGluZVN1YigncmVjb21tZW5kYXRpb25zJywgZ2V0TWFjaGluZVJlY29tbWVuZGF0aW9ucyk7XG4gIG1kZU1hY2hpbmVTdWIoJ3Z1bG5lcmFiaWxpdGllcycsIGdldE1hY2hpbmVWdWxuZXJhYmlsaXRpZXMpO1xuICBtZGVNYWNoaW5lU3ViKCdhbGVydHMnLCBnZXRNYWNoaW5lQWxlcnRzKTtcbiAgbWRlTWFjaGluZVN1YignbG9nb251c2VycycsIGdldE1hY2hpbmVMb2dvblVzZXJzKTtcbiAgbWRlTWFjaGluZVN1Yignc29mdHdhcmUnLCBnZXRNYWNoaW5lU29mdHdhcmUpO1xuXG4gIHJvdXRlci5nZXQoXG4gICAge1xuICAgICAgcGF0aDogJy9hcGkvZGVmZW5kZXJfcGx1Z2luL21kZS92dWxuZXJhYmlsaXRpZXMnLFxuICAgICAgdmFsaWRhdGU6IHsgcXVlcnk6IHNjaGVtYS5vYmplY3QoeyB0b3A6IHNjaGVtYS5tYXliZShzY2hlbWEubnVtYmVyKCkpIH0pIH0sXG4gICAgfSxcbiAgICBhc3luYyAoX2NvbnRleHQsIHJlcSwgcmVzKSA9PiB7XG4gICAgICBjb25zdCBtY2ZnID0gZ2V0TWRlQ29uZmlnKCk7XG4gICAgICBpZiAoIW1jZmcpIHJldHVybiByZXMuY3VzdG9tRXJyb3IoeyBzdGF0dXNDb2RlOiA1MDMsIGJvZHk6ICdNREUgbm90IGNvbmZpZ3VyZWQuJyB9KTtcbiAgICAgIHRyeSB7XG4gICAgICAgIGNvbnN0IHRvcCA9IChyZXEucXVlcnkgYXMgeyB0b3A/OiBudW1iZXIgfSkudG9wID8/IDIwMDtcbiAgICAgICAgY29uc3QgZGF0YSA9IGF3YWl0IGxpc3RPcmdWdWxuZXJhYmlsaXRpZXMobWNmZywgdG9wKTtcbiAgICAgICAgcmV0dXJuIHJlcy5vayh7IGJvZHk6IGRhdGEgfSk7XG4gICAgICB9IGNhdGNoIChlcnI6IGFueSkge1xuICAgICAgICByZXR1cm4gcmVzLmN1c3RvbUVycm9yKHsgc3RhdHVzQ29kZTogbWRlRXJyb3JTdGF0dXMoZXJyKSwgYm9keTogZXJyPy5tZXNzYWdlID8/IFN0cmluZyhlcnIpIH0pO1xuICAgICAgfVxuICAgIH1cbiAgKTtcblxuICByb3V0ZXIuZ2V0KFxuICAgIHtcbiAgICAgIHBhdGg6ICcvYXBpL2RlZmVuZGVyX3BsdWdpbi9tZGUvYWxlcnRzLWxlZ2FjeScsXG4gICAgICB2YWxpZGF0ZTogeyBxdWVyeTogc2NoZW1hLm9iamVjdCh7IHRvcDogc2NoZW1hLm1heWJlKHNjaGVtYS5udW1iZXIoKSkgfSkgfSxcbiAgICB9LFxuICAgIGFzeW5jIChfY29udGV4dCwgcmVxLCByZXMpID0+IHtcbiAgICAgIGNvbnN0IG1jZmcgPSBnZXRNZGVDb25maWcoKTtcbiAgICAgIGlmICghbWNmZykgcmV0dXJuIHJlcy5jdXN0b21FcnJvcih7IHN0YXR1c0NvZGU6IDUwMywgYm9keTogJ01ERSBub3QgY29uZmlndXJlZC4nIH0pO1xuICAgICAgdHJ5IHtcbiAgICAgICAgY29uc3QgdG9wID0gKHJlcS5xdWVyeSBhcyB7IHRvcD86IG51bWJlciB9KS50b3AgPz8gMTAwO1xuICAgICAgICBjb25zdCBkYXRhID0gYXdhaXQgbGlzdExlZ2FjeUFsZXJ0cyhtY2ZnLCB0b3ApO1xuICAgICAgICByZXR1cm4gcmVzLm9rKHsgYm9keTogZGF0YSB9KTtcbiAgICAgIH0gY2F0Y2ggKGVycjogYW55KSB7XG4gICAgICAgIHJldHVybiByZXMuY3VzdG9tRXJyb3IoeyBzdGF0dXNDb2RlOiBtZGVFcnJvclN0YXR1cyhlcnIpLCBib2R5OiBlcnI/Lm1lc3NhZ2UgPz8gU3RyaW5nKGVycikgfSk7XG4gICAgICB9XG4gICAgfVxuICApO1xuXG4gIHJvdXRlci5nZXQoXG4gICAge1xuICAgICAgcGF0aDogJy9hcGkvZGVmZW5kZXJfcGx1Z2luL21kZS9tYWNoaW5lYWN0aW9ucycsXG4gICAgICB2YWxpZGF0ZTogeyBxdWVyeTogc2NoZW1hLm9iamVjdCh7IHRvcDogc2NoZW1hLm1heWJlKHNjaGVtYS5udW1iZXIoKSkgfSkgfSxcbiAgICB9LFxuICAgIGFzeW5jIChfY29udGV4dCwgcmVxLCByZXMpID0+IHtcbiAgICAgIGNvbnN0IG1jZmcgPSBnZXRNZGVDb25maWcoKTtcbiAgICAgIGlmICghbWNmZykgcmV0dXJuIHJlcy5jdXN0b21FcnJvcih7IHN0YXR1c0NvZGU6IDUwMywgYm9keTogJ01ERSBub3QgY29uZmlndXJlZC4nIH0pO1xuICAgICAgdHJ5IHtcbiAgICAgICAgY29uc3QgdG9wID0gKHJlcS5xdWVyeSBhcyB7IHRvcD86IG51bWJlciB9KS50b3AgPz8gMTAwO1xuICAgICAgICBjb25zdCBkYXRhID0gYXdhaXQgbGlzdE1hY2hpbmVBY3Rpb25zKG1jZmcsIHRvcCk7XG4gICAgICAgIHJldHVybiByZXMub2soeyBib2R5OiBkYXRhIH0pO1xuICAgICAgfSBjYXRjaCAoZXJyOiBhbnkpIHtcbiAgICAgICAgcmV0dXJuIHJlcy5jdXN0b21FcnJvcih7IHN0YXR1c0NvZGU6IG1kZUVycm9yU3RhdHVzKGVyciksIGJvZHk6IGVycj8ubWVzc2FnZSA/PyBTdHJpbmcoZXJyKSB9KTtcbiAgICAgIH1cbiAgICB9XG4gICk7XG5cbiAgcm91dGVyLmdldChcbiAgICB7XG4gICAgICBwYXRoOiAnL2FwaS9kZWZlbmRlcl9wbHVnaW4vbWRlL21hY2hpbmVhY3Rpb25zL3thY3Rpb25JZH0vcGFja2FnZS11cmknLFxuICAgICAgdmFsaWRhdGU6IHsgcGFyYW1zOiBzY2hlbWEub2JqZWN0KHsgYWN0aW9uSWQ6IHNjaGVtYS5zdHJpbmcoKSB9KSB9LFxuICAgIH0sXG4gICAgYXN5bmMgKF9jb250ZXh0LCByZXEsIHJlcykgPT4ge1xuICAgICAgY29uc3QgbWNmZyA9IGdldE1kZUNvbmZpZygpO1xuICAgICAgaWYgKCFtY2ZnKSByZXR1cm4gcmVzLmN1c3RvbUVycm9yKHsgc3RhdHVzQ29kZTogNTAzLCBib2R5OiAnTURFIG5vdCBjb25maWd1cmVkLicgfSk7XG4gICAgICB0cnkge1xuICAgICAgICBjb25zdCBhY3Rpb25JZCA9IChyZXEucGFyYW1zIGFzIHsgYWN0aW9uSWQ6IHN0cmluZyB9KS5hY3Rpb25JZDtcbiAgICAgICAgY29uc3QgZGF0YSA9IGF3YWl0IGdldE1hY2hpbmVBY3Rpb25QYWNrYWdlVXJpKG1jZmcsIGFjdGlvbklkKTtcbiAgICAgICAgcmV0dXJuIHJlcy5vayh7IGJvZHk6IGRhdGEgfSk7XG4gICAgICB9IGNhdGNoIChlcnI6IGFueSkge1xuICAgICAgICByZXR1cm4gcmVzLmN1c3RvbUVycm9yKHsgc3RhdHVzQ29kZTogbWRlRXJyb3JTdGF0dXMoZXJyKSwgYm9keTogZXJyPy5tZXNzYWdlID8/IFN0cmluZyhlcnIpIH0pO1xuICAgICAgfVxuICAgIH1cbiAgKTtcblxuICByb3V0ZXIuZ2V0KHsgcGF0aDogJy9hcGkvZGVmZW5kZXJfcGx1Z2luL292ZXJ2aWV3JywgdmFsaWRhdGU6IGZhbHNlIH0sIGFzeW5jIChjb250ZXh0LCBfcmVxLCByZXMpID0+IHtcbiAgICB0cnkge1xuICAgICAgY29uc3QgY2xpZW50ID0gZ2V0Q2xpZW50KGNvbnRleHQpO1xuICAgICAgY29uc3Qgc3RhbGVEYXRlID0gbmV3IERhdGUoRGF0ZS5ub3coKSAtIDcgKiAyNCAqIDYwICogNjAgKiAxMDAwKS50b0lTT1N0cmluZygpO1xuXG4gICAgICBjb25zdCBtYWNoaW5lc1JlcyA9IGF3YWl0IGNsaWVudC5zZWFyY2goe1xuICAgICAgICBpbmRleDogREVGRU5ERVJfTUFDSElORVNfSU5ERVgsXG4gICAgICAgIGlnbm9yZV91bmF2YWlsYWJsZTogdHJ1ZSxcbiAgICAgICAgYm9keToge1xuICAgICAgICAgIHNpemU6IDgsXG4gICAgICAgICAgdHJhY2tfdG90YWxfaGl0czogdHJ1ZSxcbiAgICAgICAgICBzb3J0OiBbeyBsYXN0X3NlZW46IHsgb3JkZXI6ICdkZXNjJywgbWlzc2luZzogJ19sYXN0JyB9IH1dLFxuICAgICAgICAgIHF1ZXJ5OiB7IG1hdGNoX2FsbDoge30gfSxcbiAgICAgICAgICBhZ2dzOiB7XG4gICAgICAgICAgICBieV9vczogeyB0ZXJtczogeyBmaWVsZDogJ29zX3BsYXRmb3JtJywgc2l6ZTogMTUgfSB9LFxuICAgICAgICAgICAgYnlfZXhwb3N1cmU6IHsgdGVybXM6IHsgZmllbGQ6ICdleHBvc3VyZV9sZXZlbCcsIHNpemU6IDEwIH0gfSxcbiAgICAgICAgICAgIGJ5X2hlYWx0aDogeyB0ZXJtczogeyBmaWVsZDogJ2hlYWx0aF9zdGF0dXMnLCBzaXplOiAxMCB9IH0sXG4gICAgICAgICAgICBieV9yaXNrOiB7IHRlcm1zOiB7IGZpZWxkOiAncmlza19zY29yZScsIHNpemU6IDE1IH0gfSxcbiAgICAgICAgICB9LFxuICAgICAgICB9LFxuICAgICAgfSk7XG5cbiAgICAgIGxldCBpbmNpZGVudHNDb3VudCA9IDA7XG4gICAgICBsZXQgYWxlcnRzQ291bnQgPSAwO1xuICAgICAgbGV0IHZ1bG5Db3VudCA9IDA7XG4gICAgICBsZXQgbGlua2VkQWdlbnRzID0gMDtcbiAgICAgIGxldCBzdGFsZUNvdW50ID0gMDtcbiAgICAgIHRyeSB7XG4gICAgICAgIGNvbnN0IFtpYywgYWMsIHZjLCBpZFJlcywgc3RhbGVSZXNdID0gYXdhaXQgUHJvbWlzZS5hbGwoW1xuICAgICAgICAgIGNsaWVudC5jb3VudCh7IGluZGV4OiBERUZFTkRFUl9JTkNJREVOVFNfSU5ERVgsIGlnbm9yZV91bmF2YWlsYWJsZTogdHJ1ZSB9KSxcbiAgICAgICAgICBjbGllbnQuY291bnQoeyBpbmRleDogREVGRU5ERVJfQUxFUlRTX0lOREVYLCBpZ25vcmVfdW5hdmFpbGFibGU6IHRydWUgfSksXG4gICAgICAgICAgY2xpZW50LmNvdW50KHsgaW5kZXg6IERFRkVOREVSX1ZVTE5FUkFCSUxJVElFU19JTkRFWCwgaWdub3JlX3VuYXZhaWxhYmxlOiB0cnVlIH0pLFxuICAgICAgICAgIGNsaWVudC5jb3VudCh7IGluZGV4OiBERUZFTkRFUl9NQUNISU5FX0lERU5USVRZX0lOREVYLCBpZ25vcmVfdW5hdmFpbGFibGU6IHRydWUgfSksXG4gICAgICAgICAgY2xpZW50LnNlYXJjaCh7XG4gICAgICAgICAgICBpbmRleDogREVGRU5ERVJfTUFDSElORVNfSU5ERVgsXG4gICAgICAgICAgICBpZ25vcmVfdW5hdmFpbGFibGU6IHRydWUsXG4gICAgICAgICAgICBib2R5OiB7XG4gICAgICAgICAgICAgIHNpemU6IDAsXG4gICAgICAgICAgICAgIHF1ZXJ5OiB7XG4gICAgICAgICAgICAgICAgYm9vbDoge1xuICAgICAgICAgICAgICAgICAgZmlsdGVyOiBbeyByYW5nZTogeyBsYXN0X3NlZW46IHsgbHQ6IHN0YWxlRGF0ZSB9IH0gfV0sXG4gICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgdHJhY2tfdG90YWxfaGl0czogdHJ1ZSxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgfSksXG4gICAgICAgIF0pO1xuICAgICAgICBpbmNpZGVudHNDb3VudCA9IChpYy5ib2R5IGFzIGFueSk/LmNvdW50ID8/IDA7XG4gICAgICAgIGFsZXJ0c0NvdW50ID0gKGFjLmJvZHkgYXMgYW55KT8uY291bnQgPz8gMDtcbiAgICAgICAgdnVsbkNvdW50ID0gKHZjLmJvZHkgYXMgYW55KT8uY291bnQgPz8gMDtcbiAgICAgICAgbGlua2VkQWdlbnRzID0gKGlkUmVzLmJvZHkgYXMgYW55KT8uY291bnQgPz8gMDtcbiAgICAgICAgc3RhbGVDb3VudCA9XG4gICAgICAgICAgKHN0YWxlUmVzLmJvZHkgYXMgYW55KT8uaGl0cz8udG90YWw/LnZhbHVlID8/XG4gICAgICAgICAgKHN0YWxlUmVzLmJvZHkgYXMgYW55KT8uaGl0cz8udG90YWwgPz9cbiAgICAgICAgICAwO1xuICAgICAgfSBjYXRjaCB7XG4gICAgICAgIC8qIG9wdGlvbmFsIGluZGljZXMgKi9cbiAgICAgIH1cblxuICAgICAgY29uc3QgaGl0c0JvZHkgPSAobWFjaGluZXNSZXMuYm9keSBhcyBhbnkpPy5oaXRzID8/IHt9O1xuICAgICAgY29uc3QgYWdncyA9IChtYWNoaW5lc1Jlcy5ib2R5IGFzIGFueSk/LmFnZ3JlZ2F0aW9ucyA/PyB7fTtcbiAgICAgIGNvbnN0IHJlY2VudF9tYWNoaW5lcyA9IChoaXRzQm9keS5oaXRzID8/IFtdKS5tYXAoKGg6IGFueSkgPT4gaC5fc291cmNlKS5maWx0ZXIoQm9vbGVhbik7XG4gICAgICBjb25zdCB0b3RhbE1hY2hpbmVzID1cbiAgICAgICAgdHlwZW9mIGhpdHNCb2R5LnRvdGFsID09PSAnb2JqZWN0J1xuICAgICAgICAgID8gaGl0c0JvZHkudG90YWw/LnZhbHVlID8/IDBcbiAgICAgICAgICA6IGhpdHNCb2R5LnRvdGFsID8/IHJlY2VudF9tYWNoaW5lcy5sZW5ndGg7XG5cbiAgICAgIGxldCBieU9zQnVja2V0cyA9IGFnZ3MuYnlfb3M/LmJ1Y2tldHMgPz8gW107XG4gICAgICBsZXQgYnlFeHBvc3VyZUJ1Y2tldHMgPSBhZ2dzLmJ5X2V4cG9zdXJlPy5idWNrZXRzID8/IFtdO1xuICAgICAgbGV0IGJ5SGVhbHRoQnVja2V0cyA9IGFnZ3MuYnlfaGVhbHRoPy5idWNrZXRzID8/IFtdO1xuICAgICAgbGV0IGJ5Umlza0J1Y2tldHMgPSBhZ2dzLmJ5X3Jpc2s/LmJ1Y2tldHMgPz8gW107XG4gICAgICBsZXQgcmVjZW50TGlzdCA9IHJlY2VudF9tYWNoaW5lcztcbiAgICAgIGxldCB0b3RhbCA9IHRvdGFsTWFjaGluZXM7XG4gICAgICBsZXQgZGF0YVNvdXJjZTogJ2luZGV4JyB8ICdtZGUnID0gJ2luZGV4JztcblxuICAgICAgY29uc3QgbWNmZyA9IGdldE1kZUNvbmZpZygpO1xuICAgICAgaWYgKHRvdGFsID09PSAwICYmIG1jZmcpIHtcbiAgICAgICAgdHJ5IHtcbiAgICAgICAgICBjb25zdCByYXcgPSBhd2FpdCBmZXRjaEFsbE1hY2hpbmVzTGltaXRlZChtY2ZnLCAxMCk7XG4gICAgICAgICAgY29uc3QgdGlkID0gbWNmZy50ZW5hbnRJZDtcbiAgICAgICAgICBjb25zdCBub3JtYWxpemVkID0gcmF3Lm1hcCgobSkgPT5cbiAgICAgICAgICAgIG5vcm1hbGl6ZU1kZU1hY2hpbmUobSBhcyBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPiwgdGlkKVxuICAgICAgICAgICk7XG4gICAgICAgICAgaWYgKG5vcm1hbGl6ZWQubGVuZ3RoID4gMCkge1xuICAgICAgICAgICAgZGF0YVNvdXJjZSA9ICdtZGUnO1xuICAgICAgICAgICAgdG90YWwgPSBub3JtYWxpemVkLmxlbmd0aDtcbiAgICAgICAgICAgIHJlY2VudExpc3QgPSBub3JtYWxpemVkXG4gICAgICAgICAgICAgIC5zbGljZSgpXG4gICAgICAgICAgICAgIC5zb3J0KChhLCBiKSA9PiB7XG4gICAgICAgICAgICAgICAgY29uc3QgdGEgPSBhLmxhc3Rfc2VlbiA/IG5ldyBEYXRlKFN0cmluZyhhLmxhc3Rfc2VlbikpLmdldFRpbWUoKSA6IDA7XG4gICAgICAgICAgICAgICAgY29uc3QgdGIgPSBiLmxhc3Rfc2VlbiA/IG5ldyBEYXRlKFN0cmluZyhiLmxhc3Rfc2VlbikpLmdldFRpbWUoKSA6IDA7XG4gICAgICAgICAgICAgICAgcmV0dXJuIHRiIC0gdGE7XG4gICAgICAgICAgICAgIH0pXG4gICAgICAgICAgICAgIC5zbGljZSgwLCAxMCk7XG4gICAgICAgICAgICBjb25zdCBvc01hcDogUmVjb3JkPHN0cmluZywgbnVtYmVyPiA9IHt9O1xuICAgICAgICAgICAgY29uc3QgZXhNYXA6IFJlY29yZDxzdHJpbmcsIG51bWJlcj4gPSB7fTtcbiAgICAgICAgICAgIGNvbnN0IGhlYWx0aE1hcDogUmVjb3JkPHN0cmluZywgbnVtYmVyPiA9IHt9O1xuICAgICAgICAgICAgY29uc3Qgcmlza01hcDogUmVjb3JkPHN0cmluZywgbnVtYmVyPiA9IHt9O1xuICAgICAgICAgICAgbm9ybWFsaXplZC5mb3JFYWNoKChyKSA9PiB7XG4gICAgICAgICAgICAgIGNvbnN0IG9zID0gU3RyaW5nKHIub3NfcGxhdGZvcm0gfHwgJ1Vua25vd24nKTtcbiAgICAgICAgICAgICAgb3NNYXBbb3NdID0gKG9zTWFwW29zXSB8fCAwKSArIDE7XG4gICAgICAgICAgICAgIGNvbnN0IGV4ID0gU3RyaW5nKHIuZXhwb3N1cmVfbGV2ZWwgfHwgJ3Vua25vd24nKTtcbiAgICAgICAgICAgICAgZXhNYXBbZXhdID0gKGV4TWFwW2V4XSB8fCAwKSArIDE7XG4gICAgICAgICAgICAgIGNvbnN0IGhzID0gU3RyaW5nKHIuaGVhbHRoX3N0YXR1cyB8fCAndW5rbm93bicpO1xuICAgICAgICAgICAgICBoZWFsdGhNYXBbaHNdID0gKGhlYWx0aE1hcFtoc10gfHwgMCkgKyAxO1xuICAgICAgICAgICAgICBjb25zdCBycyA9IFN0cmluZyhyLnJpc2tfc2NvcmUgfHwgJ3Vua25vd24nKTtcbiAgICAgICAgICAgICAgcmlza01hcFtyc10gPSAocmlza01hcFtyc10gfHwgMCkgKyAxO1xuICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICBieU9zQnVja2V0cyA9IE9iamVjdC5lbnRyaWVzKG9zTWFwKS5tYXAoKFtrZXksIGRvY19jb3VudF0pID0+ICh7IGtleSwgZG9jX2NvdW50IH0pKTtcbiAgICAgICAgICAgIGJ5RXhwb3N1cmVCdWNrZXRzID0gT2JqZWN0LmVudHJpZXMoZXhNYXApLm1hcCgoW2tleSwgZG9jX2NvdW50XSkgPT4gKHsga2V5LCBkb2NfY291bnQgfSkpO1xuICAgICAgICAgICAgYnlIZWFsdGhCdWNrZXRzID0gT2JqZWN0LmVudHJpZXMoaGVhbHRoTWFwKS5tYXAoKFtrZXksIGRvY19jb3VudF0pID0+ICh7XG4gICAgICAgICAgICAgIGtleSxcbiAgICAgICAgICAgICAgZG9jX2NvdW50LFxuICAgICAgICAgICAgfSkpO1xuICAgICAgICAgICAgYnlSaXNrQnVja2V0cyA9IE9iamVjdC5lbnRyaWVzKHJpc2tNYXApLm1hcCgoW2tleSwgZG9jX2NvdW50XSkgPT4gKHtcbiAgICAgICAgICAgICAga2V5LFxuICAgICAgICAgICAgICBkb2NfY291bnQsXG4gICAgICAgICAgICB9KSk7XG4gICAgICAgICAgICBzdGFsZUNvdW50ID0gbm9ybWFsaXplZC5maWx0ZXIoXG4gICAgICAgICAgICAgIChyKSA9PiAhci5sYXN0X3NlZW4gfHwgbmV3IERhdGUoU3RyaW5nKHIubGFzdF9zZWVuKSkgPCBuZXcgRGF0ZShzdGFsZURhdGUpXG4gICAgICAgICAgICApLmxlbmd0aDtcbiAgICAgICAgICB9XG4gICAgICAgIH0gY2F0Y2gge1xuICAgICAgICAgIC8qIGtlZXAgaW5kZXggZW1wdHkgc3RhdGUgKi9cbiAgICAgICAgfVxuICAgICAgfVxuXG4gICAgICBsZXQgbGl2ZUluY2lkZW50c0NvdW50OiBudW1iZXIgfCBudWxsID0gbnVsbDtcbiAgICAgIGxldCBsaXZlQWxlcnRzQ291bnQ6IG51bWJlciB8IG51bGwgPSBudWxsO1xuICAgICAgbGV0IGdyYXBoRXJyb3I6IHN0cmluZyB8IG51bGwgPSBudWxsO1xuICAgICAgY29uc3QgZ2NmZyA9IGdldEdyYXBoU2VjdXJpdHlDb25maWcoKTtcbiAgICAgIGlmIChnY2ZnKSB7XG4gICAgICAgIHRyeSB7XG4gICAgICAgICAgbGl2ZUluY2lkZW50c0NvdW50ID0gYXdhaXQgY291bnRTZWN1cml0eUNvbGxlY3Rpb24oZ2NmZywgJ2luY2lkZW50cycpO1xuICAgICAgICB9IGNhdGNoIChlKSB7XG4gICAgICAgICAgZ3JhcGhFcnJvciA9IG1hcEdyYXBoRXJyKGUpLmJvZHk7XG4gICAgICAgICAgbGl2ZUluY2lkZW50c0NvdW50ID0gbnVsbDtcbiAgICAgICAgfVxuICAgICAgICB0cnkge1xuICAgICAgICAgIGxpdmVBbGVydHNDb3VudCA9IGF3YWl0IGNvdW50U2VjdXJpdHlDb2xsZWN0aW9uKGdjZmcsICdhbGVydHNfdjInKTtcbiAgICAgICAgfSBjYXRjaCAoZSkge1xuICAgICAgICAgIGlmICghZ3JhcGhFcnJvcikgZ3JhcGhFcnJvciA9IG1hcEdyYXBoRXJyKGUpLmJvZHk7XG4gICAgICAgICAgbGl2ZUFsZXJ0c0NvdW50ID0gbnVsbDtcbiAgICAgICAgfVxuICAgICAgfVxuXG4gICAgICByZXR1cm4gcmVzLm9rKHtcbiAgICAgICAgYm9keToge1xuICAgICAgICAgIHRvdGFsX21hY2hpbmVzOiB0b3RhbCxcbiAgICAgICAgICBieV9vczogYnlPc0J1Y2tldHMsXG4gICAgICAgICAgYnlfZXhwb3N1cmU6IGJ5RXhwb3N1cmVCdWNrZXRzLFxuICAgICAgICAgIGJ5X2hlYWx0aDogYnlIZWFsdGhCdWNrZXRzLFxuICAgICAgICAgIGJ5X3Jpc2s6IGJ5Umlza0J1Y2tldHMsXG4gICAgICAgICAgcmVjZW50X21hY2hpbmVzOiByZWNlbnRMaXN0LFxuICAgICAgICAgIGluY2lkZW50c19pbmRleF9jb3VudDogaW5jaWRlbnRzQ291bnQsXG4gICAgICAgICAgYWxlcnRzX2luZGV4X2NvdW50OiBhbGVydHNDb3VudCxcbiAgICAgICAgICB2dWxuZXJhYmlsaXRpZXNfaW5kZXhfY291bnQ6IHZ1bG5Db3VudCxcbiAgICAgICAgICBsaW5rZWRfYWdlbnRzX2NvdW50OiBsaW5rZWRBZ2VudHMsXG4gICAgICAgICAgc3RhbGVfbWFjaGluZXNfY291bnQ6IHN0YWxlQ291bnQsXG4gICAgICAgICAgZ3JhcGhfaW5jaWRlbnRzX2xpdmVfY291bnQ6IGxpdmVJbmNpZGVudHNDb3VudCxcbiAgICAgICAgICBncmFwaF9hbGVydHNfbGl2ZV9jb3VudDogbGl2ZUFsZXJ0c0NvdW50LFxuICAgICAgICAgIGdyYXBoX2Vycm9yX2hpbnQ6IGdyYXBoRXJyb3IsXG4gICAgICAgICAgZGF0YV9zb3VyY2U6IGRhdGFTb3VyY2UsXG4gICAgICAgIH0sXG4gICAgICB9KTtcbiAgICB9IGNhdGNoIChlcnI6IGFueSkge1xuICAgICAgcmV0dXJuIHJlcy5jdXN0b21FcnJvcih7XG4gICAgICAgIHN0YXR1c0NvZGU6IGVyci5zdGF0dXNDb2RlID8/IDUwMCxcbiAgICAgICAgYm9keTogZXJyLm1lc3NhZ2UgPz8gU3RyaW5nKGVyciksXG4gICAgICB9KTtcbiAgICB9XG4gIH0pO1xuXG4gIHJvdXRlci5nZXQoXG4gICAge1xuICAgICAgcGF0aDogJy9hcGkvZGVmZW5kZXJfcGx1Z2luL3Z1bG5lcmFiaWxpdGllcycsXG4gICAgICB2YWxpZGF0ZToge1xuICAgICAgICBxdWVyeTogc2NoZW1hLm9iamVjdCh7XG4gICAgICAgICAgc2l6ZTogc2NoZW1hLm1heWJlKHNjaGVtYS5udW1iZXIoKSksXG4gICAgICAgICAgZnJvbTogc2NoZW1hLm1heWJlKHNjaGVtYS5udW1iZXIoKSksXG4gICAgICAgICAgc291cmNlOiBzY2hlbWEubWF5YmUoc2NoZW1hLnN0cmluZygpKSxcbiAgICAgICAgfSksXG4gICAgICB9LFxuICAgIH0sXG4gICAgYXN5bmMgKGNvbnRleHQsIHJlcSwgcmVzKSA9PiB7XG4gICAgICBjb25zdCBxID0gcmVxLnF1ZXJ5IGFzIHsgc2l6ZT86IG51bWJlcjsgZnJvbT86IG51bWJlcjsgc291cmNlPzogc3RyaW5nIH07XG4gICAgICBpZiAocS5zb3VyY2UgPT09ICdtZGUnKSB7XG4gICAgICAgIGNvbnN0IG1jZmcgPSBnZXRNZGVDb25maWcoKTtcbiAgICAgICAgaWYgKCFtY2ZnKSByZXR1cm4gcmVzLmN1c3RvbUVycm9yKHsgc3RhdHVzQ29kZTogNTAzLCBib2R5OiAnTURFIG5vdCBjb25maWd1cmVkLicgfSk7XG4gICAgICAgIHRyeSB7XG4gICAgICAgICAgY29uc3QgZGF0YSA9IChhd2FpdCBsaXN0T3JnVnVsbmVyYWJpbGl0aWVzKG1jZmcsIHEuc2l6ZSA/PyAyMDApKSBhcyB7XG4gICAgICAgICAgICB2YWx1ZT86IHVua25vd25bXTtcbiAgICAgICAgICB9O1xuICAgICAgICAgIGNvbnN0IHJvd3MgPSBkYXRhPy52YWx1ZSA/PyBbXTtcbiAgICAgICAgICBjb25zdCBmcm9tID0gcS5mcm9tID8/IDA7XG4gICAgICAgICAgY29uc3Qgc2l6ZSA9IHEuc2l6ZSA/PyA1MDtcbiAgICAgICAgICBjb25zdCBzbGljZSA9IHJvd3Muc2xpY2UoZnJvbSwgZnJvbSArIHNpemUpO1xuICAgICAgICAgIGNvbnN0IGhpdHMgPSBzbGljZS5tYXAoKHJvdzogYW55LCBpOiBudW1iZXIpID0+ICh7XG4gICAgICAgICAgICBfaWQ6IFN0cmluZyhyb3cuaWQgPz8gcm93LmN2ZUlkID8/IGkpLFxuICAgICAgICAgICAgX3NvdXJjZTogdHlwZW9mIHJvdyA9PT0gJ29iamVjdCcgPyByb3cgOiB7IHJhdzogcm93IH0sXG4gICAgICAgICAgfSkpO1xuICAgICAgICAgIHJldHVybiByZXMub2soe1xuICAgICAgICAgICAgYm9keToge1xuICAgICAgICAgICAgICBoaXRzLFxuICAgICAgICAgICAgICB0b3RhbDogeyB2YWx1ZTogcm93cy5sZW5ndGgsIHJlbGF0aW9uOiAnZXEnIH0sXG4gICAgICAgICAgICAgIHNvdXJjZTogJ21kZScsXG4gICAgICAgICAgICB9LFxuICAgICAgICAgIH0pO1xuICAgICAgICB9IGNhdGNoIChlcnI6IGFueSkge1xuICAgICAgICAgIHJldHVybiByZXMuY3VzdG9tRXJyb3Ioe1xuICAgICAgICAgICAgc3RhdHVzQ29kZTogbWRlRXJyb3JTdGF0dXMoZXJyKSxcbiAgICAgICAgICAgIGJvZHk6IGVycj8ubWVzc2FnZSA/PyBTdHJpbmcoZXJyKSxcbiAgICAgICAgICB9KTtcbiAgICAgICAgfVxuICAgICAgfVxuICAgICAgdHJ5IHtcbiAgICAgICAgY29uc3QgY2xpZW50ID0gZ2V0Q2xpZW50KGNvbnRleHQpO1xuICAgICAgICBjb25zdCB7IHNpemUgPSA1MCwgZnJvbSA9IDAgfSA9IHE7XG4gICAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgY2xpZW50LnNlYXJjaCh7XG4gICAgICAgICAgaW5kZXg6IERFRkVOREVSX1ZVTE5FUkFCSUxJVElFU19JTkRFWCxcbiAgICAgICAgICBpZ25vcmVfdW5hdmFpbGFibGU6IHRydWUsXG4gICAgICAgICAgYm9keToge1xuICAgICAgICAgICAgc2l6ZSxcbiAgICAgICAgICAgIGZyb20sXG4gICAgICAgICAgICBzb3J0OiBbeyBzeW5jX3RzOiB7IG9yZGVyOiAnZGVzYycgfSB9XSxcbiAgICAgICAgICAgIHF1ZXJ5OiB7IG1hdGNoX2FsbDoge30gfSxcbiAgICAgICAgICB9LFxuICAgICAgICB9KTtcbiAgICAgICAgY29uc3QgaGl0cyA9IChyZXNwb25zZS5ib2R5IGFzIGFueSk/LmhpdHMgPz8ge307XG4gICAgICAgIHJldHVybiByZXMub2soeyBib2R5OiB7IGhpdHM6IGhpdHMuaGl0cyA/PyBbXSwgdG90YWw6IGhpdHMudG90YWwsIHNvdXJjZTogJ2luZGV4JyB9IH0pO1xuICAgICAgfSBjYXRjaCAoZXJyOiBhbnkpIHtcbiAgICAgICAgcmV0dXJuIHJlcy5jdXN0b21FcnJvcih7XG4gICAgICAgICAgc3RhdHVzQ29kZTogZXJyLnN0YXR1c0NvZGUgPz8gNTAwLFxuICAgICAgICAgIGJvZHk6IGVyci5tZXNzYWdlID8/IFN0cmluZyhlcnIpLFxuICAgICAgICB9KTtcbiAgICAgIH1cbiAgICB9XG4gICk7XG5cbiAgcm91dGVyLmdldChcbiAgICB7XG4gICAgICBwYXRoOiAnL2FwaS9kZWZlbmRlcl9wbHVnaW4vaW5jaWRlbnRzL2xpdmUnLFxuICAgICAgdmFsaWRhdGU6IHtcbiAgICAgICAgcXVlcnk6IHNjaGVtYS5vYmplY3Qoe1xuICAgICAgICAgIHRvcDogc2NoZW1hLm1heWJlKHNjaGVtYS5udW1iZXIoKSksXG4gICAgICAgIH0pLFxuICAgICAgfSxcbiAgICB9LFxuICAgIGFzeW5jIChfY29udGV4dCwgcmVxLCByZXMpID0+IHtcbiAgICAgIGNvbnN0IGNvbmZpZyA9IGdldEdyYXBoU2VjdXJpdHlDb25maWcoKTtcbiAgICAgIGlmICghY29uZmlnKSB7XG4gICAgICAgIHJldHVybiByZXMuY3VzdG9tRXJyb3Ioe1xuICAgICAgICAgIHN0YXR1c0NvZGU6IDUwMyxcbiAgICAgICAgICBib2R5OiAnR3JhcGggc2VjdXJpdHkgbm90IGNvbmZpZ3VyZWQuJyxcbiAgICAgICAgfSk7XG4gICAgICB9XG4gICAgICB0cnkge1xuICAgICAgICBjb25zdCB0b3AgPSAocmVxLnF1ZXJ5IGFzIHsgdG9wPzogbnVtYmVyIH0pLnRvcCA/PyAyNTtcbiAgICAgICAgY29uc3QgZGF0YSA9IGF3YWl0IGxpc3RJbmNpZGVudHMoY29uZmlnLCB0b3ApO1xuICAgICAgICByZXR1cm4gcmVzLm9rKHsgYm9keTogZGF0YSB9KTtcbiAgICAgIH0gY2F0Y2ggKGVycjogdW5rbm93bikge1xuICAgICAgICBjb25zdCB7IHN0YXR1cywgYm9keSB9ID0gbWFwR3JhcGhFcnIoZXJyKTtcbiAgICAgICAgcmV0dXJuIHJlcy5jdXN0b21FcnJvcih7IHN0YXR1c0NvZGU6IHN0YXR1cywgYm9keSB9KTtcbiAgICAgIH1cbiAgICB9XG4gICk7XG5cbiAgcm91dGVyLmdldChcbiAgICB7XG4gICAgICBwYXRoOiAnL2FwaS9kZWZlbmRlcl9wbHVnaW4vYWxlcnRzL2xpdmUnLFxuICAgICAgdmFsaWRhdGU6IHtcbiAgICAgICAgcXVlcnk6IHNjaGVtYS5vYmplY3Qoe1xuICAgICAgICAgIHRvcDogc2NoZW1hLm1heWJlKHNjaGVtYS5udW1iZXIoKSksXG4gICAgICAgIH0pLFxuICAgICAgfSxcbiAgICB9LFxuICAgIGFzeW5jIChfY29udGV4dCwgcmVxLCByZXMpID0+IHtcbiAgICAgIGNvbnN0IGNvbmZpZyA9IGdldEdyYXBoU2VjdXJpdHlDb25maWcoKTtcbiAgICAgIGlmICghY29uZmlnKSB7XG4gICAgICAgIHJldHVybiByZXMuY3VzdG9tRXJyb3Ioe1xuICAgICAgICAgIHN0YXR1c0NvZGU6IDUwMyxcbiAgICAgICAgICBib2R5OiAnR3JhcGggc2VjdXJpdHkgbm90IGNvbmZpZ3VyZWQuJyxcbiAgICAgICAgfSk7XG4gICAgICB9XG4gICAgICB0cnkge1xuICAgICAgICBjb25zdCB0b3AgPSAocmVxLnF1ZXJ5IGFzIHsgdG9wPzogbnVtYmVyIH0pLnRvcCA/PyAyNTtcbiAgICAgICAgY29uc3QgZGF0YSA9IGF3YWl0IGxpc3RBbGVydHNWMihjb25maWcsIHRvcCk7XG4gICAgICAgIHJldHVybiByZXMub2soeyBib2R5OiBkYXRhIH0pO1xuICAgICAgfSBjYXRjaCAoZXJyOiB1bmtub3duKSB7XG4gICAgICAgIGNvbnN0IHsgc3RhdHVzLCBib2R5IH0gPSBtYXBHcmFwaEVycihlcnIpO1xuICAgICAgICByZXR1cm4gcmVzLmN1c3RvbUVycm9yKHsgc3RhdHVzQ29kZTogc3RhdHVzLCBib2R5IH0pO1xuICAgICAgfVxuICAgIH1cbiAgKTtcblxuICByb3V0ZXIucG9zdChcbiAgICB7XG4gICAgICBwYXRoOiAnL2FwaS9kZWZlbmRlcl9wbHVnaW4vaHVudGluZycsXG4gICAgICB2YWxpZGF0ZToge1xuICAgICAgICBib2R5OiBzY2hlbWEub2JqZWN0KHtcbiAgICAgICAgICBxdWVyeTogc2NoZW1hLnN0cmluZygpLFxuICAgICAgICAgIHRpbWVzcGFuOiBzY2hlbWEubWF5YmUoc2NoZW1hLnN0cmluZygpKSxcbiAgICAgICAgfSksXG4gICAgICB9LFxuICAgIH0sXG4gICAgYXN5bmMgKF9jb250ZXh0LCByZXEsIHJlcykgPT4ge1xuICAgICAgY29uc3QgY29uZmlnID0gZ2V0R3JhcGhTZWN1cml0eUNvbmZpZygpO1xuICAgICAgaWYgKCFjb25maWcpIHtcbiAgICAgICAgcmV0dXJuIHJlcy5jdXN0b21FcnJvcih7XG4gICAgICAgICAgc3RhdHVzQ29kZTogNTAzLFxuICAgICAgICAgIGJvZHk6ICdHcmFwaCBzZWN1cml0eSBub3QgY29uZmlndXJlZC4nLFxuICAgICAgICB9KTtcbiAgICAgIH1cbiAgICAgIHRyeSB7XG4gICAgICAgIGNvbnN0IHsgcXVlcnksIHRpbWVzcGFuIH0gPSByZXEuYm9keSBhcyB7IHF1ZXJ5OiBzdHJpbmc7IHRpbWVzcGFuPzogc3RyaW5nIH07XG4gICAgICAgIGNvbnN0IHN0YXJ0ZWQgPSBEYXRlLm5vdygpO1xuICAgICAgICBjb25zdCBkYXRhID0gYXdhaXQgcnVuSHVudGluZ1F1ZXJ5KGNvbmZpZywgcXVlcnksIHRpbWVzcGFuIHx8ICdQN0QnKTtcbiAgICAgICAgY29uc3Qgcm93Q291bnQgPSBBcnJheS5pc0FycmF5KChkYXRhIGFzIGFueSk/LnJlc3VsdHMpXG4gICAgICAgICAgPyAoZGF0YSBhcyBhbnkpLnJlc3VsdHMubGVuZ3RoXG4gICAgICAgICAgOiAwO1xuICAgICAgICByZXR1cm4gcmVzLm9rKHtcbiAgICAgICAgICBib2R5OiB7XG4gICAgICAgICAgICAuLi4oKGRhdGEgYXMgb2JqZWN0KSB8fCB7fSksXG4gICAgICAgICAgICBleGVjdXRpb25UaW1lTXM6IERhdGUubm93KCkgLSBzdGFydGVkLFxuICAgICAgICAgICAgcm93Q291bnQsXG4gICAgICAgICAgfSxcbiAgICAgICAgfSk7XG4gICAgICB9IGNhdGNoIChlcnI6IHVua25vd24pIHtcbiAgICAgICAgY29uc3QgeyBzdGF0dXMsIGJvZHkgfSA9IG1hcEdyYXBoRXJyKGVycik7XG4gICAgICAgIHJldHVybiByZXMuY3VzdG9tRXJyb3IoeyBzdGF0dXNDb2RlOiBzdGF0dXMsIGJvZHkgfSk7XG4gICAgICB9XG4gICAgfVxuICApO1xuXG4gIHJvdXRlci5nZXQoXG4gICAge1xuICAgICAgcGF0aDogJy9hcGkvZGVmZW5kZXJfcGx1Z2luL2luZGljYXRvcnMvbGl2ZScsXG4gICAgICB2YWxpZGF0ZToge1xuICAgICAgICBxdWVyeTogc2NoZW1hLm9iamVjdCh7XG4gICAgICAgICAgdG9wOiBzY2hlbWEubWF5YmUoc2NoZW1hLm51bWJlcigpKSxcbiAgICAgICAgfSksXG4gICAgICB9LFxuICAgIH0sXG4gICAgYXN5bmMgKF9jb250ZXh0LCByZXEsIHJlcykgPT4ge1xuICAgICAgY29uc3QgY29uZmlnID0gZ2V0TWRlQ29uZmlnKCk7XG4gICAgICBpZiAoIWNvbmZpZykge1xuICAgICAgICByZXR1cm4gcmVzLmN1c3RvbUVycm9yKHsgc3RhdHVzQ29kZTogNTAzLCBib2R5OiAnTURFIG5vdCBjb25maWd1cmVkLicgfSk7XG4gICAgICB9XG4gICAgICB0cnkge1xuICAgICAgICBjb25zdCB0b3AgPSAocmVxLnF1ZXJ5IGFzIHsgdG9wPzogbnVtYmVyIH0pLnRvcCA/PyAxMDA7XG4gICAgICAgIGNvbnN0IGRhdGEgPSBhd2FpdCBsaXN0SW5kaWNhdG9ycyhjb25maWcsIHRvcCk7XG4gICAgICAgIHJldHVybiByZXMub2soeyBib2R5OiBkYXRhIH0pO1xuICAgICAgfSBjYXRjaCAoZXJyOiBhbnkpIHtcbiAgICAgICAgcmV0dXJuIHJlcy5jdXN0b21FcnJvcih7IHN0YXR1c0NvZGU6IG1kZUVycm9yU3RhdHVzKGVyciksIGJvZHk6IGVycj8ubWVzc2FnZSA/PyBTdHJpbmcoZXJyKSB9KTtcbiAgICAgIH1cbiAgICB9XG4gICk7XG5cbiAgcm91dGVyLmdldChcbiAgICB7XG4gICAgICBwYXRoOiAnL2FwaS9kZWZlbmRlcl9wbHVnaW4vYXVkaXQtbG9nJyxcbiAgICAgIHZhbGlkYXRlOiB7XG4gICAgICAgIHF1ZXJ5OiBzY2hlbWEub2JqZWN0KHtcbiAgICAgICAgICBzaXplOiBzY2hlbWEubWF5YmUoc2NoZW1hLm51bWJlcigpKSxcbiAgICAgICAgfSksXG4gICAgICB9LFxuICAgIH0sXG4gICAgYXN5bmMgKGNvbnRleHQsIHJlcSwgcmVzKSA9PiB7XG4gICAgICB0cnkge1xuICAgICAgICBjb25zdCBjbGllbnQgPSBnZXRDbGllbnQoY29udGV4dCk7XG4gICAgICAgIGNvbnN0IHNpemUgPSAocmVxLnF1ZXJ5IGFzIHsgc2l6ZT86IG51bWJlciB9KS5zaXplID8/IDUwO1xuICAgICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGNsaWVudC5zZWFyY2goe1xuICAgICAgICAgIGluZGV4OiBERUZFTkRFUl9BVURJVF9MT0dfSU5ERVgsXG4gICAgICAgICAgaWdub3JlX3VuYXZhaWxhYmxlOiB0cnVlLFxuICAgICAgICAgIGJvZHk6IHtcbiAgICAgICAgICAgIHNpemUsXG4gICAgICAgICAgICBzb3J0OiBbeyB0aW1lc3RhbXA6IHsgb3JkZXI6ICdkZXNjJyB9IH1dLFxuICAgICAgICAgICAgcXVlcnk6IHsgbWF0Y2hfYWxsOiB7fSB9LFxuICAgICAgICAgIH0sXG4gICAgICAgIH0pO1xuICAgICAgICBjb25zdCBoaXRzID0gKHJlc3BvbnNlLmJvZHkgYXMgYW55KT8uaGl0cz8uaGl0cyA/PyBbXTtcbiAgICAgICAgcmV0dXJuIHJlcy5vayh7IGJvZHk6IHsgZW50cmllczogaGl0cy5tYXAoKGg6IGFueSkgPT4gaC5fc291cmNlKSB9IH0pO1xuICAgICAgfSBjYXRjaCAoZXJyOiBhbnkpIHtcbiAgICAgICAgcmV0dXJuIHJlcy5jdXN0b21FcnJvcih7XG4gICAgICAgICAgc3RhdHVzQ29kZTogZXJyLnN0YXR1c0NvZGUgPz8gNTAwLFxuICAgICAgICAgIGJvZHk6IGVyci5tZXNzYWdlID8/IFN0cmluZyhlcnIpLFxuICAgICAgICB9KTtcbiAgICAgIH1cbiAgICB9XG4gICk7XG5cbiAgcm91dGVyLnBvc3QoXG4gICAge1xuICAgICAgcGF0aDogJy9hcGkvZGVmZW5kZXJfcGx1Z2luL2FsZXJ0c19lbnJpY2htZW50JyxcbiAgICAgIHZhbGlkYXRlOiB7XG4gICAgICAgIGJvZHk6IHNjaGVtYS5vYmplY3Qoe1xuICAgICAgICAgIHNpemU6IHNjaGVtYS5tYXliZShzY2hlbWEubnVtYmVyKCkpLFxuICAgICAgICAgIGZyb206IHNjaGVtYS5tYXliZShzY2hlbWEubnVtYmVyKCkpLFxuICAgICAgICAgIHRpbWVfZnJvbTogc2NoZW1hLm1heWJlKHNjaGVtYS5zdHJpbmcoKSksXG4gICAgICAgICAgdGltZV90bzogc2NoZW1hLm1heWJlKHNjaGVtYS5zdHJpbmcoKSksXG4gICAgICAgICAgZGVmZW5kZXJfY29ycmVsYXRlZF9vbmx5OiBzY2hlbWEubWF5YmUoc2NoZW1hLmJvb2xlYW4oKSksXG4gICAgICAgIH0pLFxuICAgICAgfSxcbiAgICB9LFxuICAgIGFzeW5jIChjb250ZXh0LCByZXEsIHJlcykgPT4ge1xuICAgICAgdHJ5IHtcbiAgICAgICAgY29uc3QgY2xpZW50ID0gZ2V0Q2xpZW50KGNvbnRleHQpO1xuICAgICAgICBjb25zdCB7XG4gICAgICAgICAgc2l6ZSA9IDI1LFxuICAgICAgICAgIGZyb20gPSAwLFxuICAgICAgICAgIHRpbWVfZnJvbSxcbiAgICAgICAgICB0aW1lX3RvLFxuICAgICAgICAgIGRlZmVuZGVyX2NvcnJlbGF0ZWRfb25seSA9IHRydWUsXG4gICAgICAgIH0gPSByZXEuYm9keTtcblxuICAgICAgICBjb25zdCBub3cgPSBuZXcgRGF0ZSgpO1xuICAgICAgICBjb25zdCBkZWZhdWx0VG8gPSBub3cudG9JU09TdHJpbmcoKTtcbiAgICAgICAgY29uc3QgZGVmYXVsdEZyb20gPSBuZXcgRGF0ZShub3cuZ2V0VGltZSgpIC0gNyAqIDI0ICogNjAgKiA2MCAqIDEwMDApLnRvSVNPU3RyaW5nKCk7XG4gICAgICAgIGNvbnN0IHRpbWVHdGUgPSB0aW1lX2Zyb20gfHwgZGVmYXVsdEZyb207XG4gICAgICAgIGNvbnN0IHRpbWVMdGUgPSB0aW1lX3RvIHx8IGRlZmF1bHRUbztcbiAgICAgICAgY29uc3QgdGltZVJhbmdlRmlsdGVyID0geyByYW5nZTogeyB0aW1lc3RhbXA6IHsgZ3RlOiB0aW1lR3RlLCBsdGU6IHRpbWVMdGUgfSB9IH07XG5cbiAgICAgICAgbGV0IGFnZW50SWRzVG9RdWVyeTogc3RyaW5nW10gfCBudWxsID0gbnVsbDtcbiAgICAgICAgY29uc3QgYWdlbnRUb0RlZmVuZGVyOiBSZWNvcmQ8c3RyaW5nLCBzdHJpbmc+ID0ge307XG5cbiAgICAgICAgaWYgKGRlZmVuZGVyX2NvcnJlbGF0ZWRfb25seSkge1xuICAgICAgICAgIGNvbnN0IGlkZW50aXR5UmVzID0gYXdhaXQgY2xpZW50LnNlYXJjaCh7XG4gICAgICAgICAgICBpbmRleDogREVGRU5ERVJfTUFDSElORV9JREVOVElUWV9JTkRFWCxcbiAgICAgICAgICAgIGlnbm9yZV91bmF2YWlsYWJsZTogdHJ1ZSxcbiAgICAgICAgICAgIGJvZHk6IHtcbiAgICAgICAgICAgICAgc2l6ZTogMTAwMCxcbiAgICAgICAgICAgICAgX3NvdXJjZTogWyd3YXp1aF9hZ2VudF9pZCcsICdkZWZlbmRlcl9tYWNoaW5lX2lkJywgJ2NvbXB1dGVyX2Ruc19uYW1lJ10sXG4gICAgICAgICAgICAgIHF1ZXJ5OiB7IG1hdGNoX2FsbDoge30gfSxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgfSk7XG4gICAgICAgICAgY29uc3QgaWRlbnRpdHlIaXRzID0gKGlkZW50aXR5UmVzLmJvZHkgYXMgYW55KT8uaGl0cz8uaGl0cyA/PyBbXTtcbiAgICAgICAgICBhZ2VudElkc1RvUXVlcnkgPSBpZGVudGl0eUhpdHNcbiAgICAgICAgICAgIC5tYXAoKGg6IGFueSkgPT4gaC5fc291cmNlPy53YXp1aF9hZ2VudF9pZClcbiAgICAgICAgICAgIC5maWx0ZXIoKGlkOiBzdHJpbmcpID0+IGlkICYmIGlkICE9PSAnMDAwJyk7XG4gICAgICAgICAgaWYgKGFnZW50SWRzVG9RdWVyeS5sZW5ndGggPT09IDApIHtcbiAgICAgICAgICAgIHJldHVybiByZXMub2soe1xuICAgICAgICAgICAgICBib2R5OiB7XG4gICAgICAgICAgICAgICAgYWxlcnRzOiBbXSxcbiAgICAgICAgICAgICAgICBlbnJpY2htZW50czoge30sXG4gICAgICAgICAgICAgICAgdG90YWw6IDAsXG4gICAgICAgICAgICAgICAgaWRlbnRpdHlfY291bnQ6IDAsXG4gICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICB9KTtcbiAgICAgICAgICB9XG4gICAgICAgICAgaWRlbnRpdHlIaXRzLmZvckVhY2goKGg6IGFueSkgPT4ge1xuICAgICAgICAgICAgY29uc3QgcyA9IGguX3NvdXJjZTtcbiAgICAgICAgICAgIGlmIChzPy53YXp1aF9hZ2VudF9pZCkgYWdlbnRUb0RlZmVuZGVyW3Mud2F6dWhfYWdlbnRfaWRdID0gcy5kZWZlbmRlcl9tYWNoaW5lX2lkO1xuICAgICAgICAgIH0pO1xuICAgICAgICB9XG5cbiAgICAgICAgY29uc3QgbXVzdDogYW55W10gPSBbdGltZVJhbmdlRmlsdGVyXTtcbiAgICAgICAgbXVzdC5wdXNoKHsgYm9vbDogeyBtdXN0X25vdDogW3sgdGVybTogeyAnYWdlbnQuaWQnOiAnMDAwJyB9IH1dIH0gfSk7XG4gICAgICAgIGlmIChhZ2VudElkc1RvUXVlcnkgJiYgYWdlbnRJZHNUb1F1ZXJ5Lmxlbmd0aCA+IDApIHtcbiAgICAgICAgICBtdXN0LnB1c2goeyB0ZXJtczogeyAnYWdlbnQuaWQnOiBhZ2VudElkc1RvUXVlcnkgfSB9KTtcbiAgICAgICAgfVxuXG4gICAgICAgIGNvbnN0IGFsZXJ0c0JvZHkgPSB7XG4gICAgICAgICAgZnJvbSxcbiAgICAgICAgICBzaXplLFxuICAgICAgICAgIHNvcnQ6IFt7IHRpbWVzdGFtcDogeyBvcmRlcjogJ2Rlc2MnIH0gfV0sXG4gICAgICAgICAgX3NvdXJjZTogWydhZ2VudC5pZCcsICdhZ2VudC5uYW1lJywgJ3J1bGUuZGVzY3JpcHRpb24nLCAncnVsZS5sZXZlbCcsICd0aW1lc3RhbXAnXSxcbiAgICAgICAgICBxdWVyeTogeyBib29sOiB7IG11c3QgfSB9LFxuICAgICAgICB9O1xuXG4gICAgICAgIGNvbnN0IFthbGVydHNSZXNwb25zZSwgY291bnRSZXNwb25zZV0gPSBhd2FpdCBQcm9taXNlLmFsbChbXG4gICAgICAgICAgY2xpZW50LnNlYXJjaCh7XG4gICAgICAgICAgICBpbmRleDogV0FaVUhfQUxFUlRTX1BBVFRFUk4sXG4gICAgICAgICAgICBpZ25vcmVfdW5hdmFpbGFibGU6IHRydWUsXG4gICAgICAgICAgICBib2R5OiBhbGVydHNCb2R5LFxuICAgICAgICAgIH0pLFxuICAgICAgICAgIGNsaWVudC5zZWFyY2goe1xuICAgICAgICAgICAgaW5kZXg6IFdBWlVIX0FMRVJUU19QQVRURVJOLFxuICAgICAgICAgICAgaWdub3JlX3VuYXZhaWxhYmxlOiB0cnVlLFxuICAgICAgICAgICAgYm9keToge1xuICAgICAgICAgICAgICBzaXplOiAwLFxuICAgICAgICAgICAgICBxdWVyeTogYWxlcnRzQm9keS5xdWVyeSxcbiAgICAgICAgICAgICAgdHJhY2tfdG90YWxfaGl0czogdHJ1ZSxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgfSksXG4gICAgICAgIF0pO1xuXG4gICAgICAgIGNvbnN0IGFsZXJ0SGl0cyA9IChhbGVydHNSZXNwb25zZS5ib2R5IGFzIGFueSk/LmhpdHM/LmhpdHMgPz8gW107XG4gICAgICAgIGNvbnN0IHRvdGFsID1cbiAgICAgICAgICAoY291bnRSZXNwb25zZS5ib2R5IGFzIGFueSk/LmhpdHM/LnRvdGFsPy52YWx1ZSA/P1xuICAgICAgICAgIChjb3VudFJlc3BvbnNlLmJvZHkgYXMgYW55KT8uaGl0cz8udG90YWwgPz9cbiAgICAgICAgICBhbGVydEhpdHMubGVuZ3RoO1xuXG4gICAgICAgIGNvbnN0IGVucmljaG1lbnRzOiBSZWNvcmQ8c3RyaW5nLCB7IGRlZmVuZGVyX21hY2hpbmVfaWQ/OiBzdHJpbmcgfT4gPSB7fTtcbiAgICAgICAgYWxlcnRIaXRzLmZvckVhY2goKGg6IGFueSkgPT4ge1xuICAgICAgICAgIGNvbnN0IGFpZCA9IGguX3NvdXJjZT8uYWdlbnQ/LmlkO1xuICAgICAgICAgIGlmIChhaWQgJiYgYWdlbnRUb0RlZmVuZGVyW2FpZF0pIHtcbiAgICAgICAgICAgIGVucmljaG1lbnRzW2guX2lkXSA9IHsgZGVmZW5kZXJfbWFjaGluZV9pZDogYWdlbnRUb0RlZmVuZGVyW2FpZF0gfTtcbiAgICAgICAgICB9XG4gICAgICAgIH0pO1xuXG4gICAgICAgIHJldHVybiByZXMub2soe1xuICAgICAgICAgIGJvZHk6IHtcbiAgICAgICAgICAgIGFsZXJ0czogYWxlcnRIaXRzLm1hcCgoaDogYW55KSA9PiAoe1xuICAgICAgICAgICAgICBpZDogaC5faWQsXG4gICAgICAgICAgICAgIC4uLmguX3NvdXJjZSxcbiAgICAgICAgICAgIH0pKSxcbiAgICAgICAgICAgIGVucmljaG1lbnRzLFxuICAgICAgICAgICAgdG90YWwsXG4gICAgICAgICAgICBpZGVudGl0eV9jb3VudDogT2JqZWN0LmtleXMoYWdlbnRUb0RlZmVuZGVyKS5sZW5ndGgsXG4gICAgICAgICAgfSxcbiAgICAgICAgfSk7XG4gICAgICB9IGNhdGNoIChlcnI6IGFueSkge1xuICAgICAgICByZXR1cm4gcmVzLmN1c3RvbUVycm9yKHtcbiAgICAgICAgICBzdGF0dXNDb2RlOiBlcnIuc3RhdHVzQ29kZSA/PyA1MDAsXG4gICAgICAgICAgYm9keTogZXJyLm1lc3NhZ2UgPz8gU3RyaW5nKGVyciksXG4gICAgICAgIH0pO1xuICAgICAgfVxuICAgIH1cbiAgKTtcbn1cbiJdLCJtYXBwaW5ncyI6Ijs7Ozs7O0FBS0EsSUFBQUEsYUFBQSxHQUFBQyxPQUFBO0FBQ0EsSUFBQUMsVUFBQSxHQUFBRCxPQUFBO0FBU0EsSUFBQUUsVUFBQSxHQUFBRixPQUFBO0FBZ0JBLElBQUFHLG9CQUFBLEdBQUFILE9BQUE7QUEvQkE7QUFDQTtBQUNBOztBQXNDQSxTQUFTSSxXQUFXQSxDQUFDQyxHQUFZLEVBQW9DO0VBQ25FLElBQUlBLEdBQUcsWUFBWUYsb0JBQUEsQ0FBQUcsYUFBYSxFQUFFO0lBQ2hDLE9BQU87TUFBRUMsTUFBTSxFQUFFRixHQUFHLENBQUNFLE1BQU0sSUFBSSxHQUFHLElBQUlGLEdBQUcsQ0FBQ0UsTUFBTSxHQUFHLEdBQUcsR0FBR0YsR0FBRyxDQUFDRSxNQUFNLEdBQUcsR0FBRztNQUFFQyxJQUFJLEVBQUVILEdBQUcsQ0FBQ0k7SUFBUSxDQUFDO0VBQ2hHO0VBQ0EsT0FBTztJQUFFRixNQUFNLEVBQUUsR0FBRztJQUFFQyxJQUFJLEVBQUVILEdBQUcsWUFBWUssS0FBSyxHQUFHTCxHQUFHLENBQUNJLE9BQU8sR0FBR0UsTUFBTSxDQUFDTixHQUFHO0VBQUUsQ0FBQztBQUNoRjtBQUVBLFNBQVNPLG1CQUFtQkEsQ0FBQ0MsQ0FBMEIsRUFBRUMsUUFBZ0IsRUFBRTtFQUN6RSxPQUFPO0lBQ0xDLFNBQVMsRUFBRUQsUUFBUTtJQUNuQkUsVUFBVSxFQUFFSCxDQUFDLENBQUNJLEVBQUU7SUFDaEJDLGlCQUFpQixFQUFFTCxDQUFDLENBQUNNLGVBQWUsSUFBSSxFQUFFO0lBQzFDQyxXQUFXLEVBQUVQLENBQUMsQ0FBQ1EsVUFBVSxJQUFJLEVBQUU7SUFDL0JDLFVBQVUsRUFBRVQsQ0FBQyxDQUFDVSxTQUFTLElBQUksRUFBRTtJQUM3QkMsU0FBUyxFQUFFWCxDQUFDLENBQUNZLFFBQVEsSUFBSSxJQUFJO0lBQzdCQyxVQUFVLEVBQUViLENBQUMsQ0FBQ2MsU0FBUyxJQUFJLElBQUk7SUFDL0JDLGFBQWEsRUFBRWYsQ0FBQyxDQUFDZ0IsV0FBVyxJQUFJLEVBQUU7SUFDbENDLFVBQVUsRUFBRWpCLENBQUMsQ0FBQ2tCLFNBQVMsSUFBSSxJQUFJLEdBQUdwQixNQUFNLENBQUNFLENBQUMsQ0FBQ2tCLFNBQVMsQ0FBQyxHQUFHLEVBQUU7SUFDMURDLGNBQWMsRUFBRW5CLENBQUMsQ0FBQ29CLGFBQWEsSUFBSSxFQUFFO0lBQ3JDQyxpQkFBaUIsRUFBRXJCLENBQUMsQ0FBQ3NCLGdCQUFnQixJQUFJdEIsQ0FBQyxDQUFDdUIsZ0JBQWdCLElBQUksRUFBRTtJQUNqRUMsYUFBYSxFQUFFeEIsQ0FBQyxDQUFDeUIsWUFBWSxJQUFJLEVBQUU7SUFDbkNDLGdCQUFnQixFQUFFMUIsQ0FBQyxDQUFDMkIsZUFBZSxJQUFJLEVBQUU7SUFDekNDLGVBQWUsRUFBRTVCLENBQUMsQ0FBQzZCLGFBQWEsSUFBSSxFQUFFO0lBQ3RDQyxlQUFlLEVBQUU5QixDQUFDLENBQUMrQixhQUFhLElBQUk7RUFDdEMsQ0FBQztBQUNIO0FBRUEsU0FBU0MsU0FBU0EsQ0FBQ0MsT0FBWSxFQUFFO0VBQy9CLE9BQU9BLE9BQU8sQ0FBQ0MsSUFBSSxDQUFDQyxVQUFVLENBQUNDLE1BQU0sQ0FBQ0MsYUFBYTtBQUNyRDtBQUVPLFNBQVNDLDRCQUE0QkEsQ0FBQ0MsTUFBZSxFQUFFO0VBQzVEQSxNQUFNLENBQUNDLEdBQUcsQ0FBQztJQUFFQyxJQUFJLEVBQUU7SUFBK0JDLFFBQVEsRUFBRTtFQUFNLENBQUMsRUFBRSxPQUFPQyxRQUFRLEVBQUVDLElBQUksRUFBRUMsR0FBRyxLQUFLO0lBQ2xHLE1BQU1DLEdBQUcsR0FBRyxDQUFDLENBQUMsSUFBQXpELFVBQUEsQ0FBQTBELFlBQVksRUFBQyxDQUFDO0lBQzVCLE1BQU1DLEtBQUssR0FBRyxDQUFDLENBQUMsSUFBQTFELG9CQUFBLENBQUEyRCxzQkFBc0IsRUFBQyxDQUFDO0lBQ3hDLE1BQUFDLFNBQWMsR0FBQUMsT0FBQSxDQUFBQyxHQUFBLENBQUFDLFNBQUE7VUFDUkMsU0FBRSxHQUFBSCxPQUFBLENBQUFDLEdBQUEsQ0FBQUcsU0FBQTtVQUNGQyxTQUFTLEdBQUFMLE9BQUssQ0FBQUMsR0FBQSxDQUFBSyxTQUFBO1VBQ2hCQyxtQkFBbUIsR0FBQVAsT0FBQSxDQUFBQyxHQUFBLENBQUFPLG1CQUFBO1VBQ25CQyxlQUFBLE1BQUFWLFNBQWdDLElBQUFRLG1CQUFBO1dBQ2hDYixHQUFBLENBQUFnQixFQUFTO01BQ1hsRSxJQUFBO1FBQ0FrRSxFQUFBLEVBQUFmLEdBQUEsSUFBQUUsS0FBQTtRQUNGYyxjQUFBLEVBQUFoQixHQUFBO1FBRUlpQix5QkFDSixFQUFBZixLQUFBO1FBQ01ZLGVBQUU7UUFDTkksWUFBVSxHQUFBSixlQUFBO1FBQ1JWLFNBQU87UUFDTEksU0FBTTtRQUNORSxTQUFNO1FBQ05FLG1CQUFhO1FBQ2JPLFNBQUEsTUFBY0MsSUFBRSxHQUFBQyxXQUFBOztNQUVsQjtJQUNGO0VBQ0Y1QixNQUNBLENBQUFDLEdBQU87SUFDTEMsSUFBQSxFQUFNLDRCQU1MO0lBQ0RDLFFBQU07TUFDSjBCLEtBQUEsRUFBTWxGLGFBQU8sQ0FBQW1GLE1BQUEsQ0FBQUMsTUFBQTtRQUNiQyxJQUFLLEVBQUFyRixhQUFNLENBQUFtRixNQUFBLENBQUFHLEtBQUEsQ0FBQXRGLGFBQUEsQ0FBQW1GLE1BQUEsQ0FBQUksTUFBQTtRQUNUQyxJQUFBLEVBQUF4RixhQUFXLENBQUFtRixNQUFZLENBQUFHLEtBQUEsQ0FBQXRGLGFBQUEsQ0FBQW1GLE1BQUEsQ0FBQUksTUFBQTttQkFBRSxFQUFVdkYsYUFBSyxDQUFBbUYsTUFBQSxDQUFBRyxLQUFBLENBQUF0RixhQUFBLENBQUFtRixNQUFBLENBQUFNLE1BQUE7c0JBQVEsRUFBQXpGLGFBQUEsQ0FBQW1GLE1BQUEsQ0FBQUcsS0FBQSxDQUFBdEYsYUFBQSxDQUFBbUYsTUFBQSxDQUFBTSxNQUFBO1FBQXNCQyxNQUFFLEVBQUExRixhQUFBLENBQUFtRixNQUFBLENBQUFHLEtBQUEsQ0FBQXRGLGFBQUEsQ0FBQW1GLE1BQUEsQ0FBQU0sTUFBQTtNQUMxRTs7WUFDSTFDLE9BQUEsRUFBQTRDLEdBQUEsRUFBQWhDLEdBQUE7VUFDRmlDLENBQUEsR0FBTUQsR0FBRyxDQUFBVCxLQUFHO1FBQ1pVLENBQUEsQ0FBQUYsTUFBTSxXQUFXLEVBQUk7WUFDakJHLElBQUksR0FBRyxJQUFJMUYsVUFBVyxDQUFBMEQsWUFBQTtVQUMxQixDQUFBZ0MsSUFBTTtlQUNBbEMsR0FBRyxDQUFBbUMsV0FBYztVQUN2QkMsVUFBQTtVQUNBdEYsSUFBTTtVQUNKOztVQUVGO1lBQ0V1RixPQUFRLEVBQUdDLE9BQUU7Y0FDYkMsR0FBTSxHQUFFLE1BQUssSUFBQS9GLFVBQWdCLENBQUFnRyx1QkFBeUIsRUFBQ04sSUFBQSxFQUFPLEVBQUU7Y0FDaEU5RSxRQUFZLEdBQUU4RSxJQUFBLENBQUE5RSxRQUFBO1FBQ2hCLElBQUVxRixJQUFBLEdBQUFGLEdBQUEsQ0FBQUcsR0FBQSxDQUFBdkYsQ0FBQSxJQUFBRCxtQkFBQSxDQUFBQyxDQUFBLEVBQUFDLFFBQUE7UUFDRixJQUFBNkUsQ0FBQSxDQUFNdkUsV0FBSTtVQUNWK0UsSUFBTSxHQUFBQSxJQUFJLENBQUFFLE1BQUEsQ0FBQUMsQ0FBQSxJQUFLM0YsTUFBSSxDQUFBMkYsQ0FBQSxDQUFBbEYsV0FBQSxNQUFBdUUsQ0FBQSxDQUFBdkUsV0FBQTtRQUNuQjtRQUNBLElBQUF1RSxDQUFBLENBQU0zRCxjQUFhLEVBQUc7VUFBYW1FLElBQUEsR0FBT0EsSUFBRSxDQUFHRSxNQUFBLENBQUFDLENBQUEsSUFBQTNGLE1BQUEsQ0FBQTJGLENBQUEsQ0FBQXRFLGNBQUEsTUFBQTJELENBQUEsQ0FBQTNELGNBQUE7O1FBQXNCbUUsSUFBRyxDQUFBSSxJQUFBLEVBQUFDLENBQUEsRUFBQUMsQ0FBQTtVQUN4RSxNQUFPQyxFQUFHLEdBQUdGLENBQUMsQ0FBQWhGLFNBQUEsT0FBQXVELElBQUEsQ0FBQXBFLE1BQUEsQ0FBQTZGLENBQUEsQ0FBQWhGLFNBQUEsR0FBQW1GLE9BQUE7VUFDWixNQUFNQyxFQUFBLEdBQUFILENBQUEsQ0FBQWpGLFNBQUEsT0FBQXVELElBQUEsQ0FBQXBFLE1BQUEsQ0FBQThGLENBQUEsQ0FBQWpGLFNBQUEsR0FBQW1GLE9BQUE7aUJBQ0FDLEVBQUEsR0FBQUYsRUFBQTs7Y0FDS25CLElBQUEsR0FBTyxDQUFBUSxPQUFLLEdBQU1KLENBQUEsQ0FBQUosSUFBQSxjQUFBUSxPQUFBLGNBQUFBLE9BQUE7Y0FBRVgsSUFBQSxJQUFRWSxPQUFFLEdBQUFMLENBQUEsQ0FBQVAsSUFBQSxjQUFBWSxPQUFBLGNBQUFBLE9BQUE7Y0FBTWEsS0FBQSxHQUFBVixJQUFBLENBQUFVLEtBQUEsQ0FBQXRCLElBQUEsRUFBQUEsSUFBQSxHQUFBSCxJQUFBO2NBQzdDMEIsSUFBTSxHQUFFRCxLQUFBLENBQUFULEdBQUEsQ0FBQVcsR0FBQTtVQUNWQyxPQUFBLEVBQUFELEdBQUE7VUFDQUUsR0FBQSxFQUFBRixHQUFBLENBQUEvRjtRQUNGO1FBQWlCLE9BQUEwQyxHQUFBLENBQUFnQixFQUFBO1VBQ2pCbEUsSUFBQSxFQUFPO1lBQ0xzRyxJQUFBO1lBQ0FJLEtBQUk7Y0FDSkMsS0FBQSxFQUFBaEIsSUFBQSxDQUFBaUIsTUFBQTtjQUNKQyxRQUFBO1lBQ0Y7WUFDSTVCLE1BQUE7VUFBQTtRQUNGO01BQ0EsU0FBTXBGLEdBQUE7UUFBRSxJQUFJaUgsWUFBSztRQUFFLE9BQU81RCxHQUFDLENBQUFtQyxXQUFBO1VBQUVDLFVBQVcsTUFBQTVGLFVBQUEsQ0FBQXFILGNBQUEsRUFBQWxILEdBQUE7VUFBRUcsSUFBQSxHQUFBOEcsWUFBQSxHQUFBakgsR0FBQSxhQUFBQSxHQUFBLHVCQUFBQSxHQUFBLENBQUFJLE9BQUEsY0FBQTZHLFlBQUEsY0FBQUEsWUFBQSxHQUFBM0csTUFBQSxDQUFBTixHQUFBO1FBQWdCLEVBQUc7TUFDN0Q7O1FBQzZCO1VBQVFtSCxLQUFBLEVBQUFDLGNBQUEsRUFBQUMsVUFBQTtZQUFZekUsTUFBQSxHQUFBSixTQUFBLENBQUFDLE9BQUE7TUFBRSxNQUFFO1FBQ3JEc0MsSUFBSTtRQUE0QkcsSUFBSSxHQUFFO21CQUFFO1FBQWV2RDtNQUFFLENBQUMsR0FBQzJELENBQUE7TUFDM0QsTUFBTWdDLElBQUEsS0FBUTtVQUNadkcsV0FBTyxFQUFBdUcsSUFBQSxDQUFBQyxJQUFBO1FBQ1BDLElBQUE7VUFDQXpHOzs7VUFHRVksY0FBTyxFQUFBMkYsSUFBQSxDQUFBQyxJQUFBO1lBQUU7Ozs7WUFBZ0RFLFFBQUUsU0FBQTdFLE1BQUEsQ0FBQThFLE1BQUE7YUFBRSxFQUFBOUgsVUFBQSxDQUFBK0gsdUJBQW1COzBCQUFRO1lBQ3hGO2NBQXVCO2NBQVE7Y0FBSztZQUFHeEcsU0FBRztjQUFFeUcsS0FBQSxFQUFTLE1BQUc7Y0FBRUMsT0FBQTtZQUM1RDtVQUNBO1lBQ0loSCxpQkFBSTtVQUNWO1VBQWdCK0QsS0FBTSxFQUFBMEMsSUFBQSxDQUFBUCxNQUFBO1lBQUVlLElBQUk7Y0FBbUJSO1lBQW1CO1VBQWdCO1lBQUlTLFNBQUE7VUFDdEY7UUFBaUI7TUFDakI7WUFDRXRCLElBQUEsR0FBVSxDQUFBVSxLQUFBLElBQUFDLGNBQU0sR0FBQUssUUFBVSxDQUFBdEgsSUFBQSxjQUFBaUgsY0FBQSx1QkFBQUEsY0FBTyxDQUFBWCxJQUFBLGNBQUFVLEtBQUEsY0FBQUEsS0FBQTthQUM3QjlELEdBQUEsQ0FBQWdCLEVBQUE7UUFDSmxFLElBQUE7VUFDSnNHLElBQUEsR0FBQVksVUFBQSxHQUFBWixJQUFBLENBQUFBLElBQUEsY0FBQVksVUFBQSxjQUFBQSxVQUFBO1VBRUhSLEtBQUEsRUFBQUosSUFBQSxDQUFBSSxLQUFBO1VBRU16QixNQUNMO1FBQ007TUFDSjtNQUFZLE9BQU1wRixHQUFFO1VBQWtCZ0ksZUFBRSxFQUFBQyxhQUFjO01BQUUsT0FBQzVFLEdBQUEsQ0FBQW1DLFdBQUE7UUFBRUMsVUFBQSxHQUFBdUMsZUFBQSxHQUFBaEksR0FBQSxDQUFBeUYsVUFBQSxjQUFBdUMsZUFBQSxjQUFBQSxlQUFBO1FBRTdEN0gsSUFBTyxHQUFBOEgsYUFBZ0IsR0FBR2pJLEdBQUEsQ0FBQUksT0FBSyxjQUFBNkgsYUFBQSxjQUFBQSxhQUFBLEdBQUEzSCxNQUFBLENBQUFOLEdBQUE7TUFDN0I7SUFDQTs7UUFFSSxDQUFBZ0QsR0FBQTtRQUNBLHdDQUFNO1lBQ047TUFDSmtGLE1BQUEsRUFBQXhJLGFBQUEsQ0FBQW1GLE1BQUEsQ0FBQUMsTUFBQTtRQUNJbEUsRUFBQSxFQUFBbEIsYUFBQSxDQUFBbUYsTUFBQSxDQUFBTSxNQUFBO01BQ0Y7O1lBRUFoQyxRQUFjLEVBQUFDLElBQUEsRUFBQUMsR0FBQTtVQUFFOEUsTUFBTSxPQUFBdEksVUFBQSxDQUFBMEQsWUFBQTtRQUFPLENBQUE0RSxNQUFBO01BQzdCLE9BQU85RSxHQUFRLENBQUFtQyxXQUFFO1FBQUFDLFVBQUE7UUFDakJ0RixJQUFBLEVBQU87UUFDTDs7UUFFQTtNQUNKLE1BQUFTLEVBQUEsR0FBQXdDLElBQUEsQ0FBQThFLE1BQUEsQ0FBQXRILEVBQUE7TUFFSCxNQUFBd0gsSUFBQSxhQUFBdkksVUFBQSxDQUFBd0ksVUFBQSxFQUFBRixNQUFBLEVBQUF2SCxFQUFBO01BRUQsT0FBTXlDLEdBQUEsQ0FBQWdCLEVBQUE7UUFDSmxFLElBQU8sRUFBR2lJO01BRU47TUFDQSxPQUFBcEksR0FBVTtVQUFFc0ksYUFBUTthQUFrQmpGLEdBQUUsQ0FBQW1DLFdBQUE7UUFBZ0JDLFVBQUMsTUFBQTVGLFVBQUEsQ0FBQXFILGNBQUEsRUFBQWxILEdBQUE7UUFBRUcsSUFBQSxHQUFBbUksYUFBQSxHQUFBdEksR0FBQSxhQUFBQSxHQUFBLHVCQUFBQSxHQUFBLENBQUFJLE9BQUEsY0FBQWtJLGFBQUEsY0FBQUEsYUFBQSxHQUFBaEksTUFBQSxDQUFBTixHQUFBO01BQzVELENBQ0Q7OztRQUdJdUksYUFBVyxHQUFBQSxDQUFBQyxVQUFZLEVBQUFDLEVBQUE7VUFBRSxDQUFBekYsR0FBQTtVQUFpQiwwQ0FBTXdGLFVBQUE7Y0FBd0I7UUFDMUVOLE1BQUEsRUFBQXhJLGFBQUEsQ0FBQW1GLE1BQUEsQ0FBQUMsTUFBQTtVQUNJbEUsRUFBQSxFQUFBbEIsYUFBQSxDQUFBbUYsTUFBQSxDQUFBTSxNQUFBO1FBQ0Y7O2NBRUFoQyxRQUFjLEVBQUFrQyxHQUFBLEVBQUFoQyxHQUFBO1lBQUVrQyxJQUFNLE9BQUExRixVQUFBLENBQUEwRCxZQUFBO1VBQU8sQ0FBQWdDLElBQUE7UUFDN0IsT0FBT2xDLEdBQVEsQ0FBQW1DLFdBQUU7VUFBQUMsVUFBQTtVQUNqQnRGLElBQUEsRUFBTztVQUFrQjs7VUFBcUU7UUFDaEcsTUFBQVMsRUFBQSxHQUFBeUUsR0FBQSxDQUFBNkMsTUFBQSxDQUFBdEgsRUFBQTtRQUVILE1BQUF3SCxJQUFBLFNBQUFLLEVBQUEsQ0FBQWxELElBQUEsRUFBQTNFLEVBQUE7UUFDRixPQUFBeUMsR0FBQSxDQUFBZ0IsRUFBQTtVQUVEbEUsSUFBQSxFQUFjaUk7UUFDZDtNQUNBLFNBQWFwSSxHQUFDO1FBQ2QsSUFBQTBJLGFBQWM7UUFDZCxPQUFhckYsR0FBQyxDQUFBbUMsV0FBWTtVQUVuQkMsVUFDTCxNQUFBNUYsVUFBQSxDQUFBcUgsY0FBQSxFQUFBbEgsR0FBQTtVQUNRRyxJQUFBLEdBQUF1SSxhQUFBLEdBQUExSSxHQUFBLGFBQUFBLEdBQTBDLHVCQUFBQSxHQUFBLENBQUFJLE9BQUEsY0FBQXNJLGFBQUEsY0FBQUEsYUFBQSxHQUFBcEksTUFBQSxDQUFBTixHQUFBO1FBQ2hEO01BQVk7OztlQUE2RCxvQkFBQUgsVUFBQSxDQUFBOEkseUJBQUE7RUFDM0VKLGFBQ08sa0JBQWtCLEVBQUsxSSxVQUFBLENBQUErSSx5QkFBQTtlQUNsQixTQUFHLEVBQUEvSSxVQUFBLENBQUFnSixnQkFBYztlQUNoQixhQUFXLEVBQUFoSixVQUFZLENBQUFpSixvQkFBQTtlQUFFLENBQVUsVUFBSyxFQUFBakosVUFBQSxDQUFBa0osa0JBQUE7UUFBRSxDQUFBL0YsR0FBTTtJQUFzQkMsSUFBRTtJQUNuRkMsUUFBSTtNQUFBMEIsS0FBQSxFQUFBbEYsYUFBQSxDQUFBbUYsTUFBQSxDQUFBQyxNQUFBO1FBQ0ZrRSxHQUFBLEVBQU10SixhQUFPLENBQUFtRixNQUFJLENBQUFHLEtBQThCLENBQUF0RixhQUFBLENBQUFtRixNQUFBLENBQUFJLE1BQUE7TUFDL0M7O1lBQ29COUIsUUFBRSxFQUFBa0MsR0FBQSxFQUFBaEMsR0FBQTtVQUFPa0MsSUFBQSxPQUFBMUYsVUFBQSxDQUFBMEQsWUFBQTtJQUMvQixJQUFFLENBQUFnQyxJQUFPLFNBQVVsQyxHQUFBLENBQUFtQyxXQUFBO01BQUFDLFVBQUE7TUFDakJ0RixJQUFBOztRQUEwRDtNQUFrQyxJQUFFOEksSUFBQTtNQUNoRyxNQUFBRCxHQUFBLElBQUFDLElBQUEsR0FBQTVELEdBQUEsQ0FBQVQsS0FBQSxDQUFBb0UsR0FBQSxjQUFBQyxJQUFBLGNBQUFBLElBQUE7TUFFSCxNQUFBYixJQUFBLGFBQUF2SSxVQUFBLENBQUFxSixzQkFBQSxFQUFBM0QsSUFBQSxFQUFBeUQsR0FBQTtNQUVELE9BQ0UzRixHQUFBLENBQUFnQixFQUFBO1FBQ01sRSxJQUFFLEVBQUFpSTtNQUNOO01BQVksT0FBT3BJLEdBQUE7VUFBZ0JtSixhQUFLO01BQThCLE9BQUM5RixHQUFBLENBQUFtQyxXQUFBO1FBQUVDLFVBQUEsTUFBQTVGLFVBQUEsQ0FBQXFILGNBQUEsRUFBQWxILEdBQUE7UUFFM0VHLElBQU8sR0FBQWdKLGFBQWUsR0FBR25KLEdBQUEsS0FBSyxRQUFBQSxHQUFBLHVCQUFBQSxHQUFBLENBQUFJLE9BQUEsY0FBQStJLGFBQUEsY0FBQUEsYUFBQSxHQUFBN0ksTUFBQSxDQUFBTixHQUFBO01BQzVCO0lBQ0E7O1FBQXFELENBQUFnRCxHQUFNO0lBQXNCQyxJQUFFO0lBQ25GQyxRQUFJO01BQUEwQixLQUFBLEVBQUFsRixhQUFBLENBQUFtRixNQUFBLENBQUFDLE1BQUE7UUFDRmtFLEdBQUEsRUFBTXRKLGFBQUcsQ0FBSW1GLE1BQUksQ0FBQUcsS0FBMkIsQ0FBR3RGLGFBQUEsQ0FBQW1GLE1BQUEsQ0FBQUksTUFBQTtNQUMvQzs7WUFDb0I5QixRQUFFLEVBQUFrQyxHQUFBLEVBQUFoQyxHQUFBO1VBQU9rQyxJQUFBLE9BQUExRixVQUFBLENBQUEwRCxZQUFBO0lBQy9CLElBQUUsQ0FBQWdDLElBQU8sU0FBVWxDLEdBQUEsQ0FBQW1DLFdBQUE7TUFBQUMsVUFBQTtNQUNqQnRGLElBQUE7O1FBQTBEO01BQWtDLElBQUVpSixLQUFBO01BQ2hHLE1BQUFKLEdBQUEsSUFBQUksS0FBQSxHQUFBL0QsR0FBQSxDQUFBVCxLQUFBLENBQUFvRSxHQUFBLGNBQUFJLEtBQUEsY0FBQUEsS0FBQTtNQUVILE1BQUFoQixJQUFBLGFBQUF2SSxVQUFBLENBQUF3SixnQkFBQSxFQUFBOUQsSUFBQSxFQUFBeUQsR0FBQTtNQUVELE9BQ0UzRixHQUFBLENBQUFnQixFQUFBO1FBQ01sRSxJQUFFLEVBQUFpSTtNQUNOO01BQVksT0FBT3BJLEdBQUE7VUFBZ0JzSixhQUFLO01BQThCLE9BQUNqRyxHQUFBLENBQUFtQyxXQUFBO1FBQUVDLFVBQUEsTUFBQTVGLFVBQUEsQ0FBQXFILGNBQUEsRUFBQWxILEdBQUE7UUFFM0VHLElBQU8sR0FBQW1KLGFBQWUsR0FBR3RKLEdBQUEsS0FBSyxRQUFBQSxHQUFBLHVCQUFBQSxHQUFBLENBQUFJLE9BQUEsY0FBQWtKLGFBQUEsY0FBQUEsYUFBQSxHQUFBaEosTUFBQSxDQUFBTixHQUFBO01BQzVCO0lBQ0E7O1FBQXFELENBQUFnRCxHQUFNO0lBQXNCQyxJQUFFO0lBQ25GQyxRQUFJO01BQUEwQixLQUFBLEVBQUFsRixhQUFBLENBQUFtRixNQUFBLENBQUFDLE1BQUE7UUFDRmtFLEdBQUEsRUFBTXRKLGFBQUcsQ0FBSW1GLE1BQUksQ0FBQUcsS0FBMkIsQ0FBR3RGLGFBQUEsQ0FBQW1GLE1BQUEsQ0FBQUksTUFBQTtNQUMvQzs7WUFDb0I5QixRQUFFLEVBQUFrQyxHQUFBLEVBQUFoQyxHQUFBO1VBQU9rQyxJQUFBLE9BQUExRixVQUFBLENBQUEwRCxZQUFBO0lBQy9CLElBQUUsQ0FBQWdDLElBQU8sU0FBVWxDLEdBQUEsQ0FBQW1DLFdBQUE7TUFBQUMsVUFBQTtNQUNqQnRGLElBQUE7O1FBQTBEO01BQWtDLElBQUVvSixLQUFBO01BQ2hHLE1BQUFQLEdBQUEsSUFBQU8sS0FBQSxHQUFBbEUsR0FBQSxDQUFBVCxLQUFBLENBQUFvRSxHQUFBLGNBQUFPLEtBQUEsY0FBQUEsS0FBQTtNQUVILE1BQUFuQixJQUFBLGFBQUF2SSxVQUFBLENBQUEySixrQkFBQSxFQUFBakUsSUFBQSxFQUFBeUQsR0FBQTtNQUVELE9BQ0UzRixHQUFBLENBQUFnQixFQUFBO1FBQ01sRSxJQUFFLEVBQUFpSTtNQUNOO01BQVksT0FBTXBJLEdBQUU7VUFBZ0J5SixhQUFVO01BQWdCLE9BQUNwRyxHQUFBLENBQUFtQyxXQUFBO1FBQUVDLFVBQUEsTUFBQTVGLFVBQUEsQ0FBQXFILGNBQUEsRUFBQWxILEdBQUE7UUFFbkVHLElBQU8sR0FBQXNKLGFBQWUsR0FBR3pKLEdBQUEsS0FBSyxRQUFBQSxHQUFBLHVCQUFBQSxHQUFBLENBQUFJLE9BQUEsY0FBQXFKLGFBQUEsY0FBQUEsYUFBQSxHQUFBbkosTUFBQSxDQUFBTixHQUFBO01BQzVCO0lBQ0E7O1FBQXFELENBQUFnRCxHQUFNO0lBQXNCQyxJQUFFO0lBQ25GQyxRQUFJO01BQ0ZnRixNQUFNLEVBQUF4SSxhQUFnQixDQUFBbUYsTUFBZ0MsQ0FBQUMsTUFBQSxDQUFRO1FBQzlENEUsUUFBVSxFQUFBaEssYUFBUyxDQUFBbUYsTUFBQSxDQUFBTSxNQUFBO01BQ25COztZQUE2QmhDLFFBQUEsRUFBQWtDLEdBQUEsRUFBQWhDLEdBQUE7SUFDL0IsTUFBRWtDLElBQU8sR0FBUSxDQUFFLEdBQUExRixVQUFBLENBQUEwRCxZQUFBO1FBQUEsQ0FBQWdDLElBQUEsU0FBQWxDLEdBQUEsQ0FBQW1DLFdBQUE7TUFDakJDLFVBQVUsRUFBQztVQUFjOztRQUFxRTtNQUNoRyxNQUFBaUUsUUFBQSxHQUFBckUsR0FBQSxDQUFBNkMsTUFBQSxDQUFBd0IsUUFBQTtNQUVILE1BQUF0QixJQUFBLGFBQUF2SSxVQUFBLENBQUE4SiwwQkFBQSxFQUFBcEUsSUFBQSxFQUFBbUUsUUFBQTtNQUVELE9BQVdyRyxHQUFBLENBQUFnQixFQUFBO1FBQU1sRSxJQUFFLEVBQUFpSTtNQUFpQztJQUFpQixDQUFFLFFBQU9wSSxHQUFBO01BQzVFLElBQUk0SixhQUFBO01BQUEsT0FBQXZHLEdBQUEsQ0FBQW1DLFdBQUE7UUFDRkMsVUFBWSxHQUFHLEdBQUE1RixVQUFVLENBQUFxSCxjQUFRLEVBQUFsSCxHQUFBO1FBQ2pDRyxJQUFNLEdBQUF5SixhQUFnQixHQUFBNUosR0FBSyxLQUFLLElBQUssSUFBSUEsR0FBRyxLQUFLLEtBQUssSUFBRSxLQUFPLENBQUMsR0FBQ0EsR0FBQSxDQUFBSSxPQUFhLGNBQUF3SixhQUFBLGNBQUFBLGFBQUEsR0FBQXRKLE1BQUEsQ0FBQU4sR0FBQTtNQUU5RTs7O1FBR0UsQ0FBQWdELEdBQUk7VUFDRiw0QkFBTztZQUNQO1lBQ0FQLE9BQU8sRUFBQVcsSUFBQSxFQUFBQyxHQUFBOztnQkFBZSxFQUFBd0csaUJBQWEsRUFBQUMsYUFBQSxFQUFBQyxrQkFBQSxFQUFBQyxjQUFBLEVBQUFDLHFCQUFBLEVBQUFDLGVBQUEsRUFBQUMsZ0JBQUEsRUFBQUMsbUJBQUEsRUFBQUMsV0FBQSxFQUFBQyxxQkFBQSxFQUFBQyxpQkFBQSxFQUFBQyxxQkFBQSxFQUFBQyxlQUFBLEVBQUFDLHFCQUFBLEVBQUFDLGFBQUE7a0JBQUUsR0FBT25JLFNBQUUsQ0FBQUMsT0FBQTtZQUFRbUksU0FBQSxPQUFBbEcsSUFBQSxDQUFBQSxJQUFBLENBQUFtRyxHQUFBLDhCQUFBbEcsV0FBQTtZQUFJbUcsV0FBQSxTQUFBbEksTUFBQSxDQUFBOEUsTUFBQTthQUMxRCxFQUFLOUgsVUFBRSxDQUFBK0gsdUJBQUE7MEJBQWM7WUFBRztVQUN4QjVDLElBQUksRUFBRTswQkFDRztjQUFFO3FCQUFjLEVBQUU7bUJBQWUsRUFBSSxNQUFFO2NBQUc4QyxPQUFBO1lBQUU7WUFDbkQ7ZUFBZTtxQkFBYyxFQUFFOztjQUEyQjtZQUFFa0QsS0FBQztjQUM3REMsS0FBQSxFQUFTO2dCQUFJQyxLQUFPO2dCQUFFbEcsSUFBQSxFQUFLOzs7WUFBOEJtRyxXQUFDO2NBQzFERixLQUFPLEVBQUU7Z0JBQUVDLEtBQU87Z0JBQUVsRyxJQUFBLEVBQUs7OztZQUEyQm9HLFNBQUE7Y0FDdERILEtBQUE7Z0JBQ0ZDLEtBQUE7Z0JBQ0FsRyxJQUFBO2NBRUU7WUFDQTtZQUNBcUcsT0FBUztjQUNUSixLQUFBO2dCQUNBQyxLQUFVLEVBQUcsWUFBQztnQkFDZGxHLElBQUE7Y0FBQTtZQUNGO1VBQ2lCOztRQUEwRDtVQUMxRHNHLGNBQU87VUFBdUJDLFdBQUE7VUFBMkJDLFNBQ2pFO1VBQVFDLFlBQU87VUFBZ0NDLFVBQUE7VUFBMkI7WUFDbEVDLE1BQU8sRUFBQUMsUUFBQSxFQUFBQyxPQUFBLEVBQUFDLFFBQUEsRUFBQUMsT0FBQSxFQUFBQyxRQUErQixFQUFBQyxPQUFBLEVBQUFDLFdBQUEsRUFBQUMsSUFBQSxFQUFBQyxpQkFBQSxFQUFBQyxjQUFBLEVBQUFDLGVBQUE7Y0FBRSxDQUFBQyxFQUFBLEVBQUFDLEVBQUEsRUFBQUMsRUFBQSxFQUFBQyxLQUFvQixFQUFBQyxRQUFBLFVBQUFDLE9BQUEsQ0FBQUMsR0FBQSxFQUFBaEssTUFBQSxDQUFBaUssS0FBQTtVQUFPQyxLQUNsRixFQUFBbE4sVUFBYyxDQUFBbU4sd0JBQUE7VUFDWkMsa0JBQU87VUFDUCxFQUFBcEssTUFBQSxDQUFBaUssS0FBQTtVQUNBQyxLQUFJLEVBQUVsTixVQUFBLENBQUFxTixxQkFBQTs0QkFDRztZQUNQckssTUFBSyxDQUFFaUssS0FBQTtlQUNMLEVBQUFqTixVQUFNLENBQUFzTiw4QkFBQTs0QkFDSztrQkFBRSxDQUFBTCxLQUFLLENBQUU7MkJBQUUsQ0FBQU0sK0JBQVc7NEJBQU07eUJBQVU7MkJBQUUsQ0FBQXhGLHVCQUFBOzRCQUFHO2NBQ3REO1lBQ0Y1QyxJQUFDO1lBQ0RILEtBQUE7Y0FDRmtELElBQUE7Z0JBRUY5QixNQUFBO2tCQUNGb0gsS0FBYztvQkFDSGpNLFNBQUE7c0JBQ0ZrTSxFQUFBLEVBQUF6QztvQkFDRztrQkFDRjtnQkFJSjtjQUNOO1lBQUE7WUFHSTBDLGdCQUFRO1VBQ2Q7UUFDQSxJQUFNO1FBQ05qQyxjQUFNLEdBQWEsQ0FBQUssTUFDakIsR0FBTyxDQUFBQyxRQUFTLEdBQUFXLEVBQUssQ0FBQW5NLElBQUssVUFBUSxJQUFBd0wsUUFBQSx1QkFBQUEsUUFBQSxDQUFBa0IsS0FDOUIsTUFBUyxJQUFLLElBQUFuQixNQUFBLGNBQUFBLE1BQUE7UUFHcEJKLFdBQUksR0FBVyxDQUFBTSxPQUFBLElBQUFDLFFBQUEsR0FBQVUsRUFBQSxDQUFBcE0sSUFBQSxVQUFHLElBQUkwTCxRQUFNLHVCQUFBQSxRQUFBLENBQUFnQixLQUFBLFVBQVYsSUFBQWpCLE9BQVksVUFBTyxJQUFBQSxPQUFBO1FBQ3JDTCxTQUFJLElBQUFPLE9BQWlCLElBQUFDLFFBQUEsR0FBQVMsRUFBQSxDQUFBck0sSUFBQSxjQUFBNEwsUUFBQSxLQUFHLEtBQUssVUFBVyxHQUFBQSxRQUFBLENBQUFjLEtBQUEsY0FBQWYsT0FBQSxjQUFBQSxPQUFoQjtRQUN4Qk4sWUFBSSxJQUFBUSxPQUFlLElBQUFDLFdBQUEsR0FBQVEsS0FBQSxDQUFBdE0sSUFBQSxjQUFHOEwsV0FBSyxLQUFTLGtCQUFBQSxXQUFBLENBQUFZLEtBQUEsY0FBZGIsT0FBQSxVQUFnQixJQUFBQSxPQUFPO1FBQzdDUCxVQUFJLElBQUFTLElBQWEsSUFBQUMsaUJBQUEsSUFBQUMsY0FBQSxHQUFHTSxRQUFLLENBQUF2TSxJQUFPLGNBQUFpTSxjQUFBLGdCQUFBQSxjQUFaLEdBQUFBLGNBQXFCLENBQUEzRixJQUFBLGNBQUEyRixjQUFBLGdCQUFBQSxjQUFBLEdBQUFBLGNBQU0sQ0FBQXZGLEtBQUEsY0FBQXVGLGNBQUEsdUJBQUFBLGNBQUEsQ0FBQXRGLEtBQUEsY0FBQXFGLGlCQUFBLGNBQUFBLGlCQUFBLElBQUFFLGVBQUEsR0FBQUssUUFBQSxDQUFBdk0sSUFBQSxjQUFBa00sZUFBQSxnQkFBQUEsZUFBQSxHQUFBQSxlQUFBLENBQUE1RixJQUFBLGNBQUE0RixlQUFBLHVCQUFBQSxlQUFBLENBQUF4RixLQUFBLGNBQUFxRixJQUFBLGNBQUFBLElBQUE7TUFDL0MsUUFBSTtRQUNKO01BQUE7TUFHQSxNQUFNcUIsUUFBTyxJQUFBQyxNQUFBLElBQUEzRCxpQkFBYyxHQUFBaUIsV0FBQSxDQUFBM0ssSUFBQSxjQUFBMEosaUJBQUEsdUJBQUFBLGlCQUFBLENBQUFwRCxJQUFBLGNBQUErRyxNQUFBLGNBQUFBLE1BQUE7TUFDM0IsTUFBSUMsSUFBSyxJQUFLM0QsYUFBVyxJQUFBQyxrQkFBQSxHQUFBZSxXQUFBLENBQUEzSyxJQUFBLGNBQUE0SixrQkFBQSx1QkFBQUEsa0JBQUEsQ0FBQTJELFlBQUEsY0FBQTVELGFBQUEsY0FBQUEsYUFBQTtZQUNuQjZELGVBQUEsS0FBQTNELGNBQUEsR0FBQXVELFFBQUEsQ0FBQTlHLElBQUEsY0FBQXVELGNBQUEsY0FBQUEsY0FBQSxPQUFBakUsR0FBQSxDQUFBNkgsQ0FBQSxJQUFBQSxDQUFBLENBQUFqSCxPQUFBLEVBQUFYLE1BQUEsQ0FBQTZILE9BQUE7WUFDRkMsYUFBWSxHQUFNLE9BQUFQLFFBQUEsQ0FBQTFHLEtBQUEsaUJBQXVCb0QscUJBQVUsSUFBQUMsZUFBQSxHQUFBcUQsUUFBQSxDQUFBMUcsS0FBQSxjQUFBcUQsZUFBQSx1QkFBQUEsZUFBQSxDQUFBcEQsS0FBQSxjQUFBbUQscUJBQUEsY0FBQUEscUJBQUEsUUFBQUUsZ0JBQUEsR0FBQW9ELFFBQUEsQ0FBQTFHLEtBQUEsY0FBQXNELGdCQUFBLGNBQUFBLGdCQUFBLEdBQUF3RCxlQUFBLENBQUE1RyxNQUFBO1VBQ25EZ0gsV0FBUyxHQUFHLENBQUEzRCxtQkFBYSxJQUFBQyxXQUFBLEdBQUFvRCxJQUFBLENBQUExQyxLQUFBLGNBQUFWLFdBQUEsdUJBQUFBLFdBQUEsQ0FBQTJELE9BQUEsY0FBQTVELG1CQUFBLGNBQUFBLG1CQUFBO1VBQ3pCNkQsaUJBQWdCLEdBQUcsQ0FBQTNELHFCQUNqQixJQUFBQyxpQkFDRCxHQUFBa0QsSUFBQSxDQUFBdkMsV0FBQSxjQUFBWCxpQkFBQSx1QkFBQUEsaUJBQUEsQ0FBQXlELE9BQUEsY0FBQTFELHFCQUFBLGNBQUFBLHFCQUFBO1VBQ0Q0RCxlQUFlLElBQUExRCxxQkFBWSxJQUFBQyxlQUFBLEdBQUFnRCxJQUFBLENBQUF0QyxTQUFBLGNBQUFWLGVBQUEsdUJBQUFBLGVBQUEsQ0FBQXVELE9BQUEsY0FBQXhELHFCQUFBLGNBQUFBLHFCQUFBO3VCQUNmLEdBQUcsQ0FBQUUscUJBQUssSUFBQUMsYUFBQSxHQUFBOEMsSUFBQSxDQUFBckMsT0FBQSxjQUFBVCxhQUFBLHVCQUFBQSxhQUFBLENBQUFxRCxPQUFBLGNBQUF0RCxxQkFBQSxjQUFBQSxxQkFBQTtvQkFDVixHQUFBaUQsZUFBaUI7ZUFDekIsR0FBQUcsYUFBYTtvQkFHSCxHQUFFLE9BQUs7Z0JBQ2IsSUFBTSxHQUFFak8sVUFBSyxDQUFBMEQsWUFBZ0IsRUFBSztlQUNsQyxNQUFPLElBQUVnQyxJQUFLO1lBQ2hCO2dCQUVGSyxHQUFNLFNBQWtDLElBQUEvRixVQUFBLENBQUFnRyx1QkFBQSxFQUFBTixJQUFBO2dCQUN4QzRJLEdBQU0sR0FBQTVJLElBQWdDLENBQUM5RSxRQUFDO2dCQUN4QzJOLFVBQU0sR0FBaUN4SSxHQUFLLENBQUFHLEdBQUEsQ0FBQXZGLENBQUEsSUFBQUQsbUJBQUEsQ0FBQUMsQ0FBQSxFQUFBMk4sR0FBQTtjQUM1Q0MsVUFBTSxDQUErQnJILE1BQUs7WUFDMUNzSCxVQUFVLEdBQUMsS0FBTztpQkFDaEIsR0FBTUQsVUFBSyxDQUFNckgsTUFBRztzQkFDWixHQUFDcUgsVUFBWSxDQUFDNUgsS0FBSyxHQUFBTixJQUFLLEVBQUFDLENBQUEsRUFBQUMsQ0FBQTtjQUNoQyxNQUFNQyxFQUFFLEdBQUdGLENBQUEsQ0FBQWhGLFNBQVMsT0FBQXVELElBQUEsQ0FBY3BFLE1BQUksQ0FBQTZGLENBQUEsQ0FBQWhGLFNBQVUsR0FBQW1GLE9BQUE7Y0FDaEQsTUFBTUMsRUFBRSxHQUFDSCxDQUFHLENBQUNqRixTQUFTLE9BQUt1RCxJQUFLLENBQUFwRSxNQUFBLENBQUE4RixDQUFBLENBQUFqRixTQUFBLEdBQUFtRixPQUFBO2NBQ2hDLE9BQU1DLEVBQUUsR0FBR0YsRUFBQTtjQUNYLENBQUFHLEtBQUEsSUFBVSxFQUFFLENBQUM7a0JBQ2I4SCxLQUFRLEdBQUc7a0JBQ1hDLEtBQVEsR0FBRyxFQUFHO1lBQ2hCLE1BQUVDLFNBQUE7WUFDRixNQUFBQyxPQUFXLEdBQUc7c0JBQXNELENBQUFDLE9BQUEsQ0FBQXpJLENBQUE7Y0FBRSxNQUFBMEksRUFBQSxHQUFBck8sTUFBQSxDQUFBMkYsQ0FBQSxDQUFBbEYsV0FBQTtjQUFZdU4sS0FBQyxDQUFBSyxFQUFBLEtBQUFMLEtBQUEsQ0FBQUssRUFBQTtjQUNuRixNQUFBQyxFQUFBLEdBQUF0TyxNQUFpQixDQUFHMkYsQ0FBQSxDQUFBdEUsY0FBZSxJQUFLLFNBQVE7Y0FBdUI0TSxLQUFHLENBQUFLLEVBQUEsS0FBQUwsS0FBQSxDQUFBSyxFQUFBO2NBQUUsTUFBQUMsRUFBQSxHQUFBdk8sTUFBQSxDQUFBMkYsQ0FBQSxDQUFBakUsYUFBQTtjQUFZd00sU0FBQyxDQUFBSyxFQUFBLEtBQUFMLFNBQUEsQ0FBQUssRUFBQTtjQUN6RixNQUFBQyxFQUFBLEdBQUF4TyxNQUFrQixDQUFBMkYsQ0FBQSxDQUFBeEUsVUFBYyxJQUFDLFNBQVc7Y0FDMUNnTixPQUFHLENBQUFLLEVBQUEsS0FBQUwsT0FBQSxDQUFBSyxFQUFBO2NBQ0g7WUFDRmYsV0FBRyxHQUFBZ0IsTUFBQSxDQUFBQyxPQUFBLENBQUFWLEtBQUEsRUFBQXZJLEdBQUEsR0FBQWtKLEdBQUEsRUFBQUMsU0FBQTtjQUNIRCxHQUFBO2NBQ0VDO2NBQ0E7WUFDRmpCLGlCQUFHLEdBQUFjLE1BQUEsQ0FBQUMsT0FBQSxDQUFBVCxLQUFBLEVBQUF4SSxHQUFBLEdBQUFrSixHQUFBLEVBQUFDLFNBQUE7Y0FDSEQsR0FBQTtjQUdGQztZQUNBO1lBQ0FoQixlQUFBLEdBQUFhLE1BQUEsQ0FBQUMsT0FBQSxDQUFBUixTQUFBLEVBQUF6SSxHQUFBLEdBQUFrSixHQUFBLEVBQUFDLFNBQUE7Y0FBQUQsR0FBQTtjQUVKQztZQUVJO1lBQ0FDLGFBQThCLEdBQUdKLE1BQUksQ0FBQUMsT0FBQSxDQUFBUCxPQUFBLEVBQUExSSxHQUFBLEdBQUFrSixHQUFBLEVBQUFDLFNBQUE7Y0FDckNELEdBQUE7Y0FDRUM7WUFDRixFQUFJO1lBQ0Z6RCxVQUFBLEdBQUEyQyxVQUFBLENBQUFwSSxNQUFBLENBQUFDLENBQUEsS0FBQUEsQ0FBQSxDQUFBOUUsU0FBQSxRQUFBdUQsSUFBQSxDQUFBcEUsTUFBQSxDQUFBMkYsQ0FBQSxDQUFBOUUsU0FBQSxTQUFBdUQsSUFBQSxDQUFBa0csU0FBQSxHQUFBN0QsTUFBQTtVQUNGO1FBQ0YsQ0FBQyxDQUFDO1VBQ0E7UUFBQTs7VUFHRnFJLGtCQUFJO1VBQ0ZDLGVBQWUsR0FBRztVQUNsQkMsVUFBVTtZQUNWQyxJQUFLLE9BQUF6UCxvQkFBeUIsQ0FBQTJELHNCQUFtQjtVQUNqRDhMLElBQUE7UUFDRjtVQUNGSCxrQkFBQSxhQUFBdFAsb0JBQUEsQ0FBQTBQLHVCQUFBLEVBQUFELElBQUE7UUFFQSxTQUFXRSxDQUFBLEVBQUc7VUFDWkgsVUFBTSxHQUFBdlAsV0FBQSxDQUFBMFAsQ0FBQSxFQUFBdFAsSUFBQTtVQUNKaVAsa0JBQWdCLEdBQUs7O1lBRXJCO1VBQ0FDLGVBQVcsV0FBZSxFQUFBdlAsb0JBQUEsQ0FBQTBQLHVCQUFBLEVBQUFELElBQUE7VUFDMUIsT0FBT0UsQ0FBQSxFQUFFO1VBQ1QsS0FBQUgsVUFBZSxFQUFFQSxVQUFVLEdBQUF2UCxXQUFBLENBQUEwUCxDQUFBLEVBQUF0UCxJQUFBO1VBQzNCa1AsZUFBQSxPQUFxQjs7O2FBR3JCaE0sR0FBQSxDQUFBZ0IsRUFBQTtZQUNBO1VBQ0FxTCxjQUFBLEVBQUE3SSxLQUFBO1VBQ0FrRSxLQUFBLEVBQUFnRCxXQUFBO1VBQ0E3QyxXQUFBLEVBQUErQyxpQkFBNEI7VUFDNUI5QyxTQUFBLEVBQVcrQyxlQUFFO1VBQ2Y5QyxPQUFBLEVBQUErRCxhQUFBO1VBQ0F4QixlQUFBLEVBQUFnQyxVQUFBO1VBQ0ZDLHFCQUFpQixFQUFBdkUsY0FBQTtVQUFBd0Usa0JBQUEsRUFBQXZFLFdBQUE7VUFDakJ3RSwyQkFBdUIsRUFBQXZFLFNBQUE7VUFDckJ3RSxtQkFBVSxFQUFBdkUsWUFBSztVQUNmd0Usb0JBQUksRUFBRXZFLFVBQVc7VUFDakJ3RSwwQkFBQSxFQUFBYixrQkFBQTtVQUNKYyx1QkFBQSxFQUFBYixlQUFBO1VBQ0FjLGdCQUFBLEVBQUFiLFVBQUE7VUFFS2MsV0FDTCxFQUFBL0I7UUFDTTtNQUNKO01BQ0UsT0FBT3JPLEdBQUE7VUFDTHFRLGdCQUFNLEVBQUFDLGFBQWE7YUFDZmpOLEdBQUUsQ0FBQW1DLFdBQUE7UUFDTkMsVUFBUSxHQUFBNEssZ0JBQU8sR0FBQXJRLEdBQU0sQ0FBQXlGLFVBQUEsVUFBTyxJQUFBNEssZ0JBQVEsY0FBQUEsZ0JBQUE7UUFDckNsUSxJQUFBLEdBQUFtUSxhQUFBLEdBQUF0USxHQUFBLENBQUFJLE9BQUEsY0FBQWtRLGFBQUEsY0FBQUEsYUFBQSxHQUFBaFEsTUFBQSxDQUFBTixHQUFBO01BQ0g7SUFDRDtJQUVDO1FBQ0ksQ0FBQ2dELEdBQUM7UUFDSixxQ0FBYTtZQUNSO1dBQStCLEVBQUF0RCxhQUFlLENBQUFtRixNQUFBLENBQUFDLE1BQUE7UUFBRUMsSUFBSSxFQUFFckYsYUFBQSxDQUFBbUYsTUFBQSxDQUFBRyxLQUFBLENBQUF0RixhQUFBLENBQUFtRixNQUFBLENBQUFJLE1BQUE7UUFBd0JDLElBQUEsRUFBQXhGLGFBQUEsQ0FBQW1GLE1BQUEsQ0FBQUcsS0FBQSxDQUFBdEYsYUFBQSxDQUFBbUYsTUFBQSxDQUFBSSxNQUFBO1FBQ25GRyxNQUFJLEVBQUExRixhQUFBLENBQUFtRixNQUFBLENBQUFHLEtBQUEsQ0FBQXRGLGFBQUEsQ0FBQW1GLE1BQUEsQ0FBQU0sTUFBQTs7O1lBSUYxQyxPQUFVLEVBQUE0QyxHQUFBLEVBQUFoQyxHQUFBO1VBQ1ZpQyxDQUFBLEdBQU1ELEdBQUEsQ0FBSVQsS0FBQTtRQUNWVSxDQUFBLENBQUFGLE1BQU0sS0FBSTtZQUNWRyxJQUFNLEdBQUssSUFBRzFGLFVBQVcsQ0FBQTBELFlBQWE7VUFDdEMsQ0FBQWdDLElBQU0sU0FBT2xDLEdBQU0sQ0FBQW1DLFdBQXdCO2tCQUFBO1lBQUE7OztvQkFFTyxFQUFBK0ssV0FBQSxFQUFBQyxRQUFBLEVBQUFDLFFBQUE7Y0FBSXJJLElBQUEsYUFBQXZJLFVBQUEsQ0FBQXFKLHNCQUFBLEVBQUEzRCxJQUFBLEdBQUFtTCxRQUFBLEdBQUFwTCxDQUFBLENBQUFQLElBQUEsY0FBQTJMLFFBQUEsY0FBQUEsUUFBQTtjQUNyRDVLLElBQUEsSUFBQXlLLFdBQUEsR0FBQW5JLElBQUEsYUFBQUEsSUFBQSx1QkFBQUEsSUFBQSxDQUFBdEIsS0FBQSxjQUFBeUosV0FBQSxjQUFBQSxXQUFBO1FBQUEsTUFBRXJMLElBQUEsSUFBQXNMLFFBQUEsR0FBQWxMLENBQUEsQ0FBQUosSUFBQSxjQUFBc0wsUUFBQSxjQUFBQSxRQUFBO1FBQ0gsTUFBQXpMLElBQVUsR0FBRyxDQUFDMEwsUUFBQSxHQUFBbkwsQ0FBQSxDQUFBUCxJQUFBLGNBQUEwTCxRQUFBLGNBQUFBLFFBQUE7Y0FDUmpLLEtBQUUsR0FBQVYsSUFBQSxDQUFBVSxLQUFBLENBQUF0QixJQUFBLEVBQUFBLElBQUEsR0FBQUgsSUFBQTtjQUNKMEIsSUFBSSxHQUFBRCxLQUFBLENBQUFULEdBQUEsRUFBQTRLLEdBQUEsRUFBQUMsQ0FBQTtjQUNKQyxLQUFPLEVBQUFDLE9BQUE7aUJBQUU7ZUFBb0IsRUFBQXhRLE1BQVEsQ0FBRSxDQUFBdVEsS0FBQSxJQUFBQyxPQUFBLEdBQUFILEdBQUEsQ0FBQS9QLEVBQUEsY0FBQWtRLE9BQUEsY0FBQUEsT0FBQSxHQUFBSCxHQUFBLENBQUFJLEtBQUEsY0FBQUYsS0FBQSxjQUFBQSxLQUFBLEdBQUFELENBQUE7WUFBS2pLLE9BQUMsU0FBQWdLLEdBQUEsZ0JBQUFBLEdBQUE7Y0FDN0MvSyxHQUFBLEVBQU0rSztZQUNSO1VBQ0E7UUFDRjtRQUFpQixPQUFBdE4sR0FBQSxDQUFBZ0IsRUFBQTtVQUNqQmxFLElBQUEsRUFBTztZQUNMc0csSUFBQTtZQUNBSSxLQUFJO2NBQ0pDLEtBQUEsRUFBQWhCLElBQUEsQ0FBQWlCLE1BQUE7Y0FDSkMsUUFBQTtZQUNGO1lBQ0k1QixNQUFBO1VBQUE7UUFDRjtNQUNBLFNBQU1wRixHQUFBO1FBQUUsSUFBSWdSLGNBQUs7UUFBRSxPQUFPM04sR0FBQSxDQUFBbUMsV0FBQTtVQUFNQyxVQUFDLE1BQUE1RixVQUFBLENBQUFxSCxjQUFBLEVBQUFsSCxHQUFBO1VBQ2pDRyxJQUFNLEdBQUE2USxjQUFpQixHQUFBaFIsR0FBTyxLQUFNLElBQUMsSUFBQUEsR0FBQSx1QkFBQUEsR0FBQSxDQUFBSSxPQUFBLGNBQUE0USxjQUFBLGNBQUFBLGNBQUEsR0FBQTFRLE1BQUEsQ0FBQU4sR0FBQTtRQUNuQzs7OztVQUlFaVIsTUFBSSxFQUFBQyxlQUFBLEVBQUFDLFdBQUE7WUFDSnZPLE1BQU8sR0FBQUosU0FBQSxDQUFBQyxPQUFBO1lBQUU7ZUFBVztZQUFjO1VBQUU2QyxDQUFDO1lBQ3JDbUMsUUFBTyxTQUFBN0UsTUFBQSxDQUFBOEUsTUFBQTthQUFFLEVBQUE5SCxVQUFZLENBQUFzTiw4QkFBQTswQkFBRTtRQUN6Qi9NLElBQUE7VUFDQTRFLElBQUE7VUFDRkcsSUFBTTtVQUNOZ0IsSUFBTyxFQUFHLENBQUM7WUFBU2tMLE9BQUU7Y0FBTXhKLEtBQUE7WUFBbUI7VUFBbUI7VUFBZ0JoRCxLQUFBO1lBQUltRCxTQUFBO1VBQ3RGO1FBQWlCO01BQ2pCO1lBQ0V0QixJQUFBLEdBQVUsQ0FBQXdLLE1BQUEsSUFBQUMsZUFBTSxHQUFBekosUUFBVSxDQUFBdEgsSUFBQSxjQUFBK1EsZUFBQSx1QkFBQUEsZUFBTyxDQUFBekssSUFBQSxjQUFBd0ssTUFBQSxjQUFBQSxNQUFBO2FBQzdCNU4sR0FBQSxDQUFBZ0IsRUFBQTtRQUNKbEUsSUFBQTtVQUNKc0csSUFBQSxHQUFBMEssV0FBQSxHQUFBMUssSUFBQSxDQUFBQSxJQUFBLGNBQUEwSyxXQUFBLGNBQUFBLFdBQUE7VUFFSHRLLEtBQUEsRUFBQUosSUFBQSxDQUFBSSxLQUFBO1VBRU16QixNQUNMO1FBQ007TUFDSjtNQUNFLE9BQU9wRixHQUFBO1VBQ0xxUixnQkFBSyxFQUFBQyxjQUFhO01BQ3BCLE9BQUNqTyxHQUFBLENBQUFtQyxXQUFBO1FBQ0hDLFVBQUEsR0FBQTRMLGdCQUFBLEdBQUFyUixHQUFBLENBQUF5RixVQUFBLGNBQUE0TCxnQkFBQSxjQUFBQSxnQkFBQTtRQUVGbFIsSUFBTyxHQUFBbVIsY0FBZSxHQUFHdFIsR0FBSyxDQUFBSSxPQUFBLGNBQUFrUixjQUFBLGNBQUFBLGNBQUEsR0FBQWhSLE1BQUEsQ0FBQU4sR0FBQTtNQUM1QjtJQUNBOztRQUVJLENBQUFnRCxHQUFBO1FBQ0Esb0NBQU07WUFDTjtNQUNKNEIsS0FBQSxFQUFBbEYsYUFBQSxDQUFBbUYsTUFBQSxDQUFBQyxNQUFBO1FBQ0lrRSxHQUFBLEVBQUF0SixhQUFBLENBQUFtRixNQUFBLENBQUFHLEtBQUEsQ0FBQXRGLGFBQUEsQ0FBQW1GLE1BQUEsQ0FBQUksTUFBQTtNQUFBOztZQUVJOUIsUUFBTyxFQUFBa0MsR0FBTSxFQUFBaEMsR0FBQTtVQUNuQjhFLE1BQVUsR0FBRyxDQUFDLEdBQUFySSxvQkFBQSxDQUFBMkQsc0JBQUE7UUFBRSxDQUFBMEUsTUFBTTtNQUFLLE9BQUU5RSxHQUFBLENBQUFtQyxXQUFBO1FBQzdCQyxVQUFxQjtRQUNyQnRGLElBQU07UUFBRTs7UUFBYztNQUN0QixJQUFBb1IsS0FBTztZQUFrQnZJLEdBQUEsR0FBVSxDQUFBdUksS0FBRSxHQUFNbE0sR0FBQSxDQUFBVCxLQUFBLENBQUFvRSxHQUFBLGNBQUF1SSxLQUFBLGNBQUFBLEtBQUE7WUFBRW5KLElBQUEsYUFBQXRJLG9CQUFBLENBQUEwUixhQUFBLEVBQUFySixNQUFBLEVBQUFhLEdBQUE7TUFBSyxPQUFFM0YsR0FBQSxDQUFBZ0IsRUFBQTtRQUN0RGxFLElBQUEsRUFBQWlJO01BRUg7SUFFRCxTQUNFcEksR0FBQTtNQUNFLE1BQU07UUFDTkUsTUFBVTtRQUNSQztVQUNFSixXQUFLLENBQUFDLEdBQUE7TUFDUCxPQUFDcUQsR0FBQSxDQUFBbUMsV0FBQTtRQUNIQyxVQUFBLEVBQUF2RixNQUFBO1FBRUZDO01BQ0U7SUFDQTs7UUFFSSxDQUFBNkMsR0FBQTtRQUNBLG9DQUFNO1lBQ047TUFDSmtGLE1BQUEsRUFBQXhJLGFBQUEsQ0FBQW1GLE1BQUEsQ0FBQUMsTUFBQTtRQUNJbEUsRUFBQSxFQUFBbEIsYUFBQSxDQUFBbUYsTUFBQSxDQUFBTSxNQUFBO01BQUE7O1lBRUloQyxRQUFPLEVBQUFrQyxHQUFNLEVBQUFoQyxHQUFBO1VBQ25COEUsTUFBVSxHQUFHLENBQUMsR0FBQXJJLG9CQUFBLENBQUEyRCxzQkFBQTtRQUFFLENBQUEwRSxNQUFNO01BQUssT0FBRTlFLEdBQUEsQ0FBQW1DLFdBQUE7UUFBQUMsVUFBQTtRQUFBdEYsSUFBQTtNQUFBO0lBQy9CO1FBQ0U7WUFBUWlJLElBQU0sYUFBQXRJLG9CQUFBLENBQUEyUixXQUFBLEVBQUF0SixNQUFBLEVBQUE5QyxHQUFBLENBQUE2QyxNQUFBLENBQUF0SCxFQUFBO2FBQUV5QyxHQUFBLENBQUFnQixFQUFBO1FBQUFsRSxJQUFBLEVBQUFpSTtNQUFBO01BQUssT0FBSXBJLEdBQUE7TUFDekI7UUFBT0UsTUFBSTtRQUFBQztNQUFBLENBQVcsR0FBQ0osV0FBQSxDQUFBQyxHQUFBO2FBQUVxRCxHQUFBLENBQUFtQyxXQUFrQjtRQUFBQyxVQUFBLEVBQUF2RixNQUFBO1FBQUFDO01BQUE7OztRQUM3QyxDQUFBNkMsR0FBQTtJQUVIQyxJQUFBO0lBRURDLFFBQU8sRUFDTDtNQUNFZ0YsTUFBTSxFQUFBeEksYUFBQSxDQUFBbUYsTUFBQSxDQUFBQyxNQUE4QjtRQUNwQ2xFLEVBQUEsRUFBUWxCLGFBQUUsQ0FBQW1GLE1BQUEsQ0FBQU0sTUFBQTtNQUNSOztZQUVFaEMsUUFBVSxFQUFBa0MsR0FBQSxFQUFBaEMsR0FBQTtVQUNYOEUsTUFBQSxPQUFBckksb0JBQUEsQ0FBQTJELHNCQUFBO0lBQ0gsS0FBQTBFLE1BQUE7TUFFRixPQUFPOUUsR0FBQSxDQUFBbUMsV0FBZTtRQUFHQyxVQUFLO1FBQUF0RixJQUFBO01BQUE7SUFDNUI7SUFDQSxJQUFJO01BQ0YsTUFBQWlJLElBQVUsR0FBQyxVQUFZdEksb0JBQUEsQ0FBQTRSLG9CQUFBLEVBQ3JCdkosTUFBQSxFQUNBLEtBQUksRUFDSix1QkFBQXdKLGtCQUFBLENBQUF0TSxHQUFBLENBQUE2QyxNQUFBLENBQUF0SCxFQUFBLEtBQ0pnUixTQUFBLEVBQ0k7UUFBQUMsZ0JBQUE7TUFBQSxDQUNGO2FBQWF4TyxHQUFBLENBQUFnQixFQUFBO1FBQUFsRSxJQUFBLEVBQUFpSTtNQUFBO2FBQUVwSSxHQUFBO01BQVMsTUFBSTtRQUFJRSxNQUE0QztRQUFBQztNQUFBLElBQUFKLFdBQUEsQ0FBQUMsR0FBQTtNQUM1RSxPQUFNcUQsR0FBQSxDQUFBbUMsV0FBZTtRQUFJQyxVQUFDLEVBQUF2RixNQUFBO1FBQUFDO01BQUE7OztRQUsxQixDQUFBNkMsR0FBQSxDQUFPO1FBQ0wsaUNBQU07WUFDSixFQUFLO1dBQ0wsRUFBQXRELGFBQWUsQ0FBRW1GLE1BQUssQ0FBQUMsTUFBUTtXQUM5QixFQUFBcEYsYUFBQSxDQUFBbUYsTUFBQSxDQUFBRyxLQUFBLENBQUF0RixhQUFBLENBQUFtRixNQUFBLENBQUFJLE1BQUE7OztLQUdMLE9BQUM5QixRQUFxQixFQUFBa0MsR0FBQSxFQUFBaEMsR0FBQTtVQUNyQjhFLE1BQU0sT0FBQXJJLG9CQUFBLENBQUEyRCxzQkFBQTtRQUFFLENBQUEwRSxNQUFNO2FBQUU5RSxHQUFBLENBQUFtQyxXQUFBO1FBQU1DLFVBQUcsS0FBWTtRQUNyQ3RGLElBQUEsRUFBTztRQUFrQjs7UUFBMkI7TUFDdEQsSUFBQTJSLEtBQUE7TUFFSCxNQUFBOUksR0FBQSxJQUFBOEksS0FBQSxHQUFBek0sR0FBQSxDQUFBVCxLQUFBLENBQUFvRSxHQUFBLGNBQUE4SSxLQUFBLGNBQUFBLEtBQUE7TUFFRCxNQUFVMUosSUFDUixhQUFBdEksb0JBQUEsQ0FBQWlTLFlBQUEsRUFBQTVKLE1BQUEsRUFBQWEsR0FBQTtNQUNFLE9BQU0zRixHQUFBLENBQUFnQixFQUFBO1FBQ05sRSxJQUFRLEVBQUVpSTtNQUNSO2FBQ09wSSxHQUFBO01BQ1AsTUFBQztRQUNIRSxNQUFBO1FBRUZDO01BQ0UsSUFBTUosV0FBUyxDQUFBQyxHQUFBO01BQ2YsT0FBS3FELEdBQU0sQ0FBRW1DLFdBQUE7UUFDWEMsVUFBVyxFQUFBdkYsTUFBQTtRQUFjQztRQUFpQjs7SUFDNUM7UUFDSSxDQUFBNlIsSUFBQTtRQUFBO1lBQ0k7TUFDTjdSLElBQUEsRUFBTVQsYUFBYSxDQUFBbUYsTUFBQSxDQUFBQyxNQUFBO1FBQ25CRixLQUFPLEVBQUFsRixhQUFPLENBQUFtRixNQUFBLENBQUFNLE1BQUE7UUFBRThNLFFBQU0sRUFBQXZTLGFBQUEsQ0FBQW1GLE1BQUEsQ0FBQUcsS0FBQSxDQUFBdEYsYUFBQSxDQUFBbUYsTUFBQSxDQUFBTSxNQUFBO01BQUssQ0FBQztJQUM5QjtZQUFtQmhDLFFBQUEsRUFBQWtDLEdBQUEsRUFBQWhDLEdBQUE7VUFDakI4RSxNQUFVLEdBQUMsSUFBQXJJLG9CQUFZLENBQUEyRCxzQkFBQTtRQUFFLENBQUEwRSxNQUFBO2FBQXFDOUUsR0FBQSxDQUFBbUMsV0FBQTtRQUFnQ0MsVUFBQTtRQUNoR3RGLElBQUE7TUFFSDtJQUVEO0lBRUksSUFBSTtNQUNKLE1BQVE7UUFDTnlFLEtBQU87UUFDTHFOO01BQ0YsQ0FBQyxHQUFBNU0sR0FBQSxDQUFBbEYsSUFBQTtNQUNILE1BQUErUixPQUFBLEdBQUF4TixJQUFBLENBQUFtRyxHQUFBO01BRUYsTUFBT3pDLElBQUEsR0FBTyxNQUFLLENBQUUsR0FBR3RJLG9CQUFLLENBQUFxUyxlQUFBLEVBQUFoSyxNQUFBLEVBQUF2RCxLQUFBLEVBQUFxTixRQUFBO01BQzNCLE1BQUlHLFFBQUEsR0FBQUMsS0FBQSxDQUFBQyxPQUFBLENBQUFsSyxJQUFBLGFBQUFBLElBQUEsdUJBQUFBLElBQUEsQ0FBQW1LLE9BQUEsSUFBQW5LLElBQUEsQ0FBQW1LLE9BQUEsQ0FBQXhMLE1BQUE7TUFBQSxPQUFBMUQsR0FBQSxDQUFBZ0IsRUFBQTtRQUNGbEUsSUFBTTtVQUNOLElBQU1pSSxJQUFJO1VBQ1ZvSyxlQUFpQixFQUFBOU4sSUFBTSxDQUFBbUcsR0FBTSxDQUFDLElBQUFxSCxPQUFPO1VBQ25DRTtRQUNBO1FBQ0E7YUFDRXBTLEdBQUk7WUFDSjtjQUFTOztxQkFBMkIsQ0FBQUEsR0FBQTthQUFJcUQsR0FBQSxDQUFBbUMsV0FBQTtrQkFDakMsRUFBQXRGLE1BQUE7Ozs7O1FBR1gsQ0FBQThDLEdBQU07UUFDTixxQ0FBYztZQUFNLEVBQUU7V0FBRSxFQUFBdEQsYUFBYyxDQUFHbUYsTUFBYSxDQUFDQyxNQUFDO1FBQVNrRSxHQUFBLEVBQUF0SixhQUFBLENBQUFtRixNQUFBLENBQUFHLEtBQUEsQ0FBQXRGLGFBQUEsQ0FBQW1GLE1BQUEsQ0FBQUksTUFBQTtNQUFFLENBQUM7SUFDdEU7WUFBbUI5QixRQUFBLEVBQUFrQyxHQUFBLEVBQUFoQyxHQUFBO1VBQ2pCOEUsTUFBVSxHQUFDLElBQUF0SSxVQUFZLENBQUEwRCxZQUFBO1FBQ3JCLENBQUE0RSxNQUFBO2FBQ0k5RSxHQUFBLENBQUFtQyxXQUFBO1FBQ0pDLFVBQUE7UUFDSnRGLElBQUE7TUFFSDtJQUVEO0lBRUksSUFBSTtNQUNKLElBQUFzUyxLQUFVO01BQ1IsTUFBTXpKLEdBQUEsSUFBQXlKLEtBQUEsR0FBQXBOLEdBQUEsQ0FBQVQsS0FBTyxDQUFBb0UsR0FBTyxjQUFBeUosS0FBQSxjQUFBQSxLQUFBO1lBQ2RySyxJQUFFLGFBQUF2SSxVQUFPLENBQUs2UyxjQUFDLEVBQUF2SyxNQUFPLEVBQUFhLEdBQUEsQ0FBTTthQUM1QjNGLEdBQUUsQ0FBQWdCLEVBQUE7UUFDTmxFLElBQUEsRUFBQWlJO1FBQ0E7YUFDQXBJLEdBQUE7TUFDRixJQUFDMlMsY0FBQTtNQUNILE9BQUF0UCxHQUFBLENBQUFtQyxXQUFBO1FBRUZDLFVBQU8sRUFBTyxDQUFFLEdBQUc1RixVQUFVLENBQUFxSCxjQUFBLEVBQUFsSCxHQUFBO1FBQ3ZCRyxJQUFBLEdBQUF3UyxjQUFBLEdBQUEzUyxHQUFBLGFBQUFBLEdBQUEsdUJBQUFBLEdBQUEsQ0FBQUksT0FBQSxjQUFBdVMsY0FBQSxjQUFBQSxjQUFBLEdBQUFyUyxNQUFBLENBQUFOLEdBQUE7TUFBQTs7O1FBR0EsQ0FBQWdELEdBQUk7UUFDSiwrQkFBUTtZQUNSO1dBQ0EsRUFBQXRELGFBQU8sQ0FBQW1GLE1BQUEsQ0FBQUMsTUFBQTtRQUNQQyxJQUFBLEVBQUFyRixhQUFBLENBQUFtRixNQUF3QixDQUFHRyxLQUFBLENBQUF0RixhQUFBLENBQUFtRixNQUFBLENBQUFJLE1BQUE7TUFDN0IsQ0FBQzs7WUFHS3hDLE9BQUEsRUFBUzRDLEdBQUcsRUFBQWhDLEdBQUk7UUFDdEI7TUFDQSxJQUFBdVAsS0FBTSxFQUFBQyxXQUFVLEVBQUFDLGVBQWE7TUFDN0IsTUFBTWxRLE1BQUEsR0FBT0osU0FBVSxDQUFBQyxPQUFJO01BQzNCLE1BQU1zQyxJQUFBLElBQUE2TixLQUFBLEdBQWV2TixHQUFHLENBQUFULEtBQUEsQ0FBQUcsSUFBQSxjQUFBNk4sS0FBQSxjQUFBQSxLQUFBO1lBQUVuTCxRQUFPLFNBQUE3RSxNQUFBLENBQUE4RSxNQUFBO2FBQUUsRUFBQTlILFVBQVcsQ0FBQW1ULHdCQUFBOzBCQUFjO1lBQUU7VUFBYWhPLElBQUE7VUFBRW1CLElBQUE7WUFBR3pCLFNBQUE7Y0FFNUVtRCxLQUFBO1lBQ0U7VUFFRjtVQUEwQmhELEtBQUE7WUFDNUJtRCxTQUFNO1VBQ0o7OztZQUdFdEIsSUFBSSxHQUFFLENBQUFvTSxXQUFJLElBQUFDLGVBQUEsR0FBQXJMLFFBQUEsQ0FBQXRILElBQUEsY0FBQTJTLGVBQUEsZ0JBQUFBLGVBQUEsR0FBQUEsZUFBQSxDQUFBck0sSUFBQSxjQUFBcU0sZUFBQSx1QkFBQUEsZUFBQSxDQUFBck0sSUFBQSxjQUFBb00sV0FBQSxjQUFBQSxXQUFBO2FBQ1Z4UCxHQUFBLENBQUFnQixFQUFPO1lBQ1A7aUJBQVMsRUFBQW9DLElBQVMsQ0FBQVYsR0FBRyxDQUFBNkgsQ0FBQSxJQUFBQSxDQUFBLENBQUFqSCxPQUFBOzs7YUFFdkIzRyxHQUFBO1VBQ0ZnVCxnQkFBa0IsRUFBQUMsY0FBQTthQUNsQjVQLEdBQUEsQ0FBQW1DLFdBQWtCO2tCQUNKLEdBQUF3TixnQkFBQSxHQUFBaFQsR0FBQSxDQUFBeUYsVUFBQSxjQUFBdU4sZ0JBQUEsY0FBQUEsZ0JBQUE7WUFBQSxHQUFBQyxjQUFBLEdBQU1qVCxHQUFDLENBQUFJLE9BQU8sY0FBQTZTLGNBQUEsY0FBQUEsY0FBRSxHQUFBM1MsTUFBQSxDQUFBTixHQUFjO1FBQUE7OztZQUl4QztzQ0FDWTtjQUNWOzBCQUNRLENBQUE2RSxNQUFBLENBQUFDLE1BQUE7Y0FDUnBGLGFBQUEsQ0FBY21GLE1BQUUsQ0FBQUcsS0FBQSxDQUFBdEYsYUFBQSxDQUFBbUYsTUFBQSxDQUFBSSxNQUFBOzs7WUFHdEJ4QyxPQUFBLEVBQUE0QyxHQUFBLEVBQUFoQyxHQUFBO1FBQ0E7WUFDRVQsTUFBTyxHQUFJSixTQUFRLENBQUFDLE9BQUE7WUFDbkJzQyxJQUFLLEdBQUFNLEdBQUEsQ0FBQVQsS0FBRCxDQUFDRyxJQUFBLFdBQURNLEdBQUcsQ0FBQVQsS0FBQSxDQUFBRyxJQUFBLEdBQWMsSUFBRTtZQUN2QmtCLENBQUEsU0FBQXJELE1BQUEsQ0FBQThFLE1BQUE7UUFDSm9GLEtBQUEsRUFBQWxOLFVBQUEsQ0FBQXVOLCtCQUFBO1FBRUFILGtCQUFxQjtRQUNyQjdNLElBQUs7VUFBSzRFLElBQUE7VUFBQUgsS0FBQTtZQUFBbUQsU0FBQTtVQUFBO1FBQUE7UUFBRTtZQUFRdEIsSUFBQSxHQUFVUixDQUFDLElBQUFBLENBQUEsQ0FBQTlGLElBQUEsSUFBQThGLENBQUEsQ0FBQTlGLElBQUEsQ0FBQXNHLElBQUEsSUFBQVIsQ0FBQSxDQUFBOUYsSUFBQSxDQUFBc0csSUFBQSxDQUFBQSxJQUFBO2FBQUVwRCxHQUFJLENBQUFnQixFQUFFO1FBQUFsRSxJQUFBO1VBQUEyRyxLQUFBLEVBQUFMLElBQUEsQ0FBQVYsR0FBQSxDQUFBNkgsQ0FBQTtZQUFBaEgsR0FBQSxFQUFBZ0gsQ0FBQSxDQUFBaEgsR0FBQTtZQUFBLElBQUFnSCxDQUFBLENBQUFqSCxPQUFBO1VBQUE7UUFBQTtNQUFBO2dCQUFFO2FBQWtCdEQsR0FBQSxDQUFBbUMsV0FBQTtRQUFBQyxVQUFBLEVBQUF6RixHQUFBLENBQUF5RixVQUFBO1FBQUF0RixJQUFBLEVBQUFILEdBQUEsQ0FBQUksT0FBQSxJQUFBRSxNQUFBLENBQUFOLEdBQUE7TUFBQTs7O1FBQVMsQ0FBQWdTLElBQUE7UUFDcEUsRUFBSSw0QkFBbUI7WUFDakIsRUFBQztVQUFPLEVBQUF0UyxhQUFPLENBQUFtRixNQUFBLENBQUFDLE1BQUE7c0JBQVksRUFBRXBGLGFBQUEsQ0FBQW1GLE1BQUEsQ0FBQU0sTUFBQTt3QkFBZ0IsRUFBQXpGLGFBQUEsQ0FBQW1GLE1BQUEsQ0FBQUcsS0FBQSxDQUFBdEYsYUFBQSxDQUFBbUYsTUFBQSxDQUFBTSxNQUFBO1FBQUUrTixtQkFBRSxFQUFBeFQsYUFBQSxDQUFBbUYsTUFBQSxDQUFBTSxNQUFBO1FBQ3ZEdEUsaUJBQUEsRUFBQW5CLGFBQUEsQ0FBQW1GLE1BQUEsQ0FBQUcsS0FBQSxDQUFBdEYsYUFBQSxDQUFBbUYsTUFBQSxDQUFBTSxNQUFBO1FBRUE1RCxhQUFNLEVBQVU3QixhQUFHLENBQUFtRixNQUFBLENBQUFHLEtBQUEsQ0FBQXRGLGFBQUEsQ0FBQW1GLE1BQUEsQ0FBQU0sTUFBQTtRQUNqQkMsTUFBSSxFQUFBMUYsYUFBQSxDQUFBbUYsTUFBQSxDQUFBRyxLQUFBLENBQUF0RixhQUFBLENBQUFtRixNQUFBLENBQUFNLE1BQUE7OztZQUVLMUMsT0FBUyxFQUFFNEMsR0FBQSxFQUFBaEMsR0FBQTs7WUFBZ0JULE1BQUEsR0FBQUosU0FBQSxDQUFBQyxPQUFBO1lBQUl0QyxJQUFBLEdBQUFrRixHQUFBLENBQUFsRixJQUFBO1lBQ3hDb0YsSUFBTyxHQUFHLElBQUExRixVQUFZLENBQUEwRCxZQUFjO1lBQ3BDN0MsU0FBTyxHQUFBNkUsSUFBQSxHQUFBQSxJQUFBLENBQUE5RSxRQUFBO1lBQUUwUyxjQUFNO1lBQUUvTixNQUFBLEdBQUErTixjQUFBLENBQUFDLE9BQUEsQ0FBQWpULElBQUEsQ0FBQWlGLE1BQUEsU0FBQWpGLElBQUEsQ0FBQWlGLE1BQUE7WUFBS2lPLEdBQUE7UUFBRUMsY0FBQSxFQUFBblQsSUFBQSxDQUFBbVQsY0FBQSxDQUFBQyxJQUFBO1FBQ3pCQyxnQkFBQSxHQUFBclQsSUFBQSxDQUFBcVQsZ0JBQUEsUUFBQUQsSUFBQTtRQUVETCxtQkFBcUIsRUFBRS9TLElBQUEsQ0FBQStTLG1CQUF1QjtRQUUxQ3JTLGlCQUFPLEVBQUFWLElBQUEsQ0FBQVUsaUJBQW9CO1FBQzNCVSxhQUFBLEVBQUFwQixJQUFrQixDQUFFb0IsYUFBSTtRQUN4QmtTLFNBQU0sTUFBQS9PLElBQUEsR0FBQUMsV0FBQTtRQUNOakUsU0FDSztRQUNMMEU7O1VBRUEsQ0FBQWlPLEdBQU0sQ0FBQUMsY0FBQTtlQUNBalEsR0FBRyxDQUFBbUMsV0FBQTtVQUFBQyxVQUFBO1VBQUF0RixJQUFBO1FBQUE7O1lBRVB5QyxNQUFBLENBQUFrSyxLQUFBO1FBQ0ZBLEtBQUEsRUFBQWxOLFVBQUEsQ0FBQXVOLCtCQUFBO1FBQ0F2TSxFQUNGLEVBQUF5UyxHQUFBLENBQUFDLGNBQUE7UUFFRkksT0FBTSxRQUFTO1FBQ2Z2VCxJQUFNLEVBQUFrVDtNQUtOO01BQ0EsT0FBQWhRLEdBQVUsQ0FBQWdCLEVBQUE7UUFBQWxFLElBQWU7VUFBS3dULE9BQUE7VUFBQU47UUFBQTtNQUFBO2FBQUFyVCxHQUFBO2FBQzVCcUQsR0FBTSxDQUFHbUMsV0FBQTtRQUFBQyxVQUFLLEVBQUF6RixHQUFPLENBQUF5RixVQUFBO1FBQUF0RixJQUFBLEVBQUFILEdBQUEsQ0FBQUksT0FBQSxJQUFBRSxNQUFBLENBQUFOLEdBQUE7TUFBVDs7O2VBRWE7VUFBMEMsNkNBQUM7WUFDcEU7TUFDRmtJLE1BQUUsRUFBQXhJLGFBQUEsQ0FBQW1GLE1BQUEsQ0FBQUMsTUFBQTtRQUVGd08sY0FBYyxFQUFBNVQsYUFBQSxDQUFBbUYsTUFBQSxDQUFBTSxNQUFBOzs7WUFHUjFDLE9BQU0sRUFBRzRDLEdBQUEsRUFBQWhDLEdBQUE7O1lBRVRULE1BQUMsR0FBQUosU0FBQSxDQUFBQyxPQUFBO1VBQ0g7Y0FDQUcsTUFBSyxDQUFBZ1IsTUFBQTtVQUNMOUcsS0FBQSxFQUFBbE4sVUFBZ0IsQ0FBQXVOLCtCQUE2QjtVQUMvQ3ZNLEVBQUEsRUFBQXlFLEdBQUEsQ0FBQTZDLE1BQUEsQ0FBQW9MLGNBQUE7VUFDQUksT0FBQTtRQUNGO01BQWlCLFNBQUFqRSxDQUFBO1FBQ2pCLElBQUFBLENBQU8sSUFBSUEsQ0FBQSxDQUFBaEssVUFBWTtVQUNyQixPQUFBcEMsR0FBVSxDQUFBZ0IsRUFBQTtZQUFBbEUsSUFBQTtjQUFBd1QsT0FBRSxFQUFHLElBQUM7Y0FBQXZULE9BQVU7WUFBQTtVQUFBO1FBQzFCO1FBQ0EsTUFBQXFQLENBQUE7TUFDSjtNQUVILE9BQUFwTSxHQUFBLENBQUFnQixFQUFBO1FBQUFsRSxJQUFBO1VBQUF3VCxPQUFBO1FBQUE7TUFBQTtJQUNILFNBQUEzVCxHQUFBIn0=