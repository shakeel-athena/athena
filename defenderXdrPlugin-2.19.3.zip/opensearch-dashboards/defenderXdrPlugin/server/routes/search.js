"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.registerDefenderSearchRoutes = registerDefenderSearchRoutes;
var _configSchema = require("@osd/config-schema");
var _constants = require("../../common/constants");
var _mdeClient = require("../lib/mde-client");
var _graphSecurityClient = require("../lib/graph-security-client");
/*
 * Defender plugin — OpenSearch reads + Graph/MDE proxies
 */

function mapGraphErr(err) {
  if (err instanceof _graphSecurityClient.GraphApiError) {
    return {
      status: err.status >= 400 && err.status < 600 ? err.status : 502,
      body: err.message
    };
  }
  return {
    status: 502,
    body: err instanceof Error ? err.message : String(err)
  };
}
function normalizeMdeMachine(m, tenantId) {
  return {
    tenant_id: tenantId,
    machine_id: m.id,
    computer_dns_name: m.computerDnsName || '',
    os_platform: m.osPlatform || '',
    os_version: m.osVersion || '',
    last_seen: m.lastSeen || null,
    first_seen: m.firstSeen || null,
    aad_device_id: m.aadDeviceId || '',
    risk_score: m.riskScore != null ? String(m.riskScore) : '',
    exposure_level: m.exposureLevel || '',
    onboarding_status: m.onboardingStatus || m.onboardingstatus || '',
    health_status: m.healthStatus || '',
    isolation_status: m.isolationStatus || '',
    last_ip_address: m.lastIpAddress || '',
    rbac_group_name: m.rbacGroupName || ''
  };
}
function getClient(context) {
  return context.core.opensearch.client.asCurrentUser;
}
function registerDefenderSearchRoutes(router) {
  router.get({
    path: '/api/defender_xdr/health',
    validate: false
  }, async (_context, _req, res) => {
    const mde = !!(0, _mdeClient.getMdeConfig)();
    const graph = !!(0, _graphSecurityClient.getGraphSecurityConfig)();
    const smtp_host = process.env.SMTP_HOST || null;
    const smtp_user = process.env.SMTP_USER || null;
    const smtp_port = process.env.SMTP_PORT || '587';
    const otp_recipient_email = process.env.OTP_RECIPIENT_EMAIL || null;
    const smtp_configured = !!(smtp_host && otp_recipient_email);
    return res.ok({
      body: {
        ok: mde || graph,
        mde_configured: mde,
        graph_security_configured: graph,
        smtp_configured,
        otp_dev_mode: !smtp_configured,
        smtp_host,
        smtp_user,
        smtp_port,
        otp_recipient_email,
        timestamp: new Date().toISOString()
      }
    });
  });
  router.get({
    path: '/api/defender_xdr/machines',
    validate: {
      query: _configSchema.schema.object({
        size: _configSchema.schema.maybe(_configSchema.schema.number()),
        from: _configSchema.schema.maybe(_configSchema.schema.number()),
        os_platform: _configSchema.schema.maybe(_configSchema.schema.string()),
        exposure_level: _configSchema.schema.maybe(_configSchema.schema.string()),
        source: _configSchema.schema.maybe(_configSchema.schema.string())
      })
    }
  }, async (context, req, res) => {
    const q = req.query;
    if (q.source === 'live') {
      const mcfg = (0, _mdeClient.getMdeConfig)();
      if (!mcfg) {
        return res.customError({
          statusCode: 503,
          body: 'MDE not configured.'
        });
      }
      try {
        var _q$from, _q$size;
        const raw = await (0, _mdeClient.fetchAllMachinesLimited)(mcfg, 15);
        const tenantId = mcfg.tenantId;
        let rows = raw.map(m => normalizeMdeMachine(m, tenantId));
        if (q.os_platform) {
          rows = rows.filter(r => String(r.os_platform) === q.os_platform);
        }
        if (q.exposure_level) {
          rows = rows.filter(r => String(r.exposure_level) === q.exposure_level);
        }
        rows.sort((a, b) => {
          const ta = a.last_seen ? new Date(String(a.last_seen)).getTime() : 0;
          const tb = b.last_seen ? new Date(String(b.last_seen)).getTime() : 0;
          return tb - ta;
        });
        const from = (_q$from = q.from) !== null && _q$from !== void 0 ? _q$from : 0;
        const size = (_q$size = q.size) !== null && _q$size !== void 0 ? _q$size : 50;
        const slice = rows.slice(from, from + size);
        const hits = slice.map(src => ({
          _source: src,
          _id: src.machine_id
        }));
        return res.ok({
          body: {
            hits,
            total: {
              value: rows.length,
              relation: 'eq'
            },
            source: 'mde'
          }
        });
      } catch (err) {
        var _err$message;
        return res.customError({
          statusCode: (0, _mdeClient.mdeErrorStatus)(err),
          body: (_err$message = err === null || err === void 0 ? void 0 : err.message) !== null && _err$message !== void 0 ? _err$message : String(err)
        });
      }
    }
    try {
      var _hits, _response$body, _hits$hits;
      const client = getClient(context);
      const {
        size = 50,
        from = 0,
        os_platform,
        exposure_level
      } = q;
      const must = [];
      if (os_platform) must.push({
        term: {
          os_platform
        }
      });
      if (exposure_level) must.push({
        term: {
          exposure_level
        }
      });
      const response = await client.search({
        index: _constants.DEFENDER_MACHINES_INDEX,
        ignore_unavailable: true,
        body: {
          size,
          from,
          sort: [{
            last_seen: {
              order: 'desc',
              missing: '_last'
            }
          }, {
            computer_dns_name: 'asc'
          }],
          query: must.length ? {
            bool: {
              must
            }
          } : {
            match_all: {}
          }
        }
      });
      const hits = (_hits = (_response$body = response.body) === null || _response$body === void 0 ? void 0 : _response$body.hits) !== null && _hits !== void 0 ? _hits : {};
      return res.ok({
        body: {
          hits: (_hits$hits = hits.hits) !== null && _hits$hits !== void 0 ? _hits$hits : [],
          total: hits.total,
          source: 'index'
        }
      });
    } catch (err) {
      var _err$statusCode, _err$message2;
      return res.customError({
        statusCode: (_err$statusCode = err.statusCode) !== null && _err$statusCode !== void 0 ? _err$statusCode : 500,
        body: (_err$message2 = err.message) !== null && _err$message2 !== void 0 ? _err$message2 : String(err)
      });
    }
  });
  router.get({
    path: '/api/defender_xdr/machines/{id}/live',
    validate: {
      params: _configSchema.schema.object({
        id: _configSchema.schema.string()
      })
    }
  }, async (_context, _req, res) => {
    const config = (0, _mdeClient.getMdeConfig)();
    if (!config) {
      return res.customError({
        statusCode: 503,
        body: 'Defender MDE not configured (DEFENDER_TENANT_ID, DEFENDER_CLIENT_ID, DEFENDER_CLIENT_SECRET).'
      });
    }
    try {
      const id = _req.params.id;
      const data = await (0, _mdeClient.getMachine)(config, id);
      return res.ok({
        body: data
      });
    } catch (err) {
      var _err$message3;
      return res.customError({
        statusCode: (0, _mdeClient.mdeErrorStatus)(err),
        body: (_err$message3 = err === null || err === void 0 ? void 0 : err.message) !== null && _err$message3 !== void 0 ? _err$message3 : String(err)
      });
    }
  });
  const mdeMachineSub = (pathSuffix, fn) => {
    router.get({
      path: `/api/defender_xdr/machines/{id}/live/${pathSuffix}`,
      validate: {
        params: _configSchema.schema.object({
          id: _configSchema.schema.string()
        })
      }
    }, async (_context, req, res) => {
      const mcfg = (0, _mdeClient.getMdeConfig)();
      if (!mcfg) {
        return res.customError({
          statusCode: 503,
          body: 'MDE not configured.'
        });
      }
      try {
        const id = req.params.id;
        const data = await fn(mcfg, id);
        return res.ok({
          body: data
        });
      } catch (err) {
        var _err$message4;
        return res.customError({
          statusCode: (0, _mdeClient.mdeErrorStatus)(err),
          body: (_err$message4 = err === null || err === void 0 ? void 0 : err.message) !== null && _err$message4 !== void 0 ? _err$message4 : String(err)
        });
      }
    });
  };
  mdeMachineSub('recommendations', _mdeClient.getMachineRecommendations);
  mdeMachineSub('vulnerabilities', _mdeClient.getMachineVulnerabilities);
  mdeMachineSub('alerts', _mdeClient.getMachineAlerts);
  mdeMachineSub('logonusers', _mdeClient.getMachineLogonUsers);
  mdeMachineSub('software', _mdeClient.getMachineSoftware);
  const SERVICE_NAME_RE = /^(system|localservice|networkservice|defaultaccount|guest|wdagutilityaccount|krbtgt|administrator)$/i;
  const SERVICE_DOMAIN_RE = /^(nt authority|nt service|font driver host|window manager)$/i;
  const INTERACTIVE_RE = /interactive|remoteinteractive|cachedinteractive|unlock/i;
  const isServiceAccount = u => {
    const n = String(u && u.accountName || '').trim();
    const d = String(u && u.accountDomain || '').trim();
    if (!n) return true;
    if (n.endsWith('$')) return true;
    if (SERVICE_NAME_RE.test(n)) return true;
    if (SERVICE_DOMAIN_RE.test(d)) return true;
    return false;
  };
  const pickPrimary = logonUsers => {
    const list = Array.isArray(logonUsers) ? logonUsers : logonUsers && logonUsers.value || [];
    const human = list.filter(u => !isServiceAccount(u));
    if (!human.length) return null;
    const sortedByLastSeen = human.slice().sort((a, b) => {
      const ta = a.lastSeen ? new Date(a.lastSeen).getTime() : 0;
      const tb = b.lastSeen ? new Date(b.lastSeen).getTime() : 0;
      return tb - ta;
    });
    const interactive = sortedByLastSeen.find(u => INTERACTIVE_RE.test(String(u.logonTypes || '')));
    const pick = interactive || sortedByLastSeen[0];
    return {
      accountName: pick.accountName,
      accountDomain: pick.accountDomain || null,
      lastSeen: pick.lastSeen || null,
      logonTypes: pick.logonTypes || null,
      isDomainAdmin: !!pick.isDomainAdmin
    };
  };
  const parseHostnameOwner = hostname => {
    if (!hostname) return null;
    const m = String(hostname).match(/^([A-Za-z][A-Za-z0-9]+)[-_]?([Mm]ac[Bb]ook|MBP|PC|MAC|MacBook|Laptop)/);
    if (m) return {
      accountName: m[1],
      inferred: true
    };
    return null;
  };
  const parseLoggedOnUsers = raw => {
    if (!raw) return [];
    if (Array.isArray(raw)) return raw;
    try {
      const parsed = JSON.parse(raw);
      return Array.isArray(parsed) ? parsed : [];
    } catch {
      return [];
    }
  };
  const pickFromHunting = entry => {
    const users = parseLoggedOnUsers(entry && entry.LoggedOnUsers);
    const human = users.map(u => ({
      accountName: u.UserName,
      accountDomain: u.DomainName,
      logonTypes: 'Interactive'
    })).filter(u => !isServiceAccount(u));
    if (!human.length) return null;
    const pick = human[0];
    return {
      accountName: pick.accountName,
      accountDomain: pick.accountDomain || null,
      logonTypes: 'Interactive',
      isDomainAdmin: false,
      lastSeen: entry.Timestamp || null,
      source: 'hunting'
    };
  };
  const readOwnerCache = async (client, machineIds) => {
    if (!machineIds.length) return {};
    try {
      const r = await client.search({
        index: _constants.DEFENDER_OWNER_CACHE_INDEX,
        ignore_unavailable: true,
        body: {
          size: machineIds.length,
          query: {
            terms: {
              machine_id: machineIds
            }
          }
        }
      });
      const hits = r && r.body && r.body.hits && r.body.hits.hits || [];
      const out = {};
      const now = Date.now();
      hits.forEach(h => {
        const s = h._source || {};
        const fetchedAt = s.fetched_at ? new Date(s.fetched_at).getTime() : 0;
        if (now - fetchedAt < _constants.DEFENDER_OWNER_CACHE_TTL_MS && s.machine_id) {
          out[s.machine_id] = s.primary_user || null;
        }
      });
      return out;
    } catch {
      return {};
    }
  };
  const writeOwnerCache = async (client, tenantId, entries) => {
    const ops = [];
    const now = new Date().toISOString();
    Object.entries(entries).forEach(([machine_id, primary_user]) => {
      ops.push({
        index: {
          _index: _constants.DEFENDER_OWNER_CACHE_INDEX,
          _id: machine_id
        }
      });
      ops.push({
        machine_id,
        primary_user,
        fetched_at: now,
        tenant_id: tenantId || 'unknown'
      });
    });
    if (!ops.length) return;
    try {
      await client.bulk({
        refresh: false,
        body: ops
      });
    } catch (e) {
      console.warn('[Defender] Failed to cache owner records:', e && e.message);
    }
  };
  const fetchAadOwnerEnrichment = async (gcfg, aadDeviceId) => {
    if (!gcfg || !aadDeviceId) return null;
    try {
      const lookup = await (0, _graphSecurityClient.graphSecurityRequest)(gcfg, 'GET', `/devices?$filter=deviceId eq '${aadDeviceId}'&$select=id,deviceId`, undefined, {
        ConsistencyLevel: 'eventual'
      });
      const aadDevice = lookup && Array.isArray(lookup.value) && lookup.value[0];
      if (!aadDevice) return null;
      const owners = await (0, _graphSecurityClient.graphSecurityRequest)(gcfg, 'GET', `/devices/${aadDevice.id}/registeredOwners?$select=id,displayName,mail,userPrincipalName,department,jobTitle`, undefined, {
        ConsistencyLevel: 'eventual'
      });
      const u = owners && Array.isArray(owners.value) && owners.value[0];
      if (!u) return null;
      return {
        displayName: u.displayName || null,
        email: u.mail || u.userPrincipalName || null,
        accountName: u.userPrincipalName ? String(u.userPrincipalName).split('@')[0] : u.displayName || null,
        department: u.department || null,
        jobTitle: u.jobTitle || null
      };
    } catch {
      return null;
    }
  };
  const fetchHuntingMostFrequent = async gcfg => {
    if (!gcfg) return {};
    const query = `DeviceInfo
| where Timestamp > ago(7d)
| summarize arg_max(Timestamp, *) by DeviceId
| project DeviceId, DeviceName, LoggedOnUsers, Timestamp
| take 5000`;
    try {
      const r = await (0, _graphSecurityClient.runHuntingQuery)(gcfg, query, 'P7D');
      const rows = r && r.results || [];
      const map = {};
      rows.forEach(row => {
        if (row && row.DeviceId) map[row.DeviceId] = row;
      });
      return map;
    } catch (e) {
      console.warn('[Defender] DeviceInfo hunting query failed:', e && e.message);
      return {};
    }
  };
  router.post({
    path: '/api/defender_xdr/primary-users',
    validate: {
      body: _configSchema.schema.object({
        machines: _configSchema.schema.arrayOf(_configSchema.schema.object({
          machine_id: _configSchema.schema.string(),
          computer_dns_name: _configSchema.schema.maybe(_configSchema.schema.string()),
          aad_device_id: _configSchema.schema.maybe(_configSchema.schema.string())
        })),
        force_refresh: _configSchema.schema.maybe(_configSchema.schema.boolean())
      })
    }
  }, async (context, req, res) => {
    const mcfg = (0, _mdeClient.getMdeConfig)();
    const gcfg = (0, _graphSecurityClient.getGraphSecurityConfig)();
    if (!mcfg && !gcfg) {
      return res.customError({
        statusCode: 503,
        body: 'Neither MDE nor Graph configured.'
      });
    }
    const client = getClient(context);
    const machines = req.body.machines || [];
    const forceRefresh = !!req.body.force_refresh;
    const result = {};
    const toFetch = [];
    const cached = forceRefresh ? {} : await readOwnerCache(client, machines.map(m => m.machine_id));
    machines.forEach(m => {
      if (cached[m.machine_id] !== undefined) {
        result[m.machine_id] = cached[m.machine_id];
      } else {
        toFetch.push(m);
      }
    });
    if (toFetch.length) {
      const huntingMap = await fetchHuntingMostFrequent(gcfg);
      const concurrency = 5;
      let cursor = 0;
      const newEntries = {};
      const next = async () => {
        while (cursor < toFetch.length) {
          const i = cursor++;
          const m = toFetch[i];
          let owner = null;
          const huntingHit = huntingMap[m.machine_id];
          if (huntingHit) owner = pickFromHunting(huntingHit);
          if (!owner && mcfg) {
            try {
              const data = await (0, _mdeClient.getMachineLogonUsers)(mcfg, m.machine_id);
              const pick = pickPrimary(data);
              if (pick) owner = {
                ...pick,
                source: 'logon'
              };
            } catch {}
          }
          if (m.aad_device_id && gcfg) {
            const aadOwner = await fetchAadOwnerEnrichment(gcfg, m.aad_device_id);
            if (aadOwner) {
              owner = {
                accountName: aadOwner.accountName || owner && owner.accountName || null,
                accountDomain: owner && owner.accountDomain || null,
                displayName: aadOwner.displayName,
                email: aadOwner.email,
                department: aadOwner.department,
                jobTitle: aadOwner.jobTitle,
                lastSeen: owner && owner.lastSeen,
                logonTypes: owner && owner.logonTypes,
                isDomainAdmin: owner && owner.isDomainAdmin,
                source: 'aad'
              };
            }
          }
          if (!owner) {
            const fb = parseHostnameOwner(m.computer_dns_name);
            if (fb) owner = {
              ...fb,
              source: 'hostname'
            };
          }
          newEntries[m.machine_id] = owner;
          result[m.machine_id] = owner;
        }
      };
      await Promise.all(Array.from({
        length: Math.min(concurrency, toFetch.length)
      }, next));
      const tenantId = mcfg ? mcfg.tenantId : gcfg ? gcfg.tenantId : 'unknown';
      void writeOwnerCache(client, tenantId, newEntries);
    }
    const sources = {};
    Object.values(result).forEach(v => {
      const s = v && v.source || 'none';
      sources[s] = (sources[s] || 0) + 1;
    });
    return res.ok({
      body: {
        value: result,
        meta: {
          total: machines.length,
          from_cache: machines.length - toFetch.length,
          fetched: toFetch.length,
          sources
        }
      }
    });
  });
  router.get({
    path: '/api/defender_xdr/mde/vulnerabilities',
    validate: {
      query: _configSchema.schema.object({
        top: _configSchema.schema.maybe(_configSchema.schema.number())
      })
    }
  }, async (_context, req, res) => {
    const mcfg = (0, _mdeClient.getMdeConfig)();
    if (!mcfg) return res.customError({
      statusCode: 503,
      body: 'MDE not configured.'
    });
    try {
      var _top;
      const top = (_top = req.query.top) !== null && _top !== void 0 ? _top : 200;
      const data = await (0, _mdeClient.listOrgVulnerabilities)(mcfg, top);
      return res.ok({
        body: data
      });
    } catch (err) {
      var _err$message5;
      return res.customError({
        statusCode: (0, _mdeClient.mdeErrorStatus)(err),
        body: (_err$message5 = err === null || err === void 0 ? void 0 : err.message) !== null && _err$message5 !== void 0 ? _err$message5 : String(err)
      });
    }
  });
  router.get({
    path: '/api/defender_xdr/mde/alerts-legacy',
    validate: {
      query: _configSchema.schema.object({
        top: _configSchema.schema.maybe(_configSchema.schema.number())
      })
    }
  }, async (_context, req, res) => {
    const mcfg = (0, _mdeClient.getMdeConfig)();
    if (!mcfg) return res.customError({
      statusCode: 503,
      body: 'MDE not configured.'
    });
    try {
      var _top2;
      const top = (_top2 = req.query.top) !== null && _top2 !== void 0 ? _top2 : 100;
      const data = await (0, _mdeClient.listLegacyAlerts)(mcfg, top);
      return res.ok({
        body: data
      });
    } catch (err) {
      var _err$message6;
      return res.customError({
        statusCode: (0, _mdeClient.mdeErrorStatus)(err),
        body: (_err$message6 = err === null || err === void 0 ? void 0 : err.message) !== null && _err$message6 !== void 0 ? _err$message6 : String(err)
      });
    }
  });
  router.get({
    path: '/api/defender_xdr/mde/machineactions',
    validate: {
      query: _configSchema.schema.object({
        top: _configSchema.schema.maybe(_configSchema.schema.number())
      })
    }
  }, async (_context, req, res) => {
    const mcfg = (0, _mdeClient.getMdeConfig)();
    if (!mcfg) return res.customError({
      statusCode: 503,
      body: 'MDE not configured.'
    });
    try {
      var _top3;
      const top = (_top3 = req.query.top) !== null && _top3 !== void 0 ? _top3 : 100;
      const data = await (0, _mdeClient.listMachineActions)(mcfg, top);
      return res.ok({
        body: data
      });
    } catch (err) {
      var _err$message7;
      return res.customError({
        statusCode: (0, _mdeClient.mdeErrorStatus)(err),
        body: (_err$message7 = err === null || err === void 0 ? void 0 : err.message) !== null && _err$message7 !== void 0 ? _err$message7 : String(err)
      });
    }
  });
  router.get({
    path: '/api/defender_xdr/mde/machineactions/{actionId}/package-uri',
    validate: {
      params: _configSchema.schema.object({
        actionId: _configSchema.schema.string()
      })
    }
  }, async (_context, req, res) => {
    const mcfg = (0, _mdeClient.getMdeConfig)();
    if (!mcfg) return res.customError({
      statusCode: 503,
      body: 'MDE not configured.'
    });
    try {
      const actionId = req.params.actionId;
      const data = await (0, _mdeClient.getMachineActionPackageUri)(mcfg, actionId);
      return res.ok({
        body: data
      });
    } catch (err) {
      var _err$message8;
      return res.customError({
        statusCode: (0, _mdeClient.mdeErrorStatus)(err),
        body: (_err$message8 = err === null || err === void 0 ? void 0 : err.message) !== null && _err$message8 !== void 0 ? _err$message8 : String(err)
      });
    }
  });
  router.get({
    path: '/api/defender_xdr/overview',
    validate: false
  }, async (context, _req, res) => {
    try {
      var _hits2, _machinesRes$body, _aggregations, _machinesRes$body2, _hitsBody$hits, _hitsBody$total$value, _hitsBody$total, _hitsBody$total2, _aggs$by_os$buckets, _aggs$by_os, _aggs$by_exposure$buc, _aggs$by_exposure, _aggs$by_health$bucke, _aggs$by_health, _aggs$by_risk$buckets, _aggs$by_risk;
      const client = getClient(context);
      const staleDate = new Date(Date.now() - 7 * 24 * 60 * 60 * 1000).toISOString();
      const machinesRes = await client.search({
        index: _constants.DEFENDER_MACHINES_INDEX,
        ignore_unavailable: true,
        body: {
          size: 8,
          track_total_hits: true,
          sort: [{
            last_seen: {
              order: 'desc',
              missing: '_last'
            }
          }],
          query: {
            match_all: {}
          },
          aggs: {
            by_os: {
              terms: {
                field: 'os_platform',
                size: 15
              }
            },
            by_exposure: {
              terms: {
                field: 'exposure_level',
                size: 10
              }
            },
            by_health: {
              terms: {
                field: 'health_status',
                size: 10
              }
            },
            by_risk: {
              terms: {
                field: 'risk_score',
                size: 15
              }
            }
          }
        }
      });
      let incidentsCount = 0;
      let alertsCount = 0;
      let vulnCount = 0;
      let linkedAgents = 0;
      let staleCount = 0;
      try {
        var _count, _ic$body, _count2, _ac$body, _count3, _vc$body, _count4, _idRes$body, _ref, _hits$total$value, _staleRes$body, _staleRes$body2;
        const [ic, ac, vc, idRes, staleRes] = await Promise.all([client.count({
          index: _constants.DEFENDER_INCIDENTS_INDEX,
          ignore_unavailable: true
        }), client.count({
          index: _constants.DEFENDER_ALERTS_INDEX,
          ignore_unavailable: true
        }), client.count({
          index: _constants.DEFENDER_VULNERABILITIES_INDEX,
          ignore_unavailable: true
        }), client.count({
          index: _constants.DEFENDER_MACHINE_IDENTITY_INDEX,
          ignore_unavailable: true
        }), client.search({
          index: _constants.DEFENDER_MACHINES_INDEX,
          ignore_unavailable: true,
          body: {
            size: 0,
            query: {
              bool: {
                filter: [{
                  range: {
                    last_seen: {
                      lt: staleDate
                    }
                  }
                }]
              }
            },
            track_total_hits: true
          }
        })]);
        incidentsCount = (_count = (_ic$body = ic.body) === null || _ic$body === void 0 ? void 0 : _ic$body.count) !== null && _count !== void 0 ? _count : 0;
        alertsCount = (_count2 = (_ac$body = ac.body) === null || _ac$body === void 0 ? void 0 : _ac$body.count) !== null && _count2 !== void 0 ? _count2 : 0;
        vulnCount = (_count3 = (_vc$body = vc.body) === null || _vc$body === void 0 ? void 0 : _vc$body.count) !== null && _count3 !== void 0 ? _count3 : 0;
        linkedAgents = (_count4 = (_idRes$body = idRes.body) === null || _idRes$body === void 0 ? void 0 : _idRes$body.count) !== null && _count4 !== void 0 ? _count4 : 0;
        staleCount = (_ref = (_hits$total$value = (_staleRes$body = staleRes.body) === null || _staleRes$body === void 0 || (_staleRes$body = _staleRes$body.hits) === null || _staleRes$body === void 0 || (_staleRes$body = _staleRes$body.total) === null || _staleRes$body === void 0 ? void 0 : _staleRes$body.value) !== null && _hits$total$value !== void 0 ? _hits$total$value : (_staleRes$body2 = staleRes.body) === null || _staleRes$body2 === void 0 || (_staleRes$body2 = _staleRes$body2.hits) === null || _staleRes$body2 === void 0 ? void 0 : _staleRes$body2.total) !== null && _ref !== void 0 ? _ref : 0;
      } catch {
        /* optional indices */
      }
      const hitsBody = (_hits2 = (_machinesRes$body = machinesRes.body) === null || _machinesRes$body === void 0 ? void 0 : _machinesRes$body.hits) !== null && _hits2 !== void 0 ? _hits2 : {};
      const aggs = (_aggregations = (_machinesRes$body2 = machinesRes.body) === null || _machinesRes$body2 === void 0 ? void 0 : _machinesRes$body2.aggregations) !== null && _aggregations !== void 0 ? _aggregations : {};
      const recent_machines = ((_hitsBody$hits = hitsBody.hits) !== null && _hitsBody$hits !== void 0 ? _hitsBody$hits : []).map(h => h._source).filter(Boolean);
      const totalMachines = typeof hitsBody.total === 'object' ? (_hitsBody$total$value = (_hitsBody$total = hitsBody.total) === null || _hitsBody$total === void 0 ? void 0 : _hitsBody$total.value) !== null && _hitsBody$total$value !== void 0 ? _hitsBody$total$value : 0 : (_hitsBody$total2 = hitsBody.total) !== null && _hitsBody$total2 !== void 0 ? _hitsBody$total2 : recent_machines.length;
      let byOsBuckets = (_aggs$by_os$buckets = (_aggs$by_os = aggs.by_os) === null || _aggs$by_os === void 0 ? void 0 : _aggs$by_os.buckets) !== null && _aggs$by_os$buckets !== void 0 ? _aggs$by_os$buckets : [];
      let byExposureBuckets = (_aggs$by_exposure$buc = (_aggs$by_exposure = aggs.by_exposure) === null || _aggs$by_exposure === void 0 ? void 0 : _aggs$by_exposure.buckets) !== null && _aggs$by_exposure$buc !== void 0 ? _aggs$by_exposure$buc : [];
      let byHealthBuckets = (_aggs$by_health$bucke = (_aggs$by_health = aggs.by_health) === null || _aggs$by_health === void 0 ? void 0 : _aggs$by_health.buckets) !== null && _aggs$by_health$bucke !== void 0 ? _aggs$by_health$bucke : [];
      let byRiskBuckets = (_aggs$by_risk$buckets = (_aggs$by_risk = aggs.by_risk) === null || _aggs$by_risk === void 0 ? void 0 : _aggs$by_risk.buckets) !== null && _aggs$by_risk$buckets !== void 0 ? _aggs$by_risk$buckets : [];
      let recentList = recent_machines;
      let total = totalMachines;
      let dataSource = 'index';
      const mcfg = (0, _mdeClient.getMdeConfig)();
      if (total === 0 && mcfg) {
        try {
          const raw = await (0, _mdeClient.fetchAllMachinesLimited)(mcfg, 10);
          const tid = mcfg.tenantId;
          const normalized = raw.map(m => normalizeMdeMachine(m, tid));
          if (normalized.length > 0) {
            dataSource = 'mde';
            total = normalized.length;
            recentList = normalized.slice().sort((a, b) => {
              const ta = a.last_seen ? new Date(String(a.last_seen)).getTime() : 0;
              const tb = b.last_seen ? new Date(String(b.last_seen)).getTime() : 0;
              return tb - ta;
            }).slice(0, 10);
            const osMap = {};
            const exMap = {};
            const healthMap = {};
            const riskMap = {};
            normalized.forEach(r => {
              const os = String(r.os_platform || 'Unknown');
              osMap[os] = (osMap[os] || 0) + 1;
              const ex = String(r.exposure_level || 'unknown');
              exMap[ex] = (exMap[ex] || 0) + 1;
              const hs = String(r.health_status || 'unknown');
              healthMap[hs] = (healthMap[hs] || 0) + 1;
              const rs = String(r.risk_score || 'unknown');
              riskMap[rs] = (riskMap[rs] || 0) + 1;
            });
            byOsBuckets = Object.entries(osMap).map(([key, doc_count]) => ({
              key,
              doc_count
            }));
            byExposureBuckets = Object.entries(exMap).map(([key, doc_count]) => ({
              key,
              doc_count
            }));
            byHealthBuckets = Object.entries(healthMap).map(([key, doc_count]) => ({
              key,
              doc_count
            }));
            byRiskBuckets = Object.entries(riskMap).map(([key, doc_count]) => ({
              key,
              doc_count
            }));
            staleCount = normalized.filter(r => !r.last_seen || new Date(String(r.last_seen)) < new Date(staleDate)).length;
          }
        } catch {
          /* keep index empty state */
        }
      }
      let liveIncidentsCount = null;
      let liveAlertsCount = null;
      let graphError = null;
      const gcfg = (0, _graphSecurityClient.getGraphSecurityConfig)();
      if (gcfg) {
        try {
          liveIncidentsCount = await (0, _graphSecurityClient.countSecurityCollection)(gcfg, 'incidents');
        } catch (e) {
          graphError = mapGraphErr(e).body;
          liveIncidentsCount = null;
        }
        try {
          liveAlertsCount = await (0, _graphSecurityClient.countSecurityCollection)(gcfg, 'alerts_v2');
        } catch (e) {
          if (!graphError) graphError = mapGraphErr(e).body;
          liveAlertsCount = null;
        }
      }
      return res.ok({
        body: {
          total_machines: total,
          by_os: byOsBuckets,
          by_exposure: byExposureBuckets,
          by_health: byHealthBuckets,
          by_risk: byRiskBuckets,
          recent_machines: recentList,
          incidents_index_count: incidentsCount,
          alerts_index_count: alertsCount,
          vulnerabilities_index_count: vulnCount,
          linked_agents_count: linkedAgents,
          stale_machines_count: staleCount,
          graph_incidents_live_count: liveIncidentsCount,
          graph_alerts_live_count: liveAlertsCount,
          graph_error_hint: graphError,
          data_source: dataSource
        }
      });
    } catch (err) {
      var _err$statusCode2, _err$message9;
      return res.customError({
        statusCode: (_err$statusCode2 = err.statusCode) !== null && _err$statusCode2 !== void 0 ? _err$statusCode2 : 500,
        body: (_err$message9 = err.message) !== null && _err$message9 !== void 0 ? _err$message9 : String(err)
      });
    }
  });
  router.get({
    path: '/api/defender_xdr/vulnerabilities',
    validate: {
      query: _configSchema.schema.object({
        size: _configSchema.schema.maybe(_configSchema.schema.number()),
        from: _configSchema.schema.maybe(_configSchema.schema.number()),
        source: _configSchema.schema.maybe(_configSchema.schema.string())
      })
    }
  }, async (context, req, res) => {
    const q = req.query;
    if (q.source === 'mde') {
      const mcfg = (0, _mdeClient.getMdeConfig)();
      if (!mcfg) return res.customError({
        statusCode: 503,
        body: 'MDE not configured.'
      });
      try {
        var _q$size2, _data$value, _q$from2, _q$size3;
        const data = await (0, _mdeClient.listOrgVulnerabilities)(mcfg, (_q$size2 = q.size) !== null && _q$size2 !== void 0 ? _q$size2 : 200);
        const rows = (_data$value = data === null || data === void 0 ? void 0 : data.value) !== null && _data$value !== void 0 ? _data$value : [];
        const from = (_q$from2 = q.from) !== null && _q$from2 !== void 0 ? _q$from2 : 0;
        const size = (_q$size3 = q.size) !== null && _q$size3 !== void 0 ? _q$size3 : 50;
        const slice = rows.slice(from, from + size);
        const hits = slice.map((row, i) => {
          var _ref2, _row$id;
          return {
            _id: String((_ref2 = (_row$id = row.id) !== null && _row$id !== void 0 ? _row$id : row.cveId) !== null && _ref2 !== void 0 ? _ref2 : i),
            _source: typeof row === 'object' ? row : {
              raw: row
            }
          };
        });
        return res.ok({
          body: {
            hits,
            total: {
              value: rows.length,
              relation: 'eq'
            },
            source: 'mde'
          }
        });
      } catch (err) {
        var _err$message10;
        return res.customError({
          statusCode: (0, _mdeClient.mdeErrorStatus)(err),
          body: (_err$message10 = err === null || err === void 0 ? void 0 : err.message) !== null && _err$message10 !== void 0 ? _err$message10 : String(err)
        });
      }
    }
    try {
      var _hits3, _response$body2, _hits$hits2;
      const client = getClient(context);
      const {
        size = 50,
        from = 0
      } = q;
      const response = await client.search({
        index: _constants.DEFENDER_VULNERABILITIES_INDEX,
        ignore_unavailable: true,
        body: {
          size,
          from,
          sort: [{
            sync_ts: {
              order: 'desc'
            }
          }],
          query: {
            match_all: {}
          }
        }
      });
      const hits = (_hits3 = (_response$body2 = response.body) === null || _response$body2 === void 0 ? void 0 : _response$body2.hits) !== null && _hits3 !== void 0 ? _hits3 : {};
      return res.ok({
        body: {
          hits: (_hits$hits2 = hits.hits) !== null && _hits$hits2 !== void 0 ? _hits$hits2 : [],
          total: hits.total,
          source: 'index'
        }
      });
    } catch (err) {
      var _err$statusCode3, _err$message11;
      return res.customError({
        statusCode: (_err$statusCode3 = err.statusCode) !== null && _err$statusCode3 !== void 0 ? _err$statusCode3 : 500,
        body: (_err$message11 = err.message) !== null && _err$message11 !== void 0 ? _err$message11 : String(err)
      });
    }
  });
  router.get({
    path: '/api/defender_xdr/incidents/live',
    validate: {
      query: _configSchema.schema.object({
        top: _configSchema.schema.maybe(_configSchema.schema.number())
      })
    }
  }, async (_context, req, res) => {
    const config = (0, _graphSecurityClient.getGraphSecurityConfig)();
    if (!config) {
      return res.customError({
        statusCode: 503,
        body: 'Graph security not configured.'
      });
    }
    try {
      var _top4;
      const top = (_top4 = req.query.top) !== null && _top4 !== void 0 ? _top4 : 25;
      const data = await (0, _graphSecurityClient.listIncidents)(config, top);
      return res.ok({
        body: data
      });
    } catch (err) {
      const {
        status,
        body
      } = mapGraphErr(err);
      return res.customError({
        statusCode: status,
        body
      });
    }
  });
  router.get({
    path: '/api/defender_xdr/incidents/{id}',
    validate: {
      params: _configSchema.schema.object({
        id: _configSchema.schema.string()
      })
    }
  }, async (_context, req, res) => {
    const config = (0, _graphSecurityClient.getGraphSecurityConfig)();
    if (!config) {
      return res.customError({
        statusCode: 503,
        body: 'Graph security not configured.'
      });
    }
    try {
      const data = await (0, _graphSecurityClient.getIncident)(config, req.params.id);
      return res.ok({
        body: data
      });
    } catch (err) {
      const {
        status,
        body
      } = mapGraphErr(err);
      return res.customError({
        statusCode: status,
        body
      });
    }
  });
  router.get({
    path: '/api/defender_xdr/alerts/{id}',
    validate: {
      params: _configSchema.schema.object({
        id: _configSchema.schema.string()
      })
    }
  }, async (_context, req, res) => {
    const config = (0, _graphSecurityClient.getGraphSecurityConfig)();
    if (!config) {
      return res.customError({
        statusCode: 503,
        body: 'Graph security not configured.'
      });
    }
    try {
      const data = await (0, _graphSecurityClient.graphSecurityRequest)(config, 'GET', `/security/alerts_v2/${encodeURIComponent(req.params.id)}`, undefined, {
        ConsistencyLevel: 'eventual'
      });
      return res.ok({
        body: data
      });
    } catch (err) {
      const {
        status,
        body
      } = mapGraphErr(err);
      return res.customError({
        statusCode: status,
        body
      });
    }
  });
  router.get({
    path: '/api/defender_xdr/alerts/live',
    validate: {
      query: _configSchema.schema.object({
        top: _configSchema.schema.maybe(_configSchema.schema.number())
      })
    }
  }, async (_context, req, res) => {
    const config = (0, _graphSecurityClient.getGraphSecurityConfig)();
    if (!config) {
      return res.customError({
        statusCode: 503,
        body: 'Graph security not configured.'
      });
    }
    try {
      var _top5;
      const top = (_top5 = req.query.top) !== null && _top5 !== void 0 ? _top5 : 25;
      const data = await (0, _graphSecurityClient.listAlertsV2)(config, top);
      return res.ok({
        body: data
      });
    } catch (err) {
      const {
        status,
        body
      } = mapGraphErr(err);
      return res.customError({
        statusCode: status,
        body
      });
    }
  });
  router.post({
    path: '/api/defender_xdr/hunting',
    validate: {
      body: _configSchema.schema.object({
        query: _configSchema.schema.string(),
        timespan: _configSchema.schema.maybe(_configSchema.schema.string())
      })
    }
  }, async (_context, req, res) => {
    const config = (0, _graphSecurityClient.getGraphSecurityConfig)();
    if (!config) {
      return res.customError({
        statusCode: 503,
        body: 'Graph security not configured.'
      });
    }
    try {
      const {
        query,
        timespan
      } = req.body;
      const started = Date.now();
      const data = await (0, _graphSecurityClient.runHuntingQuery)(config, query, timespan || 'P7D');
      const rowCount = Array.isArray(data === null || data === void 0 ? void 0 : data.results) ? data.results.length : 0;
      return res.ok({
        body: {
          ...(data || {}),
          executionTimeMs: Date.now() - started,
          rowCount
        }
      });
    } catch (err) {
      const {
        status,
        body
      } = mapGraphErr(err);
      return res.customError({
        statusCode: status,
        body
      });
    }
  });
  router.get({
    path: '/api/defender_xdr/indicators/live',
    validate: {
      query: _configSchema.schema.object({
        top: _configSchema.schema.maybe(_configSchema.schema.number())
      })
    }
  }, async (_context, req, res) => {
    const config = (0, _mdeClient.getMdeConfig)();
    if (!config) {
      return res.customError({
        statusCode: 503,
        body: 'MDE not configured.'
      });
    }
    try {
      var _top6;
      const top = (_top6 = req.query.top) !== null && _top6 !== void 0 ? _top6 : 100;
      const data = await (0, _mdeClient.listIndicators)(config, top);
      return res.ok({
        body: data
      });
    } catch (err) {
      var _err$message12;
      return res.customError({
        statusCode: (0, _mdeClient.mdeErrorStatus)(err),
        body: (_err$message12 = err === null || err === void 0 ? void 0 : err.message) !== null && _err$message12 !== void 0 ? _err$message12 : String(err)
      });
    }
  });
  router.get({
    path: '/api/defender_xdr/audit-log',
    validate: {
      query: _configSchema.schema.object({
        size: _configSchema.schema.maybe(_configSchema.schema.number())
      })
    }
  }, async (context, req, res) => {
    try {
      var _size, _hits$hits3, _response$body3;
      const client = getClient(context);
      const size = (_size = req.query.size) !== null && _size !== void 0 ? _size : 50;
      const response = await client.search({
        index: _constants.DEFENDER_AUDIT_LOG_INDEX,
        ignore_unavailable: true,
        body: {
          size,
          sort: [{
            timestamp: {
              order: 'desc'
            }
          }],
          query: {
            match_all: {}
          }
        }
      });
      const hits = (_hits$hits3 = (_response$body3 = response.body) === null || _response$body3 === void 0 || (_response$body3 = _response$body3.hits) === null || _response$body3 === void 0 ? void 0 : _response$body3.hits) !== null && _hits$hits3 !== void 0 ? _hits$hits3 : [];
      return res.ok({
        body: {
          entries: hits.map(h => h._source)
        }
      });
    } catch (err) {
      var _err$statusCode4, _err$message13;
      return res.customError({
        statusCode: (_err$statusCode4 = err.statusCode) !== null && _err$statusCode4 !== void 0 ? _err$statusCode4 : 500,
        body: (_err$message13 = err.message) !== null && _err$message13 !== void 0 ? _err$message13 : String(err)
      });
    }
  });
  router.get({
    path: '/api/defender_xdr/identity',
    validate: {
      query: _configSchema.schema.object({
        size: _configSchema.schema.maybe(_configSchema.schema.number())
      })
    }
  }, async (context, req, res) => {
    try {
      const client = getClient(context);
      const size = req.query.size != null ? req.query.size : 1000;
      const r = await client.search({
        index: _constants.DEFENDER_MACHINE_IDENTITY_INDEX,
        ignore_unavailable: true,
        body: {
          size,
          query: {
            match_all: {}
          }
        }
      });
      const hits = r && r.body && r.body.hits && r.body.hits.hits || [];
      return res.ok({
        body: {
          value: hits.map(h => ({
            _id: h._id,
            ...(h._source || {})
          }))
        }
      });
    } catch (err) {
      return res.customError({
        statusCode: err.statusCode || 500,
        body: err.message || String(err)
      });
    }
  });
  router.post({
    path: '/api/defender_xdr/identity',
    validate: {
      body: _configSchema.schema.object({
        wazuh_agent_id: _configSchema.schema.string(),
        wazuh_agent_name: _configSchema.schema.maybe(_configSchema.schema.string()),
        defender_machine_id: _configSchema.schema.string(),
        computer_dns_name: _configSchema.schema.maybe(_configSchema.schema.string()),
        aad_device_id: _configSchema.schema.maybe(_configSchema.schema.string()),
        source: _configSchema.schema.maybe(_configSchema.schema.string())
      })
    }
  }, async (context, req, res) => {
    try {
      const client = getClient(context);
      const body = req.body;
      const mcfg = (0, _mdeClient.getMdeConfig)();
      const tenant_id = mcfg ? mcfg.tenantId : 'unknown';
      const allowedSources = ['aad_device_id', 'hostname_match', 'machine_id_match', 'manual'];
      const source = allowedSources.indexOf(body.source) >= 0 ? body.source : 'manual';
      const doc = {
        wazuh_agent_id: body.wazuh_agent_id.trim(),
        wazuh_agent_name: (body.wazuh_agent_name || '').trim(),
        defender_machine_id: body.defender_machine_id,
        computer_dns_name: body.computer_dns_name || '',
        aad_device_id: body.aad_device_id || '',
        linked_at: new Date().toISOString(),
        tenant_id,
        source
      };
      if (!doc.wazuh_agent_id) {
        return res.customError({
          statusCode: 400,
          body: 'wazuh_agent_id is required'
        });
      }
      await client.index({
        index: _constants.DEFENDER_MACHINE_IDENTITY_INDEX,
        id: doc.wazuh_agent_id,
        refresh: 'true',
        body: doc
      });
      return res.ok({
        body: {
          success: true,
          doc
        }
      });
    } catch (err) {
      return res.customError({
        statusCode: err.statusCode || 500,
        body: err.message || String(err)
      });
    }
  });
  router.delete({
    path: '/api/defender_xdr/identity/{wazuh_agent_id}',
    validate: {
      params: _configSchema.schema.object({
        wazuh_agent_id: _configSchema.schema.string()
      })
    }
  }, async (context, req, res) => {
    try {
      const client = getClient(context);
      try {
        await client.delete({
          index: _constants.DEFENDER_MACHINE_IDENTITY_INDEX,
          id: req.params.wazuh_agent_id,
          refresh: 'true'
        });
      } catch (e) {
        if (e && e.statusCode === 404) {
          return res.ok({
            body: {
              success: true,
              message: 'not_found'
            }
          });
        }
        throw e;
      }
      return res.ok({
        body: {
          success: true
        }
      });
    } catch (err) {
      return res.customError({
        statusCode: err.statusCode || 500,
        body: err.message || String(err)
      });
    }
  });
  router.post({
    path: '/api/defender_xdr/alerts_enrichment',
    validate: {
      body: _configSchema.schema.object({
        size: _configSchema.schema.maybe(_configSchema.schema.number()),
        from: _configSchema.schema.maybe(_configSchema.schema.number()),
        time_from: _configSchema.schema.maybe(_configSchema.schema.string()),
        time_to: _configSchema.schema.maybe(_configSchema.schema.string()),
        defender_correlated_only: _configSchema.schema.maybe(_configSchema.schema.boolean())
      })
    }
  }, async (context, req, res) => {
    try {
      var _hits$hits5, _alertsResponse$body, _ref3, _hits$total$value2, _countResponse$body, _countResponse$body2;
      const client = getClient(context);
      const {
        size = 25,
        from = 0,
        time_from,
        time_to,
        defender_correlated_only = true
      } = req.body;
      const now = new Date();
      const defaultTo = now.toISOString();
      const defaultFrom = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000).toISOString();
      const timeGte = time_from || defaultFrom;
      const timeLte = time_to || defaultTo;
      const timeRangeFilter = {
        range: {
          timestamp: {
            gte: timeGte,
            lte: timeLte
          }
        }
      };
      let agentIdsToQuery = null;
      const agentToDefender = {};
      if (defender_correlated_only) {
        var _hits$hits4, _identityRes$body;
        const identityRes = await client.search({
          index: _constants.DEFENDER_MACHINE_IDENTITY_INDEX,
          ignore_unavailable: true,
          body: {
            size: 1000,
            _source: ['wazuh_agent_id', 'defender_machine_id', 'computer_dns_name'],
            query: {
              match_all: {}
            }
          }
        });
        const identityHits = (_hits$hits4 = (_identityRes$body = identityRes.body) === null || _identityRes$body === void 0 || (_identityRes$body = _identityRes$body.hits) === null || _identityRes$body === void 0 ? void 0 : _identityRes$body.hits) !== null && _hits$hits4 !== void 0 ? _hits$hits4 : [];
        agentIdsToQuery = identityHits.map(h => {
          var _h$_source;
          return (_h$_source = h._source) === null || _h$_source === void 0 ? void 0 : _h$_source.wazuh_agent_id;
        }).filter(id => id && id !== '000');
        if (agentIdsToQuery.length === 0) {
          return res.ok({
            body: {
              alerts: [],
              enrichments: {},
              total: 0,
              identity_count: 0
            }
          });
        }
        identityHits.forEach(h => {
          const s = h._source;
          if (s !== null && s !== void 0 && s.wazuh_agent_id) agentToDefender[s.wazuh_agent_id] = s.defender_machine_id;
        });
      }
      const must = [timeRangeFilter];
      must.push({
        bool: {
          must_not: [{
            term: {
              'agent.id': '000'
            }
          }]
        }
      });
      if (agentIdsToQuery && agentIdsToQuery.length > 0) {
        must.push({
          terms: {
            'agent.id': agentIdsToQuery
          }
        });
      }
      const alertsBody = {
        from,
        size,
        sort: [{
          timestamp: {
            order: 'desc'
          }
        }],
        _source: ['agent.id', 'agent.name', 'rule.description', 'rule.level', 'timestamp'],
        query: {
          bool: {
            must
          }
        }
      };
      const [alertsResponse, countResponse] = await Promise.all([client.search({
        index: _constants.WAZUH_ALERTS_PATTERN,
        ignore_unavailable: true,
        body: alertsBody
      }), client.search({
        index: _constants.WAZUH_ALERTS_PATTERN,
        ignore_unavailable: true,
        body: {
          size: 0,
          query: alertsBody.query,
          track_total_hits: true
        }
      })]);
      const alertHits = (_hits$hits5 = (_alertsResponse$body = alertsResponse.body) === null || _alertsResponse$body === void 0 || (_alertsResponse$body = _alertsResponse$body.hits) === null || _alertsResponse$body === void 0 ? void 0 : _alertsResponse$body.hits) !== null && _hits$hits5 !== void 0 ? _hits$hits5 : [];
      const total = (_ref3 = (_hits$total$value2 = (_countResponse$body = countResponse.body) === null || _countResponse$body === void 0 || (_countResponse$body = _countResponse$body.hits) === null || _countResponse$body === void 0 || (_countResponse$body = _countResponse$body.total) === null || _countResponse$body === void 0 ? void 0 : _countResponse$body.value) !== null && _hits$total$value2 !== void 0 ? _hits$total$value2 : (_countResponse$body2 = countResponse.body) === null || _countResponse$body2 === void 0 || (_countResponse$body2 = _countResponse$body2.hits) === null || _countResponse$body2 === void 0 ? void 0 : _countResponse$body2.total) !== null && _ref3 !== void 0 ? _ref3 : alertHits.length;
      const enrichments = {};
      alertHits.forEach(h => {
        var _h$_source2;
        const aid = (_h$_source2 = h._source) === null || _h$_source2 === void 0 || (_h$_source2 = _h$_source2.agent) === null || _h$_source2 === void 0 ? void 0 : _h$_source2.id;
        if (aid && agentToDefender[aid]) {
          enrichments[h._id] = {
            defender_machine_id: agentToDefender[aid]
          };
        }
      });
      return res.ok({
        body: {
          alerts: alertHits.map(h => ({
            id: h._id,
            ...h._source
          })),
          enrichments,
          total,
          identity_count: Object.keys(agentToDefender).length
        }
      });
    } catch (err) {
      var _err$statusCode5, _err$message14;
      return res.customError({
        statusCode: (_err$statusCode5 = err.statusCode) !== null && _err$statusCode5 !== void 0 ? _err$statusCode5 : 500,
        body: (_err$message14 = err.message) !== null && _err$message14 !== void 0 ? _err$message14 : String(err)
      });
    }
  });
}
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfY29uZmlnU2NoZW1hIiwicmVxdWlyZSIsIl9jb25zdGFudHMiLCJfbWRlQ2xpZW50IiwiX2dyYXBoU2VjdXJpdHlDbGllbnQiLCJtYXBHcmFwaEVyciIsImVyciIsIkdyYXBoQXBpRXJyb3IiLCJzdGF0dXMiLCJib2R5IiwibWVzc2FnZSIsIkVycm9yIiwiU3RyaW5nIiwibm9ybWFsaXplTWRlTWFjaGluZSIsIm0iLCJ0ZW5hbnRJZCIsInRlbmFudF9pZCIsIm1hY2hpbmVfaWQiLCJpZCIsImNvbXB1dGVyX2Ruc19uYW1lIiwiY29tcHV0ZXJEbnNOYW1lIiwib3NfcGxhdGZvcm0iLCJvc1BsYXRmb3JtIiwib3NfdmVyc2lvbiIsIm9zVmVyc2lvbiIsImxhc3Rfc2VlbiIsImxhc3RTZWVuIiwiZmlyc3Rfc2VlbiIsImZpcnN0U2VlbiIsImFhZF9kZXZpY2VfaWQiLCJhYWREZXZpY2VJZCIsInJpc2tfc2NvcmUiLCJyaXNrU2NvcmUiLCJleHBvc3VyZV9sZXZlbCIsImV4cG9zdXJlTGV2ZWwiLCJvbmJvYXJkaW5nX3N0YXR1cyIsIm9uYm9hcmRpbmdTdGF0dXMiLCJvbmJvYXJkaW5nc3RhdHVzIiwiaGVhbHRoX3N0YXR1cyIsImhlYWx0aFN0YXR1cyIsImlzb2xhdGlvbl9zdGF0dXMiLCJpc29sYXRpb25TdGF0dXMiLCJsYXN0X2lwX2FkZHJlc3MiLCJsYXN0SXBBZGRyZXNzIiwicmJhY19ncm91cF9uYW1lIiwicmJhY0dyb3VwTmFtZSIsImdldENsaWVudCIsImNvbnRleHQiLCJjb3JlIiwib3BlbnNlYXJjaCIsImNsaWVudCIsImFzQ3VycmVudFVzZXIiLCJyZWdpc3RlckRlZmVuZGVyU2VhcmNoUm91dGVzIiwicm91dGVyIiwiZ2V0IiwicGF0aCIsInZhbGlkYXRlIiwiX2NvbnRleHQiLCJfcmVxIiwicmVzIiwibWRlIiwiZ2V0TWRlQ29uZmlnIiwiZ3JhcGgiLCJnZXRHcmFwaFNlY3VyaXR5Q29uZmlnIiwic210cF9ob3N0IiwicHJvY2VzcyIsImVudiIsIlNNVFBfSE9TVCIsInNtdHBfdXNlciIsIlNNVFBfVVNFUiIsInNtdHBfcG9ydCIsIlNNVFBfUE9SVCIsIm90cF9yZWNpcGllbnRfZW1haWwiLCJPVFBfUkVDSVBJRU5UX0VNQUlMIiwic210cF9jb25maWd1cmVkIiwib2siLCJtZGVfY29uZmlndXJlZCIsImdyYXBoX3NlY3VyaXR5X2NvbmZpZ3VyZWQiLCJvdHBfZGV2X21vZGUiLCJ0aW1lc3RhbXAiLCJEYXRlIiwidG9JU09TdHJpbmciLCJxdWVyeSIsInNjaGVtYSIsIm9iamVjdCIsInNpemUiLCJtYXliZSIsIm51bWJlciIsImZyb20iLCJzdHJpbmciLCJzb3VyY2UiLCJyZXEiLCJxIiwibWNmZyIsImN1c3RvbUVycm9yIiwic3RhdHVzQ29kZSIsIl9xJGZyb20iLCJfcSRzaXplIiwicmF3IiwiZmV0Y2hBbGxNYWNoaW5lc0xpbWl0ZWQiLCJyb3dzIiwibWFwIiwiZmlsdGVyIiwiciIsInNvcnQiLCJhIiwiYiIsInRhIiwiZ2V0VGltZSIsInRiIiwic2xpY2UiLCJoaXRzIiwic3JjIiwiX3NvdXJjZSIsIl9pZCIsInRvdGFsIiwidmFsdWUiLCJsZW5ndGgiLCJyZWxhdGlvbiIsIl9lcnIkbWVzc2FnZSIsIm1kZUVycm9yU3RhdHVzIiwiX2hpdHMiLCJfcmVzcG9uc2UkYm9keSIsIl9oaXRzJGhpdHMiLCJtdXN0IiwicHVzaCIsInRlcm0iLCJyZXNwb25zZSIsInNlYXJjaCIsIkRFRkVOREVSX01BQ0hJTkVTX0lOREVYIiwib3JkZXIiLCJtaXNzaW5nIiwiYm9vbCIsIm1hdGNoX2FsbCIsIl9lcnIkc3RhdHVzQ29kZSIsIl9lcnIkbWVzc2FnZTIiLCJwYXJhbXMiLCJjb25maWciLCJkYXRhIiwiZ2V0TWFjaGluZSIsIl9lcnIkbWVzc2FnZTMiLCJtZGVNYWNoaW5lU3ViIiwicGF0aFN1ZmZpeCIsImZuIiwiX2VyciRtZXNzYWdlNCIsImdldE1hY2hpbmVSZWNvbW1lbmRhdGlvbnMiLCJnZXRNYWNoaW5lVnVsbmVyYWJpbGl0aWVzIiwiZ2V0TWFjaGluZUFsZXJ0cyIsImdldE1hY2hpbmVMb2dvblVzZXJzIiwiZ2V0TWFjaGluZVNvZnR3YXJlIiwiU0VSVklDRV9OQU1FX1JFIiwiU0VSVklDRV9ET01BSU5fUkUiLCJJTlRFUkFDVElWRV9SRSIsImlzU2VydmljZUFjY291bnQiLCJ1IiwibiIsImFjY291bnROYW1lIiwidHJpbSIsImQiLCJhY2NvdW50RG9tYWluIiwiZW5kc1dpdGgiLCJ0ZXN0IiwicGlja1ByaW1hcnkiLCJsb2dvblVzZXJzIiwibGlzdCIsIkFycmF5IiwiaXNBcnJheSIsImh1bWFuIiwic29ydGVkQnlMYXN0U2VlbiIsImludGVyYWN0aXZlIiwiZmluZCIsImxvZ29uVHlwZXMiLCJwaWNrIiwiaXNEb21haW5BZG1pbiIsInBhcnNlSG9zdG5hbWVPd25lciIsImhvc3RuYW1lIiwibWF0Y2giLCJpbmZlcnJlZCIsInBhcnNlTG9nZ2VkT25Vc2VycyIsInBhcnNlZCIsIkpTT04iLCJwYXJzZSIsInBpY2tGcm9tSHVudGluZyIsImVudHJ5IiwidXNlcnMiLCJMb2dnZWRPblVzZXJzIiwiVXNlck5hbWUiLCJEb21haW5OYW1lIiwiVGltZXN0YW1wIiwicmVhZE93bmVyQ2FjaGUiLCJtYWNoaW5lSWRzIiwiaW5kZXgiLCJERUZFTkRFUl9PV05FUl9DQUNIRV9JTkRFWCIsImlnbm9yZV91bmF2YWlsYWJsZSIsInRlcm1zIiwib3V0Iiwibm93IiwiZm9yRWFjaCIsImgiLCJzIiwiZmV0Y2hlZEF0IiwiZmV0Y2hlZF9hdCIsIkRFRkVOREVSX09XTkVSX0NBQ0hFX1RUTF9NUyIsInByaW1hcnlfdXNlciIsIndyaXRlT3duZXJDYWNoZSIsImVudHJpZXMiLCJvcHMiLCJPYmplY3QiLCJfaW5kZXgiLCJidWxrIiwicmVmcmVzaCIsImUiLCJjb25zb2xlIiwid2FybiIsImZldGNoQWFkT3duZXJFbnJpY2htZW50IiwiZ2NmZyIsImxvb2t1cCIsImdyYXBoU2VjdXJpdHlSZXF1ZXN0IiwiQ29uc2lzdGVuY3lMZXZlbCIsImFhZERldmljZSIsIm93bmVycyIsImRpc3BsYXlOYW1lIiwibWFpbCIsInVzZXJQcmluY2lwYWxOYW1lIiwic3BsaXQiLCJkZXBhcnRtZW50Iiwiam9iVGl0bGUiLCJydW5IdW50aW5nUXVlcnkiLCJyZXN1bHRzIiwicm93IiwiRGV2aWNlSWQiLCJwb3N0IiwiYXJyYXlPZiIsImJvb2xlYW4iLCJtYWNoaW5lcyIsImZvcmNlX3JlZnJlc2giLCJyZXN1bHQiLCJ0b0ZldGNoIiwiY2FjaGVkIiwiZm9yY2VSZWZyZXNoIiwidW5kZWZpbmVkIiwiaHVudGluZ01hcCIsImZldGNoSHVudGluZ01vc3RGcmVxdWVudCIsImNvbmN1cnJlbmN5IiwiY3Vyc29yIiwibmV3RW50cmllcyIsIm5leHQiLCJpIiwib3duZXIiLCJodW50aW5nSGl0IiwiYWFkT3duZXIiLCJlbWFpbCIsImZiIiwiYWxsIiwiTWF0aCIsIm1pbiIsInNvdXJjZXMiLCJ2YWx1ZXMiLCJ2IiwiZnJvbV9jYWNoZSIsImZldGNoZWQiLCJ0b3AiLCJfdG9wIiwibGlzdE9yZ1Z1bG5lcmFiaWxpdGllcyIsIl9lcnIkbWVzc2FnZTUiLCJfdG9wMiIsImxpc3RMZWdhY3lBbGVydHMiLCJfZXJyJG1lc3NhZ2U2IiwiX3RvcDMiLCJsaXN0TWFjaGluZUFjdGlvbnMiLCJfZXJyJG1lc3NhZ2U3IiwiYWN0aW9uSWQiLCJnZXRNYWNoaW5lQWN0aW9uUGFja2FnZVVyaSIsIl9lcnIkbWVzc2FnZTgiLCJfaGl0czIiLCJfbWFjaGluZXNSZXMkYm9keSIsIl9hZ2dyZWdhdGlvbnMiLCJfbWFjaGluZXNSZXMkYm9keTIiLCJfaGl0c0JvZHkkaGl0cyIsIl9oaXRzQm9keSR0b3RhbCR2YWx1ZSIsIl9oaXRzQm9keSR0b3RhbCIsIl9oaXRzQm9keSR0b3RhbDIiLCJfYWdncyRieV9vcyRidWNrZXRzIiwiX2FnZ3MkYnlfb3MiLCJfYWdncyRieV9leHBvc3VyZSRidWMiLCJfYWdncyRieV9leHBvc3VyZSIsIl9hZ2dzJGJ5X2hlYWx0aCRidWNrZSIsIl9hZ2dzJGJ5X2hlYWx0aCIsIl9hZ2dzJGJ5X3Jpc2skYnVja2V0cyIsIl9hZ2dzJGJ5X3Jpc2siLCJzdGFsZURhdGUiLCJtYWNoaW5lc1JlcyIsInRyYWNrX3RvdGFsX2hpdHMiLCJhZ2dzIiwiYnlfb3MiLCJmaWVsZCIsImJ5X2V4cG9zdXJlIiwiYnlfaGVhbHRoIiwiYnlfcmlzayIsImluY2lkZW50c0NvdW50IiwiYWxlcnRzQ291bnQiLCJ2dWxuQ291bnQiLCJsaW5rZWRBZ2VudHMiLCJzdGFsZUNvdW50IiwiX2NvdW50IiwiX2ljJGJvZHkiLCJfY291bnQyIiwiX2FjJGJvZHkiLCJfY291bnQzIiwiX3ZjJGJvZHkiLCJfY291bnQ0IiwiX2lkUmVzJGJvZHkiLCJfcmVmIiwiX2hpdHMkdG90YWwkdmFsdWUiLCJfc3RhbGVSZXMkYm9keSIsIl9zdGFsZVJlcyRib2R5MiIsImljIiwiYWMiLCJ2YyIsImlkUmVzIiwic3RhbGVSZXMiLCJQcm9taXNlIiwiY291bnQiLCJERUZFTkRFUl9JTkNJREVOVFNfSU5ERVgiLCJERUZFTkRFUl9BTEVSVFNfSU5ERVgiLCJERUZFTkRFUl9WVUxORVJBQklMSVRJRVNfSU5ERVgiLCJERUZFTkRFUl9NQUNISU5FX0lERU5USVRZX0lOREVYIiwicmFuZ2UiLCJsdCIsImhpdHNCb2R5IiwiYWdncmVnYXRpb25zIiwicmVjZW50X21hY2hpbmVzIiwiQm9vbGVhbiIsInRvdGFsTWFjaGluZXMiLCJieU9zQnVja2V0cyIsImJ1Y2tldHMiLCJieUV4cG9zdXJlQnVja2V0cyIsImJ5SGVhbHRoQnVja2V0cyIsImJ5Umlza0J1Y2tldHMiLCJyZWNlbnRMaXN0IiwiZGF0YVNvdXJjZSIsInRpZCIsIm5vcm1hbGl6ZWQiLCJvc01hcCIsImV4TWFwIiwiaGVhbHRoTWFwIiwicmlza01hcCIsIm9zIiwiZXgiLCJocyIsInJzIiwia2V5IiwiZG9jX2NvdW50IiwibGl2ZUluY2lkZW50c0NvdW50IiwibGl2ZUFsZXJ0c0NvdW50IiwiZ3JhcGhFcnJvciIsImNvdW50U2VjdXJpdHlDb2xsZWN0aW9uIiwidG90YWxfbWFjaGluZXMiLCJpbmNpZGVudHNfaW5kZXhfY291bnQiLCJhbGVydHNfaW5kZXhfY291bnQiLCJ2dWxuZXJhYmlsaXRpZXNfaW5kZXhfY291bnQiLCJsaW5rZWRfYWdlbnRzX2NvdW50Iiwic3RhbGVfbWFjaGluZXNfY291bnQiLCJncmFwaF9pbmNpZGVudHNfbGl2ZV9jb3VudCIsImdyYXBoX2FsZXJ0c19saXZlX2NvdW50IiwiZ3JhcGhfZXJyb3JfaGludCIsImRhdGFfc291cmNlIiwiX2VyciRzdGF0dXNDb2RlMiIsIl9lcnIkbWVzc2FnZTkiLCJfcSRzaXplMiIsIl9kYXRhJHZhbHVlIiwiX3EkZnJvbTIiLCJfcSRzaXplMyIsIl9yZWYyIiwiX3JvdyRpZCIsImN2ZUlkIiwiX2VyciRtZXNzYWdlMTAiLCJfaGl0czMiLCJfcmVzcG9uc2UkYm9keTIiLCJfaGl0cyRoaXRzMiIsInN5bmNfdHMiLCJfZXJyJG1lc3NhZ2UxMSIsIl9lcnIkc3RhdHVzQ29kZTMiLCJfdG9wNCIsImxpc3RJbmNpZGVudHMiXSwic291cmNlcyI6WyJzZWFyY2gudHMiXSwic291cmNlc0NvbnRlbnQiOlsiLypcbiAqIERlZmVuZGVyIHBsdWdpbiDigJQgT3BlblNlYXJjaCByZWFkcyArIEdyYXBoL01ERSBwcm94aWVzXG4gKi9cblxuaW1wb3J0IHsgSVJvdXRlciB9IGZyb20gJ29wZW5zZWFyY2gtZGFzaGJvYXJkcy9zZXJ2ZXInO1xuaW1wb3J0IHsgc2NoZW1hIH0gZnJvbSAnQG9zZC9jb25maWctc2NoZW1hJztcbmltcG9ydCB7XG4gIERFRkVOREVSX01BQ0hJTkVTX0lOREVYLFxuICBERUZFTkRFUl9NQUNISU5FX0lERU5USVRZX0lOREVYLFxuICBERUZFTkRFUl9WVUxORVJBQklMSVRJRVNfSU5ERVgsXG4gIERFRkVOREVSX0lOQ0lERU5UU19JTkRFWCxcbiAgREVGRU5ERVJfQUxFUlRTX0lOREVYLFxuICBERUZFTkRFUl9BVURJVF9MT0dfSU5ERVgsXG4gIFdBWlVIX0FMRVJUU19QQVRURVJOLFxufSBmcm9tICcuLi8uLi9jb21tb24vY29uc3RhbnRzJztcbmltcG9ydCB7XG4gIGdldE1kZUNvbmZpZyxcbiAgZ2V0TWFjaGluZSxcbiAgbGlzdEluZGljYXRvcnMsXG4gIGZldGNoQWxsTWFjaGluZXNMaW1pdGVkLFxuICBnZXRNYWNoaW5lUmVjb21tZW5kYXRpb25zLFxuICBnZXRNYWNoaW5lVnVsbmVyYWJpbGl0aWVzLFxuICBnZXRNYWNoaW5lQWxlcnRzLFxuICBnZXRNYWNoaW5lTG9nb25Vc2VycyxcbiAgZ2V0TWFjaGluZVNvZnR3YXJlLFxuICBsaXN0T3JnVnVsbmVyYWJpbGl0aWVzLFxuICBsaXN0TGVnYWN5QWxlcnRzLFxuICBsaXN0TWFjaGluZUFjdGlvbnMsXG4gIGdldE1hY2hpbmVBY3Rpb25QYWNrYWdlVXJpLFxuICBtZGVFcnJvclN0YXR1cyxcbn0gZnJvbSAnLi4vbGliL21kZS1jbGllbnQnO1xuaW1wb3J0IHtcbiAgZ2V0R3JhcGhTZWN1cml0eUNvbmZpZyxcbiAgbGlzdEluY2lkZW50cyxcbiAgbGlzdEFsZXJ0c1YyLFxuICBydW5IdW50aW5nUXVlcnksXG4gIGNvdW50U2VjdXJpdHlDb2xsZWN0aW9uLFxuICBHcmFwaEFwaUVycm9yLFxufSBmcm9tICcuLi9saWIvZ3JhcGgtc2VjdXJpdHktY2xpZW50JztcblxuZnVuY3Rpb24gbWFwR3JhcGhFcnIoZXJyOiB1bmtub3duKTogeyBzdGF0dXM6IG51bWJlcjsgYm9keTogc3RyaW5nIH0ge1xuICBpZiAoZXJyIGluc3RhbmNlb2YgR3JhcGhBcGlFcnJvcikge1xuICAgIHJldHVybiB7IHN0YXR1czogZXJyLnN0YXR1cyA+PSA0MDAgJiYgZXJyLnN0YXR1cyA8IDYwMCA/IGVyci5zdGF0dXMgOiA1MDIsIGJvZHk6IGVyci5tZXNzYWdlIH07XG4gIH1cbiAgcmV0dXJuIHsgc3RhdHVzOiA1MDIsIGJvZHk6IGVyciBpbnN0YW5jZW9mIEVycm9yID8gZXJyLm1lc3NhZ2UgOiBTdHJpbmcoZXJyKSB9O1xufVxuXG5mdW5jdGlvbiBub3JtYWxpemVNZGVNYWNoaW5lKG06IFJlY29yZDxzdHJpbmcsIHVua25vd24+LCB0ZW5hbnRJZDogc3RyaW5nKSB7XG4gIHJldHVybiB7XG4gICAgdGVuYW50X2lkOiB0ZW5hbnRJZCxcbiAgICBtYWNoaW5lX2lkOiBtLmlkLFxuICAgIGNvbXB1dGVyX2Ruc19uYW1lOiBtLmNvbXB1dGVyRG5zTmFtZSB8fCAnJyxcbiAgICBvc19wbGF0Zm9ybTogbS5vc1BsYXRmb3JtIHx8ICcnLFxuICAgIG9zX3ZlcnNpb246IG0ub3NWZXJzaW9uIHx8ICcnLFxuICAgIGxhc3Rfc2VlbjogbS5sYXN0U2VlbiB8fCBudWxsLFxuICAgIGZpcnN0X3NlZW46IG0uZmlyc3RTZWVuIHx8IG51bGwsXG4gICAgYWFkX2RldmljZV9pZDogbS5hYWREZXZpY2VJZCB8fCAnJyxcbiAgICByaXNrX3Njb3JlOiBtLnJpc2tTY29yZSAhPSBudWxsID8gU3RyaW5nKG0ucmlza1Njb3JlKSA6ICcnLFxuICAgIGV4cG9zdXJlX2xldmVsOiBtLmV4cG9zdXJlTGV2ZWwgfHwgJycsXG4gICAgb25ib2FyZGluZ19zdGF0dXM6IG0ub25ib2FyZGluZ1N0YXR1cyB8fCBtLm9uYm9hcmRpbmdzdGF0dXMgfHwgJycsXG4gICAgaGVhbHRoX3N0YXR1czogbS5oZWFsdGhTdGF0dXMgfHwgJycsXG4gICAgaXNvbGF0aW9uX3N0YXR1czogbS5pc29sYXRpb25TdGF0dXMgfHwgJycsXG4gICAgbGFzdF9pcF9hZGRyZXNzOiBtLmxhc3RJcEFkZHJlc3MgfHwgJycsXG4gICAgcmJhY19ncm91cF9uYW1lOiBtLnJiYWNHcm91cE5hbWUgfHwgJycsXG4gIH07XG59XG5cbmZ1bmN0aW9uIGdldENsaWVudChjb250ZXh0OiBhbnkpIHtcbiAgcmV0dXJuIGNvbnRleHQuY29yZS5vcGVuc2VhcmNoLmNsaWVudC5hc0N1cnJlbnRVc2VyO1xufVxuXG5leHBvcnQgZnVuY3Rpb24gcmVnaXN0ZXJEZWZlbmRlclNlYXJjaFJvdXRlcyhyb3V0ZXI6IElSb3V0ZXIpIHtcbiAgcm91dGVyLmdldCh7IHBhdGg6ICcvYXBpL2RlZmVuZGVyX3BsdWdpbi9oZWFsdGgnLCB2YWxpZGF0ZTogZmFsc2UgfSwgYXN5bmMgKF9jb250ZXh0LCBfcmVxLCByZXMpID0+IHtcbiAgICBjb25zdCBtZGUgPSAhIWdldE1kZUNvbmZpZygpO1xuICAgIGNvbnN0IGdyYXBoID0gISFnZXRHcmFwaFNlY3VyaXR5Q29uZmlnKCk7XG4gICAgcmV0dXJuIHJlcy5vayh7XG4gICAgICBib2R5OiB7XG4gICAgICAgIG9rOiBtZGUgfHwgZ3JhcGgsXG4gICAgICAgIG1kZV9jb25maWd1cmVkOiBtZGUsXG4gICAgICAgIGdyYXBoX3NlY3VyaXR5X2NvbmZpZ3VyZWQ6IGdyYXBoLFxuICAgICAgICB0aW1lc3RhbXA6IG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKSxcbiAgICAgIH0sXG4gICAgfSk7XG4gIH0pO1xuXG4gIHJvdXRlci5nZXQoXG4gICAge1xuICAgICAgcGF0aDogJy9hcGkvZGVmZW5kZXJfcGx1Z2luL21hY2hpbmVzJyxcbiAgICAgIHZhbGlkYXRlOiB7XG4gICAgICAgIHF1ZXJ5OiBzY2hlbWEub2JqZWN0KHtcbiAgICAgICAgICBzaXplOiBzY2hlbWEubWF5YmUoc2NoZW1hLm51bWJlcigpKSxcbiAgICAgICAgICBmcm9tOiBzY2hlbWEubWF5YmUoc2NoZW1hLm51bWJlcigpKSxcbiAgICAgICAgICBvc19wbGF0Zm9ybTogc2NoZW1hLm1heWJlKHNjaGVtYS5zdHJpbmcoKSksXG4gICAgICAgICAgZXhwb3N1cmVfbGV2ZWw6IHNjaGVtYS5tYXliZShzY2hlbWEuc3RyaW5nKCkpLFxuICAgICAgICAgIHNvdXJjZTogc2NoZW1hLm1heWJlKHNjaGVtYS5zdHJpbmcoKSksXG4gICAgICAgIH0pLFxuICAgICAgfSxcbiAgICB9LFxuICAgIGFzeW5jIChjb250ZXh0LCByZXEsIHJlcykgPT4ge1xuICAgICAgY29uc3QgcSA9IHJlcS5xdWVyeSBhcyB7XG4gICAgICAgIHNpemU/OiBudW1iZXI7XG4gICAgICAgIGZyb20/OiBudW1iZXI7XG4gICAgICAgIG9zX3BsYXRmb3JtPzogc3RyaW5nO1xuICAgICAgICBleHBvc3VyZV9sZXZlbD86IHN0cmluZztcbiAgICAgICAgc291cmNlPzogc3RyaW5nO1xuICAgICAgfTtcbiAgICAgIGlmIChxLnNvdXJjZSA9PT0gJ2xpdmUnKSB7XG4gICAgICAgIGNvbnN0IG1jZmcgPSBnZXRNZGVDb25maWcoKTtcbiAgICAgICAgaWYgKCFtY2ZnKSB7XG4gICAgICAgICAgcmV0dXJuIHJlcy5jdXN0b21FcnJvcih7IHN0YXR1c0NvZGU6IDUwMywgYm9keTogJ01ERSBub3QgY29uZmlndXJlZC4nIH0pO1xuICAgICAgICB9XG4gICAgICAgIHRyeSB7XG4gICAgICAgICAgY29uc3QgcmF3ID0gYXdhaXQgZmV0Y2hBbGxNYWNoaW5lc0xpbWl0ZWQobWNmZywgMTUpO1xuICAgICAgICAgIGNvbnN0IHRlbmFudElkID0gbWNmZy50ZW5hbnRJZDtcbiAgICAgICAgICBsZXQgcm93cyA9IHJhdy5tYXAoKG0pID0+IG5vcm1hbGl6ZU1kZU1hY2hpbmUobSBhcyBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPiwgdGVuYW50SWQpKTtcbiAgICAgICAgICBpZiAocS5vc19wbGF0Zm9ybSkge1xuICAgICAgICAgICAgcm93cyA9IHJvd3MuZmlsdGVyKChyKSA9PiBTdHJpbmcoci5vc19wbGF0Zm9ybSkgPT09IHEub3NfcGxhdGZvcm0pO1xuICAgICAgICAgIH1cbiAgICAgICAgICBpZiAocS5leHBvc3VyZV9sZXZlbCkge1xuICAgICAgICAgICAgcm93cyA9IHJvd3MuZmlsdGVyKChyKSA9PiBTdHJpbmcoci5leHBvc3VyZV9sZXZlbCkgPT09IHEuZXhwb3N1cmVfbGV2ZWwpO1xuICAgICAgICAgIH1cbiAgICAgICAgICByb3dzLnNvcnQoKGEsIGIpID0+IHtcbiAgICAgICAgICAgIGNvbnN0IHRhID0gYS5sYXN0X3NlZW4gPyBuZXcgRGF0ZShTdHJpbmcoYS5sYXN0X3NlZW4pKS5nZXRUaW1lKCkgOiAwO1xuICAgICAgICAgICAgY29uc3QgdGIgPSBiLmxhc3Rfc2VlbiA/IG5ldyBEYXRlKFN0cmluZyhiLmxhc3Rfc2VlbikpLmdldFRpbWUoKSA6IDA7XG4gICAgICAgICAgICByZXR1cm4gdGIgLSB0YTtcbiAgICAgICAgICB9KTtcbiAgICAgICAgICBjb25zdCBmcm9tID0gcS5mcm9tID8/IDA7XG4gICAgICAgICAgY29uc3Qgc2l6ZSA9IHEuc2l6ZSA/PyA1MDtcbiAgICAgICAgICBjb25zdCBzbGljZSA9IHJvd3Muc2xpY2UoZnJvbSwgZnJvbSArIHNpemUpO1xuICAgICAgICAgIGNvbnN0IGhpdHMgPSBzbGljZS5tYXAoKHNyYykgPT4gKHsgX3NvdXJjZTogc3JjLCBfaWQ6IHNyYy5tYWNoaW5lX2lkIH0pKTtcbiAgICAgICAgICByZXR1cm4gcmVzLm9rKHtcbiAgICAgICAgICAgIGJvZHk6IHtcbiAgICAgICAgICAgICAgaGl0cyxcbiAgICAgICAgICAgICAgdG90YWw6IHsgdmFsdWU6IHJvd3MubGVuZ3RoLCByZWxhdGlvbjogJ2VxJyB9LFxuICAgICAgICAgICAgICBzb3VyY2U6ICdtZGUnLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICB9KTtcbiAgICAgICAgfSBjYXRjaCAoZXJyOiBhbnkpIHtcbiAgICAgICAgICByZXR1cm4gcmVzLmN1c3RvbUVycm9yKHtcbiAgICAgICAgICAgIHN0YXR1c0NvZGU6IG1kZUVycm9yU3RhdHVzKGVyciksXG4gICAgICAgICAgICBib2R5OiBlcnI/Lm1lc3NhZ2UgPz8gU3RyaW5nKGVyciksXG4gICAgICAgICAgfSk7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICAgIHRyeSB7XG4gICAgICAgIGNvbnN0IGNsaWVudCA9IGdldENsaWVudChjb250ZXh0KTtcbiAgICAgICAgY29uc3QgeyBzaXplID0gNTAsIGZyb20gPSAwLCBvc19wbGF0Zm9ybSwgZXhwb3N1cmVfbGV2ZWwgfSA9IHE7XG4gICAgICAgIGNvbnN0IG11c3Q6IGFueVtdID0gW107XG4gICAgICAgIGlmIChvc19wbGF0Zm9ybSkgbXVzdC5wdXNoKHsgdGVybTogeyBvc19wbGF0Zm9ybSB9IH0pO1xuICAgICAgICBpZiAoZXhwb3N1cmVfbGV2ZWwpIG11c3QucHVzaCh7IHRlcm06IHsgZXhwb3N1cmVfbGV2ZWwgfSB9KTtcbiAgICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBjbGllbnQuc2VhcmNoKHtcbiAgICAgICAgICBpbmRleDogREVGRU5ERVJfTUFDSElORVNfSU5ERVgsXG4gICAgICAgICAgaWdub3JlX3VuYXZhaWxhYmxlOiB0cnVlLFxuICAgICAgICAgIGJvZHk6IHtcbiAgICAgICAgICAgIHNpemUsXG4gICAgICAgICAgICBmcm9tLFxuICAgICAgICAgICAgc29ydDogW3sgbGFzdF9zZWVuOiB7IG9yZGVyOiAnZGVzYycsIG1pc3Npbmc6ICdfbGFzdCcgfSB9LCB7IGNvbXB1dGVyX2Ruc19uYW1lOiAnYXNjJyB9XSxcbiAgICAgICAgICAgIHF1ZXJ5OiBtdXN0Lmxlbmd0aCA/IHsgYm9vbDogeyBtdXN0IH0gfSA6IHsgbWF0Y2hfYWxsOiB7fSB9LFxuICAgICAgICAgIH0sXG4gICAgICAgIH0pO1xuICAgICAgICBjb25zdCBoaXRzID0gKHJlc3BvbnNlLmJvZHkgYXMgYW55KT8uaGl0cyA/PyB7fTtcbiAgICAgICAgcmV0dXJuIHJlcy5vayh7IGJvZHk6IHsgaGl0czogaGl0cy5oaXRzID8/IFtdLCB0b3RhbDogaGl0cy50b3RhbCwgc291cmNlOiAnaW5kZXgnIH0gfSk7XG4gICAgICB9IGNhdGNoIChlcnI6IGFueSkge1xuICAgICAgICByZXR1cm4gcmVzLmN1c3RvbUVycm9yKHtcbiAgICAgICAgICBzdGF0dXNDb2RlOiBlcnIuc3RhdHVzQ29kZSA/PyA1MDAsXG4gICAgICAgICAgYm9keTogZXJyLm1lc3NhZ2UgPz8gU3RyaW5nKGVyciksXG4gICAgICAgIH0pO1xuICAgICAgfVxuICAgIH1cbiAgKTtcblxuICByb3V0ZXIuZ2V0KFxuICAgIHtcbiAgICAgIHBhdGg6ICcvYXBpL2RlZmVuZGVyX3BsdWdpbi9tYWNoaW5lcy97aWR9L2xpdmUnLFxuICAgICAgdmFsaWRhdGU6IHsgcGFyYW1zOiBzY2hlbWEub2JqZWN0KHsgaWQ6IHNjaGVtYS5zdHJpbmcoKSB9KSB9LFxuICAgIH0sXG4gICAgYXN5bmMgKF9jb250ZXh0LCBfcmVxLCByZXMpID0+IHtcbiAgICAgIGNvbnN0IGNvbmZpZyA9IGdldE1kZUNvbmZpZygpO1xuICAgICAgaWYgKCFjb25maWcpIHtcbiAgICAgICAgcmV0dXJuIHJlcy5jdXN0b21FcnJvcih7XG4gICAgICAgICAgc3RhdHVzQ29kZTogNTAzLFxuICAgICAgICAgIGJvZHk6ICdEZWZlbmRlciBNREUgbm90IGNvbmZpZ3VyZWQgKERFRkVOREVSX1RFTkFOVF9JRCwgREVGRU5ERVJfQ0xJRU5UX0lELCBERUZFTkRFUl9DTElFTlRfU0VDUkVUKS4nLFxuICAgICAgICB9KTtcbiAgICAgIH1cbiAgICAgIHRyeSB7XG4gICAgICAgIGNvbnN0IGlkID0gKF9yZXEucGFyYW1zIGFzIHsgaWQ6IHN0cmluZyB9KS5pZDtcbiAgICAgICAgY29uc3QgZGF0YSA9IGF3YWl0IGdldE1hY2hpbmUoY29uZmlnLCBpZCk7XG4gICAgICAgIHJldHVybiByZXMub2soeyBib2R5OiBkYXRhIH0pO1xuICAgICAgfSBjYXRjaCAoZXJyOiBhbnkpIHtcbiAgICAgICAgcmV0dXJuIHJlcy5jdXN0b21FcnJvcih7XG4gICAgICAgICAgc3RhdHVzQ29kZTogbWRlRXJyb3JTdGF0dXMoZXJyKSxcbiAgICAgICAgICBib2R5OiBlcnI/Lm1lc3NhZ2UgPz8gU3RyaW5nKGVyciksXG4gICAgICAgIH0pO1xuICAgICAgfVxuICAgIH1cbiAgKTtcblxuICBjb25zdCBtZGVNYWNoaW5lU3ViID0gKHBhdGhTdWZmaXg6IHN0cmluZywgZm46IChjOiBhbnksIGlkOiBzdHJpbmcpID0+IFByb21pc2U8dW5rbm93bj4pID0+IHtcbiAgICByb3V0ZXIuZ2V0KFxuICAgICAge1xuICAgICAgICBwYXRoOiBgL2FwaS9kZWZlbmRlcl9wbHVnaW4vbWFjaGluZXMve2lkfS9saXZlLyR7cGF0aFN1ZmZpeH1gLFxuICAgICAgICB2YWxpZGF0ZTogeyBwYXJhbXM6IHNjaGVtYS5vYmplY3QoeyBpZDogc2NoZW1hLnN0cmluZygpIH0pIH0sXG4gICAgICB9LFxuICAgICAgYXN5bmMgKF9jb250ZXh0LCByZXEsIHJlcykgPT4ge1xuICAgICAgICBjb25zdCBtY2ZnID0gZ2V0TWRlQ29uZmlnKCk7XG4gICAgICAgIGlmICghbWNmZykge1xuICAgICAgICAgIHJldHVybiByZXMuY3VzdG9tRXJyb3IoeyBzdGF0dXNDb2RlOiA1MDMsIGJvZHk6ICdNREUgbm90IGNvbmZpZ3VyZWQuJyB9KTtcbiAgICAgICAgfVxuICAgICAgICB0cnkge1xuICAgICAgICAgIGNvbnN0IGlkID0gKHJlcS5wYXJhbXMgYXMgeyBpZDogc3RyaW5nIH0pLmlkO1xuICAgICAgICAgIGNvbnN0IGRhdGEgPSBhd2FpdCBmbihtY2ZnLCBpZCk7XG4gICAgICAgICAgcmV0dXJuIHJlcy5vayh7IGJvZHk6IGRhdGEgfSk7XG4gICAgICAgIH0gY2F0Y2ggKGVycjogYW55KSB7XG4gICAgICAgICAgcmV0dXJuIHJlcy5jdXN0b21FcnJvcih7IHN0YXR1c0NvZGU6IG1kZUVycm9yU3RhdHVzKGVyciksIGJvZHk6IGVycj8ubWVzc2FnZSA/PyBTdHJpbmcoZXJyKSB9KTtcbiAgICAgICAgfVxuICAgICAgfVxuICAgICk7XG4gIH07XG5cbiAgbWRlTWFjaGluZVN1YigncmVjb21tZW5kYXRpb25zJywgZ2V0TWFjaGluZVJlY29tbWVuZGF0aW9ucyk7XG4gIG1kZU1hY2hpbmVTdWIoJ3Z1bG5lcmFiaWxpdGllcycsIGdldE1hY2hpbmVWdWxuZXJhYmlsaXRpZXMpO1xuICBtZGVNYWNoaW5lU3ViKCdhbGVydHMnLCBnZXRNYWNoaW5lQWxlcnRzKTtcbiAgbWRlTWFjaGluZVN1YignbG9nb251c2VycycsIGdldE1hY2hpbmVMb2dvblVzZXJzKTtcbiAgbWRlTWFjaGluZVN1Yignc29mdHdhcmUnLCBnZXRNYWNoaW5lU29mdHdhcmUpO1xuXG4gIHJvdXRlci5nZXQoXG4gICAge1xuICAgICAgcGF0aDogJy9hcGkvZGVmZW5kZXJfcGx1Z2luL21kZS92dWxuZXJhYmlsaXRpZXMnLFxuICAgICAgdmFsaWRhdGU6IHsgcXVlcnk6IHNjaGVtYS5vYmplY3QoeyB0b3A6IHNjaGVtYS5tYXliZShzY2hlbWEubnVtYmVyKCkpIH0pIH0sXG4gICAgfSxcbiAgICBhc3luYyAoX2NvbnRleHQsIHJlcSwgcmVzKSA9PiB7XG4gICAgICBjb25zdCBtY2ZnID0gZ2V0TWRlQ29uZmlnKCk7XG4gICAgICBpZiAoIW1jZmcpIHJldHVybiByZXMuY3VzdG9tRXJyb3IoeyBzdGF0dXNDb2RlOiA1MDMsIGJvZHk6ICdNREUgbm90IGNvbmZpZ3VyZWQuJyB9KTtcbiAgICAgIHRyeSB7XG4gICAgICAgIGNvbnN0IHRvcCA9IChyZXEucXVlcnkgYXMgeyB0b3A/OiBudW1iZXIgfSkudG9wID8/IDIwMDtcbiAgICAgICAgY29uc3QgZGF0YSA9IGF3YWl0IGxpc3RPcmdWdWxuZXJhYmlsaXRpZXMobWNmZywgdG9wKTtcbiAgICAgICAgcmV0dXJuIHJlcy5vayh7IGJvZHk6IGRhdGEgfSk7XG4gICAgICB9IGNhdGNoIChlcnI6IGFueSkge1xuICAgICAgICByZXR1cm4gcmVzLmN1c3RvbUVycm9yKHsgc3RhdHVzQ29kZTogbWRlRXJyb3JTdGF0dXMoZXJyKSwgYm9keTogZXJyPy5tZXNzYWdlID8/IFN0cmluZyhlcnIpIH0pO1xuICAgICAgfVxuICAgIH1cbiAgKTtcblxuICByb3V0ZXIuZ2V0KFxuICAgIHtcbiAgICAgIHBhdGg6ICcvYXBpL2RlZmVuZGVyX3BsdWdpbi9tZGUvYWxlcnRzLWxlZ2FjeScsXG4gICAgICB2YWxpZGF0ZTogeyBxdWVyeTogc2NoZW1hLm9iamVjdCh7IHRvcDogc2NoZW1hLm1heWJlKHNjaGVtYS5udW1iZXIoKSkgfSkgfSxcbiAgICB9LFxuICAgIGFzeW5jIChfY29udGV4dCwgcmVxLCByZXMpID0+IHtcbiAgICAgIGNvbnN0IG1jZmcgPSBnZXRNZGVDb25maWcoKTtcbiAgICAgIGlmICghbWNmZykgcmV0dXJuIHJlcy5jdXN0b21FcnJvcih7IHN0YXR1c0NvZGU6IDUwMywgYm9keTogJ01ERSBub3QgY29uZmlndXJlZC4nIH0pO1xuICAgICAgdHJ5IHtcbiAgICAgICAgY29uc3QgdG9wID0gKHJlcS5xdWVyeSBhcyB7IHRvcD86IG51bWJlciB9KS50b3AgPz8gMTAwO1xuICAgICAgICBjb25zdCBkYXRhID0gYXdhaXQgbGlzdExlZ2FjeUFsZXJ0cyhtY2ZnLCB0b3ApO1xuICAgICAgICByZXR1cm4gcmVzLm9rKHsgYm9keTogZGF0YSB9KTtcbiAgICAgIH0gY2F0Y2ggKGVycjogYW55KSB7XG4gICAgICAgIHJldHVybiByZXMuY3VzdG9tRXJyb3IoeyBzdGF0dXNDb2RlOiBtZGVFcnJvclN0YXR1cyhlcnIpLCBib2R5OiBlcnI/Lm1lc3NhZ2UgPz8gU3RyaW5nKGVycikgfSk7XG4gICAgICB9XG4gICAgfVxuICApO1xuXG4gIHJvdXRlci5nZXQoXG4gICAge1xuICAgICAgcGF0aDogJy9hcGkvZGVmZW5kZXJfcGx1Z2luL21kZS9tYWNoaW5lYWN0aW9ucycsXG4gICAgICB2YWxpZGF0ZTogeyBxdWVyeTogc2NoZW1hLm9iamVjdCh7IHRvcDogc2NoZW1hLm1heWJlKHNjaGVtYS5udW1iZXIoKSkgfSkgfSxcbiAgICB9LFxuICAgIGFzeW5jIChfY29udGV4dCwgcmVxLCByZXMpID0+IHtcbiAgICAgIGNvbnN0IG1jZmcgPSBnZXRNZGVDb25maWcoKTtcbiAgICAgIGlmICghbWNmZykgcmV0dXJuIHJlcy5jdXN0b21FcnJvcih7IHN0YXR1c0NvZGU6IDUwMywgYm9keTogJ01ERSBub3QgY29uZmlndXJlZC4nIH0pO1xuICAgICAgdHJ5IHtcbiAgICAgICAgY29uc3QgdG9wID0gKHJlcS5xdWVyeSBhcyB7IHRvcD86IG51bWJlciB9KS50b3AgPz8gMTAwO1xuICAgICAgICBjb25zdCBkYXRhID0gYXdhaXQgbGlzdE1hY2hpbmVBY3Rpb25zKG1jZmcsIHRvcCk7XG4gICAgICAgIHJldHVybiByZXMub2soeyBib2R5OiBkYXRhIH0pO1xuICAgICAgfSBjYXRjaCAoZXJyOiBhbnkpIHtcbiAgICAgICAgcmV0dXJuIHJlcy5jdXN0b21FcnJvcih7IHN0YXR1c0NvZGU6IG1kZUVycm9yU3RhdHVzKGVyciksIGJvZHk6IGVycj8ubWVzc2FnZSA/PyBTdHJpbmcoZXJyKSB9KTtcbiAgICAgIH1cbiAgICB9XG4gICk7XG5cbiAgcm91dGVyLmdldChcbiAgICB7XG4gICAgICBwYXRoOiAnL2FwaS9kZWZlbmRlcl9wbHVnaW4vbWRlL21hY2hpbmVhY3Rpb25zL3thY3Rpb25JZH0vcGFja2FnZS11cmknLFxuICAgICAgdmFsaWRhdGU6IHsgcGFyYW1zOiBzY2hlbWEub2JqZWN0KHsgYWN0aW9uSWQ6IHNjaGVtYS5zdHJpbmcoKSB9KSB9LFxuICAgIH0sXG4gICAgYXN5bmMgKF9jb250ZXh0LCByZXEsIHJlcykgPT4ge1xuICAgICAgY29uc3QgbWNmZyA9IGdldE1kZUNvbmZpZygpO1xuICAgICAgaWYgKCFtY2ZnKSByZXR1cm4gcmVzLmN1c3RvbUVycm9yKHsgc3RhdHVzQ29kZTogNTAzLCBib2R5OiAnTURFIG5vdCBjb25maWd1cmVkLicgfSk7XG4gICAgICB0cnkge1xuICAgICAgICBjb25zdCBhY3Rpb25JZCA9IChyZXEucGFyYW1zIGFzIHsgYWN0aW9uSWQ6IHN0cmluZyB9KS5hY3Rpb25JZDtcbiAgICAgICAgY29uc3QgZGF0YSA9IGF3YWl0IGdldE1hY2hpbmVBY3Rpb25QYWNrYWdlVXJpKG1jZmcsIGFjdGlvbklkKTtcbiAgICAgICAgcmV0dXJuIHJlcy5vayh7IGJvZHk6IGRhdGEgfSk7XG4gICAgICB9IGNhdGNoIChlcnI6IGFueSkge1xuICAgICAgICByZXR1cm4gcmVzLmN1c3RvbUVycm9yKHsgc3RhdHVzQ29kZTogbWRlRXJyb3JTdGF0dXMoZXJyKSwgYm9keTogZXJyPy5tZXNzYWdlID8/IFN0cmluZyhlcnIpIH0pO1xuICAgICAgfVxuICAgIH1cbiAgKTtcblxuICByb3V0ZXIuZ2V0KHsgcGF0aDogJy9hcGkvZGVmZW5kZXJfcGx1Z2luL292ZXJ2aWV3JywgdmFsaWRhdGU6IGZhbHNlIH0sIGFzeW5jIChjb250ZXh0LCBfcmVxLCByZXMpID0+IHtcbiAgICB0cnkge1xuICAgICAgY29uc3QgY2xpZW50ID0gZ2V0Q2xpZW50KGNvbnRleHQpO1xuICAgICAgY29uc3Qgc3RhbGVEYXRlID0gbmV3IERhdGUoRGF0ZS5ub3coKSAtIDcgKiAyNCAqIDYwICogNjAgKiAxMDAwKS50b0lTT1N0cmluZygpO1xuXG4gICAgICBjb25zdCBtYWNoaW5lc1JlcyA9IGF3YWl0IGNsaWVudC5zZWFyY2goe1xuICAgICAgICBpbmRleDogREVGRU5ERVJfTUFDSElORVNfSU5ERVgsXG4gICAgICAgIGlnbm9yZV91bmF2YWlsYWJsZTogdHJ1ZSxcbiAgICAgICAgYm9keToge1xuICAgICAgICAgIHNpemU6IDgsXG4gICAgICAgICAgdHJhY2tfdG90YWxfaGl0czogdHJ1ZSxcbiAgICAgICAgICBzb3J0OiBbeyBsYXN0X3NlZW46IHsgb3JkZXI6ICdkZXNjJywgbWlzc2luZzogJ19sYXN0JyB9IH1dLFxuICAgICAgICAgIHF1ZXJ5OiB7IG1hdGNoX2FsbDoge30gfSxcbiAgICAgICAgICBhZ2dzOiB7XG4gICAgICAgICAgICBieV9vczogeyB0ZXJtczogeyBmaWVsZDogJ29zX3BsYXRmb3JtJywgc2l6ZTogMTUgfSB9LFxuICAgICAgICAgICAgYnlfZXhwb3N1cmU6IHsgdGVybXM6IHsgZmllbGQ6ICdleHBvc3VyZV9sZXZlbCcsIHNpemU6IDEwIH0gfSxcbiAgICAgICAgICAgIGJ5X2hlYWx0aDogeyB0ZXJtczogeyBmaWVsZDogJ2hlYWx0aF9zdGF0dXMnLCBzaXplOiAxMCB9IH0sXG4gICAgICAgICAgICBieV9yaXNrOiB7IHRlcm1zOiB7IGZpZWxkOiAncmlza19zY29yZScsIHNpemU6IDE1IH0gfSxcbiAgICAgICAgICB9LFxuICAgICAgICB9LFxuICAgICAgfSk7XG5cbiAgICAgIGxldCBpbmNpZGVudHNDb3VudCA9IDA7XG4gICAgICBsZXQgYWxlcnRzQ291bnQgPSAwO1xuICAgICAgbGV0IHZ1bG5Db3VudCA9IDA7XG4gICAgICBsZXQgbGlua2VkQWdlbnRzID0gMDtcbiAgICAgIGxldCBzdGFsZUNvdW50ID0gMDtcbiAgICAgIHRyeSB7XG4gICAgICAgIGNvbnN0IFtpYywgYWMsIHZjLCBpZFJlcywgc3RhbGVSZXNdID0gYXdhaXQgUHJvbWlzZS5hbGwoW1xuICAgICAgICAgIGNsaWVudC5jb3VudCh7IGluZGV4OiBERUZFTkRFUl9JTkNJREVOVFNfSU5ERVgsIGlnbm9yZV91bmF2YWlsYWJsZTogdHJ1ZSB9KSxcbiAgICAgICAgICBjbGllbnQuY291bnQoeyBpbmRleDogREVGRU5ERVJfQUxFUlRTX0lOREVYLCBpZ25vcmVfdW5hdmFpbGFibGU6IHRydWUgfSksXG4gICAgICAgICAgY2xpZW50LmNvdW50KHsgaW5kZXg6IERFRkVOREVSX1ZVTE5FUkFCSUxJVElFU19JTkRFWCwgaWdub3JlX3VuYXZhaWxhYmxlOiB0cnVlIH0pLFxuICAgICAgICAgIGNsaWVudC5jb3VudCh7IGluZGV4OiBERUZFTkRFUl9NQUNISU5FX0lERU5USVRZX0lOREVYLCBpZ25vcmVfdW5hdmFpbGFibGU6IHRydWUgfSksXG4gICAgICAgICAgY2xpZW50LnNlYXJjaCh7XG4gICAgICAgICAgICBpbmRleDogREVGRU5ERVJfTUFDSElORVNfSU5ERVgsXG4gICAgICAgICAgICBpZ25vcmVfdW5hdmFpbGFibGU6IHRydWUsXG4gICAgICAgICAgICBib2R5OiB7XG4gICAgICAgICAgICAgIHNpemU6IDAsXG4gICAgICAgICAgICAgIHF1ZXJ5OiB7XG4gICAgICAgICAgICAgICAgYm9vbDoge1xuICAgICAgICAgICAgICAgICAgZmlsdGVyOiBbeyByYW5nZTogeyBsYXN0X3NlZW46IHsgbHQ6IHN0YWxlRGF0ZSB9IH0gfV0sXG4gICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgdHJhY2tfdG90YWxfaGl0czogdHJ1ZSxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgfSksXG4gICAgICAgIF0pO1xuICAgICAgICBpbmNpZGVudHNDb3VudCA9IChpYy5ib2R5IGFzIGFueSk/LmNvdW50ID8/IDA7XG4gICAgICAgIGFsZXJ0c0NvdW50ID0gKGFjLmJvZHkgYXMgYW55KT8uY291bnQgPz8gMDtcbiAgICAgICAgdnVsbkNvdW50ID0gKHZjLmJvZHkgYXMgYW55KT8uY291bnQgPz8gMDtcbiAgICAgICAgbGlua2VkQWdlbnRzID0gKGlkUmVzLmJvZHkgYXMgYW55KT8uY291bnQgPz8gMDtcbiAgICAgICAgc3RhbGVDb3VudCA9XG4gICAgICAgICAgKHN0YWxlUmVzLmJvZHkgYXMgYW55KT8uaGl0cz8udG90YWw/LnZhbHVlID8/XG4gICAgICAgICAgKHN0YWxlUmVzLmJvZHkgYXMgYW55KT8uaGl0cz8udG90YWwgPz9cbiAgICAgICAgICAwO1xuICAgICAgfSBjYXRjaCB7XG4gICAgICAgIC8qIG9wdGlvbmFsIGluZGljZXMgKi9cbiAgICAgIH1cblxuICAgICAgY29uc3QgaGl0c0JvZHkgPSAobWFjaGluZXNSZXMuYm9keSBhcyBhbnkpPy5oaXRzID8/IHt9O1xuICAgICAgY29uc3QgYWdncyA9IChtYWNoaW5lc1Jlcy5ib2R5IGFzIGFueSk/LmFnZ3JlZ2F0aW9ucyA/PyB7fTtcbiAgICAgIGNvbnN0IHJlY2VudF9tYWNoaW5lcyA9IChoaXRzQm9keS5oaXRzID8/IFtdKS5tYXAoKGg6IGFueSkgPT4gaC5fc291cmNlKS5maWx0ZXIoQm9vbGVhbik7XG4gICAgICBjb25zdCB0b3RhbE1hY2hpbmVzID1cbiAgICAgICAgdHlwZW9mIGhpdHNCb2R5LnRvdGFsID09PSAnb2JqZWN0J1xuICAgICAgICAgID8gaGl0c0JvZHkudG90YWw/LnZhbHVlID8/IDBcbiAgICAgICAgICA6IGhpdHNCb2R5LnRvdGFsID8/IHJlY2VudF9tYWNoaW5lcy5sZW5ndGg7XG5cbiAgICAgIGxldCBieU9zQnVja2V0cyA9IGFnZ3MuYnlfb3M/LmJ1Y2tldHMgPz8gW107XG4gICAgICBsZXQgYnlFeHBvc3VyZUJ1Y2tldHMgPSBhZ2dzLmJ5X2V4cG9zdXJlPy5idWNrZXRzID8/IFtdO1xuICAgICAgbGV0IGJ5SGVhbHRoQnVja2V0cyA9IGFnZ3MuYnlfaGVhbHRoPy5idWNrZXRzID8/IFtdO1xuICAgICAgbGV0IGJ5Umlza0J1Y2tldHMgPSBhZ2dzLmJ5X3Jpc2s/LmJ1Y2tldHMgPz8gW107XG4gICAgICBsZXQgcmVjZW50TGlzdCA9IHJlY2VudF9tYWNoaW5lcztcbiAgICAgIGxldCB0b3RhbCA9IHRvdGFsTWFjaGluZXM7XG4gICAgICBsZXQgZGF0YVNvdXJjZTogJ2luZGV4JyB8ICdtZGUnID0gJ2luZGV4JztcblxuICAgICAgY29uc3QgbWNmZyA9IGdldE1kZUNvbmZpZygpO1xuICAgICAgaWYgKHRvdGFsID09PSAwICYmIG1jZmcpIHtcbiAgICAgICAgdHJ5IHtcbiAgICAgICAgICBjb25zdCByYXcgPSBhd2FpdCBmZXRjaEFsbE1hY2hpbmVzTGltaXRlZChtY2ZnLCAxMCk7XG4gICAgICAgICAgY29uc3QgdGlkID0gbWNmZy50ZW5hbnRJZDtcbiAgICAgICAgICBjb25zdCBub3JtYWxpemVkID0gcmF3Lm1hcCgobSkgPT5cbiAgICAgICAgICAgIG5vcm1hbGl6ZU1kZU1hY2hpbmUobSBhcyBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPiwgdGlkKVxuICAgICAgICAgICk7XG4gICAgICAgICAgaWYgKG5vcm1hbGl6ZWQubGVuZ3RoID4gMCkge1xuICAgICAgICAgICAgZGF0YVNvdXJjZSA9ICdtZGUnO1xuICAgICAgICAgICAgdG90YWwgPSBub3JtYWxpemVkLmxlbmd0aDtcbiAgICAgICAgICAgIHJlY2VudExpc3QgPSBub3JtYWxpemVkXG4gICAgICAgICAgICAgIC5zbGljZSgpXG4gICAgICAgICAgICAgIC5zb3J0KChhLCBiKSA9PiB7XG4gICAgICAgICAgICAgICAgY29uc3QgdGEgPSBhLmxhc3Rfc2VlbiA/IG5ldyBEYXRlKFN0cmluZyhhLmxhc3Rfc2VlbikpLmdldFRpbWUoKSA6IDA7XG4gICAgICAgICAgICAgICAgY29uc3QgdGIgPSBiLmxhc3Rfc2VlbiA/IG5ldyBEYXRlKFN0cmluZyhiLmxhc3Rfc2VlbikpLmdldFRpbWUoKSA6IDA7XG4gICAgICAgICAgICAgICAgcmV0dXJuIHRiIC0gdGE7XG4gICAgICAgICAgICAgIH0pXG4gICAgICAgICAgICAgIC5zbGljZSgwLCAxMCk7XG4gICAgICAgICAgICBjb25zdCBvc01hcDogUmVjb3JkPHN0cmluZywgbnVtYmVyPiA9IHt9O1xuICAgICAgICAgICAgY29uc3QgZXhNYXA6IFJlY29yZDxzdHJpbmcsIG51bWJlcj4gPSB7fTtcbiAgICAgICAgICAgIGNvbnN0IGhlYWx0aE1hcDogUmVjb3JkPHN0cmluZywgbnVtYmVyPiA9IHt9O1xuICAgICAgICAgICAgY29uc3Qgcmlza01hcDogUmVjb3JkPHN0cmluZywgbnVtYmVyPiA9IHt9O1xuICAgICAgICAgICAgbm9ybWFsaXplZC5mb3JFYWNoKChyKSA9PiB7XG4gICAgICAgICAgICAgIGNvbnN0IG9zID0gU3RyaW5nKHIub3NfcGxhdGZvcm0gfHwgJ1Vua25vd24nKTtcbiAgICAgICAgICAgICAgb3NNYXBbb3NdID0gKG9zTWFwW29zXSB8fCAwKSArIDE7XG4gICAgICAgICAgICAgIGNvbnN0IGV4ID0gU3RyaW5nKHIuZXhwb3N1cmVfbGV2ZWwgfHwgJ3Vua25vd24nKTtcbiAgICAgICAgICAgICAgZXhNYXBbZXhdID0gKGV4TWFwW2V4XSB8fCAwKSArIDE7XG4gICAgICAgICAgICAgIGNvbnN0IGhzID0gU3RyaW5nKHIuaGVhbHRoX3N0YXR1cyB8fCAndW5rbm93bicpO1xuICAgICAgICAgICAgICBoZWFsdGhNYXBbaHNdID0gKGhlYWx0aE1hcFtoc10gfHwgMCkgKyAxO1xuICAgICAgICAgICAgICBjb25zdCBycyA9IFN0cmluZyhyLnJpc2tfc2NvcmUgfHwgJ3Vua25vd24nKTtcbiAgICAgICAgICAgICAgcmlza01hcFtyc10gPSAocmlza01hcFtyc10gfHwgMCkgKyAxO1xuICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICBieU9zQnVja2V0cyA9IE9iamVjdC5lbnRyaWVzKG9zTWFwKS5tYXAoKFtrZXksIGRvY19jb3VudF0pID0+ICh7IGtleSwgZG9jX2NvdW50IH0pKTtcbiAgICAgICAgICAgIGJ5RXhwb3N1cmVCdWNrZXRzID0gT2JqZWN0LmVudHJpZXMoZXhNYXApLm1hcCgoW2tleSwgZG9jX2NvdW50XSkgPT4gKHsga2V5LCBkb2NfY291bnQgfSkpO1xuICAgICAgICAgICAgYnlIZWFsdGhCdWNrZXRzID0gT2JqZWN0LmVudHJpZXMoaGVhbHRoTWFwKS5tYXAoKFtrZXksIGRvY19jb3VudF0pID0+ICh7XG4gICAgICAgICAgICAgIGtleSxcbiAgICAgICAgICAgICAgZG9jX2NvdW50LFxuICAgICAgICAgICAgfSkpO1xuICAgICAgICAgICAgYnlSaXNrQnVja2V0cyA9IE9iamVjdC5lbnRyaWVzKHJpc2tNYXApLm1hcCgoW2tleSwgZG9jX2NvdW50XSkgPT4gKHtcbiAgICAgICAgICAgICAga2V5LFxuICAgICAgICAgICAgICBkb2NfY291bnQsXG4gICAgICAgICAgICB9KSk7XG4gICAgICAgICAgICBzdGFsZUNvdW50ID0gbm9ybWFsaXplZC5maWx0ZXIoXG4gICAgICAgICAgICAgIChyKSA9PiAhci5sYXN0X3NlZW4gfHwgbmV3IERhdGUoU3RyaW5nKHIubGFzdF9zZWVuKSkgPCBuZXcgRGF0ZShzdGFsZURhdGUpXG4gICAgICAgICAgICApLmxlbmd0aDtcbiAgICAgICAgICB9XG4gICAgICAgIH0gY2F0Y2gge1xuICAgICAgICAgIC8qIGtlZXAgaW5kZXggZW1wdHkgc3RhdGUgKi9cbiAgICAgICAgfVxuICAgICAgfVxuXG4gICAgICBsZXQgbGl2ZUluY2lkZW50c0NvdW50OiBudW1iZXIgfCBudWxsID0gbnVsbDtcbiAgICAgIGxldCBsaXZlQWxlcnRzQ291bnQ6IG51bWJlciB8IG51bGwgPSBudWxsO1xuICAgICAgbGV0IGdyYXBoRXJyb3I6IHN0cmluZyB8IG51bGwgPSBudWxsO1xuICAgICAgY29uc3QgZ2NmZyA9IGdldEdyYXBoU2VjdXJpdHlDb25maWcoKTtcbiAgICAgIGlmIChnY2ZnKSB7XG4gICAgICAgIHRyeSB7XG4gICAgICAgICAgbGl2ZUluY2lkZW50c0NvdW50ID0gYXdhaXQgY291bnRTZWN1cml0eUNvbGxlY3Rpb24oZ2NmZywgJ2luY2lkZW50cycpO1xuICAgICAgICB9IGNhdGNoIChlKSB7XG4gICAgICAgICAgZ3JhcGhFcnJvciA9IG1hcEdyYXBoRXJyKGUpLmJvZHk7XG4gICAgICAgICAgbGl2ZUluY2lkZW50c0NvdW50ID0gbnVsbDtcbiAgICAgICAgfVxuICAgICAgICB0cnkge1xuICAgICAgICAgIGxpdmVBbGVydHNDb3VudCA9IGF3YWl0IGNvdW50U2VjdXJpdHlDb2xsZWN0aW9uKGdjZmcsICdhbGVydHNfdjInKTtcbiAgICAgICAgfSBjYXRjaCAoZSkge1xuICAgICAgICAgIGlmICghZ3JhcGhFcnJvcikgZ3JhcGhFcnJvciA9IG1hcEdyYXBoRXJyKGUpLmJvZHk7XG4gICAgICAgICAgbGl2ZUFsZXJ0c0NvdW50ID0gbnVsbDtcbiAgICAgICAgfVxuICAgICAgfVxuXG4gICAgICByZXR1cm4gcmVzLm9rKHtcbiAgICAgICAgYm9keToge1xuICAgICAgICAgIHRvdGFsX21hY2hpbmVzOiB0b3RhbCxcbiAgICAgICAgICBieV9vczogYnlPc0J1Y2tldHMsXG4gICAgICAgICAgYnlfZXhwb3N1cmU6IGJ5RXhwb3N1cmVCdWNrZXRzLFxuICAgICAgICAgIGJ5X2hlYWx0aDogYnlIZWFsdGhCdWNrZXRzLFxuICAgICAgICAgIGJ5X3Jpc2s6IGJ5Umlza0J1Y2tldHMsXG4gICAgICAgICAgcmVjZW50X21hY2hpbmVzOiByZWNlbnRMaXN0LFxuICAgICAgICAgIGluY2lkZW50c19pbmRleF9jb3VudDogaW5jaWRlbnRzQ291bnQsXG4gICAgICAgICAgYWxlcnRzX2luZGV4X2NvdW50OiBhbGVydHNDb3VudCxcbiAgICAgICAgICB2dWxuZXJhYmlsaXRpZXNfaW5kZXhfY291bnQ6IHZ1bG5Db3VudCxcbiAgICAgICAgICBsaW5rZWRfYWdlbnRzX2NvdW50OiBsaW5rZWRBZ2VudHMsXG4gICAgICAgICAgc3RhbGVfbWFjaGluZXNfY291bnQ6IHN0YWxlQ291bnQsXG4gICAgICAgICAgZ3JhcGhfaW5jaWRlbnRzX2xpdmVfY291bnQ6IGxpdmVJbmNpZGVudHNDb3VudCxcbiAgICAgICAgICBncmFwaF9hbGVydHNfbGl2ZV9jb3VudDogbGl2ZUFsZXJ0c0NvdW50LFxuICAgICAgICAgIGdyYXBoX2Vycm9yX2hpbnQ6IGdyYXBoRXJyb3IsXG4gICAgICAgICAgZGF0YV9zb3VyY2U6IGRhdGFTb3VyY2UsXG4gICAgICAgIH0sXG4gICAgICB9KTtcbiAgICB9IGNhdGNoIChlcnI6IGFueSkge1xuICAgICAgcmV0dXJuIHJlcy5jdXN0b21FcnJvcih7XG4gICAgICAgIHN0YXR1c0NvZGU6IGVyci5zdGF0dXNDb2RlID8/IDUwMCxcbiAgICAgICAgYm9keTogZXJyLm1lc3NhZ2UgPz8gU3RyaW5nKGVyciksXG4gICAgICB9KTtcbiAgICB9XG4gIH0pO1xuXG4gIHJvdXRlci5nZXQoXG4gICAge1xuICAgICAgcGF0aDogJy9hcGkvZGVmZW5kZXJfcGx1Z2luL3Z1bG5lcmFiaWxpdGllcycsXG4gICAgICB2YWxpZGF0ZToge1xuICAgICAgICBxdWVyeTogc2NoZW1hLm9iamVjdCh7XG4gICAgICAgICAgc2l6ZTogc2NoZW1hLm1heWJlKHNjaGVtYS5udW1iZXIoKSksXG4gICAgICAgICAgZnJvbTogc2NoZW1hLm1heWJlKHNjaGVtYS5udW1iZXIoKSksXG4gICAgICAgICAgc291cmNlOiBzY2hlbWEubWF5YmUoc2NoZW1hLnN0cmluZygpKSxcbiAgICAgICAgfSksXG4gICAgICB9LFxuICAgIH0sXG4gICAgYXN5bmMgKGNvbnRleHQsIHJlcSwgcmVzKSA9PiB7XG4gICAgICBjb25zdCBxID0gcmVxLnF1ZXJ5IGFzIHsgc2l6ZT86IG51bWJlcjsgZnJvbT86IG51bWJlcjsgc291cmNlPzogc3RyaW5nIH07XG4gICAgICBpZiAocS5zb3VyY2UgPT09ICdtZGUnKSB7XG4gICAgICAgIGNvbnN0IG1jZmcgPSBnZXRNZGVDb25maWcoKTtcbiAgICAgICAgaWYgKCFtY2ZnKSByZXR1cm4gcmVzLmN1c3RvbUVycm9yKHsgc3RhdHVzQ29kZTogNTAzLCBib2R5OiAnTURFIG5vdCBjb25maWd1cmVkLicgfSk7XG4gICAgICAgIHRyeSB7XG4gICAgICAgICAgY29uc3QgZGF0YSA9IChhd2FpdCBsaXN0T3JnVnVsbmVyYWJpbGl0aWVzKG1jZmcsIHEuc2l6ZSA/PyAyMDApKSBhcyB7XG4gICAgICAgICAgICB2YWx1ZT86IHVua25vd25bXTtcbiAgICAgICAgICB9O1xuICAgICAgICAgIGNvbnN0IHJvd3MgPSBkYXRhPy52YWx1ZSA/PyBbXTtcbiAgICAgICAgICBjb25zdCBmcm9tID0gcS5mcm9tID8/IDA7XG4gICAgICAgICAgY29uc3Qgc2l6ZSA9IHEuc2l6ZSA/PyA1MDtcbiAgICAgICAgICBjb25zdCBzbGljZSA9IHJvd3Muc2xpY2UoZnJvbSwgZnJvbSArIHNpemUpO1xuICAgICAgICAgIGNvbnN0IGhpdHMgPSBzbGljZS5tYXAoKHJvdzogYW55LCBpOiBudW1iZXIpID0+ICh7XG4gICAgICAgICAgICBfaWQ6IFN0cmluZyhyb3cuaWQgPz8gcm93LmN2ZUlkID8/IGkpLFxuICAgICAgICAgICAgX3NvdXJjZTogdHlwZW9mIHJvdyA9PT0gJ29iamVjdCcgPyByb3cgOiB7IHJhdzogcm93IH0sXG4gICAgICAgICAgfSkpO1xuICAgICAgICAgIHJldHVybiByZXMub2soe1xuICAgICAgICAgICAgYm9keToge1xuICAgICAgICAgICAgICBoaXRzLFxuICAgICAgICAgICAgICB0b3RhbDogeyB2YWx1ZTogcm93cy5sZW5ndGgsIHJlbGF0aW9uOiAnZXEnIH0sXG4gICAgICAgICAgICAgIHNvdXJjZTogJ21kZScsXG4gICAgICAgICAgICB9LFxuICAgICAgICAgIH0pO1xuICAgICAgICB9IGNhdGNoIChlcnI6IGFueSkge1xuICAgICAgICAgIHJldHVybiByZXMuY3VzdG9tRXJyb3Ioe1xuICAgICAgICAgICAgc3RhdHVzQ29kZTogbWRlRXJyb3JTdGF0dXMoZXJyKSxcbiAgICAgICAgICAgIGJvZHk6IGVycj8ubWVzc2FnZSA/PyBTdHJpbmcoZXJyKSxcbiAgICAgICAgICB9KTtcbiAgICAgICAgfVxuICAgICAgfVxuICAgICAgdHJ5IHtcbiAgICAgICAgY29uc3QgY2xpZW50ID0gZ2V0Q2xpZW50KGNvbnRleHQpO1xuICAgICAgICBjb25zdCB7IHNpemUgPSA1MCwgZnJvbSA9IDAgfSA9IHE7XG4gICAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgY2xpZW50LnNlYXJjaCh7XG4gICAgICAgICAgaW5kZXg6IERFRkVOREVSX1ZVTE5FUkFCSUxJVElFU19JTkRFWCxcbiAgICAgICAgICBpZ25vcmVfdW5hdmFpbGFibGU6IHRydWUsXG4gICAgICAgICAgYm9keToge1xuICAgICAgICAgICAgc2l6ZSxcbiAgICAgICAgICAgIGZyb20sXG4gICAgICAgICAgICBzb3J0OiBbeyBzeW5jX3RzOiB7IG9yZGVyOiAnZGVzYycgfSB9XSxcbiAgICAgICAgICAgIHF1ZXJ5OiB7IG1hdGNoX2FsbDoge30gfSxcbiAgICAgICAgICB9LFxuICAgICAgICB9KTtcbiAgICAgICAgY29uc3QgaGl0cyA9IChyZXNwb25zZS5ib2R5IGFzIGFueSk/LmhpdHMgPz8ge307XG4gICAgICAgIHJldHVybiByZXMub2soeyBib2R5OiB7IGhpdHM6IGhpdHMuaGl0cyA/PyBbXSwgdG90YWw6IGhpdHMudG90YWwsIHNvdXJjZTogJ2luZGV4JyB9IH0pO1xuICAgICAgfSBjYXRjaCAoZXJyOiBhbnkpIHtcbiAgICAgICAgcmV0dXJuIHJlcy5jdXN0b21FcnJvcih7XG4gICAgICAgICAgc3RhdHVzQ29kZTogZXJyLnN0YXR1c0NvZGUgPz8gNTAwLFxuICAgICAgICAgIGJvZHk6IGVyci5tZXNzYWdlID8/IFN0cmluZyhlcnIpLFxuICAgICAgICB9KTtcbiAgICAgIH1cbiAgICB9XG4gICk7XG5cbiAgcm91dGVyLmdldChcbiAgICB7XG4gICAgICBwYXRoOiAnL2FwaS9kZWZlbmRlcl9wbHVnaW4vaW5jaWRlbnRzL2xpdmUnLFxuICAgICAgdmFsaWRhdGU6IHtcbiAgICAgICAgcXVlcnk6IHNjaGVtYS5vYmplY3Qoe1xuICAgICAgICAgIHRvcDogc2NoZW1hLm1heWJlKHNjaGVtYS5udW1iZXIoKSksXG4gICAgICAgIH0pLFxuICAgICAgfSxcbiAgICB9LFxuICAgIGFzeW5jIChfY29udGV4dCwgcmVxLCByZXMpID0+IHtcbiAgICAgIGNvbnN0IGNvbmZpZyA9IGdldEdyYXBoU2VjdXJpdHlDb25maWcoKTtcbiAgICAgIGlmICghY29uZmlnKSB7XG4gICAgICAgIHJldHVybiByZXMuY3VzdG9tRXJyb3Ioe1xuICAgICAgICAgIHN0YXR1c0NvZGU6IDUwMyxcbiAgICAgICAgICBib2R5OiAnR3JhcGggc2VjdXJpdHkgbm90IGNvbmZpZ3VyZWQuJyxcbiAgICAgICAgfSk7XG4gICAgICB9XG4gICAgICB0cnkge1xuICAgICAgICBjb25zdCB0b3AgPSAocmVxLnF1ZXJ5IGFzIHsgdG9wPzogbnVtYmVyIH0pLnRvcCA/PyAyNTtcbiAgICAgICAgY29uc3QgZGF0YSA9IGF3YWl0IGxpc3RJbmNpZGVudHMoY29uZmlnLCB0b3ApO1xuICAgICAgICByZXR1cm4gcmVzLm9rKHsgYm9keTogZGF0YSB9KTtcbiAgICAgIH0gY2F0Y2ggKGVycjogdW5rbm93bikge1xuICAgICAgICBjb25zdCB7IHN0YXR1cywgYm9keSB9ID0gbWFwR3JhcGhFcnIoZXJyKTtcbiAgICAgICAgcmV0dXJuIHJlcy5jdXN0b21FcnJvcih7IHN0YXR1c0NvZGU6IHN0YXR1cywgYm9keSB9KTtcbiAgICAgIH1cbiAgICB9XG4gICk7XG5cbiAgcm91dGVyLmdldChcbiAgICB7XG4gICAgICBwYXRoOiAnL2FwaS9kZWZlbmRlcl9wbHVnaW4vYWxlcnRzL2xpdmUnLFxuICAgICAgdmFsaWRhdGU6IHtcbiAgICAgICAgcXVlcnk6IHNjaGVtYS5vYmplY3Qoe1xuICAgICAgICAgIHRvcDogc2NoZW1hLm1heWJlKHNjaGVtYS5udW1iZXIoKSksXG4gICAgICAgIH0pLFxuICAgICAgfSxcbiAgICB9LFxuICAgIGFzeW5jIChfY29udGV4dCwgcmVxLCByZXMpID0+IHtcbiAgICAgIGNvbnN0IGNvbmZpZyA9IGdldEdyYXBoU2VjdXJpdHlDb25maWcoKTtcbiAgICAgIGlmICghY29uZmlnKSB7XG4gICAgICAgIHJldHVybiByZXMuY3VzdG9tRXJyb3Ioe1xuICAgICAgICAgIHN0YXR1c0NvZGU6IDUwMyxcbiAgICAgICAgICBib2R5OiAnR3JhcGggc2VjdXJpdHkgbm90IGNvbmZpZ3VyZWQuJyxcbiAgICAgICAgfSk7XG4gICAgICB9XG4gICAgICB0cnkge1xuICAgICAgICBjb25zdCB0b3AgPSAocmVxLnF1ZXJ5IGFzIHsgdG9wPzogbnVtYmVyIH0pLnRvcCA/PyAyNTtcbiAgICAgICAgY29uc3QgZGF0YSA9IGF3YWl0IGxpc3RBbGVydHNWMihjb25maWcsIHRvcCk7XG4gICAgICAgIHJldHVybiByZXMub2soeyBib2R5OiBkYXRhIH0pO1xuICAgICAgfSBjYXRjaCAoZXJyOiB1bmtub3duKSB7XG4gICAgICAgIGNvbnN0IHsgc3RhdHVzLCBib2R5IH0gPSBtYXBHcmFwaEVycihlcnIpO1xuICAgICAgICByZXR1cm4gcmVzLmN1c3RvbUVycm9yKHsgc3RhdHVzQ29kZTogc3RhdHVzLCBib2R5IH0pO1xuICAgICAgfVxuICAgIH1cbiAgKTtcblxuICByb3V0ZXIucG9zdChcbiAgICB7XG4gICAgICBwYXRoOiAnL2FwaS9kZWZlbmRlcl9wbHVnaW4vaHVudGluZycsXG4gICAgICB2YWxpZGF0ZToge1xuICAgICAgICBib2R5OiBzY2hlbWEub2JqZWN0KHtcbiAgICAgICAgICBxdWVyeTogc2NoZW1hLnN0cmluZygpLFxuICAgICAgICAgIHRpbWVzcGFuOiBzY2hlbWEubWF5YmUoc2NoZW1hLnN0cmluZygpKSxcbiAgICAgICAgfSksXG4gICAgICB9LFxuICAgIH0sXG4gICAgYXN5bmMgKF9jb250ZXh0LCByZXEsIHJlcykgPT4ge1xuICAgICAgY29uc3QgY29uZmlnID0gZ2V0R3JhcGhTZWN1cml0eUNvbmZpZygpO1xuICAgICAgaWYgKCFjb25maWcpIHtcbiAgICAgICAgcmV0dXJuIHJlcy5jdXN0b21FcnJvcih7XG4gICAgICAgICAgc3RhdHVzQ29kZTogNTAzLFxuICAgICAgICAgIGJvZHk6ICdHcmFwaCBzZWN1cml0eSBub3QgY29uZmlndXJlZC4nLFxuICAgICAgICB9KTtcbiAgICAgIH1cbiAgICAgIHRyeSB7XG4gICAgICAgIGNvbnN0IHsgcXVlcnksIHRpbWVzcGFuIH0gPSByZXEuYm9keSBhcyB7IHF1ZXJ5OiBzdHJpbmc7IHRpbWVzcGFuPzogc3RyaW5nIH07XG4gICAgICAgIGNvbnN0IHN0YXJ0ZWQgPSBEYXRlLm5vdygpO1xuICAgICAgICBjb25zdCBkYXRhID0gYXdhaXQgcnVuSHVudGluZ1F1ZXJ5KGNvbmZpZywgcXVlcnksIHRpbWVzcGFuIHx8ICdQN0QnKTtcbiAgICAgICAgY29uc3Qgcm93Q291bnQgPSBBcnJheS5pc0FycmF5KChkYXRhIGFzIGFueSk/LnJlc3VsdHMpXG4gICAgICAgICAgPyAoZGF0YSBhcyBhbnkpLnJlc3VsdHMubGVuZ3RoXG4gICAgICAgICAgOiAwO1xuICAgICAgICByZXR1cm4gcmVzLm9rKHtcbiAgICAgICAgICBib2R5OiB7XG4gICAgICAgICAgICAuLi4oKGRhdGEgYXMgb2JqZWN0KSB8fCB7fSksXG4gICAgICAgICAgICBleGVjdXRpb25UaW1lTXM6IERhdGUubm93KCkgLSBzdGFydGVkLFxuICAgICAgICAgICAgcm93Q291bnQsXG4gICAgICAgICAgfSxcbiAgICAgICAgfSk7XG4gICAgICB9IGNhdGNoIChlcnI6IHVua25vd24pIHtcbiAgICAgICAgY29uc3QgeyBzdGF0dXMsIGJvZHkgfSA9IG1hcEdyYXBoRXJyKGVycik7XG4gICAgICAgIHJldHVybiByZXMuY3VzdG9tRXJyb3IoeyBzdGF0dXNDb2RlOiBzdGF0dXMsIGJvZHkgfSk7XG4gICAgICB9XG4gICAgfVxuICApO1xuXG4gIHJvdXRlci5nZXQoXG4gICAge1xuICAgICAgcGF0aDogJy9hcGkvZGVmZW5kZXJfcGx1Z2luL2luZGljYXRvcnMvbGl2ZScsXG4gICAgICB2YWxpZGF0ZToge1xuICAgICAgICBxdWVyeTogc2NoZW1hLm9iamVjdCh7XG4gICAgICAgICAgdG9wOiBzY2hlbWEubWF5YmUoc2NoZW1hLm51bWJlcigpKSxcbiAgICAgICAgfSksXG4gICAgICB9LFxuICAgIH0sXG4gICAgYXN5bmMgKF9jb250ZXh0LCByZXEsIHJlcykgPT4ge1xuICAgICAgY29uc3QgY29uZmlnID0gZ2V0TWRlQ29uZmlnKCk7XG4gICAgICBpZiAoIWNvbmZpZykge1xuICAgICAgICByZXR1cm4gcmVzLmN1c3RvbUVycm9yKHsgc3RhdHVzQ29kZTogNTAzLCBib2R5OiAnTURFIG5vdCBjb25maWd1cmVkLicgfSk7XG4gICAgICB9XG4gICAgICB0cnkge1xuICAgICAgICBjb25zdCB0b3AgPSAocmVxLnF1ZXJ5IGFzIHsgdG9wPzogbnVtYmVyIH0pLnRvcCA/PyAxMDA7XG4gICAgICAgIGNvbnN0IGRhdGEgPSBhd2FpdCBsaXN0SW5kaWNhdG9ycyhjb25maWcsIHRvcCk7XG4gICAgICAgIHJldHVybiByZXMub2soeyBib2R5OiBkYXRhIH0pO1xuICAgICAgfSBjYXRjaCAoZXJyOiBhbnkpIHtcbiAgICAgICAgcmV0dXJuIHJlcy5jdXN0b21FcnJvcih7IHN0YXR1c0NvZGU6IG1kZUVycm9yU3RhdHVzKGVyciksIGJvZHk6IGVycj8ubWVzc2FnZSA/PyBTdHJpbmcoZXJyKSB9KTtcbiAgICAgIH1cbiAgICB9XG4gICk7XG5cbiAgcm91dGVyLmdldChcbiAgICB7XG4gICAgICBwYXRoOiAnL2FwaS9kZWZlbmRlcl9wbHVnaW4vYXVkaXQtbG9nJyxcbiAgICAgIHZhbGlkYXRlOiB7XG4gICAgICAgIHF1ZXJ5OiBzY2hlbWEub2JqZWN0KHtcbiAgICAgICAgICBzaXplOiBzY2hlbWEubWF5YmUoc2NoZW1hLm51bWJlcigpKSxcbiAgICAgICAgfSksXG4gICAgICB9LFxuICAgIH0sXG4gICAgYXN5bmMgKGNvbnRleHQsIHJlcSwgcmVzKSA9PiB7XG4gICAgICB0cnkge1xuICAgICAgICBjb25zdCBjbGllbnQgPSBnZXRDbGllbnQoY29udGV4dCk7XG4gICAgICAgIGNvbnN0IHNpemUgPSAocmVxLnF1ZXJ5IGFzIHsgc2l6ZT86IG51bWJlciB9KS5zaXplID8/IDUwO1xuICAgICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGNsaWVudC5zZWFyY2goe1xuICAgICAgICAgIGluZGV4OiBERUZFTkRFUl9BVURJVF9MT0dfSU5ERVgsXG4gICAgICAgICAgaWdub3JlX3VuYXZhaWxhYmxlOiB0cnVlLFxuICAgICAgICAgIGJvZHk6IHtcbiAgICAgICAgICAgIHNpemUsXG4gICAgICAgICAgICBzb3J0OiBbeyB0aW1lc3RhbXA6IHsgb3JkZXI6ICdkZXNjJyB9IH1dLFxuICAgICAgICAgICAgcXVlcnk6IHsgbWF0Y2hfYWxsOiB7fSB9LFxuICAgICAgICAgIH0sXG4gICAgICAgIH0pO1xuICAgICAgICBjb25zdCBoaXRzID0gKHJlc3BvbnNlLmJvZHkgYXMgYW55KT8uaGl0cz8uaGl0cyA/PyBbXTtcbiAgICAgICAgcmV0dXJuIHJlcy5vayh7IGJvZHk6IHsgZW50cmllczogaGl0cy5tYXAoKGg6IGFueSkgPT4gaC5fc291cmNlKSB9IH0pO1xuICAgICAgfSBjYXRjaCAoZXJyOiBhbnkpIHtcbiAgICAgICAgcmV0dXJuIHJlcy5jdXN0b21FcnJvcih7XG4gICAgICAgICAgc3RhdHVzQ29kZTogZXJyLnN0YXR1c0NvZGUgPz8gNTAwLFxuICAgICAgICAgIGJvZHk6IGVyci5tZXNzYWdlID8/IFN0cmluZyhlcnIpLFxuICAgICAgICB9KTtcbiAgICAgIH1cbiAgICB9XG4gICk7XG5cbiAgcm91dGVyLnBvc3QoXG4gICAge1xuICAgICAgcGF0aDogJy9hcGkvZGVmZW5kZXJfcGx1Z2luL2FsZXJ0c19lbnJpY2htZW50JyxcbiAgICAgIHZhbGlkYXRlOiB7XG4gICAgICAgIGJvZHk6IHNjaGVtYS5vYmplY3Qoe1xuICAgICAgICAgIHNpemU6IHNjaGVtYS5tYXliZShzY2hlbWEubnVtYmVyKCkpLFxuICAgICAgICAgIGZyb206IHNjaGVtYS5tYXliZShzY2hlbWEubnVtYmVyKCkpLFxuICAgICAgICAgIHRpbWVfZnJvbTogc2NoZW1hLm1heWJlKHNjaGVtYS5zdHJpbmcoKSksXG4gICAgICAgICAgdGltZV90bzogc2NoZW1hLm1heWJlKHNjaGVtYS5zdHJpbmcoKSksXG4gICAgICAgICAgZGVmZW5kZXJfY29ycmVsYXRlZF9vbmx5OiBzY2hlbWEubWF5YmUoc2NoZW1hLmJvb2xlYW4oKSksXG4gICAgICAgIH0pLFxuICAgICAgfSxcbiAgICB9LFxuICAgIGFzeW5jIChjb250ZXh0LCByZXEsIHJlcykgPT4ge1xuICAgICAgdHJ5IHtcbiAgICAgICAgY29uc3QgY2xpZW50ID0gZ2V0Q2xpZW50KGNvbnRleHQpO1xuICAgICAgICBjb25zdCB7XG4gICAgICAgICAgc2l6ZSA9IDI1LFxuICAgICAgICAgIGZyb20gPSAwLFxuICAgICAgICAgIHRpbWVfZnJvbSxcbiAgICAgICAgICB0aW1lX3RvLFxuICAgICAgICAgIGRlZmVuZGVyX2NvcnJlbGF0ZWRfb25seSA9IHRydWUsXG4gICAgICAgIH0gPSByZXEuYm9keTtcblxuICAgICAgICBjb25zdCBub3cgPSBuZXcgRGF0ZSgpO1xuICAgICAgICBjb25zdCBkZWZhdWx0VG8gPSBub3cudG9JU09TdHJpbmcoKTtcbiAgICAgICAgY29uc3QgZGVmYXVsdEZyb20gPSBuZXcgRGF0ZShub3cuZ2V0VGltZSgpIC0gNyAqIDI0ICogNjAgKiA2MCAqIDEwMDApLnRvSVNPU3RyaW5nKCk7XG4gICAgICAgIGNvbnN0IHRpbWVHdGUgPSB0aW1lX2Zyb20gfHwgZGVmYXVsdEZyb207XG4gICAgICAgIGNvbnN0IHRpbWVMdGUgPSB0aW1lX3RvIHx8IGRlZmF1bHRUbztcbiAgICAgICAgY29uc3QgdGltZVJhbmdlRmlsdGVyID0geyByYW5nZTogeyB0aW1lc3RhbXA6IHsgZ3RlOiB0aW1lR3RlLCBsdGU6IHRpbWVMdGUgfSB9IH07XG5cbiAgICAgICAgbGV0IGFnZW50SWRzVG9RdWVyeTogc3RyaW5nW10gfCBudWxsID0gbnVsbDtcbiAgICAgICAgY29uc3QgYWdlbnRUb0RlZmVuZGVyOiBSZWNvcmQ8c3RyaW5nLCBzdHJpbmc+ID0ge307XG5cbiAgICAgICAgaWYgKGRlZmVuZGVyX2NvcnJlbGF0ZWRfb25seSkge1xuICAgICAgICAgIGNvbnN0IGlkZW50aXR5UmVzID0gYXdhaXQgY2xpZW50LnNlYXJjaCh7XG4gICAgICAgICAgICBpbmRleDogREVGRU5ERVJfTUFDSElORV9JREVOVElUWV9JTkRFWCxcbiAgICAgICAgICAgIGlnbm9yZV91bmF2YWlsYWJsZTogdHJ1ZSxcbiAgICAgICAgICAgIGJvZHk6IHtcbiAgICAgICAgICAgICAgc2l6ZTogMTAwMCxcbiAgICAgICAgICAgICAgX3NvdXJjZTogWyd3YXp1aF9hZ2VudF9pZCcsICdkZWZlbmRlcl9tYWNoaW5lX2lkJywgJ2NvbXB1dGVyX2Ruc19uYW1lJ10sXG4gICAgICAgICAgICAgIHF1ZXJ5OiB7IG1hdGNoX2FsbDoge30gfSxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgfSk7XG4gICAgICAgICAgY29uc3QgaWRlbnRpdHlIaXRzID0gKGlkZW50aXR5UmVzLmJvZHkgYXMgYW55KT8uaGl0cz8uaGl0cyA/PyBbXTtcbiAgICAgICAgICBhZ2VudElkc1RvUXVlcnkgPSBpZGVudGl0eUhpdHNcbiAgICAgICAgICAgIC5tYXAoKGg6IGFueSkgPT4gaC5fc291cmNlPy53YXp1aF9hZ2VudF9pZClcbiAgICAgICAgICAgIC5maWx0ZXIoKGlkOiBzdHJpbmcpID0+IGlkICYmIGlkICE9PSAnMDAwJyk7XG4gICAgICAgICAgaWYgKGFnZW50SWRzVG9RdWVyeS5sZW5ndGggPT09IDApIHtcbiAgICAgICAgICAgIHJldHVybiByZXMub2soe1xuICAgICAgICAgICAgICBib2R5OiB7XG4gICAgICAgICAgICAgICAgYWxlcnRzOiBbXSxcbiAgICAgICAgICAgICAgICBlbnJpY2htZW50czoge30sXG4gICAgICAgICAgICAgICAgdG90YWw6IDAsXG4gICAgICAgICAgICAgICAgaWRlbnRpdHlfY291bnQ6IDAsXG4gICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICB9KTtcbiAgICAgICAgICB9XG4gICAgICAgICAgaWRlbnRpdHlIaXRzLmZvckVhY2goKGg6IGFueSkgPT4ge1xuICAgICAgICAgICAgY29uc3QgcyA9IGguX3NvdXJjZTtcbiAgICAgICAgICAgIGlmIChzPy53YXp1aF9hZ2VudF9pZCkgYWdlbnRUb0RlZmVuZGVyW3Mud2F6dWhfYWdlbnRfaWRdID0gcy5kZWZlbmRlcl9tYWNoaW5lX2lkO1xuICAgICAgICAgIH0pO1xuICAgICAgICB9XG5cbiAgICAgICAgY29uc3QgbXVzdDogYW55W10gPSBbdGltZVJhbmdlRmlsdGVyXTtcbiAgICAgICAgbXVzdC5wdXNoKHsgYm9vbDogeyBtdXN0X25vdDogW3sgdGVybTogeyAnYWdlbnQuaWQnOiAnMDAwJyB9IH1dIH0gfSk7XG4gICAgICAgIGlmIChhZ2VudElkc1RvUXVlcnkgJiYgYWdlbnRJZHNUb1F1ZXJ5Lmxlbmd0aCA+IDApIHtcbiAgICAgICAgICBtdXN0LnB1c2goeyB0ZXJtczogeyAnYWdlbnQuaWQnOiBhZ2VudElkc1RvUXVlcnkgfSB9KTtcbiAgICAgICAgfVxuXG4gICAgICAgIGNvbnN0IGFsZXJ0c0JvZHkgPSB7XG4gICAgICAgICAgZnJvbSxcbiAgICAgICAgICBzaXplLFxuICAgICAgICAgIHNvcnQ6IFt7IHRpbWVzdGFtcDogeyBvcmRlcjogJ2Rlc2MnIH0gfV0sXG4gICAgICAgICAgX3NvdXJjZTogWydhZ2VudC5pZCcsICdhZ2VudC5uYW1lJywgJ3J1bGUuZGVzY3JpcHRpb24nLCAncnVsZS5sZXZlbCcsICd0aW1lc3RhbXAnXSxcbiAgICAgICAgICBxdWVyeTogeyBib29sOiB7IG11c3QgfSB9LFxuICAgICAgICB9O1xuXG4gICAgICAgIGNvbnN0IFthbGVydHNSZXNwb25zZSwgY291bnRSZXNwb25zZV0gPSBhd2FpdCBQcm9taXNlLmFsbChbXG4gICAgICAgICAgY2xpZW50LnNlYXJjaCh7XG4gICAgICAgICAgICBpbmRleDogV0FaVUhfQUxFUlRTX1BBVFRFUk4sXG4gICAgICAgICAgICBpZ25vcmVfdW5hdmFpbGFibGU6IHRydWUsXG4gICAgICAgICAgICBib2R5OiBhbGVydHNCb2R5LFxuICAgICAgICAgIH0pLFxuICAgICAgICAgIGNsaWVudC5zZWFyY2goe1xuICAgICAgICAgICAgaW5kZXg6IFdBWlVIX0FMRVJUU19QQVRURVJOLFxuICAgICAgICAgICAgaWdub3JlX3VuYXZhaWxhYmxlOiB0cnVlLFxuICAgICAgICAgICAgYm9keToge1xuICAgICAgICAgICAgICBzaXplOiAwLFxuICAgICAgICAgICAgICBxdWVyeTogYWxlcnRzQm9keS5xdWVyeSxcbiAgICAgICAgICAgICAgdHJhY2tfdG90YWxfaGl0czogdHJ1ZSxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgfSksXG4gICAgICAgIF0pO1xuXG4gICAgICAgIGNvbnN0IGFsZXJ0SGl0cyA9IChhbGVydHNSZXNwb25zZS5ib2R5IGFzIGFueSk/LmhpdHM/LmhpdHMgPz8gW107XG4gICAgICAgIGNvbnN0IHRvdGFsID1cbiAgICAgICAgICAoY291bnRSZXNwb25zZS5ib2R5IGFzIGFueSk/LmhpdHM/LnRvdGFsPy52YWx1ZSA/P1xuICAgICAgICAgIChjb3VudFJlc3BvbnNlLmJvZHkgYXMgYW55KT8uaGl0cz8udG90YWwgPz9cbiAgICAgICAgICBhbGVydEhpdHMubGVuZ3RoO1xuXG4gICAgICAgIGNvbnN0IGVucmljaG1lbnRzOiBSZWNvcmQ8c3RyaW5nLCB7IGRlZmVuZGVyX21hY2hpbmVfaWQ/OiBzdHJpbmcgfT4gPSB7fTtcbiAgICAgICAgYWxlcnRIaXRzLmZvckVhY2goKGg6IGFueSkgPT4ge1xuICAgICAgICAgIGNvbnN0IGFpZCA9IGguX3NvdXJjZT8uYWdlbnQ/LmlkO1xuICAgICAgICAgIGlmIChhaWQgJiYgYWdlbnRUb0RlZmVuZGVyW2FpZF0pIHtcbiAgICAgICAgICAgIGVucmljaG1lbnRzW2guX2lkXSA9IHsgZGVmZW5kZXJfbWFjaGluZV9pZDogYWdlbnRUb0RlZmVuZGVyW2FpZF0gfTtcbiAgICAgICAgICB9XG4gICAgICAgIH0pO1xuXG4gICAgICAgIHJldHVybiByZXMub2soe1xuICAgICAgICAgIGJvZHk6IHtcbiAgICAgICAgICAgIGFsZXJ0czogYWxlcnRIaXRzLm1hcCgoaDogYW55KSA9PiAoe1xuICAgICAgICAgICAgICBpZDogaC5faWQsXG4gICAgICAgICAgICAgIC4uLmguX3NvdXJjZSxcbiAgICAgICAgICAgIH0pKSxcbiAgICAgICAgICAgIGVucmljaG1lbnRzLFxuICAgICAgICAgICAgdG90YWwsXG4gICAgICAgICAgICBpZGVudGl0eV9jb3VudDogT2JqZWN0LmtleXMoYWdlbnRUb0RlZmVuZGVyKS5sZW5ndGgsXG4gICAgICAgICAgfSxcbiAgICAgICAgfSk7XG4gICAgICB9IGNhdGNoIChlcnI6IGFueSkge1xuICAgICAgICByZXR1cm4gcmVzLmN1c3RvbUVycm9yKHtcbiAgICAgICAgICBzdGF0dXNDb2RlOiBlcnIuc3RhdHVzQ29kZSA/PyA1MDAsXG4gICAgICAgICAgYm9keTogZXJyLm1lc3NhZ2UgPz8gU3RyaW5nKGVyciksXG4gICAgICAgIH0pO1xuICAgICAgfVxuICAgIH1cbiAgKTtcbn1cbiJdLCJtYXBwaW5ncyI6Ijs7Ozs7O0FBS0EsSUFBQUEsYUFBQSxHQUFBQyxPQUFBO0FBQ0EsSUFBQUMsVUFBQSxHQUFBRCxPQUFBO0FBU0EsSUFBQUUsVUFBQSxHQUFBRixPQUFBO0FBZ0JBLElBQUFHLG9CQUFBLEdBQUFILE9BQUE7QUEvQkE7QUFDQTtBQUNBOztBQXNDQSxTQUFTSSxXQUFXQSxDQUFDQyxHQUFZLEVBQW9DO0VBQ25FLElBQUlBLEdBQUcsWUFBWUYsb0JBQUEsQ0FBQUcsYUFBYSxFQUFFO0lBQ2hDLE9BQU87TUFBRUMsTUFBTSxFQUFFRixHQUFHLENBQUNFLE1BQU0sSUFBSSxHQUFHLElBQUlGLEdBQUcsQ0FBQ0UsTUFBTSxHQUFHLEdBQUcsR0FBR0YsR0FBRyxDQUFDRSxNQUFNLEdBQUcsR0FBRztNQUFFQyxJQUFJLEVBQUVILEdBQUcsQ0FBQ0k7SUFBUSxDQUFDO0VBQ2hHO0VBQ0EsT0FBTztJQUFFRixNQUFNLEVBQUUsR0FBRztJQUFFQyxJQUFJLEVBQUVILEdBQUcsWUFBWUssS0FBSyxHQUFHTCxHQUFHLENBQUNJLE9BQU8sR0FBR0UsTUFBTSxDQUFDTixHQUFHO0VBQUUsQ0FBQztBQUNoRjtBQUVBLFNBQVNPLG1CQUFtQkEsQ0FBQ0MsQ0FBMEIsRUFBRUMsUUFBZ0IsRUFBRTtFQUN6RSxPQUFPO0lBQ0xDLFNBQVMsRUFBRUQsUUFBUTtJQUNuQkUsVUFBVSxFQUFFSCxDQUFDLENBQUNJLEVBQUU7SUFDaEJDLGlCQUFpQixFQUFFTCxDQUFDLENBQUNNLGVBQWUsSUFBSSxFQUFFO0lBQzFDQyxXQUFXLEVBQUVQLENBQUMsQ0FBQ1EsVUFBVSxJQUFJLEVBQUU7SUFDL0JDLFVBQVUsRUFBRVQsQ0FBQyxDQUFDVSxTQUFTLElBQUksRUFBRTtJQUM3QkMsU0FBUyxFQUFFWCxDQUFDLENBQUNZLFFBQVEsSUFBSSxJQUFJO0lBQzdCQyxVQUFVLEVBQUViLENBQUMsQ0FBQ2MsU0FBUyxJQUFJLElBQUk7SUFDL0JDLGFBQWEsRUFBRWYsQ0FBQyxDQUFDZ0IsV0FBVyxJQUFJLEVBQUU7SUFDbENDLFVBQVUsRUFBRWpCLENBQUMsQ0FBQ2tCLFNBQVMsSUFBSSxJQUFJLEdBQUdwQixNQUFNLENBQUNFLENBQUMsQ0FBQ2tCLFNBQVMsQ0FBQyxHQUFHLEVBQUU7SUFDMURDLGNBQWMsRUFBRW5CLENBQUMsQ0FBQ29CLGFBQWEsSUFBSSxFQUFFO0lBQ3JDQyxpQkFBaUIsRUFBRXJCLENBQUMsQ0FBQ3NCLGdCQUFnQixJQUFJdEIsQ0FBQyxDQUFDdUIsZ0JBQWdCLElBQUksRUFBRTtJQUNqRUMsYUFBYSxFQUFFeEIsQ0FBQyxDQUFDeUIsWUFBWSxJQUFJLEVBQUU7SUFDbkNDLGdCQUFnQixFQUFFMUIsQ0FBQyxDQUFDMkIsZUFBZSxJQUFJLEVBQUU7SUFDekNDLGVBQWUsRUFBRTVCLENBQUMsQ0FBQzZCLGFBQWEsSUFBSSxFQUFFO0lBQ3RDQyxlQUFlLEVBQUU5QixDQUFDLENBQUMrQixhQUFhLElBQUk7RUFDdEMsQ0FBQztBQUNIO0FBRUEsU0FBU0MsU0FBU0EsQ0FBQ0MsT0FBWSxFQUFFO0VBQy9CLE9BQU9BLE9BQU8sQ0FBQ0MsSUFBSSxDQUFDQyxVQUFVLENBQUNDLE1BQU0sQ0FBQ0MsYUFBYTtBQUNyRDtBQUVPLFNBQVNDLDRCQUE0QkEsQ0FBQ0MsTUFBZSxFQUFFO0VBQzVEQSxNQUFNLENBQUNDLEdBQUcsQ0FBQztJQUFFQyxJQUFJLEVBQUU7SUFBK0JDLFFBQVEsRUFBRTtFQUFNLENBQUMsRUFBRSxPQUFPQyxRQUFRLEVBQUVDLElBQUksRUFBRUMsR0FBRyxLQUFLO0lBQ2xHLE1BQU1DLEdBQUcsR0FBRyxDQUFDLENBQUMsSUFBQXpELFVBQUEsQ0FBQTBELFlBQVksRUFBQyxDQUFDO0lBQzVCLE1BQU1DLEtBQUssR0FBRyxDQUFDLENBQUMsSUFBQTFELG9CQUFBLENBQUEyRCxzQkFBc0IsRUFBQyxDQUFDO0lBQ3hDLE1BQUFDLFNBQWMsR0FBQUMsT0FBQSxDQUFBQyxHQUFBLENBQUFDLFNBQUE7VUFDUkMsU0FBRSxHQUFBSCxPQUFBLENBQUFDLEdBQUEsQ0FBQUcsU0FBQTtVQUNGQyxTQUFTLEdBQUFMLE9BQUssQ0FBQUMsR0FBQSxDQUFBSyxTQUFBO1VBQ2hCQyxtQkFBbUIsR0FBQVAsT0FBQSxDQUFBQyxHQUFBLENBQUFPLG1CQUFBO1VBQ25CQyxlQUFBLE1BQUFWLFNBQWdDLElBQUFRLG1CQUFBO1dBQ2hDYixHQUFBLENBQUFnQixFQUFTO01BQ1hsRSxJQUFBO1FBQ0FrRSxFQUFBLEVBQUFmLEdBQUEsSUFBQUUsS0FBQTtRQUNGYyxjQUFBLEVBQUFoQixHQUFBO1FBRUlpQix5QkFDSixFQUFBZixLQUFBO1FBQ01ZLGVBQUU7UUFDTkksWUFBVSxHQUFBSixlQUFBO1FBQ1JWLFNBQU87UUFDTEksU0FBTTtRQUNORSxTQUFNO1FBQ05FLG1CQUFhO1FBQ2JPLFNBQUEsTUFBY0MsSUFBRSxHQUFBQyxXQUFBOztNQUVsQjtJQUNGO0VBQ0Y1QixNQUNBLENBQUFDLEdBQU87SUFDTEMsSUFBQSxFQUFNLDRCQU1MO0lBQ0RDLFFBQU07TUFDSjBCLEtBQUEsRUFBTWxGLGFBQU8sQ0FBQW1GLE1BQUEsQ0FBQUMsTUFBQTtRQUNiQyxJQUFLLEVBQUFyRixhQUFNLENBQUFtRixNQUFBLENBQUFHLEtBQUEsQ0FBQXRGLGFBQUEsQ0FBQW1GLE1BQUEsQ0FBQUksTUFBQTtRQUNUQyxJQUFBLEVBQUF4RixhQUFXLENBQUFtRixNQUFZLENBQUFHLEtBQUEsQ0FBQXRGLGFBQUEsQ0FBQW1GLE1BQUEsQ0FBQUksTUFBQTttQkFBRSxFQUFVdkYsYUFBSyxDQUFBbUYsTUFBQSxDQUFBRyxLQUFBLENBQUF0RixhQUFBLENBQUFtRixNQUFBLENBQUFNLE1BQUE7c0JBQVEsRUFBQXpGLGFBQUEsQ0FBQW1GLE1BQUEsQ0FBQUcsS0FBQSxDQUFBdEYsYUFBQSxDQUFBbUYsTUFBQSxDQUFBTSxNQUFBO1FBQXNCQyxNQUFFLEVBQUExRixhQUFBLENBQUFtRixNQUFBLENBQUFHLEtBQUEsQ0FBQXRGLGFBQUEsQ0FBQW1GLE1BQUEsQ0FBQU0sTUFBQTtNQUMxRTs7WUFDSTFDLE9BQUEsRUFBQTRDLEdBQUEsRUFBQWhDLEdBQUE7VUFDRmlDLENBQUEsR0FBTUQsR0FBRyxDQUFBVCxLQUFHO1FBQ1pVLENBQUEsQ0FBQUYsTUFBTSxXQUFXLEVBQUk7WUFDakJHLElBQUksR0FBRyxJQUFJMUYsVUFBVyxDQUFBMEQsWUFBQTtVQUMxQixDQUFBZ0MsSUFBTTtlQUNBbEMsR0FBRyxDQUFBbUMsV0FBYztVQUN2QkMsVUFBQTtVQUNBdEYsSUFBTTtVQUNKOztVQUVGO1lBQ0V1RixPQUFRLEVBQUdDLE9BQUU7Y0FDYkMsR0FBTSxHQUFFLE1BQUssSUFBQS9GLFVBQWdCLENBQUFnRyx1QkFBeUIsRUFBQ04sSUFBQSxFQUFPLEVBQUU7Y0FDaEU5RSxRQUFZLEdBQUU4RSxJQUFBLENBQUE5RSxRQUFBO1FBQ2hCLElBQUVxRixJQUFBLEdBQUFGLEdBQUEsQ0FBQUcsR0FBQSxDQUFBdkYsQ0FBQSxJQUFBRCxtQkFBQSxDQUFBQyxDQUFBLEVBQUFDLFFBQUE7UUFDRixJQUFBNkUsQ0FBQSxDQUFNdkUsV0FBSTtVQUNWK0UsSUFBTSxHQUFBQSxJQUFJLENBQUFFLE1BQUEsQ0FBQUMsQ0FBQSxJQUFLM0YsTUFBSSxDQUFBMkYsQ0FBQSxDQUFBbEYsV0FBQSxNQUFBdUUsQ0FBQSxDQUFBdkUsV0FBQTtRQUNuQjtRQUNBLElBQUF1RSxDQUFBLENBQU0zRCxjQUFhLEVBQUc7VUFBYW1FLElBQUEsR0FBT0EsSUFBRSxDQUFHRSxNQUFBLENBQUFDLENBQUEsSUFBQTNGLE1BQUEsQ0FBQTJGLENBQUEsQ0FBQXRFLGNBQUEsTUFBQTJELENBQUEsQ0FBQTNELGNBQUE7O1FBQXNCbUUsSUFBRyxDQUFBSSxJQUFBLEVBQUFDLENBQUEsRUFBQUMsQ0FBQTtVQUN4RSxNQUFPQyxFQUFHLEdBQUdGLENBQUMsQ0FBQWhGLFNBQUEsT0FBQXVELElBQUEsQ0FBQXBFLE1BQUEsQ0FBQTZGLENBQUEsQ0FBQWhGLFNBQUEsR0FBQW1GLE9BQUE7VUFDWixNQUFNQyxFQUFBLEdBQUFILENBQUEsQ0FBQWpGLFNBQUEsT0FBQXVELElBQUEsQ0FBQXBFLE1BQUEsQ0FBQThGLENBQUEsQ0FBQWpGLFNBQUEsR0FBQW1GLE9BQUE7aUJBQ0FDLEVBQUEsR0FBQUYsRUFBQTs7Y0FDS25CLElBQUEsR0FBTyxDQUFBUSxPQUFLLEdBQU1KLENBQUEsQ0FBQUosSUFBQSxjQUFBUSxPQUFBLGNBQUFBLE9BQUE7Y0FBRVgsSUFBQSxJQUFRWSxPQUFFLEdBQUFMLENBQUEsQ0FBQVAsSUFBQSxjQUFBWSxPQUFBLGNBQUFBLE9BQUE7Y0FBTWEsS0FBQSxHQUFBVixJQUFBLENBQUFVLEtBQUEsQ0FBQXRCLElBQUEsRUFBQUEsSUFBQSxHQUFBSCxJQUFBO2NBQzdDMEIsSUFBTSxHQUFFRCxLQUFBLENBQUFULEdBQUEsQ0FBQVcsR0FBQTtVQUNWQyxPQUFBLEVBQUFELEdBQUE7VUFDQUUsR0FBQSxFQUFBRixHQUFBLENBQUEvRjtRQUNGO1FBQWlCLE9BQUEwQyxHQUFBLENBQUFnQixFQUFBO1VBQ2pCbEUsSUFBQSxFQUFPO1lBQ0xzRyxJQUFBO1lBQ0FJLEtBQUk7Y0FDSkMsS0FBQSxFQUFBaEIsSUFBQSxDQUFBaUIsTUFBQTtjQUNKQyxRQUFBO1lBQ0Y7WUFDSTVCLE1BQUE7VUFBQTtRQUNGO01BQ0EsU0FBTXBGLEdBQUE7UUFBRSxJQUFJaUgsWUFBSztRQUFFLE9BQU81RCxHQUFDLENBQUFtQyxXQUFBO1VBQUVDLFVBQVcsTUFBQTVGLFVBQUEsQ0FBQXFILGNBQUEsRUFBQWxILEdBQUE7VUFBRUcsSUFBQSxHQUFBOEcsWUFBQSxHQUFBakgsR0FBQSxhQUFBQSxHQUFBLHVCQUFBQSxHQUFBLENBQUFJLE9BQUEsY0FBQTZHLFlBQUEsY0FBQUEsWUFBQSxHQUFBM0csTUFBQSxDQUFBTixHQUFBO1FBQWdCLEVBQUc7TUFDN0Q7O1FBQzZCO1VBQVFtSCxLQUFBLEVBQUFDLGNBQUEsRUFBQUMsVUFBQTtZQUFZekUsTUFBQSxHQUFBSixTQUFBLENBQUFDLE9BQUE7TUFBRSxNQUFFO1FBQ3JEc0MsSUFBSTtRQUE0QkcsSUFBSSxHQUFFO21CQUFFO1FBQWV2RDtNQUFFLENBQUMsR0FBQzJELENBQUE7TUFDM0QsTUFBTWdDLElBQUEsS0FBUTtVQUNadkcsV0FBTyxFQUFBdUcsSUFBQSxDQUFBQyxJQUFBO1FBQ1BDLElBQUE7VUFDQXpHOzs7VUFHRVksY0FBTyxFQUFBMkYsSUFBQSxDQUFBQyxJQUFBO1lBQUU7Ozs7WUFBZ0RFLFFBQUUsU0FBQTdFLE1BQUEsQ0FBQThFLE1BQUE7YUFBRSxFQUFBOUgsVUFBQSxDQUFBK0gsdUJBQW1COzBCQUFRO1lBQ3hGO2NBQXVCO2NBQVE7Y0FBSztZQUFHeEcsU0FBRztjQUFFeUcsS0FBQSxFQUFTLE1BQUc7Y0FBRUMsT0FBQTtZQUM1RDtVQUNBO1lBQ0loSCxpQkFBSTtVQUNWO1VBQWdCK0QsS0FBTSxFQUFBMEMsSUFBQSxDQUFBUCxNQUFBO1lBQUVlLElBQUk7Y0FBbUJSO1lBQW1CO1VBQWdCO1lBQUlTLFNBQUE7VUFDdEY7UUFBaUI7TUFDakI7WUFDRXRCLElBQUEsR0FBVSxDQUFBVSxLQUFBLElBQUFDLGNBQU0sR0FBQUssUUFBVSxDQUFBdEgsSUFBQSxjQUFBaUgsY0FBQSx1QkFBQUEsY0FBTyxDQUFBWCxJQUFBLGNBQUFVLEtBQUEsY0FBQUEsS0FBQTthQUM3QjlELEdBQUEsQ0FBQWdCLEVBQUE7UUFDSmxFLElBQUE7VUFDSnNHLElBQUEsR0FBQVksVUFBQSxHQUFBWixJQUFBLENBQUFBLElBQUEsY0FBQVksVUFBQSxjQUFBQSxVQUFBO1VBRUhSLEtBQUEsRUFBQUosSUFBQSxDQUFBSSxLQUFBO1VBRU16QixNQUNMO1FBQ007TUFDSjtNQUFZLE9BQU1wRixHQUFFO1VBQWtCZ0ksZUFBRSxFQUFBQyxhQUFjO01BQUUsT0FBQzVFLEdBQUEsQ0FBQW1DLFdBQUE7UUFBRUMsVUFBQSxHQUFBdUMsZUFBQSxHQUFBaEksR0FBQSxDQUFBeUYsVUFBQSxjQUFBdUMsZUFBQSxjQUFBQSxlQUFBO1FBRTdEN0gsSUFBTyxHQUFBOEgsYUFBZ0IsR0FBR2pJLEdBQUEsQ0FBQUksT0FBSyxjQUFBNkgsYUFBQSxjQUFBQSxhQUFBLEdBQUEzSCxNQUFBLENBQUFOLEdBQUE7TUFDN0I7SUFDQTs7UUFFSSxDQUFBZ0QsR0FBQTtRQUNBLHdDQUFNO1lBQ047TUFDSmtGLE1BQUEsRUFBQXhJLGFBQUEsQ0FBQW1GLE1BQUEsQ0FBQUMsTUFBQTtRQUNJbEUsRUFBQSxFQUFBbEIsYUFBQSxDQUFBbUYsTUFBQSxDQUFBTSxNQUFBO01BQ0Y7O1lBRUFoQyxRQUFjLEVBQUFDLElBQUEsRUFBQUMsR0FBQTtVQUFFOEUsTUFBTSxPQUFBdEksVUFBQSxDQUFBMEQsWUFBQTtRQUFPLENBQUE0RSxNQUFBO01BQzdCLE9BQU85RSxHQUFRLENBQUFtQyxXQUFFO1FBQUFDLFVBQUE7UUFDakJ0RixJQUFBLEVBQU87UUFDTDs7UUFFQTtNQUNKLE1BQUFTLEVBQUEsR0FBQXdDLElBQUEsQ0FBQThFLE1BQUEsQ0FBQXRILEVBQUE7TUFFSCxNQUFBd0gsSUFBQSxhQUFBdkksVUFBQSxDQUFBd0ksVUFBQSxFQUFBRixNQUFBLEVBQUF2SCxFQUFBO01BRUQsT0FBTXlDLEdBQUEsQ0FBQWdCLEVBQUE7UUFDSmxFLElBQU8sRUFBR2lJO01BRU47TUFDQSxPQUFBcEksR0FBVTtVQUFFc0ksYUFBUTthQUFrQmpGLEdBQUUsQ0FBQW1DLFdBQUE7UUFBZ0JDLFVBQUMsTUFBQTVGLFVBQUEsQ0FBQXFILGNBQUEsRUFBQWxILEdBQUE7UUFBRUcsSUFBQSxHQUFBbUksYUFBQSxHQUFBdEksR0FBQSxhQUFBQSxHQUFBLHVCQUFBQSxHQUFBLENBQUFJLE9BQUEsY0FBQWtJLGFBQUEsY0FBQUEsYUFBQSxHQUFBaEksTUFBQSxDQUFBTixHQUFBO01BQzVELENBQ0Q7OztRQUdJdUksYUFBVyxHQUFBQSxDQUFBQyxVQUFZLEVBQUFDLEVBQUE7VUFBRSxDQUFBekYsR0FBQTtVQUFpQiwwQ0FBTXdGLFVBQUE7Y0FBd0I7UUFDMUVOLE1BQUEsRUFBQXhJLGFBQUEsQ0FBQW1GLE1BQUEsQ0FBQUMsTUFBQTtVQUNJbEUsRUFBQSxFQUFBbEIsYUFBQSxDQUFBbUYsTUFBQSxDQUFBTSxNQUFBO1FBQ0Y7O2NBRUFoQyxRQUFjLEVBQUFrQyxHQUFBLEVBQUFoQyxHQUFBO1lBQUVrQyxJQUFNLE9BQUExRixVQUFBLENBQUEwRCxZQUFBO1VBQU8sQ0FBQWdDLElBQUE7UUFDN0IsT0FBT2xDLEdBQVEsQ0FBQW1DLFdBQUU7VUFBQUMsVUFBQTtVQUNqQnRGLElBQUEsRUFBTztVQUFrQjs7VUFBcUU7UUFDaEcsTUFBQVMsRUFBQSxHQUFBeUUsR0FBQSxDQUFBNkMsTUFBQSxDQUFBdEgsRUFBQTtRQUVILE1BQUF3SCxJQUFBLFNBQUFLLEVBQUEsQ0FBQWxELElBQUEsRUFBQTNFLEVBQUE7UUFDRixPQUFBeUMsR0FBQSxDQUFBZ0IsRUFBQTtVQUVEbEUsSUFBQSxFQUFjaUk7UUFDZDtNQUNBLFNBQWFwSSxHQUFDO1FBQ2QsSUFBQTBJLGFBQWM7UUFDZCxPQUFhckYsR0FBQyxDQUFBbUMsV0FBWTtVQUVuQkMsVUFDTCxNQUFBNUYsVUFBQSxDQUFBcUgsY0FBQSxFQUFBbEgsR0FBQTtVQUNRRyxJQUFBLEdBQUF1SSxhQUFBLEdBQUExSSxHQUFBLGFBQUFBLEdBQTBDLHVCQUFBQSxHQUFBLENBQUFJLE9BQUEsY0FBQXNJLGFBQUEsY0FBQUEsYUFBQSxHQUFBcEksTUFBQSxDQUFBTixHQUFBO1FBQ2hEO01BQVk7OztlQUE2RCxvQkFBQUgsVUFBQSxDQUFBOEkseUJBQUE7RUFDM0VKLGFBQ08sa0JBQWtCLEVBQUsxSSxVQUFBLENBQUErSSx5QkFBQTtlQUNsQixTQUFHLEVBQUEvSSxVQUFBLENBQUFnSixnQkFBYztlQUNoQixhQUFXLEVBQUFoSixVQUFZLENBQUFpSixvQkFBQTtlQUFFLENBQVUsVUFBSyxFQUFBakosVUFBQSxDQUFBa0osa0JBQUE7UUFBZ0NDLGVBQUE7UUFDL0VDLGlCQUFBO1FBQUFDLGNBQUE7UUFFRkMsZ0JBQWEsR0FBTUMsQ0FBQTtVQUNuQkMsQ0FBQSxHQUFPL0ksTUFBTyxDQUFBOEksQ0FBQSxJQUFBQSxDQUFBLENBQUFFLFdBQUEsUUFBQUMsSUFBQTtVQUFFQyxDQUFBLEdBQU1sSixNQUFBLENBQUE4SSxDQUFBLElBQUFBLENBQUEsQ0FBQUssYUFBQSxRQUFBRixJQUFBO1FBQU8sQ0FBQUYsQ0FBQTtJQUMvQixJQUFFQSxDQUFBLENBQUFLLFFBQWlCO1FBQUFWLGVBQUEsQ0FBQVcsSUFBQSxDQUFBTixDQUFBO1FBQ2pCSixpQkFBVyxDQUFBVSxJQUFZLENBQUFILENBQUE7V0FBRTs7UUFDM0JJLFdBQUEsR0FBQUMsVUFBQTtJQUVILE1BQUFDLElBQUEsR0FBQUMsS0FBQSxDQUFBQyxPQUFBLENBQUFILFVBQUEsSUFBQUEsVUFBQSxHQUFBQSxVQUFBLElBQUFBLFVBQUEsQ0FBQS9DLEtBQUE7SUFFRCxNQUFPbUQsS0FDTCxHQUFBSCxJQUFBLENBQUE5RCxNQUFBLENBQUFvRCxDQUFBLEtBQUFELGdCQUFBLENBQUFDLENBQUE7SUFDRSxJQUFJLENBQUFhLEtBQUUsQ0FBQWxELE1BQUE7SUFDTixNQUFBbUQsZ0JBQVUsR0FBQUQsS0FBQSxDQUFBekQsS0FBQSxHQUFBTixJQUFBLEVBQUFDLENBQUEsRUFBQUMsQ0FBQTtNQUFFLE1BQUtDLEVBQUUsR0FBQUYsQ0FBQSxDQUFBL0UsUUFBQSxPQUFPc0QsSUFBQSxDQUFBeUIsQ0FBTSxDQUFDL0UsUUFBQSxFQUFBa0YsT0FBQTtZQUFLQyxFQUFFLEdBQUFILENBQUEsQ0FBQWhGLFFBQUEsT0FBT3NELElBQUEsQ0FBSzBCLENBQUMsQ0FBQWhGLFFBQUEsRUFBQWtGLE9BQUEsRUFBTSxHQUFDO01BQVUsT0FBQ0MsRUFBQSxHQUFBRixFQUFBO0lBQUU7SUFDMUUsTUFDRDhELFdBQWUsR0FBRUQsZ0JBQWEsQ0FBQUUsSUFBQSxDQUFBaEIsQ0FBQSxJQUFBRixjQUFBLENBQUFTLElBQUEsQ0FBQXJKLE1BQUEsQ0FBQThJLENBQUEsQ0FBQWlCLFVBQUE7SUFDNUIsTUFBTUMsSUFBSSxHQUFHSCxXQUFBLElBQUFELGdCQUFjO0lBQzNCLE9BQUs7TUFBK0JaLFdBQVUsRUFBRWdCLElBQUcsQ0FBQWhCLFdBQUE7TUFBRUcsYUFBTSxFQUFBYSxJQUFBLENBQUFiLGFBQUE7TUFBd0JySSxRQUFBLEVBQUFrSixJQUFBLENBQUFsSixRQUFBO01BQ25GaUosVUFBSSxFQUFBQyxJQUFBLENBQUFELFVBQUE7TUFBQUUsYUFBQSxJQUFBRCxJQUFBLENBQUFDOzs7UUFHY0Msa0JBQU0sR0FBQUMsUUFBQTtRQUFPLENBQUFBLFFBQUE7SUFDL0IsTUFBRWpLLENBQUEsR0FBT0YsTUFBVSxDQUFBbUssUUFBQSxFQUFBQyxLQUFBO1FBQUFsSyxDQUFBO01BQUE4SSxXQUFBLEVBQUE5SSxDQUFBO01BQUFtSyxRQUFBO0lBQUE7V0FDakIsSUFBTzs7UUFBdUZDLGtCQUFBLEdBQUFoRixHQUFBO0lBQ2hHLEtBQUFBLEdBQUE7SUFFSCxJQUFBbUUsS0FBQSxDQUFBQyxPQUFBLENBQUFwRSxHQUFBLFVBQUFBLEdBQUE7SUFFRCxJQUFNO01BRUYsTUFBTWlGLE1BQUEsR0FBQUMsSUFBQSxDQUFBQyxLQUFBLENBQUFuRixHQUFBO01BQ04sT0FBUW1FLEtBQUUsQ0FBQUMsT0FBQSxDQUFBYSxNQUFBLElBQUFBLE1BQUE7TUFBRSxNQUFLO2FBQXVCOzs7UUFHeENHLGVBQWEsR0FBQUMsS0FBQTtJQUNiLE1BQUtDLEtBQU0sR0FBQU4sa0JBQVcsQ0FBV0ssS0FBQyxJQUFBQSxLQUFBLENBQUFFLGFBQUE7VUFBRWxCLEtBQUEsR0FBWWlCLEtBQUcsQ0FBRW5GLEdBQUksQ0FBQXFELENBQUU7TUFBQUUsV0FBQSxFQUFBRixDQUFBLENBQUFnQyxRQUFBO01BQUEzQixhQUFBLEVBQUFMLENBQUEsQ0FBQWlDLFVBQUE7TUFBQWhCLFVBQUE7SUFBQSxJQUF3QnJFLE1BQUEsQ0FBQW9ELENBQUEsS0FBQUQsZ0JBQUEsQ0FBQUMsQ0FBQTtJQUNuRixJQUFJLENBQUFhLEtBQUEsQ0FBQWxELE1BQUE7VUFBQXVELElBQUEsR0FBQUwsS0FBQTtXQUNGO01BQ0FYLFdBQVUsRUFBR2dCLElBQUEsQ0FBQWhCLFdBQU07TUFDbkJHLGFBQWEsRUFBQ2EsSUFBQSxDQUFBYixhQUFBO2dCQUFRO01BQUtjLGFBQUU7TUFDN0JuSixRQUFPLEVBQVE2SixLQUFFLENBQUFLLFNBQUE7TUFBQWxHLE1BQUE7OztRQUM2RW1HLGNBQUEsU0FBQUEsQ0FBQTNJLE1BQUEsRUFBQTRJLFVBQUE7SUFDaEcsS0FBQUEsVUFBQSxDQUFBekUsTUFBQTtJQUVIO01BRUQsTUFBVWQsQ0FDUixTQUFBckQsTUFBQSxDQUFBOEUsTUFBQTtRQUNNK0QsS0FBRSxFQUFBN0wsVUFBQSxDQUFBOEwsMEJBQUE7UUFDTkMsa0JBQVU7UUFBRXhMLElBQU0sRUFBRTtVQUFnQjRFLElBQUEsRUFBUXlHLFVBQUUsQ0FBQXpFLE1BQUE7VUFBaUJuQyxLQUFBO1lBQUFnSCxLQUFBO2NBQUFqTCxVQUFBLEVBQUE2SztZQUFBO1VBQUE7UUFBRTtNQUVuRTtNQUNFLE1BQU0vRSxJQUFJLEdBQUdSLENBQUEsSUFBQUEsQ0FBQSxDQUFBOUYsSUFBQSxJQUFBOEYsQ0FBQSxDQUFBOUYsSUFBQSxDQUFBc0csSUFBYSxJQUFDUixDQUFBLENBQUE5RixJQUFBLENBQUFzRyxJQUFBLENBQUFBLElBQUE7TUFDM0IsTUFBS29GLEdBQU07TUFBeUIsTUFBQUMsR0FBQSxHQUFZcEgsSUFBRyxDQUFBb0gsR0FBQTtNQUFFckYsSUFBSSxDQUFBc0YsT0FBRSxDQUFBQyxDQUFBO1FBQXdCLE1BQUFDLENBQUEsR0FBQUQsQ0FBQSxDQUFBckYsT0FBQTtRQUMvRSxNQUFBdUYsU0FBQSxHQUFBRCxDQUFBLENBQUFFLFVBQUEsT0FBQXpILElBQUEsQ0FBQXVILENBQUEsQ0FBQUUsVUFBQSxFQUFBN0YsT0FBQTtRQUNGLElBQU13RixHQUFBLEdBQUFJLFNBQWdCLEdBQUF0TSxVQUFnQyxDQUFBd00sMkJBQVEsSUFBQUgsQ0FBQSxDQUFBdEwsVUFBQTtVQUM5RGtMLEdBQU0sQ0FBQUksQ0FBQSxDQUFJdEwsVUFBUyxJQUFBc0wsQ0FBQSxDQUFBSSxZQUFBO1FBQ25CO1FBQWdCO01BQVcsT0FBRVIsR0FBQTtJQUMvQixDQUFDLENBQUM7TUFBaUI7OztRQUM2RVMsZUFBQSxTQUFBQSxDQUFBMUosTUFBQSxFQUFBbkMsUUFBQSxFQUFBOEwsT0FBQTtJQUNoRyxNQUFBQyxHQUFBO0lBRUgsTUFBQVYsR0FBQSxPQUFBcEgsSUFBQSxHQUFBQyxXQUFBO0lBRUQ4SCxNQUFPLENBQUFGLE9BQUksQ0FBQUEsT0FBQSxFQUFBUixPQUFBLEdBQUFwTCxVQUFBLEVBQUEwTCxZQUFBO01BQUVHLEdBQUksQ0FBRWpGLElBQUE7UUFBQWtFLEtBQUE7VUFBQWlCLE1BQUEsRUFBQTlNLFVBQStCLENBQUE4TCwwQkFBQTtVQUFBOUUsR0FBQSxFQUFBakc7UUFBQTtNQUFBO01BQUU2TCxHQUFBLENBQUFqRixJQUFVO1FBQUE1RyxVQUFBO1FBQUEwTCxZQUFBO1FBQUFGLFVBQUEsRUFBQUwsR0FBQTtRQUFBcEwsU0FBQSxFQUFBRCxRQUFBO01BQUE7SUFBTyxDQUFFO0lBQ3JFLElBQUksQ0FBQStMLEdBQUEsQ0FBQXpGLE1BQUE7UUFBQTtNQUNGLE1BQU1uRSxNQUFNLENBQUErSixJQUFHO1FBQUFDLE9BQVUsT0FBUTtRQUFBek0sSUFBQSxFQUFBcU07TUFBQTtNQUNqQyxPQUFNSyxDQUFBO01BRU5DLE9BQU0sQ0FBQUMsSUFBQSw0Q0FBa0MsRUFBQUYsQ0FBQSxJQUFBQSxDQUFBLENBQUF6TSxPQUFBOzs7K0JBSTdCLFNBQUE0TSxDQUFBQyxJQUFBLEVBQUF6TCxXQUFBO2FBQ1AsS0FBQUEsV0FBa0IsU0FBSTs7WUFDYjBMLE1BQUEsR0FBUyxNQUFFLElBQUFwTixvQkFBQSxDQUFBcU4sb0JBQUEsRSxNQUFFLEtBQUssRSxpQ0FBbUIzTCxXQUFBLHlCLFNBQVEsRTtRQUFFNEwsZ0JBQUU7TUFBQSxDO1lBQ2pEQyxTQUFTLEdBQUdILE1BQUEsSUFBQW5ELEtBQUEsQ0FBQUMsT0FBQSxDQUFBa0QsTUFBQSxDQUFBcEcsS0FBQSxLQUFBb0csTUFBQSxDQUFBcEcsS0FBQTtVQUFFLENBQUN1RyxTQUFBO1lBQ3hCQyxNQUFNLGFBQUF4TixvQkFBQSxDQUFBcU4sb0JBQUEsRSxJQUNKLE9BQU8sRSxZQUFPRSxTQUFFLENBQUF6TSxFQUFBLHVGLFNBQUUsRTt3QkFBNEI7TUFBQSxDO1lBQUt3SSxDQUFDLEdBQUFrRSxNQUFBLElBQUF2RCxLQUFBLENBQUFDLE9BQUEsQ0FBQXNELE1BQUEsQ0FBQXhHLEtBQUEsS0FBQXdHLE1BQUEsQ0FBQXhHLEtBQUE7WUFDcEQsYUFBYTs7bUJBQVcsRUFBS3NDLENBQUEsQ0FBRW1FLFdBQUEsUUFBZ0I7Z0JBQUUsQ0FBQUMsSUFBSSxJQUFFcEUsQ0FBQSxDQUFBcUUsaUJBQUE7bUJBQUcsRUFBQXJFLENBQUEsQ0FBQXFFLGlCQUFBLEdBQUFuTixNQUFBLENBQUE4SSxDQUFBLENBQUFxRSxpQkFBQSxFQUFBQyxLQUFBLFdBQUF0RSxDQUFBLENBQUFtRSxXQUFBO2tCQUFHLEVBQUFuRSxDQUFBLENBQUF1RSxVQUFBO2dCQUM3RCxFQUFBdkUsQ0FBQSxDQUFBd0UsUUFBVzs7O2lCQUFtQzs7O2dDQUM1QixTQUFBWCxJQUFBO3NCQUFPLENBQUU7a0JBQWM7Ozs7WUFFN0M7UUFDQTtNQUVGLE1BQUloSCxDQUFBLFdBQWMsRUFBQW5HLG9CQUFJLENBQUErTixlQUFBLEVBQUFaLElBQUEsRUFBQXJJLEtBQUE7TUFDdEIsTUFBSWtCLElBQUEsR0FBQUcsQ0FBVyxJQUFJQSxDQUFBLENBQUE2SCxPQUFBO01BQ25CLE1BQUkvSCxHQUFBLElBQVM7TUFDYkQsSUFBSSxDQUFBaUcsT0FBQSxDQUFBZ0MsR0FBWSxJQUFJO1FBQ3BCLElBQUlBLEdBQUEsSUFBQUEsR0FBVSxDQUFHQyxRQUFDLEVBQUFqSSxHQUFBLENBQUFnSSxHQUFBLENBQUFDLFFBQUEsSUFBQUQsR0FBQTtNQUNsQjthQUFJaEksR0FBQTthQUNGOEcsQ0FBTSxFQUFDO2FBQ1UsQ0FBQUUsSUFBTyw4Q0FBd0IsRUFBQUYsQ0FBQSxJQUFBQSxDQUFBLENBQUF6TSxPQUFBO2FBQUU7OztRQUNzQixDQUFDNk4sSUFDdkU7VUFBZSxpQ0FBTztZQUFnQztVQUEyQixFQUNqRnZPLGFBQWEsQ0FBQW1GLE1BQUEsQ0FBQUMsTUFBQTtnQkFBTyxFQUFFcEYsYUFBQSxDQUFBbUYsTUFBQSxDQUFBcUosT0FBQSxDQUFpQ3hPLGFBQUEsQ0FBQW1GLE1BQW9CLENBQUFDLE1BQUE7VUFDM0VuRSxVQUFPLEVBQUFqQixhQUFPLENBQUFtRixNQUFBLENBQUFNLE1BQUE7VUFDWnRFLGlCQUFPLEVBQUFuQixhQUFBLENBQUFtRixNQUF1QixDQUFBRyxLQUFBLENBQUF0RixhQUFBLENBQUFtRixNQUFBLENBQUFNLE1BQUE7VUFDOUI1RCxhQUFBLEVBQUE3QixhQUF3QixDQUFBbUYsTUFBQSxDQUFBRyxLQUFBLENBQUF0RixhQUFBLENBQUFtRixNQUFBLENBQUFNLE1BQUE7UUFDeEIsRTtxQkFFUyxFQUFBekYsYUFBQSxDQUFBbUYsTUFBQSxDQUFBRyxLQUFBLENBQUF0RixhQUFBLENBQUFtRixNQUFBLENBQUFzSixPQUFBOzs7bUJBRVEsRUFBQTlJLEdBQUssRUFBRWhDLEdBQUE7cUJBQUV4RCxVQUFXLENBQUEwRCxZQUFBO3lDQUFNLENBQUFFLHNCQUFBO3NCQUFVOzRCQUFFO1FBQUFnQyxVQUFBO1FBQUF0RixJQUFBO01BQUE7O2dCQUNuRCxHQUFBcUMsU0FBQSxDQUFBQyxPQUFBO2tCQUNELEdBQUE0QyxHQUFBLENBQUFsRixJQUFBLENBQUFpTyxRQUFBO3NCQUNELEtBQUEvSSxHQUFrQixDQUFBbEYsSUFBQSxDQUFBa08sYUFBQTtVQUNwQkMsTUFBQTtVQUNBQyxPQUNGO1VBRUZDLE1BQUEsR0FBV0MsWUFBQSxjQUFJbEQsY0FBTyxDQUFBM0ksTUFBQSxFQUFBd0wsUUFBQSxDQUFBckksR0FBQSxDQUFBdkYsQ0FBQSxJQUFBQSxDQUFBLENBQUFHLFVBQVI7WUFDZCxDQUFBb0wsT0FBUyxDQUFBdkwsQ0FBQTtVQUNUZ08sTUFBQSxDQUFBaE8sQ0FBQSxDQUFBRyxVQUFZLE1BQUErTixTQUFBO1FBQ1pKLE1BQUEsQ0FBQTlOLENBQUEsQ0FBQUcsVUFBVSxJQUFBNk4sTUFBQSxDQUFBaE8sQ0FBQSxDQUFBRyxVQUFBO01BSVosQ0FBQyxNQUFDO1FBQ0E0TixPQUFBLENBQUFoSCxJQUFBLENBQUEvRyxDQUFBO01BQUE7TUFHRjtRQUVBK04sT0FBTSxDQUFBeEgsTUFBQTtNQUNOLE1BQU00SCxVQUFBLEdBQWEsTUFDakJDLHdCQUEwQixDQUFBM0IsSUFBQTtNQUs1QixNQUFJNEIsV0FBQSxJQUFpQjtNQUNyQixJQUFJQyxNQUFBO01BQ0osTUFBSUMsVUFBQSxHQUFhO01BRWpCLE1BQUlDLElBQUssR0FBRyxNQUFBQSxDQUFBLEtBQWE7UUFDekIsT0FBSUYsTUFBMkIsR0FBR1AsT0FBTyxDQUFBeEgsTUFBQTtVQUV6QyxNQUFVa0ksQ0FBQSxHQUFHSCxNQUFBO1VBQ1QsTUFBS3RPLENBQUEsR0FBSytOLE9BQUssQ0FBQVUsQ0FBSTtVQUNyQixJQUFJQyxLQUFBO1VBRUYsTUFBTUMsVUFBVSxHQUFDUixVQUFRLENBQUFuTyxDQUFBLENBQUFHLFVBQUE7VUFDekIsSUFBQXdPLFVBQU0sRUFBVUQsS0FBRyxHQUFJbEUsZUFDckIsQ0FBQW1FLFVBQUEsQ0FBbUI7Y0FHbkIsQ0FBQUQsS0FBQSxJQUFVM0osSUFBRyxFQUFLO1lBQ2xCO2NBQ0EsTUFBQTZDLElBQVUsR0FBRyxRQUFVLEVBQ3BCdkksVUFDQSxDQUFJaUosb0JBQVcsRUFBQXZELElBQUEsRUFBQS9FLENBQUEsQ0FBQUcsVUFBQTtjQUNkLE1BQU0ySixJQUFFLEdBQUtWLFdBQVMsQ0FBR3hCLElBQUk7Y0FDN0IsSUFBQWtDLElBQVEsRUFBQTRFLEtBQUs7Z0JBQUEsR0FBUzVFLElBQUc7Z0JBQUlsRixNQUFLO2NBQVM7Y0FDM0MsT0FBTzs7Y0FJWDVFLENBQUEsQ0FBQWUsYUFBd0MsSUFBQTBMLElBQUE7WUFDeEMsTUFBTW1DLFFBQUEsR0FBaUMsTUFBS3BDLHVCQUFBLENBQUFDLElBQUEsRUFBQXpNLENBQUEsQ0FBQWUsYUFBQTtZQUM1QyxJQUFBNk4sUUFBTSxFQUErQjtjQUNyQ0YsS0FBQSxHQUFVO2dCQUNSNUYsV0FBVyxFQUFBOEYsUUFBUyxDQUFBOUYsV0FBZSxJQUFBNEYsS0FBVSxJQUFBQSxLQUFBLENBQUE1RixXQUFBO2dCQUM3Q0csYUFBYSxFQUFLeUYsS0FBSSxJQUFLQSxLQUFLLENBQUF6RixhQUFBO2dCQUNoQzhELFdBQVcsRUFBQTZCLFFBQVMsQ0FBQTdCLFdBQWM7Z0JBQ2xDOEIsS0FBTSxFQUFHRCxRQUFJLENBQUtDLEtBQUk7Z0JBQ3RCMUIsVUFBVyxFQUFBeUIsUUFBUyxDQUFBekIsVUFBYTtnQkFDakNDLFFBQVUsRUFBRXdCLFFBQUssQ0FBQXhCLFFBQVk7Z0JBQzdCeE0sUUFBUSxFQUFHOE4sS0FBTSxJQUFHQSxLQUFBLENBQUE5TixRQUFjO2dCQUNsQ2lKLFVBQVcsRUFBRzZFLEtBQUMsSUFBUUEsS0FBRyxDQUFBN0UsVUFBVTtnQkFDcENFLGFBQUEsRUFBQTJFLEtBQUEsSUFBQUEsS0FBQSxDQUFBM0UsYUFBQTtnQkFDRm5GLE1BQUEsRUFBVztjQUFzRDs7O2NBQ00sQ0FBQThKLEtBQUc7a0JBQUVJLEVBQUEsR0FBQTlFLGtCQUFBLENBQUFoSyxDQUFBLENBQUFLLGlCQUFBO1lBQVUsSUFBR3lPLEVBQUEsRUFBQUosS0FBQTtjQUFBLEdBQUFJLEVBQUE7Y0FBQWxLLE1BQUE7WUFBQTs7b0JBR3ZGLENBQUE1RSxDQUFBLENBQUFHLFVBQUEsSUFBQXVPLEtBQUE7Z0JBQ0MsQ0FBQTFPLENBQUEsQ0FBQUcsVUFBQSxJQUFBdU8sS0FBQTs7O21CQUdELENBQUFLLEdBQUEsQ0FBQXhGLEtBQUEsQ0FBQTdFLElBQUE7UUFBQTZCLE1BQUEsRUFBQXlJLElBQUEsQ0FBQUMsR0FBQSxDQUFBWixXQUFBLEVBQUFOLE9BQUEsQ0FBQXhILE1BQUE7TUFBQSxHQUFBaUksSUFBQTtZQUNGdk8sUUFBRyxHQUFBOEUsSUFBQSxHQUFBQSxJQUFBLENBQUE5RSxRQUFBLEdBQUF3TSxJQUFBLEdBQUFBLElBQUEsQ0FBQXhNLFFBQUE7MEJBQ1UsQ0FBQW1DLE1BQUEsRUFBVW5DLFFBQ3BCLEVBQUNzTyxVQUFROztVQUlkVyxPQUFBO1VBQUEsQ0FBQUMsTUFBQSxDQUFBckIsTUFBQSxFQUFBdkMsT0FBQSxDQUFBNkQsQ0FBQTtNQUVKLE1BQUEzRCxDQUFBLEdBQUEyRCxDQUFBLElBQUFBLENBQUEsQ0FBQXhLLE1BQUE7TUFFQXNLLE9BQUksQ0FBQXpELENBQUEsS0FBQXlELE9BQUEsQ0FBaUN6RCxDQUFBLEtBQUcsQ0FBSTtNQUM1QztXQUVBNUksR0FBTSxDQUFBZ0IsRUFBSTtNQUNWbEUsSUFBSTtRQUNGMkcsS0FBSSxFQUFBd0gsTUFBQTtZQUNGO1VBQ0F6SCxLQUFBLEVBQU91SCxRQUFHLENBQUFySCxNQUFBO1VBQ1Y4SSxVQUFVLEVBQUF6QixRQUFHLENBQUFySCxNQUFjLEdBQUN3SCxPQUFJLENBQUF4SCxNQUFBO1VBQ2hDK0ksT0FBQSxFQUFBdkIsT0FBQSxDQUFBeEgsTUFBcUI7VUFDdkIySTtRQUNBOzs7O1lBSUU7UUFDRjtZQUNGO01BRUE5SyxLQUFBLEVBQU9sRixhQUFPLENBQUFtRixNQUFBLENBQUFDLE1BQUE7UUFDWmlMLEdBQUEsRUFBSXJRLGFBQUUsQ0FBQW1GLE1BQUEsQ0FBQUcsS0FBQSxDQUFBdEYsYUFBQSxDQUFBbUYsTUFBQSxDQUFBSSxNQUFBOzs7WUFHSjlCLFFBQUEsRUFBV2tDLEdBQUUsRUFBQWhDLEdBQUE7VUFDYmtDLElBQUEsS0FBUyxFQUFFMUYsVUFBQSxDQUFBMEQsWUFBZTthQUMxQixTQUFTRixHQUFBLENBQUFtQyxXQUFhO2dCQUN0QjtVQUNBOzs7VUFHQXdLLElBQUE7WUFDQUQsR0FBQSxJQUFBQyxJQUFBLEdBQUEzSyxHQUFBLENBQW9CVCxLQUFFLENBQUFtTCxHQUFBLE1BQVUsUUFBQUMsSUFBQSxjQUFBQSxJQUFBO1lBQ2hDNUgsSUFBQSxhQUFBdkksVUFBNEIsQ0FBQW9RLHNCQUFrQixFQUFBMUssSUFBQSxFQUFBd0ssR0FBQTthQUM5QzFNLEdBQUEsQ0FBQWdCLEVBQUE7WUFDQSxFQUFBK0Q7O2FBRUZwSSxHQUFBO01BQ0YsSUFBRWtRLGFBQUE7TUFDRixPQUFPN00sR0FBUSxDQUFBbUMsV0FBRTtRQUFBQyxVQUFBLE1BQUE1RixVQUFBLENBQUFxSCxjQUFBLEVBQUFsSCxHQUFBO1FBQ2pCRyxJQUFBLEVBQU8sQ0FBQStQLGFBQWUsR0FBQ2xRLEdBQUEsYUFBQUEsR0FBQSx1QkFBQUEsR0FBQSxDQUFBSSxPQUFBLGNBQUE4UCxhQUFBLGNBQUFBLGFBQUEsR0FBQTVQLE1BQUEsQ0FBQU4sR0FBQTtRQUNyQjs7O1FBR0osQ0FBQWdELEdBQUE7SUFDQUMsSUFBQTtJQUVGQyxRQUFVLEVBQ1I7TUFDRTBCLEtBQU0sRUFBQWxGLGFBQUEsQ0FBQW1GLE1BQUEsQ0FBQUMsTUFBQTtRQUNOaUwsR0FBQSxFQUFRclEsYUFBRSxDQUFBbUYsTUFBQSxDQUFBRyxLQUFBLENBQUF0RixhQUFBLENBQUFtRixNQUFBLENBQUFJLE1BQUE7TUFDUjs7WUFFTTlCLFFBQUUsRUFBQWtDLEdBQUEsRUFBQWhDLEdBQUEsS0FBTztVQUNia0MsSUFBTSxHQUFFLElBQUExRixVQUFBLENBQUEwRCxZQUFhO1FBQ3RCLENBQUFnQyxJQUFBLFNBQUFsQyxHQUFBLENBQUFtQyxXQUFBO01BQ0hDLFVBQUE7TUFFRnRGLElBQUEsRUFBTztJQUNMO0lBQ0EsSUFBSTtNQUNGLElBQUFnUSxLQUFNO01BQ04sTUFBS0osR0FBSSxHQUFFLENBQUFJLEtBQU8sR0FBRzlLLEdBQUMsQ0FBQVQsS0FBQSxDQUFBbUwsR0FBWSxjQUFBSSxLQUFBLGNBQUFBLEtBQUE7WUFBRS9ILElBQUEsR0FBVSxNQUFLLElBQUF2SSxVQUFBLENBQUF1USxnQkFBQSxFQUFBN0ssSUFBQSxFQUFBd0ssR0FBQTthQUFNMU0sR0FBRSxDQUFBZ0IsRUFBQTtRQUF3QmxFLElBQUEsRUFBQWlJO01BQ25GO2FBQUlwSSxHQUFBO1VBQ0ZxUSxhQUFjO2FBR2RoTixHQUFNLENBQUFtQyxXQUFJO1FBQ1ZDLFVBQVUsTUFBQTVGLFVBQUksQ0FBQ3FILGNBQUksRUFBQWxILEdBQUE7UUFDbkJHLElBQUEsRUFBTSxDQUFBa1EsYUFBSSxHQUFBclEsR0FBSSxLQUFLLFFBQUFBLEdBQUEsdUJBQUFBLEdBQUEsQ0FBQUksT0FBQSxNQUFNLFFBQUFpUSxhQUFBLGNBQUFBLGFBQUEsR0FBQS9QLE1BQUEsQ0FBQU4sR0FBQTtRQUN6Qjs7O1lBQzJDO2dEQUN6QjtZQUNoQjswQkFBZ0QsQ0FBQTZFLE1BQUEsQ0FBQUMsTUFBQTthQUFJcEYsYUFBQSxDQUFBbUYsTUFBQSxDQUFBRyxLQUFBLENBQUF0RixhQUFBLENBQUFtRixNQUFBLENBQUFJLE1BQUE7OztZQUV0RDlCLFFBQVcsRUFBR2tDLEdBQUEsRUFBQWhDLEdBQUE7VUFDWmtDLElBQUksR0FBRSxJQUFBMUYsVUFBQSxDQUFBMEQsWUFBQTthQUNKLFNBQUlGLEdBQUEsQ0FBQW1DLFdBQUE7Z0JBQ0osRUFBSyxHQUFFOzs7O2VBQ1A7WUFDRnVLLEdBQUEsSUFBQU8sS0FBQSxHQUFBakwsR0FBQSxDQUFBVCxLQUFBLENBQUFtTCxHQUFBLGNBQUFPLEtBQUEsY0FBQUEsS0FBQTtZQUNBbEksSUFBQSxhQUFBdkksVUFBQSxDQUFBMFEsa0JBQUEsRUFBQWhMLElBQUEsRUFBQXdLLEdBQUE7TUFDSixPQUFFMU0sR0FBTyxDQUFBZ0IsRUFBUSxDQUFFO1FBQUFsRSxJQUFBLEVBQUFpSTtRQUNqQjthQUNFcEksR0FBQTtVQUNBd1EsYUFBSTthQUNKbk4sR0FBQSxDQUFBbUMsV0FBQTtRQUNKQyxVQUFBLE1BQUE1RixVQUFBLENBQUFxSCxjQUFBLEVBQUFsSCxHQUFBO1FBQ0ZHLElBQUEsR0FBQXFRLGFBQUEsR0FBQXhRLEdBQUEsYUFBQUEsR0FBQSx1QkFBQUEsR0FBQSxDQUFBSSxPQUFBLGNBQUFvUSxhQUFBLGNBQUFBLGFBQUEsR0FBQWxRLE1BQUEsQ0FBQU4sR0FBQTtNQUNBLEVBQUk7OztRQUVGLENBQUFnRCxHQUFNO1FBQUUsK0RBQVM7WUFBTTtNQUFLa0YsTUFBSyxFQUFBeEksYUFBQSxDQUFBbUYsTUFBQSxDQUFBQyxNQUFBO1FBQ2pDMkwsUUFBTSxFQUFBL1EsYUFBaUIsQ0FBQW1GLE1BQU8sQ0FBQU0sTUFBTzs7O1lBRy9CaEMsUUFBRSxFQUFBa0MsR0FBQSxFQUFBaEMsR0FBQTtVQUNKa0MsSUFBSSxPQUFBMUYsVUFBQSxDQUFBMEQsWUFBQTthQUNKLEVBQUksT0FBQUYsR0FBQSxDQUFBbUMsV0FBQTtnQkFDRSxFQUFDO1lBQUU7OztZQUE2QmlMLFFBQUEsR0FBQXBMLEdBQUEsQ0FBQTZDLE1BQUEsQ0FBQXVJLFFBQUE7WUFDdENySSxJQUFLLEdBQUUsVUFBQXZJLFVBQUEsQ0FBQTZRLDBCQUFBLEVBQUFuTCxJQUFBLEVBQUFrTCxRQUFBO2FBQUVwTixHQUFBLENBQUFnQixFQUFBO1lBQWMsRUFBQStEO1FBQ3pCO01BQ0YsT0FBRXBJLEdBQUE7TUFDRixJQUFBMlEsYUFBVTtNQUNWLE9BQU90TixHQUFHLENBQUNtQyxXQUFHO1FBQUVDLFVBQU0sTUFBQTVGLFVBQUEsQ0FBQXFILGNBQUEsRUFBQWxILEdBQUE7WUFBRSxFQUFJLENBQUEyUSxhQUFBLEdBQUUzUSxHQUFBLEtBQUssSUFBSSxJQUFBQSxHQUFBLHVCQUFBQSxHQUFBLENBQUFJLE9BQUEsVUFBSSxJQUFFdVEsYUFBQSxjQUFBQSxhQUFBLEdBQUFyUSxNQUFBLENBQUFOLEdBQUE7Ozs7UUFBeUMsQ0FBQWdELEdBQUE7SUFDeEZDLElBQUUsOEJBQWlCO1lBQUE7WUFDakJSLE9BQVcsRUFBQVcsSUFBQSxFQUFBQyxHQUFZO1FBQ3JCO1VBQ0F1TixNQUFJLEVBQUFDLGlCQUFLLEVBQUNDLGFBQU8sRUFBQUMsa0JBQUEsRUFBQUMsY0FBQSxFQUFBQyxxQkFBVyxFQUFBQyxlQUFHLEVBQUFDLGdCQUFBLEVBQUFDLG1CQUFBLEVBQUFDLFdBQUEsRUFBQUMscUJBQUEsRUFBQUMsaUJBQUEsRUFBQUMscUJBQUEsRUFBQUMsZUFBQSxFQUFBQyxxQkFBQSxFQUFBQyxhQUFBO01BQ2pDLE1BQUUvTyxNQUFBLEdBQUFKLFNBQUEsQ0FBQUMsT0FBQTtNQUNKLE1BQUFtUCxTQUFBLE9BQUFsTixJQUFBLENBQUFBLElBQUEsQ0FBQW9ILEdBQUEsOEJBQUFuSCxXQUFBO01BRUgsTUFBQWtOLFdBQUEsU0FBQWpQLE1BQUEsQ0FBQThFLE1BQUE7UUFFSytELEtBQ0osRUFBQTdMLFVBQUEsQ0FBQStILHVCQUFBO1FBQ01nRSxrQkFBRTtRQUNOeEwsSUFBUSxFQUFFO1VBQ1I0RSxJQUFPO1VBQ0wrTSxnQkFBSztVQUNONUwsSUFBQTtZQUNIL0UsU0FBQTtjQUVLeUcsS0FBQSxFQUFRLE1BQU87Y0FDZEMsT0FBUztZQUNWO1VBQ0g7VUFDRWpELEtBQUE7WUFDSW1ELFNBQUU7VUFDTjtVQUNKZ0ssSUFBQTtZQUNJQyxLQUFBO2NBQUFwRyxLQUFBO2dCQUNPcUcsS0FBQSxlQUFhO2dCQUNabE4sSUFBRztjQUNOO1lBQWE7WUFBU21OLFdBQUE7Y0FDdEJ0RyxLQUFjO2dCQUNmcUcsS0FBQTtnQkFBUWxOLElBQUE7Y0FBRTtZQUFTO1lBQ3pCb04sU0FBVztjQUFjdkcsS0FBVSxFQUFFO2dCQUFRcUcsS0FBQTtnQkFBT2xOLElBQUE7Y0FDdEQ7WUFFSDtZQUVTcU4sT0FDUjtjQUNReEcsS0FBQTtnQkFDSXFHLEtBQUE7Z0JBQ0RsTixJQUFBO2NBQ0E7WUFDTjtVQUNIO1FBRUY7TUFDRTtNQUNBLElBQUtzTixjQUFRO01BQ1gsSUFBQUMsV0FBVztVQUNUQyxTQUFVLEdBQUUsQ0FBRztVQUNmQyxZQUFNO01BQ1IsSUFBRUMsVUFBQTtNQUNKO1FBQ0ksSUFBQUMsTUFBQSxFQUFBQyxRQUFBLEVBQUFDLE9BQUEsRUFBQUMsUUFBQSxFQUFBQyxPQUFBLEVBQUFDLFFBQUEsRUFBQUMsT0FBQSxFQUFBQyxXQUFBLEVBQUFDLElBQUEsRUFBQUMsaUJBQUEsRUFBQUMsY0FBQSxFQUFBQyxlQUFBO1FBQUEsT0FBQUMsRUFBQSxFQUFBQyxFQUFBLEVBQUFDLEVBQUEsRUFBQUMsS0FBQSxFQUFBQyxRQUFBLFVBQUFDLE9BQUEsQ0FBQXBFLEdBQUEsRUFBQTNNLE1BQUEsQ0FBQWdSLEtBQUE7VUFDRm5JLEtBQVMsRUFBQTdMLFVBQUksQ0FBQWlVLHdCQUFrQztVQUMvQ2xJLGtCQUFtQjtRQUNuQixJQUFBL0ksTUFBVyxDQUFFZ1IsS0FBQztVQUFFbkksS0FBTSxFQUFBN0wsVUFBQSxDQUFBa1UscUJBQUE7VUFBT25JLGtCQUFBO1FBQzdCLElBQUEvSSxNQUFxQixDQUFBZ1IsS0FBQTtVQUNyQm5JLEtBQU0sRUFBQTdMLFVBQUEsQ0FBQW1VLDhCQUFBO1VBQUVwSSxrQkFBTTtRQUFFLElBQUEvSSxNQUFBLENBQUFnUixLQUFBO1VBQVNuSSxLQUFBLEVBQUE3TCxVQUFnQixDQUFBb1UsK0JBQUE7VUFDekNySSxrQkFBc0IsRUFBQztRQUFFLElBQUEvSSxNQUFVLENBQUE4RSxNQUFFLENBQU07VUFBRStELEtBQUEsRUFBQTdMLFVBQUEsQ0FBQStILHVCQUFBO1VBQU9nRSxrQkFBQTtVQUN0RHhMLElBQUE7WUFFSDRFLElBQUE7WUFFTUgsS0FDTDtjQUNRa0QsSUFBQTtnQkFDSTlCLE1BQUE7a0JBQ0ZpTyxLQUFBO29CQUNHOVMsU0FBQTtzQkFDRytTLEVBQUEsRUFBQXRDO29CQUNYO2tCQUNIO2dCQUVLO2NBQ0M7WUFDRDtZQUNIRSxnQkFBc0IsRUFBQztVQUNyQjtRQUNBLElBQUk7UUFDSk8sY0FBQSxJQUFBSyxNQUFBLElBQUFDLFFBQUEsR0FBQVcsRUFBQSxDQUFBblQsSUFBQSxjQUFBd1MsUUFBQSx1QkFBQUEsUUFBQSxDQUFBaUIsS0FBQSxjQUFBbEIsTUFBQSxjQUFBQSxNQUFBO1FBQ0pKLFdBQUEsSUFBQU0sT0FBQSxJQUFBQyxRQUFBLEdBQUFVLEVBQUEsQ0FBQXBULElBQUEsY0FBQTBTLFFBQUEsdUJBQUFBLFFBQUEsQ0FBQWUsS0FBQSxjQUFBaEIsT0FBQSxjQUFBQSxPQUFBO1FBQ0lMLFNBQUEsSUFBQU8sT0FBQSxJQUFBQyxRQUFBLEdBQUFTLEVBQUEsQ0FBQXJULElBQUEsY0FBQTRTLFFBQUEsdUJBQUFBLFFBQUEsQ0FBQWEsS0FBQSxjQUFBZCxPQUFBLGNBQUFBLE9BQUE7UUFDRk4sWUFBTSxJQUFBUSxPQUFBLElBQUFDLFdBQUEsR0FBQVEsS0FBQSxDQUFBdFQsSUFBQSxjQUFBOFMsV0FBQSx1QkFBQUEsV0FBQSxDQUFBVyxLQUFBLGNBQUFaLE9BQUEsY0FBQUEsT0FBQTtRQUFFUCxVQUFLLElBQUFTLElBQUEsSUFBQUMsaUJBQUEsSUFBQUMsY0FBQSxHQUFBTSxRQUFBLENBQUF2VCxJQUFBLGNBQUFpVCxjQUFBLGdCQUFBQSxjQUFBLEdBQUFBLGNBQUEsQ0FBQTNNLElBQUEsY0FBQTJNLGNBQUEsZ0JBQUFBLGNBQUEsR0FBQUEsY0FBQSxDQUFBdk0sS0FBQSxjQUFBdU0sY0FBQSx1QkFBQUEsY0FBQSxDQUFBdE0sS0FBQSxjQUFBcU0saUJBQUEsY0FBQUEsaUJBQUEsSUFBQUUsZUFBQSxHQUFBSyxRQUFBLENBQUF2VCxJQUFBLGNBQUFrVCxlQUFBLGdCQUFBQSxlQUFBLEdBQUFBLGVBQUEsQ0FBQTVNLElBQUEsY0FBQTRNLGVBQUEsdUJBQUFBLGVBQUEsQ0FBQXhNLEtBQUEsY0FBQXFNLElBQUEsY0FBQUEsSUFBQTtRQUFFO1FBQVU7TUFBQTtNQUV6QixNQUFNaUIsUUFBTyxJQUFBdkQsTUFBTSxJQUFBQyxpQkFBQSxHQUFBZ0IsV0FBZSxDQUFBMVIsSUFBQyxNQUFRLElBQUssSUFBRTBRLGlCQUFrQix1QkFBQUEsaUJBQUEsQ0FBQXBLLElBQUEsY0FBQW1LLE1BQUEsY0FBQUEsTUFBQTtNQUNwRSxNQUFNbUIsSUFBQSxJQUFRakIsYUFBUyxHQUFPLENBQUVDLGtCQUFBLEdBQUljLFdBQUEsQ0FBQTFSLElBQUEsVUFBSixJQUFjNFEsa0JBQzVCLEtBQVEsS0FBTSxJQUMzQixTQUFBQSxrQkFBQSxDQUFBcUQsWUFBQSxjQUFBdEQsYUFBQSxjQUFBQSxhQUFBO01BQ0wsTUFBQXVELGVBQWMsS0FBQXJELGNBQUEsR0FBQW1ELFFBQUEsQ0FBQTFOLElBQUEsY0FBQXVLLGNBQUEsY0FBQUEsY0FBQSxPQUFBakwsR0FBQSxDQUFBaUcsQ0FBQSxJQUFBQSxDQUFBLENBQUFyRixPQUFBLEVBQUFYLE1BQUEsQ0FBQXNPLE9BQUE7WUFDUkMsYUFBRSxVQUFBSixRQUFBLENBQUF0TixLQUFBLGlCQUFBb0sscUJBQUEsSUFBQUMsZUFBQSxHQUFBaUQsUUFBQSxDQUFBdE4sS0FBQSxjQUFBcUssZUFBQSx1QkFBQUEsZUFBQSxDQUFBcEssS0FBQSxjQUFBbUsscUJBQUEsY0FBQUEscUJBQUEsUUFBQUUsZ0JBQUEsR0FBQWdELFFBQUEsQ0FBQXROLEtBQUEsY0FBQXNLLGdCQUFBLGNBQUFBLGdCQUFBLEdBQUFrRCxlQUFBLENBQUF0TixNQUFBO1VBQ0p5TixXQUFTLEdBQWlCLENBQUNwRCxtQkFBQSxJQUFBQyxXQUFBLEdBQUFVLElBQUEsQ0FBQUMsS0FBQSxjQUFBWCxXQUFBLHVCQUFBQSxXQUFBLENBQUFvRCxPQUFBLGNBQUFyRCxtQkFBQSxjQUFBQSxtQkFBQTtVQUMzQnNELGlCQUFpQixJQUFJcEQscUJBQWdCLElBQUFDLGlCQUFBLEdBQUFRLElBQUEsQ0FBQUcsV0FBQSxjQUFBWCxpQkFBQSx1QkFBQUEsaUJBQUEsQ0FBQWtELE9BQUEsY0FBQW5ELHFCQUFBLGNBQUFBLHFCQUFBO1VBQ3JDcUQsZUFBQSxJQUFBbkQscUJBQUEsSUFBQUMsZUFBQSxHQUFBTSxJQUFBLENBQUFJLFNBQUEsY0FBQVYsZUFBQSx1QkFBQUEsZUFBQSxDQUFBZ0QsT0FBQSxjQUFBakQscUJBQUEsY0FBQUEscUJBQUE7VUFDRm9ELGFBQUEsSUFBQWxELHFCQUFBLElBQUFDLGFBQUEsR0FBQUksSUFBQSxDQUFBSyxPQUFBLGNBQUFULGFBQUEsdUJBQUFBLGFBQUEsQ0FBQThDLE9BQUEsY0FBQS9DLHFCQUFBLGNBQUFBLHFCQUFBO01BQ0YsSUFBRW1ELFVBQUEsR0FBQVIsZUFBQTtNQUNGLElBQUF4TixLQUFPLEdBQWMwTixhQUFBO01BQ3JCLElBQUFPLFVBQU07WUFBRXZQLElBQU0sT0FBQTFGLFVBQUEsQ0FBQTBELFlBQUE7VUFBRXNELEtBQUEsVUFBQXRCLElBQUE7UUFBTSxJQUFHO1VBQ3pCLE1BQVVLLEdBQUMsU0FBVyxDQUFDLEdBQUEvRixVQUFBLENBQUFnRyx1QkFBQSxFQUFBTixJQUFBO1VBQUUsTUFBQXdQLEdBQVUsR0FBRXhQLElBQU0sQ0FBQTlFLFFBQUE7VUFBRSxNQUFBdVUsVUFBQSxHQUFBcFAsR0FBQSxDQUFBRyxHQUFBLENBQUF2RixDQUFBLElBQUFELG1CQUFBLENBQUFDLENBQUEsRUFBQXVVLEdBQUE7VUFBTyxJQUFBQyxVQUFBLENBQUFqTyxNQUFBO1lBQ3REK04sVUFBQTtZQUVIak8sS0FBQSxHQUFBbU8sVUFBQSxDQUFBak8sTUFBQTtZQUVTOE4sVUFDUixHQUFBRyxVQUFBLENBQUF4TyxLQUFBLEdBQUFOLElBQUEsRUFBQUMsQ0FBQSxFQUFBQyxDQUFBO2NBQ1EsTUFBQUMsRUFBQSxHQUFBRixDQUFBLENBQUFoRixTQUFBLE9BQUF1RCxJQUFBLENBQXNDcEUsTUFBQSxDQUFBNkYsQ0FBQSxDQUFBaEYsU0FBQSxHQUFBbUYsT0FBQTtjQUNsQyxNQUFBQyxFQUFBLEdBQUFILENBQUEsQ0FBQWpGLFNBQUEsT0FBQXVELElBQUEsQ0FBQXBFLE1BQUEsQ0FBQThGLENBQUEsQ0FBQWpGLFNBQUEsR0FBQW1GLE9BQUE7Y0FDRCxPQUFBQyxFQUFBLEdBQUFGLEVBQUE7WUFDRixDQUFFLEVBQUFHLEtBQUE7WUFDTixNQUFBeU8sS0FBQTtZQUNILE1BQUFDLEtBQUE7WUFFSyxNQUFBQyxTQUFlLEdBQUc7WUFDakIsTUFBTUMsT0FBRztZQUNWSixVQUFRLENBQUFqSixPQUFBLENBQUE5RixDQUFBO2NBQ0osTUFBSW9QLEVBQUEsR0FBQS9VLE1BQVksQ0FBQTJGLENBQUEsQ0FBQWxGLFdBQUE7Y0FBRWtVLEtBQVUsQ0FBRUksRUFBQSxDQUFHLElBQUFKLEtBQUEsQ0FBQUksRUFBQTtjQUFRLE1BQUFDLEVBQUEsR0FBQWhWLE1BQUEsQ0FBQTJGLENBQUEsQ0FBQXRFLGNBQUE7Y0FBd0J1VCxLQUFBLENBQUFJLEVBQUEsS0FBQUosS0FBQSxDQUFBSSxFQUFBO2NBQzFFLE1BQUFDLEVBQUEsR0FBQWpWLE1BQUEsQ0FBQTJGLENBQUEsQ0FBQWpFLGFBQUE7Y0FDSW1ULFNBQUEsQ0FBQUksRUFBQSxLQUFBSixTQUFBLENBQUFJLEVBQUE7Y0FBQSxNQUFBQyxFQUFBLEdBQUFsVixNQUFBLENBQUEyRixDQUFBLENBQUF4RSxVQUFBO2NBQ0kyVCxPQUFHLENBQUFJLEVBQUEsSUFBSSxDQUFBSixPQUFTLENBQXNCSSxFQUFBLENBQUc7WUFDekM7WUFDTmhCLFdBQWMsR0FBQS9ILE1BQUEsQ0FBQUYsT0FBQSxDQUFBMEksS0FBQSxFQUFBbFAsR0FBQSxHQUFBMFAsR0FBQSxFQUFBQyxTQUFBO2NBQVFELEdBQUE7Y0FBT0M7WUFDN0IsQ0FBTztZQUFVaEIsaUJBQUEsR0FBQWpJLE1BQUEsQ0FBQUYsT0FBQSxDQUFBMkksS0FBQSxFQUFBblAsR0FBQSxHQUFBMFAsR0FBQSxFQUFBQyxTQUFBO2NBQ1ZELEdBQUk7Y0FBY0M7WUFBcUM7WUFBZ0NmLGVBQUEsR0FBQWxJLE1BQUEsQ0FBQUYsT0FBQSxDQUFBNEksU0FBQSxFQUFBcFAsR0FBQSxHQUFBMFAsR0FBQSxFQUFBQyxTQUFBO2NBQ2hHRCxHQUFBO2NBRUhDO1lBRVMsQ0FDUjtZQUNRZCxhQUFBLEdBQUFuSSxNQUFBLENBQUFGLE9BQWdDLENBQUE2SSxPQUFBLEVBQUFyUCxHQUFBLEdBQUEwUCxHQUFBLEVBQUFDLFNBQUE7Y0FDNUJELEdBQUE7Y0FDREM7WUFDRCxFQUFFO1lBQ1BqRCxVQUFBLEdBQUF1QyxVQUFBLENBQUFoUCxNQUFBLENBQUFDLENBQUEsS0FBQUEsQ0FBQSxDQUFBOUUsU0FBQSxRQUFBdUQsSUFBQSxDQUFBcEUsTUFBQSxDQUFBMkYsQ0FBQSxDQUFBOUUsU0FBQSxTQUFBdUQsSUFBQSxDQUFBa04sU0FBQSxHQUFBN0ssTUFBQTtVQUNIO1FBRUYsUUFBTztVQUNEO1FBQUE7TUFDRjtNQUNBLElBQUE0TyxrQkFBYyxHQUFHLElBQUM7TUFDbEIsSUFBQUMsZUFBaUIsT0FBTTtVQUNyQkMsVUFBTztZQUNQNUksSUFBQSxPQUFBbk4sb0JBQXdCLENBQUEyRCxzQkFBQTtVQUN4QndKLElBQU07WUFDSjtVQUNBMEksa0JBQU8sYUFBQTdWLG9CQUFBLENBQUFnVyx1QkFBQSxFQUFBN0ksSUFBQTtpQkFBRUosQ0FBQTtvQkFBa0IsR0FBRTlNLFdBQUEsQ0FBQThNLENBQUEsRUFBQTFNLElBQUE7NEJBQU87O1lBQ3BDO3lCQUFxQixhQUFBTCxvQkFBQSxDQUFBZ1csdUJBQUEsRUFBQTdJLElBQUE7VUFBRSxPQUFBSixDQUFBO1VBQ3pCLEtBQUFnSixVQUFBLEVBQUFBLFVBQUEsR0FBQTlWLFdBQUEsQ0FBQThNLENBQUEsRUFBQTFNLElBQUE7VUFDQXlWLGVBQUE7UUFDRjtNQUNBO2FBQW9CdlMsR0FBRSxDQUFBZ0IsRUFBQTtZQUFFO1VBQXlDMFIsY0FBQSxFQUFBbFAsS0FBQTtVQUFJbUwsS0FBQSxFQUFBd0MsV0FBQTtVQUNyRXRDLFdBQWlCLEVBQUF3QyxpQkFBQTtVQUFBdkMsU0FBQSxFQUFBd0MsZUFBQTtVQUNqQnZDLE9BQVcsRUFBQXdDLGFBQVk7VUFDckJQLGVBQVUsRUFBQVEsVUFBQTtVQUNWbUIscUJBQUksRUFBRTNELGNBQVc7VUFDakI0RCxrQkFBQSxFQUFBM0QsV0FBQTtVQUNKNEQsMkJBQUEsRUFBQTNELFNBQUE7VUFFSDRELG1CQUFBLEVBQUEzRCxZQUFBO1VBRU00RCxvQkFDTCxFQUFBM0QsVUFBQTtVQUNRNEQsMEJBQUEsRUFBQVYsa0JBQXdDO1VBQzlDVyx1QkFBVSxFQUFBVixlQUFBO1VBQ0pXLGdCQUFFLEVBQUFWLFVBQU87VUFDWFcsV0FBTSxFQUFBMUI7UUFDTjtRQUNBO2FBQ0E5VSxHQUFPLEVBQUU7VUFDVHlXLGdCQUFBLEVBQUFDLGFBQTBCO01BQzVCLE9BQUNyVCxHQUFBLENBQUFtQyxXQUFBO1FBQ0hDLFVBQUEsR0FBQWdSLGdCQUFBLEdBQUF6VyxHQUFBLENBQUF5RixVQUFBLGNBQUFnUixnQkFBQSxjQUFBQSxnQkFBQTtRQUVGdFcsSUFBTyxHQUFBdVcsYUFBYyxHQUFHMVcsR0FBSyxDQUFBSSxPQUFBLGNBQUFzVyxhQUFBLGNBQUFBLGFBQUEsR0FBQXBXLE1BQUEsQ0FBQU4sR0FBQTtNQUMzQixFQUFJOzs7UUFFRixDQUFBZ0QsR0FBTTtRQUNKLHFDQUFTO1lBQ0w7V0FDSixFQUFBdEQsYUFBUyxDQUFBbUYsTUFBQSxDQUFBQyxNQUFBO1FBQ1RDLElBQUEsRUFBQXJGLGFBQU8sQ0FBQW1GLE1BQUEsQ0FBQUcsS0FBQSxDQUFBdEYsYUFBQSxDQUFBbUYsTUFBQSxDQUFBSSxNQUFBO1FBQ1BDLElBQUEsRUFBQXhGLGFBQUEsQ0FBQW1GLE1BQXdCLENBQUdHLEtBQUEsQ0FBQXRGLGFBQUEsQ0FBQW1GLE1BQUEsQ0FBQUksTUFBQTtRQUM1QkcsTUFBTyxFQUFBMUYsYUFBSSxDQUFBbUYsTUFBQSxDQUFBRyxLQUFBLENBQUF0RixhQUFBLENBQUFtRixNQUFBLENBQUFNLE1BQUE7TUFFWjs7WUFFTTFDLE9BQUEsRUFBQTRDLEdBQVcsRUFBR2hDLEdBQUEsS0FBUTtVQUM1QmlDLENBQUEsR0FBTUQsR0FBQSxDQUFBVCxLQUFVO1FBQ2hCVSxDQUFBLENBQUFGLE1BQU0sS0FBTyxLQUFHO01BQ2hCLE1BQU1HLElBQUEsT0FBQTFGLFVBQWtCLENBQUEwRCxZQUFBO1VBQUUsQ0FBQWdDLElBQU8sU0FBQWxDLEdBQUEsQ0FBQW1DLFdBQUE7a0JBQUUsRUFBUyxHQUFFO1lBQUU7O1VBQTJCO1FBQUUsSUFBQW1SLFFBQUEsRUFBQUMsV0FBQSxFQUFBQyxRQUFBLEVBQUFDLFFBQUE7UUFBRyxNQUFBMU8sSUFBQSxhQUFBdkksVUFBQSxDQUFBb1Esc0JBQUEsRUFBQTFLLElBQUEsR0FBQW9SLFFBQUEsR0FBQXJSLENBQUEsQ0FBQVAsSUFBQSxjQUFBNFIsUUFBQSxjQUFBQSxRQUFBO1FBRWhGLE1BQUk3USxJQUFBLElBQUE4USxXQUF1QyxHQUFBeE8sSUFBQSxhQUFBQSxJQUFBLHVCQUFBQSxJQUFBLENBQUF0QixLQUFBLGNBQUE4UCxXQUFBLGNBQUFBLFdBQUE7UUFDM0MsTUFBTTFSLElBQUEsSUFBQTJSLFFBQTBDLEdBQUV2UixDQUFBLENBQUFKLElBQUEsY0FBQTJSLFFBQUEsY0FBQUEsUUFBQTtRQUVsRCxNQUFJOVIsSUFBQSxJQUFBK1IsUUFBQSxHQUFBeFIsQ0FBd0IsQ0FBQVAsSUFBRSxjQUFBK1IsUUFBQSxjQUFBQSxRQUFBO1FBQUEsTUFBQXRRLEtBQUEsR0FBQVYsSUFBQSxDQUFBVSxLQUFBLENBQUF0QixJQUFBLEVBQUFBLElBQUEsR0FBQUgsSUFBQTtRQUM1QixNQUFNMEIsSUFBQSxHQUFBRCxLQUFXLENBQUFULEdBQUcsRUFBQWdJLEdBQU0sRUFBQWtCLENBQUEsS0FBTztVQUMvQixJQUFBOEgsS0FBTyxFQUFBQyxPQUFBO1VBQ1A7WUFDQXBRLEdBQUksRUFBRXRHLE1BQUEsRUFBQXlXLEtBQUEsSUFBQUMsT0FBQSxHQUFBakosR0FBQSxDQUFBbk4sRUFBQSxjQUFBb1csT0FBQSxjQUFBQSxPQUFBLEdBQUFqSixHQUFBLENBQUFrSixLQUFBLGNBQUFGLEtBQUEsY0FBQUEsS0FBQSxHQUFBOUgsQ0FBQTtZQUNKdEksT0FBTSxTQUFJb0gsR0FBQSxnQkFBQUEsR0FBQTtjQUNWbkksR0FBQSxFQUFPbUk7WUFDUDs7O2VBQ0YxSyxHQUFBLENBQUFnQixFQUFBO1VBQ0FsRSxJQUFBO1lBQ0ZzRyxJQUFNO1lBQ05JLEtBQUE7Y0FDY0MsS0FBQSxFQUFBaEIsSUFBQSxDQUFBaUIsTUFBQTtjQUFBQyxRQUFBO1lBQ1g7WUFDQzVCLE1BQUE7VUFDRjs7ZUFFSXBGLEdBQUEsRUFBTTswQkFDSztlQUNYcUQsR0FBQSxDQUFLbUMsV0FBRztvQkFDUixNQUFBM0YsVUFBZ0IsQ0FBQXFILGNBQUEsRUFBQWxILEdBQUE7Y0FDbEIsR0FBQWtYLGNBQUEsR0FBQWxYLEdBQUEsYUFBQUEsR0FBQSx1QkFBQUEsR0FBQSxDQUFBSSxPQUFBLGNBQUE4VyxjQUFBLGNBQUFBLGNBQUEsR0FBQTVXLE1BQUEsQ0FBQU4sR0FBQTtVQUNGOzs7O1VBSUFtWCxNQUFLLEVBQUFDLGVBQUEsRUFBQUMsV0FBRTtZQUNQelUsTUFBQSxHQUFBSixTQUFBLENBQUFDLE9BQUE7TUFDSjtRQUVBc0MsSUFBTSxLQUFXO1FBQ2pCRyxJQUFLLEdBQUk7VUFBR0ksQ0FBQTtZQUFRbUMsUUFBVSxHQUFDLE1BQUE3RSxNQUFBLENBQUE4RSxNQUFBO2FBQUUsRUFBQTlILFVBQU0sQ0FBQW1VLDhCQUFBOzBCQUFjO1lBQU07VUFBRWhQLElBQUM7VUFBRUcsSUFBQTtVQUFJZ0IsSUFBQTtZQUNoRW9SLE9BQUE7Y0FDRzFQLEtBQUs7WUFBRTtZQUFTO1VBQTRCaEQsS0FBQTtZQUFJbUQsU0FBQTtVQUN2RDtRQUVBO1FBQ0U7WUFDSXRCLElBQUEsSUFBQTBRLE1BQUEsSUFBQUMsZUFBQSxHQUFBM1AsUUFBQSxDQUFBdEgsSUFBQSxjQUFBaVgsZUFBQSx1QkFBQUEsZUFBQSxDQUFBM1EsSUFBQSxjQUFBMFEsTUFBQSxjQUFBQSxNQUFBO2FBQ0E5VCxHQUFHLENBQUFnQixFQUFBO1lBQUU7Y0FBYSxHQUFLZ1QsV0FBRSxHQUFBNVEsSUFBQSxDQUFBQSxJQUFBLGNBQUE0USxXQUFBLGNBQUFBLFdBQUE7VUFBT3hRLEtBQUEsRUFBQUosSUFBQSxDQUFBSSxLQUFBO1VBQUl6QixNQUFBO1FBQ3hDO1FBQ0E7YUFBU3BGLEdBQU07MEJBQUUsRUFBQXVYLGNBQUE7YUFBS2xVLEdBQUEsQ0FBQW1DLFdBQUE7UUFBRUMsVUFBQSxHQUFBK1IsZ0JBQUEsR0FBQXhYLEdBQUEsQ0FBQXlGLFVBQUEsY0FBQStSLGdCQUFBLGNBQUFBLGdCQUFBO1FBQ3pCclgsSUFBQSxHQUFBb1gsY0FBQSxHQUFBdlgsR0FBQSxDQUFBSSxPQUFBLGNBQUFtWCxjQUFBLGNBQUFBLGNBQUEsR0FBQWpYLE1BQUEsQ0FBQU4sR0FBQTtNQUVEOzs7UUFJSSxDQUFBZ0QsR0FBSTtRQUNKLEVBQ0Ysa0NBQWM7WUFDWixFQUFLO1dBQ0wsRUFBQXRELGFBQWtCLENBQUFtRixNQUFNLENBQUFDLE1BQUE7UUFDeEJpTCxHQUFBLEVBQUlyUSxhQUFFLENBQUFtRixNQUFBLENBQUFHLEtBQUEsQ0FBQXRGLGFBQUEsQ0FBQW1GLE1BQUEsQ0FBQUksTUFBQTs7O1lBR0o5QixRQUFBLEVBQUFrQyxHQUFBLEVBQWdCaEMsR0FBRTtVQUNwQjhFLE1BQUEsT0FBQXJJLG9CQUFBLENBQUEyRCxzQkFBQTtRQUNBLENBQ0gwRSxNQUFDO01BRUYsT0FBTTlFLEdBQUEsQ0FBQW1DLFdBQVM7UUFDZkMsVUFBVztRQUtYdEYsSUFBTTtNQUNOOztRQUNFO1VBQ0FzWCxLQUFPO1lBQ0wxSCxHQUFBLElBQUEwSCxLQUFjLEdBQUdwUyxHQUFDLENBQUdULEtBQUEsQ0FBQW1MLEdBQUEsY0FBQTBILEtBQUEsY0FBQUEsS0FBQTtZQUFFclAsSUFBQSxhQUFBdEksb0JBQXFDLENBQUE0WCxhQUFHLEVBQUF2UCxNQUFBLEVBQUE0SCxHQUFBO2FBQUcxTSxHQUFBLENBQUFnQixFQUFBO1FBQ3BFbEUsSUFBQSxFQUFBaUk7TUFDRixDQUFDLENBQUM7TUFFRixPQUFPcEksR0FBRyxFQUFDO1lBQ0w7Y0FDRjs7cUJBRU8sQ0FBQUEsR0FBQTthQUNKcUQsR0FBQSxDQUFBbUMsV0FBQTtrQkFDSCxFQUFBdEYsTUFBVzs7Ozs7UUFLZixDQUFBOEMsR0FBQSxDQUFPO1FBQVU7WUFDakIsRUFBTztZQUNMLEVBQUF0RCxhQUFVLENBQUFtRixNQUFBLENBQUFDLE1BQUU7UUFDWmxFLEVBQUEsRUFBSWxCLGFBQUEsQ0FBQW1GLE1BQUUsQ0FBQU0sTUFBSTtNQUNaLENBQUM7SUFDSDtFQUNGLENBQ0YsRUFBQyxPQUFBaEMsUUFBQSxFQUFBa0MsR0FBQSxFQUFBaEMsR0FBQTtJQUNILE1BQUE4RSxNQUFBLE9BQUFySSxvQkFBQSxDQUFBMkQsc0JBQUEifQ==