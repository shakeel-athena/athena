"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.registerDefenderActionRoutes = registerDefenderActionRoutes;
var _configSchema = require("@osd/config-schema");
var _constants = require("../../common/constants");
var _mdeClient = require("../lib/mde-client");
var _otp = require("../lib/otp");
/*
 * Defender plugin — MDE actions + OTP for response operations
 */

function getUserFromRequest(req) {
  var _req$headers, _req$headers2;
  const user = ((_req$headers = req.headers) === null || _req$headers === void 0 ? void 0 : _req$headers['x-defender-user']) || 'dashboard-user';
  const role = ((_req$headers2 = req.headers) === null || _req$headers2 === void 0 ? void 0 : _req$headers2['x-defender-role']) || 'defender_operator';
  return {
    user,
    role
  };
}
function getOTPConfig() {
  return {
    smtpHost: process.env.SMTP_HOST,
    smtpPort: process.env.SMTP_PORT ? parseInt(process.env.SMTP_PORT, 10) : 587,
    smtpUser: process.env.SMTP_USER,
    smtpPass: process.env.SMTP_PASS,
    otpRecipientEmail: process.env.OTP_RECIPIENT_EMAIL,
    smtpSecure: process.env.SMTP_SECURE === 'true'
  };
}
function otpContext(body) {
  const c = (body.otp_context_id || body.machine_id || '').trim();
  return c;
}
async function writeAuditLog(client, entry) {
  try {
    await client.index({
      index: _constants.DEFENDER_AUDIT_LOG_INDEX,
      body: {
        ...entry,
        timestamp: new Date().toISOString()
      }
    });
  } catch (err) {
    console.error('[Defender] Audit log write failed:', err);
  }
}
const scanTypeSchema = _configSchema.schema.oneOf([_configSchema.schema.literal('Quick'), _configSchema.schema.literal('Full')]);
const isolationTypeSchema = _configSchema.schema.oneOf([_configSchema.schema.literal('Full'), _configSchema.schema.literal('Selective'), _configSchema.schema.literal('UnManagedDevice')]);

/** Machine-scoped actions: OTP + required comment */
const machineActionBody = _configSchema.schema.object({
  machine_id: _configSchema.schema.string(),
  computer_dns_name: _configSchema.schema.maybe(_configSchema.schema.string()),
  comment: _configSchema.schema.string(),
  otp: _configSchema.schema.string(),
  otp_context_id: _configSchema.schema.maybe(_configSchema.schema.string()),
  scan_type: _configSchema.schema.maybe(scanTypeSchema),
  isolation_type: _configSchema.schema.maybe(isolationTypeSchema)
});
function registerDefenderActionRoutes(router) {
  const runMachineAction = (path, actionName, fn) => {
    router.post({
      path,
      validate: {
        body: machineActionBody
      }
    }, async (context, req, res) => {
      const config = (0, _mdeClient.getMdeConfig)();
      if (!config) {
        return res.customError({
          statusCode: 503,
          body: 'Defender credentials not configured.'
        });
      }
      const {
        user,
        role
      } = getUserFromRequest(req);
      const client = context.core.opensearch.client.asCurrentUser;
      const body = req.body;
      const comment = (body.comment || '').trim();
      if (!comment) {
        return res.customError({
          statusCode: 400,
          body: 'Comment is required.'
        });
      }
      const ctx = otpContext(body);
      if (!ctx) {
        return res.customError({
          statusCode: 400,
          body: 'machine_id or otp_context_id required.'
        });
      }
      const otpCheck = (0, _otp.validateOTP)(ctx, actionName, body.otp || '');
      if (!otpCheck.valid) {
        return res.customError({
          statusCode: 400,
          body: otpCheck.reason || 'OTP required'
        });
      }
      const deviceName = body.computer_dns_name || body.machine_id;
      try {
        var _info;
        const result = await fn(config, {
          machine_id: body.machine_id,
          comment,
          scan_type: body.scan_type,
          isolation_type: body.isolation_type
        });
        const message = JSON.stringify(result).slice(0, 2000);
        await writeAuditLog(client, {
          action: actionName,
          machine_id: body.machine_id,
          computer_dns_name: deviceName,
          performed_by: user,
          role,
          status: 'success',
          message,
          source_ip: (_info = req.info) === null || _info === void 0 ? void 0 : _info.remoteAddress,
          otp_verified: true,
          comment
        });
        return res.ok({
          body: {
            success: true,
            action: actionName,
            machine_id: body.machine_id,
            message,
            timestamp: new Date().toISOString()
          }
        });
      } catch (err) {
        var _info2;
        const mdeHttpStatus = err != null && err.status != null ? err.status : null;
        const mdeErrorDetail = err && err.responseText ? String(err.responseText).slice(0, 1000) : null;
        const errorType = (err && (err.name || (err.constructor && err.constructor.name))) || 'Error';
        const errorMessage = err instanceof Error ? err.message : String(err);
        console.error('[Defender Action] ' + actionName + ' failed — type:' + errorType + ' http:' + mdeHttpStatus + ' msg:' + errorMessage);
        await writeAuditLog(client, {
          action: actionName,
          machine_id: body.machine_id,
          computer_dns_name: deviceName,
          performed_by: user,
          role,
          status: 'failure',
          message: errorMessage,
          mde_http_status: mdeHttpStatus,
          mde_error_detail: mdeErrorDetail || errorType,
          source_ip: (_info2 = req.info) === null || _info2 === void 0 ? void 0 : _info2.remoteAddress,
          otp_verified: true,
          comment
        });
        return res.customError({
          statusCode: (0, _mdeClient.mdeErrorStatus)(err),
          body: errorMessage
        });
      }
    });
  };
  runMachineAction('/api/defender_plugin/actions/antivirus-scan', 'antivirus_scan', (cfg, b) => (0, _mdeClient.runAntivirusScan)(cfg, b.machine_id, b.comment, b.scan_type || 'Quick'));
  runMachineAction('/api/defender_plugin/actions/isolate', 'isolate', (cfg, b) => (0, _mdeClient.isolateMachine)(cfg, b.machine_id, b.comment, b.isolation_type || 'Full'));
  runMachineAction('/api/defender_plugin/actions/unisolate', 'unisolate', (cfg, b) => (0, _mdeClient.unisolateMachine)(cfg, b.machine_id, b.comment));
  runMachineAction('/api/defender_plugin/actions/restrict-code-execution', 'restrict_code_execution', (cfg, b) => (0, _mdeClient.restrictCodeExecution)(cfg, b.machine_id, b.comment));
  runMachineAction('/api/defender_plugin/actions/unrestrict-code-execution', 'unrestrict_code_execution', (cfg, b) => (0, _mdeClient.unrestrictCodeExecution)(cfg, b.machine_id, b.comment));
  runMachineAction('/api/defender_plugin/actions/collect-investigation-package', 'collect_investigation_package', (cfg, b) => (0, _mdeClient.collectInvestigationPackage)(cfg, b.machine_id, b.comment));
  runMachineAction('/api/defender_plugin/actions/offboard', 'offboard_machine', (cfg, b) => (0, _mdeClient.offboardMachine)(cfg, b.machine_id, b.comment));
  const stopQuarantineBody = _configSchema.schema.object({
    machine_id: _configSchema.schema.string(),
    computer_dns_name: _configSchema.schema.maybe(_configSchema.schema.string()),
    sha1: _configSchema.schema.string(),
    comment: _configSchema.schema.string(),
    otp: _configSchema.schema.string(),
    otp_context_id: _configSchema.schema.maybe(_configSchema.schema.string())
  });
  router.post({
    path: '/api/defender_plugin/actions/stop-and-quarantine',
    validate: {
      body: stopQuarantineBody
    }
  }, async (context, req, res) => {
    const config = (0, _mdeClient.getMdeConfig)();
    if (!config) {
      return res.customError({
        statusCode: 503,
        body: 'Defender not configured.'
      });
    }
    const {
      user,
      role
    } = getUserFromRequest(req);
    const client = context.core.opensearch.client.asCurrentUser;
    const body = req.body;
    const comment = (body.comment || '').trim();
    if (!comment) {
      return res.customError({
        statusCode: 400,
        body: 'Comment is required.'
      });
    }
    const ctx = otpContext(body);
    if (!ctx) {
      return res.customError({
        statusCode: 400,
        body: 'machine_id or otp_context_id required.'
      });
    }
    const otpCheck = (0, _otp.validateOTP)(ctx, 'stop_and_quarantine', body.otp || '');
    if (!otpCheck.valid) {
      return res.customError({
        statusCode: 400,
        body: otpCheck.reason || 'OTP required'
      });
    }
    const deviceName = body.computer_dns_name || body.machine_id;
    try {
      var _info3;
      const result = await (0, _mdeClient.stopAndQuarantineFile)(config, body.machine_id, comment, body.sha1.trim());
      const message = JSON.stringify(result).slice(0, 2000);
      await writeAuditLog(client, {
        action: 'stop_and_quarantine',
        machine_id: body.machine_id,
        computer_dns_name: deviceName,
        performed_by: user,
        role,
        status: 'success',
        message,
        source_ip: (_info3 = req.info) === null || _info3 === void 0 ? void 0 : _info3.remoteAddress,
        otp_verified: true,
        comment
      });
      return res.ok({
        body: {
          success: true,
          action: 'stop_and_quarantine',
          machine_id: body.machine_id,
          message
        }
      });
    } catch (err) {
      var _info4;
      await writeAuditLog(client, {
        action: 'stop_and_quarantine',
        machine_id: body.machine_id,
        computer_dns_name: deviceName,
        performed_by: user,
        role,
        status: 'failure',
        message: err instanceof Error ? err.message : String(err),
        source_ip: (_info4 = req.info) === null || _info4 === void 0 ? void 0 : _info4.remoteAddress,
        otp_verified: true,
        comment
      });
      return res.customError({
        statusCode: (0, _mdeClient.mdeErrorStatus)(err),
        body: err instanceof Error ? err.message : String(err)
      });
    }
  });
  const cancelActionBody = _configSchema.schema.object({
    action_id: _configSchema.schema.string(),
    machine_id: _configSchema.schema.maybe(_configSchema.schema.string()),
    computer_dns_name: _configSchema.schema.maybe(_configSchema.schema.string()),
    comment: _configSchema.schema.string(),
    otp: _configSchema.schema.string()
  });
  router.post({
    path: '/api/defender_plugin/actions/cancel-machine-action',
    validate: {
      body: cancelActionBody
    }
  }, async (context, req, res) => {
    const config = (0, _mdeClient.getMdeConfig)();
    if (!config) {
      return res.customError({
        statusCode: 503,
        body: 'Defender not configured.'
      });
    }
    const {
      user,
      role
    } = getUserFromRequest(req);
    const client = context.core.opensearch.client.asCurrentUser;
    const body = req.body;
    const comment = (body.comment || '').trim();
    if (!comment) {
      return res.customError({
        statusCode: 400,
        body: 'Comment is required.'
      });
    }
    const otpCheck = (0, _otp.validateOTP)(body.action_id, 'cancel_machine_action', body.otp || '');
    if (!otpCheck.valid) {
      return res.customError({
        statusCode: 400,
        body: otpCheck.reason || 'OTP required'
      });
    }
    const deviceName = body.computer_dns_name || body.machine_id || body.action_id;
    try {
      var _info5;
      const result = await (0, _mdeClient.cancelMachineAction)(config, body.action_id);
      const message = JSON.stringify(result).slice(0, 2000);
      await writeAuditLog(client, {
        action: 'cancel_machine_action',
        machine_id: body.machine_id || body.action_id,
        computer_dns_name: deviceName,
        performed_by: user,
        role,
        status: 'success',
        message,
        source_ip: (_info5 = req.info) === null || _info5 === void 0 ? void 0 : _info5.remoteAddress,
        otp_verified: true,
        comment
      });
      return res.ok({
        body: {
          success: true,
          action: 'cancel_machine_action',
          action_id: body.action_id,
          message
        }
      });
    } catch (err) {
      var _info6;
      await writeAuditLog(client, {
        action: 'cancel_machine_action',
        machine_id: body.machine_id || body.action_id,
        computer_dns_name: deviceName,
        performed_by: user,
        role,
        status: 'failure',
        message: err instanceof Error ? err.message : String(err),
        source_ip: (_info6 = req.info) === null || _info6 === void 0 ? void 0 : _info6.remoteAddress,
        otp_verified: true,
        comment
      });
      return res.customError({
        statusCode: (0, _mdeClient.mdeErrorStatus)(err),
        body: err instanceof Error ? err.message : String(err)
      });
    }
  });
  router.post({
    path: '/api/defender_plugin/actions/request-otp',
    validate: {
      body: _configSchema.schema.object({
        action: _configSchema.schema.string(),
        machine_id: _configSchema.schema.maybe(_configSchema.schema.string()),
        computer_dns_name: _configSchema.schema.maybe(_configSchema.schema.string()),
        otp_context_id: _configSchema.schema.maybe(_configSchema.schema.string())
      })
    }
  }, async (_context, req, res) => {
    const {
      machine_id,
      action,
      computer_dns_name,
      otp_context_id
    } = req.body;
    if (!_constants.DESTRUCTIVE_ACTIONS.includes(action)) {
      return res.customError({
        statusCode: 400,
        body: 'This action does not use this OTP flow.'
      });
    }
    const ctx = (otp_context_id || machine_id || '').trim();
    if (!ctx) {
      return res.customError({
        statusCode: 400,
        body: 'Provide machine_id or otp_context_id (e.g. action id for cancel).'
      });
    }
    const otp = (0, _otp.generateOTP)();
    (0, _otp.storeOTP)(ctx, action, otp);
    const emailResult = await (0, _otp.sendOTPEmail)(getOTPConfig(), otp, computer_dns_name || ctx, action);
    return res.ok({
      body: {
        success: true,
        message: emailResult.sent ? 'OTP sent to configured recipient.' : 'OTP generated (configure SMTP for email delivery).',
        dev_mode: emailResult.devMode,
        otp: emailResult.devMode ? emailResult.otp : undefined
      }
    });
  });
  const indicatorCreateBody = _configSchema.schema.object({
    machine_id: _configSchema.schema.string(),
    computer_dns_name: _configSchema.schema.maybe(_configSchema.schema.string()),
    comment: _configSchema.schema.string(),
    otp: _configSchema.schema.string(),
    otp_context_id: _configSchema.schema.maybe(_configSchema.schema.string()),
    indicator_type: _configSchema.schema.oneOf([_configSchema.schema.literal('FileSha1'), _configSchema.schema.literal('FileSha256'), _configSchema.schema.literal('IpAddress'), _configSchema.schema.literal('DomainName'), _configSchema.schema.literal('Url')]),
    indicator_value: _configSchema.schema.string(),
    title: _configSchema.schema.string(),
    description: _configSchema.schema.maybe(_configSchema.schema.string()),
    expiration_time: _configSchema.schema.maybe(_configSchema.schema.string()),
    action: _configSchema.schema.oneOf([_configSchema.schema.literal('Alert'), _configSchema.schema.literal('AlertAndBlock'), _configSchema.schema.literal('Allowed'), _configSchema.schema.literal('Block'), _configSchema.schema.literal('Audit')]),
    severity: _configSchema.schema.oneOf([_configSchema.schema.literal('Informational'), _configSchema.schema.literal('Low'), _configSchema.schema.literal('Medium'), _configSchema.schema.literal('High')])
  });
  router.post({
    path: '/api/defender_plugin/actions/create-indicator',
    validate: {
      body: indicatorCreateBody
    }
  }, async (context, req, res) => {
    const config = (0, _mdeClient.getMdeConfig)();
    if (!config) {
      return res.customError({
        statusCode: 503,
        body: 'Defender not configured.'
      });
    }
    const {
      user,
      role
    } = getUserFromRequest(req);
    const client = context.core.opensearch.client.asCurrentUser;
    const b = req.body;
    const comment = (b.comment || '').trim();
    if (!comment) {
      return res.customError({
        statusCode: 400,
        body: 'Comment is required.'
      });
    }
    const ctx = otpContext(b);
    if (!ctx) {
      return res.customError({
        statusCode: 400,
        body: 'machine_id or otp_context_id required.'
      });
    }
    const otpCheck = (0, _otp.validateOTP)(ctx, 'create_indicator', b.otp || '');
    if (!otpCheck.valid) {
      return res.customError({
        statusCode: 400,
        body: otpCheck.reason || 'OTP required'
      });
    }
    const deviceName = b.computer_dns_name || b.machine_id;
    try {
      var _info7;
      const payload = {
        indicatorValue: b.indicator_value,
        indicatorType: b.indicator_type,
        title: b.title,
        description: b.description,
        expirationTime: b.expiration_time,
        action: b.action,
        severity: b.severity
      };
      const result = await (0, _mdeClient.createIndicator)(config, payload);
      const message = JSON.stringify(result).slice(0, 2000);
      await writeAuditLog(client, {
        action: 'create_indicator',
        machine_id: b.machine_id,
        computer_dns_name: deviceName,
        performed_by: user,
        role,
        status: 'success',
        message,
        source_ip: (_info7 = req.info) === null || _info7 === void 0 ? void 0 : _info7.remoteAddress,
        otp_verified: true,
        comment
      });
      return res.ok({
        body: {
          success: true,
          action: 'create_indicator',
          machine_id: b.machine_id,
          message,
          timestamp: new Date().toISOString()
        }
      });
    } catch (err) {
      var _info8;
      await writeAuditLog(client, {
        action: 'create_indicator',
        machine_id: b.machine_id,
        computer_dns_name: deviceName,
        performed_by: user,
        role,
        status: 'failure',
        message: err instanceof Error ? err.message : String(err),
        source_ip: (_info8 = req.info) === null || _info8 === void 0 ? void 0 : _info8.remoteAddress,
        otp_verified: true,
        comment
      });
      return res.customError({
        statusCode: (0, _mdeClient.mdeErrorStatus)(err),
        body: err instanceof Error ? err.message : String(err)
      });
    }
  });
  const updateIndicatorBody = _configSchema.schema.object({
    indicator_id: _configSchema.schema.string(),
    machine_id: _configSchema.schema.maybe(_configSchema.schema.string()),
    computer_dns_name: _configSchema.schema.maybe(_configSchema.schema.string()),
    comment: _configSchema.schema.string(),
    otp: _configSchema.schema.string(),
    title: _configSchema.schema.maybe(_configSchema.schema.string()),
    description: _configSchema.schema.maybe(_configSchema.schema.string()),
    action: _configSchema.schema.maybe(_configSchema.schema.oneOf([_configSchema.schema.literal('Alert'), _configSchema.schema.literal('AlertAndBlock'), _configSchema.schema.literal('Allowed'), _configSchema.schema.literal('Block'), _configSchema.schema.literal('Audit')])),
    severity: _configSchema.schema.maybe(_configSchema.schema.oneOf([_configSchema.schema.literal('Informational'), _configSchema.schema.literal('Low'), _configSchema.schema.literal('Medium'), _configSchema.schema.literal('High')])),
    expiration_time: _configSchema.schema.maybe(_configSchema.schema.string())
  });
  router.post({
    path: '/api/defender_plugin/actions/update-indicator',
    validate: {
      body: updateIndicatorBody
    }
  }, async (context, req, res) => {
    const config = (0, _mdeClient.getMdeConfig)();
    if (!config) {
      return res.customError({
        statusCode: 503,
        body: 'Defender not configured.'
      });
    }
    const {
      user,
      role
    } = getUserFromRequest(req);
    const client = context.core.opensearch.client.asCurrentUser;
    const b = req.body;
    const comment = (b.comment || '').trim();
    if (!comment) {
      return res.customError({
        statusCode: 400,
        body: 'Comment is required.'
      });
    }
    const otpCheck = (0, _otp.validateOTP)(b.indicator_id, 'update_indicator', b.otp || '');
    if (!otpCheck.valid) {
      return res.customError({
        statusCode: 400,
        body: otpCheck.reason || 'OTP required'
      });
    }
    const deviceName = b.computer_dns_name || b.machine_id || b.indicator_id;
    const patch = {};
    if (b.title != null) patch.title = b.title;
    if (b.description != null) patch.description = b.description;
    if (b.action != null) patch.action = b.action;
    if (b.severity != null) patch.severity = b.severity;
    if (b.expiration_time != null) patch.expirationTime = b.expiration_time;
    if (Object.keys(patch).length === 0) {
      return res.customError({
        statusCode: 400,
        body: 'Provide at least one field to update.'
      });
    }
    try {
      var _info9;
      const result = await (0, _mdeClient.updateIndicator)(config, b.indicator_id, patch);
      const message = JSON.stringify(result).slice(0, 2000);
      await writeAuditLog(client, {
        action: 'update_indicator',
        machine_id: b.machine_id || b.indicator_id,
        computer_dns_name: deviceName,
        performed_by: user,
        role,
        status: 'success',
        message,
        source_ip: (_info9 = req.info) === null || _info9 === void 0 ? void 0 : _info9.remoteAddress,
        otp_verified: true,
        comment
      });
      return res.ok({
        body: {
          success: true,
          action: 'update_indicator',
          indicator_id: b.indicator_id,
          message,
          timestamp: new Date().toISOString()
        }
      });
    } catch (err) {
      var _info10;
      await writeAuditLog(client, {
        action: 'update_indicator',
        machine_id: b.machine_id || b.indicator_id,
        computer_dns_name: deviceName,
        performed_by: user,
        role,
        status: 'failure',
        message: err instanceof Error ? err.message : String(err),
        source_ip: (_info10 = req.info) === null || _info10 === void 0 ? void 0 : _info10.remoteAddress,
        otp_verified: true,
        comment
      });
      return res.customError({
        statusCode: (0, _mdeClient.mdeErrorStatus)(err),
        body: err instanceof Error ? err.message : String(err)
      });
    }
  });
  router.post({
    path: '/api/defender_plugin/actions/request-otp-indicator',
    validate: {
      body: _configSchema.schema.object({
        machine_id: _configSchema.schema.string(),
        computer_dns_name: _configSchema.schema.maybe(_configSchema.schema.string()),
        otp_context_id: _configSchema.schema.maybe(_configSchema.schema.string())
      })
    }
  }, async (_context, req, res) => {
    const {
      machine_id,
      computer_dns_name,
      otp_context_id
    } = req.body;
    const ctx = (otp_context_id || machine_id).trim();
    const otp = (0, _otp.generateOTP)();
    (0, _otp.storeOTP)(ctx, 'create_indicator', otp);
    const emailResult = await (0, _otp.sendOTPEmail)(getOTPConfig(), otp, computer_dns_name || machine_id, 'create_indicator');
    return res.ok({
      body: {
        success: true,
        message: emailResult.sent ? 'OTP sent.' : 'OTP generated.',
        dev_mode: emailResult.devMode,
        otp: emailResult.devMode ? emailResult.otp : undefined
      }
    });
  });
  const deleteIndicatorBody = _configSchema.schema.object({
    indicator_id: _configSchema.schema.string(),
    machine_id: _configSchema.schema.maybe(_configSchema.schema.string()),
    computer_dns_name: _configSchema.schema.maybe(_configSchema.schema.string()),
    comment: _configSchema.schema.string(),
    otp: _configSchema.schema.string()
  });
  router.post({
    path: '/api/defender_plugin/actions/delete-indicator',
    validate: {
      body: deleteIndicatorBody
    }
  }, async (context, req, res) => {
    const config = (0, _mdeClient.getMdeConfig)();
    if (!config) {
      return res.customError({
        statusCode: 503,
        body: 'Defender not configured.'
      });
    }
    const {
      user,
      role
    } = getUserFromRequest(req);
    const client = context.core.opensearch.client.asCurrentUser;
    const b = req.body;
    const comment = (b.comment || '').trim();
    if (!comment) {
      return res.customError({
        statusCode: 400,
        body: 'Comment is required.'
      });
    }
    const otpCheck = (0, _otp.validateOTP)(b.indicator_id, 'delete_indicator', b.otp || '');
    if (!otpCheck.valid) {
      return res.customError({
        statusCode: 400,
        body: otpCheck.reason || 'OTP required'
      });
    }
    const deviceName = b.computer_dns_name || b.machine_id || b.indicator_id;
    try {
      var _info11;
      const result = await (0, _mdeClient.deleteIndicator)(config, b.indicator_id);
      const message = JSON.stringify(result).slice(0, 2000);
      await writeAuditLog(client, {
        action: 'delete_indicator',
        machine_id: b.machine_id || b.indicator_id,
        computer_dns_name: deviceName,
        performed_by: user,
        role,
        status: 'success',
        message,
        source_ip: (_info11 = req.info) === null || _info11 === void 0 ? void 0 : _info11.remoteAddress,
        otp_verified: true,
        comment
      });
      return res.ok({
        body: {
          success: true,
          action: 'delete_indicator',
          machine_id: b.machine_id || b.indicator_id,
          message,
          timestamp: new Date().toISOString()
        }
      });
    } catch (err) {
      var _info12;
      await writeAuditLog(client, {
        action: 'delete_indicator',
        machine_id: b.machine_id || b.indicator_id,
        computer_dns_name: deviceName,
        performed_by: user,
        role,
        status: 'failure',
        message: err instanceof Error ? err.message : String(err),
        source_ip: (_info12 = req.info) === null || _info12 === void 0 ? void 0 : _info12.remoteAddress,
        otp_verified: true,
        comment
      });
      return res.customError({
        statusCode: (0, _mdeClient.mdeErrorStatus)(err),
        body: err instanceof Error ? err.message : String(err)
      });
    }
  });
  router.post({
    path: '/api/defender_plugin/actions/request-otp-delete-indicator',
    validate: {
      body: _configSchema.schema.object({
        indicator_id: _configSchema.schema.string(),
        computer_dns_name: _configSchema.schema.maybe(_configSchema.schema.string())
      })
    }
  }, async (_context, req, res) => {
    const {
      indicator_id,
      computer_dns_name
    } = req.body;
    const otp = (0, _otp.generateOTP)();
    (0, _otp.storeOTP)(indicator_id, 'delete_indicator', otp);
    const emailResult = await (0, _otp.sendOTPEmail)(getOTPConfig(), otp, computer_dns_name || indicator_id, 'delete_indicator');
    return res.ok({
      body: {
        success: true,
        dev_mode: emailResult.devMode,
        otp: emailResult.devMode ? emailResult.otp : undefined
      }
    });
  });
  router.post({
    path: '/api/defender_plugin/actions/request-otp-update-indicator',
    validate: {
      body: _configSchema.schema.object({
        indicator_id: _configSchema.schema.string(),
        computer_dns_name: _configSchema.schema.maybe(_configSchema.schema.string())
      })
    }
  }, async (_context, req, res) => {
    const {
      indicator_id,
      computer_dns_name
    } = req.body;
    const otp = (0, _otp.generateOTP)();
    (0, _otp.storeOTP)(indicator_id, 'update_indicator', otp);
    const emailResult = await (0, _otp.sendOTPEmail)(getOTPConfig(), otp, computer_dns_name || indicator_id, 'update_indicator');
    return res.ok({
      body: {
        success: true,
        dev_mode: emailResult.devMode,
        otp: emailResult.devMode ? emailResult.otp : undefined
      }
    });
  });
}
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfY29uZmlnU2NoZW1hIiwicmVxdWlyZSIsIl9jb25zdGFudHMiLCJfbWRlQ2xpZW50IiwiX290cCIsImdldFVzZXJGcm9tUmVxdWVzdCIsInJlcSIsIl9yZXEkaGVhZGVycyIsIl9yZXEkaGVhZGVyczIiLCJ1c2VyIiwiaGVhZGVycyIsInJvbGUiLCJnZXRPVFBDb25maWciLCJzbXRwSG9zdCIsInByb2Nlc3MiLCJlbnYiLCJTTVRQX0hPU1QiLCJzbXRwUG9ydCIsIlNNVFBfUE9SVCIsInBhcnNlSW50Iiwic210cFVzZXIiLCJTTVRQX1VTRVIiLCJzbXRwUGFzcyIsIlNNVFBfUEFTUyIsIm90cFJlY2lwaWVudEVtYWlsIiwiT1RQX1JFQ0lQSUVOVF9FTUFJTCIsInNtdHBTZWN1cmUiLCJTTVRQX1NFQ1VSRSIsIm90cENvbnRleHQiLCJib2R5IiwiYyIsIm90cF9jb250ZXh0X2lkIiwibWFjaGluZV9pZCIsInRyaW0iLCJ3cml0ZUF1ZGl0TG9nIiwiY2xpZW50IiwiZW50cnkiLCJpbmRleCIsIkRFRkVOREVSX0FVRElUX0xPR19JTkRFWCIsInRpbWVzdGFtcCIsIkRhdGUiLCJ0b0lTT1N0cmluZyIsImVyciIsImNvbnNvbGUiLCJlcnJvciIsInNjYW5UeXBlU2NoZW1hIiwic2NoZW1hIiwib25lT2YiLCJsaXRlcmFsIiwiaXNvbGF0aW9uVHlwZVNjaGVtYSIsIm1hY2hpbmVBY3Rpb25Cb2R5Iiwib2JqZWN0Iiwic3RyaW5nIiwiY29tcHV0ZXJfZG5zX25hbWUiLCJtYXliZSIsImNvbW1lbnQiLCJvdHAiLCJzY2FuX3R5cGUiLCJpc29sYXRpb25fdHlwZSIsInJlZ2lzdGVyRGVmZW5kZXJBY3Rpb25Sb3V0ZXMiLCJyb3V0ZXIiLCJydW5NYWNoaW5lQWN0aW9uIiwicGF0aCIsImFjdGlvbk5hbWUiLCJmbiIsInBvc3QiLCJ2YWxpZGF0ZSIsImNvbnRleHQiLCJyZXMiLCJjb25maWciLCJnZXRNZGVDb25maWciLCJjdXN0b21FcnJvciIsInN0YXR1c0NvZGUiLCJjb3JlIiwib3BlbnNlYXJjaCIsImFzQ3VycmVudFVzZXIiLCJjdHgiLCJvdHBDaGVjayIsInZhbGlkYXRlT1RQIiwidmFsaWQiLCJyZWFzb24iLCJkZXZpY2VOYW1lIiwiX2luZm8iLCJyZXN1bHQiLCJtZXNzYWdlIiwiSlNPTiIsInN0cmluZ2lmeSIsInNsaWNlIiwiYWN0aW9uIiwicGVyZm9ybWVkX2J5Iiwic3RhdHVzIiwic291cmNlX2lwIiwiaW5mbyIsInJlbW90ZUFkZHJlc3MiLCJvdHBfdmVyaWZpZWQiLCJvayIsInN1Y2Nlc3MiLCJfaW5mbzIiLCJFcnJvciIsIlN0cmluZyIsIm1kZUVycm9yU3RhdHVzIiwiY2ZnIiwiYiIsInJ1bkFudGl2aXJ1c1NjYW4iLCJpc29sYXRlTWFjaGluZSIsInVuaXNvbGF0ZU1hY2hpbmUiLCJyZXN0cmljdENvZGVFeGVjdXRpb24iLCJ1bnJlc3RyaWN0Q29kZUV4ZWN1dGlvbiIsImNvbGxlY3RJbnZlc3RpZ2F0aW9uUGFja2FnZSIsIm9mZmJvYXJkTWFjaGluZSIsInN0b3BRdWFyYW50aW5lQm9keSIsInNoYTEiLCJfaW5mbzMiLCJzdG9wQW5kUXVhcmFudGluZUZpbGUiLCJfaW5mbzQiLCJjYW5jZWxBY3Rpb25Cb2R5IiwiYWN0aW9uX2lkIiwiX2luZm81IiwiY2FuY2VsTWFjaGluZUFjdGlvbiIsIl9pbmZvNiIsIl9jb250ZXh0IiwiREVTVFJVQ1RJVkVfQUNUSU9OUyIsImluY2x1ZGVzIiwiZ2VuZXJhdGVPVFAiLCJzdG9yZU9UUCIsImVtYWlsUmVzdWx0Iiwic2VuZE9UUEVtYWlsIiwic2VudCIsImRldl9tb2RlIiwiZGV2TW9kZSIsInVuZGVmaW5lZCIsImluZGljYXRvckNyZWF0ZUJvZHkiLCJpbmRpY2F0b3JfdHlwZSIsImluZGljYXRvcl92YWx1ZSIsInRpdGxlIiwiZGVzY3JpcHRpb24iLCJleHBpcmF0aW9uX3RpbWUiLCJzZXZlcml0eSIsIl9pbmZvNyIsInBheWxvYWQiLCJpbmRpY2F0b3JWYWx1ZSIsImluZGljYXRvclR5cGUiLCJleHBpcmF0aW9uVGltZSIsImNyZWF0ZUluZGljYXRvciIsIl9pbmZvOCIsInVwZGF0ZUluZGljYXRvckJvZHkiLCJpbmRpY2F0b3JfaWQiLCJwYXRjaCIsIk9iamVjdCIsImtleXMiLCJsZW5ndGgiLCJfaW5mbzkiLCJ1cGRhdGVJbmRpY2F0b3IiLCJfaW5mbzEwIiwiZGVsZXRlSW5kaWNhdG9yQm9keSIsIl9pbmZvMTEiLCJkZWxldGVJbmRpY2F0b3IiLCJfaW5mbzEyIl0sInNvdXJjZXMiOlsiYWN0aW9ucy50cyJdLCJzb3VyY2VzQ29udGVudCI6WyIvKlxuICogRGVmZW5kZXIgcGx1Z2luIOKAlCBNREUgYWN0aW9ucyArIE9UUCBmb3IgcmVzcG9uc2Ugb3BlcmF0aW9uc1xuICovXG5cbmltcG9ydCB7IElSb3V0ZXIgfSBmcm9tICdvcGVuc2VhcmNoLWRhc2hib2FyZHMvc2VydmVyJztcbmltcG9ydCB7IHNjaGVtYSB9IGZyb20gJ0Bvc2QvY29uZmlnLXNjaGVtYSc7XG5pbXBvcnQgeyBERUZFTkRFUl9BVURJVF9MT0dfSU5ERVgsIERFU1RSVUNUSVZFX0FDVElPTlMgfSBmcm9tICcuLi8uLi9jb21tb24vY29uc3RhbnRzJztcbmltcG9ydCB7XG4gIGdldE1kZUNvbmZpZyxcbiAgcnVuQW50aXZpcnVzU2NhbixcbiAgaXNvbGF0ZU1hY2hpbmUsXG4gIHVuaXNvbGF0ZU1hY2hpbmUsXG4gIHJlc3RyaWN0Q29kZUV4ZWN1dGlvbixcbiAgdW5yZXN0cmljdENvZGVFeGVjdXRpb24sXG4gIGNvbGxlY3RJbnZlc3RpZ2F0aW9uUGFja2FnZSxcbiAgb2ZmYm9hcmRNYWNoaW5lLFxuICBzdG9wQW5kUXVhcmFudGluZUZpbGUsXG4gIGNhbmNlbE1hY2hpbmVBY3Rpb24sXG4gIGNyZWF0ZUluZGljYXRvcixcbiAgZGVsZXRlSW5kaWNhdG9yLFxuICB1cGRhdGVJbmRpY2F0b3IsXG4gIHR5cGUgQ3JlYXRlSW5kaWNhdG9yUGF5bG9hZCxcbiAgbWRlRXJyb3JTdGF0dXMsXG59IGZyb20gJy4uL2xpYi9tZGUtY2xpZW50JztcbmltcG9ydCB7IGdlbmVyYXRlT1RQLCBzdG9yZU9UUCwgdmFsaWRhdGVPVFAsIHNlbmRPVFBFbWFpbCwgdHlwZSBPVFBFbWFpbENvbmZpZyB9IGZyb20gJy4uL2xpYi9vdHAnO1xuXG5mdW5jdGlvbiBnZXRVc2VyRnJvbVJlcXVlc3QocmVxOiBhbnkpOiB7IHVzZXI6IHN0cmluZzsgcm9sZTogc3RyaW5nIH0ge1xuICBjb25zdCB1c2VyID0gKHJlcS5oZWFkZXJzPy5bJ3gtZGVmZW5kZXItdXNlciddIGFzIHN0cmluZykgfHwgJ2Rhc2hib2FyZC11c2VyJztcbiAgY29uc3Qgcm9sZSA9IChyZXEuaGVhZGVycz8uWyd4LWRlZmVuZGVyLXJvbGUnXSBhcyBzdHJpbmcpIHx8ICdkZWZlbmRlcl9vcGVyYXRvcic7XG4gIHJldHVybiB7IHVzZXIsIHJvbGUgfTtcbn1cblxuZnVuY3Rpb24gZ2V0T1RQQ29uZmlnKCk6IE9UUEVtYWlsQ29uZmlnIHtcbiAgcmV0dXJuIHtcbiAgICBzbXRwSG9zdDogcHJvY2Vzcy5lbnYuU01UUF9IT1NULFxuICAgIHNtdHBQb3J0OiBwcm9jZXNzLmVudi5TTVRQX1BPUlQgPyBwYXJzZUludChwcm9jZXNzLmVudi5TTVRQX1BPUlQsIDEwKSA6IDU4NyxcbiAgICBzbXRwVXNlcjogcHJvY2Vzcy5lbnYuU01UUF9VU0VSLFxuICAgIHNtdHBQYXNzOiBwcm9jZXNzLmVudi5TTVRQX1BBU1MsXG4gICAgb3RwUmVjaXBpZW50RW1haWw6IHByb2Nlc3MuZW52Lk9UUF9SRUNJUElFTlRfRU1BSUwsXG4gICAgc210cFNlY3VyZTogcHJvY2Vzcy5lbnYuU01UUF9TRUNVUkUgPT09ICd0cnVlJyxcbiAgfTtcbn1cblxuZnVuY3Rpb24gb3RwQ29udGV4dChib2R5OiB7IG90cF9jb250ZXh0X2lkPzogc3RyaW5nOyBtYWNoaW5lX2lkPzogc3RyaW5nIH0pOiBzdHJpbmcge1xuICBjb25zdCBjID0gKGJvZHkub3RwX2NvbnRleHRfaWQgfHwgYm9keS5tYWNoaW5lX2lkIHx8ICcnKS50cmltKCk7XG4gIHJldHVybiBjO1xufVxuXG5hc3luYyBmdW5jdGlvbiB3cml0ZUF1ZGl0TG9nKFxuICBjbGllbnQ6IGFueSxcbiAgZW50cnk6IHtcbiAgICBhY3Rpb246IHN0cmluZztcbiAgICBtYWNoaW5lX2lkOiBzdHJpbmc7XG4gICAgY29tcHV0ZXJfZG5zX25hbWU6IHN0cmluZztcbiAgICBwZXJmb3JtZWRfYnk6IHN0cmluZztcbiAgICByb2xlOiBzdHJpbmc7XG4gICAgc3RhdHVzOiBzdHJpbmc7XG4gICAgbWVzc2FnZTogc3RyaW5nO1xuICAgIHNvdXJjZV9pcD86IHN0cmluZztcbiAgICBvdHBfdmVyaWZpZWQ/OiBib29sZWFuO1xuICAgIGNvbW1lbnQ/OiBzdHJpbmc7XG4gIH1cbikge1xuICB0cnkge1xuICAgIGF3YWl0IGNsaWVudC5pbmRleCh7XG4gICAgICBpbmRleDogREVGRU5ERVJfQVVESVRfTE9HX0lOREVYLFxuICAgICAgYm9keTogeyAuLi5lbnRyeSwgdGltZXN0YW1wOiBuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCkgfSxcbiAgICB9KTtcbiAgfSBjYXRjaCAoZXJyKSB7XG4gICAgY29uc29sZS5lcnJvcignW0RlZmVuZGVyXSBBdWRpdCBsb2cgd3JpdGUgZmFpbGVkOicsIGVycik7XG4gIH1cbn1cblxuY29uc3Qgc2NhblR5cGVTY2hlbWEgPSBzY2hlbWEub25lT2YoW3NjaGVtYS5saXRlcmFsKCdRdWljaycpLCBzY2hlbWEubGl0ZXJhbCgnRnVsbCcpXSk7XG5jb25zdCBpc29sYXRpb25UeXBlU2NoZW1hID0gc2NoZW1hLm9uZU9mKFtcbiAgc2NoZW1hLmxpdGVyYWwoJ0Z1bGwnKSxcbiAgc2NoZW1hLmxpdGVyYWwoJ1NlbGVjdGl2ZScpLFxuICBzY2hlbWEubGl0ZXJhbCgnVW5NYW5hZ2VkRGV2aWNlJyksXG5dKTtcblxuLyoqIE1hY2hpbmUtc2NvcGVkIGFjdGlvbnM6IE9UUCArIHJlcXVpcmVkIGNvbW1lbnQgKi9cbmNvbnN0IG1hY2hpbmVBY3Rpb25Cb2R5ID0gc2NoZW1hLm9iamVjdCh7XG4gIG1hY2hpbmVfaWQ6IHNjaGVtYS5zdHJpbmcoKSxcbiAgY29tcHV0ZXJfZG5zX25hbWU6IHNjaGVtYS5tYXliZShzY2hlbWEuc3RyaW5nKCkpLFxuICBjb21tZW50OiBzY2hlbWEuc3RyaW5nKCksXG4gIG90cDogc2NoZW1hLnN0cmluZygpLFxuICBvdHBfY29udGV4dF9pZDogc2NoZW1hLm1heWJlKHNjaGVtYS5zdHJpbmcoKSksXG4gIHNjYW5fdHlwZTogc2NoZW1hLm1heWJlKHNjYW5UeXBlU2NoZW1hKSxcbiAgaXNvbGF0aW9uX3R5cGU6IHNjaGVtYS5tYXliZShpc29sYXRpb25UeXBlU2NoZW1hKSxcbn0pO1xuXG5leHBvcnQgZnVuY3Rpb24gcmVnaXN0ZXJEZWZlbmRlckFjdGlvblJvdXRlcyhyb3V0ZXI6IElSb3V0ZXIpIHtcbiAgY29uc3QgcnVuTWFjaGluZUFjdGlvbiA9IChcbiAgICBwYXRoOiBzdHJpbmcsXG4gICAgYWN0aW9uTmFtZTogc3RyaW5nLFxuICAgIGZuOiAoXG4gICAgICBjZmc6IE5vbk51bGxhYmxlPFJldHVyblR5cGU8dHlwZW9mIGdldE1kZUNvbmZpZz4+LFxuICAgICAgYm9keToge1xuICAgICAgICBtYWNoaW5lX2lkOiBzdHJpbmc7XG4gICAgICAgIGNvbW1lbnQ6IHN0cmluZztcbiAgICAgICAgc2Nhbl90eXBlPzogJ1F1aWNrJyB8ICdGdWxsJztcbiAgICAgICAgaXNvbGF0aW9uX3R5cGU/OiAnRnVsbCcgfCAnU2VsZWN0aXZlJyB8ICdVbk1hbmFnZWREZXZpY2UnO1xuICAgICAgfVxuICAgICkgPT4gUHJvbWlzZTx1bmtub3duPlxuICApID0+IHtcbiAgICByb3V0ZXIucG9zdChcbiAgICAgIHsgcGF0aCwgdmFsaWRhdGU6IHsgYm9keTogbWFjaGluZUFjdGlvbkJvZHkgfSB9LFxuICAgICAgYXN5bmMgKGNvbnRleHQsIHJlcSwgcmVzKSA9PiB7XG4gICAgICAgIGNvbnN0IGNvbmZpZyA9IGdldE1kZUNvbmZpZygpO1xuICAgICAgICBpZiAoIWNvbmZpZykge1xuICAgICAgICAgIHJldHVybiByZXMuY3VzdG9tRXJyb3Ioe1xuICAgICAgICAgICAgc3RhdHVzQ29kZTogNTAzLFxuICAgICAgICAgICAgYm9keTogJ0RlZmVuZGVyIGNyZWRlbnRpYWxzIG5vdCBjb25maWd1cmVkLicsXG4gICAgICAgICAgfSk7XG4gICAgICAgIH1cbiAgICAgICAgY29uc3QgeyB1c2VyLCByb2xlIH0gPSBnZXRVc2VyRnJvbVJlcXVlc3QocmVxKTtcbiAgICAgICAgY29uc3QgY2xpZW50ID0gY29udGV4dC5jb3JlLm9wZW5zZWFyY2guY2xpZW50LmFzQ3VycmVudFVzZXI7XG4gICAgICAgIGNvbnN0IGJvZHkgPSByZXEuYm9keSBhcyB7XG4gICAgICAgICAgbWFjaGluZV9pZDogc3RyaW5nO1xuICAgICAgICAgIGNvbXB1dGVyX2Ruc19uYW1lPzogc3RyaW5nO1xuICAgICAgICAgIGNvbW1lbnQ6IHN0cmluZztcbiAgICAgICAgICBvdHA6IHN0cmluZztcbiAgICAgICAgICBvdHBfY29udGV4dF9pZD86IHN0cmluZztcbiAgICAgICAgICBzY2FuX3R5cGU/OiAnUXVpY2snIHwgJ0Z1bGwnO1xuICAgICAgICAgIGlzb2xhdGlvbl90eXBlPzogJ0Z1bGwnIHwgJ1NlbGVjdGl2ZScgfCAnVW5NYW5hZ2VkRGV2aWNlJztcbiAgICAgICAgfTtcbiAgICAgICAgY29uc3QgY29tbWVudCA9IChib2R5LmNvbW1lbnQgfHwgJycpLnRyaW0oKTtcbiAgICAgICAgaWYgKCFjb21tZW50KSB7XG4gICAgICAgICAgcmV0dXJuIHJlcy5jdXN0b21FcnJvcih7IHN0YXR1c0NvZGU6IDQwMCwgYm9keTogJ0NvbW1lbnQgaXMgcmVxdWlyZWQuJyB9KTtcbiAgICAgICAgfVxuICAgICAgICBjb25zdCBjdHggPSBvdHBDb250ZXh0KGJvZHkpO1xuICAgICAgICBpZiAoIWN0eCkge1xuICAgICAgICAgIHJldHVybiByZXMuY3VzdG9tRXJyb3IoeyBzdGF0dXNDb2RlOiA0MDAsIGJvZHk6ICdtYWNoaW5lX2lkIG9yIG90cF9jb250ZXh0X2lkIHJlcXVpcmVkLicgfSk7XG4gICAgICAgIH1cbiAgICAgICAgY29uc3Qgb3RwQ2hlY2sgPSB2YWxpZGF0ZU9UUChjdHgsIGFjdGlvbk5hbWUsIGJvZHkub3RwIHx8ICcnKTtcbiAgICAgICAgaWYgKCFvdHBDaGVjay52YWxpZCkge1xuICAgICAgICAgIHJldHVybiByZXMuY3VzdG9tRXJyb3IoeyBzdGF0dXNDb2RlOiA0MDAsIGJvZHk6IG90cENoZWNrLnJlYXNvbiB8fCAnT1RQIHJlcXVpcmVkJyB9KTtcbiAgICAgICAgfVxuICAgICAgICBjb25zdCBkZXZpY2VOYW1lID0gYm9keS5jb21wdXRlcl9kbnNfbmFtZSB8fCBib2R5Lm1hY2hpbmVfaWQ7XG5cbiAgICAgICAgdHJ5IHtcbiAgICAgICAgICBjb25zdCByZXN1bHQgPSBhd2FpdCBmbihjb25maWcsIHtcbiAgICAgICAgICAgIG1hY2hpbmVfaWQ6IGJvZHkubWFjaGluZV9pZCxcbiAgICAgICAgICAgIGNvbW1lbnQsXG4gICAgICAgICAgICBzY2FuX3R5cGU6IGJvZHkuc2Nhbl90eXBlLFxuICAgICAgICAgICAgaXNvbGF0aW9uX3R5cGU6IGJvZHkuaXNvbGF0aW9uX3R5cGUsXG4gICAgICAgICAgfSk7XG4gICAgICAgICAgY29uc3QgbWVzc2FnZSA9IEpTT04uc3RyaW5naWZ5KHJlc3VsdCkuc2xpY2UoMCwgMjAwMCk7XG4gICAgICAgICAgYXdhaXQgd3JpdGVBdWRpdExvZyhjbGllbnQsIHtcbiAgICAgICAgICAgIGFjdGlvbjogYWN0aW9uTmFtZSxcbiAgICAgICAgICAgIG1hY2hpbmVfaWQ6IGJvZHkubWFjaGluZV9pZCxcbiAgICAgICAgICAgIGNvbXB1dGVyX2Ruc19uYW1lOiBkZXZpY2VOYW1lLFxuICAgICAgICAgICAgcGVyZm9ybWVkX2J5OiB1c2VyLFxuICAgICAgICAgICAgcm9sZSxcbiAgICAgICAgICAgIHN0YXR1czogJ3N1Y2Nlc3MnLFxuICAgICAgICAgICAgbWVzc2FnZSxcbiAgICAgICAgICAgIHNvdXJjZV9pcDogKHJlcSBhcyBhbnkpLmluZm8/LnJlbW90ZUFkZHJlc3MsXG4gICAgICAgICAgICBvdHBfdmVyaWZpZWQ6IHRydWUsXG4gICAgICAgICAgICBjb21tZW50LFxuICAgICAgICAgIH0pO1xuICAgICAgICAgIHJldHVybiByZXMub2soe1xuICAgICAgICAgICAgYm9keToge1xuICAgICAgICAgICAgICBzdWNjZXNzOiB0cnVlLFxuICAgICAgICAgICAgICBhY3Rpb246IGFjdGlvbk5hbWUsXG4gICAgICAgICAgICAgIG1hY2hpbmVfaWQ6IGJvZHkubWFjaGluZV9pZCxcbiAgICAgICAgICAgICAgbWVzc2FnZSxcbiAgICAgICAgICAgICAgdGltZXN0YW1wOiBuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCksXG4gICAgICAgICAgICB9LFxuICAgICAgICAgIH0pO1xuICAgICAgICB9IGNhdGNoIChlcnI6IHVua25vd24pIHtcbiAgICAgICAgICBhd2FpdCB3cml0ZUF1ZGl0TG9nKGNsaWVudCwge1xuICAgICAgICAgICAgYWN0aW9uOiBhY3Rpb25OYW1lLFxuICAgICAgICAgICAgbWFjaGluZV9pZDogYm9keS5tYWNoaW5lX2lkLFxuICAgICAgICAgICAgY29tcHV0ZXJfZG5zX25hbWU6IGRldmljZU5hbWUsXG4gICAgICAgICAgICBwZXJmb3JtZWRfYnk6IHVzZXIsXG4gICAgICAgICAgICByb2xlLFxuICAgICAgICAgICAgc3RhdHVzOiAnZmFpbHVyZScsXG4gICAgICAgICAgICBtZXNzYWdlOiBlcnIgaW5zdGFuY2VvZiBFcnJvciA/IGVyci5tZXNzYWdlIDogU3RyaW5nKGVyciksXG4gICAgICAgICAgICBzb3VyY2VfaXA6IChyZXEgYXMgYW55KS5pbmZvPy5yZW1vdGVBZGRyZXNzLFxuICAgICAgICAgICAgb3RwX3ZlcmlmaWVkOiB0cnVlLFxuICAgICAgICAgICAgY29tbWVudCxcbiAgICAgICAgICB9KTtcbiAgICAgICAgICByZXR1cm4gcmVzLmN1c3RvbUVycm9yKHtcbiAgICAgICAgICAgIHN0YXR1c0NvZGU6IG1kZUVycm9yU3RhdHVzKGVyciksXG4gICAgICAgICAgICBib2R5OiBlcnIgaW5zdGFuY2VvZiBFcnJvciA/IGVyci5tZXNzYWdlIDogU3RyaW5nKGVyciksXG4gICAgICAgICAgfSk7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICApO1xuICB9O1xuXG4gIHJ1bk1hY2hpbmVBY3Rpb24oJy9hcGkvZGVmZW5kZXJfcGx1Z2luL2FjdGlvbnMvYW50aXZpcnVzLXNjYW4nLCAnYW50aXZpcnVzX3NjYW4nLCAoY2ZnLCBiKSA9PlxuICAgIHJ1bkFudGl2aXJ1c1NjYW4oY2ZnLCBiLm1hY2hpbmVfaWQsIGIuY29tbWVudCwgYi5zY2FuX3R5cGUgfHwgJ1F1aWNrJylcbiAgKTtcblxuICBydW5NYWNoaW5lQWN0aW9uKCcvYXBpL2RlZmVuZGVyX3BsdWdpbi9hY3Rpb25zL2lzb2xhdGUnLCAnaXNvbGF0ZScsIChjZmcsIGIpID0+XG4gICAgaXNvbGF0ZU1hY2hpbmUoY2ZnLCBiLm1hY2hpbmVfaWQsIGIuY29tbWVudCwgYi5pc29sYXRpb25fdHlwZSB8fCAnRnVsbCcpXG4gICk7XG5cbiAgcnVuTWFjaGluZUFjdGlvbignL2FwaS9kZWZlbmRlcl9wbHVnaW4vYWN0aW9ucy91bmlzb2xhdGUnLCAndW5pc29sYXRlJywgKGNmZywgYikgPT5cbiAgICB1bmlzb2xhdGVNYWNoaW5lKGNmZywgYi5tYWNoaW5lX2lkLCBiLmNvbW1lbnQpXG4gICk7XG5cbiAgcnVuTWFjaGluZUFjdGlvbihcbiAgICAnL2FwaS9kZWZlbmRlcl9wbHVnaW4vYWN0aW9ucy9yZXN0cmljdC1jb2RlLWV4ZWN1dGlvbicsXG4gICAgJ3Jlc3RyaWN0X2NvZGVfZXhlY3V0aW9uJyxcbiAgICAoY2ZnLCBiKSA9PiByZXN0cmljdENvZGVFeGVjdXRpb24oY2ZnLCBiLm1hY2hpbmVfaWQsIGIuY29tbWVudClcbiAgKTtcblxuICBydW5NYWNoaW5lQWN0aW9uKFxuICAgICcvYXBpL2RlZmVuZGVyX3BsdWdpbi9hY3Rpb25zL3VucmVzdHJpY3QtY29kZS1leGVjdXRpb24nLFxuICAgICd1bnJlc3RyaWN0X2NvZGVfZXhlY3V0aW9uJyxcbiAgICAoY2ZnLCBiKSA9PiB1bnJlc3RyaWN0Q29kZUV4ZWN1dGlvbihjZmcsIGIubWFjaGluZV9pZCwgYi5jb21tZW50KVxuICApO1xuXG4gIHJ1bk1hY2hpbmVBY3Rpb24oXG4gICAgJy9hcGkvZGVmZW5kZXJfcGx1Z2luL2FjdGlvbnMvY29sbGVjdC1pbnZlc3RpZ2F0aW9uLXBhY2thZ2UnLFxuICAgICdjb2xsZWN0X2ludmVzdGlnYXRpb25fcGFja2FnZScsXG4gICAgKGNmZywgYikgPT4gY29sbGVjdEludmVzdGlnYXRpb25QYWNrYWdlKGNmZywgYi5tYWNoaW5lX2lkLCBiLmNvbW1lbnQpXG4gICk7XG5cbiAgcnVuTWFjaGluZUFjdGlvbignL2FwaS9kZWZlbmRlcl9wbHVnaW4vYWN0aW9ucy9vZmZib2FyZCcsICdvZmZib2FyZF9tYWNoaW5lJywgKGNmZywgYikgPT5cbiAgICBvZmZib2FyZE1hY2hpbmUoY2ZnLCBiLm1hY2hpbmVfaWQsIGIuY29tbWVudClcbiAgKTtcblxuICBjb25zdCBzdG9wUXVhcmFudGluZUJvZHkgPSBzY2hlbWEub2JqZWN0KHtcbiAgICBtYWNoaW5lX2lkOiBzY2hlbWEuc3RyaW5nKCksXG4gICAgY29tcHV0ZXJfZG5zX25hbWU6IHNjaGVtYS5tYXliZShzY2hlbWEuc3RyaW5nKCkpLFxuICAgIHNoYTE6IHNjaGVtYS5zdHJpbmcoKSxcbiAgICBjb21tZW50OiBzY2hlbWEuc3RyaW5nKCksXG4gICAgb3RwOiBzY2hlbWEuc3RyaW5nKCksXG4gICAgb3RwX2NvbnRleHRfaWQ6IHNjaGVtYS5tYXliZShzY2hlbWEuc3RyaW5nKCkpLFxuICB9KTtcblxuICByb3V0ZXIucG9zdChcbiAgICB7IHBhdGg6ICcvYXBpL2RlZmVuZGVyX3BsdWdpbi9hY3Rpb25zL3N0b3AtYW5kLXF1YXJhbnRpbmUnLCB2YWxpZGF0ZTogeyBib2R5OiBzdG9wUXVhcmFudGluZUJvZHkgfSB9LFxuICAgIGFzeW5jIChjb250ZXh0LCByZXEsIHJlcykgPT4ge1xuICAgICAgY29uc3QgY29uZmlnID0gZ2V0TWRlQ29uZmlnKCk7XG4gICAgICBpZiAoIWNvbmZpZykge1xuICAgICAgICByZXR1cm4gcmVzLmN1c3RvbUVycm9yKHsgc3RhdHVzQ29kZTogNTAzLCBib2R5OiAnRGVmZW5kZXIgbm90IGNvbmZpZ3VyZWQuJyB9KTtcbiAgICAgIH1cbiAgICAgIGNvbnN0IHsgdXNlciwgcm9sZSB9ID0gZ2V0VXNlckZyb21SZXF1ZXN0KHJlcSk7XG4gICAgICBjb25zdCBjbGllbnQgPSBjb250ZXh0LmNvcmUub3BlbnNlYXJjaC5jbGllbnQuYXNDdXJyZW50VXNlcjtcbiAgICAgIGNvbnN0IGJvZHkgPSByZXEuYm9keSBhcyB7XG4gICAgICAgIG1hY2hpbmVfaWQ6IHN0cmluZztcbiAgICAgICAgY29tcHV0ZXJfZG5zX25hbWU/OiBzdHJpbmc7XG4gICAgICAgIHNoYTE6IHN0cmluZztcbiAgICAgICAgY29tbWVudDogc3RyaW5nO1xuICAgICAgICBvdHA6IHN0cmluZztcbiAgICAgICAgb3RwX2NvbnRleHRfaWQ/OiBzdHJpbmc7XG4gICAgICB9O1xuICAgICAgY29uc3QgY29tbWVudCA9IChib2R5LmNvbW1lbnQgfHwgJycpLnRyaW0oKTtcbiAgICAgIGlmICghY29tbWVudCkge1xuICAgICAgICByZXR1cm4gcmVzLmN1c3RvbUVycm9yKHsgc3RhdHVzQ29kZTogNDAwLCBib2R5OiAnQ29tbWVudCBpcyByZXF1aXJlZC4nIH0pO1xuICAgICAgfVxuICAgICAgY29uc3QgY3R4ID0gb3RwQ29udGV4dChib2R5KTtcbiAgICAgIGlmICghY3R4KSB7XG4gICAgICAgIHJldHVybiByZXMuY3VzdG9tRXJyb3IoeyBzdGF0dXNDb2RlOiA0MDAsIGJvZHk6ICdtYWNoaW5lX2lkIG9yIG90cF9jb250ZXh0X2lkIHJlcXVpcmVkLicgfSk7XG4gICAgICB9XG4gICAgICBjb25zdCBvdHBDaGVjayA9IHZhbGlkYXRlT1RQKGN0eCwgJ3N0b3BfYW5kX3F1YXJhbnRpbmUnLCBib2R5Lm90cCB8fCAnJyk7XG4gICAgICBpZiAoIW90cENoZWNrLnZhbGlkKSB7XG4gICAgICAgIHJldHVybiByZXMuY3VzdG9tRXJyb3IoeyBzdGF0dXNDb2RlOiA0MDAsIGJvZHk6IG90cENoZWNrLnJlYXNvbiB8fCAnT1RQIHJlcXVpcmVkJyB9KTtcbiAgICAgIH1cbiAgICAgIGNvbnN0IGRldmljZU5hbWUgPSBib2R5LmNvbXB1dGVyX2Ruc19uYW1lIHx8IGJvZHkubWFjaGluZV9pZDtcbiAgICAgIHRyeSB7XG4gICAgICAgIGNvbnN0IHJlc3VsdCA9IGF3YWl0IHN0b3BBbmRRdWFyYW50aW5lRmlsZShcbiAgICAgICAgICBjb25maWcsXG4gICAgICAgICAgYm9keS5tYWNoaW5lX2lkLFxuICAgICAgICAgIGNvbW1lbnQsXG4gICAgICAgICAgYm9keS5zaGExLnRyaW0oKVxuICAgICAgICApO1xuICAgICAgICBjb25zdCBtZXNzYWdlID0gSlNPTi5zdHJpbmdpZnkocmVzdWx0KS5zbGljZSgwLCAyMDAwKTtcbiAgICAgICAgYXdhaXQgd3JpdGVBdWRpdExvZyhjbGllbnQsIHtcbiAgICAgICAgICBhY3Rpb246ICdzdG9wX2FuZF9xdWFyYW50aW5lJyxcbiAgICAgICAgICBtYWNoaW5lX2lkOiBib2R5Lm1hY2hpbmVfaWQsXG4gICAgICAgICAgY29tcHV0ZXJfZG5zX25hbWU6IGRldmljZU5hbWUsXG4gICAgICAgICAgcGVyZm9ybWVkX2J5OiB1c2VyLFxuICAgICAgICAgIHJvbGUsXG4gICAgICAgICAgc3RhdHVzOiAnc3VjY2VzcycsXG4gICAgICAgICAgbWVzc2FnZSxcbiAgICAgICAgICBzb3VyY2VfaXA6IChyZXEgYXMgYW55KS5pbmZvPy5yZW1vdGVBZGRyZXNzLFxuICAgICAgICAgIG90cF92ZXJpZmllZDogdHJ1ZSxcbiAgICAgICAgICBjb21tZW50LFxuICAgICAgICB9KTtcbiAgICAgICAgcmV0dXJuIHJlcy5vayh7XG4gICAgICAgICAgYm9keTogeyBzdWNjZXNzOiB0cnVlLCBhY3Rpb246ICdzdG9wX2FuZF9xdWFyYW50aW5lJywgbWFjaGluZV9pZDogYm9keS5tYWNoaW5lX2lkLCBtZXNzYWdlIH0sXG4gICAgICAgIH0pO1xuICAgICAgfSBjYXRjaCAoZXJyOiB1bmtub3duKSB7XG4gICAgICAgIGF3YWl0IHdyaXRlQXVkaXRMb2coY2xpZW50LCB7XG4gICAgICAgICAgYWN0aW9uOiAnc3RvcF9hbmRfcXVhcmFudGluZScsXG4gICAgICAgICAgbWFjaGluZV9pZDogYm9keS5tYWNoaW5lX2lkLFxuICAgICAgICAgIGNvbXB1dGVyX2Ruc19uYW1lOiBkZXZpY2VOYW1lLFxuICAgICAgICAgIHBlcmZvcm1lZF9ieTogdXNlcixcbiAgICAgICAgICByb2xlLFxuICAgICAgICAgIHN0YXR1czogJ2ZhaWx1cmUnLFxuICAgICAgICAgIG1lc3NhZ2U6IGVyciBpbnN0YW5jZW9mIEVycm9yID8gZXJyLm1lc3NhZ2UgOiBTdHJpbmcoZXJyKSxcbiAgICAgICAgICBzb3VyY2VfaXA6IChyZXEgYXMgYW55KS5pbmZvPy5yZW1vdGVBZGRyZXNzLFxuICAgICAgICAgIG90cF92ZXJpZmllZDogdHJ1ZSxcbiAgICAgICAgICBjb21tZW50LFxuICAgICAgICB9KTtcbiAgICAgICAgcmV0dXJuIHJlcy5jdXN0b21FcnJvcih7XG4gICAgICAgICAgc3RhdHVzQ29kZTogbWRlRXJyb3JTdGF0dXMoZXJyKSxcbiAgICAgICAgICBib2R5OiBlcnIgaW5zdGFuY2VvZiBFcnJvciA/IGVyci5tZXNzYWdlIDogU3RyaW5nKGVyciksXG4gICAgICAgIH0pO1xuICAgICAgfVxuICAgIH1cbiAgKTtcblxuICBjb25zdCBjYW5jZWxBY3Rpb25Cb2R5ID0gc2NoZW1hLm9iamVjdCh7XG4gICAgYWN0aW9uX2lkOiBzY2hlbWEuc3RyaW5nKCksXG4gICAgbWFjaGluZV9pZDogc2NoZW1hLm1heWJlKHNjaGVtYS5zdHJpbmcoKSksXG4gICAgY29tcHV0ZXJfZG5zX25hbWU6IHNjaGVtYS5tYXliZShzY2hlbWEuc3RyaW5nKCkpLFxuICAgIGNvbW1lbnQ6IHNjaGVtYS5zdHJpbmcoKSxcbiAgICBvdHA6IHNjaGVtYS5zdHJpbmcoKSxcbiAgfSk7XG5cbiAgcm91dGVyLnBvc3QoXG4gICAgeyBwYXRoOiAnL2FwaS9kZWZlbmRlcl9wbHVnaW4vYWN0aW9ucy9jYW5jZWwtbWFjaGluZS1hY3Rpb24nLCB2YWxpZGF0ZTogeyBib2R5OiBjYW5jZWxBY3Rpb25Cb2R5IH0gfSxcbiAgICBhc3luYyAoY29udGV4dCwgcmVxLCByZXMpID0+IHtcbiAgICAgIGNvbnN0IGNvbmZpZyA9IGdldE1kZUNvbmZpZygpO1xuICAgICAgaWYgKCFjb25maWcpIHtcbiAgICAgICAgcmV0dXJuIHJlcy5jdXN0b21FcnJvcih7IHN0YXR1c0NvZGU6IDUwMywgYm9keTogJ0RlZmVuZGVyIG5vdCBjb25maWd1cmVkLicgfSk7XG4gICAgICB9XG4gICAgICBjb25zdCB7IHVzZXIsIHJvbGUgfSA9IGdldFVzZXJGcm9tUmVxdWVzdChyZXEpO1xuICAgICAgY29uc3QgY2xpZW50ID0gY29udGV4dC5jb3JlLm9wZW5zZWFyY2guY2xpZW50LmFzQ3VycmVudFVzZXI7XG4gICAgICBjb25zdCBib2R5ID0gcmVxLmJvZHkgYXMge1xuICAgICAgICBhY3Rpb25faWQ6IHN0cmluZztcbiAgICAgICAgbWFjaGluZV9pZD86IHN0cmluZztcbiAgICAgICAgY29tcHV0ZXJfZG5zX25hbWU/OiBzdHJpbmc7XG4gICAgICAgIGNvbW1lbnQ6IHN0cmluZztcbiAgICAgICAgb3RwOiBzdHJpbmc7XG4gICAgICB9O1xuICAgICAgY29uc3QgY29tbWVudCA9IChib2R5LmNvbW1lbnQgfHwgJycpLnRyaW0oKTtcbiAgICAgIGlmICghY29tbWVudCkge1xuICAgICAgICByZXR1cm4gcmVzLmN1c3RvbUVycm9yKHsgc3RhdHVzQ29kZTogNDAwLCBib2R5OiAnQ29tbWVudCBpcyByZXF1aXJlZC4nIH0pO1xuICAgICAgfVxuICAgICAgY29uc3Qgb3RwQ2hlY2sgPSB2YWxpZGF0ZU9UUChib2R5LmFjdGlvbl9pZCwgJ2NhbmNlbF9tYWNoaW5lX2FjdGlvbicsIGJvZHkub3RwIHx8ICcnKTtcbiAgICAgIGlmICghb3RwQ2hlY2sudmFsaWQpIHtcbiAgICAgICAgcmV0dXJuIHJlcy5jdXN0b21FcnJvcih7IHN0YXR1c0NvZGU6IDQwMCwgYm9keTogb3RwQ2hlY2sucmVhc29uIHx8ICdPVFAgcmVxdWlyZWQnIH0pO1xuICAgICAgfVxuICAgICAgY29uc3QgZGV2aWNlTmFtZSA9IGJvZHkuY29tcHV0ZXJfZG5zX25hbWUgfHwgYm9keS5tYWNoaW5lX2lkIHx8IGJvZHkuYWN0aW9uX2lkO1xuICAgICAgdHJ5IHtcbiAgICAgICAgY29uc3QgcmVzdWx0ID0gYXdhaXQgY2FuY2VsTWFjaGluZUFjdGlvbihjb25maWcsIGJvZHkuYWN0aW9uX2lkKTtcbiAgICAgICAgY29uc3QgbWVzc2FnZSA9IEpTT04uc3RyaW5naWZ5KHJlc3VsdCkuc2xpY2UoMCwgMjAwMCk7XG4gICAgICAgIGF3YWl0IHdyaXRlQXVkaXRMb2coY2xpZW50LCB7XG4gICAgICAgICAgYWN0aW9uOiAnY2FuY2VsX21hY2hpbmVfYWN0aW9uJyxcbiAgICAgICAgICBtYWNoaW5lX2lkOiBib2R5Lm1hY2hpbmVfaWQgfHwgYm9keS5hY3Rpb25faWQsXG4gICAgICAgICAgY29tcHV0ZXJfZG5zX25hbWU6IGRldmljZU5hbWUsXG4gICAgICAgICAgcGVyZm9ybWVkX2J5OiB1c2VyLFxuICAgICAgICAgIHJvbGUsXG4gICAgICAgICAgc3RhdHVzOiAnc3VjY2VzcycsXG4gICAgICAgICAgbWVzc2FnZSxcbiAgICAgICAgICBzb3VyY2VfaXA6IChyZXEgYXMgYW55KS5pbmZvPy5yZW1vdGVBZGRyZXNzLFxuICAgICAgICAgIG90cF92ZXJpZmllZDogdHJ1ZSxcbiAgICAgICAgICBjb21tZW50LFxuICAgICAgICB9KTtcbiAgICAgICAgcmV0dXJuIHJlcy5vayh7XG4gICAgICAgICAgYm9keTogeyBzdWNjZXNzOiB0cnVlLCBhY3Rpb246ICdjYW5jZWxfbWFjaGluZV9hY3Rpb24nLCBhY3Rpb25faWQ6IGJvZHkuYWN0aW9uX2lkLCBtZXNzYWdlIH0sXG4gICAgICAgIH0pO1xuICAgICAgfSBjYXRjaCAoZXJyOiB1bmtub3duKSB7XG4gICAgICAgIGF3YWl0IHdyaXRlQXVkaXRMb2coY2xpZW50LCB7XG4gICAgICAgICAgYWN0aW9uOiAnY2FuY2VsX21hY2hpbmVfYWN0aW9uJyxcbiAgICAgICAgICBtYWNoaW5lX2lkOiBib2R5Lm1hY2hpbmVfaWQgfHwgYm9keS5hY3Rpb25faWQsXG4gICAgICAgICAgY29tcHV0ZXJfZG5zX25hbWU6IGRldmljZU5hbWUsXG4gICAgICAgICAgcGVyZm9ybWVkX2J5OiB1c2VyLFxuICAgICAgICAgIHJvbGUsXG4gICAgICAgICAgc3RhdHVzOiAnZmFpbHVyZScsXG4gICAgICAgICAgbWVzc2FnZTogZXJyIGluc3RhbmNlb2YgRXJyb3IgPyBlcnIubWVzc2FnZSA6IFN0cmluZyhlcnIpLFxuICAgICAgICAgIHNvdXJjZV9pcDogKHJlcSBhcyBhbnkpLmluZm8/LnJlbW90ZUFkZHJlc3MsXG4gICAgICAgICAgb3RwX3ZlcmlmaWVkOiB0cnVlLFxuICAgICAgICAgIGNvbW1lbnQsXG4gICAgICAgIH0pO1xuICAgICAgICByZXR1cm4gcmVzLmN1c3RvbUVycm9yKHtcbiAgICAgICAgICBzdGF0dXNDb2RlOiBtZGVFcnJvclN0YXR1cyhlcnIpLFxuICAgICAgICAgIGJvZHk6IGVyciBpbnN0YW5jZW9mIEVycm9yID8gZXJyLm1lc3NhZ2UgOiBTdHJpbmcoZXJyKSxcbiAgICAgICAgfSk7XG4gICAgICB9XG4gICAgfVxuICApO1xuXG4gIHJvdXRlci5wb3N0KFxuICAgIHtcbiAgICAgIHBhdGg6ICcvYXBpL2RlZmVuZGVyX3BsdWdpbi9hY3Rpb25zL3JlcXVlc3Qtb3RwJyxcbiAgICAgIHZhbGlkYXRlOiB7XG4gICAgICAgIGJvZHk6IHNjaGVtYS5vYmplY3Qoe1xuICAgICAgICAgIGFjdGlvbjogc2NoZW1hLnN0cmluZygpLFxuICAgICAgICAgIG1hY2hpbmVfaWQ6IHNjaGVtYS5tYXliZShzY2hlbWEuc3RyaW5nKCkpLFxuICAgICAgICAgIGNvbXB1dGVyX2Ruc19uYW1lOiBzY2hlbWEubWF5YmUoc2NoZW1hLnN0cmluZygpKSxcbiAgICAgICAgICBvdHBfY29udGV4dF9pZDogc2NoZW1hLm1heWJlKHNjaGVtYS5zdHJpbmcoKSksXG4gICAgICAgIH0pLFxuICAgICAgfSxcbiAgICB9LFxuICAgIGFzeW5jIChfY29udGV4dCwgcmVxLCByZXMpID0+IHtcbiAgICAgIGNvbnN0IHsgbWFjaGluZV9pZCwgYWN0aW9uLCBjb21wdXRlcl9kbnNfbmFtZSwgb3RwX2NvbnRleHRfaWQgfSA9IHJlcS5ib2R5IGFzIHtcbiAgICAgICAgbWFjaGluZV9pZD86IHN0cmluZztcbiAgICAgICAgYWN0aW9uOiBzdHJpbmc7XG4gICAgICAgIGNvbXB1dGVyX2Ruc19uYW1lPzogc3RyaW5nO1xuICAgICAgICBvdHBfY29udGV4dF9pZD86IHN0cmluZztcbiAgICAgIH07XG4gICAgICBpZiAoIURFU1RSVUNUSVZFX0FDVElPTlMuaW5jbHVkZXMoYWN0aW9uKSkge1xuICAgICAgICByZXR1cm4gcmVzLmN1c3RvbUVycm9yKHtcbiAgICAgICAgICBzdGF0dXNDb2RlOiA0MDAsXG4gICAgICAgICAgYm9keTogJ1RoaXMgYWN0aW9uIGRvZXMgbm90IHVzZSB0aGlzIE9UUCBmbG93LicsXG4gICAgICAgIH0pO1xuICAgICAgfVxuICAgICAgY29uc3QgY3R4ID0gKG90cF9jb250ZXh0X2lkIHx8IG1hY2hpbmVfaWQgfHwgJycpLnRyaW0oKTtcbiAgICAgIGlmICghY3R4KSB7XG4gICAgICAgIHJldHVybiByZXMuY3VzdG9tRXJyb3Ioe1xuICAgICAgICAgIHN0YXR1c0NvZGU6IDQwMCxcbiAgICAgICAgICBib2R5OiAnUHJvdmlkZSBtYWNoaW5lX2lkIG9yIG90cF9jb250ZXh0X2lkIChlLmcuIGFjdGlvbiBpZCBmb3IgY2FuY2VsKS4nLFxuICAgICAgICB9KTtcbiAgICAgIH1cbiAgICAgIGNvbnN0IG90cCA9IGdlbmVyYXRlT1RQKCk7XG4gICAgICBzdG9yZU9UUChjdHgsIGFjdGlvbiwgb3RwKTtcbiAgICAgIGNvbnN0IGVtYWlsUmVzdWx0ID0gYXdhaXQgc2VuZE9UUEVtYWlsKFxuICAgICAgICBnZXRPVFBDb25maWcoKSxcbiAgICAgICAgb3RwLFxuICAgICAgICBjb21wdXRlcl9kbnNfbmFtZSB8fCBjdHgsXG4gICAgICAgIGFjdGlvblxuICAgICAgKTtcbiAgICAgIHJldHVybiByZXMub2soe1xuICAgICAgICBib2R5OiB7XG4gICAgICAgICAgc3VjY2VzczogdHJ1ZSxcbiAgICAgICAgICBtZXNzYWdlOiBlbWFpbFJlc3VsdC5zZW50XG4gICAgICAgICAgICA/ICdPVFAgc2VudCB0byBjb25maWd1cmVkIHJlY2lwaWVudC4nXG4gICAgICAgICAgICA6ICdPVFAgZ2VuZXJhdGVkIChjb25maWd1cmUgU01UUCBmb3IgZW1haWwgZGVsaXZlcnkpLicsXG4gICAgICAgICAgZGV2X21vZGU6IGVtYWlsUmVzdWx0LmRldk1vZGUsXG4gICAgICAgICAgb3RwOiBlbWFpbFJlc3VsdC5kZXZNb2RlID8gZW1haWxSZXN1bHQub3RwIDogdW5kZWZpbmVkLFxuICAgICAgICB9LFxuICAgICAgfSk7XG4gICAgfVxuICApO1xuXG4gIGNvbnN0IGluZGljYXRvckNyZWF0ZUJvZHkgPSBzY2hlbWEub2JqZWN0KHtcbiAgICBtYWNoaW5lX2lkOiBzY2hlbWEuc3RyaW5nKCksXG4gICAgY29tcHV0ZXJfZG5zX25hbWU6IHNjaGVtYS5tYXliZShzY2hlbWEuc3RyaW5nKCkpLFxuICAgIGNvbW1lbnQ6IHNjaGVtYS5zdHJpbmcoKSxcbiAgICBvdHA6IHNjaGVtYS5zdHJpbmcoKSxcbiAgICBvdHBfY29udGV4dF9pZDogc2NoZW1hLm1heWJlKHNjaGVtYS5zdHJpbmcoKSksXG4gICAgaW5kaWNhdG9yX3R5cGU6IHNjaGVtYS5vbmVPZihbXG4gICAgICBzY2hlbWEubGl0ZXJhbCgnRmlsZVNoYTEnKSxcbiAgICAgIHNjaGVtYS5saXRlcmFsKCdGaWxlU2hhMjU2JyksXG4gICAgICBzY2hlbWEubGl0ZXJhbCgnSXBBZGRyZXNzJyksXG4gICAgICBzY2hlbWEubGl0ZXJhbCgnRG9tYWluTmFtZScpLFxuICAgICAgc2NoZW1hLmxpdGVyYWwoJ1VybCcpLFxuICAgIF0pLFxuICAgIGluZGljYXRvcl92YWx1ZTogc2NoZW1hLnN0cmluZygpLFxuICAgIHRpdGxlOiBzY2hlbWEuc3RyaW5nKCksXG4gICAgZGVzY3JpcHRpb246IHNjaGVtYS5tYXliZShzY2hlbWEuc3RyaW5nKCkpLFxuICAgIGV4cGlyYXRpb25fdGltZTogc2NoZW1hLm1heWJlKHNjaGVtYS5zdHJpbmcoKSksXG4gICAgYWN0aW9uOiBzY2hlbWEub25lT2YoW1xuICAgICAgc2NoZW1hLmxpdGVyYWwoJ0FsZXJ0JyksXG4gICAgICBzY2hlbWEubGl0ZXJhbCgnQWxlcnRBbmRCbG9jaycpLFxuICAgICAgc2NoZW1hLmxpdGVyYWwoJ0FsbG93ZWQnKSxcbiAgICAgIHNjaGVtYS5saXRlcmFsKCdCbG9jaycpLFxuICAgICAgc2NoZW1hLmxpdGVyYWwoJ0F1ZGl0JyksXG4gICAgXSksXG4gICAgc2V2ZXJpdHk6IHNjaGVtYS5vbmVPZihbXG4gICAgICBzY2hlbWEubGl0ZXJhbCgnSW5mb3JtYXRpb25hbCcpLFxuICAgICAgc2NoZW1hLmxpdGVyYWwoJ0xvdycpLFxuICAgICAgc2NoZW1hLmxpdGVyYWwoJ01lZGl1bScpLFxuICAgICAgc2NoZW1hLmxpdGVyYWwoJ0hpZ2gnKSxcbiAgICBdKSxcbiAgfSk7XG5cbiAgcm91dGVyLnBvc3QoXG4gICAgeyBwYXRoOiAnL2FwaS9kZWZlbmRlcl9wbHVnaW4vYWN0aW9ucy9jcmVhdGUtaW5kaWNhdG9yJywgdmFsaWRhdGU6IHsgYm9keTogaW5kaWNhdG9yQ3JlYXRlQm9keSB9IH0sXG4gICAgYXN5bmMgKGNvbnRleHQsIHJlcSwgcmVzKSA9PiB7XG4gICAgICBjb25zdCBjb25maWcgPSBnZXRNZGVDb25maWcoKTtcbiAgICAgIGlmICghY29uZmlnKSB7XG4gICAgICAgIHJldHVybiByZXMuY3VzdG9tRXJyb3IoeyBzdGF0dXNDb2RlOiA1MDMsIGJvZHk6ICdEZWZlbmRlciBub3QgY29uZmlndXJlZC4nIH0pO1xuICAgICAgfVxuICAgICAgY29uc3QgeyB1c2VyLCByb2xlIH0gPSBnZXRVc2VyRnJvbVJlcXVlc3QocmVxKTtcbiAgICAgIGNvbnN0IGNsaWVudCA9IGNvbnRleHQuY29yZS5vcGVuc2VhcmNoLmNsaWVudC5hc0N1cnJlbnRVc2VyO1xuICAgICAgY29uc3QgYiA9IHJlcS5ib2R5IGFzIHtcbiAgICAgICAgbWFjaGluZV9pZDogc3RyaW5nO1xuICAgICAgICBjb21wdXRlcl9kbnNfbmFtZT86IHN0cmluZztcbiAgICAgICAgY29tbWVudDogc3RyaW5nO1xuICAgICAgICBvdHA6IHN0cmluZztcbiAgICAgICAgb3RwX2NvbnRleHRfaWQ/OiBzdHJpbmc7XG4gICAgICAgIGluZGljYXRvcl90eXBlOiBDcmVhdGVJbmRpY2F0b3JQYXlsb2FkWydpbmRpY2F0b3JUeXBlJ107XG4gICAgICAgIGluZGljYXRvcl92YWx1ZTogc3RyaW5nO1xuICAgICAgICB0aXRsZTogc3RyaW5nO1xuICAgICAgICBkZXNjcmlwdGlvbj86IHN0cmluZztcbiAgICAgICAgZXhwaXJhdGlvbl90aW1lPzogc3RyaW5nO1xuICAgICAgICBhY3Rpb246IENyZWF0ZUluZGljYXRvclBheWxvYWRbJ2FjdGlvbiddO1xuICAgICAgICBzZXZlcml0eTogQ3JlYXRlSW5kaWNhdG9yUGF5bG9hZFsnc2V2ZXJpdHknXTtcbiAgICAgIH07XG4gICAgICBjb25zdCBjb21tZW50ID0gKGIuY29tbWVudCB8fCAnJykudHJpbSgpO1xuICAgICAgaWYgKCFjb21tZW50KSB7XG4gICAgICAgIHJldHVybiByZXMuY3VzdG9tRXJyb3IoeyBzdGF0dXNDb2RlOiA0MDAsIGJvZHk6ICdDb21tZW50IGlzIHJlcXVpcmVkLicgfSk7XG4gICAgICB9XG4gICAgICBjb25zdCBjdHggPSBvdHBDb250ZXh0KGIpO1xuICAgICAgaWYgKCFjdHgpIHtcbiAgICAgICAgcmV0dXJuIHJlcy5jdXN0b21FcnJvcih7IHN0YXR1c0NvZGU6IDQwMCwgYm9keTogJ21hY2hpbmVfaWQgb3Igb3RwX2NvbnRleHRfaWQgcmVxdWlyZWQuJyB9KTtcbiAgICAgIH1cbiAgICAgIGNvbnN0IG90cENoZWNrID0gdmFsaWRhdGVPVFAoY3R4LCAnY3JlYXRlX2luZGljYXRvcicsIGIub3RwIHx8ICcnKTtcbiAgICAgIGlmICghb3RwQ2hlY2sudmFsaWQpIHtcbiAgICAgICAgcmV0dXJuIHJlcy5jdXN0b21FcnJvcih7IHN0YXR1c0NvZGU6IDQwMCwgYm9keTogb3RwQ2hlY2sucmVhc29uIHx8ICdPVFAgcmVxdWlyZWQnIH0pO1xuICAgICAgfVxuICAgICAgY29uc3QgZGV2aWNlTmFtZSA9IGIuY29tcHV0ZXJfZG5zX25hbWUgfHwgYi5tYWNoaW5lX2lkO1xuICAgICAgdHJ5IHtcbiAgICAgICAgY29uc3QgcGF5bG9hZDogQ3JlYXRlSW5kaWNhdG9yUGF5bG9hZCA9IHtcbiAgICAgICAgICBpbmRpY2F0b3JWYWx1ZTogYi5pbmRpY2F0b3JfdmFsdWUsXG4gICAgICAgICAgaW5kaWNhdG9yVHlwZTogYi5pbmRpY2F0b3JfdHlwZSxcbiAgICAgICAgICB0aXRsZTogYi50aXRsZSxcbiAgICAgICAgICBkZXNjcmlwdGlvbjogYi5kZXNjcmlwdGlvbixcbiAgICAgICAgICBleHBpcmF0aW9uVGltZTogYi5leHBpcmF0aW9uX3RpbWUsXG4gICAgICAgICAgYWN0aW9uOiBiLmFjdGlvbixcbiAgICAgICAgICBzZXZlcml0eTogYi5zZXZlcml0eSxcbiAgICAgICAgfTtcbiAgICAgICAgY29uc3QgcmVzdWx0ID0gYXdhaXQgY3JlYXRlSW5kaWNhdG9yKGNvbmZpZywgcGF5bG9hZCk7XG4gICAgICAgIGNvbnN0IG1lc3NhZ2UgPSBKU09OLnN0cmluZ2lmeShyZXN1bHQpLnNsaWNlKDAsIDIwMDApO1xuICAgICAgICBhd2FpdCB3cml0ZUF1ZGl0TG9nKGNsaWVudCwge1xuICAgICAgICAgIGFjdGlvbjogJ2NyZWF0ZV9pbmRpY2F0b3InLFxuICAgICAgICAgIG1hY2hpbmVfaWQ6IGIubWFjaGluZV9pZCxcbiAgICAgICAgICBjb21wdXRlcl9kbnNfbmFtZTogZGV2aWNlTmFtZSxcbiAgICAgICAgICBwZXJmb3JtZWRfYnk6IHVzZXIsXG4gICAgICAgICAgcm9sZSxcbiAgICAgICAgICBzdGF0dXM6ICdzdWNjZXNzJyxcbiAgICAgICAgICBtZXNzYWdlLFxuICAgICAgICAgIHNvdXJjZV9pcDogKHJlcSBhcyBhbnkpLmluZm8/LnJlbW90ZUFkZHJlc3MsXG4gICAgICAgICAgb3RwX3ZlcmlmaWVkOiB0cnVlLFxuICAgICAgICAgIGNvbW1lbnQsXG4gICAgICAgIH0pO1xuICAgICAgICByZXR1cm4gcmVzLm9rKHtcbiAgICAgICAgICBib2R5OiB7XG4gICAgICAgICAgICBzdWNjZXNzOiB0cnVlLFxuICAgICAgICAgICAgYWN0aW9uOiAnY3JlYXRlX2luZGljYXRvcicsXG4gICAgICAgICAgICBtYWNoaW5lX2lkOiBiLm1hY2hpbmVfaWQsXG4gICAgICAgICAgICBtZXNzYWdlLFxuICAgICAgICAgICAgdGltZXN0YW1wOiBuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCksXG4gICAgICAgICAgfSxcbiAgICAgICAgfSk7XG4gICAgICB9IGNhdGNoIChlcnI6IHVua25vd24pIHtcbiAgICAgICAgYXdhaXQgd3JpdGVBdWRpdExvZyhjbGllbnQsIHtcbiAgICAgICAgICBhY3Rpb246ICdjcmVhdGVfaW5kaWNhdG9yJyxcbiAgICAgICAgICBtYWNoaW5lX2lkOiBiLm1hY2hpbmVfaWQsXG4gICAgICAgICAgY29tcHV0ZXJfZG5zX25hbWU6IGRldmljZU5hbWUsXG4gICAgICAgICAgcGVyZm9ybWVkX2J5OiB1c2VyLFxuICAgICAgICAgIHJvbGUsXG4gICAgICAgICAgc3RhdHVzOiAnZmFpbHVyZScsXG4gICAgICAgICAgbWVzc2FnZTogZXJyIGluc3RhbmNlb2YgRXJyb3IgPyBlcnIubWVzc2FnZSA6IFN0cmluZyhlcnIpLFxuICAgICAgICAgIHNvdXJjZV9pcDogKHJlcSBhcyBhbnkpLmluZm8/LnJlbW90ZUFkZHJlc3MsXG4gICAgICAgICAgb3RwX3ZlcmlmaWVkOiB0cnVlLFxuICAgICAgICAgIGNvbW1lbnQsXG4gICAgICAgIH0pO1xuICAgICAgICByZXR1cm4gcmVzLmN1c3RvbUVycm9yKHtcbiAgICAgICAgICBzdGF0dXNDb2RlOiBtZGVFcnJvclN0YXR1cyhlcnIpLFxuICAgICAgICAgIGJvZHk6IGVyciBpbnN0YW5jZW9mIEVycm9yID8gZXJyLm1lc3NhZ2UgOiBTdHJpbmcoZXJyKSxcbiAgICAgICAgfSk7XG4gICAgICB9XG4gICAgfVxuICApO1xuXG4gIGNvbnN0IHVwZGF0ZUluZGljYXRvckJvZHkgPSBzY2hlbWEub2JqZWN0KHtcbiAgICBpbmRpY2F0b3JfaWQ6IHNjaGVtYS5zdHJpbmcoKSxcbiAgICBtYWNoaW5lX2lkOiBzY2hlbWEubWF5YmUoc2NoZW1hLnN0cmluZygpKSxcbiAgICBjb21wdXRlcl9kbnNfbmFtZTogc2NoZW1hLm1heWJlKHNjaGVtYS5zdHJpbmcoKSksXG4gICAgY29tbWVudDogc2NoZW1hLnN0cmluZygpLFxuICAgIG90cDogc2NoZW1hLnN0cmluZygpLFxuICAgIHRpdGxlOiBzY2hlbWEubWF5YmUoc2NoZW1hLnN0cmluZygpKSxcbiAgICBkZXNjcmlwdGlvbjogc2NoZW1hLm1heWJlKHNjaGVtYS5zdHJpbmcoKSksXG4gICAgYWN0aW9uOiBzY2hlbWEubWF5YmUoXG4gICAgICBzY2hlbWEub25lT2YoW1xuICAgICAgICBzY2hlbWEubGl0ZXJhbCgnQWxlcnQnKSxcbiAgICAgICAgc2NoZW1hLmxpdGVyYWwoJ0FsZXJ0QW5kQmxvY2snKSxcbiAgICAgICAgc2NoZW1hLmxpdGVyYWwoJ0FsbG93ZWQnKSxcbiAgICAgICAgc2NoZW1hLmxpdGVyYWwoJ0Jsb2NrJyksXG4gICAgICAgIHNjaGVtYS5saXRlcmFsKCdBdWRpdCcpLFxuICAgICAgXSlcbiAgICApLFxuICAgIHNldmVyaXR5OiBzY2hlbWEubWF5YmUoXG4gICAgICBzY2hlbWEub25lT2YoW1xuICAgICAgICBzY2hlbWEubGl0ZXJhbCgnSW5mb3JtYXRpb25hbCcpLFxuICAgICAgICBzY2hlbWEubGl0ZXJhbCgnTG93JyksXG4gICAgICAgIHNjaGVtYS5saXRlcmFsKCdNZWRpdW0nKSxcbiAgICAgICAgc2NoZW1hLmxpdGVyYWwoJ0hpZ2gnKSxcbiAgICAgIF0pXG4gICAgKSxcbiAgICBleHBpcmF0aW9uX3RpbWU6IHNjaGVtYS5tYXliZShzY2hlbWEuc3RyaW5nKCkpLFxuICB9KTtcblxuICByb3V0ZXIucG9zdChcbiAgICB7IHBhdGg6ICcvYXBpL2RlZmVuZGVyX3BsdWdpbi9hY3Rpb25zL3VwZGF0ZS1pbmRpY2F0b3InLCB2YWxpZGF0ZTogeyBib2R5OiB1cGRhdGVJbmRpY2F0b3JCb2R5IH0gfSxcbiAgICBhc3luYyAoY29udGV4dCwgcmVxLCByZXMpID0+IHtcbiAgICAgIGNvbnN0IGNvbmZpZyA9IGdldE1kZUNvbmZpZygpO1xuICAgICAgaWYgKCFjb25maWcpIHtcbiAgICAgICAgcmV0dXJuIHJlcy5jdXN0b21FcnJvcih7IHN0YXR1c0NvZGU6IDUwMywgYm9keTogJ0RlZmVuZGVyIG5vdCBjb25maWd1cmVkLicgfSk7XG4gICAgICB9XG4gICAgICBjb25zdCB7IHVzZXIsIHJvbGUgfSA9IGdldFVzZXJGcm9tUmVxdWVzdChyZXEpO1xuICAgICAgY29uc3QgY2xpZW50ID0gY29udGV4dC5jb3JlLm9wZW5zZWFyY2guY2xpZW50LmFzQ3VycmVudFVzZXI7XG4gICAgICBjb25zdCBiID0gcmVxLmJvZHkgYXMge1xuICAgICAgICBpbmRpY2F0b3JfaWQ6IHN0cmluZztcbiAgICAgICAgbWFjaGluZV9pZD86IHN0cmluZztcbiAgICAgICAgY29tcHV0ZXJfZG5zX25hbWU/OiBzdHJpbmc7XG4gICAgICAgIGNvbW1lbnQ6IHN0cmluZztcbiAgICAgICAgb3RwOiBzdHJpbmc7XG4gICAgICAgIHRpdGxlPzogc3RyaW5nO1xuICAgICAgICBkZXNjcmlwdGlvbj86IHN0cmluZztcbiAgICAgICAgYWN0aW9uPzogc3RyaW5nO1xuICAgICAgICBzZXZlcml0eT86IHN0cmluZztcbiAgICAgICAgZXhwaXJhdGlvbl90aW1lPzogc3RyaW5nO1xuICAgICAgfTtcbiAgICAgIGNvbnN0IGNvbW1lbnQgPSAoYi5jb21tZW50IHx8ICcnKS50cmltKCk7XG4gICAgICBpZiAoIWNvbW1lbnQpIHtcbiAgICAgICAgcmV0dXJuIHJlcy5jdXN0b21FcnJvcih7IHN0YXR1c0NvZGU6IDQwMCwgYm9keTogJ0NvbW1lbnQgaXMgcmVxdWlyZWQuJyB9KTtcbiAgICAgIH1cbiAgICAgIGNvbnN0IG90cENoZWNrID0gdmFsaWRhdGVPVFAoYi5pbmRpY2F0b3JfaWQsICd1cGRhdGVfaW5kaWNhdG9yJywgYi5vdHAgfHwgJycpO1xuICAgICAgaWYgKCFvdHBDaGVjay52YWxpZCkge1xuICAgICAgICByZXR1cm4gcmVzLmN1c3RvbUVycm9yKHsgc3RhdHVzQ29kZTogNDAwLCBib2R5OiBvdHBDaGVjay5yZWFzb24gfHwgJ09UUCByZXF1aXJlZCcgfSk7XG4gICAgICB9XG4gICAgICBjb25zdCBkZXZpY2VOYW1lID0gYi5jb21wdXRlcl9kbnNfbmFtZSB8fCBiLm1hY2hpbmVfaWQgfHwgYi5pbmRpY2F0b3JfaWQ7XG4gICAgICBjb25zdCBwYXRjaDogUmVjb3JkPHN0cmluZywgdW5rbm93bj4gPSB7fTtcbiAgICAgIGlmIChiLnRpdGxlICE9IG51bGwpIHBhdGNoLnRpdGxlID0gYi50aXRsZTtcbiAgICAgIGlmIChiLmRlc2NyaXB0aW9uICE9IG51bGwpIHBhdGNoLmRlc2NyaXB0aW9uID0gYi5kZXNjcmlwdGlvbjtcbiAgICAgIGlmIChiLmFjdGlvbiAhPSBudWxsKSBwYXRjaC5hY3Rpb24gPSBiLmFjdGlvbjtcbiAgICAgIGlmIChiLnNldmVyaXR5ICE9IG51bGwpIHBhdGNoLnNldmVyaXR5ID0gYi5zZXZlcml0eTtcbiAgICAgIGlmIChiLmV4cGlyYXRpb25fdGltZSAhPSBudWxsKSBwYXRjaC5leHBpcmF0aW9uVGltZSA9IGIuZXhwaXJhdGlvbl90aW1lO1xuICAgICAgaWYgKE9iamVjdC5rZXlzKHBhdGNoKS5sZW5ndGggPT09IDApIHtcbiAgICAgICAgcmV0dXJuIHJlcy5jdXN0b21FcnJvcih7IHN0YXR1c0NvZGU6IDQwMCwgYm9keTogJ1Byb3ZpZGUgYXQgbGVhc3Qgb25lIGZpZWxkIHRvIHVwZGF0ZS4nIH0pO1xuICAgICAgfVxuICAgICAgdHJ5IHtcbiAgICAgICAgY29uc3QgcmVzdWx0ID0gYXdhaXQgdXBkYXRlSW5kaWNhdG9yKGNvbmZpZywgYi5pbmRpY2F0b3JfaWQsIHBhdGNoKTtcbiAgICAgICAgY29uc3QgbWVzc2FnZSA9IEpTT04uc3RyaW5naWZ5KHJlc3VsdCkuc2xpY2UoMCwgMjAwMCk7XG4gICAgICAgIGF3YWl0IHdyaXRlQXVkaXRMb2coY2xpZW50LCB7XG4gICAgICAgICAgYWN0aW9uOiAndXBkYXRlX2luZGljYXRvcicsXG4gICAgICAgICAgbWFjaGluZV9pZDogYi5tYWNoaW5lX2lkIHx8IGIuaW5kaWNhdG9yX2lkLFxuICAgICAgICAgIGNvbXB1dGVyX2Ruc19uYW1lOiBkZXZpY2VOYW1lLFxuICAgICAgICAgIHBlcmZvcm1lZF9ieTogdXNlcixcbiAgICAgICAgICByb2xlLFxuICAgICAgICAgIHN0YXR1czogJ3N1Y2Nlc3MnLFxuICAgICAgICAgIG1lc3NhZ2UsXG4gICAgICAgICAgc291cmNlX2lwOiAocmVxIGFzIGFueSkuaW5mbz8ucmVtb3RlQWRkcmVzcyxcbiAgICAgICAgICBvdHBfdmVyaWZpZWQ6IHRydWUsXG4gICAgICAgICAgY29tbWVudCxcbiAgICAgICAgfSk7XG4gICAgICAgIHJldHVybiByZXMub2soe1xuICAgICAgICAgIGJvZHk6IHtcbiAgICAgICAgICAgIHN1Y2Nlc3M6IHRydWUsXG4gICAgICAgICAgICBhY3Rpb246ICd1cGRhdGVfaW5kaWNhdG9yJyxcbiAgICAgICAgICAgIGluZGljYXRvcl9pZDogYi5pbmRpY2F0b3JfaWQsXG4gICAgICAgICAgICBtZXNzYWdlLFxuICAgICAgICAgICAgdGltZXN0YW1wOiBuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCksXG4gICAgICAgICAgfSxcbiAgICAgICAgfSk7XG4gICAgICB9IGNhdGNoIChlcnI6IHVua25vd24pIHtcbiAgICAgICAgYXdhaXQgd3JpdGVBdWRpdExvZyhjbGllbnQsIHtcbiAgICAgICAgICBhY3Rpb246ICd1cGRhdGVfaW5kaWNhdG9yJyxcbiAgICAgICAgICBtYWNoaW5lX2lkOiBiLm1hY2hpbmVfaWQgfHwgYi5pbmRpY2F0b3JfaWQsXG4gICAgICAgICAgY29tcHV0ZXJfZG5zX25hbWU6IGRldmljZU5hbWUsXG4gICAgICAgICAgcGVyZm9ybWVkX2J5OiB1c2VyLFxuICAgICAgICAgIHJvbGUsXG4gICAgICAgICAgc3RhdHVzOiAnZmFpbHVyZScsXG4gICAgICAgICAgbWVzc2FnZTogZXJyIGluc3RhbmNlb2YgRXJyb3IgPyBlcnIubWVzc2FnZSA6IFN0cmluZyhlcnIpLFxuICAgICAgICAgIHNvdXJjZV9pcDogKHJlcSBhcyBhbnkpLmluZm8/LnJlbW90ZUFkZHJlc3MsXG4gICAgICAgICAgb3RwX3ZlcmlmaWVkOiB0cnVlLFxuICAgICAgICAgIGNvbW1lbnQsXG4gICAgICAgIH0pO1xuICAgICAgICByZXR1cm4gcmVzLmN1c3RvbUVycm9yKHtcbiAgICAgICAgICBzdGF0dXNDb2RlOiBtZGVFcnJvclN0YXR1cyhlcnIpLFxuICAgICAgICAgIGJvZHk6IGVyciBpbnN0YW5jZW9mIEVycm9yID8gZXJyLm1lc3NhZ2UgOiBTdHJpbmcoZXJyKSxcbiAgICAgICAgfSk7XG4gICAgICB9XG4gICAgfVxuICApO1xuXG4gIHJvdXRlci5wb3N0KFxuICAgIHtcbiAgICAgIHBhdGg6ICcvYXBpL2RlZmVuZGVyX3BsdWdpbi9hY3Rpb25zL3JlcXVlc3Qtb3RwLWluZGljYXRvcicsXG4gICAgICB2YWxpZGF0ZToge1xuICAgICAgICBib2R5OiBzY2hlbWEub2JqZWN0KHtcbiAgICAgICAgICBtYWNoaW5lX2lkOiBzY2hlbWEuc3RyaW5nKCksXG4gICAgICAgICAgY29tcHV0ZXJfZG5zX25hbWU6IHNjaGVtYS5tYXliZShzY2hlbWEuc3RyaW5nKCkpLFxuICAgICAgICAgIG90cF9jb250ZXh0X2lkOiBzY2hlbWEubWF5YmUoc2NoZW1hLnN0cmluZygpKSxcbiAgICAgICAgfSksXG4gICAgICB9LFxuICAgIH0sXG4gICAgYXN5bmMgKF9jb250ZXh0LCByZXEsIHJlcykgPT4ge1xuICAgICAgY29uc3QgeyBtYWNoaW5lX2lkLCBjb21wdXRlcl9kbnNfbmFtZSwgb3RwX2NvbnRleHRfaWQgfSA9IHJlcS5ib2R5IGFzIHtcbiAgICAgICAgbWFjaGluZV9pZDogc3RyaW5nO1xuICAgICAgICBjb21wdXRlcl9kbnNfbmFtZT86IHN0cmluZztcbiAgICAgICAgb3RwX2NvbnRleHRfaWQ/OiBzdHJpbmc7XG4gICAgICB9O1xuICAgICAgY29uc3QgY3R4ID0gKG90cF9jb250ZXh0X2lkIHx8IG1hY2hpbmVfaWQpLnRyaW0oKTtcbiAgICAgIGNvbnN0IG90cCA9IGdlbmVyYXRlT1RQKCk7XG4gICAgICBzdG9yZU9UUChjdHgsICdjcmVhdGVfaW5kaWNhdG9yJywgb3RwKTtcbiAgICAgIGNvbnN0IGVtYWlsUmVzdWx0ID0gYXdhaXQgc2VuZE9UUEVtYWlsKFxuICAgICAgICBnZXRPVFBDb25maWcoKSxcbiAgICAgICAgb3RwLFxuICAgICAgICBjb21wdXRlcl9kbnNfbmFtZSB8fCBtYWNoaW5lX2lkLFxuICAgICAgICAnY3JlYXRlX2luZGljYXRvcidcbiAgICAgICk7XG4gICAgICByZXR1cm4gcmVzLm9rKHtcbiAgICAgICAgYm9keToge1xuICAgICAgICAgIHN1Y2Nlc3M6IHRydWUsXG4gICAgICAgICAgbWVzc2FnZTogZW1haWxSZXN1bHQuc2VudCA/ICdPVFAgc2VudC4nIDogJ09UUCBnZW5lcmF0ZWQuJyxcbiAgICAgICAgICBkZXZfbW9kZTogZW1haWxSZXN1bHQuZGV2TW9kZSxcbiAgICAgICAgICBvdHA6IGVtYWlsUmVzdWx0LmRldk1vZGUgPyBlbWFpbFJlc3VsdC5vdHAgOiB1bmRlZmluZWQsXG4gICAgICAgIH0sXG4gICAgICB9KTtcbiAgICB9XG4gICk7XG5cbiAgY29uc3QgZGVsZXRlSW5kaWNhdG9yQm9keSA9IHNjaGVtYS5vYmplY3Qoe1xuICAgIGluZGljYXRvcl9pZDogc2NoZW1hLnN0cmluZygpLFxuICAgIG1hY2hpbmVfaWQ6IHNjaGVtYS5tYXliZShzY2hlbWEuc3RyaW5nKCkpLFxuICAgIGNvbXB1dGVyX2Ruc19uYW1lOiBzY2hlbWEubWF5YmUoc2NoZW1hLnN0cmluZygpKSxcbiAgICBjb21tZW50OiBzY2hlbWEuc3RyaW5nKCksXG4gICAgb3RwOiBzY2hlbWEuc3RyaW5nKCksXG4gIH0pO1xuXG4gIHJvdXRlci5wb3N0KFxuICAgIHsgcGF0aDogJy9hcGkvZGVmZW5kZXJfcGx1Z2luL2FjdGlvbnMvZGVsZXRlLWluZGljYXRvcicsIHZhbGlkYXRlOiB7IGJvZHk6IGRlbGV0ZUluZGljYXRvckJvZHkgfSB9LFxuICAgIGFzeW5jIChjb250ZXh0LCByZXEsIHJlcykgPT4ge1xuICAgICAgY29uc3QgY29uZmlnID0gZ2V0TWRlQ29uZmlnKCk7XG4gICAgICBpZiAoIWNvbmZpZykge1xuICAgICAgICByZXR1cm4gcmVzLmN1c3RvbUVycm9yKHsgc3RhdHVzQ29kZTogNTAzLCBib2R5OiAnRGVmZW5kZXIgbm90IGNvbmZpZ3VyZWQuJyB9KTtcbiAgICAgIH1cbiAgICAgIGNvbnN0IHsgdXNlciwgcm9sZSB9ID0gZ2V0VXNlckZyb21SZXF1ZXN0KHJlcSk7XG4gICAgICBjb25zdCBjbGllbnQgPSBjb250ZXh0LmNvcmUub3BlbnNlYXJjaC5jbGllbnQuYXNDdXJyZW50VXNlcjtcbiAgICAgIGNvbnN0IGIgPSByZXEuYm9keSBhcyB7XG4gICAgICAgIGluZGljYXRvcl9pZDogc3RyaW5nO1xuICAgICAgICBtYWNoaW5lX2lkPzogc3RyaW5nO1xuICAgICAgICBjb21wdXRlcl9kbnNfbmFtZT86IHN0cmluZztcbiAgICAgICAgY29tbWVudDogc3RyaW5nO1xuICAgICAgICBvdHA6IHN0cmluZztcbiAgICAgIH07XG4gICAgICBjb25zdCBjb21tZW50ID0gKGIuY29tbWVudCB8fCAnJykudHJpbSgpO1xuICAgICAgaWYgKCFjb21tZW50KSB7XG4gICAgICAgIHJldHVybiByZXMuY3VzdG9tRXJyb3IoeyBzdGF0dXNDb2RlOiA0MDAsIGJvZHk6ICdDb21tZW50IGlzIHJlcXVpcmVkLicgfSk7XG4gICAgICB9XG4gICAgICBjb25zdCBvdHBDaGVjayA9IHZhbGlkYXRlT1RQKGIuaW5kaWNhdG9yX2lkLCAnZGVsZXRlX2luZGljYXRvcicsIGIub3RwIHx8ICcnKTtcbiAgICAgIGlmICghb3RwQ2hlY2sudmFsaWQpIHtcbiAgICAgICAgcmV0dXJuIHJlcy5jdXN0b21FcnJvcih7IHN0YXR1c0NvZGU6IDQwMCwgYm9keTogb3RwQ2hlY2sucmVhc29uIHx8ICdPVFAgcmVxdWlyZWQnIH0pO1xuICAgICAgfVxuICAgICAgY29uc3QgZGV2aWNlTmFtZSA9IGIuY29tcHV0ZXJfZG5zX25hbWUgfHwgYi5tYWNoaW5lX2lkIHx8IGIuaW5kaWNhdG9yX2lkO1xuICAgICAgdHJ5IHtcbiAgICAgICAgY29uc3QgcmVzdWx0ID0gYXdhaXQgZGVsZXRlSW5kaWNhdG9yKGNvbmZpZywgYi5pbmRpY2F0b3JfaWQpO1xuICAgICAgICBjb25zdCBtZXNzYWdlID0gSlNPTi5zdHJpbmdpZnkocmVzdWx0KS5zbGljZSgwLCAyMDAwKTtcbiAgICAgICAgYXdhaXQgd3JpdGVBdWRpdExvZyhjbGllbnQsIHtcbiAgICAgICAgICBhY3Rpb246ICdkZWxldGVfaW5kaWNhdG9yJyxcbiAgICAgICAgICBtYWNoaW5lX2lkOiBiLm1hY2hpbmVfaWQgfHwgYi5pbmRpY2F0b3JfaWQsXG4gICAgICAgICAgY29tcHV0ZXJfZG5zX25hbWU6IGRldmljZU5hbWUsXG4gICAgICAgICAgcGVyZm9ybWVkX2J5OiB1c2VyLFxuICAgICAgICAgIHJvbGUsXG4gICAgICAgICAgc3RhdHVzOiAnc3VjY2VzcycsXG4gICAgICAgICAgbWVzc2FnZSxcbiAgICAgICAgICBzb3VyY2VfaXA6IChyZXEgYXMgYW55KS5pbmZvPy5yZW1vdGVBZGRyZXNzLFxuICAgICAgICAgIG90cF92ZXJpZmllZDogdHJ1ZSxcbiAgICAgICAgICBjb21tZW50LFxuICAgICAgICB9KTtcbiAgICAgICAgcmV0dXJuIHJlcy5vayh7XG4gICAgICAgICAgYm9keToge1xuICAgICAgICAgICAgc3VjY2VzczogdHJ1ZSxcbiAgICAgICAgICAgIGFjdGlvbjogJ2RlbGV0ZV9pbmRpY2F0b3InLFxuICAgICAgICAgICAgbWFjaGluZV9pZDogYi5tYWNoaW5lX2lkIHx8IGIuaW5kaWNhdG9yX2lkLFxuICAgICAgICAgICAgbWVzc2FnZSxcbiAgICAgICAgICAgIHRpbWVzdGFtcDogbmV3IERhdGUoKS50b0lTT1N0cmluZygpLFxuICAgICAgICAgIH0sXG4gICAgICAgIH0pO1xuICAgICAgfSBjYXRjaCAoZXJyOiB1bmtub3duKSB7XG4gICAgICAgIGF3YWl0IHdyaXRlQXVkaXRMb2coY2xpZW50LCB7XG4gICAgICAgICAgYWN0aW9uOiAnZGVsZXRlX2luZGljYXRvcicsXG4gICAgICAgICAgbWFjaGluZV9pZDogYi5tYWNoaW5lX2lkIHx8IGIuaW5kaWNhdG9yX2lkLFxuICAgICAgICAgIGNvbXB1dGVyX2Ruc19uYW1lOiBkZXZpY2VOYW1lLFxuICAgICAgICAgIHBlcmZvcm1lZF9ieTogdXNlcixcbiAgICAgICAgICByb2xlLFxuICAgICAgICAgIHN0YXR1czogJ2ZhaWx1cmUnLFxuICAgICAgICAgIG1lc3NhZ2U6IGVyciBpbnN0YW5jZW9mIEVycm9yID8gZXJyLm1lc3NhZ2UgOiBTdHJpbmcoZXJyKSxcbiAgICAgICAgICBzb3VyY2VfaXA6IChyZXEgYXMgYW55KS5pbmZvPy5yZW1vdGVBZGRyZXNzLFxuICAgICAgICAgIG90cF92ZXJpZmllZDogdHJ1ZSxcbiAgICAgICAgICBjb21tZW50LFxuICAgICAgICB9KTtcbiAgICAgICAgcmV0dXJuIHJlcy5jdXN0b21FcnJvcih7XG4gICAgICAgICAgc3RhdHVzQ29kZTogbWRlRXJyb3JTdGF0dXMoZXJyKSxcbiAgICAgICAgICBib2R5OiBlcnIgaW5zdGFuY2VvZiBFcnJvciA/IGVyci5tZXNzYWdlIDogU3RyaW5nKGVyciksXG4gICAgICAgIH0pO1xuICAgICAgfVxuICAgIH1cbiAgKTtcblxuICByb3V0ZXIucG9zdChcbiAgICB7XG4gICAgICBwYXRoOiAnL2FwaS9kZWZlbmRlcl9wbHVnaW4vYWN0aW9ucy9yZXF1ZXN0LW90cC1kZWxldGUtaW5kaWNhdG9yJyxcbiAgICAgIHZhbGlkYXRlOiB7XG4gICAgICAgIGJvZHk6IHNjaGVtYS5vYmplY3Qoe1xuICAgICAgICAgIGluZGljYXRvcl9pZDogc2NoZW1hLnN0cmluZygpLFxuICAgICAgICAgIGNvbXB1dGVyX2Ruc19uYW1lOiBzY2hlbWEubWF5YmUoc2NoZW1hLnN0cmluZygpKSxcbiAgICAgICAgfSksXG4gICAgICB9LFxuICAgIH0sXG4gICAgYXN5bmMgKF9jb250ZXh0LCByZXEsIHJlcykgPT4ge1xuICAgICAgY29uc3QgeyBpbmRpY2F0b3JfaWQsIGNvbXB1dGVyX2Ruc19uYW1lIH0gPSByZXEuYm9keSBhcyB7XG4gICAgICAgIGluZGljYXRvcl9pZDogc3RyaW5nO1xuICAgICAgICBjb21wdXRlcl9kbnNfbmFtZT86IHN0cmluZztcbiAgICAgIH07XG4gICAgICBjb25zdCBvdHAgPSBnZW5lcmF0ZU9UUCgpO1xuICAgICAgc3RvcmVPVFAoaW5kaWNhdG9yX2lkLCAnZGVsZXRlX2luZGljYXRvcicsIG90cCk7XG4gICAgICBjb25zdCBlbWFpbFJlc3VsdCA9IGF3YWl0IHNlbmRPVFBFbWFpbChcbiAgICAgICAgZ2V0T1RQQ29uZmlnKCksXG4gICAgICAgIG90cCxcbiAgICAgICAgY29tcHV0ZXJfZG5zX25hbWUgfHwgaW5kaWNhdG9yX2lkLFxuICAgICAgICAnZGVsZXRlX2luZGljYXRvcidcbiAgICAgICk7XG4gICAgICByZXR1cm4gcmVzLm9rKHtcbiAgICAgICAgYm9keToge1xuICAgICAgICAgIHN1Y2Nlc3M6IHRydWUsXG4gICAgICAgICAgZGV2X21vZGU6IGVtYWlsUmVzdWx0LmRldk1vZGUsXG4gICAgICAgICAgb3RwOiBlbWFpbFJlc3VsdC5kZXZNb2RlID8gZW1haWxSZXN1bHQub3RwIDogdW5kZWZpbmVkLFxuICAgICAgICB9LFxuICAgICAgfSk7XG4gICAgfVxuICApO1xuXG4gIHJvdXRlci5wb3N0KFxuICAgIHtcbiAgICAgIHBhdGg6ICcvYXBpL2RlZmVuZGVyX3BsdWdpbi9hY3Rpb25zL3JlcXVlc3Qtb3RwLXVwZGF0ZS1pbmRpY2F0b3InLFxuICAgICAgdmFsaWRhdGU6IHtcbiAgICAgICAgYm9keTogc2NoZW1hLm9iamVjdCh7XG4gICAgICAgICAgaW5kaWNhdG9yX2lkOiBzY2hlbWEuc3RyaW5nKCksXG4gICAgICAgICAgY29tcHV0ZXJfZG5zX25hbWU6IHNjaGVtYS5tYXliZShzY2hlbWEuc3RyaW5nKCkpLFxuICAgICAgICB9KSxcbiAgICAgIH0sXG4gICAgfSxcbiAgICBhc3luYyAoX2NvbnRleHQsIHJlcSwgcmVzKSA9PiB7XG4gICAgICBjb25zdCB7IGluZGljYXRvcl9pZCwgY29tcHV0ZXJfZG5zX25hbWUgfSA9IHJlcS5ib2R5IGFzIHtcbiAgICAgICAgaW5kaWNhdG9yX2lkOiBzdHJpbmc7XG4gICAgICAgIGNvbXB1dGVyX2Ruc19uYW1lPzogc3RyaW5nO1xuICAgICAgfTtcbiAgICAgIGNvbnN0IG90cCA9IGdlbmVyYXRlT1RQKCk7XG4gICAgICBzdG9yZU9UUChpbmRpY2F0b3JfaWQsICd1cGRhdGVfaW5kaWNhdG9yJywgb3RwKTtcbiAgICAgIGNvbnN0IGVtYWlsUmVzdWx0ID0gYXdhaXQgc2VuZE9UUEVtYWlsKFxuICAgICAgICBnZXRPVFBDb25maWcoKSxcbiAgICAgICAgb3RwLFxuICAgICAgICBjb21wdXRlcl9kbnNfbmFtZSB8fCBpbmRpY2F0b3JfaWQsXG4gICAgICAgICd1cGRhdGVfaW5kaWNhdG9yJ1xuICAgICAgKTtcbiAgICAgIHJldHVybiByZXMub2soe1xuICAgICAgICBib2R5OiB7XG4gICAgICAgICAgc3VjY2VzczogdHJ1ZSxcbiAgICAgICAgICBkZXZfbW9kZTogZW1haWxSZXN1bHQuZGV2TW9kZSxcbiAgICAgICAgICBvdHA6IGVtYWlsUmVzdWx0LmRldk1vZGUgPyBlbWFpbFJlc3VsdC5vdHAgOiB1bmRlZmluZWQsXG4gICAgICAgIH0sXG4gICAgICB9KTtcbiAgICB9XG4gICk7XG59XG4iXSwibWFwcGluZ3MiOiI7Ozs7OztBQUtBLElBQUFBLGFBQUEsR0FBQUMsT0FBQTtBQUNBLElBQUFDLFVBQUEsR0FBQUQsT0FBQTtBQUNBLElBQUFFLFVBQUEsR0FBQUYsT0FBQTtBQWlCQSxJQUFBRyxJQUFBLEdBQUFILE9BQUE7QUF4QkE7QUFDQTtBQUNBOztBQXdCQSxTQUFTSSxrQkFBa0JBLENBQUNDLEdBQVEsRUFBa0M7RUFBQSxJQUFBQyxZQUFBLEVBQUFDLGFBQUE7RUFDcEUsTUFBTUMsSUFBSSxHQUFHLEVBQUFGLFlBQUEsR0FBQ0QsR0FBRyxDQUFDSSxPQUFPLGNBQUFILFlBQUEsdUJBQVhBLFlBQUEsQ0FBYyxpQkFBaUIsQ0FBQyxLQUFlLGdCQUFnQjtFQUM3RSxNQUFNSSxJQUFJLEdBQUcsRUFBQUgsYUFBQSxHQUFDRixHQUFHLENBQUNJLE9BQU8sY0FBQUYsYUFBQSx1QkFBWEEsYUFBQSxDQUFjLGlCQUFpQixDQUFDLEtBQWUsbUJBQW1CO0VBQ2hGLE9BQU87SUFBRUMsSUFBSTtJQUFFRTtFQUFLLENBQUM7QUFDdkI7QUFFQSxTQUFTQyxZQUFZQSxDQUFBLEVBQW1CO0VBQ3RDLE9BQU87SUFDTEMsUUFBUSxFQUFFQyxPQUFPLENBQUNDLEdBQUcsQ0FBQ0MsU0FBUztJQUMvQkMsUUFBUSxFQUFFSCxPQUFPLENBQUNDLEdBQUcsQ0FBQ0csU0FBUyxHQUFHQyxRQUFRLENBQUNMLE9BQU8sQ0FBQ0MsR0FBRyxDQUFDRyxTQUFTLEVBQUUsRUFBRSxDQUFDLEdBQUcsR0FBRztJQUMzRUUsUUFBUSxFQUFFTixPQUFPLENBQUNDLEdBQUcsQ0FBQ00sU0FBUztJQUMvQkMsUUFBUSxFQUFFUixPQUFPLENBQUNDLEdBQUcsQ0FBQ1EsU0FBUztJQUMvQkMsaUJBQWlCLEVBQUVWLE9BQU8sQ0FBQ0MsR0FBRyxDQUFDVSxtQkFBbUI7SUFDbERDLFVBQVUsRUFBRVosT0FBTyxDQUFDQyxHQUFHLENBQUNZLFdBQVcsS0FBSztFQUMxQyxDQUFDO0FBQ0g7QUFFQSxTQUFTQyxVQUFVQSxDQUFDQyxJQUFzRCxFQUFVO0VBQ2xGLE1BQU1DLENBQUMsR0FBRyxDQUFDRCxJQUFJLENBQUNFLGNBQWMsSUFBSUYsSUFBSSxDQUFDRyxVQUFVLElBQUksRUFBRSxFQUFFQyxJQUFJLENBQUMsQ0FBQztFQUMvRCxPQUFPSCxDQUFDO0FBQ1Y7QUFFQSxlQUFlSSxhQUFhQSxDQUMxQkMsTUFBVyxFQUNYQyxLQVdDLEVBQ0Q7RUFDQSxJQUFJO0lBQ0YsTUFBTUQsTUFBTSxDQUFDRSxLQUFLLENBQUM7TUFDakJBLEtBQUssRUFBRUMsbUNBQXdCO01BQy9CVCxJQUFJLEVBQUU7UUFBRSxHQUFHTyxLQUFLO1FBQUVHLFNBQVMsRUFBRSxJQUFJQyxJQUFJLENBQUMsQ0FBQyxDQUFDQyxXQUFXLENBQUM7TUFBRTtJQUN4RCxDQUFDLENBQUM7RUFDSixDQUFDLENBQUMsT0FBT0MsR0FBRyxFQUFFO0lBQ1pDLE9BQU8sQ0FBQ0MsS0FBSyxDQUFDLG9DQUFvQyxFQUFFRixHQUFHLENBQUM7RUFDMUQ7QUFDRjtBQUVBLE1BQU1HLGNBQWMsR0FBR0Msb0JBQU0sQ0FBQ0MsS0FBSyxDQUFDLENBQUNELG9CQUFNLENBQUNFLE9BQU8sQ0FBQyxPQUFPLENBQUMsRUFBRUYsb0JBQU0sQ0FBQ0UsT0FBTyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUM7QUFDdEYsTUFBTUMsbUJBQW1CLEdBQUdILG9CQUFNLENBQUNDLEtBQUssQ0FBQyxDQUN2Q0Qsb0JBQU0sQ0FBQ0UsT0FBTyxDQUFDLE1BQU0sQ0FBQyxFQUN0QkYsb0JBQU0sQ0FBQ0UsT0FBTyxDQUFDLFdBQVcsQ0FBQyxFQUMzQkYsb0JBQU0sQ0FBQ0UsT0FBTyxDQUFDLGlCQUFpQixDQUFDLENBQ2xDLENBQUM7O0FBRUY7QUFDQSxNQUFNRSxpQkFBaUIsR0FBR0osb0JBQU0sQ0FBQ0ssTUFBTSxDQUFDO0VBQ3RDbkIsVUFBVSxFQUFFYyxvQkFBTSxDQUFDTSxNQUFNLENBQUMsQ0FBQztFQUMzQkMsaUJBQWlCLEVBQUVQLG9CQUFNLENBQUNRLEtBQUssQ0FBQ1Isb0JBQU0sQ0FBQ00sTUFBTSxDQUFDLENBQUMsQ0FBQztFQUNoREcsT0FBTyxFQUFFVCxvQkFBTSxDQUFDTSxNQUFNLENBQUMsQ0FBQztFQUN4QkksR0FBRyxFQUFFVixvQkFBTSxDQUFDTSxNQUFNLENBQUMsQ0FBQztFQUNwQnJCLGNBQWMsRUFBRWUsb0JBQU0sQ0FBQ1EsS0FBSyxDQUFDUixvQkFBTSxDQUFDTSxNQUFNLENBQUMsQ0FBQyxDQUFDO0VBQzdDSyxTQUFTLEVBQUVYLG9CQUFNLENBQUNRLEtBQUssQ0FBQ1QsY0FBYyxDQUFDO0VBQ3ZDYSxjQUFjLEVBQUVaLG9CQUFNLENBQUNRLEtBQUssQ0FBQ0wsbUJBQW1CO0FBQ2xELENBQUMsQ0FBQztBQUVLLFNBQVNVLDRCQUE0QkEsQ0FBQ0MsTUFBZSxFQUFFO0VBQzVELE1BQU1DLGdCQUFnQixHQUFHQSxDQUN2QkMsSUFBWSxFQUNaQyxVQUFrQixFQUNsQkMsRUFRcUIsS0FDbEI7SUFDSEosTUFBTSxDQUFDSyxJQUFJLENBQ1Q7TUFBRUgsSUFBSTtNQUFFSSxRQUFRLEVBQUU7UUFBRXJDLElBQUksRUFBRXFCO01BQWtCO0lBQUUsQ0FBQyxFQUMvQyxPQUFPaUIsT0FBTyxFQUFFN0QsR0FBRyxFQUFFOEQsR0FBRyxLQUFLO01BQzNCLE1BQU1DLE1BQU0sR0FBRyxJQUFBQyx1QkFBWSxFQUFDLENBQUM7TUFDN0IsSUFBSSxDQUFDRCxNQUFNLEVBQUU7UUFDWCxPQUFPRCxHQUFHLENBQUNHLFdBQVcsQ0FBQztVQUNyQkMsVUFBVSxFQUFFLEdBQUc7VUFDZjNDLElBQUksRUFBRTtRQUNSLENBQUMsQ0FBQztNQUNKO01BQ0EsTUFBTTtRQUFFcEIsSUFBSTtRQUFFRTtNQUFLLENBQUMsR0FBR04sa0JBQWtCLENBQUNDLEdBQUcsQ0FBQztNQUM5QyxNQUFNNkIsTUFBTSxHQUFHZ0MsT0FBTyxDQUFDTSxJQUFJLENBQUNDLFVBQVUsQ0FBQ3ZDLE1BQU0sQ0FBQ3dDLGFBQWE7TUFDM0QsTUFBTTlDLElBQUksR0FBR3ZCLEdBQUcsQ0FBQ3VCLElBUWhCO01BQ0QsTUFBTTBCLE9BQU8sR0FBRyxDQUFDMUIsSUFBSSxDQUFDMEIsT0FBTyxJQUFJLEVBQUUsRUFBRXRCLElBQUksQ0FBQyxDQUFDO01BQzNDLElBQUksQ0FBQ3NCLE9BQU8sRUFBRTtRQUNaLE9BQU9hLEdBQUcsQ0FBQ0csV0FBVyxDQUFDO1VBQUVDLFVBQVUsRUFBRSxHQUFHO1VBQUUzQyxJQUFJLEVBQUU7UUFBdUIsQ0FBQyxDQUFDO01BQzNFO01BQ0EsTUFBTStDLEdBQUcsR0FBR2hELFVBQVUsQ0FBQ0MsSUFBSSxDQUFDO01BQzVCLElBQUksQ0FBQytDLEdBQUcsRUFBRTtRQUNSLE9BQU9SLEdBQUcsQ0FBQ0csV0FBVyxDQUFDO1VBQUVDLFVBQVUsRUFBRSxHQUFHO1VBQUUzQyxJQUFJLEVBQUU7UUFBeUMsQ0FBQyxDQUFDO01BQzdGO01BQ0EsTUFBTWdELFFBQVEsR0FBRyxJQUFBQyxnQkFBVyxFQUFDRixHQUFHLEVBQUViLFVBQVUsRUFBRWxDLElBQUksQ0FBQzJCLEdBQUcsSUFBSSxFQUFFLENBQUM7TUFDN0QsSUFBSSxDQUFDcUIsUUFBUSxDQUFDRSxLQUFLLEVBQUU7UUFDbkIsT0FBT1gsR0FBRyxDQUFDRyxXQUFXLENBQUM7VUFBRUMsVUFBVSxFQUFFLEdBQUc7VUFBRTNDLElBQUksRUFBRWdELFFBQVEsQ0FBQ0csTUFBTSxJQUFJO1FBQWUsQ0FBQyxDQUFDO01BQ3RGO01BQ0EsTUFBTUMsVUFBVSxHQUFHcEQsSUFBSSxDQUFDd0IsaUJBQWlCLElBQUl4QixJQUFJLENBQUNHLFVBQVU7TUFFNUQsSUFBSTtRQUFBLElBQUFrRCxLQUFBO1FBQ0YsTUFBTUMsTUFBTSxHQUFHLE1BQU1uQixFQUFFLENBQUNLLE1BQU0sRUFBRTtVQUM5QnJDLFVBQVUsRUFBRUgsSUFBSSxDQUFDRyxVQUFVO1VBQzNCdUIsT0FBTztVQUNQRSxTQUFTLEVBQUU1QixJQUFJLENBQUM0QixTQUFTO1VBQ3pCQyxjQUFjLEVBQUU3QixJQUFJLENBQUM2QjtRQUN2QixDQUFDLENBQUM7UUFDRixNQUFNMEIsT0FBTyxHQUFHQyxJQUFJLENBQUNDLFNBQVMsQ0FBQ0gsTUFBTSxDQUFDLENBQUNJLEtBQUssQ0FBQyxDQUFDLEVBQUUsSUFBSSxDQUFDO1FBQ3JELE1BQU1yRCxhQUFhLENBQUNDLE1BQU0sRUFBRTtVQUMxQnFELE1BQU0sRUFBRXpCLFVBQVU7VUFDbEIvQixVQUFVLEVBQUVILElBQUksQ0FBQ0csVUFBVTtVQUMzQnFCLGlCQUFpQixFQUFFNEIsVUFBVTtVQUM3QlEsWUFBWSxFQUFFaEYsSUFBSTtVQUNsQkUsSUFBSTtVQUNKK0UsTUFBTSxFQUFFLFNBQVM7VUFDakJOLE9BQU87VUFDUE8sU0FBUyxHQUFBVCxLQUFBLEdBQUc1RSxHQUFHLENBQVNzRixJQUFJLGNBQUFWLEtBQUEsdUJBQWpCQSxLQUFBLENBQW1CVyxhQUFhO1VBQzNDQyxZQUFZLEVBQUUsSUFBSTtVQUNsQnZDO1FBQ0YsQ0FBQyxDQUFDO1FBQ0YsT0FBT2EsR0FBRyxDQUFDMkIsRUFBRSxDQUFDO1VBQ1psRSxJQUFJLEVBQUU7WUFDSm1FLE9BQU8sRUFBRSxJQUFJO1lBQ2JSLE1BQU0sRUFBRXpCLFVBQVU7WUFDbEIvQixVQUFVLEVBQUVILElBQUksQ0FBQ0csVUFBVTtZQUMzQm9ELE9BQU87WUFDUDdDLFNBQVMsRUFBRSxJQUFJQyxJQUFJLENBQUMsQ0FBQyxDQUFDQyxXQUFXLENBQUM7VUFDcEM7UUFDRixDQUFDLENBQUM7TUFDSixDQUFDLENBQUMsT0FBT0MsR0FBWSxFQUFFO1FBQUEsSUFBQXVELE1BQUE7UUFDckIsTUFBTS9ELGFBQWEsQ0FBQ0MsTUFBTSxFQUFFO1VBQzFCcUQsTUFBTSxFQUFFekIsVUFBVTtVQUNsQi9CLFVBQVUsRUFBRUgsSUFBSSxDQUFDRyxVQUFVO1VBQzNCcUIsaUJBQWlCLEVBQUU0QixVQUFVO1VBQzdCUSxZQUFZLEVBQUVoRixJQUFJO1VBQ2xCRSxJQUFJO1VBQ0orRSxNQUFNLEVBQUUsU0FBUztVQUNqQk4sT0FBTyxFQUFFMUMsR0FBRyxZQUFZd0QsS0FBSyxHQUFHeEQsR0FBRyxDQUFDMEMsT0FBTyxHQUFHZSxNQUFNLENBQUN6RCxHQUFHLENBQUM7VUFDekRpRCxTQUFTLEdBQUFNLE1BQUEsR0FBRzNGLEdBQUcsQ0FBU3NGLElBQUksY0FBQUssTUFBQSx1QkFBakJBLE1BQUEsQ0FBbUJKLGFBQWE7VUFDM0NDLFlBQVksRUFBRSxJQUFJO1VBQ2xCdkM7UUFDRixDQUFDLENBQUM7UUFDRixPQUFPYSxHQUFHLENBQUNHLFdBQVcsQ0FBQztVQUNyQkMsVUFBVSxFQUFFLElBQUE0Qix5QkFBYyxFQUFDMUQsR0FBRyxDQUFDO1VBQy9CYixJQUFJLEVBQUVhLEdBQUcsWUFBWXdELEtBQUssR0FBR3hELEdBQUcsQ0FBQzBDLE9BQU8sR0FBR2UsTUFBTSxDQUFDekQsR0FBRztRQUN2RCxDQUFDLENBQUM7TUFDSjtJQUNGLENBQ0YsQ0FBQztFQUNILENBQUM7RUFFRG1CLGdCQUFnQixDQUFDLDZDQUE2QyxFQUFFLGdCQUFnQixFQUFFLENBQUN3QyxHQUFHLEVBQUVDLENBQUMsS0FDdkYsSUFBQUMsMkJBQWdCLEVBQUNGLEdBQUcsRUFBRUMsQ0FBQyxDQUFDdEUsVUFBVSxFQUFFc0UsQ0FBQyxDQUFDL0MsT0FBTyxFQUFFK0MsQ0FBQyxDQUFDN0MsU0FBUyxJQUFJLE9BQU8sQ0FDdkUsQ0FBQztFQUVESSxnQkFBZ0IsQ0FBQyxzQ0FBc0MsRUFBRSxTQUFTLEVBQUUsQ0FBQ3dDLEdBQUcsRUFBRUMsQ0FBQyxLQUN6RSxJQUFBRSx5QkFBYyxFQUFDSCxHQUFHLEVBQUVDLENBQUMsQ0FBQ3RFLFVBQVUsRUFBRXNFLENBQUMsQ0FBQy9DLE9BQU8sRUFBRStDLENBQUMsQ0FBQzVDLGNBQWMsSUFBSSxNQUFNLENBQ3pFLENBQUM7RUFFREcsZ0JBQWdCLENBQUMsd0NBQXdDLEVBQUUsV0FBVyxFQUFFLENBQUN3QyxHQUFHLEVBQUVDLENBQUMsS0FDN0UsSUFBQUcsMkJBQWdCLEVBQUNKLEdBQUcsRUFBRUMsQ0FBQyxDQUFDdEUsVUFBVSxFQUFFc0UsQ0FBQyxDQUFDL0MsT0FBTyxDQUMvQyxDQUFDO0VBRURNLGdCQUFnQixDQUNkLHNEQUFzRCxFQUN0RCx5QkFBeUIsRUFDekIsQ0FBQ3dDLEdBQUcsRUFBRUMsQ0FBQyxLQUFLLElBQUFJLGdDQUFxQixFQUFDTCxHQUFHLEVBQUVDLENBQUMsQ0FBQ3RFLFVBQVUsRUFBRXNFLENBQUMsQ0FBQy9DLE9BQU8sQ0FDaEUsQ0FBQztFQUVETSxnQkFBZ0IsQ0FDZCx3REFBd0QsRUFDeEQsMkJBQTJCLEVBQzNCLENBQUN3QyxHQUFHLEVBQUVDLENBQUMsS0FBSyxJQUFBSyxrQ0FBdUIsRUFBQ04sR0FBRyxFQUFFQyxDQUFDLENBQUN0RSxVQUFVLEVBQUVzRSxDQUFDLENBQUMvQyxPQUFPLENBQ2xFLENBQUM7RUFFRE0sZ0JBQWdCLENBQ2QsNERBQTRELEVBQzVELCtCQUErQixFQUMvQixDQUFDd0MsR0FBRyxFQUFFQyxDQUFDLEtBQUssSUFBQU0sc0NBQTJCLEVBQUNQLEdBQUcsRUFBRUMsQ0FBQyxDQUFDdEUsVUFBVSxFQUFFc0UsQ0FBQyxDQUFDL0MsT0FBTyxDQUN0RSxDQUFDO0VBRURNLGdCQUFnQixDQUFDLHVDQUF1QyxFQUFFLGtCQUFrQixFQUFFLENBQUN3QyxHQUFHLEVBQUVDLENBQUMsS0FDbkYsSUFBQU8sMEJBQWUsRUFBQ1IsR0FBRyxFQUFFQyxDQUFDLENBQUN0RSxVQUFVLEVBQUVzRSxDQUFDLENBQUMvQyxPQUFPLENBQzlDLENBQUM7RUFFRCxNQUFNdUQsa0JBQWtCLEdBQUdoRSxvQkFBTSxDQUFDSyxNQUFNLENBQUM7SUFDdkNuQixVQUFVLEVBQUVjLG9CQUFNLENBQUNNLE1BQU0sQ0FBQyxDQUFDO0lBQzNCQyxpQkFBaUIsRUFBRVAsb0JBQU0sQ0FBQ1EsS0FBSyxDQUFDUixvQkFBTSxDQUFDTSxNQUFNLENBQUMsQ0FBQyxDQUFDO0lBQ2hEMkQsSUFBSSxFQUFFakUsb0JBQU0sQ0FBQ00sTUFBTSxDQUFDLENBQUM7SUFDckJHLE9BQU8sRUFBRVQsb0JBQU0sQ0FBQ00sTUFBTSxDQUFDLENBQUM7SUFDeEJJLEdBQUcsRUFBRVYsb0JBQU0sQ0FBQ00sTUFBTSxDQUFDLENBQUM7SUFDcEJyQixjQUFjLEVBQUVlLG9CQUFNLENBQUNRLEtBQUssQ0FBQ1Isb0JBQU0sQ0FBQ00sTUFBTSxDQUFDLENBQUM7RUFDOUMsQ0FBQyxDQUFDO0VBRUZRLE1BQU0sQ0FBQ0ssSUFBSSxDQUNUO0lBQUVILElBQUksRUFBRSxrREFBa0Q7SUFBRUksUUFBUSxFQUFFO01BQUVyQyxJQUFJLEVBQUVpRjtJQUFtQjtFQUFFLENBQUMsRUFDcEcsT0FBTzNDLE9BQU8sRUFBRTdELEdBQUcsRUFBRThELEdBQUcsS0FBSztJQUMzQixNQUFNQyxNQUFNLEdBQUcsSUFBQUMsdUJBQVksRUFBQyxDQUFDO0lBQzdCLElBQUksQ0FBQ0QsTUFBTSxFQUFFO01BQ1gsT0FBT0QsR0FBRyxDQUFDRyxXQUFXLENBQUM7UUFBRUMsVUFBVSxFQUFFLEdBQUc7UUFBRTNDLElBQUksRUFBRTtNQUEyQixDQUFDLENBQUM7SUFDL0U7SUFDQSxNQUFNO01BQUVwQixJQUFJO01BQUVFO0lBQUssQ0FBQyxHQUFHTixrQkFBa0IsQ0FBQ0MsR0FBRyxDQUFDO0lBQzlDLE1BQU02QixNQUFNLEdBQUdnQyxPQUFPLENBQUNNLElBQUksQ0FBQ0MsVUFBVSxDQUFDdkMsTUFBTSxDQUFDd0MsYUFBYTtJQUMzRCxNQUFNOUMsSUFBSSxHQUFHdkIsR0FBRyxDQUFDdUIsSUFPaEI7SUFDRCxNQUFNMEIsT0FBTyxHQUFHLENBQUMxQixJQUFJLENBQUMwQixPQUFPLElBQUksRUFBRSxFQUFFdEIsSUFBSSxDQUFDLENBQUM7SUFDM0MsSUFBSSxDQUFDc0IsT0FBTyxFQUFFO01BQ1osT0FBT2EsR0FBRyxDQUFDRyxXQUFXLENBQUM7UUFBRUMsVUFBVSxFQUFFLEdBQUc7UUFBRTNDLElBQUksRUFBRTtNQUF1QixDQUFDLENBQUM7SUFDM0U7SUFDQSxNQUFNK0MsR0FBRyxHQUFHaEQsVUFBVSxDQUFDQyxJQUFJLENBQUM7SUFDNUIsSUFBSSxDQUFDK0MsR0FBRyxFQUFFO01BQ1IsT0FBT1IsR0FBRyxDQUFDRyxXQUFXLENBQUM7UUFBRUMsVUFBVSxFQUFFLEdBQUc7UUFBRTNDLElBQUksRUFBRTtNQUF5QyxDQUFDLENBQUM7SUFDN0Y7SUFDQSxNQUFNZ0QsUUFBUSxHQUFHLElBQUFDLGdCQUFXLEVBQUNGLEdBQUcsRUFBRSxxQkFBcUIsRUFBRS9DLElBQUksQ0FBQzJCLEdBQUcsSUFBSSxFQUFFLENBQUM7SUFDeEUsSUFBSSxDQUFDcUIsUUFBUSxDQUFDRSxLQUFLLEVBQUU7TUFDbkIsT0FBT1gsR0FBRyxDQUFDRyxXQUFXLENBQUM7UUFBRUMsVUFBVSxFQUFFLEdBQUc7UUFBRTNDLElBQUksRUFBRWdELFFBQVEsQ0FBQ0csTUFBTSxJQUFJO01BQWUsQ0FBQyxDQUFDO0lBQ3RGO0lBQ0EsTUFBTUMsVUFBVSxHQUFHcEQsSUFBSSxDQUFDd0IsaUJBQWlCLElBQUl4QixJQUFJLENBQUNHLFVBQVU7SUFDNUQsSUFBSTtNQUFBLElBQUFnRixNQUFBO01BQ0YsTUFBTTdCLE1BQU0sR0FBRyxNQUFNLElBQUE4QixnQ0FBcUIsRUFDeEM1QyxNQUFNLEVBQ054QyxJQUFJLENBQUNHLFVBQVUsRUFDZnVCLE9BQU8sRUFDUDFCLElBQUksQ0FBQ2tGLElBQUksQ0FBQzlFLElBQUksQ0FBQyxDQUNqQixDQUFDO01BQ0QsTUFBTW1ELE9BQU8sR0FBR0MsSUFBSSxDQUFDQyxTQUFTLENBQUNILE1BQU0sQ0FBQyxDQUFDSSxLQUFLLENBQUMsQ0FBQyxFQUFFLElBQUksQ0FBQztNQUNyRCxNQUFNckQsYUFBYSxDQUFDQyxNQUFNLEVBQUU7UUFDMUJxRCxNQUFNLEVBQUUscUJBQXFCO1FBQzdCeEQsVUFBVSxFQUFFSCxJQUFJLENBQUNHLFVBQVU7UUFDM0JxQixpQkFBaUIsRUFBRTRCLFVBQVU7UUFDN0JRLFlBQVksRUFBRWhGLElBQUk7UUFDbEJFLElBQUk7UUFDSitFLE1BQU0sRUFBRSxTQUFTO1FBQ2pCTixPQUFPO1FBQ1BPLFNBQVMsR0FBQXFCLE1BQUEsR0FBRzFHLEdBQUcsQ0FBU3NGLElBQUksY0FBQW9CLE1BQUEsdUJBQWpCQSxNQUFBLENBQW1CbkIsYUFBYTtRQUMzQ0MsWUFBWSxFQUFFLElBQUk7UUFDbEJ2QztNQUNGLENBQUMsQ0FBQztNQUNGLE9BQU9hLEdBQUcsQ0FBQzJCLEVBQUUsQ0FBQztRQUNabEUsSUFBSSxFQUFFO1VBQUVtRSxPQUFPLEVBQUUsSUFBSTtVQUFFUixNQUFNLEVBQUUscUJBQXFCO1VBQUV4RCxVQUFVLEVBQUVILElBQUksQ0FBQ0csVUFBVTtVQUFFb0Q7UUFBUTtNQUM3RixDQUFDLENBQUM7SUFDSixDQUFDLENBQUMsT0FBTzFDLEdBQVksRUFBRTtNQUFBLElBQUF3RSxNQUFBO01BQ3JCLE1BQU1oRixhQUFhLENBQUNDLE1BQU0sRUFBRTtRQUMxQnFELE1BQU0sRUFBRSxxQkFBcUI7UUFDN0J4RCxVQUFVLEVBQUVILElBQUksQ0FBQ0csVUFBVTtRQUMzQnFCLGlCQUFpQixFQUFFNEIsVUFBVTtRQUM3QlEsWUFBWSxFQUFFaEYsSUFBSTtRQUNsQkUsSUFBSTtRQUNKK0UsTUFBTSxFQUFFLFNBQVM7UUFDakJOLE9BQU8sRUFBRTFDLEdBQUcsWUFBWXdELEtBQUssR0FBR3hELEdBQUcsQ0FBQzBDLE9BQU8sR0FBR2UsTUFBTSxDQUFDekQsR0FBRyxDQUFDO1FBQ3pEaUQsU0FBUyxHQUFBdUIsTUFBQSxHQUFHNUcsR0FBRyxDQUFTc0YsSUFBSSxjQUFBc0IsTUFBQSx1QkFBakJBLE1BQUEsQ0FBbUJyQixhQUFhO1FBQzNDQyxZQUFZLEVBQUUsSUFBSTtRQUNsQnZDO01BQ0YsQ0FBQyxDQUFDO01BQ0YsT0FBT2EsR0FBRyxDQUFDRyxXQUFXLENBQUM7UUFDckJDLFVBQVUsRUFBRSxJQUFBNEIseUJBQWMsRUFBQzFELEdBQUcsQ0FBQztRQUMvQmIsSUFBSSxFQUFFYSxHQUFHLFlBQVl3RCxLQUFLLEdBQUd4RCxHQUFHLENBQUMwQyxPQUFPLEdBQUdlLE1BQU0sQ0FBQ3pELEdBQUc7TUFDdkQsQ0FBQyxDQUFDO0lBQ0o7RUFDRixDQUNGLENBQUM7RUFFRCxNQUFNeUUsZ0JBQWdCLEdBQUdyRSxvQkFBTSxDQUFDSyxNQUFNLENBQUM7SUFDckNpRSxTQUFTLEVBQUV0RSxvQkFBTSxDQUFDTSxNQUFNLENBQUMsQ0FBQztJQUMxQnBCLFVBQVUsRUFBRWMsb0JBQU0sQ0FBQ1EsS0FBSyxDQUFDUixvQkFBTSxDQUFDTSxNQUFNLENBQUMsQ0FBQyxDQUFDO0lBQ3pDQyxpQkFBaUIsRUFBRVAsb0JBQU0sQ0FBQ1EsS0FBSyxDQUFDUixvQkFBTSxDQUFDTSxNQUFNLENBQUMsQ0FBQyxDQUFDO0lBQ2hERyxPQUFPLEVBQUVULG9CQUFNLENBQUNNLE1BQU0sQ0FBQyxDQUFDO0lBQ3hCSSxHQUFHLEVBQUVWLG9CQUFNLENBQUNNLE1BQU0sQ0FBQztFQUNyQixDQUFDLENBQUM7RUFFRlEsTUFBTSxDQUFDSyxJQUFJLENBQ1Q7SUFBRUgsSUFBSSxFQUFFLG9EQUFvRDtJQUFFSSxRQUFRLEVBQUU7TUFBRXJDLElBQUksRUFBRXNGO0lBQWlCO0VBQUUsQ0FBQyxFQUNwRyxPQUFPaEQsT0FBTyxFQUFFN0QsR0FBRyxFQUFFOEQsR0FBRyxLQUFLO0lBQzNCLE1BQU1DLE1BQU0sR0FBRyxJQUFBQyx1QkFBWSxFQUFDLENBQUM7SUFDN0IsSUFBSSxDQUFDRCxNQUFNLEVBQUU7TUFDWCxPQUFPRCxHQUFHLENBQUNHLFdBQVcsQ0FBQztRQUFFQyxVQUFVLEVBQUUsR0FBRztRQUFFM0MsSUFBSSxFQUFFO01BQTJCLENBQUMsQ0FBQztJQUMvRTtJQUNBLE1BQU07TUFBRXBCLElBQUk7TUFBRUU7SUFBSyxDQUFDLEdBQUdOLGtCQUFrQixDQUFDQyxHQUFHLENBQUM7SUFDOUMsTUFBTTZCLE1BQU0sR0FBR2dDLE9BQU8sQ0FBQ00sSUFBSSxDQUFDQyxVQUFVLENBQUN2QyxNQUFNLENBQUN3QyxhQUFhO0lBQzNELE1BQU05QyxJQUFJLEdBQUd2QixHQUFHLENBQUN1QixJQU1oQjtJQUNELE1BQU0wQixPQUFPLEdBQUcsQ0FBQzFCLElBQUksQ0FBQzBCLE9BQU8sSUFBSSxFQUFFLEVBQUV0QixJQUFJLENBQUMsQ0FBQztJQUMzQyxJQUFJLENBQUNzQixPQUFPLEVBQUU7TUFDWixPQUFPYSxHQUFHLENBQUNHLFdBQVcsQ0FBQztRQUFFQyxVQUFVLEVBQUUsR0FBRztRQUFFM0MsSUFBSSxFQUFFO01BQXVCLENBQUMsQ0FBQztJQUMzRTtJQUNBLE1BQU1nRCxRQUFRLEdBQUcsSUFBQUMsZ0JBQVcsRUFBQ2pELElBQUksQ0FBQ3VGLFNBQVMsRUFBRSx1QkFBdUIsRUFBRXZGLElBQUksQ0FBQzJCLEdBQUcsSUFBSSxFQUFFLENBQUM7SUFDckYsSUFBSSxDQUFDcUIsUUFBUSxDQUFDRSxLQUFLLEVBQUU7TUFDbkIsT0FBT1gsR0FBRyxDQUFDRyxXQUFXLENBQUM7UUFBRUMsVUFBVSxFQUFFLEdBQUc7UUFBRTNDLElBQUksRUFBRWdELFFBQVEsQ0FBQ0csTUFBTSxJQUFJO01BQWUsQ0FBQyxDQUFDO0lBQ3RGO0lBQ0EsTUFBTUMsVUFBVSxHQUFHcEQsSUFBSSxDQUFDd0IsaUJBQWlCLElBQUl4QixJQUFJLENBQUNHLFVBQVUsSUFBSUgsSUFBSSxDQUFDdUYsU0FBUztJQUM5RSxJQUFJO01BQUEsSUFBQUMsTUFBQTtNQUNGLE1BQU1sQyxNQUFNLEdBQUcsTUFBTSxJQUFBbUMsOEJBQW1CLEVBQUNqRCxNQUFNLEVBQUV4QyxJQUFJLENBQUN1RixTQUFTLENBQUM7TUFDaEUsTUFBTWhDLE9BQU8sR0FBR0MsSUFBSSxDQUFDQyxTQUFTLENBQUNILE1BQU0sQ0FBQyxDQUFDSSxLQUFLLENBQUMsQ0FBQyxFQUFFLElBQUksQ0FBQztNQUNyRCxNQUFNckQsYUFBYSxDQUFDQyxNQUFNLEVBQUU7UUFDMUJxRCxNQUFNLEVBQUUsdUJBQXVCO1FBQy9CeEQsVUFBVSxFQUFFSCxJQUFJLENBQUNHLFVBQVUsSUFBSUgsSUFBSSxDQUFDdUYsU0FBUztRQUM3Qy9ELGlCQUFpQixFQUFFNEIsVUFBVTtRQUM3QlEsWUFBWSxFQUFFaEYsSUFBSTtRQUNsQkUsSUFBSTtRQUNKK0UsTUFBTSxFQUFFLFNBQVM7UUFDakJOLE9BQU87UUFDUE8sU0FBUyxHQUFBMEIsTUFBQSxHQUFHL0csR0FBRyxDQUFTc0YsSUFBSSxjQUFBeUIsTUFBQSx1QkFBakJBLE1BQUEsQ0FBbUJ4QixhQUFhO1FBQzNDQyxZQUFZLEVBQUUsSUFBSTtRQUNsQnZDO01BQ0YsQ0FBQyxDQUFDO01BQ0YsT0FBT2EsR0FBRyxDQUFDMkIsRUFBRSxDQUFDO1FBQ1psRSxJQUFJLEVBQUU7VUFBRW1FLE9BQU8sRUFBRSxJQUFJO1VBQUVSLE1BQU0sRUFBRSx1QkFBdUI7VUFBRTRCLFNBQVMsRUFBRXZGLElBQUksQ0FBQ3VGLFNBQVM7VUFBRWhDO1FBQVE7TUFDN0YsQ0FBQyxDQUFDO0lBQ0osQ0FBQyxDQUFDLE9BQU8xQyxHQUFZLEVBQUU7TUFBQSxJQUFBNkUsTUFBQTtNQUNyQixNQUFNckYsYUFBYSxDQUFDQyxNQUFNLEVBQUU7UUFDMUJxRCxNQUFNLEVBQUUsdUJBQXVCO1FBQy9CeEQsVUFBVSxFQUFFSCxJQUFJLENBQUNHLFVBQVUsSUFBSUgsSUFBSSxDQUFDdUYsU0FBUztRQUM3Qy9ELGlCQUFpQixFQUFFNEIsVUFBVTtRQUM3QlEsWUFBWSxFQUFFaEYsSUFBSTtRQUNsQkUsSUFBSTtRQUNKK0UsTUFBTSxFQUFFLFNBQVM7UUFDakJOLE9BQU8sRUFBRTFDLEdBQUcsWUFBWXdELEtBQUssR0FBR3hELEdBQUcsQ0FBQzBDLE9BQU8sR0FBR2UsTUFBTSxDQUFDekQsR0FBRyxDQUFDO1FBQ3pEaUQsU0FBUyxHQUFBNEIsTUFBQSxHQUFHakgsR0FBRyxDQUFTc0YsSUFBSSxjQUFBMkIsTUFBQSx1QkFBakJBLE1BQUEsQ0FBbUIxQixhQUFhO1FBQzNDQyxZQUFZLEVBQUUsSUFBSTtRQUNsQnZDO01BQ0YsQ0FBQyxDQUFDO01BQ0YsT0FBT2EsR0FBRyxDQUFDRyxXQUFXLENBQUM7UUFDckJDLFVBQVUsRUFBRSxJQUFBNEIseUJBQWMsRUFBQzFELEdBQUcsQ0FBQztRQUMvQmIsSUFBSSxFQUFFYSxHQUFHLFlBQVl3RCxLQUFLLEdBQUd4RCxHQUFHLENBQUMwQyxPQUFPLEdBQUdlLE1BQU0sQ0FBQ3pELEdBQUc7TUFDdkQsQ0FBQyxDQUFDO0lBQ0o7RUFDRixDQUNGLENBQUM7RUFFRGtCLE1BQU0sQ0FBQ0ssSUFBSSxDQUNUO0lBQ0VILElBQUksRUFBRSwwQ0FBMEM7SUFDaERJLFFBQVEsRUFBRTtNQUNSckMsSUFBSSxFQUFFaUIsb0JBQU0sQ0FBQ0ssTUFBTSxDQUFDO1FBQ2xCcUMsTUFBTSxFQUFFMUMsb0JBQU0sQ0FBQ00sTUFBTSxDQUFDLENBQUM7UUFDdkJwQixVQUFVLEVBQUVjLG9CQUFNLENBQUNRLEtBQUssQ0FBQ1Isb0JBQU0sQ0FBQ00sTUFBTSxDQUFDLENBQUMsQ0FBQztRQUN6Q0MsaUJBQWlCLEVBQUVQLG9CQUFNLENBQUNRLEtBQUssQ0FBQ1Isb0JBQU0sQ0FBQ00sTUFBTSxDQUFDLENBQUMsQ0FBQztRQUNoRHJCLGNBQWMsRUFBRWUsb0JBQU0sQ0FBQ1EsS0FBSyxDQUFDUixvQkFBTSxDQUFDTSxNQUFNLENBQUMsQ0FBQztNQUM5QyxDQUFDO0lBQ0g7RUFDRixDQUFDLEVBQ0QsT0FBT29FLFFBQVEsRUFBRWxILEdBQUcsRUFBRThELEdBQUcsS0FBSztJQUM1QixNQUFNO01BQUVwQyxVQUFVO01BQUV3RCxNQUFNO01BQUVuQyxpQkFBaUI7TUFBRXRCO0lBQWUsQ0FBQyxHQUFHekIsR0FBRyxDQUFDdUIsSUFLckU7SUFDRCxJQUFJLENBQUM0Riw4QkFBbUIsQ0FBQ0MsUUFBUSxDQUFDbEMsTUFBTSxDQUFDLEVBQUU7TUFDekMsT0FBT3BCLEdBQUcsQ0FBQ0csV0FBVyxDQUFDO1FBQ3JCQyxVQUFVLEVBQUUsR0FBRztRQUNmM0MsSUFBSSxFQUFFO01BQ1IsQ0FBQyxDQUFDO0lBQ0o7SUFDQSxNQUFNK0MsR0FBRyxHQUFHLENBQUM3QyxjQUFjLElBQUlDLFVBQVUsSUFBSSxFQUFFLEVBQUVDLElBQUksQ0FBQyxDQUFDO0lBQ3ZELElBQUksQ0FBQzJDLEdBQUcsRUFBRTtNQUNSLE9BQU9SLEdBQUcsQ0FBQ0csV0FBVyxDQUFDO1FBQ3JCQyxVQUFVLEVBQUUsR0FBRztRQUNmM0MsSUFBSSxFQUFFO01BQ1IsQ0FBQyxDQUFDO0lBQ0o7SUFDQSxNQUFNMkIsR0FBRyxHQUFHLElBQUFtRSxnQkFBVyxFQUFDLENBQUM7SUFDekIsSUFBQUMsYUFBUSxFQUFDaEQsR0FBRyxFQUFFWSxNQUFNLEVBQUVoQyxHQUFHLENBQUM7SUFDMUIsTUFBTXFFLFdBQVcsR0FBRyxNQUFNLElBQUFDLGlCQUFZLEVBQ3BDbEgsWUFBWSxDQUFDLENBQUMsRUFDZDRDLEdBQUcsRUFDSEgsaUJBQWlCLElBQUl1QixHQUFHLEVBQ3hCWSxNQUNGLENBQUM7SUFDRCxPQUFPcEIsR0FBRyxDQUFDMkIsRUFBRSxDQUFDO01BQ1psRSxJQUFJLEVBQUU7UUFDSm1FLE9BQU8sRUFBRSxJQUFJO1FBQ2JaLE9BQU8sRUFBRXlDLFdBQVcsQ0FBQ0UsSUFBSSxHQUNyQixtQ0FBbUMsR0FDbkMsb0RBQW9EO1FBQ3hEQyxRQUFRLEVBQUVILFdBQVcsQ0FBQ0ksT0FBTztRQUM3QnpFLEdBQUcsRUFBRXFFLFdBQVcsQ0FBQ0ksT0FBTyxHQUFHSixXQUFXLENBQUNyRSxHQUFHLEdBQUcwRTtNQUMvQztJQUNGLENBQUMsQ0FBQztFQUNKLENBQ0YsQ0FBQztFQUVELE1BQU1DLG1CQUFtQixHQUFHckYsb0JBQU0sQ0FBQ0ssTUFBTSxDQUFDO0lBQ3hDbkIsVUFBVSxFQUFFYyxvQkFBTSxDQUFDTSxNQUFNLENBQUMsQ0FBQztJQUMzQkMsaUJBQWlCLEVBQUVQLG9CQUFNLENBQUNRLEtBQUssQ0FBQ1Isb0JBQU0sQ0FBQ00sTUFBTSxDQUFDLENBQUMsQ0FBQztJQUNoREcsT0FBTyxFQUFFVCxvQkFBTSxDQUFDTSxNQUFNLENBQUMsQ0FBQztJQUN4QkksR0FBRyxFQUFFVixvQkFBTSxDQUFDTSxNQUFNLENBQUMsQ0FBQztJQUNwQnJCLGNBQWMsRUFBRWUsb0JBQU0sQ0FBQ1EsS0FBSyxDQUFDUixvQkFBTSxDQUFDTSxNQUFNLENBQUMsQ0FBQyxDQUFDO0lBQzdDZ0YsY0FBYyxFQUFFdEYsb0JBQU0sQ0FBQ0MsS0FBSyxDQUFDLENBQzNCRCxvQkFBTSxDQUFDRSxPQUFPLENBQUMsVUFBVSxDQUFDLEVBQzFCRixvQkFBTSxDQUFDRSxPQUFPLENBQUMsWUFBWSxDQUFDLEVBQzVCRixvQkFBTSxDQUFDRSxPQUFPLENBQUMsV0FBVyxDQUFDLEVBQzNCRixvQkFBTSxDQUFDRSxPQUFPLENBQUMsWUFBWSxDQUFDLEVBQzVCRixvQkFBTSxDQUFDRSxPQUFPLENBQUMsS0FBSyxDQUFDLENBQ3RCLENBQUM7SUFDRnFGLGVBQWUsRUFBRXZGLG9CQUFNLENBQUNNLE1BQU0sQ0FBQyxDQUFDO0lBQ2hDa0YsS0FBSyxFQUFFeEYsb0JBQU0sQ0FBQ00sTUFBTSxDQUFDLENBQUM7SUFDdEJtRixXQUFXLEVBQUV6RixvQkFBTSxDQUFDUSxLQUFLLENBQUNSLG9CQUFNLENBQUNNLE1BQU0sQ0FBQyxDQUFDLENBQUM7SUFDMUNvRixlQUFlLEVBQUUxRixvQkFBTSxDQUFDUSxLQUFLLENBQUNSLG9CQUFNLENBQUNNLE1BQU0sQ0FBQyxDQUFDLENBQUM7SUFDOUNvQyxNQUFNLEVBQUUxQyxvQkFBTSxDQUFDQyxLQUFLLENBQUMsQ0FDbkJELG9CQUFNLENBQUNFLE9BQU8sQ0FBQyxPQUFPLENBQUMsRUFDdkJGLG9CQUFNLENBQUNFLE9BQU8sQ0FBQyxlQUFlLENBQUMsRUFDL0JGLG9CQUFNLENBQUNFLE9BQU8sQ0FBQyxTQUFTLENBQUMsRUFDekJGLG9CQUFNLENBQUNFLE9BQU8sQ0FBQyxPQUFPLENBQUMsRUFDdkJGLG9CQUFNLENBQUNFLE9BQU8sQ0FBQyxPQUFPLENBQUMsQ0FDeEIsQ0FBQztJQUNGeUYsUUFBUSxFQUFFM0Ysb0JBQU0sQ0FBQ0MsS0FBSyxDQUFDLENBQ3JCRCxvQkFBTSxDQUFDRSxPQUFPLENBQUMsZUFBZSxDQUFDLEVBQy9CRixvQkFBTSxDQUFDRSxPQUFPLENBQUMsS0FBSyxDQUFDLEVBQ3JCRixvQkFBTSxDQUFDRSxPQUFPLENBQUMsUUFBUSxDQUFDLEVBQ3hCRixvQkFBTSxDQUFDRSxPQUFPLENBQUMsTUFBTSxDQUFDLENBQ3ZCO0VBQ0gsQ0FBQyxDQUFDO0VBRUZZLE1BQU0sQ0FBQ0ssSUFBSSxDQUNUO0lBQUVILElBQUksRUFBRSwrQ0FBK0M7SUFBRUksUUFBUSxFQUFFO01BQUVyQyxJQUFJLEVBQUVzRztJQUFvQjtFQUFFLENBQUMsRUFDbEcsT0FBT2hFLE9BQU8sRUFBRTdELEdBQUcsRUFBRThELEdBQUcsS0FBSztJQUMzQixNQUFNQyxNQUFNLEdBQUcsSUFBQUMsdUJBQVksRUFBQyxDQUFDO0lBQzdCLElBQUksQ0FBQ0QsTUFBTSxFQUFFO01BQ1gsT0FBT0QsR0FBRyxDQUFDRyxXQUFXLENBQUM7UUFBRUMsVUFBVSxFQUFFLEdBQUc7UUFBRTNDLElBQUksRUFBRTtNQUEyQixDQUFDLENBQUM7SUFDL0U7SUFDQSxNQUFNO01BQUVwQixJQUFJO01BQUVFO0lBQUssQ0FBQyxHQUFHTixrQkFBa0IsQ0FBQ0MsR0FBRyxDQUFDO0lBQzlDLE1BQU02QixNQUFNLEdBQUdnQyxPQUFPLENBQUNNLElBQUksQ0FBQ0MsVUFBVSxDQUFDdkMsTUFBTSxDQUFDd0MsYUFBYTtJQUMzRCxNQUFNMkIsQ0FBQyxHQUFHaEcsR0FBRyxDQUFDdUIsSUFhYjtJQUNELE1BQU0wQixPQUFPLEdBQUcsQ0FBQytDLENBQUMsQ0FBQy9DLE9BQU8sSUFBSSxFQUFFLEVBQUV0QixJQUFJLENBQUMsQ0FBQztJQUN4QyxJQUFJLENBQUNzQixPQUFPLEVBQUU7TUFDWixPQUFPYSxHQUFHLENBQUNHLFdBQVcsQ0FBQztRQUFFQyxVQUFVLEVBQUUsR0FBRztRQUFFM0MsSUFBSSxFQUFFO01BQXVCLENBQUMsQ0FBQztJQUMzRTtJQUNBLE1BQU0rQyxHQUFHLEdBQUdoRCxVQUFVLENBQUMwRSxDQUFDLENBQUM7SUFDekIsSUFBSSxDQUFDMUIsR0FBRyxFQUFFO01BQ1IsT0FBT1IsR0FBRyxDQUFDRyxXQUFXLENBQUM7UUFBRUMsVUFBVSxFQUFFLEdBQUc7UUFBRTNDLElBQUksRUFBRTtNQUF5QyxDQUFDLENBQUM7SUFDN0Y7SUFDQSxNQUFNZ0QsUUFBUSxHQUFHLElBQUFDLGdCQUFXLEVBQUNGLEdBQUcsRUFBRSxrQkFBa0IsRUFBRTBCLENBQUMsQ0FBQzlDLEdBQUcsSUFBSSxFQUFFLENBQUM7SUFDbEUsSUFBSSxDQUFDcUIsUUFBUSxDQUFDRSxLQUFLLEVBQUU7TUFDbkIsT0FBT1gsR0FBRyxDQUFDRyxXQUFXLENBQUM7UUFBRUMsVUFBVSxFQUFFLEdBQUc7UUFBRTNDLElBQUksRUFBRWdELFFBQVEsQ0FBQ0csTUFBTSxJQUFJO01BQWUsQ0FBQyxDQUFDO0lBQ3RGO0lBQ0EsTUFBTUMsVUFBVSxHQUFHcUIsQ0FBQyxDQUFDakQsaUJBQWlCLElBQUlpRCxDQUFDLENBQUN0RSxVQUFVO0lBQ3RELElBQUk7TUFBQSxJQUFBMEcsTUFBQTtNQUNGLE1BQU1DLE9BQStCLEdBQUc7UUFDdENDLGNBQWMsRUFBRXRDLENBQUMsQ0FBQytCLGVBQWU7UUFDakNRLGFBQWEsRUFBRXZDLENBQUMsQ0FBQzhCLGNBQWM7UUFDL0JFLEtBQUssRUFBRWhDLENBQUMsQ0FBQ2dDLEtBQUs7UUFDZEMsV0FBVyxFQUFFakMsQ0FBQyxDQUFDaUMsV0FBVztRQUMxQk8sY0FBYyxFQUFFeEMsQ0FBQyxDQUFDa0MsZUFBZTtRQUNqQ2hELE1BQU0sRUFBRWMsQ0FBQyxDQUFDZCxNQUFNO1FBQ2hCaUQsUUFBUSxFQUFFbkMsQ0FBQyxDQUFDbUM7TUFDZCxDQUFDO01BQ0QsTUFBTXRELE1BQU0sR0FBRyxNQUFNLElBQUE0RCwwQkFBZSxFQUFDMUUsTUFBTSxFQUFFc0UsT0FBTyxDQUFDO01BQ3JELE1BQU12RCxPQUFPLEdBQUdDLElBQUksQ0FBQ0MsU0FBUyxDQUFDSCxNQUFNLENBQUMsQ0FBQ0ksS0FBSyxDQUFDLENBQUMsRUFBRSxJQUFJLENBQUM7TUFDckQsTUFBTXJELGFBQWEsQ0FBQ0MsTUFBTSxFQUFFO1FBQzFCcUQsTUFBTSxFQUFFLGtCQUFrQjtRQUMxQnhELFVBQVUsRUFBRXNFLENBQUMsQ0FBQ3RFLFVBQVU7UUFDeEJxQixpQkFBaUIsRUFBRTRCLFVBQVU7UUFDN0JRLFlBQVksRUFBRWhGLElBQUk7UUFDbEJFLElBQUk7UUFDSitFLE1BQU0sRUFBRSxTQUFTO1FBQ2pCTixPQUFPO1FBQ1BPLFNBQVMsR0FBQStDLE1BQUEsR0FBR3BJLEdBQUcsQ0FBU3NGLElBQUksY0FBQThDLE1BQUEsdUJBQWpCQSxNQUFBLENBQW1CN0MsYUFBYTtRQUMzQ0MsWUFBWSxFQUFFLElBQUk7UUFDbEJ2QztNQUNGLENBQUMsQ0FBQztNQUNGLE9BQU9hLEdBQUcsQ0FBQzJCLEVBQUUsQ0FBQztRQUNabEUsSUFBSSxFQUFFO1VBQ0ptRSxPQUFPLEVBQUUsSUFBSTtVQUNiUixNQUFNLEVBQUUsa0JBQWtCO1VBQzFCeEQsVUFBVSxFQUFFc0UsQ0FBQyxDQUFDdEUsVUFBVTtVQUN4Qm9ELE9BQU87VUFDUDdDLFNBQVMsRUFBRSxJQUFJQyxJQUFJLENBQUMsQ0FBQyxDQUFDQyxXQUFXLENBQUM7UUFDcEM7TUFDRixDQUFDLENBQUM7SUFDSixDQUFDLENBQUMsT0FBT0MsR0FBWSxFQUFFO01BQUEsSUFBQXNHLE1BQUE7TUFDckIsTUFBTTlHLGFBQWEsQ0FBQ0MsTUFBTSxFQUFFO1FBQzFCcUQsTUFBTSxFQUFFLGtCQUFrQjtRQUMxQnhELFVBQVUsRUFBRXNFLENBQUMsQ0FBQ3RFLFVBQVU7UUFDeEJxQixpQkFBaUIsRUFBRTRCLFVBQVU7UUFDN0JRLFlBQVksRUFBRWhGLElBQUk7UUFDbEJFLElBQUk7UUFDSitFLE1BQU0sRUFBRSxTQUFTO1FBQ2pCTixPQUFPLEVBQUUxQyxHQUFHLFlBQVl3RCxLQUFLLEdBQUd4RCxHQUFHLENBQUMwQyxPQUFPLEdBQUdlLE1BQU0sQ0FBQ3pELEdBQUcsQ0FBQztRQUN6RGlELFNBQVMsR0FBQXFELE1BQUEsR0FBRzFJLEdBQUcsQ0FBU3NGLElBQUksY0FBQW9ELE1BQUEsdUJBQWpCQSxNQUFBLENBQW1CbkQsYUFBYTtRQUMzQ0MsWUFBWSxFQUFFLElBQUk7UUFDbEJ2QztNQUNGLENBQUMsQ0FBQztNQUNGLE9BQU9hLEdBQUcsQ0FBQ0csV0FBVyxDQUFDO1FBQ3JCQyxVQUFVLEVBQUUsSUFBQTRCLHlCQUFjLEVBQUMxRCxHQUFHLENBQUM7UUFDL0JiLElBQUksRUFBRWEsR0FBRyxZQUFZd0QsS0FBSyxHQUFHeEQsR0FBRyxDQUFDMEMsT0FBTyxHQUFHZSxNQUFNLENBQUN6RCxHQUFHO01BQ3ZELENBQUMsQ0FBQztJQUNKO0VBQ0YsQ0FDRixDQUFDO0VBRUQsTUFBTXVHLG1CQUFtQixHQUFHbkcsb0JBQU0sQ0FBQ0ssTUFBTSxDQUFDO0lBQ3hDK0YsWUFBWSxFQUFFcEcsb0JBQU0sQ0FBQ00sTUFBTSxDQUFDLENBQUM7SUFDN0JwQixVQUFVLEVBQUVjLG9CQUFNLENBQUNRLEtBQUssQ0FBQ1Isb0JBQU0sQ0FBQ00sTUFBTSxDQUFDLENBQUMsQ0FBQztJQUN6Q0MsaUJBQWlCLEVBQUVQLG9CQUFNLENBQUNRLEtBQUssQ0FBQ1Isb0JBQU0sQ0FBQ00sTUFBTSxDQUFDLENBQUMsQ0FBQztJQUNoREcsT0FBTyxFQUFFVCxvQkFBTSxDQUFDTSxNQUFNLENBQUMsQ0FBQztJQUN4QkksR0FBRyxFQUFFVixvQkFBTSxDQUFDTSxNQUFNLENBQUMsQ0FBQztJQUNwQmtGLEtBQUssRUFBRXhGLG9CQUFNLENBQUNRLEtBQUssQ0FBQ1Isb0JBQU0sQ0FBQ00sTUFBTSxDQUFDLENBQUMsQ0FBQztJQUNwQ21GLFdBQVcsRUFBRXpGLG9CQUFNLENBQUNRLEtBQUssQ0FBQ1Isb0JBQU0sQ0FBQ00sTUFBTSxDQUFDLENBQUMsQ0FBQztJQUMxQ29DLE1BQU0sRUFBRTFDLG9CQUFNLENBQUNRLEtBQUssQ0FDbEJSLG9CQUFNLENBQUNDLEtBQUssQ0FBQyxDQUNYRCxvQkFBTSxDQUFDRSxPQUFPLENBQUMsT0FBTyxDQUFDLEVBQ3ZCRixvQkFBTSxDQUFDRSxPQUFPLENBQUMsZUFBZSxDQUFDLEVBQy9CRixvQkFBTSxDQUFDRSxPQUFPLENBQUMsU0FBUyxDQUFDLEVBQ3pCRixvQkFBTSxDQUFDRSxPQUFPLENBQUMsT0FBTyxDQUFDLEVBQ3ZCRixvQkFBTSxDQUFDRSxPQUFPLENBQUMsT0FBTyxDQUFDLENBQ3hCLENBQ0gsQ0FBQztJQUNEeUYsUUFBUSxFQUFFM0Ysb0JBQU0sQ0FBQ1EsS0FBSyxDQUNwQlIsb0JBQU0sQ0FBQ0MsS0FBSyxDQUFDLENBQ1hELG9CQUFNLENBQUNFLE9BQU8sQ0FBQyxlQUFlLENBQUMsRUFDL0JGLG9CQUFNLENBQUNFLE9BQU8sQ0FBQyxLQUFLLENBQUMsRUFDckJGLG9CQUFNLENBQUNFLE9BQU8sQ0FBQyxRQUFRLENBQUMsRUFDeEJGLG9CQUFNLENBQUNFLE9BQU8sQ0FBQyxNQUFNLENBQUMsQ0FDdkIsQ0FDSCxDQUFDO0lBQ0R3RixlQUFlLEVBQUUxRixvQkFBTSxDQUFDUSxLQUFLLENBQUNSLG9CQUFNLENBQUNNLE1BQU0sQ0FBQyxDQUFDO0VBQy9DLENBQUMsQ0FBQztFQUVGUSxNQUFNLENBQUNLLElBQUksQ0FDVDtJQUFFSCxJQUFJLEVBQUUsK0NBQStDO0lBQUVJLFFBQVEsRUFBRTtNQUFFckMsSUFBSSxFQUFFb0g7SUFBb0I7RUFBRSxDQUFDLEVBQ2xHLE9BQU85RSxPQUFPLEVBQUU3RCxHQUFHLEVBQUU4RCxHQUFHLEtBQUs7SUFDM0IsTUFBTUMsTUFBTSxHQUFHLElBQUFDLHVCQUFZLEVBQUMsQ0FBQztJQUM3QixJQUFJLENBQUNELE1BQU0sRUFBRTtNQUNYLE9BQU9ELEdBQUcsQ0FBQ0csV0FBVyxDQUFDO1FBQUVDLFVBQVUsRUFBRSxHQUFHO1FBQUUzQyxJQUFJLEVBQUU7TUFBMkIsQ0FBQyxDQUFDO0lBQy9FO0lBQ0EsTUFBTTtNQUFFcEIsSUFBSTtNQUFFRTtJQUFLLENBQUMsR0FBR04sa0JBQWtCLENBQUNDLEdBQUcsQ0FBQztJQUM5QyxNQUFNNkIsTUFBTSxHQUFHZ0MsT0FBTyxDQUFDTSxJQUFJLENBQUNDLFVBQVUsQ0FBQ3ZDLE1BQU0sQ0FBQ3dDLGFBQWE7SUFDM0QsTUFBTTJCLENBQUMsR0FBR2hHLEdBQUcsQ0FBQ3VCLElBV2I7SUFDRCxNQUFNMEIsT0FBTyxHQUFHLENBQUMrQyxDQUFDLENBQUMvQyxPQUFPLElBQUksRUFBRSxFQUFFdEIsSUFBSSxDQUFDLENBQUM7SUFDeEMsSUFBSSxDQUFDc0IsT0FBTyxFQUFFO01BQ1osT0FBT2EsR0FBRyxDQUFDRyxXQUFXLENBQUM7UUFBRUMsVUFBVSxFQUFFLEdBQUc7UUFBRTNDLElBQUksRUFBRTtNQUF1QixDQUFDLENBQUM7SUFDM0U7SUFDQSxNQUFNZ0QsUUFBUSxHQUFHLElBQUFDLGdCQUFXLEVBQUN3QixDQUFDLENBQUM0QyxZQUFZLEVBQUUsa0JBQWtCLEVBQUU1QyxDQUFDLENBQUM5QyxHQUFHLElBQUksRUFBRSxDQUFDO0lBQzdFLElBQUksQ0FBQ3FCLFFBQVEsQ0FBQ0UsS0FBSyxFQUFFO01BQ25CLE9BQU9YLEdBQUcsQ0FBQ0csV0FBVyxDQUFDO1FBQUVDLFVBQVUsRUFBRSxHQUFHO1FBQUUzQyxJQUFJLEVBQUVnRCxRQUFRLENBQUNHLE1BQU0sSUFBSTtNQUFlLENBQUMsQ0FBQztJQUN0RjtJQUNBLE1BQU1DLFVBQVUsR0FBR3FCLENBQUMsQ0FBQ2pELGlCQUFpQixJQUFJaUQsQ0FBQyxDQUFDdEUsVUFBVSxJQUFJc0UsQ0FBQyxDQUFDNEMsWUFBWTtJQUN4RSxNQUFNQyxLQUE4QixHQUFHLENBQUMsQ0FBQztJQUN6QyxJQUFJN0MsQ0FBQyxDQUFDZ0MsS0FBSyxJQUFJLElBQUksRUFBRWEsS0FBSyxDQUFDYixLQUFLLEdBQUdoQyxDQUFDLENBQUNnQyxLQUFLO0lBQzFDLElBQUloQyxDQUFDLENBQUNpQyxXQUFXLElBQUksSUFBSSxFQUFFWSxLQUFLLENBQUNaLFdBQVcsR0FBR2pDLENBQUMsQ0FBQ2lDLFdBQVc7SUFDNUQsSUFBSWpDLENBQUMsQ0FBQ2QsTUFBTSxJQUFJLElBQUksRUFBRTJELEtBQUssQ0FBQzNELE1BQU0sR0FBR2MsQ0FBQyxDQUFDZCxNQUFNO0lBQzdDLElBQUljLENBQUMsQ0FBQ21DLFFBQVEsSUFBSSxJQUFJLEVBQUVVLEtBQUssQ0FBQ1YsUUFBUSxHQUFHbkMsQ0FBQyxDQUFDbUMsUUFBUTtJQUNuRCxJQUFJbkMsQ0FBQyxDQUFDa0MsZUFBZSxJQUFJLElBQUksRUFBRVcsS0FBSyxDQUFDTCxjQUFjLEdBQUd4QyxDQUFDLENBQUNrQyxlQUFlO0lBQ3ZFLElBQUlZLE1BQU0sQ0FBQ0MsSUFBSSxDQUFDRixLQUFLLENBQUMsQ0FBQ0csTUFBTSxLQUFLLENBQUMsRUFBRTtNQUNuQyxPQUFPbEYsR0FBRyxDQUFDRyxXQUFXLENBQUM7UUFBRUMsVUFBVSxFQUFFLEdBQUc7UUFBRTNDLElBQUksRUFBRTtNQUF3QyxDQUFDLENBQUM7SUFDNUY7SUFDQSxJQUFJO01BQUEsSUFBQTBILE1BQUE7TUFDRixNQUFNcEUsTUFBTSxHQUFHLE1BQU0sSUFBQXFFLDBCQUFlLEVBQUNuRixNQUFNLEVBQUVpQyxDQUFDLENBQUM0QyxZQUFZLEVBQUVDLEtBQUssQ0FBQztNQUNuRSxNQUFNL0QsT0FBTyxHQUFHQyxJQUFJLENBQUNDLFNBQVMsQ0FBQ0gsTUFBTSxDQUFDLENBQUNJLEtBQUssQ0FBQyxDQUFDLEVBQUUsSUFBSSxDQUFDO01BQ3JELE1BQU1yRCxhQUFhLENBQUNDLE1BQU0sRUFBRTtRQUMxQnFELE1BQU0sRUFBRSxrQkFBa0I7UUFDMUJ4RCxVQUFVLEVBQUVzRSxDQUFDLENBQUN0RSxVQUFVLElBQUlzRSxDQUFDLENBQUM0QyxZQUFZO1FBQzFDN0YsaUJBQWlCLEVBQUU0QixVQUFVO1FBQzdCUSxZQUFZLEVBQUVoRixJQUFJO1FBQ2xCRSxJQUFJO1FBQ0orRSxNQUFNLEVBQUUsU0FBUztRQUNqQk4sT0FBTztRQUNQTyxTQUFTLEdBQUE0RCxNQUFBLEdBQUdqSixHQUFHLENBQVNzRixJQUFJLGNBQUEyRCxNQUFBLHVCQUFqQkEsTUFBQSxDQUFtQjFELGFBQWE7UUFDM0NDLFlBQVksRUFBRSxJQUFJO1FBQ2xCdkM7TUFDRixDQUFDLENBQUM7TUFDRixPQUFPYSxHQUFHLENBQUMyQixFQUFFLENBQUM7UUFDWmxFLElBQUksRUFBRTtVQUNKbUUsT0FBTyxFQUFFLElBQUk7VUFDYlIsTUFBTSxFQUFFLGtCQUFrQjtVQUMxQjBELFlBQVksRUFBRTVDLENBQUMsQ0FBQzRDLFlBQVk7VUFDNUI5RCxPQUFPO1VBQ1A3QyxTQUFTLEVBQUUsSUFBSUMsSUFBSSxDQUFDLENBQUMsQ0FBQ0MsV0FBVyxDQUFDO1FBQ3BDO01BQ0YsQ0FBQyxDQUFDO0lBQ0osQ0FBQyxDQUFDLE9BQU9DLEdBQVksRUFBRTtNQUFBLElBQUErRyxPQUFBO01BQ3JCLE1BQU12SCxhQUFhLENBQUNDLE1BQU0sRUFBRTtRQUMxQnFELE1BQU0sRUFBRSxrQkFBa0I7UUFDMUJ4RCxVQUFVLEVBQUVzRSxDQUFDLENBQUN0RSxVQUFVLElBQUlzRSxDQUFDLENBQUM0QyxZQUFZO1FBQzFDN0YsaUJBQWlCLEVBQUU0QixVQUFVO1FBQzdCUSxZQUFZLEVBQUVoRixJQUFJO1FBQ2xCRSxJQUFJO1FBQ0orRSxNQUFNLEVBQUUsU0FBUztRQUNqQk4sT0FBTyxFQUFFMUMsR0FBRyxZQUFZd0QsS0FBSyxHQUFHeEQsR0FBRyxDQUFDMEMsT0FBTyxHQUFHZSxNQUFNLENBQUN6RCxHQUFHLENBQUM7UUFDekRpRCxTQUFTLEdBQUE4RCxPQUFBLEdBQUduSixHQUFHLENBQVNzRixJQUFJLGNBQUE2RCxPQUFBLHVCQUFqQkEsT0FBQSxDQUFtQjVELGFBQWE7UUFDM0NDLFlBQVksRUFBRSxJQUFJO1FBQ2xCdkM7TUFDRixDQUFDLENBQUM7TUFDRixPQUFPYSxHQUFHLENBQUNHLFdBQVcsQ0FBQztRQUNyQkMsVUFBVSxFQUFFLElBQUE0Qix5QkFBYyxFQUFDMUQsR0FBRyxDQUFDO1FBQy9CYixJQUFJLEVBQUVhLEdBQUcsWUFBWXdELEtBQUssR0FBR3hELEdBQUcsQ0FBQzBDLE9BQU8sR0FBR2UsTUFBTSxDQUFDekQsR0FBRztNQUN2RCxDQUFDLENBQUM7SUFDSjtFQUNGLENBQ0YsQ0FBQztFQUVEa0IsTUFBTSxDQUFDSyxJQUFJLENBQ1Q7SUFDRUgsSUFBSSxFQUFFLG9EQUFvRDtJQUMxREksUUFBUSxFQUFFO01BQ1JyQyxJQUFJLEVBQUVpQixvQkFBTSxDQUFDSyxNQUFNLENBQUM7UUFDbEJuQixVQUFVLEVBQUVjLG9CQUFNLENBQUNNLE1BQU0sQ0FBQyxDQUFDO1FBQzNCQyxpQkFBaUIsRUFBRVAsb0JBQU0sQ0FBQ1EsS0FBSyxDQUFDUixvQkFBTSxDQUFDTSxNQUFNLENBQUMsQ0FBQyxDQUFDO1FBQ2hEckIsY0FBYyxFQUFFZSxvQkFBTSxDQUFDUSxLQUFLLENBQUNSLG9CQUFNLENBQUNNLE1BQU0sQ0FBQyxDQUFDO01BQzlDLENBQUM7SUFDSDtFQUNGLENBQUMsRUFDRCxPQUFPb0UsUUFBUSxFQUFFbEgsR0FBRyxFQUFFOEQsR0FBRyxLQUFLO0lBQzVCLE1BQU07TUFBRXBDLFVBQVU7TUFBRXFCLGlCQUFpQjtNQUFFdEI7SUFBZSxDQUFDLEdBQUd6QixHQUFHLENBQUN1QixJQUk3RDtJQUNELE1BQU0rQyxHQUFHLEdBQUcsQ0FBQzdDLGNBQWMsSUFBSUMsVUFBVSxFQUFFQyxJQUFJLENBQUMsQ0FBQztJQUNqRCxNQUFNdUIsR0FBRyxHQUFHLElBQUFtRSxnQkFBVyxFQUFDLENBQUM7SUFDekIsSUFBQUMsYUFBUSxFQUFDaEQsR0FBRyxFQUFFLGtCQUFrQixFQUFFcEIsR0FBRyxDQUFDO0lBQ3RDLE1BQU1xRSxXQUFXLEdBQUcsTUFBTSxJQUFBQyxpQkFBWSxFQUNwQ2xILFlBQVksQ0FBQyxDQUFDLEVBQ2Q0QyxHQUFHLEVBQ0hILGlCQUFpQixJQUFJckIsVUFBVSxFQUMvQixrQkFDRixDQUFDO0lBQ0QsT0FBT29DLEdBQUcsQ0FBQzJCLEVBQUUsQ0FBQztNQUNabEUsSUFBSSxFQUFFO1FBQ0ptRSxPQUFPLEVBQUUsSUFBSTtRQUNiWixPQUFPLEVBQUV5QyxXQUFXLENBQUNFLElBQUksR0FBRyxXQUFXLEdBQUcsZ0JBQWdCO1FBQzFEQyxRQUFRLEVBQUVILFdBQVcsQ0FBQ0ksT0FBTztRQUM3QnpFLEdBQUcsRUFBRXFFLFdBQVcsQ0FBQ0ksT0FBTyxHQUFHSixXQUFXLENBQUNyRSxHQUFHLEdBQUcwRTtNQUMvQztJQUNGLENBQUMsQ0FBQztFQUNKLENBQ0YsQ0FBQztFQUVELE1BQU13QixtQkFBbUIsR0FBRzVHLG9CQUFNLENBQUNLLE1BQU0sQ0FBQztJQUN4QytGLFlBQVksRUFBRXBHLG9CQUFNLENBQUNNLE1BQU0sQ0FBQyxDQUFDO0lBQzdCcEIsVUFBVSxFQUFFYyxvQkFBTSxDQUFDUSxLQUFLLENBQUNSLG9CQUFNLENBQUNNLE1BQU0sQ0FBQyxDQUFDLENBQUM7SUFDekNDLGlCQUFpQixFQUFFUCxvQkFBTSxDQUFDUSxLQUFLLENBQUNSLG9CQUFNLENBQUNNLE1BQU0sQ0FBQyxDQUFDLENBQUM7SUFDaERHLE9BQU8sRUFBRVQsb0JBQU0sQ0FBQ00sTUFBTSxDQUFDLENBQUM7SUFDeEJJLEdBQUcsRUFBRVYsb0JBQU0sQ0FBQ00sTUFBTSxDQUFDO0VBQ3JCLENBQUMsQ0FBQztFQUVGUSxNQUFNLENBQUNLLElBQUksQ0FDVDtJQUFFSCxJQUFJLEVBQUUsK0NBQStDO0lBQUVJLFFBQVEsRUFBRTtNQUFFckMsSUFBSSxFQUFFNkg7SUFBb0I7RUFBRSxDQUFDLEVBQ2xHLE9BQU92RixPQUFPLEVBQUU3RCxHQUFHLEVBQUU4RCxHQUFHLEtBQUs7SUFDM0IsTUFBTUMsTUFBTSxHQUFHLElBQUFDLHVCQUFZLEVBQUMsQ0FBQztJQUM3QixJQUFJLENBQUNELE1BQU0sRUFBRTtNQUNYLE9BQU9ELEdBQUcsQ0FBQ0csV0FBVyxDQUFDO1FBQUVDLFVBQVUsRUFBRSxHQUFHO1FBQUUzQyxJQUFJLEVBQUU7TUFBMkIsQ0FBQyxDQUFDO0lBQy9FO0lBQ0EsTUFBTTtNQUFFcEIsSUFBSTtNQUFFRTtJQUFLLENBQUMsR0FBR04sa0JBQWtCLENBQUNDLEdBQUcsQ0FBQztJQUM5QyxNQUFNNkIsTUFBTSxHQUFHZ0MsT0FBTyxDQUFDTSxJQUFJLENBQUNDLFVBQVUsQ0FBQ3ZDLE1BQU0sQ0FBQ3dDLGFBQWE7SUFDM0QsTUFBTTJCLENBQUMsR0FBR2hHLEdBQUcsQ0FBQ3VCLElBTWI7SUFDRCxNQUFNMEIsT0FBTyxHQUFHLENBQUMrQyxDQUFDLENBQUMvQyxPQUFPLElBQUksRUFBRSxFQUFFdEIsSUFBSSxDQUFDLENBQUM7SUFDeEMsSUFBSSxDQUFDc0IsT0FBTyxFQUFFO01BQ1osT0FBT2EsR0FBRyxDQUFDRyxXQUFXLENBQUM7UUFBRUMsVUFBVSxFQUFFLEdBQUc7UUFBRTNDLElBQUksRUFBRTtNQUF1QixDQUFDLENBQUM7SUFDM0U7SUFDQSxNQUFNZ0QsUUFBUSxHQUFHLElBQUFDLGdCQUFXLEVBQUN3QixDQUFDLENBQUM0QyxZQUFZLEVBQUUsa0JBQWtCLEVBQUU1QyxDQUFDLENBQUM5QyxHQUFHLElBQUksRUFBRSxDQUFDO0lBQzdFLElBQUksQ0FBQ3FCLFFBQVEsQ0FBQ0UsS0FBSyxFQUFFO01BQ25CLE9BQU9YLEdBQUcsQ0FBQ0csV0FBVyxDQUFDO1FBQUVDLFVBQVUsRUFBRSxHQUFHO1FBQUUzQyxJQUFJLEVBQUVnRCxRQUFRLENBQUNHLE1BQU0sSUFBSTtNQUFlLENBQUMsQ0FBQztJQUN0RjtJQUNBLE1BQU1DLFVBQVUsR0FBR3FCLENBQUMsQ0FBQ2pELGlCQUFpQixJQUFJaUQsQ0FBQyxDQUFDdEUsVUFBVSxJQUFJc0UsQ0FBQyxDQUFDNEMsWUFBWTtJQUN4RSxJQUFJO01BQUEsSUFBQVMsT0FBQTtNQUNGLE1BQU14RSxNQUFNLEdBQUcsTUFBTSxJQUFBeUUsMEJBQWUsRUFBQ3ZGLE1BQU0sRUFBRWlDLENBQUMsQ0FBQzRDLFlBQVksQ0FBQztNQUM1RCxNQUFNOUQsT0FBTyxHQUFHQyxJQUFJLENBQUNDLFNBQVMsQ0FBQ0gsTUFBTSxDQUFDLENBQUNJLEtBQUssQ0FBQyxDQUFDLEVBQUUsSUFBSSxDQUFDO01BQ3JELE1BQU1yRCxhQUFhLENBQUNDLE1BQU0sRUFBRTtRQUMxQnFELE1BQU0sRUFBRSxrQkFBa0I7UUFDMUJ4RCxVQUFVLEVBQUVzRSxDQUFDLENBQUN0RSxVQUFVLElBQUlzRSxDQUFDLENBQUM0QyxZQUFZO1FBQzFDN0YsaUJBQWlCLEVBQUU0QixVQUFVO1FBQzdCUSxZQUFZLEVBQUVoRixJQUFJO1FBQ2xCRSxJQUFJO1FBQ0orRSxNQUFNLEVBQUUsU0FBUztRQUNqQk4sT0FBTztRQUNQTyxTQUFTLEdBQUFnRSxPQUFBLEdBQUdySixHQUFHLENBQVNzRixJQUFJLGNBQUErRCxPQUFBLHVCQUFqQkEsT0FBQSxDQUFtQjlELGFBQWE7UUFDM0NDLFlBQVksRUFBRSxJQUFJO1FBQ2xCdkM7TUFDRixDQUFDLENBQUM7TUFDRixPQUFPYSxHQUFHLENBQUMyQixFQUFFLENBQUM7UUFDWmxFLElBQUksRUFBRTtVQUNKbUUsT0FBTyxFQUFFLElBQUk7VUFDYlIsTUFBTSxFQUFFLGtCQUFrQjtVQUMxQnhELFVBQVUsRUFBRXNFLENBQUMsQ0FBQ3RFLFVBQVUsSUFBSXNFLENBQUMsQ0FBQzRDLFlBQVk7VUFDMUM5RCxPQUFPO1VBQ1A3QyxTQUFTLEVBQUUsSUFBSUMsSUFBSSxDQUFDLENBQUMsQ0FBQ0MsV0FBVyxDQUFDO1FBQ3BDO01BQ0YsQ0FBQyxDQUFDO0lBQ0osQ0FBQyxDQUFDLE9BQU9DLEdBQVksRUFBRTtNQUFBLElBQUFtSCxPQUFBO01BQ3JCLE1BQU0zSCxhQUFhLENBQUNDLE1BQU0sRUFBRTtRQUMxQnFELE1BQU0sRUFBRSxrQkFBa0I7UUFDMUJ4RCxVQUFVLEVBQUVzRSxDQUFDLENBQUN0RSxVQUFVLElBQUlzRSxDQUFDLENBQUM0QyxZQUFZO1FBQzFDN0YsaUJBQWlCLEVBQUU0QixVQUFVO1FBQzdCUSxZQUFZLEVBQUVoRixJQUFJO1FBQ2xCRSxJQUFJO1FBQ0orRSxNQUFNLEVBQUUsU0FBUztRQUNqQk4sT0FBTyxFQUFFMUMsR0FBRyxZQUFZd0QsS0FBSyxHQUFHeEQsR0FBRyxDQUFDMEMsT0FBTyxHQUFHZSxNQUFNLENBQUN6RCxHQUFHLENBQUM7UUFDekRpRCxTQUFTLEdBQUFrRSxPQUFBLEdBQUd2SixHQUFHLENBQVNzRixJQUFJLGNBQUFpRSxPQUFBLHVCQUFqQkEsT0FBQSxDQUFtQmhFLGFBQWE7UUFDM0NDLFlBQVksRUFBRSxJQUFJO1FBQ2xCdkM7TUFDRixDQUFDLENBQUM7TUFDRixPQUFPYSxHQUFHLENBQUNHLFdBQVcsQ0FBQztRQUNyQkMsVUFBVSxFQUFFLElBQUE0Qix5QkFBYyxFQUFDMUQsR0FBRyxDQUFDO1FBQy9CYixJQUFJLEVBQUVhLEdBQUcsWUFBWXdELEtBQUssR0FBR3hELEdBQUcsQ0FBQzBDLE9BQU8sR0FBR2UsTUFBTSxDQUFDekQsR0FBRztNQUN2RCxDQUFDLENBQUM7SUFDSjtFQUNGLENBQ0YsQ0FBQztFQUVEa0IsTUFBTSxDQUFDSyxJQUFJLENBQ1Q7SUFDRUgsSUFBSSxFQUFFLDJEQUEyRDtJQUNqRUksUUFBUSxFQUFFO01BQ1JyQyxJQUFJLEVBQUVpQixvQkFBTSxDQUFDSyxNQUFNLENBQUM7UUFDbEIrRixZQUFZLEVBQUVwRyxvQkFBTSxDQUFDTSxNQUFNLENBQUMsQ0FBQztRQUM3QkMsaUJBQWlCLEVBQUVQLG9CQUFNLENBQUNRLEtBQUssQ0FBQ1Isb0JBQU0sQ0FBQ00sTUFBTSxDQUFDLENBQUM7TUFDakQsQ0FBQztJQUNIO0VBQ0YsQ0FBQyxFQUNELE9BQU9vRSxRQUFRLEVBQUVsSCxHQUFHLEVBQUU4RCxHQUFHLEtBQUs7SUFDNUIsTUFBTTtNQUFFOEUsWUFBWTtNQUFFN0Y7SUFBa0IsQ0FBQyxHQUFHL0MsR0FBRyxDQUFDdUIsSUFHL0M7SUFDRCxNQUFNMkIsR0FBRyxHQUFHLElBQUFtRSxnQkFBVyxFQUFDLENBQUM7SUFDekIsSUFBQUMsYUFBUSxFQUFDc0IsWUFBWSxFQUFFLGtCQUFrQixFQUFFMUYsR0FBRyxDQUFDO0lBQy9DLE1BQU1xRSxXQUFXLEdBQUcsTUFBTSxJQUFBQyxpQkFBWSxFQUNwQ2xILFlBQVksQ0FBQyxDQUFDLEVBQ2Q0QyxHQUFHLEVBQ0hILGlCQUFpQixJQUFJNkYsWUFBWSxFQUNqQyxrQkFDRixDQUFDO0lBQ0QsT0FBTzlFLEdBQUcsQ0FBQzJCLEVBQUUsQ0FBQztNQUNabEUsSUFBSSxFQUFFO1FBQ0ptRSxPQUFPLEVBQUUsSUFBSTtRQUNiZ0MsUUFBUSxFQUFFSCxXQUFXLENBQUNJLE9BQU87UUFDN0J6RSxHQUFHLEVBQUVxRSxXQUFXLENBQUNJLE9BQU8sR0FBR0osV0FBVyxDQUFDckUsR0FBRyxHQUFHMEU7TUFDL0M7SUFDRixDQUFDLENBQUM7RUFDSixDQUNGLENBQUM7RUFFRHRFLE1BQU0sQ0FBQ0ssSUFBSSxDQUNUO0lBQ0VILElBQUksRUFBRSwyREFBMkQ7SUFDakVJLFFBQVEsRUFBRTtNQUNSckMsSUFBSSxFQUFFaUIsb0JBQU0sQ0FBQ0ssTUFBTSxDQUFDO1FBQ2xCK0YsWUFBWSxFQUFFcEcsb0JBQU0sQ0FBQ00sTUFBTSxDQUFDLENBQUM7UUFDN0JDLGlCQUFpQixFQUFFUCxvQkFBTSxDQUFDUSxLQUFLLENBQUNSLG9CQUFNLENBQUNNLE1BQU0sQ0FBQyxDQUFDO01BQ2pELENBQUM7SUFDSDtFQUNGLENBQUMsRUFDRCxPQUFPb0UsUUFBUSxFQUFFbEgsR0FBRyxFQUFFOEQsR0FBRyxLQUFLO0lBQzVCLE1BQU07TUFBRThFLFlBQVk7TUFBRTdGO0lBQWtCLENBQUMsR0FBRy9DLEdBQUcsQ0FBQ3VCLElBRy9DO0lBQ0QsTUFBTTJCLEdBQUcsR0FBRyxJQUFBbUUsZ0JBQVcsRUFBQyxDQUFDO0lBQ3pCLElBQUFDLGFBQVEsRUFBQ3NCLFlBQVksRUFBRSxrQkFBa0IsRUFBRTFGLEdBQUcsQ0FBQztJQUMvQyxNQUFNcUUsV0FBVyxHQUFHLE1BQU0sSUFBQUMsaUJBQVksRUFDcENsSCxZQUFZLENBQUMsQ0FBQyxFQUNkNEMsR0FBRyxFQUNISCxpQkFBaUIsSUFBSTZGLFlBQVksRUFDakMsa0JBQ0YsQ0FBQztJQUNELE9BQU85RSxHQUFHLENBQUMyQixFQUFFLENBQUM7TUFDWmxFLElBQUksRUFBRTtRQUNKbUUsT0FBTyxFQUFFLElBQUk7UUFDYmdDLFFBQVEsRUFBRUgsV0FBVyxDQUFDSSxPQUFPO1FBQzdCekUsR0FBRyxFQUFFcUUsV0FBVyxDQUFDSSxPQUFPLEdBQUdKLFdBQVcsQ0FBQ3JFLEdBQUcsR0FBRzBFO01BQy9DO0lBQ0YsQ0FBQyxDQUFDO0VBQ0osQ0FDRixDQUFDO0FBQ0gifQ==