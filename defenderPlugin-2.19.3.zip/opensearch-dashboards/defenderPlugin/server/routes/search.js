"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.registerDefenderSearchRoutes = registerDefenderSearchRoutes;
var _configSchema = require("@osd/config-schema");
var _constants = require("../../common/constants");
var _mdeClient = require("../lib/mde-client");
var _graphSecurityClient = require("../lib/graph-security-client");
/*
 * Defender plugin — OpenSearch reads + Graph/MDE proxies
 */

function mapGraphErr(err) {
  if (err instanceof _graphSecurityClient.GraphApiError) {
    return {
      status: err.status >= 400 && err.status < 600 ? err.status : 502,
      body: err.message
    };
  }
  return {
    status: 502,
    body: err instanceof Error ? err.message : String(err)
  };
}
function normalizeMdeMachine(m, tenantId) {
  return {
    tenant_id: tenantId,
    machine_id: m.id,
    computer_dns_name: m.computerDnsName || '',
    os_platform: m.osPlatform || '',
    os_version: m.osVersion || '',
    last_seen: m.lastSeen || null,
    first_seen: m.firstSeen || null,
    aad_device_id: m.aadDeviceId || '',
    risk_score: m.riskScore != null ? String(m.riskScore) : '',
    exposure_level: m.exposureLevel || '',
    onboarding_status: m.onboardingStatus || m.onboardingstatus || '',
    health_status: m.healthStatus || '',
    isolation_status: m.isolationStatus || '',
    last_ip_address: m.lastIpAddress || '',
    rbac_group_name: m.rbacGroupName || ''
  };
}
function getClient(context) {
  return context.core.opensearch.client.asCurrentUser;
}
function registerDefenderSearchRoutes(router) {
  router.get({
    path: '/api/defender/health',
    validate: false
  }, async (_context, _req, res) => {
    const mde = !!(0, _mdeClient.getMdeConfig)();
    const graph = !!(0, _graphSecurityClient.getGraphSecurityConfig)();
    const smtp_host = process.env.SMTP_HOST || null;
    const smtp_user = process.env.SMTP_USER || null;
    const smtp_port = process.env.SMTP_PORT || '587';
    const otp_recipient_email = process.env.OTP_RECIPIENT_EMAIL || null;
    const smtp_configured = !!(smtp_host && otp_recipient_email);
    return res.ok({
      body: {
        ok: mde || graph,
        mde_configured: mde,
        graph_security_configured: graph,
        smtp_configured,
        otp_dev_mode: !smtp_configured,
        smtp_host,
        smtp_user,
        smtp_port,
        otp_recipient_email,
        timestamp: new Date().toISOString()
      }
    });
  });
  router.get({
    path: '/api/defender/machines',
    validate: {
      query: _configSchema.schema.object({
        size: _configSchema.schema.maybe(_configSchema.schema.number()),
        from: _configSchema.schema.maybe(_configSchema.schema.number()),
        os_platform: _configSchema.schema.maybe(_configSchema.schema.string()),
        exposure_level: _configSchema.schema.maybe(_configSchema.schema.string()),
        source: _configSchema.schema.maybe(_configSchema.schema.string())
      })
    }
  }, async (context, req, res) => {
    const q = req.query;
    if (q.source === 'live') {
      const mcfg = (0, _mdeClient.getMdeConfig)();
      if (!mcfg) {
        return res.customError({
          statusCode: 503,
          body: 'MDE not configured.'
        });
      }
      try {
        var _q$from, _q$size;
        const raw = await (0, _mdeClient.fetchAllMachinesLimited)(mcfg, 15);
        const tenantId = mcfg.tenantId;
        let rows = raw.map(m => normalizeMdeMachine(m, tenantId));
        if (q.os_platform) {
          rows = rows.filter(r => String(r.os_platform) === q.os_platform);
        }
        if (q.exposure_level) {
          rows = rows.filter(r => String(r.exposure_level) === q.exposure_level);
        }
        rows.sort((a, b) => {
          const ta = a.last_seen ? new Date(String(a.last_seen)).getTime() : 0;
          const tb = b.last_seen ? new Date(String(b.last_seen)).getTime() : 0;
          return tb - ta;
        });
        const from = (_q$from = q.from) !== null && _q$from !== void 0 ? _q$from : 0;
        const size = (_q$size = q.size) !== null && _q$size !== void 0 ? _q$size : 50;
        const slice = rows.slice(from, from + size);
        const hits = slice.map(src => ({
          _source: src,
          _id: src.machine_id
        }));
        return res.ok({
          body: {
            hits,
            total: {
              value: rows.length,
              relation: 'eq'
            },
            source: 'mde'
          }
        });
      } catch (err) {
        var _err$message;
        return res.customError({
          statusCode: (0, _mdeClient.mdeErrorStatus)(err),
          body: (_err$message = err === null || err === void 0 ? void 0 : err.message) !== null && _err$message !== void 0 ? _err$message : String(err)
        });
      }
    }
    try {
      var _hits, _response$body, _hits$hits;
      const client = getClient(context);
      const {
        size = 50,
        from = 0,
        os_platform,
        exposure_level
      } = q;
      const must = [];
      if (os_platform) must.push({
        term: {
          os_platform
        }
      });
      if (exposure_level) must.push({
        term: {
          exposure_level
        }
      });
      const response = await client.search({
        index: _constants.DEFENDER_MACHINES_INDEX,
        ignore_unavailable: true,
        body: {
          size,
          from,
          sort: [{
            last_seen: {
              order: 'desc',
              missing: '_last'
            }
          }, {
            computer_dns_name: 'asc'
          }],
          query: must.length ? {
            bool: {
              must
            }
          } : {
            match_all: {}
          }
        }
      });
      const hits = (_hits = (_response$body = response.body) === null || _response$body === void 0 ? void 0 : _response$body.hits) !== null && _hits !== void 0 ? _hits : {};
      return res.ok({
        body: {
          hits: (_hits$hits = hits.hits) !== null && _hits$hits !== void 0 ? _hits$hits : [],
          total: hits.total,
          source: 'index'
        }
      });
    } catch (err) {
      var _err$statusCode, _err$message2;
      return res.customError({
        statusCode: (_err$statusCode = err.statusCode) !== null && _err$statusCode !== void 0 ? _err$statusCode : 500,
        body: (_err$message2 = err.message) !== null && _err$message2 !== void 0 ? _err$message2 : String(err)
      });
    }
  });
  router.get({
    path: '/api/defender/machines/{id}/live',
    validate: {
      params: _configSchema.schema.object({
        id: _configSchema.schema.string()
      })
    }
  }, async (_context, _req, res) => {
    const config = (0, _mdeClient.getMdeConfig)();
    if (!config) {
      return res.customError({
        statusCode: 503,
        body: 'Defender MDE not configured (DEFENDER_TENANT_ID, DEFENDER_CLIENT_ID, DEFENDER_CLIENT_SECRET).'
      });
    }
    try {
      const id = _req.params.id;
      const data = await (0, _mdeClient.getMachine)(config, id);
      return res.ok({
        body: data
      });
    } catch (err) {
      var _err$message3;
      return res.customError({
        statusCode: (0, _mdeClient.mdeErrorStatus)(err),
        body: (_err$message3 = err === null || err === void 0 ? void 0 : err.message) !== null && _err$message3 !== void 0 ? _err$message3 : String(err)
      });
    }
  });
  const mdeMachineSub = (pathSuffix, fn) => {
    router.get({
      path: `/api/defender/machines/{id}/live/${pathSuffix}`,
      validate: {
        params: _configSchema.schema.object({
          id: _configSchema.schema.string()
        })
      }
    }, async (_context, req, res) => {
      const mcfg = (0, _mdeClient.getMdeConfig)();
      if (!mcfg) {
        return res.customError({
          statusCode: 503,
          body: 'MDE not configured.'
        });
      }
      try {
        const id = req.params.id;
        const data = await fn(mcfg, id);
        return res.ok({
          body: data
        });
      } catch (err) {
        var _err$message4;
        return res.customError({
          statusCode: (0, _mdeClient.mdeErrorStatus)(err),
          body: (_err$message4 = err === null || err === void 0 ? void 0 : err.message) !== null && _err$message4 !== void 0 ? _err$message4 : String(err)
        });
      }
    });
  };
  mdeMachineSub('recommendations', _mdeClient.getMachineRecommendations);
  mdeMachineSub('vulnerabilities', _mdeClient.getMachineVulnerabilities);
  mdeMachineSub('alerts', _mdeClient.getMachineAlerts);
  mdeMachineSub('logonusers', _mdeClient.getMachineLogonUsers);
  mdeMachineSub('software', _mdeClient.getMachineSoftware);
  const SERVICE_NAME_RE = /^(system|localservice|networkservice|defaultaccount|guest|wdagutilityaccount|krbtgt|administrator|admin|user|owner|root)$/i;
  const SERVICE_DOMAIN_RE = /^(nt authority|nt service|font driver host|window manager)$/i;
  const INTERACTIVE_RE = /interactive|remoteinteractive|cachedinteractive|unlock/i;
  const LOCAL_ADMIN_PATTERN_RE = /^[A-Za-z]{2,8}[-_]?(PC|MAC|LAPTOP|DESKTOP|WORKSTATION)$/i;
  const isServiceAccount = (u, hostname) => {
    const n = String(u && u.accountName || '').trim();
    const d = String(u && u.accountDomain || '').trim();
    if (!n) return true;
    if (n.endsWith('$')) return true;
    if (SERVICE_NAME_RE.test(n)) return true;
    if (SERVICE_DOMAIN_RE.test(d)) return true;
    if (LOCAL_ADMIN_PATTERN_RE.test(n)) return true;
    if (hostname) {
      const hn = String(hostname).toLowerCase().trim();
      const hnTrunc = hn.split('.')[0].slice(0, 15);
      const dn = d.toLowerCase();
      if (dn && (dn === hn || dn === hnTrunc)) return true;
      if (n.toLowerCase() === hn || n.toLowerCase() === hnTrunc) return true;
    }
    return false;
  };
  const pickPrimary = (logonUsers, hostname) => {
    const list = Array.isArray(logonUsers) ? logonUsers : logonUsers && logonUsers.value || [];
    const human = list.filter(u => !isServiceAccount(u, hostname));
    if (!human.length) return null;
    const sortedByLastSeen = human.slice().sort((a, b) => {
      const ta = a.lastSeen ? new Date(a.lastSeen).getTime() : 0;
      const tb = b.lastSeen ? new Date(b.lastSeen).getTime() : 0;
      return tb - ta;
    });
    const interactive = sortedByLastSeen.find(u => INTERACTIVE_RE.test(String(u.logonTypes || '')));
    const pick = interactive || sortedByLastSeen[0];
    return {
      accountName: pick.accountName,
      accountDomain: pick.accountDomain || null,
      lastSeen: pick.lastSeen || null,
      logonTypes: pick.logonTypes || null,
      isDomainAdmin: !!pick.isDomainAdmin
    };
  };
  const parseHostnameOwner = hostname => {
    if (!hostname) return null;
    const m = String(hostname).match(/^([A-Za-z][A-Za-z0-9]+)[-_]?([Mm]ac[Bb]ook|MBP|PC|MAC|MacBook|Laptop)/);
    if (m) return {
      accountName: m[1],
      inferred: true
    };
    return null;
  };
  const parseLoggedOnUsers = raw => {
    if (!raw) return [];
    if (Array.isArray(raw)) return raw;
    try {
      const parsed = JSON.parse(raw);
      return Array.isArray(parsed) ? parsed : [];
    } catch {
      return [];
    }
  };
  const pickFromHunting = (entry, hostname) => {
    const users = parseLoggedOnUsers(entry && entry.LoggedOnUsers);
    const human = users.map(u => ({
      accountName: u.UserName,
      accountDomain: u.DomainName,
      logonTypes: 'Interactive'
    })).filter(u => !isServiceAccount(u, hostname));
    if (!human.length) return null;
    const pick = human[0];
    return {
      accountName: pick.accountName,
      accountDomain: pick.accountDomain || null,
      logonTypes: 'Interactive',
      isDomainAdmin: false,
      lastSeen: entry.Timestamp || null,
      source: 'hunting'
    };
  };
  const OWNER_FILTER_VERSION = 2;
  const readOwnerCache = async (client, machineIds) => {
    if (!machineIds.length) return {};
    try {
      const r = await client.search({
        index: _constants.DEFENDER_OWNER_CACHE_INDEX,
        ignore_unavailable: true,
        body: {
          size: machineIds.length,
          query: {
            terms: {
              machine_id: machineIds
            }
          }
        }
      });
      const hits = r && r.body && r.body.hits && r.body.hits.hits || [];
      const out = {};
      const now = Date.now();
      hits.forEach(h => {
        const s = h._source || {};
        const fetchedAt = s.fetched_at ? new Date(s.fetched_at).getTime() : 0;
        const versionOk = (s.filter_version || 0) === OWNER_FILTER_VERSION;
        if (versionOk && now - fetchedAt < _constants.DEFENDER_OWNER_CACHE_TTL_MS && s.machine_id) {
          out[s.machine_id] = s.primary_user || null;
        }
      });
      return out;
    } catch {
      return {};
    }
  };
  const writeOwnerCache = async (client, tenantId, entries) => {
    const ops = [];
    const now = new Date().toISOString();
    Object.entries(entries).forEach(([machine_id, primary_user]) => {
      ops.push({
        index: {
          _index: _constants.DEFENDER_OWNER_CACHE_INDEX,
          _id: machine_id
        }
      });
      ops.push({
        machine_id,
        primary_user,
        fetched_at: now,
        tenant_id: tenantId || 'unknown',
        filter_version: OWNER_FILTER_VERSION
      });
    });
    if (!ops.length) return;
    try {
      await client.bulk({
        refresh: false,
        body: ops
      });
    } catch (e) {
      console.warn('[Defender] Failed to cache owner records:', e && e.message);
    }
  };
  const fetchAadOwnerEnrichment = async (gcfg, aadDeviceId) => {
    if (!gcfg || !aadDeviceId) return null;
    try {
      const lookup = await (0, _graphSecurityClient.graphSecurityRequest)(gcfg, 'GET', `/devices?$filter=deviceId eq '${aadDeviceId}'&$select=id,deviceId`, undefined, {
        ConsistencyLevel: 'eventual'
      });
      const aadDevice = lookup && Array.isArray(lookup.value) && lookup.value[0];
      if (!aadDevice) return null;
      const owners = await (0, _graphSecurityClient.graphSecurityRequest)(gcfg, 'GET', `/devices/${aadDevice.id}/registeredOwners?$select=id,displayName,mail,userPrincipalName,department,jobTitle`, undefined, {
        ConsistencyLevel: 'eventual'
      });
      const u = owners && Array.isArray(owners.value) && owners.value[0];
      if (!u) return null;
      return {
        displayName: u.displayName || null,
        email: u.mail || u.userPrincipalName || null,
        accountName: u.userPrincipalName ? String(u.userPrincipalName).split('@')[0] : u.displayName || null,
        department: u.department || null,
        jobTitle: u.jobTitle || null
      };
    } catch {
      return null;
    }
  };
  const fetchHuntingMostFrequent = async gcfg => {
    if (!gcfg) return {};
    const query = `DeviceInfo
| where Timestamp > ago(7d)
| summarize arg_max(Timestamp, *) by DeviceId
| project DeviceId, DeviceName, LoggedOnUsers, Timestamp
| take 5000`;
    try {
      const r = await (0, _graphSecurityClient.runHuntingQuery)(gcfg, query, 'P7D');
      const rows = r && r.results || [];
      const map = {};
      rows.forEach(row => {
        if (row && row.DeviceId) map[row.DeviceId] = row;
      });
      return map;
    } catch (e) {
      console.warn('[Defender] DeviceInfo hunting query failed:', e && e.message);
      return {};
    }
  };
  router.post({
    path: '/api/defender/primary-users',
    validate: {
      body: _configSchema.schema.object({
        machines: _configSchema.schema.arrayOf(_configSchema.schema.object({
          machine_id: _configSchema.schema.string(),
          computer_dns_name: _configSchema.schema.maybe(_configSchema.schema.string()),
          aad_device_id: _configSchema.schema.maybe(_configSchema.schema.string())
        })),
        force_refresh: _configSchema.schema.maybe(_configSchema.schema.boolean())
      })
    }
  }, async (context, req, res) => {
    const mcfg = (0, _mdeClient.getMdeConfig)();
    const gcfg = (0, _graphSecurityClient.getGraphSecurityConfig)();
    if (!mcfg && !gcfg) {
      return res.customError({
        statusCode: 503,
        body: 'Neither MDE nor Graph configured.'
      });
    }
    const client = getClient(context);
    const machines = req.body.machines || [];
    const forceRefresh = !!req.body.force_refresh;
    const result = {};
    const toFetch = [];
    const cached = forceRefresh ? {} : await readOwnerCache(client, machines.map(m => m.machine_id));
    machines.forEach(m => {
      if (cached[m.machine_id] !== undefined) {
        result[m.machine_id] = cached[m.machine_id];
      } else {
        toFetch.push(m);
      }
    });
    if (toFetch.length) {
      const huntingMap = await fetchHuntingMostFrequent(gcfg);
      const concurrency = 5;
      let cursor = 0;
      const newEntries = {};
      const next = async () => {
        while (cursor < toFetch.length) {
          const i = cursor++;
          const m = toFetch[i];
          let owner = null;
          const huntingHit = huntingMap[m.machine_id];
          if (huntingHit) owner = pickFromHunting(huntingHit, m.computer_dns_name);
          if (!owner && mcfg) {
            try {
              const data = await (0, _mdeClient.getMachineLogonUsers)(mcfg, m.machine_id);
              const pick = pickPrimary(data, m.computer_dns_name);
              if (pick) owner = {
                ...pick,
                source: 'logon'
              };
            } catch {}
          }
          if (m.aad_device_id && gcfg) {
            const aadOwner = await fetchAadOwnerEnrichment(gcfg, m.aad_device_id);
            if (aadOwner) {
              owner = {
                accountName: aadOwner.accountName || owner && owner.accountName || null,
                accountDomain: owner && owner.accountDomain || null,
                displayName: aadOwner.displayName,
                email: aadOwner.email,
                department: aadOwner.department,
                jobTitle: aadOwner.jobTitle,
                lastSeen: owner && owner.lastSeen,
                logonTypes: owner && owner.logonTypes,
                isDomainAdmin: owner && owner.isDomainAdmin,
                source: 'aad'
              };
            }
          }
          if (!owner) {
            const fb = parseHostnameOwner(m.computer_dns_name);
            if (fb) owner = {
              ...fb,
              source: 'hostname'
            };
          }
          newEntries[m.machine_id] = owner;
          result[m.machine_id] = owner;
        }
      };
      await Promise.all(Array.from({
        length: Math.min(concurrency, toFetch.length)
      }, next));
      const tenantId = mcfg ? mcfg.tenantId : gcfg ? gcfg.tenantId : 'unknown';
      void writeOwnerCache(client, tenantId, newEntries);
    }
    const sources = {};
    Object.values(result).forEach(v => {
      const s = v && v.source || 'none';
      sources[s] = (sources[s] || 0) + 1;
    });
    return res.ok({
      body: {
        value: result,
        meta: {
          total: machines.length,
          from_cache: machines.length - toFetch.length,
          fetched: toFetch.length,
          sources
        }
      }
    });
  });
  router.get({
    path: '/api/defender/vulnerabilities/aggregations',
    validate: false
  }, async (_context, _req, res) => {
    const mcfg = (0, _mdeClient.getMdeConfig)();
    if (!mcfg) {
      return res.customError({
        statusCode: 503,
        body: 'MDE not configured.'
      });
    }
    try {
      const data = await (0, _mdeClient.listOrgVulnerabilities)(mcfg, 1000);
      const vulns = data && data.value || [];
      const sevMap = {};
      vulns.forEach(v => {
        const s = (v.severity || 'unknown').toString();
        sevMap[s] = (sevMap[s] || 0) + 1;
      });
      const by_severity = Object.entries(sevMap).map(([severity, count]) => ({
        severity,
        count
      }));
      const top_cves_by_spread = vulns.filter(v => (v.exposedMachines || 0) > 0).sort((a, b) => (b.exposedMachines || 0) - (a.exposedMachines || 0)).slice(0, 10).map(v => ({
        id: v.id,
        name: v.name || v.id,
        severity: v.severity,
        cvssV3: v.cvssV3,
        exposedMachines: v.exposedMachines,
        publicExploit: !!v.publicExploit,
        publishedOn: v.publishedOn
      }));
      const kpis = {
        total: vulns.length,
        critical: vulns.filter(v => (v.severity || '').toLowerCase() === 'critical').length,
        high: vulns.filter(v => (v.severity || '').toLowerCase() === 'high').length,
        with_exploit: vulns.filter(v => v.publicExploit).length,
        affected_hosts_total: vulns.reduce((acc, v) => acc + (v.exposedMachines || 0), 0)
      };
      let top_hosts_by_count = [];
      const gcfg = (0, _graphSecurityClient.getGraphSecurityConfig)();
      if (gcfg) {
        try {
          const huntQuery = 'DeviceTvmSoftwareVulnerabilities | summarize CveCount = dcount(CveId) by DeviceId, DeviceName | top 10 by CveCount';
          const r = await (0, _graphSecurityClient.runHuntingQuery)(gcfg, huntQuery, 'P7D');
          top_hosts_by_count = (r && r.results || []).map(h => ({
            machine_id: h.DeviceId,
            computer_dns_name: h.DeviceName,
            cve_count: h.CveCount
          }));
        } catch (e) {
          console.warn('[Defender] Top-hosts hunting query failed:', e && e.message);
        }
      }
      return res.ok({
        body: {
          kpis,
          by_severity,
          top_cves_by_spread,
          top_hosts_by_count
        }
      });
    } catch (err) {
      return res.customError({
        statusCode: (0, _mdeClient.mdeErrorStatus)(err),
        body: err && err.message ? err.message : String(err)
      });
    }
  });
  router.get({
    path: '/api/defender/vulnerabilities/{cveId}/machines',
    validate: {
      params: _configSchema.schema.object({
        cveId: _configSchema.schema.string()
      })
    }
  }, async (_context, req, res) => {
    const mcfg = (0, _mdeClient.getMdeConfig)();
    if (!mcfg) {
      return res.customError({
        statusCode: 503,
        body: 'MDE not configured.'
      });
    }
    try {
      const data = await (0, _mdeClient.mdeRequest)(mcfg, 'GET', `/api/vulnerabilities/${encodeURIComponent(req.params.cveId)}/machineReferences`);
      return res.ok({
        body: data
      });
    } catch (err) {
      return res.customError({
        statusCode: (0, _mdeClient.mdeErrorStatus)(err),
        body: err && err.message ? err.message : String(err)
      });
    }
  });
  router.get({
    path: '/api/defender/mde/vulnerabilities',
    validate: {
      query: _configSchema.schema.object({
        top: _configSchema.schema.maybe(_configSchema.schema.number())
      })
    }
  }, async (_context, req, res) => {
    const mcfg = (0, _mdeClient.getMdeConfig)();
    if (!mcfg) return res.customError({
      statusCode: 503,
      body: 'MDE not configured.'
    });
    try {
      var _top;
      const top = (_top = req.query.top) !== null && _top !== void 0 ? _top : 200;
      const data = await (0, _mdeClient.listOrgVulnerabilities)(mcfg, top);
      return res.ok({
        body: data
      });
    } catch (err) {
      var _err$message5;
      return res.customError({
        statusCode: (0, _mdeClient.mdeErrorStatus)(err),
        body: (_err$message5 = err === null || err === void 0 ? void 0 : err.message) !== null && _err$message5 !== void 0 ? _err$message5 : String(err)
      });
    }
  });
  router.get({
    path: '/api/defender/mde/alerts-legacy',
    validate: {
      query: _configSchema.schema.object({
        top: _configSchema.schema.maybe(_configSchema.schema.number())
      })
    }
  }, async (_context, req, res) => {
    const mcfg = (0, _mdeClient.getMdeConfig)();
    if (!mcfg) return res.customError({
      statusCode: 503,
      body: 'MDE not configured.'
    });
    try {
      var _top2;
      const top = (_top2 = req.query.top) !== null && _top2 !== void 0 ? _top2 : 100;
      const data = await (0, _mdeClient.listLegacyAlerts)(mcfg, top);
      return res.ok({
        body: data
      });
    } catch (err) {
      var _err$message6;
      return res.customError({
        statusCode: (0, _mdeClient.mdeErrorStatus)(err),
        body: (_err$message6 = err === null || err === void 0 ? void 0 : err.message) !== null && _err$message6 !== void 0 ? _err$message6 : String(err)
      });
    }
  });
  router.get({
    path: '/api/defender/mde/machineactions',
    validate: {
      query: _configSchema.schema.object({
        top: _configSchema.schema.maybe(_configSchema.schema.number())
      })
    }
  }, async (_context, req, res) => {
    const mcfg = (0, _mdeClient.getMdeConfig)();
    if (!mcfg) return res.customError({
      statusCode: 503,
      body: 'MDE not configured.'
    });
    try {
      var _top3;
      const top = (_top3 = req.query.top) !== null && _top3 !== void 0 ? _top3 : 100;
      const data = await (0, _mdeClient.listMachineActions)(mcfg, top);
      return res.ok({
        body: data
      });
    } catch (err) {
      var _err$message7;
      return res.customError({
        statusCode: (0, _mdeClient.mdeErrorStatus)(err),
        body: (_err$message7 = err === null || err === void 0 ? void 0 : err.message) !== null && _err$message7 !== void 0 ? _err$message7 : String(err)
      });
    }
  });
  router.get({
    path: '/api/defender/mde/machineactions/{actionId}/package-uri',
    validate: {
      params: _configSchema.schema.object({
        actionId: _configSchema.schema.string()
      })
    }
  }, async (_context, req, res) => {
    const mcfg = (0, _mdeClient.getMdeConfig)();
    if (!mcfg) return res.customError({
      statusCode: 503,
      body: 'MDE not configured.'
    });
    try {
      const actionId = req.params.actionId;
      const data = await (0, _mdeClient.getMachineActionPackageUri)(mcfg, actionId);
      return res.ok({
        body: data
      });
    } catch (err) {
      var _err$message8;
      return res.customError({
        statusCode: (0, _mdeClient.mdeErrorStatus)(err),
        body: (_err$message8 = err === null || err === void 0 ? void 0 : err.message) !== null && _err$message8 !== void 0 ? _err$message8 : String(err)
      });
    }
  });
  router.get({
    path: '/api/defender/overview',
    validate: false
  }, async (context, _req, res) => {
    try {
      var _hits2, _machinesRes$body, _aggregations, _machinesRes$body2, _hitsBody$hits, _hitsBody$total$value, _hitsBody$total, _hitsBody$total2, _aggs$by_os$buckets, _aggs$by_os, _aggs$by_exposure$buc, _aggs$by_exposure, _aggs$by_health$bucke, _aggs$by_health, _aggs$by_risk$buckets, _aggs$by_risk;
      const client = getClient(context);
      const staleDate = new Date(Date.now() - 7 * 24 * 60 * 60 * 1000).toISOString();
      const machinesRes = await client.search({
        index: _constants.DEFENDER_MACHINES_INDEX,
        ignore_unavailable: true,
        body: {
          size: 8,
          track_total_hits: true,
          sort: [{
            last_seen: {
              order: 'desc',
              missing: '_last'
            }
          }],
          query: {
            match_all: {}
          },
          aggs: {
            by_os: {
              terms: {
                field: 'os_platform',
                size: 15
              }
            },
            by_exposure: {
              terms: {
                field: 'exposure_level',
                size: 10
              }
            },
            by_health: {
              terms: {
                field: 'health_status',
                size: 10
              }
            },
            by_risk: {
              terms: {
                field: 'risk_score',
                size: 15
              }
            }
          }
        }
      });
      let incidentsCount = 0;
      let alertsCount = 0;
      let vulnCount = 0;
      let linkedAgents = 0;
      let staleCount = 0;
      try {
        var _count, _ic$body, _count2, _ac$body, _count3, _vc$body, _count4, _idRes$body, _ref, _hits$total$value, _staleRes$body, _staleRes$body2;
        const [ic, ac, vc, idRes, staleRes] = await Promise.all([client.count({
          index: _constants.DEFENDER_INCIDENTS_INDEX,
          ignore_unavailable: true
        }), client.count({
          index: _constants.DEFENDER_ALERTS_INDEX,
          ignore_unavailable: true
        }), client.count({
          index: _constants.DEFENDER_VULNERABILITIES_INDEX,
          ignore_unavailable: true
        }), client.count({
          index: _constants.DEFENDER_MACHINE_IDENTITY_INDEX,
          ignore_unavailable: true
        }), client.search({
          index: _constants.DEFENDER_MACHINES_INDEX,
          ignore_unavailable: true,
          body: {
            size: 0,
            query: {
              bool: {
                filter: [{
                  range: {
                    last_seen: {
                      lt: staleDate
                    }
                  }
                }]
              }
            },
            track_total_hits: true
          }
        })]);
        incidentsCount = (_count = (_ic$body = ic.body) === null || _ic$body === void 0 ? void 0 : _ic$body.count) !== null && _count !== void 0 ? _count : 0;
        alertsCount = (_count2 = (_ac$body = ac.body) === null || _ac$body === void 0 ? void 0 : _ac$body.count) !== null && _count2 !== void 0 ? _count2 : 0;
        vulnCount = (_count3 = (_vc$body = vc.body) === null || _vc$body === void 0 ? void 0 : _vc$body.count) !== null && _count3 !== void 0 ? _count3 : 0;
        linkedAgents = (_count4 = (_idRes$body = idRes.body) === null || _idRes$body === void 0 ? void 0 : _idRes$body.count) !== null && _count4 !== void 0 ? _count4 : 0;
        staleCount = (_ref = (_hits$total$value = (_staleRes$body = staleRes.body) === null || _staleRes$body === void 0 || (_staleRes$body = _staleRes$body.hits) === null || _staleRes$body === void 0 || (_staleRes$body = _staleRes$body.total) === null || _staleRes$body === void 0 ? void 0 : _staleRes$body.value) !== null && _hits$total$value !== void 0 ? _hits$total$value : (_staleRes$body2 = staleRes.body) === null || _staleRes$body2 === void 0 || (_staleRes$body2 = _staleRes$body2.hits) === null || _staleRes$body2 === void 0 ? void 0 : _staleRes$body2.total) !== null && _ref !== void 0 ? _ref : 0;
      } catch {
        /* optional indices */
      }
      const hitsBody = (_hits2 = (_machinesRes$body = machinesRes.body) === null || _machinesRes$body === void 0 ? void 0 : _machinesRes$body.hits) !== null && _hits2 !== void 0 ? _hits2 : {};
      const aggs = (_aggregations = (_machinesRes$body2 = machinesRes.body) === null || _machinesRes$body2 === void 0 ? void 0 : _machinesRes$body2.aggregations) !== null && _aggregations !== void 0 ? _aggregations : {};
      const recent_machines = ((_hitsBody$hits = hitsBody.hits) !== null && _hitsBody$hits !== void 0 ? _hitsBody$hits : []).map(h => h._source).filter(Boolean);
      const totalMachines = typeof hitsBody.total === 'object' ? (_hitsBody$total$value = (_hitsBody$total = hitsBody.total) === null || _hitsBody$total === void 0 ? void 0 : _hitsBody$total.value) !== null && _hitsBody$total$value !== void 0 ? _hitsBody$total$value : 0 : (_hitsBody$total2 = hitsBody.total) !== null && _hitsBody$total2 !== void 0 ? _hitsBody$total2 : recent_machines.length;
      let byOsBuckets = (_aggs$by_os$buckets = (_aggs$by_os = aggs.by_os) === null || _aggs$by_os === void 0 ? void 0 : _aggs$by_os.buckets) !== null && _aggs$by_os$buckets !== void 0 ? _aggs$by_os$buckets : [];
      let byExposureBuckets = (_aggs$by_exposure$buc = (_aggs$by_exposure = aggs.by_exposure) === null || _aggs$by_exposure === void 0 ? void 0 : _aggs$by_exposure.buckets) !== null && _aggs$by_exposure$buc !== void 0 ? _aggs$by_exposure$buc : [];
      let byHealthBuckets = (_aggs$by_health$bucke = (_aggs$by_health = aggs.by_health) === null || _aggs$by_health === void 0 ? void 0 : _aggs$by_health.buckets) !== null && _aggs$by_health$bucke !== void 0 ? _aggs$by_health$bucke : [];
      let byRiskBuckets = (_aggs$by_risk$buckets = (_aggs$by_risk = aggs.by_risk) === null || _aggs$by_risk === void 0 ? void 0 : _aggs$by_risk.buckets) !== null && _aggs$by_risk$buckets !== void 0 ? _aggs$by_risk$buckets : [];
      let recentList = recent_machines;
      let total = totalMachines;
      let dataSource = 'index';
      const mcfg = (0, _mdeClient.getMdeConfig)();
      if (total === 0 && mcfg) {
        try {
          const raw = await (0, _mdeClient.fetchAllMachinesLimited)(mcfg, 10);
          const tid = mcfg.tenantId;
          const normalized = raw.map(m => normalizeMdeMachine(m, tid));
          if (normalized.length > 0) {
            dataSource = 'mde';
            total = normalized.length;
            recentList = normalized.slice().sort((a, b) => {
              const ta = a.last_seen ? new Date(String(a.last_seen)).getTime() : 0;
              const tb = b.last_seen ? new Date(String(b.last_seen)).getTime() : 0;
              return tb - ta;
            }).slice(0, 10);
            const osMap = {};
            const exMap = {};
            const healthMap = {};
            const riskMap = {};
            normalized.forEach(r => {
              const os = String(r.os_platform || 'Unknown');
              osMap[os] = (osMap[os] || 0) + 1;
              const ex = String(r.exposure_level || 'unknown');
              exMap[ex] = (exMap[ex] || 0) + 1;
              const hs = String(r.health_status || 'unknown');
              healthMap[hs] = (healthMap[hs] || 0) + 1;
              const rs = String(r.risk_score || 'unknown');
              riskMap[rs] = (riskMap[rs] || 0) + 1;
            });
            byOsBuckets = Object.entries(osMap).map(([key, doc_count]) => ({
              key,
              doc_count
            }));
            byExposureBuckets = Object.entries(exMap).map(([key, doc_count]) => ({
              key,
              doc_count
            }));
            byHealthBuckets = Object.entries(healthMap).map(([key, doc_count]) => ({
              key,
              doc_count
            }));
            byRiskBuckets = Object.entries(riskMap).map(([key, doc_count]) => ({
              key,
              doc_count
            }));
            staleCount = normalized.filter(r => !r.last_seen || new Date(String(r.last_seen)) < new Date(staleDate)).length;
          }
        } catch {
          /* keep index empty state */
        }
      }
      let liveIncidentsCount = null;
      let liveAlertsCount = null;
      let graphError = null;
      const gcfg = (0, _graphSecurityClient.getGraphSecurityConfig)();
      if (gcfg) {
        try {
          liveIncidentsCount = await (0, _graphSecurityClient.countSecurityCollection)(gcfg, 'incidents');
        } catch (e) {
          graphError = mapGraphErr(e).body;
          liveIncidentsCount = null;
        }
        try {
          liveAlertsCount = await (0, _graphSecurityClient.countSecurityCollection)(gcfg, 'alerts_v2');
        } catch (e) {
          if (!graphError) graphError = mapGraphErr(e).body;
          liveAlertsCount = null;
        }
      }
      return res.ok({
        body: {
          total_machines: total,
          by_os: byOsBuckets,
          by_exposure: byExposureBuckets,
          by_health: byHealthBuckets,
          by_risk: byRiskBuckets,
          recent_machines: recentList,
          incidents_index_count: incidentsCount,
          alerts_index_count: alertsCount,
          vulnerabilities_index_count: vulnCount,
          linked_agents_count: linkedAgents,
          stale_machines_count: staleCount,
          graph_incidents_live_count: liveIncidentsCount,
          graph_alerts_live_count: liveAlertsCount,
          graph_error_hint: graphError,
          data_source: dataSource
        }
      });
    } catch (err) {
      var _err$statusCode2, _err$message9;
      return res.customError({
        statusCode: (_err$statusCode2 = err.statusCode) !== null && _err$statusCode2 !== void 0 ? _err$statusCode2 : 500,
        body: (_err$message9 = err.message) !== null && _err$message9 !== void 0 ? _err$message9 : String(err)
      });
    }
  });
  router.get({
    path: '/api/defender/vulnerabilities',
    validate: {
      query: _configSchema.schema.object({
        size: _configSchema.schema.maybe(_configSchema.schema.number()),
        from: _configSchema.schema.maybe(_configSchema.schema.number()),
        source: _configSchema.schema.maybe(_configSchema.schema.string())
      })
    }
  }, async (context, req, res) => {
    const q = req.query;
    if (q.source === 'mde') {
      const mcfg = (0, _mdeClient.getMdeConfig)();
      if (!mcfg) return res.customError({
        statusCode: 503,
        body: 'MDE not configured.'
      });
      try {
        var _q$size2, _data$value, _q$from2, _q$size3;
        const data = await (0, _mdeClient.listOrgVulnerabilities)(mcfg, (_q$size2 = q.size) !== null && _q$size2 !== void 0 ? _q$size2 : 200);
        const rows = (_data$value = data === null || data === void 0 ? void 0 : data.value) !== null && _data$value !== void 0 ? _data$value : [];
        const from = (_q$from2 = q.from) !== null && _q$from2 !== void 0 ? _q$from2 : 0;
        const size = (_q$size3 = q.size) !== null && _q$size3 !== void 0 ? _q$size3 : 50;
        const slice = rows.slice(from, from + size);
        const hits = slice.map((row, i) => {
          var _ref2, _row$id;
          return {
            _id: String((_ref2 = (_row$id = row.id) !== null && _row$id !== void 0 ? _row$id : row.cveId) !== null && _ref2 !== void 0 ? _ref2 : i),
            _source: typeof row === 'object' ? row : {
              raw: row
            }
          };
        });
        return res.ok({
          body: {
            hits,
            total: {
              value: rows.length,
              relation: 'eq'
            },
            source: 'mde'
          }
        });
      } catch (err) {
        var _err$message10;
        return res.customError({
          statusCode: (0, _mdeClient.mdeErrorStatus)(err),
          body: (_err$message10 = err === null || err === void 0 ? void 0 : err.message) !== null && _err$message10 !== void 0 ? _err$message10 : String(err)
        });
      }
    }
    try {
      var _hits3, _response$body2, _hits$hits2;
      const client = getClient(context);
      const {
        size = 50,
        from = 0
      } = q;
      const response = await client.search({
        index: _constants.DEFENDER_VULNERABILITIES_INDEX,
        ignore_unavailable: true,
        body: {
          size,
          from,
          sort: [{
            sync_ts: {
              order: 'desc'
            }
          }],
          query: {
            match_all: {}
          }
        }
      });
      const hits = (_hits3 = (_response$body2 = response.body) === null || _response$body2 === void 0 ? void 0 : _response$body2.hits) !== null && _hits3 !== void 0 ? _hits3 : {};
      return res.ok({
        body: {
          hits: (_hits$hits2 = hits.hits) !== null && _hits$hits2 !== void 0 ? _hits$hits2 : [],
          total: hits.total,
          source: 'index'
        }
      });
    } catch (err) {
      var _err$statusCode3, _err$message11;
      return res.customError({
        statusCode: (_err$statusCode3 = err.statusCode) !== null && _err$statusCode3 !== void 0 ? _err$statusCode3 : 500,
        body: (_err$message11 = err.message) !== null && _err$message11 !== void 0 ? _err$message11 : String(err)
      });
    }
  });
  router.get({
    path: '/api/defender/incidents/live',
    validate: {
      query: _configSchema.schema.object({
        top: _configSchema.schema.maybe(_configSchema.schema.number())
      })
    }
  }, async (_context, req, res) => {
    const config = (0, _graphSecurityClient.getGraphSecurityConfig)();
    if (!config) {
      return res.customError({
        statusCode: 503,
        body: 'Graph security not configured.'
      });
    }
    try {
      var _top4;
      const top = (_top4 = req.query.top) !== null && _top4 !== void 0 ? _top4 : 25;
      const data = await (0, _graphSecurityClient.listIncidents)(config, top);
      return res.ok({
        body: data
      });
    } catch (err) {
      const {
        status,
        body
      } = mapGraphErr(err);
      return res.customError({
        statusCode: status,
        body
      });
    }
  });
  router.get({
    path: '/api/defender/incidents/{id}',
    validate: {
      params: _configSchema.schema.object({
        id: _configSchema.schema.string()
      })
    }
  }, async (_context, req, res) => {
    const config = (0, _graphSecurityClient.getGraphSecurityConfig)();
    if (!config) {
      return res.customError({
        statusCode: 503,
        body: 'Graph security not configured.'
      });
    }
    try {
      const data = await (0, _graphSecurityClient.getIncident)(config, req.params.id);
      return res.ok({
        body: data
      });
    } catch (err) {
      const {
        status,
        body
      } = mapGraphErr(err);
      return res.customError({
        statusCode: status,
        body
      });
    }
  });
  router.get({
    path: '/api/defender/alerts/{id}',
    validate: {
      params: _configSchema.schema.object({
        id: _configSchema.schema.string()
      })
    }
  }, async (_context, req, res) => {
    const config = (0, _graphSecurityClient.getGraphSecurityConfig)();
    if (!config) {
      return res.customError({
        statusCode: 503,
        body: 'Graph security not configured.'
      });
    }
    try {
      const data = await (0, _graphSecurityClient.graphSecurityRequest)(config, 'GET', `/security/alerts_v2/${encodeURIComponent(req.params.id)}`, undefined, {
        ConsistencyLevel: 'eventual'
      });
      return res.ok({
        body: data
      });
    } catch (err) {
      const {
        status,
        body
      } = mapGraphErr(err);
      return res.customError({
        statusCode: status,
        body
      });
    }
  });
  router.get({
    path: '/api/defender/alerts/live',
    validate: {
      query: _configSchema.schema.object({
        top: _configSchema.schema.maybe(_configSchema.schema.number())
      })
    }
  }, async (_context, req, res) => {
    const config = (0, _graphSecurityClient.getGraphSecurityConfig)();
    if (!config) {
      return res.customError({
        statusCode: 503,
        body: 'Graph security not configured.'
      });
    }
    try {
      var _top5;
      const top = (_top5 = req.query.top) !== null && _top5 !== void 0 ? _top5 : 25;
      const data = await (0, _graphSecurityClient.listAlertsV2)(config, top);
      return res.ok({
        body: data
      });
    } catch (err) {
      const {
        status,
        body
      } = mapGraphErr(err);
      return res.customError({
        statusCode: status,
        body
      });
    }
  });
  router.post({
    path: '/api/defender/hunting',
    validate: {
      body: _configSchema.schema.object({
        query: _configSchema.schema.string(),
        timespan: _configSchema.schema.maybe(_configSchema.schema.string())
      })
    }
  }, async (_context, req, res) => {
    const config = (0, _graphSecurityClient.getGraphSecurityConfig)();
    if (!config) {
      return res.customError({
        statusCode: 503,
        body: 'Graph security not configured.'
      });
    }
    try {
      const {
        query,
        timespan
      } = req.body;
      const started = Date.now();
      const data = await (0, _graphSecurityClient.runHuntingQuery)(config, query, timespan || 'P7D');
      const rowCount = Array.isArray(data === null || data === void 0 ? void 0 : data.results) ? data.results.length : 0;
      return res.ok({
        body: {
          ...(data || {}),
          executionTimeMs: Date.now() - started,
          rowCount
        }
      });
    } catch (err) {
      const {
        status,
        body
      } = mapGraphErr(err);
      return res.customError({
        statusCode: status,
        body
      });
    }
  });
  router.get({
    path: '/api/defender/indicators/live',
    validate: {
      query: _configSchema.schema.object({
        top: _configSchema.schema.maybe(_configSchema.schema.number())
      })
    }
  }, async (_context, req, res) => {
    const config = (0, _mdeClient.getMdeConfig)();
    if (!config) {
      return res.customError({
        statusCode: 503,
        body: 'MDE not configured.'
      });
    }
    try {
      var _top6;
      const top = (_top6 = req.query.top) !== null && _top6 !== void 0 ? _top6 : 100;
      const data = await (0, _mdeClient.listIndicators)(config, top);
      return res.ok({
        body: data
      });
    } catch (err) {
      var _err$message12;
      return res.customError({
        statusCode: (0, _mdeClient.mdeErrorStatus)(err),
        body: (_err$message12 = err === null || err === void 0 ? void 0 : err.message) !== null && _err$message12 !== void 0 ? _err$message12 : String(err)
      });
    }
  });
  router.get({
    path: '/api/defender/audit-log',
    validate: {
      query: _configSchema.schema.object({
        size: _configSchema.schema.maybe(_configSchema.schema.number())
      })
    }
  }, async (context, req, res) => {
    try {
      var _size, _hits$hits3, _response$body3;
      const client = getClient(context);
      const size = (_size = req.query.size) !== null && _size !== void 0 ? _size : 50;
      const response = await client.search({
        index: _constants.DEFENDER_AUDIT_LOG_INDEX,
        ignore_unavailable: true,
        body: {
          size,
          sort: [{
            timestamp: {
              order: 'desc'
            }
          }],
          query: {
            match_all: {}
          }
        }
      });
      const hits = (_hits$hits3 = (_response$body3 = response.body) === null || _response$body3 === void 0 || (_response$body3 = _response$body3.hits) === null || _response$body3 === void 0 ? void 0 : _response$body3.hits) !== null && _hits$hits3 !== void 0 ? _hits$hits3 : [];
      return res.ok({
        body: {
          entries: hits.map(h => h._source)
        }
      });
    } catch (err) {
      var _err$statusCode4, _err$message13;
      return res.customError({
        statusCode: (_err$statusCode4 = err.statusCode) !== null && _err$statusCode4 !== void 0 ? _err$statusCode4 : 500,
        body: (_err$message13 = err.message) !== null && _err$message13 !== void 0 ? _err$message13 : String(err)
      });
    }
  });
  router.get({
    path: '/api/defender/identity',
    validate: {
      query: _configSchema.schema.object({
        size: _configSchema.schema.maybe(_configSchema.schema.number())
      })
    }
  }, async (context, req, res) => {
    try {
      const client = getClient(context);
      const size = req.query.size != null ? req.query.size : 1000;
      const r = await client.search({
        index: _constants.DEFENDER_MACHINE_IDENTITY_INDEX,
        ignore_unavailable: true,
        body: {
          size,
          query: {
            match_all: {}
          }
        }
      });
      const hits = r && r.body && r.body.hits && r.body.hits.hits || [];
      return res.ok({
        body: {
          value: hits.map(h => ({
            _id: h._id,
            ...(h._source || {})
          }))
        }
      });
    } catch (err) {
      return res.customError({
        statusCode: err.statusCode || 500,
        body: err.message || String(err)
      });
    }
  });
  router.post({
    path: '/api/defender/identity',
    validate: {
      body: _configSchema.schema.object({
        wazuh_agent_id: _configSchema.schema.string(),
        wazuh_agent_name: _configSchema.schema.maybe(_configSchema.schema.string()),
        defender_machine_id: _configSchema.schema.string(),
        computer_dns_name: _configSchema.schema.maybe(_configSchema.schema.string()),
        aad_device_id: _configSchema.schema.maybe(_configSchema.schema.string()),
        source: _configSchema.schema.maybe(_configSchema.schema.string())
      })
    }
  }, async (context, req, res) => {
    try {
      const client = getClient(context);
      const body = req.body;
      const mcfg = (0, _mdeClient.getMdeConfig)();
      const tenant_id = mcfg ? mcfg.tenantId : 'unknown';
      const allowedSources = ['aad_device_id', 'hostname_match', 'machine_id_match', 'manual'];
      const source = allowedSources.indexOf(body.source) >= 0 ? body.source : 'manual';
      const doc = {
        wazuh_agent_id: body.wazuh_agent_id.trim(),
        wazuh_agent_name: (body.wazuh_agent_name || '').trim(),
        defender_machine_id: body.defender_machine_id,
        computer_dns_name: body.computer_dns_name || '',
        aad_device_id: body.aad_device_id || '',
        linked_at: new Date().toISOString(),
        tenant_id,
        source
      };
      if (!doc.wazuh_agent_id) {
        return res.customError({
          statusCode: 400,
          body: 'wazuh_agent_id is required'
        });
      }
      await client.index({
        index: _constants.DEFENDER_MACHINE_IDENTITY_INDEX,
        id: doc.wazuh_agent_id,
        refresh: 'true',
        body: doc
      });
      return res.ok({
        body: {
          success: true,
          doc
        }
      });
    } catch (err) {
      return res.customError({
        statusCode: err.statusCode || 500,
        body: err.message || String(err)
      });
    }
  });
  router.delete({
    path: '/api/defender/identity/{wazuh_agent_id}',
    validate: {
      params: _configSchema.schema.object({
        wazuh_agent_id: _configSchema.schema.string()
      })
    }
  }, async (context, req, res) => {
    try {
      const client = getClient(context);
      try {
        await client.delete({
          index: _constants.DEFENDER_MACHINE_IDENTITY_INDEX,
          id: req.params.wazuh_agent_id,
          refresh: 'true'
        });
      } catch (e) {
        if (e && e.statusCode === 404) {
          return res.ok({
            body: {
              success: true,
              message: 'not_found'
            }
          });
        }
        throw e;
      }
      return res.ok({
        body: {
          success: true
        }
      });
    } catch (err) {
      return res.customError({
        statusCode: err.statusCode || 500,
        body: err.message || String(err)
      });
    }
  });
  router.post({
    path: '/api/defender/alerts_enrichment',
    validate: {
      body: _configSchema.schema.object({
        size: _configSchema.schema.maybe(_configSchema.schema.number()),
        from: _configSchema.schema.maybe(_configSchema.schema.number()),
        time_from: _configSchema.schema.maybe(_configSchema.schema.string()),
        time_to: _configSchema.schema.maybe(_configSchema.schema.string()),
        defender_correlated_only: _configSchema.schema.maybe(_configSchema.schema.boolean())
      })
    }
  }, async (context, req, res) => {
    try {
      var _hits$hits5, _alertsResponse$body, _ref3, _hits$total$value2, _countResponse$body, _countResponse$body2;
      const client = getClient(context);
      const {
        size = 25,
        from = 0,
        time_from,
        time_to,
        defender_correlated_only = true
      } = req.body;
      const now = new Date();
      const defaultTo = now.toISOString();
      const defaultFrom = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000).toISOString();
      const timeGte = time_from || defaultFrom;
      const timeLte = time_to || defaultTo;
      const timeRangeFilter = {
        range: {
          timestamp: {
            gte: timeGte,
            lte: timeLte
          }
        }
      };
      let agentIdsToQuery = null;
      const agentToDefender = {};
      if (defender_correlated_only) {
        var _hits$hits4, _identityRes$body;
        const identityRes = await client.search({
          index: _constants.DEFENDER_MACHINE_IDENTITY_INDEX,
          ignore_unavailable: true,
          body: {
            size: 1000,
            _source: ['wazuh_agent_id', 'defender_machine_id', 'computer_dns_name'],
            query: {
              match_all: {}
            }
          }
        });
        const identityHits = (_hits$hits4 = (_identityRes$body = identityRes.body) === null || _identityRes$body === void 0 || (_identityRes$body = _identityRes$body.hits) === null || _identityRes$body === void 0 ? void 0 : _identityRes$body.hits) !== null && _hits$hits4 !== void 0 ? _hits$hits4 : [];
        agentIdsToQuery = identityHits.map(h => {
          var _h$_source;
          return (_h$_source = h._source) === null || _h$_source === void 0 ? void 0 : _h$_source.wazuh_agent_id;
        }).filter(id => id && id !== '000');
        if (agentIdsToQuery.length === 0) {
          return res.ok({
            body: {
              alerts: [],
              enrichments: {},
              total: 0,
              identity_count: 0
            }
          });
        }
        identityHits.forEach(h => {
          const s = h._source;
          if (s !== null && s !== void 0 && s.wazuh_agent_id) agentToDefender[s.wazuh_agent_id] = s.defender_machine_id;
        });
      }
      const must = [timeRangeFilter];
      must.push({
        bool: {
          must_not: [{
            term: {
              'agent.id': '000'
            }
          }]
        }
      });
      if (agentIdsToQuery && agentIdsToQuery.length > 0) {
        must.push({
          terms: {
            'agent.id': agentIdsToQuery
          }
        });
      }
      const alertsBody = {
        from,
        size,
        sort: [{
          timestamp: {
            order: 'desc'
          }
        }],
        _source: ['agent.id', 'agent.name', 'rule.description', 'rule.level', 'timestamp'],
        query: {
          bool: {
            must
          }
        }
      };
      const [alertsResponse, countResponse] = await Promise.all([client.search({
        index: _constants.WAZUH_ALERTS_PATTERN,
        ignore_unavailable: true,
        body: alertsBody
      }), client.search({
        index: _constants.WAZUH_ALERTS_PATTERN,
        ignore_unavailable: true,
        body: {
          size: 0,
          query: alertsBody.query,
          track_total_hits: true
        }
      })]);
      const alertHits = (_hits$hits5 = (_alertsResponse$body = alertsResponse.body) === null || _alertsResponse$body === void 0 || (_alertsResponse$body = _alertsResponse$body.hits) === null || _alertsResponse$body === void 0 ? void 0 : _alertsResponse$body.hits) !== null && _hits$hits5 !== void 0 ? _hits$hits5 : [];
      const total = (_ref3 = (_hits$total$value2 = (_countResponse$body = countResponse.body) === null || _countResponse$body === void 0 || (_countResponse$body = _countResponse$body.hits) === null || _countResponse$body === void 0 || (_countResponse$body = _countResponse$body.total) === null || _countResponse$body === void 0 ? void 0 : _countResponse$body.value) !== null && _hits$total$value2 !== void 0 ? _hits$total$value2 : (_countResponse$body2 = countResponse.body) === null || _countResponse$body2 === void 0 || (_countResponse$body2 = _countResponse$body2.hits) === null || _countResponse$body2 === void 0 ? void 0 : _countResponse$body2.total) !== null && _ref3 !== void 0 ? _ref3 : alertHits.length;
      const enrichments = {};
      alertHits.forEach(h => {
        var _h$_source2;
        const aid = (_h$_source2 = h._source) === null || _h$_source2 === void 0 || (_h$_source2 = _h$_source2.agent) === null || _h$_source2 === void 0 ? void 0 : _h$_source2.id;
        if (aid && agentToDefender[aid]) {
          enrichments[h._id] = {
            defender_machine_id: agentToDefender[aid]
          };
        }
      });
      return res.ok({
        body: {
          alerts: alertHits.map(h => ({
            id: h._id,
            ...h._source
          })),
          enrichments,
          total,
          identity_count: Object.keys(agentToDefender).length
        }
      });
    } catch (err) {
      var _err$statusCode5, _err$message14;
      return res.customError({
        statusCode: (_err$statusCode5 = err.statusCode) !== null && _err$statusCode5 !== void 0 ? _err$statusCode5 : 500,
        body: (_err$message14 = err.message) !== null && _err$message14 !== void 0 ? _err$message14 : String(err)
      });
    }
  });
}
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfY29uZmlnU2NoZW1hIiwicmVxdWlyZSIsIl9jb25zdGFudHMiLCJfbWRlQ2xpZW50IiwiX2dyYXBoU2VjdXJpdHlDbGllbnQiLCJtYXBHcmFwaEVyciIsImVyciIsIkdyYXBoQXBpRXJyb3IiLCJzdGF0dXMiLCJib2R5IiwibWVzc2FnZSIsIkVycm9yIiwiU3RyaW5nIiwibm9ybWFsaXplTWRlTWFjaGluZSIsIm0iLCJ0ZW5hbnRJZCIsInRlbmFudF9pZCIsIm1hY2hpbmVfaWQiLCJpZCIsImNvbXB1dGVyX2Ruc19uYW1lIiwiY29tcHV0ZXJEbnNOYW1lIiwib3NfcGxhdGZvcm0iLCJvc1BsYXRmb3JtIiwib3NfdmVyc2lvbiIsIm9zVmVyc2lvbiIsImxhc3Rfc2VlbiIsImxhc3RTZWVuIiwiZmlyc3Rfc2VlbiIsImZpcnN0U2VlbiIsImFhZF9kZXZpY2VfaWQiLCJhYWREZXZpY2VJZCIsInJpc2tfc2NvcmUiLCJyaXNrU2NvcmUiLCJleHBvc3VyZV9sZXZlbCIsImV4cG9zdXJlTGV2ZWwiLCJvbmJvYXJkaW5nX3N0YXR1cyIsIm9uYm9hcmRpbmdTdGF0dXMiLCJvbmJvYXJkaW5nc3RhdHVzIiwiaGVhbHRoX3N0YXR1cyIsImhlYWx0aFN0YXR1cyIsImlzb2xhdGlvbl9zdGF0dXMiLCJpc29sYXRpb25TdGF0dXMiLCJsYXN0X2lwX2FkZHJlc3MiLCJsYXN0SXBBZGRyZXNzIiwicmJhY19ncm91cF9uYW1lIiwicmJhY0dyb3VwTmFtZSIsImdldENsaWVudCIsImNvbnRleHQiLCJjb3JlIiwib3BlbnNlYXJjaCIsImNsaWVudCIsImFzQ3VycmVudFVzZXIiLCJyZWdpc3RlckRlZmVuZGVyU2VhcmNoUm91dGVzIiwicm91dGVyIiwiZ2V0IiwicGF0aCIsInZhbGlkYXRlIiwiX2NvbnRleHQiLCJfcmVxIiwicmVzIiwibWRlIiwiZ2V0TWRlQ29uZmlnIiwiZ3JhcGgiLCJnZXRHcmFwaFNlY3VyaXR5Q29uZmlnIiwic210cF9ob3N0IiwicHJvY2VzcyIsImVudiIsIlNNVFBfSE9TVCIsInNtdHBfdXNlciIsIlNNVFBfVVNFUiIsInNtdHBfcG9ydCIsIlNNVFBfUE9SVCIsIm90cF9yZWNpcGllbnRfZW1haWwiLCJPVFBfUkVDSVBJRU5UX0VNQUlMIiwic210cF9jb25maWd1cmVkIiwib2siLCJtZGVfY29uZmlndXJlZCIsImdyYXBoX3NlY3VyaXR5X2NvbmZpZ3VyZWQiLCJvdHBfZGV2X21vZGUiLCJ0aW1lc3RhbXAiLCJEYXRlIiwidG9JU09TdHJpbmciLCJxdWVyeSIsInNjaGVtYSIsIm9iamVjdCIsInNpemUiLCJtYXliZSIsIm51bWJlciIsImZyb20iLCJzdHJpbmciLCJzb3VyY2UiLCJyZXEiLCJxIiwibWNmZyIsImN1c3RvbUVycm9yIiwic3RhdHVzQ29kZSIsIl9xJGZyb20iLCJfcSRzaXplIiwicmF3IiwiZmV0Y2hBbGxNYWNoaW5lc0xpbWl0ZWQiLCJyb3dzIiwibWFwIiwiZmlsdGVyIiwiciIsInNvcnQiLCJhIiwiYiIsInRhIiwiZ2V0VGltZSIsInRiIiwic2xpY2UiLCJoaXRzIiwic3JjIiwiX3NvdXJjZSIsIl9pZCIsInRvdGFsIiwidmFsdWUiLCJsZW5ndGgiLCJyZWxhdGlvbiIsIl9lcnIkbWVzc2FnZSIsIm1kZUVycm9yU3RhdHVzIiwiX2hpdHMiLCJfcmVzcG9uc2UkYm9keSIsIl9oaXRzJGhpdHMiLCJtdXN0IiwicHVzaCIsInRlcm0iLCJyZXNwb25zZSIsInNlYXJjaCIsIkRFRkVOREVSX01BQ0hJTkVTX0lOREVYIiwib3JkZXIiLCJtaXNzaW5nIiwiYm9vbCIsIm1hdGNoX2FsbCIsIl9lcnIkc3RhdHVzQ29kZSIsIl9lcnIkbWVzc2FnZTIiLCJwYXJhbXMiLCJjb25maWciLCJkYXRhIiwiZ2V0TWFjaGluZSIsIl9lcnIkbWVzc2FnZTMiLCJtZGVNYWNoaW5lU3ViIiwicGF0aFN1ZmZpeCIsImZuIiwiX2VyciRtZXNzYWdlNCIsImdldE1hY2hpbmVSZWNvbW1lbmRhdGlvbnMiLCJnZXRNYWNoaW5lVnVsbmVyYWJpbGl0aWVzIiwiZ2V0TWFjaGluZUFsZXJ0cyIsImdldE1hY2hpbmVMb2dvblVzZXJzIiwiZ2V0TWFjaGluZVNvZnR3YXJlIiwiU0VSVklDRV9OQU1FX1JFIiwiU0VSVklDRV9ET01BSU5fUkUiLCJJTlRFUkFDVElWRV9SRSIsIkxPQ0FMX0FETUlOX1BBVFRFUk5fUkUiLCJpc1NlcnZpY2VBY2NvdW50IiwidSIsImhvc3RuYW1lIiwibiIsImFjY291bnROYW1lIiwidHJpbSIsImQiLCJhY2NvdW50RG9tYWluIiwiZW5kc1dpdGgiLCJ0ZXN0IiwiaG4iLCJ0b0xvd2VyQ2FzZSIsImhuVHJ1bmMiLCJzcGxpdCIsImRuIiwicGlja1ByaW1hcnkiLCJsb2dvblVzZXJzIiwibGlzdCIsIkFycmF5IiwiaXNBcnJheSIsImh1bWFuIiwic29ydGVkQnlMYXN0U2VlbiIsImludGVyYWN0aXZlIiwiZmluZCIsImxvZ29uVHlwZXMiLCJwaWNrIiwiaXNEb21haW5BZG1pbiIsInBhcnNlSG9zdG5hbWVPd25lciIsIm1hdGNoIiwiaW5mZXJyZWQiLCJwYXJzZUxvZ2dlZE9uVXNlcnMiLCJwYXJzZWQiLCJKU09OIiwicGFyc2UiLCJwaWNrRnJvbUh1bnRpbmciLCJlbnRyeSIsInVzZXJzIiwiTG9nZ2VkT25Vc2VycyIsIlVzZXJOYW1lIiwiRG9tYWluTmFtZSIsIlRpbWVzdGFtcCIsIk9XTkVSX0ZJTFRFUl9WRVJTSU9OIiwicmVhZE93bmVyQ2FjaGUiLCJtYWNoaW5lSWRzIiwiaW5kZXgiLCJERUZFTkRFUl9PV05FUl9DQUNIRV9JTkRFWCIsImlnbm9yZV91bmF2YWlsYWJsZSIsInRlcm1zIiwib3V0Iiwibm93IiwiZm9yRWFjaCIsImgiLCJzIiwiZmV0Y2hlZEF0IiwiZmV0Y2hlZF9hdCIsInZlcnNpb25PayIsImZpbHRlcl92ZXJzaW9uIiwiREVGRU5ERVJfT1dORVJfQ0FDSEVfVFRMX01TIiwicHJpbWFyeV91c2VyIiwid3JpdGVPd25lckNhY2hlIiwiZW50cmllcyIsIm9wcyIsIl9pbmRleCIsImJ1bGsiLCJyZWZyZXNoIiwiZSIsIndhcm4iLCJmZXRjaEFhZE93bmVyRW5yaWNobWVudCIsImdjZmciLCJncmFwaFNlY3VyaXR5UmVxdWVzdCIsImxvb2t1cCIsIm93bmVycyIsImFhZERldmljZSIsImRpc3BsYXlOYW1lIiwibWFpbCIsInVzZXJQcmluY2lwYWxOYW1lIiwiZGVwYXJ0bWVudCIsImpvYlRpdGxlIiwiZmV0Y2hIdW50aW5nTW9zdEZyZXF1ZW50IiwicnVuSHVudGluZ1F1ZXJ5IiwicmVzdWx0cyIsInJvdyIsIkRldmljZUlkIiwiYXJyYXlPZiIsImJvb2xlYW4iLCJtYWNoaW5lcyIsImZvcmNlUmVmcmVzaCIsImZvcmNlX3JlZnJlc2giLCJyZXN1bHQiLCJ0b0ZldGNoIiwiY2FjaGVkIiwidW5kZWZpbmVkIiwiaHVudGluZ01hcCIsImNvbmN1cnJlbmN5IiwibmV3RW50cmllcyIsIm5leHQiLCJjdXJzb3IiLCJpIiwib3duZXIiLCJodW50aW5nSGl0IiwiYWFkT3duZXIiLCJlbWFpbCIsImZiIiwiUHJvbWlzZSIsImFsbCIsIk1hdGgiLCJtaW4iLCJzb3VyY2VzIiwidmFsdWVzIiwidiIsIm1ldGEiLCJmcm9tX2NhY2hlIiwiZmV0Y2hlZCIsImxpc3RPcmdWdWxuZXJhYmlsaXRpZXMiLCJ2dWxucyIsInNldk1hcCIsInNldmVyaXR5IiwidG9TdHJpbmciLCJieV9zZXZlcml0eSIsIk9iamVjdCIsImNvdW50IiwidG9wX2N2ZXNfYnlfc3ByZWFkIiwiZXhwb3NlZE1hY2hpbmVzIiwibmFtZSIsImN2c3NWMyIsInB1YmxpY0V4cGxvaXQiLCJwdWJsaXNoZWRPbiIsImtwaXMiLCJjcml0aWNhbCIsImhpZ2giLCJ3aXRoX2V4cGxvaXQiLCJhZmZlY3RlZF9ob3N0c190b3RhbCIsInJlZHVjZSIsImFjYyIsInRvcF9ob3N0c19ieV9jb3VudCIsImh1bnRRdWVyeSIsIkRldmljZU5hbWUiLCJjdmVfY291bnQiLCJDdmVDb3VudCIsImN2ZUlkIiwibWRlUmVxdWVzdCIsImVuY29kZVVSSUNvbXBvbmVudCIsIl90b3AiLCJ0b3AiLCJfZXJyJG1lc3NhZ2U1IiwiX3RvcDIiLCJsaXN0TGVnYWN5QWxlcnRzIiwiX2VyciRtZXNzYWdlNiIsIl90b3AzIiwibGlzdE1hY2hpbmVBY3Rpb25zIiwiX2VyciRtZXNzYWdlNyIsImFjdGlvbklkIiwiZ2V0TWFjaGluZUFjdGlvblBhY2thZ2VVcmkiLCJfZXJyJG1lc3NhZ2U4IiwiX2hpdHMyIiwiX21hY2hpbmVzUmVzJGJvZHkiLCJfYWdncmVnYXRpb25zIiwiX21hY2hpbmVzUmVzJGJvZHkyIiwiX2hpdHNCb2R5JGhpdHMiLCJfaGl0c0JvZHkkdG90YWwkdmFsdWUiLCJfaGl0c0JvZHkkdG90YWwiLCJfaGl0c0JvZHkkdG90YWwyIiwiX2FnZ3MkYnlfb3MkYnVja2V0cyIsIl9hZ2dzJGJ5X29zIiwiX2FnZ3MkYnlfZXhwb3N1cmUkYnVjIiwiX2FnZ3MkYnlfZXhwb3N1cmUiLCJfYWdncyRieV9oZWFsdGgkYnVja2UiLCJfYWdncyRieV9oZWFsdGgiLCJfYWdncyRieV9yaXNrJGJ1Y2tldHMiLCJfYWdncyRieV9yaXNrIiwic3RhbGVEYXRlIiwibWFjaGluZXNSZXMiLCJ0cmFja190b3RhbF9oaXRzIiwiYWdncyIsImJ5X29zIiwiZmllbGQiLCJieV9leHBvc3VyZSIsImJ5X2hlYWx0aCIsImJ5X3Jpc2siLCJpbmNpZGVudHNDb3VudCIsImFsZXJ0c0NvdW50IiwidnVsbkNvdW50IiwibGlua2VkQWdlbnRzIiwic3RhbGVDb3VudCIsIl9jb3VudCIsIl9pYyRib2R5IiwiX2NvdW50MiIsIl9hYyRib2R5IiwiX2NvdW50MyIsIl92YyRib2R5IiwiX2NvdW50NCIsIl9pZFJlcyRib2R5IiwiX3JlZiIsIl9oaXRzJHRvdGFsJHZhbHVlIiwiX3N0YWxlUmVzJGJvZHkiLCJfc3RhbGVSZXMkYm9keTIiLCJpYyIsImFjIiwidmMiLCJpZFJlcyIsInN0YWxlUmVzIiwiREVGRU5ERVJfSU5DSURFTlRTX0lOREVYIiwiREVGRU5ERVJfQUxFUlRTX0lOREVYIiwiREVGRU5ERVJfVlVMTkVSQUJJTElUSUVTX0lOREVYIiwiREVGRU5ERVJfTUFDSElORV9JREVOVElUWV9JTkRFWCIsInJhbmdlIiwibHQiLCJoaXRzQm9keSIsImFnZ3JlZ2F0aW9ucyIsInJlY2VudF9tYWNoaW5lcyIsIkJvb2xlYW4iLCJ0b3RhbE1hY2hpbmVzIiwiYnlPc0J1Y2tldHMiLCJidWNrZXRzIiwiYnlFeHBvc3VyZUJ1Y2tldHMiLCJieUhlYWx0aEJ1Y2tldHMiLCJieVJpc2tCdWNrZXRzIiwicmVjZW50TGlzdCIsImRhdGFTb3VyY2UiLCJ0aWQiLCJub3JtYWxpemVkIiwib3NNYXAiLCJleE1hcCIsImhlYWx0aE1hcCIsInJpc2tNYXAiLCJvcyIsImV4IiwiaHMiLCJycyIsImtleSIsImRvY19jb3VudCIsImdyYXBoRXJyb3IiLCJsaXZlSW5jaWRlbnRzQ291bnQiLCJjb3VudFNlY3VyaXR5Q29sbGVjdGlvbiIsImxpdmVBbGVydHNDb3VudCIsInRvdGFsX21hY2hpbmVzIiwiaW5jaWRlbnRzX2luZGV4X2NvdW50IiwiYWxlcnRzX2luZGV4X2NvdW50IiwidnVsbmVyYWJpbGl0aWVzX2luZGV4X2NvdW50IiwibGlua2VkX2FnZW50c19jb3VudCIsInN0YWxlX21hY2hpbmVzX2NvdW50IiwiZ3JhcGhfYWxlcnRzX2xpdmVfY291bnQiLCJncmFwaF9lcnJvcl9oaW50IiwiZGF0YV9zb3VyY2UiLCJfZXJyJHN0YXR1c0NvZGUyIiwiX2VyciRtZXNzYWdlOSIsIl9xJHNpemUyIiwiX2RhdGEkdmFsdWUiLCJfcSRmcm9tMiIsIl9xJHNpemUzIiwiX3JlZjIiLCJfcm93JGlkIl0sInNvdXJjZXMiOlsic2VhcmNoLnRzIl0sInNvdXJjZXNDb250ZW50IjpbIi8qXG4gKiBEZWZlbmRlciBwbHVnaW4g4oCUIE9wZW5TZWFyY2ggcmVhZHMgKyBHcmFwaC9NREUgcHJveGllc1xuICovXG5cbmltcG9ydCB7IElSb3V0ZXIgfSBmcm9tICdvcGVuc2VhcmNoLWRhc2hib2FyZHMvc2VydmVyJztcbmltcG9ydCB7IHNjaGVtYSB9IGZyb20gJ0Bvc2QvY29uZmlnLXNjaGVtYSc7XG5pbXBvcnQge1xuICBERUZFTkRFUl9NQUNISU5FU19JTkRFWCxcbiAgREVGRU5ERVJfTUFDSElORV9JREVOVElUWV9JTkRFWCxcbiAgREVGRU5ERVJfVlVMTkVSQUJJTElUSUVTX0lOREVYLFxuICBERUZFTkRFUl9JTkNJREVOVFNfSU5ERVgsXG4gIERFRkVOREVSX0FMRVJUU19JTkRFWCxcbiAgREVGRU5ERVJfQVVESVRfTE9HX0lOREVYLFxuICBXQVpVSF9BTEVSVFNfUEFUVEVSTixcbn0gZnJvbSAnLi4vLi4vY29tbW9uL2NvbnN0YW50cyc7XG5pbXBvcnQge1xuICBnZXRNZGVDb25maWcsXG4gIGdldE1hY2hpbmUsXG4gIGxpc3RJbmRpY2F0b3JzLFxuICBmZXRjaEFsbE1hY2hpbmVzTGltaXRlZCxcbiAgZ2V0TWFjaGluZVJlY29tbWVuZGF0aW9ucyxcbiAgZ2V0TWFjaGluZVZ1bG5lcmFiaWxpdGllcyxcbiAgZ2V0TWFjaGluZUFsZXJ0cyxcbiAgZ2V0TWFjaGluZUxvZ29uVXNlcnMsXG4gIGdldE1hY2hpbmVTb2Z0d2FyZSxcbiAgbGlzdE9yZ1Z1bG5lcmFiaWxpdGllcyxcbiAgbGlzdExlZ2FjeUFsZXJ0cyxcbiAgbGlzdE1hY2hpbmVBY3Rpb25zLFxuICBnZXRNYWNoaW5lQWN0aW9uUGFja2FnZVVyaSxcbiAgbWRlRXJyb3JTdGF0dXMsXG59IGZyb20gJy4uL2xpYi9tZGUtY2xpZW50JztcbmltcG9ydCB7XG4gIGdldEdyYXBoU2VjdXJpdHlDb25maWcsXG4gIGxpc3RJbmNpZGVudHMsXG4gIGxpc3RBbGVydHNWMixcbiAgcnVuSHVudGluZ1F1ZXJ5LFxuICBjb3VudFNlY3VyaXR5Q29sbGVjdGlvbixcbiAgR3JhcGhBcGlFcnJvcixcbn0gZnJvbSAnLi4vbGliL2dyYXBoLXNlY3VyaXR5LWNsaWVudCc7XG5cbmZ1bmN0aW9uIG1hcEdyYXBoRXJyKGVycjogdW5rbm93bik6IHsgc3RhdHVzOiBudW1iZXI7IGJvZHk6IHN0cmluZyB9IHtcbiAgaWYgKGVyciBpbnN0YW5jZW9mIEdyYXBoQXBpRXJyb3IpIHtcbiAgICByZXR1cm4geyBzdGF0dXM6IGVyci5zdGF0dXMgPj0gNDAwICYmIGVyci5zdGF0dXMgPCA2MDAgPyBlcnIuc3RhdHVzIDogNTAyLCBib2R5OiBlcnIubWVzc2FnZSB9O1xuICB9XG4gIHJldHVybiB7IHN0YXR1czogNTAyLCBib2R5OiBlcnIgaW5zdGFuY2VvZiBFcnJvciA/IGVyci5tZXNzYWdlIDogU3RyaW5nKGVycikgfTtcbn1cblxuZnVuY3Rpb24gbm9ybWFsaXplTWRlTWFjaGluZShtOiBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPiwgdGVuYW50SWQ6IHN0cmluZykge1xuICByZXR1cm4ge1xuICAgIHRlbmFudF9pZDogdGVuYW50SWQsXG4gICAgbWFjaGluZV9pZDogbS5pZCxcbiAgICBjb21wdXRlcl9kbnNfbmFtZTogbS5jb21wdXRlckRuc05hbWUgfHwgJycsXG4gICAgb3NfcGxhdGZvcm06IG0ub3NQbGF0Zm9ybSB8fCAnJyxcbiAgICBvc192ZXJzaW9uOiBtLm9zVmVyc2lvbiB8fCAnJyxcbiAgICBsYXN0X3NlZW46IG0ubGFzdFNlZW4gfHwgbnVsbCxcbiAgICBmaXJzdF9zZWVuOiBtLmZpcnN0U2VlbiB8fCBudWxsLFxuICAgIGFhZF9kZXZpY2VfaWQ6IG0uYWFkRGV2aWNlSWQgfHwgJycsXG4gICAgcmlza19zY29yZTogbS5yaXNrU2NvcmUgIT0gbnVsbCA/IFN0cmluZyhtLnJpc2tTY29yZSkgOiAnJyxcbiAgICBleHBvc3VyZV9sZXZlbDogbS5leHBvc3VyZUxldmVsIHx8ICcnLFxuICAgIG9uYm9hcmRpbmdfc3RhdHVzOiBtLm9uYm9hcmRpbmdTdGF0dXMgfHwgbS5vbmJvYXJkaW5nc3RhdHVzIHx8ICcnLFxuICAgIGhlYWx0aF9zdGF0dXM6IG0uaGVhbHRoU3RhdHVzIHx8ICcnLFxuICAgIGlzb2xhdGlvbl9zdGF0dXM6IG0uaXNvbGF0aW9uU3RhdHVzIHx8ICcnLFxuICAgIGxhc3RfaXBfYWRkcmVzczogbS5sYXN0SXBBZGRyZXNzIHx8ICcnLFxuICAgIHJiYWNfZ3JvdXBfbmFtZTogbS5yYmFjR3JvdXBOYW1lIHx8ICcnLFxuICB9O1xufVxuXG5mdW5jdGlvbiBnZXRDbGllbnQoY29udGV4dDogYW55KSB7XG4gIHJldHVybiBjb250ZXh0LmNvcmUub3BlbnNlYXJjaC5jbGllbnQuYXNDdXJyZW50VXNlcjtcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIHJlZ2lzdGVyRGVmZW5kZXJTZWFyY2hSb3V0ZXMocm91dGVyOiBJUm91dGVyKSB7XG4gIHJvdXRlci5nZXQoeyBwYXRoOiAnL2FwaS9kZWZlbmRlcl9wbHVnaW4vaGVhbHRoJywgdmFsaWRhdGU6IGZhbHNlIH0sIGFzeW5jIChfY29udGV4dCwgX3JlcSwgcmVzKSA9PiB7XG4gICAgY29uc3QgbWRlID0gISFnZXRNZGVDb25maWcoKTtcbiAgICBjb25zdCBncmFwaCA9ICEhZ2V0R3JhcGhTZWN1cml0eUNvbmZpZygpO1xuICAgIHJldHVybiByZXMub2soe1xuICAgICAgYm9keToge1xuICAgICAgICBvazogbWRlIHx8IGdyYXBoLFxuICAgICAgICBtZGVfY29uZmlndXJlZDogbWRlLFxuICAgICAgICBncmFwaF9zZWN1cml0eV9jb25maWd1cmVkOiBncmFwaCxcbiAgICAgICAgdGltZXN0YW1wOiBuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCksXG4gICAgICB9LFxuICAgIH0pO1xuICB9KTtcblxuICByb3V0ZXIuZ2V0KFxuICAgIHtcbiAgICAgIHBhdGg6ICcvYXBpL2RlZmVuZGVyX3BsdWdpbi9tYWNoaW5lcycsXG4gICAgICB2YWxpZGF0ZToge1xuICAgICAgICBxdWVyeTogc2NoZW1hLm9iamVjdCh7XG4gICAgICAgICAgc2l6ZTogc2NoZW1hLm1heWJlKHNjaGVtYS5udW1iZXIoKSksXG4gICAgICAgICAgZnJvbTogc2NoZW1hLm1heWJlKHNjaGVtYS5udW1iZXIoKSksXG4gICAgICAgICAgb3NfcGxhdGZvcm06IHNjaGVtYS5tYXliZShzY2hlbWEuc3RyaW5nKCkpLFxuICAgICAgICAgIGV4cG9zdXJlX2xldmVsOiBzY2hlbWEubWF5YmUoc2NoZW1hLnN0cmluZygpKSxcbiAgICAgICAgICBzb3VyY2U6IHNjaGVtYS5tYXliZShzY2hlbWEuc3RyaW5nKCkpLFxuICAgICAgICB9KSxcbiAgICAgIH0sXG4gICAgfSxcbiAgICBhc3luYyAoY29udGV4dCwgcmVxLCByZXMpID0+IHtcbiAgICAgIGNvbnN0IHEgPSByZXEucXVlcnkgYXMge1xuICAgICAgICBzaXplPzogbnVtYmVyO1xuICAgICAgICBmcm9tPzogbnVtYmVyO1xuICAgICAgICBvc19wbGF0Zm9ybT86IHN0cmluZztcbiAgICAgICAgZXhwb3N1cmVfbGV2ZWw/OiBzdHJpbmc7XG4gICAgICAgIHNvdXJjZT86IHN0cmluZztcbiAgICAgIH07XG4gICAgICBpZiAocS5zb3VyY2UgPT09ICdsaXZlJykge1xuICAgICAgICBjb25zdCBtY2ZnID0gZ2V0TWRlQ29uZmlnKCk7XG4gICAgICAgIGlmICghbWNmZykge1xuICAgICAgICAgIHJldHVybiByZXMuY3VzdG9tRXJyb3IoeyBzdGF0dXNDb2RlOiA1MDMsIGJvZHk6ICdNREUgbm90IGNvbmZpZ3VyZWQuJyB9KTtcbiAgICAgICAgfVxuICAgICAgICB0cnkge1xuICAgICAgICAgIGNvbnN0IHJhdyA9IGF3YWl0IGZldGNoQWxsTWFjaGluZXNMaW1pdGVkKG1jZmcsIDE1KTtcbiAgICAgICAgICBjb25zdCB0ZW5hbnRJZCA9IG1jZmcudGVuYW50SWQ7XG4gICAgICAgICAgbGV0IHJvd3MgPSByYXcubWFwKChtKSA9PiBub3JtYWxpemVNZGVNYWNoaW5lKG0gYXMgUmVjb3JkPHN0cmluZywgdW5rbm93bj4sIHRlbmFudElkKSk7XG4gICAgICAgICAgaWYgKHEub3NfcGxhdGZvcm0pIHtcbiAgICAgICAgICAgIHJvd3MgPSByb3dzLmZpbHRlcigocikgPT4gU3RyaW5nKHIub3NfcGxhdGZvcm0pID09PSBxLm9zX3BsYXRmb3JtKTtcbiAgICAgICAgICB9XG4gICAgICAgICAgaWYgKHEuZXhwb3N1cmVfbGV2ZWwpIHtcbiAgICAgICAgICAgIHJvd3MgPSByb3dzLmZpbHRlcigocikgPT4gU3RyaW5nKHIuZXhwb3N1cmVfbGV2ZWwpID09PSBxLmV4cG9zdXJlX2xldmVsKTtcbiAgICAgICAgICB9XG4gICAgICAgICAgcm93cy5zb3J0KChhLCBiKSA9PiB7XG4gICAgICAgICAgICBjb25zdCB0YSA9IGEubGFzdF9zZWVuID8gbmV3IERhdGUoU3RyaW5nKGEubGFzdF9zZWVuKSkuZ2V0VGltZSgpIDogMDtcbiAgICAgICAgICAgIGNvbnN0IHRiID0gYi5sYXN0X3NlZW4gPyBuZXcgRGF0ZShTdHJpbmcoYi5sYXN0X3NlZW4pKS5nZXRUaW1lKCkgOiAwO1xuICAgICAgICAgICAgcmV0dXJuIHRiIC0gdGE7XG4gICAgICAgICAgfSk7XG4gICAgICAgICAgY29uc3QgZnJvbSA9IHEuZnJvbSA/PyAwO1xuICAgICAgICAgIGNvbnN0IHNpemUgPSBxLnNpemUgPz8gNTA7XG4gICAgICAgICAgY29uc3Qgc2xpY2UgPSByb3dzLnNsaWNlKGZyb20sIGZyb20gKyBzaXplKTtcbiAgICAgICAgICBjb25zdCBoaXRzID0gc2xpY2UubWFwKChzcmMpID0+ICh7IF9zb3VyY2U6IHNyYywgX2lkOiBzcmMubWFjaGluZV9pZCB9KSk7XG4gICAgICAgICAgcmV0dXJuIHJlcy5vayh7XG4gICAgICAgICAgICBib2R5OiB7XG4gICAgICAgICAgICAgIGhpdHMsXG4gICAgICAgICAgICAgIHRvdGFsOiB7IHZhbHVlOiByb3dzLmxlbmd0aCwgcmVsYXRpb246ICdlcScgfSxcbiAgICAgICAgICAgICAgc291cmNlOiAnbWRlJyxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgfSk7XG4gICAgICAgIH0gY2F0Y2ggKGVycjogYW55KSB7XG4gICAgICAgICAgcmV0dXJuIHJlcy5jdXN0b21FcnJvcih7XG4gICAgICAgICAgICBzdGF0dXNDb2RlOiBtZGVFcnJvclN0YXR1cyhlcnIpLFxuICAgICAgICAgICAgYm9keTogZXJyPy5tZXNzYWdlID8/IFN0cmluZyhlcnIpLFxuICAgICAgICAgIH0pO1xuICAgICAgICB9XG4gICAgICB9XG4gICAgICB0cnkge1xuICAgICAgICBjb25zdCBjbGllbnQgPSBnZXRDbGllbnQoY29udGV4dCk7XG4gICAgICAgIGNvbnN0IHsgc2l6ZSA9IDUwLCBmcm9tID0gMCwgb3NfcGxhdGZvcm0sIGV4cG9zdXJlX2xldmVsIH0gPSBxO1xuICAgICAgICBjb25zdCBtdXN0OiBhbnlbXSA9IFtdO1xuICAgICAgICBpZiAob3NfcGxhdGZvcm0pIG11c3QucHVzaCh7IHRlcm06IHsgb3NfcGxhdGZvcm0gfSB9KTtcbiAgICAgICAgaWYgKGV4cG9zdXJlX2xldmVsKSBtdXN0LnB1c2goeyB0ZXJtOiB7IGV4cG9zdXJlX2xldmVsIH0gfSk7XG4gICAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgY2xpZW50LnNlYXJjaCh7XG4gICAgICAgICAgaW5kZXg6IERFRkVOREVSX01BQ0hJTkVTX0lOREVYLFxuICAgICAgICAgIGlnbm9yZV91bmF2YWlsYWJsZTogdHJ1ZSxcbiAgICAgICAgICBib2R5OiB7XG4gICAgICAgICAgICBzaXplLFxuICAgICAgICAgICAgZnJvbSxcbiAgICAgICAgICAgIHNvcnQ6IFt7IGxhc3Rfc2VlbjogeyBvcmRlcjogJ2Rlc2MnLCBtaXNzaW5nOiAnX2xhc3QnIH0gfSwgeyBjb21wdXRlcl9kbnNfbmFtZTogJ2FzYycgfV0sXG4gICAgICAgICAgICBxdWVyeTogbXVzdC5sZW5ndGggPyB7IGJvb2w6IHsgbXVzdCB9IH0gOiB7IG1hdGNoX2FsbDoge30gfSxcbiAgICAgICAgICB9LFxuICAgICAgICB9KTtcbiAgICAgICAgY29uc3QgaGl0cyA9IChyZXNwb25zZS5ib2R5IGFzIGFueSk/LmhpdHMgPz8ge307XG4gICAgICAgIHJldHVybiByZXMub2soeyBib2R5OiB7IGhpdHM6IGhpdHMuaGl0cyA/PyBbXSwgdG90YWw6IGhpdHMudG90YWwsIHNvdXJjZTogJ2luZGV4JyB9IH0pO1xuICAgICAgfSBjYXRjaCAoZXJyOiBhbnkpIHtcbiAgICAgICAgcmV0dXJuIHJlcy5jdXN0b21FcnJvcih7XG4gICAgICAgICAgc3RhdHVzQ29kZTogZXJyLnN0YXR1c0NvZGUgPz8gNTAwLFxuICAgICAgICAgIGJvZHk6IGVyci5tZXNzYWdlID8/IFN0cmluZyhlcnIpLFxuICAgICAgICB9KTtcbiAgICAgIH1cbiAgICB9XG4gICk7XG5cbiAgcm91dGVyLmdldChcbiAgICB7XG4gICAgICBwYXRoOiAnL2FwaS9kZWZlbmRlcl9wbHVnaW4vbWFjaGluZXMve2lkfS9saXZlJyxcbiAgICAgIHZhbGlkYXRlOiB7IHBhcmFtczogc2NoZW1hLm9iamVjdCh7IGlkOiBzY2hlbWEuc3RyaW5nKCkgfSkgfSxcbiAgICB9LFxuICAgIGFzeW5jIChfY29udGV4dCwgX3JlcSwgcmVzKSA9PiB7XG4gICAgICBjb25zdCBjb25maWcgPSBnZXRNZGVDb25maWcoKTtcbiAgICAgIGlmICghY29uZmlnKSB7XG4gICAgICAgIHJldHVybiByZXMuY3VzdG9tRXJyb3Ioe1xuICAgICAgICAgIHN0YXR1c0NvZGU6IDUwMyxcbiAgICAgICAgICBib2R5OiAnRGVmZW5kZXIgTURFIG5vdCBjb25maWd1cmVkIChERUZFTkRFUl9URU5BTlRfSUQsIERFRkVOREVSX0NMSUVOVF9JRCwgREVGRU5ERVJfQ0xJRU5UX1NFQ1JFVCkuJyxcbiAgICAgICAgfSk7XG4gICAgICB9XG4gICAgICB0cnkge1xuICAgICAgICBjb25zdCBpZCA9IChfcmVxLnBhcmFtcyBhcyB7IGlkOiBzdHJpbmcgfSkuaWQ7XG4gICAgICAgIGNvbnN0IGRhdGEgPSBhd2FpdCBnZXRNYWNoaW5lKGNvbmZpZywgaWQpO1xuICAgICAgICByZXR1cm4gcmVzLm9rKHsgYm9keTogZGF0YSB9KTtcbiAgICAgIH0gY2F0Y2ggKGVycjogYW55KSB7XG4gICAgICAgIHJldHVybiByZXMuY3VzdG9tRXJyb3Ioe1xuICAgICAgICAgIHN0YXR1c0NvZGU6IG1kZUVycm9yU3RhdHVzKGVyciksXG4gICAgICAgICAgYm9keTogZXJyPy5tZXNzYWdlID8/IFN0cmluZyhlcnIpLFxuICAgICAgICB9KTtcbiAgICAgIH1cbiAgICB9XG4gICk7XG5cbiAgY29uc3QgbWRlTWFjaGluZVN1YiA9IChwYXRoU3VmZml4OiBzdHJpbmcsIGZuOiAoYzogYW55LCBpZDogc3RyaW5nKSA9PiBQcm9taXNlPHVua25vd24+KSA9PiB7XG4gICAgcm91dGVyLmdldChcbiAgICAgIHtcbiAgICAgICAgcGF0aDogYC9hcGkvZGVmZW5kZXJfcGx1Z2luL21hY2hpbmVzL3tpZH0vbGl2ZS8ke3BhdGhTdWZmaXh9YCxcbiAgICAgICAgdmFsaWRhdGU6IHsgcGFyYW1zOiBzY2hlbWEub2JqZWN0KHsgaWQ6IHNjaGVtYS5zdHJpbmcoKSB9KSB9LFxuICAgICAgfSxcbiAgICAgIGFzeW5jIChfY29udGV4dCwgcmVxLCByZXMpID0+IHtcbiAgICAgICAgY29uc3QgbWNmZyA9IGdldE1kZUNvbmZpZygpO1xuICAgICAgICBpZiAoIW1jZmcpIHtcbiAgICAgICAgICByZXR1cm4gcmVzLmN1c3RvbUVycm9yKHsgc3RhdHVzQ29kZTogNTAzLCBib2R5OiAnTURFIG5vdCBjb25maWd1cmVkLicgfSk7XG4gICAgICAgIH1cbiAgICAgICAgdHJ5IHtcbiAgICAgICAgICBjb25zdCBpZCA9IChyZXEucGFyYW1zIGFzIHsgaWQ6IHN0cmluZyB9KS5pZDtcbiAgICAgICAgICBjb25zdCBkYXRhID0gYXdhaXQgZm4obWNmZywgaWQpO1xuICAgICAgICAgIHJldHVybiByZXMub2soeyBib2R5OiBkYXRhIH0pO1xuICAgICAgICB9IGNhdGNoIChlcnI6IGFueSkge1xuICAgICAgICAgIHJldHVybiByZXMuY3VzdG9tRXJyb3IoeyBzdGF0dXNDb2RlOiBtZGVFcnJvclN0YXR1cyhlcnIpLCBib2R5OiBlcnI/Lm1lc3NhZ2UgPz8gU3RyaW5nKGVycikgfSk7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICApO1xuICB9O1xuXG4gIG1kZU1hY2hpbmVTdWIoJ3JlY29tbWVuZGF0aW9ucycsIGdldE1hY2hpbmVSZWNvbW1lbmRhdGlvbnMpO1xuICBtZGVNYWNoaW5lU3ViKCd2dWxuZXJhYmlsaXRpZXMnLCBnZXRNYWNoaW5lVnVsbmVyYWJpbGl0aWVzKTtcbiAgbWRlTWFjaGluZVN1YignYWxlcnRzJywgZ2V0TWFjaGluZUFsZXJ0cyk7XG4gIG1kZU1hY2hpbmVTdWIoJ2xvZ29udXNlcnMnLCBnZXRNYWNoaW5lTG9nb25Vc2Vycyk7XG4gIG1kZU1hY2hpbmVTdWIoJ3NvZnR3YXJlJywgZ2V0TWFjaGluZVNvZnR3YXJlKTtcblxuICByb3V0ZXIuZ2V0KFxuICAgIHtcbiAgICAgIHBhdGg6ICcvYXBpL2RlZmVuZGVyX3BsdWdpbi9tZGUvdnVsbmVyYWJpbGl0aWVzJyxcbiAgICAgIHZhbGlkYXRlOiB7IHF1ZXJ5OiBzY2hlbWEub2JqZWN0KHsgdG9wOiBzY2hlbWEubWF5YmUoc2NoZW1hLm51bWJlcigpKSB9KSB9LFxuICAgIH0sXG4gICAgYXN5bmMgKF9jb250ZXh0LCByZXEsIHJlcykgPT4ge1xuICAgICAgY29uc3QgbWNmZyA9IGdldE1kZUNvbmZpZygpO1xuICAgICAgaWYgKCFtY2ZnKSByZXR1cm4gcmVzLmN1c3RvbUVycm9yKHsgc3RhdHVzQ29kZTogNTAzLCBib2R5OiAnTURFIG5vdCBjb25maWd1cmVkLicgfSk7XG4gICAgICB0cnkge1xuICAgICAgICBjb25zdCB0b3AgPSAocmVxLnF1ZXJ5IGFzIHsgdG9wPzogbnVtYmVyIH0pLnRvcCA/PyAyMDA7XG4gICAgICAgIGNvbnN0IGRhdGEgPSBhd2FpdCBsaXN0T3JnVnVsbmVyYWJpbGl0aWVzKG1jZmcsIHRvcCk7XG4gICAgICAgIHJldHVybiByZXMub2soeyBib2R5OiBkYXRhIH0pO1xuICAgICAgfSBjYXRjaCAoZXJyOiBhbnkpIHtcbiAgICAgICAgcmV0dXJuIHJlcy5jdXN0b21FcnJvcih7IHN0YXR1c0NvZGU6IG1kZUVycm9yU3RhdHVzKGVyciksIGJvZHk6IGVycj8ubWVzc2FnZSA/PyBTdHJpbmcoZXJyKSB9KTtcbiAgICAgIH1cbiAgICB9XG4gICk7XG5cbiAgcm91dGVyLmdldChcbiAgICB7XG4gICAgICBwYXRoOiAnL2FwaS9kZWZlbmRlcl9wbHVnaW4vbWRlL2FsZXJ0cy1sZWdhY3knLFxuICAgICAgdmFsaWRhdGU6IHsgcXVlcnk6IHNjaGVtYS5vYmplY3QoeyB0b3A6IHNjaGVtYS5tYXliZShzY2hlbWEubnVtYmVyKCkpIH0pIH0sXG4gICAgfSxcbiAgICBhc3luYyAoX2NvbnRleHQsIHJlcSwgcmVzKSA9PiB7XG4gICAgICBjb25zdCBtY2ZnID0gZ2V0TWRlQ29uZmlnKCk7XG4gICAgICBpZiAoIW1jZmcpIHJldHVybiByZXMuY3VzdG9tRXJyb3IoeyBzdGF0dXNDb2RlOiA1MDMsIGJvZHk6ICdNREUgbm90IGNvbmZpZ3VyZWQuJyB9KTtcbiAgICAgIHRyeSB7XG4gICAgICAgIGNvbnN0IHRvcCA9IChyZXEucXVlcnkgYXMgeyB0b3A/OiBudW1iZXIgfSkudG9wID8/IDEwMDtcbiAgICAgICAgY29uc3QgZGF0YSA9IGF3YWl0IGxpc3RMZWdhY3lBbGVydHMobWNmZywgdG9wKTtcbiAgICAgICAgcmV0dXJuIHJlcy5vayh7IGJvZHk6IGRhdGEgfSk7XG4gICAgICB9IGNhdGNoIChlcnI6IGFueSkge1xuICAgICAgICByZXR1cm4gcmVzLmN1c3RvbUVycm9yKHsgc3RhdHVzQ29kZTogbWRlRXJyb3JTdGF0dXMoZXJyKSwgYm9keTogZXJyPy5tZXNzYWdlID8/IFN0cmluZyhlcnIpIH0pO1xuICAgICAgfVxuICAgIH1cbiAgKTtcblxuICByb3V0ZXIuZ2V0KFxuICAgIHtcbiAgICAgIHBhdGg6ICcvYXBpL2RlZmVuZGVyX3BsdWdpbi9tZGUvbWFjaGluZWFjdGlvbnMnLFxuICAgICAgdmFsaWRhdGU6IHsgcXVlcnk6IHNjaGVtYS5vYmplY3QoeyB0b3A6IHNjaGVtYS5tYXliZShzY2hlbWEubnVtYmVyKCkpIH0pIH0sXG4gICAgfSxcbiAgICBhc3luYyAoX2NvbnRleHQsIHJlcSwgcmVzKSA9PiB7XG4gICAgICBjb25zdCBtY2ZnID0gZ2V0TWRlQ29uZmlnKCk7XG4gICAgICBpZiAoIW1jZmcpIHJldHVybiByZXMuY3VzdG9tRXJyb3IoeyBzdGF0dXNDb2RlOiA1MDMsIGJvZHk6ICdNREUgbm90IGNvbmZpZ3VyZWQuJyB9KTtcbiAgICAgIHRyeSB7XG4gICAgICAgIGNvbnN0IHRvcCA9IChyZXEucXVlcnkgYXMgeyB0b3A/OiBudW1iZXIgfSkudG9wID8/IDEwMDtcbiAgICAgICAgY29uc3QgZGF0YSA9IGF3YWl0IGxpc3RNYWNoaW5lQWN0aW9ucyhtY2ZnLCB0b3ApO1xuICAgICAgICByZXR1cm4gcmVzLm9rKHsgYm9keTogZGF0YSB9KTtcbiAgICAgIH0gY2F0Y2ggKGVycjogYW55KSB7XG4gICAgICAgIHJldHVybiByZXMuY3VzdG9tRXJyb3IoeyBzdGF0dXNDb2RlOiBtZGVFcnJvclN0YXR1cyhlcnIpLCBib2R5OiBlcnI/Lm1lc3NhZ2UgPz8gU3RyaW5nKGVycikgfSk7XG4gICAgICB9XG4gICAgfVxuICApO1xuXG4gIHJvdXRlci5nZXQoXG4gICAge1xuICAgICAgcGF0aDogJy9hcGkvZGVmZW5kZXJfcGx1Z2luL21kZS9tYWNoaW5lYWN0aW9ucy97YWN0aW9uSWR9L3BhY2thZ2UtdXJpJyxcbiAgICAgIHZhbGlkYXRlOiB7IHBhcmFtczogc2NoZW1hLm9iamVjdCh7IGFjdGlvbklkOiBzY2hlbWEuc3RyaW5nKCkgfSkgfSxcbiAgICB9LFxuICAgIGFzeW5jIChfY29udGV4dCwgcmVxLCByZXMpID0+IHtcbiAgICAgIGNvbnN0IG1jZmcgPSBnZXRNZGVDb25maWcoKTtcbiAgICAgIGlmICghbWNmZykgcmV0dXJuIHJlcy5jdXN0b21FcnJvcih7IHN0YXR1c0NvZGU6IDUwMywgYm9keTogJ01ERSBub3QgY29uZmlndXJlZC4nIH0pO1xuICAgICAgdHJ5IHtcbiAgICAgICAgY29uc3QgYWN0aW9uSWQgPSAocmVxLnBhcmFtcyBhcyB7IGFjdGlvbklkOiBzdHJpbmcgfSkuYWN0aW9uSWQ7XG4gICAgICAgIGNvbnN0IGRhdGEgPSBhd2FpdCBnZXRNYWNoaW5lQWN0aW9uUGFja2FnZVVyaShtY2ZnLCBhY3Rpb25JZCk7XG4gICAgICAgIHJldHVybiByZXMub2soeyBib2R5OiBkYXRhIH0pO1xuICAgICAgfSBjYXRjaCAoZXJyOiBhbnkpIHtcbiAgICAgICAgcmV0dXJuIHJlcy5jdXN0b21FcnJvcih7IHN0YXR1c0NvZGU6IG1kZUVycm9yU3RhdHVzKGVyciksIGJvZHk6IGVycj8ubWVzc2FnZSA/PyBTdHJpbmcoZXJyKSB9KTtcbiAgICAgIH1cbiAgICB9XG4gICk7XG5cbiAgcm91dGVyLmdldCh7IHBhdGg6ICcvYXBpL2RlZmVuZGVyX3BsdWdpbi9vdmVydmlldycsIHZhbGlkYXRlOiBmYWxzZSB9LCBhc3luYyAoY29udGV4dCwgX3JlcSwgcmVzKSA9PiB7XG4gICAgdHJ5IHtcbiAgICAgIGNvbnN0IGNsaWVudCA9IGdldENsaWVudChjb250ZXh0KTtcbiAgICAgIGNvbnN0IHN0YWxlRGF0ZSA9IG5ldyBEYXRlKERhdGUubm93KCkgLSA3ICogMjQgKiA2MCAqIDYwICogMTAwMCkudG9JU09TdHJpbmcoKTtcblxuICAgICAgY29uc3QgbWFjaGluZXNSZXMgPSBhd2FpdCBjbGllbnQuc2VhcmNoKHtcbiAgICAgICAgaW5kZXg6IERFRkVOREVSX01BQ0hJTkVTX0lOREVYLFxuICAgICAgICBpZ25vcmVfdW5hdmFpbGFibGU6IHRydWUsXG4gICAgICAgIGJvZHk6IHtcbiAgICAgICAgICBzaXplOiA4LFxuICAgICAgICAgIHRyYWNrX3RvdGFsX2hpdHM6IHRydWUsXG4gICAgICAgICAgc29ydDogW3sgbGFzdF9zZWVuOiB7IG9yZGVyOiAnZGVzYycsIG1pc3Npbmc6ICdfbGFzdCcgfSB9XSxcbiAgICAgICAgICBxdWVyeTogeyBtYXRjaF9hbGw6IHt9IH0sXG4gICAgICAgICAgYWdnczoge1xuICAgICAgICAgICAgYnlfb3M6IHsgdGVybXM6IHsgZmllbGQ6ICdvc19wbGF0Zm9ybScsIHNpemU6IDE1IH0gfSxcbiAgICAgICAgICAgIGJ5X2V4cG9zdXJlOiB7IHRlcm1zOiB7IGZpZWxkOiAnZXhwb3N1cmVfbGV2ZWwnLCBzaXplOiAxMCB9IH0sXG4gICAgICAgICAgICBieV9oZWFsdGg6IHsgdGVybXM6IHsgZmllbGQ6ICdoZWFsdGhfc3RhdHVzJywgc2l6ZTogMTAgfSB9LFxuICAgICAgICAgICAgYnlfcmlzazogeyB0ZXJtczogeyBmaWVsZDogJ3Jpc2tfc2NvcmUnLCBzaXplOiAxNSB9IH0sXG4gICAgICAgICAgfSxcbiAgICAgICAgfSxcbiAgICAgIH0pO1xuXG4gICAgICBsZXQgaW5jaWRlbnRzQ291bnQgPSAwO1xuICAgICAgbGV0IGFsZXJ0c0NvdW50ID0gMDtcbiAgICAgIGxldCB2dWxuQ291bnQgPSAwO1xuICAgICAgbGV0IGxpbmtlZEFnZW50cyA9IDA7XG4gICAgICBsZXQgc3RhbGVDb3VudCA9IDA7XG4gICAgICB0cnkge1xuICAgICAgICBjb25zdCBbaWMsIGFjLCB2YywgaWRSZXMsIHN0YWxlUmVzXSA9IGF3YWl0IFByb21pc2UuYWxsKFtcbiAgICAgICAgICBjbGllbnQuY291bnQoeyBpbmRleDogREVGRU5ERVJfSU5DSURFTlRTX0lOREVYLCBpZ25vcmVfdW5hdmFpbGFibGU6IHRydWUgfSksXG4gICAgICAgICAgY2xpZW50LmNvdW50KHsgaW5kZXg6IERFRkVOREVSX0FMRVJUU19JTkRFWCwgaWdub3JlX3VuYXZhaWxhYmxlOiB0cnVlIH0pLFxuICAgICAgICAgIGNsaWVudC5jb3VudCh7IGluZGV4OiBERUZFTkRFUl9WVUxORVJBQklMSVRJRVNfSU5ERVgsIGlnbm9yZV91bmF2YWlsYWJsZTogdHJ1ZSB9KSxcbiAgICAgICAgICBjbGllbnQuY291bnQoeyBpbmRleDogREVGRU5ERVJfTUFDSElORV9JREVOVElUWV9JTkRFWCwgaWdub3JlX3VuYXZhaWxhYmxlOiB0cnVlIH0pLFxuICAgICAgICAgIGNsaWVudC5zZWFyY2goe1xuICAgICAgICAgICAgaW5kZXg6IERFRkVOREVSX01BQ0hJTkVTX0lOREVYLFxuICAgICAgICAgICAgaWdub3JlX3VuYXZhaWxhYmxlOiB0cnVlLFxuICAgICAgICAgICAgYm9keToge1xuICAgICAgICAgICAgICBzaXplOiAwLFxuICAgICAgICAgICAgICBxdWVyeToge1xuICAgICAgICAgICAgICAgIGJvb2w6IHtcbiAgICAgICAgICAgICAgICAgIGZpbHRlcjogW3sgcmFuZ2U6IHsgbGFzdF9zZWVuOiB7IGx0OiBzdGFsZURhdGUgfSB9IH1dLFxuICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgIHRyYWNrX3RvdGFsX2hpdHM6IHRydWUsXG4gICAgICAgICAgICB9LFxuICAgICAgICAgIH0pLFxuICAgICAgICBdKTtcbiAgICAgICAgaW5jaWRlbnRzQ291bnQgPSAoaWMuYm9keSBhcyBhbnkpPy5jb3VudCA/PyAwO1xuICAgICAgICBhbGVydHNDb3VudCA9IChhYy5ib2R5IGFzIGFueSk/LmNvdW50ID8/IDA7XG4gICAgICAgIHZ1bG5Db3VudCA9ICh2Yy5ib2R5IGFzIGFueSk/LmNvdW50ID8/IDA7XG4gICAgICAgIGxpbmtlZEFnZW50cyA9IChpZFJlcy5ib2R5IGFzIGFueSk/LmNvdW50ID8/IDA7XG4gICAgICAgIHN0YWxlQ291bnQgPVxuICAgICAgICAgIChzdGFsZVJlcy5ib2R5IGFzIGFueSk/LmhpdHM/LnRvdGFsPy52YWx1ZSA/P1xuICAgICAgICAgIChzdGFsZVJlcy5ib2R5IGFzIGFueSk/LmhpdHM/LnRvdGFsID8/XG4gICAgICAgICAgMDtcbiAgICAgIH0gY2F0Y2gge1xuICAgICAgICAvKiBvcHRpb25hbCBpbmRpY2VzICovXG4gICAgICB9XG5cbiAgICAgIGNvbnN0IGhpdHNCb2R5ID0gKG1hY2hpbmVzUmVzLmJvZHkgYXMgYW55KT8uaGl0cyA/PyB7fTtcbiAgICAgIGNvbnN0IGFnZ3MgPSAobWFjaGluZXNSZXMuYm9keSBhcyBhbnkpPy5hZ2dyZWdhdGlvbnMgPz8ge307XG4gICAgICBjb25zdCByZWNlbnRfbWFjaGluZXMgPSAoaGl0c0JvZHkuaGl0cyA/PyBbXSkubWFwKChoOiBhbnkpID0+IGguX3NvdXJjZSkuZmlsdGVyKEJvb2xlYW4pO1xuICAgICAgY29uc3QgdG90YWxNYWNoaW5lcyA9XG4gICAgICAgIHR5cGVvZiBoaXRzQm9keS50b3RhbCA9PT0gJ29iamVjdCdcbiAgICAgICAgICA/IGhpdHNCb2R5LnRvdGFsPy52YWx1ZSA/PyAwXG4gICAgICAgICAgOiBoaXRzQm9keS50b3RhbCA/PyByZWNlbnRfbWFjaGluZXMubGVuZ3RoO1xuXG4gICAgICBsZXQgYnlPc0J1Y2tldHMgPSBhZ2dzLmJ5X29zPy5idWNrZXRzID8/IFtdO1xuICAgICAgbGV0IGJ5RXhwb3N1cmVCdWNrZXRzID0gYWdncy5ieV9leHBvc3VyZT8uYnVja2V0cyA/PyBbXTtcbiAgICAgIGxldCBieUhlYWx0aEJ1Y2tldHMgPSBhZ2dzLmJ5X2hlYWx0aD8uYnVja2V0cyA/PyBbXTtcbiAgICAgIGxldCBieVJpc2tCdWNrZXRzID0gYWdncy5ieV9yaXNrPy5idWNrZXRzID8/IFtdO1xuICAgICAgbGV0IHJlY2VudExpc3QgPSByZWNlbnRfbWFjaGluZXM7XG4gICAgICBsZXQgdG90YWwgPSB0b3RhbE1hY2hpbmVzO1xuICAgICAgbGV0IGRhdGFTb3VyY2U6ICdpbmRleCcgfCAnbWRlJyA9ICdpbmRleCc7XG5cbiAgICAgIGNvbnN0IG1jZmcgPSBnZXRNZGVDb25maWcoKTtcbiAgICAgIGlmICh0b3RhbCA9PT0gMCAmJiBtY2ZnKSB7XG4gICAgICAgIHRyeSB7XG4gICAgICAgICAgY29uc3QgcmF3ID0gYXdhaXQgZmV0Y2hBbGxNYWNoaW5lc0xpbWl0ZWQobWNmZywgMTApO1xuICAgICAgICAgIGNvbnN0IHRpZCA9IG1jZmcudGVuYW50SWQ7XG4gICAgICAgICAgY29uc3Qgbm9ybWFsaXplZCA9IHJhdy5tYXAoKG0pID0+XG4gICAgICAgICAgICBub3JtYWxpemVNZGVNYWNoaW5lKG0gYXMgUmVjb3JkPHN0cmluZywgdW5rbm93bj4sIHRpZClcbiAgICAgICAgICApO1xuICAgICAgICAgIGlmIChub3JtYWxpemVkLmxlbmd0aCA+IDApIHtcbiAgICAgICAgICAgIGRhdGFTb3VyY2UgPSAnbWRlJztcbiAgICAgICAgICAgIHRvdGFsID0gbm9ybWFsaXplZC5sZW5ndGg7XG4gICAgICAgICAgICByZWNlbnRMaXN0ID0gbm9ybWFsaXplZFxuICAgICAgICAgICAgICAuc2xpY2UoKVxuICAgICAgICAgICAgICAuc29ydCgoYSwgYikgPT4ge1xuICAgICAgICAgICAgICAgIGNvbnN0IHRhID0gYS5sYXN0X3NlZW4gPyBuZXcgRGF0ZShTdHJpbmcoYS5sYXN0X3NlZW4pKS5nZXRUaW1lKCkgOiAwO1xuICAgICAgICAgICAgICAgIGNvbnN0IHRiID0gYi5sYXN0X3NlZW4gPyBuZXcgRGF0ZShTdHJpbmcoYi5sYXN0X3NlZW4pKS5nZXRUaW1lKCkgOiAwO1xuICAgICAgICAgICAgICAgIHJldHVybiB0YiAtIHRhO1xuICAgICAgICAgICAgICB9KVxuICAgICAgICAgICAgICAuc2xpY2UoMCwgMTApO1xuICAgICAgICAgICAgY29uc3Qgb3NNYXA6IFJlY29yZDxzdHJpbmcsIG51bWJlcj4gPSB7fTtcbiAgICAgICAgICAgIGNvbnN0IGV4TWFwOiBSZWNvcmQ8c3RyaW5nLCBudW1iZXI+ID0ge307XG4gICAgICAgICAgICBjb25zdCBoZWFsdGhNYXA6IFJlY29yZDxzdHJpbmcsIG51bWJlcj4gPSB7fTtcbiAgICAgICAgICAgIGNvbnN0IHJpc2tNYXA6IFJlY29yZDxzdHJpbmcsIG51bWJlcj4gPSB7fTtcbiAgICAgICAgICAgIG5vcm1hbGl6ZWQuZm9yRWFjaCgocikgPT4ge1xuICAgICAgICAgICAgICBjb25zdCBvcyA9IFN0cmluZyhyLm9zX3BsYXRmb3JtIHx8ICdVbmtub3duJyk7XG4gICAgICAgICAgICAgIG9zTWFwW29zXSA9IChvc01hcFtvc10gfHwgMCkgKyAxO1xuICAgICAgICAgICAgICBjb25zdCBleCA9IFN0cmluZyhyLmV4cG9zdXJlX2xldmVsIHx8ICd1bmtub3duJyk7XG4gICAgICAgICAgICAgIGV4TWFwW2V4XSA9IChleE1hcFtleF0gfHwgMCkgKyAxO1xuICAgICAgICAgICAgICBjb25zdCBocyA9IFN0cmluZyhyLmhlYWx0aF9zdGF0dXMgfHwgJ3Vua25vd24nKTtcbiAgICAgICAgICAgICAgaGVhbHRoTWFwW2hzXSA9IChoZWFsdGhNYXBbaHNdIHx8IDApICsgMTtcbiAgICAgICAgICAgICAgY29uc3QgcnMgPSBTdHJpbmcoci5yaXNrX3Njb3JlIHx8ICd1bmtub3duJyk7XG4gICAgICAgICAgICAgIHJpc2tNYXBbcnNdID0gKHJpc2tNYXBbcnNdIHx8IDApICsgMTtcbiAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgYnlPc0J1Y2tldHMgPSBPYmplY3QuZW50cmllcyhvc01hcCkubWFwKChba2V5LCBkb2NfY291bnRdKSA9PiAoeyBrZXksIGRvY19jb3VudCB9KSk7XG4gICAgICAgICAgICBieUV4cG9zdXJlQnVja2V0cyA9IE9iamVjdC5lbnRyaWVzKGV4TWFwKS5tYXAoKFtrZXksIGRvY19jb3VudF0pID0+ICh7IGtleSwgZG9jX2NvdW50IH0pKTtcbiAgICAgICAgICAgIGJ5SGVhbHRoQnVja2V0cyA9IE9iamVjdC5lbnRyaWVzKGhlYWx0aE1hcCkubWFwKChba2V5LCBkb2NfY291bnRdKSA9PiAoe1xuICAgICAgICAgICAgICBrZXksXG4gICAgICAgICAgICAgIGRvY19jb3VudCxcbiAgICAgICAgICAgIH0pKTtcbiAgICAgICAgICAgIGJ5Umlza0J1Y2tldHMgPSBPYmplY3QuZW50cmllcyhyaXNrTWFwKS5tYXAoKFtrZXksIGRvY19jb3VudF0pID0+ICh7XG4gICAgICAgICAgICAgIGtleSxcbiAgICAgICAgICAgICAgZG9jX2NvdW50LFxuICAgICAgICAgICAgfSkpO1xuICAgICAgICAgICAgc3RhbGVDb3VudCA9IG5vcm1hbGl6ZWQuZmlsdGVyKFxuICAgICAgICAgICAgICAocikgPT4gIXIubGFzdF9zZWVuIHx8IG5ldyBEYXRlKFN0cmluZyhyLmxhc3Rfc2VlbikpIDwgbmV3IERhdGUoc3RhbGVEYXRlKVxuICAgICAgICAgICAgKS5sZW5ndGg7XG4gICAgICAgICAgfVxuICAgICAgICB9IGNhdGNoIHtcbiAgICAgICAgICAvKiBrZWVwIGluZGV4IGVtcHR5IHN0YXRlICovXG4gICAgICAgIH1cbiAgICAgIH1cblxuICAgICAgbGV0IGxpdmVJbmNpZGVudHNDb3VudDogbnVtYmVyIHwgbnVsbCA9IG51bGw7XG4gICAgICBsZXQgbGl2ZUFsZXJ0c0NvdW50OiBudW1iZXIgfCBudWxsID0gbnVsbDtcbiAgICAgIGxldCBncmFwaEVycm9yOiBzdHJpbmcgfCBudWxsID0gbnVsbDtcbiAgICAgIGNvbnN0IGdjZmcgPSBnZXRHcmFwaFNlY3VyaXR5Q29uZmlnKCk7XG4gICAgICBpZiAoZ2NmZykge1xuICAgICAgICB0cnkge1xuICAgICAgICAgIGxpdmVJbmNpZGVudHNDb3VudCA9IGF3YWl0IGNvdW50U2VjdXJpdHlDb2xsZWN0aW9uKGdjZmcsICdpbmNpZGVudHMnKTtcbiAgICAgICAgfSBjYXRjaCAoZSkge1xuICAgICAgICAgIGdyYXBoRXJyb3IgPSBtYXBHcmFwaEVycihlKS5ib2R5O1xuICAgICAgICAgIGxpdmVJbmNpZGVudHNDb3VudCA9IG51bGw7XG4gICAgICAgIH1cbiAgICAgICAgdHJ5IHtcbiAgICAgICAgICBsaXZlQWxlcnRzQ291bnQgPSBhd2FpdCBjb3VudFNlY3VyaXR5Q29sbGVjdGlvbihnY2ZnLCAnYWxlcnRzX3YyJyk7XG4gICAgICAgIH0gY2F0Y2ggKGUpIHtcbiAgICAgICAgICBpZiAoIWdyYXBoRXJyb3IpIGdyYXBoRXJyb3IgPSBtYXBHcmFwaEVycihlKS5ib2R5O1xuICAgICAgICAgIGxpdmVBbGVydHNDb3VudCA9IG51bGw7XG4gICAgICAgIH1cbiAgICAgIH1cblxuICAgICAgcmV0dXJuIHJlcy5vayh7XG4gICAgICAgIGJvZHk6IHtcbiAgICAgICAgICB0b3RhbF9tYWNoaW5lczogdG90YWwsXG4gICAgICAgICAgYnlfb3M6IGJ5T3NCdWNrZXRzLFxuICAgICAgICAgIGJ5X2V4cG9zdXJlOiBieUV4cG9zdXJlQnVja2V0cyxcbiAgICAgICAgICBieV9oZWFsdGg6IGJ5SGVhbHRoQnVja2V0cyxcbiAgICAgICAgICBieV9yaXNrOiBieVJpc2tCdWNrZXRzLFxuICAgICAgICAgIHJlY2VudF9tYWNoaW5lczogcmVjZW50TGlzdCxcbiAgICAgICAgICBpbmNpZGVudHNfaW5kZXhfY291bnQ6IGluY2lkZW50c0NvdW50LFxuICAgICAgICAgIGFsZXJ0c19pbmRleF9jb3VudDogYWxlcnRzQ291bnQsXG4gICAgICAgICAgdnVsbmVyYWJpbGl0aWVzX2luZGV4X2NvdW50OiB2dWxuQ291bnQsXG4gICAgICAgICAgbGlua2VkX2FnZW50c19jb3VudDogbGlua2VkQWdlbnRzLFxuICAgICAgICAgIHN0YWxlX21hY2hpbmVzX2NvdW50OiBzdGFsZUNvdW50LFxuICAgICAgICAgIGdyYXBoX2luY2lkZW50c19saXZlX2NvdW50OiBsaXZlSW5jaWRlbnRzQ291bnQsXG4gICAgICAgICAgZ3JhcGhfYWxlcnRzX2xpdmVfY291bnQ6IGxpdmVBbGVydHNDb3VudCxcbiAgICAgICAgICBncmFwaF9lcnJvcl9oaW50OiBncmFwaEVycm9yLFxuICAgICAgICAgIGRhdGFfc291cmNlOiBkYXRhU291cmNlLFxuICAgICAgICB9LFxuICAgICAgfSk7XG4gICAgfSBjYXRjaCAoZXJyOiBhbnkpIHtcbiAgICAgIHJldHVybiByZXMuY3VzdG9tRXJyb3Ioe1xuICAgICAgICBzdGF0dXNDb2RlOiBlcnIuc3RhdHVzQ29kZSA/PyA1MDAsXG4gICAgICAgIGJvZHk6IGVyci5tZXNzYWdlID8/IFN0cmluZyhlcnIpLFxuICAgICAgfSk7XG4gICAgfVxuICB9KTtcblxuICByb3V0ZXIuZ2V0KFxuICAgIHtcbiAgICAgIHBhdGg6ICcvYXBpL2RlZmVuZGVyX3BsdWdpbi92dWxuZXJhYmlsaXRpZXMnLFxuICAgICAgdmFsaWRhdGU6IHtcbiAgICAgICAgcXVlcnk6IHNjaGVtYS5vYmplY3Qoe1xuICAgICAgICAgIHNpemU6IHNjaGVtYS5tYXliZShzY2hlbWEubnVtYmVyKCkpLFxuICAgICAgICAgIGZyb206IHNjaGVtYS5tYXliZShzY2hlbWEubnVtYmVyKCkpLFxuICAgICAgICAgIHNvdXJjZTogc2NoZW1hLm1heWJlKHNjaGVtYS5zdHJpbmcoKSksXG4gICAgICAgIH0pLFxuICAgICAgfSxcbiAgICB9LFxuICAgIGFzeW5jIChjb250ZXh0LCByZXEsIHJlcykgPT4ge1xuICAgICAgY29uc3QgcSA9IHJlcS5xdWVyeSBhcyB7IHNpemU/OiBudW1iZXI7IGZyb20/OiBudW1iZXI7IHNvdXJjZT86IHN0cmluZyB9O1xuICAgICAgaWYgKHEuc291cmNlID09PSAnbWRlJykge1xuICAgICAgICBjb25zdCBtY2ZnID0gZ2V0TWRlQ29uZmlnKCk7XG4gICAgICAgIGlmICghbWNmZykgcmV0dXJuIHJlcy5jdXN0b21FcnJvcih7IHN0YXR1c0NvZGU6IDUwMywgYm9keTogJ01ERSBub3QgY29uZmlndXJlZC4nIH0pO1xuICAgICAgICB0cnkge1xuICAgICAgICAgIGNvbnN0IGRhdGEgPSAoYXdhaXQgbGlzdE9yZ1Z1bG5lcmFiaWxpdGllcyhtY2ZnLCBxLnNpemUgPz8gMjAwKSkgYXMge1xuICAgICAgICAgICAgdmFsdWU/OiB1bmtub3duW107XG4gICAgICAgICAgfTtcbiAgICAgICAgICBjb25zdCByb3dzID0gZGF0YT8udmFsdWUgPz8gW107XG4gICAgICAgICAgY29uc3QgZnJvbSA9IHEuZnJvbSA/PyAwO1xuICAgICAgICAgIGNvbnN0IHNpemUgPSBxLnNpemUgPz8gNTA7XG4gICAgICAgICAgY29uc3Qgc2xpY2UgPSByb3dzLnNsaWNlKGZyb20sIGZyb20gKyBzaXplKTtcbiAgICAgICAgICBjb25zdCBoaXRzID0gc2xpY2UubWFwKChyb3c6IGFueSwgaTogbnVtYmVyKSA9PiAoe1xuICAgICAgICAgICAgX2lkOiBTdHJpbmcocm93LmlkID8/IHJvdy5jdmVJZCA/PyBpKSxcbiAgICAgICAgICAgIF9zb3VyY2U6IHR5cGVvZiByb3cgPT09ICdvYmplY3QnID8gcm93IDogeyByYXc6IHJvdyB9LFxuICAgICAgICAgIH0pKTtcbiAgICAgICAgICByZXR1cm4gcmVzLm9rKHtcbiAgICAgICAgICAgIGJvZHk6IHtcbiAgICAgICAgICAgICAgaGl0cyxcbiAgICAgICAgICAgICAgdG90YWw6IHsgdmFsdWU6IHJvd3MubGVuZ3RoLCByZWxhdGlvbjogJ2VxJyB9LFxuICAgICAgICAgICAgICBzb3VyY2U6ICdtZGUnLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICB9KTtcbiAgICAgICAgfSBjYXRjaCAoZXJyOiBhbnkpIHtcbiAgICAgICAgICByZXR1cm4gcmVzLmN1c3RvbUVycm9yKHtcbiAgICAgICAgICAgIHN0YXR1c0NvZGU6IG1kZUVycm9yU3RhdHVzKGVyciksXG4gICAgICAgICAgICBib2R5OiBlcnI/Lm1lc3NhZ2UgPz8gU3RyaW5nKGVyciksXG4gICAgICAgICAgfSk7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICAgIHRyeSB7XG4gICAgICAgIGNvbnN0IGNsaWVudCA9IGdldENsaWVudChjb250ZXh0KTtcbiAgICAgICAgY29uc3QgeyBzaXplID0gNTAsIGZyb20gPSAwIH0gPSBxO1xuICAgICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGNsaWVudC5zZWFyY2goe1xuICAgICAgICAgIGluZGV4OiBERUZFTkRFUl9WVUxORVJBQklMSVRJRVNfSU5ERVgsXG4gICAgICAgICAgaWdub3JlX3VuYXZhaWxhYmxlOiB0cnVlLFxuICAgICAgICAgIGJvZHk6IHtcbiAgICAgICAgICAgIHNpemUsXG4gICAgICAgICAgICBmcm9tLFxuICAgICAgICAgICAgc29ydDogW3sgc3luY190czogeyBvcmRlcjogJ2Rlc2MnIH0gfV0sXG4gICAgICAgICAgICBxdWVyeTogeyBtYXRjaF9hbGw6IHt9IH0sXG4gICAgICAgICAgfSxcbiAgICAgICAgfSk7XG4gICAgICAgIGNvbnN0IGhpdHMgPSAocmVzcG9uc2UuYm9keSBhcyBhbnkpPy5oaXRzID8/IHt9O1xuICAgICAgICByZXR1cm4gcmVzLm9rKHsgYm9keTogeyBoaXRzOiBoaXRzLmhpdHMgPz8gW10sIHRvdGFsOiBoaXRzLnRvdGFsLCBzb3VyY2U6ICdpbmRleCcgfSB9KTtcbiAgICAgIH0gY2F0Y2ggKGVycjogYW55KSB7XG4gICAgICAgIHJldHVybiByZXMuY3VzdG9tRXJyb3Ioe1xuICAgICAgICAgIHN0YXR1c0NvZGU6IGVyci5zdGF0dXNDb2RlID8/IDUwMCxcbiAgICAgICAgICBib2R5OiBlcnIubWVzc2FnZSA/PyBTdHJpbmcoZXJyKSxcbiAgICAgICAgfSk7XG4gICAgICB9XG4gICAgfVxuICApO1xuXG4gIHJvdXRlci5nZXQoXG4gICAge1xuICAgICAgcGF0aDogJy9hcGkvZGVmZW5kZXJfcGx1Z2luL2luY2lkZW50cy9saXZlJyxcbiAgICAgIHZhbGlkYXRlOiB7XG4gICAgICAgIHF1ZXJ5OiBzY2hlbWEub2JqZWN0KHtcbiAgICAgICAgICB0b3A6IHNjaGVtYS5tYXliZShzY2hlbWEubnVtYmVyKCkpLFxuICAgICAgICB9KSxcbiAgICAgIH0sXG4gICAgfSxcbiAgICBhc3luYyAoX2NvbnRleHQsIHJlcSwgcmVzKSA9PiB7XG4gICAgICBjb25zdCBjb25maWcgPSBnZXRHcmFwaFNlY3VyaXR5Q29uZmlnKCk7XG4gICAgICBpZiAoIWNvbmZpZykge1xuICAgICAgICByZXR1cm4gcmVzLmN1c3RvbUVycm9yKHtcbiAgICAgICAgICBzdGF0dXNDb2RlOiA1MDMsXG4gICAgICAgICAgYm9keTogJ0dyYXBoIHNlY3VyaXR5IG5vdCBjb25maWd1cmVkLicsXG4gICAgICAgIH0pO1xuICAgICAgfVxuICAgICAgdHJ5IHtcbiAgICAgICAgY29uc3QgdG9wID0gKHJlcS5xdWVyeSBhcyB7IHRvcD86IG51bWJlciB9KS50b3AgPz8gMjU7XG4gICAgICAgIGNvbnN0IGRhdGEgPSBhd2FpdCBsaXN0SW5jaWRlbnRzKGNvbmZpZywgdG9wKTtcbiAgICAgICAgcmV0dXJuIHJlcy5vayh7IGJvZHk6IGRhdGEgfSk7XG4gICAgICB9IGNhdGNoIChlcnI6IHVua25vd24pIHtcbiAgICAgICAgY29uc3QgeyBzdGF0dXMsIGJvZHkgfSA9IG1hcEdyYXBoRXJyKGVycik7XG4gICAgICAgIHJldHVybiByZXMuY3VzdG9tRXJyb3IoeyBzdGF0dXNDb2RlOiBzdGF0dXMsIGJvZHkgfSk7XG4gICAgICB9XG4gICAgfVxuICApO1xuXG4gIHJvdXRlci5nZXQoXG4gICAge1xuICAgICAgcGF0aDogJy9hcGkvZGVmZW5kZXJfcGx1Z2luL2FsZXJ0cy9saXZlJyxcbiAgICAgIHZhbGlkYXRlOiB7XG4gICAgICAgIHF1ZXJ5OiBzY2hlbWEub2JqZWN0KHtcbiAgICAgICAgICB0b3A6IHNjaGVtYS5tYXliZShzY2hlbWEubnVtYmVyKCkpLFxuICAgICAgICB9KSxcbiAgICAgIH0sXG4gICAgfSxcbiAgICBhc3luYyAoX2NvbnRleHQsIHJlcSwgcmVzKSA9PiB7XG4gICAgICBjb25zdCBjb25maWcgPSBnZXRHcmFwaFNlY3VyaXR5Q29uZmlnKCk7XG4gICAgICBpZiAoIWNvbmZpZykge1xuICAgICAgICByZXR1cm4gcmVzLmN1c3RvbUVycm9yKHtcbiAgICAgICAgICBzdGF0dXNDb2RlOiA1MDMsXG4gICAgICAgICAgYm9keTogJ0dyYXBoIHNlY3VyaXR5IG5vdCBjb25maWd1cmVkLicsXG4gICAgICAgIH0pO1xuICAgICAgfVxuICAgICAgdHJ5IHtcbiAgICAgICAgY29uc3QgdG9wID0gKHJlcS5xdWVyeSBhcyB7IHRvcD86IG51bWJlciB9KS50b3AgPz8gMjU7XG4gICAgICAgIGNvbnN0IGRhdGEgPSBhd2FpdCBsaXN0QWxlcnRzVjIoY29uZmlnLCB0b3ApO1xuICAgICAgICByZXR1cm4gcmVzLm9rKHsgYm9keTogZGF0YSB9KTtcbiAgICAgIH0gY2F0Y2ggKGVycjogdW5rbm93bikge1xuICAgICAgICBjb25zdCB7IHN0YXR1cywgYm9keSB9ID0gbWFwR3JhcGhFcnIoZXJyKTtcbiAgICAgICAgcmV0dXJuIHJlcy5jdXN0b21FcnJvcih7IHN0YXR1c0NvZGU6IHN0YXR1cywgYm9keSB9KTtcbiAgICAgIH1cbiAgICB9XG4gICk7XG5cbiAgcm91dGVyLnBvc3QoXG4gICAge1xuICAgICAgcGF0aDogJy9hcGkvZGVmZW5kZXJfcGx1Z2luL2h1bnRpbmcnLFxuICAgICAgdmFsaWRhdGU6IHtcbiAgICAgICAgYm9keTogc2NoZW1hLm9iamVjdCh7XG4gICAgICAgICAgcXVlcnk6IHNjaGVtYS5zdHJpbmcoKSxcbiAgICAgICAgICB0aW1lc3Bhbjogc2NoZW1hLm1heWJlKHNjaGVtYS5zdHJpbmcoKSksXG4gICAgICAgIH0pLFxuICAgICAgfSxcbiAgICB9LFxuICAgIGFzeW5jIChfY29udGV4dCwgcmVxLCByZXMpID0+IHtcbiAgICAgIGNvbnN0IGNvbmZpZyA9IGdldEdyYXBoU2VjdXJpdHlDb25maWcoKTtcbiAgICAgIGlmICghY29uZmlnKSB7XG4gICAgICAgIHJldHVybiByZXMuY3VzdG9tRXJyb3Ioe1xuICAgICAgICAgIHN0YXR1c0NvZGU6IDUwMyxcbiAgICAgICAgICBib2R5OiAnR3JhcGggc2VjdXJpdHkgbm90IGNvbmZpZ3VyZWQuJyxcbiAgICAgICAgfSk7XG4gICAgICB9XG4gICAgICB0cnkge1xuICAgICAgICBjb25zdCB7IHF1ZXJ5LCB0aW1lc3BhbiB9ID0gcmVxLmJvZHkgYXMgeyBxdWVyeTogc3RyaW5nOyB0aW1lc3Bhbj86IHN0cmluZyB9O1xuICAgICAgICBjb25zdCBzdGFydGVkID0gRGF0ZS5ub3coKTtcbiAgICAgICAgY29uc3QgZGF0YSA9IGF3YWl0IHJ1bkh1bnRpbmdRdWVyeShjb25maWcsIHF1ZXJ5LCB0aW1lc3BhbiB8fCAnUDdEJyk7XG4gICAgICAgIGNvbnN0IHJvd0NvdW50ID0gQXJyYXkuaXNBcnJheSgoZGF0YSBhcyBhbnkpPy5yZXN1bHRzKVxuICAgICAgICAgID8gKGRhdGEgYXMgYW55KS5yZXN1bHRzLmxlbmd0aFxuICAgICAgICAgIDogMDtcbiAgICAgICAgcmV0dXJuIHJlcy5vayh7XG4gICAgICAgICAgYm9keToge1xuICAgICAgICAgICAgLi4uKChkYXRhIGFzIG9iamVjdCkgfHwge30pLFxuICAgICAgICAgICAgZXhlY3V0aW9uVGltZU1zOiBEYXRlLm5vdygpIC0gc3RhcnRlZCxcbiAgICAgICAgICAgIHJvd0NvdW50LFxuICAgICAgICAgIH0sXG4gICAgICAgIH0pO1xuICAgICAgfSBjYXRjaCAoZXJyOiB1bmtub3duKSB7XG4gICAgICAgIGNvbnN0IHsgc3RhdHVzLCBib2R5IH0gPSBtYXBHcmFwaEVycihlcnIpO1xuICAgICAgICByZXR1cm4gcmVzLmN1c3RvbUVycm9yKHsgc3RhdHVzQ29kZTogc3RhdHVzLCBib2R5IH0pO1xuICAgICAgfVxuICAgIH1cbiAgKTtcblxuICByb3V0ZXIuZ2V0KFxuICAgIHtcbiAgICAgIHBhdGg6ICcvYXBpL2RlZmVuZGVyX3BsdWdpbi9pbmRpY2F0b3JzL2xpdmUnLFxuICAgICAgdmFsaWRhdGU6IHtcbiAgICAgICAgcXVlcnk6IHNjaGVtYS5vYmplY3Qoe1xuICAgICAgICAgIHRvcDogc2NoZW1hLm1heWJlKHNjaGVtYS5udW1iZXIoKSksXG4gICAgICAgIH0pLFxuICAgICAgfSxcbiAgICB9LFxuICAgIGFzeW5jIChfY29udGV4dCwgcmVxLCByZXMpID0+IHtcbiAgICAgIGNvbnN0IGNvbmZpZyA9IGdldE1kZUNvbmZpZygpO1xuICAgICAgaWYgKCFjb25maWcpIHtcbiAgICAgICAgcmV0dXJuIHJlcy5jdXN0b21FcnJvcih7IHN0YXR1c0NvZGU6IDUwMywgYm9keTogJ01ERSBub3QgY29uZmlndXJlZC4nIH0pO1xuICAgICAgfVxuICAgICAgdHJ5IHtcbiAgICAgICAgY29uc3QgdG9wID0gKHJlcS5xdWVyeSBhcyB7IHRvcD86IG51bWJlciB9KS50b3AgPz8gMTAwO1xuICAgICAgICBjb25zdCBkYXRhID0gYXdhaXQgbGlzdEluZGljYXRvcnMoY29uZmlnLCB0b3ApO1xuICAgICAgICByZXR1cm4gcmVzLm9rKHsgYm9keTogZGF0YSB9KTtcbiAgICAgIH0gY2F0Y2ggKGVycjogYW55KSB7XG4gICAgICAgIHJldHVybiByZXMuY3VzdG9tRXJyb3IoeyBzdGF0dXNDb2RlOiBtZGVFcnJvclN0YXR1cyhlcnIpLCBib2R5OiBlcnI/Lm1lc3NhZ2UgPz8gU3RyaW5nKGVycikgfSk7XG4gICAgICB9XG4gICAgfVxuICApO1xuXG4gIHJvdXRlci5nZXQoXG4gICAge1xuICAgICAgcGF0aDogJy9hcGkvZGVmZW5kZXJfcGx1Z2luL2F1ZGl0LWxvZycsXG4gICAgICB2YWxpZGF0ZToge1xuICAgICAgICBxdWVyeTogc2NoZW1hLm9iamVjdCh7XG4gICAgICAgICAgc2l6ZTogc2NoZW1hLm1heWJlKHNjaGVtYS5udW1iZXIoKSksXG4gICAgICAgIH0pLFxuICAgICAgfSxcbiAgICB9LFxuICAgIGFzeW5jIChjb250ZXh0LCByZXEsIHJlcykgPT4ge1xuICAgICAgdHJ5IHtcbiAgICAgICAgY29uc3QgY2xpZW50ID0gZ2V0Q2xpZW50KGNvbnRleHQpO1xuICAgICAgICBjb25zdCBzaXplID0gKHJlcS5xdWVyeSBhcyB7IHNpemU/OiBudW1iZXIgfSkuc2l6ZSA/PyA1MDtcbiAgICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBjbGllbnQuc2VhcmNoKHtcbiAgICAgICAgICBpbmRleDogREVGRU5ERVJfQVVESVRfTE9HX0lOREVYLFxuICAgICAgICAgIGlnbm9yZV91bmF2YWlsYWJsZTogdHJ1ZSxcbiAgICAgICAgICBib2R5OiB7XG4gICAgICAgICAgICBzaXplLFxuICAgICAgICAgICAgc29ydDogW3sgdGltZXN0YW1wOiB7IG9yZGVyOiAnZGVzYycgfSB9XSxcbiAgICAgICAgICAgIHF1ZXJ5OiB7IG1hdGNoX2FsbDoge30gfSxcbiAgICAgICAgICB9LFxuICAgICAgICB9KTtcbiAgICAgICAgY29uc3QgaGl0cyA9IChyZXNwb25zZS5ib2R5IGFzIGFueSk/LmhpdHM/LmhpdHMgPz8gW107XG4gICAgICAgIHJldHVybiByZXMub2soeyBib2R5OiB7IGVudHJpZXM6IGhpdHMubWFwKChoOiBhbnkpID0+IGguX3NvdXJjZSkgfSB9KTtcbiAgICAgIH0gY2F0Y2ggKGVycjogYW55KSB7XG4gICAgICAgIHJldHVybiByZXMuY3VzdG9tRXJyb3Ioe1xuICAgICAgICAgIHN0YXR1c0NvZGU6IGVyci5zdGF0dXNDb2RlID8/IDUwMCxcbiAgICAgICAgICBib2R5OiBlcnIubWVzc2FnZSA/PyBTdHJpbmcoZXJyKSxcbiAgICAgICAgfSk7XG4gICAgICB9XG4gICAgfVxuICApO1xuXG4gIHJvdXRlci5wb3N0KFxuICAgIHtcbiAgICAgIHBhdGg6ICcvYXBpL2RlZmVuZGVyX3BsdWdpbi9hbGVydHNfZW5yaWNobWVudCcsXG4gICAgICB2YWxpZGF0ZToge1xuICAgICAgICBib2R5OiBzY2hlbWEub2JqZWN0KHtcbiAgICAgICAgICBzaXplOiBzY2hlbWEubWF5YmUoc2NoZW1hLm51bWJlcigpKSxcbiAgICAgICAgICBmcm9tOiBzY2hlbWEubWF5YmUoc2NoZW1hLm51bWJlcigpKSxcbiAgICAgICAgICB0aW1lX2Zyb206IHNjaGVtYS5tYXliZShzY2hlbWEuc3RyaW5nKCkpLFxuICAgICAgICAgIHRpbWVfdG86IHNjaGVtYS5tYXliZShzY2hlbWEuc3RyaW5nKCkpLFxuICAgICAgICAgIGRlZmVuZGVyX2NvcnJlbGF0ZWRfb25seTogc2NoZW1hLm1heWJlKHNjaGVtYS5ib29sZWFuKCkpLFxuICAgICAgICB9KSxcbiAgICAgIH0sXG4gICAgfSxcbiAgICBhc3luYyAoY29udGV4dCwgcmVxLCByZXMpID0+IHtcbiAgICAgIHRyeSB7XG4gICAgICAgIGNvbnN0IGNsaWVudCA9IGdldENsaWVudChjb250ZXh0KTtcbiAgICAgICAgY29uc3Qge1xuICAgICAgICAgIHNpemUgPSAyNSxcbiAgICAgICAgICBmcm9tID0gMCxcbiAgICAgICAgICB0aW1lX2Zyb20sXG4gICAgICAgICAgdGltZV90byxcbiAgICAgICAgICBkZWZlbmRlcl9jb3JyZWxhdGVkX29ubHkgPSB0cnVlLFxuICAgICAgICB9ID0gcmVxLmJvZHk7XG5cbiAgICAgICAgY29uc3Qgbm93ID0gbmV3IERhdGUoKTtcbiAgICAgICAgY29uc3QgZGVmYXVsdFRvID0gbm93LnRvSVNPU3RyaW5nKCk7XG4gICAgICAgIGNvbnN0IGRlZmF1bHRGcm9tID0gbmV3IERhdGUobm93LmdldFRpbWUoKSAtIDcgKiAyNCAqIDYwICogNjAgKiAxMDAwKS50b0lTT1N0cmluZygpO1xuICAgICAgICBjb25zdCB0aW1lR3RlID0gdGltZV9mcm9tIHx8IGRlZmF1bHRGcm9tO1xuICAgICAgICBjb25zdCB0aW1lTHRlID0gdGltZV90byB8fCBkZWZhdWx0VG87XG4gICAgICAgIGNvbnN0IHRpbWVSYW5nZUZpbHRlciA9IHsgcmFuZ2U6IHsgdGltZXN0YW1wOiB7IGd0ZTogdGltZUd0ZSwgbHRlOiB0aW1lTHRlIH0gfSB9O1xuXG4gICAgICAgIGxldCBhZ2VudElkc1RvUXVlcnk6IHN0cmluZ1tdIHwgbnVsbCA9IG51bGw7XG4gICAgICAgIGNvbnN0IGFnZW50VG9EZWZlbmRlcjogUmVjb3JkPHN0cmluZywgc3RyaW5nPiA9IHt9O1xuXG4gICAgICAgIGlmIChkZWZlbmRlcl9jb3JyZWxhdGVkX29ubHkpIHtcbiAgICAgICAgICBjb25zdCBpZGVudGl0eVJlcyA9IGF3YWl0IGNsaWVudC5zZWFyY2goe1xuICAgICAgICAgICAgaW5kZXg6IERFRkVOREVSX01BQ0hJTkVfSURFTlRJVFlfSU5ERVgsXG4gICAgICAgICAgICBpZ25vcmVfdW5hdmFpbGFibGU6IHRydWUsXG4gICAgICAgICAgICBib2R5OiB7XG4gICAgICAgICAgICAgIHNpemU6IDEwMDAsXG4gICAgICAgICAgICAgIF9zb3VyY2U6IFsnd2F6dWhfYWdlbnRfaWQnLCAnZGVmZW5kZXJfbWFjaGluZV9pZCcsICdjb21wdXRlcl9kbnNfbmFtZSddLFxuICAgICAgICAgICAgICBxdWVyeTogeyBtYXRjaF9hbGw6IHt9IH0sXG4gICAgICAgICAgICB9LFxuICAgICAgICAgIH0pO1xuICAgICAgICAgIGNvbnN0IGlkZW50aXR5SGl0cyA9IChpZGVudGl0eVJlcy5ib2R5IGFzIGFueSk/LmhpdHM/LmhpdHMgPz8gW107XG4gICAgICAgICAgYWdlbnRJZHNUb1F1ZXJ5ID0gaWRlbnRpdHlIaXRzXG4gICAgICAgICAgICAubWFwKChoOiBhbnkpID0+IGguX3NvdXJjZT8ud2F6dWhfYWdlbnRfaWQpXG4gICAgICAgICAgICAuZmlsdGVyKChpZDogc3RyaW5nKSA9PiBpZCAmJiBpZCAhPT0gJzAwMCcpO1xuICAgICAgICAgIGlmIChhZ2VudElkc1RvUXVlcnkubGVuZ3RoID09PSAwKSB7XG4gICAgICAgICAgICByZXR1cm4gcmVzLm9rKHtcbiAgICAgICAgICAgICAgYm9keToge1xuICAgICAgICAgICAgICAgIGFsZXJ0czogW10sXG4gICAgICAgICAgICAgICAgZW5yaWNobWVudHM6IHt9LFxuICAgICAgICAgICAgICAgIHRvdGFsOiAwLFxuICAgICAgICAgICAgICAgIGlkZW50aXR5X2NvdW50OiAwLFxuICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgfSk7XG4gICAgICAgICAgfVxuICAgICAgICAgIGlkZW50aXR5SGl0cy5mb3JFYWNoKChoOiBhbnkpID0+IHtcbiAgICAgICAgICAgIGNvbnN0IHMgPSBoLl9zb3VyY2U7XG4gICAgICAgICAgICBpZiAocz8ud2F6dWhfYWdlbnRfaWQpIGFnZW50VG9EZWZlbmRlcltzLndhenVoX2FnZW50X2lkXSA9IHMuZGVmZW5kZXJfbWFjaGluZV9pZDtcbiAgICAgICAgICB9KTtcbiAgICAgICAgfVxuXG4gICAgICAgIGNvbnN0IG11c3Q6IGFueVtdID0gW3RpbWVSYW5nZUZpbHRlcl07XG4gICAgICAgIG11c3QucHVzaCh7IGJvb2w6IHsgbXVzdF9ub3Q6IFt7IHRlcm06IHsgJ2FnZW50LmlkJzogJzAwMCcgfSB9XSB9IH0pO1xuICAgICAgICBpZiAoYWdlbnRJZHNUb1F1ZXJ5ICYmIGFnZW50SWRzVG9RdWVyeS5sZW5ndGggPiAwKSB7XG4gICAgICAgICAgbXVzdC5wdXNoKHsgdGVybXM6IHsgJ2FnZW50LmlkJzogYWdlbnRJZHNUb1F1ZXJ5IH0gfSk7XG4gICAgICAgIH1cblxuICAgICAgICBjb25zdCBhbGVydHNCb2R5ID0ge1xuICAgICAgICAgIGZyb20sXG4gICAgICAgICAgc2l6ZSxcbiAgICAgICAgICBzb3J0OiBbeyB0aW1lc3RhbXA6IHsgb3JkZXI6ICdkZXNjJyB9IH1dLFxuICAgICAgICAgIF9zb3VyY2U6IFsnYWdlbnQuaWQnLCAnYWdlbnQubmFtZScsICdydWxlLmRlc2NyaXB0aW9uJywgJ3J1bGUubGV2ZWwnLCAndGltZXN0YW1wJ10sXG4gICAgICAgICAgcXVlcnk6IHsgYm9vbDogeyBtdXN0IH0gfSxcbiAgICAgICAgfTtcblxuICAgICAgICBjb25zdCBbYWxlcnRzUmVzcG9uc2UsIGNvdW50UmVzcG9uc2VdID0gYXdhaXQgUHJvbWlzZS5hbGwoW1xuICAgICAgICAgIGNsaWVudC5zZWFyY2goe1xuICAgICAgICAgICAgaW5kZXg6IFdBWlVIX0FMRVJUU19QQVRURVJOLFxuICAgICAgICAgICAgaWdub3JlX3VuYXZhaWxhYmxlOiB0cnVlLFxuICAgICAgICAgICAgYm9keTogYWxlcnRzQm9keSxcbiAgICAgICAgICB9KSxcbiAgICAgICAgICBjbGllbnQuc2VhcmNoKHtcbiAgICAgICAgICAgIGluZGV4OiBXQVpVSF9BTEVSVFNfUEFUVEVSTixcbiAgICAgICAgICAgIGlnbm9yZV91bmF2YWlsYWJsZTogdHJ1ZSxcbiAgICAgICAgICAgIGJvZHk6IHtcbiAgICAgICAgICAgICAgc2l6ZTogMCxcbiAgICAgICAgICAgICAgcXVlcnk6IGFsZXJ0c0JvZHkucXVlcnksXG4gICAgICAgICAgICAgIHRyYWNrX3RvdGFsX2hpdHM6IHRydWUsXG4gICAgICAgICAgICB9LFxuICAgICAgICAgIH0pLFxuICAgICAgICBdKTtcblxuICAgICAgICBjb25zdCBhbGVydEhpdHMgPSAoYWxlcnRzUmVzcG9uc2UuYm9keSBhcyBhbnkpPy5oaXRzPy5oaXRzID8/IFtdO1xuICAgICAgICBjb25zdCB0b3RhbCA9XG4gICAgICAgICAgKGNvdW50UmVzcG9uc2UuYm9keSBhcyBhbnkpPy5oaXRzPy50b3RhbD8udmFsdWUgPz9cbiAgICAgICAgICAoY291bnRSZXNwb25zZS5ib2R5IGFzIGFueSk/LmhpdHM/LnRvdGFsID8/XG4gICAgICAgICAgYWxlcnRIaXRzLmxlbmd0aDtcblxuICAgICAgICBjb25zdCBlbnJpY2htZW50czogUmVjb3JkPHN0cmluZywgeyBkZWZlbmRlcl9tYWNoaW5lX2lkPzogc3RyaW5nIH0+ID0ge307XG4gICAgICAgIGFsZXJ0SGl0cy5mb3JFYWNoKChoOiBhbnkpID0+IHtcbiAgICAgICAgICBjb25zdCBhaWQgPSBoLl9zb3VyY2U/LmFnZW50Py5pZDtcbiAgICAgICAgICBpZiAoYWlkICYmIGFnZW50VG9EZWZlbmRlclthaWRdKSB7XG4gICAgICAgICAgICBlbnJpY2htZW50c1toLl9pZF0gPSB7IGRlZmVuZGVyX21hY2hpbmVfaWQ6IGFnZW50VG9EZWZlbmRlclthaWRdIH07XG4gICAgICAgICAgfVxuICAgICAgICB9KTtcblxuICAgICAgICByZXR1cm4gcmVzLm9rKHtcbiAgICAgICAgICBib2R5OiB7XG4gICAgICAgICAgICBhbGVydHM6IGFsZXJ0SGl0cy5tYXAoKGg6IGFueSkgPT4gKHtcbiAgICAgICAgICAgICAgaWQ6IGguX2lkLFxuICAgICAgICAgICAgICAuLi5oLl9zb3VyY2UsXG4gICAgICAgICAgICB9KSksXG4gICAgICAgICAgICBlbnJpY2htZW50cyxcbiAgICAgICAgICAgIHRvdGFsLFxuICAgICAgICAgICAgaWRlbnRpdHlfY291bnQ6IE9iamVjdC5rZXlzKGFnZW50VG9EZWZlbmRlcikubGVuZ3RoLFxuICAgICAgICAgIH0sXG4gICAgICAgIH0pO1xuICAgICAgfSBjYXRjaCAoZXJyOiBhbnkpIHtcbiAgICAgICAgcmV0dXJuIHJlcy5jdXN0b21FcnJvcih7XG4gICAgICAgICAgc3RhdHVzQ29kZTogZXJyLnN0YXR1c0NvZGUgPz8gNTAwLFxuICAgICAgICAgIGJvZHk6IGVyci5tZXNzYWdlID8/IFN0cmluZyhlcnIpLFxuICAgICAgICB9KTtcbiAgICAgIH1cbiAgICB9XG4gICk7XG59XG4iXSwibWFwcGluZ3MiOiI7Ozs7OztBQUtBLElBQUFBLGFBQUEsR0FBQUMsT0FBQTtBQUNBLElBQUFDLFVBQUEsR0FBQUQsT0FBQTtBQVNBLElBQUFFLFVBQUEsR0FBQUYsT0FBQTtBQWdCQSxJQUFBRyxvQkFBQSxHQUFBSCxPQUFBO0FBL0JBO0FBQ0E7QUFDQTs7QUFzQ0EsU0FBU0ksV0FBV0EsQ0FBQ0MsR0FBWSxFQUFvQztFQUNuRSxJQUFJQSxHQUFHLFlBQVlGLG9CQUFBLENBQUFHLGFBQWEsRUFBRTtJQUNoQyxPQUFPO01BQUVDLE1BQU0sRUFBRUYsR0FBRyxDQUFDRSxNQUFNLElBQUksR0FBRyxJQUFJRixHQUFHLENBQUNFLE1BQU0sR0FBRyxHQUFHLEdBQUdGLEdBQUcsQ0FBQ0UsTUFBTSxHQUFHLEdBQUc7TUFBRUMsSUFBSSxFQUFFSCxHQUFHLENBQUNJO0lBQVEsQ0FBQztFQUNoRztFQUNBLE9BQU87SUFBRUYsTUFBTSxFQUFFLEdBQUc7SUFBRUMsSUFBSSxFQUFFSCxHQUFHLFlBQVlLLEtBQUssR0FBR0wsR0FBRyxDQUFDSSxPQUFPLEdBQUdFLE1BQU0sQ0FBQ04sR0FBRztFQUFFLENBQUM7QUFDaEY7QUFFQSxTQUFTTyxtQkFBbUJBLENBQUNDLENBQTBCLEVBQUVDLFFBQWdCLEVBQUU7RUFDekUsT0FBTztJQUNMQyxTQUFTLEVBQUVELFFBQVE7SUFDbkJFLFVBQVUsRUFBRUgsQ0FBQyxDQUFDSSxFQUFFO0lBQ2hCQyxpQkFBaUIsRUFBRUwsQ0FBQyxDQUFDTSxlQUFlLElBQUksRUFBRTtJQUMxQ0MsV0FBVyxFQUFFUCxDQUFDLENBQUNRLFVBQVUsSUFBSSxFQUFFO0lBQy9CQyxVQUFVLEVBQUVULENBQUMsQ0FBQ1UsU0FBUyxJQUFJLEVBQUU7SUFDN0JDLFNBQVMsRUFBRVgsQ0FBQyxDQUFDWSxRQUFRLElBQUksSUFBSTtJQUM3QkMsVUFBVSxFQUFFYixDQUFDLENBQUNjLFNBQVMsSUFBSSxJQUFJO0lBQy9CQyxhQUFhLEVBQUVmLENBQUMsQ0FBQ2dCLFdBQVcsSUFBSSxFQUFFO0lBQ2xDQyxVQUFVLEVBQUVqQixDQUFDLENBQUNrQixTQUFTLElBQUksSUFBSSxHQUFHcEIsTUFBTSxDQUFDRSxDQUFDLENBQUNrQixTQUFTLENBQUMsR0FBRyxFQUFFO0lBQzFEQyxjQUFjLEVBQUVuQixDQUFDLENBQUNvQixhQUFhLElBQUksRUFBRTtJQUNyQ0MsaUJBQWlCLEVBQUVyQixDQUFDLENBQUNzQixnQkFBZ0IsSUFBSXRCLENBQUMsQ0FBQ3VCLGdCQUFnQixJQUFJLEVBQUU7SUFDakVDLGFBQWEsRUFBRXhCLENBQUMsQ0FBQ3lCLFlBQVksSUFBSSxFQUFFO0lBQ25DQyxnQkFBZ0IsRUFBRTFCLENBQUMsQ0FBQzJCLGVBQWUsSUFBSSxFQUFFO0lBQ3pDQyxlQUFlLEVBQUU1QixDQUFDLENBQUM2QixhQUFhLElBQUksRUFBRTtJQUN0Q0MsZUFBZSxFQUFFOUIsQ0FBQyxDQUFDK0IsYUFBYSxJQUFJO0VBQ3RDLENBQUM7QUFDSDtBQUVBLFNBQVNDLFNBQVNBLENBQUNDLE9BQVksRUFBRTtFQUMvQixPQUFPQSxPQUFPLENBQUNDLElBQUksQ0FBQ0MsVUFBVSxDQUFDQyxNQUFNLENBQUNDLGFBQWE7QUFDckQ7QUFFTyxTQUFTQyw0QkFBNEJBLENBQUNDLE1BQWUsRUFBRTtFQUM1REEsTUFBTSxDQUFDQyxHQUFHLENBQUM7SUFBRUMsSUFBSSxFQUFFO0lBQStCQyxRQUFRLEVBQUU7RUFBTSxDQUFDLEVBQUUsT0FBT0MsUUFBUSxFQUFFQyxJQUFJLEVBQUVDLEdBQUcsS0FBSztJQUNsRyxNQUFNQyxHQUFHLEdBQUcsQ0FBQyxDQUFDLElBQUF6RCxVQUFBLENBQUEwRCxZQUFZLEVBQUMsQ0FBQztJQUM1QixNQUFNQyxLQUFLLEdBQUcsQ0FBQyxDQUFDLElBQUExRCxvQkFBQSxDQUFBMkQsc0JBQXNCLEVBQUMsQ0FBQztJQUN4QyxNQUFBQyxTQUFjLEdBQUFDLE9BQUEsQ0FBQUMsR0FBQSxDQUFBQyxTQUFBO1VBQ1JDLFNBQUUsR0FBQUgsT0FBQSxDQUFBQyxHQUFBLENBQUFHLFNBQUE7VUFDRkMsU0FBUyxHQUFBTCxPQUFLLENBQUFDLEdBQUEsQ0FBQUssU0FBQTtVQUNoQkMsbUJBQW1CLEdBQUFQLE9BQUEsQ0FBQUMsR0FBQSxDQUFBTyxtQkFBQTtVQUNuQkMsZUFBQSxNQUFBVixTQUFnQyxJQUFBUSxtQkFBQTtXQUNoQ2IsR0FBQSxDQUFBZ0IsRUFBUztNQUNYbEUsSUFBQTtRQUNBa0UsRUFBQSxFQUFBZixHQUFBLElBQUFFLEtBQUE7UUFDRmMsY0FBQSxFQUFBaEIsR0FBQTtRQUVJaUIseUJBQ0osRUFBQWYsS0FBQTtRQUNNWSxlQUFFO1FBQ05JLFlBQVUsR0FBQUosZUFBQTtRQUNSVixTQUFPO1FBQ0xJLFNBQU07UUFDTkUsU0FBTTtRQUNORSxtQkFBYTtRQUNiTyxTQUFBLE1BQWNDLElBQUUsR0FBQUMsV0FBQTs7TUFFbEI7SUFDRjtFQUNGNUIsTUFDQSxDQUFBQyxHQUFPO0lBQ0xDLElBQUEsRUFBTSx3QkFNTDtJQUNEQyxRQUFNO01BQ0owQixLQUFBLEVBQU1sRixhQUFPLENBQUFtRixNQUFBLENBQUFDLE1BQUE7UUFDYkMsSUFBSyxFQUFBckYsYUFBTSxDQUFBbUYsTUFBQSxDQUFBRyxLQUFBLENBQUF0RixhQUFBLENBQUFtRixNQUFBLENBQUFJLE1BQUE7UUFDVEMsSUFBQSxFQUFBeEYsYUFBVyxDQUFBbUYsTUFBWSxDQUFBRyxLQUFBLENBQUF0RixhQUFBLENBQUFtRixNQUFBLENBQUFJLE1BQUE7bUJBQUUsRUFBVXZGLGFBQUssQ0FBQW1GLE1BQUEsQ0FBQUcsS0FBQSxDQUFBdEYsYUFBQSxDQUFBbUYsTUFBQSxDQUFBTSxNQUFBO3NCQUFRLEVBQUF6RixhQUFBLENBQUFtRixNQUFBLENBQUFHLEtBQUEsQ0FBQXRGLGFBQUEsQ0FBQW1GLE1BQUEsQ0FBQU0sTUFBQTtRQUFzQkMsTUFBRSxFQUFBMUYsYUFBQSxDQUFBbUYsTUFBQSxDQUFBRyxLQUFBLENBQUF0RixhQUFBLENBQUFtRixNQUFBLENBQUFNLE1BQUE7TUFDMUU7O1lBQ0kxQyxPQUFBLEVBQUE0QyxHQUFBLEVBQUFoQyxHQUFBO1VBQ0ZpQyxDQUFBLEdBQU1ELEdBQUcsQ0FBQVQsS0FBRztRQUNaVSxDQUFBLENBQUFGLE1BQU0sV0FBVyxFQUFJO1lBQ2pCRyxJQUFJLEdBQUcsSUFBSTFGLFVBQVcsQ0FBQTBELFlBQUE7VUFDMUIsQ0FBQWdDLElBQU07ZUFDQWxDLEdBQUcsQ0FBQW1DLFdBQWM7VUFDdkJDLFVBQUE7VUFDQXRGLElBQU07VUFDSjs7VUFFRjtZQUNFdUYsT0FBUSxFQUFHQyxPQUFFO2NBQ2JDLEdBQU0sR0FBRSxNQUFLLElBQUEvRixVQUFnQixDQUFBZ0csdUJBQXlCLEVBQUNOLElBQUEsRUFBTyxFQUFFO2NBQ2hFOUUsUUFBWSxHQUFFOEUsSUFBQSxDQUFBOUUsUUFBQTtRQUNoQixJQUFFcUYsSUFBQSxHQUFBRixHQUFBLENBQUFHLEdBQUEsQ0FBQXZGLENBQUEsSUFBQUQsbUJBQUEsQ0FBQUMsQ0FBQSxFQUFBQyxRQUFBO1FBQ0YsSUFBQTZFLENBQUEsQ0FBTXZFLFdBQUk7VUFDVitFLElBQU0sR0FBQUEsSUFBSSxDQUFBRSxNQUFBLENBQUFDLENBQUEsSUFBSzNGLE1BQUksQ0FBQTJGLENBQUEsQ0FBQWxGLFdBQUEsTUFBQXVFLENBQUEsQ0FBQXZFLFdBQUE7UUFDbkI7UUFDQSxJQUFBdUUsQ0FBQSxDQUFNM0QsY0FBYSxFQUFHO1VBQWFtRSxJQUFBLEdBQU9BLElBQUUsQ0FBR0UsTUFBQSxDQUFBQyxDQUFBLElBQUEzRixNQUFBLENBQUEyRixDQUFBLENBQUF0RSxjQUFBLE1BQUEyRCxDQUFBLENBQUEzRCxjQUFBOztRQUFzQm1FLElBQUcsQ0FBQUksSUFBQSxFQUFBQyxDQUFBLEVBQUFDLENBQUE7VUFDeEUsTUFBT0MsRUFBRyxHQUFHRixDQUFDLENBQUFoRixTQUFBLE9BQUF1RCxJQUFBLENBQUFwRSxNQUFBLENBQUE2RixDQUFBLENBQUFoRixTQUFBLEdBQUFtRixPQUFBO1VBQ1osTUFBTUMsRUFBQSxHQUFBSCxDQUFBLENBQUFqRixTQUFBLE9BQUF1RCxJQUFBLENBQUFwRSxNQUFBLENBQUE4RixDQUFBLENBQUFqRixTQUFBLEdBQUFtRixPQUFBO2lCQUNBQyxFQUFBLEdBQUFGLEVBQUE7O2NBQ0tuQixJQUFBLEdBQU8sQ0FBQVEsT0FBSyxHQUFNSixDQUFBLENBQUFKLElBQUEsY0FBQVEsT0FBQSxjQUFBQSxPQUFBO2NBQUVYLElBQUEsSUFBUVksT0FBRSxHQUFBTCxDQUFBLENBQUFQLElBQUEsY0FBQVksT0FBQSxjQUFBQSxPQUFBO2NBQU1hLEtBQUEsR0FBQVYsSUFBQSxDQUFBVSxLQUFBLENBQUF0QixJQUFBLEVBQUFBLElBQUEsR0FBQUgsSUFBQTtjQUM3QzBCLElBQU0sR0FBRUQsS0FBQSxDQUFBVCxHQUFBLENBQUFXLEdBQUE7VUFDVkMsT0FBQSxFQUFBRCxHQUFBO1VBQ0FFLEdBQUEsRUFBQUYsR0FBQSxDQUFBL0Y7UUFDRjtRQUFpQixPQUFBMEMsR0FBQSxDQUFBZ0IsRUFBQTtVQUNqQmxFLElBQUEsRUFBTztZQUNMc0csSUFBQTtZQUNBSSxLQUFJO2NBQ0pDLEtBQUEsRUFBQWhCLElBQUEsQ0FBQWlCLE1BQUE7Y0FDSkMsUUFBQTtZQUNGO1lBQ0k1QixNQUFBO1VBQUE7UUFDRjtNQUNBLFNBQU1wRixHQUFBO1FBQUUsSUFBSWlILFlBQUs7UUFBRSxPQUFPNUQsR0FBQyxDQUFBbUMsV0FBQTtVQUFFQyxVQUFXLE1BQUE1RixVQUFBLENBQUFxSCxjQUFBLEVBQUFsSCxHQUFBO1VBQUVHLElBQUEsR0FBQThHLFlBQUEsR0FBQWpILEdBQUEsYUFBQUEsR0FBQSx1QkFBQUEsR0FBQSxDQUFBSSxPQUFBLGNBQUE2RyxZQUFBLGNBQUFBLFlBQUEsR0FBQTNHLE1BQUEsQ0FBQU4sR0FBQTtRQUFnQixFQUFHO01BQzdEOztRQUM2QjtVQUFRbUgsS0FBQSxFQUFBQyxjQUFBLEVBQUFDLFVBQUE7WUFBWXpFLE1BQUEsR0FBQUosU0FBQSxDQUFBQyxPQUFBO01BQUUsTUFBRTtRQUNyRHNDLElBQUk7UUFBNEJHLElBQUksR0FBRTttQkFBRTtRQUFldkQ7TUFBRSxDQUFDLEdBQUMyRCxDQUFBO01BQzNELE1BQU1nQyxJQUFBLEtBQVE7VUFDWnZHLFdBQU8sRUFBQXVHLElBQUEsQ0FBQUMsSUFBQTtRQUNQQyxJQUFBO1VBQ0F6Rzs7O1VBR0VZLGNBQU8sRUFBQTJGLElBQUEsQ0FBQUMsSUFBQTtZQUFFOzs7O1lBQWdERSxRQUFFLFNBQUE3RSxNQUFBLENBQUE4RSxNQUFBO2FBQUUsRUFBQTlILFVBQUEsQ0FBQStILHVCQUFtQjswQkFBUTtZQUN4RjtjQUF1QjtjQUFRO2NBQUs7WUFBR3hHLFNBQUc7Y0FBRXlHLEtBQUEsRUFBUyxNQUFHO2NBQUVDLE9BQUE7WUFDNUQ7VUFDQTtZQUNJaEgsaUJBQUk7VUFDVjtVQUFnQitELEtBQU0sRUFBQTBDLElBQUEsQ0FBQVAsTUFBQTtZQUFFZSxJQUFJO2NBQW1CUjtZQUFtQjtVQUFnQjtZQUFJUyxTQUFBO1VBQ3RGO1FBQWlCO01BQ2pCO1lBQ0V0QixJQUFBLEdBQVUsQ0FBQVUsS0FBQSxJQUFBQyxjQUFNLEdBQUFLLFFBQVUsQ0FBQXRILElBQUEsY0FBQWlILGNBQUEsdUJBQUFBLGNBQU8sQ0FBQVgsSUFBQSxjQUFBVSxLQUFBLGNBQUFBLEtBQUE7YUFDN0I5RCxHQUFBLENBQUFnQixFQUFBO1FBQ0psRSxJQUFBO1VBQ0pzRyxJQUFBLEdBQUFZLFVBQUEsR0FBQVosSUFBQSxDQUFBQSxJQUFBLGNBQUFZLFVBQUEsY0FBQUEsVUFBQTtVQUVIUixLQUFBLEVBQUFKLElBQUEsQ0FBQUksS0FBQTtVQUVNekIsTUFDTDtRQUNNO01BQ0o7TUFBWSxPQUFNcEYsR0FBRTtVQUFrQmdJLGVBQUUsRUFBQUMsYUFBYztNQUFFLE9BQUM1RSxHQUFBLENBQUFtQyxXQUFBO1FBQUVDLFVBQUEsR0FBQXVDLGVBQUEsR0FBQWhJLEdBQUEsQ0FBQXlGLFVBQUEsY0FBQXVDLGVBQUEsY0FBQUEsZUFBQTtRQUU3RDdILElBQU8sR0FBQThILGFBQWdCLEdBQUdqSSxHQUFBLENBQUFJLE9BQUssY0FBQTZILGFBQUEsY0FBQUEsYUFBQSxHQUFBM0gsTUFBQSxDQUFBTixHQUFBO01BQzdCO0lBQ0E7O1FBRUksQ0FBQWdELEdBQUE7UUFDQSxvQ0FBTTtZQUNOO01BQ0prRixNQUFBLEVBQUF4SSxhQUFBLENBQUFtRixNQUFBLENBQUFDLE1BQUE7UUFDSWxFLEVBQUEsRUFBQWxCLGFBQUEsQ0FBQW1GLE1BQUEsQ0FBQU0sTUFBQTtNQUNGOztZQUVBaEMsUUFBYyxFQUFBQyxJQUFBLEVBQUFDLEdBQUE7VUFBRThFLE1BQU0sT0FBQXRJLFVBQUEsQ0FBQTBELFlBQUE7UUFBTyxDQUFBNEUsTUFBQTtNQUM3QixPQUFPOUUsR0FBUSxDQUFBbUMsV0FBRTtRQUFBQyxVQUFBO1FBQ2pCdEYsSUFBQSxFQUFPO1FBQ0w7O1FBRUE7TUFDSixNQUFBUyxFQUFBLEdBQUF3QyxJQUFBLENBQUE4RSxNQUFBLENBQUF0SCxFQUFBO01BRUgsTUFBQXdILElBQUEsYUFBQXZJLFVBQUEsQ0FBQXdJLFVBQUEsRUFBQUYsTUFBQSxFQUFBdkgsRUFBQTtNQUVELE9BQU15QyxHQUFBLENBQUFnQixFQUFBO1FBQ0psRSxJQUFPLEVBQUdpSTtNQUVOO01BQ0EsT0FBQXBJLEdBQVU7VUFBRXNJLGFBQVE7YUFBa0JqRixHQUFFLENBQUFtQyxXQUFBO1FBQWdCQyxVQUFDLE1BQUE1RixVQUFBLENBQUFxSCxjQUFBLEVBQUFsSCxHQUFBO1FBQUVHLElBQUEsR0FBQW1JLGFBQUEsR0FBQXRJLEdBQUEsYUFBQUEsR0FBQSx1QkFBQUEsR0FBQSxDQUFBSSxPQUFBLGNBQUFrSSxhQUFBLGNBQUFBLGFBQUEsR0FBQWhJLE1BQUEsQ0FBQU4sR0FBQTtNQUM1RCxDQUNEOzs7UUFHSXVJLGFBQVcsR0FBQUEsQ0FBQUMsVUFBWSxFQUFBQyxFQUFBO1VBQUUsQ0FBQXpGLEdBQUE7VUFBaUIsc0NBQU13RixVQUFBO2NBQXdCO1FBQzFFTixNQUFBLEVBQUF4SSxhQUFBLENBQUFtRixNQUFBLENBQUFDLE1BQUE7VUFDSWxFLEVBQUEsRUFBQWxCLGFBQUEsQ0FBQW1GLE1BQUEsQ0FBQU0sTUFBQTtRQUNGOztjQUVBaEMsUUFBYyxFQUFBa0MsR0FBQSxFQUFBaEMsR0FBQTtZQUFFa0MsSUFBTSxPQUFBMUYsVUFBQSxDQUFBMEQsWUFBQTtVQUFPLENBQUFnQyxJQUFBO1FBQzdCLE9BQU9sQyxHQUFRLENBQUFtQyxXQUFFO1VBQUFDLFVBQUE7VUFDakJ0RixJQUFBLEVBQU87VUFBa0I7O1VBQXFFO1FBQ2hHLE1BQUFTLEVBQUEsR0FBQXlFLEdBQUEsQ0FBQTZDLE1BQUEsQ0FBQXRILEVBQUE7UUFFSCxNQUFBd0gsSUFBQSxTQUFBSyxFQUFBLENBQUFsRCxJQUFBLEVBQUEzRSxFQUFBO1FBQ0YsT0FBQXlDLEdBQUEsQ0FBQWdCLEVBQUE7VUFFRGxFLElBQUEsRUFBY2lJO1FBQ2Q7TUFDQSxTQUFhcEksR0FBQztRQUNkLElBQUEwSSxhQUFjO1FBQ2QsT0FBYXJGLEdBQUMsQ0FBQW1DLFdBQVk7VUFFbkJDLFVBQ0wsTUFBQTVGLFVBQUEsQ0FBQXFILGNBQUEsRUFBQWxILEdBQUE7VUFDUUcsSUFBQSxHQUFBdUksYUFBQSxHQUFBMUksR0FBQSxhQUFBQSxHQUEwQyx1QkFBQUEsR0FBQSxDQUFBSSxPQUFBLGNBQUFzSSxhQUFBLGNBQUFBLGFBQUEsR0FBQXBJLE1BQUEsQ0FBQU4sR0FBQTtRQUNoRDtNQUFZOzs7ZUFBNkQsb0JBQUFILFVBQUEsQ0FBQThJLHlCQUFBO0VBQzNFSixhQUNPLGtCQUFrQixFQUFLMUksVUFBQSxDQUFBK0kseUJBQUE7ZUFDbEIsU0FBRyxFQUFBL0ksVUFBQSxDQUFBZ0osZ0JBQWM7ZUFDaEIsYUFBVyxFQUFBaEosVUFBWSxDQUFBaUosb0JBQUE7ZUFBRSxDQUFVLFVBQUssRUFBQWpKLFVBQUEsQ0FBQWtKLGtCQUFBO1FBQWdDQyxlQUFBO1FBQy9FQyxpQkFBQTtRQUFBQyxjQUFBO1FBQ0ZDLHNCQUFpQiw2REFBcUM7UUFFdERDLGdCQUFjLEdBQUFBLENBQUFDLENBQUEsRUFBQUMsUUFBQTtVQUFFQyxDQUFBLEdBQU1qSixNQUFBLENBQUErSSxDQUFBLElBQUFBLENBQUEsQ0FBQUcsV0FBQSxRQUFBQyxJQUFBO1VBQU9DLENBQUEsR0FBQXBKLE1BQUEsQ0FBQStJLENBQUEsSUFBQUEsQ0FBQSxDQUFBTSxhQUFBLFFBQUFGLElBQUE7SUFDL0IsSUFBRSxDQUFBRixDQUFBLFNBQWlCO1FBQUFBLENBQUEsQ0FBQUssUUFBQTtRQUNqQlosZUFBVyxDQUFBYSxJQUFXLENBQUNOLENBQUE7UUFBRU4saUJBQVksQ0FBQVksSUFBQSxDQUFBSCxDQUFBO1FBQXFCUCxzQkFBSSxDQUFFVSxJQUFHLENBQUFOLENBQUEsVUFBSCxJQUFHO1FBQTJCRCxRQUFBO01BQ2hHLE1BQUFRLEVBQUEsR0FBQXhKLE1BQUEsQ0FBQWdKLFFBQUEsRUFBQVMsV0FBQSxHQUFBTixJQUFBO01BRUgsTUFBQU8sT0FBQSxHQUFBRixFQUFBLENBQUFHLEtBQUEsU0FBQXpELEtBQUE7TUFFRCxNQUFVMEQsRUFDUixHQUFBUixDQUFBLENBQUFLLFdBQUE7TUFDRSxJQUFNRyxFQUFBLEtBQUFBLEVBQUEsS0FBQUosRUFBQSxJQUFBSSxFQUFBLEtBQUFGLE9BQUEsVUFBd0M7TUFDOUMsSUFBQVQsQ0FBQSxDQUFRUSxXQUFFLE9BQUFELEVBQUEsSUFBQVAsQ0FBQSxDQUFBUSxXQUFBLE9BQUFDLE9BQUE7O1dBQTRCLEtBQUU7O0VBQzFDLE1BQ0FHLFdBQU8sR0FBVUEsQ0FBQUMsVUFBUSxFQUFLZCxRQUFBO0lBQzVCLE1BQU1lLElBQUksR0FBR0MsS0FBQSxDQUFBQyxPQUFBLENBQUFILFVBQUEsSUFBWUEsVUFBRSxHQUFBQSxVQUFBLElBQUFBLFVBQUEsQ0FBQXRELEtBQUE7SUFDM0IsTUFBSzBELEtBQU0sR0FBQUgsSUFBTyxDQUFBckUsTUFBSSxDQUFBcUQsQ0FBQSxLQUFBRCxnQkFBWSxDQUFBQyxDQUFBLEVBQUFDLFFBQUE7UUFBRSxDQUFBa0IsS0FBQSxDQUFBekQsTUFBZTtVQUFNMEQsZ0JBQUUsR0FBQUQsS0FBQSxDQUFBaEUsS0FBQSxHQUFBTixJQUFBLEVBQUFDLENBQUEsRUFBQUMsQ0FBQTtNQUF3QixNQUFBQyxFQUFBLEdBQUFGLENBQUEsQ0FBQS9FLFFBQUEsT0FBQXNELElBQUEsQ0FBQXlCLENBQUEsQ0FBQS9FLFFBQUEsRUFBQWtGLE9BQUE7TUFDbkYsTUFBSUMsRUFBQSxHQUFBSCxDQUFBLENBQUFoRixRQUFBLE9BQUFzRCxJQUFBLENBQUEwQixDQUFBLENBQUFoRixRQUFBLEVBQUFrRixPQUFBO01BQUEsT0FBQUMsRUFBQSxHQUFBRixFQUFBO01BQ0Y7VUFDQXFFLFdBQWEsR0FBQUQsZ0JBQU0sQ0FBQUUsSUFBQSxDQUFBdEIsQ0FBQSxJQUFBSCxjQUF1QixDQUFBVyxJQUFJLENBQUF2SixNQUFBLENBQUErSSxDQUFBLENBQUF1QixVQUFBO1VBQzlDQyxJQUFPLEdBQUlILFdBQUcsSUFBQUQsZ0JBQUE7V0FBRTtNQUFXakIsV0FBRSxFQUFBcUIsSUFBQSxDQUFBckIsV0FBQTtNQUM3QkcsYUFBaUIsRUFBQWtCLElBQUEsQ0FBQWxCLGFBQUE7TUFBQXZJLFFBQUEsRUFBQXlKLElBQUEsQ0FBQXpKLFFBQUE7TUFDakJ3SixVQUFVLEVBQUNDLElBQUEsQ0FBQUQsVUFBWTttQkFBWSxFQUFFLEVBQUFDLElBQUEsQ0FBQUM7OztFQUV6QyxNQUNEQyxrQkFBQSxHQUFBekIsUUFBQTtJQUVELElBQU0sQ0FBQ0EsUUFDTDtJQUNFLE1BQU05SSxDQUFBLEdBQUFGLE1BQUEsQ0FBQWdKLFFBQUEsRUFBQTBCLEtBQUEsd0VBQXlDO0lBQy9DLElBQUF4SyxDQUFBLFNBQVU7TUFBQWdKLFdBQUEsRUFBQWhKLENBQUE7TUFBQXlLLFFBQUE7SUFBQTtXQUFPLElBQUU7O1FBQXNEQyxrQkFBQSxHQUFBdEYsR0FBQTtJQUMxRSxJQUNELENBQUFBLEdBQU8sU0FBUSxFQUFFO0lBQ2YsSUFBQTBFLEtBQU0sQ0FBSUMsT0FBRyxDQUFBM0UsR0FBQSxVQUFBQSxHQUFBO0lBQ2IsSUFBSTtNQUFnQyxNQUFBdUYsTUFBWSxHQUFHQyxJQUFBLENBQUFDLEtBQUEsQ0FBQXpGLEdBQUE7TUFBRSxPQUFNMEUsS0FBQSxDQUFBQyxPQUFBLENBQUFZLE1BQUEsSUFBQUEsTUFBQTtJQUFzQixDQUFDLENBQUM7TUFDbkYsT0FBSTs7O1FBR0ZHLGVBQWMsR0FBQUEsQ0FBQUMsS0FBQSxFQUFBakMsUUFBQTtVQUFFa0MsS0FBTSxHQUFBTixrQkFBQSxDQUFBSyxLQUFBLElBQUFBLEtBQUEsQ0FBQUUsYUFBQTtVQUFPakIsS0FBQSxHQUFBZ0IsS0FBQSxDQUM3QnpGLEdBQUEsQ0FBQXNELENBQUEsS0FBZTtNQUFFRyxXQUFBLEVBQUFILENBQUEsQ0FBQXFDLFFBQUE7TUFBQS9CLGFBQUEsRUFBQU4sQ0FBQSxDQUFBc0MsVUFBQTtNQUFBZixVQUFBO0lBQUEsSUFBQTVFLE1BQUEsQ0FBQXFELENBQUEsS0FBQUQsZ0JBQUEsQ0FBQUMsQ0FBQSxFQUFBQyxRQUFBO1FBQ2pCLENBQUFrQixLQUFPLENBQUF6RCxNQUFJLFNBQVk7VUFBRThELElBQUEsR0FBQUwsS0FBWTtXQUFxQjtNQUFrQ2hCLFdBQUUsRUFBQXFCLElBQUEsQ0FBQXJCLFdBQUE7TUFDaEdHLGFBQUEsRUFBQWtCLElBQUEsQ0FBQWxCLGFBQUE7TUFFSGlCLFVBQUE7TUFFREUsYUFDRTtNQUNFMUosUUFBTSxFQUFBbUssS0FBQSxDQUFBSyxTQUFBO01BQ054RyxNQUFRLEVBQUU7OztRQUF1RHlHLG9CQUFBO1FBR2pFQyxjQUFhLFNBQUFBLENBQUFsSixNQUFBLEVBQUFtSixVQUFjO0lBQzNCLElBQUksQ0FBQ0EsVUFBTSxDQUFBaEYsTUFBVyxXQUFXO1FBQUc7TUFBaUIsTUFBTWQsQ0FBQSxTQUFBckQsTUFBQSxDQUFBOEUsTUFBQTtRQUF3QnNFLEtBQUEsRUFBQXBNLFVBQUEsQ0FBQXFNLDBCQUFBO1FBQy9FQyxrQkFBQTtRQUNGL0wsSUFBTTtVQUNONEUsSUFBTSxFQUFJZ0gsVUFBUyxDQUFBaEYsTUFBQTtVQUNuQm5DLEtBQU8sRUFBSTtZQUFFdUgsS0FBQztjQUFBeEwsVUFBQSxFQUFBb0w7WUFBQTtVQUFBO1FBQUU7TUFBVyxDQUFDLENBQUM7TUFDN0IsTUFBQXRGLElBQWUsR0FBRVIsQ0FBQSxJQUFBQSxDQUFBLENBQUE5RixJQUFBLElBQUE4RixDQUFBLENBQUE5RixJQUFBLENBQUFzRyxJQUFBLElBQUFSLENBQUEsQ0FBQTlGLElBQUEsQ0FBQXNHLElBQUEsQ0FBQUEsSUFBQTtNQUFBLE1BQUEyRixHQUFBO01BQ2pCLE1BQUFDLEdBQU8sR0FBSTNILElBQUEsQ0FBQTJILEdBQUEsRUFBVztVQUFHLENBQUFDLE9BQVUsQ0FBQUMsQ0FBRTtRQUFxQixNQUFJQyxDQUFBLEdBQUFELENBQUEsQ0FBQTVGLE9BQUEsSUFBRTtRQUE4QixNQUFBOEYsU0FBQSxHQUFBRCxDQUFBLENBQUFFLFVBQUEsT0FBQWhJLElBQUEsQ0FBQThILENBQUEsQ0FBQUUsVUFBQSxFQUFBcEcsT0FBQTtRQUNoRyxNQUFBcUcsU0FBQSxJQUFBSCxDQUFBLENBQUFJLGNBQUEsV0FBQWYsb0JBQUE7UUFFSCxJQUFBYyxTQUFBLElBQUFOLEdBQUEsR0FBQUksU0FBQSxHQUFBN00sVUFBQSxDQUFBaU4sMkJBQUEsSUFBQUwsQ0FBQSxDQUFBN0wsVUFBQTtVQUVNeUwsR0FBSSxDQUFBSSxDQUFBLENBQUE3TCxVQUFBLElBQUE2TCxDQUFBLENBQUFNLFlBQUE7UUFBTTtNQUFtQztNQUFtQixPQUFPVixHQUFBO0lBQzVFLFFBQUk7TUFBQTs7O1FBS0FXLGVBQU8sU0FBQUEsQ0FBQW5LLE1BQUEsRUFBQW5DLFFBQXVCLEVBQUF1TSxPQUFBO1VBQzlCQyxHQUFBO1VBQ0FaLEdBQUksR0FBRSxJQUFBM0gsSUFBQSxHQUFBQyxXQUFBO1VBQ0osQ0FBQXFJLE9BQU8sQ0FBQUEsT0FBQSxFQUFBVixPQUFBLEdBQUEzTCxVQUFBLEVBQUFtTSxZQUFBO1VBQ1B2RixJQUFBO1FBQUF5RSxLQUFBO1VBQWdCa0IsTUFBTSxFQUFBdE4sVUFBQSxDQUFBcU0sMEJBQUE7VUFBQXJGLEdBQUEsRUFBQWpHO1FBQUE7TUFBQTtVQUN0QjRHLElBQUk7UUFBRzVHLFVBQUE7UUFBQW1NLFlBQUE7UUFBQUosVUFBQSxFQUFBTCxHQUFBO1FBQUEzTCxTQUFBLEVBQUFELFFBQUE7UUFBQW1NLGNBQUEsRUFBQWY7TUFBQTs7bUJBQW9CLEVBQUU7O1lBQXlCakosTUFBQSxDQUFBdUssSUFBQTtRQUFBQyxPQUFBO1FBQUFqTixJQUFBLEVBQUE4TTtNQUFBO2FBQUlJLENBQUE7YUFDMUQsQ0FBQUMsSUFBTyw4Q0FBQUQsQ0FBQSxJQUFBQSxDQUFBLENBQUFqTixPQUFBOzs7K0JBRUUsU0FBQW1OLENBQUFDLElBQUEsRUFBQWhNLFdBQUE7aUJBQUUsQ0FBQUEsV0FBTzs7a0JBQXdCLEdBQUksTUFBRSxJQUFBMUIsb0JBQUEsQ0FBQTJOLG9CQUFBLEUsTUFBRyxPLGlDQUFHak0sV0FBQSx5QixTQUNwRCxFO3dCQUFzQjtNQUFBLEM7cUJBQStCLEdBQUVrTSxNQUFBLElBQUFwRCxLQUFBLENBQUFDLE9BQUEsQ0FBQW1ELE1BQUEsQ0FBQTVHLEtBQUEsS0FBQTRHLE1BQUEsQ0FBQTVHLEtBQUE7b0JBQUc7WUFBRTZHLE1BQUMsYUFBQTdOLG9CQUFBLENBQUEyTixvQkFBQSxFLElBQzdELFMsWUFBa0JHLFNBQUUsQ0FBQWhOLEVBQUEsdUYsU0FBRSxFO3dCQUE4QjtNQUFBLEM7WUFBS3lJLENBQUMsR0FBQXNFLE1BQUEsSUFBQXJELEtBQUEsQ0FBQUMsT0FBQSxDQUFBb0QsTUFBQSxDQUFBN0csS0FBQSxLQUFBNkcsTUFBQSxDQUFBN0csS0FBQTtZQUMxRCxTQUFTOzttQkFBVyxFQUFLdUMsQ0FBQSxDQUFFd0UsV0FBQSxJQUFZO2dCQUFFLENBQUFDLElBQUksSUFBRXpFLENBQUEsQ0FBQTBFLGlCQUFBO21CQUFHLEVBQUExRSxDQUFBLENBQUEwRSxpQkFBQSxHQUFBek4sTUFBQSxDQUFBK0ksQ0FBQSxDQUFBMEUsaUJBQUEsRUFBQTlELEtBQUEsV0FBQVosQ0FBQSxDQUFBd0UsV0FBQTtrQkFBRSxFQUFBeEUsQ0FBQSxDQUFBMkUsVUFBQTtnQkFDdEQsRUFBQTNFLENBQUEsQ0FBQTRFLFFBQUE7O01BRUosTUFBRTtNQUVGLE9BQUk7OztRQUlKQyx3QkFBa0IsU0FBQVYsSUFBQTtRQUNsQixDQUFBQSxJQUFJO1VBQUE1SSxLQUFBOzs7O1lBR0E7O1lBQTZDcUIsQ0FBQSxhQUFBbkcsb0JBQW9CLENBQUFxTyxlQUFBLEVBQUFYLElBQUEsRUFBQTVJLEtBQUE7WUFDakVrQixJQUFBLEdBQU9HLENBQUEsSUFBTUEsQ0FBQSxDQUFBbUksT0FBQTtZQUFFckksR0FBSyxHQUFFO1VBQWdDLENBQUF1RyxPQUFBLENBQUErQixHQUFBO1FBQXlCLElBQy9FQSxHQUFBLElBQU9BLEdBQUEsQ0FBQUMsUUFBTSxFQUFBdkksR0FBQSxDQUFBc0ksR0FBQSxDQUFBQyxRQUFBLElBQUFELEdBQUE7O2FBQTBDdEksR0FBQTthQUN2RHNILENBQUE7YUFDRSxDQUFBQyxJQUFPLDhDQUF1QixFQUFBRCxDQUFBLElBQUFBLENBQUEsQ0FBQWpOLE9BQUE7YUFDOUI7OztjQUlJO3VDQUNXOzt5QkFBVyxDQUFBeUUsTUFBVyxDQUFBQyxNQUFBOytCQUFNLENBQUFELE1BQUEsQ0FBQTBKLE9BQUEsQyxhQUFVLENBQUExSixNQUFBLENBQUFDLE1BQUE7b0JBQUUsRUFBQXBGLGFBQUEsQ0FBQW1GLE1BQUEsQ0FBQU0sTUFBQTsyQkFBRyxFQUFBekYsYUFBQSxDQUFBbUYsTUFBQSxDQUFBRyxLQUFBLENBQUF0RixhQUFBLENBQUFtRixNQUFBLENBQUFNLE1BQUE7dUJBQ3RELEVBQUF6RixhQUFBLENBQUFtRixNQUFBLENBQUFHLEtBQUEsQ0FBQXRGLGFBQUEsQ0FBQW1GLE1BQUEsQ0FBQU0sTUFBQTs7cUJBR0osRUFBQXpGLGFBQUEsQ0FBQW1GLE1BQUEsQ0FBQUcsS0FBQSxDQUFBdEYsYUFBQSxDQUFBbUYsTUFBQSxDQUFBMkosT0FBQTs7O1lBSUovTCxPQUFXLEVBQUE0QyxHQUFBLEVBQUFoQyxHQUFBO1VBQ1hrQyxJQUFBLEdBQVMsSUFBQTFGLFVBQUEsQ0FBQTBELFlBQUksRUFBRztVQUNoQmlLLElBQUEsT0FBWTFOLG9CQUFBLENBQUEyRCxzQkFBYztRQUMxQixDQUFBOEIsSUFBQSxLQUFVaUksSUFBQTtNQUlaLE9BQUVuSyxHQUFNLENBQUFtQyxXQUFBO1FBQUFDLFVBQUE7UUFBQXRGLElBQUE7TUFBQTs7VUFDTnlDLE1BQUEsR0FBQUosU0FBQSxDQUFBQyxPQUFBO1VBR0ZnTSxRQUFNLEdBQVFwSixHQUFBLENBQUFsRixJQUFBLENBQUFzTyxRQUFBO1VBQ2RDLFlBQVUsS0FBQXJKLEdBQUEsQ0FBQWxGLElBQUEsQ0FBQXdPLGFBQUE7VUFDVkMsTUFBTTtVQUNOQyxPQUFNO1VBTUZDLE1BQUEsR0FBQUosWUFBaUIsY0FBQTVDLGNBQUEsQ0FBQWxKLE1BQUEsRUFBQTZMLFFBQUcsQ0FBQTFJLEdBQUksQ0FBQ3ZGLENBQUEsSUFBQUEsQ0FBQSxDQUFBRyxVQUFXO1lBQ3BDLENBQUEyTCxPQUFBLENBQUE5TCxDQUFBLElBQWU7TUFDbkIsSUFBSXNPLE1BQUEsQ0FBQXRPLENBQUEsQ0FBQUcsVUFBYSxNQUFBb08sU0FBQTtRQUNqQkgsTUFBSSxDQUFBcE8sQ0FBQSxDQUFBRyxVQUFhLElBQUFtTyxNQUFBLENBQWV0TyxDQUFBLENBQUFHLFVBQUE7TUFDaEMsT0FBSTtRQUNKa08sT0FBSSxDQUFBdEgsSUFBMkIsQ0FBQS9HLENBQUEsQ0FBRztNQUVsQztNQUNBO2VBRUksQ0FBTXVHLE1BQU07WUFDWmlJLFVBQVksU0FBS2Qsd0JBQVEsQ0FBQVYsSUFBQTtZQUl6QnlCLFdBQUksR0FBVztnQkFDYjtZQUNBQyxVQUFRO2dCQUlKLFNBQUFDLENBQUEsS0FBYTtlQUNiQyxNQUFNLEdBQUVQLE9BQUssQ0FBQTlILE1BQVMsRUFBRztnQkFDekJzSSxDQUFBLEdBQUFELE1BQVksRUFBRTtnQkFFZjVPLENBQUEsR0FBS3FPLE9BQU8sQ0FBQVEsQ0FBQTtjQUNmQyxLQUFNLE9BQWdDO2dCQUV0Q0MsVUFBTSxHQUFpQ1AsVUFBSyxDQUFBeE8sQ0FBQSxDQUFBRyxVQUFBO2NBQzVDNE8sVUFBTSxFQUErQkQsS0FBSyxHQUFBaEUsZUFBQSxDQUFBaUUsVUFBQSxFQUFBL08sQ0FBQSxDQUFBSyxpQkFBQTtjQUV4QyxDQUFBeU8sS0FBTSxJQUFFL0osSUFBRztnQkFDWDtjQUNBLE1BQU02QyxJQUFFLEdBQUcsTUFBUSxDQUFDLEdBQUF2SSxVQUFBLENBQWNpSixvQkFBYyxFQUFBdkQsSUFBQSxFQUFBL0UsQ0FBQSxDQUFBRyxVQUFBO2NBQ2hELE1BQU1rSyxJQUFHLEdBQUlWLFdBQVMsQ0FBQS9CLElBQUssRUFBSTVILENBQUMsQ0FBQUssaUJBQUE7Y0FDaEMsSUFBQWdLLElBQVEsRUFBQXlFLEtBQUcsR0FBTztnQkFBRSxHQUFBekUsSUFBQTtnQkFBQXpGLE1BQWEsRUFBSTtjQUFBLENBQVM7Y0FDOUM7O2NBR0E1RSxDQUFBLENBQUFlLGFBQUEsSUFBQWlNLElBQUE7WUFDRixNQUFBZ0MsUUFBYyxTQUFPakMsdUJBQXdCLENBQUVDLElBQUEsRUFBQWhOLENBQUEsQ0FBQWUsYUFBZ0I7Z0JBQUVpTyxRQUFHO2NBQUVGLEtBQUE7Z0JBQWE5RixXQUFBLEVBQUFnRyxRQUFBLENBQUFoRyxXQUFBLElBQUE4RixLQUFBLElBQUFBLEtBQUEsQ0FBQTlGLFdBQUE7Z0JBQ25GRyxhQUFpQixFQUFHMkYsS0FBQSxJQUFPQSxLQUFPLENBQUMzRixhQUFhLElBQUs7Z0JBQWtCa0UsV0FBRyxFQUFBMkIsUUFBQSxDQUFBM0IsV0FBQTtnQkFBRTRCLEtBQUEsRUFBQUQsUUFBQSxDQUFBQyxLQUFBO2dCQUFhekIsVUFBQSxFQUFBd0IsUUFBQSxDQUFBeEIsVUFBQTtnQkFDekZDLFFBQUEsRUFBQXVCLFFBQWtCLENBQUF2QixRQUFPO2dCQUN2QjdNLFFBQUcsRUFBQWtPLEtBQUEsSUFBQUEsS0FBQSxDQUFBbE8sUUFBQTtnQkFDSHdKLFVBQUEsRUFBQTBFLEtBQUEsSUFBQUEsS0FBQSxDQUFBMUUsVUFBQTtnQkFDQ0UsYUFBQSxFQUFBd0UsS0FBQSxJQUFBQSxLQUFBLENBQUF4RSxhQUFBO2dCQUNIMUYsTUFBQTtjQUNFOzs7VUFNSixLQUFBa0ssS0FBQTtZQUNBLE1BQU1JLEVBQUEsR0FBQTNFLGtCQUFBLENBQUF2SyxDQUFBLENBQUFLLGlCQUFBO1lBQ04sSUFBQTZPLEVBQUEsRUFBQUosS0FBQTtjQUFBLEdBQUFJLEVBQUE7Y0FBQXRLLE1BQUE7WUFBQTtVQUFBO1VBSUE4SixVQUFBLENBQUExTyxDQUFBLENBQUFHLFVBQW9DLElBQUkyTyxLQUFBO1VBQ3hDVixNQUFBLENBQUFwTyxDQUFBLENBQUFHLFVBQWlDLElBQUkyTyxLQUFBO1FBQ3pDO01BQ0E7TUFDQSxNQUFJSyxPQUFNLENBQUFDLEdBQUEsQ0FBQXRGLEtBQUEsQ0FBQXBGLElBQUE7UUFBQTZCLE1BQUEsRUFBQThJLElBQUEsQ0FBQUMsR0FBQSxDQUFBYixXQUFBLEVBQUFKLE9BQUEsQ0FBQTlILE1BQUE7TUFBQSxHQUFBb0ksSUFBQTtZQUNKMU8sUUFBQSxHQUFBOEUsSUFBQSxHQUFBQSxJQUFBLENBQUE5RSxRQUFBLEdBQUErTSxJQUFBLEdBQUFBLElBQUEsQ0FBQS9NLFFBQUE7V0FDRnNNLGVBQUEsQ0FBQW5LLE1BQXFCLEVBQUFuQyxRQUFNLEVBQUF5TyxVQUFBOztVQUczQmEsT0FBQTtVQUNGLENBQUFDLE1BQUEsQ0FBQXBCLE1BQUEsRUFBQXRDLE9BQUEsQ0FBQTJELENBQUE7WUFDSXpELENBQUEsR0FBQXlELENBQUEsSUFBQUEsQ0FBQSxDQUFBN0ssTUFBQTthQUNGLENBQUFvSCxDQUFBLEtBQUF1RCxPQUFlLENBQUd2RCxDQUFBLEtBQU07O1dBR3hCbkosR0FBQSxDQUFBZ0IsRUFBQTtVQUNGO1FBQ0Z5QyxLQUFBLEVBQUE4SCxNQUFBO1FBRUFzQixJQUFBLEVBQU87VUFDTHJKLEtBQU0sRUFBQTRILFFBQUEsQ0FBQTFILE1BQUE7VUFDSm9KLFVBQUEsRUFBQTFCLFFBQWdCLENBQUsxSCxNQUFBLEdBQUE4SCxPQUFBLENBQUE5SCxNQUFBO1VBQ3JCcUosT0FBTyxFQUFBdkIsT0FBQSxDQUFBOUgsTUFBVztVQUNsQmdKOzs7OztZQUtBO1VBQ0EsNENBQXNDO1lBQ3RDO1lBQ0E1TSxRQUFBLEVBQUFDLElBQUEsRUFBQUMsR0FBb0IsS0FBRTtVQUN0QmtDLElBQUEsT0FBQTFGLFVBQUEsQ0FBQTBELFlBQTRCO2FBQzVCO2FBQ0FGLEdBQUEsQ0FBQW1DLFdBQWtCO1FBQUFDLFVBQVU7UUFBQXRGLElBQUE7TUFBQTs7UUFFOUI7TUFDRixNQUFFaUksSUFBQSxhQUFBdkksVUFBQSxDQUFBd1Esc0JBQUEsRUFBQTlLLElBQUE7TUFDRixNQUFBK0ssS0FBZSxHQUFFbEksSUFBQSxJQUFBQSxJQUFBLENBQUF0QixLQUFBO01BQ2pCLE1BQUF5SixNQUFXO1dBQ1QsQ0FBQWpFLE9BQVUsQ0FBQTJELENBQUE7UUFDVixNQUFJekQsQ0FBQSxJQUFBeUQsQ0FBQSxDQUFBTyxRQUFBLElBQUUsU0FBVyxFQUFBQyxRQUFBO1FBQ2pCRixNQUFBLENBQUEvRCxDQUFBLEtBQUErRCxNQUFBLENBQUEvRCxDQUFBO01BQ0o7TUFDQSxNQUFBa0UsV0FBQSxHQUFBQyxNQUFBLENBQUEzRCxPQUFBLENBQUF1RCxNQUFBLEVBQUF4SyxHQUFBLEdBQUF5SyxRQUFBLEVBQUFJLEtBQUE7UUFBQUosUUFBQTtRQUFBSTtNQUFBO01BSUUsTUFBTUMsa0JBQUEsR0FBQVAsS0FBQSxDQUNOdEssTUFBVSxDQUFBaUssQ0FBQSxLQUFBQSxDQUFBLENBQUFhLGVBQUEsWUFDUjVLLElBQU8sRUFBQUMsQ0FBQSxFQUFBQyxDQUFBLE1BQUFBLENBQUEsQ0FBQTBLLGVBQWMsVUFBQTNLLENBQUEsQ0FBQTJLLGVBQUEsUUFDbkJ0SyxLQUFNLFFBQ05ULEdBQUksQ0FBQWtLLENBQUU7UUFDTnJQLEVBQUEsRUFBTXFQLENBQUEsQ0FBRXJQLEVBQUE7UUFDVG1RLElBQUEsRUFBQWQsQ0FBQSxDQUFBYyxJQUFBLElBQUFkLENBQUEsQ0FBQXJQLEVBQUE7UUFDSDRQLFFBQUEsRUFBQVAsQ0FBQSxDQUFBTyxRQUFBO1FBRUZRLE1BQU8sRUFBQWYsQ0FBTyxDQUFBZSxNQUFPO1FBQ2JGLGVBQWtFLEVBQUFiLENBQUEsQ0FBQWEsZUFBQTtRQUNsRUcsYUFBVyxHQUFLLENBQUFoQixDQUFFLENBQUFnQixhQUFBO1FBQ3RCQyxXQUFhLEVBQUFqQixDQUFBLENBQUFpQjtNQUNiLEVBQUksQ0FBQztZQUFvREMsSUFBRTtRQUF3QnRLLEtBQUEsRUFBQXlKLEtBQUEsQ0FBQXZKLE1BQUE7UUFDbkZxSyxRQUFJLEVBQUFkLEtBQUEsQ0FBQXRLLE1BQUEsQ0FBQWlLLENBQUEsS0FBQUEsQ0FBQSxDQUFBTyxRQUFBLFFBQUF6RyxXQUFBLG1CQUFBaEQsTUFBQTtRQUFBc0ssSUFBQSxFQUFBZixLQUFBLENBQUF0SyxNQUFBLENBQUFpSyxDQUFBLEtBQUFBLENBQUEsQ0FBQU8sUUFBQSxRQUFBekcsV0FBQSxlQUFBaEQsTUFBQTtRQUNGdUssWUFBVSxFQUFJaEIsS0FBTSxDQUFBdEssTUFBQSxDQUFBaUssQ0FBQSxJQUFBQSxDQUFBLENBQUFnQixhQUFBLEVBQUFsSyxNQUFBO1FBR3BCd0ssb0JBQVUsRUFBQWpCLEtBQUEsQ0FBR2tCLE1BQUksRUFBQUMsR0FBQSxFQUFBeEIsQ0FBQSxLQUFKd0IsR0FBSSxJQUFBeEIsQ0FBQSxDQUFBYSxlQUFBLElBQUosQ0FBSSxDQUFFOztVQUduQlksa0JBQW1CLEtBQU07WUFDekJsRSxJQUFNLEdBQUksRUFBRyxFQUFBMU4sb0JBQThCLENBQUEyRCxzQkFBQTtVQUFBK0osSUFBQTtZQUFBO2dCQUN0Q21FLFNBQVEsdUhBQW9CO2dCQUMvQjFMLENBQUEsR0FBTyxNQUFFLEVBQU8sRUFBQW5HLG9CQUFzQixDQUFBcU8sZUFBRyxFQUFBWCxJQUFBLEVBQUFtRSxTQUFBOzRCQUFPLElBQUExTCxDQUFBLElBQUFBLENBQUEsQ0FBQW1JLE9BQUEsUUFBQXJJLEdBQUEsQ0FBQXdHLENBQUE7WUFBSTVMLFVBQUEsRUFBQTRMLENBQUEsQ0FBQStCLFFBQUE7WUFDckR6TixpQkFBQSxFQUFBMEwsQ0FBQSxDQUFBcUYsVUFBQTtZQUFFQyxTQUFBLEVBQUF0RixDQUFBLENBQUF1RjtVQUNIO1VBQ0UsT0FBTXpFLENBQUE7aUJBQ0EsQ0FBQUMsSUFBQSwrQ0FBQUQsQ0FBQSxJQUFBQSxDQUFBLENBQUFqTixPQUFBOzs7YUFDeUNpRCxHQUFBLENBQUFnQixFQUFBO1FBQUFsRSxJQUFBO1VBQUFnUixJQUFBO1VBQUFULFdBQUE7VUFBQUcsa0JBQUE7VUFBQWE7UUFBQTtNQUFBO2FBQzdDMVIsR0FBQSxFQUFNO2FBQ1JxRCxHQUFBLENBQUFtQyxXQUFBO1FBQUFDLFVBQUEsTUFBQTVGLFVBQUEsQ0FBQXFILGNBQUEsRUFBQWxILEdBQUE7UUFBQUcsSUFBQSxFQUFBSCxHQUFBLElBQUFBLEdBQUEsQ0FBQUksT0FBQSxHQUFBSixHQUFBLENBQUFJLE9BQUEsR0FBQUUsTUFBQSxDQUFBTixHQUFBO01BQUE7OztRQUVlLENBQUFnRCxHQUFBO1FBQ2pCLGtEQUF1QjtZQUNyQjtZQUNBLEVBQUl0RCxhQUFBLENBQUFtRixNQUFFLENBQUFDLE1BQUc7UUFBQWlOLEtBQUEsRUFBSHJTLGFBQUcsQ0FBQW1GLE1BQUEsQ0FBQU0sTUFBSCxDQUFHO01BQUU7O1lBRWZoQyxRQUFBLEVBQUFrQyxHQUFBLEVBQUFoQyxHQUFBO0lBQ0YsTUFBQWtDLElBQUEsT0FBQTFGLFVBQUEsQ0FBQTBELFlBQUE7SUFDQSxJQUFJLENBQUFnQyxJQUFBO01BQUEsT0FBQWxDLEdBQUEsQ0FBQW1DLFdBQUE7UUFBQUMsVUFBQTtRQUFBdEYsSUFBQTtNQUFBOztRQUVGO1lBQVlpSSxJQUFHLEdBQUUsVUFBQXZJLFVBQUEsQ0FBQW1TLFVBQUEsRUFBQXpNLElBQUEsaUNBQUEwTSxrQkFBQSxDQUFBNU0sR0FBQSxDQUFBNkMsTUFBQSxDQUFBNkosS0FBQTthQUFNMU8sR0FBRyxDQUFBZ0IsRUFBQTtRQUFBbEUsSUFBQSxFQUFBaUk7TUFBQTtNQUFFLE9BQUtwSSxHQUFBO01BQ2pDLE9BQU1xRCxHQUFBLENBQUFtQyxXQUFXLENBQU07UUFBQUMsVUFBTyxFQUFPLElBQUE1RixVQUFBLENBQUFxSCxjQUFBLEVBQUFsSCxHQUFBO1FBQUFHLElBQUEsRUFBQUgsR0FBQSxJQUFBQSxHQUFBLENBQUFJLE9BQUEsR0FBQUosR0FBQSxDQUFBSSxPQUFBLEdBQUFFLE1BQUEsQ0FBQU4sR0FBQTtNQUFBOzs7UUFHbkMsQ0FBQWdELEdBQUk7VUFDRixtQ0FBSTtZQUNKLEVBQUk7V0FDSixFQUFBdEQsYUFBTyxDQUFBbUYsTUFBQSxDQUFBQyxNQUFBO2FBQUVwRixhQUFTLENBQUFtRixNQUFBLENBQUFHLEtBQUEsQ0FBQXRGLGFBQUEsQ0FBQW1GLE1BQUEsQ0FBQUksTUFBQTs7O1lBQW9COUIsUUFBQSxFQUFBa0MsR0FBQSxFQUFBaEMsR0FBQTtVQUN0Q2tDLElBQUEsR0FBTyxJQUFBMUYsVUFBQSxDQUFBMEQsWUFBQTthQUFFLFNBQVNGLEdBQUcsQ0FBQW1DLFdBQUE7Z0JBQUU7VUFDekI7TUFDRjtRQUNBO01BQ0EsSUFBQTBNLElBQU87WUFBYUMsR0FBRSxJQUFBRCxJQUFBLEdBQUE3TSxHQUFBLENBQUFULEtBQUEsQ0FBQXVOLEdBQUEsY0FBQUQsSUFBQSxjQUFBQSxJQUFBO1lBQUU5SixJQUFJLGFBQUF2SSxVQUFPLENBQUl3USxzQkFBQSxFQUFBOUssSUFBQSxFQUFBNE0sR0FBQTthQUFROU8sR0FBSyxDQUFFZ0IsRUFBQTtZQUFZLEVBQUErRDtRQUFnQjtNQUFFLE9BQUVwSSxHQUFBO01BQ3RGLElBQUFvUyxhQUFpQjtNQUFBLE9BQUEvTyxHQUFBLENBQUFtQyxXQUFBO1FBQ2pCQyxVQUFXLE1BQUE1RixVQUFZLENBQUFxSCxjQUFBLEVBQUFsSCxHQUFBO1FBQ3JCRyxJQUFBLEdBQUFpUyxhQUFVLEdBQUFwUyxHQUFBLFNBQUssSUFBQ0EsR0FBQSxLQUFVLGtCQUFBQSxHQUFBLENBQUFJLE9BQUEsY0FBQWdTLGFBQUEsVUFBTyxJQUFBQSxhQUFBLEdBQUE5UixNQUFBLENBQUFOLEdBQUE7UUFDakM7O0lBRUo7RUFDRitDLE1BQ0QsQ0FBQUMsR0FBQTtJQUVEQyxJQUFNLEVBQUMsaUNBQ0w7SUFDRUMsUUFBTTtNQUNOMEIsS0FBQSxFQUFRbEYsYUFBRSxDQUFBbUYsTUFBQSxDQUFBQyxNQUFBO1FBQ1JxTixHQUFLLEVBQUV6UyxhQUFBLENBQUFtRixNQUFNLENBQUNHLEtBQUEsQ0FBTXRGLGFBQUMsQ0FBQW1GLE1BQUEsQ0FBQUksTUFBQTs7O0tBR3ZCLE9BQUE5QixRQUFBLEVBQUFrQyxHQUFBLEVBQUFoQyxHQUFBO0lBQ0QsTUFDRGtDLElBQU8sT0FBUTFGLFVBQVUsQ0FBQTBELFlBQUs7SUFDNUIsS0FBQWdDLElBQU0sU0FBU2xDLEdBQUEsQ0FBQW1DLFdBQUE7TUFDZkMsVUFBVyxFQUFFO01BQ1h0RixJQUFBOztRQUVFO01BQ0YsSUFBRWtTLEtBQUE7TUFDSixNQUFBRixHQUFBLElBQUFFLEtBQUEsR0FBQWhOLEdBQUEsQ0FBQVQsS0FBQSxDQUFBdU4sR0FBQSxjQUFBRSxLQUFBLGNBQUFBLEtBQUE7TUFDQSxNQUFJakssSUFBQSxhQUFBdkksVUFBQSxDQUFBeVMsZ0JBQUEsRUFBQS9NLElBQUEsRUFBQTRNLEdBQUE7TUFBQSxPQUFBOU8sR0FBQSxDQUFBZ0IsRUFBQTtRQUNGbEUsSUFBTSxFQUFBaUk7TUFDTjtNQUNBLE9BQU9wSSxHQUFHLEVBQUM7VUFBS3VTLGFBQU07TUFBSyxPQUFFbFAsR0FBQSxDQUFBbUMsV0FBQTtRQUM3QkMsVUFBcUIsTUFBQTVGLFVBQUEsQ0FBQXFILGNBQUEsRUFBQWxILEdBQUE7UUFDckJHLElBQU0sR0FBQW9TLGFBQUEsR0FBQXZTLEdBQUEsYUFBQUEsR0FBQSx1QkFBQUEsR0FBQSxDQUFBSSxPQUFBLGNBQUFtUyxhQUFBLGNBQUFBLGFBQUEsR0FBQWpTLE1BQUEsQ0FBQU4sR0FBQTtRQUFFOzs7UUFDUixDQUFBZ0QsR0FBQSxDQUFPO1FBQWtCLG9DQUFrQjtZQUFFO01BQUs0QixLQUFFLEVBQUFsRixhQUFBLENBQUFtRixNQUFBLENBQUFDLE1BQUE7UUFDdERxTixHQUFBLEVBQUF6UyxhQUFBLENBQUFtRixNQUFBLENBQUFHLEtBQUEsQ0FBQXRGLGFBQUEsQ0FBQW1GLE1BQUEsQ0FBQUksTUFBQTtNQUVIO0lBRUQ7S0FFSSxPQUFNOUIsUUFBQSxFQUFBa0MsR0FBQSxFQUFBaEMsR0FBQTtJQUNOLE1BQUFrQyxJQUFVLE9BQUExRixVQUFBLENBQUEwRCxZQUFBO1FBQ1IsQ0FBQWdDLElBQU8sU0FBQWxDLEdBQUEsQ0FBQW1DLFdBQU87Z0JBQ1A7TUFDUHJGLElBQUM7SUFDSDtJQUNELElBQ0Q7TUFDRSxJQUFNcVMsS0FBQTtNQUNOLE1BQUtMLEdBQU0sR0FBRSxDQUFBSyxLQUFBLEdBQUFuTixHQUFBLENBQUFULEtBQUEsQ0FBQXVOLEdBQUEsY0FBQUssS0FBQSxjQUFBQSxLQUFBO01BQ1gsTUFBQXBLLElBQVUsR0FBQyxVQUFZdkksVUFBQSxDQUFBNFMsa0JBQUEsRUFBQWxOLElBQUEsRUFBQTRNLEdBQUE7YUFDckI5TyxHQUFBLENBQUFnQixFQUFVLENBQUU7UUFDWmxFLElBQUksRUFBRWlJO01BQ1IsQ0FBQyxDQUFDO0lBQ0osU0FBQXBJLEdBQUE7TUFDQSxJQUFJMFMsYUFBQTtNQUFBLE9BQUFyUCxHQUFBLENBQUFtQyxXQUFBO1FBQ0ZDLFVBQVMsTUFBQTVGLFVBQVEsQ0FBQXFILGNBQThCLEVBQUFsSCxHQUFBO1FBQy9DRyxJQUFNLEdBQUF1UyxhQUFhLEdBQUExUyxHQUFBLGFBQUFBLEdBQUEsY0FBYSxNQUFNLEdBQUVBLEdBQUksQ0FBQUksT0FBQSxjQUFBc1MsYUFBQSxjQUFBQSxhQUFBLEdBQUFwUyxNQUFBLENBQUFOLEdBQUE7TUFDNUM7OztRQUNBLENBQUFnRCxHQUFBLENBQU87UUFDUCwyREFBTTtZQUFFLEVBQU07WUFBRSxFQUFBdEQsYUFBQSxDQUFBbUYsTUFBQSxDQUFBQyxNQUFBO1FBQU02TixRQUFHLEVBQUFqVCxhQUFnQixDQUFBbUYsTUFBQSxDQUFBTSxNQUFBO01BQ3pDOztZQUE2Q2hDLFFBQUEsRUFBQWtDLEdBQUEsRUFBQWhDLEdBQUE7VUFBT2tDLElBQUEsT0FBQTFGLFVBQUEsQ0FBQTBELFlBQUE7SUFDdEQsS0FBQWdDLElBQUEsU0FBQWxDLEdBQUEsQ0FBQW1DLFdBQUE7TUFFSEMsVUFBQTtNQUVEdEYsSUFBTztJQUVIO0lBQ0E7TUFDRSxNQUFNd1MsUUFBQSxHQUFBdE4sR0FBQSxDQUFBNkMsTUFBTyxDQUFBeUssUUFBTztZQUNsQnZLLElBQU8sYUFBQXZJLFVBQU8sQ0FBQStTLDBCQUFRLEVBQUFyTixJQUFBLEVBQUFvTixRQUFBO2FBQ3RCdFAsR0FBUSxDQUFBZ0IsRUFBRTtRQUNYbEUsSUFBQSxFQUFBaUk7TUFDSDtJQUNELENBQ0QsUUFBT3BJLEdBQUE7TUFDTCxJQUFNNlMsYUFBUztNQUNmLE9BQUt4UCxHQUFNLENBQUVtQyxXQUFBO1FBQ1hDLFVBQVcsTUFBQTVGLFVBQVksQ0FBQXFILGNBQUEsRUFBQWxILEdBQUE7UUFDckJHLElBQUEsR0FBQTBTLGFBQWUsR0FBQTdTLEdBQUEsYUFBQUEsR0FBQSx1QkFBQUEsR0FBQSxDQUFBSSxPQUFBLGNBQUF5UyxhQUFBLGNBQUFBLGFBQUEsR0FBQXZTLE1BQUEsQ0FBQU4sR0FBQTtRQUNmOztJQUVKO1FBQ0ksQ0FBQWdELEdBQUE7UUFDRiwwQkFBTTtZQUFFLEVBQUs7WUFBRVAsT0FBQSxFQUFBVyxJQUFBLEVBQUFDLEdBQUE7UUFBVTtNQUN6QixJQUFBeVAsTUFBTSxFQUFBQyxpQkFBb0IsRUFBQUMsYUFBQSxFQUFBQyxrQkFBQSxFQUFBQyxjQUFBLEVBQUFDLHFCQUFBLEVBQUFDLGVBQUEsRUFBQUMsZ0JBQUEsRUFBQUMsbUJBQUEsRUFBQUMsV0FBQSxFQUFBQyxxQkFBQSxFQUFBQyxpQkFBQSxFQUFBQyxxQkFBQSxFQUFBQyxlQUFBLEVBQUFDLHFCQUFBLEVBQUFDLGFBQUE7TUFDMUIsTUFBTWpSLE1BQUksR0FBR0osU0FBTSxDQUFBQyxPQUFBO01BQ25CLE1BQU1xUixTQUFRLEdBQUcsSUFBS3BQLElBQUMsQ0FBQUEsSUFBUyxDQUFBMkgsR0FBSSxjQUFKLEtBQUksV0FBQTFILFdBQUo7TUFHaEMsTUFBQW9QLFdBQWMsU0FBQW5SLE1BQUEsQ0FBQThFLE1BQUE7UUFDWnNFLEtBQUksRUFBRXBNLFVBQUEsQ0FBQStILHVCQUFBOzBCQUN1QjtZQUMzQjtVQUNBNUMsSUFBQTtVQUNGaVAsZ0JBQUE7VUFDQTlOLElBQUE7WUFDRi9FLFNBQXFCO2NBQ2Z5RyxLQUFBO2NBQVFDLE9BQUE7WUFBRTtVQUFTO1VBQ3pCakQsS0FBTyxFQUFJO1lBQWNtRCxTQUFZO1VBQVE7VUFBT2tNLElBQUE7WUFDdERDLEtBQUE7Y0FFSC9ILEtBQUE7Z0JBR0NnSSxLQUFBO2dCQUNRcFAsSUFBQTtjQUNJO1lBQ0gsQ0FBRTtZQUNGcVAsV0FBRTtjQUNOakksS0FBQTtnQkFDSGdJLEtBQUE7Z0JBRUtwUCxJQUFRLEVBQUU7Y0FDVDtZQUNEO1lBQ0hzUCxTQUFXO2NBQWNsSSxLQUFVLEVBQUU7Z0JBQVdnSSxLQUFBO2dCQUF3QnBQLElBQUE7Y0FDMUU7WUFDSTtZQUFBdVAsT0FBQTtjQUNJbkksS0FBRztnQkFDQ2dJLEtBQUcsY0FBTTtnQkFDVHBQLElBQUk7Y0FBUTtZQUFPO1VBQzdCO1FBQWlCO01BQ2pCO1VBQXlCd1AsY0FBWTtVQUFxQkMsV0FBSTtNQUE4QixJQUFFQyxTQUFBO01BQ2hHLElBQUFDLFlBQUE7TUFFSCxJQUFBQyxVQUFBO01BRUQsSUFBTztRQUVDLElBQUVDLE1BQUEsRUFBQUMsUUFBQSxFQUFBQyxPQUFBLEVBQUFDLFFBQWdDLEVBQUFDLE9BQUEsRUFBQUMsUUFBQSxFQUFBQyxPQUFBLEVBQUFDLFdBQUEsRUFBQUMsSUFBQSxFQUFBQyxpQkFBQSxFQUFBQyxjQUFBLEVBQUFDLGVBQUE7UUFDdEMsTUFBVSxDQUFBQyxFQUFBLEVBQUFDLEVBQUEsRUFBQUMsRUFBQSxFQUFBQyxLQUFBLEVBQUFDLFFBQUEsVUFBQWpHLE9BQUEsQ0FBQUMsR0FBQSxFQUFBaE4sTUFBQSxDQUFBZ08sS0FBQTtVQUNSNUUsS0FBTyxFQUFBcE0sVUFBQSxDQUFBaVcsd0JBQWM7VUFDbkIzSixrQkFBTTtRQUNQLElBQUF0SixNQUFBLENBQUFnTyxLQUFBO1VBQ0g1RSxLQUFBLEVBQUFwTSxVQUFBLENBQUFrVyxxQkFBQTtVQUVGNUosa0JBQXFCLEVBQUc7UUFDbEIsSUFBQXRKLE1BQUEsQ0FBQWdPLEtBQUE7VUFBQTVFLEtBQUEsRUFBQXBNLFVBQUEsQ0FBQW1XLDhCQUFBO1VBQ0Y3SixrQkFBZSxFQUFTO1FBQ3hCLElBQU10SixNQUFJLENBQUFnTyxLQUFBO1VBQ1Y1RSxLQUFNLEVBQUFwTSxVQUFXLENBQUFvVywrQkFBb0I7VUFDbkM5SixrQkFBTztRQUNQLElBQUF0SixNQUFBLENBQUE4RSxNQUFBLENBQWtCO1VBQ2xCc0UsS0FBTSxFQUFBcE0sVUFBQSxDQUFBK0gsdUJBQUE7VUFDSnVFLGtCQUFJO1VBQ0ovTCxJQUFJLEVBQUU7WUFBRzRFLElBQUE7aUJBQWEsRUFBSztjQUFTK0MsSUFBQTtnQkFBSTlCLE1BQUE7a0JBQ2pDaVEsS0FBQTtvQkFBRTlVLFNBQVk7c0JBQUUrVSxFQUFBLEVBQUFwQztvQkFDekI7a0JBQ0E7Z0JBQ1E7Y0FDSDtZQUFhO1lBQUlFLGdCQUFtQixFQUFNO1VBQWdCO1FBQUk7UUFDckVPLGNBQWlCLElBQUFLLE1BQUEsSUFBQUMsUUFBQSxHQUFBVyxFQUFBLENBQUFyVixJQUFBLGNBQUEwVSxRQUFBLHVCQUFBQSxRQUFBLENBQUFqRSxLQUFBLGNBQUFnRSxNQUFBLGNBQUFBLE1BQUE7UUFBQUosV0FBQSxJQUFBTSxPQUFBLElBQUFDLFFBQUEsR0FBQVUsRUFBQSxDQUFBdFYsSUFBQSxjQUFBNFUsUUFBQSx1QkFBQUEsUUFBQSxDQUFBbkUsS0FBQSxjQUFBa0UsT0FBQSxjQUFBQSxPQUFBO1FBQ2pCTCxTQUFXLElBQUFPLE9BQVcsR0FBQyxDQUFBQyxRQUFBLEdBQUFTLEVBQUEsQ0FBQXZWLElBQUEsY0FBQThVLFFBQUEsdUJBQUFBLFFBQUEsQ0FBQXJFLEtBQUEsY0FBQW9FLE9BQUEsY0FBQUEsT0FBQTtRQUNyQk4sWUFBVSxJQUFBUSxPQUFBLElBQUFDLFdBQU0sR0FBQVEsS0FBVSxDQUFBeFYsSUFBQSxjQUFBZ1YsV0FBQSx1QkFBQUEsV0FBSSxDQUFBdkUsS0FBRyxjQUFBc0UsT0FBQSxjQUFBQSxPQUFBO1FBQ2pDUCxVQUFJLElBQUFTLElBQUEsSUFBQUMsaUJBQWEsSUFBQUMsY0FBQSxHQUFBTSxRQUFBLENBQUF6VixJQUFBLGNBQUFtVixjQUFXLEtBQUcsV0FBQUEsY0FBQSxHQUFBQSxjQUFBLENBQUE3TyxJQUFBLGNBQUE2TyxjQUFBLGdCQUFBQSxjQUFBLEdBQUFBLGNBQUEsQ0FBQXpPLEtBQUEsY0FBQXlPLGNBQUEsdUJBQUFBLGNBQUEsQ0FBQXhPLEtBQUEsY0FBQXVPLGlCQUFBLGNBQUFBLGlCQUFBLElBQUFFLGVBQUEsR0FBQUssUUFBQSxDQUFBelYsSUFBQSxjQUFBb1YsZUFBQSxnQkFBQUEsZUFBQSxHQUFBQSxlQUFBLENBQUE5TyxJQUFBLGNBQUE4TyxlQUFBLHVCQUFBQSxlQUFBLENBQUExTyxLQUFBLGNBQUF1TyxJQUFBLGNBQUFBLElBQUE7TUFDakMsQ0FBQyxDQUFDO1FBQ0o7TUFBQTtNQUlKLE1BQU9lLFFBQ0wsSUFBQXJELE1BQUEsSUFBQUMsaUJBQUEsR0FBQWdCLFdBQUEsQ0FBQTVULElBQUEsY0FBQTRTLGlCQUFBLHVCQUFBQSxpQkFBQSxDQUFBdE0sSUFBQSxjQUFBcU0sTUFBQSxjQUFBQSxNQUFBO01BQ0UsTUFBTW1CLElBQUEsSUFBQWpCLGFBQUEsSUFBQUMsa0JBQXdDLEdBQUFjLFdBQUEsQ0FBQTVULElBQUEsY0FBQThTLGtCQUFBLHVCQUFBQSxrQkFBQSxDQUFBbUQsWUFBQSxjQUFBcEQsYUFBQSxjQUFBQSxhQUFBO01BQzlDLE1BQVFxRCxlQUFFLEtBQUFuRCxjQUFBLEdBQUFpRCxRQUFBLENBQUExUCxJQUFBLGNBQUF5TSxjQUFBLGNBQUFBLGNBQUEsT0FBQW5OLEdBQUEsQ0FBQXdHLENBQUEsSUFBQUEsQ0FBQSxDQUFBNUYsT0FBQSxFQUFBWCxNQUFBLENBQUFzUSxPQUFBO01BQ1IsTUFBTUMsYUFBQSxVQUFPSixRQUFPLENBQUF0UCxLQUFBLGlCQUFBc00scUJBQUEsSUFBQUMsZUFBQSxHQUFBK0MsUUFBQSxDQUFBdFAsS0FBQSxjQUFBdU0sZUFBQSx1QkFBQUEsZUFBQSxDQUFBdE0sS0FBQSxjQUFBcU0scUJBQUEsY0FBQUEscUJBQUEsUUFBQUUsZ0JBQUEsR0FBQThDLFFBQUEsQ0FBQXRQLEtBQUEsY0FBQXdNLGdCQUFBLGNBQUFBLGdCQUFBLEdBQUFnRCxlQUFBLENBQUF0UCxNQUFBO1VBQ2xCeVAsV0FBTSxJQUFBbEQsbUJBQWEsSUFBQUMsV0FBQSxHQUFPVSxJQUFBLENBQUFDLEtBQVMsY0FBQVgsV0FBQSx1QkFBQUEsV0FBQSxDQUFBa0QsT0FBQSxjQUFBbkQsbUJBQUEsY0FBQUEsbUJBQUE7VUFDbkNvRCxpQkFBTSxJQUFBbEQscUJBQWEsSUFBQUMsaUJBQWdCLEdBQUFRLElBQUEsQ0FBQUcsV0FBQSxjQUFBWCxpQkFBQSx1QkFBQUEsaUJBQUEsQ0FBQWdELE9BQUEsY0FBQWpELHFCQUFBLGNBQUFBLHFCQUFBO1VBQ25DbUQsZUFBVyxJQUFBakQscUJBQWEsSUFBQUMsZUFBTyxHQUFBTSxJQUFTLENBQUFJLFNBQUEsY0FBQVYsZUFBQSx1QkFBQUEsZUFBQSxDQUFBOEMsT0FBQSxjQUFBL0MscUJBQUEsY0FBQUEscUJBQUE7VUFDeENrRCxhQUFTLElBQUFoRCxxQkFBYSxJQUFBQyxhQUFPLEdBQUFJLElBQU8sQ0FBQ0ssT0FBQyxjQUFBVCxhQUFBLHVCQUFBQSxhQUFBLENBQUE0QyxPQUFBLGNBQUE3QyxxQkFBQSxjQUFBQSxxQkFBQTtVQUN0Q2lELFVBQUEsR0FBQVIsZUFBMEI7TUFDNUIsSUFBQ3hQLEtBQUEsR0FBQTBQLGFBQUE7TUFDSCxJQUFBTyxVQUFBO01BRUYsTUFBT3ZSLElBQUEsR0FBTyxFQUFFLEVBQUExRixVQUFRLENBQUswRCxZQUFBO01BQzNCLElBQUlzRCxLQUFBLFVBQUF0QixJQUFBO1FBQUE7VUFDRixNQUFNSyxHQUFNLEdBQUcsUUFBUyxFQUFDL0YsVUFBUSxDQUFBZ0csdUJBQUEsRUFBQU4sSUFBQTtVQUNqQyxNQUFNd1IsR0FBQSxHQUFBeFIsSUFBQSxDQUFBOUUsUUFBQTtVQUNKLE1BQU91VyxVQUFFLEdBQUFwUixHQUFBLENBQUFHLEdBQUEsQ0FBQXZGLENBQUEsSUFBQUQsbUJBQUEsQ0FBQUMsQ0FBQSxFQUFBdVcsR0FBQTtVQUNULElBQUlDLFVBQUksQ0FBQWpRLE1BQUE7WUFDUitQLFVBQVM7WUFDVGpRLEtBQU8sR0FBQW1RLFVBQUEsQ0FBQWpRLE1BQUE7WUFDUDhQLFVBQUEsR0FBQUcsVUFBMkIsQ0FBQXhRLEtBQUEsR0FBQU4sSUFBQSxFQUFBQyxDQUFBLEVBQUFDLENBQUE7Y0FDckIsTUFBSUMsRUFBQSxHQUFBRixDQUFBLENBQUFoRixTQUFBLE9BQUF1RCxJQUFBLENBQUFwRSxNQUFBLENBQUE2RixDQUFBLENBQUFoRixTQUFBLEdBQUFtRixPQUFBO2NBRU4sTUFBTUMsRUFBSSxHQUFBSCxDQUFJLENBQUNqRixTQUFDLE9BQUF1RCxJQUFBLENBQUFwRSxNQUFBLENBQUE4RixDQUFBLENBQUFqRixTQUFBLEdBQUFtRixPQUFBO2NBQ2hCLE9BQVNDLEVBQUEsR0FBR0YsRUFBSTtZQUNoQixHQUFBRyxLQUFBLElBQVcsRUFBRztZQUNkLE1BQUF5USxLQUFVO1lBQ1YsTUFBQUMsS0FBVTtZQUNWLE1BQUFDLFNBQWUsR0FBRztZQUFFLE1BQU9DLE9BQUE7WUFBRUosVUFBVyxDQUFBMUssT0FBQSxDQUFBckcsQ0FBQTtjQUFFLE1BQUtvUixFQUFBLEdBQU8vVyxNQUFBLENBQUEyRixDQUFBLENBQUFsRixXQUFBO2NBQUVrVyxLQUFLLENBQUFJLEVBQUEsS0FBQUosS0FBQSxDQUFBSSxFQUFBO2NBQVEsTUFBQUMsRUFBQSxHQUFBaFgsTUFBQSxDQUFBMkYsQ0FBQSxDQUFBdEUsY0FBQTtjQUFFdVYsS0FBQSxDQUFBSSxFQUFBLEtBQUFKLEtBQUEsQ0FBQUksRUFBQTtjQUFHLE1BQUFDLEVBQUEsR0FBQWpYLE1BQUEsQ0FBQTJGLENBQUEsQ0FBQWpFLGFBQUE7Y0FFNUVtVixTQUFBLENBQUFJLEVBQWdDLElBQUcsQ0FBQUosU0FBSSxDQUFBSSxFQUFBO2NBQ3JDLE1BQUFDLEVBQUEsR0FBQWxYLE1BQTJDLENBQUMyRixDQUFBLENBQUF4RSxVQUFBO2NBRTlDMlYsT0FBQSxDQUFBSSxFQUFBLEtBQUFKLE9BQTBCLENBQUFJLEVBQUE7WUFBQTtZQUM1QmhCLFdBQU0sR0FBVzdGLE1BQUcsQ0FBQTNELE9BQVksQ0FBQ2lLLEtBQUEsQ0FBTSxDQUFDbFIsR0FBQSxHQUFBMFIsR0FBQSxFQUFBQyxTQUFBO2NBQ3RDRCxHQUFPO2NBQ1BDO1lBQ0EsRUFBSTtZQUNGaEIsaUJBQVUsR0FBQS9GLE1BQUEsQ0FBQTNELE9BQUEsQ0FBQWtLLEtBQUEsRUFBQW5SLEdBQUEsR0FBQTBSLEdBQUEsRUFBQUMsU0FBQTtjQUNWRCxHQUFBO2NBQ0FDO2NBQVM7WUFBY2YsZUFBQSxHQUFBaEcsTUFBQSxDQUFBM0QsT0FBQSxDQUFBbUssU0FBQSxFQUFBcFIsR0FBQSxHQUFBMFIsR0FBQSxFQUFBQyxTQUFBO2NBQ3pCRCxHQUFBO2NBQ0FDO1lBQ0YsRUFBTTtZQUNOZCxhQUFlLEdBQUdqRyxNQUFBLENBQUEzRCxPQUNaLENBQUVvSyxPQUFNLEVBQUFyUixHQUFBLEdBQUEwUixHQUFBLEVBQUFDLFNBQUE7Y0FBQUQsR0FBQTtjQUFBQztZQUNYO1lBQ0MvQyxVQUFBLEdBQUFxQyxVQUFzQixDQUFBaFIsTUFBUSxDQUFBQyxDQUFBLEtBQUFBLENBQUEsQ0FBQTlFLFNBQUEsUUFBQXVELElBQUEsQ0FBQXBFLE1BQUEsQ0FBQTJGLENBQUEsQ0FBQTlFLFNBQUEsU0FBQXVELElBQUEsQ0FBQW9QLFNBQUEsR0FBQS9NLE1BQUE7VUFDaEM7Z0JBQ007Ozs7NEJBSVksR0FBRTt5QkFDbEI7VUFDRjRRLFVBQUU7WUFDSm5LLElBQUEsT0FBQTFOLG9CQUFBLENBQUEyRCxzQkFBQTtVQUNBK0osSUFBQTtZQUNFO1VBQ0FvSyxrQkFBSSxHQUFDLFVBQUE5WCxvQkFBZ0IsQ0FBRStYLHVCQUFrQixFQUFBckssSUFBQSxhQUFvQjtRQUMvRCxDQUFDLENBQUMsT0FBQUgsQ0FBQTtVQUNKc0ssVUFBQSxHQUFBNVgsV0FBQSxDQUFBc04sQ0FBQSxFQUFBbE4sSUFBQTtVQUVBeVgsa0JBQXFCLE9BQWU7UUFDcEM7UUFBWSxJQUFJO1VBQUlFLGVBQVcsYUFBQWhZLG9CQUFBLENBQUErWCx1QkFBQSxFQUFBckssSUFBQTtpQkFBTUgsQ0FBRTtjQUFFLENBQUFzSyxVQUFVLEVBQUVBLFVBQUEsR0FBQTVYLFdBQUEsQ0FBQXNOLENBQUEsRUFBQWxOLElBQUE7eUJBQU07OztNQUFPLE9BQUVrRCxHQUFBLENBQUFnQixFQUFBO1FBQ3BFbEUsSUFBSTtVQUNGNFgsY0FBVSxFQUFBbFIsS0FBQTtVQUFFcU4sS0FBSyxFQUFFc0MsV0FBQTtxQkFBRSxFQUFVRSxpQkFBRTtVQUFnQnJDLFNBQUEsRUFBQXNDLGVBQUE7VUFBSXJDLE9BQUEsRUFBQXNDLGFBQUE7VUFDdkRQLGVBQUEsRUFBQVEsVUFBQTtVQUVBbUIscUJBQW1CLEVBQUF6RCxjQUFBO1VBQ2pCMEQsa0JBQUksRUFBQXpELFdBQUE7VUFDSjBELDJCQUFJLEVBQUF6RCxTQUFBO1VBQ0owRCxtQkFBTyxFQUFBekQsWUFBQTtVQUFFMEQsb0JBQVcsRUFBQXpELFVBQUE7b0NBQVMsRUFBQWlELGtCQUFBO1VBQU9TLHVCQUFBLEVBQUFQLGVBQUE7VUFBSVEsZ0JBQUEsRUFBQVgsVUFBQTtVQUN4Q1ksV0FBVSxFQUFBekI7UUFDVjs7YUFBaUI5VyxHQUFBO1VBQUt3WSxnQkFBQSxFQUFBQyxhQUFBO2FBQUVwVixHQUFBLENBQUFtQyxXQUFBO1FBQ3pCQyxVQUFBLEdBQUErUyxnQkFBQSxHQUFBeFksR0FBQSxDQUFBeUYsVUFBQSxjQUFBK1MsZ0JBQUEsY0FBQUEsZ0JBQUE7UUFFRHJZLElBQU0sRUFBQyxDQUFBc1ksYUFBYyxHQUFFelksR0FBQSxDQUFBSSxPQUFhLE1BQUksSUFBTSxJQUFBcVksYUFDNUMsS0FBTyxLQUFPLElBQUFBLGFBQUEsR0FBQW5ZLE1BQUEsQ0FBQU4sR0FBQTtRQUNaOzs7UUFHQSxDQUFBZ0QsR0FDRjtRQUNFLGlDQUFPO1lBQ1A7V0FDQSxFQUFJdEQsYUFBRSxDQUFBbUYsTUFBQSxDQUFBQyxNQUFBO1lBQ0osRUFBSXBGLGFBQUcsQ0FBQW1GLE1BQUEsQ0FBQUcsS0FBQSxDQUFBdEYsYUFBQSxDQUFBbUYsTUFBQSxDQUFBSSxNQUFBO1lBQ1AsRUFBQXZGLGFBQWlCLENBQUNtRixNQUFLLENBQUFHLEtBQUEsQ0FBQXRGLGFBQUEsQ0FBQW1GLE1BQUEsQ0FBQUksTUFBQTtjQUN2QixFQUFBdkYsYUFBa0IsQ0FBQW1GLE1BQUEsQ0FBQUcsS0FBQSxDQUFBdEYsYUFBQSxDQUFBbUYsTUFBQSxDQUFBTSxNQUFBOzs7WUFLbEIxQyxPQUFBLEVBQVM0QyxHQUFBLEVBQUFoQyxHQUFBO1VBQ2ZpQyxDQUFBLEdBQU1ELEdBQUssQ0FBQVQsS0FBQTtRQUtYVSxDQUFBLENBQUFGLE1BQU0sVUFBZ0UsRUFBRTtNQUN4RSxNQUFBRyxJQUFVLE9BQU8xRixVQUFhLENBQUEwRCxZQUFBO1VBQUEsQ0FBQWdDLElBQUEsU0FBQWxDLEdBQUEsQ0FBQW1DLFdBQUE7UUFDNUJDLFVBQVM7UUFDVHRGLElBQUk7OztZQUNnRXVZLFFBQUEsRUFBQUMsV0FBQSxFQUFBQyxRQUFBLEVBQUFDLFFBQUE7UUFDcEUsTUFBQXpRLElBQUEsYUFBQXZJLFVBQUEsQ0FBQXdRLHNCQUFBLEVBQUE5SyxJQUFBLEdBQUFtVCxRQUFBLEdBQUFwVCxDQUFBLENBQUFQLElBQUEsY0FBQTJULFFBQUEsY0FBQUEsUUFBQTtRQUNBLE1BQUE1UyxJQUFBLElBQUE2UyxXQUFBLEdBQUF2USxJQUFBLGFBQUFBLElBQUEsdUJBQUFBLElBQUEsQ0FBQXRCLEtBQUEsY0FBQTZSLFdBQUEsY0FBQUEsV0FBQTtRQUVGLE1BQU96VCxJQUFJLEdBQUcsQ0FBQTBULFFBQUEsR0FBQXRULENBQUEsQ0FBQUosSUFBQSxjQUFBMFQsUUFBQSxjQUFBQSxRQUFBO1FBQ1osTUFBTTdULElBQUEsSUFBQThULFFBQUEsR0FBQXZULENBQUEsQ0FBQVAsSUFBQSxjQUFBOFQsUUFBQSxjQUFBQSxRQUFBO2NBQ0pyUyxLQUFRLEdBQUFWLElBQUEsQ0FBU1UsS0FBTSxDQUFNdEIsSUFBQSxFQUFNQSxJQUFBLEdBQUFILElBQUE7Y0FDL0IwQixJQUFJLEdBQUdELEtBQUEsQ0FBQVQsR0FBQSxFQUFBc0ksR0FBQSxFQUFBZ0IsQ0FBQTtjQUNUeUosS0FBSyxFQUFBQyxPQUFBO1VBQ1AsT0FBRztZQUNIblMsR0FBQSxFQUFBdEcsTUFBVyxFQUFBd1ksS0FBQSxJQUFBQyxPQUFBLEdBQUExSyxHQUFBLENBQUF6TixFQUFBLGNBQUFtWSxPQUFBLGNBQUFBLE9BQUEsR0FBQTFLLEdBQUEsQ0FBQTBELEtBQUEsY0FBQStHLEtBQUEsY0FBQUEsS0FBQSxHQUFBekosQ0FBQTtZQUNYMUksT0FBSyxTQUFBMEgsR0FBQSxnQkFBQUEsR0FBQTtjQUNMekksR0FBQSxFQUFBeUk7WUFDRjtVQUNBO1FBQ0Y7UUFBaUIsT0FBQWhMLEdBQUEsQ0FBQWdCLEVBQUE7VUFDakJsRSxJQUFPLEVBQUc7WUFDUnNHLElBQUE7WUFDSUksS0FBQTtjQUNKQyxLQUFBLEVBQUFoQixJQUFBLENBQUFpQixNQUFBO2NBQ0pDLFFBQUE7WUFFSDtZQUNINUIsTUFBQSJ9