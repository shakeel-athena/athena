/**
 * usePallas Hook
 *
 * Enhanced WebSocket connection with auto-reconnect, heartbeat,
 * v2 response parsing (metadata, SOC analysis, suggestions),
 * query history, response caching, loading timeout, and cancel support.
 *
 * Ported from pallas/public/hooks/usePallas.ts for Athena React/JS.
 */

import { useState, useEffect, useRef, useCallback } from 'react';
import { createChatSocket } from '../services/pallasService';

// ─── Constants ───────────────────────────────────────────────────────────────

const MAX_HISTORY = 20;
const HEARTBEAT_INTERVAL = 30000;
const RECONNECT_BASE_DELAY = 1000;
const RECONNECT_MAX_DELAY = 30000;
const LOADING_TIMEOUT_MS = 60000;
const LONG_QUERY_THRESHOLD_MS = 10000;
const MAX_PINNED = 5;
const SOC_ANALYSIS_MARKERS = ['## SOC ANALYSIS', '## \u{1F50D} SOC ANALYSIS'];

// ─── TTL + LRU Cache ────────────────────────────────────────────────────────
// Persists across mount/unmount so tab switching doesn't lose results.

class TTLCache {
  constructor(maxSize, ttlMinutes) {
    this._cache = new Map();
    this._maxSize = maxSize;
    this._ttlMs = ttlMinutes * 60 * 1000;
  }

  get(key) {
    const entry = this._cache.get(key);
    if (!entry) return undefined;
    if (Date.now() - entry.ts > this._ttlMs) {
      this._cache.delete(key);
      return undefined;
    }
    // Move to end (most recently used)
    this._cache.delete(key);
    this._cache.set(key, entry);
    return entry.value;
  }

  set(key, value) {
    this._cache.delete(key);
    if (this._cache.size >= this._maxSize) {
      const oldest = this._cache.keys().next().value;
      if (oldest !== undefined) this._cache.delete(oldest);
    }
    this._cache.set(key, { value, ts: Date.now() });
  }

  delete(key) {
    this._cache.delete(key);
  }
}

// Module-scoped caches — survive component unmount/remount
const responseCache = new TTLCache(20, 30);   // 30 min TTL, max 20 entries
const historyCache  = new TTLCache(10, 60);   // 60 min TTL, max 10
const pinnedCache   = new TTLCache(10, 120);  // 2 hr TTL, max 10

// ─── Favorites (localStorage) ───────────────────────────────────────────────

const FAVORITES_KEY = 'pallas-favorites';

function loadFavorites() {
  try {
    const raw = localStorage.getItem(FAVORITES_KEY);
    return raw ? JSON.parse(raw) : [];
  } catch {
    return [];
  }
}

function saveFavorites(favs) {
  try {
    localStorage.setItem(FAVORITES_KEY, JSON.stringify(favs));
  } catch { /* storage full — silent */ }
}

// ─── Response parsing ───────────────────────────────────────────────────────

/** Extract ## SOC ANALYSIS section from markdown content */
function extractSocAnalysis(content) {
  for (const marker of SOC_ANALYSIS_MARKERS) {
    const idx = content.indexOf(marker);
    if (idx !== -1) {
      return {
        mainContent: content.substring(0, idx).trimEnd(),
        socAnalysis: content.substring(idx + marker.length).trim(),
      };
    }
  }
  return { mainContent: content };
}

/**
 * Parse incoming WebSocket message.
 * Supports three response formats (most preferred first):
 *
 *   v3 (Phase-2 hybrid): backend emits a `blocks` array of typed render
 *       blocks alongside the markdown body. Frontend uses blocks directly,
 *       skipping markdown parsing for those sections. See BLOCK_SCHEMAS.md
 *       for the JSON contract.
 *
 *   v2: structured fields (metadata / soc_analysis / suggestions) but no
 *       blocks array — frontend parses the markdown body via BlockParser.
 *
 *   v1: SOC analysis embedded inside markdown. Frontend extracts the
 *       "## SOC ANALYSIS" section by regex and parses the rest via
 *       BlockParser.
 *
 * The `blocks` field, when present, is passed straight through to
 * ResponseBlockRenderer which dispatches each typed block to its
 * specialized component. This is the preferred path for new MCP tools
 * because it's lossless, faster, and 100% reliable (no heuristic detection).
 */
function parseResponse(data) {
  const rawContent = data.message || data.content || '';

  // v3 (preferred): backend emitted typed blocks directly
  if (Array.isArray(data.blocks) && data.blocks.length > 0) {
    const { mainContent } = extractSocAnalysis(rawContent);
    return {
      content: mainContent,
      blocks: data.blocks,
      metadata: data.metadata || undefined,
      socAnalysis: data.soc_analysis || undefined,
      suggestions: data.suggestions || undefined,
      warn: data.warn || false,
      timestamp: new Date(),
    };
  }

  // v2: structured fields
  if (data.metadata || data.soc_analysis || data.suggestions) {
    const { mainContent } = extractSocAnalysis(rawContent);
    return {
      content: mainContent,
      metadata: data.metadata || undefined,
      socAnalysis: data.soc_analysis || undefined,
      suggestions: data.suggestions || undefined,
      warn: data.warn || false,
      timestamp: new Date(),
    };
  }

  // v1: extract SOC analysis from markdown body
  const { mainContent, socAnalysis } = extractSocAnalysis(rawContent);
  return {
    content: mainContent,
    socAnalysis,
    warn: data.warn || false,
    timestamp: new Date(),
  };
}

// ─── Hook ────────────────────────────────────────────────────────────────────

/**
 * Enhanced Pallas WebSocket hook.
 *
 * @param {string}   [cacheKey]  Module-scoped cache key (e.g. 'chat', 'siem').
 *                               Enables cross-tab persistence.
 * @param {object}   [options]
 * @param {function} [options.onQueryComplete] (module, query, durationMs)
 *                               Fired when a long-running query (>10 s) finishes.
 */
export function usePallas(cacheKey, options) {
  // ── State ───────────────────────────────────────────────────────────────
  const [response, setResponse] = useState(
    () => (cacheKey ? responseCache.get(cacheKey) || null : null)
  );
  const [isLoading, setIsLoading] = useState(false);
  const [connectionStatus, setConnectionStatus] = useState('connecting');
  const [queryHistory, setQueryHistory] = useState(
    () => (cacheKey ? historyCache.get(cacheKey) || [] : [])
  );
  const [favorites, setFavorites] = useState(loadFavorites);
  const [pinnedResponses, setPinnedResponses] = useState(
    () => (cacheKey ? pinnedCache.get(cacheKey) || [] : [])
  );

  // ── Refs ────────────────────────────────────────────────────────────────
  const wsRef              = useRef(null);
  const reconnectAttempt   = useRef(0);
  const reconnectTimer     = useRef(null);
  const heartbeatTimer     = useRef(null);
  const loadingTimer       = useRef(null);
  const intentionalClose   = useRef(false);
  const queryStart         = useRef(0);
  const pendingQuery       = useRef(null);
  const queryCounter       = useRef(0);
  const mounted            = useRef(true);

  // ── Cache persistence ───────────────────────────────────────────────────
  useEffect(() => {
    if (cacheKey && response) responseCache.set(cacheKey, response);
  }, [cacheKey, response]);

  useEffect(() => {
    if (cacheKey && queryHistory.length > 0) historyCache.set(cacheKey, queryHistory);
  }, [cacheKey, queryHistory]);

  // ── Timeout helpers ─────────────────────────────────────────────────────

  const clearLoadingTimeout = useCallback(() => {
    if (loadingTimer.current) {
      clearTimeout(loadingTimer.current);
      loadingTimer.current = null;
    }
  }, []);

  const startLoadingTimeout = useCallback(() => {
    clearLoadingTimeout();
    loadingTimer.current = setTimeout(() => {
      if (!mounted.current) return;
      setIsLoading(false);
      setResponse({
        content:
          '**Query timed out.** The server did not respond within 60 seconds. ' +
          'This may indicate a complex query or server issue. Please try again or simplify your query.',
        warn: true,
        timestamp: new Date(),
      });
    }, LOADING_TIMEOUT_MS);
  }, [clearLoadingTimeout]);

  // ── Heartbeat ───────────────────────────────────────────────────────────

  const stopHeartbeat = useCallback(() => {
    if (heartbeatTimer.current) {
      clearInterval(heartbeatTimer.current);
      heartbeatTimer.current = null;
    }
  }, []);

  const startHeartbeat = useCallback((ws) => {
    stopHeartbeat();
    heartbeatTimer.current = setInterval(() => {
      if (ws.readyState === WebSocket.OPEN) {
        try { ws.send(JSON.stringify({ type: 'ping' })); } catch { /* ignore */ }
      }
    }, HEARTBEAT_INTERVAL);
  }, [stopHeartbeat]);

  // ── WebSocket connection ────────────────────────────────────────────────

  const connect = useCallback(() => {
    if (wsRef.current) {
      intentionalClose.current = true;
      wsRef.current.close();
      wsRef.current = null;
    }
    if (!mounted.current) return;
    intentionalClose.current = false;

    try {
      const ws = createChatSocket();

      ws.onopen = () => {
        if (!mounted.current) return;
        setConnectionStatus('connected');
        reconnectAttempt.current = 0;
        startHeartbeat(ws);
      };

      ws.onmessage = (event) => {
        if (!mounted.current) return;
        try {
          const data = JSON.parse(event.data);

          // Ignore pong / cancel ack
          if (data.type === 'pong' || data.cancelled) return;

          // Guard: discard unsolicited responses (ping leak on old servers)
          if (data.role === 'bot' && !pendingQuery.current && queryStart.current === 0) return;

          if (data.role === 'bot') {
            const parsed = parseResponse(data);
            setResponse(parsed);
            clearLoadingTimeout();

            // Long-query completion callback
            if (queryStart.current > 0 && options?.onQueryComplete && cacheKey) {
              const elapsed = Date.now() - queryStart.current;
              if (elapsed >= LONG_QUERY_THRESHOLD_MS) {
                options.onQueryComplete(cacheKey, pendingQuery.current || 'query', elapsed);
              }
              queryStart.current = 0;
            }

            // Attach strategy info to the most-recent history entry
            if (parsed.metadata?.strategy && pendingQuery.current) {
              setQueryHistory((prev) => {
                const updated = [...prev];
                const last = updated.length - 1;
                if (last >= 0 && updated[last].query === pendingQuery.current) {
                  updated[last] = { ...updated[last], strategy: parsed.metadata.strategy };
                }
                return updated;
              });
              pendingQuery.current = null;
            }
          }

          setIsLoading(false);
        } catch {
          setIsLoading(false);
          clearLoadingTimeout();
        }
      };

      ws.onerror = () => {
        if (!mounted.current) return;
        setConnectionStatus('error');
        setIsLoading(false);
        clearLoadingTimeout();
      };

      ws.onclose = () => {
        stopHeartbeat();
        if (!mounted.current || intentionalClose.current) return;

        const attempt = reconnectAttempt.current;
        const delay = Math.min(RECONNECT_BASE_DELAY * Math.pow(2, attempt), RECONNECT_MAX_DELAY);
        setConnectionStatus('reconnecting');
        reconnectAttempt.current = attempt + 1;

        reconnectTimer.current = setTimeout(() => {
          if (mounted.current) connect();
        }, delay);
      };

      wsRef.current = ws;
    } catch {
      setConnectionStatus('error');
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [cacheKey, startHeartbeat, stopHeartbeat, clearLoadingTimeout]);

  // ── Lifecycle ───────────────────────────────────────────────────────────

  useEffect(() => {
    mounted.current = true;
    connect();

    return () => {
      mounted.current = false;
      intentionalClose.current = true;
      stopHeartbeat();
      clearLoadingTimeout();
      if (reconnectTimer.current) clearTimeout(reconnectTimer.current);
      if (wsRef.current) {
        wsRef.current.close();
        wsRef.current = null;
      }
    };
  }, [connect, stopHeartbeat, clearLoadingTimeout]);

  // ── Actions ─────────────────────────────────────────────────────────────

  const sendQuery = useCallback((query) => {
    const trimmed = (query || '').trim();
    if (!trimmed || !wsRef.current || wsRef.current.readyState !== WebSocket.OPEN) return;

    queryCounter.current += 1;
    queryStart.current = Date.now();
    pendingQuery.current = trimmed;

    setQueryHistory((prev) => {
      const updated = [{ query: trimmed, timestamp: new Date() }, ...prev];
      return updated.slice(0, MAX_HISTORY);
    });

    setIsLoading(true);
    startLoadingTimeout();
    wsRef.current.send(trimmed);
  }, [startLoadingTimeout]);

  const cancelQuery = useCallback(() => {
    if (!isLoading) return;
    queryCounter.current += 1;
    clearLoadingTimeout();
    setIsLoading(false);
    pendingQuery.current = null;

    if (wsRef.current && wsRef.current.readyState === WebSocket.OPEN) {
      try { wsRef.current.send(JSON.stringify({ type: 'cancel' })); } catch { /* ignore */ }
    }
  }, [isLoading, clearLoadingTimeout]);

  const clearResponse = useCallback(() => {
    setResponse(null);
    if (cacheKey) responseCache.delete(cacheKey);
  }, [cacheKey]);

  // ── Favorites ───────────────────────────────────────────────────────────

  const toggleFavorite = useCallback((query) => {
    setFavorites((prev) => {
      const trimmed = (query || '').trim();
      const next = prev.includes(trimmed)
        ? prev.filter((f) => f !== trimmed)
        : [trimmed, ...prev];
      saveFavorites(next);
      return next;
    });
  }, []);

  // ── Pinned Responses ────────────────────────────────────────────────────

  const pinResponse = useCallback(() => {
    if (!response) return;
    setPinnedResponses((prev) => {
      if (prev.length >= MAX_PINNED) return prev;
      if (prev.some((p) => p.content === response.content && +p.timestamp === +response.timestamp)) return prev;
      const next = [response, ...prev];
      if (cacheKey) pinnedCache.set(cacheKey, next);
      return next;
    });
  }, [response, cacheKey]);

  const unpinResponse = useCallback((index) => {
    setPinnedResponses((prev) => {
      const next = prev.filter((_, i) => i !== index);
      if (cacheKey) pinnedCache.set(cacheKey, next);
      return next;
    });
  }, [cacheKey]);

  // ── Retry last query ────────────────────────────────────────────────────

  const retryLastQuery = useCallback(() => {
    // Retry the most recent query from history
    if (queryHistory.length > 0) {
      const lastQuery = queryHistory[0].query || queryHistory[0];
      if (lastQuery && typeof lastQuery === 'string') {
        sendQuery(lastQuery);
      }
    }
  }, [queryHistory, sendQuery]);

  // ── Return ──────────────────────────────────────────────────────────────

  return {
    response,
    isLoading,
    connectionStatus,
    sendQuery,
    cancelQuery,
    clearResponse,
    retryLastQuery,
    queryHistory,
    favorites,
    toggleFavorite,
    pinnedResponses,
    pinResponse,
    unpinResponse,
  };
}
