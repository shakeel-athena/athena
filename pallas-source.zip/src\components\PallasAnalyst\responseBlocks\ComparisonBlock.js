/**
 * ComparisonBlock — Side-by-side 2-column comparison
 *
 * Replaces flat tables that compare two states (active vs disconnected,
 * before vs after, on-prem vs cloud, healthy vs unhealthy) with a clean
 * dual-column card layout.
 *
 * Triggered when BlockParser detects:
 *   - Header containing "vs" / "versus" / "compared to"
 *   - OR a 2-column table where the first column header looks like "Metric"
 *     and the other 2 columns are state labels
 *
 * Data shape (from BlockParser):
 *   {
 *     title: 'Active vs Disconnected' | null,
 *     left:  { label: 'Active', accent: 'success' },
 *     right: { label: 'Disconnected', accent: 'warning' },
 *     metrics: [
 *       { name: 'Total Agents', leftValue: 4, rightValue: 42 },
 *       { name: 'Vulnerabilities', leftValue: 120, rightValue: 945 },
 *       ...
 *     ]
 *   }
 */

import { useState } from 'react';
import { THEME, GRADIENTS, SHADOWS, TIMINGS } from '../../../utils/theme';
import { FONT } from '../PallasUI';
import { useAnimatedCounter, formatNumber } from './blockHelpers';

const ACCENT_MAP = {
  success: { color: THEME.success,    glow: 'rgba(16, 185, 129, 0.30)' },
  warning: { color: THEME.warning,    glow: 'rgba(245, 158, 11, 0.30)' },
  danger:  { color: THEME.danger,     glow: 'rgba(239, 68, 68, 0.30)'  },
  primary: { color: THEME.primary,    glow: 'rgba(59, 130, 246, 0.30)' },
  accent:  { color: THEME.primary,    glow: 'rgba(59, 130, 246, 0.30)' },
  muted:   { color: THEME.textMuted,  glow: 'rgba(142, 159, 188, 0.20)'},
};

function getAccent(name) {
  return ACCENT_MAP[name] || ACCENT_MAP.primary;
}

// ─── Single column header card ──────────────────────────────────────────────

function ColumnHeader({ label, accent, total }) {
  const a = getAccent(accent);
  return (
    <div
      style={{
        padding: '10px 14px',
        borderRadius: 8,
        background: `${a.color}12`,
        border: `1px solid ${a.color}40`,
        boxShadow: a.glow ? `0 0 16px ${a.glow}` : 'none',
        textAlign: 'center',
      }}
    >
      <div
        style={{
          fontSize: 10,
          fontWeight: 700,
          color: a.color,
          textTransform: 'uppercase',
          letterSpacing: '0.06em',
          marginBottom: total != null ? 2 : 0,
        }}
      >
        {label}
      </div>
      {total != null && (
        <div
          style={{
            fontFamily: FONT.mono,
            fontSize: 14,
            fontWeight: 700,
            color: a.color,
          }}
        >
          {formatNumber(total)}
        </div>
      )}
    </div>
  );
}

// ─── Single comparison row ──────────────────────────────────────────────────

function ComparisonRow({ metric, leftAccent, rightAccent }) {
  const leftA = getAccent(leftAccent);
  const rightA = getAccent(rightAccent);

  // Animated counters for both sides
  const leftCounter = useAnimatedCounter(
    typeof metric.leftValue === 'number' ? metric.leftValue : 0,
    700
  );
  const rightCounter = useAnimatedCounter(
    typeof metric.rightValue === 'number' ? metric.rightValue : 0,
    700
  );

  // Compute "winner" — which side has the LARGER number, used for visual emphasis
  const lv = Number(metric.leftValue) || 0;
  const rv = Number(metric.rightValue) || 0;
  const leftWins = lv > rv;
  const rightWins = rv > lv;

  return (
    <div
      style={{
        display: 'grid',
        gridTemplateColumns: '1fr auto 1fr',
        alignItems: 'center',
        gap: 12,
        padding: '8px 10px',
        borderRadius: 6,
        marginBottom: 4,
        background: 'rgba(255,255,255,0.015)',
        border: `1px solid ${THEME.borderFaint}`,
      }}
    >
      {/* Left value */}
      <div
        style={{
          fontFamily: FONT.mono,
          fontSize: 14,
          fontWeight: leftWins ? 800 : 600,
          color: leftWins ? leftA.color : THEME.textSecondary,
          textAlign: 'right',
          textShadow: leftWins ? `0 0 8px ${leftA.color}40` : 'none',
        }}
      >
        {typeof metric.leftValue === 'number' ? formatNumber(leftCounter) : (metric.leftValue || '—')}
      </div>

      {/* Metric name (center) */}
      <div
        style={{
          fontSize: 11,
          color: THEME.textMuted,
          fontWeight: 500,
          padding: '0 6px',
          textAlign: 'center',
          minWidth: 100,
          maxWidth: 200,
        }}
      >
        {metric.name}
      </div>

      {/* Right value */}
      <div
        style={{
          fontFamily: FONT.mono,
          fontSize: 14,
          fontWeight: rightWins ? 800 : 600,
          color: rightWins ? rightA.color : THEME.textSecondary,
          textAlign: 'left',
          textShadow: rightWins ? `0 0 8px ${rightA.color}40` : 'none',
        }}
      >
        {typeof metric.rightValue === 'number' ? formatNumber(rightCounter) : (metric.rightValue || '—')}
      </div>
    </div>
  );
}

// ─── Main component ────────────────────────────────────────────────────────

export default function ComparisonBlock({ data }) {
  const title = data?.title;
  const left  = data?.left  || { label: 'A', accent: 'primary' };
  const right = data?.right || { label: 'B', accent: 'accent'  };
  const metrics = data?.metrics || [];

  if (metrics.length === 0) return null;

  // Compute totals (sum of all left values, sum of all right values)
  const leftTotal = metrics.reduce((s, m) => s + (typeof m.leftValue === 'number' ? m.leftValue : 0), 0);
  const rightTotal = metrics.reduce((s, m) => s + (typeof m.rightValue === 'number' ? m.rightValue : 0), 0);

  return (
    <div
      style={{
        margin: '14px 0',
        background: GRADIENTS.card,
        border: `1px solid ${THEME.border}`,
        borderRadius: 12,
        padding: '14px 16px',
        boxShadow: SHADOWS.md + ", inset 0 1px 0 rgba(255,255,255,0.04)",
      }}
    >
      {/* Title */}
      {title && (
        <div
          style={{
            display: 'flex',
            alignItems: 'center',
            gap: 10,
            marginBottom: 12,
          }}
        >
          <span
            style={{
              width: 3,
              height: 14,
              background: GRADIENTS.primaryAccent,
              borderRadius: 2,
              flexShrink: 0,
            }}
          />
          <h4
            style={{
              margin: 0,
              fontSize: 12,
              fontWeight: 700,
              color: THEME.textSecondary,
              textTransform: 'uppercase',
              letterSpacing: '0.05em',
            }}
          >
            {title}
          </h4>
        </div>
      )}

      {/* Column headers */}
      <div
        style={{
          display: 'grid',
          gridTemplateColumns: '1fr auto 1fr',
          alignItems: 'stretch',
          gap: 12,
          marginBottom: 10,
        }}
      >
        <ColumnHeader label={left.label}  accent={left.accent}  total={leftTotal  > 0 ? leftTotal  : null} />
        <div style={{ width: 1, background: THEME.border, opacity: 0.5 }} />
        <ColumnHeader label={right.label} accent={right.accent} total={rightTotal > 0 ? rightTotal : null} />
      </div>

      {/* Comparison rows */}
      <div>
        {metrics.map((m, idx) => (
          <ComparisonRow
            key={`${m.name}-${idx}`}
            metric={m}
            leftAccent={left.accent}
            rightAccent={right.accent}
          />
        ))}
      </div>
    </div>
  );
}
