#!/bin/bash
# Auto-generated restore script

set -e
BACKUP_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="/opt/mcpserver_rizwan/Wazuh-MCP-Server"

echo "⏮️  Pallas Restore Utility"
echo "========================"
echo ""
echo "📁 Restoring from: $BACKUP_DIR"
echo ""

# Restore files
for file in src/wazuh_mcp_server/*.py docker-compose.yml; do
    if [ -f "$BACKUP_DIR/$file" ]; then
        cp "$BACKUP_DIR/$file" "$PROJECT_ROOT/$file"
        echo "  ✅ Restored: $file"
    fi
done

echo ""
echo "✅ Restore complete!"
echo ""
echo "Next steps:"
echo "  1. Validate syntax: python3 -m py_compile src/wazuh_mcp_server/*.py"
echo "  2. Rebuild: docker compose build --no-cache"
echo "  3. Restart: docker compose down && docker compose up -d"
