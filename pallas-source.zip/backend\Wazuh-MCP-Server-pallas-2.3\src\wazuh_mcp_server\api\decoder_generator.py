"""
Wazuh Decoder Generator — LLM-powered decoder creation with validation.

Pallas 4.2: Parent-child PCRE2 architecture.
Generates one parent decoder (prematch) + multiple same-name child decoders,
each extracting a single field via type="pcre2". Based on proven production
patterns that reliably extract 40+ fields from FortiGate, Sophos, etc.
"""

import re
import os
import logging
import xml.etree.ElementTree as ET
from typing import Dict, Any, Optional, List, Tuple

logger = logging.getLogger(__name__)


class DecoderGenerator:
    """Generate and validate Wazuh decoders from raw log samples."""

    MAX_RETRIES = 5

    # Standard Wazuh decoder fields
    STANDARD_FIELDS = [
        "srcip", "dstip", "srcport", "dstport", "user", "action",
        "protocol", "id", "url", "status", "extra_data", "srcuser",
        "dstuser", "data", "system_name",
    ]

    def __init__(self, wazuh_client, llm_client):
        self.wazuh_client = wazuh_client
        self.llm_client = llm_client

    # ── Main Generation Pipeline ─────────────────────────────────────

    async def generate(
        self,
        raw_log: str,
        log_format: str = "syslog",
        device_type: Optional[str] = None,
        vendor: Optional[str] = None,
        expected_fields=None,
    ) -> Dict[str, Any]:
        """
        Full lifecycle: analyze raw log -> generate decoder -> validate -> retry.

        ``expected_fields`` may be a comma-separated string or a list/tuple.

        Returns:
            Dict with keys: status, decoder_xml, extracted_fields, attempts,
                           logtest_output, validation_details, errors
        """
        # Normalize expected_fields to comma-separated string for prompt clarity.
        if isinstance(expected_fields, (list, tuple, set)):
            expected_fields = ",".join(str(f).strip() for f in expected_fields if str(f).strip())
        elif expected_fields is not None and not isinstance(expected_fields, str):
            expected_fields = str(expected_fields)

        result = {
            "status": "failed",
            "decoder_xml": None,
            "extracted_fields": {},
            "attempts": [],
            "logtest_output": None,
            "raw_log": raw_log,
            "log_format": log_format,
            "device_type": device_type,
            "vendor": vendor,
        }

        # Step A: Run logtest to analyze the raw log with existing decoders
        logtest_output = await self._run_logtest(raw_log, log_format)
        result["logtest_output"] = logtest_output

        # Step B-D: Generate, validate, retry loop
        last_decoder_xml = None
        last_errors = []

        for attempt in range(1, self.MAX_RETRIES + 1):
            attempt_record = {"attempt": attempt, "status": "pending", "errors": []}

            try:
                # Build the appropriate prompt
                if attempt == 1:
                    prompt = self._build_llm_prompt(
                        raw_log, logtest_output, device_type, vendor, expected_fields
                    )
                else:
                    prompt = self._build_retry_prompt(
                        raw_log, last_decoder_xml, last_errors,
                        attempt=attempt, max_attempts=self.MAX_RETRIES
                    )

                # Call LLM to generate decoder XML
                llm_response = await self._call_llm_generate(prompt)
                decoder_xml = self._extract_xml_from_response(llm_response)

                if not decoder_xml:
                    attempt_record["status"] = "failed"
                    attempt_record["errors"].append("Could not extract valid XML from LLM response")
                    result["attempts"].append(attempt_record)
                    last_decoder_xml = llm_response
                    last_errors = attempt_record["errors"]
                    continue

                attempt_record["decoder_xml"] = decoder_xml
                last_decoder_xml = decoder_xml

                # Validate the generated decoder
                validation = self._validate_decoder(decoder_xml, raw_log)
                attempt_record["validation"] = validation

                if validation["valid"]:
                    attempt_record["status"] = "success"
                    result["status"] = "success"
                    result["decoder_xml"] = decoder_xml
                    result["extracted_fields"] = validation.get("extracted_fields", {})
                    result["attempts"].append(attempt_record)
                    logger.info(f"Decoder generated successfully on attempt {attempt}")
                    break
                else:
                    attempt_record["status"] = "validation_failed"
                    attempt_record["errors"] = validation.get("errors", [])
                    last_errors = validation.get("errors", [])

            except Exception as e:
                logger.error(f"Decoder generation attempt {attempt} error: {e}")
                attempt_record["status"] = "error"
                attempt_record["errors"].append(str(e))
                last_errors = [str(e)]

            result["attempts"].append(attempt_record)

        # If all attempts failed, include the best decoder we got
        if result["status"] == "failed" and last_decoder_xml:
            result["decoder_xml"] = last_decoder_xml
            result["errors"] = last_errors

        return result

    async def _run_logtest(self, event: str, log_format: str = "syslog") -> Optional[Dict]:
        """Run PUT /logtest to analyze the raw log with existing decoders."""
        try:
            response = await self.wazuh_client.run_logtest(
                event=event,
                log_format=log_format,
                location="decoder-generator",
            )
            if response and "data" in response:
                return response["data"]
            return response
        except Exception as e:
            logger.warning(f"Logtest call failed (non-fatal): {e}")
            return {"error": str(e), "note": "Logtest unavailable, generating without analysis"}

    # ── Log Format Detection ─────────────────────────────────────────

    def _detect_log_format(self, raw_log: str) -> str:
        """Detect the log format to provide targeted prompt guidance."""
        kv_quoted = len(re.findall(r'\w+="[^"]*"', raw_log))
        kv_unquoted = len(re.findall(r'\w+=\S+', raw_log))

        if kv_quoted >= 5:
            return "key_value_quoted"
        if kv_unquoted >= 5:
            return "key_value_unquoted"
        if raw_log.strip().startswith('{') and raw_log.strip().endswith('}'):
            return "json"
        if 'CEF:' in raw_log:
            return "cef"
        if 'LEEF:' in raw_log:
            return "leef"
        if raw_log.count(',') >= 5 and kv_unquoted < 3:
            return "csv"
        return "generic"

    def _detect_vendor_name(self, raw_log: str) -> str:
        """Extract a vendor/product name for decoder naming."""
        # Try common vendor identifiers
        patterns = [
            (r'devname="([^"]+)"', None),          # FortiGate
            (r'device_name="([^"]+)"', None),      # Sophos
            (r'CEF:0\|([^|]+)\|([^|]+)\|', None),  # CEF vendor|product
            (r'hostname="([^"]+)"', None),
        ]
        for pattern, _ in patterns:
            m = re.search(pattern, raw_log)
            if m:
                name = m.group(1).lower()
                # Clean to valid decoder name chars
                name = re.sub(r'[^a-z0-9_-]', '-', name)
                return name[:20]

        return "custom-log"

    # ── Prompt Building ──────────────────────────────────────────────

    def _build_format_guidance(self, log_format: str, expected_fields) -> str:
        """Build format-specific examples using the parent-child PCRE2 pattern.

        Accepts ``expected_fields`` as a comma-separated string or a list/tuple.
        """
        if expected_fields:
            if isinstance(expected_fields, (list, tuple, set)):
                field_list = [str(f).strip() for f in expected_fields if str(f).strip()]
            else:
                field_list = [f.strip() for f in str(expected_fields).split(',') if f.strip()]
        else:
            field_list = ["srcip", "dstip", "srcport", "dstport", "action", "protocol", "status"]

        target_fields = field_list[:10]
        fields_str = ', '.join(target_fields)

        if log_format == "key_value_quoted":
            return f"""LOG FORMAT DETECTED: Key="Value" pairs (FortiGate, Sophos, PaloAlto, etc.)

TARGET FIELDS: {fields_str}

EXAMPLE — FortiGate key="value" decoder (PROVEN PATTERN):

<decoder name="fortigate-traffic">
  <prematch type="pcre2">type="traffic"</prematch>
</decoder>

<decoder name="fortigate-traffic-fields">
  <parent>fortigate-traffic</parent>
  <regex type="pcre2">srcip=(\\d+\\.\\d+\\.\\d+\\.\\d+)</regex>
  <order>srcip</order>
</decoder>

<decoder name="fortigate-traffic-fields">
  <parent>fortigate-traffic</parent>
  <regex type="pcre2">dstip=(\\d+\\.\\d+\\.\\d+\\.\\d+)</regex>
  <order>dstip</order>
</decoder>

<decoder name="fortigate-traffic-fields">
  <parent>fortigate-traffic</parent>
  <regex type="pcre2">srcport=(\\d+)</regex>
  <order>srcport</order>
</decoder>

<decoder name="fortigate-traffic-fields">
  <parent>fortigate-traffic</parent>
  <regex type="pcre2">dstport=(\\d+)</regex>
  <order>dstport</order>
</decoder>

<decoder name="fortigate-traffic-fields">
  <parent>fortigate-traffic</parent>
  <regex type="pcre2">action="([^"]+)"</regex>
  <order>action</order>
</decoder>

<decoder name="fortigate-traffic-fields">
  <parent>fortigate-traffic</parent>
  <regex type="pcre2">proto=(\\d+)</regex>
  <order>protocol</order>
</decoder>

KEY PATTERNS for key="value" logs:
- Quoted values: field="([^"]+)" — captures everything between quotes
- Unquoted values: field=(\\S+) — captures until next space
- IP addresses: field=(\\d+\\.\\d+\\.\\d+\\.\\d+)
- Port numbers: field=(\\d+)"""

        elif log_format == "key_value_unquoted":
            return f"""LOG FORMAT DETECTED: Key=Value pairs (unquoted)

TARGET FIELDS: {fields_str}

Use same parent-child pattern. For unquoted values use field=(\\S+).
For each field, create a separate child decoder with the SAME name."""

        elif log_format == "cef":
            return f"""LOG FORMAT DETECTED: CEF (Common Event Format)

TARGET FIELDS: {fields_str}

CEF STRATEGY:
1. Parent prematch on "CEF:" literal string
2. One child for the pipe-delimited header (can extract multiple fields)
3. Individual children for extension key=value fields

EXAMPLE:
<decoder name="cef-log">
  <prematch type="pcre2">CEF:</prematch>
</decoder>

<decoder name="cef-log-fields">
  <parent>cef-log</parent>
  <regex type="pcre2">CEF:\\d+\\|[^|]+\\|[^|]+\\|([^|]+)\\|(\\d+)\\|([^|]+)\\|(\\d+)\\|</regex>
  <order>extra_data, id, action, status</order>
</decoder>

<decoder name="cef-log-fields">
  <parent>cef-log</parent>
  <regex type="pcre2">src=(\\d+\\.\\d+\\.\\d+\\.\\d+)</regex>
  <order>srcip</order>
</decoder>

<decoder name="cef-log-fields">
  <parent>cef-log</parent>
  <regex type="pcre2">dst=(\\d+\\.\\d+\\.\\d+\\.\\d+)</regex>
  <order>dstip</order>
</decoder>"""

        elif log_format == "json":
            return f"""LOG FORMAT DETECTED: JSON

TARGET FIELDS: {fields_str}

JSON STRATEGY — Use Wazuh's built-in JSON decoder:

<decoder name="json-log">
  <prematch type="pcre2">^\\{{</prematch>
</decoder>

<decoder name="json-log-fields">
  <parent>json-log</parent>
  <plugin_decoder>JSON_Decoder</plugin_decoder>
</decoder>

This automatically extracts all JSON fields. No regex needed."""

        else:
            return f"""LOG FORMAT: Generic / space-delimited

TARGET FIELDS: {fields_str}

Use the parent-child PCRE2 pattern:
1. Parent with a literal prematch identifying this log type
2. Each child extracts ONE field with type="pcre2"
3. Each child scans the full log independently"""

    def _build_llm_prompt(
        self,
        raw_log: str,
        logtest_output: Optional[Dict],
        device_type: Optional[str],
        vendor: Optional[str],
        expected_fields: Optional[str],
    ) -> str:
        """Construct the decoder generation prompt with full context."""

        logtest_section = "No logtest data available."
        if logtest_output and not logtest_output.get("error"):
            logtest_section = self._format_logtest_output(logtest_output)

        hints = []
        if device_type:
            hints.append(f"- Device type: {device_type}")
        if vendor:
            hints.append(f"- Vendor: {vendor}")
        if expected_fields:
            hints.append(f"- Expected fields to extract: {expected_fields}")
        hints_section = "\n".join(hints) if hints else "- No specific hints provided"

        detected_format = self._detect_log_format(raw_log)
        format_guidance = self._build_format_guidance(detected_format, expected_fields)

        return f"""You are a Wazuh 4.x decoder expert. Generate a decoder using the PARENT-CHILD PCRE2 architecture.

RAW LOG:
{raw_log}

LOGTEST ANALYSIS (current decoder state):
{logtest_section}

HINTS:
{hints_section}

{format_guidance}

═══════════════════════════════════════════════════════════════
MANDATORY ARCHITECTURE — PARENT-CHILD PCRE2 PATTERN
═══════════════════════════════════════════════════════════════

You MUST generate decoders using this proven architecture:

1. ONE parent decoder with <prematch> to identify the log type
2. MULTIPLE child decoders, ALL sharing the SAME decoder name
3. Each child extracts exactly ONE field (sometimes 2 if closely related)
4. ALL elements use type="pcre2" for modern regex support

RULES:
- Parent <prematch> must be a LITERAL substring from the raw log
  (Wazuh prematch uses OS_Match = literal substring search)
- All child decoder names MUST be identical (e.g., "mylog-fields")
- Each child has <parent>, <regex type="pcre2">, and <order>
- Each child scans the ENTIRE log independently — field order doesn't matter
- Use PCRE2 syntax in <regex>: [^"]+, \\d+, \\w+, \\S+, \\d{{4}} — all valid
- Do NOT wrap decoders in <group> tags (that's for rules, not decoders)
- Do NOT try to match the entire log in a single regex

PCRE2 REGEX PATTERNS (use these in <regex type="pcre2">):
- IP address:  (\\d+\\.\\d+\\.\\d+\\.\\d+)
- Port/number: (\\d+)
- Quoted value: "([^"]+)"  — captures content between quotes
- Unquoted value: =(\\S+)  — captures until next space
- Word: (\\w+)
- Any chars: (.+) or (.*?)

OUTPUT FORMAT (return ONLY the XML, no explanation):
```xml
<decoder name="parent-name">
  <prematch type="pcre2">literal text from log</prematch>
</decoder>

<decoder name="parent-name-fields">
  <parent>parent-name</parent>
  <regex type="pcre2">fieldA=(\\S+)</regex>
  <order>srcip</order>
</decoder>

<decoder name="parent-name-fields">
  <parent>parent-name</parent>
  <regex type="pcre2">fieldB="([^"]+)"</regex>
  <order>action</order>
</decoder>
```"""

    def _format_logtest_output(self, logtest_data: Dict) -> str:
        """Format logtest API response into readable context for the LLM."""
        lines = []
        output = logtest_data.get("output", logtest_data)
        if isinstance(output, dict):
            predecoder = output.get("predecoder", {})
            if predecoder:
                lines.append("Predecoder output:")
                for key, val in predecoder.items():
                    lines.append(f"  {key}: {val}")

            decoder = output.get("decoder", {})
            if decoder:
                lines.append(f"Matched decoder: {decoder.get('name', 'unknown')}")
                if decoder.get("parent"):
                    lines.append(f"Parent decoder: {decoder['parent']}")
            else:
                lines.append("No existing decoder matched this log.")

            data = output.get("data", {})
            if data:
                lines.append("Extracted fields:")
                for key, val in data.items():
                    lines.append(f"  {key}: {val}")

            rule = output.get("rule", {})
            if rule:
                lines.append(f"Matched rule: {rule.get('id', 'N/A')} - {rule.get('description', '')}")
        else:
            lines.append(str(output))

        return "\n".join(lines) if lines else "No logtest data available."

    # ── Retry Prompt ─────────────────────────────────────────────────

    def _build_retry_prompt(
        self, raw_log: str, decoder_xml: str, errors: List[str],
        attempt: int = 2, max_attempts: int = 5
    ) -> str:
        """Build a retry prompt with progressive simplification strategy."""
        errors_text = "\n".join(f"- {e}" for e in errors)

        if attempt <= 2:
            strategy = """STRATEGY: Fix the specific errors below. Keep the parent-child PCRE2 architecture.
- If a child's regex failed: fix that child's pattern only, don't change working children
- If prematch failed: use a shorter literal string that appears EXACTLY in the raw log
- If group count wrong: ensure each child has exactly 1 capture group and 1 field in <order>
- Remember: all child decoders must have the SAME name"""

        elif attempt <= 4:
            strategy = """STRATEGY: SIMPLIFY. Reduce to fewer children. Extract only core fields.

Generate:
- 1 parent decoder with a short literal prematch (2-3 words from the log)
- 3-4 child decoders only: srcip, dstip, action, protocol
- All children MUST have the SAME decoder name
- Each child: <regex type="pcre2">field=(\\S+)</regex> or field="([^"]+)"

MINIMAL EXAMPLE:
<decoder name="simple-log">
  <prematch type="pcre2">srcip=</prematch>
</decoder>

<decoder name="simple-log-fields">
  <parent>simple-log</parent>
  <regex type="pcre2">srcip=(\\d+\\.\\d+\\.\\d+\\.\\d+)</regex>
  <order>srcip</order>
</decoder>

<decoder name="simple-log-fields">
  <parent>simple-log</parent>
  <regex type="pcre2">dstip=(\\d+\\.\\d+\\.\\d+\\.\\d+)</regex>
  <order>dstip</order>
</decoder>

<decoder name="simple-log-fields">
  <parent>simple-log</parent>
  <regex type="pcre2">action="([^"]+)"</regex>
  <order>action</order>
</decoder>"""

        else:
            strategy = """STRATEGY: ULTRA-MINIMAL. Parent + 1 child only. Cannot fail.

<decoder name="minimal-log">
  <prematch type="pcre2">srcip=</prematch>
</decoder>

<decoder name="minimal-log-fields">
  <parent>minimal-log</parent>
  <regex type="pcre2">srcip=(\\d+\\.\\d+\\.\\d+\\.\\d+)</regex>
  <order>srcip</order>
</decoder>"""

        return f"""Your Wazuh decoder FAILED validation (attempt {attempt}/{max_attempts}). Fix it.

RAW LOG:
{raw_log}

YOUR FAILED DECODER:
{decoder_xml}

ERRORS:
{errors_text}

{strategy}

CRITICAL RULES:
1. Use PARENT-CHILD architecture — one parent (prematch) + multiple same-name children
2. Parent <prematch> must be a LITERAL substring of the raw log (no regex in prematch)
3. All child decoders must have the SAME name (e.g., "mylog-fields")
4. Each child uses <regex type="pcre2"> with EXACTLY 1 capture group
5. Each child has <order> with EXACTLY 1 field name
6. PCRE2 is valid: [^"]+ and \\d{{4}} and \\S+ all work with type="pcre2"

Return ONLY the corrected XML:"""

    # ── LLM Call ─────────────────────────────────────────────────────

    async def _call_llm_generate(self, prompt: str) -> str:
        """Call the LLM to generate decoder XML."""
        system_prompt = (
            "You are a Wazuh 4.x decoder specialist. Generate valid Wazuh XML decoders "
            "using the PARENT-CHILD PCRE2 architecture. "
            "Return ONLY XML decoder blocks, no explanations or markdown formatting. "
            "RULES: One parent decoder with <prematch> (literal substring from the log). "
            "Multiple child decoders all with the SAME name, each using "
            '<regex type="pcre2"> to extract exactly ONE field. '
            "For quoted values use ([^\"]+). For IPs use (\\d+\\.\\d+\\.\\d+\\.\\d+). "
            "Never try to match the entire log in a single regex."
        )
        response = await self.llm_client.generate(
            prompt=prompt,
            system_prompt=system_prompt,
            max_tokens=7000,
            temperature=0.2,
        )
        return response

    # ── XML Extraction ───────────────────────────────────────────────

    def _extract_xml_from_response(self, llm_response: str) -> Optional[str]:
        """Extract decoder XML from the LLM response text."""
        if not llm_response:
            return None

        # Try to find XML in code blocks first
        code_block = re.search(r"```(?:xml)?\s*\n?(.*?)```", llm_response, re.DOTALL)
        if code_block:
            xml_text = code_block.group(1).strip()
        else:
            xml_text = llm_response.strip()

        # Find all <decoder>...</decoder> blocks
        decoder_blocks = re.findall(
            r"(<decoder\b[^>]*>.*?</decoder>)", xml_text, re.DOTALL
        )

        if not decoder_blocks:
            if "<decoder" in xml_text and "</decoder>" in xml_text:
                start = xml_text.index("<decoder")
                end = xml_text.rindex("</decoder>") + len("</decoder>")
                return xml_text[start:end].strip()
            return None

        return "\n\n".join(decoder_blocks)

    # ── Validation ───────────────────────────────────────────────────

    def _validate_decoder(self, decoder_xml: str, raw_log: str) -> Dict[str, Any]:
        """
        Validate a parent-child decoder set against the raw log.

        Supports:
        - Parent-child architecture (parent prematch + multiple children)
        - Single decoder (legacy fallback)
        - type="pcre2" regex (pass-through to Python regex)
        - JSON_Decoder plugin (skip regex validation)
        - Partial success: valid if parent + at least 1 child works
        """
        result = {
            "valid": False,
            "errors": [],
            "warnings": [],
            "extracted_fields": {},
            "parent_valid": False,
            "children_valid": 0,
            "children_total": 0,
        }

        # Wrap in root element for multi-decoder parsing
        wrapped = f"<root>{decoder_xml}</root>"

        # Step 1: Parse XML
        try:
            root = ET.fromstring(wrapped)
        except ET.ParseError as e:
            result["errors"].append(f"Invalid XML structure: {e}")
            return result

        decoders = root.findall("decoder")
        if not decoders:
            result["errors"].append("No <decoder> elements found")
            return result

        # Step 2: Classify decoders into parent and children
        parent_decoders = []
        child_decoders = []
        for dec in decoders:
            if dec.find("parent") is not None:
                child_decoders.append(dec)
            elif dec.find("prematch") is not None:
                parent_decoders.append(dec)
            else:
                # Legacy: decoder with regex but no parent — treat as standalone
                child_decoders.append(dec)

        # Step 3: Validate parent decoder(s)
        for parent_el in parent_decoders:
            name = parent_el.get("name", "unknown")
            prematch_el = parent_el.find("prematch")
            if prematch_el is not None and prematch_el.text:
                prematch_text = prematch_el.text.strip()
                is_pcre2 = prematch_el.get("type", "").lower() == "pcre2"

                if is_pcre2:
                    prematch_ok = self._test_prematch_pcre2(prematch_text, raw_log)
                else:
                    prematch_ok = self._test_prematch(prematch_text, raw_log)

                if prematch_ok:
                    result["parent_valid"] = True
                else:
                    result["errors"].append(
                        f"Parent decoder '{name}': <prematch> does not match the raw log. "
                        f"Pattern: {prematch_text}"
                    )

        # If no explicit parent, check if it's a single-decoder (legacy)
        if not parent_decoders and child_decoders:
            # Legacy single-decoder mode — validate each independently
            result["parent_valid"] = True  # No parent to validate

        # Step 4: Validate child decoders
        result["children_total"] = len(child_decoders)
        child_names = set()

        for child_el in child_decoders:
            name = child_el.get("name", "unknown")
            child_names.add(name)

            # Check for JSON_Decoder plugin (skip regex validation)
            plugin_el = child_el.find("plugin_decoder")
            if plugin_el is not None and plugin_el.text:
                if "JSON" in plugin_el.text:
                    result["children_valid"] += 1
                    result["extracted_fields"]["_json_decoder"] = "active"
                    continue

            regex_el = child_el.find("regex")
            order_el = child_el.find("order")

            if regex_el is None or not regex_el.text:
                # Parent-only decoder or prematch-only — valid structure
                prematch_el = child_el.find("prematch")
                if prematch_el is not None:
                    continue
                result["warnings"].append(f"Child '{name}': no <regex> element")
                continue

            regex_pattern = regex_el.text.strip()
            is_pcre2 = regex_el.get("type", "").lower() == "pcre2"
            order_text = order_el.text.strip() if (order_el is not None and order_el.text) else ""
            field_names = [f.strip() for f in order_text.split(",") if f.strip()]

            # Extract fields using appropriate regex engine
            extracted = self._extract_fields_from_log(
                regex_pattern, raw_log, field_names, is_pcre2=is_pcre2
            )

            if extracted.get("error"):
                result["warnings"].append(
                    f"Child '{name}' (fields: {', '.join(field_names)}): "
                    f"regex failed — {extracted['error']}"
                )
            elif not extracted.get("fields"):
                result["warnings"].append(
                    f"Child '{name}': regex matched but captured no fields"
                )
            else:
                # Check group count matches order count
                captured_count = extracted.get("group_count", 0)
                if field_names and captured_count != len(field_names):
                    result["warnings"].append(
                        f"Child '{name}': capture groups ({captured_count}) "
                        f"!= order fields ({len(field_names)})"
                    )
                else:
                    result["children_valid"] += 1
                    result["extracted_fields"].update(extracted["fields"])

        # Step 5: Warn if child names are not consistent
        if len(child_names) > 1 and parent_decoders:
            result["warnings"].append(
                f"Child decoders have inconsistent names: {child_names}. "
                f"All children should share the same name for Wazuh to fire all of them."
            )

        # Step 6: Determine overall validity
        # Valid if: parent OK + at least 1 child extracted fields successfully
        # (partial success is acceptable — some children may fail for optional fields)
        if result["parent_valid"] and result["children_valid"] >= 1:
            result["valid"] = True
            # Promote warnings about failed children (not errors — decoder is still usable)
            if result["children_valid"] < result["children_total"]:
                failed = result["children_total"] - result["children_valid"]
                logger.info(
                    f"Decoder partially valid: {result['children_valid']}/{result['children_total']} "
                    f"children passed, {failed} had warnings"
                )
        elif result["parent_valid"] and result["children_total"] == 0:
            # Parent-only decoder (prematch identifier) — valid but no extraction
            result["valid"] = True
            result["warnings"].append("Parent-only decoder — no field extraction children found")
        else:
            # Convert critical warnings to errors for failed state
            if not result["parent_valid"]:
                pass  # Error already added above
            if result["children_valid"] == 0 and result["children_total"] > 0:
                result["errors"].append(
                    f"All {result['children_total']} child decoders failed regex validation. "
                    f"Details: {'; '.join(result['warnings'])}"
                )

        return result

    # ── Pattern Testing ──────────────────────────────────────────────

    def _test_prematch(self, prematch_pattern: str, text: str) -> bool:
        """
        Test Wazuh prematch (OS_Match) — literal substring search.
        Falls back to regex if literal fails and pattern contains wildcards.
        """
        try:
            if prematch_pattern in text:
                return True
            # Try Wazuh OS_Match wildcard conversion
            py_pattern = self._wazuh_to_python_regex(prematch_pattern)
            return bool(re.search(py_pattern, text))
        except re.error:
            return prematch_pattern in text

    def _test_prematch_pcre2(self, prematch_pattern: str, text: str) -> bool:
        """Test prematch with type="pcre2" — use as regex directly."""
        try:
            # First try literal (most prematch patterns are still literal even with pcre2)
            if prematch_pattern in text:
                return True
            return bool(re.search(prematch_pattern, text))
        except re.error as e:
            logger.debug(f"PCRE2 prematch error for '{prematch_pattern}': {e}")
            return prematch_pattern in text

    def _wazuh_to_python_regex(self, wazuh_pattern: str) -> str:
        """
        Convert Wazuh OS_Regex syntax to Python regex.

        Key difference: Wazuh \\. means "any char" (Python's .),
        NOT "literal dot" (which is what \\. means in PCRE).
        """
        result = wazuh_pattern
        # Wazuh \\.+ → Python .*? (non-greedy any chars)
        result = result.replace("\\.+", ".*?")
        # Wazuh \\. → Python . (any single char)
        result = result.replace("\\.", ".")
        return result

    def _extract_fields_from_log(
        self, regex_pattern: str, raw_log: str, field_names: List[str],
        is_pcre2: bool = False
    ) -> Dict[str, Any]:
        """
        Simulate Wazuh regex field extraction against the raw log.

        Args:
            regex_pattern: The regex from <regex> element
            raw_log: The raw log line to test against
            field_names: Field names from <order> element
            is_pcre2: If True, pattern is PCRE2 (use directly as Python regex)

        Returns:
            Dict with: fields (name->value map), group_count, error (if any)
        """
        try:
            if is_pcre2:
                # PCRE2 is nearly identical to Python regex — use directly
                py_regex = regex_pattern
            else:
                # Legacy Wazuh OS_Regex — convert
                py_regex = self._wazuh_to_python_regex(regex_pattern)

            match = re.search(py_regex, raw_log)

            if not match:
                return {"fields": {}, "group_count": 0, "error": "Regex did not match the raw log"}

            groups = match.groups()
            group_count = len(groups)

            fields = {}
            for idx, value in enumerate(groups):
                if value is not None:
                    if idx < len(field_names):
                        fields[field_names[idx]] = value
                    else:
                        fields[f"group_{idx+1}"] = value

            return {"fields": fields, "group_count": group_count, "error": None}

        except re.error as e:
            return {"fields": {}, "group_count": 0, "error": f"Invalid regex: {e}"}

