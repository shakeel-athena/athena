#!/bin/bash

echo "🔧 Fixing Suricata Index Pattern"
echo "================================="

# Backup original
cp /opt/mcpserver/Wazuh-MCP-Server/src/wazuh_mcp_server/api/suricata_client.py \
   /opt/mcpserver/Wazuh-MCP-Server/src/wazuh_mcp_server/api/suricata_client.py.backup

echo "✅ Backup created"

# Update index pattern
sed -i 's/self.index_pattern = "suricata-\*"/self.index_pattern = "suricata-1.1.0-*"/' \
  /opt/mcpserver/Wazuh-MCP-Server/src/wazuh_mcp_server/api/suricata_client.py

echo "✅ Index pattern updated to: suricata-1.1.0-*"

# Verify change
if grep -q 'self.index_pattern = "suricata-1.1.0-\*"' \
   /opt/mcpserver/Wazuh-MCP-Server/src/wazuh_mcp_server/api/suricata_client.py; then
    echo "✅ Verification passed"
else
    echo "❌ Update failed, restoring backup"
    mv /opt/mcpserver/Wazuh-MCP-Server/src/wazuh_mcp_server/api/suricata_client.py.backup \
       /opt/mcpserver/Wazuh-MCP-Server/src/wazuh_mcp_server/api/suricata_client.py
    exit 1
fi

# Restart server
cd /opt/mcpserver/Wazuh-MCP-Server/
docker-compose restart

echo ""
echo "🎉 Fix complete! Server restarting..."
echo ""
echo "Test with:"
echo "  curl -X POST http://localhost:3000/mcp -H 'Content-Type: application/json' \\"
echo "    -d '{\"jsonrpc\":\"2.0\",\"id\":1,\"method\":\"tools/call\",\"params\":{\"name\":\"get_suricata_alerts\",\"arguments\":{\"limit\":5}}}' | jq ."
