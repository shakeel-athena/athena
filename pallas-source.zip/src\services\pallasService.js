/**
 * Pallas AI Analyst Service
 *
 * MCP (Model Context Protocol) client + WebSocket factory for the Pallas server.
 * Completely separate from apiClient.js — Pallas uses its own Origin-based auth,
 * not Keycloak JWT.
 */

import keycloak from '../config/keycloak';

const PALLAS_BASE_URL = process.env.REACT_APP_PALLAS_URL || '/ai-analyst';
const PALLAS_WS_URL = process.env.REACT_APP_PALLAS_WS_URL || '';
const PALLAS_API_KEY = process.env.REACT_APP_PALLAS_API_KEY || 'aI9xT2kP7vR4nQ8mW6sE3bH5dL1fG0jN2yU4cX9zA7';

// ---------------------------------------------------------------------------
// Keycloak JWT helper — forwards user identity alongside API key
// ---------------------------------------------------------------------------

// Refresh the JWT if it'll expire within this many seconds. 30s gives a
// comfortable buffer for in-flight requests after a refresh.
const TOKEN_MIN_VALIDITY_SEC = 30;

/**
 * Return a valid (refreshed if necessary) Keycloak JWT.
 *
 * Uses keycloak-js's updateToken(minValidity) which proactively refreshes the
 * token using the stored refresh token if the access token will expire within
 * `minValidity` seconds. Falls back to the stored token (sessionStorage /
 * localStorage) when keycloak isn't initialized — that path is used by the
 * apikey-only auth mode where there is no SSO.
 */
async function getValidKeycloakToken() {
  // apikey mode or pre-init: fall back to whatever's in storage (legacy path)
  if (!keycloak || !keycloak.authenticated) {
    try {
      return sessionStorage.getItem('keycloak_token') || localStorage.getItem('keycloak_token') || null;
    } catch {
      return null;
    }
  }
  try {
    await keycloak.updateToken(TOKEN_MIN_VALIDITY_SEC);
  } catch (e) {
    // updateToken rejects if the refresh token is also expired/invalid.
    // Fall through to return whatever current token we have — the request
    // will 401 and authedFetch's retry path will then surface a clear
    // "session expired" error to the user.
    console.warn('[Pallas] Proactive token refresh failed:', e?.message || e);
  }
  return keycloak.token || null;
}

/**
 * Force-refresh the JWT (used after a 401). Returns true on success.
 * Also rewrites the stored copy so any consumer that still reads from
 * storage (older code paths, websockets) sees the fresh token.
 */
async function forceRefreshKeycloakToken() {
  if (!keycloak || !keycloak.authenticated) return false;
  try {
    await keycloak.updateToken(-1); // -1 forces a refresh regardless of validity
    if (keycloak.token) {
      try { sessionStorage.setItem('keycloak_token', keycloak.token); } catch {}
    }
    return true;
  } catch (e) {
    console.warn('[Pallas] Force token refresh failed:', e?.message || e);
    return false;
  }
}

async function authHeaders() {
  const headers = {
    'x-api-key': PALLAS_API_KEY,
  };
  // Parent-frame auth (iframe deployments — e.g. Wazuh dashboard plugin):
  // the parent posts its Keycloak token via postMessage on iframe load, and
  // we use it directly. This avoids in-iframe Keycloak silent-SSO which is
  // blocked by browser ITP/ETP/SameSite policies in third-party contexts.
  const parentAuth = (typeof window !== 'undefined') ? window.__pallasParentAuth : null;
  if (parentAuth && parentAuth.token) {
    headers['Authorization'] = `Bearer ${parentAuth.token}`;
    if (parentAuth.username) {
      // Pallas backend reads X-Pallas-Iframe-User as the audit-trail actor
      // when forwarding write actions to Agelia. Body analyst_name is also
      // populated from this for endpoints that read from body.
      headers['X-Pallas-Iframe-User'] = parentAuth.username;
    }
    return headers;
  }
  const jwt = await getValidKeycloakToken();
  if (jwt) {
    headers['Authorization'] = `Bearer ${jwt}`;
  }
  return headers;
}

/**
 * Return the current analyst's display name for incident-store actor fields.
 *
 * Reads `preferred_username` from the parsed Keycloak token (the standard
 * OIDC claim). Falls back to `name`, `email`, or 'SOC Analyst' literal as
 * a last resort if the token isn't available (e.g. apikey-only auth mode,
 * or Keycloak not initialized yet).
 *
 * The Pallas backend currently uses whatever is sent in the body's
 * `analyst_name` field for incident_store updates and Jira comments.
 * Sending the real username here keeps Pallas's audit trail consistent
 * with Agelia's audit trail (which extracts the username server-side
 * from the validated JWT and never trusts the body field).
 */
export function getCurrentAnalystName() {
  try {
    // Parent-frame mode: prefer the username posted by the parent (Wazuh plugin)
    // since there is no local Keycloak session to read from.
    if (typeof window !== 'undefined' && window.__pallasParentAuth) {
      const p = window.__pallasParentAuth;
      if (p.username) return p.username;
      if (p.displayName) return p.displayName;
    }
    if (keycloak && keycloak.tokenParsed) {
      const t = keycloak.tokenParsed;
      return t.preferred_username || t.name || t.email || 'SOC Analyst';
    }
  } catch (_) {
    // Fall through to default
  }
  return 'SOC Analyst';
}

/**
 * fetch() wrapper that:
 *   1. attaches the API key + a fresh JWT (proactive refresh before request)
 *   2. on a 401 response, force-refreshes the JWT and retries once
 *   3. honors an optional AbortSignal for caller-controlled timeouts
 * Returns the Response object — caller decides how to interpret.
 */
// Request a fresh token from the parent frame (iframe-mode only). Resolves to
// true once a new token arrives within `timeoutMs`, false on timeout. The
// parent listens for { type: 'pallas-iframe-needs-token' } and re-posts.
async function requestFreshTokenFromParent(timeoutMs = 5000) {
  if (typeof window === 'undefined' || !window.__pallasParentAuth) return false;
  const beforeReceivedAt = window.__pallasParentAuth.receivedAt || 0;
  try {
    window.parent.postMessage({ type: 'pallas-iframe-needs-token' }, '*');
  } catch (_) {
    return false;
  }
  return new Promise((resolve) => {
    const start = Date.now();
    const interval = setInterval(() => {
      const cur = (window.__pallasParentAuth && window.__pallasParentAuth.receivedAt) || 0;
      if (cur > beforeReceivedAt) {
        clearInterval(interval);
        resolve(true);
      } else if (Date.now() - start > timeoutMs) {
        clearInterval(interval);
        resolve(false);
      }
    }, 100);
  });
}

async function authedFetch(url, options = {}) {
  const buildOptions = async () => ({
    ...options,
    headers: {
      ...(options.headers || {}),
      ...(await authHeaders()),
    },
  });

  let response = await fetch(url, await buildOptions());

  if (response.status === 401) {
    // Iframe (parent-auth) mode — ask parent to post a fresh token, then retry
    if (typeof window !== 'undefined' && window.__pallasParentAuth) {
      const got = await requestFreshTokenFromParent();
      if (got) {
        response = await fetch(url, await buildOptions());
      }
    } else {
      // Standalone Keycloak mode — force-refresh and retry
      const refreshed = await forceRefreshKeycloakToken();
      if (refreshed) {
        response = await fetch(url, await buildOptions());
      }
    }
  }

  return response;
}

// ---------------------------------------------------------------------------
// Config
// ---------------------------------------------------------------------------

export const PALLAS_CONFIG = {
  get baseUrl() {
    // If absolute URL provided, use as-is; otherwise resolve against origin
    if (PALLAS_BASE_URL.startsWith('http')) return PALLAS_BASE_URL;
    return `${window.location.origin}${PALLAS_BASE_URL}`;
  },
  get wsUrl() {
    // Explicit WS URL takes precedence (supports reverse proxy configs)
    if (PALLAS_WS_URL) {
      const wsBase = PALLAS_WS_URL.replace(/\/$/, '');
      return `${wsBase}/ws/chat?api_key=${PALLAS_API_KEY}`;
    }
    // Derive from base URL — replace http(s) with ws(s)
    const base = this.baseUrl;
    const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
    const hostPath = base.replace(/^https?:\/\//, '');
    return `${protocol}//${hostPath}/ws/chat?api_key=${PALLAS_API_KEY}`;
  },
  get apiKey() {
    return PALLAS_API_KEY;
  },
};

// ---------------------------------------------------------------------------
// Internal helpers
// ---------------------------------------------------------------------------

let _requestId = 0;
const nextId = () => ++_requestId;

async function mcpRequest(method, params = {}) {
  const url = `${PALLAS_CONFIG.baseUrl}/`;
  const body = {
    jsonrpc: '2.0',
    method,
    params,
    id: nextId(),
  };

  const response = await authedFetch(url, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Accept': 'application/json',
    },
    body: JSON.stringify(body),
  });

  if (!response.ok) {
    if (response.status === 401) {
      throw new Error(
        (typeof window !== 'undefined' && window.__pallasParentAuth)
          ? 'Auth refresh failed — your Wazuh session may have ended. Please reload the Wazuh dashboard tab.'
          : 'Session expired — please refresh the page to continue'
      );
    }
    throw new Error(`MCP HTTP error: ${response.status} ${response.statusText}`);
  }

  const data = await response.json();

  if (data.error) {
    throw new Error(data.error.message || 'MCP error');
  }

  return data.result;
}

// ---------------------------------------------------------------------------
// MCP Protocol Methods
// ---------------------------------------------------------------------------

/**
 * Initialize MCP session — returns server info + capabilities
 */
export async function mcpInitialize() {
  return mcpRequest('initialize', {
    protocolVersion: '2025-06-18',
    capabilities: {},
    clientInfo: { name: 'athena-pallas', version: '1.0.0' },
  });
}

/**
 * List all available MCP tools
 */
export async function mcpListTools() {
  const result = await mcpRequest('tools/list', {});
  return result?.tools || [];
}

/**
 * Call an MCP tool and return the parsed result
 * @param {string} toolName - Tool name (e.g. 'get_wazuh_agents')
 * @param {object} args - Tool arguments
 * @returns {{ text: string, isError: boolean }}
 */
export async function mcpCall(toolName, args = {}) {
  const result = await mcpRequest('tools/call', {
    name: toolName,
    arguments: args,
  });

  const content = result?.content?.[0];
  return {
    text: content?.text || '',
    isError: result?.isError || false,
  };
}

// ---------------------------------------------------------------------------
// REST Endpoints (non-MCP)
// ---------------------------------------------------------------------------

/**
 * Fetch server health status
 */
export async function fetchHealth() {
  const response = await authedFetch(`${PALLAS_CONFIG.baseUrl}/health`);
  if (!response.ok) throw new Error(`Health check failed: ${response.status}`);
  return response.json();
}

/**
 * Fetch server meta — tool health, feature flags.
 * Used by workspace layout for NavigationRail + StatusBar health dots.
 *
 * The Pallas server exposes /health (not /meta). We fetch /health and
 * map its `services` object into the shape the frontend expects:
 *   { cti_enabled, ollama_enabled, services }
 *
 * @returns {{ cti_enabled: boolean, ollama_enabled: boolean, services: object }}
 */
export async function fetchMeta() {
  const response = await authedFetch(`${PALLAS_CONFIG.baseUrl}/health`);
  if (!response.ok) throw new Error(`Meta fetch failed: ${response.status}`);
  const data = await response.json();

  // Map /health services into the meta shape the workspace layout expects
  const svc = data.services || {};
  return {
    cti_enabled: svc.suricata_ids === 'healthy',
    ollama_enabled: Boolean(svc.query_orchestrator && svc.query_orchestrator !== 'unhealthy'),
    services: svc,
    version: data.version,
    status: data.status,
  };
}

/**
 * Authenticated POST to a Pallas REST endpoint.
 * Used by AttackNarrative, DecoderLab, DetectIOC for non-MCP endpoints.
 *
 * Auto-refreshes the JWT before the request and retries once on a 401.
 * If the refresh token is also expired, throws a clear "Session expired"
 * error so the UI can prompt the user to reload.
 *
 * Optionally accepts a `timeoutMs` so callers (e.g. narrative generation,
 * which legitimately runs up to 180s on the backend) can pick an explicit
 * client-side timeout that matches the backend rather than relying on the
 * browser's default ~30-90s. Throws an `AbortError` (`err.name === 'AbortError'`)
 * on timeout so the caller can render a tailored error.
 *
 * @param {string} path - Endpoint path (e.g. '/api/narrative/enhance')
 * @param {object} body - JSON body
 * @param {{ timeoutMs?: number }} [opts]
 * @returns {Promise<any>} Parsed JSON response
 */
export async function pallasPost(path, body = {}, opts = {}) {
  const { timeoutMs } = opts;
  const ctrl = timeoutMs ? new AbortController() : null;
  const timer = ctrl ? setTimeout(() => ctrl.abort(), timeoutMs) : null;

  try {
    const response = await authedFetch(`${PALLAS_CONFIG.baseUrl}${path}`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(body),
      signal: ctrl?.signal,
    });
    if (!response.ok) {
      const errText = await response.text().catch(() => '');
      if (response.status === 401) {
        throw new Error(
        (typeof window !== 'undefined' && window.__pallasParentAuth)
          ? 'Auth refresh failed — your Wazuh session may have ended. Please reload the Wazuh dashboard tab.'
          : 'Session expired — please refresh the page to continue'
      );
      }
      throw new Error(response.status === 404
        ? `Endpoint ${path} not available. Ensure the MCP server has been updated.`
        : `HTTP ${response.status}: ${errText}`);
    }
    return response.json();
  } finally {
    if (timer) clearTimeout(timer);
  }
}

// ---------------------------------------------------------------------------
// WebSocket Factory
// ---------------------------------------------------------------------------

/**
 * Create a WebSocket connection to the Pallas chat endpoint.
 * Returns the raw WebSocket instance — consumers manage lifecycle.
 */
export function createChatSocket() {
  return new WebSocket(PALLAS_CONFIG.wsUrl);
}

// ---------------------------------------------------------------------------
// Tool Metadata (for Tool Runner UI)
// ---------------------------------------------------------------------------

export const PALLAS_TOOL_CATEGORIES = [
  {
    name: 'Alerts & Events',
    tools: [
      'get_wazuh_alerts',
      'get_wazuh_alert_summary',
      'analyze_alert_patterns',
      'search_security_events',
      'get_top_security_threats',
    ],
  },
  {
    name: 'Agents',
    tools: [
      'get_wazuh_agents',
      'get_wazuh_running_agents',
      'check_agent_health',
      'get_agent_processes',
      'get_agent_ports',
      'get_agent_configuration',
    ],
  },
  {
    name: 'Vulnerabilities',
    tools: [
      'get_wazuh_vulnerabilities',
      'get_wazuh_critical_vulnerabilities',
      'get_wazuh_vulnerability_summary',
    ],
  },
  {
    name: 'Intelligence & Compliance',
    tools: [
      'analyze_security_threat',
      'check_ioc_reputation',
      'perform_risk_assessment',
      'generate_security_report',
      'run_compliance_check',
    ],
  },
  {
    name: 'System & Cluster',
    tools: [
      'get_wazuh_statistics',
      'get_wazuh_weekly_stats',
      'get_wazuh_cluster_health',
      'get_wazuh_cluster_nodes',
      'get_wazuh_rules_summary',
      'get_wazuh_remoted_stats',
      'get_wazuh_log_collector_stats',
      'search_wazuh_manager_logs',
      'get_wazuh_manager_error_logs',
      'validate_wazuh_connection',
    ],
  },
];
