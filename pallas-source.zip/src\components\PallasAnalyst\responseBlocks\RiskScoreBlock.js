/**
 * RiskScoreBlock — Animated SVG gauge dial for risk scores
 *
 * Replaces "Overall Risk: HIGH (Score: 836)" plain-text rendering with a
 * proper risk dial visualization.
 *
 * Features:
 *   - Hand-rolled SVG semi-circular gauge (no external chart libs)
 *   - Animated needle sweep from 0 to score on mount
 *   - Animated counter for the numeric score
 *   - Color zones: green (0-25%) → amber (25-50%) → orange (50-75%) → red (75-100%)
 *   - The needle, score number, and "level" label all animate together
 *   - Score level pill (CRITICAL / HIGH / MEDIUM / LOW) with matching glow
 *   - Subtle Ageleia card styling, fully responsive via SVG viewBox
 *
 * Data shape (from BlockParser):
 *   {
 *     level: 'critical' | 'high' | 'medium' | 'low',
 *     score: 836,
 *     max:   1000
 *   }
 */

import { useState, useEffect } from 'react';
import { THEME, GRADIENTS, SHADOWS, GLOWS, TIMINGS } from '../../../utils/theme';
import { FONT } from '../PallasUI';
import { useAnimatedCounter, useReducedMotion, useContainerWidth } from './blockHelpers';

const BP_HERO = 720;

// ─── Color zones ────────────────────────────────────────────────────────────

const ZONE_COLORS = {
  low:      THEME.success,    // green
  medium:   THEME.sevMedium,  // amber
  high:     THEME.sevHigh,    // orange
  critical: THEME.sevCritical,// red
};

const ZONE_GLOWS = {
  low:      GLOWS.success,
  medium:   GLOWS.warning,
  high:     GLOWS.warning,
  critical: GLOWS.danger,
};

const ZONE_LABELS = {
  low:      'LOW',
  medium:   'MEDIUM',
  high:     'HIGH',
  critical: 'CRITICAL',
};

// Convert percentage [0..1] → angle in degrees [180..360] (semi-circle, left to right)
function pctToAngle(pct) {
  return 180 + Math.max(0, Math.min(1, pct)) * 180;
}

// Convert angle (deg) + radius → x,y on the arc circle (centered at cx,cy)
function polarToCartesian(cx, cy, r, angleDeg) {
  const rad = (angleDeg - 90) * Math.PI / 180;
  return {
    x: cx + r * Math.cos(rad),
    y: cy + r * Math.sin(rad),
  };
}

// Build an SVG arc path between two angles
function arcPath(cx, cy, r, startAngle, endAngle) {
  const start = polarToCartesian(cx, cy, r, endAngle);
  const end   = polarToCartesian(cx, cy, r, startAngle);
  const largeArc = endAngle - startAngle > 180 ? 1 : 0;
  return [
    'M', start.x, start.y,
    'A', r, r, 0, largeArc, 0, end.x, end.y,
  ].join(' ');
}

// ─── Component ──────────────────────────────────────────────────────────────

export default function RiskScoreBlock({ data, onPivot }) {
  const reduced = useReducedMotion();
  const [mounted, setMounted] = useState(false);
  const [containerRef, containerWidth] = useContainerWidth();
  const useHeroLayout = containerWidth >= BP_HERO;

  useEffect(() => {
    if (reduced) {
      setMounted(true);
      return;
    }
    const id = requestAnimationFrame(() => setMounted(true));
    return () => cancelAnimationFrame(id);
  }, [reduced]);

  const score = Number(data?.score) || 0;
  const max   = Number(data?.max)   || 1000;
  const level = String(data?.level || 'medium').toLowerCase();
  const pct   = Math.max(0, Math.min(1, score / max));

  const zoneColor = ZONE_COLORS[level] || ZONE_COLORS.medium;
  const zoneGlow  = ZONE_GLOWS[level]  || ZONE_GLOWS.medium;
  const zoneLabel = ZONE_LABELS[level] || level.toUpperCase();

  // Animated counter for the score number
  const animatedScore = useAnimatedCounter(score, 1100);

  // Geometry — semi-circle gauge
  // viewBox: 200 wide × 130 tall (gives room for label below)
  const VIEW_W = 200;
  const VIEW_H = 130;
  const cx = 100;
  const cy = 110;     // center near the bottom so the arc opens upward
  const radius = 80;
  const trackStroke = 14;

  // Color zones along the arc (4 segments, each 25% of 180°)
  const zones = [
    { from: 0,    to: 0.25, color: THEME.success     },
    { from: 0.25, to: 0.50, color: THEME.sevMedium   },
    { from: 0.50, to: 0.75, color: THEME.sevHigh     },
    { from: 0.75, to: 1.00, color: THEME.sevCritical },
  ];

  // Needle angle (animated via CSS transition on transform attribute)
  const needleAngle = pctToAngle(mounted ? pct : 0);  // start at 0 (left), animate to target

  // Needle line endpoints (center → out)
  const needleEnd = polarToCartesian(cx, cy, radius - 4, needleAngle);

  return (
    <div
      ref={containerRef}
      style={{
        margin: '14px 0',
        background: GRADIENTS.card,
        border: `1px solid ${THEME.border}`,
        borderRadius: 12,
        padding: '16px 18px',
        boxShadow: SHADOWS.md + ", inset 0 1px 0 rgba(255,255,255,0.04)",
        textAlign: useHeroLayout ? 'left' : 'center',
      }}
    >
      {/* Header */}
      <div
        style={{
          display: 'flex',
          alignItems: 'center',
          justifyContent: useHeroLayout ? 'flex-start' : 'center',
          gap: 10,
          marginBottom: 8,
        }}
      >
        <span
          style={{
            width: 3,
            height: 14,
            background: GRADIENTS.primaryAccent,
            borderRadius: 2,
            flexShrink: 0,
          }}
        />
        <h4
          style={{
            margin: 0,
            fontSize: 12,
            fontWeight: 700,
            color: THEME.textSecondary,
            textTransform: 'uppercase',
            letterSpacing: '0.06em',
          }}
        >
          Overall Risk Assessment
        </h4>
      </div>

      {/* Body: gauge (+ optional hero side panel) */}
      <div
        style={{
          display: 'grid',
          gridTemplateColumns: useHeroLayout ? 'minmax(280px, 380px) minmax(0, 1fr)' : '1fr',
          alignItems: 'center',
          gap: useHeroLayout ? 24 : 0,
        }}
      >

      {/* SVG Gauge */}
      <div
        style={{
          maxWidth: useHeroLayout ? 380 : 320,
          margin: useHeroLayout ? 0 : '0 auto',
        }}
      >
        <svg
          viewBox={`0 0 ${VIEW_W} ${VIEW_H}`}
          preserveAspectRatio="xMidYMid meet"
          style={{ width: '100%', height: 'auto', display: 'block', overflow: 'visible' }}
          aria-label={`Risk score ${score} out of ${max}, level ${zoneLabel}`}
        >
          {/* Soft glow behind active zone */}
          <defs>
            <filter id="risk-glow" x="-50%" y="-50%" width="200%" height="200%">
              <feGaussianBlur stdDeviation="3" result="b" />
              <feMerge>
                <feMergeNode in="b" />
                <feMergeNode in="SourceGraphic" />
              </feMerge>
            </filter>
            <linearGradient id="risk-needle-gradient" x1="0%" y1="0%" x2="100%" y2="0%">
              <stop offset="0%"  stopColor={THEME.text} stopOpacity="0.6" />
              <stop offset="100%" stopColor={zoneColor} stopOpacity="1.0" />
            </linearGradient>
          </defs>

          {/* Background track (full semi-circle, unfilled) */}
          <path
            d={arcPath(cx, cy, radius, 180, 360)}
            fill="none"
            stroke={THEME.border}
            strokeWidth={trackStroke}
            strokeLinecap="round"
          />

          {/* Color zones — each 45° arc */}
          {zones.map((z, idx) => {
            const start = pctToAngle(z.from);
            const end   = pctToAngle(z.to);
            const isActiveZone = pct >= z.from && pct < z.to + 0.001;
            return (
              <path
                key={idx}
                d={arcPath(cx, cy, radius, start, end)}
                fill="none"
                stroke={z.color}
                strokeWidth={trackStroke}
                strokeLinecap="butt"
                opacity={isActiveZone ? 1 : 0.30}
                style={{
                  transition: `opacity ${TIMINGS.slow} ${TIMINGS.ease}`,
                }}
              />
            );
          })}

          {/* Tick marks at zone boundaries */}
          {[0, 0.25, 0.5, 0.75, 1].map((p, i) => {
            const a = pctToAngle(p);
            const inner = polarToCartesian(cx, cy, radius - trackStroke - 4, a);
            const outer = polarToCartesian(cx, cy, radius + 4, a);
            return (
              <line
                key={i}
                x1={inner.x} y1={inner.y}
                x2={outer.x} y2={outer.y}
                stroke={THEME.textMuted}
                strokeWidth="1"
                opacity="0.5"
              />
            );
          })}

          {/* Tick labels (0, 25, 50, 75, 100) */}
          {[
            { p: 0,    label: '0' },
            { p: 0.5,  label: String(Math.round(max / 2)) },
            { p: 1,    label: String(max) },
          ].map((t, i) => {
            const a = pctToAngle(t.p);
            const pos = polarToCartesian(cx, cy, radius + 14, a);
            return (
              <text
                key={i}
                x={pos.x}
                y={pos.y}
                textAnchor="middle"
                dominantBaseline="middle"
                fontSize="8"
                fontFamily={FONT.mono}
                fill={THEME.textMuted}
              >
                {t.label}
              </text>
            );
          })}

          {/* Needle (animates from 180° to target angle via transition) */}
          <line
            x1={cx}
            y1={cy}
            x2={needleEnd.x}
            y2={needleEnd.y}
            stroke="url(#risk-needle-gradient)"
            strokeWidth="3"
            strokeLinecap="round"
            filter="url(#risk-glow)"
            style={{
              transition: reduced ? 'none' : `all ${TIMINGS.slowest} cubic-bezier(0.34, 1.2, 0.64, 1)`,
            }}
          />

          {/* Needle hub (circle at center) */}
          <circle
            cx={cx}
            cy={cy}
            r={6}
            fill={zoneColor}
            stroke={THEME.bgDeep}
            strokeWidth="2"
            style={{
              filter: `drop-shadow(0 0 6px ${zoneColor}80)`,
              transition: `fill ${TIMINGS.slow} ${TIMINGS.ease}`,
            }}
          />

          {/* Center score text */}
          <text
            x={cx}
            y={cy - 32}
            textAnchor="middle"
            fontSize="28"
            fontWeight="800"
            fontFamily={FONT.mono}
            fill={zoneColor}
            style={{
              filter: `drop-shadow(0 0 8px ${zoneColor}60)`,
              transition: `fill ${TIMINGS.slow} ${TIMINGS.ease}`,
            }}
          >
            {animatedScore}
          </text>
          <text
            x={cx}
            y={cy - 14}
            textAnchor="middle"
            fontSize="9"
            fontFamily={FONT.mono}
            fill={THEME.textMuted}
          >
            / {max}
          </text>
        </svg>
      </div>

      {/* Level pill below — only inline when not in hero mode */}
      {!useHeroLayout && (
        <div style={{ marginTop: 4, display: 'flex', justifyContent: 'center' }}>
          <LevelPill zoneColor={zoneColor} zoneGlow={zoneGlow} zoneLabel={zoneLabel} reduced={reduced} />
        </div>
      )}

        {/* Hero side panel: level pill + zone breakdown + narrative */}
        {useHeroLayout && (
          <RiskHeroPanel
            zoneColor={zoneColor}
            zoneGlow={zoneGlow}
            zoneLabel={zoneLabel}
            reduced={reduced}
            score={score}
            max={max}
            pct={pct}
            level={level}
          />
        )}
      </div>
    </div>
  );
}

// ─── Level pill (reusable) ──────────────────────────────────────────────────

function LevelPill({ zoneColor, zoneGlow, zoneLabel, reduced }) {
  return (
    <span
      style={{
        display: 'inline-flex',
        alignItems: 'center',
        gap: 6,
        padding: '5px 14px',
        borderRadius: 6,
        fontSize: 11,
        fontWeight: 800,
        color: zoneColor,
        background: `${zoneColor}18`,
        border: `1px solid ${zoneColor}50`,
        letterSpacing: '0.06em',
        boxShadow: zoneGlow,
        textTransform: 'uppercase',
      }}
    >
      <span
        style={{
          width: 7,
          height: 7,
          borderRadius: '50%',
          background: zoneColor,
          boxShadow: `0 0 6px ${zoneColor}`,
          animation: reduced ? 'none' : 'pallas-breathe 2s ease-in-out infinite',
        }}
      />
      {zoneLabel} RISK
    </span>
  );
}

// ─── Hero side panel ────────────────────────────────────────────────────────

function RiskHeroPanel({ zoneColor, zoneGlow, zoneLabel, reduced, score, max, pct, level }) {
  // 4 zone breakdown rows — highlights the active band
  const bands = [
    { key: 'low',      label: 'Low',      from: 0,           to: Math.round(max * 0.25), color: THEME.success     },
    { key: 'medium',   label: 'Medium',   from: Math.round(max * 0.25), to: Math.round(max * 0.50), color: THEME.sevMedium },
    { key: 'high',     label: 'High',     from: Math.round(max * 0.50), to: Math.round(max * 0.75), color: THEME.sevHigh   },
    { key: 'critical', label: 'Critical', from: Math.round(max * 0.75), to: max,          color: THEME.sevCritical },
  ];

  const narrative =
    level === 'critical' ? 'Immediate remediation required. Escalate to on-call.' :
    level === 'high'     ? 'Action required this shift. Schedule remediation.' :
    level === 'medium'   ? 'Track and contain. Revisit in next planning cycle.' :
                           'Nominal posture. Continue routine monitoring.';

  return (
    <div
      style={{
        display: 'flex',
        flexDirection: 'column',
        gap: 12,
        minWidth: 0,
      }}
    >
      {/* Level pill */}
      <div>
        <LevelPill zoneColor={zoneColor} zoneGlow={zoneGlow} zoneLabel={zoneLabel} reduced={reduced} />
      </div>

      {/* Short narrative line */}
      <div
        style={{
          fontSize: 12,
          lineHeight: 1.5,
          color: THEME.textSecondary,
        }}
      >
        <b style={{ color: THEME.text, fontFamily: FONT.mono }}>{score}</b>
        <span style={{ color: THEME.textMuted, fontFamily: FONT.mono }}> / {max}</span>
        {' — '}
        {narrative}
      </div>

      {/* Zone breakdown */}
      <div
        style={{
          display: 'flex',
          flexDirection: 'column',
          gap: 6,
          paddingTop: 8,
          borderTop: `1px solid ${THEME.border}`,
        }}
      >
        <span
          style={{
            fontSize: 9,
            fontWeight: 700,
            color: THEME.textMuted,
            textTransform: 'uppercase',
            letterSpacing: '0.08em',
            marginBottom: 2,
          }}
        >
          Risk Bands
        </span>
        {bands.map((b) => {
          const isActive = level === b.key;
          return (
            <div
              key={b.key}
              style={{
                display: 'grid',
                gridTemplateColumns: 'auto 1fr auto',
                alignItems: 'center',
                gap: 10,
                padding: '4px 8px',
                borderRadius: 6,
                background: isActive ? `${b.color}14` : 'transparent',
                border: `1px solid ${isActive ? `${b.color}45` : 'transparent'}`,
                transition: `all ${TIMINGS.fast} ${TIMINGS.ease}`,
              }}
            >
              <span
                style={{
                  width: 8,
                  height: 8,
                  borderRadius: '50%',
                  background: b.color,
                  boxShadow: isActive ? `0 0 6px ${b.color}` : 'none',
                }}
              />
              <span
                style={{
                  fontSize: 11,
                  color: isActive ? THEME.text : THEME.textSecondary,
                  fontWeight: isActive ? 700 : 500,
                }}
              >
                {b.label}
              </span>
              <span
                style={{
                  fontSize: 10,
                  fontFamily: FONT.mono,
                  color: isActive ? b.color : THEME.textMuted,
                }}
              >
                {b.from}–{b.to}
              </span>
            </div>
          );
        })}
      </div>
    </div>
  );
}
