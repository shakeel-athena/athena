/**
 * ResponseBlockRenderer — Dispatches typed blocks to specialized components
 *
 * Hybrid input: accepts EITHER backend-supplied typed blocks (preferred) OR
 * legacy markdown which is then pattern-detected by BlockParser.
 *
 * 1. **Backend blocks** (preferred): when the props include a `blocks` array
 *    from the WebSocket response, those are used directly — no detection,
 *    no parsing, 100% reliable. This is the path for new MCP tools that emit
 *    structured JSON. See BLOCK_SCHEMAS.md for the contract.
 *
 * 2. **Markdown fallback**: when no `blocks` field is present, the renderer
 *    parses the `markdown` string via BlockParser and routes pattern matches
 *    to the same component dispatch table. This keeps every existing tool
 *    working with zero changes during the gradual backend migration.
 *
 * Both paths share the same dispatcher and the same cascade fade-in stagger,
 * so the user-visible result is identical regardless of which path was taken.
 *
 * Props:
 *   - blocks?:  optional pre-typed blocks array from the backend
 *   - markdown: the raw response markdown string (fallback / legacy path)
 *   - onPivot:  optional callback (query) => void, fired when user clicks an
 *               interactive element (severity segment, agent ID, etc.)
 */

import { useMemo } from 'react';
import { TIMINGS } from '../../../utils/theme';
import PallasMarkdown from '../PallasMarkdown';
import { parseResponseBlocks, BLOCK_TYPES } from './BlockParser';
import { useReducedMotion, classifyBlocks } from './blockHelpers';

import KPIGridBlock from './KPIGridBlock';
import SeverityBreakdownBlock from './SeverityBreakdownBlock';
import EntityListBlock from './EntityListBlock';
import RankedBarBlock from './RankedBarBlock';
import RiskScoreBlock from './RiskScoreBlock';
import HealthStatusBlock from './HealthStatusBlock';
import SparklineBlock from './SparklineBlock';
import BadgeCloudBlock from './BadgeCloudBlock';
import MitreMatrixBlock from './MitreMatrixBlock';
import TimelineBlock from './TimelineBlock';
import FlowDiagramBlock from './FlowDiagramBlock';
import ComparisonBlock from './ComparisonBlock';

// ─── Block dispatch table ────────────────────────────────────────────────────
// As R2-R6 add new components, register them here.

function dispatchBlock(block, onPivot, key) {
  if (!block) return null;

  switch (block.type) {
    case BLOCK_TYPES.KPI_GRID:
      return <KPIGridBlock key={key} data={block.data} onPivot={onPivot} />;

    case BLOCK_TYPES.SEVERITY_BREAKDOWN:
      return <SeverityBreakdownBlock key={key} data={block.data} onPivot={onPivot} />;

    // R2 — Entity lists as premium SOC cards
    case BLOCK_TYPES.AGENT_TABLE:
    case BLOCK_TYPES.VULN_TABLE:
    case BLOCK_TYPES.RULE_TABLE:
      return (
        <EntityListBlock
          key={key}
          blockType={block.type}
          data={block.data}
          onPivot={onPivot}
        />
      );

    // R2 — Top-N rankings as horizontal bar chart
    case BLOCK_TYPES.TOP_ATTACKERS:
      return <RankedBarBlock key={key} data={block.data} onPivot={onPivot} />;

    // R3 — Risk + Health visualizations
    case BLOCK_TYPES.RISK_SCORE:
      return <RiskScoreBlock key={key} data={block.data} onPivot={onPivot} />;

    case BLOCK_TYPES.HEALTH_STATUS:
      return <HealthStatusBlock key={key} data={block.data} onPivot={onPivot} />;

    case BLOCK_TYPES.TIME_SERIES:
      return <SparklineBlock key={key} data={block.data} onPivot={onPivot} />;

    // R4 — MITRE matrix + badge cloud chips
    case BLOCK_TYPES.MITRE_MATRIX:
      return <MitreMatrixBlock key={key} data={block.data} onPivot={onPivot} />;

    case BLOCK_TYPES.BADGE_CLOUD:
      return <BadgeCloudBlock key={key} data={block.data} onPivot={onPivot} />;

    // R5 — Timeline / Flow diagram / Comparison
    case BLOCK_TYPES.TIMELINE:
      return <TimelineBlock key={key} data={block.data} onPivot={onPivot} />;

    case BLOCK_TYPES.FLOW_DIAGRAM:
      return <FlowDiagramBlock key={key} data={block.data} onPivot={onPivot} />;

    case BLOCK_TYPES.COMPARISON:
      return <ComparisonBlock key={key} data={block.data} onPivot={onPivot} />;

    // Handled by upgraded PallasMarkdown — fall through
    case BLOCK_TYPES.RECOMMENDATIONS:
    case BLOCK_TYPES.CODE_BLOCK:
    case BLOCK_TYPES.PROSE:
    default:
      // Fall through to PallasMarkdown — now with Ageleia polish (severity-tinted
      // rows, mono numeric cells, click-to-pivot on agent/IP/CVE, collapse).
      return (
        <PallasMarkdown
          key={key}
          content={block.raw ? block.raw.join('\n') : (block.data?.content || '')}
          onPivot={onPivot}
        />
      );
  }
}

// ─── ResponseBlockRenderer ───────────────────────────────────────────────────

export default function ResponseBlockRenderer({ markdown, blocks, onPivot }) {
  const reduced = useReducedMotion();

  // Hybrid path: prefer backend-supplied typed blocks when present.
  // Otherwise fall back to markdown pattern detection via BlockParser.
  const blocksToRender = useMemo(() => {
    if (Array.isArray(blocks) && blocks.length > 0) {
      return blocks;
    }
    return parseResponseBlocks(markdown || '');
  }, [blocks, markdown]);

  if (!blocksToRender || blocksToRender.length === 0) {
    return null;
  }

  return (
    <div style={{ wordWrap: 'break-word', overflowWrap: 'break-word' }}>
      {blocksToRender.map((block, idx) => {
        // Stagger: each block fades in 80ms after the previous
        const delay = reduced ? '0ms' : `${Math.min(idx * 80, 600)}ms`;
        return (
          <div
            key={`block-${idx}-${block.type}-${block.start ?? idx}`}
            style={{
              animation: reduced ? 'none' : `pallas-fadeIn 0.35s ${TIMINGS.ease} both`,
              animationDelay: delay,
            }}
          >
            {dispatchBlock(block, onPivot, `inner-${idx}`)}
          </div>
        );
      })}
    </div>
  );
}

// ─── useSplitBlocks hook — Intelligence Briefing layout ─────────────────────
// Resolves blocks (backend or BlockParser), classifies into hero vs detail,
// and renders each group as a separate React element with independent stagger.

function useResolvedBlocks(blocks, markdown) {
  return useMemo(() => {
    if (Array.isArray(blocks) && blocks.length > 0) return blocks;
    return parseResponseBlocks(markdown || '');
  }, [blocks, markdown]);
}

function renderBlockGroup(group, onPivot, reduced, keyPrefix, compact = false) {
  if (!group || group.length === 0) return null;
  return (
    <div style={{
      wordWrap: 'break-word',
      overflowWrap: 'break-word',
      // Compact mode: tighten margins between hero blocks by using CSS to
      // override child block margins. This avoids modifying individual components.
      ...(compact ? { fontSize: 'inherit' } : {}),
    }}
    className={compact ? 'pallas-compact-blocks' : undefined}
    >
      {group.map((block, idx) => {
        const delay = reduced ? '0ms' : `${Math.min(idx * 80, 600)}ms`;
        return (
          <div
            key={`${keyPrefix}-${idx}-${block.type}-${block.start ?? idx}`}
            style={{
              animation: reduced ? 'none' : `pallas-fadeIn 0.35s ${TIMINGS.ease} both`,
              animationDelay: delay,
              // Compact hero: reduce vertical margins between blocks
              ...(compact ? { marginTop: idx === 0 ? 0 : 6, marginBottom: 0 } : {}),
            }}
          >
            {dispatchBlock(block, onPivot, `${keyPrefix}-inner-${idx}`)}
          </div>
        );
      })}
    </div>
  );
}

export function useSplitBlocks({ markdown, blocks, onPivot }) {
  const reduced = useReducedMotion();
  const resolvedBlocks = useResolvedBlocks(blocks, markdown);

  const { hero, detail } = useMemo(
    () => classifyBlocks(resolvedBlocks || []),
    [resolvedBlocks]
  );

  const heroElement = renderBlockGroup(hero, onPivot, reduced, 'hero', true);  // compact
  const detailElement = renderBlockGroup(detail, onPivot, reduced, 'detail', false);

  return {
    heroElement,
    detailElement,
    hasHero: hero.length > 0,
    hasDetail: detail.length > 0,
    hasAnyBlocks: (resolvedBlocks || []).length > 0,
  };
}

// ─── Re-export the parser for downstream use ────────────────────────────────

export { parseResponseBlocks, BLOCK_TYPES };
