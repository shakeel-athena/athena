/**
 * PallasDecoderLab — Decoder Lab AI Plugin
 *
 * Redesigned with shared PallasUI components and Decoder accent color (#C084FC).
 * Generate and test Wazuh decoders from raw log samples using AI.
 */

import React, { useState, useCallback } from 'react';
import { EuiIcon } from '@elastic/eui';
import { THEME } from '../../utils/theme';
import { MODULE_COLORS, ActionChip, GlassCard, PillBadge, FONT, ChatDisclaimer } from './PallasUI';
import { ResponsePanel } from './PallasResponsePanel';
import { pallasPost } from '../../services/pallasService';
import PallasLogo from '../../artifacts/pallas-icon-light.svg';

const ACCENT = MODULE_COLORS.decoder.accent;
const BTN_BG = 'linear-gradient(135deg, #00BFB3 0%, #00D4C8 100%)'; // Matches chat send button

// ─── Constants ───────────────────────────────────────────────────────────────

const EXPECTED_FIELDS = ['srcip', 'dstip', 'srcport', 'dstport', 'user', 'action', 'protocol', 'id', 'url', 'status'];

const INITIAL_STEPS = [
  { id: 'analyze',  label: 'Analyzing Log',       status: 'pending' },
  { id: 'generate', label: 'Generating Decoder',  status: 'pending' },
  { id: 'test',     label: 'Testing with Logtest', status: 'pending' },
  { id: 'complete', label: 'Complete',             status: 'pending' },
];

// ─── DecoderStepper ─────────────────────────────────────────────────────────

function DecoderStepper({ steps }) {
  return (
    <div style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'center', gap: 0, margin: '24px 0' }}>
      {steps.map((step, i) => {
        const isLast = i === steps.length - 1;
        const circleSize = 32;

        let bg = THEME.bgDeep;
        let borderColor = THEME.border;
        let content = <span style={{ fontSize: 13, fontWeight: 600, color: THEME.textSecondary }}>{i + 1}</span>;

        if (step.status === 'active') {
          bg = ACCENT;
          borderColor = ACCENT;
          content = (
            <span style={{
              display: 'inline-block', width: 14, height: 14,
              border: '2px solid rgba(255,255,255,0.3)', borderTopColor: '#fff',
              borderRadius: '50%', animation: 'pallas-spin 0.6s linear infinite',
            }} />
          );
        } else if (step.status === 'complete') {
          bg = '#00C853';
          borderColor = '#00C853';
          content = <EuiIcon type="check" size="s" color="#fff" />;
        } else if (step.status === 'error') {
          bg = '#FF4D4D';
          borderColor = '#FF4D4D';
          content = <EuiIcon type="cross" size="s" color="#fff" />;
        }

        const connectorBg = step.status === 'complete'
          ? `linear-gradient(90deg, ${ACCENT}, ${ACCENT}AA)`
          : THEME.border;

        return (
          <div key={step.id} style={{ display: 'flex', alignItems: 'flex-start' }}>
            <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', minWidth: 80 }}>
              <div style={{
                width: circleSize, height: circleSize, borderRadius: '50%',
                background: bg, border: `2px solid ${borderColor}`,
                display: 'flex', alignItems: 'center', justifyContent: 'center',
              }}>
                {content}
              </div>
              <span style={{
                marginTop: 8, fontSize: 11,
                fontWeight: step.status === 'active' || step.status === 'complete' ? 700 : 400,
                color: step.status === 'active' || step.status === 'complete' ? THEME.text : THEME.textSecondary,
                textAlign: 'center', whiteSpace: 'nowrap',
              }}>
                {step.label}
              </span>
            </div>
            {!isLast && (
              <div style={{
                width: 48, height: 2, marginTop: circleSize / 2,
                background: connectorBg, flexShrink: 0,
              }} />
            )}
          </div>
        );
      })}
    </div>
  );
}

// ─── Main Component ─────────────────────────────────────────────────────────

export default function PallasDecoderLab({ connectionStatus, onQueryComplete, onClose, hideHeader }) {
  const accent = ACCENT;
  const [rawLog, setRawLog] = useState('');
  const [selectedFields, setSelectedFields] = useState([]);
  const [isGenerating, setIsGenerating] = useState(false);
  const [result, setResult] = useState(null);
  const [copiedXml, setCopiedXml] = useState(false);
  const [steps, setSteps] = useState(INITIAL_STEPS.map(s => ({ ...s })));
  const [aiExplanation, setAiExplanation] = useState('');
  const [aiLoading, setAiLoading] = useState(false);
  const [aiError, setAiError] = useState('');

  const toggleField = useCallback((field) => {
    setSelectedFields(prev =>
      prev.includes(field) ? prev.filter(f => f !== field) : [...prev, field]
    );
  }, []);

  const updateStep = useCallback((stepId, status) => {
    setSteps(prev => prev.map(s => s.id === stepId ? { ...s, status } : s));
  }, []);

  // ── Generate decoder ──────────────────────────────────────────────────

  const handleGenerate = useCallback(async () => {
    if (!rawLog.trim() || isGenerating) return;

    setIsGenerating(true);
    setResult(null);
    setAiExplanation('');
    setAiError('');
    setSteps(INITIAL_STEPS.map(s => ({ ...s })));

    try {
      updateStep('analyze', 'active');
      await new Promise(r => setTimeout(r, 600));
      updateStep('analyze', 'complete');

      updateStep('generate', 'active');
      const data = await pallasPost('/api/decoder/generate', {
        raw_log: rawLog.trim(),
        hints: { expected_fields: selectedFields },
      });
      updateStep('generate', 'complete');

      updateStep('test', 'active');
      await new Promise(r => setTimeout(r, 400));

      if (data.success === false || data.error) {
        updateStep('test', 'error');
        updateStep('complete', 'error');
        setResult({ error: data.error || 'Decoder generation failed', ...data });
      } else {
        updateStep('test', 'complete');
        updateStep('complete', 'complete');
        setResult(data);
        if (onQueryComplete) onQueryComplete('decoder', 'Generate decoder', 0);
      }
    } catch (err) {
      setSteps(prev => prev.map(s => s.status === 'active' ? { ...s, status: 'error' } : s));
      setResult({ error: err.message });
    } finally {
      setIsGenerating(false);
    }
  }, [rawLog, selectedFields, isGenerating, updateStep, onQueryComplete]);

  // ── Explain decoder ───────────────────────────────────────────────────

  const handleExplain = useCallback(async () => {
    if (!result?.decoder_xml || aiLoading) return;
    setAiLoading(true);
    setAiError('');
    setAiExplanation('');
    try {
      const data = await pallasPost('/api/decoder/explain', { decoder_xml: result.decoder_xml });
      setAiExplanation(data.explanation || data.text || JSON.stringify(data));
    } catch (err) {
      setAiError(err.message);
    } finally {
      setAiLoading(false);
    }
  }, [result, aiLoading]);

  // ── Copy XML ──────────────────────────────────────────────────────────

  const handleCopyXml = useCallback(() => {
    if (!result?.decoder_xml) return;
    navigator.clipboard.writeText(result.decoder_xml).then(() => {
      setCopiedXml(true);
      setTimeout(() => setCopiedXml(false), 2000);
    });
  }, [result]);

  // ── Render ────────────────────────────────────────────────────────────

  const hasResults = !!(result || isGenerating);

  return (
    <div style={{ display: 'flex', flexDirection: 'column', height: '100%', fontFamily: FONT.base }}>

      {/* ═══ WELCOME STATE — matches chat/IOC welcome pattern ═══ */}
      {!hasResults && (
        <div style={{
          flex: 1, display: 'flex', flexDirection: 'column', alignItems: 'center',
          justifyContent: 'center', padding: '0 24px',
        }}>
          <img src={PallasLogo} alt="Pallas AI" style={{ width: 90, height: 90, marginBottom: 12, opacity: 0.9 }} />
          <h3 style={{ fontSize: 22, fontWeight: 700, color: THEME.text, margin: '0 0 6px', letterSpacing: '-0.01em' }}>
            Decoder Lab
          </h3>
          <p style={{ fontSize: 13, color: THEME.textMuted, margin: '0 0 20px', textAlign: 'center', maxWidth: 420, lineHeight: 1.5 }}>
            Generate and test Wazuh decoders from raw log samples using AI
          </p>

          {/* Expected fields chips */}
          <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap', justifyContent: 'center', marginBottom: 16 }}>
            {EXPECTED_FIELDS.map(field => (
              <ActionChip key={field} label={field} onClick={() => toggleField(field)}
                active={selectedFields.includes(field)} accent={accent} style={{ fontFamily: FONT.mono }} />
            ))}
          </div>

          {/* Log input — same style as chat/IOC input */}
          <div style={{ width: '100%', maxWidth: 680 }}>
            <div style={{
              borderRadius: 12, border: `1px solid ${THEME.border}`, backgroundColor: '#0D1520',
              overflow: 'hidden',
            }}>
              <textarea
                value={rawLog}
                onChange={e => setRawLog(e.target.value)}
                placeholder="Paste a raw log line here..."
                rows={3}
                style={{
                  width: '100%', padding: '14px 16px', border: 'none', outline: 'none',
                  backgroundColor: 'transparent', color: THEME.text, fontSize: 13,
                  fontFamily: FONT.mono, resize: 'none', boxSizing: 'border-box', lineHeight: 1.5,
                }}
              />
              <div style={{ display: 'flex', justifyContent: 'flex-end', padding: '0 6px 6px' }}>
                <button
                  onClick={handleGenerate}
                  disabled={!rawLog.trim() || isGenerating}
                  style={{
                    padding: '8px 18px', border: 'none', borderRadius: 8,
                    background: BTN_BG, color: '#fff', fontWeight: 600, fontSize: 13,
                    cursor: (!rawLog.trim()) ? 'not-allowed' : 'pointer',
                    display: 'flex', alignItems: 'center', gap: 6,
                    opacity: (!rawLog.trim()) ? 0.5 : 1, outline: 'none',
                  }}
                >
                  <EuiIcon type="wrench" size="s" color="#fff" />
                  Generate Decoder
                </button>
              </div>
            </div>
            <ChatDisclaimer align="center" marginTop={6} />
          </div>
        </div>
      )}

      {/* ═══ RESULTS STATE — results on top, form at bottom ═══ */}
      {hasResults && (
        <>
          {/* Results area — scrollable */}
          <div style={{ flex: 1, overflowY: 'auto', padding: '16px 24px' }} className="pallas-scrollbar">
            <div style={{ maxWidth: 1320, margin: '0 auto' }}>
              {isGenerating && <DecoderStepper steps={steps} />}

              {result && (
                <>
                  {result.error && !result.decoder_xml && (
                    <div style={{
                      background: 'rgba(255, 77, 77, 0.08)', border: '1px solid rgba(255, 77, 77, 0.3)',
                      borderRadius: 8, padding: '14px 18px', color: '#FF6B6B', fontSize: 13,
                      marginBottom: 16, display: 'flex', alignItems: 'center', gap: 8,
                    }}>
                      <EuiIcon type="cross" size="s" color="#FF6B6B" /> {result.error}
                    </div>
                  )}

                  {result.decoder_xml && (
                    <GlassCard style={{ overflow: 'hidden', marginBottom: 20, borderLeft: `4px solid ${accent}` }}>
                      <div style={{
                        display: 'flex', alignItems: 'center', justifyContent: 'space-between',
                        padding: '12px 16px', borderBottom: `1px solid ${THEME.border}`,
                      }}>
                        <span style={{ fontSize: 13, fontWeight: 700, color: THEME.text, display: 'flex', alignItems: 'center', gap: 6 }}>
                          <EuiIcon type="document" size="s" color={accent} /> Decoder XML
                        </span>
                        <div style={{ display: 'flex', gap: 8 }}>
                          <button onClick={handleExplain} disabled={aiLoading} style={{
                            background: 'transparent', border: `1px solid ${accent}`, borderRadius: 6,
                            color: accent, fontSize: 12, fontWeight: 600, padding: '4px 12px',
                            cursor: aiLoading ? 'not-allowed' : 'pointer',
                            display: 'flex', alignItems: 'center', gap: 4, outline: 'none',
                          }}>
                            <EuiIcon type="inspect" size="s" color={accent} />
                            {aiLoading ? 'Explaining...' : 'Explain'}
                          </button>
                          <button onClick={handleCopyXml} style={{
                            background: 'transparent', border: `1px solid ${THEME.border}`, borderRadius: 6,
                            color: copiedXml ? '#00C853' : THEME.textSecondary, fontSize: 12, fontWeight: 600,
                            padding: '4px 12px', cursor: 'pointer',
                            display: 'flex', alignItems: 'center', gap: 4, outline: 'none',
                          }}>
                            <EuiIcon type={copiedXml ? 'check' : 'copy'} size="s" />
                            {copiedXml ? 'Copied' : 'Copy'}
                          </button>
                        </div>
                      </div>
                      <pre style={{
                        margin: 0, padding: 16, background: THEME.bg, color: THEME.text,
                        fontFamily: FONT.mono, fontSize: 12, lineHeight: 1.6,
                        overflowX: 'auto', whiteSpace: 'pre-wrap', wordBreak: 'break-word',
                      }}>
                        {result.decoder_xml}
                      </pre>
                    </GlassCard>
                  )}

                  {aiExplanation && (
                    <div style={{ marginBottom: 20 }}>
                      <ResponsePanel content={aiExplanation} accent={accent} />
                    </div>
                  )}

                  {aiError && (
                    <div style={{
                      background: 'rgba(255, 77, 77, 0.08)', border: '1px solid rgba(255, 77, 77, 0.3)',
                      borderRadius: 8, padding: '10px 14px', color: '#FF6B6B', fontSize: 12,
                      marginBottom: 16, display: 'flex', alignItems: 'center', gap: 8,
                    }}>
                      <EuiIcon type="cross" size="s" color="#FF6B6B" /> {aiError}
                    </div>
                  )}

                  {result.extracted_fields && Object.keys(result.extracted_fields).length > 0 && (
                    <GlassCard style={{ padding: 16, marginBottom: 20 }}>
                      <h4 style={{ margin: '0 0 12px', fontSize: 13, fontWeight: 700, color: THEME.text, display: 'flex', alignItems: 'center', gap: 6 }}>
                        <EuiIcon type="list" size="s" color={accent} /> Extracted Fields
                      </h4>
                      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(200px, 1fr))', gap: 10 }}>
                        {Object.entries(result.extracted_fields).map(([key, value]) => (
                          <div key={key} style={{
                            background: 'rgba(255,255,255,0.02)', border: `1px solid ${THEME.border}`,
                            borderRadius: 6, padding: '8px 12px', display: 'flex', alignItems: 'center', gap: 8,
                          }}>
                            <div style={{ flex: 1, minWidth: 0 }}>
                              <div style={{ fontSize: 11, fontFamily: FONT.mono, color: THEME.textMuted, marginBottom: 2 }}>{key}</div>
                              <div style={{ fontSize: 13, fontFamily: FONT.mono, color: THEME.text, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{value}</div>
                            </div>
                            <EuiIcon type="check" size="s" color="#00C853" />
                          </div>
                        ))}
                      </div>
                    </GlassCard>
                  )}

                  {result.attempts && result.attempts.length > 0 && (
                    <GlassCard style={{ padding: 16, marginBottom: 20 }}>
                      <h4 style={{ margin: '0 0 12px', fontSize: 13, fontWeight: 700, color: THEME.text, display: 'flex', alignItems: 'center', gap: 6 }}>
                        <EuiIcon type="refresh" size="s" color={accent} /> Attempt History
                      </h4>
                      <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
                        {result.attempts.map((attempt, i) => {
                          const success = attempt.success || attempt.status === 'success';
                          return (
                            <div key={i} style={{
                              display: 'flex', alignItems: 'center', gap: 10, padding: '8px 12px',
                              background: 'rgba(255,255,255,0.02)', border: `1px solid ${THEME.border}`,
                              borderRadius: 6, fontSize: 13,
                            }}>
                              <span style={{ color: THEME.textMuted, fontWeight: 600, fontSize: 12, minWidth: 24 }}>#{i + 1}</span>
                              <PillBadge
                                label={success ? 'PASS' : 'FAIL'}
                                color={success ? '#00C853' : '#FF4D4D'}
                                bg={success ? 'rgba(0,200,83,0.12)' : 'rgba(255,77,77,0.12)'}
                                style={{ fontSize: 10, fontWeight: 700 }}
                              />
                              <span style={{ color: success ? THEME.text : '#FF6B6B' }}>
                                {success ? 'Decoder validated successfully' : (attempt.error || attempt.message || 'Validation failed')}
                              </span>
                            </div>
                          );
                        })}
                      </div>
                    </GlassCard>
                  )}

                  {!isGenerating && <DecoderStepper steps={steps} />}
                </>
              )}
            </div>
          </div>

          {/* Bottom form — centered, matches chat/IOC pattern */}
          <div style={{ flexShrink: 0, padding: '12px 24px 16px' }}>
            <div style={{ maxWidth: 680, margin: '0 auto', display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 10 }}>
              <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap', justifyContent: 'center' }}>
                {EXPECTED_FIELDS.map(field => (
                  <ActionChip key={field} label={field} onClick={() => toggleField(field)}
                    active={selectedFields.includes(field)} accent={accent} style={{ fontFamily: FONT.mono }} />
                ))}
              </div>
              <div style={{ width: '100%' }}>
                <div style={{
                  borderRadius: 12, border: `1px solid ${THEME.border}`, backgroundColor: '#0D1520',
                  overflow: 'hidden',
                }}>
                  <textarea
                    value={rawLog}
                    onChange={e => setRawLog(e.target.value)}
                    placeholder="Paste a raw log line here..."
                    rows={2}
                    style={{
                      width: '100%', padding: '10px 16px', border: 'none', outline: 'none',
                      backgroundColor: 'transparent', color: THEME.text, fontSize: 13,
                      fontFamily: FONT.mono, resize: 'none', boxSizing: 'border-box', lineHeight: 1.4,
                    }}
                  />
                  <div style={{ display: 'flex', justifyContent: 'flex-end', padding: '0 6px 6px' }}>
                    <button
                      onClick={handleGenerate}
                      disabled={!rawLog.trim() || isGenerating}
                      style={{
                        padding: '8px 18px', border: 'none', borderRadius: 8,
                        background: (!rawLog.trim() || isGenerating) ? THEME.border : BTN_BG,
                        color: '#fff', fontWeight: 600, fontSize: 13,
                        cursor: (!rawLog.trim() || isGenerating) ? 'not-allowed' : 'pointer',
                        display: 'flex', alignItems: 'center', gap: 6,
                        opacity: (!rawLog.trim() || isGenerating) ? 0.5 : 1, outline: 'none',
                      }}
                    >
                      <EuiIcon type="wrench" size="s" color="#fff" />
                      {isGenerating ? 'Generating...' : 'Generate'}
                    </button>
                  </div>
                </div>
                <ChatDisclaimer align="center" marginTop={6} />
              </div>
            </div>
          </div>
        </>
      )}
    </div>
  );
}
