/**
 * PallasDecoderLab — Decoder Lab AI Plugin
 *
 * Redesigned with shared PallasUI components and Decoder accent color (#C084FC).
 * Generate and test Wazuh decoders from raw log samples using AI.
 */

import React, { useState, useCallback } from 'react';
import { EuiIcon } from '@elastic/eui';
import { THEME, GLOWS, SHADOWS } from '../../utils/theme';
import { MODULE_COLORS, ActionChip, GlassCard, PillBadge, FONT, ChatDisclaimer, KPICard, SkeletonLine, PALLAS_KEYFRAMES } from './PallasUI';
import { ResponsePanel } from './PallasResponsePanel';
import { pallasPost } from '../../services/pallasService';
import PallasLogo from '../../artifacts/pallas-icon-light.svg';

const ACCENT = MODULE_COLORS.decoder.accent;
const BTN_BG = 'linear-gradient(135deg, #00BFB3 0%, #00D4C8 100%)'; // Matches chat send button
const ACCENT_GRAD = `linear-gradient(135deg, ${ACCENT}, ${ACCENT}AA)`;
const ACCENT_GLOW = `0 0 24px ${ACCENT}40`;

// ─── Constants ───────────────────────────────────────────────────────────────

const EXPECTED_FIELDS = ['srcip', 'dstip', 'srcport', 'dstport', 'user', 'action', 'protocol', 'id', 'url', 'status'];

const INITIAL_STEPS = [
  { id: 'analyze',  label: 'Analyzing Log',       status: 'pending' },
  { id: 'generate', label: 'Generating Decoder',  status: 'pending' },
  { id: 'test',     label: 'Testing with Logtest', status: 'pending' },
  { id: 'complete', label: 'Complete',             status: 'pending' },
];

// ─── DecoderStepper ─────────────────────────────────────────────────────────

function DecoderStepper({ steps }) {
  return (
    <div style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'center', gap: 0, margin: '24px 0' }}>
      {steps.map((step, i) => {
        const isLast = i === steps.length - 1;
        const circleSize = 32;

        let bg = THEME.bgDeep;
        let borderColor = THEME.border;
        let content = <span style={{ fontSize: 13, fontWeight: 600, color: THEME.textSecondary }}>{i + 1}</span>;

        if (step.status === 'active') {
          bg = ACCENT;
          borderColor = ACCENT;
          content = (
            <span style={{
              display: 'inline-block', width: 14, height: 14,
              border: '2px solid rgba(255,255,255,0.3)', borderTopColor: '#fff',
              borderRadius: '50%', animation: 'pallas-spin 0.6s linear infinite',
            }} />
          );
        } else if (step.status === 'complete') {
          bg = '#00C853';
          borderColor = '#00C853';
          content = <EuiIcon type="check" size="s" color="#fff" />;
        } else if (step.status === 'error') {
          bg = '#FF4D4D';
          borderColor = '#FF4D4D';
          content = <EuiIcon type="cross" size="s" color="#fff" />;
        }

        const connectorBg = step.status === 'complete'
          ? `linear-gradient(90deg, ${ACCENT}, ${ACCENT}AA)`
          : THEME.border;

        return (
          <div key={step.id} style={{ display: 'flex', alignItems: 'flex-start' }}>
            <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', minWidth: 80 }}>
              <div style={{
                width: circleSize, height: circleSize, borderRadius: '50%',
                background: bg, border: `2px solid ${borderColor}`,
                display: 'flex', alignItems: 'center', justifyContent: 'center',
              }}>
                {content}
              </div>
              <span style={{
                marginTop: 8, fontSize: 11,
                fontWeight: step.status === 'active' || step.status === 'complete' ? 700 : 400,
                color: step.status === 'active' || step.status === 'complete' ? THEME.text : THEME.textSecondary,
                textAlign: 'center', whiteSpace: 'nowrap',
              }}>
                {step.label}
              </span>
            </div>
            {!isLast && (
              <div style={{
                width: 48, height: 2, marginTop: circleSize / 2,
                background: connectorBg, flexShrink: 0,
              }} />
            )}
          </div>
        );
      })}
    </div>
  );
}

// ─── Main Component ─────────────────────────────────────────────────────────

export default function PallasDecoderLab({ connectionStatus, onQueryComplete, onClose, hideHeader }) {
  const accent = ACCENT;
  const [rawLog, setRawLog] = useState('');
  const [selectedFields, setSelectedFields] = useState([]);
  const [isGenerating, setIsGenerating] = useState(false);
  const [result, setResult] = useState(null);
  const [copiedXml, setCopiedXml] = useState(false);
  const [steps, setSteps] = useState(INITIAL_STEPS.map(s => ({ ...s })));
  const [aiExplanation, setAiExplanation] = useState('');
  const [aiLoading, setAiLoading] = useState(false);
  const [aiError, setAiError] = useState('');

  const toggleField = useCallback((field) => {
    setSelectedFields(prev =>
      prev.includes(field) ? prev.filter(f => f !== field) : [...prev, field]
    );
  }, []);

  const updateStep = useCallback((stepId, status) => {
    setSteps(prev => prev.map(s => s.id === stepId ? { ...s, status } : s));
  }, []);

  // ── Explain decoder (called automatically after a successful generate) ─

  const runExplain = useCallback(async (decoderXml) => {
    if (!decoderXml) return;
    setAiLoading(true);
    setAiError('');
    setAiExplanation('');
    try {
      const data = await pallasPost('/api/decoder/explain', { decoder_xml: decoderXml });
      setAiExplanation(data.explanation || data.text || '');
    } catch (err) {
      setAiError(err.message);
    } finally {
      setAiLoading(false);
    }
  }, []);

  // ── Generate decoder ──────────────────────────────────────────────────

  const handleGenerate = useCallback(async () => {
    if (!rawLog.trim() || isGenerating) return;

    setIsGenerating(true);
    setResult(null);
    setAiExplanation('');
    setAiError('');
    setSteps(INITIAL_STEPS.map(s => ({ ...s })));

    try {
      updateStep('analyze', 'active');
      await new Promise(r => setTimeout(r, 600));
      updateStep('analyze', 'complete');

      updateStep('generate', 'active');
      const data = await pallasPost('/api/decoder/generate', {
        raw_log: rawLog.trim(),
        hints: { expected_fields: selectedFields },
      });
      updateStep('generate', 'complete');

      updateStep('test', 'active');
      await new Promise(r => setTimeout(r, 400));

      if (data.success === false || data.error) {
        updateStep('test', 'error');
        updateStep('complete', 'error');
        setResult({ error: data.error || 'Decoder generation failed', ...data });
      } else {
        updateStep('test', 'complete');
        updateStep('complete', 'complete');
        setResult(data);
        if (onQueryComplete) onQueryComplete('decoder', 'Generate decoder', 0);
        // Auto-fire AI explanation so the analyst gets full context without
        // a second click. Non-blocking — runs in parallel with the user
        // reading the extracted fields and decoder XML.
        if (data.decoder_xml) {
          runExplain(data.decoder_xml);
        }
      }
    } catch (err) {
      setSteps(prev => prev.map(s => s.status === 'active' ? { ...s, status: 'error' } : s));
      setResult({ error: err.message });
    } finally {
      setIsGenerating(false);
    }
  }, [rawLog, selectedFields, isGenerating, updateStep, onQueryComplete, runExplain]);

  // Manual re-explain (rarely needed, but kept for retry on aiError)
  const handleRetryExplain = useCallback(() => {
    if (result?.decoder_xml) runExplain(result.decoder_xml);
  }, [result, runExplain]);

  // Reset to welcome state for a fresh decoder
  const handleNewDecoder = useCallback(() => {
    setRawLog('');
    setSelectedFields([]);
    setResult(null);
    setAiExplanation('');
    setAiError('');
    setSteps(INITIAL_STEPS.map(s => ({ ...s })));
  }, []);

  // ── Copy XML ──────────────────────────────────────────────────────────

  const handleCopyXml = useCallback(() => {
    if (!result?.decoder_xml) return;
    navigator.clipboard.writeText(result.decoder_xml).then(() => {
      setCopiedXml(true);
      setTimeout(() => setCopiedXml(false), 2000);
    });
  }, [result]);

  // ── Render ────────────────────────────────────────────────────────────

  const hasResults = !!(result || isGenerating);

  return (
    <div style={{ display: 'flex', flexDirection: 'column', height: '100%', fontFamily: FONT.base }}>
      {/* Pallas keyframes (fade-in / slide-up / shimmer) — injected once per mount */}
      <style>{PALLAS_KEYFRAMES}</style>

      {/* ═══ WELCOME STATE — matches chat/IOC welcome pattern ═══ */}
      {!hasResults && (
        <div style={{
          flex: 1, display: 'flex', flexDirection: 'column', alignItems: 'center',
          justifyContent: 'center', padding: '0 24px',
          animation: 'pallas-fadeIn 0.4s ease',
        }}>
          <div style={{
            position: 'relative', marginBottom: 12,
            filter: `drop-shadow(0 0 24px ${ACCENT}40)`,
          }}>
            <img src={PallasLogo} alt="Pallas AI" style={{ width: 90, height: 90, opacity: 0.95 }} />
          </div>
          <h3 style={{
            fontSize: 24, fontWeight: 700,
            background: `linear-gradient(135deg, #fff, ${ACCENT})`,
            WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent',
            backgroundClip: 'text',
            margin: '0 0 6px', letterSpacing: '-0.01em',
          }}>
            Decoder Lab
          </h3>
          <p style={{ fontSize: 13, color: THEME.textMuted, margin: '0 0 24px', textAlign: 'center', maxWidth: 420, lineHeight: 1.5 }}>
            Paste a raw log line and Pallas will generate a Wazuh decoder, validate it, and explain how it works.
          </p>

          {/* Expected fields chips — labeled so analyst knows what they do */}
          <div style={{ width: '100%', maxWidth: 680, marginBottom: 16 }}>
            <div style={{
              display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 6,
              fontSize: 11, color: THEME.textMuted, marginBottom: 8,
            }}>
              <EuiIcon type="iInCircle" size="s" color={THEME.textMuted} />
              <span>Optional hints — pick fields the AI should try to extract</span>
            </div>
            <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap', justifyContent: 'center' }}>
              {EXPECTED_FIELDS.map(field => (
                <ActionChip key={field} label={field} onClick={() => toggleField(field)}
                  active={selectedFields.includes(field)} accent={accent} style={{ fontFamily: FONT.mono }} />
              ))}
            </div>
          </div>

          {/* Log input — same style as chat/IOC input */}
          <div style={{ width: '100%', maxWidth: 680 }}>
            <div style={{
              borderRadius: 12, border: `1px solid ${THEME.border}`, backgroundColor: '#0D1520',
              overflow: 'hidden',
            }}>
              <textarea
                value={rawLog}
                onChange={e => setRawLog(e.target.value)}
                placeholder="Paste a raw log line here..."
                rows={3}
                style={{
                  width: '100%', padding: '14px 16px', border: 'none', outline: 'none',
                  backgroundColor: 'transparent', color: THEME.text, fontSize: 13,
                  fontFamily: FONT.mono, resize: 'none', boxSizing: 'border-box', lineHeight: 1.5,
                }}
              />
              <div style={{ display: 'flex', justifyContent: 'flex-end', padding: '0 6px 6px' }}>
                <button
                  onClick={handleGenerate}
                  disabled={!rawLog.trim() || isGenerating}
                  style={{
                    padding: '8px 18px', border: 'none', borderRadius: 8,
                    background: BTN_BG, color: '#fff', fontWeight: 600, fontSize: 13,
                    cursor: (!rawLog.trim()) ? 'not-allowed' : 'pointer',
                    display: 'flex', alignItems: 'center', gap: 6,
                    opacity: (!rawLog.trim()) ? 0.5 : 1, outline: 'none',
                  }}
                >
                  <EuiIcon type="wrench" size="s" color="#fff" />
                  Generate Decoder
                </button>
              </div>
            </div>
            <ChatDisclaimer align="center" marginTop={6} />
          </div>
        </div>
      )}

      {/* ═══ RESULTS STATE ═══
           Section order is intentional — most useful info first:
             1. Status banner (success/fail at a glance)
             2. AI Explanation (the WHY — auto-generated)
             3. Extracted Fields (the WHAT — what the decoder parses out)
             4. Decoder XML (the HOW — collapsible, copyable, technical)
             5. Attempt History (the audit trail — last)
           One sticky bar at the bottom for "New Decoder" / re-run.
       */}
      {hasResults && (
        <>
          {/* Results area — scrollable */}
          <div style={{ flex: 1, overflowY: 'auto', padding: '16px 24px' }} className="pallas-scrollbar">
            <div style={{ maxWidth: 1100, margin: '0 auto' }}>

              {/* In-progress stepper */}
              {isGenerating && <DecoderStepper steps={steps} />}

              {result && (() => {
                const fieldCount = result.extracted_fields ? Object.keys(result.extracted_fields).length : 0;
                const attemptCount = result.attempts ? result.attempts.length : 0;
                const passedAttempts = result.attempts ? result.attempts.filter(a => a.success || a.status === 'success').length : 0;
                const success = !result.error && !!result.decoder_xml;
                // Failure with no explicit error message but exhausted retries —
                // synthesize a useful message from the last attempt.
                const lastAttempt = result.attempts && result.attempts.length > 0 ? result.attempts[result.attempts.length - 1] : null;
                const synthesizedError = !success && !result.error && attemptCount > 0
                  ? `All ${attemptCount} validation attempts failed. ${lastAttempt?.error || lastAttempt?.message || 'The generated decoder could not be validated by wazuh-logtest. The log format may be unusual or the AI couldn\'t produce a working pattern — try simplifying the log sample or adjusting the field hints.'}`
                  : null;
                const showError = !success && (result.error || synthesizedError);

                return (
                  <>
                    {/* ── 1. Hero status banner — gradient with glow ── */}
                    {showError && (
                      <div style={{
                        position: 'relative', overflow: 'hidden',
                        background: 'linear-gradient(135deg, rgba(239,68,68,0.18), rgba(239,68,68,0.06))',
                        border: '1px solid rgba(239,68,68,0.35)',
                        borderRadius: 12, padding: '16px 20px',
                        marginBottom: 20, display: 'flex', alignItems: 'center', gap: 14,
                        boxShadow: GLOWS.danger,
                        animation: 'pallas-slideUp 0.3s ease',
                      }}>
                        <div style={{
                          width: 40, height: 40, borderRadius: 10,
                          background: 'rgba(239,68,68,0.2)',
                          display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0,
                        }}>
                          <EuiIcon type="alert" size="m" color="#EF4444" />
                        </div>
                        <div style={{ flex: 1, minWidth: 0 }}>
                          <div style={{ fontSize: 14, fontWeight: 700, color: '#fff', marginBottom: 2 }}>
                            Decoder generation failed
                          </div>
                          <div style={{ fontSize: 12, color: 'rgba(255,255,255,0.85)', lineHeight: 1.5 }}>
                            {result.error || synthesizedError}
                          </div>
                        </div>
                      </div>
                    )}
                    {success && (
                      <div style={{
                        position: 'relative', overflow: 'hidden',
                        background: `linear-gradient(135deg, ${accent}26, ${accent}0d)`,
                        border: `1px solid ${accent}55`,
                        borderRadius: 12, padding: '18px 22px',
                        marginBottom: 16,
                        boxShadow: ACCENT_GLOW,
                        animation: 'pallas-slideUp 0.3s ease',
                      }}>
                        <div style={{ display: 'flex', alignItems: 'center', gap: 14 }}>
                          <div style={{
                            width: 44, height: 44, borderRadius: 12,
                            background: ACCENT_GRAD,
                            display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0,
                            boxShadow: SHADOWS.md,
                          }}>
                            <EuiIcon type="check" size="m" color="#fff" />
                          </div>
                          <div style={{ flex: 1, minWidth: 0 }}>
                            <div style={{
                              fontSize: 16, fontWeight: 700, color: '#fff',
                              marginBottom: 4, letterSpacing: '-0.01em',
                            }}>
                              Decoder generated and validated
                            </div>
                            <div style={{ fontSize: 12, color: THEME.textSecondary, lineHeight: 1.5 }}>
                              {fieldCount > 0
                                ? `Successfully extracted ${fieldCount} field${fieldCount === 1 ? '' : 's'} from your sample log${attemptCount > 1 ? ` after ${passedAttempts}/${attemptCount} attempts` : ''}.`
                                : 'Ready to copy and deploy.'}
                            </div>
                          </div>
                        </div>
                      </div>
                    )}

                    {/* ── KPI summary tiles ── */}
                    {success && (
                      <div style={{
                        display: 'grid',
                        gridTemplateColumns: 'repeat(auto-fit, minmax(180px, 1fr))',
                        gap: 10, marginBottom: 20,
                        animation: 'pallas-fadeIn 0.4s ease',
                      }}>
                        <KPICard
                          icon="check"
                          label="Validation"
                          value="Passed"
                          accent="#22C55E"
                        />
                        <KPICard
                          icon="list"
                          label="Fields Extracted"
                          value={fieldCount}
                          accent={accent}
                        />
                        <KPICard
                          icon="refresh"
                          label="Attempts"
                          value={attemptCount > 0 ? `${passedAttempts}/${attemptCount}` : '1/1'}
                          accent={passedAttempts === attemptCount ? '#22C55E' : '#F59E0B'}
                        />
                        <KPICard
                          icon="document"
                          label="Decoder Size"
                          value={result.decoder_xml ? `${result.decoder_xml.split('\n').length} lines` : '—'}
                          accent={THEME.textSecondary}
                        />
                      </div>
                    )}

                    {/* ── 2. AI Explanation (auto-generated, with skeleton loading) ── */}
                    {(aiLoading || aiExplanation || aiError) && (
                      <GlassCard
                        accent={accent}
                        style={{
                          padding: 0, marginBottom: 20, overflow: 'hidden',
                          borderLeft: `4px solid ${accent}`,
                          animation: 'pallas-slideUp 0.35s ease',
                        }}
                      >
                        <div style={{
                          display: 'flex', alignItems: 'center', justifyContent: 'space-between',
                          padding: '12px 16px',
                          borderBottom: `1px solid ${THEME.border}`,
                          background: `linear-gradient(90deg, ${accent}14, transparent 70%)`,
                        }}>
                          <span style={{ fontSize: 13, fontWeight: 700, color: THEME.text, display: 'flex', alignItems: 'center', gap: 8 }}>
                            <div style={{
                              width: 24, height: 24, borderRadius: 6,
                              background: `${accent}26`,
                              display: 'flex', alignItems: 'center', justifyContent: 'center',
                            }}>
                              <EuiIcon type="inspect" size="s" color={accent} />
                            </div>
                            AI Explanation
                            {aiLoading && (
                              <span style={{
                                display: 'inline-flex', alignItems: 'center', gap: 5,
                                fontSize: 11, fontWeight: 500, color: accent,
                                padding: '2px 8px', borderRadius: 999,
                                background: `${accent}1a`,
                              }}>
                                <span style={{
                                  display: 'inline-block', width: 8, height: 8,
                                  border: `1.5px solid ${accent}50`, borderTopColor: accent,
                                  borderRadius: '50%', animation: 'pallas-spin 0.6s linear infinite',
                                }} />
                                Streaming
                              </span>
                            )}
                          </span>
                          {aiError && (
                            <button onClick={handleRetryExplain} style={{
                              background: 'transparent', border: `1px solid ${accent}`, borderRadius: 6,
                              color: accent, fontSize: 11, fontWeight: 600, padding: '4px 12px',
                              cursor: 'pointer', display: 'flex', alignItems: 'center', gap: 4, outline: 'none',
                            }}>
                              <EuiIcon type="refresh" size="s" color={accent} /> Retry
                            </button>
                          )}
                        </div>
                        {aiLoading && !aiExplanation && (
                          <div style={{ padding: '16px 18px', display: 'flex', flexDirection: 'column', gap: 8 }}>
                            <SkeletonLine width="92%" height={10} />
                            <SkeletonLine width="84%" height={10} />
                            <SkeletonLine width="96%" height={10} />
                            <SkeletonLine width="70%" height={10} />
                            <SkeletonLine width="88%" height={10} />
                          </div>
                        )}
                        {aiExplanation && (
                          <div style={{ padding: '4px 16px 8px' }}>
                            <ResponsePanel content={aiExplanation} accent={accent} />
                          </div>
                        )}
                        {aiError && !aiLoading && (
                          <div style={{
                            padding: '12px 16px', color: '#F87171', fontSize: 12,
                            display: 'flex', alignItems: 'center', gap: 8,
                          }}>
                            <EuiIcon type="alert" size="s" color="#F87171" />
                            Couldn't generate explanation: {aiError}
                          </div>
                        )}
                      </GlassCard>
                    )}

                    {/* ── 3. Extracted fields — KPI-tile style ── */}
                    {result.extracted_fields && fieldCount > 0 && (
                      <GlassCard
                        accent={accent}
                        style={{ padding: 16, marginBottom: 20, animation: 'pallas-slideUp 0.4s ease' }}
                      >
                        <h4 style={{
                          margin: '0 0 12px', fontSize: 13, fontWeight: 700, color: THEME.text,
                          display: 'flex', alignItems: 'center', gap: 8,
                        }}>
                          <div style={{
                            width: 24, height: 24, borderRadius: 6,
                            background: `${accent}26`,
                            display: 'flex', alignItems: 'center', justifyContent: 'center',
                          }}>
                            <EuiIcon type="list" size="s" color={accent} />
                          </div>
                          Extracted Fields
                          <span style={{
                            fontSize: 10, fontWeight: 700, marginLeft: 'auto',
                            padding: '2px 8px', borderRadius: 999,
                            background: `${accent}1a`, color: accent,
                          }}>
                            {fieldCount}
                          </span>
                        </h4>
                        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(200px, 1fr))', gap: 10 }}>
                          {Object.entries(result.extracted_fields).map(([key, value]) => (
                            <div key={key} style={{
                              background: 'rgba(255,255,255,0.025)',
                              border: `1px solid ${THEME.border}`,
                              borderLeft: `2px solid ${accent}80`,
                              borderRadius: 6, padding: '8px 12px',
                              display: 'flex', alignItems: 'center', gap: 8,
                              transition: 'all 0.15s ease',
                            }}
                              onMouseEnter={e => { e.currentTarget.style.background = 'rgba(255,255,255,0.05)'; }}
                              onMouseLeave={e => { e.currentTarget.style.background = 'rgba(255,255,255,0.025)'; }}
                            >
                              <div style={{ flex: 1, minWidth: 0 }}>
                                <div style={{
                                  fontSize: 10, fontFamily: FONT.mono,
                                  color: accent, marginBottom: 2, fontWeight: 600,
                                  textTransform: 'uppercase', letterSpacing: '0.04em',
                                }}>
                                  {key}
                                </div>
                                <div style={{ fontSize: 13, fontFamily: FONT.mono, color: THEME.text, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }} title={String(value)}>
                                  {String(value)}
                                </div>
                              </div>
                              <EuiIcon type="check" size="s" color="#22C55E" />
                            </div>
                          ))}
                        </div>
                      </GlassCard>
                    )}

                    {/* ── 4. Decoder XML — refined header gradient ── */}
                    {result.decoder_xml && (
                      <GlassCard
                        accent={accent}
                        style={{ overflow: 'hidden', marginBottom: 20, animation: 'pallas-slideUp 0.45s ease' }}
                      >
                        <div style={{
                          display: 'flex', alignItems: 'center', justifyContent: 'space-between',
                          padding: '12px 16px',
                          borderBottom: `1px solid ${THEME.border}`,
                          background: `linear-gradient(90deg, ${accent}14, transparent 70%)`,
                        }}>
                          <span style={{ fontSize: 13, fontWeight: 700, color: THEME.text, display: 'flex', alignItems: 'center', gap: 8 }}>
                            <div style={{
                              width: 24, height: 24, borderRadius: 6,
                              background: `${accent}26`,
                              display: 'flex', alignItems: 'center', justifyContent: 'center',
                            }}>
                              <EuiIcon type="document" size="s" color={accent} />
                            </div>
                            Decoder XML
                            <span style={{
                              fontSize: 10, fontWeight: 500, color: THEME.textMuted, marginLeft: 4,
                            }}>
                              paste into <code style={{ fontFamily: FONT.mono, color: accent }}>local_decoder.xml</code>
                            </span>
                          </span>
                          <button onClick={handleCopyXml} style={{
                            background: copiedXml ? 'rgba(34,197,94,0.15)' : 'transparent',
                            border: `1px solid ${copiedXml ? '#22C55E' : THEME.border}`, borderRadius: 6,
                            color: copiedXml ? '#22C55E' : THEME.textSecondary, fontSize: 12, fontWeight: 600,
                            padding: '4px 12px', cursor: 'pointer',
                            display: 'flex', alignItems: 'center', gap: 4, outline: 'none',
                            transition: 'all 0.15s',
                          }}>
                            <EuiIcon type={copiedXml ? 'check' : 'copy'} size="s" />
                            {copiedXml ? 'Copied!' : 'Copy XML'}
                          </button>
                        </div>
                        <pre style={{
                          margin: 0, padding: 16, background: THEME.bgDeep, color: THEME.text,
                          fontFamily: FONT.mono, fontSize: 12, lineHeight: 1.6,
                          overflowX: 'auto', whiteSpace: 'pre-wrap', wordBreak: 'break-word',
                        }}>
                          {result.decoder_xml}
                        </pre>
                      </GlassCard>
                    )}

                    {/* ── 5. Validation attempts — audit trail ── */}
                    {result.attempts && attemptCount > 0 && (
                      <GlassCard
                        accent={accent}
                        style={{ padding: 16, marginBottom: 20, animation: 'pallas-slideUp 0.5s ease' }}
                      >
                        <h4 style={{
                          margin: '0 0 12px', fontSize: 13, fontWeight: 700, color: THEME.text,
                          display: 'flex', alignItems: 'center', gap: 8,
                        }}>
                          <div style={{
                            width: 24, height: 24, borderRadius: 6,
                            background: `${accent}26`,
                            display: 'flex', alignItems: 'center', justifyContent: 'center',
                          }}>
                            <EuiIcon type="refresh" size="s" color={accent} />
                          </div>
                          Validation Attempts
                          <span style={{
                            fontSize: 10, fontWeight: 700, marginLeft: 'auto',
                            padding: '2px 8px', borderRadius: 999,
                            background: `${accent}1a`, color: accent,
                          }}>
                            {passedAttempts}/{attemptCount} passed
                          </span>
                        </h4>
                        <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
                          {result.attempts.map((attempt, i) => {
                            const ok = attempt.success || attempt.status === 'success';
                            return (
                              <div key={i} style={{
                                display: 'flex', alignItems: 'center', gap: 10, padding: '10px 12px',
                                background: 'rgba(255,255,255,0.02)',
                                border: `1px solid ${THEME.border}`,
                                borderLeft: `2px solid ${ok ? '#22C55E' : '#EF4444'}`,
                                borderRadius: 6, fontSize: 13,
                              }}>
                                <span style={{ color: THEME.textMuted, fontWeight: 600, fontSize: 12, minWidth: 28, fontFamily: FONT.mono }}>
                                  #{i + 1}
                                </span>
                                <PillBadge
                                  label={ok ? 'PASS' : 'FAIL'}
                                  color={ok ? '#22C55E' : '#EF4444'}
                                  bg={ok ? 'rgba(34,197,94,0.15)' : 'rgba(239,68,68,0.15)'}
                                  style={{ fontSize: 10, fontWeight: 700 }}
                                />
                                <span style={{ color: ok ? THEME.text : '#F87171', flex: 1, minWidth: 0 }}>
                                  {ok ? 'Decoder validated successfully' : (attempt.error || attempt.message || 'Validation failed')}
                                </span>
                              </div>
                            );
                          })}
                        </div>
                      </GlassCard>
                    )}
                  </>
                );
              })()}
            </div>
          </div>

          {/* Bottom action bar — single CTA row, no duplicate input/chips */}
          <div style={{
            flexShrink: 0, padding: '12px 24px 16px',
            borderTop: `1px solid ${THEME.border}`, background: THEME.bgDeep,
          }}>
            <div style={{
              maxWidth: 1100, margin: '0 auto', display: 'flex',
              alignItems: 'center', justifyContent: 'space-between', gap: 12, flexWrap: 'wrap',
            }}>
              <div style={{ fontSize: 12, color: THEME.textMuted, fontStyle: 'italic' }}>
                Pallas can make mistakes. Test the decoder against more samples before deploying.
              </div>
              <div style={{ display: 'flex', gap: 8 }}>
                <button
                  onClick={handleNewDecoder}
                  disabled={isGenerating}
                  style={{
                    padding: '8px 18px', borderRadius: 8,
                    border: `1px solid ${THEME.border}`, background: 'transparent',
                    color: THEME.textSecondary, fontSize: 13, fontWeight: 600,
                    cursor: isGenerating ? 'not-allowed' : 'pointer',
                    display: 'flex', alignItems: 'center', gap: 6,
                    opacity: isGenerating ? 0.5 : 1, outline: 'none',
                  }}>
                  <EuiIcon type="plus" size="s" />
                  New Decoder
                </button>
                <button
                  onClick={handleGenerate}
                  disabled={!rawLog.trim() || isGenerating}
                  title={!rawLog.trim() ? 'Type or paste a log line first (use New Decoder to start fresh)' : 'Re-run generation with the same log'}
                  style={{
                    padding: '8px 18px', border: 'none', borderRadius: 8,
                    background: (!rawLog.trim() || isGenerating) ? THEME.border : BTN_BG,
                    color: '#fff', fontWeight: 600, fontSize: 13,
                    cursor: (!rawLog.trim() || isGenerating) ? 'not-allowed' : 'pointer',
                    display: 'flex', alignItems: 'center', gap: 6,
                    opacity: (!rawLog.trim() || isGenerating) ? 0.5 : 1, outline: 'none',
                  }}>
                  <EuiIcon type="refresh" size="s" color="#fff" />
                  {isGenerating ? 'Generating...' : 'Re-generate'}
                </button>
              </div>
            </div>
          </div>
        </>
      )}
    </div>
  );
}
