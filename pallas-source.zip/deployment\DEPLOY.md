# Pallas AI Standalone — Deployment Guide

## Architecture Overview

```
172.16.134.12 (dev-ollama-server, AWS EC2 g5.4xlarge)
├── Pallas MCP Server  → port 3000 (FastAPI, existing container, --network host)
├── Pallas UI          → port 8001 (nginx, new container, --network host)
│
│   nginx inside pallas-ui container:
│   ├── /               → serves React static build
│   ├── /ai-analyst/*   → proxy_pass to localhost:3000 (MCP server)
│   └── /ai-analyst/ws/ → proxy_pass with WebSocket upgrade
│
└── Keycloak auth      → https://keycloak.athenasecuritygrp.com (remote, athena-security realm)
```

**Access:**
- Current (no DNS): `http://172.16.134.12:8001`
- Production (with DNS): `https://pallas.athenasecuritygrp.com`

---

## Prerequisites

| Requirement | Status |
|------------|--------|
| Pallas MCP Server running on 172.16.134.12:3000 | Already deployed |
| Security group allows port 8001 (range 8000-8002) | Already configured |
| Keycloak client `pallas-ui` in `athena-security` realm | Already created |
| VPN access to 172.16.134.12 | Required for testing |

---

## 1. Keycloak Client Setup

Create `pallas-ui` client on **both** Keycloak instances:
- Local dev: `http://localhost:8080/admin`
- Remote/production: `https://keycloak.athenasecuritygrp.com/admin`

Realm: `athena-security` → Clients → Create Client:

| Setting | Value |
|---------|-------|
| Client ID | `pallas-ui` |
| Protocol | OpenID Connect |
| Client authentication | Off (public SPA) |
| Standard flow | On |
| Direct access grants | On |

Valid Redirect URIs (add all):
```
http://localhost:3001/*
http://172.16.134.12:8001/*
https://pallas.athenasecuritygrp.com/*
```

Web Origins (add all):
```
http://localhost:3001
http://172.16.134.12:8001
https://pallas.athenasecuritygrp.com
```

---

## 2. Build the React App (on your dev machine)

```bash
cd pallas-app

# Install dependencies
npm install --legacy-peer-deps

# Build production bundle
npm run build

# Verify build output
ls build/
# Should show: index.html, static/, asset-manifest.json
```

---

## 3. Copy Files to Server

```bash
# From your dev machine, zip and upload
cd pallas-app
zip -r pallas-app.zip build/ nginx.conf Dockerfile.simple deployment/

# Upload to server
scp pallas-app.zip root@172.16.134.12:/opt/

# SSH to server and extract
ssh root@172.16.134.12
cd /opt
unzip pallas-app.zip -d pallas-app
```

**Required files on server:**
```
/opt/pallas-app/
├── build/                  # React production build (from npm run build)
│   ├── index.html
│   └── static/
│       ├── js/
│       └── css/
├── nginx.conf              # nginx config (serves UI + proxies API)
└── Dockerfile.simple       # Simple Dockerfile (copies build into nginx)
```

---

## 4. nginx.conf

The nginx.conf proxies API calls to the MCP server on the same host:

```nginx
server {
    listen 8001;
    server_name _;
    root /usr/share/nginx/html;
    index index.html;

    location / {
        try_files $uri $uri/ /index.html;
    }

    location /ai-analyst/ {
        proxy_pass http://127.0.0.1:3000;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
    }

    location /ai-analyst/ws/ {
        proxy_pass http://127.0.0.1:3000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection "upgrade";
        proxy_set_header Host $host;
        proxy_read_timeout 86400;
    }

    location /static/ {
        expires 1y;
        add_header Cache-Control "public, immutable";
    }

    gzip on;
    gzip_types text/plain text/css application/json application/javascript text/xml;
    gzip_min_length 256;
}
```

---

## 5. Dockerfile.simple

```dockerfile
FROM nginx:alpine
COPY build/ /usr/share/nginx/html
COPY nginx.conf /etc/nginx/conf.d/default.conf
EXPOSE 8001
CMD ["nginx", "-g", "daemon off;"]
```

---

## 6. Deploy Container

```bash
# On 172.16.134.12
cd /opt/pallas-app

# Build Docker image
docker build -f Dockerfile.simple -t pallas-ui:1.0.0 .

# Run with host networking (shares network with MCP server on port 3000)
docker run -d \
  --name pallas-ui \
  --network host \
  --restart unless-stopped \
  pallas-ui:1.0.0

# Verify container is running
docker ps | grep pallas-ui

# Verify UI serves
curl http://localhost:8001/

# Verify API proxy works
curl http://localhost:8001/ai-analyst/health
```

---

## 7. Verify End-to-End

### From the server:
```bash
# UI responds with HTML
curl http://localhost:8001/
# → Should return HTML with <title>Pallas AI</title>

# API proxy works
curl http://localhost:8001/ai-analyst/health
# → Should return JSON with {"status":"healthy",...}

# MCP server is healthy
curl http://localhost:3000/ai-analyst/health
# → Same JSON response
```

### From your machine (via VPN):
```bash
# UI is reachable
curl http://172.16.134.12:8001/
# → Should return HTML

# API proxy is reachable
curl http://172.16.134.12:8001/ai-analyst/health
# → Should return JSON
```

### In browser (via VPN):
1. Open `http://172.16.134.12:8001`
2. Keycloak login page appears → log in
3. Pallas workspace loads with NavigationRail, Header, StatusBar
4. Status shows "Online" (green)
5. Type "show all agents" → AI responds
6. Switch modules (IOC, Decoder, SIEM, NIDS, Vulns, Correlations, Narrative)
7. Click "Daily Standup" → KPIs load + AI analysis

---

## 8. Update Deployment

When code changes are made:

```bash
# 1. On dev machine: rebuild
cd pallas-app
npm run build

# 2. Copy new build to server
scp -r build/ root@172.16.134.12:/opt/pallas-app/

# 3. On server: rebuild and restart container
ssh root@172.16.134.12
cd /opt/pallas-app
docker stop pallas-ui && docker rm pallas-ui
docker build -f Dockerfile.simple -t pallas-ui:1.0.0 .
docker run -d --name pallas-ui --network host --restart unless-stopped pallas-ui:1.0.0

# 4. Verify
curl http://localhost:8001/
```

---

## 9. Production DNS Setup (when ready)

When infra team sets up the subdomain:

### Step 1: DNS Record
```
Type: CNAME (or A via ALB)
Name: pallas.athenasecuritygrp.com
Value: ALB DNS name (or 172.16.134.12 if directly accessible)
```

### Step 2: SSL Certificate
- Request ACM certificate for `pallas.athenasecuritygrp.com`
- Or use Let's Encrypt on the server

### Step 3: ALB Rule (if using ALB)
```
Host header: pallas.athenasecuritygrp.com
→ Target Group: 172.16.134.12:8001
```

### Step 4: Rebuild with production Keycloak URL
The current build uses `https://keycloak.athenasecuritygrp.com` as the Keycloak URL (baked in at build time). If this is correct for production, no rebuild needed.

### Step 5: Update Keycloak client
Ensure `https://pallas.athenasecuritygrp.com/*` is in Valid Redirect URIs (already added).

---

## 10. Troubleshooting

### Container not starting
```bash
docker logs pallas-ui
# Check for nginx config errors
```

### "Offline" / WebSocket not connecting
```bash
# Verify MCP server is running
docker ps | grep wazuh-mcp
curl http://localhost:3000/ai-analyst/health

# Verify proxy works
curl http://localhost:8001/ai-analyst/health

# Check nginx logs
docker logs pallas-ui --tail 50
```

### Keycloak "Client not found"
- Ensure `pallas-ui` client exists in the correct Keycloak instance
- The build uses `REACT_APP_KEYCLOAK_URL` baked at build time
- Check which Keycloak the build points to:
  ```bash
  grep -o 'keycloak[^"]*' /opt/pallas-app/build/static/js/main.*.js | head -5
  ```

### Can't reach from browser
- Check VPN connection
- Verify security group allows your VPN CIDR on port 8001
- Test with curl first: `curl http://172.16.134.12:8001/`

### Port conflict
```bash
# Check what's using a port
ss -tlnp | grep 8001
# Current ports in use:
# 3000 → Pallas MCP server (FastAPI)
# 8000 → Python process (Ollama proxy)
# 8001 → Pallas UI (nginx) ← this container
# 9000 → (other service)
# 11434 → Ollama LLM
```

---

## 11. Infrastructure Summary

### Servers
| Server | IP | Purpose |
|--------|-----|---------|
| dev-ollama-server | 172.16.134.12 | Pallas MCP + Pallas UI + Ollama |
| Ageleia server | 172.16.129.133 | Ageleia frontend/backend + Keycloak |
| Wazuh server | 172.16.52.125 | Wazuh Dashboard + Indexer + Manager |
| Suricata server | 172.16.49.71 | Suricata IDS agent |

### Ports on 172.16.134.12
| Port | Service | Container |
|------|---------|-----------|
| 3000 | Pallas MCP Server (FastAPI) | wazuh-mcp-remote-server |
| 8000 | Ollama proxy (Python) | Host process |
| 8001 | Pallas UI (nginx) | pallas-ui |
| 9000 | (reserved) | — |
| 11434 | Ollama LLM | Host process |

### Security Group: dev-athena-ollama
| Port | Source | Description |
|------|--------|-------------|
| 3000 | 172.16.0.0/16 | Pallas MCP API |
| 8000-8002 | 172.16.0.0/16 | Pallas UI + Ollama |
| 9000 | 172.16.0.0/16 | Reserved |
| 11434 | 172.16.52.125/32 | Ollama from Wazuh |

### Docker Containers
```bash
# View running containers
docker ps

# Expected output:
# pallas-ui              nginx:alpine    --network host    port 8001
# wazuh-mcp-remote-server FastAPI        --network host    port 3000
```
