/**
 * PallasDailyStandup — One-click SOC daily briefing
 *
 * Fetches structured KPI data via MCP REST calls (fast),
 * then streams an AI narrative via the parent's WebSocket connection.
 */

import React, { useState, useEffect, useRef, useCallback } from 'react';
import { EuiIcon } from '@elastic/eui';
import { THEME } from '../../utils/theme';
import {
  FONT,
  PALLAS_KEYFRAMES,
  StandupKPICard,
  RiskScoreBadge,
  CoverageBar,
  ChatDisclaimer,
} from './PallasUI';
import { mcpCall } from '../../services/pallasService';
import { ResponsePanel } from './PallasResponsePanel';
import PallasMarkdown from './PallasMarkdown';

// ─── Constants ────────────────────────────────────────────────────────────────

const STANDUP_QUERY = 'generate daily security standup: executive summary of the last 24 hours including alert trends, critical alerts needing attention, top 5 security threats with MITRE ATT&CK mapping, disconnected agents requiring investigation, and recommended actions for the SOC team';

// ─── Drill-Through Navigation ─────────────────────────────────────────────────
//
// Pallas runs iframed inside Athena Core (Wazuh Dashboard). Drill-through
// navigates the parent frame to the matching plugin app — relative paths
// resolve against the parent's origin, so the same code works for every
// tenant (test.athenasecuritygrp.com, prod-clientA.com, etc.) with zero
// per-tenant configuration.
//
// Target app IDs come from the Wazuh plugin's applications.ts registration:
//   threat-hunting           — EDR alerts overview dashboard
//   network-threats          — NIDS / Suricata dashboard
//   vulnerability-detection  — Vulnerabilities dashboard
//   endpoints-summary        — Agent inventory + coverage
//   data-explorer/discover   — raw Discover (used for rule-id deep links)

const ATHENA_CORE = {
  edr:        '/app/threat-hunting#/overview/?tab=general&tabView=dashboard',
  nids:       '/app/network-threats',
  vulns:      '/app/vulnerability-detection#/overview/?tab=vuls&tabView=dashboard',
  endpoints:  '/app/endpoints-summary',
  discoverByRule: (ruleId) =>
    `/app/data-explorer/discover#/?_g=(time:(from:now-24h,to:now))&_q=(query:(language:kuery,query:'rule.id:${ruleId}'))`,
};

function drillThrough(path) {
  if (!path) return;
  try {
    // Pallas is iframed inside Athena Core (same OSD instance, same origin),
    // so top-frame navigation is allowed and resolves to the tenant's host.
    window.top.location.href = path;
  } catch (err) {
    // Cross-origin iframe edge case — fall back to a new tab.
    window.open(path, '_blank', 'noopener');
  }
}

// ─── Main Component ──────────────────────────────────────────────────────────

export default function PallasDailyStandup({
  sendQuery,
  response,
  isLoading,
  onClose,
  connectionStatus,
  onSuggestionClick,
}) {
  // ── KPI Data State ─────────────────────────────────────────────────────────
  const [reportData, setReportData] = useState(null);
  const [riskData, setRiskData] = useState(null);
  const [nidsData, setNidsData] = useState(null);
  const [topThreats, setTopThreats] = useState(null);
  const [kpiLoading, setKpiLoading] = useState(true);
  const [kpiError, setKpiError] = useState(null);
  const [narrativeTriggered, setNarrativeTriggered] = useState(false);
  const [aiExpanded, setAiExpanded] = useState(false);

  const scrollRef = useRef(null);
  const inputRef = useRef(null);
  const [replyValue, setReplyValue] = useState('');

  // ── Fetch KPI data on mount ────────────────────────────────────────────────
  useEffect(() => {
    let cancelled = false;

    async function fetchKPIs() {
      try {
        const [reportRes, riskRes, nidsRes, threatsRes] = await Promise.allSettled([
          mcpCall('generate_security_report', { report_type: 'daily', include_recommendations: true }),
          mcpCall('perform_risk_assessment', {}),
          mcpCall('get_suricata_alert_summary', { time_range: '24h' }),
          mcpCall('get_top_security_threats', { limit: 10, time_range: '24h' }),
        ]);

        if (cancelled) return;

        // Parse report data (skip if MCP tool returned an error)
        if (reportRes.status === 'fulfilled' && reportRes.value.text && !reportRes.value.isError) {
          try {
            const parsed = JSON.parse(reportRes.value.text);
            setReportData(parsed);
          } catch { setReportData(null); }
        } else if (reportRes.status === 'fulfilled' && reportRes.value.isError) {
          console.warn('[Standup] generate_security_report failed:', reportRes.value.text);
        }

        // Parse risk data (skip if MCP tool returned an error)
        if (riskRes.status === 'fulfilled' && riskRes.value.text && !riskRes.value.isError) {
          const text = riskRes.value.text;
          const scoreMatch = text.match(/Score:\s*(\d+)/i);
          const coverageMatch = text.match(/Monitoring Coverage.*?([\d.]+)%/i);
          const disconnectedMatch = text.match(/Disconnected.*?(\d+)/i);
          const totalMatch = text.match(/Total Agents.*?(\d+)/i);
          setRiskData({
            score: scoreMatch ? parseInt(scoreMatch[1], 10) : 0,
            coverage: coverageMatch ? parseFloat(coverageMatch[1]) : 0,
            disconnected: disconnectedMatch ? parseInt(disconnectedMatch[1], 10) : 0,
            totalAgents: totalMatch ? parseInt(totalMatch[1], 10) : 0,
          });
        } else if (riskRes.status === 'fulfilled' && riskRes.value.isError) {
          console.warn('[Standup] perform_risk_assessment failed:', riskRes.value.text);
        }

        // Parse NIDS data (skip if MCP tool returned an error)
        if (nidsRes.status === 'fulfilled' && nidsRes.value.text && !nidsRes.value.isError) {
          try {
            const parsed = JSON.parse(nidsRes.value.text);
            setNidsData(parsed);
          } catch { setNidsData(null); }
        } else if (nidsRes.status === 'fulfilled' && nidsRes.value.isError) {
          console.warn('[Standup] get_suricata_alert_summary failed:', nidsRes.value.text);
        }

        // Parse top threats (markdown format — extract structured data)
        if (threatsRes.status === 'fulfilled' && threatsRes.value.text && !threatsRes.value.isError) {
          const text = threatsRes.value.text;
          const threats = [];
          const blocks = text.split(/###\s+\d+\.\s+/).filter(Boolean);
          for (const block of blocks) {
            const lines = block.trim().split('\n');
            const title = lines[0]?.trim() || '';
            const levelMatch = block.match(/\*\*Level:\*\*\s*(\d+)/);
            const ruleMatch = block.match(/\*\*Rule ID:\*\*\s*(\d+)/);
            const agentMatch = block.match(/\*\*Agent:\*\*\s*(.+)/);
            const mitreMatch = block.match(/\*\*MITRE Technique:\*\*\s*(.+)/);
            const timeMatch = block.match(/\*\*Timestamp:\*\*\s*(.+)/);
            if (title && levelMatch) {
              threats.push({
                title: title.length > 80 ? title.slice(0, 77) + '...' : title,
                level: parseInt(levelMatch[1], 10),
                ruleId: ruleMatch ? ruleMatch[1] : '',
                agent: agentMatch ? agentMatch[1].trim() : '',
                mitre: mitreMatch ? mitreMatch[1].trim() : '',
                timestamp: timeMatch ? timeMatch[1].trim() : '',
              });
            }
          }
          setTopThreats(threats);
        }
      } catch (err) {
        if (!cancelled) setKpiError(err.message);
      } finally {
        if (!cancelled) setKpiLoading(false);
      }
    }

    fetchKPIs();
    return () => { cancelled = true; };
  }, []);

  // ── Trigger AI narrative after KPI data loads ──────────────────────────────
  useEffect(() => {
    if (!kpiLoading && !narrativeTriggered && connectionStatus === 'connected') {
      sendQuery(STANDUP_QUERY);
      setNarrativeTriggered(true);
    }
  }, [kpiLoading, narrativeTriggered, connectionStatus, sendQuery]);

  // ── Smooth scroll to AI Analysis section when response first arrives ────────
  const hasScrolledToAnalysis = useRef(false);
  useEffect(() => {
    if (response && scrollRef.current && !hasScrolledToAnalysis.current) {
      hasScrolledToAnalysis.current = true;
      // Scroll the "AI Analysis" divider into view, not to the very bottom
      const divider = scrollRef.current.querySelector('[data-standup-ai-divider]');
      if (divider) {
        divider.scrollIntoView({ behavior: 'smooth', block: 'start' });
      }
    }
  }, [response]);

  // ── Reply handler ──────────────────────────────────────────────────────────
  const handleReply = useCallback(() => {
    if (!replyValue.trim() || isLoading) return;
    sendQuery(replyValue.trim());
    setReplyValue('');
    if (inputRef.current) inputRef.current.style.height = 'auto';
  }, [replyValue, isLoading, sendQuery]);

  const handleReplyKeyDown = useCallback((e) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleReply();
    }
  }, [handleReply]);

  // ── Derived KPI values ─────────────────────────────────────────────────────
  const hasReport = reportData !== null;
  const hasRisk = riskData !== null;
  const totalAlerts = hasReport ? (reportData.alerts?.total || 0) : null;
  const criticalHigh = hasReport ? Object.entries(reportData.alerts?.by_level || {})
    .filter(([level]) => parseInt(level, 10) >= 10)
    .reduce((sum, [, count]) => sum + count, 0) : null;
  const nidsAlerts = nidsData?.total_alerts || 0;
  const criticalVulns = hasReport ? (reportData.vulnerabilities?.by_severity?.critical || 0) : null;
  const agentsActive = hasReport ? (reportData.agents?.active || 0) : null;
  const agentsTotal = hasReport ? (reportData.agents?.total || 0) : null;
  const riskScore = hasRisk ? (riskData.score || 0) : null;

  const now = new Date();
  const dateStr = now.toLocaleDateString('en-US', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' });
  const timeStr = now.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' });

  // ── Render ─────────────────────────────────────────────────────────────────
  return (
    <div style={{ display: 'flex', flexDirection: 'column', height: '100%', width: '100%', flex: 1, fontFamily: FONT.base }}>
      <style>{PALLAS_KEYFRAMES}</style>

      {/* ── Scrollable Content ─────────────────────────────────────────────── */}
      <div
        ref={scrollRef}
        className="pallas-scrollbar"
        style={{ flex: 1, overflow: 'auto', padding: '0 24px 24px' }}
      >
        {/* Central container — fluid + responsive. 90% of available width
            up to a 2400px cap. The 10% combined side margin (5% each side)
            keeps content visually centered without feeling stretched edge
            to edge — at 95% on wider Chrome windows analysts reported the
            page feeling too "zoomed out" / content too far apart. */}
        <div style={{ width: '90%', maxWidth: 2400, margin: '0 auto' }}>

          {/* ── Standup Header ───────────────────────────────────────────── */}
          <div style={{
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'space-between',
            padding: '20px 0 16px',
            borderBottom: `1px solid ${THEME.border}`,
            marginBottom: 20,
          }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
              <div style={{
                width: 36,
                height: 36,
                borderRadius: 10,
                background: `linear-gradient(135deg, ${THEME.accent}, ${THEME.accent}80)`,
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
              }}>
                <EuiIcon type="calendar" size="m" color="#fff" />
              </div>
              <div>
                <div style={{
                  fontSize: 10,
                  fontWeight: 700,
                  color: THEME.accent,
                  textTransform: 'uppercase',
                  letterSpacing: '0.1em',
                }}>
                  Pallas Daily Standup
                </div>
                <div style={{ fontSize: 13, color: THEME.textMuted }}>
                  {dateStr} {timeStr}
                </div>
              </div>
            </div>
            <div style={{ display: 'flex', gap: 8 }}>
              {/* Export button */}
              <button
                onClick={() => {
                  const lines = [`# Pallas Daily Standup — ${dateStr} ${timeStr}\n`];
                  if (reportData) {
                    lines.push(`## KPIs`);
                    lines.push(`- EDR Alerts (24h): ${totalAlerts !== null ? totalAlerts.toLocaleString() : 'N/A'}`);
                    lines.push(`- Critical/High: ${criticalHigh !== null ? criticalHigh.toLocaleString() : 'N/A'}`);
                    lines.push(`- NIDS Alerts: ${nidsAlerts.toLocaleString()}`);
                    lines.push(`- Critical Vulns: ${criticalVulns !== null ? criticalVulns.toLocaleString() : 'N/A'}\n`);
                  }
                  if (reportData?.recommendations) {
                    lines.push(`## Priority Actions`);
                    reportData.recommendations.forEach((r, i) => lines.push(`${i + 1}. ${r}`));
                    lines.push('');
                  }
                  if (topThreats?.length) {
                    lines.push(`## Top Alerts`);
                    topThreats.forEach((t, i) => lines.push(`${i + 1}. [Level ${t.level}] ${t.title} — Agent: ${t.agent}${t.mitre ? ` (MITRE: ${t.mitre})` : ''}`));
                    lines.push('');
                  }
                  if (response?.content) {
                    lines.push(`## AI Analysis\n`);
                    lines.push(response.content);
                  }
                  if (response?.socAnalysis) {
                    lines.push(`\n## SOC Analysis\n`);
                    lines.push(response.socAnalysis);
                  }
                  const blob = new Blob([lines.join('\n')], { type: 'text/markdown' });
                  const url = URL.createObjectURL(blob);
                  const a = document.createElement('a');
                  a.href = url;
                  a.download = `standup-${new Date().toISOString().slice(0, 10)}.md`;
                  document.body.appendChild(a);
                  a.click();
                  document.body.removeChild(a);
                  URL.revokeObjectURL(url);
                }}
                style={{
                  padding: '6px 14px', borderRadius: 6,
                  border: `1px solid ${THEME.border}`,
                  background: 'transparent', color: THEME.textMuted,
                  fontSize: 12, cursor: 'pointer',
                  display: 'flex', alignItems: 'center', gap: 4,
                }}
              >
                <EuiIcon type="download" size="s" />
                Export
              </button>
              {/* Close button */}
              <button
                onClick={onClose}
                style={{
                  padding: '6px 14px', borderRadius: 6,
                  border: `1px solid ${THEME.border}`,
                  background: 'transparent', color: THEME.textMuted,
                  fontSize: 12, cursor: 'pointer',
                  display: 'flex', alignItems: 'center', gap: 4,
                }}
              >
                <EuiIcon type="cross" size="s" />
              Close
            </button>
            </div>
          </div>

          {/* ── KPI Cards ────────────────────────────────────────────────── */}
          {kpiLoading ? (
            <div style={{ display: 'flex', gap: 12, marginBottom: 16 }}>
              {[1, 2, 3, 4].map((i) => (
                <div key={i} style={{
                  flex: '1 1 0',
                  height: 90,
                  borderRadius: 10,
                  background: 'rgba(255,255,255,0.03)',
                  border: `1px solid ${THEME.border}`,
                  animation: 'pallas-pulse 1.5s ease infinite',
                  animationDelay: `${i * 0.15}s`,
                }} />
              ))}
            </div>
          ) : kpiError ? (
            <div style={{
              padding: 16,
              borderRadius: 10,
              background: `${THEME.sevHigh}08`,
              border: `1px solid ${THEME.sevHigh}25`,
              color: THEME.sevHigh,
              fontSize: 13,
              marginBottom: 16,
            }}>
              Failed to load KPI data: {kpiError}
            </div>
          ) : (
            <>
              <div style={{ display: 'flex', gap: 12, marginBottom: 12 }}>
                <StandupKPICard
                  icon="storage"
                  label="EDR Alerts (24h)"
                  value={totalAlerts !== null ? totalAlerts.toLocaleString() : 'N/A'}
                  subValue={hasReport ? `${Object.keys(reportData.alerts?.by_level || {}).length} severity levels` : 'Wazuh unavailable'}
                  color={THEME.accent}
                  onClick={() => drillThrough(ATHENA_CORE.edr)}
                />
                <StandupKPICard
                  icon="alert"
                  label="Critical / High"
                  value={criticalHigh !== null ? criticalHigh.toLocaleString() : 'N/A'}
                  subValue="Level 10+ alerts"
                  color={criticalHigh !== null && criticalHigh > 0 ? THEME.sevHigh : THEME.success}
                  onClick={() => drillThrough(ATHENA_CORE.edr)}
                />
                <StandupKPICard
                  icon="globe"
                  label="NIDS Alerts (24h)"
                  value={nidsAlerts.toLocaleString()}
                  subValue={nidsData ? `Sev 1: ${nidsData.severity_breakdown?.['1'] || 0} critical` : ''}
                  color="#F97316"
                  onClick={() => drillThrough(ATHENA_CORE.nids)}
                />
                <StandupKPICard
                  icon="bug"
                  label="Critical Vulns"
                  value={criticalVulns !== null ? criticalVulns.toLocaleString() : 'N/A'}
                  subValue={hasReport ? `${(reportData.vulnerabilities?.total || 0).toLocaleString()} total` : 'Wazuh unavailable'}
                  color={criticalVulns !== null && criticalVulns > 50 ? THEME.sevHigh : THEME.sevMedium}
                  onClick={() => drillThrough(ATHENA_CORE.vulns)}
                />
              </div>

              {/* ── Risk Score + Agent Coverage ─────────────────────────── */}
              <div style={{ display: 'flex', gap: 12, marginBottom: 20 }}>
                <RiskScoreBadge score={riskScore !== null ? riskScore : 0} onClick={null} />
                <CoverageBar active={agentsActive !== null ? agentsActive : 0} total={agentsTotal !== null ? agentsTotal : 0} onClick={() => drillThrough(ATHENA_CORE.endpoints)} />
              </div>
            </>
          )}

          {/* ── Recommendations (from structured data) ───────────────────── */}
          {reportData?.recommendations?.length > 0 && (
            <div style={{
              padding: '12px 16px',
              borderRadius: 10,
              background: `${THEME.sevMedium}06`,
              border: `1px solid ${THEME.sevMedium}20`,
              marginBottom: 20,
            }}>
              <div style={{
                fontSize: 10,
                fontWeight: 700,
                color: THEME.sevMedium,
                textTransform: 'uppercase',
                letterSpacing: '0.06em',
                marginBottom: 8,
                display: 'flex',
                alignItems: 'center',
                gap: 6,
              }}>
                <EuiIcon type="alert" size="s" color={THEME.sevMedium} />
                Priority Actions
              </div>
              <ul style={{ margin: 0, paddingLeft: 18, display: 'flex', flexDirection: 'column', gap: 4 }}>
                {reportData.recommendations.map((rec, i) => (
                  <li key={i} style={{ fontSize: 13, color: THEME.textSecondary, lineHeight: 1.5 }}>
                    {rec}
                  </li>
                ))}
              </ul>
            </div>
          )}

          {/* ── Top Alerts Needing Attention ─────────────────────────────── */}
          {topThreats && topThreats.length > 0 && (
            <div style={{
              padding: '12px 0', marginBottom: 20,
            }}>
              <div style={{
                display: 'flex', alignItems: 'center', justifyContent: 'space-between',
                marginBottom: 12,
              }}>
                <div style={{
                  fontSize: 10, fontWeight: 700, color: THEME.sevCritical,
                  textTransform: 'uppercase', letterSpacing: '0.06em',
                  display: 'flex', alignItems: 'center', gap: 6,
                }}>
                  <EuiIcon type="alert" size="s" color={THEME.sevCritical} />
                  Alerts Requiring Attention
                </div>
              </div>
              <div style={{
                borderRadius: 8, overflow: 'hidden',
                border: `1px solid ${THEME.border}`,
              }}>
                <table style={{ width: '100%', borderCollapse: 'collapse' }}>
                  <thead>
                    <tr style={{ background: THEME.cardSubtle }}>
                      <th style={{ padding: '8px 12px', textAlign: 'left', fontSize: 10, fontWeight: 700, color: THEME.textMuted, textTransform: 'uppercase' }}>Description</th>
                      <th style={{ padding: '8px 12px', textAlign: 'left', fontSize: 10, fontWeight: 700, color: THEME.textMuted, textTransform: 'uppercase' }}>Rule</th>
                      <th style={{ padding: '8px 12px', textAlign: 'left', fontSize: 10, fontWeight: 700, color: THEME.textMuted, textTransform: 'uppercase' }}>Agent</th>
                      <th style={{ padding: '8px 12px', textAlign: 'left', fontSize: 10, fontWeight: 700, color: THEME.textMuted, textTransform: 'uppercase' }}>MITRE</th>
                      <th style={{ padding: '8px 12px', textAlign: 'center', fontSize: 10, fontWeight: 700, color: THEME.textMuted, textTransform: 'uppercase' }}>Severity</th>
                    </tr>
                  </thead>
                  <tbody>
                    {topThreats.slice(0, 8).map((threat, i) => {
                      const sevColor = threat.level >= 12 ? THEME.sevCritical
                        : threat.level >= 7 ? THEME.sevHigh
                        : THEME.sevMedium;
                      const sevLabel = threat.level >= 12 ? 'Critical'
                        : threat.level >= 10 ? 'High'
                        : threat.level >= 7 ? 'Medium'
                        : 'Low';
                      return (
                        <tr key={i}
                          onClick={() => drillThrough(ATHENA_CORE.discoverByRule(threat.ruleId))}
                          style={{
                            borderBottom: `1px solid ${THEME.borderSubtle}`,
                            background: i % 2 === 0 ? 'transparent' : 'rgba(255,255,255,0.01)',
                            cursor: 'pointer',
                            transition: 'background 0.15s',
                          }}
                          onMouseEnter={(e) => { e.currentTarget.style.background = `${THEME.accent}08`; }}
                          onMouseLeave={(e) => { e.currentTarget.style.background = i % 2 === 0 ? 'transparent' : 'rgba(255,255,255,0.01)'; }}
                        >
                          <td style={{ padding: '8px 12px', fontSize: 12, color: THEME.text, maxWidth: 300, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                            {threat.title}
                          </td>
                          <td style={{ padding: '8px 12px', fontSize: 11, color: THEME.textMuted, fontFamily: FONT.mono }}>
                            {threat.ruleId}
                          </td>
                          <td style={{ padding: '8px 12px', fontSize: 11, color: THEME.textSecondary }}>
                            {threat.agent}
                          </td>
                          <td style={{ padding: '8px 12px', fontSize: 11, color: THEME.primary }}>
                            {threat.mitre || '—'}
                          </td>
                          <td style={{ padding: '8px 12px', textAlign: 'center' }}>
                            <span style={{
                              padding: '2px 8px', borderRadius: 4, fontSize: 10, fontWeight: 700,
                              color: sevColor, background: sevColor + '15',
                            }}>
                              {sevLabel}
                            </span>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* ── AI Analysis (collapsible) ─────────────────────────────────── */}
          <div data-standup-ai-divider style={{
            display: 'flex',
            alignItems: 'center',
            gap: 12,
            margin: '4px 0 16px',
            cursor: 'pointer',
          }} onClick={() => setAiExpanded((v) => !v)}>
            <div style={{ flex: 1, height: 1, background: THEME.border }} />
            <div style={{
              display: 'flex', alignItems: 'center', gap: 6,
            }}>
              <EuiIcon type={aiExpanded ? 'arrowDown' : 'arrowRight'} size="s" color={THEME.textMuted} />
              <span style={{
                fontSize: 10, fontWeight: 700, color: THEME.textMuted,
                textTransform: 'uppercase', letterSpacing: '0.08em',
              }}>
                AI Deep Analysis {response ? '(click to expand)' : isLoading ? '(loading...)' : ''}
              </span>
            </div>
            <div style={{ flex: 1, height: 1, background: THEME.border }} />
          </div>

          {/* ── AI Narrative (from WebSocket) ─────────────────────────────── */}
          {(aiExpanded || (!response && isLoading)) && (
            <div style={{ minHeight: 80 }}>
              {isLoading && !response && (
                <div style={{
                  display: 'flex', alignItems: 'center', gap: 10,
                  padding: 20, color: THEME.textMuted,
                  animation: 'pallas-breathe 2s ease infinite',
                }}>
                  <div style={{
                    width: 8, height: 8, borderRadius: '50%',
                    backgroundColor: THEME.accent,
                    animation: 'pallas-pulse 1s ease infinite',
                  }} />
                  <span style={{ fontSize: 13 }}>Pallas is analyzing your environment...</span>
                </div>
              )}

              {response && (
                <ResponsePanel
                  content={response.content}
                  blocks={response.blocks}
                  metadata={response.metadata}
                  socAnalysis={response.socAnalysis}
                  suggestions={response.suggestions}
                  onSuggestionClick={onSuggestionClick}
                  isLoading={isLoading}
                />
              )}
            </div>
          )}
        </div>
      </div>

      {/* ── Reply Input ────────────────────────────────────────────────────── */}
      <div style={{
        flexShrink: 0,
        padding: '12px 24px 16px',
        borderTop: `1px solid ${THEME.border}`,
      }}>
        <div style={{ width: '90%', margin: '0 auto' }}>
          <div style={{ fontSize: 11, color: THEME.textMuted, marginBottom: 6 }}>
            Reply to Pallas...
          </div>
          <div style={{
            position: 'relative',
            borderRadius: 10,
            border: `1px solid ${THEME.border}`,
            background: THEME.card,
            overflow: 'hidden',
          }}>
            <textarea
              ref={inputRef}
              value={replyValue}
              onChange={(e) => setReplyValue(e.target.value)}
              onKeyDown={handleReplyKeyDown}
              placeholder="Ask a follow-up question about this standup..."
              rows={2}
              style={{
                width: '100%',
                padding: '12px 56px 12px 14px',
                border: 'none',
                outline: 'none',
                background: 'transparent',
                color: THEME.text,
                fontSize: 13,
                fontFamily: FONT.base,
                resize: 'none',
                lineHeight: 1.5,
              }}
            />
            <button
              onClick={handleReply}
              disabled={!replyValue.trim() || isLoading}
              style={{
                position: 'absolute',
                bottom: 8,
                right: 8,
                width: 34,
                height: 34,
                borderRadius: 8,
                border: 'none',
                background: replyValue.trim() && !isLoading
                  ? `linear-gradient(135deg, ${THEME.accent}, ${THEME.accent}CC)`
                  : THEME.border,
                cursor: replyValue.trim() && !isLoading ? 'pointer' : 'default',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                transition: 'all 0.15s',
              }}
            >
              <EuiIcon type="arrowRight" size="s" color={replyValue.trim() && !isLoading ? '#fff' : THEME.textMuted} />
            </button>
          </div>
          <ChatDisclaimer align="center" marginTop={6} />
        </div>
      </div>
    </div>
  );
}
