"""
Wazuh Decoder Generator — LLM-powered decoder creation with validation.

Accepts a raw log sample, uses the LLM to generate a Wazuh XML decoder,
validates it with Python regex simulation, and retries on failure.
"""

import re
import os
import logging
import xml.etree.ElementTree as ET
from typing import Dict, Any, Optional, List, Tuple

logger = logging.getLogger(__name__)


class DecoderGenerator:
    """Generate and validate Wazuh decoders from raw log samples."""

    MAX_RETRIES = 3

    # Wazuh-specific regex group pattern: (\S+), (\.+), etc.
    WAZUH_REGEX_MAP = {
        r"\\.+": r"(.+)",
        r"\\S+": r"(\S+)",
        r"\\s+": r"(\s+)",
        r"\\d+": r"(\d+)",
        r"\\w+": r"(\w+)",
    }

    # Standard Wazuh fields
    STANDARD_FIELDS = [
        "srcip", "dstip", "srcport", "dstport", "user", "action",
        "protocol", "id", "url", "status", "extra_data", "srcuser",
        "dstuser", "data", "system_name",
    ]

    def __init__(self, wazuh_client, llm_client):
        """
        Args:
            wazuh_client: WazuhClient instance for logtest API calls
            llm_client: OllamaClient instance for decoder generation
        """
        self.wazuh_client = wazuh_client
        self.llm_client = llm_client

    async def generate(
        self,
        raw_log: str,
        log_format: str = "syslog",
        device_type: Optional[str] = None,
        vendor: Optional[str] = None,
        expected_fields: Optional[str] = None,
    ) -> Dict[str, Any]:
        """
        Full lifecycle: analyze raw log -> generate decoder -> validate -> retry.

        Returns:
            Dict with keys: status, decoder_xml, extracted_fields, attempts,
                           logtest_output, validation_details, errors
        """
        result = {
            "status": "failed",
            "decoder_xml": None,
            "extracted_fields": {},
            "attempts": [],
            "logtest_output": None,
            "raw_log": raw_log,
            "log_format": log_format,
            "device_type": device_type,
            "vendor": vendor,
        }

        # Step A: Run logtest to analyze the raw log with existing decoders
        logtest_output = await self._run_logtest(raw_log, log_format)
        result["logtest_output"] = logtest_output

        # Step B-D: Generate, validate, retry loop
        last_decoder_xml = None
        last_errors = []

        for attempt in range(1, self.MAX_RETRIES + 1):
            attempt_record = {"attempt": attempt, "status": "pending", "errors": []}

            try:
                # Build the appropriate prompt
                if attempt == 1:
                    prompt = self._build_llm_prompt(
                        raw_log, logtest_output, device_type, vendor, expected_fields
                    )
                else:
                    prompt = self._build_retry_prompt(
                        raw_log, last_decoder_xml, last_errors
                    )

                # Call LLM to generate decoder XML
                llm_response = await self._call_llm_generate(prompt)
                decoder_xml = self._extract_xml_from_response(llm_response)

                if not decoder_xml:
                    attempt_record["status"] = "failed"
                    attempt_record["errors"].append("Could not extract valid XML from LLM response")
                    result["attempts"].append(attempt_record)
                    last_decoder_xml = llm_response
                    last_errors = attempt_record["errors"]
                    continue

                attempt_record["decoder_xml"] = decoder_xml
                last_decoder_xml = decoder_xml

                # Validate the generated decoder
                validation = self._validate_decoder(decoder_xml, raw_log)
                attempt_record["validation"] = validation

                if validation["valid"]:
                    attempt_record["status"] = "success"
                    result["status"] = "success"
                    result["decoder_xml"] = decoder_xml
                    result["extracted_fields"] = validation.get("extracted_fields", {})
                    result["attempts"].append(attempt_record)
                    logger.info(f"Decoder generated successfully on attempt {attempt}")
                    break
                else:
                    attempt_record["status"] = "validation_failed"
                    attempt_record["errors"] = validation.get("errors", [])
                    last_errors = validation.get("errors", [])

            except Exception as e:
                logger.error(f"Decoder generation attempt {attempt} error: {e}")
                attempt_record["status"] = "error"
                attempt_record["errors"].append(str(e))
                last_errors = [str(e)]

            result["attempts"].append(attempt_record)

        # If all attempts failed, include the best decoder we got
        if result["status"] == "failed" and last_decoder_xml:
            result["decoder_xml"] = last_decoder_xml
            result["errors"] = last_errors

        return result

    async def _run_logtest(self, event: str, log_format: str = "syslog") -> Optional[Dict]:
        """Run PUT /logtest to analyze the raw log with existing decoders."""
        try:
            response = await self.wazuh_client.run_logtest(
                event=event,
                log_format=log_format,
                location="decoder-generator",
            )
            if response and "data" in response:
                return response["data"]
            return response
        except Exception as e:
            logger.warning(f"Logtest call failed (non-fatal): {e}")
            return {"error": str(e), "note": "Logtest unavailable, generating without analysis"}

    def _build_llm_prompt(
        self,
        raw_log: str,
        logtest_output: Optional[Dict],
        device_type: Optional[str],
        vendor: Optional[str],
        expected_fields: Optional[str],
    ) -> str:
        """Construct the decoder generation prompt with full context."""

        logtest_section = "No logtest data available."
        if logtest_output and not logtest_output.get("error"):
            logtest_section = self._format_logtest_output(logtest_output)

        hints = []
        if device_type:
            hints.append(f"- Device type: {device_type}")
        if vendor:
            hints.append(f"- Vendor: {vendor}")
        if expected_fields:
            hints.append(f"- Expected fields to extract: {expected_fields}")
        hints_section = "\n".join(hints) if hints else "- No specific hints provided"

        return f"""You are a Wazuh decoder expert. Generate a Wazuh XML decoder for this log.

RAW LOG:
{raw_log}

LOGTEST ANALYSIS (current decoder state):
{logtest_section}

HINTS:
{hints_section}

REQUIREMENTS:
1. Output ONLY valid Wazuh XML decoder(s) wrapped in <decoder>...</decoder> tags
2. Use Wazuh regex syntax with capture groups using parentheses
3. Include <prematch> for log line identification
4. Include <regex> with capture groups matching <order> fields
5. Use appropriate parent decoder if the log starts with a syslog header
6. Extract fields like: srcip, dstip, srcport, dstport, user, action, protocol where applicable
7. Wazuh regex uses: \\S+ (non-space), \\.+ (any chars), \\d+ (digits), \\w+ (word chars)
8. Capture groups in <regex> are positional — they map 1:1 to fields in <order>

IMPORTANT WAZUH REGEX RULES:
- Use \\S+ to match non-whitespace sequences
- Use \\.+ to match any character sequences
- Use \\d+ to match digit sequences
- Capture groups use parentheses: (\\S+) captures a non-whitespace token
- The <order> tag lists field names separated by commas, matching capture group positions
- If the log has a syslog header (timestamp hostname program), use a parent decoder like "syslog"

OUTPUT FORMAT (return ONLY the XML, no explanation):
```xml
<decoder name="decoder_name">
  <parent>parent_decoder</parent>
  <prematch>pattern to identify this log type</prematch>
  <regex>pattern with (capture) (groups)</regex>
  <order>field1, field2, field3</order>
</decoder>
```"""

    def _format_logtest_output(self, logtest_data: Dict) -> str:
        """Format logtest API response into readable context for the LLM."""
        lines = []

        output = logtest_data.get("output", logtest_data)
        if isinstance(output, dict):
            # Predecoder info
            predecoder = output.get("predecoder", {})
            if predecoder:
                lines.append("Predecoder output:")
                for key, val in predecoder.items():
                    lines.append(f"  {key}: {val}")

            # Decoder match
            decoder = output.get("decoder", {})
            if decoder:
                lines.append(f"Matched decoder: {decoder.get('name', 'unknown')}")
                if decoder.get("parent"):
                    lines.append(f"Parent decoder: {decoder['parent']}")
            else:
                lines.append("No existing decoder matched this log.")

            # Extracted data
            data = output.get("data", {})
            if data:
                lines.append("Extracted fields:")
                for key, val in data.items():
                    lines.append(f"  {key}: {val}")

            # Rule match
            rule = output.get("rule", {})
            if rule:
                lines.append(f"Matched rule: {rule.get('id', 'N/A')} - {rule.get('description', '')}")
        else:
            lines.append(str(output))

        return "\n".join(lines) if lines else "No logtest data available."

    def _build_retry_prompt(
        self, raw_log: str, decoder_xml: str, errors: List[str]
    ) -> str:
        """Build a retry prompt with failure details for LLM to fix."""
        errors_text = "\n".join(f"- {e}" for e in errors)

        return f"""The Wazuh decoder you generated failed validation. Fix the issues below.

ORIGINAL RAW LOG:
{raw_log}

YOUR PREVIOUS DECODER:
{decoder_xml}

VALIDATION ERRORS:
{errors_text}

FIX INSTRUCTIONS:
1. Carefully check that <prematch> actually matches a substring of the raw log
2. Check that <regex> capture groups match the right parts of the log
3. Ensure <order> field count matches the number of capture groups in <regex>
4. Use correct Wazuh regex syntax: \\S+ \\d+ \\.+ (backslash-escaped)

Return ONLY the corrected XML decoder, no explanation:"""

    async def _call_llm_generate(self, prompt: str) -> str:
        """Call the LLM to generate decoder XML."""
        system_prompt = (
            "You are a Wazuh SIEM decoder specialist. Generate valid Wazuh XML decoders. "
            "Return ONLY the XML decoder block, no explanations or markdown formatting."
        )
        response = await self.llm_client.generate(
            prompt=prompt,
            system_prompt=system_prompt,
            max_tokens=1000,
            temperature=0.2,
        )
        return response

    def _extract_xml_from_response(self, llm_response: str) -> Optional[str]:
        """Extract decoder XML from the LLM response text."""
        if not llm_response:
            return None

        # Try to find XML in code blocks first
        code_block = re.search(r"```(?:xml)?\s*\n?(.*?)```", llm_response, re.DOTALL)
        if code_block:
            xml_text = code_block.group(1).strip()
        else:
            xml_text = llm_response.strip()

        # Find all <decoder>...</decoder> blocks
        decoder_blocks = re.findall(
            r"(<decoder\b[^>]*>.*?</decoder>)", xml_text, re.DOTALL
        )

        if not decoder_blocks:
            # Try the entire text as XML
            if "<decoder" in xml_text and "</decoder>" in xml_text:
                start = xml_text.index("<decoder")
                end = xml_text.rindex("</decoder>") + len("</decoder>")
                return xml_text[start:end].strip()
            return None

        # Return all decoder blocks joined (some decoders need parent + child)
        return "\n\n".join(decoder_blocks)

    def _validate_decoder(self, decoder_xml: str, raw_log: str) -> Dict[str, Any]:
        """
        Python-based decoder validation:
        1. Parse XML structure
        2. Extract and test prematch against raw log
        3. Extract and test regex capture groups
        4. Verify field mapping with <order>
        """
        result = {"valid": False, "errors": [], "extracted_fields": {}}

        # Wrap in root element for multi-decoder parsing
        wrapped = f"<root>{decoder_xml}</root>"

        # Step 1: Parse XML
        try:
            root = ET.fromstring(wrapped)
        except ET.ParseError as e:
            result["errors"].append(f"Invalid XML structure: {e}")
            return result

        decoders = root.findall("decoder")
        if not decoders:
            result["errors"].append("No <decoder> elements found")
            return result

        # Validate each decoder block
        for i, decoder_el in enumerate(decoders):
            name = decoder_el.get("name")
            if not name:
                result["errors"].append(f"Decoder {i+1}: missing 'name' attribute")
                continue

            prematch_el = decoder_el.find("prematch")
            regex_el = decoder_el.find("regex")
            order_el = decoder_el.find("order")

            # At minimum, a child decoder needs regex + order OR prematch
            if prematch_el is None and regex_el is None:
                result["errors"].append(
                    f"Decoder '{name}': needs at least <prematch> or <regex>"
                )
                continue

            # Step 2: Test prematch against raw log
            if prematch_el is not None and prematch_el.text:
                prematch_ok = self._test_wazuh_pattern(prematch_el.text.strip(), raw_log)
                if not prematch_ok:
                    result["errors"].append(
                        f"Decoder '{name}': <prematch> pattern does not match the raw log. "
                        f"Pattern: {prematch_el.text.strip()}"
                    )

            # Step 3: Test regex and extract fields
            if regex_el is not None and regex_el.text:
                regex_pattern = regex_el.text.strip()
                order_text = order_el.text.strip() if (order_el is not None and order_el.text) else ""
                field_names = [f.strip() for f in order_text.split(",") if f.strip()]

                extracted = self._extract_fields_from_log(regex_pattern, raw_log, field_names)

                if extracted.get("error"):
                    result["errors"].append(
                        f"Decoder '{name}': regex extraction failed — {extracted['error']}"
                    )
                elif not extracted.get("fields"):
                    result["errors"].append(
                        f"Decoder '{name}': regex matched but captured no fields"
                    )
                else:
                    # Check group count matches order count
                    captured_count = extracted.get("group_count", 0)
                    if field_names and captured_count != len(field_names):
                        result["errors"].append(
                            f"Decoder '{name}': capture group count ({captured_count}) "
                            f"!= order field count ({len(field_names)})"
                        )
                    else:
                        result["extracted_fields"].update(extracted["fields"])

        # Valid if no errors
        if not result["errors"]:
            result["valid"] = True

        return result

    def _test_wazuh_pattern(self, wazuh_pattern: str, text: str) -> bool:
        """Test a Wazuh prematch/regex pattern against text. Returns True if it matches."""
        try:
            py_pattern = self._wazuh_to_python_regex(wazuh_pattern)
            return bool(re.search(py_pattern, text))
        except re.error as e:
            logger.debug(f"Regex error testing pattern '{wazuh_pattern}': {e}")
            return False

    def _wazuh_to_python_regex(self, wazuh_pattern: str) -> str:
        """
        Convert Wazuh regex syntax to Python regex.

        Wazuh uses its own regex dialect:
          \\S+ -> non-whitespace
          \\.+ -> any chars (like .+ in Python)
          \\d+ -> digits
          \\w+ -> word chars
          \\s+ -> whitespace
          \\t  -> tab
          Parentheses () are capture groups (same as Python)
          ^ anchors to start

        Key difference: Wazuh \\. means "any char" (like Python's .)
        while in standard regex \\. means literal dot.
        """
        result = wazuh_pattern

        # Wazuh \\.+ means .+ (any chars), convert to Python
        result = result.replace("\\.+", ".+")
        result = result.replace("\\.", ".")

        # Wazuh \\S+ -> Python \\S+ (same meaning)
        # Wazuh \\d+ -> Python \\d+ (same meaning)
        # Wazuh \\w+ -> Python \\w+ (same meaning)
        # Wazuh \\s+ -> Python \\s+ (same meaning)
        # These are already compatible.

        # Wazuh \\t -> Python \\t (same)
        # Parentheses and ^ are the same.

        return result

    def _extract_fields_from_log(
        self, wazuh_regex: str, raw_log: str, field_names: List[str]
    ) -> Dict[str, Any]:
        """
        Simulate Wazuh regex field extraction against the raw log.

        Returns:
            Dict with: fields (name->value map), group_count, error (if any)
        """
        try:
            py_regex = self._wazuh_to_python_regex(wazuh_regex)
            match = re.search(py_regex, raw_log)

            if not match:
                return {"fields": {}, "group_count": 0, "error": "Regex did not match the raw log"}

            groups = match.groups()
            group_count = len(groups)

            fields = {}
            for idx, value in enumerate(groups):
                if idx < len(field_names):
                    fields[field_names[idx]] = value
                else:
                    fields[f"group_{idx+1}"] = value

            return {"fields": fields, "group_count": group_count, "error": None}

        except re.error as e:
            return {"fields": {}, "group_count": 0, "error": f"Invalid regex: {e}"}

