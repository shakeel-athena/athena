<p align="center">
  <img src="https://img.shields.io/badge/PALLAS-2.3-00A89D?style=for-the-badge&logoColor=white&labelColor=0B0F14" alt="Pallas 2.3" height="50"/>
</p>

<h3 align="center">Enterprise SOC Intelligence Platform</h3>

<p align="center">
  AI-native security operations powered by Wazuh SIEM, Suricata NIDS, and Cloud LLM.<br/>
  Natural language queries. SOC-grade output. Full incident response workflow.
</p>

<p align="center">
  <img src="https://img.shields.io/badge/Python-3.13-3776AB?style=flat-square&logo=python&logoColor=white" alt="Python"/>
  <img src="https://img.shields.io/badge/MCP-2025--06--18-00A89D?style=flat-square&logo=anthropic&logoColor=white" alt="MCP"/>
  <img src="https://img.shields.io/badge/Wazuh-4.8--4.14-0052CC?style=flat-square&logo=wazuh&logoColor=white" alt="Wazuh"/>
  <img src="https://img.shields.io/badge/Suricata-7.x-E0401D?style=flat-square&logo=suricata&logoColor=white" alt="Suricata"/>
  <img src="https://img.shields.io/badge/LLM-Kimi--K2.5-7C3AED?style=flat-square&logoColor=white" alt="Kimi-K2.5"/>
  <img src="https://img.shields.io/badge/Docker-Ready-2496ED?style=flat-square&logo=docker&logoColor=white" alt="Docker"/>
  <img src="https://img.shields.io/badge/License-Proprietary-red?style=flat-square" alt="License"/>
</p>

<p align="center">
  <img src="https://img.shields.io/badge/Tools-58-00A89D?style=for-the-badge&labelColor=151B23" alt="Tools"/>
  <img src="https://img.shields.io/badge/Strategies-73-4493F8?style=for-the-badge&labelColor=151B23" alt="Strategies"/>
  <img src="https://img.shields.io/badge/Patterns-206+-00C878?style=for-the-badge&labelColor=151B23" alt="Patterns"/>
  <img src="https://img.shields.io/badge/Correlations-45+-E06B20?style=for-the-badge&labelColor=151B23" alt="Correlations"/>
</p>

---

## Table of Contents

- [Overview](#-overview)
- [What's New in v2.3](#-whats-new-in-v23)
- [Architecture](#-architecture)
- [Features](#-features)
- [Attack Narrative Workflow](#-attack-narrative--incident-response-workflow)
- [Prerequisites](#-prerequisites)
- [Quick Start](#-quick-start)
- [Environment Variables](#-environment-variables)
- [Docker Deployment](#-docker-deployment)
- [Authentication](#-authentication)
- [Integrations](#-integrations)
- [Dashboard Plugin](#-dashboard-plugin)
- [Query Orchestration](#-query-orchestration)
- [Example Queries](#-example-queries)
- [Wazuh Compatibility](#-wazuh-compatibility)
- [Documentation](#-documentation)

---

## Overview

Pallas AI unifies **endpoint detection**, **network intrusion detection**, **vulnerability management**, **threat intelligence**, and **incident response** under a single natural language interface.

SOC analysts query in plain English — Pallas selects tools, correlates data across sources, formats results into SOC-grade markdown tables, appends AI-driven security analysis, and enables a complete incident response workflow from alert to closure.

<table>
<tr>
<td width="50%">

### What Makes Pallas Different

- **AI-Native** — Not bolted-on; AI is in the pipeline
- **Cloud LLM** — Kimi-K2.5 via HuggingFace Inference API
- **Unified SIEM + NIDS** — Single pane of glass
- **MCP-Native** — Built on Model Context Protocol
- **Incident Response** — Full SOC workflow (ACK to Close)
- **Jira JSM** — Automated ticket creation, assignment, closure
- **IP Blocking** — AWS WAF + Network Firewall integration
- **Forensic Narratives** — Per-alert, not summaries
- **Decoder Automation** — No competitor offers this

</td>
<td width="50%">

### Platform at a Glance

| | |
|---|---|
| Backend Tools | **58** (41 Wazuh + 19 Suricata) |
| Strategies | **73** across 8 modules |
| Query Patterns | **206+** deterministic routes |
| Correlations | **45+** multi-tool strategies |
| Format Methods | **92+** SOC-grade formatters |
| LLM | **Kimi-K2.5** (Cloud — HuggingFace) |
| Jira | **OAuth 2.0** (SECOPS project) |
| IP Blocking | **AWS WAF + Network Firewall** |

</td>
</tr>
</table>

---

## What's New in v2.3

### SOC Incident Response Workflow
- **9-step workflow** — Alert Detection, AI Narrative, Observable Enrichment, Acknowledge, Create Ticket / False Positive, Assign User, Block WAF, Block FW, Close Incident
- **Workflow enforcement** — Acknowledge disabled until AI Narrative is viewed
- **False positive handling** — Dismiss with preset reasons before ticket creation
- **Conditional paths** — Public IP: full workflow (block + close). Private IP: ticket + assign only

### Integrations
- **Jira Service Management** — OAuth 2.0 client credentials, Security Alert in SECOPS project, auto-close with resolution
- **AWS WAF** — IP blocking via WAFv2 IP Set, two-click confirmation
- **AWS Network Firewall** — Suricata-format deny rules, two-click confirmation
- **AbuseIPDB** — IP reputation enrichment with verdict (malicious/suspicious/clean)

### LLM Migration
- **Ollama replaced with Cloud LLM** — Kimi-K2.5 via HuggingFace Inference API
- **OpenAI-compatible API** — supports any `/v1/chat/completions` provider
- **Organization billing** — `X-HF-Bill-To` header for HuggingFace org billing

### SOC Chat Enhancements
- **Enhanced search** — MITRE tactic/technique/ID, rule ID, rule level search support
- **Real OSD username** — captured from `/_plugins/_security/api/account`, logged on all actions

### Attack Narrative Enhancements
- **Observables at top** — moved from bottom to top of narrative for quick IP investigation
- **Pagination** — 20 alerts per page with Previous/Next navigation
- **User audit trail** — all actions (ACK, ticket, block, close, FP dismiss) logged with real username in OpenSearch + Jira
- **Assign User** — searchable dropdown of SECOPS team members
- **Duplicate ticket prevention** — immediate UI update after ticket creation

### Infrastructure
- **Package-relative imports** — fixed `from wazuh_mcp_server.xxx import` for Docker compatibility
- **Incident Store** — OpenSearch index `pallas-incidents` with full audit trail (`actions_log[]`)

---

## Architecture

```
                          +-------------------+
                          |  SOC Analyst      |
                          | (Natural Language)|
                          +--------+----------+
                                   |
                                   v
+----------------------------------------------------------------------+
|  server.py -- FastAPI MCP Server                                      |
|  Transports: Streamable HTTP | SSE | WebSocket                       |
|  Auth: Bearer Token | OAuth 2.1 | Authless (dev)                     |
+---------------------------+------------------------------------------+
                            |
                            v
+----------------------------------------------------------------------+
|  query_orchestrator.py -- Hybrid Tool Selector                        |
|                                                                       |
|  +------------+  +------------+  +---------+  +-------------+        |
|  | Regex (95%)|->| Keyword    |->| LLM     |->| Safe        |        |
|  | ~70% hits  |  | (75%) ~15% |  | ~10%    |  | Fallback ~5%|        |
|  +------------+  +------------+  +---------+  +-------------+        |
+------+---------------------+------------------------+-----------------+
       |                     |                        |
       v                     v                        v
+--------------+   +-------------------+   +--------------------+
| Wazuh        |   | Wazuh Indexer     |   | Suricata IDS       |
| Manager API  |   | Elasticsearch     |   | Elasticsearch      |
| 41 tools     |   | Alerts & Vulns    |   | 19 tools           |
+--------------+   +-------------------+   +--------------------+
       |                     |                        |
       +---------------------+------------------------+
                             |
                             v
+----------------------------------------------------------------------+
|  correlation_engine.py -- 45+ Strategies                              |
|  Multi-tool merge | Strict filtering | Risk scoring                  |
+----------------------------------------------------------------------+
                             |
                             v
+----------------------------------------------------------------------+
|  response_formatter.py -- 92+ Methods                                 |
|  Markdown tables | Severity coding | Structured sections             |
+----------------------------------------------------------------------+
                             |
                             v
+----------------------------------------------------------------------+
|  llm_client.py -- Cloud LLM (Kimi-K2.5 via HuggingFace)              |
|  SOC Analysis | Forensic Narratives | Decoder Generation             |
+----------------------------------------------------------------------+
                             |
                             v
+----------------------------------------------------------------------+
|  SOC Workflow Integrations                                            |
|  +----------+  +--------+  +--------+  +-------------------+        |
|  | Jira JSM |  | AWS WAF|  | AWS FW |  | Incident Store    |        |
|  | OAuth2.0 |  | WAFv2  |  | NFW    |  | OpenSearch Index  |        |
|  +----------+  +--------+  +--------+  +-------------------+        |
+----------------------------------------------------------------------+
                             |
                             v
+----------------------------------------------------------------------+
|  Pallas Dashboard -- OpenSearch Dashboards Plugin (React)             |
|  8 Modules | 73 Strategies | Enterprise Design System                |
+----------------------------------------------------------------------+
```

---

## Features

### Backend -- 58 Tools

| Domain | Tools | Key Capabilities |
|--------|:-----:|-----------------|
| **Agent Management** | 7 | Listing, health, processes, ports, config, inventory |
| **Alert Management** | 6 | Retrieval, summaries, patterns, timeline, rules |
| **Vulnerability Mgmt** | 3 | CVEs, severity breakdown, agent correlation |
| **Security Analysis** | 13 | Threats, IOC reputation, MITRE, FIM, SCA, compliance |
| **System Monitoring** | 12 | Stats, cluster health, logs, decoders |
| **Suricata IDS** | 19 | Alerts, HTTP/TLS, JA3/JA4, flows, signatures |

### Dashboard -- 8 Modules

| # | Module | Strategies | Description |
|:-:|--------|:---------:|-------------|
| 1 | **SOC Chat** | -- | Natural language queries, caching & pinning |
| 2 | **IOC Investigation** | -- | AbuseIPDB, IP/hash/domain lookups |
| 3 | **Decoder Lab** | -- | AI workflow: Analyze, Generate, Test, Explain |
| 4 | **SIEM Intelligence** | 25 | Agent recon, log analysis, threat hunting |
| 5 | **NIDS Intelligence** | 18 | Alert triage, network recon, JA3/JA4 |
| 6 | **Vulnerabilities** | 12 | Risk assessment, exposure, CVE investigation |
| 7 | **Correlations** | 10 | Cross-platform: SIEM+NIDS, SIEM+Vulns |
| 8 | **Attack Narrative** | -- | Per-alert AI forensic reports + incident response |

### AI Capabilities -- Cloud LLM (Kimi-K2.5)

| Capability | Description |
|------------|-------------|
| **SOC Analysis** | Every response includes Risk Summary, Key Findings, Recommended Actions, Priority |
| **Forensic Narratives** | Per-alert reports with timestamps, IPs, MITRE mapping, response actions |
| **Decoder Generation** | Create Wazuh decoders from raw log samples with PCRE2 validation |
| **Decoder Explanation** | Document any decoder: regex breakdown, deployment steps, recommendations |
| **Intelligent Tool Selection** | LLM fallback when regex/keyword patterns don't match |

---

## Attack Narrative & Incident Response Workflow

Pallas v2.3 includes a complete SOC incident response workflow:

### Public IP Alerts (Full Workflow)
```
Narrative -> ACK -> [Create Ticket / False Positive] -> Assign User -> Block WAF -> Block FW -> Close
```

### Private IP Alerts (Minimal Workflow)
```
Narrative -> ACK -> [Create Ticket / False Positive] -> Assign User -> (closed manually in Jira)
```

### Workflow Steps

| Step | Description | Logged In |
|------|-------------|-----------|
| **1. Alert Detection** | Wazuh (level >= 12) + Suricata (severity 1-2), paginated 20/page | -- |
| **2. AI Narrative** | LLM forensic report. **Required before ACK.** | -- |
| **3. Observable Enrichment** | AbuseIPDB + Wazuh history. Verdict: malicious/suspicious/clean | OpenSearch |
| **4. Acknowledge** | Creates incident. Captures real OSD username. Calculates MTTD | OpenSearch |
| **5a. Create Ticket** | JSM Security Alert in SECOPS (OAuth 2.0) | OpenSearch + Jira |
| **5b. False Positive** | Dismiss with reason. No ticket created. Workflow ends | OpenSearch |
| **6. Assign User** | Searchable dropdown of SECOPS team members | OpenSearch + Jira |
| **7. Block WAF** | Two-click confirm. IP added to AWS WAF IP Set | OpenSearch + Jira |
| **8. Block Firewall** | Two-click confirm. Suricata deny rules on Network Firewall | OpenSearch + Jira |
| **9. Close Incident** | Resolves Jira ticket. MTTR calculated | OpenSearch + Jira |

### Security Controls
- WAF/FW tools **only** callable from Attack Narrative UI -- NOT from SOC Chat or LLM
- False Positive only available **before** ticket creation
- All actions require ACK first -- no skipping steps
- ACK requires viewing AI Narrative -- no blind acknowledgement

### Audit Trail
Every action logged with real username in OpenSearch `pallas-incidents` index:
```json
{
  "actions_log": [
    {"action": "acknowledged", "actor": "rizwan.baloch", "timestamp": "..."},
    {"action": "jira_created", "actor": "rizwan.baloch", "details": "SECOPS-274"},
    {"action": "assigned", "actor": "rizwan.baloch", "details": "Assigned to Mohsin Ahmed"},
    {"action": "waf_block", "actor": "rizwan.baloch", "details": "156.238.251.246 blocked"},
    {"action": "closed", "actor": "rizwan.baloch", "details": "MTTR: 21min"}
  ]
}
```

---

## Prerequisites

| Component | Version | Required |
|-----------|---------|:--------:|
| Python | 3.11+ (3.13 recommended) | Yes |
| Wazuh Manager | 4.8 -- 4.14.x | Yes |
| Wazuh Indexer | 4.x | Yes |
| Suricata | 7.x | Optional |
| Docker | 24+ | Recommended |
| HuggingFace Account | With Inference credits | Yes |
| OpenSearch Dashboards | 2.x | For plugin |
| Jira Cloud (JSM) | With SECOPS project | For incident workflow |
| AWS Account | With WAF + Network Firewall | For IP blocking |

---

## Quick Start

### Step 1 -- Clone & Configure

```bash
git clone <repo-url> Wazuh-MCP-Server
cd Wazuh-MCP-Server
cp .env.example .env
```

Edit `.env` with your configuration (see Environment Variables section below).

### Step 2 -- Deploy

```bash
docker compose up -d
```

### Step 3 -- Verify

```bash
curl http://localhost:3000/ai-analyst/health
```

---

## Environment Variables

### Wazuh Manager (Required)

| Variable | Default | Description |
|----------|---------|-------------|
| `WAZUH_HOST` | *required* | Manager IP/hostname |
| `WAZUH_PORT` | `55000` | API port |
| `WAZUH_USER` | *required* | API username |
| `WAZUH_PASS` | *required* | API password |
| `VERIFY_SSL` | `true` | Verify SSL certificates |

### Wazuh Indexer (Required)

| Variable | Default | Description |
|----------|---------|-------------|
| `WAZUH_INDEXER_HOST` | *required* | Elasticsearch host |
| `WAZUH_INDEXER_PORT` | `9200` | Elasticsearch port |
| `WAZUH_INDEXER_USER` | *required* | Elasticsearch username |
| `WAZUH_INDEXER_PASS` | *required* | Elasticsearch password |

### Suricata (Optional)

| Variable | Default | Description |
|----------|---------|-------------|
| `SURICATA_ENABLED` | `true` | Enable Suricata integration |
| `SURICATA_INDEX_PATTERN` | `suricata-*` | Elasticsearch index pattern |

### LLM -- Cloud API (Required)

| Variable | Default | Description |
|----------|---------|-------------|
| `LLM_BASE_URL` | `https://router.huggingface.co/v1` | LLM API endpoint (OpenAI-compatible) |
| `LLM_MODEL` | `moonshotai/Kimi-K2.5` | Model name |
| `LLM_API_KEY` | *required* | HuggingFace API token |
| `HF_ORG_NAME` | -- | HuggingFace org ID for billing (adds `X-HF-Bill-To` header) |

### Jira Service Management (Required for Incident Workflow)

| Variable | Default | Description |
|----------|---------|-------------|
| `JIRA_CLIENT_ID` | -- | OAuth 2.0 Client ID |
| `JIRA_CLIENT_SECRET` | -- | OAuth 2.0 Client Secret |
| `JIRA_BASE_URL` | -- | Jira Cloud URL (e.g., `https://yoursite.atlassian.net`) |
| `JIRA_PROJECT_KEY` | `SECOPS` | Jira project key |
| `JIRA_ISSUE_TYPE` | `Security Alert` | Issue type for new tickets |

### AWS WAF (Required for IP Blocking -- Layer 7)

| Variable | Default | Description |
|----------|---------|-------------|
| `AWS_REGION` | `us-east-1` | AWS region |
| `WAF_IP_SET_NAME` | *required* | WAF IP Set name |
| `WAF_IP_SET_ID` | *required* | WAF IP Set ID |
| `WAF_SCOPE` | `REGIONAL` | WAF scope |

### AWS Network Firewall (Required for IP Blocking -- Layer 3/4)

| Variable | Default | Description |
|----------|---------|-------------|
| `NETWORK_FW_RULE_GROUP_ARN` | *required* | Stateful rule group ARN |
| `NETWORK_FW_RULE_GROUP_NAME` | *required* | Stateful rule group name |

### AbuseIPDB (Required for IOC Enrichment)

| Variable | Default | Description |
|----------|---------|-------------|
| `ABUSEIPDB_API_KEY` | -- | AbuseIPDB API key |

### Server

| Variable | Default | Description |
|----------|---------|-------------|
| `MCP_HOST` | `0.0.0.0` | Bind address |
| `MCP_PORT` | `3000` | Server port |
| `AUTH_MODE` | `bearer` | Auth mode (`bearer`, `oauth`, `none`) |
| `LOG_LEVEL` | `INFO` | Logging level |
| `ALLOWED_ORIGINS` | `http://localhost` | CORS origins |

### Sample `.env`

```env
# Wazuh Manager
WAZUH_HOST=172.16.52.125
WAZUH_PORT=55000
WAZUH_USER=wazuh
WAZUH_PASS=your_password
VERIFY_SSL=false

# Wazuh Indexer
WAZUH_INDEXER_HOST=indexer.example.com
WAZUH_INDEXER_PORT=9200
WAZUH_INDEXER_USER=admin
WAZUH_INDEXER_PASS=your_password

# Suricata
SURICATA_ENABLED=true
SURICATA_INDEX_PATTERN=suricata-*

# LLM (Kimi-K2.5 via HuggingFace)
LLM_BASE_URL=https://router.huggingface.co/v1
LLM_MODEL=moonshotai/Kimi-K2.5
LLM_API_KEY=hf_your_token_here
HF_ORG_NAME=your_org_id

# AbuseIPDB
ABUSEIPDB_API_KEY=your_key_here

# Jira (OAuth 2.0)
JIRA_CLIENT_ID=your_client_id
JIRA_CLIENT_SECRET=your_client_secret
JIRA_BASE_URL=https://yoursite.atlassian.net
JIRA_PROJECT_KEY=SECOPS
JIRA_ISSUE_TYPE=Security Alert

# AWS WAF
AWS_REGION=us-east-2
WAF_IP_SET_NAME=Blocked
WAF_IP_SET_ID=your-ip-set-id
WAF_SCOPE=REGIONAL

# AWS Network Firewall
NETWORK_FW_RULE_GROUP_ARN=arn:aws:network-firewall:us-east-2:123456:stateful-rulegroup/drop-malicious-ips
NETWORK_FW_RULE_GROUP_NAME=drop-malicious-ips

# Server
MCP_HOST=0.0.0.0
MCP_PORT=3000
AUTH_MODE=bearer
LOG_LEVEL=INFO
```

---

## Docker Deployment

Production `compose.yml` features:

| Feature | Detail |
|---------|--------|
| **Build** | Multi-stage, Python 3.13, production target |
| **Resources** | 1 CPU / 512MB RAM (128MB reserved) |
| **Security** | `no-new-privileges`, `cap_drop: ALL`, read-only FS |
| **Health** | 15s interval, `/ai-analyst/health`, 45s start period |
| **Logging** | JSON driver, 10MB max, 3 rotated files |
| **Network** | Host mode for Wazuh/Elasticsearch access |

```bash
# Start production
docker compose up -d

# View logs
docker compose logs -f wazuh-mcp-remote-server

# Rebuild after code changes
docker compose build --no-cache && docker compose up -d

# Health check
curl http://localhost:3000/ai-analyst/health
```

### IAM Permissions (for WAF/FW)

The EC2 instance role needs:

```json
{
  "Effect": "Allow",
  "Action": [
    "wafv2:GetIPSet",
    "wafv2:UpdateIPSet",
    "network-firewall:DescribeRuleGroup",
    "network-firewall:UpdateRuleGroup"
  ],
  "Resource": ["<your WAF IP Set ARN>", "<your Network Firewall Rule Group ARN>"]
}
```

---

## Authentication

| Mode | Use Case | Config |
|------|----------|--------|
| **Bearer** | Standard deployments | `AUTH_MODE=bearer` |
| **OAuth 2.1** | Enterprise (PKCE + DCR) | `AUTH_MODE=oauth` |
| **Authless** | Development only | `AUTH_MODE=none` |

---

## Integrations

| Integration | Protocol | Auth | Purpose |
|-------------|----------|------|---------|
| **Wazuh Manager** | REST API | Bearer (10-min refresh) | 41 SIEM tools |
| **Wazuh Indexer** | Elasticsearch | HTTPS + SSL | Alerts, vulnerabilities, search |
| **Suricata IDS** | Elasticsearch | HTTPS + SSL | 19 NIDS tools |
| **Kimi-K2.5 (HuggingFace)** | OpenAI-compatible API | Bearer + org billing | SOC analysis, narratives, decoders |
| **Jira Cloud (JSM)** | REST API v2 | OAuth 2.0 client credentials | Ticket creation, assignment, closure |
| **AWS WAF** | WAFv2 API | IAM Instance Role | Layer 7 IP blocking |
| **AWS Network Firewall** | NFW API | IAM Instance Role | Layer 3/4 IP blocking |
| **AbuseIPDB** | REST API v2 | API key | IP reputation enrichment |
| **OpenSearch** | Elasticsearch | HTTPS | Incident store (`pallas-incidents`) |

---

## Dashboard Plugin

The Pallas Dashboard is an **OpenSearch Dashboards plugin** (React, TypeScript, inline styles).

### Plugin Configuration

| Property | Value |
|----------|-------|
| Plugin ID | `aiAnalystPluginTest` |
| App ID | `aiAnalystAppTest` |
| Display Name | `Pallas 2.3` |
| Route | `/app/aiAnalystAppTest` |

### Build & Deploy

```bash
# Inside OSD monorepo plugins/ directory
cd plugins/aiAnalystPluginTest/
yarn plugin-helpers build
# Output: aiAnalystPluginTest-1.0.0.zip
```

### Design System

| Token | Detail |
|-------|--------|
| **Brand** | Teal `#00A89D` / `#00D4C8` |
| **Dark Mode** | 5-level dark backgrounds |
| **Typography** | Inter + JetBrains Mono, 12 sizes |
| **Accessibility** | WCAG AA+, ARIA, keyboard nav |

---

## Query Orchestration

Pallas uses a **4-strategy hybrid selection pipeline** -- deterministic first, AI only when needed:

| Strategy | Confidence | Coverage | Description |
|----------|:----------:|:--------:|-------------|
| **1. Regex** | 95% | ~70% of queries | 206+ patterns, fastest |
| **2. Keyword** | 70-80% | ~15% of queries | Registered keywords |
| **3. LLM** | Variable | ~10% of queries | Cloud LLM (Kimi-K2.5) for complex queries |
| **4. Safe Fallback** | 100% | ~5% of queries | Default agent listing, never empty |

---

## Example Queries

### Agent Operations
```
"show active agents"
"show disconnected agents"
"check health of agent 019"
"show processes for agent 019"
```

### Alerts & Threats
```
"show recent alerts"
"search brute force attacks"
"search rule 80255"
"search T1110"
"search credential access"
```

### Vulnerabilities
```
"show critical vulnerabilities"
"show vulnerabilities for agent 019"
"which agents have the most CVEs?"
```

### Suricata / Network
```
"show suricata alerts"
"show top attack signatures"
"show HTTP traffic analysis"
```

### Cross-Platform Correlation
```
"show active agents with critical vulnerabilities"
"correlate SIEM alerts with NIDS detections"
"full stack investigation for agent 019"
```

---

## Wazuh Compatibility

| Wazuh Version | Status |
|:-------------:|:------:|
| 4.14.x | Fully supported |
| 4.12.x -- 4.13.x | Supported |
| 4.8.x -- 4.11.x | Supported (minor API diffs) |
| < 4.8 | Not supported |

---

## Documentation

| Document | Description |
|----------|-------------|
| [Architecture](docs/architecture.md) | System design & component interactions |
| [Filtering Rules](docs/filtering-rules.md) | Strict status filtering, zero cross-leakage |
| [Response Format Spec](docs/response-format-spec.md) | Output formatting requirements |
| [SOC Analysis Spec](docs/soc-analysis-spec.md) | Mandatory AI analysis spec |
| [Tool Response Schemas](docs/tool-response-schemas.md) | Required fields per query type |
| [Fallback Handling](docs/fallback-handling.md) | Graceful degradation behavior |
| [MCP Compliance](MCP_COMPLIANCE_VERIFICATION.md) | MCP 2025-06-18 audit |
| [Production Readiness](PRODUCTION_READINESS.md) | Production deployment checklist |
| [Wazuh Compatibility](WAZUH_COMPATIBILITY.md) | Version support matrix |

---

<p align="center">
  <sub>Pallas AI v2.3 -- Athena Security Group. All rights reserved.</sub>
</p>
