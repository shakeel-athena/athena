"""
Response Formatter - Context-Aware SOC Reporting
Implements all 8 SOC requirements
"""

import json
import logging
from typing import List, Dict, Any, Optional
from datetime import datetime

logger = logging.getLogger(__name__)


class ResponseFormatter:
    """
    SOC-grade response formatter with context awareness.

    Key Features:
    ✅ Excludes manager (ID 000) from all agent counts
    ✅ Shows only relevant sections based on query type
    ✅ Proper tabular formatting
    ✅ Actionable recommendations
    """

    def _exclude_manager(self, agents: List[Dict]) -> List[Dict]:
        """Remove Wazuh manager (ID 000) from agent lists"""
        if not isinstance(agents, list):
            return []
        return [a for a in agents if a.get('id') != '000']

    def _extract_data(self, correlated_data: Any) -> List[Dict]:
        """
        Extract data from various possible structures.
        Handles both direct lists and nested Wazuh API responses.
        """
        if isinstance(correlated_data, list):
            return correlated_data

        if isinstance(correlated_data, dict):
            # Try various nested structures
            if 'data' in correlated_data:
                data = correlated_data['data']
                if isinstance(data, dict) and 'affected_items' in data:
                    return data['affected_items']
                elif isinstance(data, list):
                    return data

            if 'affected_items' in correlated_data:
                return correlated_data['affected_items']

            if 'items' in correlated_data:
                return correlated_data['items']

        return []

    # ================================================================
    # AGENT FORMATTERS
    # ================================================================

    def format_agent_status_response(self, correlated_data, summary, status_filter=None, **kwargs):
        """
        Main agent formatter - routes based on status_filter
        ✅ Requirement 1: Exclude manager
        ✅ Requirement 2: Remove irrelevant sections
        """
        logger.error(f"🔍 AGENT FORMATTER: Received data type: {type(correlated_data)}")
        logger.error(f"🔍 AGENT FORMATTER: Data keys: {correlated_data.keys() if isinstance(correlated_data, dict) else 'not a dict'}")
        agents = self._extract_data(correlated_data)
        logger.error(f"🔍 AGENT FORMATTER: Extracted {len(agents)} agents")
        agents = self._exclude_manager(agents)
        logger.error(f"🔍 AGENT FORMATTER: After excluding manager: {len(agents)} agents")

        if status_filter == 'active':
            return self._format_active_agents_table(agents)
        else:
            return self._format_agent_status_table(agents)

    def _format_active_agents_table(self, agents: List[Dict]) -> str:
        """✅ Requirement 3: Show proper agent table"""
        active_agents = [a for a in agents if a.get('status') == 'active']

        if not active_agents:
            return "✅ No active agents found (excluding manager)"

        lines = [
            f"## 📊 Active Agents: {len(active_agents)}",
            "",
            "| Agent ID | Name | IP Address | OS | OS Version | Agent Version |",
            "|----------|------|------------|----|-----------:|---------------|"
        ]

        for agent in active_agents:
            agent_id = agent.get('id', 'N/A')
            name = agent.get('name', 'N/A')
            ip = agent.get('ip', 'N/A')
            os_info = agent.get('os', {})
            os_name = os_info.get('name', 'N/A')
            os_version = os_info.get('version', 'N/A')
            agent_version = agent.get('version', 'N/A').replace('Wazuh v', '')

            lines.append(
                f"| {agent_id} | {name} | {ip} | {os_name} | {os_version} | {agent_version} |"
            )

        lines.append("")
        lines.append(f"*Last updated: {datetime.utcnow().strftime('%Y-%m-%d %H:%M UTC')}*")

        return "\n".join(lines)

    def _format_agent_status_table(self, agents: List[Dict]) -> str:
        """✅ Requirement 5: Format agent status as clean table"""
        status_counts = {
            'active': 0,
            'disconnected': 0,
            'never_connected': 0,
            'pending': 0
        }

        for agent in agents:
            status = agent.get('status', 'unknown')
            if status in status_counts:
                status_counts[status] += 1

        total = sum(status_counts.values())

        if total == 0:
            return "✅ No agents found (excluding manager)"

        lines = [
            "## 📊 Agent Status Summary",
            "",
            f"**Total Agents:** {total} (excluding manager)",
            "",
            "| Status | Count | Percentage |",
            "|--------|------:|-----------:|"
        ]

        for status, count in status_counts.items():
            if count > 0:
                pct = (count / total * 100) if total > 0 else 0
                icon = "🟢" if status == "active" else "🔴" if status == "disconnected" else "🟡"
                lines.append(f"| {icon} {status.title()} | {count} | {pct:.1f}% |")

        # Add action items only if needed
        if status_counts['disconnected'] > 0:
            lines.append("")
            lines.append("### ⚠️ Action Required")
            lines.append(f"- **{status_counts['disconnected']} disconnected agents**")
            lines.append("- Check: Network connectivity, firewall rules, agent service status")

        return "\n".join(lines)

    # ================================================================
    # VULNERABILITY FORMATTERS
    # ================================================================

    def format_vulnerability_response(self, correlated_data, summary, **kwargs):
        """Route based ONLY on tool name - never auto-filter by severity"""
        vulns = self._extract_data(correlated_data)
        logger.info(f"🔍 VULN FORMATTER: Received {len(vulns)} vulnerabilities")
        if not vulns:
            return "✅ No vulnerabilities found"
        tool_name = summary.get("tool", "").lower()
        if tool_name == "get_wazuh_critical_vulnerabilities":
            logger.info(f"🔴 CRITICAL tool → using critical formatter")
            return self._format_critical_vulnerabilities(vulns)
        elif tool_name == "get_wazuh_vulnerability_summary":
            logger.info(f"📊 SUMMARY tool → using summary formatter")
            return self._format_vulnerability_summary(vulns)
        else:
            logger.info(f"📋 ALL VULNS tool → using all vulnerabilities formatter")
            return self._format_all_vulnerabilities(vulns)

    def _format_critical_vulnerabilities(self, vulns: List[Dict]) -> str:
        """
        Show critical vulnerabilities with full details
        ✅ Show total count
        ✅ Top 10 with complete information
        ✅ Clear explanation for each
        ✅ Link to dashboard
        """
        if not vulns:
            return "✅ No critical vulnerabilities found"

        total = len(vulns)
        top_10 = vulns[:10]

        lines = [
            f"## 🔴 Critical Vulnerabilities",
            "",
            f"**Total Found:** {total} critical vulnerabilities",
            "",
            f"### 📋 Top {len(top_10)} Critical CVEs (Detailed)",
            ""
        ]

        for i, vuln in enumerate(top_10, 1):
            cve_id = vuln.get('id') or vuln.get('cve_id') or 'N/A'
            severity = vuln.get('severity', 'Critical')
            description = vuln.get('description', 'No description available')

            # Truncate description
            if len(description) > 250:
                description = description[:247] + "..."

            # Extract CVSS score
            cvss_score = vuln.get('cvss_score', 'N/A')
            if cvss_score == 'N/A' and 'cvss' in vuln:
                cvss_data = vuln.get('cvss', {})
                # Correlated schema may provide cvss as dict or already a numeric score
                if isinstance(cvss_data, (int, float, str)):
                    cvss_score = cvss_data
                if isinstance(cvss_data, dict):
                    if 'cvss3' in cvss_data:
                        cvss_score = cvss_data['cvss3'].get('base_score', 'N/A')
                    elif 'cvss2' in cvss_data:
                        cvss_score = cvss_data['cvss2'].get('base_score', 'N/A')

            # Get detection date
            detected = vuln.get('detected_at', 'Unknown')
            if detected and detected != 'Unknown':
                try:
                    detected = detected[:10]  # YYYY-MM-DD
                except:
                    pass

            # Get references
            references = vuln.get('reference', '')
            ref_links = []
            if references:
                refs = [r.strip() for r in str(references).split(',')]
                ref_links = [r for r in refs if r.startswith('http')][:2]

            lines.append(f"### {i}. {cve_id}")
            lines.append(f"**Severity:** 🔴 {severity} | **CVSS:** {cvss_score} | **Detected:** {detected}")
            agent = vuln.get('agent', {}) if isinstance(vuln.get('agent', {}), dict) else {}
            if agent:
                a_id = agent.get('id', 'N/A')
                a_name = agent.get('name', 'N/A')
                a_ip = agent.get('ip', 'N/A')
                a_os = agent.get('os') or agent.get('os_name') or 'N/A'
                lines.append(f"**Affected Agent:** {a_id} | {a_name} | {a_ip} | {a_os}")
            lines.append("")
            lines.append(f"**Description:**  ")
            lines.append(f"{description}")
            lines.append("")

            if ref_links:
                lines.append(f"**References:**")
                for ref in ref_links:
                    lines.append(f"- {ref}")
                lines.append("")

            # Remediation guidance
            lines.append(f"**Immediate Action:**")
            lines.append(f"```bash")
            lines.append(f"# Update vulnerable packages")
            lines.append(f"sudo yum update -y  # RHEL/CentOS")
            lines.append(f"sudo apt-get update && sudo apt-get upgrade -y  # Ubuntu/Debian")
            lines.append(f"```")
            lines.append("")
            lines.append("---")
            lines.append("")

        if total > 10:
            lines.append(f"*...and {total - 10} more critical vulnerabilities*")
            lines.append("")

        # Dashboard link
        lines.append("### 📊 View Complete Details in Wazuh Dashboard")
        lines.append("")
        lines.append("🔗 **Navigate to:** Wazuh → Vulnerabilities → Filter by 'Critical'")
        lines.append("")

        # Summary
        lines.append("### 📈 Action Summary")
        lines.append("")
        lines.append(f"- **Total Critical CVEs:** {total}")
        lines.append(f"- **Timeline:** Remediate within 24-48 hours")
        lines.append(f"- **Priority:** Patch internet-facing systems first")

        return "\n".join(lines)

    def _format_all_vulnerabilities(self, vulns: List[Dict]) -> str:
        """Format all vulnerabilities with summary"""
        if not vulns:
            return "✅ No vulnerabilities found"

        by_severity = {}
        for v in vulns:
            sev = v.get('severity', 'Unknown')
            by_severity[sev] = by_severity.get(sev, 0) + 1

        lines = [
            f"## 🔒 Vulnerabilities: {len(vulns)}",
            "",
            "### By Severity",
            ""
        ]

        for sev in ['Critical', 'High', 'Medium', 'Low']:
            count = by_severity.get(sev, 0)
            if count > 0:
                icon = {"Critical": "🔴", "High": "🟠", "Medium": "🟡", "Low": "🟢"}.get(sev, "⚪")
                lines.append(f"- {icon} **{sev}**: {count}")

        return "\n".join(lines)



    # ================================================================
    # AGENT DETAIL FORMATTERS (Ports / Processes / Config / Health)
    # ================================================================

    def format_agent_ports_response(self, correlated_data, summary, agent_id: Optional[str] = None, **kwargs) -> str:
        ports = self._extract_data(correlated_data)
        title_id = f" for Agent {agent_id}" if agent_id else ""
        if not ports:
            return f"✅ No port data found{title_id}"

        # Common keys seen in collectors: port/protocol/state/process or local_port/proto/status/program
        lines = [
            f"## 🔌 Open Ports{title_id}: {len(ports)}",
            "",
            "| Port | Proto | State | Process |",
            "|-----:|:------|:------|:--------|",
        ]
        for p in ports[:200]:
            port = p.get("port") or p.get("local_port") or p.get("listen_port") or p.get("dst_port") or "N/A"
            proto = (p.get("protocol") or p.get("proto") or p.get("transport") or "N/A")
            state = p.get("state") or p.get("status") or p.get("listen") or "N/A"
            proc = p.get("process") or p.get("program") or p.get("name") or p.get("cmd") or "N/A"
            lines.append(f"| {port} | {proto} | {state} | {str(proc)[:60]} |")

        if len(ports) > 200:
            lines += ["", f"*Showing first 200 ports. Total: {len(ports)}*"]

        return "\n".join(lines)

    def format_agent_processes_response(self, correlated_data, summary, agent_id: Optional[str] = None, **kwargs) -> str:
        procs = self._extract_data(correlated_data)
        title_id = f" for Agent {agent_id}" if agent_id else ""
        if not procs:
            return f"✅ No process data found{title_id}"

        lines = [
            f"## 🧩 Running Processes{title_id}: {len(procs)}",
            "",
            "| PID | Name | User | CPU | Mem | Command |",
            "|----:|:-----|:-----|----:|----:|:--------|",
        ]
        for p in procs[:200]:
            pid = p.get("pid") or p.get("process_id") or "N/A"
            name = p.get("name") or p.get("process") or p.get("comm") or "N/A"
            user = p.get("user") or p.get("username") or p.get("uid") or "N/A"
            cpu = p.get("cpu") or p.get("cpu_pct") or p.get("cpu_percent") or "N/A"
            mem = p.get("mem") or p.get("mem_pct") or p.get("memory_percent") or "N/A"
            cmd = p.get("cmdline") or p.get("command") or p.get("cmd") or ""
            lines.append(f"| {pid} | {str(name)[:30]} | {str(user)[:20]} | {cpu} | {mem} | {str(cmd)[:60]} |")

        if len(procs) > 200:
            lines += ["", f"*Showing first 200 processes. Total: {len(procs)}*"]

        return "\n".join(lines)

    def format_agent_configuration_response(self, correlated_data, summary, agent_id: Optional[str] = None, **kwargs) -> str:
        title_id = f" for Agent {agent_id}" if agent_id else ""
        # Configuration could be dict, list, or raw content
        data = correlated_data
        try:
            payload = json.dumps(data, indent=2, default=str)
        except Exception:
            payload = str(data)

        if not payload or payload == "null":
            return f"✅ No configuration data found{title_id}"

        payload = payload[:3000]
        return f"## ⚙️ Agent Configuration{title_id}\n\n```json\n{payload}\n```"

    def format_agent_health_response(self, correlated_data, summary, agent_id: Optional[str] = None, **kwargs) -> str:
        # Health usually is dict-like (status, last_keep_alive, etc.)
        title_id = f" for Agent {agent_id}" if agent_id else ""
        data = correlated_data
        if isinstance(data, list) and data:
            data = data[0]
        if not isinstance(data, dict):
            return f"## 🩺 Agent Health{title_id}\n\n```json\n{json.dumps(correlated_data, indent=2, default=str)[:1500]}\n```"

        status = data.get("status") or data.get("agent_status") or "Unknown"
        last = data.get("last_keep_alive") or data.get("lastKeepAlive") or data.get("last_seen") or "Unknown"
        version = data.get("version") or data.get("agent_version") or "N/A"
        ip = data.get("ip") or data.get("agent_ip") or "N/A"
        name = data.get("name") or data.get("agent_name") or "N/A"

        lines = [
            f"## 🩺 Agent Health{title_id}",
            "",
            f"- **Name:** {name}",
            f"- **IP:** {ip}",
            f"- **Version:** {version}",
            f"- **Status:** {status}",
            f"- **Last Keep Alive:** {last}",
        ]
        return "\n".join(lines)

# ================================================================
    # ALERT FORMATTERS
    # ================================================================

    def format_alert_response(self, correlated_data, summary, **kwargs):
        """✅ Requirement 8: Show latest 20 alerts with analysis"""
        alerts = self._extract_data(correlated_data)

        if not alerts:
            return "✅ No alerts in the specified time range"

        total = len(alerts)
        recent = alerts[:20]

        # Analyze
        severity_counts = {'critical': 0, 'high': 0, 'medium': 0, 'low': 0}
        rule_counts = {}

        for alert in alerts:
            level = alert.get('rule', {}).get('level', 0)
            if level >= 12:
                severity_counts['critical'] += 1
            elif level >= 7:
                severity_counts['high'] += 1
            elif level >= 4:
                severity_counts['medium'] += 1
            else:
                severity_counts['low'] += 1

            rule_id = alert.get('rule', {}).get('id', 'unknown')
            rule_counts[rule_id] = rule_counts.get(rule_id, 0) + 1

        lines = [
            f"## 🚨 Recent Alerts: {total}",
            "",
            "### Severity Breakdown",
            "",
            f"- 🔴 Critical (L12+): {severity_counts['critical']}",
            f"- 🟠 High (L7-11): {severity_counts['high']}",
            f"- 🟡 Medium (L4-6): {severity_counts['medium']}",
            f"- 🟢 Low (L1-3): {severity_counts['low']}",
            "",
            f"### Latest {len(recent)} Alerts",
            "",
            "| Time | Rule | Level | Agent | Description |",
            "|------|------|------:|-------|-------------|"
        ]

        for alert in recent:
            timestamp = alert.get('timestamp', 'N/A')[:16]
            rule_id = alert.get('rule', {}).get('id', 'N/A')
            level = alert.get('rule', {}).get('level', 'N/A')
            agent = alert.get('agent', {}).get('name', 'N/A')
            desc = alert.get('rule', {}).get('description', 'N/A')[:45]

            level_num = int(level) if str(level).isdigit() else 0
            icon = "🔴" if level_num >= 12 else "🟠" if level_num >= 7 else "🟡" if level_num >= 4 else "🟢"

            lines.append(f"| {timestamp} | {rule_id} | {icon} {level} | {agent} | {desc} |")

        # Pattern analysis
        lines.append("")
        lines.append("### 🔍 Analysis")
        lines.append("")

        top_rules = sorted(rule_counts.items(), key=lambda x: x[1], reverse=True)[:3]
        lines.append("**Most Frequent Rules:**")
        for rule_id, count in top_rules:
            pct = (count / total * 100)
            lines.append(f"- Rule {rule_id}: {count} times ({pct:.1f}%)")

        if severity_counts['critical'] > 0:
            lines.append("")
            lines.append(f"⚠️ **{severity_counts['critical']} critical alerts** require immediate investigation")

        return "\n".join(lines)

    # ================================================================
    # FALLBACK METHODS
    # ================================================================

    def format_general_response(self, data, title="Results", **kwargs):
        """Generic formatter for unknown types"""
        return f"## {title}\n\n```json\n{json.dumps(data, indent=2, default=str)[:1000]}\n```"

    def format_statistics_response(self, correlated_data, summary, **kwargs):
        """Format statistics"""
        return f"```json\n{json.dumps(correlated_data, indent=2, default=str)[:1000]}\n```"

    def format_analysis_response(self, correlated_data, summary, **kwargs):
        """Format analysis"""
        return self.format_general_response(correlated_data, "Analysis")
