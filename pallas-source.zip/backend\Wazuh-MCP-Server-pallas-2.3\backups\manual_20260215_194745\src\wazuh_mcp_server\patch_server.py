#!/usr/bin/env python3
"""
FINAL WORKING Patcher for Wazuh MCP Server LLaMA Fix
Version 3.0 - With proper escaping and complete syntax verification
"""

import re
import sys
import ast
from pathlib import Path

def create_safe_get_param_function():
    """Return the safe_get_param helper function code."""
    return '''
# ============================================================
# HELPER FUNCTION: Safe Parameter Extraction (ADDED FOR LLAMA FIX)
# ============================================================
def safe_get_param(arguments: dict, key: str, default=None, param_type=None):
    """
    Safely extract and normalize parameter from arguments dict with type conversion.
    
    Args:
        arguments: Arguments dictionary from tool call
        key: Parameter key to extract
        default: Default value if parameter is missing or null-like
        param_type: Optional type to convert to (int, str, bool, float)
    
    Returns:
        Normalized and type-converted parameter value or default
    """
    value = arguments.get(key, default)
    
    # Normalize null-like values to default
    if value in (None, "", "null", "None", "undefined"):
        return default
    
    # Type conversion if requested
    if param_type is not None:
        try:
            if param_type == bool:
                if isinstance(value, str):
                    return value.lower() in ('true', '1', 'yes', 'on')
                return bool(value)
            elif param_type == int:
                return int(value)
            elif param_type == float:
                return float(value)
            elif param_type == str:
                return str(value)
            else:
                return param_type(value)
        except (ValueError, TypeError) as e:
            logger.warning(f"Type conversion failed for {key}={value} to {param_type}: {e}")
            return default
    
    return value

'''

def patch_server_file(input_file: str, output_file: str):
    """Patch the server.py file with all fixes."""
    
    print(f"📖 Reading {input_file}...")
    with open(input_file, 'r', encoding='utf-8') as f:
        lines = f.readlines()
    
    content = ''.join(lines)
    
    # Step 1: Add safe_get_param function after verify_authentication
    print("🔧 Step 1: Adding safe_get_param helper function...")
    
    auth_end = 'headers={"WWW-Authenticate": "Bearer"}\n        )\n'
    if auth_end in content:
        parts = content.split(auth_end, 1)
        if len(parts) == 2:
            content = parts[0] + auth_end + create_safe_get_param_function() + parts[1]
            print("   ✅ safe_get_param function added")
        else:
            print("   ⚠️  Could not split content")
    else:
        print("   ⚠️  Could not find insertion point")
    
    # Step 2: Replace get_wazuh_agents handler completely
    print("🔧 Step 2: Fixing get_wazuh_agents handler...")
    
    # Find the start of get_wazuh_agents
    start_marker = '        elif tool_name == "get_wazuh_agents":'
    end_marker = '        elif tool_name == "get_wazuh_running_agents":'
    
    start_idx = content.find(start_marker)
    end_idx = content.find(end_marker)
    
    if start_idx != -1 and end_idx != -1:
        # New handler with CORRECT escaping
        new_handler = '''        elif tool_name == "get_wazuh_agents":
            # Type-safe parameter extraction (FIXED FOR LLAMA)
            agent_id = safe_get_param(arguments, "agent_id", None, str)
            status = safe_get_param(arguments, "status", None, str)
            limit = safe_get_param(arguments, "limit", 100, int)
            
            # Validate status parameter if provided
            if status is not None:
                valid_statuses = ["active", "disconnected", "never_connected"]
                if status not in valid_statuses:
                    logger.warning(f"Invalid status '{status}' provided. Valid values: {valid_statuses}. Ignoring.")
                    status = None
            
            # Build kwargs - only include valid, non-None parameters
            kwargs = {"limit": limit}
            if status is not None:
                kwargs["status"] = status
            
            # Call Wazuh client
            result = await wazuh_client.get_agents(agent_id=agent_id, **kwargs)
            return {"content": [{"type": "text", "text": f"Wazuh Agents:\\n{json.dumps(result, indent=2)}"}]}

'''
        content = content[:start_idx] + new_handler + content[end_idx:]
        print("   ✅ get_wazuh_agents handler replaced")
    else:
        print("   ⚠️  Could not find handler boundaries")
    
    # Step 3: Fix check_agent_health (add required validation)
    print("🔧 Step 3: Fixing check_agent_health...")
    
    old_check = '''        elif tool_name == "check_agent_health":
            agent_id = arguments.get("agent_id")
            result = await wazuh_client.check_agent_health(agent_id)'''
    
    new_check = '''        elif tool_name == "check_agent_health":
            agent_id = safe_get_param(arguments, "agent_id", None, str)
            if not agent_id:
                raise ValueError("agent_id parameter is required for check_agent_health")
            result = await wazuh_client.check_agent_health(agent_id)'''
    
    if old_check in content:
        content = content.replace(old_check, new_check)
        print("   ✅ check_agent_health fixed")
    else:
        print("   ⚠️  check_agent_health not found")
    
    # Step 4: Fix get_agent_processes
    print("🔧 Step 4: Fixing get_agent_processes...")
    
    old_proc = '''        elif tool_name == "get_agent_processes":
            agent_id = arguments.get("agent_id")
            limit = arguments.get("limit", 100)
            result = await wazuh_client.get_agent_processes(agent_id, limit)'''
    
    new_proc = '''        elif tool_name == "get_agent_processes":
            agent_id = safe_get_param(arguments, "agent_id", None, str)
            if not agent_id:
                raise ValueError("agent_id parameter is required for get_agent_processes")
            limit = safe_get_param(arguments, "limit", 100, int)
            result = await wazuh_client.get_agent_processes(agent_id, limit)'''
    
    if old_proc in content:
        content = content.replace(old_proc, new_proc)
        print("   ✅ get_agent_processes fixed")
    else:
        print("   ⚠️  get_agent_processes not found")
    
    # Step 5: Fix get_agent_ports
    print("🔧 Step 5: Fixing get_agent_ports...")
    
    old_ports = '''        elif tool_name == "get_agent_ports":
            agent_id = arguments.get("agent_id")
            limit = arguments.get("limit", 100)
            result = await wazuh_client.get_agent_ports(agent_id, limit)'''
    
    new_ports = '''        elif tool_name == "get_agent_ports":
            agent_id = safe_get_param(arguments, "agent_id", None, str)
            if not agent_id:
                raise ValueError("agent_id parameter is required for get_agent_ports")
            limit = safe_get_param(arguments, "limit", 100, int)
            result = await wazuh_client.get_agent_ports(agent_id, limit)'''
    
    if old_ports in content:
        content = content.replace(old_ports, new_ports)
        print("   ✅ get_agent_ports fixed")
    else:
        print("   ⚠️  get_agent_ports not found")
    
    # Step 6: Fix get_agent_configuration
    print("🔧 Step 6: Fixing get_agent_configuration...")
    
    old_config = '''        elif tool_name == "get_agent_configuration":
            agent_id = arguments.get("agent_id")
            result = await wazuh_client.get_agent_configuration(agent_id)'''
    
    new_config = '''        elif tool_name == "get_agent_configuration":
            agent_id = safe_get_param(arguments, "agent_id", None, str)
            if not agent_id:
                raise ValueError("agent_id parameter is required for get_agent_configuration")
            result = await wazuh_client.get_agent_configuration(agent_id)'''
    
    if old_config in content:
        content = content.replace(old_config, new_config)
        print("   ✅ get_agent_configuration fixed")
    else:
        print("   ⚠️  get_agent_configuration not found")
    
    # Step 7: Add debug mode at START of handle_tools_call
    print("🔧 Step 7: Adding debug mode...")
    
    # Find the validate_input line and add debug code after it
    validate_line = '    validate_input(tool_name, max_length=100)\n'
    
    if validate_line in content:
        debug_code = '''    validate_input(tool_name, max_length=100)

    # Debug logging (enable with DEBUG_TOOL_CALLS=true)
    DEBUG_MODE = os.getenv("DEBUG_TOOL_CALLS", "false").lower() == "true"
    if DEBUG_MODE:
        logger.info(f"🔧 Tool call: {tool_name}")
        logger.info(f"📥 Arguments: {json.dumps(arguments, indent=2)}")
'''
        content = content.replace(validate_line, debug_code)
        print("   ✅ Debug mode added")
    else:
        print("   ⚠️  Could not add debug mode")
    
    # Step 8: Write the patched file
    print(f"\n💾 Writing patched file to {output_file}...")
    with open(output_file, 'w', encoding='utf-8') as f:
        f.write(content)
    
    # Step 9: Verify syntax
    print("🔍 Verifying Python syntax...")
    try:
        ast.parse(content)
        print("   ✅ Syntax verification PASSED!")
        print("\n🎉 SUCCESS! All fixes applied correctly.")
        return True
    except SyntaxError as e:
        print(f"   ❌ Syntax error at line {e.lineno}: {e.msg}")
        if e.text:
            print(f"      {e.text}")
        print("\n⚠️  Syntax error found. The patch was NOT successful.")
        return False

if __name__ == "__main__":
    if len(sys.argv) != 3:
        print("Usage: python patch_server_final.py <input> <output>")
        print("\nExample:")
        print("  python patch_server_final.py server.py.backup server_FIXED.py")
        sys.exit(1)
    
    input_file = sys.argv[1]
    output_file = sys.argv[2]
    
    if not Path(input_file).exists():
        print(f"❌ Error: '{input_file}' not found!")
        sys.exit(1)
    
    try:
        success = patch_server_file(input_file, output_file)
        
        if success:
            print(f"\n📂 Files:")
            print(f"   Input:  {input_file}")
            print(f"   Output: {output_file}")
            print(f"\n🚀 Next steps:")
            print(f"   1. Backup: cp server.py server.py.old")
            print(f"   2. Apply:  cp {output_file} server.py")
            print(f"   3. Restart: sudo systemctl restart wazuh-mcp-server")
            sys.exit(0)
        else:
            sys.exit(1)
            
    except Exception as e:
        print(f"\n❌ Unexpected error: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)

