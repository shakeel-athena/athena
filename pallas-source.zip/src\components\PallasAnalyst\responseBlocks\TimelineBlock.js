/**
 * TimelineBlock — Vertical timeline for alert/event sequences
 *
 * Replaces flat alert tables that have a chronological ordering with a
 * proper timeline visualization. Each event is a card with:
 *   - A severity-colored dot on the timeline rail
 *   - Relative timestamp ("5m ago")
 *   - Title + secondary detail
 *   - Severity badge (when present)
 *
 * Triggered when BlockParser detects:
 *   - A markdown table with timestamp + severity columns + 3+ rows
 *   - OR a "Recent Alerts" / "Alert Timeline" / "Event Timeline" header followed by structured items
 *
 * Data shape (from BlockParser):
 *   {
 *     title: 'Alert Timeline' | null,
 *     events: [
 *       {
 *         timestamp: '2026-04-11T18:57:22Z',
 *         severity:  'critical' | 'high' | 'medium' | 'low' | 'info',
 *         title:     'Multiple SSH login failures',
 *         detail:    'rule 5712 · agent 011 (test-sensor) · src_ip 192.168.1.5',
 *         rule_id?:  '5712',
 *         agent?:    '011',
 *       },
 *       ...
 *     ]
 *   }
 *
 * Features:
 *   - Vertical rail with severity-colored dots and connector lines
 *   - Most-recent-first ordering (already done by parser)
 *   - Hover lift on cards
 *   - Click event title → fires `show alert {rule_id}` pivot
 *   - Collapses to "show first 10 + Show all N" for long lists
 */

import { useState, useMemo } from 'react';
import { EuiIcon } from '@elastic/eui';
import { THEME, GRADIENTS, SHADOWS, TIMINGS } from '../../../utils/theme';
import { FONT } from '../PallasUI';
import { severityColor, formatRelativeTime, useContainerWidth } from './blockHelpers';

// Timeline stays single-column (the rail is the visual anchor) but on wider
// containers each card switches to a horizontal 3-section layout with more
// metadata visible per row, and we show more events before collapsing.
const BP_WIDE = 820;

function visibleCountFor(wide) {
  return wide ? 16 : 10;
}

const SEVERITY_LABELS = {
  critical: 'Critical',
  high:     'High',
  medium:   'Medium',
  low:      'Low',
  info:     'Info',
};

// ─── Severity badge (small inline pill) ─────────────────────────────────────

function SeverityPill({ severity }) {
  const key = String(severity || '').toLowerCase();
  const color = severityColor(key);
  const label = SEVERITY_LABELS[key] || severity || 'Unknown';
  return (
    <span
      style={{
        display: 'inline-flex',
        alignItems: 'center',
        padding: '1px 8px',
        borderRadius: 4,
        fontSize: 9,
        fontWeight: 800,
        textTransform: 'uppercase',
        letterSpacing: '0.05em',
        color,
        background: `${color}18`,
        border: `1px solid ${color}40`,
        whiteSpace: 'nowrap',
      }}
    >
      {label}
    </span>
  );
}

// ─── Single timeline item ───────────────────────────────────────────────────

function TimelineItem({ event, isLast, onPivot, wide }) {
  const [hovered, setHovered] = useState(false);
  const sev = String(event.severity || '').toLowerCase() || 'low';
  const sevColor = severityColor(sev);
  const isCritical = sev === 'critical' || sev === 'high';

  const clickable = typeof onPivot === 'function' && (event.rule_id || event.agent);
  const handleClick = () => {
    if (!clickable) return;
    if (event.rule_id) onPivot(`show alerts for rule ${event.rule_id}`);
    else if (event.agent) onPivot(`check agent ${event.agent} health`);
  };

  return (
    <div
      style={{
        position: 'relative',
        paddingLeft: wide ? 36 : 28,
        paddingBottom: isLast ? 0 : 14,
      }}
    >
      {/* Connector line */}
      {!isLast && (
        <div
          style={{
            position: 'absolute',
            left: wide ? 13 : 9,
            top: 16,
            bottom: 0,
            width: 2,
            background: `linear-gradient(180deg, ${THEME.border}, ${THEME.borderFaint})`,
          }}
        />
      )}

      {/* Severity dot */}
      <div
        style={{
          position: 'absolute',
          left: wide ? 8 : 4,
          top: 6,
          width: 12,
          height: 12,
          borderRadius: '50%',
          background: `linear-gradient(135deg, ${sevColor}, ${sevColor}c0)`,
          border: `2px solid ${THEME.bgDeep}`,
          boxShadow: isCritical ? `0 0 10px ${sevColor}` : `0 0 4px ${sevColor}80`,
          animation: isCritical ? 'pallas-breathe 2.5s ease-in-out infinite' : 'none',
          zIndex: 1,
        }}
      />

      {/* Event card — wide layout uses a 3-section horizontal grid so one row
          holds timestamp (left), title+detail (center fluid), and severity +
          ids (right). Narrow layout stacks them like the original. */}
      <div
        onMouseEnter={() => setHovered(true)}
        onMouseLeave={() => setHovered(false)}
        onClick={clickable ? handleClick : undefined}
        role={clickable ? 'button' : undefined}
        tabIndex={clickable ? 0 : undefined}
        style={{
          position: 'relative',
          background: GRADIENTS.card,
          border: `1px solid ${hovered ? sevColor : THEME.border}`,
          borderLeft: `3px solid ${sevColor}`,
          borderRadius: 8,
          padding: wide ? '10px 16px' : '10px 14px',
          boxShadow: hovered ? SHADOWS.lg : SHADOWS.sm,
          transform: hovered ? 'translateX(3px)' : 'translateX(0)',
          transition: `all ${TIMINGS.fast} ${TIMINGS.ease}`,
          cursor: clickable ? 'pointer' : 'default',
        }}
      >
        {wide ? (
          <div
            style={{
              display: 'grid',
              gridTemplateColumns: '112px minmax(0, 1fr) auto',
              alignItems: 'center',
              gap: 16,
            }}
          >
            {/* Timestamp column */}
            <div
              style={{
                display: 'flex',
                flexDirection: 'column',
                gap: 2,
                color: THEME.textMuted,
                fontFamily: FONT.mono,
                fontSize: 10,
                lineHeight: 1.3,
              }}
              title={event.timestamp || ''}
            >
              <span style={{ color: THEME.textSecondary, fontWeight: 700, fontSize: 11 }}>
                {formatRelativeTime(event.timestamp)}
              </span>
              {event.timestamp && (
                <span style={{ fontSize: 9 }}>
                  {String(event.timestamp).replace('T', ' ').replace('Z', '').slice(0, 19)}
                </span>
              )}
            </div>

            {/* Title + detail */}
            <div style={{ minWidth: 0 }}>
              <div
                style={{
                  fontSize: 13,
                  fontWeight: 600,
                  color: THEME.text,
                  lineHeight: 1.4,
                  overflow: 'hidden',
                  textOverflow: 'ellipsis',
                  whiteSpace: 'nowrap',
                  marginBottom: event.detail ? 3 : 0,
                }}
                title={event.title}
              >
                {event.title || '(no description)'}
                {event._count > 1 && (
                  <span style={{
                    marginLeft: 8, padding: '1px 7px', borderRadius: 10,
                    fontSize: 10, fontWeight: 700, fontFamily: FONT.mono,
                    background: `${THEME.primary}18`, color: THEME.primary,
                    border: `1px solid ${THEME.primary}30`,
                  }}>
                    ×{event._count}
                  </span>
                )}
              </div>
              {event.detail && (
                <div
                  style={{
                    fontSize: 11,
                    color: THEME.textMuted,
                    fontFamily: FONT.mono,
                    lineHeight: 1.4,
                    overflow: 'hidden',
                    textOverflow: 'ellipsis',
                    whiteSpace: 'nowrap',
                  }}
                  title={event.detail}
                >
                  {event.detail}
                </div>
              )}
            </div>

            {/* Right column: severity + optional rule/agent pills */}
            <div
              style={{
                display: 'flex',
                alignItems: 'center',
                gap: 6,
                flexShrink: 0,
              }}
            >
              {event.rule_id && (
                <span
                  style={{
                    fontFamily: FONT.mono,
                    fontSize: 10,
                    fontWeight: 700,
                    color: THEME.primary,
                    padding: '2px 7px',
                    borderRadius: 4,
                    background: `${THEME.primary}12`,
                    border: `1px solid ${THEME.primary}25`,
                  }}
                  title={`Rule ${event.rule_id}`}
                >
                  #{event.rule_id}
                </span>
              )}
              {event.agent && (
                <span
                  style={{
                    fontFamily: FONT.mono,
                    fontSize: 10,
                    color: THEME.textMuted,
                  }}
                  title={`Agent ${event.agent}`}
                >
                  {event.agent}
                </span>
              )}
              <SeverityPill severity={sev} />
            </div>
          </div>
        ) : (
          <>
            {/* Narrow layout — original stacked form */}
            <div
              style={{
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'space-between',
                marginBottom: 4,
                gap: 8,
                flexWrap: 'wrap',
              }}
            >
              <SeverityPill severity={sev} />
              <span
                style={{
                  fontSize: 10,
                  color: THEME.textMuted,
                  fontFamily: FONT.mono,
                  whiteSpace: 'nowrap',
                }}
                title={event.timestamp || ''}
              >
                {formatRelativeTime(event.timestamp)}
              </span>
            </div>
            <div
              style={{
                fontSize: 13,
                fontWeight: 600,
                color: THEME.text,
                lineHeight: 1.4,
                marginBottom: event.detail ? 4 : 0,
              }}
            >
              {event.title || '(no description)'}
            </div>
            {event.detail && (
              <div
                style={{
                  fontSize: 11,
                  color: THEME.textMuted,
                  fontFamily: FONT.mono,
                  lineHeight: 1.4,
                  display: '-webkit-box',
                  WebkitLineClamp: 2,
                  WebkitBoxOrient: 'vertical',
                  overflow: 'hidden',
                }}
              >
                {event.detail}
              </div>
            )}
          </>
        )}
      </div>
    </div>
  );
}

// ─── Main component ────────────────────────────────────────────────────────

export default function TimelineBlock({ data, onPivot }) {
  const [containerRef, containerWidth] = useContainerWidth();
  const [expanded, setExpanded] = useState(false);
  const wide = containerWidth >= BP_WIDE;
  const defaultVisible = visibleCountFor(wide);

  const rawEvents = data?.events || [];
  const title = data?.title || 'Event Timeline';

  // Deduplicate: group consecutive identical titles with a count badge
  // (must be before early return to satisfy hooks rules)
  const events = useMemo(() => {
    if (rawEvents.length === 0) return [];
    const grouped = [];
    for (const ev of rawEvents) {
      const last = grouped[grouped.length - 1];
      if (last && last.title === ev.title && last.severity === ev.severity) {
        last._count = (last._count || 1) + 1;
        last._lastTimestamp = ev.timestamp;
      } else {
        grouped.push({ ...ev, _count: 1 });
      }
    }
    return grouped;
  }, [rawEvents]);

  if (events.length === 0) return null;

  const visible = expanded ? events : events.slice(0, defaultVisible);
  const hidden = events.length - defaultVisible;

  return (
    <div
      ref={containerRef}
      style={{
        margin: '14px 0',
        background: GRADIENTS.card,
        border: `1px solid ${THEME.border}`,
        borderRadius: 12,
        padding: '14px 16px',
        boxShadow: SHADOWS.md + ", inset 0 1px 0 rgba(255,255,255,0.04)",
      }}
    >
      {/* Header */}
      <div
        style={{
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'space-between',
          marginBottom: 14,
          gap: 8,
          flexWrap: 'wrap',
        }}
      >
        <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
          <span
            style={{
              width: 3,
              height: 14,
              background: GRADIENTS.primaryAccent,
              borderRadius: 2,
              flexShrink: 0,
            }}
          />
          <h4
            style={{
              margin: 0,
              fontSize: 12,
              fontWeight: 700,
              color: THEME.textSecondary,
              textTransform: 'uppercase',
              letterSpacing: '0.05em',
            }}
          >
            {title}
          </h4>
        </div>
        <span
          style={{
            fontSize: 11,
            color: THEME.textMuted,
            fontFamily: FONT.mono,
          }}
        >
          {events.length} {events.length === 1 ? 'event' : 'events'}
        </span>
      </div>

      {/* Timeline */}
      <div>
        {visible.map((event, idx) => (
          <TimelineItem
            key={`${event.timestamp || idx}-${idx}`}
            event={event}
            isLast={idx === visible.length - 1}
            onPivot={onPivot}
            wide={wide}
          />
        ))}
      </div>

      {/* Footer */}
      {hidden > 0 && (
        <div
          style={{
            marginTop: 12,
            display: 'flex',
            justifyContent: 'center',
          }}
        >
          <button
            onClick={() => setExpanded(!expanded)}
            style={{
              display: 'inline-flex',
              alignItems: 'center',
              gap: 6,
              padding: '6px 16px',
              borderRadius: 8,
              border: `1px solid ${THEME.primary}40`,
              background: `${THEME.primary}10`,
              color: THEME.primary,
              fontSize: 11,
              fontWeight: 600,
              cursor: 'pointer',
              fontFamily: 'inherit',
              transition: `all ${TIMINGS.fast} ${TIMINGS.ease}`,
              outline: 'none',
            }}
            onMouseEnter={(e) => {
              e.currentTarget.style.background = `${THEME.primary}20`;
              e.currentTarget.style.borderColor = THEME.primary;
            }}
            onMouseLeave={(e) => {
              e.currentTarget.style.background = `${THEME.primary}10`;
              e.currentTarget.style.borderColor = `${THEME.primary}40`;
            }}
          >
            <EuiIcon type={expanded ? 'arrowUp' : 'arrowDown'} size="s" color={THEME.primary} />
            {expanded ? 'Show less' : `Show all ${events.length}`}
          </button>
        </div>
      )}
    </div>
  );
}
