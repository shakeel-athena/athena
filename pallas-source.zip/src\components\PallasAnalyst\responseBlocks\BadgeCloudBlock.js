/**
 * BadgeCloudBlock — Chip cloud for tags (MITRE / compliance / rule groups)
 *
 * Replaces flat lists like:
 *   "MITRE: T1190, T1133, T1059, T1003"
 *   "Compliance: PCI-DSS 10.2.5, HIPAA 164.312.b, NIST AU.14"
 *   "Groups: pam, syslog, authentication_failed"
 *
 * Renders each tag as a styled chip with:
 *   - Framework-specific color coding (MITRE = blue, PCI = teal, HIPAA = green,
 *     NIST = purple, GDPR = amber, GPG13 = pink, TSC = slate)
 *   - Hover tooltip with description (when known)
 *   - Click-to-pivot for MITRE techniques (opens ATT&CK Navigator)
 *   - Click-to-filter for compliance tags (filter alerts by control)
 *   - Smart grouping when multiple frameworks are mixed
 *
 * Data shape (from BlockParser):
 *   {
 *     title: 'MITRE ATT&CK Coverage' | 'Compliance Tags' | 'Rule Groups' | etc.
 *     groups: [
 *       {
 *         framework: 'mitre' | 'pci' | 'hipaa' | 'nist' | 'gdpr' | 'gpg13' | 'tsc' | 'group',
 *         label: 'MITRE ATT&CK',  // optional display label
 *         items: [
 *           { id: 'T1190', label: 'Exploit Public-Facing Application', technique?: 'T1190' },
 *           ...
 *         ]
 *       }
 *     ]
 *   }
 */

import { useState } from 'react';
import { EuiIcon } from '@elastic/eui';
import { THEME, GRADIENTS, SHADOWS, TIMINGS } from '../../../utils/theme';
import { FONT } from '../PallasUI';

// ─── Framework styles ───────────────────────────────────────────────────────

const FRAMEWORK_STYLES = {
  mitre: {
    label: 'MITRE ATT&CK',
    color: THEME.primary,
    bg: 'rgba(59, 130, 246, 0.10)',
    border: 'rgba(59, 130, 246, 0.40)',
    hoverBg: 'rgba(59, 130, 246, 0.18)',
    icon: 'crosshairs',
  },
  pci: {
    label: 'PCI-DSS',
    color: '#10b981',
    bg: 'rgba(16, 185, 129, 0.10)',
    border: 'rgba(16, 185, 129, 0.40)',
    hoverBg: 'rgba(16, 185, 129, 0.18)',
    icon: 'lock',
  },
  hipaa: {
    label: 'HIPAA',
    color: '#06b6d4',
    bg: 'rgba(6, 182, 212, 0.10)',
    border: 'rgba(6, 182, 212, 0.40)',
    hoverBg: 'rgba(6, 182, 212, 0.18)',
    icon: 'heart',
  },
  nist: {
    label: 'NIST 800-53',
    color: '#60a5fa',
    bg: 'rgba(96, 165, 250, 0.10)',
    border: 'rgba(96, 165, 250, 0.40)',
    hoverBg: 'rgba(96, 165, 250, 0.18)',
    icon: 'starFilled',
  },
  gdpr: {
    label: 'GDPR',
    color: '#f59e0b',
    bg: 'rgba(245, 158, 11, 0.10)',
    border: 'rgba(245, 158, 11, 0.40)',
    hoverBg: 'rgba(245, 158, 11, 0.18)',
    icon: 'globe',
  },
  gpg13: {
    label: 'GPG13',
    color: '#ec4899',
    bg: 'rgba(236, 72, 153, 0.10)',
    border: 'rgba(236, 72, 153, 0.40)',
    hoverBg: 'rgba(236, 72, 153, 0.18)',
    icon: 'documentEdit',
  },
  tsc: {
    label: 'TSC',
    color: '#64748b',
    bg: 'rgba(100, 116, 139, 0.10)',
    border: 'rgba(100, 116, 139, 0.40)',
    hoverBg: 'rgba(100, 116, 139, 0.18)',
    icon: 'documentation',
  },
  group: {
    label: 'Rule Groups',
    color: THEME.textSecondary,
    bg: 'rgba(142, 159, 188, 0.08)',
    border: 'rgba(142, 159, 188, 0.30)',
    hoverBg: 'rgba(142, 159, 188, 0.16)',
    icon: 'tag',
  },
  iso27001: {
    label: 'ISO 27001',
    color: '#0ea5e9',
    bg: 'rgba(14, 165, 233, 0.10)',
    border: 'rgba(14, 165, 233, 0.40)',
    hoverBg: 'rgba(14, 165, 233, 0.18)',
    icon: 'documentation',
  },
};

function getFrameworkStyle(framework) {
  return FRAMEWORK_STYLES[framework] || FRAMEWORK_STYLES.group;
}

// ─── Single chip ────────────────────────────────────────────────────────────

function Chip({ item, framework, onPivot }) {
  const [hovered, setHovered] = useState(false);
  const style = getFrameworkStyle(framework);

  // MITRE technique IDs are clickable to open ATT&CK Navigator in new tab
  const isMitreTechnique = framework === 'mitre' && /^T\d{4}(\.\d{3})?$/i.test(item.id || '');
  const isMitreTactic = framework === 'mitre' && /^TA\d{4}$/i.test(item.id || '');
  const externalUrl = isMitreTechnique
    ? `https://attack.mitre.org/techniques/${item.id.toUpperCase()}/`
    : isMitreTactic
    ? `https://attack.mitre.org/tactics/${item.id.toUpperCase()}/`
    : null;

  // Compliance tags are clickable to fire a follow-up filter query
  const filterQuery =
    framework === 'pci'   ? `show alerts matching PCI-DSS ${item.id}` :
    framework === 'hipaa' ? `show alerts matching HIPAA ${item.id}` :
    framework === 'nist'  ? `show alerts matching NIST ${item.id}` :
    framework === 'gdpr'  ? `show alerts matching GDPR ${item.id}` :
    null;

  const clickable = externalUrl || (filterQuery && typeof onPivot === 'function');

  const handleClick = (e) => {
    e.stopPropagation();
    if (externalUrl) {
      window.open(externalUrl, '_blank', 'noopener');
    } else if (filterQuery && typeof onPivot === 'function') {
      onPivot(filterQuery);
    }
  };

  const tooltipText = item.label && item.label !== item.id
    ? `${item.id} — ${item.label}${externalUrl ? ' (click for ATT&CK Navigator)' : ''}`
    : (clickable ? 'Click for details' : item.id);

  return (
    <span
      onMouseEnter={() => setHovered(true)}
      onMouseLeave={() => setHovered(false)}
      onClick={clickable ? handleClick : undefined}
      title={tooltipText}
      role={clickable ? 'button' : undefined}
      tabIndex={clickable ? 0 : undefined}
      onKeyDown={
        clickable
          ? (e) => {
              if (e.key === 'Enter' || e.key === ' ') {
                e.preventDefault();
                handleClick(e);
              }
            }
          : undefined
      }
      style={{
        display: 'inline-flex',
        alignItems: 'center',
        gap: 5,
        padding: '4px 9px',
        borderRadius: 5,
        border: `1px solid ${hovered ? style.color : style.border}`,
        background: hovered ? style.hoverBg : style.bg,
        color: style.color,
        fontFamily: FONT.mono,
        fontSize: 11,
        fontWeight: 600,
        cursor: clickable ? 'pointer' : 'default',
        whiteSpace: 'nowrap',
        transition: `all ${TIMINGS.fast} ${TIMINGS.ease}`,
        boxShadow: hovered ? `0 0 8px ${style.color}40` : 'none',
        transform: hovered ? 'translateY(-1px)' : 'translateY(0)',
      }}
    >
      {item.id}
    </span>
  );
}

// ─── Single framework group (header + chip row) ─────────────────────────────

function FrameworkGroup({ framework, items, onPivot }) {
  const style = getFrameworkStyle(framework);

  return (
    <div style={{ marginBottom: 10 }}>
      <div
        style={{
          display: 'flex',
          alignItems: 'center',
          gap: 8,
          marginBottom: 6,
        }}
      >
        <span
          style={{
            display: 'inline-flex',
            alignItems: 'center',
            gap: 5,
            padding: '2px 8px',
            borderRadius: 4,
            background: `${style.color}14`,
            border: `1px solid ${style.color}30`,
            color: style.color,
            fontSize: 9,
            fontWeight: 700,
            textTransform: 'uppercase',
            letterSpacing: '0.06em',
          }}
        >
          <EuiIcon type={style.icon} size="s" color={style.color} />
          {style.label}
        </span>
        <span
          style={{
            fontSize: 10,
            color: THEME.textMuted,
            fontFamily: FONT.mono,
          }}
        >
          {items.length} {items.length === 1 ? 'item' : 'items'}
        </span>
      </div>
      <div style={{ display: 'flex', flexWrap: 'wrap', gap: 5 }}>
        {items.map((item, i) => (
          <Chip
            key={`${framework}-${item.id}-${i}`}
            item={item}
            framework={framework}
            onPivot={onPivot}
          />
        ))}
      </div>
    </div>
  );
}

// ─── Main component ────────────────────────────────────────────────────────

export default function BadgeCloudBlock({ data, onPivot }) {
  const groups = data?.groups || [];
  const title = data?.title;
  const totalItems = groups.reduce((sum, g) => sum + (g.items?.length || 0), 0);

  if (groups.length === 0 || totalItems === 0) return null;

  return (
    <div
      style={{
        margin: '14px 0',
        background: GRADIENTS.card,
        border: `1px solid ${THEME.border}`,
        borderRadius: 12,
        padding: '14px 16px',
        boxShadow: SHADOWS.md + ", inset 0 1px 0 rgba(255,255,255,0.04)",
      }}
    >
      {title && (
        <div
          style={{
            display: 'flex',
            alignItems: 'center',
            gap: 10,
            marginBottom: 12,
          }}
        >
          <span
            style={{
              width: 3,
              height: 14,
              background: GRADIENTS.primaryAccent,
              borderRadius: 2,
              flexShrink: 0,
            }}
          />
          <h4
            style={{
              margin: 0,
              fontSize: 12,
              fontWeight: 700,
              color: THEME.textSecondary,
              textTransform: 'uppercase',
              letterSpacing: '0.05em',
            }}
          >
            {title}
          </h4>
          <span
            style={{
              fontSize: 11,
              color: THEME.textMuted,
              fontFamily: FONT.mono,
            }}
          >
            ({totalItems})
          </span>
        </div>
      )}

      {groups.map((g, idx) => (
        <FrameworkGroup
          key={`${g.framework}-${idx}`}
          framework={g.framework}
          items={g.items || []}
          onPivot={onPivot}
        />
      ))}
    </div>
  );
}
