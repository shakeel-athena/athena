/**
 * PallasStrategies — Single source of truth for all Pallas query strategies
 *
 * Hybrid alignment with the plugin:
 *   • Per-page chip union (welcome + siem-tools + nids-tools + vulns-dashboard
 *     + correlations) — these queries are LLM-tested through the plugin's
 *     visible UI surfaces.
 *   • Plus a small handful of high-value command-palette-only entries
 *     (CVE Lookup, MITRE ATT&CK Coverage, Compliance frameworks) that aren't
 *     promoted as chips in plugin but are universally useful in SOC work.
 *
 * Total: 49 active strategies in 6 categories (SIEM Agents, SIEM Alerts,
 * NIDS Alerts, Vulnerabilities, Correlations, Compliance).
 *
 * Each category has:
 *   - id:         Unique identifier (used by CommandPalette)
 *   - name:       Display name (used by StrategyPanel)
 *   - label:      Alias for CommandPalette display (defaults to name)
 *   - icon:       EUI icon type
 *   - strategies: Array of { label, query, description, params? }
 */

// ─── SIEM — Agents & Endpoints ──────────────────────────────────────────────

export const SIEM_AGENT_STRATEGIES = {
  id: 'siem-agents',
  name: 'Agents & Endpoints',
  label: 'SIEM — Agents & Endpoints',
  icon: 'compute',
  strategies: [
    { label: 'Agent Status', query: 'show all agents', description: 'View all monitored agents with status, OS, and last check-in' },
    { label: 'Active Agents', query: 'show active agents', description: 'View all active endpoint agents and their details' },
    { label: 'Disconnected Agents', query: 'show disconnected agents', description: 'Identify agents that have lost connectivity' },
    { label: 'Agent Health', query: 'check agent {agent_id} health', description: 'Health status for a specific agent', params: [{ key: 'agent_id', label: 'Agent ID', placeholder: 'e.g. 011' }] },
    { label: 'Full Agent Investigation', query: 'full investigation for agent {agent_id}', description: 'Deep dive into a specific agent', params: [{ key: 'agent_id', label: 'Agent ID', placeholder: 'e.g. 011' }] },
    { label: 'Open Ports', query: 'show ports for agent {agent_id}', description: 'Network ports and listening services', params: [{ key: 'agent_id', label: 'Agent ID', placeholder: 'e.g. 011' }] },
    { label: 'Running Processes', query: 'show processes for agent {agent_id}', description: 'Active processes and resource usage', params: [{ key: 'agent_id', label: 'Agent ID', placeholder: 'e.g. 011' }] },
    { label: 'Software Inventory', query: 'show inventory for agent {agent_id}', description: 'Installed packages and software', params: [{ key: 'agent_id', label: 'Agent ID', placeholder: 'e.g. 011' }] },
    { label: 'Log Source Health', query: 'show log source health', description: 'Health and status of log sources' },
  ],
};

// SIEM_ENDPOINT_STRATEGIES retained as a thin export for backward-compatible
// imports. Active development uses SIEM_AGENT_STRATEGIES.
export const SIEM_ENDPOINT_STRATEGIES = {
  id: 'siem-endpoints',
  name: 'Endpoint Investigation',
  label: 'SIEM — Endpoint Investigation',
  icon: 'inspect',
  strategies: SIEM_AGENT_STRATEGIES.strategies.filter(s =>
    s.label === 'Open Ports' ||
    s.label === 'Running Processes' ||
    s.label === 'Software Inventory' ||
    s.label === 'Log Source Health'
  ),
};

// ─── SIEM — Alerts & Threat Hunting ─────────────────────────────────────────

export const SIEM_ALERT_STRATEGIES = {
  id: 'siem-alerts',
  name: 'Alerts & Threat Hunting',
  label: 'SIEM — Alerts & Threat Hunting',
  icon: 'securityAnalyticsApp',
  strategies: [
    { label: 'Recent Alerts', query: 'show recent alerts', description: 'Latest security alerts across all agents' },
    { label: 'Active Alerts', query: 'show recent alert analysis', description: 'Recent alerts with severity breakdown and top triggered rules' },
    { label: 'Severity Breakdown', query: 'show alert summary', description: 'Alert distribution by severity level' },
    { label: 'Top Detection Rules', query: 'which rules trigger most frequently', description: 'Most frequently triggered detection rules' },
    { label: 'MITRE ATT&CK Coverage', query: 'show MITRE ATT&CK coverage', description: 'Tactic and technique mapping of alerts' },
    { label: 'Alert Patterns', query: 'analyze alert patterns', description: 'Detect recurring alert clusters and frequency anomalies' },
    { label: 'Security Report', query: 'generate security report', description: 'Generate a full security report with findings and recommendations' },
  ],
};

// ─── NIDS — Alerts & Network ────────────────────────────────────────────────

export const NIDS_ALERT_STRATEGIES = {
  id: 'nids-alerts',
  name: 'Alerts & Network',
  label: 'NIDS — Alerts & Network',
  icon: 'globe',
  strategies: [
    { label: 'IDS Alerts', query: 'show suricata alerts', description: 'Latest network intrusion detection alerts' },
    { label: 'Critical IDS Alerts', query: 'show critical suricata alerts', description: 'High-priority alerts requiring immediate attention' },
    { label: 'High Severity IDS Alerts', query: 'show high severity suricata alerts', description: 'Severity 1-2 alerts with threat context' },
    { label: 'IDS Alert Summary', query: 'show suricata alert summary', description: 'Aggregate alert statistics and trends' },
    { label: 'Category Breakdown', query: 'show suricata alert categories', description: 'Alerts grouped by classification category' },
    { label: 'Top Signatures', query: 'show top suricata signatures', description: 'Most frequently triggered IDS signatures' },
    { label: 'Top Attackers', query: 'show top suricata attackers', description: 'Source IPs generating the most alerts' },
    { label: 'Network Analysis', query: 'suricata network analysis', description: 'Top talkers, traffic patterns, and service breakdown from IDS' },
    { label: 'NIDS Health', query: 'show suricata health status', description: 'IDS engine status and performance metrics' },
    { label: 'Search IDS Alerts', query: 'search suricata alerts for {keyword}', description: 'Search alerts by keyword or signature', params: [{ key: 'keyword', label: 'Keyword', placeholder: 'e.g. CVE-2024, exploit, malware' }] },
  ],
};

// NIDS_HUNTING / NIDS_NETWORK retained as thin exports for backward-compatible
// imports. The underlying queries that mattered (Suricata Health, Search Alerts)
// now live in NIDS_ALERT_STRATEGIES.
export const NIDS_HUNTING_STRATEGIES = {
  id: 'nids-hunting',
  name: 'Advanced Hunting',
  label: 'NIDS — Advanced Hunting',
  icon: 'securityAnalyticsApp',
  strategies: [],
};

export const NIDS_NETWORK_STRATEGIES = {
  id: 'nids-network',
  name: 'Network Recon',
  label: 'NIDS — Network Recon',
  icon: 'globe',
  strategies: [],
};

// ─── Vulnerabilities ────────────────────────────────────────────────────────

export const VULN_STRATEGIES = {
  id: 'vulnerabilities',
  name: 'Risk Assessment',
  label: 'Vulnerabilities',
  icon: 'bug',
  strategies: [
    { label: 'Vulnerability Summary', query: 'show vulnerability summary', description: 'Overall vulnerability landscape and severity breakdown' },
    { label: 'Critical CVEs', query: 'show critical vulnerabilities', description: 'Critical severity vulnerabilities requiring immediate action' },
    { label: 'Vulns by Agent', query: 'show vulnerabilities with agent details', description: 'Full vulnerability details per agent' },
    { label: 'Top Vulnerable Agents', query: 'show top vulnerable agents', description: 'Agents with the most or most-critical vulnerabilities' },
    { label: 'Active + High Vulns', query: 'show active agents with high vulnerabilities', description: 'Active agents with unpatched high-severity CVEs' },
    { label: 'Disconnected + Critical', query: 'show disconnected agents with critical vulnerabilities', description: 'Unreachable agents with critical exposure' },
    { label: 'Compare by Status', query: 'compare vulnerabilities active vs disconnected', description: 'Compare vulnerability exposure across agent statuses' },
    { label: 'CVE Lookup', query: 'show vulnerability summary for {cve_id}', description: 'Deep dive into a specific CVE', params: [{ key: 'cve_id', label: 'CVE ID', placeholder: 'e.g. CVE-2024-1234' }] },
    { label: 'Behavioral Baseline', query: 'establish behavioral baseline', description: 'Normal vs anomalous behavior patterns' },
  ],
};

// ─── Correlations ───────────────────────────────────────────────────────────

export const CORRELATION_STRATEGIES = {
  id: 'correlations',
  name: 'Cross-Platform',
  label: 'Correlations',
  icon: 'layers',
  strategies: [
    { label: 'Security Posture', query: 'comprehensive security posture analysis', description: 'Cross-platform security health across SIEM, NIDS, and vulnerabilities' },
    { label: 'Combined Alerts', query: 'show combined alerts from all platforms', description: 'Unified view of alerts from Endpoints and NIDS' },
    { label: 'Alert + Vuln Correlation', query: 'correlate active alerts with known vulnerabilities', description: 'Match triggered alerts against existing CVEs' },
    { label: 'Top Risk Agents', query: 'show top risk agents across alerts and vulnerabilities', description: 'Agents with highest combined alert + vulnerability exposure' },
    { label: 'Most At Risk Agents', query: 'most at risk agents', description: 'Agents ranked by risk score from alerts and vulnerabilities' },
    { label: 'Risk Scoring', query: 'calculate dynamic risk score for all agents', description: 'Composite risk score from alerts, vulns, and network activity' },
    { label: 'Scanning Detection', query: 'detect all scanning activity', description: 'Identify reconnaissance from both endpoint and network perspectives' },
    { label: 'Endpoints + NIDS', query: 'correlate wazuh alerts with suricata alerts', description: 'Match endpoint alerts with network-level detections' },
    { label: 'Behavioral Baseline (Critical)', query: 'establish behavioral baseline for critical agents', description: 'Normal vs anomalous behavior patterns for high-value endpoints' },
    { label: 'IP Investigation', query: 'investigate IP {ip}', description: 'Cross-correlate an IP across alerts, network traffic, and vulnerabilities', params: [{ key: 'ip', label: 'IP Address', placeholder: 'e.g. 192.168.1.100' }] },
  ],
};

// ─── Compliance ─────────────────────────────────────────────────────────────

export const COMPLIANCE_STRATEGIES = {
  id: 'compliance',
  name: 'Compliance',
  label: 'Compliance',
  icon: 'checkInCircleFilled',
  strategies: [
    { label: 'PCI-DSS Compliance', query: 'show {framework} compliance status', description: 'PCI-DSS compliance posture', params: [{ key: 'framework', label: 'Framework', placeholder: 'PCI-DSS' }] },
    { label: 'HIPAA Compliance', query: 'show HIPAA compliance status', description: 'HIPAA compliance posture' },
    { label: 'GDPR Compliance', query: 'show GDPR compliance status', description: 'GDPR compliance posture' },
    { label: 'NIST Compliance', query: 'show NIST compliance status', description: 'NIST compliance posture' },
  ],
};

// ─── System & Stats — DROPPED ──────────────────────────────────────────────
// Removed per analyst review (not in plugin per-page chips). The Wazuh
// daemon stats (remoted/analysisd/cluster/manager logs) remain accessible via
// free-form chat but no longer occupy Quick Actions space.
//
// Empty export retained for any code that still imports the symbol.

export const SYSTEM_STRATEGIES = {
  id: 'system-stats',
  name: 'System & Stats',
  label: 'System & Stats',
  icon: 'monitoringApp',
  strategies: [],
};

// ─── Assembled Collections ──────────────────────────────────────────────────

/** All categories — used by CommandPalette for global Ctrl+K search.
 *  Six active categories: SIEM Agents, SIEM Alerts, NIDS Alerts,
 *  Vulnerabilities, Correlations, Compliance. */
export const ALL_STRATEGY_CATEGORIES = [
  SIEM_AGENT_STRATEGIES,
  SIEM_ALERT_STRATEGIES,
  NIDS_ALERT_STRATEGIES,
  VULN_STRATEGIES,
  CORRELATION_STRATEGIES,
  COMPLIANCE_STRATEGIES,
];

/** SIEM module strategies (StrategyPanel format). */
export const SIEM_PANEL_STRATEGIES = [
  SIEM_AGENT_STRATEGIES,
  SIEM_ALERT_STRATEGIES,
];

/** NIDS module strategies (StrategyPanel format). */
export const NIDS_PANEL_STRATEGIES = [
  NIDS_ALERT_STRATEGIES,
];
