/**
 * PallasStrategies — Single source of truth for all Pallas query strategies
 *
 * Shared by PallasCommandPalette (global Ctrl+K), PallasStrategyPanel (per-module),
 * and individual module components (SIEM, NIDS, Vulns, Correlations).
 *
 * Each category has:
 *   - id:         Unique identifier (used by CommandPalette)
 *   - name:       Display name (used by StrategyPanel)
 *   - label:      Alias for CommandPalette display (defaults to name)
 *   - icon:       EUI icon type
 *   - strategies: Array of { label, query, description, params? }
 */

// ─── SIEM Strategies ────────────────────────────────────────────────────────

export const SIEM_AGENT_STRATEGIES = {
  id: 'siem-agents',
  name: 'Agent Recon',
  label: 'SIEM — Agents & Endpoints',
  icon: 'compute',
  strategies: [
    { label: 'Active Agents', query: 'show active agents', description: 'List all currently active/connected agents' },
    { label: 'Disconnected Agents', query: 'show disconnected agents', description: 'List agents that are currently disconnected' },
    { label: 'Agent Health Check', query: 'check agent health status', description: 'Check the overall health status of all agents' },
    { label: 'OS Breakdown', query: 'show agent OS breakdown', description: 'Breakdown of agents by operating system' },
    { label: 'Event Volume by Agent', query: 'show event volume by agent', description: 'Which agents are generating the most events' },
    { label: 'Full Agent Investigation', query: 'full investigation for agent {agent_id}', description: 'Comprehensive investigation for a specific agent', params: [{ key: 'agent_id', label: 'Agent ID', placeholder: 'e.g. 001' }] },
    { label: 'Open Ports', query: 'show ports for agent {agent_id}', description: 'List all open ports for a specific agent', params: [{ key: 'agent_id', label: 'Agent ID', placeholder: 'e.g. 001' }] },
    { label: 'Running Processes', query: 'show processes for agent {agent_id}', description: 'List running processes on a specific agent', params: [{ key: 'agent_id', label: 'Agent ID', placeholder: 'e.g. 001' }] },
    { label: 'Software Inventory', query: 'show inventory for agent {agent_id}', description: 'Show installed software inventory for a specific agent', params: [{ key: 'agent_id', label: 'Agent ID', placeholder: 'e.g. 001' }] },
    // FIM and SCA temporarily hidden — backend tools not yet registered in MCP tools list
    // { label: 'FIM Events', query: 'show FIM events', description: 'File Integrity Monitoring events across all agents' },
    // { label: 'SCA Results', query: 'show SCA results', description: 'Security Configuration Assessment results' },
  ],
};

export const SIEM_ALERT_STRATEGIES = {
  id: 'siem-alerts',
  name: 'Log Analysis',
  label: 'SIEM — Alerts & Threat Hunting',
  icon: 'securityAnalyticsApp',
  strategies: [
    { label: 'Recent Alerts', query: 'show recent alerts', description: 'Most recent SIEM alerts across all agents' },
    { label: 'Severity Breakdown', query: 'show alert summary', description: 'Alert distribution by severity level' },
    { label: 'Top Detection Rules', query: 'which rules trigger most frequently', description: 'Detection rules with the highest trigger frequency' },
    { label: 'MITRE ATT&CK Coverage', query: 'show MITRE ATT&CK coverage', description: 'Map detections to MITRE ATT&CK tactics and techniques' },
    { label: 'Alert Timeline Trends', query: 'show alert timeline trends', description: 'Alert volume trends over time' },
    { label: 'Rule Frequency Analysis', query: 'analyze rule frequency patterns', description: 'Analyze detection rule trigger patterns and anomalies' },
    { label: 'Brute Force Detection', query: 'detect brute force attacks', description: 'Identify brute force attack patterns' },
    { label: 'Privilege Escalation', query: 'detect privilege escalation attempts', description: 'Detect privilege escalation attempts across endpoints' },
    { label: 'Suspicious PowerShell', query: 'detect suspicious PowerShell activity', description: 'Identify suspicious PowerShell execution patterns' },
    { label: 'Lateral Movement', query: 'detect lateral movement indicators', description: 'Detect lateral movement indicators across the network' },
    { label: 'Malware Alerts', query: 'show malware detection alerts', description: 'Alerts related to malware and suspicious file activity' },
    { label: 'Auth Failure Analysis', query: 'detect brute force login failures', description: 'Analyze authentication failure patterns' },
  ],
};

export const SIEM_ENDPOINT_STRATEGIES = {
  id: 'siem-endpoints',
  name: 'Endpoint Investigation',
  label: 'SIEM — Endpoint Investigation',
  icon: 'inspect',
  strategies: [
    { label: 'Open Ports', query: 'show ports for agent {agent_id}', description: 'Network ports and listening services', params: [{ key: 'agent_id', label: 'Agent ID', placeholder: 'e.g. 019' }] },
    { label: 'Running Processes', query: 'show processes for agent {agent_id}', description: 'Active processes and resource usage', params: [{ key: 'agent_id', label: 'Agent ID', placeholder: 'e.g. 019' }] },
    { label: 'Software Inventory', query: 'show inventory for agent {agent_id}', description: 'Installed packages and software', params: [{ key: 'agent_id', label: 'Agent ID', placeholder: 'e.g. 019' }] },
    // FIM and SCA temporarily hidden — backend tools not yet registered in MCP tools list
    // { label: 'FIM Events', query: 'show FIM events', description: 'File integrity monitoring — recent file changes' },
    // { label: 'SCA Results', query: 'show SCA results', description: 'Security Configuration Assessment findings' },
    { label: 'Log Source Health', query: 'show log source health', description: 'Health and status of log sources' },
  ],
};

// ─── NIDS Strategies ────────────────────────────────────────────────────────

export const NIDS_ALERT_STRATEGIES = {
  id: 'nids-alerts',
  name: 'Alert Triage',
  label: 'NIDS — Alerts & Network',
  icon: 'globe',
  strategies: [
    { label: 'Recent IDS Alerts', query: 'show suricata alerts', description: 'Recent network intrusion detection alerts' },
    { label: 'Critical IDS Alerts', query: 'show critical suricata alerts', description: 'Critical severity network intrusion alerts' },
    { label: 'High Severity IDS', query: 'show high severity suricata alerts', description: 'High severity network intrusion alerts' },
    { label: 'IDS Alert Summary', query: 'show suricata alert summary', description: 'Summary of IDS alerts by category and severity' },
    { label: 'Category Breakdown', query: 'show suricata alert categories', description: 'IDS alerts broken down by detection category' },
    { label: 'IDS MITRE Mapping', query: 'show suricata MITRE mapping', description: 'Map IDS alerts to MITRE ATT&CK framework' },
    { label: 'Top Signatures', query: 'show top suricata signatures', description: 'Most frequently triggered IDS signatures' },
    { label: 'Top Attackers', query: 'show top suricata attackers', description: 'Source IPs generating the most IDS alerts' },
    { label: 'Network Analysis', query: 'suricata network analysis', description: 'Comprehensive network traffic analysis from IDS' },
    { label: 'HTTP Traffic', query: 'show HTTP traffic analysis', description: 'HTTP traffic patterns and anomalies' },
    { label: 'TLS/SSL Analysis', query: 'TLS fingerprint analysis', description: 'TLS/SSL traffic analysis and fingerprinting' },
    { label: 'Traffic Overview', query: 'show suricata traffic overview', description: 'High-level network traffic overview from IDS' },
  ],
};

export const NIDS_HUNTING_STRATEGIES = {
  id: 'nids-hunting',
  name: 'Advanced Hunting',
  label: 'NIDS — Advanced Hunting',
  icon: 'securityAnalyticsApp',
  strategies: [
    { label: 'JA3 Fingerprints', query: 'show JA3 fingerprint analysis', description: 'Analyze JA3 TLS client fingerprints for threat hunting' },
    { label: 'JA4 Fingerprints', query: 'show JA4 fingerprint analysis', description: 'Analyze JA4 TLS fingerprints for threat hunting' },
    { label: 'Suspicious Activity', query: 'detect suspicious suricata activity', description: 'Detect anomalous and suspicious network patterns' },
    { label: 'Flow Analysis', query: 'show suricata flow analysis', description: 'Analyze network flow data from IDS' },
    { label: 'Search IDS Alerts', query: 'search suricata alerts for {keyword}', description: 'Search IDS alerts for a specific keyword or indicator', params: [{ key: 'keyword', label: 'Keyword', placeholder: 'e.g. CVE-2024, exploit, malware' }] },
    { label: 'Suricata Health', query: 'show suricata health status', description: 'Check the health and operational status of Suricata IDS' },
  ],
};

export const NIDS_NETWORK_STRATEGIES = {
  id: 'nids-network',
  name: 'Network Recon',
  label: 'NIDS — Network Recon',
  icon: 'globe',
  strategies: [
    { label: 'Top Signatures', query: 'show top suricata signatures', description: 'Most frequently triggered IDS signatures' },
    { label: 'Top Attackers', query: 'show top suricata attackers', description: 'Source IPs generating the most alerts' },
    { label: 'Network Analysis', query: 'suricata network analysis', description: 'Traffic patterns and anomaly detection' },
    { label: 'Health Status', query: 'show suricata health status', description: 'IDS engine status and performance metrics' },
  ],
};

// ─── Vulnerability Strategies ───────────────────────────────────────────────

export const VULN_STRATEGIES = {
  id: 'vulnerabilities',
  name: 'Risk Assessment',
  label: 'Vulnerabilities',
  icon: 'bug',
  strategies: [
    { label: 'Vulnerability Summary', query: 'show vulnerability summary', description: 'Overview of all vulnerabilities across the environment' },
    { label: 'Critical CVEs', query: 'show critical vulnerabilities', description: 'Critical severity CVEs requiring immediate attention' },
    { label: 'Vulnerability Trends', query: 'show vulnerability trends and distribution', description: 'Vulnerability trends over time and severity distribution' },
    { label: 'Ranking by Agent', query: 'show vulnerability ranking by agent', description: 'Agents ranked by vulnerability count and severity' },
    { label: 'Active + High Vulns', query: 'show active agents with high vulnerabilities', description: 'Active agents that have high severity vulnerabilities' },
    { label: 'Disconnected + Critical', query: 'show disconnected agents with critical vulnerabilities', description: 'Disconnected agents with critical unpatched vulnerabilities' },
    { label: 'Port Exposure Risk', query: 'assess port exposure risk for all agents', description: 'Evaluate risk from exposed ports across all agents' },
    { label: 'Security Posture Deep Dive', query: 'comprehensive security posture analysis', description: 'In-depth analysis of overall security posture' },
    { label: 'Exploit Correlation', query: 'correlate vulnerabilities with active exploits', description: 'Match known vulnerabilities with active exploit activity' },
    { label: 'CVE Lookup', query: 'show vulnerability summary for {cve_id}', description: 'Look up details for a specific CVE', params: [{ key: 'cve_id', label: 'CVE ID', placeholder: 'e.g. CVE-2024-1234' }] },
    { label: 'Unpatched Systems', query: 'show vulnerabilities with active exploits', description: 'Systems with unpatched vulnerabilities that have active exploits' },
    { label: 'Compliance Gaps', query: 'show vulnerability compliance gaps', description: 'Vulnerabilities contributing to compliance gaps' },
  ],
};

// ─── Correlation Strategies ─────────────────────────────────────────────────

export const CORRELATION_STRATEGIES = {
  id: 'correlations',
  name: 'Cross-Platform',
  label: 'Correlations',
  icon: 'layers',
  strategies: [
    { label: 'Security Posture Overview', query: 'comprehensive security posture analysis', description: 'Cross-platform security posture analysis' },
    { label: 'IP Investigation', query: 'investigate IP {ip}', description: 'Investigate all activity associated with a specific IP address', params: [{ key: 'ip', label: 'IP Address', placeholder: 'e.g. 192.168.1.100' }] },
    { label: 'Cross-Platform Correlation', query: 'show combined alerts from all platforms', description: 'Correlate alerts across SIEM, NIDS, and other sources' },
    { label: 'Dynamic Risk Scoring', query: 'calculate dynamic risk score for all agents', description: 'Calculate risk scores dynamically based on current threat data' },
    { label: 'Alert + Network Correlation', query: 'correlate wazuh alerts with suricata detections', description: 'Find overlapping detections between SIEM and NIDS' },
    { label: 'Unified Threat Summary', query: 'show combined alert summary from all platforms', description: 'Unified view of threats from all detection platforms' },
    { label: 'Combined Scanning Detection', query: 'detect all scanning activity', description: 'Detect scanning activity from SIEM and NIDS combined' },
    { label: 'Alert + Vuln Correlation', query: 'correlate active alerts with known vulnerabilities', description: 'Match active alerts to known vulnerabilities on affected hosts' },
    { label: 'Top Risk Agents', query: 'identify top risk agents combining alerts and vulnerabilities', description: 'Rank agents by combined alert and vulnerability risk' },
    { label: 'Behavioral Baseline', query: 'establish behavioral baseline for critical agents', description: 'Establish normal behavior baselines for critical systems' },
  ],
};

// ─── System & Compliance Strategies ─────────────────────────────────────────

export const SYSTEM_STRATEGIES = {
  id: 'system-stats',
  name: 'System & Stats',
  label: 'System & Stats',
  icon: 'monitoringApp',
  strategies: [
    { label: 'Remoted Stats', query: 'show remoted stats', description: 'Wazuh remoted daemon statistics' },
    { label: 'Analysisd Stats', query: 'show analysisd stats', description: 'Wazuh analysisd daemon statistics' },
    { label: 'Cluster Health', query: 'show cluster health', description: 'Wazuh cluster health and node status' },
    { label: 'Manager Logs', query: 'show manager logs', description: 'Recent Wazuh manager log entries' },
  ],
};

export const COMPLIANCE_STRATEGIES = {
  id: 'compliance',
  name: 'Compliance',
  label: 'Compliance',
  icon: 'checkInCircleFilled',
  strategies: [
    { label: 'PCI-DSS Compliance', query: 'show {framework} compliance status', description: 'Check PCI-DSS compliance status across all agents', params: [{ key: 'framework', label: 'Framework', placeholder: 'PCI-DSS' }] },
    { label: 'HIPAA Compliance', query: 'show HIPAA compliance status', description: 'Check HIPAA compliance status across all agents' },
    { label: 'GDPR Compliance', query: 'show GDPR compliance status', description: 'Check GDPR compliance status across all agents' },
    { label: 'NIST Compliance', query: 'show NIST compliance status', description: 'Check NIST compliance status across all agents' },
  ],
};

// ─── Assembled Collections ──────────────────────────────────────────────────

/** All categories — used by CommandPalette for global search */
export const ALL_STRATEGY_CATEGORIES = [
  SIEM_AGENT_STRATEGIES,
  SIEM_ALERT_STRATEGIES,
  SIEM_ENDPOINT_STRATEGIES,
  NIDS_ALERT_STRATEGIES,
  NIDS_HUNTING_STRATEGIES,
  NIDS_NETWORK_STRATEGIES,
  VULN_STRATEGIES,
  CORRELATION_STRATEGIES,
  SYSTEM_STRATEGIES,
  COMPLIANCE_STRATEGIES,
];

/** SIEM module strategies (StrategyPanel format) */
export const SIEM_PANEL_STRATEGIES = [
  SIEM_AGENT_STRATEGIES,
  SIEM_ALERT_STRATEGIES,
  SIEM_ENDPOINT_STRATEGIES,
];

/** NIDS module strategies (StrategyPanel format) */
export const NIDS_PANEL_STRATEGIES = [
  { ...NIDS_ALERT_STRATEGIES, strategies: NIDS_ALERT_STRATEGIES.strategies.slice(0, 5) },
  NIDS_NETWORK_STRATEGIES,
  { ...NIDS_HUNTING_STRATEGIES, strategies: NIDS_HUNTING_STRATEGIES.strategies.filter(s => s.params) },
];
