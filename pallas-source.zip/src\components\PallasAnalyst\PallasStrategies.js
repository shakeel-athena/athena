/**
 * PallasStrategies — Single source of truth for all Pallas query strategies
 *
 * Mirrors plugin's quick-action surfaces (command-palette.tsx + per-page
 * chips in siem-tools.tsx, nids-tools.tsx, vulns-dashboard.tsx,
 * correlations.tsx) to ensure all query strings are LLM-tested and produce
 * proper responses.
 *
 * Each category has:
 *   - id:         Unique identifier (used by CommandPalette)
 *   - name:       Display name (used by StrategyPanel)
 *   - label:      Alias for CommandPalette display (defaults to name)
 *   - icon:       EUI icon type
 *   - strategies: Array of { label, query, description, params? }
 */

// ─── SIEM — Agents & Endpoints ──────────────────────────────────────────────
// Plugin command-palette.tsx category "SIEM — Agents & Endpoints" + per-page
// chips from siem-tools.tsx (Log Source Health, Agent Health param) + welcome
// card "Agent Status".

export const SIEM_AGENT_STRATEGIES = {
  id: 'siem-agents',
  name: 'Agents & Endpoints',
  label: 'SIEM — Agents & Endpoints',
  icon: 'compute',
  strategies: [
    { label: 'Agent Status', query: 'show all agents', description: 'View all monitored agents with status, OS, and last check-in' },
    { label: 'Active Agents', query: 'show active agents', description: 'View all active endpoint agents and their details' },
    { label: 'Disconnected Agents', query: 'show disconnected agents', description: 'Identify agents that have lost connectivity' },
    { label: 'Agent Health Check', query: 'check agent health status', description: 'Heartbeat, version, and connectivity status' },
    { label: 'Agent Health (per agent)', query: 'check agent {agent_id} health', description: 'Health status for a specific agent', params: [{ key: 'agent_id', label: 'Agent ID', placeholder: 'e.g. 011' }] },
    { label: 'OS Breakdown', query: 'show agent OS breakdown', description: 'Distribution of operating systems across agents' },
    { label: 'Event Volume by Agent', query: 'show event volume by agent', description: 'Alert and event count per endpoint' },
    { label: 'Full Agent Investigation', query: 'full investigation for agent {agent_id}', description: 'Deep dive into a specific agent', params: [{ key: 'agent_id', label: 'Agent ID', placeholder: 'e.g. 011' }] },
    { label: 'Open Ports', query: 'show ports for agent {agent_id}', description: 'Network ports and listening services', params: [{ key: 'agent_id', label: 'Agent ID', placeholder: 'e.g. 011' }] },
    { label: 'Running Processes', query: 'show processes for agent {agent_id}', description: 'Active processes and resource usage', params: [{ key: 'agent_id', label: 'Agent ID', placeholder: 'e.g. 011' }] },
    { label: 'Software Inventory', query: 'show inventory for agent {agent_id}', description: 'Installed packages and software', params: [{ key: 'agent_id', label: 'Agent ID', placeholder: 'e.g. 011' }] },
    { label: 'Log Source Health', query: 'show log source health', description: 'Health and status of log sources' },
    // FIM and SCA temporarily hidden — backend MCP tools not yet registered
    // { label: 'FIM Events', query: 'show FIM events', description: 'File integrity monitoring — recent file changes' },
    // { label: 'SCA Results', query: 'show SCA results', description: 'Security Configuration Assessment findings' },
  ],
};

// ─── SIEM — Alerts & Threat Hunting ─────────────────────────────────────────
// Plugin command-palette.tsx + Active Alerts (welcome) + Alert Patterns,
// Security Report (siem-tools chips).

export const SIEM_ALERT_STRATEGIES = {
  id: 'siem-alerts',
  name: 'Alerts & Threat Hunting',
  label: 'SIEM — Alerts & Threat Hunting',
  icon: 'securityAnalyticsApp',
  strategies: [
    // Log Analysis
    { label: 'Recent Alerts', query: 'show recent alerts', description: 'Latest security alerts across all agents' },
    { label: 'Active Alerts', query: 'show recent alert analysis', description: 'Recent alerts with severity breakdown and top triggered rules' },
    { label: 'Severity Breakdown', query: 'show alert summary', description: 'Alert distribution by severity level' },
    { label: 'Top Detection Rules', query: 'which rules trigger most frequently', description: 'Most frequently triggered detection rules' },
    { label: 'MITRE ATT&CK Coverage', query: 'show MITRE ATT&CK coverage', description: 'Tactic and technique mapping of alerts' },
    { label: 'Alert Timeline Trends', query: 'show alert timeline trends', description: 'Alert frequency patterns over time' },
    { label: 'Alert Patterns', query: 'analyze alert patterns', description: 'Detect recurring alert clusters and frequency anomalies' },
    { label: 'Rule Frequency Analysis', query: 'analyze rule frequency patterns', description: 'Detailed rule trigger frequency and trends' },
    // Threat Hunting
    { label: 'Brute Force Detection', query: 'detect brute force attacks', description: 'Authentication failure patterns and lockouts' },
    { label: 'Privilege Escalation', query: 'detect privilege escalation attempts', description: 'Unauthorized privilege elevation attempts' },
    { label: 'Suspicious PowerShell', query: 'detect suspicious PowerShell activity', description: 'Encoded commands, bypass flags, downloads' },
    { label: 'Lateral Movement', query: 'detect lateral movement indicators', description: 'Cross-host authentication and pivoting' },
    { label: 'Malware Alerts', query: 'show malware detection alerts', description: 'Malicious file and behavior detections' },
    { label: 'Auth Failure Analysis', query: 'detect brute force login failures', description: 'Failed login patterns across endpoints' },
    // Reports
    { label: 'Security Report', query: 'generate security report', description: 'Generate a full security report with findings and recommendations' },
  ],
};

// SIEM_ENDPOINT_STRATEGIES retained for backward-compatible imports.
// Active development uses SIEM_AGENT_STRATEGIES (which already covers ports,
// processes, inventory, log source health — matching plugin's combined
// "SIEM — Agents & Endpoints" category).
export const SIEM_ENDPOINT_STRATEGIES = {
  id: 'siem-endpoints',
  name: 'Endpoint Investigation',
  label: 'SIEM — Endpoint Investigation',
  icon: 'inspect',
  strategies: SIEM_AGENT_STRATEGIES.strategies.filter(s =>
    s.label === 'Open Ports' ||
    s.label === 'Running Processes' ||
    s.label === 'Software Inventory' ||
    s.label === 'Log Source Health'
  ),
};

// ─── NIDS — Alerts & Network ────────────────────────────────────────────────
// Plugin command-palette.tsx category "NIDS — Alerts & Network" — 12 items.

export const NIDS_ALERT_STRATEGIES = {
  id: 'nids-alerts',
  name: 'Alerts & Network',
  label: 'NIDS — Alerts & Network',
  icon: 'globe',
  strategies: [
    // Alert Triage
    { label: 'Recent IDS Alerts', query: 'show suricata alerts', description: 'Latest network intrusion detection alerts' },
    { label: 'Critical IDS Alerts', query: 'show critical suricata alerts', description: 'High-priority alerts requiring immediate attention' },
    { label: 'High Severity IDS Alerts', query: 'show high severity suricata alerts', description: 'Severity 1-2 alerts with threat context' },
    { label: 'IDS Alert Summary', query: 'show suricata alert summary', description: 'Aggregate alert statistics and trends' },
    { label: 'Category Breakdown', query: 'show suricata alert categories', description: 'Alerts grouped by classification category' },
    { label: 'IDS MITRE Mapping', query: 'show suricata MITRE mapping', description: 'Map IDS detections to MITRE techniques' },
    // Network Recon
    { label: 'Top Signatures', query: 'show top suricata signatures', description: 'Most frequently triggered IDS signatures' },
    { label: 'Top Attackers', query: 'show top suricata attackers', description: 'Source IPs generating the most alerts' },
    { label: 'Network Analysis', query: 'suricata network analysis', description: 'Traffic patterns and anomaly detection' },
    { label: 'HTTP Traffic', query: 'show HTTP traffic analysis', description: 'HTTP requests and suspicious web activity' },
    { label: 'TLS/SSL Analysis', query: 'TLS fingerprint analysis', description: 'Certificate and JA3/JA4 fingerprint analysis' },
    { label: 'Traffic Overview', query: 'show suricata traffic overview', description: 'Protocol distribution and volume analysis' },
  ],
};

// ─── NIDS — Advanced Hunting ────────────────────────────────────────────────

export const NIDS_HUNTING_STRATEGIES = {
  id: 'nids-hunting',
  name: 'Advanced Hunting',
  label: 'NIDS — Advanced Hunting',
  icon: 'securityAnalyticsApp',
  strategies: [
    { label: 'JA3 Fingerprints', query: 'show JA3 fingerprint analysis', description: 'TLS client fingerprinting for threat detection' },
    { label: 'JA4 Fingerprints', query: 'show JA4 fingerprint analysis', description: 'Next-gen TLS fingerprinting analysis' },
    { label: 'Suspicious Activity', query: 'detect suspicious suricata activity', description: 'Anomalous network behavior patterns' },
    { label: 'Flow Analysis', query: 'show suricata flow analysis', description: 'Network flow records and session data' },
    { label: 'Search IDS Alerts', query: 'search suricata alerts for {keyword}', description: 'Search alerts by keyword or signature', params: [{ key: 'keyword', label: 'Keyword', placeholder: 'e.g. CVE-2024, exploit, malware' }] },
    { label: 'Suricata Health', query: 'show suricata health status', description: 'IDS engine status and performance metrics' },
  ],
};

// NIDS_NETWORK_STRATEGIES retained for backward-compatible imports.
// Items duplicate entries already in NIDS_ALERT (Top Signatures, Top Attackers,
// Network Analysis) and NIDS_HUNTING (Suricata Health).
export const NIDS_NETWORK_STRATEGIES = {
  id: 'nids-network',
  name: 'Network Recon',
  label: 'NIDS — Network Recon',
  icon: 'globe',
  strategies: [
    { label: 'Top Signatures', query: 'show top suricata signatures', description: 'Most frequently triggered IDS signatures' },
    { label: 'Top Attackers', query: 'show top suricata attackers', description: 'Source IPs generating the most alerts' },
    { label: 'Network Analysis', query: 'suricata network analysis', description: 'Traffic patterns and anomaly detection' },
    { label: 'Health Status', query: 'show suricata health status', description: 'IDS engine status and performance metrics' },
  ],
};

// ─── Vulnerabilities ────────────────────────────────────────────────────────
// Plugin command-palette.tsx (12) + per-page additions from vulns-dashboard.tsx
// (Top Vulnerable Agents, Vulns by Agent, Compare by Status, Agent Posture
// Deep Dive).

export const VULN_STRATEGIES = {
  id: 'vulnerabilities',
  name: 'Risk Assessment',
  label: 'Vulnerabilities',
  icon: 'bug',
  strategies: [
    // Risk Assessment
    { label: 'Vulnerability Summary', query: 'show vulnerability summary', description: 'Overall vulnerability landscape and severity breakdown' },
    { label: 'Critical CVEs', query: 'show critical vulnerabilities', description: 'Critical severity vulnerabilities requiring immediate action' },
    { label: 'Vulnerability Trends', query: 'show vulnerability trends and distribution', description: 'Trend analysis and distribution patterns over time' },
    { label: 'Ranking by Agent', query: 'show vulnerability ranking by agent', description: 'Agents ranked by vulnerability count and severity' },
    { label: 'Top Vulnerable Agents', query: 'show top vulnerable agents', description: 'Agents with the most or most-critical vulnerabilities' },
    { label: 'Vulns by Agent', query: 'show vulnerabilities with agent details', description: 'Full vulnerability details per agent' },
    // Agent Exposure
    { label: 'Active + High Vulns', query: 'show active agents with high vulnerabilities', description: 'Active agents with unpatched high-severity CVEs' },
    { label: 'Disconnected + Critical', query: 'show disconnected agents with critical vulnerabilities', description: 'Unreachable agents with critical exposure' },
    { label: 'Compare by Status', query: 'compare vulnerabilities active vs disconnected', description: 'Compare vulnerability exposure across agent statuses' },
    { label: 'Port Exposure Risk', query: 'assess port exposure risk for all agents', description: 'Open ports that amplify vulnerability risk' },
    { label: 'Security Posture Deep Dive', query: 'comprehensive security posture analysis', description: 'Full vulnerability posture across all endpoints' },
    { label: 'Agent Posture Deep Dive', query: 'deep dive security posture for agent {agent_id}', description: 'Full security posture for a specific agent', params: [{ key: 'agent_id', label: 'Agent ID', placeholder: 'e.g. 011' }] },
    // Investigation
    { label: 'Exploit Correlation', query: 'correlate vulnerabilities with active exploits', description: 'Match CVEs against known exploit databases' },
    { label: 'CVE Lookup', query: 'show vulnerability summary for {cve_id}', description: 'Deep dive into a specific CVE', params: [{ key: 'cve_id', label: 'CVE ID', placeholder: 'e.g. CVE-2024-1234' }] },
    { label: 'Unpatched Systems', query: 'show vulnerabilities with active exploits', description: 'Systems missing critical security patches' },
    { label: 'Compliance Gaps', query: 'show vulnerability compliance gaps', description: 'Vulnerabilities violating compliance requirements' },
  ],
};

// ─── Correlations ───────────────────────────────────────────────────────────
// Plugin command-palette.tsx (10) + welcome card "Most At Risk Agents" +
// chip queries that differ from command-palette (Top Risk Agents, Wazuh +
// Suricata) take chip version since chips are the most recently tested surface.

export const CORRELATION_STRATEGIES = {
  id: 'correlations',
  name: 'Cross-Platform',
  label: 'Correlations',
  icon: 'layers',
  strategies: [
    // Full Stack
    { label: 'Security Posture Overview', query: 'comprehensive security posture analysis', description: 'Cross-platform security health across SIEM, NIDS, and vulnerabilities' },
    { label: 'Security Posture', query: 'comprehensive security posture', description: 'Comprehensive posture analysis combining alerts, vulns, and agents' },
    { label: 'IP Investigation', query: 'investigate IP {ip}', description: 'Cross-correlate an IP across alerts, network traffic, and vulnerabilities', params: [{ key: 'ip', label: 'IP Address', placeholder: 'e.g. 192.168.1.100' }] },
    { label: 'Cross-Platform Correlation', query: 'show combined alerts from all platforms', description: 'Unified view of alerts from Wazuh and Suricata' },
    { label: 'Dynamic Risk Scoring', query: 'calculate dynamic risk score for all agents', description: 'Composite risk score from alerts, vulns, and network activity' },
    // SIEM + NIDS
    { label: 'Alert + Network Correlation', query: 'correlate wazuh alerts with suricata alerts', description: 'Match endpoint alerts with network-level detections' },
    { label: 'Unified Threat Summary', query: 'show combined alert summary from all platforms', description: 'Combined threat landscape from both detection engines' },
    { label: 'Combined Scanning Detection', query: 'detect all scanning activity', description: 'Identify reconnaissance from both endpoint and network perspectives' },
    // SIEM + Vulnerabilities
    { label: 'Alert + Vuln Correlation', query: 'correlate active alerts with known vulnerabilities', description: 'Match triggered alerts against existing CVEs' },
    { label: 'Top Risk Agents', query: 'show top risk agents across alerts and vulnerabilities', description: 'Agents with highest combined alert + vulnerability exposure' },
    { label: 'Most At Risk Agents', query: 'most at risk agents', description: 'Agents ranked by risk score from alerts and vulnerabilities' },
    { label: 'Behavioral Baseline', query: 'establish behavioral baseline for critical agents', description: 'Normal vs anomalous behavior patterns for high-value endpoints' },
  ],
};

// ─── System & Stats ─────────────────────────────────────────────────────────
// Plugin command-palette.tsx — 4 items.

export const SYSTEM_STRATEGIES = {
  id: 'system-stats',
  name: 'System & Stats',
  label: 'System & Stats',
  icon: 'monitoringApp',
  strategies: [
    { label: 'Remoted Stats', query: 'show remoted stats', description: 'Remote daemon statistics' },
    { label: 'Analysisd Stats', query: 'show analysisd stats', description: 'Analysis daemon statistics' },
    { label: 'Cluster Health', query: 'show cluster health', description: 'Wazuh cluster status' },
    { label: 'Manager Logs', query: 'show manager logs', description: 'Recent manager log entries' },
  ],
};

// ─── Compliance ─────────────────────────────────────────────────────────────

export const COMPLIANCE_STRATEGIES = {
  id: 'compliance',
  name: 'Compliance',
  label: 'Compliance',
  icon: 'checkInCircleFilled',
  strategies: [
    { label: 'PCI-DSS Compliance', query: 'show {framework} compliance status', description: 'PCI-DSS compliance posture', params: [{ key: 'framework', label: 'Framework', placeholder: 'PCI-DSS' }] },
    { label: 'HIPAA Compliance', query: 'show HIPAA compliance status', description: 'HIPAA compliance posture' },
    { label: 'GDPR Compliance', query: 'show GDPR compliance status', description: 'GDPR compliance posture' },
    { label: 'NIST Compliance', query: 'show NIST compliance status', description: 'NIST compliance posture' },
  ],
};

// ─── Assembled Collections ──────────────────────────────────────────────────

/** All categories — used by CommandPalette for global Ctrl+K search.
 *  Mirrors plugin's command-palette.tsx category structure (8 categories).
 *  SIEM_ENDPOINT_STRATEGIES and NIDS_NETWORK_STRATEGIES are intentionally
 *  excluded — their items are duplicates of SIEM_AGENT and NIDS_ALERT
 *  respectively. They remain exported for backward-compatible imports. */
export const ALL_STRATEGY_CATEGORIES = [
  SIEM_AGENT_STRATEGIES,
  SIEM_ALERT_STRATEGIES,
  NIDS_ALERT_STRATEGIES,
  NIDS_HUNTING_STRATEGIES,
  VULN_STRATEGIES,
  CORRELATION_STRATEGIES,
  SYSTEM_STRATEGIES,
  COMPLIANCE_STRATEGIES,
];

/** SIEM module strategies (StrategyPanel format).
 *  SIEM_AGENT now contains all endpoint-level entries that used to be split
 *  into SIEM_ENDPOINT, matching plugin's combined category. */
export const SIEM_PANEL_STRATEGIES = [
  SIEM_AGENT_STRATEGIES,
  SIEM_ALERT_STRATEGIES,
];

/** NIDS module strategies (StrategyPanel format).
 *  Plugin combines Alert Triage + Network Recon into NIDS_ALERT — same here. */
export const NIDS_PANEL_STRATEGIES = [
  NIDS_ALERT_STRATEGIES,
  NIDS_HUNTING_STRATEGIES,
];
