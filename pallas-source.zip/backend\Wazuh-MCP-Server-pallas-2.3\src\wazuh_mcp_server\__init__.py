"""Wazuh MCP Server"""
__version__ = "2.0.1"
