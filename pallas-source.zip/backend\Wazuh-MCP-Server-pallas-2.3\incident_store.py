"""
Pallas Incident Store - OpenSearch CRUD for pallas-incidents index.
Manages incident lifecycle: acknowledge, ticket, block, close.
"""

import os
import uuid
import logging
from datetime import datetime, timezone
from typing import Optional, Dict, Any, List

import httpx

logger = logging.getLogger("pallas.incident_store")


class IncidentStore:
    """OpenSearch-backed incident state store for SOC workflow."""

    INDEX_NAME = "pallas-incidents"

    INDEX_MAPPING = {
        "mappings": {
            "properties": {
                "incident_id": {"type": "keyword"},
                "alert_id": {"type": "keyword"},
                "alert_source": {"type": "keyword"},
                "rule_id": {"type": "keyword"},
                "rule_description": {"type": "text"},
                "severity": {"type": "keyword"},
                "severity_num": {"type": "integer"},
                "source_ip": {"type": "ip", "ignore_malformed": True},
                "dest_ip": {"type": "ip", "ignore_malformed": True},
                "agent_id": {"type": "keyword"},
                "agent_name": {"type": "keyword"},
                "alert_timestamp": {"type": "date"},
                "status": {"type": "keyword"},
                "acknowledged_at": {"type": "date"},
                "acknowledged_by": {"type": "keyword"},
                "jira_ticket_id": {"type": "keyword"},
                "jira_ticket_url": {"type": "text"},
                "jira_created_at": {"type": "date"},
                "observability_completed": {"type": "boolean"},
                "observability_verdict": {"type": "keyword"},
                "observability_completed_at": {"type": "date"},
                "waf_blocked": {"type": "boolean"},
                "waf_blocked_at": {"type": "date"},
                "waf_blocked_ip": {"type": "ip", "ignore_malformed": True},
                "waf_error": {"type": "text"},
                "firewall_blocked": {"type": "boolean"},
                "firewall_blocked_at": {"type": "date"},
                "firewall_blocked_ip": {"type": "ip", "ignore_malformed": True},
                "firewall_error": {"type": "text"},
                "closed_at": {"type": "date"},
                "closed_by": {"type": "keyword"},
                "resolution_notes": {"type": "text"},
                "mttd_seconds": {"type": "float"},
                "mttr_seconds": {"type": "float"},
                "actions_log": {
                    "type": "nested",
                    "properties": {
                        "action": {"type": "keyword"},
                        "timestamp": {"type": "date"},
                        "actor": {"type": "keyword"},
                        "details": {"type": "text"},
                    }
                },
                "created_at": {"type": "date"},
                "updated_at": {"type": "date"},
            }
        }
    }

    def __init__(self):
        host = os.getenv("WAZUH_INDEXER_HOST", "localhost")
        port = int(os.getenv("WAZUH_INDEXER_PORT", "9200"))
        user = os.getenv("WAZUH_INDEXER_USER", "admin")
        password = os.getenv("WAZUH_INDEXER_PASS", "admin")

        self.base_url = f"https://{host}:{port}"
        self.auth = (user, password)
        self.client = httpx.AsyncClient(
            base_url=self.base_url,
            auth=self.auth,
            verify=False,
            timeout=15.0,
        )
        self._index_ensured = False

    async def _ensure_index(self):
        """Create pallas-incidents index if it doesn't exist."""
        if self._index_ensured:
            return
        try:
            resp = await self.client.head(f"/{self.INDEX_NAME}")
            if resp.status_code == 404:
                resp = await self.client.put(
                    f"/{self.INDEX_NAME}",
                    json=self.INDEX_MAPPING,
                )
                if resp.status_code in (200, 201):
                    logger.info(f"Created index '{self.INDEX_NAME}'")
                else:
                    logger.warning(f"Failed to create index: {resp.status_code} {resp.text}")
            self._index_ensured = True
        except Exception as e:
            logger.error(f"Index ensure failed: {e}")

    async def get_incident(self, alert_id: str) -> Optional[Dict[str, Any]]:
        """Get incident by alert_id. Returns None if not found."""
        await self._ensure_index()
        try:
            query = {
                "query": {"term": {"alert_id": alert_id}},
                "size": 1
            }
            resp = await self.client.post(
                f"/{self.INDEX_NAME}/_search",
                json=query,
            )
            if resp.status_code != 200:
                return None
            data = resp.json()
            hits = data.get("hits", {}).get("hits", [])
            if not hits:
                return None
            doc = hits[0]["_source"]
            doc["_doc_id"] = hits[0]["_id"]
            return doc
        except Exception as e:
            logger.error(f"Get incident failed: {e}")
            return None

    async def create_incident(self, alert_id: str, alert: Dict[str, Any], analyst_name: str) -> Dict[str, Any]:
        """Create or update incident with acknowledged status."""
        await self._ensure_index()

        existing = await self.get_incident(alert_id)
        now = datetime.now(timezone.utc).isoformat()

        if existing:
            # Already exists - return current state
            return existing

        # Parse alert timestamp for MTTD calculation
        alert_ts = alert.get("timestamp") or alert.get("alert_timestamp", "")
        mttd_seconds = None
        if alert_ts:
            try:
                if alert_ts.endswith("Z"):
                    alert_dt = datetime.fromisoformat(alert_ts.replace("Z", "+00:00"))
                else:
                    alert_dt = datetime.fromisoformat(alert_ts)
                if alert_dt.tzinfo is None:
                    alert_dt = alert_dt.replace(tzinfo=timezone.utc)
                mttd_seconds = (datetime.now(timezone.utc) - alert_dt).total_seconds()
            except Exception:
                pass

        incident_id = str(uuid.uuid4())
        doc = {
            "incident_id": incident_id,
            "alert_id": alert_id,
            "alert_source": alert.get("source", "unknown"),
            "rule_id": alert.get("rule_id", ""),
            "rule_description": alert.get("rule_description", ""),
            "severity": alert.get("severity", ""),
            "severity_num": alert.get("severity_num", 0),
            "source_ip": alert.get("source_ip", "") or None,
            "dest_ip": alert.get("dest_ip", "") or None,
            "agent_id": alert.get("agent_id", ""),
            "agent_name": alert.get("agent_name", ""),
            "alert_timestamp": alert_ts or now,
            "status": "acknowledged",
            "acknowledged_at": now,
            "acknowledged_by": analyst_name,
            "jira_ticket_id": None,
            "jira_ticket_url": None,
            "jira_created_at": None,
            "observability_completed": False,
            "observability_verdict": None,
            "observability_completed_at": None,
            "waf_blocked": False,
            "waf_blocked_at": None,
            "waf_blocked_ip": None,
            "waf_error": None,
            "firewall_blocked": False,
            "firewall_blocked_at": None,
            "firewall_blocked_ip": None,
            "firewall_error": None,
            "closed_at": None,
            "closed_by": None,
            "resolution_notes": None,
            "mttd_seconds": mttd_seconds,
            "mttr_seconds": None,
            "actions_log": [
                {
                    "action": "acknowledged",
                    "timestamp": now,
                    "actor": analyst_name,
                    "details": f"Alert acknowledged by {analyst_name}",
                }
            ],
            "created_at": now,
            "updated_at": now,
        }

        try:
            resp = await self.client.post(
                f"/{self.INDEX_NAME}/_doc",
                json=doc,
            )
            if resp.status_code in (200, 201):
                logger.info(f"Incident created: {incident_id} for alert {alert_id}")
            else:
                logger.error(f"Incident create failed: {resp.status_code} {resp.text}")
        except Exception as e:
            logger.error(f"Incident create exception: {e}")

        return doc

    async def update_incident(self, alert_id: str, updates: Dict[str, Any], action_log: Optional[Dict[str, Any]] = None) -> Optional[Dict[str, Any]]:
        """Update incident fields and optionally append to actions_log."""
        await self._ensure_index()

        existing = await self.get_incident(alert_id)
        if not existing:
            return None

        doc_id = existing.get("_doc_id")
        if not doc_id:
            return None

        now = datetime.now(timezone.utc).isoformat()
        updates["updated_at"] = now

        # Build update script for actions_log append
        if action_log:
            script = {
                "script": {
                    "source": "ctx._source.putAll(params.updates); ctx._source.actions_log.add(params.action_log)",
                    "params": {
                        "updates": updates,
                        "action_log": action_log,
                    }
                }
            }
        else:
            script = {"doc": updates}

        try:
            if action_log:
                resp = await self.client.post(
                    f"/{self.INDEX_NAME}/_update/{doc_id}",
                    json=script,
                )
            else:
                resp = await self.client.post(
                    f"/{self.INDEX_NAME}/_update/{doc_id}",
                    json={"doc": updates},
                )

            if resp.status_code in (200, 201):
                return await self.get_incident(alert_id)
            else:
                logger.error(f"Incident update failed: {resp.status_code} {resp.text}")
                return None
        except Exception as e:
            logger.error(f"Incident update exception: {e}")
            return None

    async def get_incidents_batch(self, alert_ids: List[str]) -> Dict[str, Dict[str, Any]]:
        """Get multiple incidents by alert_ids in a single query."""
        await self._ensure_index()
        if not alert_ids:
            return {}

        try:
            query = {
                "query": {"terms": {"alert_id": alert_ids}},
                "size": len(alert_ids),
            }
            resp = await self.client.post(
                f"/{self.INDEX_NAME}/_search",
                json=query,
            )
            if resp.status_code != 200:
                return {}

            data = resp.json()
            result = {}
            for hit in data.get("hits", {}).get("hits", []):
                doc = hit["_source"]
                doc["_doc_id"] = hit["_id"]
                result[doc["alert_id"]] = doc
            return result
        except Exception as e:
            logger.error(f"Batch get failed: {e}")
            return {}

