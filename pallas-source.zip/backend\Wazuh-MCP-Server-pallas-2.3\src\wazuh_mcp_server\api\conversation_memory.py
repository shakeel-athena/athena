"""
Conversation Memory — Multi-turn context for SOC Chat sessions.

Stores per-session conversation history with sliding window,
detects follow-up queries, and resolves references to previous results.
"""

import re
import logging
from dataclasses import dataclass, field
from datetime import datetime
from typing import Dict, Any, List, Optional, Tuple

logger = logging.getLogger(__name__)


@dataclass
class ConversationTurn:
    """One turn of conversation — what was asked, what was done, what was returned."""
    query: str
    timestamp: datetime
    tool_used: str
    entities: Dict[str, Any]
    result_summary: str
    result_type: str
    key_ids: List[str]
    record_count: int


class ConversationMemory:
    """Per-session conversation history with sliding window and TTL expiration."""

    def __init__(self, max_turns: int = 10, ttl_minutes: int = 30):
        self._sessions: Dict[str, List[ConversationTurn]] = {}
        self._timestamps: Dict[str, datetime] = {}
        self.max_turns = max_turns
        self.ttl_minutes = ttl_minutes

    def add_turn(self, session_id: str, turn: ConversationTurn):
        """Add a completed turn to session history."""
        self._cleanup_expired()
        if session_id not in self._sessions:
            self._sessions[session_id] = []
        self._sessions[session_id].append(turn)
        if len(self._sessions[session_id]) > self.max_turns:
            self._sessions[session_id] = self._sessions[session_id][-self.max_turns:]
        self._timestamps[session_id] = datetime.utcnow()

    def get_history(self, session_id: str) -> List[ConversationTurn]:
        """Get conversation history for session."""
        self._cleanup_expired()
        return self._sessions.get(session_id, [])

    def get_last_turn(self, session_id: str) -> Optional[ConversationTurn]:
        """Get most recent turn."""
        history = self.get_history(session_id)
        return history[-1] if history else None

    def get_context_summary(self, session_id: str) -> str:
        """Build a text summary of conversation history for LLM injection."""
        history = self.get_history(session_id)
        if not history:
            return ""
        lines = ["Previous conversation:"]
        for i, turn in enumerate(history[-5:], 1):
            ids_str = ", ".join(turn.key_ids[:5]) if turn.key_ids else "none"
            lines.append(
                f"  {i}. User asked: \"{turn.query}\" -> Tool: {turn.tool_used}, "
                f"Result: {turn.record_count} {turn.result_type}, "
                f"Key IDs: [{ids_str}]"
            )
        return "\n".join(lines)

    def get_carried_entities(self, session_id: str) -> Dict[str, Any]:
        """Get entities from the most recent turn."""
        last = self.get_last_turn(session_id)
        if not last:
            return {}
        return dict(last.entities)

    def _cleanup_expired(self):
        """Remove sessions older than TTL."""
        now = datetime.utcnow()
        expired = [
            sid for sid, ts in self._timestamps.items()
            if (now - ts).total_seconds() > self.ttl_minutes * 60
        ]
        for sid in expired:
            del self._sessions[sid]
            del self._timestamps[sid]
        if expired:
            logger.debug(f"[MEMORY] Cleaned up {len(expired)} expired sessions")


class ReferenceResolver:
    """Detect follow-up queries and resolve references to previous results."""

    FOLLOW_UP_PATTERNS = [
        r"^(which|what)\s+(of\s+)?(those|them|these)",
        r"^(show|check|get)\s+(their|its|the)\b",
        r"^(and|also|now)\s+(\w+\s+)?(show|check|get|list)",
        r"^(focus|filter|narrow)\s+(on|down|to)",
        r"^(more|details?|elaborate|explain)\b",
        r"^(for|about)\s+(the|those|these|them)",
        r"\b(the\s+same|those\s+same|from\s+above)\b",
        r"\b(that|those|them|these)\s+(agent|agents|host|hosts|cve|vulnerabilit|alert)",
    ]

    @classmethod
    def is_follow_up(cls, query: str) -> bool:
        """Detect if a query is a follow-up to a previous conversation."""
        q = query.lower().strip()
        return any(re.search(p, q) for p in cls.FOLLOW_UP_PATTERNS)

    @classmethod
    def resolve_references(
        cls,
        query: str,
        last_turn: Optional[ConversationTurn]
    ) -> Tuple[str, Dict[str, Any]]:
        """
        Resolve references in a follow-up query.

        Returns:
            (enriched_query, additional_entities)
        """
        if not last_turn:
            return query, {}

        additional_entities = {}

        # Carry forward agent_id from previous turn
        if last_turn.entities.get("agent_id"):
            additional_entities["agent_id"] = last_turn.entities["agent_id"]

        # Carry forward status from previous turn (for agent follow-ups)
        if last_turn.result_type == "agents" and last_turn.entities.get("status"):
            additional_entities["status"] = last_turn.entities["status"]

        # If previous turn returned a single agent, carry its ID
        if last_turn.result_type == "agents" and len(last_turn.key_ids) == 1:
            additional_entities["agent_id"] = last_turn.key_ids[0]

        # Carry forward severity from previous turn
        if last_turn.entities.get("severity"):
            additional_entities["severity"] = last_turn.entities["severity"]

        # Carry forward time_range
        if last_turn.entities.get("time_range"):
            additional_entities["time_range"] = last_turn.entities["time_range"]

        logger.info(f"[REFERENCE] Resolved entities from previous turn: {additional_entities}")
        return query, additional_entities

