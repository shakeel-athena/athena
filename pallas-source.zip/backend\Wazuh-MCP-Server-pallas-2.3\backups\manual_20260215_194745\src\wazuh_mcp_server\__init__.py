"""Wazuh MCP Server"""
__version__ = "4.0.3"
