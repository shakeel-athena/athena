# Pallas Response Display — UX/UI Redesign Plan

## Why This Document Exists

The current Pallas response rendering is **functionally correct but visually outdated**. Looking at the screenshots:

- Tables look like flat 2010 admin dashboard tables
- Status indicators are emoji-only (`🔴 Critical: 21 | 🟠 High: 188 | 🟡 Medium: 23990 | 🟢 Low: 2008`)
- Hero numbers like "26,207 alerts" are buried in plain markdown text instead of being visual focal points
- No progressive disclosure — everything dumps at once
- No animations during data reveal
- No interactivity (clicking an agent ID does nothing)
- Severity breakdowns shown as pipe-separated strings instead of visual bar charts
- The SOC Analysis section looks identical visually whether the LLM worked or fell back to the canned "service unreachable" message

Modern AI tools (Claude, ChatGPT, Perplexity, Cursor, GitHub Copilot Chat) handle response rendering very differently. They use a **block detection + specialized component** model where the renderer recognizes patterns in the AI output and swaps in purpose-built components for each pattern.

This document defines a complete redesign plan, organized in phases that can be shipped independently.

---

## Part 1 — Current State Analysis

### How responses flow today

```
Backend (server.py)
  ↓ (formats data into markdown text)
  ↓ {role, message: "<markdown>", warn: false}
WebSocket
  ↓
hooks/usePallas.js
  ↓ (parses out content, metadata, socAnalysis, suggestions)
PallasResponsePanel
  ├── MetadataBar (chips: query, tool, results count, time, match type)
  ├── PallasMarkdown (parses markdown text → React elements)
  │     ├── # / ## / ### → <h3>/<h4>/<h5>
  │     ├── | a | b |   → flat HTML <table>
  │     ├── - / *       → <ul>
  │     ├── 1.          → <ol>
  │     ├── ```         → <pre><code>
  │     ├── > quote     → <blockquote>
  │     ├── **bold**    → <strong>
  │     └── plain text  → <p>
  ├── SOCAnalysisSection (markdown again, in a colored card)
  └── SuggestionChips
```

### What the backend actually sends

From the screenshots, a typical response looks like:

```markdown
Security Report — Daily

Generated: 2026-04-11 19:24:20

Agent Overview
| Metric    | Count |
|-----------|-------|
| Total     | 49    |
| Active    | 4     |
| Disconnected | 42 |

Agent Health: 🔴 8% online
Warning: 42 agent(s) disconnected

Alert Summary (Last 24h)
Total Alerts: 26,207
🔴 Critical: 21 | 🟠 High: 188 | 🟡 Medium: 23990 | 🟢 Low: 2008

Vulnerability Summary
Total Vulnerabilities: 98,158
| Severity | Count |
|----------|-------|
| 🔴 Critical | 945 |
...

Recommendations
1. Investigate 42 disconnected agent(s) immediately
2. Review 21 critical-level alerts from the last 24 hours
...
```

The backend's `generate_security_report` tool builds this markdown server-side. It's literally pasting numbers into a template string.

### Why the current approach is limiting

| Limitation | Why it matters |
|---|---|
| **Pure markdown is lossy** | "26,207" inside a paragraph and "26,207" in a hero KPI card carry the same information but very different visual weight |
| **No semantic structure** | Renderer has no idea that the table is "agent list" vs. "vulnerability list" vs. "rule frequency" — they all get the same flat treatment |
| **No interaction layer** | Agent ID `011` is just text; in modern UX it should be a clickable pivot ("investigate this agent") |
| **No data binding** | A "severity breakdown" line `🔴 21 | 🟠 188 | 🟡 23990` should be a stacked bar chart with hover tooltips |
| **Loading states are generic** | The skeleton shows the same shimmer regardless of whether the response will be a table, prose, or KPIs |
| **Markdown emojis carry semantics** | `🔴` is the only thing telling you "critical" — replace with proper icon + label + color and accessibility improves |
| **No streaming** | Backend sends `stream: false` to Ollama, frontend waits until full response arrives → 10-30s of dead time |

### What the screenshots reveal about specific gaps

| Screenshot | Gap |
|---|---|
| **"show all agents"** | 49 agents in a flat table; 8% online is buried; no way to filter "disconnected" agents to investigate; "...and 38 more agents" should be a "Show all" button |
| **"show critical vulnerabilities"** | Long flat table; no severity grouping; no "patches available" call-to-action; CVE IDs not clickable; no NVD link |
| **"vulnerabilities with agent details"** | 98K rows with no aggregation; should default to "by agent" or "by package" view |
| **"generate security report"** | Hero numbers (26K alerts, 98K vulns) are paragraph text; should be 4-card KPI dashboard at the top |
| **"suricata network analysis"** | Top attackers + top targets shown as 2 separate flat tables; should be an interactive Sankey diagram or paired bar chart |
| **"suricata alert summary"** | Severity 1/2/3 with counts in a flat table; should be a stacked bar with click-to-filter |
| **"perform risk assessment"** | "Overall Risk: HIGH (Score 836)" is text; should be a giant gauge/dial with the score animated counting up |

---

## Part 2 — The Redesign Strategy

### Core idea: "Block detection" architecture

Replace the current pipeline:

```
markdown → PallasMarkdown → flat HTML
```

With a 2-stage pipeline:

```
markdown → Block Parser → [block1, block2, ...] → Block Renderer → specialized components
```

Where each block has a **type** that drives which component renders it:

| Block type | Detection rule | Renders as |
|---|---|---|
| `kpi_grid` | Lines like `Total X: NUMBER` followed by multiple sub-stats | Hero card grid with animated counters |
| `severity_breakdown` | Line containing `🔴 X \| 🟠 Y \| 🟡 Z \| 🟢 W` | Horizontal stacked bar with click-to-filter |
| `agent_table` | Markdown table with columns matching `agent_id, name, ip, status, ...` | Interactive agent card grid with status pills |
| `vulnerability_table` | Markdown table with columns matching `cve, severity, package, agent, ...` | Severity-grouped vulnerability list with NVD links |
| `rule_table` | Markdown table with columns matching `rule_id, level, description, ...` | Rule cards with level badges + tune actions |
| `top_attackers_table` | Markdown table with columns `source_ip, count` | Bar chart sorted descending |
| `risk_score_card` | Pattern `Risk Score: \d+` or `Overall Risk: (CRITICAL\|HIGH\|MEDIUM\|LOW)` | Gauge dial with animated needle |
| `recommendations_list` | `Recommendations` header followed by numbered list | Action cards with priority indicators |
| `code_block` | ` ``` ` fence | Existing code block + copy button + language badge |
| `prose` | Default fallback | Markdown text (existing renderer) |
| `health_status` | `Agent Health: 🔴 X%` pattern | Donut chart |
| `time_series_table` | Markdown table with column matching `timestamp` or `date` | Sparkline chart |
| `compliance_badges` | Block containing `pci_dss / hipaa / nist_800_53` keys | Compliance badge grid |
| `mitre_badges` | Block containing `mitre_tactic` / `mitre_technique` | MITRE ATT&CK chips with tooltip descriptions |
| `narrative_alert_card` | Single alert object with severity, source, description | Alert card with severity stripe + actions |

### Why this works

1. **Backwards compatible** — if no block matches, falls back to existing markdown renderer
2. **Independently shippable** — each block type can be added one at a time
3. **Server-friendly** — backend doesn't need to change formats; frontend just gets smarter at recognizing patterns
4. **Eventually replaceable** — once all common block types are recognized, we can ask the backend to send structured JSON instead of markdown for an even cleaner pipeline

### The detection layer

A new file: `src/components/PallasAnalyst/responseBlocks/BlockParser.js`

```javascript
// Pseudo-code
export function parseResponseBlocks(markdown) {
  const lines = markdown.split('\n');
  const blocks = [];
  let i = 0;

  while (i < lines.length) {
    // Try each detector in order; first match wins
    const block = 
         tryDetectKPIGrid(lines, i)
      || tryDetectSeverityBreakdown(lines, i)
      || tryDetectAgentTable(lines, i)
      || tryDetectVulnerabilityTable(lines, i)
      || tryDetectRuleTable(lines, i)
      || tryDetectTopAttackersTable(lines, i)
      || tryDetectRiskScoreCard(lines, i)
      || tryDetectRecommendationsList(lines, i)
      || tryDetectHealthStatus(lines, i)
      || tryDetectCodeBlock(lines, i)
      || tryDetectComplianceBadges(lines, i)
      || tryDetectMitreBadges(lines, i)
      || consumeProseUntilNextBlock(lines, i);

    blocks.push(block);
    i = block.endLine + 1;
  }

  return blocks;
}
```

Each detector returns either `null` (no match, try next) or `{ type, data, startLine, endLine }`.

### The render layer

```javascript
// In PallasMarkdown.js (or new ResponseBlockRenderer.js)
export function renderBlocks(blocks) {
  return blocks.map((block, i) => {
    switch (block.type) {
      case 'kpi_grid':            return <KPIGridBlock key={i} data={block.data} />;
      case 'severity_breakdown':  return <SeverityBreakdownBlock key={i} data={block.data} />;
      case 'agent_table':         return <AgentTableBlock key={i} data={block.data} />;
      case 'vulnerability_table': return <VulnerabilityTableBlock key={i} data={block.data} />;
      case 'rule_table':          return <RuleTableBlock key={i} data={block.data} />;
      case 'top_attackers':       return <TopAttackersBlock key={i} data={block.data} />;
      case 'risk_score':          return <RiskScoreBlock key={i} data={block.data} />;
      case 'recommendations':     return <RecommendationsBlock key={i} data={block.data} />;
      case 'health_status':       return <HealthStatusBlock key={i} data={block.data} />;
      case 'code_block':          return <CodeBlock key={i} data={block.data} />;
      case 'mitre_badges':        return <MITREBadgesBlock key={i} data={block.data} />;
      case 'compliance_badges':   return <ComplianceBadgesBlock key={i} data={block.data} />;
      case 'prose':
      default:                    return <PallasMarkdown key={i} content={block.raw} />;
    }
  });
}
```

---

## Part 3 — Component Specifications

### 3.1 KPIGridBlock

**Renders when:** Backend sends a "header" line like `## Agent Overview` or `## Alert Summary (Last 24h)` immediately followed by `Total X: NUMBER` patterns.

**Visual:**
```
┌──────────────────────────────────────────────────────────┐
│  ┌─────────┐  ┌─────────┐  ┌─────────┐  ┌─────────┐    │
│  │  ▣     │  │  ⚠     │  │  ⚡     │  │  ✓      │    │
│  │ 26,207 │  │   21   │  │  188   │  │ 23,990 │    │
│  │ ALERTS │  │CRITICAL│  │  HIGH  │  │ MEDIUM │    │
│  │ ▲ 12%  │  │ ▲ 4%   │  │ ▼ 8%   │  │ — 0%   │    │
│  └─────────┘  └─────────┘  └─────────┘  └─────────┘    │
│   ━━━━━━━━━ animated count up from 0 ━━━━━━━━━         │
└──────────────────────────────────────────────────────────┘
```

**Features:**
- **Animated counter** — number rolls from 0 to value over 600ms with easing
- **Trend arrow** — if metadata has `previous` or `delta`, shows ▲▼— with colored percentage
- **Severity-colored borders** — critical = red top border, high = orange, etc.
- **Hover lift** — card lifts 2px on hover with subtle shadow
- **Click action** — clicking a card fires a follow-up query (e.g., click "Critical 21" → "show me the 21 critical alerts")

**Backend signal needed:** None initially — frontend detects patterns. Eventually backend can send `meta.kpi_blocks: [{label, value, severity, click_query}]` for richer behavior.

### 3.2 SeverityBreakdownBlock

**Renders when:** Backend sends a line containing `🔴 N | 🟠 N | 🟡 N | 🟢 N` or `Critical: N, High: N, Medium: N, Low: N`.

**Visual:**
```
┌──────────────────────────────────────────────────────────┐
│  Severity Distribution                                    │
│                                                           │
│  ███████████████████░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░  │
│  ▓▓ Critical 21 (0.1%)  ▓▓ High 188 (0.7%)              │
│  ▓▓ Medium 23,990 (91.5%)  ▓▓ Low 2,008 (7.7%)         │
└──────────────────────────────────────────────────────────┘
```

**Features:**
- Horizontal **stacked bar** with proportional widths
- Each segment is **clickable** → fires a follow-up filter query
- Hover **tooltip** shows count + percentage
- **Animated fill** — segments slide in from left over 800ms
- Below the bar, a **legend** with the same colors

### 3.3 AgentTableBlock

**Renders when:** Backend sends a markdown table with columns matching agent fields.

**Visual:**
```
┌──────────────────────────────────────────────────────────┐
│  Agents (49)                            🔍 Filter ▾      │
│  ┌───────────────────────────────────────────────────┐  │
│  │ ● 011  test-sensor              ACTIVE  ●         │  │
│  │   172.16.49.71 · Ubuntu 24.04.4 · v4.14.3         │  │
│  │   Last seen: 2 minutes ago        [Investigate]   │  │
│  ├───────────────────────────────────────────────────┤  │
│  │ ● 004  test-athena-agent-rhel    DISCONNECTED ●  │  │
│  │   172.16.56.24 · RHEL 10.0 · v4.14.0              │  │
│  │   Last seen: 142 days ago         [Investigate]   │  │
│  └───────────────────────────────────────────────────┘  │
│  Showing 10 of 49   [ Show All ]   [ Group by OS ▾ ]    │
└──────────────────────────────────────────────────────────┘
```

**Features:**
- **Card-style rows** instead of HTML table cells
- Status indicator dot on the left (green/amber/red with subtle pulse for active)
- Collapsed metadata in a second line (IP, OS, version)
- **Relative timestamps** ("2 minutes ago") with absolute on hover
- **Investigate button** per row → fires `check agent X health`
- Status filter dropdown (All / Active / Disconnected / Never Connected)
- **Pagination** — show 10, then "Show All" button reveals the rest
- **Group by** dropdown (OS / Status / Agent group)
- Disconnected agents subtly **dimmed** (60% opacity)
- Sortable by clicking column area

### 3.4 VulnerabilityTableBlock

**Renders when:** Backend sends a table with CVE/severity/package columns.

**Visual:**
```
┌──────────────────────────────────────────────────────────┐
│  Vulnerabilities (98,158)                                 │
│                                                           │
│  Critical (945)  ▼                                        │
│  ┌───────────────────────────────────────────────────┐  │
│  │ ●● CVE-2025-68784                            🔗  │  │
│  │    kernel-tools-libs 6.12.0-55.34.1.el10_0       │  │
│  │    Affects: test-rhel-01 (agent 024)             │  │
│  │    Linux kernel UAF in xattr repair...           │  │
│  │    Detected: 2026-04-10        [View on NVD]     │  │
│  └───────────────────────────────────────────────────┘  │
│                                                           │
│  High (13,735)  ▶                                         │
│  Medium (71,042)  ▶                                       │
│  Low (6,322)  ▶                                           │
└──────────────────────────────────────────────────────────┘
```

**Features:**
- **Grouped by severity** with collapsible sections (Critical expanded by default)
- Each vulnerability is a card with:
  - **Severity dots** (●●●● = critical, ●●● = high, ●● = medium, ● = low)
  - CVE ID with **link icon** (clicks open NVD page)
  - Package name and version (mono font)
  - Affected agents (link to filter)
  - Brief description (truncated, expand on click)
  - Detected date (relative)
  - "View on NVD" button
- Search box at the top filters across all groups
- "Export CSV" button per group

### 3.5 RiskScoreBlock

**Renders when:** Backend sends `Risk Score: \d+` or `Overall Risk: (CRITICAL|HIGH|MEDIUM|LOW)`.

**Visual:**
```
┌──────────────────────────────────────────────────────────┐
│           Overall Risk Assessment                         │
│                                                           │
│              ┌─────────────────┐                          │
│              │       836       │  ← animated counter     │
│              │     /  1000     │                          │
│              │       HIGH      │  ← color = severity     │
│              └─────────────────┘                          │
│              ━━━━━━━━━━░░░░░░  ← gauge fill animation   │
│                                                           │
│  Risk Factors                                             │
│   • Total Agents: 49                                      │
│   • Disconnected: 42 (87.5%)                              │
│   • Monitoring Coverage: 14.3%                            │
└──────────────────────────────────────────────────────────┘
```

**Features:**
- **Big animated gauge** — needle sweeps from 0 to score over 1000ms
- **Color coding** — green (0-300), yellow (300-600), orange (600-800), red (800-1000)
- Score has subtle **glow effect** in the matching color
- Risk factors below as a clean bullet list
- Click the gauge → expand to full risk breakdown

### 3.6 HealthStatusBlock

**Renders when:** Backend sends `Agent Health: 🔴 X% online`.

**Visual:**
```
┌──────────────────────────────────────────────────────────┐
│  Infrastructure Health                                    │
│                                                           │
│         ╭──────╮         Active          4               │
│        ╱        ╲        Disconnected   42               │
│       │   8%    │        Never Conn.     2               │
│       │ ONLINE  │                                         │
│        ╲        ╱        ⚠ 87.5% offline                │
│         ╰──────╯                                          │
└──────────────────────────────────────────────────────────┘
```

**Features:**
- **Donut chart** with animated stroke fill
- Center percentage **counts up** from 0
- Legend on the right with counts and colors
- Warning indicator if any segment > 50% (e.g., disconnected dominant)

### 3.7 RecommendationsBlock

**Renders when:** Backend sends `## Recommendations` followed by numbered or bulleted list.

**Visual:**
```
┌──────────────────────────────────────────────────────────┐
│  Recommended Actions                                      │
│                                                           │
│  ┌──┐ #1   PRIORITY: CRITICAL                            │
│  │ 1│   Investigate 42 disconnected agent(s)              │
│  └──┘   Why this matters: Without these agents reporting,│
│         your visibility is at 14.3% — well below safe... │
│         [ Take Action ]    [ Defer ]                      │
│                                                           │
│  ┌──┐ #2   PRIORITY: HIGH                                 │
│  │ 2│   Review 21 critical-level alerts                   │
│  └──┘   ...                                               │
└──────────────────────────────────────────────────────────┘
```

**Features:**
- Each recommendation is a **card** with priority badge
- Numbered avatar on the left (gradient circle)
- Priority pill (CRITICAL/HIGH/MEDIUM/LOW) with severity color
- Optional "why this matters" description (LLM-generated, expandable)
- **Action buttons** per recommendation
- Fade-in stagger (each card 100ms after the previous)

### 3.8 TopAttackersBlock / TopTargetsBlock

**Renders when:** Backend sends a table with `(source_ip|src_ip)` and a count column.

**Visual:**
```
┌──────────────────────────────────────────────────────────┐
│  Top Source IPs (Potential Attackers)                     │
│                                                           │
│  185.135.180.81   ████████████████████████  9            │
│  13.107.226.21    ███████████████             5            │
│  52.15.108.142    ███████████████             5            │
│  52.15.108.54     ███████████████             5            │
│  52.15.108.198    ███████████████             5            │
│  ─────────────────────────────────────                   │
│         [ Sort by count ▼ ]  [ Investigate IP ]          │
└──────────────────────────────────────────────────────────┘
```

**Features:**
- **Horizontal bar chart** with proportional widths
- Click an IP → fires `investigate IP X` query
- Hover row → highlights and shows IP geolocation tooltip
- Sortable
- "Investigate" button per row

### 3.9 MITREBadgesBlock

**Renders when:** A block contains MITRE tactic/technique data (typically inside an alert card).

**Visual:**
```
MITRE ATT&CK
┌─────────────────────────────────────────────┐
│ [TA0001 Initial Access] [TA0007 Discovery]  │
│ [T1190 Exploit Public-Facing App]          │
│ [T1133 External Remote Services]            │
└─────────────────────────────────────────────┘
```

**Features:**
- Each tactic/technique is a **clickable chip** with the ATT&CK ID + name
- Hover shows **technique description** in tooltip (from local MITRE STIX bundle)
- Click opens MITRE ATT&CK Navigator URL in new tab

### 3.10 ComplianceBadgesBlock

**Renders when:** An alert/event contains `compliance.{pci_dss|hipaa|nist_800_53|gdpr|gpg13|tsc}` (this is the P5 fix from earlier).

**Visual:**
```
Compliance
┌─────────────────────────────────────────────┐
│ [PCI-DSS 10.2.5] [HIPAA 164.312.b]          │
│ [NIST AU.14] [NIST AC.7]                    │
│ [GDPR IV_32.2] [GPG13 7.8] [GPG13 7.9]     │
│ [TSC CC6.8] [TSC CC7.2] [TSC CC7.3]        │
└─────────────────────────────────────────────┘
```

**Features:**
- Color-coded by framework (PCI = blue, HIPAA = green, NIST = purple, etc.)
- Hover shows the **control description** in tooltip
- Click filters to "show me other alerts touching this control"

### 3.11 NarrativeAlertCard

**Renders when:** Inside the Attack Narrative module, each alert object becomes a card.

**Visual:**
```
┌──────────────────────────────────────────────────────────┐
│ ▌ CRITICAL              SURICATA           5m ago        │  ← severity stripe
│ ETPRO MALWARE Win32/Emotet CnC Beacon                    │
│                                                           │
│  Source: 192.168.1.42 → Dest: 185.220.101.5             │
│  Geo: 🇺🇸 → 🇩🇪 (Tor exit node)                          │
│                                                           │
│  [TA0011 C&C] [T1071 Application Layer Protocol]         │
│                                                           │
│  ──────────────────────────────────────                  │
│  ✨ Generate AI Narrative   📌 Pin   🔗 Investigate       │
└──────────────────────────────────────────────────────────┘
```

**Features:**
- **Severity stripe** on the left (4px tall, full height of card)
- Source / Suricata / Wazuh badge top right
- Relative timestamp
- Source → Dest with arrow and **GeoIP flags**
- MITRE chips inline
- AI Narrative generation button (if not yet generated)
- Pin / Investigate buttons

---

## Part 4 — Streaming + Loading States

### 4.1 Token-by-token reveal

Currently the backend sends `stream: false` to Ollama and the frontend only receives the response when it's fully complete. With streaming:

**Backend change** (`chat_handler.py`):
```python
async with httpx.AsyncClient() as client:
    async with client.stream(
        "POST", f"{ollama_host}/api/generate",
        json={"model": model, "prompt": prompt, "stream": True}
    ) as response:
        async for line in response.aiter_lines():
            chunk = json.loads(line)
            yield chunk["response"]  # send each token to WebSocket
```

**WebSocket protocol change:**
```javascript
// Old
{ role: "bot", message: "<full markdown>", warn: false }

// New
{ type: "chunk", text: "Generating " }
{ type: "chunk", text: "report" }
{ type: "chunk", text: "..." }
...
{ type: "complete", metadata: {...}, suggestions: [...] }
```

**Frontend change** (`usePallas.js`):
```javascript
ws.onmessage = (event) => {
  const msg = JSON.parse(event.data);
  if (msg.type === 'chunk') {
    setResponse(prev => ({
      ...prev,
      content: (prev?.content || '') + msg.text,
      isStreaming: true,
    }));
  } else if (msg.type === 'complete') {
    setResponse(prev => ({
      ...prev,
      metadata: msg.metadata,
      suggestions: msg.suggestions,
      isStreaming: false,
    }));
  }
};
```

**Visual effect:** Words appear typewriter-style as the LLM generates them, with a blinking cursor at the end. Block detection re-runs on every chunk so KPIs and tables "snap into place" the moment their data arrives.

### 4.2 Skeleton placeholders per section

Currently the loading skeleton is generic shimmer lines. With block-aware loading:

```
┌──────────────────────────────────────────────────────────┐
│  Generating Security Report...                           │
│                                                           │
│  ┌──────┐ ┌──────┐ ┌──────┐ ┌──────┐                     │
│  │ ░░░░ │ │ ░░░░ │ │ ░░░░ │ │ ░░░░ │  ← KPI shimmer    │
│  │ ░░░░ │ │ ░░░░ │ │ ░░░░ │ │ ░░░░ │                    │
│  └──────┘ └──────┘ └──────┘ └──────┘                     │
│                                                           │
│  ░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░  ← bar shimmer    │
│                                                           │
│  ┌─────────────────────────────────┐                     │
│  │ ░░░░░░░░░░░░░░░░░░░░░░░░░░░░  │  ← table shimmer   │
│  │ ░░░░░░░░░░░░░░░░░░░░░░░░░░░░  │                    │
│  │ ░░░░░░░░░░░░░░░░░░░░░░░░░░░░  │                    │
│  └─────────────────────────────────┘                     │
└──────────────────────────────────────────────────────────┘
```

The skeleton can be **predicted from the strategy name**. When `metadata.strategy === 'generate_security_report'`, we know it's going to have KPI cards + severity bars + tables → skeleton shows that layout.

### 4.3 Per-section reveal animation

When the response is complete (or as chunks arrive), each block fades in with a stagger:

```javascript
// Each block animates in with delay = index * 80ms
<div style={{
  animation: `pallas-fadeIn 0.4s ease ${idx * 80}ms backwards`,
}}>
  {renderBlock(block)}
</div>
```

The effect: KPIs pop in first (top of response), then tables slide in below, then SOC analysis fades in last. Feels responsive and intentional rather than dumping everything at once.

---

## Part 5 — Phased Rollout Plan

This redesign is significant. To avoid a big-bang rewrite, ship it in 6 phases. Each phase is independently deployable.

### **Phase R1 — Block Parser Foundation** (Backend untouched)

**Scope:**
- Create `src/components/PallasAnalyst/responseBlocks/` directory
- Implement `BlockParser.js` with detector functions for:
  - `kpi_grid`
  - `severity_breakdown`
  - `code_block`
  - `prose` (fallback)
- Implement `ResponseBlockRenderer.js` that wraps the existing `PallasMarkdown` for `prose` blocks
- Update `PallasResponsePanel` to use the new renderer
- All other block types fall through to the existing markdown renderer

**Effort:** 1 day
**Risk:** Low — additive only, falls through to existing code for unmatched patterns
**User-visible change:** Hero KPI cards + severity bar charts replace plain text. Everything else looks the same.
**Files touched:** 4 new files, 1 modified

---

### **Phase R2 — Smart Tables** (Backend untouched)

**Scope:**
- Add detectors:
  - `agent_table` (columns matching `agent_id|name|ip|status|...`)
  - `vulnerability_table` (columns matching `cve|severity|package|...`)
  - `top_attackers_table` (columns `source_ip|count`)
  - `rule_table` (columns `rule_id|level|description|...`)
- Build matching components:
  - `AgentTableBlock` — card grid with status pills + investigate buttons
  - `VulnerabilityTableBlock` — severity-grouped collapsible list with NVD links
  - `TopAttackersBlock` — horizontal bar chart
  - `RuleTableBlock` — rule cards with level badges
- Wire up click-to-pivot — clicking an agent fires `check agent X health`, etc.

**Effort:** 2-3 days
**Risk:** Low — table detection is conservative; fallback to flat markdown table if columns don't match
**User-visible change:** All major SOC tables become interactive cards. Click an agent ID to investigate it. Click a CVE for NVD.
**Files touched:** 4 new component files

---

### **Phase R3 — Risk + Health Visualizations** (Backend untouched)

**Scope:**
- Add detectors:
  - `risk_score_card`
  - `health_status` (donut)
  - `time_series` (sparklines for `daily/weekly` data)
- Build components:
  - `RiskScoreBlock` — animated gauge dial
  - `HealthStatusBlock` — donut chart
  - `SparklineBlock` — minimalist line chart for time series

**Effort:** 1-2 days
**Risk:** Low
**User-visible change:** Risk score becomes a hero gauge. Agent health becomes a donut. Time-series tables become sparklines.
**Files touched:** 3 new component files
**Library decision needed:** Use a small charting library (e.g., `react-charts-3` ~30KB, or hand-rolled SVG). Recommend **hand-rolled SVG** to keep bundle size minimal and match the existing dependency-free philosophy.

---

### **Phase R4 — MITRE + Compliance Badges** (Depends on backend P4/P5 fixes)

**Scope:**
- Add detectors:
  - `mitre_badges` — picks up the new `mitre_tactics` / `mitre_techniques` arrays from the P4 fix
  - `compliance_badges` — picks up the new `compliance.{pci_dss|hipaa|nist_800_53|gdpr|gpg13|tsc}` block from the P5 fix
- Build components:
  - `MITREBadgesBlock` with tooltips from a local MITRE STIX bundle
  - `ComplianceBadgesBlock` with framework-color coding
- Bundle a small MITRE ATT&CK lookup table (~50KB) for tooltip descriptions

**Effort:** 1-2 days
**Risk:** Low
**User-visible change:** Every alert with MITRE or compliance data shows a clickable chip row. Hover for descriptions.
**Files touched:** 2 new component files + 1 data file
**Dependency:** P4 and P5 backend fixes must be deployed first (already done locally, just needs server deploy)

---

### **Phase R5 — Streaming + Skeleton** (Backend changes required)

**Scope:**
- **Backend** (`chat_handler.py`):
  - Switch Ollama call from `stream: false` to `stream: True`
  - Yield each chunk to WebSocket as `{type: 'chunk', text: '...'}`
  - Send final `{type: 'complete', metadata, suggestions}` after generation finishes
- **Frontend** (`usePallas.js`):
  - Update WebSocket message handler to support both old single-message and new streaming protocols
  - Maintain `isStreaming` flag in response state
  - Re-run block parser on every chunk so structured blocks "snap in"
- **Frontend** (`ResponsePanel`):
  - Show blinking cursor at end of streaming text
  - Strategy-aware skeleton — when waiting, show layout matching the expected response shape
  - Block-by-block reveal animation with stagger

**Effort:** 2-3 days (split between backend + frontend)
**Risk:** Medium — touches both sides of the WebSocket protocol; needs careful backwards compatibility
**User-visible change:** Responses appear word-by-word like ChatGPT. Skeletons match the final shape.
**Files touched:** 1 backend file, 2 frontend files

---

### **Phase R6 — Polish, Animations, Dark Mode Refinement** (Frontend only)

**Scope:**
- **Number counters** — animate KPI numbers from 0 to value with easing
- **Card hover states** — subtle lift, glow on hover for clickable cards
- **Cascade fade-in** — blocks reveal with staggered animation
- **Severity-aware row coloring** — entire table rows tinted by severity
- **Empty state polish** — "0 disconnected agents" should show a green checkmark animation, not a 0
- **Tooltip system** — consistent tooltip component across all blocks
- **Responsive breakpoints** — block grid collapses gracefully on narrower screens
- **Loading state polish** — strategy-aware predictive skeletons

**Effort:** 2 days
**Risk:** Low — pure polish
**User-visible change:** Everything feels alive. Numbers tick up. Cards lift on hover. Loading feels intentional.
**Files touched:** All block components for animation refinements

---

## Part 6 — Total Effort + Sequencing

| Phase | Effort | Dependencies | User Impact |
|---|---|---|---|
| **R1** Block Parser + KPIs + Severity bars | 1 day | None | High — KPIs become hero, severity gets visual |
| **R2** Smart Tables | 2-3 days | R1 | Highest — tables become interactive |
| **R3** Risk + Health Visualizations | 1-2 days | R1 | Medium-High — risk score becomes hero |
| **R4** MITRE + Compliance Badges | 1-2 days | R1 + P4/P5 backend deploy | Medium — narrative cards become rich |
| **R5** Streaming + Skeleton | 2-3 days | R1, R2 | High — perceived responsiveness |
| **R6** Polish + Animations | 2 days | All above | Medium — everything feels alive |

**Total effort:** ~10-13 days for the full redesign, deliverable in 6 independent phases

**Recommended sequence:**
```
Week 1: R1 → R2  (foundational + biggest visual impact)
Week 2: R3 → R4  (visualizations + after backend fixes deployed)
Week 3: R5 → R6  (streaming + final polish)
```

---

## Part 7 — Architecture Decisions to Make Up Front

### Decision 1 — Hand-rolled SVG vs charting library?

**Options:**
- **Hand-rolled SVG** — 0 KB extra, full control, matches existing dependency-free philosophy
- **React-Vis / Recharts** — ~80-150 KB extra, faster to build, more chart types out of the box
- **D3 + custom React wrappers** — ~100 KB, max flexibility, steepest learning curve

**Recommendation:** **Hand-rolled SVG** for the basic blocks (donut, bar chart, sparkline, gauge). They're all simple shapes, and we keep the bundle lean. If we later need complex charts (heatmaps, treemaps, Sankey), pull in `react-vis` selectively.

### Decision 2 — Detect blocks on the frontend, or send structured data from backend?

**Options:**
- **Frontend-only detection** (Phase 1 approach) — backend keeps sending markdown, frontend detects patterns
  - Pro: Backend doesn't change, can ship immediately
  - Con: Detection is heuristic, can be wrong on edge cases
- **Backend sends structured JSON** (longer-term)
  - Pro: 100% reliable, smaller payload, easier testing
  - Con: Requires updating every MCP tool's response format

**Recommendation:** **Frontend detection now, backend structured later.** Phases R1-R6 all work with the current backend output. Once R1-R6 are in production, we can optionally add a `meta.blocks` field to responses to bypass detection — but it's not blocking.

### Decision 3 — Where do block components live?

Two options:
- `src/components/PallasAnalyst/responseBlocks/{KPIGridBlock.js, AgentTableBlock.js, ...}` (recommended)
- Inline inside `PallasMarkdown.js` (would balloon the file)

**Recommendation:** Separate folder. Each block component is its own file with its own detector + renderer + styles. Easier to test, easier to reason about, easier to A/B test.

### Decision 4 — How to handle the "fallback canned message" from the LLM 401?

When the LLM is down, the backend renders the canned "Automated analysis temporarily unavailable" block. Currently this is rendered identically to a real LLM response, which is misleading.

**Recommendation:** Add a detector for the fallback message text → render as a distinct **warning card** with:
- Yellow border instead of accent color
- "LLM Service Unavailable" header
- Link to operator documentation
- Optional "Retry" button (if backend returns retry-after)

This makes it visually obvious when AI augmentation is degraded vs working.

---

## Part 8 — Verification Plan Per Phase

### R1 verification
- Send a chat query "generate security report"
- ✅ Total Alerts (26K) renders as a KPI card with animated counter
- ✅ Severity breakdown line (`🔴 21 | 🟠 188 | ...`) renders as horizontal stacked bar
- ✅ Other markdown elements (tables, lists, code) render as before
- ✅ No regressions on existing chat queries

### R2 verification
- Send "show all agents"
- ✅ Agent table renders as cards, not flat HTML table
- ✅ Click an agent ID → fires `check agent {id} health` query
- ✅ Status filter dropdown works
- ✅ Send "show critical vulnerabilities"
- ✅ Vulnerabilities grouped by severity, click CVE opens NVD
- ✅ Send "suricata top attackers"
- ✅ Renders as horizontal bar chart, click IP fires `investigate IP {ip}`

### R3 verification
- Send "perform risk assessment"
- ✅ Risk score renders as animated gauge
- ✅ Send query that returns agent health %
- ✅ Health status renders as donut

### R4 verification
- After backend P4/P5 deployed: send any narrative query
- ✅ Wazuh alerts show compliance badges (PCI/HIPAA/etc)
- ✅ Suricata alerts show MITRE chips
- ✅ Hover any badge → tooltip with description
- ✅ Click MITRE chip → opens ATT&CK Navigator

### R5 verification
- Send any chat query
- ✅ Words appear typewriter-style as Ollama generates
- ✅ Loading skeleton matches the strategy's expected output shape
- ✅ Blocks "snap in" the moment their data is in the buffer
- ✅ Cancel button still works mid-stream

### R6 verification
- ✅ All KPI numbers count up from 0 to final value with easing
- ✅ All cards lift on hover
- ✅ Block reveal cascades top-to-bottom with stagger
- ✅ "0 disconnected agents" shows green check, not flat 0
- ✅ Tooltips consistent across all components
- ✅ Resize browser → grid collapses gracefully

---

## Part 9 — Risk Register

| Risk | Mitigation |
|---|---|
| Block detection misfires on edge cases | Always fall through to the existing markdown renderer if no block matches; never hide content |
| Backend changes break old clients during R5 streaming rollout | Send both old `{role, message}` AND new `{type: chunk}` formats during transition; deprecate old after 2 weeks |
| Chart library bloat | Hand-roll SVG for basic charts; only pull in libraries if we hit a chart type that's genuinely complex |
| MITRE STIX bundle is too large | Use a stripped-down JSON of just `{tactic_id, technique_id, name, short_description}` — should be ~50KB gzipped |
| Animations feel laggy on low-end devices | Use `transform` and `opacity` only (GPU-accelerated); no layout-thrashing properties; respect `prefers-reduced-motion` |
| Click-to-pivot creates query loops | Cap pivot depth; show a "back to previous" navigation in chat history |

---

## Part 10 — What This Replaces / What It Doesn't

### What this redesign DOES change

- ResponsePanel content rendering (currently `PallasMarkdown`)
- Loading skeleton (currently generic shimmer)
- Chat WebSocket protocol (R5 only)
- Visual treatment of KPIs, tables, severity, risk, MITRE, compliance, recommendations

### What this redesign does NOT change

- Welcome screen layout (owl logo, category tabs, quick action pills)
- Header bar (Browse, Standup, History, New Chat, tool icon buttons)
- Side modules (IOC, Decoder Lab, Attack Narrative) — they have their own UIs
- Daily Standup component
- Auth flow
- Backend MCP tools, AbuseIPDB integration, Wazuh/Suricata/Indexer queries
- Frontend → backend transport other than the streaming protocol change in R5

---

## Part 11 — Final Recommendation

Ship this in **2-3 sprint cycles** following the phase order:

**Sprint 1 (R1 + R2):** Block parser foundation + smart tables. **Biggest perceived improvement** — KPIs become hero, every table becomes interactive, click-to-pivot works.

**Sprint 2 (R3 + R4):** Visualizations + MITRE/compliance badges. Adds depth and SOC-specific richness. R4 requires the P4/P5 backend fixes to be deployed first.

**Sprint 3 (R5 + R6):** Streaming + polish. Brings the perceived responsiveness up to ChatGPT-level. R5 needs backend coordination but is mostly self-contained.

**Phase 1 (P1-P5 production bugs)** is still the prerequisite to all of this — there's no point in beautifying the response display while the LLM is broken. Fix the LLM token first, deploy the P1-P5 code fixes, then tackle this redesign.

---

## Awaiting User Decision

This document is a complete plan, not an implementation. Before I write any code:

1. **Approve the block-detection architecture** vs. an alternative approach
2. **Confirm chart strategy** — hand-rolled SVG or a library?
3. **Pick a starting phase** — R1 (foundation, recommended) or jump to a specific block type that's most painful right now
4. **Confirm backend coordination** — for R5 (streaming), I'll need to also touch `chat_handler.py` on the backend

Let me know your direction and I'll start implementing.

---

## Part 12 — Ageleia Theme Alignment (binding for ALL redesign work)

Source: `d:\Athena\Promochos\Main Branch\stages\version1.1.02\frontend\src\styles\enhanced-theme.css` + `dashboard-enhancements.css` + `index.css`. The redesign MUST use these tokens to feel like part of the same product as Ageleia.

### Current vs Ageleia — what to reuse and what to swap

| Token | Ageleia (production) | Pallas current | Action |
|---|---|---|---|
| BG dark | `#151519` | `#151519` | ✅ keep |
| BG deep | `#0E0E11` | `#0E0E11` | ✅ keep |
| Card | `#1D1E24` | `#1D1E24` | ✅ keep |
| Card hover | `#25262E` | `#25262E` | ✅ keep |
| Border | `#2A2B33` | `#2A2B33` | ✅ keep |
| Border light | `#35363F` | `#35363F` | ✅ keep |
| **Primary blue** | **`#3b82f6`** (Tailwind blue-500) | `#61a2ff` (cyan-blue) | ⚠️ **swap to Ageleia** |
| Primary dark | `#2563eb` | — | ⚠️ **add** |
| Primary light | `#60a5fa` | — | ⚠️ **add** |
| **Accent** | **`#8b5cf6`** (purple) | `#16c5c0` (cyan teal) | ⚠️ **swap to Ageleia** |
| **Success** | **`#10b981`** | `#24c292` | ⚠️ **swap to Ageleia** |
| Success dark | `#059669` | — | ⚠️ **add** |
| **Warning** | **`#f59e0b`** (amber) | `#dc6a13` (orange) | ⚠️ **swap to Ageleia** |
| Warning dark | `#d97706` | — | ⚠️ **add** |
| **Danger** | **`#ef4444`** | `#f6726a` (coral) | ⚠️ **swap to Ageleia** |
| Danger dark | `#dc2626` | — | ⚠️ **add** |
| Severity Critical | `#ef4444` | `#EF4444` | ✅ already aligned |
| Severity High | `#f97316` | `#F97316` | ✅ already aligned |
| Severity Medium | `#f59e0b` | `#F59E0B` | ✅ already aligned |
| Severity Low | `#64748b` | `#64748B` | ✅ already aligned |
| Status Active | `#10b981` | `#10B981` | ✅ already aligned |
| Body font | `Inter` (Google Fonts) | `Inter` | ✅ already aligned |
| Mono font | `JetBrains Mono` | (system mono) | ⚠️ **add JetBrains Mono** |

**Why this matters:** Pallas's current cyan-teal accent (`#16c5c0`) is friendly but doesn't match Ageleia's enterprise blue+purple feel. After swapping, KPI cards in Pallas will look like KPI cards in Ageleia — same gradients, same glows, same shadows — making them feel like one unified product.

### Ageleia signature gradients (use these in chart components)

```javascript
// In src/utils/theme.js — add these as exported helpers
export const GRADIENTS = {
  primary:   'linear-gradient(135deg, #3b82f6, #2563eb)',
  primaryHorizontal: 'linear-gradient(90deg, #3b82f6, #2563eb)',
  primaryAccent: 'linear-gradient(135deg, #3b82f6, #8b5cf6)',  // blue → purple (signature)
  success:   'linear-gradient(135deg, #10b981, #059669)',
  warning:   'linear-gradient(135deg, #f59e0b, #d97706)',
  danger:    'linear-gradient(135deg, #ef4444, #dc2626)',
  card:      'linear-gradient(145deg, rgba(29, 30, 36, 0.95), rgba(29, 30, 36, 0.85))',
  bgFull:    'linear-gradient(135deg, #151519 0%, #1D1E24 50%, #151519 100%)',
};
```

### Ageleia signature shadows + glows

```javascript
export const SHADOWS = {
  sm: '0 1px 2px 0 rgba(0, 0, 0, 0.3)',
  md: '0 4px 6px -1px rgba(0, 0, 0, 0.4), 0 2px 4px -1px rgba(0, 0, 0, 0.3)',
  lg: '0 10px 15px -3px rgba(0, 0, 0, 0.5), 0 4px 6px -2px rgba(0, 0, 0, 0.4)',
  xl: '0 20px 25px -5px rgba(0, 0, 0, 0.5), 0 10px 10px -5px rgba(0, 0, 0, 0.4)',
};

export const GLOWS = {
  primary: '0 0 20px rgba(59, 130, 246, 0.3)',
  success: '0 0 20px rgba(16, 185, 129, 0.3)',
  danger:  '0 0 20px rgba(239, 68, 68, 0.3)',
  warning: '0 0 20px rgba(245, 158, 11, 0.3)',
  accent:  '0 0 20px rgba(139, 92, 246, 0.3)',
};
```

### Ageleia card hover signature (every block component should match)

From `enhanced-theme.css:111-142`:

```css
/* The Ageleia card hover signature — apply to every block card */
.card {
  background: linear-gradient(145deg, rgba(29, 30, 36, 0.95), rgba(29, 30, 36, 0.85));
  border: 1px solid #2A2B33;
  border-radius: 12px;
  box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.4), 0 2px 4px -1px rgba(0, 0, 0, 0.3);
  position: relative;
  overflow: hidden;
  transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
}

/* Top accent bar appears on hover — blue→purple gradient */
.card::before {
  content: '';
  position: absolute;
  top: 0; left: 0; right: 0;
  height: 3px;
  background: linear-gradient(90deg, #3b82f6, #8b5cf6);
  opacity: 0;
  transition: opacity 0.3s;
}

.card:hover::before { opacity: 1; }

.card:hover {
  border-color: #3b82f6;
  box-shadow: 0 20px 25px -5px rgba(0, 0, 0, 0.5), 0 0 20px rgba(59, 130, 246, 0.3);
  transform: translateY(-4px);
}
```

**Use this exact pattern for every block component** (KPI cards, agent cards, vulnerability cards, recommendation cards). The `transform: translateY(-4px)` on hover plus the 3px accent bar appearing is the Ageleia signature interaction.

### Ageleia signature animations

| Animation | Where used | Code reference |
|---|---|---|
| `fadeIn` (translateY 20px → 0, opacity 0 → 1, 0.5s) | All cards on mount | `enhanced-theme.css:568-577` |
| Cascade stagger (`nth-child(n) { animation-delay: n*0.1s }`) | Lists/grids | `enhanced-theme.css:584-589` |
| `progressShine` (sliding white gradient overlay, 2s infinite) | Progress bars | `enhanced-theme.css:204-220` |
| `dangerGlow` / `warningGlow` (box-shadow pulse, 2s ease) | Severity badges | `dashboard-enhancements.css:42-66` |
| `statusPulse` (ring expansion, 2s) | "Live" / "Active" status dots | `dashboard-enhancements.css:128-154` |
| `bgPulse` (background gradient opacity, 20s) | Page background ambience | `enhanced-theme.css:64-67` |
| `countUp` (translateY 10px → 0, opacity, 0.5s) | KPI numbers on mount | `dashboard-enhancements.css:187-200` |
| `shine` (sliding white sheen, 1.5s on hover) | Metric cards | `dashboard-enhancements.css:74-98` |
| `mapPulse` (radial gradient breathe, 4s) | Map containers | `dashboard-enhancements.css:24-39` |
| `successSweep` (sliding green gradient, 2s) | Action success indicators | `dashboard-enhancements.css:226-247` |

**The redesign should reuse these exact animations** by porting them into PallasUI.js as keyframe constants, so visual rhythm matches Ageleia.

### Ageleia signature interactions

| Pattern | Where | Apply to Pallas |
|---|---|---|
| Card hover lift (`translateY(-4px)`) | Every panel, every card | Every block component |
| Accent bar reveal on hover (top 3px gradient) | Cards | Every block component header |
| Sliding sheen on hover (45deg white gradient) | Metric cards | KPI cards specifically |
| Border-left scale-Y on hover | Alert/vuln list items | Agent cards, vuln cards |
| Hover translate X+4px on list items | Alert items, vuln items | Agent cards, vuln cards |
| Status dot with pulsing ring | Active sensors | Active agent indicator |
| Progress bar with sliding shine | All progress bars | Severity stacked bar segments, gauges |

### Ageleia typography

```css
/* Body font — already in Pallas */
font-family: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', 'Roboto', sans-serif;

/* Mono font — needs to be added to Pallas */
font-family: 'JetBrains Mono', 'SFMono-Regular', Menlo, Monaco, Consolas, monospace;
```

**Action:** Add the Google Fonts import for JetBrains Mono to Pallas's `index.html` or `index.css`:
```html
<link href="https://fonts.googleapis.com/css2?family=JetBrains+Mono:wght@300;400;500;600&display=swap" rel="stylesheet">
```

Use JetBrains Mono for: CVE IDs, IP addresses, port numbers, agent IDs, hashes, code blocks, decoder XML, KPI numerics. **Don't** use it for everything — only for monospace-appropriate content.

### Ageleia title gradient text effect

From `enhanced-theme.css:281-289`:

```css
/* Used on .euiTitle — applies a subtle white-gradient gradient text effect */
font-weight: 700;
letter-spacing: -0.02em;
background: linear-gradient(135deg, #f8fafc, #cbd5e1);
-webkit-background-clip: text;
-webkit-text-fill-color: transparent;
background-clip: text;
```

**Apply to:** Block component titles ("VULNERABILITIES (98,158)", "TOP ATTACKERS", "INFRASTRUCTURE HEALTH"). It gives titles a subtle metallic / premium feel that matches Ageleia's enterprise dashboard aesthetic.

---

## Part 13 — Responsive Layout Strategy

The Pallas response panel currently sits inside the SOC Chat content area, which has variable width. Block components must adapt to:

| Breakpoint | Container width | Behavior |
|---|---|---|
| Wide (≥1280px) | ~700-900px | Default — KPI cards in 4-column grid, side-by-side bars |
| Medium (768-1279px) | ~600-700px | KPI cards in 2-column grid, charts stay full-width |
| Narrow (<768px) | <600px | KPI cards stack to 1-column, charts compress, agent cards full-width |
| Mini (<480px) | <480px | Hide secondary metadata, compress KPI labels, single-column everything |

### Responsive grid pattern for KPI cards

```javascript
// Use CSS Grid with auto-fit + minmax for responsive without media queries
const kpiGridStyle = {
  display: 'grid',
  gridTemplateColumns: 'repeat(auto-fit, minmax(180px, 1fr))',
  gap: 12,
  marginBottom: 16,
};
```

This **automatically reflows** from 4 columns → 2 columns → 1 column based on container width, no media queries needed. Same trick for vulnerability cards (`minmax(280px, 1fr)`) and agent cards (`minmax(320px, 1fr)`).

### Responsive table → card transition

For data tables, instead of horizontal scrolling on narrow screens (which is awful), **collapse the table into stacked cards**:

```javascript
// AgentTableBlock has two render modes
const useCardMode = containerWidth < 700;  // Detect via ResizeObserver

return useCardMode
  ? <AgentCardGrid agents={data.agents} />     // each agent as a card
  : <AgentTableGrid agents={data.agents} />;   // tabular layout
```

In card mode, each agent becomes a self-contained card:
```
┌────────────────────────────┐
│ ● 011 test-sensor          │
│ ACTIVE · 2 min ago         │
│ 172.16.49.71               │
│ Ubuntu 24.04.4 · v4.14.3   │
│ [Investigate]              │
└────────────────────────────┘
```

### Charts must scale with container

All hand-rolled SVG charts use `viewBox` + `preserveAspectRatio` so they scale perfectly:

```javascript
// HorizontalBarChart example
<svg
  viewBox="0 0 400 200"
  preserveAspectRatio="xMidYMid meet"
  style={{ width: '100%', height: 'auto', display: 'block' }}
>
  {/* bars use percentage-based widths */}
  <rect x="0" y={i * 30} width={`${pct}%`} height="20" fill={color} />
</svg>
```

The `width: 100%` + `height: auto` makes the chart fill its container while maintaining aspect ratio.

### Long content — graceful collapse

For long lists (50+ agents, 100+ vulnerabilities), default to showing 8-10 items + a "Show all (N)" button. **Never** dump 945 cards onto the screen at once.

```javascript
const VISIBLE_LIMIT = 10;
const [showAll, setShowAll] = useState(false);

const visible = showAll ? data : data.slice(0, VISIBLE_LIMIT);
const hidden = data.length - VISIBLE_LIMIT;

return (
  <>
    {visible.map(item => <Card key={item.id} {...item} />)}
    {!showAll && hidden > 0 && (
      <button onClick={() => setShowAll(true)}>
        Show {hidden} more
      </button>
    )}
  </>
);
```

### Container-aware via ResizeObserver

Some block components need to know their container width to pick the right layout. Use a hook:

```javascript
// hooks/useContainerWidth.js
import { useState, useEffect, useRef } from 'react';

export function useContainerWidth() {
  const ref = useRef(null);
  const [width, setWidth] = useState(0);

  useEffect(() => {
    if (!ref.current) return;
    const observer = new ResizeObserver(([entry]) => {
      setWidth(entry.contentRect.width);
    });
    observer.observe(ref.current);
    return () => observer.disconnect();
  }, []);

  return [ref, width];
}
```

Usage in `AgentTableBlock`:
```javascript
const [containerRef, width] = useContainerWidth();
const useCardMode = width > 0 && width < 700;

return (
  <div ref={containerRef}>
    {useCardMode ? <AgentCardGrid /> : <AgentTableGrid />}
  </div>
);
```

### Responsive typography

| Element | Wide (≥1280px) | Medium | Narrow (<768px) |
|---|---|---|---|
| Block title | 18px | 16px | 15px |
| KPI number | 36px | 30px | 26px |
| KPI label | 11px | 10px | 10px |
| Card body text | 13px | 13px | 12px |
| Metadata | 11px | 10px | 10px |
| Severity dots | 6px | 5px | 5px |

Use `clamp()` for fluid typography where it makes sense:
```css
font-size: clamp(26px, 4vw, 36px);  /* fluid KPI numbers */
```

### Tested target containers

The block components must look correct in **3 specific Pallas contexts**:

1. **Inside SOC Chat ResponsePanel** (~700px max-width centered)
2. **Inside Daily Standup view** (full width minus sidebar, ~900px)
3. **Inside Threat Intel / Decoder Lab tool views** (~700px centered, smaller header above)

Build a Storybook-like test page that renders each block at 480px / 700px / 900px / 1280px widths so we catch layout breaks before deploying.

---

## Part 14 — Implementation Steps (Updated with Theme + Responsive)

The phased plan from Part 5 is unchanged in scope, but each phase now also has theme + responsive sub-tasks:

### R1 (Block Parser + KPIs + Severity bars)
- ✅ Create `BlockParser.js`
- ✅ Create `responseBlocks/` folder
- ✅ Build `KPIGridBlock` using **Ageleia gradient backgrounds**, **Ageleia card hover signature** (translateY -4px, top 3px accent bar), **Ageleia countUp animation**
- ✅ Build `SeverityBreakdownBlock` using **Ageleia progress bar shine animation**
- ✅ Use **CSS Grid with `repeat(auto-fit, minmax(180px, 1fr))`** for KPI grid responsiveness
- ✅ All charts use `viewBox` + `width: 100%` for SVG responsiveness

**Theme update:** Modify `src/utils/theme.js` to add Ageleia tokens (primary `#3b82f6`, accent `#8b5cf6`, gradients, shadows, glows). Existing components keep working because the old token names stay valid — new tokens are additive.

### R2 (Smart Tables)
- ✅ Build `AgentTableBlock` with **container-aware mode switch** (table mode at ≥700px, card mode below)
- ✅ Each card uses **Ageleia card hover signature**
- ✅ Active agents get **statusPulse animation** on the status dot
- ✅ Disconnected agents get 70% opacity dimming
- ✅ Vulnerability cards use **Ageleia cve-badge styling** (mono font, amber gradient)
- ✅ All long lists capped at 10 items + "Show all" button

### R3 (Risk + Health Visualizations)
- ✅ Risk score gauge uses **Ageleia gradient fills** (success → warning → danger color stops)
- ✅ Health donut uses **Ageleia successPulse** when healthy, **dangerGlow** when critical
- ✅ All charts use `viewBox` for responsive scaling

### R4 (MITRE + Compliance Badges)
- ✅ MITRE chips use **Ageleia threat-badge styling** (rounded, hover scale)
- ✅ Compliance chips use framework-color-coded gradients matching Ageleia palette

### R5 (Streaming + Skeleton)
- ✅ Skeleton shimmer uses **Ageleia progressShine animation**
- ✅ Block reveal cascade uses **Ageleia stagger pattern** (nth-child delay)
- ✅ Streaming cursor matches Ageleia primary color (#3b82f6) with glow

### R6 (Polish)
- ✅ All KPI numbers use **Ageleia countUp animation**
- ✅ All cards use **Ageleia fadeIn animation**
- ✅ Critical alerts get **dangerGlow pulse**
- ✅ Add JetBrains Mono Google Fonts import
- ✅ Title gradient text effect on all block headers
- ✅ Test rendering at 480px / 700px / 900px / 1280px container widths

---

## Part 15 — Theme File Migration

Before any redesign work begins, **update `src/utils/theme.js`** to be the unified Ageleia + Pallas token source. This is a **non-breaking** change because we keep all existing token names and only add new ones.

```javascript
// Updated src/utils/theme.js
export const THEME = {
  // ───── Backgrounds (unchanged from Pallas current) ─────
  bg:           '#151519',
  bgDeep:       '#0E0E11',
  card:         '#1D1E24',
  cardDark:     '#151519',
  cardSubtle:   '#1D1E24',
  cardHover:    '#25262E',

  // ───── Borders (unchanged) ─────
  border:       '#2A2B33',
  borderLight:  '#35363F',
  borderSubtle: '#1D1E24',
  borderFaint:  '#151519',

  // ───── Text (unchanged) ─────
  text:         '#ffffff',
  textBright:   '#e8f0ff',
  textSecondary:'#8e9fbc',
  textMuted:    '#5a6d8a',
  textFaint:    '#3d5070',
  textDisabled: '#2a3a54',

  // ───── ACCENT COLORS (Ageleia-aligned) ─────
  primary:      '#3b82f6',   // ⚠️ CHANGED from #61a2ff to Ageleia blue
  primaryDark:  '#2563eb',   // 🆕
  primaryLight: '#60a5fa',   // 🆕
  accent:       '#8b5cf6',   // ⚠️ CHANGED from #16c5c0 (cyan) to Ageleia purple
  accentDark:   '#7c3aed',   // 🆕
  success:      '#10b981',   // ⚠️ CHANGED from #24c292 to Ageleia green
  successDark:  '#059669',   // 🆕
  successLight: '#7de2d1',   // unchanged (legacy alias)
  danger:       '#ef4444',   // ⚠️ CHANGED from #f6726a (coral) to Ageleia red
  dangerDark:   '#dc2626',   // 🆕
  warning:      '#f59e0b',   // ⚠️ CHANGED from #dc6a13 (orange) to Ageleia amber
  warningDark:  '#d97706',   // 🆕
  warningYellow:'#fec514',   // unchanged

  // ───── Severity (already aligned) ─────
  sevCritical:  '#EF4444',
  sevHigh:      '#F97316',
  sevMedium:    '#F59E0B',
  sevLow:       '#64748B',

  // ───── Status (already aligned) ─────
  statusActive:       '#10B981',
  statusDisconnected: '#F59E0B',
  statusInactive:     '#6B7280',

  // ───── Glows (updated to match new accent colors) ─────
  primaryGlow:  '0 0 20px rgba(59, 130, 246, 0.3)',  // ⚠️ updated
  accentGlow:   '0 0 20px rgba(139, 92, 246, 0.3)',  // ⚠️ updated
  successGlow:  '0 0 20px rgba(16, 185, 129, 0.3)',  // ⚠️ updated
  dangerGlow:   '0 0 20px rgba(239, 68, 68, 0.3)',   // ⚠️ updated
  warningGlow:  '0 0 20px rgba(245, 158, 11, 0.3)',  // ⚠️ updated

  // ───── Shadows (Ageleia, 🆕) ─────
  shadowSm: '0 1px 2px 0 rgba(0, 0, 0, 0.3)',
  shadowMd: '0 4px 6px -1px rgba(0, 0, 0, 0.4), 0 2px 4px -1px rgba(0, 0, 0, 0.3)',
  shadowLg: '0 10px 15px -3px rgba(0, 0, 0, 0.5), 0 4px 6px -2px rgba(0, 0, 0, 0.4)',
  shadowXl: '0 20px 25px -5px rgba(0, 0, 0, 0.5), 0 10px 10px -5px rgba(0, 0, 0, 0.4)',

  // ───── Legacy Pallas (unchanged) ─────
  panelShadow:  '-8px 0 32px rgba(0, 0, 0, 0.6)',
  backdropBg:   'rgba(0, 0, 0, 0.5)',
};

// 🆕 Ageleia gradients
export const GRADIENTS = {
  primary:        'linear-gradient(135deg, #3b82f6, #2563eb)',
  primaryAccent:  'linear-gradient(135deg, #3b82f6, #8b5cf6)',
  primaryHorizontal: 'linear-gradient(90deg, #3b82f6, #2563eb)',
  success:        'linear-gradient(135deg, #10b981, #059669)',
  warning:        'linear-gradient(135deg, #f59e0b, #d97706)',
  danger:         'linear-gradient(135deg, #ef4444, #dc2626)',
  card:           'linear-gradient(145deg, rgba(29, 30, 36, 0.95), rgba(29, 30, 36, 0.85))',
  bgFull:         'linear-gradient(135deg, #151519 0%, #1D1E24 50%, #151519 100%)',
  cveBadge:       'linear-gradient(135deg, rgba(245, 167, 0, 0.3), rgba(245, 167, 0, 0.1))',
  titleText:      'linear-gradient(135deg, #f8fafc, #cbd5e1)',
};

// 🆕 Animation timings (consistent across all blocks)
export const TIMINGS = {
  fast:    '0.15s',
  base:    '0.3s',
  slow:    '0.5s',
  slowest: '0.8s',
  ease:    'cubic-bezier(0.4, 0, 0.2, 1)',
};

// AGELIA_COLORS legacy alias kept unchanged for backwards compat
export const AGELIA_COLORS = {
  background:    THEME.bg,
  panel:         THEME.card,
  panelDark:     THEME.cardDark,
  border:        THEME.border,
  borderLight:   THEME.borderLight,
  text:          THEME.text,
  textSecondary: THEME.textSecondary,
  textMuted:     '#94A3B8',
  primary:       THEME.primary,
  success:       THEME.success,
  successLight:  THEME.successLight,
  danger:        THEME.danger,
  warning:       THEME.warning,
  warningYellow: THEME.warningYellow,
  accent:        THEME.accent,
  accentGlow:    THEME.accentGlow,
  dangerGlow:    THEME.dangerGlow,
  warningGlow:   THEME.warningGlow,
  successGlow:   THEME.successGlow,
  primaryGlow:   THEME.primaryGlow,
};
```

### Risk: Existing Pallas components reference the old `accent: '#16c5c0'` (cyan teal) value

When we change `accent` from cyan teal to Ageleia purple, **everything that uses `THEME.accent`** will look different. Audit needed:

```bash
# Find all usages
grep -r "THEME.accent" pallas-app/src/
```

Most components use `THEME.accent` for hover states and active highlights — those will look just as nice in Ageleia purple as they did in cyan teal. But there are a few places (the SOC Chat module uses cyan teal as its module accent color in `MODULE_COLORS.chat.accent = '#16c5c0'`) that we should preserve as a separate "module accent" rather than the Ageleia accent.

**Decision:** Keep `MODULE_COLORS` independent of `THEME.accent`. Module accent colors stay as the per-module identity colors (chat=cyan, ioc=red, decoder=purple, narrative=violet). `THEME.accent` becomes the global Ageleia accent (purple), used for the redesigned response blocks. This separation lets the redesigned blocks feel like Ageleia while individual modules keep their identity colors.

---

## Part 16 — Final Recommendation (Updated)

Ship this in **3 sprints** following the phase order:

**Sprint 1:**
- **Theme migration** (R1 prerequisite) — update `theme.js` with Ageleia tokens, add `GRADIENTS`, `SHADOWS`, `GLOWS`, `TIMINGS` exports, add JetBrains Mono import
- **R1** — Block parser foundation + KPI cards + severity bars
- **R2** — Smart tables (agents, vulns, top attackers, rules)

**Sprint 2:**
- **R3** — Risk gauge + health donut + sparklines
- **R4** — MITRE + compliance badges (after backend P4/P5 deployed)
- **Responsive testing** at 480px / 700px / 900px / 1280px

**Sprint 3:**
- **R5** — Streaming + smart skeletons
- **R6** — Polish, animations, fluid typography

**Phase 1 (P1-P5 production bug fixes)** is still the prerequisite — no point beautifying responses while the LLM is broken and IP investigate returns wrong shape. Fix LLM token, deploy P1-P5, then start this redesign.

The result: Pallas response cards will be visually indistinguishable from Ageleia panels — same gradients, same hover lifts, same shadows, same animations, same fonts — making Pallas feel like a first-class part of the Athena platform instead of a bolt-on.
