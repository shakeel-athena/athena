/**
 * PallasResponsePanel — Structured response display panel
 *
 * Redesigned with module accent color support, improved visual hierarchy,
 * confidence gauge always visible, SOC Analysis as distinct card,
 * and better suggestion chips.
 *
 * Exports:
 *   - ResponsePanel (named + default) — main response display
 *   - ComparePanel (named) — side-by-side comparison of pinned responses
 */

import React, { useState, useEffect, useCallback, useMemo } from 'react';
import { EuiIcon, EuiToolTip } from '@elastic/eui';
import { THEME } from '../../utils/theme';
import { FONT } from './PallasUI';
import PallasMarkdown from './PallasMarkdown';
import ResponseBlockRenderer, { useSplitBlocks } from './responseBlocks/ResponseBlockRenderer';
import { useContainerWidth } from './responseBlocks/blockHelpers';

// ─── ConfidenceGauge ─────────────────────────────────────────────────────────

function ConfidenceGauge({ value, accent }) {
  const pct = Math.round((value || 0) * 100);
  const color = pct >= 90 ? THEME.success : pct >= 70 ? accent || THEME.sevMedium : THEME.sevHigh;

  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
      <div style={{
        width: 48,
        height: 4,
        borderRadius: 2,
        backgroundColor: THEME.border,
        overflow: 'hidden',
        flexShrink: 0,
      }}>
        <div style={{
          width: `${pct}%`,
          height: '100%',
          backgroundColor: color,
          borderRadius: 2,
          transition: 'width 0.4s ease',
        }} />
      </div>
      <span style={{
        fontSize: 11,
        color,
        fontWeight: 700,
        fontFamily: FONT.mono,
        minWidth: 28,
      }}>
        {pct}%
      </span>
    </div>
  );
}

// ─── Helpers ────────────────────────────────────────────────────────────────

function formatStrategy(s) {
  if (!s) return '—';
  const titleCased = s.replace(/_/g, ' ').replace(/\b\w/g, c => c.toUpperCase());
  // Pipe through whitelabelText so strategy slugs like `get_wazuh_running_agents`
  // render as "Get Endpoints Running Agents" in the user-visible block header,
  // matching the platform-neutral wording used everywhere else in the SPA.
  return whitelabelText(titleCased);
}

// ─── White-labeling ─────────────────────────────────────────────────────────
// Pure display-layer transform: rewrites vendor names in user-visible text
// to platform-neutral terms ("Endpoints" / "NIDS") so Pallas can speak to
// its generic capability without hardcoding a specific HIDS/NIDS vendor.
//
// Backend tool names, query strings, field paths, OpenSearch indexes,
// MITRE rendering, and routing logic are 100% UNCHANGED — the transform
// runs only on text being rendered.
//
// Two variants:
//   whitelabelToolName — for controlled inputs we render directly (tools
//     strip, badges). Case-insensitive replacement, output is lowercase to
//     match the existing "wazuh alerts + wazuh agents" → "endpoints alerts
//     + endpoints agents" rendering.
//   whitelabelText — for free-form LLM markdown / SOC analysis text. Only
//     matches CAPITALIZED forms (Wazuh / Suricata / WAZUH / SURICATA) so
//     lowercase identifiers in code blocks and field paths
//     (`wazuh.rule.id`, `get_wazuh_alerts`) are preserved.

function whitelabelToolName(text) {
  if (typeof text !== 'string') return text;
  return text
    .replace(/\bwazuh\b/gi, 'endpoints')
    .replace(/\bsuricata\b/gi, 'nids');
}

function whitelabelText(text) {
  if (typeof text !== 'string') return text;
  return text
    .replace(/\bWazuh\b/g, 'Endpoints')
    .replace(/\bWAZUH\b/g, 'ENDPOINTS')
    .replace(/\bSuricata\b/g, 'NIDS')
    .replace(/\bSURICATA\b/g, 'NIDS');
}

// Defensive metadata readers — backend can emit either the plugin shape
// (primary_tool / secondary_tools / execution_time_ms / selection_method) or
// the older SPA shape (tools.primary / execution_time). Read both.

function readTools(metadata) {
  if (!metadata) return '';
  const primary = metadata.primary_tool || metadata.tools?.primary;
  const secondary = metadata.secondary_tools || metadata.tools?.secondary || [];
  if (!primary) return '';
  return [primary, ...secondary]
    .filter(Boolean)
    .map(t => whitelabelToolName(
      String(t).replace(/^get_/, '').replace(/_/g, ' ')
    ))
    .join(' + ');
}

function readExecTime(metadata) {
  if (!metadata) return null;
  const ms = metadata.execution_time_ms;
  if (typeof ms === 'number') {
    return ms >= 1000 ? `${(ms / 1000).toFixed(1)}s` : `${Math.round(ms)}ms`;
  }
  const sec = metadata.execution_time;
  if (typeof sec === 'number') {
    return sec >= 1 ? `${sec.toFixed(1)}s` : `${Math.round(sec * 1000)}ms`;
  }
  return null;
}

const MATCH_TYPE_LABELS = {
  rule_regex:   { label: 'Pattern Match',  color: '#00D4C8' },
  rule_keyword: { label: 'Keyword Match',  color: '#4493F8' },
  llm:          { label: 'AI Interpreted', color: '#FFA600' },
  fallback:     { label: 'Fallback',       color: '#FF6B6B' },
};

function MatchTypePill({ method }) {
  if (!method) return null;
  const m = MATCH_TYPE_LABELS[method] || {
    label: String(method).replace(/_/g, ' '),
    color: THEME.textMuted,
  };
  return (
    <span style={{
      display: 'inline-block',
      padding: '1px 7px',
      borderRadius: 4,
      fontSize: 10,
      fontWeight: 700,
      color: m.color,
      backgroundColor: `${m.color}18`,
      border: `1px solid ${m.color}30`,
      letterSpacing: '0.04em',
      textTransform: 'uppercase',
      whiteSpace: 'nowrap',
    }}>
      {m.label}
    </span>
  );
}

// Single-line metadata strip — rendered inline in the header row.
// Shows: tools · results · execution time · correlation type
// (Strategy and Confidence are rendered separately in the header.)
function InlineMetaTags({ metadata, accent }) {
  if (!metadata) return null;
  const accentColor = accent || THEME.accent;
  const items = [];

  const tools = readTools(metadata);
  if (tools) {
    items.push(
      <span key="tool" style={{ display: 'inline-flex', alignItems: 'center', gap: 4, fontFamily: FONT.mono, fontSize: 10, color: THEME.textMuted, whiteSpace: 'nowrap' }}>
        <EuiIcon type="wrench" size="s" color={accentColor + '80'} />
        {tools}
      </span>
    );
  }
  if (metadata.results_count != null) {
    items.push(
      <span key="count" style={{ fontFamily: FONT.mono, fontSize: 10, color: THEME.textMuted, whiteSpace: 'nowrap' }}>
        {metadata.results_count} results
      </span>
    );
  }
  const execText = readExecTime(metadata);
  if (execText) {
    items.push(
      <span key="time" style={{ fontFamily: FONT.mono, fontSize: 10, color: THEME.textMuted, whiteSpace: 'nowrap' }}>
        {execText}
      </span>
    );
  }
  if (metadata.correlation_type) {
    items.push(
      <span key="corr" style={{ fontFamily: FONT.mono, fontSize: 10, color: THEME.textMuted, whiteSpace: 'nowrap' }}>
        {String(metadata.correlation_type).replace(/_/g, ' ')}
      </span>
    );
  }

  if (items.length === 0) return null;

  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: 8, flexWrap: 'wrap' }}>
      {items.map((item, i) => (
        <React.Fragment key={i}>
          {i > 0 && <span style={{ color: THEME.border, fontSize: 8 }}>·</span>}
          {item}
        </React.Fragment>
      ))}
    </div>
  );
}

// ─── SOCAnalysisSection ───────────────────────────────────────────────────────

// ─── SOC Analysis structured renderer ────────────────────────────────────────
// Parses the LLM's consistent section format and renders each as a distinct
// visual card instead of a wall of plain text.

const SOC_SECTIONS = [
  { key: 'assessment',     re: /^(?:Risk\s+)?Assessment\s*[:]/i,       icon: 'alert',          color: null },
  { key: 'findings',       re: /^Key\s+Findings\s*[:]/i,              icon: 'search',         color: THEME.primary },
  { key: 'threats',        re: /^Threat\s+Indicators?\s*[:]/i,        icon: 'securitySignal', color: THEME.danger },
  { key: 'actions',        re: /^Recommended\s+Actions?\s*[:]/i,      icon: 'wrench',         color: THEME.success },
  { key: 'priority',       re: /^Priority\s*[:]/i,                    icon: 'flag',           color: null },
];

const PRIORITY_COLORS = {
  critical: THEME.danger,
  high:     '#F97316',
  medium:   THEME.warning,
  low:      THEME.success,
};

function parseSOCSections(content) {
  if (!content) return [];
  const lines = content.split('\n');
  const sections = [];
  let current = null;

  for (const line of lines) {
    const trimmed = line.replace(/^\*{1,2}|\*{1,2}$/g, '').trim();
    if (!trimmed) {
      if (current) current.lines.push('');
      continue;
    }

    let matched = false;
    for (const sec of SOC_SECTIONS) {
      if (sec.re.test(trimmed)) {
        // Extract the text after the "Label:" prefix
        const afterColon = trimmed.replace(sec.re, '').trim();
        current = { ...sec, title: trimmed.split(':')[0].trim(), lines: [] };
        if (afterColon) current.lines.push(afterColon);
        sections.push(current);
        matched = true;
        break;
      }
    }
    if (!matched && current) {
      current.lines.push(line);
    } else if (!matched && !current) {
      // Content before any section — create an "overview" section
      current = { key: 'overview', icon: 'iInCircle', color: THEME.primary, title: 'Overview', lines: [line] };
      sections.push(current);
    }
  }
  return sections;
}

function SOCPriorityBanner({ text }) {
  const lower = text.toLowerCase();
  let level = 'medium';
  for (const k of ['critical', 'high', 'medium', 'low']) {
    if (lower.includes(k)) { level = k; break; }
  }
  const color = PRIORITY_COLORS[level] || THEME.warning;

  return (
    <div style={{
      display: 'flex',
      alignItems: 'center',
      gap: 10,
      padding: '10px 14px',
      borderRadius: 8,
      background: `${color}12`,
      border: `1px solid ${color}35`,
      boxShadow: `0 0 12px ${color}15`,
    }}>
      <div style={{
        width: 8, height: 8, borderRadius: '50%', background: color,
        boxShadow: `0 0 8px ${color}`, animation: 'pallas-breathe 2s ease-in-out infinite',
      }} />
      <span style={{ fontSize: 10, fontWeight: 800, textTransform: 'uppercase', letterSpacing: '0.06em', color }}>
        {level}
      </span>
      <span style={{ fontSize: 12, color: THEME.textSecondary, flex: 1 }}>
        {text.replace(/^Priority\s*[:]\s*/i, '').replace(/^(CRITICAL|HIGH|MEDIUM|LOW)\s*[-–—]\s*/i, '')}
      </span>
    </div>
  );
}

function SOCSectionCard({ section, accent }) {
  const accentColor = section.color || accent;
  const content = section.lines.join('\n').trim();
  if (!content) return null;

  // Priority gets a special banner treatment
  if (section.key === 'priority') {
    return <SOCPriorityBanner text={content} />;
  }

  // Extract bullet items for findings/threats/actions
  const bulletLines = [];
  const proseLines = [];
  for (const line of section.lines) {
    const t = line.trim();
    if (/^[-*•]\s+/.test(t) || /^\d+\.\s+/.test(t)) {
      bulletLines.push(t.replace(/^[-*•]\s+/, '').replace(/^\d+\.\s+/, ''));
    } else if (t) {
      proseLines.push(t);
    }
  }

  return (
    <div style={{
      padding: '10px 14px',
      borderRadius: 8,
      background: 'rgba(255,255,255,0.015)',
      border: `1px solid ${THEME.border}`,
      borderLeft: `3px solid ${accentColor}`,
    }}>
      {/* Section header */}
      <div style={{
        display: 'flex', alignItems: 'center', gap: 8, marginBottom: 8,
      }}>
        <EuiIcon type={section.icon} size="s" color={accentColor} />
        <span style={{
          fontSize: 11, fontWeight: 700, color: accentColor,
          textTransform: 'uppercase', letterSpacing: '0.04em',
        }}>
          {section.title}
        </span>
      </div>

      {/* Prose content */}
      {proseLines.length > 0 && (
        <div style={{ fontSize: 12, color: THEME.textSecondary, lineHeight: 1.6, marginBottom: bulletLines.length > 0 ? 8 : 0 }}>
          {proseLines.join(' ')}
        </div>
      )}

      {/* Bullet items */}
      {bulletLines.length > 0 && (
        <div style={{ display: 'flex', flexDirection: 'column', gap: 5 }}>
          {bulletLines.map((item, idx) => (
            <div key={idx} style={{ display: 'flex', gap: 8, alignItems: 'flex-start' }}>
              <span style={{
                width: 5, height: 5, borderRadius: '50%', background: accentColor,
                marginTop: 6, flexShrink: 0, opacity: 0.7,
              }} />
              <span style={{ fontSize: 12, color: THEME.text, lineHeight: 1.5 }}>
                {item}
              </span>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

function SOCAnalysisSection({ content, accent }) {
  if (!content) return null;
  const accentColor = accent || THEME.accent;
  const sections = parseSOCSections(content);

  return (
    <div style={{
      marginTop: 16,
      borderRadius: 10,
      overflow: 'hidden',
      border: `1px solid ${accentColor}30`,
      boxShadow: `0 0 24px ${accentColor}08, 0 4px 16px rgba(0,0,0,0.15)`,
    }}>
      {/* Top accent gradient bar */}
      <div style={{
        height: 3,
        background: `linear-gradient(90deg, ${accentColor}, ${THEME.primary}, ${accentColor}60)`,
      }} />

      {/* Header */}
      <div style={{
        display: 'flex', alignItems: 'center', gap: 10,
        padding: '10px 16px',
        background: `linear-gradient(135deg, ${accentColor}12, ${accentColor}04)`,
        borderBottom: `1px solid ${accentColor}18`,
      }}>
        <div style={{
          width: 28, height: 28, borderRadius: 8,
          background: `linear-gradient(135deg, ${accentColor}, ${accentColor}80)`,
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          flexShrink: 0, boxShadow: `0 0 12px ${accentColor}40`,
        }}>
          <EuiIcon type="securitySignal" size="s" color="#ffffff" />
        </div>
        <div style={{ display: 'flex', flexDirection: 'column' }}>
          <span style={{ fontSize: 12, fontWeight: 800, color: THEME.text, letterSpacing: '0.02em' }}>
            Pallas Intelligence Engine
          </span>
          <span style={{ fontSize: 9, fontWeight: 600, color: THEME.textMuted, textTransform: 'uppercase', letterSpacing: '0.06em' }}>
            SOC Threat Assessment
          </span>
        </div>
      </div>

      {/* Structured sections */}
      <div style={{
        padding: '12px 14px',
        background: `linear-gradient(180deg, ${accentColor}06, transparent)`,
        display: 'flex', flexDirection: 'column', gap: 10,
      }}>
        {sections.length > 0 ? (
          sections.map((sec, idx) => (
            <SOCSectionCard key={idx} section={sec} accent={accentColor} />
          ))
        ) : (
          // Fallback: render as plain markdown if no sections detected
          <PallasMarkdown content={content} />
        )}
      </div>
    </div>
  );
}

// ─── SuggestionChips ─────────────────────────────────────────────────────────

function SuggestionChips({ suggestions, onSuggestionClick, accent }) {
  const [hoveredIdx, setHoveredIdx] = useState(null);
  const accentColor = accent || THEME.accent;

  if (!suggestions || suggestions.length === 0) return null;

  return (
    <div style={{
      marginTop: 16,
      padding: '12px 14px',
      borderRadius: 8,
      background: `linear-gradient(135deg, rgba(255,255,255,0.02), ${accentColor}04)`,
      border: `1px solid ${THEME.border}`,
    }}>
      <div style={{
        display: 'flex',
        alignItems: 'center',
        gap: 6,
        marginBottom: 10,
      }}>
        <EuiIcon type="branch" size="s" color={accentColor} />
        <span style={{
          fontSize: 11,
          fontWeight: 700,
          color: THEME.textSecondary,
          textTransform: 'uppercase',
          letterSpacing: '0.04em',
        }}>
          Related queries
        </span>
      </div>
      <div style={{ display: 'flex', flexWrap: 'wrap', gap: 8 }}>
        {suggestions.map((suggestion, idx) => (
          <button
            key={idx}
            onClick={() => onSuggestionClick && onSuggestionClick(suggestion)}
            onMouseEnter={() => setHoveredIdx(idx)}
            onMouseLeave={() => setHoveredIdx(null)}
            style={{
              padding: '7px 14px',
              borderRadius: 20,
              border: `1px solid ${hoveredIdx === idx ? accentColor + '60' : accentColor + '25'}`,
              backgroundColor: hoveredIdx === idx ? accentColor + '12' : accentColor + '06',
              color: hoveredIdx === idx ? accentColor : THEME.textSecondary,
              fontSize: 12,
              fontWeight: 500,
              cursor: 'pointer',
              transition: 'all 0.15s ease',
              fontFamily: 'inherit',
              outline: 'none',
            }}
          >
            {suggestion}
          </button>
        ))}
      </div>
    </div>
  );
}

// ─── SkeletonBlock — pulsing placeholder card ──────────────────────────────────

function SkeletonBlock({ height = 48, borderRadius = 8, accent = THEME.primary, delay = 0 }) {
  return (
    <div style={{
      height,
      borderRadius,
      background: 'rgba(255,255,255,0.03)',
      border: `1px solid ${THEME.border}`,
      overflow: 'hidden',
      position: 'relative',
      animation: `pallas-fadeIn 0.4s ease both`,
      animationDelay: `${delay}s`,
    }}>
      <div style={{
        position: 'absolute',
        inset: 0,
        background: `linear-gradient(90deg, transparent 0%, ${accent}08 50%, transparent 100%)`,
        animation: 'pallas-sweep 2s ease-in-out infinite',
        animationDelay: `${delay}s`,
      }} />
    </div>
  );
}

// ─── LoadingSkeleton ──────────────────────────────────────────────────────────
// Self-driving: manages its own timer + auto-progresses through pipeline stages.
// No parent needs to pass elapsedSeconds or currentStage — it handles everything.
// Stage timing spread across 30s window (typical backend response takes 10-35s).
// Stages progress slower so the last step doesn't complete before the response arrives.

const PIPELINE_STAGES = [
  { icon: 'search',          label: 'Selecting strategy',   sub: 'Analyzing query intent...',         at: 0   },
  { icon: 'database',        label: 'Querying data',        sub: 'Fetching from Endpoints Indexer...',    at: 2   },
  { icon: 'link',            label: 'Correlating results',  sub: 'Cross-referencing data sources...',  at: 6   },
  { icon: 'editorCodeBlock', label: 'Formatting response',  sub: 'Building structured output...',     at: 12  },
  { icon: 'securitySignal',  label: 'SOC analysis',         sub: 'Running threat assessment...',       at: 18  },
  { icon: 'check',           label: 'Finalizing',           sub: 'Preparing response...',              at: 28  },
];

function LoadingSkeleton({ onCancel, accent, wide }) {
  const accentColor = accent || THEME.accent;
  const [elapsed, setElapsed] = useState(0);

  // Self-driving timer — ticks every 100ms for smooth progress
  useEffect(() => {
    const start = Date.now();
    const id = setInterval(() => {
      setElapsed((Date.now() - start) / 1000);
    }, 100);
    return () => clearInterval(id);
  }, []);

  // Determine current stage based on elapsed time
  let stageIdx = 0;
  for (let i = PIPELINE_STAGES.length - 1; i >= 0; i--) {
    if (elapsed >= PIPELINE_STAGES[i].at) {
      stageIdx = i;
      break;
    }
  }
  const stage = PIPELINE_STAGES[stageIdx];

  // Progress within current stage (0→1) for the sub-progress bar
  const nextAt = stageIdx < PIPELINE_STAGES.length - 1
    ? PIPELINE_STAGES[stageIdx + 1].at
    : PIPELINE_STAGES[stageIdx].at + 3;
  const stageProgress = Math.min(1, (elapsed - stage.at) / (nextAt - stage.at));

  return (
    <div style={{
      padding: '16px 0',
      animation: 'pallas-fadeIn 0.3s ease',
    }}>
      {/* Pipeline stages — horizontal stepper */}
      <div style={{
        display: 'flex',
        alignItems: 'center',
        gap: 0,
        marginBottom: 20,
      }}>
        {PIPELINE_STAGES.map((s, i) => {
          const isDone = i < stageIdx;
          const isActive = i === stageIdx;
          const color = isDone ? THEME.success : isActive ? accentColor : THEME.textMuted + '40';
          return (
            <React.Fragment key={i}>
              <div style={{
                display: 'flex',
                flexDirection: 'column',
                alignItems: 'center',
                gap: 5,
                flex: 1,
                opacity: isDone || isActive ? 1 : 0.35,
                transition: 'opacity 0.5s ease',
              }}>
                <div style={{
                  width: 30,
                  height: 30,
                  borderRadius: '50%',
                  background: isDone
                    ? THEME.success + '20'
                    : isActive
                      ? `linear-gradient(135deg, ${accentColor}30, ${accentColor}10)`
                      : 'rgba(255,255,255,0.04)',
                  border: `2px solid ${color}`,
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  flexShrink: 0,
                  animation: isActive ? 'pallas-glow 2s ease-in-out infinite' : 'none',
                  transition: 'all 0.4s ease',
                  boxShadow: isDone ? `0 0 8px ${THEME.success}40` : isActive ? `0 0 12px ${accentColor}30` : 'none',
                }}>
                  <EuiIcon
                    type={isDone ? 'check' : s.icon}
                    size="s"
                    color={isDone ? THEME.success : isActive ? accentColor : THEME.textMuted}
                  />
                </div>
                <span style={{
                  fontSize: 9,
                  fontWeight: isActive ? 700 : isDone ? 500 : 400,
                  color: isActive ? accentColor : isDone ? THEME.success : THEME.textMuted,
                  textAlign: 'center',
                  lineHeight: 1.2,
                  transition: 'color 0.4s ease',
                }}>
                  {s.label}
                </span>
              </div>
              {i < PIPELINE_STAGES.length - 1 && (
                <div style={{
                  flex: 0.5,
                  height: 2,
                  borderRadius: 1,
                  background: isDone ? THEME.success : THEME.border,
                  marginBottom: 18,
                  transition: 'background 0.5s ease',
                  position: 'relative',
                  overflow: 'hidden',
                }}>
                  {/* Animated fill for the connector between current → next */}
                  {isActive && (
                    <div style={{
                      position: 'absolute',
                      left: 0,
                      top: 0,
                      bottom: 0,
                      width: `${stageProgress * 100}%`,
                      background: `linear-gradient(90deg, ${accentColor}, ${accentColor}80)`,
                      borderRadius: 1,
                      transition: 'width 0.3s ease',
                    }} />
                  )}
                </div>
              )}
            </React.Fragment>
          );
        })}
      </div>

      {/* Active stage label + elapsed timer + cancel */}
      <div style={{
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'space-between',
        marginBottom: 14,
        padding: '8px 12px',
        borderRadius: 8,
        background: `${accentColor}08`,
        border: `1px solid ${accentColor}15`,
      }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
          <div style={{
            width: 6,
            height: 6,
            borderRadius: '50%',
            background: accentColor,
            animation: 'pallas-breathe 1.5s ease-in-out infinite',
          }} />
          <span style={{ fontSize: 12, color: THEME.text, fontWeight: 600 }}>
            {stage.label}
          </span>
          <span style={{ fontSize: 11, color: THEME.textMuted }}>
            — {stage.sub}
          </span>
        </div>
        <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
          <span style={{
            fontFamily: FONT.mono,
            fontSize: 11,
            color: THEME.textMuted,
            minWidth: 36,
            textAlign: 'right',
          }}>
            {elapsed.toFixed(1)}s
          </span>
          {onCancel && (
            <button
              onClick={onCancel}
              style={{
                padding: '4px 12px',
                borderRadius: 6,
                border: `1px solid ${THEME.border}`,
                backgroundColor: 'rgba(255,255,255,0.03)',
                color: THEME.textMuted,
                fontSize: 11,
                cursor: 'pointer',
                fontFamily: 'inherit',
                outline: 'none',
                transition: 'all 0.15s',
              }}
              onMouseEnter={(e) => {
                e.currentTarget.style.borderColor = '#F87171';
                e.currentTarget.style.color = '#F87171';
              }}
              onMouseLeave={(e) => {
                e.currentTarget.style.borderColor = THEME.border;
                e.currentTarget.style.color = THEME.textMuted;
              }}
            >
              Cancel
            </button>
          )}
        </div>
      </div>

      {/* Intelligence briefing skeleton — 3-row layout when wide */}
      <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
        {/* Row 1: Hero stats skeleton */}
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 10 }}>
          {[0, 1, 2, 3].map(i => (
            <SkeletonBlock key={i} height={56} borderRadius={10} accent={accentColor} delay={i * 0.1} />
          ))}
        </div>
        <SkeletonBlock height={20} borderRadius={6} accent={accentColor} delay={0.4} />

        {/* Row 2: Split layout skeleton (detail left + SOC right) */}
        {wide ? (
          <div style={{ display: 'grid', gridTemplateColumns: '3fr 2fr', gap: 14 }}>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
              <div style={{ display: 'grid', gridTemplateColumns: 'repeat(2, 1fr)', gap: 10 }}>
                {[0, 1, 2, 3].map(i => (
                  <SkeletonBlock key={i} height={72} borderRadius={10} accent={accentColor} delay={0.5 + i * 0.08} />
                ))}
              </div>
              <SkeletonBlock height={48} borderRadius={10} accent={accentColor} delay={0.8} />
            </div>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
              <SkeletonBlock height={36} borderRadius={10} accent={accentColor} delay={0.5} />
              <SkeletonBlock height={60} borderRadius={8} accent={accentColor} delay={0.6} />
              <SkeletonBlock height={60} borderRadius={8} accent={accentColor} delay={0.7} />
              <SkeletonBlock height={40} borderRadius={8} accent={accentColor} delay={0.8} />
            </div>
          </div>
        ) : (
          <>
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 10 }}>
              {[0, 1, 2, 3, 4, 5].map(i => (
                <SkeletonBlock key={i} height={72} borderRadius={10} accent={accentColor} delay={0.5 + i * 0.08} />
              ))}
            </div>
            <SkeletonBlock height={100} borderRadius={10} accent={accentColor} delay={1.0} />
          </>
        )}

        {/* Row 3: Chip skeleton */}
        <div style={{ display: 'flex', gap: 8 }}>
          {[0, 1, 2].map(i => (
            <SkeletonBlock key={i} height={28} borderRadius={14} accent={accentColor} delay={0.9 + i * 0.05} />
          ))}
        </div>
      </div>
    </div>
  );
}

// ─── Action Button ────────────────────────────────────────────────────────────

function ActionButton({ tooltip, iconType, onClick, active, accent }) {
  const [hovered, setHovered] = useState(false);
  const accentColor = accent || THEME.accent;

  return (
    <EuiToolTip content={tooltip} position="top">
      <button
        onClick={onClick}
        onMouseEnter={() => setHovered(true)}
        onMouseLeave={() => setHovered(false)}
        style={{
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          width: 26,
          height: 26,
          borderRadius: 5,
          border: `1px solid ${active || hovered ? accentColor + '40' : THEME.border}`,
          backgroundColor: active ? accentColor + '12' : hovered ? accentColor + '08' : 'transparent',
          cursor: 'pointer',
          transition: 'all 0.15s ease',
          flexShrink: 0,
          outline: 'none',
        }}
        aria-label={tooltip}
      >
        <EuiIcon
          type={iconType}
          size="s"
          color={active || hovered ? accentColor : THEME.textMuted}
        />
      </button>
    </EuiToolTip>
  );
}

// ─── ResponsePanel ────────────────────────────────────────────────────────────

function ResponsePanel({
  content,
  blocks,
  metadata,
  socAnalysis,
  suggestions,
  onSuggestionClick,
  isLoading,
  onCancel,
  onPin,
  isPinned,
  onRetry,
  warn,
  accent,
  // Loading state extras
  elapsedSeconds,
  currentStage,
}) {
  const [collapsed, setCollapsed] = useState(false);
  const [copied, setCopied] = useState(false);
  const accentColor = accent || THEME.accent;

  // Apply white-labeling to the user-visible response text. The raw `content`
  // and `socAnalysis` props are kept untouched in parent state; only the
  // display-layer derives the platform-neutral version below and feeds it
  // into every downstream renderer (markdown body, SOC analysis section,
  // copy-to-clipboard, export-to-md). Block parsing (KPI grids, tables, etc.)
  // uses the whitelabelled markdown too so any "Wazuh" / "Suricata" mentions
  // detected inside block titles get the same treatment.
  const displayContent     = useMemo(() => whitelabelText(content),     [content]);
  const displaySocAnalysis = useMemo(() => whitelabelText(socAnalysis), [socAnalysis]);

  // Intelligence Briefing layout hooks (must be called unconditionally)
  const [containerRef, containerWidth] = useContainerWidth();
  const { heroElement, detailElement, hasHero, hasDetail, hasAnyBlocks } = useSplitBlocks({
    markdown: displayContent,
    blocks,
    onPivot: onSuggestionClick,
  });
  const isWideLayout = containerWidth >= 1024;
  const hasSOC = !!displaySocAnalysis;

  const handleCopy = useCallback(() => {
    // Copy the whitelabelled version — the analyst is copying what they SEE.
    if (!displayContent) return;
    navigator.clipboard.writeText(displayContent).then(() => {
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    });
  }, [displayContent]);

  const handleExport = useCallback(() => {
    if (!displayContent) return;
    const strategy = metadata?.strategy || 'response';
    const timestamp = new Date().toISOString().slice(0, 19).replace(/:/g, '-');
    const filename = `pallas-${strategy}-${timestamp}.md`;

    let mdContent = displayContent;
    if (displaySocAnalysis) {
      mdContent += `\n\n---\n## SOC Analysis\n\n${displaySocAnalysis}`;
    }

    const blob = new Blob([mdContent], { type: 'text/markdown' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    a.click();
    URL.revokeObjectURL(url);
  }, [content, metadata, socAnalysis]);

  // Nothing to render
  if (!isLoading && !content) return null;

  return (
    <div ref={containerRef} style={{
      backgroundColor: THEME.card,
      borderRadius: 14,
      border: `1px solid ${THEME.border}`,
      overflow: 'hidden',
      boxShadow: `0 4px 24px rgba(0,0,0,0.25), 0 0 0 1px rgba(255,255,255,0.03) inset`,
      animation: 'pallas-fadeIn 0.25s ease',
      position: 'relative',
    }}>
      {/* Accent top gradient bar — thicker + more vibrant */}
      <div style={{
        height: 3,
        background: `linear-gradient(90deg, ${accentColor}, ${THEME.accent}, ${accentColor}50, transparent)`,
      }} />

      {/* ── Compact header: icon + title + inline meta + actions — ONE ROW ── */}
      <div style={{
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'space-between',
        padding: '8px 14px',
        borderBottom: `1px solid ${THEME.border}`,
        background: 'rgba(255,255,255,0.015)',
        gap: 8,
        minHeight: 0,
      }}>
        {/* Left side: icon + strategy name + inline meta */}
        <div style={{ display: 'flex', alignItems: 'center', gap: 8, minWidth: 0, flex: 1 }}>
          <div style={{
            width: 22,
            height: 22,
            borderRadius: 6,
            background: `linear-gradient(135deg, ${accentColor}25, ${accentColor}10)`,
            border: `1px solid ${accentColor}30`,
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            flexShrink: 0,
          }}>
            <EuiIcon type="machineLearningApp" size="s" color={accentColor} />
          </div>

          {/* Strategy name */}
          <span style={{
            fontSize: 12,
            fontWeight: 700,
            color: THEME.text,
            whiteSpace: 'nowrap',
            flexShrink: 0,
          }}>
            {metadata?.strategy ? formatStrategy(metadata.strategy) : 'Response'}
          </span>

          {/* Separator dot */}
          {metadata && <span style={{ color: THEME.border, fontSize: 10 }}>·</span>}

          {/* Inline metadata tags (tool + count + time + correlation) */}
          {!collapsed && <InlineMetaTags metadata={metadata} accent={accentColor} />}

          {/* Confidence gauge — inline with meta */}
          {metadata?.confidence != null && !collapsed && (
            <ConfidenceGauge value={metadata.confidence} accent={accentColor} />
          )}

          {/* Match type pill — selection method (Pattern / Keyword / AI / Fallback) */}
          {metadata?.selection_method && !collapsed && (
            <MatchTypePill method={metadata.selection_method} />
          )}
        </div>

        {/* Action buttons */}
        <div style={{ display: 'flex', gap: 3, flexShrink: 0 }}>
          <ActionButton
            tooltip={copied ? 'Copied!' : 'Copy response'}
            iconType={copied ? 'checkInCircleFilled' : 'copy'}
            onClick={handleCopy}
            active={copied}
            accent={accentColor}
          />
          <ActionButton
            tooltip="Export as .md"
            iconType="download"
            onClick={handleExport}
            accent={accentColor}
          />
          {onPin && (
            <ActionButton
              tooltip={isPinned ? 'Unpin response' : 'Pin for comparison'}
              iconType={isPinned ? 'pinFilled' : 'pin'}
              onClick={onPin}
              active={isPinned}
              accent={accentColor}
            />
          )}
          <ActionButton
            tooltip={collapsed ? 'Expand' : 'Collapse'}
            iconType={collapsed ? 'expand' : 'minimize'}
            onClick={() => setCollapsed(c => !c)}
            accent={accentColor}
          />
        </div>
      </div>

      {/* ── Content area — tighter padding, no separate MetadataBar ── */}
      {/* ── Content: Intelligence Briefing 3-Row Layout ── */}
      {!collapsed && (
        <div style={{ padding: '10px 14px 14px' }}>
          {isLoading ? (
            <LoadingSkeleton onCancel={onCancel} accent={accentColor} wide={isWideLayout} />
          ) : !isWideLayout || !hasSOC ? (
            /* ── NARROW / NO-SOC: single column (current behavior) ── */
            <>
              {hasAnyBlocks ? (
                <>
                  {heroElement}
                  {detailElement}
                </>
              ) : (
                <ResponseBlockRenderer markdown={displayContent} blocks={blocks} onPivot={onSuggestionClick} />
              )}
              {hasSOC && <SOCAnalysisSection content={displaySocAnalysis} accent={accentColor} />}
              {suggestions?.length > 0 && (
                <SuggestionChips suggestions={suggestions} onSuggestionClick={onSuggestionClick} accent={accentColor} />
              )}
              {warn && onRetry && (
                <RetryButton onClick={onRetry} accent={accentColor} />
              )}
            </>
          ) : (
            /* ── WIDE + HAS SOC: 3-row Intelligence Briefing ── */
            <>
              {/* Row 1: Hero stats — full width */}
              {hasHero && (
                <div style={{ marginBottom: 14 }}>
                  {heroElement}
                </div>
              )}

              {/* Row 2: Detail (left) + SOC Assessment (right, sticky) */}
              <div style={{
                display: 'grid',
                gridTemplateColumns: hasDetail ? '3fr 2fr' : '1fr',
                gap: 16,
                alignItems: 'start',
                marginBottom: 14,
              }}>
                {/* Left panel: detail blocks */}
                {hasDetail && (
                  <div style={{ minWidth: 0 }}>
                    {detailElement}
                  </div>
                )}

                {/* Right panel: Pallas Intelligence Engine — full height, no separate scroll */}
                <div style={{ alignSelf: 'start' }}>

                  <SOCAnalysisSection content={displaySocAnalysis} accent={accentColor} />
                </div>
              </div>

              {/* Row 3: Related queries — full width */}
              {suggestions?.length > 0 && (
                <SuggestionChips suggestions={suggestions} onSuggestionClick={onSuggestionClick} accent={accentColor} />
              )}
              {warn && onRetry && (
                <RetryButton onClick={onRetry} accent={accentColor} />
              )}
            </>
          )}
        </div>
      )}
    </div>
  );
}

// ─── RetryButton (extracted for reuse in both layouts) ───────────────────────

function RetryButton({ onClick, accent }) {
  return (
    <div style={{ marginTop: 14 }}>
      <button
        onClick={onClick}
        style={{
          display: 'inline-flex',
          alignItems: 'center',
          gap: 6,
          padding: '6px 16px',
          borderRadius: 6,
          border: `1px solid ${accent}`,
          backgroundColor: accent + '10',
          color: accent,
          fontSize: 12,
          fontWeight: 600,
          cursor: 'pointer',
          fontFamily: 'inherit',
          transition: 'all 0.15s ease',
          outline: 'none',
        }}
      >
        <EuiIcon type="refresh" size="s" color={accent} />
        Retry Query
      </button>
    </div>
  );
}

// ─── ComparePanel ─────────────────────────────────────────────────────────────

export function ComparePanel({ pinnedResponses, onClose, accent }) {
  const [leftIdx, setLeftIdx] = useState(0);
  const [rightIdx, setRightIdx] = useState(Math.min(1, pinnedResponses.length - 1));
  const accentColor = accent || THEME.accent;

  if (!pinnedResponses || pinnedResponses.length === 0) return null;

  const left = pinnedResponses[leftIdx];
  const right = pinnedResponses[rightIdx];

  return (
    <div style={{
      backgroundColor: THEME.bg,
      border: `1px solid ${THEME.border}`,
      borderRadius: 10,
      overflow: 'hidden',
      animation: 'pallas-fadeIn 0.25s ease',
    }}>
      {/* Header */}
      <div style={{
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'space-between',
        padding: '8px 14px',
        borderBottom: `1px solid ${THEME.border}`,
        backgroundColor: THEME.card,
      }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
          <EuiIcon type="layers" size="s" color={accentColor} />
          <span style={{
            fontSize: 11,
            fontWeight: 700,
            color: accentColor,
            textTransform: 'uppercase',
            letterSpacing: '0.05em',
          }}>
            Compare Responses
          </span>
          <span style={{ fontSize: 10, color: THEME.textMuted }}>
            ({pinnedResponses.length} pinned)
          </span>
        </div>
        <ActionButton tooltip="Close comparison" iconType="cross" onClick={onClose} accent={accentColor} />
      </div>

      {/* Selector rows */}
      <div style={{
        display: 'grid',
        gridTemplateColumns: '1fr 1fr',
        gap: 1,
        backgroundColor: THEME.border,
      }}>
        <SelectorRow
          label="Left"
          responses={pinnedResponses}
          selectedIdx={leftIdx}
          onSelect={setLeftIdx}
          accent={accentColor}
        />
        <SelectorRow
          label="Right"
          responses={pinnedResponses}
          selectedIdx={rightIdx}
          onSelect={setRightIdx}
          accent={THEME.primary}
        />
      </div>

      {/* Side-by-side panels */}
      <div style={{
        display: 'grid',
        gridTemplateColumns: '1fr 1fr',
        gap: 12,
        padding: 12,
      }}>
        <ResponsePanel {...left} onPin={undefined} isPinned={false} accent={accentColor} />
        <ResponsePanel {...right} onPin={undefined} isPinned={false} accent={THEME.primary} />
      </div>
    </div>
  );
}

function SelectorRow({ label, responses, selectedIdx, onSelect, accent }) {
  return (
    <div style={{
      backgroundColor: THEME.card,
      padding: '6px 10px',
      display: 'flex',
      alignItems: 'center',
      gap: 6,
      flexWrap: 'wrap',
    }}>
      <span style={{
        fontSize: 10,
        color: THEME.textMuted,
        fontWeight: 700,
        textTransform: 'uppercase',
        letterSpacing: '0.04em',
        marginRight: 2,
        flexShrink: 0,
      }}>
        {label}:
      </span>
      {responses.map((r, i) => {
        const isSelected = i === selectedIdx;
        return (
          <button
            key={i}
            onClick={() => onSelect(i)}
            style={{
              padding: '2px 10px',
              borderRadius: 4,
              border: `1px solid ${isSelected ? accent : THEME.border}`,
              backgroundColor: isSelected ? accent + '15' : 'transparent',
              color: isSelected ? accent : THEME.textMuted,
              fontSize: 11,
              fontWeight: isSelected ? 600 : 400,
              cursor: 'pointer',
              fontFamily: 'inherit',
              transition: 'all 0.15s ease',
              outline: 'none',
            }}
          >
            {r.metadata?.strategy ? formatStrategy(r.metadata.strategy) : `Response ${i + 1}`}
          </button>
        );
      })}
    </div>
  );
}

// ─── Exports ──────────────────────────────────────────────────────────────────

export { ResponsePanel };
export default ResponsePanel;
