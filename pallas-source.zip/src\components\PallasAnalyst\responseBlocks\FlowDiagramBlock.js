/**
 * FlowDiagramBlock — Network flow visualization (src → dst with metadata)
 *
 * Replaces flat tables of network flows with a directional flow diagram.
 * Each flow row shows:
 *   - Source IP (left, mono)
 *   - Optional source country flag / port
 *   - Animated arrow with protocol label
 *   - Destination IP (right, mono)
 *   - Bytes / packet count badge
 *   - Click on either IP fires `investigate IP X`
 *
 * Triggered when BlockParser detects a markdown table with src + dst IP columns
 * (HTTP traffic, flow analysis, port exposure queries).
 *
 * Data shape (from BlockParser):
 *   {
 *     title: 'Network Flow Analysis' | null,
 *     flows: [
 *       {
 *         src_ip: '192.168.1.42',
 *         src_port?: 49152,
 *         dst_ip: '13.107.226.20',
 *         dst_port?: 443,
 *         proto?: 'TCP' | 'UDP',
 *         bytes?: 12345,
 *         packets?: 23,
 *         action?: 'allowed' | 'blocked',
 *       },
 *       ...
 *     ]
 *   }
 */

import { useState } from 'react';
import { EuiIcon } from '@elastic/eui';
import { THEME, GRADIENTS, SHADOWS, TIMINGS } from '../../../utils/theme';
import { FONT } from '../PallasUI';
import { formatNumberCompact, useContainerWidth } from './blockHelpers';

// Breakpoints mirror EntityListBlock so all row-based blocks feel consistent.
// Narrow: single column. Tablet-ish: 2-col. Wide desktop: 2-col (flows need
// wider rows than agent cards, so we intentionally stop at 2).
function columnsFor(width) {
  if (width === 0) return 1;
  if (width >= 980) return 2;
  return 1;
}

function visibleCountFor(cols) {
  return cols >= 2 ? 16 : 8;
}

// ─── Color helpers ──────────────────────────────────────────────────────────

function actionColor(action) {
  const k = String(action || '').toLowerCase();
  if (k === 'blocked' || k === 'denied' || k === 'drop' || k === 'reject') return THEME.danger;
  if (k === 'allowed' || k === 'permit' || k === 'pass' || k === 'accept') return THEME.success;
  return THEME.primary;
}

function actionIcon(action) {
  const k = String(action || '').toLowerCase();
  if (k === 'blocked' || k === 'denied' || k === 'drop' || k === 'reject') return 'cross';
  if (k === 'allowed' || k === 'permit' || k === 'pass' || k === 'accept') return 'check';
  return 'sortRight';
}

function protoColor(proto) {
  const p = String(proto || '').toUpperCase();
  if (p === 'TCP') return THEME.primary;
  if (p === 'UDP') return THEME.accent;
  if (p === 'ICMP') return THEME.warning;
  return THEME.textMuted;
}

// ─── Single flow row ────────────────────────────────────────────────────────

function FlowRow({ flow, onPivot }) {
  const [hovered, setHovered] = useState(false);
  const aColor = actionColor(flow.action);
  const aIcon = actionIcon(flow.action);
  const pColor = protoColor(flow.proto);

  const clickable = typeof onPivot === 'function';
  const handleSrcClick = (e) => {
    e.stopPropagation();
    if (clickable && flow.src_ip) onPivot(`investigate IP ${flow.src_ip}`);
  };
  const handleDstClick = (e) => {
    e.stopPropagation();
    if (clickable && flow.dst_ip) onPivot(`investigate IP ${flow.dst_ip}`);
  };

  return (
    <div
      onMouseEnter={() => setHovered(true)}
      onMouseLeave={() => setHovered(false)}
      style={{
        display: 'grid',
        gridTemplateColumns: 'minmax(120px, 1fr) auto minmax(120px, 1fr) auto',
        alignItems: 'center',
        gap: 10,
        padding: '10px 12px',
        borderRadius: 8,
        background: hovered ? 'rgba(255,255,255,0.04)' : 'rgba(255,255,255,0.015)',
        border: `1px solid ${hovered ? `${aColor}40` : THEME.border}`,
        borderLeft: `3px solid ${aColor}`,
        marginBottom: 6,
        minWidth: 0,
        transition: `all ${TIMINGS.fast} ${TIMINGS.ease}`,
        boxShadow: hovered ? SHADOWS.md : 'none',
      }}
    >
      {/* Source */}
      <div style={{ display: 'flex', flexDirection: 'column', minWidth: 0 }}>
        <span
          onClick={clickable ? handleSrcClick : undefined}
          title={clickable ? `Click to investigate ${flow.src_ip}` : flow.src_ip}
          style={{
            fontFamily: FONT.mono,
            fontSize: 12,
            fontWeight: 700,
            color: clickable ? THEME.primary : THEME.text,
            cursor: clickable ? 'pointer' : 'default',
            borderBottom: clickable ? `1px dashed ${THEME.primary}50` : 'none',
            display: 'inline-block',
            whiteSpace: 'nowrap',
            overflow: 'hidden',
            textOverflow: 'ellipsis',
            transition: `color ${TIMINGS.fast} ${TIMINGS.ease}`,
          }}
          onMouseEnter={clickable ? (e) => { e.currentTarget.style.color = THEME.primaryLight; } : undefined}
          onMouseLeave={clickable ? (e) => { e.currentTarget.style.color = THEME.primary; } : undefined}
        >
          {flow.src_ip || '?'}
        </span>
        {flow.src_port != null && (
          <span style={{ fontSize: 9, color: THEME.textMuted, fontFamily: FONT.mono, marginTop: 1 }}>
            :{flow.src_port}
          </span>
        )}
      </div>

      {/* Arrow with protocol label */}
      <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 1, padding: '0 6px' }}>
        {flow.proto && (
          <span
            style={{
              fontSize: 8,
              fontWeight: 700,
              color: pColor,
              fontFamily: FONT.mono,
              padding: '1px 5px',
              borderRadius: 3,
              background: `${pColor}15`,
              border: `1px solid ${pColor}30`,
              letterSpacing: '0.04em',
              textTransform: 'uppercase',
            }}
          >
            {flow.proto}
          </span>
        )}
        <div style={{ position: 'relative', width: 36, height: 14, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
          <div
            style={{
              position: 'absolute',
              left: 0,
              right: 8,
              top: '50%',
              height: 1,
              background: `linear-gradient(90deg, transparent, ${aColor}, ${aColor})`,
              transform: 'translateY(-50%)',
            }}
          />
          <EuiIcon type={aIcon} size="s" color={aColor} style={{ position: 'absolute', right: -2, filter: `drop-shadow(0 0 4px ${aColor}80)` }} />
        </div>
      </div>

      {/* Destination */}
      <div style={{ display: 'flex', flexDirection: 'column', minWidth: 0 }}>
        <span
          onClick={clickable ? handleDstClick : undefined}
          title={clickable ? `Click to investigate ${flow.dst_ip}` : flow.dst_ip}
          style={{
            fontFamily: FONT.mono,
            fontSize: 12,
            fontWeight: 700,
            color: clickable ? THEME.primary : THEME.text,
            cursor: clickable ? 'pointer' : 'default',
            borderBottom: clickable ? `1px dashed ${THEME.primary}50` : 'none',
            display: 'inline-block',
            whiteSpace: 'nowrap',
            overflow: 'hidden',
            textOverflow: 'ellipsis',
            transition: `color ${TIMINGS.fast} ${TIMINGS.ease}`,
          }}
          onMouseEnter={clickable ? (e) => { e.currentTarget.style.color = THEME.primaryLight; } : undefined}
          onMouseLeave={clickable ? (e) => { e.currentTarget.style.color = THEME.primary; } : undefined}
        >
          {flow.dst_ip || '?'}
        </span>
        {flow.dst_port != null && (
          <span style={{ fontSize: 9, color: THEME.textMuted, fontFamily: FONT.mono, marginTop: 1 }}>
            :{flow.dst_port}
          </span>
        )}
      </div>

      {/* Bytes / packets badge */}
      <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'flex-end', gap: 2, minWidth: 60 }}>
        {flow.bytes != null && (
          <span
            style={{
              fontFamily: FONT.mono,
              fontSize: 11,
              fontWeight: 700,
              color: THEME.text,
            }}
            title={`${flow.bytes.toLocaleString()} bytes`}
          >
            {formatNumberCompact(flow.bytes)}B
          </span>
        )}
        {flow.packets != null && (
          <span
            style={{
              fontFamily: FONT.mono,
              fontSize: 9,
              color: THEME.textMuted,
            }}
          >
            {formatNumberCompact(flow.packets)} pkts
          </span>
        )}
      </div>
    </div>
  );
}

// ─── Main component ────────────────────────────────────────────────────────

export default function FlowDiagramBlock({ data, onPivot }) {
  const [containerRef, containerWidth] = useContainerWidth();
  const [expanded, setExpanded] = useState(false);

  const columns = columnsFor(containerWidth);
  const defaultVisible = visibleCountFor(columns);

  const flows = data?.flows || [];
  const title = data?.title || 'Network Flows';

  if (flows.length === 0) return null;

  const visible = expanded ? flows : flows.slice(0, defaultVisible);
  const hidden = flows.length - defaultVisible;

  // Stats
  const totalBytes   = flows.reduce((s, f) => s + (f.bytes   || 0), 0);
  const totalPackets = flows.reduce((s, f) => s + (f.packets || 0), 0);
  const blockedCount = flows.filter((f) => {
    const a = String(f.action || '').toLowerCase();
    return a === 'blocked' || a === 'denied' || a === 'drop' || a === 'reject';
  }).length;

  return (
    <div
      ref={containerRef}
      style={{
        margin: '14px 0',
        background: GRADIENTS.card,
        border: `1px solid ${THEME.border}`,
        borderRadius: 12,
        padding: '14px 16px',
        boxShadow: SHADOWS.md + ", inset 0 1px 0 rgba(255,255,255,0.04)",
      }}
    >
      {/* Header */}
      <div
        style={{
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'space-between',
          marginBottom: 12,
          gap: 8,
          flexWrap: 'wrap',
        }}
      >
        <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
          <span
            style={{
              width: 3,
              height: 14,
              background: GRADIENTS.primaryAccent,
              borderRadius: 2,
              flexShrink: 0,
            }}
          />
          <h4
            style={{
              margin: 0,
              fontSize: 12,
              fontWeight: 700,
              color: THEME.textSecondary,
              textTransform: 'uppercase',
              letterSpacing: '0.05em',
            }}
          >
            {title}
          </h4>
        </div>
        <div style={{ display: 'flex', gap: 12, fontFamily: FONT.mono, fontSize: 10, color: THEME.textMuted, flexWrap: 'wrap' }}>
          <span>{flows.length} flows</span>
          {totalBytes > 0 && <span>{formatNumberCompact(totalBytes)}B</span>}
          {totalPackets > 0 && <span>{formatNumberCompact(totalPackets)} pkts</span>}
          {blockedCount > 0 && (
            <span style={{ color: THEME.danger, fontWeight: 700 }}>
              {blockedCount} blocked
            </span>
          )}
        </div>
      </div>

      {/* Flow rows — 1-col on narrow, 2-col on wide desktops */}
      <div
        style={{
          display: 'grid',
          gridTemplateColumns: `repeat(${columns}, minmax(0, 1fr))`,
          gap: columns === 2 ? 8 : 0,
        }}
      >
        {visible.map((flow, idx) => (
          <FlowRow key={`${flow.src_ip}-${flow.dst_ip}-${idx}`} flow={flow} onPivot={onPivot} />
        ))}
      </div>

      {/* Footer */}
      {hidden > 0 && (
        <div style={{ marginTop: 8, display: 'flex', justifyContent: 'center' }}>
          <button
            onClick={() => setExpanded(!expanded)}
            style={{
              display: 'inline-flex',
              alignItems: 'center',
              gap: 6,
              padding: '6px 16px',
              borderRadius: 8,
              border: `1px solid ${THEME.primary}40`,
              background: `${THEME.primary}10`,
              color: THEME.primary,
              fontSize: 11,
              fontWeight: 600,
              cursor: 'pointer',
              fontFamily: 'inherit',
              transition: `all ${TIMINGS.fast} ${TIMINGS.ease}`,
              outline: 'none',
            }}
            onMouseEnter={(e) => {
              e.currentTarget.style.background = `${THEME.primary}20`;
              e.currentTarget.style.borderColor = THEME.primary;
            }}
            onMouseLeave={(e) => {
              e.currentTarget.style.background = `${THEME.primary}10`;
              e.currentTarget.style.borderColor = `${THEME.primary}40`;
            }}
          >
            <EuiIcon type={expanded ? 'arrowUp' : 'arrowDown'} size="s" color={THEME.primary} />
            {expanded ? 'Show less' : `Show all ${flows.length}`}
          </button>
        </div>
      )}
    </div>
  );
}
