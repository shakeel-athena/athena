"""
Tool Registry - Complete metadata for all 29 MCP tools
Provides tool discovery, validation, and correlation capabilities
"""

from dataclasses import dataclass
from typing import Dict, List, Optional, Any
from enum import Enum


class ToolCategory(Enum):
    """Tool categories for organization"""
    ALERT_MANAGEMENT = "alert_management"
    AGENT_MANAGEMENT = "agent_management"
    VULNERABILITY_MANAGEMENT = "vulnerability_management"
    SECURITY_ANALYSIS = "security_analysis"
    SYSTEM_MONITORING = "system_monitoring"
    SURICATA_IDS = "suricata_ids"


@dataclass
class ToolMetadata:
    """Metadata for a single tool"""
    name: str
    category: ToolCategory
    description: str
    primary_intent_keywords: List[str]
    secondary_intent_keywords: List[str]
    input_schema: Dict[str, Any]
    output_format: str
    requires_indexer: bool = False
    can_be_secondary: bool = False
    correlation_key: Optional[str] = None


class ToolRegistry:
    """
    Central registry for all 29 MCP tools.
    Provides tool discovery, validation, and metadata.
    """

    TOOLS: Dict[str, ToolMetadata] = {
        # ============================================================
        # ALERT MANAGEMENT (4 tools)
        # ============================================================
        "get_wazuh_alerts": ToolMetadata(
            name="get_wazuh_alerts",
            category=ToolCategory.ALERT_MANAGEMENT,
            description="Retrieve security alerts with optional filtering",
            primary_intent_keywords=["alert", "alerts", "detection", "incident"],
            secondary_intent_keywords=["security event", "triggered", "suspicious"],
            input_schema={
                "limit": {"type": "integer", "default": 10000},
                "rule_id": {"type": "string", "optional": True},
                "level": {"type": "string", "optional": True},
                "agent_id": {"type": "string", "optional": True},
                "time_range": {"type": "string", "optional": True}
            },
            output_format="alerts",
            requires_indexer=True,
            can_be_secondary=True,
            correlation_key="agent_id"
        ),

        "get_wazuh_alert_summary": ToolMetadata(
            name="get_wazuh_alert_summary",
            category=ToolCategory.ALERT_MANAGEMENT,
            description="Get statistical summary of alerts",
            primary_intent_keywords=["alert summary", "alert statistics", "alert trends"],
            secondary_intent_keywords=["alert count", "alert breakdown"],
            input_schema={
                "time_range": {"type": "string", "default": "24h"},
                "group_by": {"type": "string", "default": "rule.level"}
            },
            output_format="statistics",
            requires_indexer=True
        ),

        "analyze_alert_patterns": ToolMetadata(
            name="analyze_alert_patterns",
            category=ToolCategory.ALERT_MANAGEMENT,
            description="Analyze alert patterns for trends and anomalies",
            primary_intent_keywords=["alert pattern", "alert trend", "anomaly"],
            secondary_intent_keywords=["pattern analysis", "trending alerts"],
            input_schema={
                "time_range": {"type": "string", "default": "24h"},
                "min_frequency": {"type": "integer", "default": 5}
            },
            output_format="statistics",
            requires_indexer=True
        ),

        "search_security_events": ToolMetadata(
            name="search_security_events",
            category=ToolCategory.ALERT_MANAGEMENT,
            description="Full-text search across security events",
            primary_intent_keywords=["search event", "find event", "event search"],
            secondary_intent_keywords=["search log", "query event"],
            input_schema={
                "query": {"type": "string", "required": True},
                "time_range": {"type": "string", "default": "24h"},
                "limit": {"type": "integer", "default": 100000},
                "rule_id": {"type": "string", "required": False},
                "level": {"type": "integer", "required": False},
                "agent_id": {"type": "string", "required": False},
                "mitre_id": {"type": "string", "required": False},
                "mitre_tactic": {"type": "string", "required": False},
                "mitre_technique": {"type": "string", "required": False}
            },
            output_format="alerts",
            requires_indexer=True
        ),

        # ============================================================
        # AGENT MANAGEMENT (6 tools)
        # ============================================================
        "get_wazuh_agents": ToolMetadata(
            name="get_wazuh_agents",
            category=ToolCategory.AGENT_MANAGEMENT,
            description="Retrieve agent information with filtering",
            primary_intent_keywords=["agent", "agents", "endpoint", "host", "server"],
            secondary_intent_keywords=["machine", "system", "node"],
            input_schema={
                "agent_id": {"type": "string", "optional": True},
                "status": {"type": "string", "enum": ["active", "disconnected", "never_connected"], "optional": True},
                "limit": {"type": "integer", "default": 100000}
            },
            output_format="agents",
            can_be_secondary=True,
            correlation_key="agent_id"
        ),

        "get_wazuh_running_agents": ToolMetadata(
            name="get_wazuh_running_agents",
            category=ToolCategory.AGENT_MANAGEMENT,
            description="Get only active/running agents",
            primary_intent_keywords=["active agent", "running agent", "online agent"],
            secondary_intent_keywords=["connected agent", "available agent"],
            input_schema={},
            output_format="agents",
            can_be_secondary=True
        ),

        "check_agent_health": ToolMetadata(
            name="check_agent_health",
            category=ToolCategory.AGENT_MANAGEMENT,
            description="Check health of a specific agent",
            primary_intent_keywords=["agent health", "check agent", "agent status"],
            secondary_intent_keywords=["agent diagnostics", "agent check"],
            input_schema={
                "agent_id": {"type": "string", "required": True}
            },
            output_format="health"
        ),

        "get_agent_processes": ToolMetadata(
            name="get_agent_processes",
            category=ToolCategory.AGENT_MANAGEMENT,
            description="Get running processes from an agent",
            primary_intent_keywords=["agent processes", "running processes"],
            secondary_intent_keywords=["process list"],
            input_schema={
                "agent_id": {"type": "string", "required": True},
                "limit": {"type": "integer", "default": 10000}
            },
            output_format="processes"
        ),

        "get_agent_ports": ToolMetadata(
            name="get_agent_ports",
            category=ToolCategory.AGENT_MANAGEMENT,
            description="Get open ports from an agent",
            primary_intent_keywords=["agent ports", "open ports", "listening ports"],
            secondary_intent_keywords=["port list", "network ports"],
            input_schema={
                "agent_id": {"type": "string", "required": True},
                "limit": {"type": "integer", "default": 10000}
            },
            output_format="ports"
        ),

        "get_agent_configuration": ToolMetadata(
            name="get_agent_configuration",
            category=ToolCategory.AGENT_MANAGEMENT,
            description="Get agent configuration",
            primary_intent_keywords=["agent config", "agent configuration"],
            secondary_intent_keywords=["agent settings"],
            input_schema={
                "agent_id": {"type": "string", "required": True}
            },
            output_format="configuration"
        ),

        # ============================================================
        # VULNERABILITY MANAGEMENT (3 tools)
        # ============================================================
        "get_wazuh_vulnerabilities": ToolMetadata(
            name="get_wazuh_vulnerabilities",
            category=ToolCategory.VULNERABILITY_MANAGEMENT,
            description="Retrieve vulnerabilities",
            primary_intent_keywords=["vulnerability", "vulnerabilities", "cve", "vuln"],
            secondary_intent_keywords=["security flaw", "patch"],
            input_schema={
                "agent_id": {"type": "string", "optional": True},
                "severity": {"type": "string", "enum": ["low", "medium", "high", "critical"], "optional": True},
                "limit": {"type": "integer", "default": 10000}
            },
            output_format="vulnerabilities",
            requires_indexer=True,
            can_be_secondary=True,
            correlation_key="agent_id"
        ),

        "get_wazuh_critical_vulnerabilities": ToolMetadata(
            name="get_wazuh_critical_vulnerabilities",
            category=ToolCategory.VULNERABILITY_MANAGEMENT,
            description="Get critical vulnerabilities only",
            primary_intent_keywords=["critical vulnerability", "critical cve", "critical vuln"],
            secondary_intent_keywords=["urgent vulnerability"],
            input_schema={
                "limit": {"type": "integer", "default": 10000}
            },
            output_format="vulnerabilities",
            requires_indexer=True,
            can_be_secondary=True,
            correlation_key="agent_id"
        ),

        "get_wazuh_vulnerability_summary": ToolMetadata(
            name="get_wazuh_vulnerability_summary",
            category=ToolCategory.VULNERABILITY_MANAGEMENT,
            description="Get vulnerability statistics",
            primary_intent_keywords=["vulnerability summary", "vulnerability statistics", "vulnerability trend"],
            secondary_intent_keywords=["vulnerability count", "vulnerability breakdown"],
            input_schema={
                "time_range": {"type": "string", "default": "7d"}
            },
            output_format="statistics",
            requires_indexer=True
        ),

        # ============================================================
        # SECURITY ANALYSIS (6 tools)
        # ============================================================
        "analyze_security_threat": ToolMetadata(
            name="analyze_security_threat",
            category=ToolCategory.SECURITY_ANALYSIS,
            description="Analyze threat indicators",
            primary_intent_keywords=["threat", "threat analysis", "analyze threat"],
            secondary_intent_keywords=["ioc analysis", "indicator analysis"],
            input_schema={
                "indicator": {"type": "string", "required": True},
                "indicator_type": {"type": "string", "enum": ["ip", "hash", "domain", "url"], "default": "ip"}
            },
            output_format="analysis"
        ),

        "check_ioc_reputation": ToolMetadata(
            name="check_ioc_reputation",
            category=ToolCategory.SECURITY_ANALYSIS,
            description="Check IoC reputation",
            primary_intent_keywords=["ioc", "reputation", "indicator reputation"],
            secondary_intent_keywords=["check indicator"],
            input_schema={
                "indicator": {"type": "string", "required": True},
                "indicator_type": {"type": "string", "enum": ["ip", "domain", "hash", "url"], "default": "ip"}
            },
            output_format="reputation"
        ),

        "perform_risk_assessment": ToolMetadata(
            name="perform_risk_assessment",
            category=ToolCategory.SECURITY_ANALYSIS,
            description="Perform risk assessment",
            primary_intent_keywords=["risk assessment", "risk analysis", "assess risk"],
            secondary_intent_keywords=["security risk"],
            input_schema={
                "agent_id": {"type": "string", "optional": True}
            },
            output_format="assessment"
        ),

        "get_top_security_threats": ToolMetadata(
            name="get_top_security_threats",
            category=ToolCategory.SECURITY_ANALYSIS,
            description="Get top security threats",
            primary_intent_keywords=["top threats", "security threats", "major threats"],
            secondary_intent_keywords=["threat list"],
            input_schema={
                "limit": {"type": "integer", "default": 10},
                "time_range": {"type": "string", "default": "24h"}
            },
            output_format="threats"
        ),

        "generate_security_report": ToolMetadata(
            name="generate_security_report",
            category=ToolCategory.SECURITY_ANALYSIS,
            description="Generate security report",
            primary_intent_keywords=["security report", "generate report", "report"],
            secondary_intent_keywords=["security summary"],
            input_schema={
                "report_type": {"type": "string", "enum": ["daily", "weekly", "monthly", "incident"], "default": "daily"},
                "include_recommendations": {"type": "boolean", "default": True}
            },
            output_format="report"
        ),

        "run_compliance_check": ToolMetadata(
            name="run_compliance_check",
            category=ToolCategory.SECURITY_ANALYSIS,
            description="Run compliance check",
            primary_intent_keywords=["compliance", "compliance check", "regulatory check"],
            secondary_intent_keywords=["pci", "hipaa", "gdpr", "nist"],
            input_schema={
                "framework": {"type": "string", "enum": ["PCI-DSS", "HIPAA", "SOX", "GDPR", "NIST"], "default": "PCI-DSS"},
                "agent_id": {"type": "string", "optional": True}
            },
            output_format="compliance"
        ),

        # ============================================================
        # SYSTEM MONITORING (10 tools)
        # ============================================================
        "get_wazuh_statistics": ToolMetadata(
            name="get_wazuh_statistics",
            category=ToolCategory.SYSTEM_MONITORING,
            description="Get system statistics",
            primary_intent_keywords=["statistics", "stats", "metrics"],
            secondary_intent_keywords=["system stats"],
            input_schema={},
            output_format="statistics"
        ),

        "get_wazuh_weekly_stats": ToolMetadata(
            name="get_wazuh_weekly_stats",
            category=ToolCategory.SYSTEM_MONITORING,
            description="Get weekly statistics",
            primary_intent_keywords=["weekly stats", "week statistics"],
            secondary_intent_keywords=["weekly report"],
            input_schema={},
            output_format="statistics"
        ),

        "get_wazuh_cluster_health": ToolMetadata(
            name="get_wazuh_cluster_health",
            category=ToolCategory.SYSTEM_MONITORING,
            description="Get cluster health",
            primary_intent_keywords=["cluster health", "cluster status"],
            secondary_intent_keywords=["cluster check"],
            input_schema={},
            output_format="health"
        ),

        "get_wazuh_cluster_nodes": ToolMetadata(
            name="get_wazuh_cluster_nodes",
            category=ToolCategory.SYSTEM_MONITORING,
            description="Get cluster nodes",
            primary_intent_keywords=["cluster nodes", "nodes"],
            secondary_intent_keywords=["cluster members"],
            input_schema={},
            output_format="nodes"
        ),

        "get_wazuh_rules_summary": ToolMetadata(
            name="get_wazuh_rules_summary",
            category=ToolCategory.SYSTEM_MONITORING,
            description="Get rules summary",
            primary_intent_keywords=["rules summary", "rules"],
            secondary_intent_keywords=["rule statistics"],
            input_schema={},
            output_format="statistics"
        ),

        "get_wazuh_remoted_stats": ToolMetadata(
            name="get_wazuh_remoted_stats",
            category=ToolCategory.SYSTEM_MONITORING,
            description="Get remoted statistics",
            primary_intent_keywords=["remoted stats", "agent communication"],
            secondary_intent_keywords=["remoted statistics"],
            input_schema={},
            output_format="statistics"
        ),

        "get_wazuh_log_collector_stats": ToolMetadata(
            name="get_wazuh_log_collector_stats",
            category=ToolCategory.SYSTEM_MONITORING,
            description="Get log collector statistics",
            primary_intent_keywords=["log collector", "collector stats"],
            secondary_intent_keywords=["log statistics"],
            input_schema={},
            output_format="statistics"
        ),

        "search_wazuh_manager_logs": ToolMetadata(
            name="search_wazuh_manager_logs",
            category=ToolCategory.SYSTEM_MONITORING,
            description="Search manager logs",
            primary_intent_keywords=["manager logs", "search logs"],
            secondary_intent_keywords=["log search"],
            input_schema={
                "query": {"type": "string", "required": True},
                "limit": {"type": "integer", "default": 10000}
            },
            output_format="logs"
        ),

        "get_wazuh_manager_error_logs": ToolMetadata(
            name="get_wazuh_manager_error_logs",
            category=ToolCategory.SYSTEM_MONITORING,
            description="Get manager error logs",
            primary_intent_keywords=["error logs", "errors"],
            secondary_intent_keywords=["manager errors"],
            input_schema={
                "limit": {"type": "integer", "default": 10000}
            },
            output_format="logs"
        ),

        "validate_wazuh_connection": ToolMetadata(
            name="validate_wazuh_connection",
            category=ToolCategory.SYSTEM_MONITORING,
            description="Validate connection to Wazuh",
            primary_intent_keywords=["validate connection", "test connection", "check connection"],
            secondary_intent_keywords=["connection test"],
            input_schema={},
            output_format="validation"
        ),

        # ============================================================
        # ROUND 6: ENTERPRISE SOC ANALYSIS TOOLS
        # ============================================================

        "get_rule_trigger_analysis": ToolMetadata(
            name="get_rule_trigger_analysis",
            category=ToolCategory.ALERT_MANAGEMENT,
            description="Analyze rule trigger frequency, noisy rules, and MITRE mapping",
            primary_intent_keywords=["rule trigger", "noisy rules", "rule frequency"],
            secondary_intent_keywords=["rule analysis", "firing rules"],
            input_schema={"time_range": {"type": "string", "default": "24h"},
                          "limit": {"type": "integer", "default": 20}},
            output_format="rule_analysis",
            requires_indexer=True
        ),
        "get_mitre_coverage": ToolMetadata(
            name="get_mitre_coverage",
            category=ToolCategory.SECURITY_ANALYSIS,
            description="Map MITRE ATT&CK technique and tactic coverage from detections",
            primary_intent_keywords=["mitre coverage", "mitre attack", "detection coverage"],
            secondary_intent_keywords=["att&ck", "technique coverage"],
            input_schema={"time_range": {"type": "string", "default": "7d"}},
            output_format="mitre_coverage",
            requires_indexer=True
        ),
        "get_alert_timeline": ToolMetadata(
            name="get_alert_timeline",
            category=ToolCategory.ALERT_MANAGEMENT,
            description="Get alert time-series trends with spike detection",
            primary_intent_keywords=["alert timeline", "alert trend", "alert spike"],
            secondary_intent_keywords=["hourly alerts", "alert distribution"],
            input_schema={"time_range": {"type": "string", "default": "24h"},
                          "interval": {"type": "string", "default": "1h"}},
            output_format="alert_timeline",
            requires_indexer=True
        ),
        "get_log_source_health": ToolMetadata(
            name="get_log_source_health",
            category=ToolCategory.SYSTEM_MONITORING,
            description="Validate log ingestion health, detect silent sources and drop rates",
            primary_intent_keywords=["log source health", "ingestion status", "silent agents"],
            secondary_intent_keywords=["log health", "source coverage"],
            input_schema={"time_range": {"type": "string", "default": "24h"}},
            output_format="log_health"
        ),
        "get_decoder_analysis": ToolMetadata(
            name="get_decoder_analysis",
            category=ToolCategory.SYSTEM_MONITORING,
            description="List active decoders with coverage analysis",
            primary_intent_keywords=["decoder analysis", "active decoders", "decoder coverage"],
            secondary_intent_keywords=["decoders", "log parser"],
            input_schema={"limit": {"type": "integer", "default": 100}},
            output_format="decoder_analysis"
        ),
        "get_fim_events": ToolMetadata(
            name="get_fim_events",
            category=ToolCategory.SECURITY_ANALYSIS,
            description="Get File Integrity Monitoring events — file changes, integrity violations",
            primary_intent_keywords=["fim events", "file integrity", "syscheck events"],
            secondary_intent_keywords=["file changes", "integrity monitoring"],
            input_schema={"agent_id": {"type": "string"},
                          "time_range": {"type": "string", "default": "24h"},
                          "limit": {"type": "integer", "default": 50}},
            output_format="fim_events",
            requires_indexer=True
        ),
        "get_sca_results": ToolMetadata(
            name="get_sca_results",
            category=ToolCategory.SECURITY_ANALYSIS,
            description="Get Security Configuration Assessment results — CIS benchmarks, hardening",
            primary_intent_keywords=["sca results", "configuration assessment", "cis benchmark"],
            secondary_intent_keywords=["hardening", "sca score"],
            input_schema={"agent_id": {"type": "string", "required": True}},
            output_format="sca_results"
        ),
        "get_agent_inventory": ToolMetadata(
            name="get_agent_inventory",
            category=ToolCategory.AGENT_MANAGEMENT,
            description="Get full system inventory — hardware, OS, packages, network interfaces",
            primary_intent_keywords=["agent inventory", "system inventory", "installed packages"],
            secondary_intent_keywords=["hardware info", "network interfaces"],
            input_schema={"agent_id": {"type": "string", "required": True}},
            output_format="agent_inventory"
        ),
        "get_rootcheck_results": ToolMetadata(
            name="get_rootcheck_results",
            category=ToolCategory.SECURITY_ANALYSIS,
            description="Get rootkit/malware/anomaly scan results for an agent",
            primary_intent_keywords=["rootcheck results", "rootkit scan", "malware scan"],
            secondary_intent_keywords=["rootcheck", "rootkit detection"],
            input_schema={"agent_id": {"type": "string", "required": True}},
            output_format="rootcheck"
        ),
        "correlate_alerts_vulnerabilities": ToolMetadata(
            name="correlate_alerts_vulnerabilities",
            category=ToolCategory.SECURITY_ANALYSIS,
            description="Cross-correlate agents with active alerts AND known vulnerabilities",
            primary_intent_keywords=["correlate alerts vulnerabilities", "alert vulnerability overlap"],
            secondary_intent_keywords=["cross correlation", "risk matrix"],
            input_schema={"time_range": {"type": "string", "default": "24h"},
                          "min_severity": {"type": "string", "default": "high"}},
            output_format="alert_vuln_correlation",
            requires_indexer=True
        ),
        "get_behavioral_baseline": ToolMetadata(
            name="get_behavioral_baseline",
            category=ToolCategory.SECURITY_ANALYSIS,
            description="Compare current alert rates against historical baseline for anomaly detection",
            primary_intent_keywords=["behavioral baseline", "anomaly detection", "alert deviation"],
            secondary_intent_keywords=["baseline", "normal activity"],
            input_schema={"agent_id": {"type": "string"},
                          "baseline_days": {"type": "integer", "default": 7}},
            output_format="behavioral_baseline",
            requires_indexer=True
        ),

        "generate_wazuh_decoder": ToolMetadata(
            name="generate_wazuh_decoder",
            category=ToolCategory.SECURITY_ANALYSIS,
            description="Generate and validate a Wazuh decoder from a raw log sample using LLM",
            primary_intent_keywords=["generate decoder", "create decoder", "build decoder", "decoder for log"],
            secondary_intent_keywords=["parse log", "log parser", "custom decoder", "wazuh decoder"],
            input_schema={
                "raw_log": {"type": "string", "required": True, "description": "The raw log sample to create a decoder for"},
                "log_format": {"type": "string", "default": "syslog", "description": "Log format (syslog, json, multi-line)"},
                "device_type": {"type": "string", "optional": True, "description": "Device type hint (firewall, IDS, web_server)"},
                "vendor": {"type": "string", "optional": True, "description": "Vendor hint (Palo Alto, Fortinet, etc.)"},
                "expected_fields": {"type": "string", "optional": True, "description": "Comma-separated fields to extract"}
            },
            output_format="decoder_result",
            requires_indexer=False,
            can_be_secondary=False
        ),

        # ============================================================
        # SURICATA IDS TOOLS (10 tools)
        # ============================================================
        "get_suricata_alerts": ToolMetadata(
            name="get_suricata_alerts",
            category=ToolCategory.SURICATA_IDS,
            description="Retrieve Suricata IDS alerts with severity/category/IP filters",
            primary_intent_keywords=["suricata alerts", "ids alerts", "suricata detections"],
            secondary_intent_keywords=["suricata", "ids"],
            input_schema={
                "limit": {"type": "integer", "default": 100},
                "severity": {"type": "string", "optional": True},
                "category": {"type": "string", "optional": True},
                "src_ip": {"type": "string", "optional": True},
                "dest_ip": {"type": "string", "optional": True},
                "time_range": {"type": "string", "default": "24h"}
            },
            output_format="suricata_alerts",
            requires_indexer=True,
            can_be_secondary=True,
            correlation_key="src_ip"
        ),
        "get_suricata_alert_summary": ToolMetadata(
            name="get_suricata_alert_summary",
            category=ToolCategory.SURICATA_IDS,
            description="Suricata alert summary with severity breakdown and top signatures",
            primary_intent_keywords=["suricata summary", "suricata stats", "ids summary"],
            secondary_intent_keywords=["suricata overview"],
            input_schema={"time_range": {"type": "string", "default": "24h"}},
            output_format="suricata_summary",
            requires_indexer=True
        ),
        "get_suricata_critical_alerts": ToolMetadata(
            name="get_suricata_critical_alerts",
            category=ToolCategory.SURICATA_IDS,
            description="Critical severity Suricata IDS alerts",
            primary_intent_keywords=["critical suricata", "critical ids"],
            secondary_intent_keywords=["suricata critical"],
            input_schema={"limit": {"type": "integer", "default": 50}, "time_range": {"type": "string", "default": "24h"}},
            output_format="suricata_alerts",
            requires_indexer=True
        ),
        "get_suricata_high_alerts": ToolMetadata(
            name="get_suricata_high_alerts",
            category=ToolCategory.SURICATA_IDS,
            description="High severity Suricata IDS alerts",
            primary_intent_keywords=["high suricata", "high ids"],
            secondary_intent_keywords=["suricata high"],
            input_schema={"limit": {"type": "integer", "default": 50}, "time_range": {"type": "string", "default": "24h"}},
            output_format="suricata_alerts",
            requires_indexer=True
        ),
        "get_suricata_network_analysis": ToolMetadata(
            name="get_suricata_network_analysis",
            category=ToolCategory.SURICATA_IDS,
            description="Suricata network analysis: top source/dest IPs, services, hostnames",
            primary_intent_keywords=["suricata network", "network analysis", "top talkers"],
            secondary_intent_keywords=["traffic analysis", "network traffic"],
            input_schema={"time_range": {"type": "string", "default": "24h"}, "limit": {"type": "integer", "default": 10}},
            output_format="suricata_network",
            requires_indexer=True,
            can_be_secondary=True
        ),
        "search_suricata_alerts": ToolMetadata(
            name="search_suricata_alerts",
            category=ToolCategory.SURICATA_IDS,
            description="Search Suricata IDS alerts by signature, category, or IP",
            primary_intent_keywords=["search suricata", "find suricata"],
            secondary_intent_keywords=["suricata search"],
            input_schema={
                "query": {"type": "string", "required": True},
                "time_range": {"type": "string", "default": "24h"},
                "limit": {"type": "integer", "default": 100}
            },
            output_format="suricata_alerts",
            requires_indexer=True
        ),
        "get_suricata_top_signatures": ToolMetadata(
            name="get_suricata_top_signatures",
            category=ToolCategory.SURICATA_IDS,
            description="Top firing Suricata IDS signatures ranked by count",
            primary_intent_keywords=["suricata signatures", "top signatures", "ids signatures"],
            secondary_intent_keywords=["signature analysis"],
            input_schema={"time_range": {"type": "string", "default": "24h"}},
            output_format="suricata_signatures",
            requires_indexer=True
        ),
        "get_suricata_top_attackers": ToolMetadata(
            name="get_suricata_top_attackers",
            category=ToolCategory.SURICATA_IDS,
            description="Top source IPs generating Suricata IDS alerts",
            primary_intent_keywords=["top attackers", "attacking ips", "suricata attackers"],
            secondary_intent_keywords=["attacker analysis"],
            input_schema={"time_range": {"type": "string", "default": "24h"}, "limit": {"type": "integer", "default": 10}},
            output_format="suricata_network",
            requires_indexer=True
        ),
        "get_suricata_health": ToolMetadata(
            name="get_suricata_health",
            category=ToolCategory.SURICATA_IDS,
            description="Suricata Elasticsearch cluster health check",
            primary_intent_keywords=["suricata health", "ids health", "suricata status"],
            secondary_intent_keywords=["suricata check"],
            input_schema={},
            output_format="suricata_health",
            requires_indexer=True
        ),
        "get_suricata_category_breakdown": ToolMetadata(
            name="get_suricata_category_breakdown",
            category=ToolCategory.SURICATA_IDS,
            description="Suricata IDS alert breakdown by category",
            primary_intent_keywords=["suricata categories", "ids categories", "alert categories"],
            secondary_intent_keywords=["category breakdown"],
            input_schema={"time_range": {"type": "string", "default": "24h"}},
            output_format="suricata_categories",
            requires_indexer=True
        ),
        # Suricata Deep Visibility Tools (7 tools)
        "get_suricata_http_analysis": ToolMetadata(
            name="get_suricata_http_analysis",
            category=ToolCategory.SURICATA_IDS,
            description="Suricata HTTP traffic analysis: top URLs, methods, status codes, user agents",
            primary_intent_keywords=["http traffic", "http analysis", "web traffic", "http events"],
            secondary_intent_keywords=["http", "url", "web"],
            input_schema={"time_range": {"type": "string", "default": "24h"}, "limit": {"type": "integer", "default": 10}},
            output_format="suricata_http_analysis",
            requires_indexer=True,
            can_be_secondary=True,
            correlation_key="src_ip"
        ),
        "search_suricata_http": ToolMetadata(
            name="search_suricata_http",
            category=ToolCategory.SURICATA_IDS,
            description="Search Suricata HTTP events by URL, method, status code, user agent",
            primary_intent_keywords=["search http", "find url", "http search", "find http"],
            secondary_intent_keywords=["search", "http"],
            input_schema={"url": {"type": "string"}, "method": {"type": "string"}, "time_range": {"type": "string", "default": "24h"}},
            output_format="suricata_http_search",
            requires_indexer=True
        ),
        "get_suricata_tls_analysis": ToolMetadata(
            name="get_suricata_tls_analysis",
            category=ToolCategory.SURICATA_IDS,
            description="Suricata TLS/SSL analysis: version distribution, JA3/JA3S/JA4 fingerprints",
            primary_intent_keywords=["tls analysis", "ssl analysis", "tls fingerprint", "ja3"],
            secondary_intent_keywords=["tls", "ssl", "certificate"],
            input_schema={"time_range": {"type": "string", "default": "24h"}, "limit": {"type": "integer", "default": 10}},
            output_format="suricata_tls_analysis",
            requires_indexer=True,
            can_be_secondary=True
        ),
        "get_suricata_mitre_mapping": ToolMetadata(
            name="get_suricata_mitre_mapping",
            category=ToolCategory.SURICATA_IDS,
            description="MITRE ATT&CK tactics and techniques from Suricata alert metadata",
            primary_intent_keywords=["mitre mapping", "mitre att&ck", "mitre tactics", "mitre techniques"],
            secondary_intent_keywords=["mitre", "att&ck", "tactic", "technique"],
            input_schema={"time_range": {"type": "string", "default": "24h"}},
            output_format="suricata_mitre_mapping",
            requires_indexer=True,
            can_be_secondary=True
        ),
        "get_suricata_ja3_fingerprints": ToolMetadata(
            name="get_suricata_ja3_fingerprints",
            category=ToolCategory.SURICATA_IDS,
            description="JA3/JA3S TLS fingerprint deep analysis with IP and service correlation",
            primary_intent_keywords=["ja3 fingerprint", "ja3 analysis", "tls fingerprint", "ja3s"],
            secondary_intent_keywords=["ja3", "fingerprint", "ja4"],
            input_schema={"time_range": {"type": "string", "default": "24h"}, "limit": {"type": "integer", "default": 20}},
            output_format="suricata_ja3",
            requires_indexer=True,
            correlation_key="ja3_hash"
        ),
        "get_suricata_suspicious_activity": ToolMetadata(
            name="get_suricata_suspicious_activity",
            category=ToolCategory.SURICATA_IDS,
            description="Detect suspicious activity: scanner user agents, legacy TLS, unusual methods, HTTP errors",
            primary_intent_keywords=["suspicious activity", "scanner detection", "anomaly detection", "suspicious"],
            secondary_intent_keywords=["suspicious", "scanner", "anomaly"],
            input_schema={"time_range": {"type": "string", "default": "24h"}},
            output_format="suricata_suspicious",
            requires_indexer=True
        ),
        "get_suricata_traffic_overview": ToolMetadata(
            name="get_suricata_traffic_overview",
            category=ToolCategory.SURICATA_IDS,
            description="Suricata traffic overview: event type, protocol, service distribution",
            primary_intent_keywords=["traffic overview", "event distribution", "traffic distribution"],
            secondary_intent_keywords=["traffic", "overview", "distribution"],
            input_schema={"time_range": {"type": "string", "default": "24h"}},
            output_format="suricata_traffic_overview",
            requires_indexer=True
        ),
        # --- Pallas 3.3: New Suricata tools ---
        "get_suricata_ja4_analysis": ToolMetadata(
            name="get_suricata_ja4_analysis",
            category=ToolCategory.SURICATA_IDS,
            description="JA4 TLS fingerprint deep analysis with IP, service, and TLS version correlation",
            primary_intent_keywords=["ja4 fingerprint", "ja4 analysis", "ja4 deep analysis"],
            secondary_intent_keywords=["ja4", "fingerprint"],
            input_schema={"time_range": {"type": "string", "default": "24h"}, "limit": {"type": "integer", "default": 20}},
            output_format="suricata_ja4",
            requires_indexer=True,
            correlation_key="ja4_fingerprint"
        ),
        "get_suricata_flow_analysis": ToolMetadata(
            name="get_suricata_flow_analysis",
            category=ToolCategory.SURICATA_IDS,
            description="Network flow/conversation analysis: IP pairs with alert counts, signatures, protocols, and ports",
            primary_intent_keywords=["flow analysis", "conversation analysis", "ip pair analysis", "network flow"],
            secondary_intent_keywords=["flow", "conversation", "ip pair", "communication pattern"],
            input_schema={"time_range": {"type": "string", "default": "24h"}, "limit": {"type": "integer", "default": 20}},
            output_format="suricata_flow_analysis",
            requires_indexer=True,
            correlation_key="src_ip",
            can_be_secondary=True
        ),
    }

    # ============================================================
    # REGISTRY METHODS (All Static)
    # ============================================================

    @staticmethod
    def get_tool(tool_name: str) -> Optional[ToolMetadata]:
        """Get tool metadata by name"""
        return ToolRegistry.TOOLS.get(tool_name)

    @staticmethod
    def get_all_tools() -> List[ToolMetadata]:
        """Get all tools"""
        return list(ToolRegistry.TOOLS.values())

    @staticmethod
    def get_tools_by_category(category: ToolCategory) -> List[ToolMetadata]:
        """Get all tools in a category"""
        return [t for t in ToolRegistry.TOOLS.values() if t.category == category]

    @staticmethod
    def search_tools(keywords: List[str]) -> List[ToolMetadata]:
        """Search tools by keywords"""
        matches = []
        keywords_lower = [k.lower() for k in keywords]

        for tool in ToolRegistry.TOOLS.values():
            all_keywords = tool.primary_intent_keywords + tool.secondary_intent_keywords
            all_keywords_lower = [k.lower() for k in all_keywords]

            if any(kw in all_keywords_lower for kw in keywords_lower):
                matches.append(tool)

        return matches

    @staticmethod
    def validate_tool_arguments(tool_name: str, arguments: Dict[str, Any]) -> tuple:
        """Validate tool arguments against schema"""
        tool = ToolRegistry.get_tool(tool_name)

        if not tool:
            return False, f"Tool '{tool_name}' not found in registry"

        schema = tool.input_schema

        # Check required fields
        for field, spec in schema.items():
            if spec.get("required", False) and field not in arguments:
                return False, f"Required field '{field}' missing"

        # Validate types
        for field, value in arguments.items():
            if field not in schema:
                continue

            spec = schema[field]
            expected_type = spec.get("type")

            if expected_type == "integer" and not isinstance(value, int):
                return False, f"Field '{field}' must be integer"
            elif expected_type == "string" and not isinstance(value, str):
                return False, f"Field '{field}' must be string"
            elif expected_type == "boolean" and not isinstance(value, bool):
                return False, f"Field '{field}' must be boolean"

            # Validate enum values
            if "enum" in spec and value not in spec["enum"]:
                return False, f"Field '{field}' must be one of {spec['enum']}"

        return True, None
