# Build a frontend-only deploy zip for Pallas.
# Refuses to package the backend folder or any .env / key files.

param(
    [string]$Output = "pallas-source.zip"
)

$ErrorActionPreference = "Stop"
$repoRoot = Split-Path -Parent $PSScriptRoot
Set-Location $repoRoot

if (Test-Path $Output) {
    Remove-Item $Output -Force
}

Write-Host "Packaging frontend deploy bundle..." -ForegroundColor Cyan

Compress-Archive `
    -Path src, public, package.json, package-lock.json, deployment `
    -DestinationPath $Output -Force

# Verify no secrets / no backend
Add-Type -AssemblyName System.IO.Compression.FileSystem
$archive = [System.IO.Compression.ZipFile]::OpenRead("$repoRoot\$Output")

$leaked = $archive.Entries | Where-Object {
    $_.FullName -like 'backend/*' -or
    $_.Name -like '.env*' -or
    $_.Name -like '*.key' -or
    $_.Name -like '*.pem'
}

$entries = $archive.Entries.Count
$sizeKb = [math]::Round((Get-Item "$repoRoot\$Output").Length / 1KB, 1)
$archive.Dispose()

if ($leaked) {
    Write-Host "ERROR: Refusing to ship - disallowed entries detected:" -ForegroundColor Red
    foreach ($e in $leaked) {
        Write-Host "    $($e.FullName)" -ForegroundColor Red
    }
    Remove-Item $Output -Force
    exit 1
}

Write-Host "OK: Bundle clean - no backend, no secrets" -ForegroundColor Green
Write-Host "  Entries: $entries"
Write-Host "  Size:    $sizeKb KB"
$outputName = $Output
Write-Host "  Output:  $outputName"
Write-Host ""
Write-Host "Next:" -ForegroundColor Cyan
$scpTarget = 'root@172.16.134.12:/tmp/'
Write-Host "  scp $outputName $scpTarget"
