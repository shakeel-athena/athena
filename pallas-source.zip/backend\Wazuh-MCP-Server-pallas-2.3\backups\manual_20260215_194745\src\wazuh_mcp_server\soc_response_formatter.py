"""
SOC Response Formatter - Context-Aware, Actionable Security Reporting
Formats responses based on query intent, showing only relevant data
"""

import json
import logging
from typing import Dict, Any, List, Optional
from datetime import datetime

logger = logging.getLogger(__name__)


class SOCResponseFormatter:
    """
    Formats tool responses into SOC-grade, context-aware reports.
    Key principles:
    - Show only what was asked for
    - No irrelevant sections
    - Actionable, not generic
    - Tabular when appropriate
    """
    
    @staticmethod
    def format_active_agents(data: Dict[str, Any]) -> str:
        """
        Format active agents - clean table, exclude manager
        """
        agents = data.get('data', {}).get('affected_items', [])
        
        # Filter out manager (ID 000)
        active_agents = [a for a in agents if a.get('id') != '000' and a.get('status') == 'active']
        
        if not active_agents:
            return "✅ No active agents found (excluding manager)"
        
        # Build clean table
        lines = [
            f"## 📊 Active Agents: {len(active_agents)}",
            "",
            "| Agent ID | Name | IP Address | OS | OS Version | Agent Version |",
            "|----------|------|------------|----|-----------:|---------------|"
        ]
        
        for agent in active_agents:
            agent_id = agent.get('id', 'N/A')
            name = agent.get('name', 'N/A')
            ip = agent.get('ip', 'N/A')
            os_name = agent.get('os', {}).get('name', 'N/A')
            os_version = agent.get('os', {}).get('version', 'N/A')
            agent_version = agent.get('version', 'N/A')
            
            lines.append(f"| {agent_id} | {name} | {ip} | {os_name} | {os_version} | {agent_version} |")
        
        lines.append("")
        lines.append(f"*Last updated: {datetime.utcnow().strftime('%Y-%m-%d %H:%M UTC')}*")
        
        return "\n".join(lines)
    
    @staticmethod
    def format_agent_status_summary(data: Dict[str, Any]) -> str:
        """
        Format agent status summary - clean breakdown
        """
        agents = data.get('data', {}).get('affected_items', [])
        
        # Exclude manager
        agents = [a for a in agents if a.get('id') != '000']
        
        # Count by status
        status_counts = {
            'active': 0,
            'disconnected': 0,
            'never_connected': 0,
            'pending': 0
        }
        
        for agent in agents:
            status = agent.get('status', 'unknown')
            if status in status_counts:
                status_counts[status] += 1
        
        total = sum(status_counts.values())
        
        lines = [
            "## 📊 Agent Status Summary",
            "",
            "| Status | Count | Percentage |",
            "|--------|------:|-----------:|"
        ]
        
        for status, count in status_counts.items():
            if count > 0:
                pct = (count / total * 100) if total > 0 else 0
                icon = "🟢" if status == "active" else "🔴" if status == "disconnected" else "🟡"
                lines.append(f"| {icon} {status.title()} | {count} | {pct:.1f}% |")
        
        lines.append(f"| **Total** | **{total}** | **100%** |")
        lines.append("")
        
        # Add actionable insights
        if status_counts['disconnected'] > 0:
            lines.append("### ⚠️ Action Required")
            lines.append(f"- **{status_counts['disconnected']} disconnected agents** need investigation")
            lines.append("- Check network connectivity, firewall rules, and agent service status")
            lines.append("")
        
        return "\n".join(lines)
    
    @staticmethod
    def format_critical_vulnerabilities(data: Dict[str, Any], limit: int = 15) -> str:
        """
        Format critical vulnerabilities - top N with actionable remediation
        """
        vulns = data.get('data', {}).get('affected_items', [])
        
        if not vulns:
            return "✅ No critical vulnerabilities found"
        
        # Sort by CVSS score (highest first)
        vulns = sorted(vulns, key=lambda v: float(v.get('cvss', {}).get('cvss3', {}).get('base_score', 0)), reverse=True)
        
        total = len(vulns)
        top_vulns = vulns[:limit]
        
        lines = [
            f"## 🔴 Critical Vulnerabilities: {total} Total",
            "",
            f"**Showing top {len(top_vulns)} by CVSS score**",
            "",
            "| CVE ID | Agent | Package | CVSS | Status | Fix Available |",
            "|--------|-------|---------|-----:|--------|---------------|"
        ]
        
        for vuln in top_vulns:
            cve = vuln.get('cve', 'N/A')
            agent_id = vuln.get('agent_id', 'N/A')
            package = vuln.get('name', 'N/A')
            cvss = vuln.get('cvss', {}).get('cvss3', {}).get('base_score', 'N/A')
            status = vuln.get('status', 'Unknown')
            
            # Determine if fix is available
            fix_version = vuln.get('detection_time', '')  # This would need real data
            fix_available = "Yes" if fix_version else "Unknown"
            
            lines.append(f"| {cve} | {agent_id} | {package} | {cvss} | {status} | {fix_available} |")
        
        if total > limit:
            lines.append("")
            lines.append(f"*...and {total - limit} more. Use filters to see all.*")
        
        # Add immediate actions
        lines.append("")
        lines.append("### ⚡ Immediate Actions")
        lines.append("")
        
        # Group by package for easier patching
        packages = {}
        for vuln in top_vulns:
            pkg = vuln.get('name', 'Unknown')
            if pkg not in packages:
                packages[pkg] = []
            packages[pkg].append(vuln.get('cve', 'N/A'))
        
        for pkg, cves in list(packages.items())[:5]:  # Top 5 packages
            lines.append(f"**{pkg}**")
            lines.append(f"- CVEs: {', '.join(cves[:3])}{'...' if len(cves) > 3 else ''}")
            lines.append(f"- Command: `yum update {pkg}` or `apt-get install --only-upgrade {pkg}`")
            lines.append("")
        
        return "\n".join(lines)
    
    @staticmethod
    def format_recent_alerts(data: Dict[str, Any], limit: int = 20) -> str:
        """
        Format recent alerts - latest N with analysis
        """
        alerts = data.get('data', {}).get('affected_items', [])
        
        if not alerts:
            return "✅ No alerts in the specified time range"
        
        total = len(alerts)
        recent = alerts[:limit]
        
        # Analyze alert patterns
        rule_counts = {}
        severity_counts = {'critical': 0, 'high': 0, 'medium': 0, 'low': 0}
        
        for alert in alerts:
            rule_id = alert.get('rule', {}).get('id', 'unknown')
            rule_counts[rule_id] = rule_counts.get(rule_id, 0) + 1
            
            level = alert.get('rule', {}).get('level', 0)
            if level >= 12:
                severity_counts['critical'] += 1
            elif level >= 7:
                severity_counts['high'] += 1
            elif level >= 4:
                severity_counts['medium'] += 1
            else:
                severity_counts['low'] += 1
        
        lines = [
            f"## 🚨 Recent Alerts: {total} in last 24h",
            "",
            "### 📊 Severity Breakdown",
            "",
            f"- 🔴 Critical (L12+): {severity_counts['critical']}",
            f"- 🟠 High (L7-11): {severity_counts['high']}",
            f"- 🟡 Medium (L4-6): {severity_counts['medium']}",
            f"- 🟢 Low (L1-3): {severity_counts['low']}",
            "",
            f"### 📋 Latest {len(recent)} Alerts",
            "",
            "| Time | Rule ID | Level | Agent | Description |",
            "|------|---------|------:|-------|-------------|"
        ]
        
        for alert in recent:
            timestamp = alert.get('timestamp', 'N/A')[:16]  # YYYY-MM-DD HH:MM
            rule_id = alert.get('rule', {}).get('id', 'N/A')
            level = alert.get('rule', {}).get('level', 'N/A')
            agent = alert.get('agent', {}).get('name', 'N/A')
            desc = alert.get('rule', {}).get('description', 'N/A')[:60]
            
            level_icon = "🔴" if level >= 12 else "🟠" if level >= 7 else "🟡" if level >= 4 else "🟢"
            
            lines.append(f"| {timestamp} | {rule_id} | {level_icon} {level} | {agent} | {desc} |")
        
        # Add pattern analysis
        lines.append("")
        lines.append("### 🔍 Pattern Analysis")
        lines.append("")
        
        # Top 3 most frequent rules
        top_rules = sorted(rule_counts.items(), key=lambda x: x[1], reverse=True)[:3]
        for rule_id, count in top_rules:
            pct = (count / total * 100)
            lines.append(f"- **Rule {rule_id}**: {count} times ({pct:.1f}%)")
        
        # Actionable recommendations
        lines.append("")
        lines.append("### 💡 Recommendations")
        lines.append("")
        
        if severity_counts['critical'] > 0:
            lines.append(f"- ⚠️ **{severity_counts['critical']} critical alerts** require immediate investigation")
        
        if severity_counts['high'] > 10:
            lines.append(f"- 📊 High volume of high-severity alerts - check for ongoing attack or misconfiguration")
        
        if len(top_rules) > 0 and top_rules[0][1] > total * 0.3:
            lines.append(f"- 🔁 Rule {top_rules[0][0]} is very frequent - may need tuning to reduce noise")
        
        lines.append(f"- 📖 Review older alerts manually if needed (showing latest {limit} of {total})")
        
        return "\n".join(lines)
    
    @staticmethod
    def format_response(query_type: str, data: Dict[str, Any], **kwargs) -> str:
        """
        Main formatter - routes to appropriate sub-formatter
        """
        formatters = {
            'active_agents': SOCResponseFormatter.format_active_agents,
            'agent_status': SOCResponseFormatter.format_agent_status_summary,
            'critical_vulnerabilities': SOCResponseFormatter.format_critical_vulnerabilities,
            'recent_alerts': SOCResponseFormatter.format_recent_alerts,
        }
        
        formatter = formatters.get(query_type)
        if formatter:
            return formatter(data, **kwargs)
        
        # Fallback: clean JSON
        return f"```json\n{json.dumps(data, indent=2)}\n```"
