"""
Correlation Engine - Intelligent multi-tool result correlation
Handles primary → secondary tool orchestration and data merging

Supports:
- Vulnerabilities ↔ Agents enrichment
- Agent ranking by vulnerability count
- Filters (active/disconnected + critical/high)
- Threshold queries (e.g., >100 vulnerabilities)
- Comparison queries (active vs disconnected)
- Agent posture deep-dive (vulns + ports + processes) when secondary tools are executed
"""

import json
import logging
from typing import List, Dict, Any, Optional, Callable
from dataclasses import dataclass

logger = logging.getLogger(__name__)


@dataclass
class CorrelationResult:
    correlated_data: List[Dict[str, Any]]
    summary: Dict[str, Any]
    correlation_type: str
    primary_tool: str
    secondary_tools: List[str]


_PENDING_STRATEGIES: Dict[str, Callable] = {}


def register_strategy(name: str):
    """Decorator to register correlation strategies (lazy)"""
    def decorator(func):
        _PENDING_STRATEGIES[name] = func
        return func
    return decorator


class CorrelationEngine:
    """
    Correlates data from multiple tool executions.
    Handles MCP tool wrapper + Wazuh API structures robustly.
    """

    STRATEGIES: Dict[str, Callable] = {}

    # -----------------------------
    # Core normalize/extract helpers
    # -----------------------------
    def _normalize_tool_payload(self, payload: Any) -> Dict[str, Any]:
        """
        Normalize raw MCP tool responses to a consistent dict:
          {"data": {"affected_items":[...]}}
        Handles:
        - {"content":[{"text":"{json}"}]}
        - {"data": {...}}
        - {"affected_items":[...]}  (already data-like)
        """
        if payload is None:
            return {"data": {"affected_items": []}}

        if isinstance(payload, dict):
            # MCP wrapper: {"content":[{"text":"...json..."}]}
            if "content" in payload and isinstance(payload.get("content"), list) and payload["content"]:
                text = payload["content"][0].get("text", "")
                if isinstance(text, str) and text.strip():
                    try:
                        parsed = json.loads(text)
                        if isinstance(parsed, dict):
                            if "data" in parsed and isinstance(parsed["data"], dict):
                                return parsed
                            if "affected_items" in parsed and isinstance(parsed.get("affected_items"), list):
                                return {"data": parsed}
                            # fallback: treat parsed as data object
                            return {"data": parsed}
                    except json.JSONDecodeError:
                        return {"data": {"affected_items": []}, "meta": {"raw_text": text[:500]}}

            # Wazuh-style: {"data": {...}}
            if "data" in payload and isinstance(payload["data"], dict):
                return payload

            # Data-like already
            if "affected_items" in payload and isinstance(payload.get("affected_items"), list):
                return {"data": payload}

            # Last fallback
            return {"data": {"affected_items": []}, "meta": {"raw": payload}}

        return {"data": {"affected_items": []}, "meta": {"payload_type": str(type(payload))}}

    def _items(self, normalized: Dict[str, Any]) -> List[Dict[str, Any]]:
        data = normalized.get("data", {})
        if isinstance(data, dict):
            items = data.get("affected_items", [])
            return items if isinstance(items, list) else []
        return []

    def _severity_rank(self, sev: Any) -> int:
        order = {"critical": 0, "high": 1, "medium": 2, "low": 3}
        return order.get(str(sev or "low").lower(), 99)

    def _extract_cvss_score(self, vuln: Dict[str, Any]) -> Optional[float]:
        cvss = vuln.get("cvss") or {}
        try:
            cvss3 = (cvss.get("cvss3") or {}).get("base_score")
            if cvss3 is not None:
                return float(cvss3)
            cvss2 = (cvss.get("cvss2") or {}).get("base_score")
            if cvss2 is not None:
                return float(cvss2)
        except Exception:
            return None
        return None

    def _compact_agent(self, a: Dict[str, Any]) -> Dict[str, Any]:
        return {
            "id": a.get("id"),
            "name": a.get("name"),
            "ip": a.get("ip"),
            "status": a.get("status"),
            "os": (a.get("os") or {}).get("name"),
            "os_version": (a.get("os") or {}).get("version"),
            "last_keep_alive": a.get("lastKeepAlive"),
            "groups": a.get("group", []) or a.get("groups", []),
        }

    def _summarize_vulnerabilities(self, vulns: List[Dict[str, Any]]) -> Dict[str, int]:
        out = {"total": len(vulns), "critical": 0, "high": 0, "medium": 0, "low": 0}
        for v in vulns:
            s = str(v.get("severity", "low")).lower()
            if s in out:
                out[s] += 1
        return out

    def _calculate_agent_risk_score(self, agent: Dict[str, Any], vulns: List[Dict[str, Any]]) -> int:
        score = 0
        vs = self._summarize_vulnerabilities(vulns)
        score += vs["critical"] * 25
        score += vs["high"] * 10
        score += vs["medium"] * 3
        score += vs["low"] * 1
        if str(agent.get("status", "")).lower() == "disconnected":
            score += 20
        return min(100, score)

    def _top_vulns_minimal(self, vulns: List[Dict[str, Any]], limit: int = 10) -> List[Dict[str, Any]]:
        def rank(v):
            return (self._severity_rank(v.get("severity")), -(self._extract_cvss_score(v) or 0.0))

        out = []
        for v in sorted(vulns, key=rank)[:limit]:
            out.append({
                "cve_id": v.get("id") or v.get("cve") or v.get("cve_id"),
                "severity": v.get("severity"),
                "cvss_score": self._extract_cvss_score(v),
                "package": (v.get("package") or {}).get("name"),
                "version": (v.get("package") or {}).get("version"),
                "status": v.get("status"),
                "detected_at": v.get("detected_at"),
                "agent_id": (v.get("agent") or {}).get("id"),
            })
        return out

    def _calculate_vuln_risk_factors(self, vuln: Dict[str, Any], agent: Dict[str, Any]) -> List[str]:
        factors: List[str] = []
        sev = str(vuln.get("severity", "")).lower()
        if sev in ("critical", "high"):
            factors.append(f"{sev.capitalize()} severity")

        if str(agent.get("status", "")).lower() == "disconnected":
            factors.append("Agent offline - patch visibility may be stale")

        groups = agent.get("group", []) or agent.get("groups", [])
        if any(("dmz" in str(g).lower()) or ("web" in str(g).lower()) for g in groups):
            factors.append("Internet-facing system (group heuristic)")

        score = self._extract_cvss_score(vuln)
        if score is not None and score >= 9.0:
            factors.append("CVSS >= 9.0")

        return factors

    def _count_by_agent_status(self, items: List[Dict[str, Any]]) -> Dict[str, int]:
        counts = {"active": 0, "disconnected": 0, "unknown": 0}
        for it in items:
            st = str((it.get("agent") or {}).get("status", "unknown")).lower()
            counts[st] = counts.get(st, 0) + 1 if st in counts else counts["unknown"] + 1
        return counts

    def _count_by_severity(self, items: List[Dict[str, Any]]) -> Dict[str, int]:
        out = {"Critical": 0, "High": 0, "Medium": 0, "Low": 0}
        for it in items:
            s = str(it.get("severity", "low")).lower()
            if s == "critical": out["Critical"] += 1
            elif s == "high": out["High"] += 1
            elif s == "medium": out["Medium"] += 1
            else: out["Low"] += 1
        return out

    # -----------------------------
    # Public API
    # -----------------------------
    def correlate(
        self,
        strategy: str,
        primary_result: Dict[str, Any],
        secondary_results: List[Dict[str, Any]],
        context: Optional[Dict[str, Any]] = None
    ) -> CorrelationResult:

        context = context or {}

        primary_norm = self._normalize_tool_payload(primary_result)
        secondary_norm = [self._normalize_tool_payload(r) for r in (secondary_results or [])]

        correlator = self.STRATEGIES.get(strategy)
        if not correlator:
            logger.warning(f"Unknown correlation strategy: {strategy}")
            return self._fallback(primary_norm, secondary_norm)

        try:
            return correlator(self, primary_norm, secondary_norm, context)
        except Exception as e:
            logger.error(f"Correlation '{strategy}' failed: {e}", exc_info=True)
            return self._fallback(primary_norm, secondary_norm)

    def _fallback(self, primary_norm: Dict[str, Any], secondary_norm: List[Dict[str, Any]]) -> CorrelationResult:
        all_items: List[Dict[str, Any]] = []
        all_items.extend(self._items(primary_norm))
        for r in secondary_norm:
            all_items.extend(self._items(r))

        return CorrelationResult(
            correlated_data=all_items,
            summary={"total_items": len(all_items), "mode": "fallback"},
            correlation_type="fallback",
            primary_tool="unknown",
            secondary_tools=[]
        )

    # ================================================================
    # STRATEGIES
    # ================================================================

    @register_strategy("vulnerability_with_agents")
    def vulnerability_with_agents(self, primary: Dict[str, Any], secondary: List[Dict[str, Any]], context: Dict[str, Any]) -> CorrelationResult:
        vulns = self._items(primary)

        agents: List[Dict[str, Any]] = []
        for r in secondary:
            agents.extend(self._items(r))

        agent_map = {a.get("id"): a for a in agents if a.get("id")}

        enriched: List[Dict[str, Any]] = []
        affected_agents = set()

        for v in vulns:
            aid = (v.get("agent") or {}).get("id")
            if aid and aid in agent_map:
                a = agent_map[aid]
                affected_agents.add(aid)
                enriched.append({
                    "cve_id": v.get("id") or v.get("cve") or v.get("cve_id"),
                    "id": v.get("id"),
                    "severity": v.get("severity"),
                    "status": v.get("status"),
                    "detected_at": v.get("detected_at"),
                    "description": (v.get("description") or "")[:250],
                    "cvss_score": self._extract_cvss_score(v),
                    "package": {
                        "name": (v.get("package") or {}).get("name"),
                        "version": (v.get("package") or {}).get("version"),
                    },
                    "agent": self._compact_agent(a),
                    "risk_factors": self._calculate_vuln_risk_factors(v, a),
                })
            else:
                enriched.append({
                    "cve_id": v.get("id") or v.get("cve") or v.get("cve_id"),
                    "id": v.get("id"),
                    "severity": v.get("severity"),
                    "agent": {"id": aid, "name": (v.get("agent") or {}).get("name", "Unknown")},
                    "note": "Agent details not available"
                })

        enriched.sort(key=lambda x: self._severity_rank(x.get("severity")))

        return CorrelationResult(
            correlated_data=enriched,
            summary={
                "total_vulnerabilities": len(vulns),
                "affected_agents": len(affected_agents),
                "by_severity": self._count_by_severity(enriched),
                "by_agent_status": self._count_by_agent_status(enriched),
            },
            correlation_type="vulnerability_with_agents",
            primary_tool="get_wazuh_vulnerabilities",
            secondary_tools=["get_wazuh_agents"]
        )

    @register_strategy("agents_with_vulnerabilities")
    def agents_with_vulnerabilities(self, primary: Dict[str, Any], secondary: List[Dict[str, Any]], context: Dict[str, Any]) -> CorrelationResult:
        agents = self._items(primary)
        vulns: List[Dict[str, Any]] = []
        for r in secondary:
            vulns.extend(self._items(r))

        by_agent: Dict[str, List[Dict[str, Any]]] = {}
        for v in vulns:
            aid = (v.get("agent") or {}).get("id")
            if aid:
                by_agent.setdefault(aid, []).append(v)

        out: List[Dict[str, Any]] = []
        for a in agents:
            aid = a.get("id")
            vlist = by_agent.get(aid, [])
            vs = self._summarize_vulnerabilities(vlist)
            out.append({
                **self._compact_agent(a),
                "vulnerability_count": vs["total"],
                "by_severity": {"critical": vs["critical"], "high": vs["high"], "medium": vs["medium"], "low": vs["low"]},
                "risk_score": self._calculate_agent_risk_score(a, vlist),
                "top_vulnerabilities": self._top_vulns_minimal(vlist, limit=10),
            })

        out.sort(key=lambda x: x.get("vulnerability_count", 0), reverse=True)

        return CorrelationResult(
            correlated_data=out,
            summary={
                "total_agents": len(agents),
                "total_vulnerabilities": len(vulns),
                "agents_with_vulnerabilities": sum(1 for x in out if x.get("vulnerability_count", 0) > 0),
            },
            correlation_type="agents_with_vulnerabilities",
            primary_tool="get_wazuh_agents",
            secondary_tools=["get_wazuh_vulnerabilities"]
        )

    @register_strategy("disconnected_agents_with_critical_vulns")
    def disconnected_agents_with_critical_vulns(self, primary: Dict[str, Any], secondary: List[Dict[str, Any]], context: Dict[str, Any]) -> CorrelationResult:
        agents = self._items(primary)

        vulns: List[Dict[str, Any]] = []
        for r in secondary:
            vulns.extend(self._items(r))

        critical = [v for v in vulns if str(v.get("severity", "")).lower() == "critical"]
        by_agent: Dict[str, List[Dict[str, Any]]] = {}
        for v in critical:
            aid = (v.get("agent") or {}).get("id")
            if aid:
                by_agent.setdefault(aid, []).append(v)

        out: List[Dict[str, Any]] = []
        disconnected = [a for a in agents if str(a.get("status", "")).lower() == "disconnected"]
        for a in disconnected:
            aid = a.get("id")
            vlist = by_agent.get(aid, [])
            if not vlist:
                continue
            out.append({
                **self._compact_agent(a),
                "critical_vulnerability_count": len(vlist),
                "top_critical_vulnerabilities": self._top_vulns_minimal(vlist, limit=10),
                "risk_score": self._calculate_agent_risk_score(a, vlist),
            })

        out.sort(key=lambda x: x.get("critical_vulnerability_count", 0), reverse=True)

        return CorrelationResult(
            correlated_data=out,
            summary={
                "disconnected_agents_with_critical_vulns": len(out),
                "total_disconnected_agents": len(disconnected),
                "total_critical_vulns_seen": len(critical),
            },
            correlation_type="disconnected_agents_with_critical_vulns",
            primary_tool="get_wazuh_agents",
            secondary_tools=["get_wazuh_vulnerabilities"]
        )

    @register_strategy("top_agents_by_vuln_count")
    def top_agents_by_vuln_count(self, primary: Dict[str, Any], secondary: List[Dict[str, Any]], context: Dict[str, Any]) -> CorrelationResult:
        top_n = int(context.get("top_n", 5))

        agents = self._items(primary)
        agent_map = {a.get("id"): a for a in agents if a.get("id")}

        vulns: List[Dict[str, Any]] = []
        for r in secondary:
            vulns.extend(self._items(r))

        counts: Dict[str, int] = {}
        for v in vulns:
            aid = (v.get("agent") or {}).get("id")
            if aid:
                counts[aid] = counts.get(aid, 0) + 1

        ranked = sorted(counts.items(), key=lambda kv: kv[1], reverse=True)[:top_n]

        out: List[Dict[str, Any]] = []
        for aid, total in ranked:
            a = agent_map.get(aid, {"id": aid, "name": "Unknown", "status": "unknown"})
            out.append({**self._compact_agent(a), "vulnerability_count": total})

        return CorrelationResult(
            correlated_data=out,
            summary={"top_n": top_n, "total_vulnerabilities_seen": len(vulns)},
            correlation_type="top_agents_by_vuln_count",
            primary_tool="get_wazuh_agents",
            secondary_tools=["get_wazuh_vulnerabilities"]
        )

    @register_strategy("active_agents_vulns_over_threshold")
    def active_agents_vulns_over_threshold(self, primary: Dict[str, Any], secondary: List[Dict[str, Any]], context: Dict[str, Any]) -> CorrelationResult:
        threshold = int(context.get("threshold", 100))

        agents = self._items(primary)
        vulns: List[Dict[str, Any]] = []
        for r in secondary:
            vulns.extend(self._items(r))

        counts: Dict[str, int] = {}
        for v in vulns:
            aid = (v.get("agent") or {}).get("id")
            if aid:
                counts[aid] = counts.get(aid, 0) + 1

        out: List[Dict[str, Any]] = []
        for a in agents:
            if str(a.get("status", "")).lower() != "active":
                continue
            aid = a.get("id")
            total = counts.get(aid, 0)
            if total > threshold:
                out.append({**self._compact_agent(a), "vulnerability_count": total})

        out.sort(key=lambda x: x.get("vulnerability_count", 0), reverse=True)

        return CorrelationResult(
            correlated_data=out,
            summary={"threshold": threshold, "active_agents_over_threshold": len(out)},
            correlation_type="active_agents_vulns_over_threshold",
            primary_tool="get_wazuh_agents",
            secondary_tools=["get_wazuh_vulnerabilities"]
        )

    @register_strategy("active_agents_with_high_vulns")
    def active_agents_with_high_vulns(self, primary: Dict[str, Any], secondary: List[Dict[str, Any]], context: Dict[str, Any]) -> CorrelationResult:
        agents = self._items(primary)
        vulns: List[Dict[str, Any]] = []
        for r in secondary:
            vulns.extend(self._items(r))

        high = [v for v in vulns if str(v.get("severity", "")).lower() == "high"]
        by_agent: Dict[str, int] = {}
        for v in high:
            aid = (v.get("agent") or {}).get("id")
            if aid:
                by_agent[aid] = by_agent.get(aid, 0) + 1

        out: List[Dict[str, Any]] = []
        for a in agents:
            if str(a.get("status", "")).lower() != "active":
                continue
            aid = a.get("id")
            c = by_agent.get(aid, 0)
            if c > 0:
                out.append({**self._compact_agent(a), "high_vulnerability_count": c})

        out.sort(key=lambda x: x.get("high_vulnerability_count", 0), reverse=True)

        return CorrelationResult(
            correlated_data=out,
            summary={"active_agents_with_high_vulns": len(out), "total_high_vulns_seen": len(high)},
            correlation_type="active_agents_with_high_vulns",
            primary_tool="get_wazuh_agents",
            secondary_tools=["get_wazuh_vulnerabilities"]
        )

    @register_strategy("compare_vulns_active_vs_disconnected")
    def compare_vulns_active_vs_disconnected(self, primary: Dict[str, Any], secondary: List[Dict[str, Any]], context: Dict[str, Any]) -> CorrelationResult:
        agents = self._items(primary)
        status_map = {a.get("id"): str(a.get("status", "unknown")).lower() for a in agents if a.get("id")}

        vulns: List[Dict[str, Any]] = []
        for r in secondary:
            vulns.extend(self._items(r))

        active = disconnected = unknown = 0
        for v in vulns:
            aid = (v.get("agent") or {}).get("id")
            st = status_map.get(aid, "unknown")
            if st == "active":
                active += 1
            elif st == "disconnected":
                disconnected += 1
            else:
                unknown += 1

        return CorrelationResult(
            correlated_data=[{
                "active_vulnerabilities": active,
                "disconnected_vulnerabilities": disconnected,
                "unknown_status_vulnerabilities": unknown
            }],
            summary={
                "active_vulnerabilities": active,
                "disconnected_vulnerabilities": disconnected,
                "unknown_status_vulnerabilities": unknown
            },
            correlation_type="compare_vulns_active_vs_disconnected",
            primary_tool="get_wazuh_agents",
            secondary_tools=["get_wazuh_vulnerabilities"]
        )


# Apply pending strategy registrations
CorrelationEngine.STRATEGIES = _PENDING_STRATEGIES

