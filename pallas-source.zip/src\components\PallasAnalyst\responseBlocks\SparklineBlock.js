/**
 * SparklineBlock — Time-series mini chart for trends
 *
 * Replaces flat 2-column "date | count" tables with a polished line/area
 * chart so trends become visually obvious at a glance.
 *
 * Features:
 *   - Hand-rolled SVG line + area gradient (no chart libs)
 *   - Animated path draw on mount (stroke-dasharray)
 *   - Hover dots show tooltips with value + label
 *   - X-axis: time labels (auto-thinned if too many)
 *   - Y-axis: min / max value labels
 *   - Min / Max / Avg / Last value indicators above the chart
 *   - Trend arrow (▲ ▼ —) showing direction from first → last point
 *   - Color-coded trend: green if downward (good), red if upward (bad)
 *   - Responsive via SVG viewBox
 *
 * Data shape (from BlockParser when a time-series table is detected):
 *   {
 *     points: [
 *       { label: '2026-04-08', value: 1234 },
 *       { label: '2026-04-09', value: 1567 },
 *       ...
 *     ],
 *     metricLabel: 'Alerts',
 *     timeLabel:   'Date'
 *   }
 */

import { useState, useEffect, useMemo, useRef } from 'react';
import { THEME, GRADIENTS, SHADOWS, TIMINGS } from '../../../utils/theme';
import { FONT } from '../PallasUI';
import { useAnimatedCounter, useReducedMotion, formatNumber } from './blockHelpers';

// ─── SVG geometry ───────────────────────────────────────────────────────────

const VIEW_W = 600;
const VIEW_H = 160;
const PAD_LEFT = 50;
const PAD_RIGHT = 16;
const PAD_TOP = 18;
const PAD_BOTTOM = 30;
const CHART_W = VIEW_W - PAD_LEFT - PAD_RIGHT;
const CHART_H = VIEW_H - PAD_TOP - PAD_BOTTOM;

// Build the line path "M x,y L x,y L ..." from points
function buildLinePath(points, scaleX, scaleY) {
  if (points.length === 0) return '';
  let d = '';
  points.forEach((p, i) => {
    const x = scaleX(i);
    const y = scaleY(p.value);
    d += i === 0 ? `M ${x} ${y}` : ` L ${x} ${y}`;
  });
  return d;
}

// Build the area path (line + close to baseline)
function buildAreaPath(points, scaleX, scaleY) {
  if (points.length === 0) return '';
  const baseline = PAD_TOP + CHART_H;
  let d = `M ${scaleX(0)} ${baseline}`;
  points.forEach((p, i) => {
    d += ` L ${scaleX(i)} ${scaleY(p.value)}`;
  });
  d += ` L ${scaleX(points.length - 1)} ${baseline} Z`;
  return d;
}

// ─── Component ──────────────────────────────────────────────────────────────

export default function SparklineBlock({ data, onPivot }) {
  const reduced = useReducedMotion();
  const [mounted, setMounted] = useState(false);
  const [hoverIdx, setHoverIdx] = useState(null);
  const pathRef = useRef(null);
  const [pathLen, setPathLen] = useState(0);

  useEffect(() => {
    if (reduced) {
      setMounted(true);
      return;
    }
    const id = requestAnimationFrame(() => setMounted(true));
    return () => cancelAnimationFrame(id);
  }, [reduced]);

  useEffect(() => {
    // Once the path is rendered, capture its length so we can animate the dash
    if (pathRef.current) {
      setPathLen(pathRef.current.getTotalLength());
    }
  }, [data]);

  const points = data?.points || [];
  const metricLabel = data?.metricLabel || 'Value';

  // Stats
  const stats = useMemo(() => {
    if (points.length === 0) return { min: 0, max: 0, avg: 0, first: 0, last: 0, delta: 0, deltaPct: 0 };
    const values = points.map((p) => p.value);
    const min = Math.min(...values);
    const max = Math.max(...values);
    const avg = Math.round(values.reduce((a, b) => a + b, 0) / values.length);
    const first = values[0];
    const last = values[values.length - 1];
    const delta = last - first;
    const deltaPct = first > 0 ? ((delta / first) * 100) : 0;
    return { min, max, avg, first, last, delta, deltaPct };
  }, [points]);

  // Y-scale: leave 5% headroom above max so the line doesn't touch the top
  const yMin = 0;
  const yMax = stats.max > 0 ? stats.max * 1.08 : 1;

  const scaleX = (i) => PAD_LEFT + (points.length > 1 ? (i / (points.length - 1)) * CHART_W : CHART_W / 2);
  const scaleY = (v) => PAD_TOP + CHART_H - ((v - yMin) / (yMax - yMin)) * CHART_H;

  const linePath = buildLinePath(points, scaleX, scaleY);
  const areaPath = buildAreaPath(points, scaleX, scaleY);

  // Trend coloring — line is good (green) if values trend down, bad (red) if trending up
  // (Most security trends — alerts/vulns — are bad when going up.)
  const trendUp = stats.delta > 0;
  const trendNeutral = stats.delta === 0;
  const trendColor = trendNeutral
    ? THEME.textMuted
    : (trendUp ? THEME.danger : THEME.success);
  const trendIcon = trendNeutral ? '—' : (trendUp ? '▲' : '▼');

  // Animated last value
  const animatedLast = useAnimatedCounter(stats.last, 900);

  // Auto-thin X-axis labels if too many
  const xLabelEvery = Math.max(1, Math.ceil(points.length / 6));

  if (points.length < 2) return null;

  return (
    <div
      style={{
        margin: '14px 0',
        background: GRADIENTS.card,
        border: `1px solid ${THEME.border}`,
        borderRadius: 12,
        padding: '14px 16px',
        boxShadow: SHADOWS.md + ", inset 0 1px 0 rgba(255,255,255,0.04)",
      }}
    >
      {/* Header row: metric label + trend stats */}
      <div
        style={{
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'space-between',
          marginBottom: 10,
          flexWrap: 'wrap',
          gap: 8,
        }}
      >
        <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
          <span
            style={{
              width: 3,
              height: 14,
              background: GRADIENTS.primaryAccent,
              borderRadius: 2,
              flexShrink: 0,
            }}
          />
          <h4
            style={{
              margin: 0,
              fontSize: 12,
              fontWeight: 700,
              color: THEME.textSecondary,
              textTransform: 'uppercase',
              letterSpacing: '0.05em',
            }}
          >
            {metricLabel} Trend
          </h4>
        </div>
        <div style={{ display: 'flex', alignItems: 'center', gap: 14, flexWrap: 'wrap' }}>
          <Stat label="Last"  value={animatedLast} color={THEME.text} />
          <Stat label="Avg"   value={stats.avg}    color={THEME.textSecondary} />
          <Stat label="Max"   value={stats.max}    color={THEME.warning} />
          {!trendNeutral && (
            <span
              style={{
                display: 'inline-flex',
                alignItems: 'center',
                gap: 4,
                padding: '3px 9px',
                borderRadius: 5,
                background: `${trendColor}15`,
                border: `1px solid ${trendColor}40`,
                fontSize: 11,
                fontWeight: 700,
                color: trendColor,
                fontFamily: FONT.mono,
              }}
            >
              {trendIcon} {Math.abs(stats.deltaPct).toFixed(1)}%
            </span>
          )}
        </div>
      </div>

      {/* SVG chart — max height capped so it doesn't dominate on wide screens */}
      <svg
        viewBox={`0 0 ${VIEW_W} ${VIEW_H}`}
        preserveAspectRatio="xMidYMid meet"
        style={{ display: 'block', width: '100%', height: 'auto', maxHeight: 180 }}
        onMouseLeave={() => setHoverIdx(null)}
      >
        <defs>
          <linearGradient id="spark-area" x1="0%" y1="0%" x2="0%" y2="100%">
            <stop offset="0%"   stopColor={THEME.primary} stopOpacity="0.40" />
            <stop offset="100%" stopColor={THEME.primary} stopOpacity="0.00" />
          </linearGradient>
        </defs>

        {/* Y-axis labels (max + min only, kept minimal) */}
        <text
          x={PAD_LEFT - 8}
          y={PAD_TOP + 4}
          textAnchor="end"
          fontSize="9"
          fontFamily={FONT.mono}
          fill={THEME.textMuted}
        >
          {formatNumber(stats.max)}
        </text>
        <text
          x={PAD_LEFT - 8}
          y={PAD_TOP + CHART_H}
          textAnchor="end"
          fontSize="9"
          fontFamily={FONT.mono}
          fill={THEME.textMuted}
        >
          {formatNumber(yMin)}
        </text>

        {/* Horizontal grid lines (subtle) */}
        {[0, 0.25, 0.5, 0.75, 1].map((p, i) => (
          <line
            key={i}
            x1={PAD_LEFT}
            y1={PAD_TOP + p * CHART_H}
            x2={PAD_LEFT + CHART_W}
            y2={PAD_TOP + p * CHART_H}
            stroke={THEME.border}
            strokeWidth="0.5"
            strokeDasharray="2 4"
            opacity="0.5"
          />
        ))}

        {/* Area fill (background) */}
        <path
          d={areaPath}
          fill="url(#spark-area)"
          opacity={mounted ? 1 : 0}
          style={{
            transition: `opacity ${TIMINGS.slowest} ${TIMINGS.ease}`,
          }}
        />

        {/* Line stroke (animated draw) */}
        <path
          ref={pathRef}
          d={linePath}
          fill="none"
          stroke={THEME.primary}
          strokeWidth="2"
          strokeLinecap="round"
          strokeLinejoin="round"
          style={{
            strokeDasharray: pathLen || 1000,
            strokeDashoffset: mounted ? 0 : (pathLen || 1000),
            transition: `stroke-dashoffset ${TIMINGS.slowest} ${TIMINGS.ease}`,
            filter: `drop-shadow(0 0 4px ${THEME.primary}60)`,
          }}
        />

        {/* Hover dots (interactive points) */}
        {points.map((p, i) => {
          const x = scaleX(i);
          const y = scaleY(p.value);
          const isHover = hoverIdx === i;
          return (
            <g key={i}>
              {/* Larger transparent target for hover */}
              <rect
                x={x - 10}
                y={PAD_TOP}
                width={20}
                height={CHART_H}
                fill="transparent"
                onMouseEnter={() => setHoverIdx(i)}
                style={{ cursor: 'pointer' }}
              />
              {isHover && (
                <>
                  {/* Vertical guide line */}
                  <line
                    x1={x}
                    y1={PAD_TOP}
                    x2={x}
                    y2={PAD_TOP + CHART_H}
                    stroke={THEME.primary}
                    strokeWidth="0.5"
                    strokeDasharray="2 2"
                    opacity="0.6"
                  />
                  {/* Hover dot */}
                  <circle
                    cx={x}
                    cy={y}
                    r={4.5}
                    fill={THEME.primary}
                    stroke={THEME.bgDeep}
                    strokeWidth="2"
                    style={{ filter: `drop-shadow(0 0 8px ${THEME.primary})` }}
                  />
                  {/* Tooltip */}
                  <g transform={`translate(${Math.min(VIEW_W - 90, Math.max(10, x - 40))}, ${Math.max(2, y - 32)})`}>
                    <rect
                      x="0"
                      y="0"
                      width="80"
                      height="26"
                      rx="4"
                      fill={THEME.bgDeep}
                      stroke={THEME.primary}
                      strokeWidth="0.5"
                      opacity="0.96"
                    />
                    <text x="40" y="11" textAnchor="middle" fontSize="9" fontFamily={FONT.mono} fill={THEME.textMuted}>
                      {p.label}
                    </text>
                    <text x="40" y="22" textAnchor="middle" fontSize="11" fontFamily={FONT.mono} fontWeight="700" fill={THEME.primary}>
                      {formatNumber(p.value)}
                    </text>
                  </g>
                </>
              )}
              {/* Permanent first/last dots */}
              {(i === 0 || i === points.length - 1) && !isHover && (
                <circle
                  cx={x}
                  cy={y}
                  r={3}
                  fill={i === points.length - 1 ? trendColor : THEME.primary}
                  stroke={THEME.bgDeep}
                  strokeWidth="1.5"
                  style={{ opacity: mounted ? 1 : 0, transition: `opacity ${TIMINGS.slow} ${TIMINGS.ease}` }}
                />
              )}
            </g>
          );
        })}

        {/* X-axis labels (auto-thinned) */}
        {points.map((p, i) => {
          if (i % xLabelEvery !== 0 && i !== points.length - 1) return null;
          const x = scaleX(i);
          return (
            <text
              key={`xlbl-${i}`}
              x={x}
              y={VIEW_H - 8}
              textAnchor="middle"
              fontSize="9"
              fontFamily={FONT.mono}
              fill={THEME.textMuted}
            >
              {p.label.length > 10 ? p.label.slice(5) /* drop year */ : p.label}
            </text>
          );
        })}
      </svg>
    </div>
  );
}

// ─── Inline stat helper ─────────────────────────────────────────────────────

function Stat({ label, value, color }) {
  return (
    <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'flex-end', minWidth: 0 }}>
      <span
        style={{
          fontSize: 9,
          color: THEME.textMuted,
          fontWeight: 600,
          textTransform: 'uppercase',
          letterSpacing: '0.05em',
          lineHeight: 1,
          marginBottom: 2,
        }}
      >
        {label}
      </span>
      <span
        style={{
          fontFamily: FONT.mono,
          fontSize: 12,
          fontWeight: 700,
          color,
          lineHeight: 1.1,
        }}
      >
        {formatNumber(value)}
      </span>
    </div>
  );
}
