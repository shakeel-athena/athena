"""
Direct MCP Mapper - Simple keyword to tool mapping
Bypasses orchestrator/formatter, returns raw MCP responses
"""

import re
from typing import Dict, Any, Tuple, Optional

class DirectMCPMapper:
    """Maps user queries to MCP tools using simple keywords"""
    
    def __init__(self):
        # Simple keyword to tool mapping
        self.mappings = [
            # Vulnerabilities
            (r"vulnerability summary|vuln summary", "get_wazuh_vulnerability_summary", {}),
            (r"critical vulnerabilit|critical vuln|critical cve", "get_wazuh_critical_vulnerabilities", {"limit": 100000}),
            (r"vulnerabilit|vuln|cve", "get_wazuh_vulnerabilities", {"limit": 100000}),
            
            # Agents
            (r"running agent|active agent|online agent", "get_wazuh_running_agents", {}),
            (r"agent status|all agent|list agent", "get_wazuh_agents", {}),
            
            # Alerts
            (r"alert.*24.*hour|alert.*last.*day|recent alert", "get_wazuh_alerts", {"time_range": "24h"}),
            (r"alert", "get_wazuh_alerts", {}),
            
            # Security
            (r"security report|generate report", "generate_security_report", {}),
            (r"top.*threat|security threat", "get_top_security_threats", {}),
            
            # Statistics
            (r"statistics|stats|system.*stat", "get_wazuh_statistics", {}),
            
            # Default
            (r".*", "get_wazuh_agents", {}),  # Fallback
        ]
    
    def map_query(self, query: str) -> Tuple[str, Dict[str, Any]]:
        """
        Map user query to MCP tool and arguments
        
        Returns:
            (tool_name, arguments)
        """
        query_lower = query.lower().strip()
        
        for pattern, tool_name, default_args in self.mappings:
            if re.search(pattern, query_lower, re.IGNORECASE):
                return tool_name, default_args
        
        # Fallback
        return "get_wazuh_agents", {}
