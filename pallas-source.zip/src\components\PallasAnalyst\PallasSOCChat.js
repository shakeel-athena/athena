/**
 * PallasSOCChat.js
 *
 * Redesigned SOC intelligence interface — ChatGPT-style layout with:
 *   - Page header with action buttons (Browse Quick Actions, History, Search, New Chat)
 *   - Welcome state with owl logo, category tabs, and quick action pills
 *   - Input area at bottom
 *   - Toggleable history sidebar
 */

import React, { useState, useRef, useEffect, useCallback } from 'react';
import { EuiIcon } from '@elastic/eui';
import { THEME } from '../../utils/theme';
import { usePallas } from '../../hooks/usePallas';
import { ResponsePanel, ComparePanel } from './PallasResponsePanel';
import PallasCommandPalette from './PallasCommandPalette';
import { FONT, MODULE_COLORS, ChatDisclaimer } from './PallasUI';
import { ALL_STRATEGY_CATEGORIES } from './PallasStrategies';
import PallasLogo from '../../artifacts/pallas-icon-light.svg';
import PallasDailyStandup from './PallasDailyStandup';
import PallasDetectIOC from './PallasDetectIOC';
import PallasDecoderLab from './PallasDecoderLab';
import PallasAttackNarrative from './PallasAttackNarrative';

// ─── Slash Command Data (built from strategies) ────────────────────────────────

const SLASH_COMMANDS = ALL_STRATEGY_CATEGORIES.flatMap((cat) =>
  cat.strategies
    .filter((s) => !s.params || s.params.length === 0) // exclude parameterized
    .map((s) => ({
      label: s.label,
      query: s.query,
      slash: '/' + s.label.replace(/\s+/g, ' ').trim(),
    }))
);

// ─── Welcome Quick Actions — categorized tabs ─────────────────────────────────
// Each tab shows ~4 curated picks using plugin-tested query strings. Full
// strategy library (81 strategies, 8 categories) is one click away via
// "Browse all strategies" / Ctrl+K.

const QUICK_ACTIONS = {
  recent: [
    { icon: 'users', label: 'Agent Status', query: 'show all agents', description: 'View all monitored agents with status, OS, and last check-in' },
    { icon: 'bell', label: 'Active Alerts', query: 'show recent alert analysis', description: 'Recent alerts with severity breakdown and top triggered rules' },
    { icon: 'alert', label: 'Critical Vulnerabilities', query: 'show critical vulnerabilities', description: 'High-severity CVEs across your environment' },
    { icon: 'shield', label: 'Security Posture', query: 'comprehensive security posture', description: 'Comprehensive posture analysis combining alerts, vulns, and agents' },
  ],
  edr: [
    { icon: 'check', label: 'Active Agents', query: 'show active agents', description: 'View all active endpoint agents' },
    { icon: 'offline', label: 'Disconnected Agents', query: 'show disconnected agents', description: 'Identify agents that have lost connectivity' },
    { icon: 'bell', label: 'Recent Alerts', query: 'show recent alerts', description: 'Latest security alerts across all agents' },
    { icon: 'visTagCloud', label: 'Alert Patterns', query: 'analyze alert patterns', description: 'Detect recurring alert clusters and frequency anomalies' },
  ],
  nids: [
    { icon: 'bell', label: 'IDS Alerts', query: 'show suricata alerts', description: 'Latest network intrusion detection alerts' },
    { icon: 'crossClusterReplicationApp', label: 'Top Attackers', query: 'show top suricata attackers', description: 'Source IPs generating the most alerts' },
    { icon: 'visAreaStacked', label: 'Network Analysis', query: 'suricata network analysis', description: 'Traffic patterns and anomaly detection' },
    { icon: 'alert', label: 'Critical Alerts', query: 'show critical suricata alerts', description: 'High-priority IDS alerts requiring immediate attention' },
  ],
  vulns: [
    { icon: 'alert', label: 'Critical CVEs', query: 'show critical vulnerabilities', description: 'Critical severity vulnerabilities requiring immediate action' },
    { icon: 'bug', label: 'Vuln Summary', query: 'show vulnerability summary', description: 'Overall vulnerability landscape and severity breakdown' },
    { icon: 'visBarVerticalStacked', label: 'Top Vulnerable Agents', query: 'show top vulnerable agents', description: 'Agents with the most or most-critical vulnerabilities' },
    { icon: 'check', label: 'Active + High Vulns', query: 'show active agents with high vulnerabilities', description: 'Active agents with unpatched high-severity CVEs' },
  ],
};

const WELCOME_TABS = [
  { id: 'recent', label: 'Recent Actions' },
  { id: 'edr', label: 'EDR' },
  { id: 'nids', label: 'NIDS' },
  { id: 'vulns', label: 'Vulnerabilities' },
];

// ─── Header Button ──────────────────────────────────────────────────────────────

function HeaderButton({ icon, label, onClick, active, accentColor, title }) {
  const activeColor = accentColor || THEME.accent;
  return (
    <button
      onClick={onClick}
      aria-label={title || label}
      title={!label && title ? title : undefined}
      style={{
        display: 'inline-flex',
        alignItems: 'center',
        gap: 6,
        padding: label ? '6px 12px' : '6px 8px',
        borderRadius: 6,
        border: 'none',
        background: active ? `${activeColor}20` : 'transparent',
        color: active ? activeColor : THEME.textSecondary,
        fontSize: 13,
        fontWeight: 500,
        fontFamily: FONT.base,
        cursor: 'pointer',
        transition: 'all 0.15s ease',
      }}
      onMouseEnter={(e) => {
        if (!active) {
          e.currentTarget.style.background = 'rgba(255,255,255,0.06)';
          e.currentTarget.style.color = THEME.text;
        }
      }}
      onMouseLeave={(e) => {
        if (!active) {
          e.currentTarget.style.background = 'transparent';
          e.currentTarget.style.color = THEME.textSecondary;
        }
      }}
    >
      <EuiIcon type={icon} size="s" color="inherit" />
      {label || null}
    </button>
  );
}

// ─── Slash Menu Dropdown ─────────────────────────────────────────────────────────

function SlashMenu({ commands, selectedIdx, onSelect }) {
  if (!commands || commands.length === 0) return null;
  return (
    <div style={{
      position: 'absolute',
      bottom: '100%',
      left: 0,
      right: 0,
      marginBottom: 4,
      maxHeight: 320,
      overflowY: 'auto',
      backgroundColor: '#111827',
      border: `1px solid ${THEME.border}`,
      borderRadius: 10,
      boxShadow: '0 -8px 30px rgba(0,0,0,0.4)',
      zIndex: 50,
    }}>
      {commands.map((cmd, idx) => (
        <div
          key={cmd.label}
          onClick={() => onSelect(cmd)}
          style={{
            padding: '10px 14px',
            cursor: 'pointer',
            backgroundColor: idx === selectedIdx ? 'rgba(22, 197, 192, 0.08)' : 'transparent',
            borderBottom: idx < commands.length - 1 ? `1px solid ${THEME.border}` : 'none',
            transition: 'background 0.1s',
          }}
          onMouseEnter={(e) => {
            e.currentTarget.style.backgroundColor = 'rgba(22, 197, 192, 0.08)';
          }}
          onMouseLeave={(e) => {
            if (idx !== selectedIdx) e.currentTarget.style.backgroundColor = 'transparent';
          }}
        >
          <div style={{
            fontSize: 13,
            fontWeight: 500,
            color: idx === selectedIdx ? THEME.accent : THEME.text,
          }}>
            / {cmd.label}
          </div>
        </div>
      ))}
    </div>
  );
}

// ─── Component ──────────────────────────────────────────────────────────────────

const PallasSOCChat = ({
  connectionStatus: externalStatus,
  onConnectionStatusChange,
  commandPaletteOpen,
  onCommandPaletteClose,
  pendingQuery,
  onPendingQueryConsumed,
  onQueryComplete,
}) => {
  const [inputValue, setInputValue] = useState('');
  const [localPaletteOpen, setLocalPaletteOpen] = useState(false);
  const [activeCategory, setActiveCategory] = useState('recent');
  const [showHistory, setShowHistory] = useState(false);
  const [activeToolView, setActiveToolView] = useState(null); // null | 'standup' | 'ioc' | 'decoder' | 'narrative'
  // Header "Use Cases" dropdown — groups specialty tool pages (Threat Intel,
  // Decoder Lab) under one menu so the top bar stays clean. Daily Standup and
  // Alert Triage stay as primary labeled buttons because they're high-traffic.
  const [showUseCasesDropdown, setShowUseCasesDropdown] = useState(false);
  const useCasesRef = useRef(null);
  // Click-outside to close the Use Cases dropdown.
  useEffect(() => {
    if (!showUseCasesDropdown) return;
    const onDocClick = (e) => {
      if (!useCasesRef.current) return;
      if (useCasesRef.current.contains(e.target)) return;
      setShowUseCasesDropdown(false);
    };
    const onKey = (e) => {
      if (e.key === 'Escape') setShowUseCasesDropdown(false);
    };
    document.addEventListener('mousedown', onDocClick);
    document.addEventListener('keydown', onKey);
    return () => {
      document.removeEventListener('mousedown', onDocClick);
      document.removeEventListener('keydown', onKey);
    };
  }, [showUseCasesDropdown]);
  const [slashFilter, setSlashFilter] = useState('');
  const [slashMenuOpen, setSlashMenuOpen] = useState(false);
  const [slashSelectedIdx, setSlashSelectedIdx] = useState(0);
  const inputRef = useRef(null);
  const responseAreaRef = useRef(null);

  // ── usePallas hook — all chat state lives here ──────────────────────────────
  const {
    response,
    isLoading,
    connectionStatus,
    sendQuery,
    cancelQuery,
    clearResponse,
    queryHistory,
    favorites,
    toggleFavorite,
    pinnedResponses,
    pinResponse,
    unpinResponse,
  } = usePallas('chat', { onQueryComplete });

  // Pinned-results local UI state
  const [pinnedCollapsed, setPinnedCollapsed] = useState(false);
  const [expandedPinIndex, setExpandedPinIndex] = useState(null);
  const [comparing, setComparing] = useState(false);

  // ── Sync connectionStatus upstream ─────────────────────────────────────────
  useEffect(() => {
    onConnectionStatusChange(connectionStatus);
  }, [connectionStatus, onConnectionStatusChange]);

  // ── Handle pendingQuery from other modules ──────────────────────────────────
  useEffect(() => {
    if (pendingQuery && connectionStatus === 'connected') {
      sendQuery(pendingQuery);
      setInputValue('');
      if (onPendingQueryConsumed) onPendingQueryConsumed();
    }
  }, [pendingQuery, connectionStatus, sendQuery, onPendingQueryConsumed]);

  // ── Keyboard shortcut — Ctrl+/ focuses input ───────────────────────────────
  useEffect(() => {
    const handleKeyDown = (e) => {
      if ((e.ctrlKey || e.metaKey) && e.key === '/') {
        e.preventDefault();
        if (inputRef.current) inputRef.current.focus();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);

  // ── Auto-scroll to bottom when response updates ────────────────────────────
  useEffect(() => {
    if (response && responseAreaRef.current) {
      responseAreaRef.current.scrollTop = 0;
    }
  }, [response]);

  // ── Handlers ────────────────────────────────────────────────────────────────

  const handleSend = useCallback(() => {
    const trimmed = inputValue.trim();
    if (!trimmed || isLoading) return;
    sendQuery(trimmed);
    setInputValue('');
    if (inputRef.current) {
      inputRef.current.style.height = 'auto';
      inputRef.current.focus();
    }
  }, [inputValue, isLoading, sendQuery]);

  const handleCommandSelect = useCallback((query) => {
    sendQuery(query);
    onCommandPaletteClose();
    setLocalPaletteOpen(false);
  }, [sendQuery, onCommandPaletteClose]);

  const handleSuggestionClick = useCallback((query) => {
    sendQuery(query);
  }, [sendQuery]);

  const handleSuggestionPreview = useCallback((query) => {
    setInputValue(query);
    if (inputRef.current) inputRef.current.focus();
  }, []);

  const handleHistoryClick = useCallback((query) => {
    sendQuery(query);
    setShowHistory(false);
  }, [sendQuery]);

  const toggleToolView = useCallback((viewId) => {
    if (activeToolView === viewId) {
      setActiveToolView(null);
      clearResponse();
    } else {
      clearResponse();
      setActiveToolView(viewId);
      setShowHistory(false);
    }
  }, [activeToolView, clearResponse]);

  const closeToolView = useCallback(() => {
    setActiveToolView(null);
    clearResponse();
  }, [clearResponse]);

  const handleNewChat = useCallback(() => {
    clearResponse();
    setInputValue('');
    setActiveToolView(null);
    if (inputRef.current) {
      inputRef.current.style.height = 'auto';
      inputRef.current.focus();
    }
  }, [clearResponse]);

  // Auto-resize textarea + slash command detection
  const handleInputChange = (e) => {
    const val = e.target.value;
    setInputValue(val);
    const el = e.target;
    el.style.height = 'auto';
    el.style.height = Math.min(el.scrollHeight, 120) + 'px';

    // Slash menu: open when input starts with "/"
    if (val.startsWith('/')) {
      const filter = val.slice(1).toLowerCase();
      setSlashFilter(filter);
      setSlashMenuOpen(true);
      setSlashSelectedIdx(0);
    } else {
      setSlashMenuOpen(false);
    }
  };

  // Filtered slash commands
  const filteredSlashCommands = slashMenuOpen
    ? SLASH_COMMANDS.filter((cmd) =>
        !slashFilter || cmd.label.toLowerCase().includes(slashFilter)
      ).slice(0, 10)
    : [];

  // Handle slash command selection
  const handleSlashSelect = useCallback((cmd) => {
    sendQuery(cmd.query);
    setInputValue('');
    setSlashMenuOpen(false);
    if (inputRef.current) {
      inputRef.current.style.height = 'auto';
      inputRef.current.focus();
    }
  }, [sendQuery]);

  // Slash menu keyboard navigation
  const handleSlashKeyDown = useCallback((e) => {
    if (!slashMenuOpen || filteredSlashCommands.length === 0) return false;
    if (e.key === 'ArrowDown') {
      e.preventDefault();
      setSlashSelectedIdx((i) => Math.min(i + 1, filteredSlashCommands.length - 1));
      return true;
    }
    if (e.key === 'ArrowUp') {
      e.preventDefault();
      setSlashSelectedIdx((i) => Math.max(i - 1, 0));
      return true;
    }
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      if (filteredSlashCommands[slashSelectedIdx]) {
        handleSlashSelect(filteredSlashCommands[slashSelectedIdx]);
      }
      return true;
    }
    if (e.key === 'Escape') {
      setSlashMenuOpen(false);
      return true;
    }
    return false;
  }, [slashMenuOpen, filteredSlashCommands, slashSelectedIdx, handleSlashSelect]);

  // Export all pinned results as markdown
  const handleExportPinned = (e) => {
    e.stopPropagation();
    const sections = pinnedResponses.map((p, i) => {
      const parts = [`## Pin ${i + 1} — ${new Date(p.timestamp).toLocaleString()}`];
      if (p.metadata && p.metadata.strategy) parts.push(`**Strategy:** ${p.metadata.strategy}`);
      parts.push('', p.content);
      if (p.socAnalysis) parts.push('', `## SOC ANALYSIS\n${p.socAnalysis}`);
      return parts.join('\n');
    });
    const report = `# Pallas SOC Chat — Pinned Results Export\n**Exported:** ${new Date().toLocaleString()}\n**Count:** ${pinnedResponses.length}\n\n---\n\n${sections.join('\n\n---\n\n')}`;
    const blob = new Blob([report], { type: 'text/markdown;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `pallas-chat-pinned-${new Date().toISOString().slice(0, 19).replace(/[:.]/g, '-')}.md`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  const isPaletteOpen = commandPaletteOpen || localPaletteOpen;
  const hasResponseOrLoading = Boolean(response || isLoading);

  // ── Tool View Renderer ─────────────────────────────────────────────────────

  // Tool metadata for the welcome-style header
  const TOOL_META = {
    ioc:       { title: 'Threat Intel',       desc: 'Search for indicators of compromise and investigate IPs across all indexes', accent: MODULE_COLORS.ioc.accent },
    decoder:   { title: 'Decoder Lab',        desc: 'Paste a log, generate, test, and self-correct Endpoints decoders automatically', accent: MODULE_COLORS.decoder.accent },
    narrative: { title: 'Alert Triage',         desc: 'High-priority alerts from Endpoints + NIDS with on-demand AI forensic narratives', accent: MODULE_COLORS.narrative.accent },
  };

  const renderToolView = () => {
    if (activeToolView === 'standup') {
      return (
        <PallasDailyStandup
          sendQuery={sendQuery}
          response={response}
          isLoading={isLoading}
          onClose={closeToolView}
          connectionStatus={connectionStatus}
          onSuggestionClick={handleSuggestionClick}
        />
      );
    }

    const meta = TOOL_META[activeToolView];
    if (!meta) return null;

    let toolContent = null;
    switch (activeToolView) {
      case 'ioc':
        toolContent = (
          <PallasDetectIOC
            connectionStatus={connectionStatus}
            onConnectionStatusChange={onConnectionStatusChange}
            onQueryComplete={onQueryComplete}
            onClose={closeToolView}
            hideHeader
          />
        );
        break;
      case 'decoder':
        toolContent = (
          <PallasDecoderLab
            connectionStatus={connectionStatus}
            onQueryComplete={onQueryComplete}
            onClose={closeToolView}
            hideHeader
          />
        );
        break;
      case 'narrative':
        toolContent = (
          <PallasAttackNarrative
            connectionStatus={connectionStatus}
            onQueryComplete={onQueryComplete}
            onClose={closeToolView}
            hideHeader
          />
        );
        break;
      default:
        return null;
    }

    // Tool screens have their own compact header — render them full-height, no wrapper
    return (
      <div style={{ display: 'flex', flexDirection: 'column', height: '100%', overflow: 'hidden' }}>
        {toolContent}
      </div>
    );
  };

  // ── Render ───────────────────────────────────────────────────────────────────

  return (
    <div style={{ height: '100%', display: 'flex', flexDirection: 'column', overflow: 'hidden' }}>

      {/* ── Command Palette Overlay ─────────────────────────────────────────── */}
      <PallasCommandPalette
        isOpen={isPaletteOpen}
        onClose={() => {
          onCommandPaletteClose();
          setLocalPaletteOpen(false);
        }}
        onSelect={handleCommandSelect}
      />

      {/* ── Page Header ────────────────────────────────────────────────────── */}
      <div style={{
        padding: '16px 24px',
        borderBottom: `1px solid ${THEME.borderSubtle}`,
        flexShrink: 0,
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'space-between',
      }}>
        <h2 style={{
          fontSize: 20,
          fontWeight: 700,
          color: THEME.text,
          margin: 0,
          letterSpacing: '-0.01em',
        }}>
          Ask Pallas
        </h2>
        <div style={{ display: 'flex', gap: 4, alignItems: 'center' }}>
          <HeaderButton
            icon="grid"
            label="Browse Quick Actions"
            onClick={() => { setActiveToolView(null); setLocalPaletteOpen(true); }}
          />
          <HeaderButton
            icon="calendar"
            label="Daily Standup"
            onClick={() => toggleToolView('standup')}
            active={activeToolView === 'standup'}
          />

          {/* Alert Triage stays as a primary labeled button — high-traffic page
              and renamed from "Attack Narratives" per Peter's feedback. Uses
              the default HeaderButton styling (no accentColor) so it matches
              Daily Standup / History / New Chat visually — explicitly NOT the
              module-red color the old icon-only button used. */}
          <HeaderButton
            icon="crosshairs"
            label="Alert Triage"
            onClick={() => toggleToolView('narrative')}
            active={activeToolView === 'narrative'}
          />

          {/* Use Cases — collapses Threat Intel + Decoder Lab into one menu so
              the header stays uncluttered as more specialty pages get added.
              Daily Standup and Alert Triage stay surfaced as primary buttons. */}
          <div ref={useCasesRef} style={{ position: 'relative' }}>
            <HeaderButton
              icon="apps"
              label="Use Cases"
              onClick={() => setShowUseCasesDropdown((v) => !v)}
              active={showUseCasesDropdown || activeToolView === 'ioc' || activeToolView === 'decoder'}
            />
            {showUseCasesDropdown && (
              <div
                role="menu"
                aria-label="Use Cases"
                style={{
                  position: 'absolute',
                  top: 'calc(100% + 4px)',
                  right: 0,
                  minWidth: 200,
                  background: THEME.card,
                  border: `1px solid ${THEME.border}`,
                  borderRadius: 8,
                  boxShadow: '0 12px 32px rgba(0,0,0,0.6)',
                  padding: 6,
                  zIndex: 9999,
                }}
              >
                {[
                  { id: 'ioc',     label: 'Threat Intel', icon: 'search', accent: MODULE_COLORS.ioc.accent },
                  { id: 'decoder', label: 'Decoder Lab',  icon: 'wrench', accent: MODULE_COLORS.decoder.accent },
                ].map((item) => {
                  const isActive = activeToolView === item.id;
                  return (
                    <button
                      key={item.id}
                      role="menuitem"
                      onClick={() => {
                        toggleToolView(item.id);
                        setShowUseCasesDropdown(false);
                      }}
                      style={{
                        display: 'flex', alignItems: 'center', gap: 10, width: '100%',
                        padding: '8px 10px', borderRadius: 6, border: 'none',
                        background: isActive ? `${item.accent}20` : 'transparent',
                        color: isActive ? item.accent : THEME.text,
                        fontSize: 13, fontWeight: isActive ? 600 : 500,
                        cursor: 'pointer', outline: 'none', textAlign: 'left',
                      }}
                      onMouseEnter={(e) => {
                        if (!isActive) e.currentTarget.style.background = 'rgba(255,255,255,0.05)';
                      }}
                      onMouseLeave={(e) => {
                        if (!isActive) e.currentTarget.style.background = 'transparent';
                      }}
                    >
                      <EuiIcon type={item.icon} size="s" color="inherit" />
                      <span>{item.label}</span>
                      {isActive && (
                        <EuiIcon type="check" size="s" color={item.accent} style={{ marginLeft: 'auto' }} />
                      )}
                    </button>
                  );
                })}
              </div>
            )}
          </div>

          <span style={{ width: 1, height: 18, background: THEME.border, margin: '0 4px', opacity: 0.5 }} />

          <HeaderButton
            icon="clock"
            label="History"
            onClick={() => { setActiveToolView(null); setShowHistory(!showHistory); }}
            active={showHistory}
          />
          <HeaderButton
            icon="plus"
            label="New Chat"
            onClick={() => { setActiveToolView(null); handleNewChat(); }}
          />
        </div>
      </div>

      {/* ── Main Content Area ──────────────────────────────────────────────── */}
      <div style={{ flex: 1, display: 'flex', overflow: 'hidden' }}>

        {/* ── Tool Views (Standup, IOC, Decoder, Narrative) ─────────────── */}
        {activeToolView ? (
          <div style={{
            flex: 1,
            width: '100%',
            overflow: 'hidden',
            animation: 'pallas-fadeIn 0.2s ease',
          }}>
            {renderToolView()}
          </div>
        ) : (
        <>
        {/* ── Content Panel ──────────────────────────────────────────────── */}
        <div
          ref={responseAreaRef}
          className="pallas-scrollbar"
          style={{ flex: 1, overflow: 'auto', padding: '24px' }}
        >

          {/* ── Pinned Results ────────────────────────────────────────────── */}
          {pinnedResponses.length > 0 && (
            <div style={{ maxWidth: 1320, width: '100%', margin: '0 auto 16px' }}>
              <button
                onClick={() => setPinnedCollapsed(!pinnedCollapsed)}
                aria-label={pinnedCollapsed ? 'Expand pinned results' : 'Collapse pinned results'}
                style={{
                  display: 'flex',
                  alignItems: 'center',
                  gap: 6,
                  padding: '6px 10px',
                  border: `1px solid ${THEME.borderSubtle}`,
                  borderRadius: 6,
                  backgroundColor: 'rgba(255,255,255,0.02)',
                  cursor: 'pointer',
                  marginBottom: 8,
                  width: '100%',
                  textAlign: 'left',
                }}
              >
                <EuiIcon type="pinFilled" size="s" color={THEME.accent} />
                <span style={{ fontSize: 12, fontWeight: 600, color: THEME.textSecondary }}>
                  Pinned Results ({pinnedResponses.length})
                </span>
                <span
                  role="button"
                  tabIndex={0}
                  onClick={handleExportPinned}
                  onKeyDown={(e) => { if (e.key === 'Enter') handleExportPinned(e); }}
                  aria-label="Export all pinned results"
                  style={{
                    marginLeft: 'auto',
                    marginRight: 8,
                    padding: '2px 8px',
                    borderRadius: 4,
                    fontSize: 11,
                    fontWeight: 500,
                    color: THEME.textMuted,
                    cursor: 'pointer',
                  }}
                  onMouseEnter={(e) => { e.currentTarget.style.color = THEME.accent; }}
                  onMouseLeave={(e) => { e.currentTarget.style.color = THEME.textMuted; }}
                >
                  Export All
                </span>
                {pinnedResponses.length >= 2 && (
                  <span
                    role="button"
                    tabIndex={0}
                    onClick={(e) => { e.stopPropagation(); setComparing(!comparing); }}
                    onKeyDown={(e) => {
                      if (e.key === 'Enter') { e.stopPropagation(); setComparing(!comparing); }
                    }}
                    aria-label="Compare pinned results side by side"
                    style={{
                      padding: '2px 8px',
                      borderRadius: 4,
                      fontSize: 11,
                      fontWeight: 500,
                      color: comparing ? THEME.accent : THEME.textMuted,
                      cursor: 'pointer',
                    }}
                    onMouseEnter={(e) => { e.currentTarget.style.color = THEME.accent; }}
                    onMouseLeave={(e) => {
                      if (!comparing) e.currentTarget.style.color = THEME.textMuted;
                    }}
                  >
                    Compare
                  </span>
                )}
                <EuiIcon
                  type={pinnedCollapsed ? 'arrowDown' : 'arrowUp'}
                  size="s"
                  color={THEME.textMuted}
                />
              </button>

              {!pinnedCollapsed && (
                <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
                  {comparing && pinnedResponses.length >= 2 && (
                    <ComparePanel
                      pinnedResponses={pinnedResponses}
                      onClose={() => setComparing(false)}
                    />
                  )}
                  {pinnedResponses.map((pinned, idx) => (
                    <div
                      key={idx}
                      style={{
                        padding: '10px 14px',
                        borderRadius: 8,
                        border: `1px solid ${THEME.borderSubtle}`,
                        backgroundColor: 'rgba(255,255,255,0.02)',
                      }}
                    >
                      <div style={{
                        display: 'flex',
                        justifyContent: 'space-between',
                        alignItems: 'center',
                        marginBottom: expandedPinIndex === idx ? 8 : 0,
                      }}>
                        <div style={{ flex: 1, minWidth: 0 }}>
                          <div style={{
                            fontSize: 12,
                            color: THEME.text,
                            overflow: 'hidden',
                            textOverflow: 'ellipsis',
                            whiteSpace: 'nowrap',
                          }}>
                            {(pinned.metadata && pinned.metadata.strategy)
                              ? pinned.metadata.strategy.replace(/_/g, ' ')
                              : 'Query result'}
                          </div>
                          <div style={{ fontSize: 10, color: THEME.textMuted, marginTop: 2 }}>
                            {new Date(pinned.timestamp).toLocaleTimeString([], {
                              hour: '2-digit',
                              minute: '2-digit',
                            })}
                            {pinned.metadata && pinned.metadata.execution_time_ms &&
                              ` \u00B7 ${(pinned.metadata.execution_time_ms / 1000).toFixed(1)}s`}
                          </div>
                        </div>
                        <div style={{ display: 'flex', gap: 4, flexShrink: 0 }}>
                          <button
                            onClick={() =>
                              setExpandedPinIndex(expandedPinIndex === idx ? null : idx)
                            }
                            aria-label={expandedPinIndex === idx ? 'Collapse' : 'Expand'}
                            style={{
                              padding: 4, border: 'none', background: 'transparent',
                              cursor: 'pointer', display: 'flex', alignItems: 'center',
                            }}
                          >
                            <EuiIcon
                              type={expandedPinIndex === idx ? 'arrowUp' : 'arrowDown'}
                              size="s" color={THEME.textMuted}
                            />
                          </button>
                          <button
                            onClick={() => unpinResponse(idx)}
                            aria-label="Unpin"
                            style={{
                              padding: 4, border: 'none', background: 'transparent',
                              cursor: 'pointer', display: 'flex', alignItems: 'center',
                            }}
                          >
                            <EuiIcon type="cross" size="s" color={THEME.textMuted} />
                          </button>
                        </div>
                      </div>
                      {expandedPinIndex === idx && (
                        <ResponsePanel
                          content={pinned.content}
                          blocks={pinned.blocks}
                          metadata={pinned.metadata}
                          socAnalysis={pinned.socAnalysis}
                          suggestions={pinned.suggestions}
                          onSuggestionClick={handleSuggestionClick}
                        />
                      )}
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {/* ── Welcome State (no response, not loading) ───────────────────── */}
          {!hasResponseOrLoading && (
            <div style={{
              width: '100%',
              maxWidth: 620,
              margin: '0 auto',
              animation: 'pallas-fadeIn 0.3s ease',
              display: 'flex',
              flexDirection: 'column',
              alignItems: 'center',
              paddingTop: 32,
            }}>
              {/* Owl Logo — SVG includes AΘήνη text */}
              <img
                src={PallasLogo}
                alt="Pallas AI"
                style={{ width: 90, height: 90, marginBottom: 12, opacity: 0.9 }}
              />
              <h3 style={{
                fontSize: 22,
                fontWeight: 700,
                color: THEME.text,
                margin: '0 0 28px 0',
                letterSpacing: '-0.01em',
              }}>
                Welcome to Pallas AI
              </h3>

              {/* Category Tabs + Browse all link */}
              <div style={{
                display: 'flex',
                alignItems: 'center',
                gap: 0,
                marginBottom: 20,
                width: '100%',
                borderBottom: `1px solid ${THEME.border}`,
              }}>
                {WELCOME_TABS.map((tab) => {
                  const isActive = activeCategory === tab.id;
                  return (
                    <button
                      key={tab.id}
                      onClick={() => setActiveCategory(tab.id)}
                      style={{
                        padding: '8px 16px',
                        border: 'none',
                        borderBottom: isActive ? `2px solid ${THEME.accent}` : '2px solid transparent',
                        background: 'transparent',
                        color: isActive ? THEME.text : THEME.textMuted,
                        fontSize: 13,
                        fontWeight: isActive ? 600 : 400,
                        fontFamily: FONT.base,
                        cursor: 'pointer',
                        transition: 'all 0.15s',
                      }}
                    >
                      {tab.label}
                    </button>
                  );
                })}
                <button
                  onClick={() => setLocalPaletteOpen(true)}
                  style={{
                    marginLeft: 'auto',
                    padding: '8px 12px',
                    border: 'none',
                    background: 'transparent',
                    color: THEME.accent,
                    fontSize: 13,
                    fontWeight: 500,
                    fontFamily: FONT.base,
                    cursor: 'pointer',
                  }}
                >
                  Browse all
                </button>
              </div>

              {/* Quick Action Cards — per active tab */}
              <div style={{ display: 'flex', flexWrap: 'wrap', gap: 8, width: '100%', marginBottom: 28 }}>
                {(QUICK_ACTIONS[activeCategory] || []).map((action) => (
                  <button
                    key={action.label}
                    onClick={() => {
                      if (connectionStatus === 'connected' && !isLoading) sendQuery(action.query);
                    }}
                    disabled={isLoading || connectionStatus !== 'connected'}
                    style={{
                      display: 'inline-flex',
                      alignItems: 'center',
                      gap: 6,
                      padding: '7px 14px',
                      borderRadius: 20,
                      border: `1px solid ${THEME.accent}30`,
                      background: 'rgba(22, 197, 192, 0.08)',
                      color: THEME.accent,
                      fontSize: 12,
                      fontWeight: 500,
                      fontFamily: FONT.base,
                      whiteSpace: 'nowrap',
                      flexShrink: 0,
                      cursor: connectionStatus === 'connected' ? 'pointer' : 'not-allowed',
                      opacity: connectionStatus === 'connected' ? 1 : 0.5,
                      transition: 'all 0.15s ease',
                      outline: 'none',
                    }}
                    onMouseEnter={(e) => {
                      if (connectionStatus === 'connected') {
                        e.currentTarget.style.background = 'rgba(22, 197, 192, 0.16)';
                        e.currentTarget.style.borderColor = THEME.accent + '60';
                      }
                    }}
                    onMouseLeave={(e) => {
                      e.currentTarget.style.background = 'rgba(22, 197, 192, 0.08)';
                      e.currentTarget.style.borderColor = THEME.accent + '30';
                    }}
                  >
                    <EuiIcon type={action.icon} size="s" color={THEME.accent} />
                    {action.label}
                  </button>
                ))}
              </div>

              {/* Input card — inline in welcome state */}
              <div style={{
                width: '100%',
                position: 'relative',
              }}>
                {slashMenuOpen && (
                  <SlashMenu
                    commands={filteredSlashCommands}
                    selectedIdx={slashSelectedIdx}
                    onSelect={handleSlashSelect}
                  />
                )}
              <div style={{
                width: '100%',
                borderRadius: 12,
                border: `1px solid ${THEME.border}`,
                backgroundColor: '#0D1520',
                position: 'relative',
                transition: 'border-color 0.15s, box-shadow 0.15s',
              }}
                onFocus={(e) => {
                  e.currentTarget.style.borderColor = 'rgba(22, 197, 192, 0.3)';
                  e.currentTarget.style.boxShadow = '0 0 0 2px rgba(22,197,192,0.08)';
                }}
                onBlur={(e) => {
                  e.currentTarget.style.borderColor = THEME.border;
                  e.currentTarget.style.boxShadow = 'none';
                }}
              >
                <textarea
                  ref={inputRef}
                  value={inputValue}
                  onChange={handleInputChange}
                  onKeyDown={(e) => {
                    if (handleSlashKeyDown(e)) return;
                    if (e.key === 'Enter' && !e.shiftKey) {
                      e.preventDefault();
                      handleSend();
                    }
                  }}
                  placeholder={
                    connectionStatus === 'connected'
                      ? 'Ask about your security environment...'
                      : 'Waiting for server connection...'
                  }
                  aria-label="SOC intelligence query input"
                  rows={3}
                  disabled={isLoading || connectionStatus !== 'connected'}
                  style={{
                    width: '100%',
                    padding: '14px 56px 14px 16px',
                    border: 'none',
                    outline: 'none',
                    backgroundColor: 'transparent',
                    color: THEME.text,
                    fontSize: 14,
                    fontFamily: FONT.base,
                    resize: 'none',
                    lineHeight: 1.5,
                    maxHeight: 140,
                    minHeight: 72,
                    boxSizing: 'border-box',
                  }}
                />
                <button
                  onClick={isLoading ? cancelQuery : handleSend}
                  disabled={!isLoading && (!inputValue.trim() || connectionStatus !== 'connected')}
                  aria-label={isLoading ? 'Cancel' : 'Send query'}
                  style={{
                    position: 'absolute',
                    right: 10,
                    bottom: 10,
                    width: 32,
                    height: 32,
                    borderRadius: 6,
                    border: 'none',
                    background: isLoading
                      ? 'rgba(248, 113, 113, 0.2)'
                      : 'linear-gradient(135deg, #00BFB3 0%, #00D4C8 100%)',
                    color: isLoading ? '#F87171' : '#FFFFFF',
                    cursor: (!isLoading && (!inputValue.trim() || connectionStatus !== 'connected'))
                      ? 'not-allowed' : 'pointer',
                    opacity: (!isLoading && (!inputValue.trim() || connectionStatus !== 'connected'))
                      ? 0.4 : 1,
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    transition: 'all 0.15s',
                  }}
                >
                  {isLoading
                    ? <EuiIcon type="cross" size="s" />
                    : <EuiIcon type="playFilled" size="s" />}
                </button>
              </div>
              </div>{/* end slash wrapper */}
              <div style={{
                fontSize: 11,
                color: THEME.textMuted,
                marginTop: 6,
                alignSelf: 'flex-start',
              }}>
                Type <span style={{ fontFamily: FONT.mono, color: THEME.textSecondary }}>/</span> for more quick actions
              </div>
              <ChatDisclaimer align="center" marginTop={6} />
            </div>
          )}

          {/* ── Response Panel ──────────────────────────────────────────────── */}
          {hasResponseOrLoading && (
            <div style={{ maxWidth: 1320, margin: '0 auto', width: '100%' }}>
              {isLoading && !response ? (
                <ResponsePanel
                  isLoading
                  onCancel={cancelQuery}
                />
              ) : response ? (
                <ResponsePanel
                  content={response.content}
                  blocks={response.blocks}
                  metadata={response.metadata}
                  socAnalysis={response.socAnalysis}
                  suggestions={response.suggestions}
                  isLoading={isLoading}
                  onCancel={isLoading ? cancelQuery : undefined}
                  onSuggestionClick={handleSuggestionClick}
                  onSuggestionPreview={handleSuggestionPreview}
                  onPin={pinResponse}
                  isPinned={pinnedResponses.some(
                    (p) => p.content === response.content && p.timestamp === response.timestamp
                  )}
                />
              ) : null}
            </div>
          )}
        </div>

        {/* ── History Sidebar (toggleable) ──────────────────────────────────── */}
        {showHistory && (queryHistory.length > 0 || favorites.length > 0) && (
          <div style={{
            width: 280,
            borderLeft: `1px solid ${THEME.borderSubtle}`,
            overflow: 'auto',
            padding: '16px 12px',
            flexShrink: 0,
            animation: 'pallas-fadeIn 0.15s ease',
          }}>
            {/* Favorites section */}
            {favorites.length > 0 && (
              <>
                <span style={{
                  fontSize: 11,
                  fontWeight: 600,
                  color: THEME.warning,
                  textTransform: 'uppercase',
                  letterSpacing: '0.05em',
                }}>
                  Favorites
                </span>
                <div style={{
                  marginTop: 6,
                  marginBottom: 12,
                  display: 'flex',
                  flexDirection: 'column',
                  gap: 2,
                }}>
                  {favorites.map((fav, idx) => (
                    <div
                      key={`fav-${idx}`}
                      style={{
                        display: 'flex',
                        alignItems: 'center',
                        gap: 4,
                        borderRadius: 6,
                        transition: 'background 0.12s',
                      }}
                      onMouseEnter={(e) => {
                        e.currentTarget.style.backgroundColor = 'rgba(255,255,255,0.04)';
                      }}
                      onMouseLeave={(e) => {
                        e.currentTarget.style.backgroundColor = 'transparent';
                      }}
                    >
                      <button
                        onClick={() => toggleFavorite(fav)}
                        aria-label={`Remove from favorites: ${fav}`}
                        style={{
                          padding: 4, border: 'none', backgroundColor: 'transparent',
                          cursor: 'pointer', flexShrink: 0, display: 'flex', alignItems: 'center',
                        }}
                      >
                        <EuiIcon type="starFilled" size="s" color={THEME.warning} />
                      </button>
                      <button
                        onClick={() => handleHistoryClick(fav)}
                        aria-label={`Run favorite: ${fav}`}
                        style={{
                          flex: 1, padding: '6px 4px', border: 'none',
                          backgroundColor: 'transparent', cursor: 'pointer', textAlign: 'left',
                          fontSize: 12, color: THEME.text, overflow: 'hidden',
                          textOverflow: 'ellipsis', whiteSpace: 'nowrap',
                        }}
                      >
                        {fav}
                      </button>
                    </div>
                  ))}
                </div>
              </>
            )}

            {/* Recent history section */}
            {queryHistory.length > 0 && (
              <>
                <span style={{
                  fontSize: 11,
                  fontWeight: 600,
                  color: THEME.textMuted,
                  textTransform: 'uppercase',
                  letterSpacing: '0.05em',
                }}>
                  Recent
                </span>
                <div style={{ marginTop: 6, display: 'flex', flexDirection: 'column', gap: 2 }}>
                  {queryHistory.slice(0, 20).map((item, idx) => (
                    <div
                      key={idx}
                      style={{
                        display: 'flex',
                        alignItems: 'flex-start',
                        gap: 4,
                        borderRadius: 6,
                        transition: 'background 0.12s',
                      }}
                      onMouseEnter={(e) => {
                        e.currentTarget.style.backgroundColor = 'rgba(255,255,255,0.04)';
                      }}
                      onMouseLeave={(e) => {
                        e.currentTarget.style.backgroundColor = 'transparent';
                      }}
                    >
                      <button
                        onClick={() => toggleFavorite(item.query)}
                        aria-label={
                          favorites.includes(item.query)
                            ? `Remove from favorites: ${item.query}`
                            : `Add to favorites: ${item.query}`
                        }
                        style={{
                          padding: '6px 4px', border: 'none', backgroundColor: 'transparent',
                          cursor: 'pointer', flexShrink: 0, display: 'flex', alignItems: 'center',
                        }}
                      >
                        <EuiIcon
                          type={favorites.includes(item.query) ? 'starFilled' : 'starEmpty'}
                          size="s"
                          color={favorites.includes(item.query) ? THEME.warning : THEME.textMuted}
                        />
                      </button>
                      <button
                        onClick={() => handleHistoryClick(item.query)}
                        aria-label={`Re-run query: ${item.query}`}
                        style={{
                          flex: 1, padding: '6px 4px', border: 'none',
                          backgroundColor: 'transparent', cursor: 'pointer', textAlign: 'left',
                        }}
                      >
                        <div style={{
                          fontSize: 12, color: THEME.text, overflow: 'hidden',
                          textOverflow: 'ellipsis', whiteSpace: 'nowrap',
                        }}>
                          {item.query}
                        </div>
                        <div style={{ fontSize: 10, color: THEME.textMuted, marginTop: 2 }}>
                          {new Date(item.timestamp).toLocaleTimeString([], {
                            hour: '2-digit',
                            minute: '2-digit',
                          })}
                          {item.strategy && (
                            <span style={{ marginLeft: 4 }}>
                              \u00B7 {item.strategy.replace(/_/g, ' ')}
                            </span>
                          )}
                        </div>
                      </button>
                    </div>
                  ))}
                </div>
              </>
            )}
          </div>
        )}
        </>
        )}
      </div>

      {/* ── Bottom Input Area (only when response is showing, not during standup) */}
      {hasResponseOrLoading && !activeToolView && (
      <div style={{
        padding: '12px 24px 16px',
        flexShrink: 0,
        maxWidth: 680,
        margin: '0 auto',
        width: '100%',
        boxSizing: 'border-box',
      }}>
        {/* Connection warning */}
        {connectionStatus !== 'connected' && (
          <div style={{
            padding: '6px 12px',
            fontSize: 12,
            color: connectionStatus === 'reconnecting' ? THEME.warning : '#F87171',
            backgroundColor: connectionStatus === 'reconnecting'
              ? 'rgba(220,106,19,0.10)'
              : 'rgba(248,113,113,0.08)',
            borderRadius: 8,
            marginBottom: 8,
            display: 'flex',
            alignItems: 'center',
            gap: 6,
          }}>
            <div style={{
              width: 6, height: 6, borderRadius: '50%',
              backgroundColor: connectionStatus === 'reconnecting' ? THEME.warning : '#F87171',
              animation: connectionStatus === 'reconnecting' ? 'pallas-pulse 1.5s ease-in-out infinite' : 'none',
              flexShrink: 0,
            }} />
            {connectionStatus === 'reconnecting' ? 'Reconnecting to server...' : 'Server disconnected'}
          </div>
        )}

        {/* Input card — dark contained card matching reference */}
        <div style={{ position: 'relative' }}>
          {slashMenuOpen && (
            <SlashMenu
              commands={filteredSlashCommands}
              selectedIdx={slashSelectedIdx}
              onSelect={handleSlashSelect}
            />
          )}
        <div style={{
          borderRadius: 12,
          border: `1px solid ${THEME.border}`,
          backgroundColor: '#0D1520',
          position: 'relative',
          transition: 'border-color 0.15s, box-shadow 0.15s',
        }}
          onFocus={(e) => {
            e.currentTarget.style.borderColor = 'rgba(22, 197, 192, 0.3)';
            e.currentTarget.style.boxShadow = '0 0 0 2px rgba(22,197,192,0.08)';
          }}
          onBlur={(e) => {
            e.currentTarget.style.borderColor = THEME.border;
            e.currentTarget.style.boxShadow = 'none';
          }}
        >
          <textarea
            ref={inputRef}
            value={inputValue}
            onChange={handleInputChange}
            onKeyDown={(e) => {
              if (handleSlashKeyDown(e)) return;
              if (e.key === 'Enter' && !e.shiftKey) {
                e.preventDefault();
                handleSend();
              }
            }}
            placeholder={
              connectionStatus === 'connected'
                ? 'Ask about your security environment...'
                : 'Waiting for server connection...'
            }
            aria-label="SOC intelligence query input"
            rows={hasResponseOrLoading ? 1 : 3}
            disabled={isLoading || connectionStatus !== 'connected'}
            style={{
              width: '100%',
              padding: hasResponseOrLoading ? '10px 56px 10px 16px' : '14px 56px 14px 16px',
              border: 'none',
              outline: 'none',
              backgroundColor: 'transparent',
              color: THEME.text,
              fontSize: hasResponseOrLoading ? 13 : 14,
              fontFamily: FONT.base,
              resize: 'none',
              lineHeight: 1.5,
              maxHeight: hasResponseOrLoading ? 40 : 140,
              minHeight: hasResponseOrLoading ? 36 : 72,
              boxSizing: 'border-box',
              transition: 'all 0.2s ease',
            }}
          />
          {/* Send button — green, bottom right */}
          <button
            onClick={isLoading ? cancelQuery : handleSend}
            disabled={!isLoading && (!inputValue.trim() || connectionStatus !== 'connected')}
            aria-label={isLoading ? 'Cancel' : 'Send query'}
            style={{
              position: 'absolute',
              right: 10,
              bottom: 10,
              width: 32,
              height: 32,
              borderRadius: 6,
              border: 'none',
              background: isLoading
                ? 'rgba(248, 113, 113, 0.2)'
                : 'linear-gradient(135deg, #00BFB3 0%, #00D4C8 100%)',
              color: isLoading ? '#F87171' : '#FFFFFF',
              cursor: (!isLoading && (!inputValue.trim() || connectionStatus !== 'connected'))
                ? 'not-allowed'
                : 'pointer',
              opacity: (!isLoading && (!inputValue.trim() || connectionStatus !== 'connected'))
                ? 0.4
                : 1,
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              transition: 'all 0.15s',
            }}
          >
            {isLoading
              ? <EuiIcon type="cross" size="s" />
              : <EuiIcon type="playFilled" size="s" />}
          </button>
        </div>
        </div>{/* end slash wrapper */}

        {/* Hint text */}
        <div style={{
          fontSize: 11,
          color: THEME.textMuted,
          marginTop: 6,
          paddingLeft: 4,
        }}>
          Type <span style={{ fontFamily: FONT.mono, color: THEME.textSecondary }}>/</span> for more quick actions
        </div>
        <ChatDisclaimer align="center" marginTop={6} />
      </div>
      )}
    </div>
  );
};

export default PallasSOCChat;
