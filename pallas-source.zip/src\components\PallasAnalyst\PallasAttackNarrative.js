/**
 * PallasAttackNarrative — Attack Narrative AI Plugin
 *
 * Redesigned with shared PallasUI components and Narrative accent color (#A78BFA).
 * Alert browser with on-demand AI forensic narrative generation.
 */

import React, { useState, useEffect, useRef, useCallback, useMemo } from 'react';
import { createPortal } from 'react-dom';
import { EuiIcon, EuiFieldSearch, EuiSelect, EuiSwitch, EuiButton, EuiPagination, EuiText, EuiFlexGroup, EuiFlexItem } from '@elastic/eui';
import toast, { Toaster } from 'react-hot-toast';
import { THEME } from '../../utils/theme';
import { MODULE_COLORS, ModuleHeader, PillBadge, EmptyState, FONT, StandupKPICard, SkeletonLine } from './PallasUI';
import { pallasPost, getCurrentAnalystName } from '../../services/pallasService';
import PallasMarkdown from './PallasMarkdown';

// Router-free `useSearchParams` shim. Pallas isn't wrapped in a react-router
// `<BrowserRouter>` context, so the standard hook throws on render. This
// shim mirrors the same `[params, setParams]` API directly against the
// browser History API — bookmark/share-able URLs without dragging Router
// into the app.
function useUrlSearchParams() {
  const [params, setLocalParams] = useState(
    () => new URLSearchParams(typeof window !== 'undefined' ? window.location.search : '')
  );
  useEffect(() => {
    const onPop = () => setLocalParams(new URLSearchParams(window.location.search));
    window.addEventListener('popstate', onPop);
    return () => window.removeEventListener('popstate', onPop);
  }, []);
  const setParams = useCallback((updater, options) => {
    setLocalParams(prev => {
      const next = typeof updater === 'function'
        ? updater(new URLSearchParams(prev))
        : new URLSearchParams(updater);
      const qs = next.toString();
      const url = `${window.location.pathname}${qs ? `?${qs}` : ''}${window.location.hash}`;
      if (options?.replace) {
        window.history.replaceState(null, '', url);
      } else {
        window.history.pushState(null, '', url);
      }
      return next;
    });
  }, []);
  return [params, setParams];
}

const ACCENT = MODULE_COLORS.narrative.accent;

// ─── Capability flags ────────────────────────────────────────────────────────
// Standalone release: Mute is hidden in the UI and the backend returns 501
// for the mute endpoints. RE-ENABLE NEXT RELEASE — flip to read live from
// (window.__pallasCapabilities?.mute_enabled) once Agelia + mute return.
const HIDE_MUTE = true;

// Block button is gated on a backend capability flag — true when either
// Agelia is wired (legacy path) or AWS WAF + Network Firewall are configured
// (direct boto3 path). Read fresh on each render via getCapabilities().
function getCapabilities() {
  if (typeof window === 'undefined') return {};
  return window.__pallasCapabilities || {};
}

// ─── Constants ───────────────────────────────────────────────────────────────

const TIME_RANGES = [
  { value: '12h', label: '12 Hours' },
  { value: '24h', label: '24 Hours' },
  { value: '48h', label: '48 Hours' },
  { value: '7d', label: '7 Days' },
];

const SEVERITY_COLORS = {
  critical: { bg: 'rgba(255,77,77,0.12)', text: '#FF6B6B', border: 'rgba(255,77,77,0.3)' },
  high:     { bg: 'rgba(255,140,66,0.12)', text: '#FF8C42', border: 'rgba(255,140,66,0.3)' },
  medium:   { bg: 'rgba(240,180,41,0.12)', text: '#F0B429', border: 'rgba(240,180,41,0.3)' },
  low:      { bg: 'rgba(0,212,200,0.12)',  text: '#00D4C8', border: 'rgba(0,212,200,0.3)' },
};

const SOURCE_COLORS = {
  wazuh:    { bg: 'rgba(0,212,200,0.12)', text: THEME.accent, border: 'rgba(0,212,200,0.25)' },
  suricata: { bg: 'rgba(251,146,60,0.12)', text: '#FB923C', border: 'rgba(251,146,60,0.25)' },
};

// ─── Helpers ─────────────────────────────────────────────────────────────────

function formatTimestamp(ts) {
  if (!ts) return '';
  return new Date(ts).toLocaleString('en-US', {
    month: 'short', day: 'numeric', hour: 'numeric',
    minute: '2-digit', second: '2-digit', hour12: true,
  });
}

function normalizeSeverity(level) {
  if (level >= 15) return 'critical';
  if (level >= 12) return 'high';
  if (level >= 7)  return 'medium';
  return 'low';
}

function formatDuration(seconds) {
  if (!seconds) return '';
  if (seconds < 60) return `${Math.round(seconds)}s`;
  if (seconds < 3600) return `${Math.floor(seconds / 60)}min`;
  return `${Math.floor(seconds / 3600)}h ${Math.floor((seconds % 3600) / 60)}min`;
}

function formatTimeAgo(ts) {
  if (!ts) return '';
  const diff = (Date.now() - new Date(ts).getTime()) / 1000;
  if (diff < 60) return `${Math.round(diff)}s ago`;
  if (diff < 3600) return `${Math.floor(diff / 60)}min ago`;
  if (diff < 86400) return `${Math.floor(diff / 3600)}h ago`;
  return `${Math.floor(diff / 86400)}d ago`;
}

// ─── SLA targets (per severity, in minutes) ─────────────────────────────────
//
// Aligned with NIST 800-61r2 + common SOC 2 expectations. Tier-1 acknowledgement
// targets are tight; resolution targets reflect "containment" not full eradication.
// These are visible in the alert card via SLABadge and are the reference for any
// downstream SOC reporting (MTTD/MTTR vs SLA).
//
// Tunable per deployment via window.__pallas_sla_overrides — useful for managed
// SOCs whose customer SLAs differ. Falls back to these defaults otherwise.
const DEFAULT_SLA = {
  critical: { ack_min: 15,  resolve_min: 60   },
  high:     { ack_min: 30,  resolve_min: 240  },
  medium:   { ack_min: 120, resolve_min: 480  },
  low:      { ack_min: 240, resolve_min: 1440 },
};

function getSLATargets(severity) {
  const overrides = (typeof window !== 'undefined' && window.__pallas_sla_overrides) || {};
  const sev = (severity || 'low').toLowerCase();
  return overrides[sev] || DEFAULT_SLA[sev] || DEFAULT_SLA.low;
}

/**
 * Compute the SLA state for a given alert.
 * Returns { phase, state, label, percentElapsed }
 *   phase: 'ack' | 'resolve' | 'closed'
 *   state: 'on-track' | 'approaching' | 'breached' | 'met' | 'missed'
 *   label: short human-readable string for the badge
 *   percentElapsed: 0..100+ (>100 = breached)
 */
function computeSLAState(alert, nowMs) {
  const incident = alert._incident || {};
  const severity = (alert.severity || 'low').toLowerCase();
  const targets = getSLATargets(severity);
  const ackMs       = targets.ack_min * 60 * 1000;
  const resolveMs   = targets.resolve_min * 60 * 1000;
  const alertMs     = new Date(alert.timestamp || incident.alert_timestamp || Date.now()).getTime();
  const ackedAtMs   = incident.acknowledged_at ? new Date(incident.acknowledged_at).getTime() : null;
  const closedAtMs  = incident.closed_at ? new Date(incident.closed_at).getTime() : null;

  // Closed → past-tense vs SLA
  if (closedAtMs) {
    const totalMs = closedAtMs - alertMs;
    const met = totalMs <= resolveMs;
    return {
      phase: 'closed',
      state: met ? 'met' : 'missed',
      label: met
        ? `SLA met (${formatDuration(totalMs / 1000)})`
        : `SLA missed (${formatDuration(totalMs / 1000)} / ${formatDuration(resolveMs / 1000)})`,
      percentElapsed: (totalMs / resolveMs) * 100,
    };
  }

  // Ack'd, counting down to resolve target
  if (ackedAtMs) {
    const elapsed = nowMs - alertMs;
    const remaining = resolveMs - elapsed;
    if (remaining < 0) {
      return {
        phase: 'resolve',
        state: 'breached',
        label: `BREACHED ${formatDuration(-remaining / 1000)}`,
        percentElapsed: 100 + ((-remaining / resolveMs) * 100),
      };
    }
    const pct = (elapsed / resolveMs) * 100;
    return {
      phase: 'resolve',
      state: pct > 50 ? 'approaching' : 'on-track',
      label: `Close in ${formatDuration(remaining / 1000)}`,
      percentElapsed: pct,
    };
  }

  // Not yet ack'd, counting down to ack target
  const elapsed = nowMs - alertMs;
  const remaining = ackMs - elapsed;
  if (remaining < 0) {
    return {
      phase: 'ack',
      state: 'breached',
      label: `ACK BREACHED ${formatDuration(-remaining / 1000)}`,
      percentElapsed: 100 + ((-remaining / ackMs) * 100),
    };
  }
  const pct = (elapsed / ackMs) * 100;
  return {
    phase: 'ack',
    state: pct > 50 ? 'approaching' : 'on-track',
    label: `ACK in ${formatDuration(remaining / 1000)}`,
    percentElapsed: pct,
  };
}

// SLABadge — tiny pill rendered next to the severity pill on each alert card.
// Color reflects SLA state; icon distinguishes the phase (ack vs resolve vs done).
function SLABadge({ alert, tickMs }) {
  const sla = computeSLAState(alert, tickMs || Date.now());
  // Don't render anything for closed alerts that met SLA — keeps the row clean.
  // Closed-but-missed shows because that's relevant for retro analysis.
  if (sla.state === 'met') return null;

  const styles = {
    'on-track':    { bg: 'rgba(16,185,129,0.12)',  fg: '#10B981', border: 'rgba(16,185,129,0.3)' },
    'approaching': { bg: 'rgba(245,158,11,0.12)',  fg: '#F59E0B', border: 'rgba(245,158,11,0.3)' },
    'breached':    { bg: 'rgba(239,68,68,0.15)',   fg: '#EF4444', border: 'rgba(239,68,68,0.4)' },
    'missed':      { bg: 'rgba(239,68,68,0.10)',   fg: '#EF4444', border: 'rgba(239,68,68,0.3)' },
  }[sla.state] || { bg: 'transparent', fg: '#94a3b8', border: 'rgba(148,163,184,0.2)' };

  const icon = sla.state === 'breached' || sla.state === 'missed' ? 'alert' : 'clock';

  return (
    <span
      title={`SLA ${sla.phase} — ${Math.round(sla.percentElapsed)}% elapsed`}
      style={{
        display: 'inline-flex', alignItems: 'center', gap: 4,
        padding: '2px 8px', borderRadius: 4,
        fontSize: 10, fontWeight: 700, lineHeight: 1.4,
        background: styles.bg,
        color: styles.fg,
        border: `1px solid ${styles.border}`,
        whiteSpace: 'nowrap',
      }}>
      <EuiIcon type={icon} size="s" color={styles.fg} />
      {sla.label}
    </span>
  );
}

// ─── Observable extraction ──────────────────────────────────────────────────

const IP_REGEX = /\b(?:(?:25[0-5]|2[0-4]\d|1\d{2}|[1-9]?\d)\.){3}(?:25[0-5]|2[0-4]\d|1\d{2}|[1-9]?\d)\b/g;
const DOMAIN_REGEX = /\b(?:[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\.)+(?:com|net|org|io|ru|cn|de|uk|info|biz|xyz|top|cc|edu|gov)\b/gi;
const HASH_REGEX = /\b[a-f0-9]{64}\b|\b[a-f0-9]{40}\b|\b[a-f0-9]{32}\b/gi;

function isPublicIP(ip) {
  const parts = ip.split('.').map(Number);
  if (parts[0] === 10) return false;
  if (parts[0] === 172 && parts[1] >= 16 && parts[1] <= 31) return false;
  if (parts[0] === 192 && parts[1] === 168) return false;
  if (parts[0] === 127) return false;
  if (parts[0] === 0) return false;
  return true;
}

function extractObservables(alert, narrativeText) {
  const seen = new Set();
  const obs = [];
  const add = (type, value, source) => {
    const key = `${type}:${value}`;
    if (seen.has(key)) return;
    seen.add(key);
    obs.push({ type, value, source, isPublic: type === 'ip' ? isPublicIP(value) : null });
  };

  // From alert fields
  if (alert.src_ip) add('ip', alert.src_ip, 'source_ip');
  if (alert.dest_ip) add('ip', alert.dest_ip, 'dest_ip');
  if (alert.http_xff) alert.http_xff.split(',').forEach(ip => { const t = ip.trim(); if (t) add('ip', t, 'xff'); });
  if (alert.http_hostname) add('domain', alert.http_hostname, 'http_host');

  // From narrative text
  if (narrativeText) {
    (narrativeText.match(IP_REGEX) || []).forEach(ip => add('ip', ip, 'narrative'));
    (narrativeText.match(DOMAIN_REGEX) || []).forEach(d => add('domain', d, 'narrative'));
    (narrativeText.match(HASH_REGEX) || []).forEach(h => add('hash', h, 'narrative'));
  }

  return obs;
}

// ─── Status colors ──────────────────────────────────────────────────────────

const STATUS_STYLES = {
  open:          { bg: 'rgba(100,116,139,0.12)', text: '#94A3B8', label: 'OPEN' },
  acknowledged:  { bg: 'rgba(6,182,212,0.12)',   text: '#06B6D4', label: 'ACKNOWLEDGED' },
  in_progress:   { bg: 'rgba(59,130,246,0.12)',  text: '#3B82F6', label: 'IN PROGRESS' },
  closed:        { bg: 'rgba(34,197,94,0.12)',   text: '#22C55E', label: 'CLOSED' },
  false_positive:{ bg: 'rgba(245,158,11,0.12)',  text: '#F59E0B', label: 'FALSE POSITIVE' },
};

const VERDICT_COLORS = {
  clean:      { bg: 'rgba(34,197,94,0.12)', text: '#22C55E' },
  low_risk:   { bg: 'rgba(245,158,11,0.12)', text: '#F59E0B' },
  suspicious: { bg: 'rgba(249,115,22,0.12)', text: '#F97316' },
  malicious:  { bg: 'rgba(239,68,68,0.12)', text: '#EF4444' },
};

// Predefined False-Positive dismissal reasons. Mirrors plugin
// attack-narrative.tsx:312-318. Analyst can pick one and (optionally) add a
// custom note that gets concatenated into the final reason string.
const FP_REASONS = [
  'Known safe IP / service',
  'Testing / security scan',
  'Misconfigured rule',
  'Duplicate alert',
  'Expected behavior',
];

// Portal-based dropdown anchored to a button. Renders into document.body so
// it escapes the stacking context of the alert card it lives in — without
// this, the next alert card's title text shows through the dropdown because
// each card creates its own stacking context (border-radius + shadow + flex
// sibling ordering). Handles outside-click + Escape to close, and tracks
// the anchor's position on scroll/resize so the dropdown stays glued to
// its button.
function AnchoredDropdown({ anchorRef, onClose, children, minWidth = 280, accentColor = '#F59E0B' }) {
  const [rect, setRect] = useState(null);
  const dropdownRef = useRef(null);

  useEffect(() => {
    if (!anchorRef.current) return;
    const updatePos = () => {
      if (!anchorRef.current) return;
      setRect(anchorRef.current.getBoundingClientRect());
    };
    updatePos();
    // Watch for layout shifts while the dropdown is open.
    window.addEventListener('scroll', updatePos, true);
    window.addEventListener('resize', updatePos);
    return () => {
      window.removeEventListener('scroll', updatePos, true);
      window.removeEventListener('resize', updatePos);
    };
  }, [anchorRef]);

  // Outside-click + Escape — close the dropdown on either signal.
  useEffect(() => {
    const onDocClick = (e) => {
      if (!dropdownRef.current) return;
      if (dropdownRef.current.contains(e.target)) return;
      if (anchorRef.current && anchorRef.current.contains(e.target)) return;
      onClose();
    };
    const onKey = (e) => {
      if (e.key === 'Escape') onClose();
    };
    document.addEventListener('mousedown', onDocClick);
    document.addEventListener('keydown', onKey);
    return () => {
      document.removeEventListener('mousedown', onDocClick);
      document.removeEventListener('keydown', onKey);
    };
  }, [anchorRef, onClose]);

  if (!rect) return null;

  return createPortal(
    <div
      ref={dropdownRef}
      style={{
        position: 'fixed',
        top: rect.bottom + 4,
        left: rect.left,
        zIndex: 99999,
        minWidth,
        background: THEME.card,
        border: `1px solid ${accentColor}55`,
        borderRadius: 8,
        boxShadow: '0 12px 32px rgba(0,0,0,0.6)',
        padding: 8,
      }}
      role="menu"
    >
      {children}
    </div>,
    document.body
  );
}

// ─── Component ───────────────────────────────────────────────────────────────

export default function PallasAttackNarrative({ connectionStatus, onQueryComplete, onClose, hideHeader }) {
  const accent = ACCENT;
  const [alerts, setAlerts] = useState([]);
  const [metadata, setMetadata] = useState(null);
  const [isLoading, setIsLoading] = useState(false);
  const [loadError, setLoadError] = useState(null);

  // ── Filter / pagination state (URL-synced) ──────────────────────────
  // The URL is the single source of truth: bookmarkable, shareable, and
  // analyst's filter view survives page reload. Empty/default values are
  // dropped from the URL by `updateFilter` to keep links short.
  const [searchParams, setSearchParams] = useUrlSearchParams();
  const filters = useMemo(() => ({
    time_range:  searchParams.get('time_range')  || '24h',
    severity:    searchParams.get('severity')    || 'all',
    source:      searchParams.get('source')      || 'all',
    status:      searchParams.get('status')      || 'all',
    assigned_to: searchParams.get('assigned_to') || '',
    search:      searchParams.get('search')      || '',
    page:        parseInt(searchParams.get('page') || '1', 10) || 1,
    page_size:   parseInt(searchParams.get('page_size') || '25', 10) || 25,
  }), [searchParams]);

  const updateFilter = useCallback((updates) => {
    setSearchParams(prev => {
      const next = new URLSearchParams(prev);
      Object.entries(updates).forEach(([k, v]) => {
        // Drop default / empty values so the URL stays minimal
        if (v == null || v === '' || v === 'all' || (k === 'page' && v === 1) || (k === 'page_size' && v === 25)) {
          next.delete(k);
        } else {
          next.set(k, String(v));
        }
      });
      // Any filter change other than `page`/`page_size` resets pagination to 1
      const onlyPaging = Object.keys(updates).every(k => k === 'page' || k === 'page_size');
      if (!onlyPaging) next.delete('page');
      return next;
    }, { replace: true });
  }, [setSearchParams]);

  // Search input keeps its own immediate state for responsive typing; the
  // URL is updated only after a 250ms debounce to avoid hammering the
  // backend on every keystroke.
  const [searchInput, setSearchInput] = useState(filters.search);
  useEffect(() => {
    if (searchInput === filters.search) return;
    const t = setTimeout(() => updateFilter({ search: searchInput }), 250);
    return () => clearTimeout(t);
  }, [searchInput, filters.search, updateFilter]);
  // Sync external URL changes back into the input (e.g. reset button)
  useEffect(() => { setSearchInput(filters.search); }, [filters.search]);

  const [generatingAlertId, setGeneratingAlertId] = useState(null);
  const [narratives, setNarratives] = useState({});
  const [typewriterText, setTypewriterText] = useState({});

  // ── Incident management state ──
  const [incidents, setIncidents] = useState({});       // alertId → IncidentState
  const [integrationStatus, setIntegrationStatus] = useState({ jira: false, agelia_blocking: false });
  // List view: hide muted alerts by default (matches Cortex XSOAR / Splunk SOAR
  // convention — mute = "I don't want to see this anymore"). Toggle stays
  // available for analysts who need to audit what automation has filtered.
  // The "Show muted" toggle is now folded into the Muted lifecycle tab —
  // selecting that tab implicitly sets showMutedInList to true via tabKey.
  const [showMutedInList, setShowMutedInList] = useState(false);

  // Lifecycle tabs — analyst's current "view" of the alert list. One of:
  //   'open'        — alerts not yet acknowledged
  //   'in_progress' — acknowledged / ticketed / assigned but not closed
  //   'closed'      — closed (either resolved-style or false-positive)
  //   'muted'       — alerts suppressed by mute rules (only place they appear)
  // Default landing tab is 'open' because that's the analyst's first job.
  // tabPagination remembers the page index per tab so switching tabs and back
  // doesn't lose your place. Backend status filter is the source of truth via
  // the existing `filters.status` URL param (we just route tab clicks to it).
  const [activeTab, setActiveTab] = useState('open');
  const [tabPagination, setTabPagination] = useState({
    open: 1, in_progress: 1, closed: 1, muted: 1,
  });
  // Per-tab badge counters populated from metadata.tab_counts on each fetch.
  // Lets the LifecycleTabs render "Open: 12, In Progress: 5, Closed: 200,
  // Muted: 73" so the analyst sees their queue across all states without
  // having to click each tab individually.
  const [tabCounts, setTabCounts] = useState({ open: 0, in_progress: 0, closed: 0, muted: 0 });

  // Phase B — duplicate grouping. When we send `group_by` to the backend it
  // returns alerts folded by signature key in metadata.groups. We render group
  // rows for any group with count > 1; singletons render via the existing
  // renderAlertCard path. expandedGroups tracks which groups the analyst has
  // manually expanded; default-collapsed for noise reduction in Open/InProgress
  // tabs and default-expanded in Closed (audit reading).
  const [groups, setGroups] = useState(null); // null = grouping not in use; [] = empty
  const [expandedGroups, setExpandedGroups] = useState({});
  // Phase C — bulk action state. selectedGroups holds signature_keys of groups
  // the analyst has checked for bulk action; bulkActionInFlight locks per-alert
  // controls inside any selected group while a batched call is running.
  const [selectedGroups, setSelectedGroups] = useState(() => new Set());
  const [bulkActionInFlight, setBulkActionInFlight] = useState(null);
  const [showBulkMuteModal, setShowBulkMuteModal] = useState(false);
  const [bulkMuteGroup, setBulkMuteGroup] = useState(null);
  const [bulkMuteClassification, setBulkMuteClassification] = useState('false_positive');
  const [showBulkCloseModal, setShowBulkCloseModal] = useState(false);
  const [bulkCloseDispo, setBulkCloseDispo] = useState('resolved');
  const [bulkCloseNotes, setBulkCloseNotes] = useState('');
  const isGroupExpanded = useCallback((sigKey, defaultExpanded) => {
    if (Object.prototype.hasOwnProperty.call(expandedGroups, sigKey)) {
      return expandedGroups[sigKey];
    }
    return defaultExpanded;
  }, [expandedGroups]);
  const toggleGroup = useCallback((sigKey, currentlyExpanded) => {
    setExpandedGroups(prev => ({ ...prev, [sigKey]: !currentlyExpanded }));
  }, []);

  // Compact-row state: which alert cards the analyst has explicitly expanded
  // (open) or collapsed (closed). Keys = alert.id; value = boolean. When an
  // alert is NOT in this set, fall back to a smart default based on incident
  // status — fresh open alerts collapse for fast triage; alerts the analyst
  // is actively working on (acknowledged / in_progress) auto-expand.
  const [expandedRows, setExpandedRows] = useState({});
  const isRowExpanded = useCallback((alertId, defaultExpanded) => {
    if (Object.prototype.hasOwnProperty.call(expandedRows, alertId)) {
      return expandedRows[alertId];
    }
    return defaultExpanded;
  }, [expandedRows]);
  const toggleRow = useCallback((alertId, currentlyExpanded) => {
    setExpandedRows(prev => ({ ...prev, [alertId]: !currentlyExpanded }));
  }, []);
  const [actionLoading, setActionLoading] = useState({}); // "ack:{id}" → true
  const [actionError, setActionError] = useState({});
  const [showMuteModal, setShowMuteModal] = useState(false);
  const [muteModalAlert, setMuteModalAlert] = useState(null);
  const [muteConditionOptions, setMuteConditionOptions] = useState([]);
  const [muteSelectedConditions, setMuteSelectedConditions] = useState({});
  const [muteClassification, setMuteClassification] = useState('false_positive');
  // Block IP modal — replaces the previous double-click confirm pattern.
  const [showBlockModal, setShowBlockModal] = useState(false);
  const [blockModalAlert, setBlockModalAlert] = useState(null);
  const [blockIpCandidates, setBlockIpCandidates] = useState([]); // [{ip, label, isPrivate}]
  const [blockSelectedIp, setBlockSelectedIp] = useState('');
  const [blockReason, setBlockReason] = useState('');
  const [blockThreatType, setBlockThreatType] = useState('other');
  const [blockExpiresHours, setBlockExpiresHours] = useState(''); // '' = permanent
  // Close-with-disposition modal (Mode B only — no Jira). Mute and Block already
  // auto-close with derived dispositions; this modal handles the rare "close
  // without taking action" case (analyst investigated, real but mitigated
  // elsewhere, etc.).
  const [showCloseDispoModal, setShowCloseDispoModal] = useState(false);
  const [closeDispoAlert, setCloseDispoAlert] = useState(null);
  const [closeDispoChoice, setCloseDispoChoice] = useState('resolved');
  const [closeDispoNotes, setCloseDispoNotes] = useState('');
  const [enrichments, setEnrichments] = useState({});   // "ip:1.2.3.4" → EnrichmentResult
  const [enrichingObs, setEnrichingObs] = useState(null); // currently enriching observable
  const [narrativeViewed, setNarrativeViewed] = useState({}); // alertId → true
  // Tick state for live SLA countdowns. Updates every 60s so all SLABadge
  // instances re-render with fresh "ACK in 12m" / "Close in 2h" / "BREACHED
  // 5m" text without per-component intervals.
  const [slaTickMs, setSlaTickMs] = useState(Date.now());
  useEffect(() => {
    const id = setInterval(() => setSlaTickMs(Date.now()), 60_000);
    return () => clearInterval(id);
  }, []);
  const [assignableUsers, setAssignableUsers] = useState([]); // JiraUser[]
  const [showAssignDropdown, setShowAssignDropdown] = useState(null); // alertId
  // False-Positive dropdown state — Mute (Agelia) is HIDE_MUTE'd this release,
  // so FP dismissals route through /api/narrative/incident/dismiss-fp instead.
  // When Agelia ships, add a "Mute this signature" row inside the same dropdown
  // (mirror plugin attack-narrative.tsx:2015-2028).
  const [showFPDropdown, setShowFPDropdown] = useState(null); // alertId
  const [fpNotes, setFPNotes] = useState('');
  // Per-alert button refs — used as anchors for the portal-based FP and
  // Assign dropdowns. The dropdowns render into document.body to escape
  // the alert card's stacking context, so they need ref handles to compute
  // their position. Refs are populated by the button's `ref` callback.
  const fpButtonRefs = useRef({});      // { [alertId]: HTMLButtonElement }
  const assignButtonRefs = useRef({});  // { [alertId]: HTMLButtonElement }
  const [expandedAlertId, setExpandedAlertId] = useState(null);
  const [pinnedNarratives, setPinnedNarratives] = useState([]);
  const [compareMode, setCompareMode] = useState(false);
  const typewriterRef = useRef({});
  const [hasScanned, setHasScanned] = useState(false);

  // ── Fetch alerts ─────────────────────────────────────────────────────────

  const fetchAlerts = useCallback(async (filterValues, includeMutedOverride, tabOverride) => {
    setIsLoading(true);
    setLoadError(null);
    setHasScanned(true);
    // Resolve the effective tab — explicit override (used during transitions
    // when state hasn't updated yet) wins over current activeTab state.
    const effectiveTab = tabOverride || activeTab;
    // Translate the tab into the (status, include_muted) pair the backend expects.
    // The 'all' status passes through unchanged so legacy callers keep working.
    let effectiveStatus;
    let effectiveIncludeMuted;
    switch (effectiveTab) {
      case 'open':
        effectiveStatus = 'open';
        effectiveIncludeMuted = false;
        break;
      case 'in_progress':
        // Once an analyst has acked an alert, it stays visible in In Progress
        // until they manually close it — even if the pattern got muted. So
        // we include muted alerts here. Backend status_filter='in_progress'
        // matches BOTH 'in_progress' AND 'acknowledged' (alias for the bucket).
        effectiveStatus = 'in_progress';
        effectiveIncludeMuted = true;
        break;
      case 'closed':
        // Backend status_filter='closed' matches BOTH 'closed' and
        // 'false_positive' (analyst's resolved work, regardless of disposition).
        // Include muted so that closed-but-muted records are visible in the
        // analyst's audit trail.
        effectiveStatus = 'closed';
        effectiveIncludeMuted = true;
        break;
      case 'muted':
        // Muted tab: server returns ALL muted alerts regardless of lifecycle
        // status. We use 'all' for status because muted alerts can be in any
        // state (open-but-muted, ack'd-but-muted, etc.) — the unifying property
        // is _agelia_muted=true, which include_muted=true keeps in the result.
        effectiveStatus = 'all';
        effectiveIncludeMuted = true;
        break;
      default:
        // Fall-through: caller hasn't picked a tab. Use whatever filter says.
        effectiveStatus = filterValues.status;
        effectiveIncludeMuted = typeof includeMutedOverride === 'boolean'
          ? includeMutedOverride : showMutedInList;
    }
    try {
      const data = await pallasPost('/api/narrative/generate', {
        time_range:  filterValues.time_range,
        min_level:   12,
        severity:    filterValues.severity,
        source:      filterValues.source,
        status:      effectiveStatus,
        assigned_to: filterValues.assigned_to,
        search:      filterValues.search,
        page:        filterValues.page,
        page_size:   filterValues.page_size,
        include_muted: effectiveIncludeMuted,
        // Grouping disabled — analyst sees each alert individually so each
        // gets its own audit trail (incident record + Jira ticket per alert).
        // Backend bulk endpoints + GroupRow rendering remain in place but
        // inert; re-enable by sending `['rule_id', 'source', 'src_ip']`.
        group_by: [],
      });
      // Muted tab: filter the response client-side to keep ONLY _agelia_muted
      // alerts (backend with include_muted=true returns muted + non-muted; we
      // want muted-only as the tab's defining content).
      let alertsForTab = data.alerts || [];
      let groupsForTab = data.metadata?.groups || null;
      if (effectiveTab === 'muted') {
        alertsForTab = alertsForTab.filter(a => a._agelia_muted);
        if (groupsForTab) {
          groupsForTab = groupsForTab
            .map(g => ({ ...g, alerts: g.alerts.filter(a => a._agelia_muted) }))
            .filter(g => g.alerts.length > 0)
            .map(g => ({ ...g, count: g.alerts.length }));
        }
      }
      setAlerts(alertsForTab);
      setGroups(groupsForTab);
      setMetadata(data.metadata || null);
      if (data.metadata?.tab_counts) {
        setTabCounts(data.metadata.tab_counts);
      }
      if (onQueryComplete) {
        onQueryComplete('narrative', `Scan ${filterValues.time_range} (${alertsForTab.length} alerts)`, 0);
      }
    } catch (err) {
      setLoadError(err.message);
      setAlerts([]);
      setGroups(null);
      setMetadata(null);
    } finally {
      setIsLoading(false);
    }
  }, [onQueryComplete, showMutedInList, activeTab]);

  // Refetch whenever any filter changes, the active tab changes, or the legacy
  // showMutedInList flag changes. activeTab being in deps means clicking a tab
  // immediately re-fetches with the right backend params.
  useEffect(() => {
    fetchAlerts(filters);
  }, [filters, fetchAlerts, showMutedInList, activeTab]);

  useEffect(() => {
    // Fetch integration status on mount
    pallasPost('/api/narrative/incident/integration-status', {}).then(data => {
      if (data) {
        // Forward-compatible: accept the new {agelia_blocking} shape and fall back
        // to legacy {waf, firewall} so the Block button stays visible regardless
        // of whether the deployed Pallas backend has been upgraded.
        const blockingOk = data.agelia_blocking ?? (data.waf || data.firewall);
        setIntegrationStatus({ jira: !!data.jira, agelia_blocking: !!blockingOk });
        // Fetch assignable users if JIRA is configured
        if (data.jira) {
          pallasPost('/api/narrative/incident/assignable-users', {}).then(d => {
            if (d?.users) setAssignableUsers(d.users);
          }).catch(() => {});
        }
      }
    }).catch(() => {});
    return () => { Object.values(typewriterRef.current).forEach(clearInterval); };
  }, []); // eslint-disable-line react-hooks/exhaustive-deps

  // Fetch incident states when alerts change
  useEffect(() => {
    if (alerts.length === 0) return;
    const alertIds = alerts.map(a => a.id).filter(Boolean);
    if (alertIds.length === 0) return;
    pallasPost('/api/narrative/incidents/batch', { alert_ids: alertIds }).then(data => {
      if (data && typeof data === 'object') setIncidents(data);
    }).catch(() => {});
  }, [alerts]);

  // ── Incident actions ────────────────────────────────────────────────────

  const setActionState = (key, loading) => {
    setActionLoading(prev => ({ ...prev, [key]: loading }));
    if (loading) setActionError(prev => ({ ...prev, [key]: null }));
  };

  // Forward-ref to generateNarrative — declared later in the file, so we use a
  // ref to call it from handleAcknowledge without a TDZ error in the deps array.
  const generateNarrativeRef = useRef(null);

  const handleAcknowledge = useCallback(async (alert) => {
    const key = `ack:${alert.id}`;
    setActionState(key, true);
    try {
      const data = await pallasPost('/api/narrative/incident/acknowledge', {
        alert_id: alert.id, alert, analyst_name: getCurrentAnalystName(),
      });
      if (data) setIncidents(prev => ({ ...prev, [alert.id]: data }));

      // Refetch the canonical incident shape right after ack so we have a
      // reliable `incident_id`. The /acknowledge response can return a
      // lighter payload that omits incident_id, which then causes Create
      // Ticket to fail with HTTP 400 "Incident not found. Acknowledge the
      // alert first." even though the frontend shows ACK'd. The batch
      // endpoint returns the full incident object, so merging it here
      // guarantees Create Ticket has the right id ready.
      try {
        const fresh = await pallasPost('/api/narrative/incidents/batch', {
          alert_ids: [alert.id],
        });
        if (fresh && fresh[alert.id]) {
          setIncidents(prev => ({ ...prev, [alert.id]: { ...prev[alert.id], ...fresh[alert.id] } }));
        }
      } catch { /* non-fatal — Create Ticket will still try with what we have */ }

      // Auto-generate AI narrative on first Acknowledge so the engineer who
      // picks up the Jira ticket has full context already populated.
      if (!narratives[alert.id]) {
        generateNarrativeRef.current?.(alert);
      }
    } catch (err) {
      setActionError(prev => ({ ...prev, [key]: err.message }));
    } finally {
      setActionState(key, false);
    }
  }, [narratives]);

  const handleCreateTicket = useCallback(async (alert) => {
    const key = `jira:${alert.id}`;
    setActionState(key, true);
    try {
      // Ensure the AI narrative is fully generated before creating the ticket so
      // the engineer who opens Jira gets full context. Auto-narrative starts
      // firing on Acknowledge, so by Create-Ticket time it's usually already
      // there — but if the analyst clicks fast, we kick off generation and wait.
      let narrativeText = narratives[alert.id];
      if (!narrativeText) {
        // Trigger generation if not yet started
        await generateNarrativeRef.current?.(alert);
        // Read the latest value via a microtask — generateNarrative writes to
        // narratives state; functional read is reliable enough for this flow.
        narrativeText = narratives[alert.id] || '';
      }

      // Defensive: if our local incident snapshot is missing `incident_id`
      // (e.g. the /acknowledge response was lighter and the post-ack refetch
      // hadn't completed by the time the analyst clicked Create Ticket),
      // refetch the canonical incident shape one more time before posting.
      // Without this, the backend's create-ticket lookup fails with
      // HTTP 400 "Incident not found. Acknowledge the alert first." even
      // though the alert is genuinely acknowledged.
      let incidentId = incidents[alert.id]?.incident_id || '';
      if (!incidentId) {
        try {
          const fresh = await pallasPost('/api/narrative/incidents/batch', {
            alert_ids: [alert.id],
          });
          if (fresh && fresh[alert.id]) {
            incidentId = fresh[alert.id].incident_id || '';
            setIncidents(prev => ({ ...prev, [alert.id]: { ...prev[alert.id], ...fresh[alert.id] } }));
          }
        } catch { /* fall through and let the create-ticket call return its real error */ }
      }

      const data = await pallasPost('/api/narrative/incident/create-ticket', {
        // Use the refreshed `incidentId` local — reading from state here would
        // see the pre-refetch value because React batches updates.
        alert_id: alert.id, incident_id: incidentId,
        narrative: narrativeText, alert, analyst_name: getCurrentAnalystName(),
      });
      if (data) setIncidents(prev => ({ ...prev, [alert.id]: { ...prev[alert.id], ...data } }));
    } catch (err) {
      setActionError(prev => ({ ...prev, [key]: err.message }));
    } finally {
      setActionState(key, false);
    }
  }, [incidents, narratives]);

  const handleCloseIncident = useCallback(async (alert, resolutionNotes) => {
    const key = `close:${alert.id}`;
    setActionState(key, true);
    try {
      const body = {
        alert_id: alert.id,
        incident_id: incidents[alert.id]?.incident_id || '',
        analyst_name: getCurrentAnalystName(),
      };
      // Optional derived close reason from auto-close flows (e.g. "Closed: False Positive (muted)")
      if (resolutionNotes) body.resolution_notes = resolutionNotes;
      const data = await pallasPost('/api/narrative/incident/close', body);
      if (data) setIncidents(prev => ({ ...prev, [alert.id]: { ...prev[alert.id], ...data, status: 'closed' } }));
    } catch (err) {
      setActionError(prev => ({ ...prev, [key]: err.message }));
    } finally {
      setActionState(key, false);
    }
  }, [incidents]);

  // Dismiss alert as False Positive — independent path from Mute (which uses
  // Agelia and is HIDE_MUTE'd this release). POSTs to the dedicated
  // /dismiss-fp endpoint so the audit trail captures analyst + reason without
  // requiring any Agelia call. Reason is the picked preset, optionally
  // suffixed with the free-form note. After success the existing FP badge
  // (status === 'false_positive') renders automatically and the Block button
  // disappears.
  const handleDismissFP = useCallback(async (alert, reason) => {
    const key = `fp:${alert.id}`;
    setActionState(key, true);
    try {
      const notes = fpNotes.trim() ? `${reason}: ${fpNotes.trim()}` : reason;
      const analyst = getCurrentAnalystName();
      const data = await pallasPost('/api/narrative/incident/dismiss-fp', {
        alert_id: alert.id,
        incident_id: incidents[alert.id]?.incident_id || '',
        reason: notes,
        analyst_name: analyst,
      });
      if (data) {
        setIncidents(prev => ({
          ...prev,
          [alert.id]: {
            ...prev[alert.id],
            ...data,
            status: 'false_positive',
            fp_reason: notes,
            fp_dismissed_by: analyst,
          },
        }));
      } else {
        // Optimistic fallback so the UI updates even if the response body is
        // empty / non-JSON — the badge keys off status === 'false_positive'.
        setIncidents(prev => ({
          ...prev,
          [alert.id]: {
            ...prev[alert.id],
            status: 'false_positive',
            fp_reason: notes,
            fp_dismissed_by: analyst,
          },
        }));
      }
      setShowFPDropdown(null);
      setFPNotes('');
    } catch (err) {
      setActionError(prev => ({ ...prev, [key]: err.message }));
    } finally {
      setActionState(key, false);
    }
  }, [incidents, fpNotes]);

  // ── Close-with-disposition modal ────────────────────────────────────────
  // Used in Mode B (no Jira) when analyst wants to close without muting or
  // blocking — captures a categorical disposition + optional notes for audit.

  const openCloseDispositionModal = useCallback((alert) => {
    setCloseDispoAlert(alert);
    setCloseDispoChoice('resolved');
    setCloseDispoNotes('');
    setShowCloseDispoModal(true);
  }, []);

  const executeCloseDisposition = useCallback(async () => {
    if (!closeDispoAlert) return;
    const alert = closeDispoAlert;
    const key = `close:${alert.id}`;
    setShowCloseDispoModal(false);
    setActionState(key, true);
    try {
      const body = {
        alert_id: alert.id,
        incident_id: incidents[alert.id]?.incident_id || '',
        disposition: closeDispoChoice,
        notes: closeDispoNotes,
        analyst_name: getCurrentAnalystName(),
      };
      const data = await pallasPost('/api/narrative/incident/close-with-disposition', body);
      if (data) setIncidents(prev => ({ ...prev, [alert.id]: { ...prev[alert.id], ...data, status: 'closed' } }));
    } catch (err) {
      setActionError(prev => ({ ...prev, [key]: err.message }));
    } finally {
      setActionState(key, false);
    }
  }, [closeDispoAlert, closeDispoChoice, closeDispoNotes, incidents]);

  // Pending auto-close timers keyed by alert.id — used to cancel when the analyst clicks Undo.
  // Stored in a ref because timers are non-reactive (we don't want re-renders on each tick).
  const autoCloseTimersRef = useRef(new Map());

  // Cleanup any pending auto-close timers when the component unmounts (avoid leaking timers).
  useEffect(() => {
    const timers = autoCloseTimersRef.current;
    return () => {
      timers.forEach((timeoutId) => clearTimeout(timeoutId));
      timers.clear();
    };
  }, []);

  // Schedule auto-close 5s after a Mute or Block, with a toast offering Undo.
  // Pattern from Cortex XSOAR / Sentinel: analyst verdict (Mute/Block) is decisive, so the
  // incident closes automatically — but the analyst can cancel within a short undo window.
  const scheduleAutoClose = useCallback((alert, resolutionNotes) => {
    const timers = autoCloseTimersRef.current;
    // Cancel any existing pending close for this alert before scheduling a new one
    if (timers.has(alert.id)) {
      clearTimeout(timers.get(alert.id));
    }

    const toastId = `autoclose:${alert.id}`;
    const fireAt = Date.now() + 5000;

    const timeoutId = setTimeout(() => {
      timers.delete(alert.id);
      toast.dismiss(toastId);
      handleCloseIncident(alert, resolutionNotes);
    }, 5000);
    timers.set(alert.id, timeoutId);

    toast.custom((t) => {
      const remaining = Math.max(0, Math.ceil((fireAt - Date.now()) / 1000));
      return (
        <div style={{
          background: THEME.card,
          border: `1px solid ${THEME.border}`,
          borderLeft: `3px solid #A78BFA`,
          borderRadius: 10,
          padding: '12px 16px',
          minWidth: 320,
          boxShadow: '0 8px 24px rgba(0,0,0,0.4)',
          display: 'flex', alignItems: 'center', gap: 14,
          opacity: t.visible ? 1 : 0,
          transition: 'opacity 0.2s ease',
        }}>
          <div style={{ flex: 1, fontSize: 13, color: THEME.text }}>
            {resolutionNotes} <span style={{ color: THEME.textMuted }}>· auto-closing in {remaining}s</span>
          </div>
          <button
            onClick={() => {
              if (timers.has(alert.id)) {
                clearTimeout(timers.get(alert.id));
                timers.delete(alert.id);
              }
              toast.dismiss(t.id);
            }}
            style={{
              padding: '5px 12px', borderRadius: 6, fontSize: 12, fontWeight: 600,
              border: '1px solid #A78BFA', background: 'transparent', color: '#A78BFA',
              cursor: 'pointer', outline: 'none',
            }}>
            Undo
          </button>
        </div>
      );
    }, { id: toastId, duration: 5000, position: 'bottom-right' });
  }, [handleCloseIncident]);

  const handleAssignUser = useCallback(async (alert, user) => {
    const key = `assign:${alert.id}`;
    setActionState(key, true);
    setShowAssignDropdown(null);
    try {
      const data = await pallasPost('/api/narrative/incident/assign-ticket', {
        alert_id: alert.id, incident_id: incidents[alert.id]?.incident_id || '',
        jira_ticket_id: incidents[alert.id]?.jira_ticket_id || '',
        assignee_id: user.accountId || user.id || user.name,
        assignee_name: user.displayName || user.name,
        analyst_name: getCurrentAnalystName(),
      });
      if (data) setIncidents(prev => ({ ...prev, [alert.id]: { ...prev[alert.id], ...data } }));
    } catch (err) {
      setActionError(prev => ({ ...prev, [key]: err.message }));
    } finally {
      setActionState(key, false);
    }
  }, [incidents]);

  // RFC1918 / loopback / link-local check for IP candidate UI
  const isPrivateIp = useCallback((ip) => {
    if (!ip) return true;
    if (ip === '127.0.0.1' || ip === '::1' || ip.startsWith('169.254.') || ip.startsWith('fe80:')) return true;
    if (ip.startsWith('10.')) return true;
    if (ip.startsWith('192.168.')) return true;
    const m = ip.match(/^172\.(\d+)\./);
    if (m) {
      const n = parseInt(m[1], 10);
      if (n >= 16 && n <= 31) return true;
    }
    return false;
  }, []);

  const openBlockModal = useCallback((alert) => {
    // Build candidate IP list from observables. Public IPs are pre-selected;
    // RFC1918 entries are visible but disabled (cannot be blocked at perimeter).
    const seen = new Set();
    const candidates = [];
    const push = (ip, label) => {
      if (!ip || seen.has(ip)) return;
      seen.add(ip);
      candidates.push({ ip, label, isPrivate: isPrivateIp(ip) });
    };
    const xffFirst = alert.http_xff?.split(',')[0]?.trim();
    push(xffFirst, 'X-Forwarded-For (true origin)');
    push(alert.src_ip || alert.source_ip, 'Source IP');
    push(alert.dest_ip || alert.destination_ip, 'Destination IP');

    const firstPublic = candidates.find(c => !c.isPrivate);
    setBlockModalAlert(alert);
    setBlockIpCandidates(candidates);
    setBlockSelectedIp(firstPublic ? firstPublic.ip : '');
    setBlockReason('');
    setBlockThreatType('other');
    setBlockExpiresHours('');
    setShowBlockModal(true);
  }, [isPrivateIp]);

  const executeBlock = useCallback(async () => {
    if (!blockModalAlert || !blockSelectedIp) return;
    const alert = blockModalAlert;
    const key = `waf:${alert.id}`;
    setShowBlockModal(false);
    setActionState(key, true);
    try {
      const body = {
        alert_id: alert.id,
        incident_id: incidents[alert.id]?.incident_id || '',
        ip: blockSelectedIp,
        analyst_name: getCurrentAnalystName(),
        threat_type: blockThreatType,
        reason: blockReason || `Blocked from Pallas: ${blockThreatType}`,
      };
      if (blockExpiresHours) body.expires_in_hours = Number(blockExpiresHours);
      const data = await pallasPost('/api/narrative/incident/waf-block', body);
      // The Pallas backend returns the Agelia AWS response (aws_enforced,
      // waf_enforced, metadata_id, layers_blocked) — not the Pallas-side
      // incident-store fields. Set the lifecycle flags the status banner
      // reads (`waf_blocked` / `firewall_blocked`) explicitly here so the
      // green "WAF: Blocked" / "FW: Blocked" badge appears immediately on
      // the alert card without waiting for a page refresh. Backend already
      // wrote the same values to incident_store.
      const layers = (data && data.layers_blocked) || [];
      const wafEnforced  = data?.waf_enforced  ?? layers.includes('waf');
      const nfwEnforced  = data?.aws_enforced  ?? layers.includes('network_firewall');
      const nowIso = new Date().toISOString();
      if (data) {
        setIncidents(prev => ({
          ...prev,
          [alert.id]: {
            ...prev[alert.id],
            ...data,
            waf_blocked: wafEnforced,
            waf_blocked_at: wafEnforced ? nowIso : prev[alert.id]?.waf_blocked_at,
            firewall_blocked: nfwEnforced,
            firewall_blocked_at: nfwEnforced ? nowIso : prev[alert.id]?.firewall_blocked_at,
            firewall_blocked_ip: blockSelectedIp,
          },
        }));
      }
      // Block is an action, not a final disposition. The incident stays open
      // until the analyst explicitly clicks Close Incident and picks a
      // disposition. This avoids the "auto-closed on me while I was multitasking"
      // surprise and keeps Pallas's behavior consistent with how Sentinel,
      // XSOAR, and Splunk SOAR handle decisive analyst actions.
    } catch (err) {
      setActionError(prev => ({ ...prev, [key]: err.message }));
    } finally {
      setActionState(key, false);
    }
  }, [blockModalAlert, blockSelectedIp, blockReason, blockThreatType, blockExpiresHours]);

  const openMuteModal = useCallback((alert) => {
    const isSuricata = (alert.source || '').toLowerCase() === 'suricata';
    const sev = alert.severity || normalizeSeverity(alert.level);
    // Pallas backend normalizes Suricata's signature_id into the `rule_id` field
    // (server.py:_normalize_suricata_alert), so for Suricata alerts the SID lives at
    // alert.rule_id. Wazuh alerts use alert.rule_id natively; the two never overlap
    // because the modal branches on isSuricata when picking which condition to expose.
    const sigId  = String(alert.signature_id || alert.alert?.signature_id || (isSuricata ? alert.rule_id : '') || '');
    const ruleId = String((!isSuricata && alert.rule_id) || alert.rule?.id || '');
    const srcIp = alert.http_xff?.split(',')[0]?.trim() || alert.src_ip || alert.source_ip || '';
    const destIp = alert.dest_ip || alert.destination_ip || '';
    const agentName = alert.agent?.name || '';
    const category = alert.category || alert.rule?.groups?.[0] || '';

    const opts = isSuricata ? [
      { key: 'signature_id', label: 'Signature ID',    value: sigId },
      { key: 'source_ip',    label: 'Source IP',       value: srcIp },
      { key: 'dest_ip',      label: 'Destination IP',  value: destIp },
      { key: 'severity',     label: 'Severity Level',  value: sev },
      { key: 'category',     label: 'Category',        value: category },
    ] : [
      { key: 'rule_id',      label: 'Rule ID',         value: ruleId },
      { key: 'source_ip',    label: 'Source IP',       value: srcIp },
      { key: 'agent_name',   label: 'Agent Name',      value: agentName },
      { key: 'severity',     label: 'Severity Level',  value: sev },
      { key: 'category',     label: 'Category',        value: category },
    ];

    setMuteModalAlert(alert);
    setMuteConditionOptions(opts);
    setMuteSelectedConditions({});
    setMuteClassification('false_positive');
    setShowMuteModal(true);
  }, []);

  const executeMute = useCallback(async () => {
    if (!muteModalAlert) return;
    const conditions = {};
    muteConditionOptions.forEach(opt => {
      if (muteSelectedConditions[opt.key] && opt.value) conditions[opt.key] = opt.value;
    });
    if (Object.keys(conditions).length === 0) return;
    const alert = muteModalAlert;
    const classification = muteClassification;
    const key = `mute:${alert.id}`;
    setShowMuteModal(false);
    setActionState(key, true);
    try {
      await pallasPost('/api/narrative/incident/mute-agelia', {
        alert_id: alert.id,
        conditions,
        classification,
        analyst_name: getCurrentAnalystName(),
        reason: `Muted from Pallas: ${classification}`,
      });
      setIncidents(prev => ({ ...prev, [alert.id]: { ...prev[alert.id], agelia_muted: true, agelia_muted_conditions: conditions } }));
      // Mute is an intermediate action — it suppresses the rule pattern but does
      // NOT close the incident. The classification on the mute is about the rule
      // pattern (e.g. "this rule fires on benign traffic"); the disposition for
      // *this specific alert* is captured separately when the analyst clicks
      // Close Incident and picks a disposition. This separation matters for SOC 2
      // audit clarity — muting a noisy rule does not retroactively classify
      // every past alert from that rule as the same disposition.
    } catch (err) {
      setActionError(prev => ({ ...prev, [key]: err.message }));
    } finally {
      setActionState(key, false);
    }
  }, [muteModalAlert, muteConditionOptions, muteSelectedConditions, muteClassification]);

  // ── Bulk action handlers (Phase C) ───────────────────────────────────────
  // Each generates an idempotency key per click, locks the in-flight bar so
  // double-clicks coalesce, batches one HTTP call for N alerts, then refetches
  // to reconcile. Results map per-alert lookups so the in-memory `incidents`
  // cache updates atomically — no per-alert visual flicker.

  const generateIdempotencyKey = () => {
    // RFC4122 v4-ish — analyst-friendly random key, doesn't need cryptographic
    // strength because uniqueness is the only invariant we need for dedup.
    return 'bulk-' + Date.now().toString(36) + '-' +
           Math.random().toString(36).slice(2, 10) + '-' +
           Math.random().toString(36).slice(2, 10);
  };

  const groupAlertIds = (group) => (group?.alerts || []).map(a => a.id).filter(Boolean);

  const handleBulkAcknowledge = useCallback(async (group) => {
    if (!group || bulkActionInFlight) return;
    const alertIds = groupAlertIds(group);
    if (!alertIds.length) return;
    const idemKey = generateIdempotencyKey();
    setBulkActionInFlight({ action: 'ack', signature_key: group.signature_key, idempotency_key: idemKey, count: alertIds.length });
    try {
      const alertsMap = {};
      for (const a of group.alerts) { if (a.id) alertsMap[a.id] = a; }
      const data = await pallasPost('/api/narrative/incident/bulk-acknowledge', {
        alert_ids:       alertIds,
        alerts:          alertsMap,
        analyst_name:    getCurrentAnalystName(),
        idempotency_key: idemKey,
      });
      // Merge per-alert incident records back into in-memory cache so the
      // group's children all show ACK'd state immediately.
      if (data && data.results) {
        setIncidents(prev => ({ ...prev, ...data.results }));
      }
      // Drop the group from selection — it's no longer "open" so the bulk-ack
      // button isn't relevant for it.
      setSelectedGroups(prev => {
        const next = new Set(prev);
        next.delete(group.signature_key);
        return next;
      });
    } catch (err) {
      setActionError(prev => ({ ...prev, [`bulk-ack:${group.signature_key}`]: err.message }));
    } finally {
      setBulkActionInFlight(null);
    }
  }, [bulkActionInFlight]);

  const openBulkMuteModal = useCallback((group) => {
    if (!group || bulkActionInFlight) return;
    setBulkMuteGroup(group);
    setBulkMuteClassification('false_positive');
    setShowBulkMuteModal(true);
  }, [bulkActionInFlight]);

  const executeBulkMute = useCallback(async () => {
    const group = bulkMuteGroup;
    if (!group) return;
    const alertIds = groupAlertIds(group);
    if (!alertIds.length) return;
    // Conditions for the single new mute rule are derived from the signature
    // key — the same fields used to fold the group server-side. This ensures
    // the mute matches future alerts of the exact same pattern, not just the
    // current 50 instances.
    const conditions = {};
    if (group.rule_id)  conditions.rule_id = String(group.rule_id);
    if (group.src_ip)   conditions.source_ip = String(group.src_ip);
    const idemKey = generateIdempotencyKey();
    setShowBulkMuteModal(false);
    setBulkActionInFlight({ action: 'mute', signature_key: group.signature_key, idempotency_key: idemKey, count: alertIds.length });
    try {
      const data = await pallasPost('/api/narrative/incident/bulk-mute', {
        alert_ids:       alertIds,
        conditions,
        classification:  bulkMuteClassification,
        analyst_name:    getCurrentAnalystName(),
        idempotency_key: idemKey,
        reason:          `Bulk muted ${alertIds.length} alerts: ${bulkMuteClassification}`,
      });
      if (data && data.results) {
        setIncidents(prev => ({ ...prev, ...data.results }));
      }
      setSelectedGroups(prev => {
        const next = new Set(prev);
        next.delete(group.signature_key);
        return next;
      });
    } catch (err) {
      setActionError(prev => ({ ...prev, [`bulk-mute:${group.signature_key}`]: err.message }));
    } finally {
      setBulkActionInFlight(null);
      setBulkMuteGroup(null);
    }
  }, [bulkMuteGroup, bulkMuteClassification]);

  const openBulkCloseModal = useCallback((group) => {
    if (!group || bulkActionInFlight) return;
    setBulkMuteGroup(group);  // Reuse — the close modal also needs a group ref
    setBulkCloseDispo('resolved');
    setBulkCloseNotes('');
    setShowBulkCloseModal(true);
  }, [bulkActionInFlight]);

  const executeBulkClose = useCallback(async () => {
    const group = bulkMuteGroup;  // shared ref
    if (!group) return;
    const alertIds = groupAlertIds(group);
    if (!alertIds.length) return;
    if (bulkCloseDispo === 'other' && !bulkCloseNotes.trim()) return;
    const idemKey = generateIdempotencyKey();
    setShowBulkCloseModal(false);
    setBulkActionInFlight({ action: 'close', signature_key: group.signature_key, idempotency_key: idemKey, count: alertIds.length });
    try {
      const data = await pallasPost('/api/narrative/incident/bulk-close', {
        alert_ids:       alertIds,
        disposition:     bulkCloseDispo,
        notes:           bulkCloseNotes,
        analyst_name:    getCurrentAnalystName(),
        idempotency_key: idemKey,
      });
      if (data && data.results) {
        // Each result has status:'closed' + closed_at + mttr — merge
        setIncidents(prev => {
          const next = { ...prev };
          for (const [aid, rec] of Object.entries(data.results)) {
            next[aid] = { ...(next[aid] || {}), ...rec };
          }
          return next;
        });
      }
      setSelectedGroups(prev => {
        const next = new Set(prev);
        next.delete(group.signature_key);
        return next;
      });
    } catch (err) {
      setActionError(prev => ({ ...prev, [`bulk-close:${group.signature_key}`]: err.message }));
    } finally {
      setBulkActionInFlight(null);
      setBulkMuteGroup(null);
    }
  }, [bulkMuteGroup, bulkCloseDispo, bulkCloseNotes]);

  const toggleGroupSelection = useCallback((sigKey) => {
    setSelectedGroups(prev => {
      const next = new Set(prev);
      if (next.has(sigKey)) next.delete(sigKey);
      else next.add(sigKey);
      return next;
    });
  }, []);

  const clearGroupSelection = useCallback(() => {
    setSelectedGroups(new Set());
  }, []);

  // ── Observable enrichment ───────────────────────────────────────────────

  const handleEnrichObservable = useCallback(async (obs, alertId) => {
    const key = `${obs.type}:${obs.value}`;
    if (enrichments[key]) return; // Already enriched
    setEnrichingObs(key);
    try {
      // Backend expects {indicator, indicator_type} per server.py:enrich_observable
      // (frontend used to send {observable, type} which the backend rejected
      // with "Missing 'indicator' (or 'ip') parameter").
      const data = await pallasPost('/api/narrative/enrich-observable', {
        indicator: obs.value,
        indicator_type: obs.type,
        alert_id: alertId,
      });
      if (data) {
        setEnrichments(prev => ({ ...prev, [key]: data }));
        // Update incident observability if public IP with hostile verdict
        if (obs.isPublic && (data.verdict === 'malicious' || data.verdict === 'suspicious') && incidents[alertId]) {
          pallasPost('/api/narrative/incident/update-observability', {
            alert_id: alertId, incident_id: incidents[alertId]?.incident_id || '',
            verdict: data.verdict,
          }).then(d => {
            if (d) setIncidents(prev => ({ ...prev, [alertId]: { ...prev[alertId], ...d } }));
          }).catch(() => {});
        }
      }
    } catch (err) {
      setEnrichments(prev => ({ ...prev, [key]: { error: err.message } }));
    } finally {
      setEnrichingObs(null);
    }
  }, [enrichments, incidents]);

  // ── Generate narrative ───────────────────────────────────────────────────

  const generateNarrative = useCallback(async (alert) => {
    if (generatingAlertId) return;
    setGeneratingAlertId(alert.id);
    setExpandedAlertId(alert.id);
    setNarrativeViewed(prev => ({ ...prev, [alert.id]: true }));
    // Clear any previous error so the retry button doesn't show during a fresh attempt.
    setNarratives((prev) => {
      const next = { ...prev };
      // If the previous "value" was an error string, drop it; preserve real narratives.
      if (typeof next[alert.id] === 'string' && next[alert.id].startsWith('Error:')) {
        delete next[alert.id];
      }
      return next;
    });

    try {
      // Backend LLM call can take 30-180s; explicit 200s client timeout matches
      // backend ceiling + buffer instead of relying on browser default (~30-90s)
      // which would fire prematurely while the backend is still working.
      const data = await pallasPost('/api/narrative/enhance', alert, { timeoutMs: 200000 });
      const fullText = data.narrative || 'No narrative returned.';

      // Cached responses skip the typewriter — analyst already saw it animate
      // the first time, no point making them watch again.
      if (data.cached) {
        setNarratives((prev) => ({ ...prev, [alert.id]: fullText }));
        return;
      }

      let index = 0;
      if (typewriterRef.current[alert.id]) clearInterval(typewriterRef.current[alert.id]);

      typewriterRef.current[alert.id] = setInterval(() => {
        index += 3;
        if (index >= fullText.length) {
          clearInterval(typewriterRef.current[alert.id]);
          delete typewriterRef.current[alert.id];
          setTypewriterText((prev) => { const next = { ...prev }; delete next[alert.id]; return next; });
          setNarratives((prev) => ({ ...prev, [alert.id]: fullText }));
        } else {
          setTypewriterText((prev) => ({ ...prev, [alert.id]: fullText.slice(0, index) }));
        }
      }, 12);
    } catch (err) {
      // Map raw errors to user-friendly messages. The state value still starts
      // with "Error:" so the existing error-rendering path picks it up — the
      // text after "Error:" is what the analyst sees.
      let userMsg;
      if (err?.name === 'AbortError') {
        userMsg = 'Generation timed out. Click "Generate AI Narrative" to retry.';
      } else if ((err?.message || '').startsWith('Session expired')) {
        userMsg = err.message;
      } else if (/HTTP 5\d\d/.test(err?.message || '')) {
        userMsg = 'Pallas LLM service error — try again in a moment.';
      } else {
        userMsg = err?.message || 'Unknown error';
      }
      setNarratives((prev) => ({ ...prev, [alert.id]: `Error: ${userMsg}` }));
    } finally {
      setGeneratingAlertId(null);
    }
  }, [generatingAlertId]);

  // Bind the ref used by handleAcknowledge so it can fire generateNarrative
  // without a forward-declaration TDZ error.
  useEffect(() => {
    generateNarrativeRef.current = generateNarrative;
  }, [generateNarrative]);

  // ── Time range change ──────────────────────────────────────────────────
  // Updating the URL triggers the filters-change useEffect which calls
  // fetchAlerts. Local UI state (narratives, typewriter, expanded card) is
  // cleared here since the fetched alert list will be entirely different.

  const handleTimeRangeChange = (range) => {
    setNarratives({});
    setTypewriterText({});
    setExpandedAlertId(null);
    Object.values(typewriterRef.current).forEach(clearInterval);
    typewriterRef.current = {};
    updateFilter({ time_range: range });
  };

  const toggleNarrative = (alertId) => {
    setExpandedAlertId((prev) => (prev === alertId ? null : alertId));
  };

  // ── Pin / Unpin / Export ──────────────────────────────────────────────

  const pinNarrative = useCallback((alert) => {
    const text = narratives[alert.id];
    if (!text) return;
    setPinnedNarratives((prev) => {
      if (prev.length >= 5) return prev;
      if (prev.some((p) => p.alertId === alert.id)) return prev;
      const description = alert.rule?.description || alert.description || alert.alert_msg || 'Alert';
      return [...prev, { alertId: alert.id, description, narrative: text, timestamp: new Date() }];
    });
  }, [narratives]);

  const unpinNarrative = useCallback((index) => {
    setPinnedNarratives((prev) => prev.filter((_, i) => i !== index));
  }, []);

  const exportPinnedNarratives = useCallback(() => {
    if (!pinnedNarratives.length) return;
    const md = pinnedNarratives.map((p, i) => {
      const ts = p.timestamp ? new Date(p.timestamp).toLocaleString() : 'N/A';
      return `## Narrative ${i + 1}: ${p.description} (${ts})\n\n${p.narrative}\n`;
    }).join('\n---\n\n');
    const blob = new Blob([md], { type: 'text/markdown' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `pallas-narratives-${Date.now()}.md`;
    a.click();
    URL.revokeObjectURL(url);
  }, [pinnedNarratives]);

  // ── Render helpers ───────────────────────────────────────────────────────

  const renderSeverityBadge = (level, severity) => {
    const sev = severity || normalizeSeverity(level);
    const colors = SEVERITY_COLORS[sev] || SEVERITY_COLORS.low;
    return (
      <PillBadge
        label={sev}
        color={colors.text}
        bg={colors.bg}
        border={colors.border}
        style={{ textTransform: 'uppercase', letterSpacing: 0.5 }}
      />
    );
  };

  const renderSourceBadge = (source) => {
    const key = (source || '').toLowerCase();
    const colors = SOURCE_COLORS[key] || SOURCE_COLORS.wazuh;
    return (
      <PillBadge
        label={source || 'Unknown'}
        color={colors.text}
        bg={colors.bg}
        border={colors.border}
        style={{ textTransform: 'uppercase', letterSpacing: 0.5 }}
      />
    );
  };

  const renderMitreBadges = (alert) => {
    if ((alert.source || '').toLowerCase() !== 'wazuh') return null;
    const tactics = alert.mitre_tactics || alert.rule?.mitre?.tactic || [];
    const techniques = alert.mitre_techniques || alert.rule?.mitre?.technique || [];
    if (!tactics.length && !techniques.length) return null;

    return (
      <div style={{ display: 'flex', flexWrap: 'wrap', gap: 4, marginTop: 6 }}>
        {(Array.isArray(tactics) ? tactics : [tactics]).map((t, i) => (
          <PillBadge key={`tac-${i}`} label={t} color={THEME.accent} bg="rgba(22,197,192,0.12)" border="rgba(22,197,192,0.25)" />
        ))}
        {(Array.isArray(techniques) ? techniques : [techniques]).map((t, i) => (
          <PillBadge key={`tech-${i}`} label={t} color={THEME.textMuted} bg="rgba(255,255,255,0.04)" border={THEME.border} />
        ))}
      </div>
    );
  };

  const renderNarrativeButton = (alert) => {
    const isGenerating = generatingAlertId === alert.id;
    const hasNarrative = !!narratives[alert.id];
    const isExpanded = expandedAlertId === alert.id;
    const isTyping = !!typewriterText[alert.id];

    if (isGenerating || isTyping) {
      return (
        <button disabled style={{
          display: 'inline-flex', alignItems: 'center', gap: 6, padding: '5px 12px',
          borderRadius: 6, border: `1px solid ${ACCENT}`, background: 'transparent',
          color: ACCENT, fontSize: 12, fontWeight: 600, cursor: 'wait',
        }}>
          <span style={{
            display: 'inline-block', width: 12, height: 12,
            border: '2px solid rgba(255,255,255,0.3)', borderTopColor: ACCENT,
            borderRadius: '50%', animation: 'pallas-spin 0.6s linear infinite',
          }} />
          Generating...
        </button>
      );
    }

    if (hasNarrative) {
      const isPinned = pinnedNarratives.some((p) => p.alertId === alert.id);
      return (
        <div style={{ display: 'inline-flex', alignItems: 'center', gap: 8 }}>
          <button
            onClick={() => toggleNarrative(alert.id)}
            style={{
              display: 'inline-flex', alignItems: 'center', gap: 6, padding: '5px 12px',
              borderRadius: 6, border: `1px solid ${ACCENT}44`, background: `${ACCENT}1A`,
              color: ACCENT, fontSize: 12, fontWeight: 600, cursor: 'pointer',
            }}
          >
            <EuiIcon type="check" size="s" color={ACCENT} />
            {isExpanded ? 'Hide Narrative' : 'Show Narrative'}
          </button>
          <button
            onClick={() => pinNarrative(alert)}
            disabled={isPinned || pinnedNarratives.length >= 5}
            style={{
              display: 'inline-flex', alignItems: 'center', gap: 5, padding: '5px 10px',
              borderRadius: 6, border: `1px solid ${isPinned ? ACCENT : THEME.border}`,
              background: isPinned ? `${ACCENT}1A` : 'transparent',
              color: isPinned ? ACCENT : THEME.textSecondary, fontSize: 11, fontWeight: 600,
              cursor: isPinned ? 'default' : 'pointer', opacity: isPinned ? 0.7 : 1,
            }}
          >
            <EuiIcon type={isPinned ? 'check' : 'pinFilled'} size="s" />
            {isPinned ? 'Pinned' : 'Pin'}
          </button>
          <PillBadge label="AI ENHANCED" color={ACCENT} bg={`${ACCENT}26`} style={{ fontSize: 10, letterSpacing: 0.8 }} />
        </div>
      );
    }

    return (
      <button
        onClick={() => generateNarrative(alert)}
        disabled={!!generatingAlertId}
        style={{
          display: 'inline-flex', alignItems: 'center', gap: 6, padding: '5px 12px',
          borderRadius: 6, border: `1px solid ${ACCENT}`, background: 'transparent',
          color: ACCENT, fontSize: 12, fontWeight: 600,
          cursor: generatingAlertId ? 'not-allowed' : 'pointer',
          opacity: generatingAlertId ? 0.5 : 1,
        }}
      >
        <EuiIcon type="sparkles" size="s" color={ACCENT} /> AI Narrative
      </button>
    );
  };

  const renderNarrativePanel = (alert) => {
    const isExpanded = expandedAlertId === alert.id;
    const isTyping = !!typewriterText[alert.id];
    const text = isTyping ? typewriterText[alert.id] : narratives[alert.id];
    if (!isExpanded && !isTyping) return null;
    if (!text) return null;

    // Error state: narrative text starts with "Error:" — render a friendly
    // panel with a Retry button instead of the regular narrative styling.
    // Session-expired errors don't get a retry button; the analyst has to
    // refresh the page to get a new JWT.
    const isError = typeof text === 'string' && text.startsWith('Error:');
    const errorMsg = isError ? text.slice('Error:'.length).trim() : null;
    const isSessionExpired = isError && errorMsg.toLowerCase().includes('session expired');
    const canRetry = isError && !isSessionExpired && !generatingAlertId;

    if (isError) {
      return (
        <div style={{
          marginTop: 10, padding: 14, borderRadius: 6,
          background: 'rgba(220, 38, 38, 0.06)',
          border: '1px solid rgba(220, 38, 38, 0.4)',
        }}>
          <div style={{ display: 'flex', alignItems: 'flex-start', gap: 10 }}>
            <div style={{
              flexShrink: 0, width: 22, height: 22, borderRadius: '50%',
              background: 'rgba(220, 38, 38, 0.2)', color: '#FCA5A5',
              display: 'flex', alignItems: 'center', justifyContent: 'center',
              fontSize: 13, fontWeight: 700,
            }}>!</div>
            <div style={{ flex: 1, minWidth: 0 }}>
              <div style={{ fontSize: 12, fontWeight: 600, color: '#FCA5A5', marginBottom: 4 }}>
                Narrative generation failed
              </div>
              <div style={{ fontSize: 13, color: THEME.textSecondary, lineHeight: 1.5 }}>
                {errorMsg}
              </div>
              {canRetry && (
                <button
                  onClick={() => generateNarrative(alert)}
                  style={{
                    marginTop: 10, padding: '5px 14px', fontSize: 12, fontWeight: 600,
                    background: 'rgba(22, 197, 192, 0.15)', color: ACCENT,
                    border: `1px solid ${ACCENT}`, borderRadius: 4,
                    cursor: 'pointer',
                  }}
                >
                  Retry
                </button>
              )}
            </div>
          </div>
        </div>
      );
    }

    // Markdown line/inline renderer ported from plugin attack-narrative.tsx
    // (renderNarrative + renderInlineFormatting, lines 781-911). Supports:
    //   ## H3 / # H2, bullet (-/*), numbered (1.), inline **bold**, `code`.
    // The typing caret continues to render on the last visible line during
    // generation so the streaming UX is preserved.
    const renderInlineFormatting = (line) => {
      const parts = [];
      let remaining = line;
      let keyIdx = 0;
      while (remaining.length > 0) {
        const boldMatch = remaining.match(/\*\*(.+?)\*\*/);
        const codeMatch = remaining.match(/`(.+?)`/);
        const firstMatch = [boldMatch, codeMatch]
          .filter(Boolean)
          .sort((a, b) => (a.index ?? Infinity) - (b.index ?? Infinity))[0];
        if (!firstMatch || firstMatch.index === undefined) {
          parts.push(remaining);
          break;
        }
        if (firstMatch.index > 0) parts.push(remaining.slice(0, firstMatch.index));
        if (firstMatch === boldMatch) {
          parts.push(
            <strong key={`b${keyIdx++}`} style={{ fontWeight: 700, color: THEME.text }}>
              {firstMatch[1]}
            </strong>
          );
        } else {
          parts.push(
            <code key={`c${keyIdx++}`} style={{
              padding: '1px 5px', borderRadius: 3,
              backgroundColor: 'rgba(255,255,255,0.08)',
              fontFamily: FONT.mono, fontSize: '11.5px', color: ACCENT,
            }}>
              {firstMatch[1]}
            </code>
          );
        }
        remaining = remaining.slice(firstMatch.index + firstMatch[0].length);
      }
      return parts.length === 0 ? line : <>{parts}</>;
    };

    const lines = text.split('\n');
    const lastNonEmptyIdx = (() => {
      for (let i = lines.length - 1; i >= 0; i--) {
        if (lines[i].trim()) return i;
      }
      return lines.length - 1;
    })();

    const renderCaret = (i) => (
      isTyping && i === lastNonEmptyIdx ? (
        <span style={{
          display: 'inline-block', width: 2, height: 14, marginLeft: 2,
          background: ACCENT, verticalAlign: 'text-bottom',
          animation: 'pallas-pulse 0.8s ease-in-out infinite',
        }} />
      ) : null
    );

    return (
      <div style={{
        marginTop: 10, padding: 14, borderRadius: 6,
        background: THEME.bgDeep, border: `1px solid ${ACCENT}33`,
      }}>
        {lines.map((line, i) => {
          const trimmed = line.trim();
          if (trimmed.startsWith('## ')) {
            return (
              <h3 key={i} style={{
                margin: i === 0 ? '0 0 8px' : '16px 0 8px',
                fontSize: 14, fontWeight: 700, color: ACCENT,
                letterSpacing: '0.3px',
              }}>
                {trimmed.replace(/^##\s+/, '')}
                {renderCaret(i)}
              </h3>
            );
          }
          if (trimmed.startsWith('# ')) {
            return (
              <h2 key={i} style={{
                margin: i === 0 ? '0 0 8px' : '16px 0 8px',
                fontSize: 15, fontWeight: 700, color: THEME.text,
              }}>
                {trimmed.replace(/^#\s+/, '')}
                {renderCaret(i)}
              </h2>
            );
          }
          if (trimmed.startsWith('- ') || trimmed.startsWith('* ')) {
            return (
              <div key={i} style={{
                margin: '3px 0', paddingLeft: 14, position: 'relative',
                fontSize: 13, lineHeight: 1.6, color: THEME.textSecondary,
              }}>
                <span style={{
                  position: 'absolute', left: 0, color: ACCENT, fontWeight: 700,
                }}>{'•'}</span>
                {renderInlineFormatting(trimmed.replace(/^[-*]\s+/, ''))}
                {renderCaret(i)}
              </div>
            );
          }
          const numMatch = trimmed.match(/^(\d+)\.\s/);
          if (numMatch) {
            return (
              <div key={i} style={{
                margin: '3px 0', paddingLeft: 20, position: 'relative',
                fontSize: 13, lineHeight: 1.6, color: THEME.textSecondary,
              }}>
                <span style={{
                  position: 'absolute', left: 0, color: ACCENT, fontWeight: 700, fontSize: 12,
                }}>{numMatch[1]}.</span>
                {renderInlineFormatting(trimmed.replace(/^\d+\.\s+/, ''))}
                {renderCaret(i)}
              </div>
            );
          }
          if (!trimmed) {
            return <div key={i} style={{ height: 8 }} />;
          }
          return (
            <p key={i} style={{
              margin: '4px 0', fontSize: 13, lineHeight: 1.65, color: THEME.textSecondary,
            }}>
              {renderInlineFormatting(trimmed)}
              {renderCaret(i)}
            </p>
          );
        })}
      </div>
    );
  };

  // ── Alert card ─────────────────────────────────────────────────────────

  const renderAlertCard = (alert, idx = 0) => {
    const isGenerating = generatingAlertId === alert.id;
    const source = (alert.source || '').toLowerCase();
    // Suricata: signature + signature_id. Wazuh: rule.description
    const sigId = alert.rule_id || alert.signature_id || alert.alert?.signature_id || '';
    const sigName = alert.rule_description || alert.signature || alert.alert?.signature || alert.rule?.description || alert.description || alert.alert_msg || '';
    const description = sigId && sigName ? `SID ${sigId} — ${sigName}` : sigName || 'No description';
    const sev = alert.severity || normalizeSeverity(alert.level);
    const sevColor = SEVERITY_COLORS[sev] || SEVERITY_COLORS.low;
    const inc = incidents[alert.id] || {};
    const status = inc.status || 'open';
    const stStyle = STATUS_STYLES[status] || STATUS_STYLES.open;
    const isAcked = ['acknowledged', 'in_progress', 'closed', 'false_positive'].includes(status);
    const isClosed = status === 'closed' || status === 'false_positive';
    const hasJira = !!inc.jira_ticket_id;
    const observables = extractObservables(alert, narratives[alert.id]);
    const canBlock = isAcked && hasJira && inc.observability_completed;

    // Derived state from Agelia (annotated by the alert fetch handler).
    // Reflect current Agelia truth on every alert in the list, regardless of
    // whether this particular alert was the one acted on.
    const ageliaMuted = !!alert._agelia_muted;
    const ageliaMuteClass = alert._agelia_mute_classification;
    const wafBlockedDerived = !!alert._waf_blocked;

    // All alert metadata (Level, Agent, IPs, decoder, MITRE, observables) is
    // shown by default — no expand/collapse needed for SOC review.

    return (
      <div
        key={alert.id}
        onMouseEnter={(e) => { e.currentTarget.style.background = 'rgba(255,255,255,0.04)'; }}
        onMouseLeave={(e) => { e.currentTarget.style.background = ageliaMuted ? 'rgba(255,255,255,0.01)' : 'rgba(255,255,255,0.02)'; }}
        style={{
          padding: 0, borderRadius: 10,
          background: ageliaMuted ? 'rgba(255,255,255,0.01)' : 'rgba(255,255,255,0.02)',
          border: `1px solid ${isGenerating ? ACCENT : THEME.border}`,
          borderLeft: `4px solid ${sevColor.text}`,
          boxShadow: isGenerating ? `0 0 16px ${ACCENT}33` : 'none',
          transition: 'border-color 0.3s ease, background 0.15s ease, box-shadow 0.3s ease',
          position: 'relative',
          zIndex: showAssignDropdown === alert.id ? 100 : 1,
          opacity: ageliaMuted ? 0.7 : 1,
          // Staggered fade-in: each row enters 30ms after the previous, capped
          // so a 25-page render doesn't take forever to settle.
          animation: 'pallas-fadeIn 0.3s ease backwards',
          animationDelay: `${Math.min(idx * 30, 600)}ms`,
        }}
      >
        {/* ── Status banner ── */}
        {status !== 'open' && (
          <div style={{
            display: 'flex', alignItems: 'center', gap: 8, flexWrap: 'wrap',
            padding: '6px 14px', background: stStyle.bg, borderBottom: `1px solid ${stStyle.text}25`,
            fontSize: 11,
          }}>
            <span style={{ fontWeight: 700, color: stStyle.text, letterSpacing: '0.04em' }}>{stStyle.label}</span>
            {inc.acknowledged_by && (
              <span style={{ color: THEME.textMuted }}>by {inc.acknowledged_by} · {formatTimeAgo(inc.acknowledged_at)}</span>
            )}
            {inc.mttd_seconds && <span style={{ color: THEME.textMuted }}>MTTD: {formatDuration(inc.mttd_seconds)}</span>}
            {inc.jira_ticket_id && (
              <a href={inc.jira_ticket_url || '#'} target="_blank" rel="noopener noreferrer"
                style={{ color: '#3B82F6', fontWeight: 600, textDecoration: 'none' }}>
                {inc.jira_ticket_id}
              </a>
            )}
            {inc.waf_blocked && <span style={{ color: '#22C55E', fontWeight: 600 }}>WAF: Blocked</span>}
            {inc.firewall_blocked && <span style={{ color: '#22C55E', fontWeight: 600 }}>FW: Blocked</span>}
            {inc.mttr_seconds && <span style={{ color: '#22C55E' }}>MTTR: {formatDuration(inc.mttr_seconds)}</span>}
          </div>
        )}

        <div style={{ padding: 14 }}>
          {/* Row 1: Severity + Source + Description + Timestamp */}
          <div style={{ display: 'flex', alignItems: 'center', gap: 8, flexWrap: 'wrap' }}>
            {renderSeverityBadge(alert.level, alert.severity)}
            {renderSourceBadge(alert.source)}
            <span style={{
              flex: 1, fontSize: 13, fontWeight: 500, color: THEME.text,
              overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap', minWidth: 0,
            }} title={description}>
              {description}
            </span>
            {/* Mute badge — derived from Agelia (refreshes on alert fetch) */}
            {ageliaMuted && (
              <span
                title={`Muted in Agelia${ageliaMuteClass ? ` (${ageliaMuteClass})` : ''}`}
                style={{
                  padding: '2px 8px', fontSize: 10, fontWeight: 600,
                  borderRadius: 4, background: '#374151', color: '#9CA3AF',
                  letterSpacing: '0.04em',
                }}
              >
                Muted
              </span>
            )}
            {/* Block badge — derived from Agelia */}
            {wafBlockedDerived && (
              <span
                title="Source IP currently blocked at AWS perimeter"
                style={{
                  padding: '2px 8px', fontSize: 10, fontWeight: 600,
                  borderRadius: 4, background: '#7F1D1D', color: '#FECACA',
                  letterSpacing: '0.04em',
                }}
              >
                IP Blocked
              </span>
            )}
            <span style={{ fontSize: 11, color: THEME.textMuted, whiteSpace: 'nowrap', flexShrink: 0 }}>
              {formatTimestamp(alert.timestamp)}
            </span>
          </div>

          {/* Row 2: Level + Agent/IPs + Category — always visible for SOC review. */}
          <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginTop: 8, fontSize: 12, color: THEME.textSecondary, flexWrap: 'wrap' }}>
            <span>
              <span style={{ color: THEME.textMuted }}>Level:</span>{' '}
              <span style={{ fontWeight: 600 }}>{alert.level ?? '\u2014'}</span>
            </span>
            {source === 'wazuh' && alert.agent?.name && (
              <span>
                <span style={{ color: THEME.textMuted }}>Agent:</span>{' '}
                <span style={{ fontWeight: 500 }}>{alert.agent.name} ({alert.agent.id})</span>
              </span>
            )}
            {(alert.src_ip || alert.source_ip) && (
              <span style={{ fontFamily: FONT.mono, fontSize: 11 }}>
                {alert.src_ip || alert.source_ip}{alert.src_port ? `:${alert.src_port}` : ''}
                {' \u2192 '}
                {alert.dest_ip || alert.destination_ip || '\u2014'}{alert.dest_port ? `:${alert.dest_port}` : ''}
              </span>
            )}
            {alert.protocol && <PillBadge label={alert.protocol} color={THEME.textMuted} bg="rgba(255,255,255,0.05)" />}
            {(alert.category || alert.rule?.groups?.[0]) && (
              <span style={{ color: THEME.textMuted }}>{alert.category || alert.rule?.groups?.[0]}</span>
            )}
          </div>

          {/* Row 3: HTTP enrichment (Suricata) / Wazuh metadata — always visible. */}
          {source === 'suricata' && (alert.http_xff || alert.http_hostname || alert.http_url) && (
            <div style={{ marginTop: 6, fontSize: 11, color: THEME.textMuted, fontFamily: FONT.mono, display: 'flex', gap: 10, flexWrap: 'wrap' }}>
              {alert.http_xff && <span>XFF: <span style={{ color: '#F97316' }}>{alert.http_xff}</span></span>}
              {alert.http_hostname && <span>Host: <span style={{ color: THEME.textSecondary }}>{alert.http_hostname}</span></span>}
              {alert.http_method && alert.http_url && (
                <span style={{ maxWidth: 400, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                  {alert.http_method} {alert.http_url}
                </span>
              )}
              {alert.http_user_agent && (
                <span style={{ fontSize: 10, maxWidth: 300, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                  UA: {alert.http_user_agent}
                </span>
              )}
            </div>
          )}
          {source === 'wazuh' && (alert.decoder_name || alert.location) && (
            <div style={{ marginTop: 6, fontSize: 11, color: THEME.textMuted, display: 'flex', gap: 10, flexWrap: 'wrap' }}>
              {alert.decoder_name && <span>Decoder: <span style={{ fontFamily: FONT.mono }}>{alert.decoder_name}</span></span>}
              {alert.location && <span style={{ fontFamily: FONT.mono, fontSize: 10 }}>{alert.location}</span>}
              {alert.firedtimes > 1 && <span>Fired {alert.firedtimes}x</span>}
            </div>
          )}

          {/* MITRE badges — always visible */}
          {renderMitreBadges(alert)}

          {/* AI Narrative button — always visible (primary investigation entry
              point). Clicking expands the narrative panel via expandedAlertId. */}
          <div style={{ marginTop: 10 }}>{renderNarrativeButton(alert)}</div>

          {/* Narrative panel — gated by its own expandedAlertId state */}
          {renderNarrativePanel(alert)}

          {/* ── Observables ── (visible once narrative is loaded or alert is acked) */}
          {observables.length > 0 && (narratives[alert.id] || isAcked) && (
            <div style={{ marginTop: 10, display: 'flex', alignItems: 'center', gap: 6, flexWrap: 'wrap' }}>
              <span style={{ fontSize: 10, fontWeight: 700, color: THEME.textMuted, textTransform: 'uppercase', letterSpacing: '0.04em' }}>
                Observables
              </span>
              {observables.map((obs) => {
                const key = `${obs.type}:${obs.value}`;
                const enr = enrichments[key];
                const vColor = enr?.verdict ? (VERDICT_COLORS[enr.verdict] || VERDICT_COLORS.clean) : null;
                const isEnriching = enrichingObs === key;
                return (
                  <button key={key} onClick={() => handleEnrichObservable(obs, alert.id)}
                    disabled={isEnriching}
                    style={{
                      display: 'inline-flex', alignItems: 'center', gap: 4,
                      padding: '2px 8px', borderRadius: 4, fontSize: 11, fontFamily: FONT.mono,
                      background: vColor ? vColor.bg : 'rgba(255,255,255,0.04)',
                      border: `1px solid ${vColor ? vColor.text + '40' : THEME.border}`,
                      color: vColor ? vColor.text : THEME.textSecondary,
                      cursor: isEnriching ? 'wait' : 'pointer', outline: 'none',
                    }}
                    title={enr?.error || (enr ? `${enr.verdict} · Score: ${enr.risk_score}` : 'Click to enrich')}
                  >
                    <EuiIcon type={obs.type === 'ip' ? 'globe' : obs.type === 'domain' ? 'link' : 'document'} size="s" />
                    {obs.value.length > 20 ? obs.value.slice(0, 18) + '...' : obs.value}
                    {!obs.isPublic && obs.type === 'ip' && <span style={{ fontSize: 9, opacity: 0.6 }}>RFC1918</span>}
                    {enr?.verdict && <span style={{ fontSize: 9, fontWeight: 700 }}>{enr.verdict.toUpperCase()}</span>}
                  </button>
                );
              })}
            </div>
          )}

          {/* ── SOC Workflow Action Bar ──
              Action set is intentionally UNIFORM across Wazuh and Suricata.
              Source-specific differentiation lives at the data layer, not the
              UI layer:
                • Block: gates on (a) public-IP candidate AND (b) backend
                  observability verdict ∈ {malicious, suspicious}. Wazuh
                  FIM/SCA/rootcheck alerts have no public IP → button hidden
                  by the candidate check.
                • Display: agent/decoder fields render for Wazuh, http_xff/
                  http_url for Suricata (existing renderers at lines ~1622,
                  ~1642, ~1658).
                • Mute conditions modal (out this release, HIDE_MUTE=true)
                  branches on isSuricata at line ~916.
              Flow: AI Narrative → Acknowledge → Create Ticket → (Assign) →
              Enrich → [Block | Dismiss FP] → Close. */}
          <div style={{ marginTop: 10, display: 'flex', alignItems: 'center', gap: 6, flexWrap: 'wrap' }}>
            {/* ── Completed action badges + active buttons (matches plugin flow) ── */}

            {/* ACK'd badge (completed) */}
            {isAcked && (
              <span style={{ padding: '3px 10px', borderRadius: 4, fontSize: 10, fontWeight: 700,
                background: 'rgba(6,182,212,0.15)', color: '#06B6D4', border: '1px solid rgba(6,182,212,0.3)',
                display: 'inline-flex', alignItems: 'center', gap: 4 }}>
                <EuiIcon type="check" size="s" /> ACK'd
              </span>
            )}

            {/* Acknowledge button (not yet ack'd). Gated behind AI narrative
                being loaded so the analyst always reviews the LLM analysis
                before triaging. Click [AI Narrative] first, then Acknowledge
                becomes enabled. Mute is the noise-dismissal path that does
                not require a narrative review. */}
            {!isAcked && (() => {
              const narrativeReady = !!narratives[alert.id] && typeof narratives[alert.id] === 'string' && !narratives[alert.id].startsWith('Error:');
              const ackInFlight = !!actionLoading[`ack:${alert.id}`];
              const ackDisabled = ackInFlight || !narrativeReady;
              return (
                <button onClick={() => handleAcknowledge(alert)}
                  disabled={ackDisabled}
                  title={narrativeReady
                    ? 'Acknowledge alert'
                    : 'Click "AI Narrative" first to load the analysis, then acknowledge'}
                  style={{
                    padding: '4px 12px', borderRadius: 5, fontSize: 11, fontWeight: 600,
                    border: `1px solid #06B6D4`, background: 'transparent',
                    color: '#06B6D4',
                    cursor: ackDisabled ? 'not-allowed' : 'pointer',
                    opacity: ackDisabled ? 0.45 : 1,
                    display: 'flex', alignItems: 'center', gap: 4, outline: 'none',
                  }}>
                  <EuiIcon type="check" size="s" />
                  {ackInFlight ? 'Acknowledging...' : (narrativeReady ? 'Acknowledge' : 'Acknowledge (review narrative first)')}
                </button>
              );
            })()}

            {/* JIRA ticket badge (completed) */}
            {hasJira && (
              <a href={inc.jira_ticket_url || '#'} target="_blank" rel="noopener noreferrer"
                style={{ padding: '3px 10px', borderRadius: 4, fontSize: 10, fontWeight: 700,
                  background: 'rgba(59,130,246,0.15)', color: '#3B82F6', border: '1px solid rgba(59,130,246,0.3)',
                  display: 'inline-flex', alignItems: 'center', gap: 4, textDecoration: 'none' }}>
                <EuiIcon type="check" size="s" /> {inc.jira_ticket_id}
              </a>
            )}

            {/* Create Ticket button — hidden entirely when Jira not configured for the tenant */}
            {isAcked && !hasJira && !isClosed && integrationStatus.jira && (
              <button onClick={() => handleCreateTicket(alert)}
                disabled={actionLoading[`jira:${alert.id}`]}
                title="Create JIRA ticket"
                style={{
                  padding: '4px 12px', borderRadius: 5, fontSize: 11, fontWeight: 600,
                  border: `1px solid #3B82F6`, background: 'transparent', color: '#3B82F6',
                  cursor: 'pointer',
                  display: 'flex', alignItems: 'center', gap: 4, outline: 'none',
                }}>
                <EuiIcon type="document" size="s" />
                {actionLoading[`jira:${alert.id}`] ? 'Creating...' : 'Create Ticket'}
              </button>
            )}

            {/* False Positive — completion badge OR dismissal dropdown.
                This release: Mute modal is HIDE_MUTE'd (Agelia API not in
                scope), so FP dismissals route through the dedicated
                /api/narrative/incident/dismiss-fp endpoint and the dropdown
                below. When Agelia returns, add a "Mute this signature" row
                inside this same dropdown (mirror plugin
                attack-narrative.tsx:2015-2028) so FP + Mute are sibling
                options in one menu — analyst's mental model: "is this real
                or not, and if not, how do we make it stop". */}
            {status === 'false_positive' ? (
              <span style={{ padding: '3px 10px', borderRadius: 4, fontSize: 10, fontWeight: 700,
                background: 'rgba(245,158,11,0.15)', color: '#F59E0B', border: '1px solid rgba(245,158,11,0.3)',
                display: 'inline-flex', alignItems: 'center', gap: 4 }}>
                <EuiIcon type="cross" size="s" /> {inc.fp_reason || 'False Positive'}
              </span>
            ) : hasJira && !isClosed && integrationStatus.jira ? (
              <>
                <button
                  ref={(el) => { if (el) fpButtonRefs.current[alert.id] = el; }}
                  onClick={() => setShowFPDropdown(showFPDropdown === alert.id ? null : alert.id)}
                  disabled={actionLoading[`fp:${alert.id}`]}
                  title="Mark this alert as a false positive"
                  style={{
                    padding: '4px 12px', borderRadius: 5, fontSize: 11, fontWeight: 600,
                    border: '1px solid #F59E0B',
                    background: showFPDropdown === alert.id ? 'rgba(245,158,11,0.1)' : 'transparent',
                    color: '#F59E0B', cursor: 'pointer',
                    display: 'flex', alignItems: 'center', gap: 4, outline: 'none',
                  }}>
                  <EuiIcon type="cross" size="s" />
                  {actionLoading[`fp:${alert.id}`] ? 'Dismissing...' : 'False Positive'}
                  <EuiIcon type="arrowDown" size="s" />
                </button>
                {showFPDropdown === alert.id && (
                  <AnchoredDropdown
                    anchorRef={{ current: fpButtonRefs.current[alert.id] }}
                    onClose={() => { setShowFPDropdown(null); setFPNotes(''); }}
                    accentColor="#F59E0B"
                    minWidth={280}
                  >
                    <div style={{ fontSize: 10, fontWeight: 700, color: THEME.textMuted,
                      textTransform: 'uppercase', letterSpacing: '0.05em',
                      padding: '4px 8px 6px' }}>
                      Select reason
                    </div>
                    {FP_REASONS.map(reason => (
                      <button key={reason} onClick={() => handleDismissFP(alert, reason)}
                        style={{
                          display: 'flex', alignItems: 'center', width: '100%',
                          padding: '7px 10px', borderRadius: 6, border: 'none',
                          background: 'transparent', color: THEME.text,
                          fontSize: 12, cursor: 'pointer', textAlign: 'left', outline: 'none',
                        }}
                        onMouseEnter={e => { e.currentTarget.style.background = 'rgba(245,158,11,0.1)'; }}
                        onMouseLeave={e => { e.currentTarget.style.background = 'transparent'; }}
                      >
                        {reason}
                      </button>
                    ))}
                    <div style={{ borderTop: `1px solid ${THEME.border}`, marginTop: 4, paddingTop: 6 }}>
                      <input type="text" placeholder="Other reason (press Enter to submit)"
                        value={fpNotes}
                        onChange={e => setFPNotes(e.target.value)}
                        onKeyDown={e => {
                          if (e.key === 'Enter' && fpNotes.trim()) {
                            handleDismissFP(alert, fpNotes.trim());
                          }
                        }}
                        style={{
                          width: '100%', padding: '6px 10px',
                          borderRadius: 6, border: `1px solid ${THEME.border}`,
                          background: 'transparent', color: THEME.text,
                          fontSize: 11, outline: 'none', boxSizing: 'border-box',
                        }} />
                    </div>
                  </AnchoredDropdown>
                )}
              </>
            ) : null}

            {/* Assign badge (completed) OR dropdown button */}
            {inc.assigned_to ? (
              <span style={{ padding: '3px 10px', borderRadius: 4, fontSize: 10, fontWeight: 700,
                background: 'rgba(139,92,246,0.15)', color: '#A78BFA', border: '1px solid rgba(139,92,246,0.3)',
                display: 'inline-flex', alignItems: 'center', gap: 4 }}>
                <EuiIcon type="check" size="s" /> {inc.assigned_to}
              </span>
            ) : hasJira && !isClosed && assignableUsers.length > 0 ? (
              <>
                <button
                  ref={(el) => { if (el) assignButtonRefs.current[alert.id] = el; }}
                  onClick={() => setShowAssignDropdown(showAssignDropdown === alert.id ? null : alert.id)}
                  disabled={actionLoading[`assign:${alert.id}`]}
                  style={{
                    padding: '4px 12px', borderRadius: 5, fontSize: 11, fontWeight: 600,
                    border: `1px solid #A78BFA`, background: showAssignDropdown === alert.id ? 'rgba(139,92,246,0.1)' : 'transparent',
                    color: '#A78BFA', cursor: 'pointer',
                    display: 'flex', alignItems: 'center', gap: 4, outline: 'none',
                  }}>
                  <EuiIcon type="user" size="s" /> Assign <EuiIcon type="arrowDown" size="s" />
                </button>
                {showAssignDropdown === alert.id && (
                  <AnchoredDropdown
                    anchorRef={{ current: assignButtonRefs.current[alert.id] }}
                    onClose={() => setShowAssignDropdown(null)}
                    accentColor="#A78BFA"
                    minWidth={220}
                  >
                    <div style={{ maxHeight: 240, overflowY: 'auto' }}>
                      {assignableUsers.map(user => (
                        <button key={user.accountId || user.name} onClick={() => handleAssignUser(alert, user)}
                          style={{
                            display: 'flex', alignItems: 'center', gap: 8, width: '100%', padding: '8px 12px',
                            background: 'transparent', border: 'none', color: THEME.text,
                            fontSize: 12, cursor: 'pointer', borderRadius: 6, outline: 'none',
                          }}
                          onMouseEnter={e => { e.currentTarget.style.background = 'rgba(139,92,246,0.12)'; }}
                          onMouseLeave={e => { e.currentTarget.style.background = 'transparent'; }}
                        >
                          {user.avatarUrl && <img src={user.avatarUrl} alt="" style={{ width: 20, height: 20, borderRadius: '50%' }} />}
                          <span>{user.displayName || user.name}</span>
                        </button>
                      ))}
                    </div>
                  </AnchoredDropdown>
                )}
              </>
            ) : null}

            {/* Mute — explicit pill once muted; hidden entirely if Block has already
                been applied. The rare "block + suppress noise" combo can still be
                done via Agelia's Mute Rules admin page. */}
            {/* RE-ENABLE NEXT RELEASE — Muted pill + Mute button return with Agelia */}
            {!HIDE_MUTE && isAcked && !isClosed && inc.agelia_muted && (
              <span style={{ padding: '3px 10px', borderRadius: 4, fontSize: 10, fontWeight: 700,
                background: 'rgba(251,191,36,0.15)', color: '#FBBF24', border: '1px solid rgba(251,191,36,0.3)',
                display: 'inline-flex', alignItems: 'center', gap: 4 }}>
                <EuiIcon type="bellSlash" size="s" /> Muted
              </span>
            )}
            {!HIDE_MUTE && isAcked && !isClosed && !inc.agelia_muted && !inc.waf_blocked && (
              <button onClick={() => openMuteModal(alert)}
                disabled={actionLoading[`mute:${alert.id}`]}
                title="Mute future alerts matching this signature"
                style={{
                  padding: '4px 12px', borderRadius: 5, fontSize: 11, fontWeight: 600,
                  border: '1px solid #FBBF24', background: 'transparent', color: '#FBBF24',
                  cursor: 'pointer',
                  display: 'flex', alignItems: 'center', gap: 4, outline: 'none',
                }}>
                <EuiIcon type="bellSlash" size="s" />
                {actionLoading[`mute:${alert.id}`] ? 'Muting...' : 'Mute'}
              </button>
            )}

            {/* Block — same pattern: green pill when blocked, hidden if Mute was the
                verdict. No fade, no hover tooltip — explicit visible state. */}
            {inc.waf_blocked && (
              <span style={{ padding: '3px 10px', borderRadius: 4, fontSize: 10, fontWeight: 700,
                background: 'rgba(34,197,94,0.15)', color: '#22C55E', border: '1px solid rgba(34,197,94,0.3)',
                display: 'inline-flex', alignItems: 'center', gap: 4 }}>
                <EuiIcon type="check" size="s" /> Blocked
              </span>
            )}
            {/* Block — visible only when blockable; DISABLED unless enrichment
                verdict on a public IP is malicious/suspicious. Mirrors plugin
                attack-narrative.tsx:1881-1883:
                   canBlock = isAcked && hasJira && obsReady && verdict ∈ {malicious, suspicious}
                Rationale: blocking has real consequences (could cut off a
                corporate VPN exit / CDN). Force "enrich → decide → block" not
                "block first, ask later". obsReady + obsVerdict are stamped on
                the incident by /api/narrative/incident/update-observability,
                which the SPA already calls from handleEnrichObservable on a
                hostile verdict — so the gate is backend-of-truth, survives
                reloads. */}
            {!inc.waf_blocked && !inc.agelia_muted && isAcked && !isClosed
              && status !== 'false_positive' && integrationStatus.agelia_blocking && (() => {
              // Block is only meaningful when there is at least one PUBLIC IP
              // candidate. Gating on alert.src_ip alone shows the button on
              // Wazuh alerts whose only IP is RFC1918 (e.g. internal FIM events
              // with private source) — clicking would open a modal with no
              // selectable target. Mirror openBlockModal's candidate-build logic.
              const xffFirst = alert.http_xff?.split(',')[0]?.trim();
              const ips = [xffFirst, alert.src_ip || alert.source_ip, alert.dest_ip || alert.destination_ip].filter(Boolean);
              return ips.some(ip => !isPrivateIp(ip));
            })() && (() => {
              const obsReady = inc.observability_completed === true;
              const obsVerdict = inc.observability_verdict || null;
              const obsHostile = obsReady && (obsVerdict === 'malicious' || obsVerdict === 'suspicious');
              const canBlock = hasJira && obsHostile;
              const inFlight = !!actionLoading[`waf:${alert.id}`];
              const disabled = inFlight || !canBlock;
              const tooltip = !hasJira
                ? 'Create a Jira ticket first — Block requires an audit record.'
                : !obsReady
                  ? 'Enrich the public IP first. Block enables only after observability verdict is malicious or suspicious.'
                  : !obsHostile
                    ? `Enrichment verdict is ${(obsVerdict || 'unknown').toUpperCase()} — Block is reserved for malicious/suspicious IPs.`
                    : 'Block source IP at Network Firewall + WAF';
              return (
                <button onClick={() => openBlockModal(alert)}
                  disabled={disabled}
                  title={tooltip}
                  style={{
                    padding: '4px 12px', borderRadius: 5, fontSize: 11, fontWeight: 600,
                    border: '1px solid #EF4444', background: 'transparent', color: '#EF4444',
                    cursor: disabled ? 'not-allowed' : 'pointer',
                    opacity: disabled ? 0.45 : 1,
                    display: 'flex', alignItems: 'center', gap: 4, outline: 'none',
                  }}>
                  <EuiIcon type="lock" size="s" />
                  {inFlight ? 'Blocking...' : 'Block'}
                </button>
              );
            })()}

            {/* Closed badge OR Close button — always last.
                Close is visible on BOTH Wazuh and Suricata. Mute and Block are
                intermediate actions (rule suppression / perimeter block); the
                analyst still explicitly closes the incident with a disposition,
                so the audit trail captures both the action taken AND the analyst's
                judgement on this specific alert. */}
            {status === 'closed' ? (
              <span style={{ padding: '3px 10px', borderRadius: 4, fontSize: 10, fontWeight: 700,
                background: 'rgba(34,197,94,0.15)', color: '#22C55E', border: '1px solid rgba(34,197,94,0.3)',
                display: 'inline-flex', alignItems: 'center', gap: 4 }}>
                <EuiIcon type="check" size="s" /> Closed
                {inc.mttr_seconds ? ` (${formatDuration(inc.mttr_seconds)})` : ''}
              </span>
            ) : isAcked && !isClosed ? (
              // Single-click close — matches plugin behavior. Disposition picker
              // (Resolved / Benign / Other) was removed for this release per
              // analyst feedback; the dedicated FP button covers the FP path.
              // When richer disposition reporting is needed, restore the modal
              // by switching the onClick back to openCloseDispositionModal and
              // un-deleting the showCloseDispoModal JSX block.
              <button onClick={() => handleCloseIncident(alert)}
                disabled={actionLoading[`close:${alert.id}`]}
                title="Close incident"
                style={{
                  padding: '4px 12px', borderRadius: 5, fontSize: 11, fontWeight: 600,
                  border: `1px solid #22C55E`, background: 'transparent', color: '#22C55E',
                  cursor: 'pointer', display: 'flex', alignItems: 'center', gap: 4, outline: 'none',
                }}>
                <EuiIcon type="checkInCircleFilled" size="s" />
                {actionLoading[`close:${alert.id}`] ? 'Closing...' : 'Close Incident'}
              </button>
            ) : null}

            {/* Full workflow indicator */}
            {isAcked && (
              <span style={{ marginLeft: 'auto', fontSize: 10, color: THEME.textMuted, fontStyle: 'italic' }}>
                Full workflow
              </span>
            )}

            {/* Action error */}
            {Object.entries(actionError).filter(([k]) => k.includes(alert.id)).map(([k, err]) => (
              err && <span key={k} style={{ fontSize: 10, color: '#EF4444' }}>{err}</span>
            ))}
          </div>
        </div>
      </div>
    );
  };

  // ── Lifecycle tabs ─────────────────────────────────────────────────────
  // Primary navigation across the four states an alert can be in. Default
  // landing tab is 'open' because that's the analyst's first job. Switching
  // tabs resets the per-tab pagination index, then re-fetches via fetchAlerts
  // (driven by activeTab dep in useEffect). Counts shown reflect ONLY the
  // current tab in Phase A — full per-tab counts arrive with Phase B's
  // backend tab_counts addition.

  const TAB_DEFINITIONS = [
    { key: 'open',         label: 'Open',         color: '#EF4444', icon: 'alert' },
    { key: 'in_progress',  label: 'In Progress',  color: '#F59E0B', icon: 'clock' },
    { key: 'closed',       label: 'Closed',       color: '#22C55E', icon: 'check' },
    // RE-ENABLE NEXT RELEASE — Muted tab returns alongside Agelia
    ...(HIDE_MUTE ? [] : [{ key: 'muted', label: 'Muted', color: '#FBBF24', icon: 'bellSlash' }]),
  ];

  const handleTabChange = useCallback((tabKey) => {
    if (tabKey === activeTab) return;
    // Save the current tab's page index so we can restore it later
    setTabPagination(prev => ({ ...prev, [activeTab]: filters.page || 1 }));
    setActiveTab(tabKey);
    // Restore the destination tab's page index, or 1 if first visit
    const restorePage = tabPagination[tabKey] || 1;
    updateFilter({ page: restorePage });
  }, [activeTab, filters.page, tabPagination, updateFilter]);

  const renderLifecycleTabs = () => (
    <div
      role="tablist"
      aria-label="Alert lifecycle state"
      style={{
        display: 'flex', gap: 4,
        padding: 4, marginBottom: 14,
        background: THEME.bgDeep, border: `1px solid ${THEME.border}`,
        borderRadius: 10,
      }}
    >
      {TAB_DEFINITIONS.map(tab => {
        const isActive = tab.key === activeTab;
        // Counter prefers backend's per-tab count from metadata.tab_counts
        // (accurate across all tabs); falls back to total_alerts for the
        // active tab when the backend hasn't sent tab_counts yet.
        const count = (tabCounts && typeof tabCounts[tab.key] === 'number')
          ? tabCounts[tab.key]
          : (isActive && metadata ? (metadata.total_alerts ?? 0) : null);
        return (
          <button
            key={tab.key}
            role="tab"
            aria-selected={isActive}
            aria-controls="alert-list-region"
            onClick={() => handleTabChange(tab.key)}
            style={{
              flex: 1,
              display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 8,
              padding: '8px 14px',
              borderRadius: 8,
              border: 'none',
              background: isActive ? `${tab.color}18` : 'transparent',
              color: isActive ? tab.color : THEME.textSecondary,
              fontSize: 13,
              fontWeight: isActive ? 700 : 500,
              cursor: isActive ? 'default' : 'pointer',
              transition: 'background 0.15s, color 0.15s',
              outline: 'none',
            }}
            onMouseEnter={e => { if (!isActive) e.currentTarget.style.background = 'rgba(255,255,255,0.03)'; }}
            onMouseLeave={e => { if (!isActive) e.currentTarget.style.background = 'transparent'; }}
          >
            <EuiIcon type={tab.icon} size="s" color={isActive ? tab.color : THEME.textMuted} />
            <span>{tab.label}</span>
            {count !== null && (
              <span style={{
                display: 'inline-flex', alignItems: 'center', justifyContent: 'center',
                minWidth: 22, height: 18, padding: '0 6px',
                borderRadius: 9, fontSize: 11, fontWeight: 700,
                background: `${tab.color}30`, color: tab.color,
              }}>{count}</span>
            )}
          </button>
        );
      })}
    </div>
  );

  // ── Group row ──────────────────────────────────────────────────────────
  // Renders one collapsed row for a duplicate-alert group (count > 1). The
  // row shows severity / source pills, occurrence count, first/last seen
  // timestamps, and an expand triangle. When expanded, the group's individual
  // alerts render below using the existing renderAlertCard so all per-alert
  // actions (ACK / Mute / Block / Close) keep working unchanged.

  const renderGroupRow = (group, idx) => {
    const sigKey = group.signature_key;
    // Default-collapse for Open / In Progress (high noise — analyst wants to
    // skim). Default-expand for Closed (audit reading — analyst wants detail).
    const defaultExpanded = activeTab === 'closed';
    const expanded = isGroupExpanded(sigKey, defaultExpanded);
    // Find the worst (oldest unacknowledged) alert in the group for the SLA
    // badge. The group as a whole is "as breached as its worst member".
    const worstAlert = group.alerts.reduce((worst, a) => {
      const ts = a.timestamp || '';
      const inc = (incidents[a.id] || a._incident || {});
      const isAcked = !!inc.acknowledged_at;
      // Open + oldest = worst. Already-acked alerts only beat open if no
      // open ones exist in the group.
      if (!worst) return a;
      const wInc = (incidents[worst.id] || worst._incident || {});
      const wAcked = !!wInc.acknowledged_at;
      if (isAcked !== wAcked) return wAcked ? a : worst;
      return ts < (worst.timestamp || '') ? a : worst;
    }, null);
    const sev = group.severity || normalizeSeverity(group.alerts[0]?.level);
    const sevColor = SEVERITY_COLORS[sev] || SEVERITY_COLORS.low;
    const sigId = group.rule_id || '';
    const description = group.alerts[0]?.rule_description
      || group.alerts[0]?.signature
      || group.alerts[0]?.rule?.description
      || 'No description';
    const desc = sigId ? `SID ${sigId} — ${description}` : description;
    // Count of alerts in the group with at least one of: muted, blocked,
    // ack'd. Drives the small status pills next to the count chip.
    const stateSummary = group.alerts.reduce((acc, a) => {
      const inc = incidents[a.id] || a._incident || {};
      if (a._agelia_muted || inc.agelia_muted) acc.muted += 1;
      if (a._waf_blocked || inc.waf_blocked) acc.blocked += 1;
      if (inc.acknowledged_at) acc.acked += 1;
      return acc;
    }, { muted: 0, blocked: 0, acked: 0 });

    return (
      <div key={sigKey} style={{
        background: THEME.card,
        border: `1px solid ${THEME.border}`,
        borderLeft: `4px solid ${sevColor.text}`,
        borderRadius: 8,
        animation: `pallas-fadeIn 0.3s ease`,
        animationDelay: `${Math.min(idx * 30, 300)}ms`,
        animationFillMode: 'both',
      }}>
        {/* Group header — always visible. Click to expand/collapse. */}
        <div
          onClick={() => toggleGroup(sigKey, expanded)}
          role="button"
          aria-expanded={expanded}
          aria-controls={`group-content-${sigKey}`}
          style={{
            display: 'flex', alignItems: 'center', gap: 10,
            padding: '10px 14px',
            cursor: 'pointer',
            borderBottom: expanded ? `1px solid ${THEME.border}` : 'none',
            transition: 'background-color 0.15s',
          }}
          onMouseEnter={e => { e.currentTarget.style.backgroundColor = 'rgba(255,255,255,0.02)'; }}
          onMouseLeave={e => { e.currentTarget.style.backgroundColor = 'transparent'; }}
        >
          {/* Per-group checkbox for bulk selection. Stops click propagation
              so toggling the box doesn't also toggle expansion. */}
          <input
            type="checkbox"
            aria-label={`Select group of ${group.count} ${desc}`}
            checked={selectedGroups.has(sigKey)}
            disabled={!!bulkActionInFlight}
            onClick={(e) => { e.stopPropagation(); }}
            onChange={(e) => {
              e.stopPropagation();
              toggleGroupSelection(sigKey);
            }}
            style={{ accentColor: ACCENT, cursor: bulkActionInFlight ? 'not-allowed' : 'pointer' }}
          />
          <EuiIcon
            type={expanded ? 'arrowDown' : 'arrowRight'}
            size="s"
            color={THEME.textMuted}
          />
          {renderSeverityBadge(group.alerts[0]?.level, sev)}
          {renderSourceBadge(group.source)}
          {worstAlert && <SLABadge alert={worstAlert} tickMs={slaTickMs} />}
          <span style={{
            fontSize: 13, fontWeight: 500, color: THEME.text,
            flex: 1, minWidth: 0,
            overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap',
          }} title={desc}>
            {desc}
          </span>
          {/* Occurrence count — the headline number for grouped duplicates */}
          <span style={{
            display: 'inline-flex', alignItems: 'center', gap: 4,
            padding: '3px 10px', borderRadius: 12,
            background: `${ACCENT}25`, color: ACCENT,
            fontSize: 11, fontWeight: 700,
          }}>
            <EuiIcon type="copy" size="s" color={ACCENT} />
            {group.count} alerts
          </span>
          {stateSummary.muted > 0 && (
            <PillBadge label={`${stateSummary.muted} muted`} color="#FBBF24" bg="rgba(251,191,36,0.12)" border="rgba(251,191,36,0.3)" />
          )}
          {stateSummary.blocked > 0 && (
            <PillBadge label={`${stateSummary.blocked} blocked`} color="#22C55E" bg="rgba(34,197,94,0.12)" border="rgba(34,197,94,0.3)" />
          )}
          {stateSummary.acked > 0 && stateSummary.acked < group.count && (
            <PillBadge label={`${stateSummary.acked}/${group.count} ACK'd`} color="#06B6D4" bg="rgba(6,182,212,0.12)" border="rgba(6,182,212,0.3)" />
          )}
          {/* Time range — first to last seen */}
          <span style={{
            fontSize: 10, color: THEME.textMuted, fontFamily: FONT.mono, whiteSpace: 'nowrap',
          }}>
            {group.first_seen && group.last_seen && group.first_seen !== group.last_seen
              ? `${formatTimeAgo(group.first_seen)} – ${formatTimeAgo(group.last_seen)}`
              : formatTimeAgo(group.last_seen || group.first_seen)}
          </span>
        </div>
        {/* Group content — expanded list of individual alerts */}
        {expanded && (
          <div
            id={`group-content-${sigKey}`}
            style={{ padding: 10, display: 'flex', flexDirection: 'column', gap: 8 }}
          >
            {group.alerts.map((a, i) => renderAlertCard(a, i))}
          </div>
        )}
      </div>
    );
  };

  // ── Main render ────────────────────────────────────────────────────────

  return (
    <div style={{ display: 'flex', flexDirection: 'column', height: '100%', fontFamily: FONT.base }}>

      {/* Toast container — used by scheduleAutoClose() to render the post-action
          undo banner. Bottom-right keeps it out of the way of the action bar. */}
      <Toaster
        position="bottom-right"
        toastOptions={{ duration: 5000, style: { background: 'transparent', boxShadow: 'none', padding: 0 } }}
      />

      {/* ── Compact toolbar: title + time range controls ── */}
      <div style={{
        flexShrink: 0,
        borderBottom: `1px solid ${THEME.border}`,
        background: 'rgba(255,255,255,0.015)',
        padding: '8px 16px',
        display: 'flex',
        alignItems: 'center',
        gap: 10,
        flexWrap: 'wrap',
      }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
          <EuiIcon type="timeline" size="s" color={accent} />
          <span style={{ fontSize: 13, fontWeight: 700, color: THEME.text }}>Attack Narrative</span>
        </div>

        {metadata?.scan_duration_ms != null && (
          <PillBadge label={`${metadata.scan_duration_ms}ms`} color={accent} bg={`${accent}1A`} border={`${accent}33`} />
        )}

        <div style={{ display: 'flex', gap: 3, marginLeft: 4 }}>
          {TIME_RANGES.map((tr) => {
            const isActive = filters.time_range === tr.value;
            return (
              <button
                key={tr.value}
                onClick={() => handleTimeRangeChange(tr.value)}
                disabled={isLoading}
                style={{
                  padding: '4px 10px', borderRadius: 5, fontSize: 11, fontWeight: 600,
                  border: `1px solid ${isActive ? accent : THEME.border}`,
                  background: isActive ? `${accent}1A` : 'transparent',
                  color: isActive ? accent : THEME.textSecondary,
                  cursor: isLoading ? 'not-allowed' : 'pointer',
                  opacity: isLoading ? 0.5 : 1, transition: 'all 0.2s',
                  outline: 'none',
                }}
              >
                {tr.label}
              </button>
            );
          })}
        </div>

        <button
          onClick={() => fetchAlerts(filters)}
          disabled={isLoading}
          aria-label="Refresh alerts"
          style={{
            display: 'inline-flex', alignItems: 'center', justifyContent: 'center',
            width: 28, height: 28, borderRadius: 5, border: `1px solid ${THEME.border}`,
            background: 'transparent', cursor: isLoading ? 'not-allowed' : 'pointer',
            opacity: isLoading ? 0.5 : 1, outline: 'none',
          }}
        >
          <EuiIcon type="refresh" size="s" color={THEME.textSecondary} />
        </button>

        {onClose && (
          <button onClick={onClose} style={{
            marginLeft: 'auto', padding: '4px 10px', borderRadius: 5,
            border: `1px solid ${THEME.border}`, background: 'transparent',
            color: THEME.textMuted, fontSize: 11, cursor: 'pointer',
            display: 'flex', alignItems: 'center', gap: 4, outline: 'none',
          }}>
            <EuiIcon type="cross" size="s" /> Close
          </button>
        )}
      </div>

      {/* Scrollable content — constrained width with side padding */}
      <div style={{ flex: 1, overflowY: 'auto', padding: '16px 24px' }} className="pallas-scrollbar">
        <div style={{ maxWidth: 1320, margin: '0 auto' }}>
        {/* Filter bar — sticky to top of scroll container so it stays in
            view as the analyst scrolls through alerts. backdrop-blur keeps
            content readable behind it. */}
        <div style={{
          position: 'sticky',
          top: -16, // negative offset cancels the parent's 16px top padding so it sticks flush
          zIndex: 10,
          marginBottom: 12,
          padding: '12px 0',
          background: `${THEME.bg}DC`,
          backdropFilter: 'blur(8px)',
          WebkitBackdropFilter: 'blur(8px)',
        }}>
          <EuiFlexGroup gutterSize="s" alignItems="center" wrap responsive={false}>
            <EuiFlexItem grow={2} style={{ minWidth: 220 }}>
              <EuiFieldSearch
                placeholder="Search SID, IP, agent, description\u2026"
                value={searchInput}
                onChange={(e) => setSearchInput(e.target.value)}
                isClearable
                fullWidth
                compressed
              />
            </EuiFlexItem>
            <EuiFlexItem grow={false}>
              <EuiSelect
                compressed
                aria-label="Severity filter"
                options={[
                  { value: 'all',      text: 'All Severity' },
                  { value: 'critical', text: 'Critical' },
                  { value: 'high',     text: 'High' },
                  { value: 'medium',   text: 'Medium' },
                  { value: 'low',      text: 'Low' },
                ]}
                value={filters.severity}
                onChange={(e) => updateFilter({ severity: e.target.value })}
              />
            </EuiFlexItem>
            <EuiFlexItem grow={false}>
              <EuiSelect
                compressed
                aria-label="Source filter"
                options={[
                  { value: 'all',      text: 'All Sources' },
                  { value: 'wazuh',    text: 'Wazuh' },
                  { value: 'suricata', text: 'Suricata' },
                ]}
                value={filters.source}
                onChange={(e) => updateFilter({ source: e.target.value })}
              />
            </EuiFlexItem>
            {/* Status dropdown removed — replaced by lifecycle tabs below the filter bar.
                The tabs (Open / In Progress / Closed / Muted) are the canonical
                way to scope the list by lifecycle state. */}
            <EuiFlexItem grow={false}>
              <EuiSwitch
                compressed
                label="My alerts"
                title="Show alerts I've worked on (acknowledged, closed, dismissed, assigned, or I'm the Jira assignee)"
                checked={!!filters.assigned_to && filters.assigned_to === getCurrentAnalystName()}
                onChange={(e) => updateFilter({
                  assigned_to: e.target.checked ? getCurrentAnalystName() : '',
                })}
              />
            </EuiFlexItem>
            <EuiFlexItem grow={false}>
              <EuiButton
                size="s"
                iconType="cross"
                onClick={() => setSearchParams(new URLSearchParams(), { replace: true })}
                aria-label="Reset all filters"
              >
                Reset
              </EuiButton>
            </EuiFlexItem>
          </EuiFlexGroup>
        </div>

        {/* Lifecycle tabs \u2014 primary navigation. Sits between the filter bar
            (which scopes "what data") and the KPI tiles (which describe the
            current scope). Tabs determine which lifecycle state to show. */}
        {renderLifecycleTabs()}

        {/* KPI tiles \u2014 replaces the old inline metadata row. Stat tiles double
            as filter shortcuts: clicking Wazuh/Suricata toggles the source filter.
            Clicking Muted now switches to the Muted tab (replaces the older
            inline show-muted toggle). Each tile uses StandupKPICard from PallasUI
            for visual consistency with the Daily Standup page. */}
        {metadata && !isLoading && (
          <div style={{ display: 'flex', gap: 12, marginBottom: 14, flexWrap: 'wrap' }}>
            <StandupKPICard
              icon="visTable"
              label={metadata.raw_total != null && metadata.raw_total !== metadata.total_alerts
                ? `Showing of ${metadata.raw_total}`
                : 'Showing'}
              value={metadata.total_alerts ?? alerts.length}
              subValue={metadata.time_range ? `Range ${metadata.time_range}` : null}
              color={THEME.accent}
            />
            <StandupKPICard
              icon="securityApp"
              label="Wazuh"
              value={metadata.wazuh_count ?? '\u2014'}
              subValue={filters.source === 'wazuh' ? 'Filter active \u2014 click to clear' : 'Click to filter'}
              color={filters.source === 'wazuh' ? THEME.primary : THEME.textMuted}
              onClick={() => updateFilter({ source: filters.source === 'wazuh' ? 'all' : 'wazuh' })}
            />
            <StandupKPICard
              icon="globe"
              label="Suricata"
              value={metadata.suricata_count ?? '\u2014'}
              subValue={filters.source === 'suricata' ? 'Filter active \u2014 click to clear' : 'Click to filter'}
              color={filters.source === 'suricata' ? '#F97316' : THEME.textMuted}
              onClick={() => updateFilter({ source: filters.source === 'suricata' ? 'all' : 'suricata' })}
            />
            {metadata.agelia_muted_count != null && metadata.agelia_muted_count > 0 && (
              <StandupKPICard
                icon="bellSlash"
                label="Muted"
                value={metadata.agelia_muted_count}
                subValue={activeTab === 'muted' ? 'Viewing \u2014 click to leave tab' : 'Click to view in Muted tab'}
                color={activeTab === 'muted' ? THEME.warning : THEME.textMuted}
                onClick={() => handleTabChange(activeTab === 'muted' ? 'open' : 'muted')}
              />
            )}
            {metadata.agelia_blocked_count != null && metadata.agelia_blocked_count > 0 && (
              <StandupKPICard
                icon="lock"
                label="IP Blocked"
                value={metadata.agelia_blocked_count}
                subValue="Source IPs blocked at AWS perimeter"
                color={THEME.danger}
              />
            )}
          </div>
        )}

        {/* Error state */}
        {loadError && (
          <div style={{
            padding: '10px 14px', borderRadius: 6, marginBottom: 14,
            background: 'rgba(239,68,68,0.1)', border: '1px solid rgba(239,68,68,0.3)',
            color: '#EF4444', fontSize: 13, display: 'flex', alignItems: 'center', gap: 8,
          }}>
            <EuiIcon type="warning" size="s" color="#EF4444" /> {loadError}
          </div>
        )}

        {/* Loading state — shimmer skeleton rows. Better perceived speed than a
            single centered spinner: the shape of the page appears immediately so
            the analyst can orient while data loads. */}
        {isLoading && (
          <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }} aria-busy="true" aria-label="Loading alerts">
            {[0, 1, 2, 3, 4, 5].map(i => (
              <div key={i} style={{
                padding: '14px 16px', borderRadius: 10,
                background: THEME.card, border: `1px solid ${THEME.border}`,
                borderLeft: `3px solid ${THEME.border}`,
                display: 'flex', flexDirection: 'column', gap: 8,
              }}>
                <div style={{ display: 'flex', gap: 10, alignItems: 'center' }}>
                  <SkeletonLine width={70} height={18} />
                  <SkeletonLine width={80} height={14} />
                  <SkeletonLine width={`${50 + (i * 7) % 30}%`} height={14} />
                  <div style={{ marginLeft: 'auto' }}>
                    <SkeletonLine width={60} height={11} />
                  </div>
                </div>
                <SkeletonLine width={`${30 + (i * 11) % 40}%`} height={11} />
              </div>
            ))}
          </div>
        )}

        {/* Welcome state */}
        {!isLoading && !loadError && !hasScanned && (
          <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', padding: '60px 20px', gap: 14 }}>
            <EuiIcon type="sparkles" size="xxl" color={accent} />
            <span style={{ fontSize: 16, fontWeight: 600, color: THEME.text }}>Ready to Scan</span>
            <span style={{ fontSize: 13, color: THEME.textSecondary, textAlign: 'center', maxWidth: 420, lineHeight: '1.5' }}>
              Click <strong>Scan Alerts</strong> to fetch critical alerts (level &ge; 12) from Wazuh and Suricata.
              Each alert can then be enhanced with an AI-generated forensic narrative.
            </span>
            <button
              onClick={() => fetchAlerts(filters)}
              style={{
                marginTop: 8, padding: '10px 28px', borderRadius: 8, border: 'none',
                background: accent, color: '#fff', fontSize: 14, fontWeight: 600,
                cursor: 'pointer', display: 'flex', alignItems: 'center', gap: 8,
                outline: 'none',
              }}
            >
              <EuiIcon type="refresh" size="s" color="#fff" /> Scan Alerts
            </button>
          </div>
        )}

        {/* Empty state */}
        {!isLoading && !loadError && hasScanned && alerts.length === 0 && (
          <EmptyState
            icon="check"
            title="No Critical Alerts"
            description="No alerts at level 12 or above found in the selected time range. Adjust the range or check back later."
            accent={ACCENT}
          />
        )}

        {/* Pinned Narratives */}
        {pinnedNarratives.length > 0 && (
          <div style={{ marginBottom: 16 }}>
            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 10 }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: 6, fontSize: 12, fontWeight: 600, color: THEME.textSecondary, textTransform: 'uppercase', letterSpacing: '0.5px' }}>
                <EuiIcon type="pinFilled" size="s" color={ACCENT} />
                Pinned Narratives
                <span style={{ fontSize: 11, fontWeight: 400, color: THEME.textMuted, textTransform: 'none', letterSpacing: 'normal' }}>
                  ({pinnedNarratives.length})
                </span>
              </div>
              <div style={{ display: 'flex', gap: 8 }}>
                {pinnedNarratives.length >= 2 && (
                  <button
                    onClick={() => setCompareMode((v) => !v)}
                    style={{
                      display: 'inline-flex', alignItems: 'center', gap: 5, padding: '4px 10px',
                      borderRadius: 6, border: `1px solid ${compareMode ? ACCENT : THEME.border}`,
                      backgroundColor: compareMode ? `${ACCENT}1A` : 'transparent',
                      color: compareMode ? ACCENT : THEME.textSecondary,
                      fontSize: 11, fontWeight: 500, cursor: 'pointer', outline: 'none',
                    }}
                  >
                    <EuiIcon type="merge" size="s" /> Compare
                  </button>
                )}
                <button
                  onClick={exportPinnedNarratives}
                  style={{
                    display: 'inline-flex', alignItems: 'center', gap: 5, padding: '4px 10px',
                    borderRadius: 6, border: `1px solid ${THEME.border}`, backgroundColor: 'transparent',
                    color: THEME.textSecondary, fontSize: 11, fontWeight: 500, cursor: 'pointer', outline: 'none',
                  }}
                >
                  <EuiIcon type="download" size="s" /> Export
                </button>
              </div>
            </div>

            {/* Pinned chips */}
            <div style={{ display: 'flex', flexWrap: 'wrap', gap: 6, marginBottom: compareMode ? 12 : 0 }}>
              {pinnedNarratives.map((p, idx) => (
                <div key={p.alertId} style={{
                  display: 'inline-flex', alignItems: 'center', gap: 6, padding: '4px 10px',
                  borderRadius: 6, backgroundColor: THEME.cardSubtle || 'rgba(255,255,255,0.03)',
                  border: `1px solid ${THEME.border}`, fontSize: 11, color: THEME.textSecondary,
                }}>
                  <EuiIcon type="pinFilled" size="s" color={ACCENT} />
                  <span style={{ maxWidth: 180, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                    {p.description.substring(0, 50)}
                  </span>
                  <button
                    onClick={() => unpinNarrative(idx)}
                    style={{ background: 'none', border: 'none', color: THEME.textMuted, cursor: 'pointer', padding: 2, display: 'flex', alignItems: 'center' }}
                    title="Unpin"
                  >
                    <EuiIcon type="cross" size="s" />
                  </button>
                </div>
              ))}
            </div>

            {/* Compare view */}
            {compareMode && pinnedNarratives.length >= 2 && (
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12, marginTop: 8 }}>
                {pinnedNarratives.slice(0, 2).map((p, idx) => (
                  <div key={p.alertId} style={{
                    padding: 14, borderRadius: 8, background: THEME.bgDeep || 'rgba(0,0,0,0.15)',
                    border: `1px solid ${idx === 0 ? `${ACCENT}4D` : 'rgba(97,162,255,0.3)'}`,
                  }}>
                    <div style={{
                      fontSize: 11, fontWeight: 600, color: idx === 0 ? ACCENT : '#61A2FF',
                      textTransform: 'uppercase', letterSpacing: '0.4px', marginBottom: 8,
                    }}>
                      {p.description.substring(0, 60)}
                    </div>
                    <PallasMarkdown content={p.narrative} />
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {/* Bulk action bar — sticky toolbar that appears when the analyst
            checks one or more group rows. Each button operates on EVERY group
            currently selected (so "Acknowledge all" is "ack every alert in
            every selected group"). For Phase C we run actions per-group
            sequentially because each group needs its own pattern/conditions
            for mute. Multi-group selection is therefore a series of individual
            bulk calls — not one mega-batch — which keeps idempotency keys
            distinct per group. */}
        {selectedGroups.size > 0 && groups && (() => {
          const selected = (groups || []).filter(g => selectedGroups.has(g.signature_key));
          const totalAlerts = selected.reduce((sum, g) => sum + (g.count || 0), 0);
          const inFlight = !!bulkActionInFlight;
          return (
            <div style={{
              position: 'sticky', top: 0, zIndex: 5,
              display: 'flex', alignItems: 'center', gap: 12,
              padding: '10px 14px', marginBottom: 10,
              background: `${ACCENT}15`,
              border: `1px solid ${ACCENT}55`,
              borderRadius: 8,
              boxShadow: '0 4px 12px rgba(0,0,0,0.3)',
              animation: 'pallas-slideUp 0.2s ease',
            }}>
              <EuiIcon type="check" size="m" color={ACCENT} />
              <span style={{ fontSize: 13, fontWeight: 600, color: THEME.text }}>
                {selected.length} group{selected.length === 1 ? '' : 's'} selected · {totalAlerts} alerts
              </span>
              <div style={{ flex: 1 }} />
              <button
                onClick={() => selected.forEach(g => handleBulkAcknowledge(g))}
                disabled={inFlight}
                style={{
                  padding: '6px 14px', borderRadius: 6,
                  border: '1px solid #06B6D4', background: 'rgba(6,182,212,0.12)',
                  color: '#06B6D4', fontSize: 12, fontWeight: 600,
                  cursor: inFlight ? 'not-allowed' : 'pointer', opacity: inFlight ? 0.5 : 1,
                  display: 'flex', alignItems: 'center', gap: 4, outline: 'none',
                }}>
                <EuiIcon type="check" size="s" /> Acknowledge all
              </button>
              {/* RE-ENABLE NEXT RELEASE — bulk Mute pattern returns with Agelia */}
              {!HIDE_MUTE && (
              <button
                onClick={() => selected.forEach(g => openBulkMuteModal(g))}
                disabled={inFlight || selected.length !== 1}
                title={selected.length !== 1 ? 'Select exactly one group to mute its pattern' : 'Mute the pattern of the selected group'}
                style={{
                  padding: '6px 14px', borderRadius: 6,
                  border: '1px solid #FBBF24', background: 'rgba(251,191,36,0.12)',
                  color: '#FBBF24', fontSize: 12, fontWeight: 600,
                  cursor: (inFlight || selected.length !== 1) ? 'not-allowed' : 'pointer',
                  opacity: (inFlight || selected.length !== 1) ? 0.5 : 1,
                  display: 'flex', alignItems: 'center', gap: 4, outline: 'none',
                }}>
                <EuiIcon type="bellSlash" size="s" /> Mute pattern
              </button>
              )}
              <button
                onClick={() => selected.forEach(g => openBulkCloseModal(g))}
                disabled={inFlight || selected.length !== 1}
                title={selected.length !== 1 ? 'Select exactly one group to close (each pattern closes with its own disposition)' : 'Close all alerts in the selected group with one disposition'}
                style={{
                  padding: '6px 14px', borderRadius: 6,
                  border: '1px solid #22C55E', background: 'rgba(34,197,94,0.12)',
                  color: '#22C55E', fontSize: 12, fontWeight: 600,
                  cursor: (inFlight || selected.length !== 1) ? 'not-allowed' : 'pointer',
                  opacity: (inFlight || selected.length !== 1) ? 0.5 : 1,
                  display: 'flex', alignItems: 'center', gap: 4, outline: 'none',
                }}>
                <EuiIcon type="checkInCircleFilled" size="s" /> Close all
              </button>
              <button
                onClick={clearGroupSelection}
                disabled={inFlight}
                style={{
                  padding: '6px 12px', borderRadius: 6,
                  border: `1px solid ${THEME.border}`, background: 'transparent',
                  color: THEME.textMuted, fontSize: 12, fontWeight: 500,
                  cursor: inFlight ? 'not-allowed' : 'pointer',
                  display: 'flex', alignItems: 'center', gap: 4, outline: 'none',
                }}>
                Clear
              </button>
              {bulkActionInFlight && (
                <span style={{ fontSize: 11, color: THEME.textMuted, fontStyle: 'italic' }}>
                  {bulkActionInFlight.action === 'ack' ? 'Acknowledging' : bulkActionInFlight.action === 'mute' ? 'Muting' : 'Closing'} {bulkActionInFlight.count}…
                </span>
              )}
            </div>
          );
        })()}

        {/* Alert list.
            With lifecycle tabs + grouping in place, the backend returns alerts
            already scoped to the current tab AND folded into signature-keyed
            groups when group_by is requested. Rendering rules:
              - groups with count > 1 render as a collapsible <GroupRow />
              - groups with count == 1 render their single alert via the
                existing renderAlertCard path (visually identical to ungrouped)
              - if `groups` is null (server didn't group), fall back to the
                flat alerts list. */}
        {!isLoading && (alerts.length > 0 || (groups && groups.length > 0)) && (
          <div
            id="alert-list-region"
            role="tabpanel"
            aria-label={`${activeTab} alerts`}
            // paddingBottom gives the last alert card breathing room from the
            // viewport edge so its action buttons (ACK / Create Ticket / Close)
            // aren't visually clipped or unreachable.
            style={{ display: 'flex', flexDirection: 'column', gap: 10, paddingBottom: 60 }}
          >
            {groups
              ? groups.map((g, idx) => g.count > 1
                  ? renderGroupRow(g, idx)
                  : renderAlertCard(g.alerts[0], idx))
              : alerts.map((alert, idx) => renderAlertCard(alert, idx))}
          </div>
        )}

        {/* Pagination controls — render only when there's more than one page */}
        {!isLoading && metadata && metadata.total_pages > 1 && (
          <div style={{
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            gap: 16, padding: '20px 0 8px', flexWrap: 'wrap',
          }}>
            <EuiPagination
              aria-label="Alerts pagination"
              pageCount={metadata.total_pages}
              activePage={Math.max(0, (filters.page || 1) - 1)}
              onPageClick={(zeroIndexedPage) => updateFilter({ page: zeroIndexedPage + 1 })}
            />
            <EuiSelect
              compressed
              aria-label="Page size"
              options={[
                { value: '25',  text: '25 / page' },
                { value: '50',  text: '50 / page' },
                { value: '100', text: '100 / page' },
              ]}
              value={String(filters.page_size)}
              onChange={(e) => updateFilter({ page_size: parseInt(e.target.value, 10) })}
              style={{ width: 120 }}
            />
            <EuiText size="xs" color="subdued">
              {metadata.total_alerts} alerts
              {metadata.raw_total != null && metadata.raw_total !== metadata.total_alerts &&
                ` (${metadata.raw_total} before filters)`}
            </EuiText>
          </div>
        )}
        </div>
      </div>

      {/* ── Mute Modal ── */}
      {/* RE-ENABLE NEXT RELEASE — Mute modal returns with Agelia */}
      {!HIDE_MUTE && showMuteModal && muteModalAlert && (() => {
        const isSuricata = (muteModalAlert.source || '').toLowerCase() === 'suricata';
        const sev = muteModalAlert.severity || normalizeSeverity(muteModalAlert.level);
        const sevColor = SEVERITY_COLORS[sev] || SEVERITY_COLORS.low;
        const sigName = muteModalAlert.rule_description || muteModalAlert.signature || muteModalAlert.alert?.signature || muteModalAlert.description || '';
        const hasSelection = Object.values(muteSelectedConditions).some(Boolean);
        return (
          <div onClick={(e) => e.target === e.currentTarget && setShowMuteModal(false)} style={{
            position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.75)',
            zIndex: 9999, display: 'flex', alignItems: 'center', justifyContent: 'center',
            animation: 'pallasModalFadeIn 0.15s ease',
          }}>
            <div style={{
              background: THEME.card, border: `1px solid ${THEME.border}`,
              borderRadius: 14, padding: 24, width: 500, maxWidth: '92vw',
              boxShadow: '0 24px 80px rgba(0,0,0,0.6)',
              animation: 'pallasModalSlideUp 0.2s cubic-bezier(0.34,1.56,0.64,1)',
            }}>
              {/* Header */}
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 18 }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
                  <div style={{ width: 36, height: 36, borderRadius: 10, background: 'rgba(251,191,36,0.15)', border: '1px solid rgba(251,191,36,0.3)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                    <EuiIcon type="bellSlash" size="m" color="#FBBF24" />
                  </div>
                  <div>
                    <div style={{ fontWeight: 700, fontSize: 15, color: THEME.text }}>Mute Alert</div>
                    <div style={{ fontSize: 11, color: THEME.textMuted, marginTop: 2 }}>
                      {isSuricata ? '🟠 Suricata / NIDS Alert' : '🔵 Wazuh / HIDS Alert'}
                    </div>
                  </div>
                </div>
                <button onClick={() => setShowMuteModal(false)} style={{ background: 'none', border: 'none', color: THEME.textMuted, cursor: 'pointer', fontSize: 20, lineHeight: 1, padding: 4 }}>×</button>
              </div>

              {/* Alert details */}
              <div style={{ background: 'rgba(255,255,255,0.03)', borderRadius: 8, padding: '10px 14px', marginBottom: 18, border: `1px solid ${THEME.border}` }}>
                <div style={{ fontSize: 12, fontWeight: 600, color: THEME.text, marginBottom: 6 }}>{sigName || 'Alert Details'}</div>
                <div style={{ display: 'flex', gap: 14, flexWrap: 'wrap', fontSize: 11, color: THEME.textMuted }}>
                  <span>Severity: <span style={{ color: sevColor.text, fontWeight: 700 }}>{sev.toUpperCase()}</span></span>
                  {(muteModalAlert.src_ip || muteModalAlert.source_ip) && (
                    <span>Source: <span style={{ fontFamily: 'monospace', color: THEME.textSecondary }}>{muteModalAlert.src_ip || muteModalAlert.source_ip}</span></span>
                  )}
                  {(muteModalAlert.dest_ip || muteModalAlert.destination_ip) && (
                    <span>Dest: <span style={{ fontFamily: 'monospace', color: THEME.textSecondary }}>{muteModalAlert.dest_ip || muteModalAlert.destination_ip}</span></span>
                  )}
                </div>
              </div>

              {/* Conditions */}
              <div style={{ marginBottom: 18 }}>
                <div style={{ fontSize: 12, fontWeight: 600, color: THEME.text, marginBottom: 10 }}>
                  Mute Conditions <span style={{ fontWeight: 400, color: THEME.textMuted }}>(select one or more)</span>
                </div>
                <div style={{ display: 'flex', flexDirection: 'column', gap: 2 }}>
                  {muteConditionOptions.map(opt => (
                    <label key={opt.key} style={{
                      display: 'flex', alignItems: 'center', gap: 12, padding: '9px 12px',
                      borderRadius: 8, cursor: opt.value ? 'pointer' : 'default',
                      opacity: opt.value ? 1 : 0.35,
                      background: muteSelectedConditions[opt.key] ? 'rgba(251,191,36,0.08)' : 'transparent',
                      border: `1px solid ${muteSelectedConditions[opt.key] ? 'rgba(251,191,36,0.3)' : 'transparent'}`,
                      transition: 'all 0.15s ease',
                    }}>
                      <input type="checkbox"
                        checked={!!muteSelectedConditions[opt.key]}
                        disabled={!opt.value}
                        onChange={e => opt.value && setMuteSelectedConditions(prev => ({ ...prev, [opt.key]: e.target.checked }))}
                        style={{ width: 15, height: 15, accentColor: '#FBBF24', cursor: opt.value ? 'pointer' : 'default' }}
                      />
                      <div style={{ flex: 1 }}>
                        <div style={{ fontSize: 12, fontWeight: 500, color: THEME.text }}>{opt.label}</div>
                        <div style={{ fontSize: 11, color: THEME.textMuted, fontFamily: 'monospace', marginTop: 1 }}>{opt.value || 'N/A'}</div>
                      </div>
                    </label>
                  ))}
                </div>
              </div>

              {/* Classification */}
              <div style={{ marginBottom: 22 }}>
                <div style={{ fontSize: 12, fontWeight: 600, color: THEME.text, marginBottom: 8 }}>
                  Classification <span style={{ fontWeight: 400, color: THEME.textMuted }}>(Why are you muting this?)</span>
                </div>
                <select value={muteClassification} onChange={e => setMuteClassification(e.target.value)} style={{
                  width: '100%', padding: '9px 12px', background: THEME.bg,
                  border: `1px solid ${THEME.border}`, borderRadius: 8,
                  color: THEME.text, fontSize: 13, outline: 'none', cursor: 'pointer',
                }}>
                  <option value="false_positive">False Positive</option>
                  <option value="known_benign">Known Benign</option>
                  <option value="tuning">Tuning</option>
                </select>
              </div>

              {/* Actions */}
              <div style={{ display: 'flex', justifyContent: 'flex-end', gap: 10 }}>
                <button onClick={() => setShowMuteModal(false)} style={{
                  padding: '8px 18px', borderRadius: 8, border: `1px solid ${THEME.border}`,
                  background: 'transparent', color: THEME.textMuted, cursor: 'pointer', fontSize: 12, fontWeight: 500,
                }}>Cancel</button>
                <button onClick={executeMute} disabled={!hasSelection || actionLoading[`mute:${muteModalAlert.id}`]} style={{
                  padding: '8px 22px', borderRadius: 8, border: 'none',
                  background: hasSelection ? '#FBBF24' : THEME.border,
                  color: hasSelection ? '#000' : THEME.textMuted,
                  cursor: hasSelection ? 'pointer' : 'not-allowed',
                  fontSize: 12, fontWeight: 700, transition: 'all 0.2s',
                  display: 'flex', alignItems: 'center', gap: 6,
                }}>
                  <EuiIcon type="bellSlash" size="s" />
                  {actionLoading[`mute:${muteModalAlert.id}`] ? 'Muting...' : 'Mute Alert'}
                </button>
              </div>
            </div>
          </div>
        );
      })()}

      {/* ── Block IP Modal ── */}
      {showBlockModal && blockModalAlert && (() => {
        const sev = blockModalAlert.severity || normalizeSeverity(blockModalAlert.level);
        const sevColor = SEVERITY_COLORS[sev] || SEVERITY_COLORS.low;
        const sigName = blockModalAlert.rule_description || blockModalAlert.signature || blockModalAlert.alert?.signature || blockModalAlert.description || '';
        const hasPublicCandidate = blockIpCandidates.some(c => !c.isPrivate);
        const canSubmit = !!blockSelectedIp && !isPrivateIp(blockSelectedIp) && !!blockReason.trim();
        return (
          <div onClick={(e) => e.target === e.currentTarget && setShowBlockModal(false)} style={{
            position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.75)',
            zIndex: 9999, display: 'flex', alignItems: 'center', justifyContent: 'center',
            animation: 'pallasModalFadeIn 0.15s ease',
          }}>
            <div style={{
              background: THEME.card, border: `1px solid ${THEME.border}`,
              borderRadius: 14, padding: 24, width: 520, maxWidth: '92vw',
              boxShadow: '0 24px 80px rgba(0,0,0,0.6)',
              animation: 'pallasModalSlideUp 0.2s cubic-bezier(0.34,1.56,0.64,1)',
            }}>
              {/* Header */}
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 18 }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
                  <div style={{ width: 36, height: 36, borderRadius: 10, background: 'rgba(239,68,68,0.15)', border: '1px solid rgba(239,68,68,0.3)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                    <EuiIcon type="lock" size="m" color="#EF4444" />
                  </div>
                  <div>
                    <div style={{ fontWeight: 700, fontSize: 15, color: THEME.text }}>Block IP</div>
                    <div style={{ fontSize: 11, color: THEME.textMuted, marginTop: 2 }}>
                      Network Firewall (L3/4) + WAF (L7)
                    </div>
                  </div>
                </div>
                <button onClick={() => setShowBlockModal(false)} style={{ background: 'none', border: 'none', color: THEME.textMuted, cursor: 'pointer', fontSize: 20, lineHeight: 1, padding: 4 }}>×</button>
              </div>

              {/* Alert summary */}
              <div style={{ background: 'rgba(255,255,255,0.03)', borderRadius: 8, padding: '10px 14px', marginBottom: 18, border: `1px solid ${THEME.border}` }}>
                <div style={{ fontSize: 12, fontWeight: 600, color: THEME.text, marginBottom: 6 }}>{sigName || 'Alert Details'}</div>
                <div style={{ display: 'flex', gap: 14, flexWrap: 'wrap', fontSize: 11, color: THEME.textMuted }}>
                  <span>Severity: <span style={{ color: sevColor.text, fontWeight: 700 }}>{sev.toUpperCase()}</span></span>
                </div>
              </div>

              {/* IP picker */}
              <div style={{ marginBottom: 16 }}>
                <div style={{ fontSize: 12, fontWeight: 600, color: THEME.text, marginBottom: 8 }}>
                  IP to Block <span style={{ fontWeight: 400, color: THEME.textMuted }}>(public IPs only)</span>
                </div>
                <div style={{ display: 'flex', flexDirection: 'column', gap: 4 }}>
                  {blockIpCandidates.length === 0 && (
                    <div style={{ fontSize: 11, color: THEME.textMuted, padding: '8px 0' }}>
                      No IP observables found on this alert.
                    </div>
                  )}
                  {blockIpCandidates.map(c => (
                    <label key={c.ip} style={{
                      display: 'flex', alignItems: 'center', gap: 10, padding: '8px 12px',
                      borderRadius: 8, cursor: c.isPrivate ? 'not-allowed' : 'pointer',
                      opacity: c.isPrivate ? 0.45 : 1,
                      background: blockSelectedIp === c.ip ? 'rgba(239,68,68,0.08)' : 'transparent',
                      border: `1px solid ${blockSelectedIp === c.ip ? 'rgba(239,68,68,0.3)' : 'transparent'}`,
                    }}
                    title={c.isPrivate ? 'Private IP (RFC1918 / loopback / link-local) — cannot be blocked at perimeter' : c.label}>
                      <input type="radio" name="blockIp"
                        checked={blockSelectedIp === c.ip}
                        disabled={c.isPrivate}
                        onChange={() => !c.isPrivate && setBlockSelectedIp(c.ip)}
                        style={{ accentColor: '#EF4444' }}
                      />
                      <div style={{ flex: 1 }}>
                        <div style={{ fontSize: 12, fontFamily: 'monospace', color: THEME.text }}>
                          {c.ip}
                          {c.isPrivate && <span style={{ marginLeft: 8, fontSize: 10, color: THEME.textMuted, fontFamily: 'inherit' }}>RFC1918</span>}
                        </div>
                        <div style={{ fontSize: 10, color: THEME.textMuted }}>{c.label}</div>
                      </div>
                    </label>
                  ))}
                </div>
                {!hasPublicCandidate && blockIpCandidates.length > 0 && (
                  <div style={{ fontSize: 11, color: '#F59E0B', marginTop: 6 }}>
                    Only private IPs found on this alert — perimeter block not available.
                  </div>
                )}
              </div>

              {/* Threat type */}
              <div style={{ marginBottom: 14 }}>
                <div style={{ fontSize: 12, fontWeight: 600, color: THEME.text, marginBottom: 6 }}>Threat Type</div>
                <select value={blockThreatType} onChange={e => setBlockThreatType(e.target.value)} style={{
                  width: '100%', padding: '8px 12px', background: THEME.bg,
                  border: `1px solid ${THEME.border}`, borderRadius: 8,
                  color: THEME.text, fontSize: 13, outline: 'none', cursor: 'pointer',
                }}>
                  <option value="malware_c2">Malware / C2</option>
                  <option value="scanning">Scanning</option>
                  <option value="brute_force">Brute Force</option>
                  <option value="exploit_attempt">Exploit Attempt</option>
                  <option value="other">Other</option>
                </select>
              </div>

              {/* Duration */}
              <div style={{ marginBottom: 14 }}>
                <div style={{ fontSize: 12, fontWeight: 600, color: THEME.text, marginBottom: 6 }}>Duration</div>
                <select value={blockExpiresHours} onChange={e => setBlockExpiresHours(e.target.value)} style={{
                  width: '100%', padding: '8px 12px', background: THEME.bg,
                  border: `1px solid ${THEME.border}`, borderRadius: 8,
                  color: THEME.text, fontSize: 13, outline: 'none', cursor: 'pointer',
                }}>
                  <option value="">Permanent</option>
                  <option value="168">7 Days</option>
                  <option value="720">30 Days</option>
                  <option value="2160">90 Days</option>
                </select>
              </div>

              {/* Reason */}
              <div style={{ marginBottom: 22 }}>
                <div style={{ fontSize: 12, fontWeight: 600, color: THEME.text, marginBottom: 6 }}>
                  Reason <span style={{ fontWeight: 400, color: THEME.textMuted }}>(required)</span>
                </div>
                <textarea value={blockReason} onChange={e => setBlockReason(e.target.value)}
                  placeholder="e.g. Confirmed RCE attempt — see narrative"
                  rows={2}
                  style={{
                    width: '100%', padding: '8px 12px', background: THEME.bg,
                    border: `1px solid ${THEME.border}`, borderRadius: 8,
                    color: THEME.text, fontSize: 12, outline: 'none', resize: 'vertical',
                    fontFamily: 'inherit',
                  }}/>
              </div>

              {/* Actions */}
              <div style={{ display: 'flex', justifyContent: 'flex-end', gap: 10 }}>
                <button onClick={() => setShowBlockModal(false)} style={{
                  padding: '8px 18px', borderRadius: 8, border: `1px solid ${THEME.border}`,
                  background: 'transparent', color: THEME.textMuted, cursor: 'pointer', fontSize: 12, fontWeight: 500,
                }}>Cancel</button>
                <button onClick={executeBlock} disabled={!canSubmit || actionLoading[`waf:${blockModalAlert.id}`]} style={{
                  padding: '8px 22px', borderRadius: 8, border: 'none',
                  background: canSubmit ? '#EF4444' : THEME.border,
                  color: canSubmit ? '#fff' : THEME.textMuted,
                  cursor: canSubmit ? 'pointer' : 'not-allowed',
                  fontSize: 12, fontWeight: 700, transition: 'all 0.2s',
                  display: 'flex', alignItems: 'center', gap: 6,
                }}>
                  <EuiIcon type="lock" size="s" />
                  {actionLoading[`waf:${blockModalAlert.id}`] ? 'Blocking...' : 'Block IP'}
                </button>
              </div>
            </div>
          </div>
        );
      })()}

      {/* ── Close-with-disposition modal (Mode B only) ── */}
      {showCloseDispoModal && closeDispoAlert && (
        <div onClick={(e) => e.target === e.currentTarget && setShowCloseDispoModal(false)} style={{
          position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.6)', backdropFilter: 'blur(4px)',
          display: 'flex', alignItems: 'center', justifyContent: 'center', zIndex: 1000,
          animation: 'pallasModalFadeIn 0.2s ease',
        }}>
          <div style={{
            background: THEME.card, border: `1px solid ${THEME.border}`, borderRadius: 12,
            padding: '20px 24px', width: '100%', maxWidth: 480, maxHeight: '85vh', overflowY: 'auto',
            boxShadow: '0 20px 50px rgba(0,0,0,0.5)', animation: 'pallasModalSlideUp 0.25s ease',
          }}>
            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 14 }}>
              <h3 style={{ margin: 0, fontSize: 14, fontWeight: 700, color: THEME.text, display: 'flex', alignItems: 'center', gap: 8 }}>
                <EuiIcon type="checkInCircleFilled" size="m" color="#22C55E" /> Close Incident
              </h3>
              <button onClick={() => setShowCloseDispoModal(false)} style={{
                background: 'none', border: 'none', color: THEME.textMuted, cursor: 'pointer',
                fontSize: 20, lineHeight: 1, padding: 4,
              }}>×</button>
            </div>

            <div style={{ marginBottom: 14, fontSize: 11, color: THEME.textMuted }}>
              Select a disposition for the audit trail. Required.
            </div>

            {/* If analyst opened Close meaning to dismiss as FP, point them to
                the dedicated False Positive button. FP isn't a disposition of
                Close — it has its own endpoint (/dismiss-fp), its own status
                (false_positive vs closed), and its own audit shape (fp_reason +
                fp_dismissed_by). Letting FP appear here too creates two paths
                to "this alert was noise" with different backend records and
                breaks reporting. */}
            <div style={{
              marginBottom: 14, padding: '8px 12px', borderRadius: 6,
              background: 'rgba(245,158,11,0.08)', border: '1px solid rgba(245,158,11,0.25)',
              fontSize: 10, color: '#F59E0B', lineHeight: 1.5,
            }}>
              <strong>Note:</strong> If this alert was a false positive (detection rule fired
              incorrectly), close this dialog and use the <strong>False Positive</strong> button instead —
              it routes to a different audit trail.
            </div>

            <div style={{ display: 'flex', flexDirection: 'column', gap: 8, marginBottom: 16 }}>
              {[
                { key: 'resolved', label: 'Resolved', hint: 'Real incident, action taken, threat addressed' },
                { key: 'benign',   label: 'Benign',   hint: 'Real activity, but authorized / expected behavior' },
                { key: 'other',    label: 'Other',    hint: 'See notes below for details' },
              ].map(opt => {
                const selected = closeDispoChoice === opt.key;
                return (
                  <label key={opt.key} style={{
                    display: 'flex', alignItems: 'flex-start', gap: 10, cursor: 'pointer',
                    padding: '10px 12px', borderRadius: 8,
                    border: `1px solid ${selected ? '#22C55E' : THEME.border}`,
                    background: selected ? 'rgba(34,197,94,0.08)' : 'transparent',
                    transition: 'all 0.15s',
                  }}>
                    <input
                      type="radio"
                      name="close-dispo"
                      value={opt.key}
                      checked={selected}
                      onChange={() => setCloseDispoChoice(opt.key)}
                      style={{ accentColor: '#22C55E', marginTop: 2, cursor: 'pointer' }}
                    />
                    <div>
                      <div style={{ fontSize: 12, fontWeight: 600, color: THEME.text }}>{opt.label}</div>
                      <div style={{ fontSize: 10, color: THEME.textMuted, marginTop: 2 }}>{opt.hint}</div>
                    </div>
                  </label>
                );
              })}
            </div>

            <div style={{ marginBottom: 16 }}>
              <label style={{ display: 'block', fontSize: 11, color: THEME.textMuted, marginBottom: 6 }}>
                Notes {closeDispoChoice === 'other' && <span style={{ color: '#EF4444' }}>(required)</span>}
              </label>
              <textarea
                value={closeDispoNotes}
                onChange={(e) => setCloseDispoNotes(e.target.value)}
                placeholder="Additional context for the audit trail..."
                rows={3}
                style={{
                  width: '100%', padding: '10px 12px', borderRadius: 8,
                  border: `1px solid ${THEME.border}`, background: 'transparent',
                  color: THEME.text, fontSize: 12, fontFamily: 'inherit', resize: 'vertical',
                  outline: 'none', boxSizing: 'border-box',
                }}
              />
            </div>

            <div style={{ display: 'flex', justifyContent: 'flex-end', gap: 10 }}>
              <button onClick={() => setShowCloseDispoModal(false)} style={{
                padding: '8px 18px', borderRadius: 8, border: `1px solid ${THEME.border}`,
                background: 'transparent', color: THEME.textMuted, cursor: 'pointer', fontSize: 12, fontWeight: 500,
              }}>Cancel</button>
              {(() => {
                const canSubmit = closeDispoChoice !== 'other' || closeDispoNotes.trim().length > 0;
                return (
                  <button onClick={executeCloseDisposition} disabled={!canSubmit || actionLoading[`close:${closeDispoAlert.id}`]} style={{
                    padding: '8px 22px', borderRadius: 8, border: 'none',
                    background: canSubmit ? '#22C55E' : THEME.border,
                    color: canSubmit ? '#fff' : THEME.textMuted,
                    cursor: canSubmit ? 'pointer' : 'not-allowed',
                    fontSize: 12, fontWeight: 700, transition: 'all 0.2s',
                    display: 'flex', alignItems: 'center', gap: 6,
                  }}>
                    <EuiIcon type="checkInCircleFilled" size="s" />
                    {actionLoading[`close:${closeDispoAlert.id}`] ? 'Closing...' : 'Close Incident'}
                  </button>
                );
              })()}
            </div>
          </div>
        </div>
      )}

      {/* ── Bulk Mute Modal ──
          Variant of the per-alert mute modal. Conditions are pre-derived from
          the group's signature key (rule_id + src_ip) so the analyst doesn't
          have to pick — they just confirm classification. The single new mute
          rule will match any future alert with the same pattern. */}
      {/* RE-ENABLE NEXT RELEASE — Bulk Mute modal returns with Agelia */}
      {!HIDE_MUTE && showBulkMuteModal && bulkMuteGroup && (
        <div onClick={(e) => e.target === e.currentTarget && setShowBulkMuteModal(false)} style={{
          position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.6)', backdropFilter: 'blur(4px)',
          display: 'flex', alignItems: 'center', justifyContent: 'center', zIndex: 1000,
          animation: 'pallasModalFadeIn 0.2s ease',
        }}>
          <div style={{
            background: THEME.card, border: `1px solid ${THEME.border}`, borderRadius: 12,
            padding: '20px 24px', width: '100%', maxWidth: 480,
            boxShadow: '0 20px 50px rgba(0,0,0,0.5)', animation: 'pallasModalSlideUp 0.25s ease',
          }}>
            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 14 }}>
              <h3 style={{ margin: 0, fontSize: 14, fontWeight: 700, color: THEME.text, display: 'flex', alignItems: 'center', gap: 8 }}>
                <EuiIcon type="bellSlash" size="m" color="#FBBF24" /> Mute pattern — {bulkMuteGroup.count} alerts
              </h3>
              <button onClick={() => setShowBulkMuteModal(false)} style={{
                background: 'none', border: 'none', color: THEME.textMuted, cursor: 'pointer',
                fontSize: 20, lineHeight: 1, padding: 4,
              }}>×</button>
            </div>

            <div style={{ marginBottom: 14, fontSize: 12, color: THEME.textMuted, lineHeight: 1.5 }}>
              This will create one mute rule for the pattern below and mark all {bulkMuteGroup.count}
              alerts in the group as muted. Future alerts matching the same pattern will be muted automatically.
            </div>

            <div style={{
              padding: 12, marginBottom: 16,
              background: THEME.bgDeep, border: `1px solid ${THEME.border}`, borderRadius: 8,
              fontSize: 12, fontFamily: FONT.mono,
            }}>
              {bulkMuteGroup.rule_id && <div>rule_id = <span style={{ color: THEME.warning }}>{String(bulkMuteGroup.rule_id)}</span></div>}
              {bulkMuteGroup.src_ip && <div>source_ip = <span style={{ color: THEME.warning }}>{String(bulkMuteGroup.src_ip)}</span></div>}
              {bulkMuteGroup.source && <div style={{ color: THEME.textMuted }}>source = {String(bulkMuteGroup.source)}</div>}
            </div>

            <div style={{ marginBottom: 16 }}>
              <label style={{ display: 'block', fontSize: 11, color: THEME.textMuted, marginBottom: 6 }}>
                Classification
              </label>
              <select
                value={bulkMuteClassification}
                onChange={(e) => setBulkMuteClassification(e.target.value)}
                style={{
                  width: '100%', padding: '8px 12px', borderRadius: 8,
                  border: `1px solid ${THEME.border}`, background: THEME.bgDeep,
                  color: THEME.text, fontSize: 13, fontFamily: 'inherit', outline: 'none',
                }}>
                <option value="false_positive">False Positive — pattern is not real</option>
                <option value="true_positive">True Positive — real but suppressed</option>
                <option value="benign">Benign — authorized activity</option>
              </select>
            </div>

            <div style={{ display: 'flex', justifyContent: 'flex-end', gap: 10 }}>
              <button onClick={() => setShowBulkMuteModal(false)} style={{
                padding: '8px 18px', borderRadius: 8, border: `1px solid ${THEME.border}`,
                background: 'transparent', color: THEME.textMuted, cursor: 'pointer', fontSize: 12, fontWeight: 500,
              }}>Cancel</button>
              <button onClick={executeBulkMute} style={{
                padding: '8px 22px', borderRadius: 8, border: 'none',
                background: '#FBBF24', color: '#000', cursor: 'pointer',
                fontSize: 12, fontWeight: 700, display: 'flex', alignItems: 'center', gap: 6,
              }}>
                <EuiIcon type="bellSlash" size="s" /> Mute {bulkMuteGroup.count} alerts
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ── Bulk Close Modal ──
          Same disposition picker as the per-alert close, but operates on
          every alert in the selected group. */}
      {showBulkCloseModal && bulkMuteGroup && (
        <div onClick={(e) => e.target === e.currentTarget && setShowBulkCloseModal(false)} style={{
          position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.6)', backdropFilter: 'blur(4px)',
          display: 'flex', alignItems: 'center', justifyContent: 'center', zIndex: 1000,
          animation: 'pallasModalFadeIn 0.2s ease',
        }}>
          <div style={{
            background: THEME.card, border: `1px solid ${THEME.border}`, borderRadius: 12,
            padding: '20px 24px', width: '100%', maxWidth: 480, maxHeight: '85vh', overflowY: 'auto',
            boxShadow: '0 20px 50px rgba(0,0,0,0.5)', animation: 'pallasModalSlideUp 0.25s ease',
          }}>
            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 14 }}>
              <h3 style={{ margin: 0, fontSize: 14, fontWeight: 700, color: THEME.text, display: 'flex', alignItems: 'center', gap: 8 }}>
                <EuiIcon type="checkInCircleFilled" size="m" color="#22C55E" /> Close {bulkMuteGroup.count} alerts
              </h3>
              <button onClick={() => setShowBulkCloseModal(false)} style={{
                background: 'none', border: 'none', color: THEME.textMuted, cursor: 'pointer',
                fontSize: 20, lineHeight: 1, padding: 4,
              }}>×</button>
            </div>

            <div style={{ marginBottom: 14, fontSize: 11, color: THEME.textMuted }}>
              Pick a disposition to apply to every alert in this group. Required.
            </div>

            <div style={{ display: 'flex', flexDirection: 'column', gap: 8, marginBottom: 16 }}>
              {[
                { key: 'resolved',       label: 'Resolved',       hint: 'Real incident, action taken, threat addressed' },
                { key: 'false_positive', label: 'False Positive', hint: 'Alert was wrong — no real threat existed' },
                { key: 'benign',         label: 'Benign',         hint: 'Real activity, but authorized / harmless' },
                { key: 'other',          label: 'Other',          hint: 'See notes below for details' },
              ].map(opt => {
                const selected = bulkCloseDispo === opt.key;
                return (
                  <label key={opt.key} style={{
                    display: 'flex', alignItems: 'flex-start', gap: 10, cursor: 'pointer',
                    padding: '10px 12px', borderRadius: 8,
                    border: `1px solid ${selected ? '#22C55E' : THEME.border}`,
                    background: selected ? 'rgba(34,197,94,0.08)' : 'transparent',
                    transition: 'all 0.15s',
                  }}>
                    <input
                      type="radio"
                      name="bulk-close-dispo"
                      value={opt.key}
                      checked={selected}
                      onChange={() => setBulkCloseDispo(opt.key)}
                      style={{ accentColor: '#22C55E', marginTop: 2, cursor: 'pointer' }}
                    />
                    <div>
                      <div style={{ fontSize: 12, fontWeight: 600, color: THEME.text }}>{opt.label}</div>
                      <div style={{ fontSize: 10, color: THEME.textMuted, marginTop: 2 }}>{opt.hint}</div>
                    </div>
                  </label>
                );
              })}
            </div>

            <div style={{ marginBottom: 16 }}>
              <label style={{ display: 'block', fontSize: 11, color: THEME.textMuted, marginBottom: 6 }}>
                Notes {bulkCloseDispo === 'other' && <span style={{ color: '#EF4444' }}>(required)</span>}
              </label>
              <textarea
                value={bulkCloseNotes}
                onChange={(e) => setBulkCloseNotes(e.target.value)}
                placeholder="Additional context for the audit trail (applies to all alerts in this group)..."
                rows={3}
                style={{
                  width: '100%', padding: '10px 12px', borderRadius: 8,
                  border: `1px solid ${THEME.border}`, background: 'transparent',
                  color: THEME.text, fontSize: 12, fontFamily: 'inherit', resize: 'vertical',
                  outline: 'none', boxSizing: 'border-box',
                }}
              />
            </div>

            <div style={{ display: 'flex', justifyContent: 'flex-end', gap: 10 }}>
              <button onClick={() => setShowBulkCloseModal(false)} style={{
                padding: '8px 18px', borderRadius: 8, border: `1px solid ${THEME.border}`,
                background: 'transparent', color: THEME.textMuted, cursor: 'pointer', fontSize: 12, fontWeight: 500,
              }}>Cancel</button>
              {(() => {
                const canSubmit = bulkCloseDispo !== 'other' || bulkCloseNotes.trim().length > 0;
                return (
                  <button onClick={executeBulkClose} disabled={!canSubmit} style={{
                    padding: '8px 22px', borderRadius: 8, border: 'none',
                    background: canSubmit ? '#22C55E' : THEME.border,
                    color: canSubmit ? '#fff' : THEME.textMuted,
                    cursor: canSubmit ? 'pointer' : 'not-allowed',
                    fontSize: 12, fontWeight: 700, display: 'flex', alignItems: 'center', gap: 6,
                  }}>
                    <EuiIcon type="checkInCircleFilled" size="s" />
                    Close {bulkMuteGroup.count} alerts
                  </button>
                );
              })()}
            </div>
          </div>
        </div>
      )}

      {/* ── Animation keyframes ── */}
      <style>{`
        @keyframes pallasModalFadeIn { from { opacity: 0; } to { opacity: 1; } }
        @keyframes pallasModalSlideUp { from { opacity: 0; transform: translateY(20px) scale(0.97); } to { opacity: 1; transform: translateY(0) scale(1); } }
      `}</style>
    </div>
  );
}
