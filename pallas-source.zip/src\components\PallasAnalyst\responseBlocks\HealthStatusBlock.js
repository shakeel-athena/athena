/**
 * HealthStatusBlock — SVG donut chart for infrastructure / agent health
 *
 * Replaces "Agent Health: 🔴 8% online" plain-text rendering with a donut
 * chart showing the proportion of healthy vs degraded vs offline.
 *
 * Features:
 *   - Hand-rolled SVG donut (no external chart libs)
 *   - Animated stroke-dasharray fill on mount (clockwise sweep)
 *   - Center number animates from 0 to percentage
 *   - Color-coded segments: green (active) / amber (disconnected) / muted (never)
 *   - Legend on the right with counts and matching colors
 *   - Warning indicator if percentage < 50% (visibility gap)
 *   - Responsive: stacks legend below donut on narrow screens
 *
 * Data shape (from BlockParser):
 *   {
 *     label: 'Agent Health',
 *     percentage: 8,
 *     total: 49,           // optional
 *     active: 4,           // optional
 *     disconnected: 42,    // optional
 *     neverConnected: 2,   // optional
 *   }
 */

import { useState, useEffect } from 'react';
import { EuiIcon } from '@elastic/eui';
import { THEME, GRADIENTS, SHADOWS, GLOWS, TIMINGS } from '../../../utils/theme';
import { FONT } from '../PallasUI';
import {
  useAnimatedCounter,
  useReducedMotion,
  useContainerWidth,
  formatNumber,
} from './blockHelpers';

// ─── Donut geometry ─────────────────────────────────────────────────────────
// The SVG uses viewBox so this size is logical, not pixel. The actual rendered
// size depends on the container: 140px stacked, 180px side-by-side, 220px hero.

const DONUT_VIEW_SIZE = 140;
const DONUT_RADIUS = 50;
const DONUT_STROKE = 14;
const DONUT_CIRCUMFERENCE = 2 * Math.PI * DONUT_RADIUS;

// Layout breakpoints: stacked (<480) → horizontal (≥480) → hero (≥820)
const BP_HORIZONTAL = 480;
const BP_HERO       = 820;

// ─── Segment renderer (one segment of the donut) ────────────────────────────

function DonutSegment({ offset, length, color, total, mounted }) {
  // stroke-dasharray: visible portion + gap (rest of circle)
  // stroke-dashoffset: rotates the segment around the circle
  // We start with length=0 and animate to the real length
  const visible = mounted ? length : 0;
  return (
    <circle
      cx={DONUT_VIEW_SIZE / 2}
      cy={DONUT_VIEW_SIZE / 2}
      r={DONUT_RADIUS}
      fill="none"
      stroke={color}
      strokeWidth={DONUT_STROKE}
      strokeLinecap="butt"
      strokeDasharray={`${visible} ${DONUT_CIRCUMFERENCE}`}
      strokeDashoffset={-offset}
      transform={`rotate(-90 ${DONUT_VIEW_SIZE / 2} ${DONUT_VIEW_SIZE / 2})`}
      style={{
        transition: `stroke-dasharray ${TIMINGS.slowest} cubic-bezier(0.34, 1.1, 0.64, 1)`,
        filter: `drop-shadow(0 0 4px ${color}50)`,
      }}
    />
  );
}

// ─── Component ──────────────────────────────────────────────────────────────

export default function HealthStatusBlock({ data }) {
  const reduced = useReducedMotion();
  const [mounted, setMounted] = useState(false);
  const [containerRef, containerWidth] = useContainerWidth();

  // Three layout tiers.
  //   stacked   : narrow mobile — donut above legend
  //   horizontal: tablet-ish   — donut beside legend (compact)
  //   hero      : wide desktop — big donut + legend grid + summary tile
  const useStackedLayout = containerWidth > 0 && containerWidth < BP_HORIZONTAL;
  const useHeroLayout    = containerWidth >= BP_HERO;
  const donutPixelSize   = useHeroLayout ? 220 : (useStackedLayout ? 160 : 150);

  useEffect(() => {
    if (reduced) {
      setMounted(true);
      return;
    }
    const id = requestAnimationFrame(() => setMounted(true));
    return () => cancelAnimationFrame(id);
  }, [reduced]);

  const label = data?.label || 'Agent Health';
  const percentage = Math.max(0, Math.min(100, Number(data?.percentage) || 0));
  const animatedPct = useAnimatedCounter(Math.round(percentage), 900);

  // Build the segments array. If we have explicit counts, use them; otherwise
  // synthesize from the percentage alone (single active vs degraded segment).
  let segments;
  let total = data?.total;

  if (data?.total && (data?.active != null || data?.disconnected != null)) {
    const active = data.active || 0;
    const disconnected = data.disconnected || 0;
    const never = data.neverConnected || 0;
    total = data.total || active + disconnected + never;
    segments = [];
    if (active > 0)       segments.push({ key: 'active',       label: 'Active',         count: active,        color: THEME.success    });
    if (disconnected > 0) segments.push({ key: 'disconnected', label: 'Disconnected',   count: disconnected,  color: THEME.warning    });
    if (never > 0)        segments.push({ key: 'never',        label: 'Never Connected',count: never,         color: THEME.textMuted  });
  } else {
    // Just percentage → 2-segment donut (active vs degraded)
    const activeFrac = percentage / 100;
    segments = [
      { key: 'active',  label: 'Active',  count: Math.round(percentage),       color: THEME.success, fraction: activeFrac },
      { key: 'offline', label: 'Offline', count: Math.round(100 - percentage), color: THEME.warning, fraction: 1 - activeFrac },
    ];
    total = 100;
  }

  // Determine status color from percentage (used for center text + warning)
  const statusColor =
    percentage >= 90 ? THEME.success :
    percentage >= 70 ? THEME.success :
    percentage >= 50 ? THEME.warning :
    THEME.danger;

  const isGap = percentage < 50;

  // Calculate offsets so segments butt up against each other
  let offsetCursor = 0;
  const segmentRenders = segments.map((s) => {
    const fraction = s.fraction != null ? s.fraction : (total > 0 ? s.count / total : 0);
    const length = fraction * DONUT_CIRCUMFERENCE;
    const render = (
      <DonutSegment
        key={s.key}
        offset={offsetCursor}
        length={length}
        color={s.color}
        total={total}
        mounted={mounted}
      />
    );
    offsetCursor += length;
    return render;
  });

  return (
    <div
      ref={containerRef}
      style={{
        margin: '14px 0',
        background: GRADIENTS.card,
        border: `1px solid ${THEME.border}`,
        borderRadius: 12,
        padding: '14px 18px',
        boxShadow: SHADOWS.md + ", inset 0 1px 0 rgba(255,255,255,0.04)",
      }}
    >
      {/* Title row */}
      <div
        style={{
          display: 'flex',
          alignItems: 'center',
          gap: 10,
          marginBottom: 10,
        }}
      >
        <span
          style={{
            width: 3,
            height: 14,
            background: GRADIENTS.primaryAccent,
            borderRadius: 2,
            flexShrink: 0,
          }}
        />
        <h4
          style={{
            margin: 0,
            fontSize: 12,
            fontWeight: 700,
            color: THEME.textSecondary,
            textTransform: 'uppercase',
            letterSpacing: '0.05em',
          }}
        >
          {label}
        </h4>
      </div>

      {/* Donut + Legend + (hero) Summary Tile */}
      <div
        style={{
          display: 'grid',
          gridTemplateColumns: useHeroLayout
            ? `${donutPixelSize}px minmax(0, 1fr) minmax(220px, 1fr)`
            : useStackedLayout
              ? '1fr'
              : `${donutPixelSize}px minmax(0, 1fr)`,
          alignItems: 'center',
          gap: useStackedLayout ? 16 : useHeroLayout ? 28 : 24,
        }}
      >
        {/* Donut SVG */}
        <div
          style={{
            position: 'relative',
            width: donutPixelSize,
            height: donutPixelSize,
            flexShrink: 0,
            justifySelf: useStackedLayout ? 'center' : 'start',
          }}
        >
          <svg
            viewBox={`0 0 ${DONUT_VIEW_SIZE} ${DONUT_VIEW_SIZE}`}
            style={{ display: 'block', width: '100%', height: '100%', overflow: 'visible' }}
            aria-label={`${label}: ${Math.round(percentage)}% online`}
          >
            {/* Background ring (full circle, faint) */}
            <circle
              cx={DONUT_VIEW_SIZE / 2}
              cy={DONUT_VIEW_SIZE / 2}
              r={DONUT_RADIUS}
              fill="none"
              stroke={THEME.border}
              strokeWidth={DONUT_STROKE}
              opacity="0.3"
            />
            {/* Animated segments */}
            {segmentRenders}
          </svg>

          {/* Center text overlay — font sizes scale with donut */}
          <div
            style={{
              position: 'absolute',
              inset: 0,
              display: 'flex',
              flexDirection: 'column',
              alignItems: 'center',
              justifyContent: 'center',
              pointerEvents: 'none',
            }}
          >
            <span
              style={{
                fontSize: useHeroLayout ? 42 : 26,
                fontWeight: 800,
                fontFamily: FONT.mono,
                color: statusColor,
                lineHeight: 1,
                textShadow: `0 0 16px ${statusColor}70`,
                transition: `color ${TIMINGS.slow} ${TIMINGS.ease}`,
              }}
            >
              {animatedPct}%
            </span>
            <span
              style={{
                fontSize: useHeroLayout ? 11 : 9,
                fontWeight: 700,
                color: THEME.textMuted,
                textTransform: 'uppercase',
                letterSpacing: '0.08em',
                marginTop: useHeroLayout ? 4 : 2,
              }}
            >
              ONLINE
            </span>
            {data?.total != null && (
              <span
                style={{
                  fontSize: useHeroLayout ? 11 : 9,
                  color: THEME.textFaint,
                  fontFamily: FONT.mono,
                  marginTop: 1,
                }}
              >
                of {data.total}
              </span>
            )}
          </div>
        </div>

        {/* Legend */}
        <div
          style={{
            display: 'flex',
            flexDirection: 'column',
            gap: useHeroLayout ? 12 : 8,
            minWidth: 0,
            width: useStackedLayout ? '100%' : 'auto',
          }}
        >
          {segments.map((s) => (
            <LegendRow
              key={s.key}
              color={s.color}
              label={s.label}
              count={s.count}
              total={total}
              large={useHeroLayout}
            />
          ))}

          {/* In non-hero layouts, the gap warning lives inline under legend rows */}
          {!useHeroLayout && isGap && (
            <div
              style={{
                marginTop: 6,
                padding: '8px 12px',
                borderRadius: 6,
                border: `1px solid ${THEME.danger}40`,
                background: `${THEME.danger}10`,
                display: 'flex',
                alignItems: 'center',
                gap: 8,
                boxShadow: GLOWS.danger,
              }}
            >
              <EuiIcon type="warning" size="s" color={THEME.danger} />
              <span style={{ fontSize: 11, color: THEME.danger, fontWeight: 600 }}>
                Critical visibility gap
              </span>
            </div>
          )}
        </div>

        {/* Hero summary tile — only shown at ≥820px container width */}
        {useHeroLayout && (
          <HeroSummaryTile
            percentage={percentage}
            total={data?.total}
            active={data?.active}
            disconnected={data?.disconnected}
            neverConnected={data?.neverConnected}
            statusColor={statusColor}
            isGap={isGap}
          />
        )}
      </div>
    </div>
  );
}

// ─── HeroSummaryTile ────────────────────────────────────────────────────────
// Wide-screen companion card: surfaces the most urgent derived facts so the
// user can act without scrolling — disconnected count, availability SLI,
// visibility-gap call-out, and the primary CTA.

function HeroSummaryTile({ percentage, total, active, disconnected, neverConnected, statusColor, isGap }) {
  const unseenCount = (disconnected || 0) + (neverConnected || 0);
  const activeFloat = typeof active === 'number' ? active : Math.round((percentage / 100) * (total || 0));
  return (
    <div
      style={{
        background: isGap ? `${THEME.danger}0C` : `${statusColor}0A`,
        border: `1px solid ${isGap ? `${THEME.danger}40` : `${statusColor}30`}`,
        borderRadius: 10,
        padding: '14px 16px',
        display: 'flex',
        flexDirection: 'column',
        gap: 10,
        minHeight: 140,
        justifySelf: 'stretch',
        boxShadow: isGap ? GLOWS.danger : 'none',
      }}
    >
      <div
        style={{
          display: 'flex',
          alignItems: 'center',
          gap: 8,
          color: isGap ? THEME.danger : statusColor,
        }}
      >
        <EuiIcon type={isGap ? 'warning' : 'checkInCircleFilled'} size="m" />
        <span
          style={{
            fontSize: 11,
            fontWeight: 800,
            textTransform: 'uppercase',
            letterSpacing: '0.06em',
          }}
        >
          {isGap ? 'Critical Visibility Gap' : 'Fleet Healthy'}
        </span>
      </div>

      <div
        style={{
          fontSize: 12,
          color: THEME.textSecondary,
          lineHeight: 1.5,
        }}
      >
        {isGap ? (
          <>
            Only <b style={{ color: THEME.text, fontFamily: FONT.mono }}>{activeFloat}</b>{' '}
            of <b style={{ color: THEME.text, fontFamily: FONT.mono }}>{total || '—'}</b> agents
            are reporting.{' '}
            {unseenCount > 0 && (
              <>
                <b style={{ color: THEME.danger, fontFamily: FONT.mono }}>{unseenCount}</b>{' '}
                agent{unseenCount === 1 ? '' : 's'} need immediate triage.
              </>
            )}
          </>
        ) : (
          <>
            <b style={{ color: THEME.text, fontFamily: FONT.mono }}>{activeFloat}</b>{' '}
            of <b style={{ color: THEME.text, fontFamily: FONT.mono }}>{total || '—'}</b> agents
            are online. Availability SLI is meeting target.
          </>
        )}
      </div>

      {/* Mini KPI row */}
      <div
        style={{
          display: 'grid',
          gridTemplateColumns: '1fr 1fr',
          gap: 8,
          marginTop: 'auto',
        }}
      >
        <MiniKPI label="Online" value={activeFloat} color={THEME.success} />
        <MiniKPI label="Offline" value={unseenCount} color={isGap ? THEME.danger : THEME.warning} />
      </div>
    </div>
  );
}

function MiniKPI({ label, value, color }) {
  return (
    <div
      style={{
        padding: '8px 10px',
        borderRadius: 8,
        background: 'rgba(255,255,255,0.02)',
        border: `1px solid ${THEME.border}`,
        display: 'flex',
        flexDirection: 'column',
        gap: 2,
      }}
    >
      <span
        style={{
          fontSize: 9,
          fontWeight: 700,
          color: THEME.textMuted,
          textTransform: 'uppercase',
          letterSpacing: '0.06em',
        }}
      >
        {label}
      </span>
      <span
        style={{
          fontSize: 18,
          fontWeight: 800,
          fontFamily: FONT.mono,
          color,
          lineHeight: 1,
        }}
      >
        {formatNumber(value)}
      </span>
    </div>
  );
}

// ─── Legend row sub-component ───────────────────────────────────────────────

function LegendRow({ color, label, count, total, large }) {
  const animated = useAnimatedCounter(count, 800);
  const pct = total > 0 ? Math.round((count / total) * 1000) / 10 : 0;
  const pctFraction = total > 0 ? (count / total) * 100 : 0;
  return (
    <div
      style={{
        display: 'grid',
        gridTemplateColumns: 'auto minmax(0, 1fr) auto auto',
        alignItems: 'center',
        gap: large ? 12 : 10,
        fontSize: large ? 13 : 12,
      }}
    >
      <span
        style={{
          width: large ? 12 : 10,
          height: large ? 12 : 10,
          borderRadius: 3,
          background: `linear-gradient(135deg, ${color}, ${color}b0)`,
          boxShadow: `0 0 6px ${color}50`,
          flexShrink: 0,
        }}
      />
      <div
        style={{
          display: 'flex',
          flexDirection: 'column',
          minWidth: 0,
          gap: large ? 4 : 0,
        }}
      >
        <span
          style={{
            color: THEME.textSecondary,
            overflow: 'hidden',
            textOverflow: 'ellipsis',
            whiteSpace: 'nowrap',
            fontWeight: large ? 600 : 500,
          }}
        >
          {label}
        </span>
        {large && (
          <div
            style={{
              height: 4,
              borderRadius: 2,
              background: 'rgba(255,255,255,0.05)',
              overflow: 'hidden',
            }}
          >
            <div
              style={{
                width: `${pctFraction}%`,
                height: '100%',
                background: `linear-gradient(90deg, ${color}, ${color}a0)`,
                transition: `width 900ms cubic-bezier(0.34, 1.1, 0.64, 1)`,
              }}
            />
          </div>
        )}
      </div>
      <span
        style={{
          fontFamily: FONT.mono,
          fontSize: large ? 15 : 13,
          fontWeight: 700,
          color: THEME.text,
          textAlign: 'right',
          minWidth: large ? 44 : 32,
        }}
      >
        {formatNumber(animated)}
      </span>
      <span
        style={{
          fontFamily: FONT.mono,
          fontSize: large ? 11 : 10,
          color: THEME.textMuted,
          minWidth: large ? 52 : 44,
          textAlign: 'right',
        }}
      >
        {pct.toFixed(1)}%
      </span>
    </div>
  );
}
