/**
 * Athena Unified Theme — Ageleia Design System
 *
 * Single source of truth for ALL dark-theme colors across:
 *   - Threat Topology main page
 *   - ZoneSummaryModal / AgentDetailModal
 *   - Pallas SOC Chat + tool views
 *   - Response renderer block components
 *
 * Aligned with Ageleia's enhanced theme tokens (see version1.1.02/src/styles/enhanced-theme.css).
 * Pallas and Ageleia now share identical brand colors so the two apps feel like one product.
 *
 * Import as: import { THEME, GRADIENTS, SHADOWS, GLOWS, TIMINGS } from '../utils/theme';
 */

// ─── Core Palette ────────────────────────────────────────────────────────────

export const THEME = {
  // ───── Backgrounds (shared with Ageleia) ─────
  bg:           '#151519',   // Page / modal panel background
  bgDeep:       '#0E0E11',   // Canvas / deepest layer
  card:         '#1D1E24',   // Card / panel surface
  cardDark:     '#151519',   // Same as bg — flat sections / tab containers
  cardSubtle:   '#1D1E24',   // Same as card — meta bars, table headers
  cardHover:    '#25262E',   // Hover state — slightly lighter than card

  // ───── Borders (shared with Ageleia) ─────
  border:       '#2A2B33',   // Standard border / divider
  borderLight:  '#35363F',   // Active / lighter border
  borderSubtle: '#1D1E24',   // Same as card — subtle row dividers
  borderFaint:  '#151519',   // Same as bg — faintest divider

  // ───── Text ─────
  text:         '#ffffff',   // Primary text
  textBright:   '#e8f0ff',   // Bright emphasis
  textSecondary:'#8e9fbc',   // Secondary / labels
  textMuted:    '#5a6d8a',   // Muted (metadata, timestamps)
  textFaint:    '#3d5070',   // Faint (disabled-ish)
  textDisabled: '#2a3a54',   // Disabled

  // ───── Brand Accent Colors (Ageleia palette) ─────
  primary:      '#3b82f6',   // Ageleia primary blue (Tailwind blue-500)
  primaryDark:  '#2563eb',   // Ageleia primary dark (blue-600)
  primaryLight: '#60a5fa',   // Ageleia primary light (blue-400)

  accent:       '#e2e8f0',   // Clean white-silver accent (slate-200)
  accentDark:   '#cbd5e1',   // Slightly darker silver (slate-300)

  success:      '#10b981',   // Ageleia success green (emerald-500)
  successDark:  '#059669',   // Ageleia success dark (emerald-600)
  successLight: '#7de2d1',   // Light cyan (legacy alias)

  danger:       '#ef4444',   // Ageleia danger red (red-500)
  dangerDark:   '#dc2626',   // Ageleia danger dark (red-600)

  warning:      '#f59e0b',   // Ageleia warning amber (amber-500)
  warningDark:  '#d97706',   // Ageleia warning dark (amber-600)
  warningYellow:'#fec514',   // Yellow (legacy)

  // ───── Severity (shared with Ageleia, kept consistent) ─────
  sevCritical:  '#EF4444',   // Red
  sevHigh:      '#F97316',   // Orange
  sevMedium:    '#F59E0B',   // Amber
  sevLow:       '#64748B',   // Slate

  // ───── Status (shared with Ageleia) ─────
  statusActive:       '#10B981',
  statusDisconnected: '#F59E0B',
  statusInactive:     '#6B7280',

  // ───── Glow color strings (used as colors in box-shadow / inset shadow) ─────
  // NOTE: These are bare rgba color values, NOT full box-shadow strings.
  // Components use them like: boxShadow: `0 0 16px ${THEME.primaryGlow}`
  primaryGlow:  'rgba(59, 130, 246, 0.5)',   // Ageleia blue glow
  accentGlow:   'rgba(226, 232, 240, 0.3)',   // Silver glow
  successGlow:  'rgba(16, 185, 129, 0.5)',   // Ageleia green glow
  dangerGlow:   'rgba(239, 68, 68, 0.5)',    // Ageleia red glow
  warningGlow:  'rgba(245, 158, 11, 0.5)',   // Ageleia amber glow

  // ───── Pallas-specific shadows ─────
  panelShadow:  '-8px 0 32px rgba(0, 0, 0, 0.6)',
  backdropBg:   'rgba(0, 0, 0, 0.5)',
};

// ─── Ageleia Gradients ───────────────────────────────────────────────────────
// Use these for backgrounds, buttons, accent bars, and chart fills.
// They give Pallas the same enterprise look as Ageleia panels.

export const GRADIENTS = {
  // Brand gradients (135deg = top-left to bottom-right)
  primary:           'linear-gradient(135deg, #3b82f6, #2563eb)',
  primaryHorizontal: 'linear-gradient(90deg, #3b82f6, #2563eb)',
  primaryAccent:     'linear-gradient(135deg, #3b82f6, #60a5fa)',  // Blue gradient (primary → light)
  accent:            'linear-gradient(135deg, #e2e8f0, #cbd5e1)',  // Silver gradient
  success:           'linear-gradient(135deg, #10b981, #059669)',
  warning:           'linear-gradient(135deg, #f59e0b, #d97706)',
  danger:            'linear-gradient(135deg, #ef4444, #dc2626)',

  // Card backgrounds (Ageleia signature)
  card:              'linear-gradient(145deg, rgba(29, 30, 36, 0.95), rgba(29, 30, 36, 0.85))',
  bgFull:            'linear-gradient(135deg, #151519 0%, #1D1E24 50%, #151519 100%)',

  // Special-purpose gradients
  cveBadge:          'linear-gradient(135deg, rgba(245, 167, 0, 0.3), rgba(245, 167, 0, 0.1))',
  titleText:         'linear-gradient(135deg, #f8fafc, #cbd5e1)',  // metallic title text effect

  // Severity gradients (for stacked bars, severity badges)
  sevCritical:       'linear-gradient(135deg, #ef4444, #dc2626)',
  sevHigh:           'linear-gradient(135deg, #f97316, #ea580c)',
  sevMedium:         'linear-gradient(135deg, #f59e0b, #d97706)',
  sevLow:            'linear-gradient(135deg, #64748b, #475569)',
};

// ─── Ageleia Shadows ─────────────────────────────────────────────────────────
// Use as boxShadow values directly: style={{ boxShadow: SHADOWS.md }}

export const SHADOWS = {
  sm: '0 1px 2px 0 rgba(0, 0, 0, 0.3)',
  md: '0 4px 6px -1px rgba(0, 0, 0, 0.4), 0 2px 4px -1px rgba(0, 0, 0, 0.3)',
  lg: '0 10px 15px -3px rgba(0, 0, 0, 0.5), 0 4px 6px -2px rgba(0, 0, 0, 0.4)',
  xl: '0 20px 25px -5px rgba(0, 0, 0, 0.5), 0 10px 10px -5px rgba(0, 0, 0, 0.4)',
};

// ─── Ageleia Glow Box-Shadows ────────────────────────────────────────────────
// Full box-shadow strings (different from THEME.*Glow which are color values).
// Use as:  boxShadow: `${SHADOWS.lg}, ${GLOWS.primary}`

export const GLOWS = {
  primary: '0 0 20px rgba(59, 130, 246, 0.3)',
  success: '0 0 20px rgba(16, 185, 129, 0.3)',
  danger:  '0 0 20px rgba(239, 68, 68, 0.3)',
  warning: '0 0 20px rgba(245, 158, 11, 0.3)',
  accent:  '0 0 20px rgba(226, 232, 240, 0.2)',
};

// ─── Animation Timings ───────────────────────────────────────────────────────
// Consistent durations + easing across all redesigned components.

export const TIMINGS = {
  fast:    '0.15s',
  base:    '0.3s',
  slow:    '0.5s',
  slowest: '0.8s',
  ease:    'cubic-bezier(0.4, 0, 0.2, 1)',  // Ageleia's standard easing
};

// ─── Legacy alias (drop-in for NetworkTopology.js AGELIA_COLORS) ─────────────

export const AGELIA_COLORS = {
  background:    THEME.bg,
  panel:         THEME.card,
  panelDark:     THEME.cardDark,
  border:        THEME.border,
  borderLight:   THEME.borderLight,
  text:          THEME.text,
  textSecondary: THEME.textSecondary,
  textMuted:     '#94A3B8',          // Matched to modal secondary text
  primary:       THEME.primary,
  success:       THEME.success,
  successLight:  THEME.successLight,
  danger:        THEME.danger,
  warning:       THEME.warning,
  warningYellow: THEME.warningYellow,
  accent:        THEME.accent,
  accentGlow:    THEME.accentGlow,
  dangerGlow:    THEME.dangerGlow,
  warningGlow:   THEME.warningGlow,
  successGlow:   THEME.successGlow,
  primaryGlow:   THEME.primaryGlow,
};
