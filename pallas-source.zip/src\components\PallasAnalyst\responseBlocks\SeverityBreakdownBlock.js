/**
 * SeverityBreakdownBlock — Horizontal stacked bar for severity distribution
 *
 * Replaces lines like:
 *   "🔴 Critical: 21 | 🟠 High: 188 | 🟡 Medium: 23990 | 🟢 Low: 2008"
 *
 * Renders a single horizontal stacked bar with proportional segments + a
 * legend below. Each segment is clickable to fire a follow-up filter query.
 *
 * Data shape (from BlockParser):
 *   {
 *     segments: [
 *       { label: 'Critical', key: 'critical', value: 21,    color: '#EF4444' },
 *       { label: 'High',     key: 'high',     value: 188,   color: '#F97316' },
 *       ...
 *     ],
 *     total: 26207
 *   }
 */

import { useState, useMemo, useEffect } from 'react';
import { THEME, GRADIENTS, SHADOWS, TIMINGS } from '../../../utils/theme';
import { FONT } from '../PallasUI';
import { useAnimatedCounter, useReducedMotion, formatNumber } from './blockHelpers';

// ─── Map severity key → click pivot query ───────────────────────────────────

function pivotQueryForSeverity(key) {
  switch (key) {
    case 'critical': return 'show critical alerts';
    case 'high':     return 'show high severity alerts';
    case 'medium':   return 'show medium severity alerts';
    case 'low':      return 'show low severity alerts';
    case 'info':
    case 'informational': return 'show informational alerts';
    default: return null;
  }
}

// ─── Single segment of the stacked bar ──────────────────────────────────────

function BarSegment({ segment, percentage, isFirst, isLast, hovered, onHover, onLeave, onClick, animated }) {
  return (
    <div
      onMouseEnter={onHover}
      onMouseLeave={onLeave}
      onClick={onClick}
      role={onClick ? 'button' : undefined}
      tabIndex={onClick ? 0 : undefined}
      title={`${segment.label}: ${formatNumber(segment.value)} (${percentage.toFixed(1)}%)`}
      style={{
        width: animated ? `${percentage}%` : '0%',
        height: '100%',
        background: `linear-gradient(180deg, ${segment.color}f0, ${segment.color})`,
        borderTopLeftRadius:    isFirst ? 6 : 0,
        borderBottomLeftRadius: isFirst ? 6 : 0,
        borderTopRightRadius:   isLast  ? 6 : 0,
        borderBottomRightRadius:isLast  ? 6 : 0,
        cursor: onClick ? 'pointer' : 'default',
        transition: `width ${TIMINGS.slowest} ${TIMINGS.ease}, filter ${TIMINGS.fast} ${TIMINGS.ease}, transform ${TIMINGS.fast} ${TIMINGS.ease}`,
        filter: hovered ? `brightness(1.15) drop-shadow(0 0 8px ${segment.color}90)` : 'none',
        transform: hovered ? 'scaleY(1.08)' : 'scaleY(1)',
        transformOrigin: 'center',
        position: 'relative',
        overflow: 'hidden',
      }}
    >
      {/* Progress shine sweep — Ageleia signature */}
      <div
        style={{
          position: 'absolute',
          inset: 0,
          background: 'linear-gradient(90deg, transparent, rgba(255,255,255,0.20), transparent)',
          animation: 'pallas-sweep 2.4s ease-in-out infinite',
          pointerEvents: 'none',
        }}
      />
    </div>
  );
}

// ─── Legend item below the bar ──────────────────────────────────────────────

function LegendItem({ segment, percentage, hovered, onHover, onLeave, onClick }) {
  const animatedCount = useAnimatedCounter(segment.value, 700);

  return (
    <div
      onMouseEnter={onHover}
      onMouseLeave={onLeave}
      onClick={onClick}
      role={onClick ? 'button' : undefined}
      tabIndex={onClick ? 0 : undefined}
      style={{
        display: 'inline-flex',
        alignItems: 'center',
        gap: 8,
        padding: '6px 12px',
        borderRadius: 8,
        background: hovered ? `${segment.color}14` : 'rgba(255,255,255,0.02)',
        border: `1px solid ${hovered ? `${segment.color}60` : THEME.border}`,
        cursor: onClick ? 'pointer' : 'default',
        transition: `all ${TIMINGS.fast} ${TIMINGS.ease}`,
      }}
    >
      <span
        style={{
          width: 10,
          height: 10,
          borderRadius: 3,
          background: `linear-gradient(135deg, ${segment.color}, ${segment.color}c0)`,
          boxShadow: hovered ? `0 0 8px ${segment.color}80` : 'none',
          flexShrink: 0,
          transition: `box-shadow ${TIMINGS.fast} ${TIMINGS.ease}`,
        }}
      />
      <span
        style={{
          fontSize: 11,
          color: THEME.textSecondary,
          fontWeight: 500,
          letterSpacing: '0.02em',
        }}
      >
        {segment.label}
      </span>
      <span
        style={{
          fontSize: 12,
          fontFamily: FONT.mono,
          fontWeight: 700,
          color: THEME.text,
        }}
      >
        {formatNumber(animatedCount)}
      </span>
      <span
        style={{
          fontSize: 10,
          color: THEME.textMuted,
          fontFamily: FONT.mono,
        }}
      >
        ({percentage.toFixed(1)}%)
      </span>
    </div>
  );
}

// ─── SeverityBreakdownBlock ─────────────────────────────────────────────────

export default function SeverityBreakdownBlock({ data, onPivot }) {
  const [hoveredKey, setHoveredKey] = useState(null);
  const reduced = useReducedMotion();
  const [mounted, setMounted] = useState(false);

  // Trigger the bar fill animation on mount (next paint)
  useEffect(() => {
    if (reduced) {
      setMounted(true);
      return;
    }
    const id = requestAnimationFrame(() => setMounted(true));
    return () => cancelAnimationFrame(id);
  }, [reduced]);

  const segments = data?.segments || [];
  const total = data?.total || segments.reduce((a, b) => a + b.value, 0);
  const animatedTotal = useAnimatedCounter(total, 700);

  const segmentsWithPct = useMemo(
    () =>
      segments.map((s) => ({
        ...s,
        percentage: total > 0 ? (s.value / total) * 100 : 0,
      })),
    [segments, total]
  );

  if (segments.length === 0 || total === 0) return null;

  return (
    <div
      style={{
        margin: '14px 0',
        padding: '14px 16px',
        background: GRADIENTS.card,
        border: `1px solid ${THEME.border}`,
        borderRadius: 12,
        boxShadow: SHADOWS.md + ", inset 0 1px 0 rgba(255,255,255,0.04)",
      }}
    >
      {/* Title row */}
      <div
        style={{
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'space-between',
          marginBottom: 12,
          flexWrap: 'wrap',
          gap: 8,
        }}
      >
        <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
          <span
            style={{
              width: 3,
              height: 14,
              background: GRADIENTS.primaryAccent,
              borderRadius: 2,
              flexShrink: 0,
            }}
          />
          <h4
            style={{
              margin: 0,
              fontSize: 12,
              fontWeight: 700,
              color: THEME.textSecondary,
              textTransform: 'uppercase',
              letterSpacing: '0.05em',
            }}
          >
            Severity Distribution
          </h4>
        </div>
        <div
          style={{
            fontSize: 11,
            color: THEME.textMuted,
            fontFamily: FONT.mono,
          }}
        >
          Total: <span style={{ color: THEME.text, fontWeight: 700 }}>{formatNumber(animatedTotal)}</span>
        </div>
      </div>

      {/* The stacked bar */}
      <div
        style={{
          display: 'flex',
          width: '100%',
          height: 18,
          borderRadius: 6,
          overflow: 'hidden',
          background: 'rgba(255,255,255,0.04)',
          border: `1px solid ${THEME.border}`,
          marginBottom: 14,
        }}
      >
        {segmentsWithPct.map((s, idx) => {
          const pivotQuery = pivotQueryForSeverity(s.key);
          const onClick = pivotQuery && typeof onPivot === 'function' ? () => onPivot(pivotQuery) : null;
          return (
            <BarSegment
              key={s.key}
              segment={s}
              percentage={s.percentage}
              isFirst={idx === 0}
              isLast={idx === segmentsWithPct.length - 1}
              hovered={hoveredKey === s.key}
              onHover={() => setHoveredKey(s.key)}
              onLeave={() => setHoveredKey(null)}
              onClick={onClick}
              animated={mounted}
            />
          );
        })}
      </div>

      {/* Legend */}
      <div style={{ display: 'flex', flexWrap: 'wrap', gap: 6 }}>
        {segmentsWithPct.map((s) => {
          const pivotQuery = pivotQueryForSeverity(s.key);
          const onClick = pivotQuery && typeof onPivot === 'function' ? () => onPivot(pivotQuery) : null;
          return (
            <LegendItem
              key={s.key}
              segment={s}
              percentage={s.percentage}
              hovered={hoveredKey === s.key}
              onHover={() => setHoveredKey(s.key)}
              onLeave={() => setHoveredKey(null)}
              onClick={onClick}
            />
          );
        })}
      </div>
    </div>
  );
}
