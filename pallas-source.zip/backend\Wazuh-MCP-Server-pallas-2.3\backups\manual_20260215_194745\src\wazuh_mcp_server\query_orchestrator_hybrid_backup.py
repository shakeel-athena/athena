"""
Query Orchestrator - Hybrid Intelligence System
Combines deterministic rules with LLM fallback for optimal tool selection

ARCHITECTURE:
1. High-confidence regex patterns (95% confidence, 0ms latency)
2. Medium-confidence keyword matching (75% confidence, 0ms latency)
3. LLM fallback for complex queries (variable confidence, 2s latency)
4. Validation layer for all selections
5. Multi-tool correlation with intelligent chaining
6. SOC-grade response formatting

REPLACES: chat_handler.py
INTEGRATES WITH: All 29 MCP tools via tool_registry.py
"""

import re
import logging
import json
import asyncio
from typing import List, Dict, Any, Optional, Tuple
from dataclasses import dataclass, field
from datetime import datetime
import time

from .tool_registry import ToolRegistry, ToolMetadata, ToolCategory
from .correlation_engine import CorrelationEngine, CorrelationResult
from .response_formatter import ResponseFormatter
from .llm_client import OllamaClient

logger = logging.getLogger(__name__)


# ============================================================================
# DATA STRUCTURES
# ============================================================================

@dataclass
class ToolPlan:
    """Tool execution plan with confidence scoring"""
    primary_tool: str
    secondary_tools: List[str] = field(default_factory=list)
    primary_args: Dict[str, Any] = field(default_factory=dict)
    secondary_args: List[Dict[str, Any]] = field(default_factory=list)
    confidence: float = 0.0  # 0.0 to 1.0
    selection_method: str = "unknown"  # "rule_regex", "rule_keyword", "llm", "fallback"
    reasoning: str = ""
    requires_correlation: bool = False
    correlation_strategy: Optional[str] = None


@dataclass
class ExecutionResult:
    """Result of single tool execution"""
    tool_name: str
    arguments: Dict[str, Any]
    success: bool
    data: Optional[Dict[str, Any]]
    error: Optional[str]
    execution_time: float


@dataclass
class QueryContext:
    """Context about the query for logging/analytics"""
    original_query: str
    timestamp: datetime
    user_id: Optional[str] = None
    session_id: Optional[str] = None


# ============================================================================
# HYBRID TOOL SELECTOR - Core Intelligence
# ============================================================================

class HybridToolSelector:
    """
    Hybrid tool selection combining rules and LLM.

    Strategy:
    1. Try high-confidence regex patterns first (fastest, most accurate)
    2. Fall back to keyword matching (fast, good accuracy)
    3. Use LLM for complex/ambiguous queries (slower, handles edge cases)
    4. Validate all selections against tool registry
    5. Learn from usage patterns over time
    """

    def __init__(self, llm_client: OllamaClient):
        self.llm = llm_client

        # Statistics tracking
        self.stats = {
            "rule_regex": 0,
            "rule_keyword": 0,
            "llm": 0,
            "fallback": 0,
            "total": 0
        }

        # ================================================================
        # HIGH-CONFIDENCE PATTERNS (Regex-based, 95%+ confidence)
        # ================================================================
        self.HIGH_CONFIDENCE_PATTERNS = {
            "critical_vulnerability_simple": {
                "patterns": [
                    r"^show\s+(me\s+)?critical\s+(vulnerability|vulnerabilities|cve)",
                    r"^list\s+critical\s+(vulnerability|vulnerabilities|cve)",
                    r"^get\s+critical\s+(vulnerability|vulnerabilities|cve)",
                    r"critical\s+(vulnerability|vulnerabilities|cve)\s*$"
                ],
                "tool": "get_wazuh_critical_vulnerabilities",
                "secondary": ["get_wazuh_agents"],
                "correlation": "vulnerability_with_agents",
                "confidence": 0.95,
                "description": "Simple critical vulnerability query"
            },

            "critical_vulnerability_with_agents": {
                "patterns": [
                    r"critical\s+(vulnerability|vulnerabilities|cve).*\b(agent|host|server|machine|system)",
                    r"\b(agent|host|server|machine|system).*critical\s+(vulnerability|vulnerabilities|cve)",
                    r"critical\s+(vulnerability|vulnerabilities|cve).*\b(affected|associated|related)"
                ],
                "tool": "get_wazuh_critical_vulnerabilities",
                "secondary": ["get_wazuh_agents"],
                "correlation": "vulnerability_with_agents",
                "confidence": 0.97,
                "description": "Critical vulnerabilities with agent correlation"
            },

            "all_vulnerabilities_with_agents": {
                "patterns": [
                    r"(vulnerability|vulnerabilities|cve).*\b(agent|host|server|machine|affected)",
                    r"\b(agent|host|server|machine).*\b(vulnerability|vulnerabilities|cve)",
                    r"(vulnerability|vulnerabilities|cve).*\b(associated|related)\s+with"
                ],
                "tool": "get_wazuh_vulnerabilities",
                "secondary": ["get_wazuh_agents"],
                "correlation": "vulnerability_with_agents",
                "confidence": 0.92,
                "description": "Vulnerabilities with agent details"
            },

            "active_agents_only": {
                "patterns": [
                    r"^(show|list|get)\s+(only\s+)?active\s+agents?",
                    r"^active\s+agents?\s+(only|list)?",
                    r"^(show|list)\s+(me\s+)?(running|online|connected)\s+agents?",
                    r"\bonly\s+active\s+agents?\b"
                ],
                "tool": "get_wazuh_running_agents",
                "secondary": [],
                "confidence": 0.98,
                "description": "Active agents only"
            },


            "agent_ports": {
                "patterns": [
                    r"\b(agent|agents)\b.*\b(open\s+ports?|ports?)\b",
                    r"\b(open\s+ports?|ports?)\b.*\b(agent|agents)\b",
                    r"\b(list|show|get)\b.*\bports?\b.*\bfor\b.*\bagent\b"
                ],
                "tool": "get_agent_ports",
                "secondary": [],
                "confidence": 0.97,
                "description": "Agent open ports query (requires agent_id)"
            },

            "agent_processes": {
                "patterns": [
                    r"\b(agent|agents)\b.*\b(process|processes|running\s+processes)\b",
                    r"\b(process|processes|running\s+processes)\b.*\b(agent|agents)\b",
                    r"\b(list|show|get)\b.*\bprocess(es)?\b.*\bfor\b.*\bagent\b"
                ],
                "tool": "get_agent_processes",
                "secondary": [],
                "confidence": 0.97,
                "description": "Agent processes query (requires agent_id)"
            },

            "agent_configuration": {
                "patterns": [
                    r"\b(agent|agents)\b.*\b(config|configuration)\b",
                    r"\b(config|configuration)\b.*\b(agent|agents)\b",
                    r"\b(get|show)\b.*\bagent\b.*\bconfiguration\b"
                ],
                "tool": "get_agent_configuration",
                "secondary": [],
                "confidence": 0.96,
                "description": "Agent configuration query (requires agent_id)"
            },

            "agent_health": {
                "patterns": [
                    r"\b(check|validate|verify)\b.*\bagent\b.*\b(health|status)\b",
                    r"\bagent\b.*\b(health|heartbeat|keepalive)\b",
                    r"\b(health|heartbeat)\b.*\bagent\b"
                ],
                "tool": "check_agent_health",
                "secondary": [],
                "confidence": 0.95,
                "description": "Agent health query (requires agent_id)"
            },


            "disconnected_agents_only": {
                "patterns": [
                    r"^(show|list|get)\s+(only\s+)?(disconnected|offline|down)\s+agents?",
                    r"^(disconnected|offline|down)\s+agents?\s+(only|list)?",
                    r"\bonly\s+(disconnected|offline|down)\s+agents?\b"
                ],
                "tool": "get_wazuh_agents",
                "args": {"status": "disconnected"},
                "secondary": [],
                "confidence": 0.98,
                "description": "Disconnected agents only"
            },

            "agent_status_with_vulnerabilities": {
                "patterns": [
                    r"agent\s+status.*\b(vulnerability|vulnerabilities|cve)",
                    r"\b(vulnerability|vulnerabilities|cve).*agent\s+status",
                    r"agents?.*\bwith\b.*(vulnerability|vulnerabilities|their\s+cve)"
                ],
                "tool": "get_wazuh_agents",
                "secondary": ["get_wazuh_vulnerabilities"],
                "correlation": "agents_with_vulnerabilities",
                "confidence": 0.93,
                "description": "Agent status with vulnerability correlation"
            },

            "alert_investigation": {
                "patterns": [
                    r"^(show|list|get)\s+(recent\s+)?alerts?",
                    r"^alerts?\s+from\s+(last|past)",
                    r"security\s+(alerts?|incidents?|events?)"
                ],
                "tool": "get_wazuh_alerts",
                "secondary": ["get_wazuh_agents"],
                "correlation": "alerts_with_agents",
                "confidence": 0.90,
                "description": "Security alert investigation"
            },

            "compliance_check": {
                "patterns": [
                    r"\b(pci|pci-dss)\s+(compliance|check|audit)",
                    r"\b(hipaa)\s+(compliance|check|audit)",
                    r"\b(gdpr)\s+(compliance|check|audit)",
                    r"\b(nist)\s+(compliance|check|audit)",
                    r"run\s+(compliance|regulatory)\s+check"
                ],
                "tool": "run_compliance_check",
                "secondary": [],
                "confidence": 0.95,
                "description": "Compliance framework check"
            },

            "system_statistics": {
                "patterns": [
                    r"^(show|get|display)\s+(system\s+)?(statistics|stats|metrics)",
                    r"^(overall|system)\s+(status|health|overview)",
                    r"wazuh\s+(statistics|stats|metrics)"
                ],
                "tool": "get_wazuh_statistics",
                "secondary": [],
                "confidence": 0.92,
                "description": "System statistics"
            }
        }

        # ================================================================
        # MEDIUM-CONFIDENCE PATTERNS (Keyword-based, 70-80% confidence)
        # ================================================================
        self.KEYWORD_PATTERNS = {
            "vulnerability_general": {
                "keywords": ["vulnerability", "vulnerabilities", "cve", "vuln", "patch", "all vulnerabilities"],
                "exclude_keywords": ["critical"],  # Exclude critical to prevent filtering
                "tool": "get_wazuh_vulnerabilities",
                "args": {},  # No severity filter
                "secondary": [],
                "confidence": 0.75,
                "description": "General vulnerability query"
            },

            "alert_general": {
                "keywords": ["alert", "alerts", "detection", "incident", "triggered"],
                "exclude_keywords": [],
                "tool": "get_wazuh_alerts",
                "secondary": [],
                "confidence": 0.75,
                "description": "General alert query"
            },

                        "agent_ports": {
                "keywords": ["port", "ports", "open port", "open ports"],
                "exclude_keywords": ["vulnerability", "cve", "alert"],
                "tool": "get_agent_ports",
                "secondary": [],
                "confidence": 0.82,
                "description": "Agent ports keyword query (requires agent_id)"
            },

            "agent_processes": {
                "keywords": ["process", "processes", "running process", "running processes"],
                "exclude_keywords": ["vulnerability", "cve", "alert"],
                "tool": "get_agent_processes",
                "secondary": [],
                "confidence": 0.82,
                "description": "Agent processes keyword query (requires agent_id)"
            },

            "agent_configuration": {
                "keywords": ["configuration", "config"],
                "exclude_keywords": ["vulnerability", "cve", "alert"],
                "tool": "get_agent_configuration",
                "secondary": [],
                "confidence": 0.80,
                "description": "Agent configuration keyword query (requires agent_id)"
            },

            "agent_health": {
                "keywords": ["health", "heartbeat", "keepalive"],
                "exclude_keywords": ["vulnerability", "cve", "alert"],
                "tool": "check_agent_health",
                "secondary": [],
                "confidence": 0.78,
                "description": "Agent health keyword query (requires agent_id)"
            },

"agent_general": {
                "keywords": ["agent", "agents", "endpoint", "host", "server", "machine"],
                "exclude_keywords": ["active", "disconnected", "offline", "vulnerability", "port", "ports", "process", "processes", "configuration", "config", "health", "heartbeat", "keepalive"],
                "tool": "get_wazuh_agents",
                "secondary": [],
                "confidence": 0.70,
                "description": "General agent query"
            },

            "threat_analysis": {
                "keywords": ["threat", "threats", "ioc", "indicator", "malware"],
                "exclude_keywords": [],
                "tool": "get_top_security_threats",
                "secondary": [],
                "confidence": 0.72,
                "description": "Threat analysis"
            }
        }

        # ================================================================
        # ENTITY EXTRACTION PATTERNS
        # ================================================================
        self.ENTITY_PATTERNS = {
            "severity": r"\b(critical|high|medium|low)\b",
            "agent_id": r"\b(agent[_-]?\d+|[a-z0-9]+-[a-z0-9]+-\d+)\b",
            "cve_id": r"\b(CVE-\d{4}-\d{4,7})\b",
            "status": r"\b(active|disconnected|never_connected|online|offline)\b",
            "time_range": r"\b(?:last|past)\s+(\d+)\s+(hour|day|week|month)s?\b",
            "framework": r"\b(PCI-DSS|PCI|HIPAA|GDPR|NIST|SOX)\b",
            "ip_address": r"\b(?:\d{1,3}\.){3}\d{1,3}\b",
            "level": r"\blevel\s+(\d+)\b"
        }

    async def select_tools(self, query: str, context: Optional[QueryContext] = None) -> ToolPlan:
        """
        Main entry point for hybrid tool selection.

        Execution flow:
        1. Normalize query
        2. Extract entities
        3. Try high-confidence patterns (regex)
        4. Try medium-confidence patterns (keywords)
        5. Fall back to LLM for complex queries
        6. Validate and enrich plan
        7. Return execution plan

        Args:
            query: User's natural language query
            context: Optional context (user, session, etc.)

        Returns:
            ToolPlan with selected tools and arguments
        """

        start_time = time.time()
        query_lower = query.lower().strip()

        # Extract entities (used by all strategies)
        entities = self._extract_entities(query)
        logger.info(f"Extracted entities: {entities}")

        # ================================================================
        # STRATEGY 1: High-Confidence Regex Patterns
        # ================================================================
        for pattern_name, config in self.HIGH_CONFIDENCE_PATTERNS.items():
            for pattern in config.get("patterns", []):
                if re.search(pattern, query_lower):
                    logger.info(f"✅ HIGH-CONFIDENCE MATCH: {pattern_name}")

                    plan = self._build_plan_from_config(
                        config=config,
                        entities=entities,
                        selection_method="rule_regex",
                        reasoning=f"Matched regex pattern: {pattern_name}"
                    )

                    self.stats["rule_regex"] += 1
                    self.stats["total"] += 1

                    selection_time = time.time() - start_time
                    logger.info(f"Tool selection completed in {selection_time*1000:.1f}ms (regex)")

                    return plan

        # ================================================================
        # STRATEGY 2: Medium-Confidence Keyword Patterns
        # ================================================================
        for pattern_name, config in self.KEYWORD_PATTERNS.items():
            # Check if keywords match
            keywords = config.get("keywords", [])
            exclude_keywords = config.get("exclude_keywords", [])

            has_keyword = any(kw in query_lower for kw in keywords)
            has_exclusion = any(ekw in query_lower for ekw in exclude_keywords)

            if has_keyword and not has_exclusion:
                logger.info(f"⚡ KEYWORD MATCH: {pattern_name}")

                plan = self._build_plan_from_config(
                    config=config,
                    entities=entities,
                    selection_method="rule_keyword",
                    reasoning=f"Matched keywords: {pattern_name}"
                )

                self.stats["rule_keyword"] += 1
                self.stats["total"] += 1

                selection_time = time.time() - start_time
                logger.info(f"Tool selection completed in {selection_time*1000:.1f}ms (keyword)")

                return plan

        # ================================================================
        # STRATEGY 3: LLM Fallback (Complex/Ambiguous Queries)
        # ================================================================
        logger.info("🤖 NO RULE MATCH - Consulting LLM for complex query")

        try:
            llm_plan = await self._llm_tool_selection(query, entities)

            # Validate LLM output
            validated_plan = self._validate_and_enrich_plan(llm_plan, query, entities)

            self.stats["llm"] += 1
            self.stats["total"] += 1

            selection_time = time.time() - start_time
            logger.info(f"Tool selection completed in {selection_time*1000:.1f}ms (LLM)")

            return validated_plan

        except Exception as e:
            logger.error(f"LLM tool selection failed: {e}")

            # ================================================================
            # STRATEGY 4: Safe Fallback
            # ================================================================
            logger.warning("⚠️ FALLBACK - Using safe default")

            fallback_plan = ToolPlan(
                primary_tool="get_wazuh_agents",
                secondary_tools=[],
                primary_args={"limit": 50},
                confidence=0.3,
                selection_method="fallback",
                reasoning=f"All strategies failed, using safe default. Error: {str(e)}"
            )

            self.stats["fallback"] += 1
            self.stats["total"] += 1

            return fallback_plan

    def _build_plan_from_config(
        self,
        config: Dict[str, Any],
        entities: Dict[str, Any],
        selection_method: str,
        reasoning: str
    ) -> ToolPlan:
        """Build ToolPlan from pattern configuration"""

        primary_tool = config["tool"]
        secondary_tools = config.get("secondary", [])
        base_args = config.get("args", {})

        # Build primary arguments
        primary_args = self._build_arguments(primary_tool, entities, base_args)

        # Build secondary arguments
        secondary_args = [
            self._build_arguments(tool, entities)
            for tool in secondary_tools
        ]

        # Determine correlation
        requires_correlation = len(secondary_tools) > 0 and config.get("correlation") is not None
        correlation_strategy = config.get("correlation")

        return ToolPlan(
            primary_tool=primary_tool,
            secondary_tools=secondary_tools,
            primary_args=primary_args,
            secondary_args=secondary_args,
            confidence=config.get("confidence", 0.8),
            selection_method=selection_method,
            reasoning=reasoning,
            requires_correlation=requires_correlation,
            correlation_strategy=correlation_strategy
        )

    def _extract_entities(self, query: str) -> Dict[str, Any]:
        """Extract structured entities from query"""

        entities = {}

        for entity_type, pattern in self.ENTITY_PATTERNS.items():
            matches = re.findall(pattern, query, re.IGNORECASE)
            if matches:
                if entity_type == "time_range":
                    # Parse time range into standard format
                    amount, unit = matches[0]
                    entities[entity_type] = f"{amount}{unit[0]}"  # e.g., "24h"

                elif entity_type == "framework":
                    # Normalize framework name
                    framework = matches[0].upper()
                    if framework == "PCI":
                        framework = "PCI-DSS"
                    entities[entity_type] = framework

                elif entity_type == "status":
                    # Normalize status
                    status = matches[0].lower()
                    if status in ["online", "connected"]:
                        status = "active"
                    elif status == "offline":
                        status = "disconnected"
                    entities[entity_type] = status

                else:
                    entities[entity_type] = matches[0]

        # Extra agent_id extraction (numeric IDs like 001) when query mentions 'agent'
        if "agent_id" not in entities:
            m_id = re.search(r"\bagent\s*(?:id)?\s*[:#-]?\s*(\d{1,6})\b", query, re.IGNORECASE)
            if m_id:
                entities["agent_id"] = m_id.group(1).zfill(3) if len(m_id.group(1)) <= 3 else m_id.group(1)

        return entities

    def _build_arguments(
        self,
        tool_name: str,
        entities: Dict[str, Any],
        base_args: Dict[str, Any] = None
    ) -> Dict[str, Any]:
        """Build tool arguments from entities"""

        args = base_args.copy() if base_args else {}

        # Get tool metadata
        tool_meta = ToolRegistry.get_tool(tool_name)
        if not tool_meta:
            logger.warning(f"Tool not found in registry: {tool_name}")
            return args

        schema = tool_meta.input_schema

        # Map entities to arguments based on schema
        if "severity" in entities and "severity" in schema:
            args["severity"] = entities["severity"]

        if "agent_id" in entities and "agent_id" in schema:
            args["agent_id"] = entities["agent_id"]

        if "status" in entities and "status" in schema:
            args["status"] = entities["status"]

        if "time_range" in entities and "time_range" in schema:
            args["time_range"] = entities["time_range"]

        if "framework" in entities and "framework" in schema:
            args["framework"] = entities["framework"]

        if "level" in entities and "level" in schema:
            args["level"] = entities["level"]

        if "cve_id" in entities and "cve_id" in schema:
            args["cve_id"] = entities["cve_id"]

        # Add defaults from schema
        for field, spec in schema.items():
            if field not in args and "default" in spec:
                args[field] = spec["default"]

        return args

    async def _llm_tool_selection(self, query: str, entities: Dict[str, Any]) -> ToolPlan:
        """
        Use LLM for tool selection (complex queries only).

        This is called when:
        - Query doesn't match any regex patterns
        - Query doesn't match keyword patterns
        - Query is complex/novel
        """

        # Build tool list for LLM (limit to prevent token overflow)
        available_tools = ToolRegistry.get_all_tools()

        # Prioritize tools by category for better context
        tool_descriptions = []

        # Add vulnerability tools first (most common)
        vuln_tools = [t for t in available_tools if t.category == ToolCategory.VULNERABILITY_MANAGEMENT]
        for tool in vuln_tools:
            tool_descriptions.append(f"- {tool.name}: {tool.description}")

        # Add agent tools
        agent_tools = [t for t in available_tools if t.category == ToolCategory.AGENT_MANAGEMENT]
        for tool in agent_tools[:3]:  # Limit to top 3
            tool_descriptions.append(f"- {tool.name}: {tool.description}")

        # Add alert tools
        alert_tools = [t for t in available_tools if t.category == ToolCategory.ALERT_MANAGEMENT]
        for tool in alert_tools[:2]:
            tool_descriptions.append(f"- {tool.name}: {tool.description}")

        # Add analysis tools
        analysis_tools = [t for t in available_tools if t.category == ToolCategory.SECURITY_ANALYSIS]
        for tool in analysis_tools[:3]:
            tool_descriptions.append(f"- {tool.name}: {tool.description}")

        tools_text = "\n".join(tool_descriptions[:15])  # Max 15 tools to prevent overflow

        # Structured prompt for tool selection
        system_prompt = """You are a security operations expert selecting appropriate tools to answer queries.
You have access to Wazuh SIEM tools for security monitoring.

RULES:
1. Select 1-3 tools maximum
2. First tool is PRIMARY (main data source)
3. Additional tools are SECONDARY (for enrichment)
4. ONLY select tools from the available list
5. If vulnerabilities + agents mentioned --> select both tools
6. Provide brief reasoning"""

        prompt = f"""AVAILABLE TOOLS:
{tools_text}

EXTRACTED ENTITIES: {json.dumps(entities)}

USER QUERY: "{query}"

Select the most appropriate tools to answer this query.

Respond in JSON format:
{{
    "primary_tool": "exact_tool_name",
    "secondary_tools": ["tool_name"],
    "reasoning": "why these tools",
    "confidence": 0.8
}}

JSON:"""

        try:
            response = await self.llm.generate(
                prompt=prompt,
                system_prompt=system_prompt,
                max_tokens=250,
                temperature=0.1  # Very low temp for consistency
            )

            # Parse JSON from response
            json_match = re.search(r'\{.*\}', response, re.DOTALL)
            if json_match:
                plan_data = json.loads(json_match.group(0))

                return ToolPlan(
                    primary_tool=plan_data.get("primary_tool", "get_wazuh_agents"),
                    secondary_tools=plan_data.get("secondary_tools", []),
                    primary_args={},  # Will be filled by _build_arguments
                    secondary_args=[],
                    confidence=float(plan_data.get("confidence", 0.6)),
                    selection_method="llm",
                    reasoning=plan_data.get("reasoning", "LLM selection")
                )
            else:
                raise ValueError("No JSON found in LLM response")

        except Exception as e:
            logger.error(f"LLM tool selection parsing failed: {e}")
            logger.error(f"LLM response was: {response if 'response' in locals() else 'N/A'}")
            raise

    def _validate_and_enrich_plan(
        self,
        plan: ToolPlan,
        query: str,
        entities: Dict[str, Any]
    ) -> ToolPlan:
        """
        Validate LLM-generated plan and enrich with arguments.

        Validation checks:
        1. Primary tool exists in registry
        2. Secondary tools exist in registry
        3. Tools make sense for the query
        4. Add correlation if needed
        """

        # Check if primary tool exists
        primary_tool_meta = ToolRegistry.get_tool(plan.primary_tool)
        if not primary_tool_meta:
            logger.warning(f"LLM selected invalid primary tool: {plan.primary_tool}")
            # Override with safe default
            plan.primary_tool = "get_wazuh_agents"
            plan.confidence *= 0.5
            plan.reasoning += " [CORRECTED: invalid primary tool]"

        # Check secondary tools
        valid_secondary = []
        for tool in plan.secondary_tools:
            if ToolRegistry.get_tool(tool):
                valid_secondary.append(tool)
            else:
                logger.warning(f"LLM selected invalid secondary tool: {tool}, removing")

        plan.secondary_tools = valid_secondary

        # Build arguments from entities
        plan.primary_args = self._build_arguments(plan.primary_tool, entities)
        plan.secondary_args = [
            self._build_arguments(tool, entities)
            for tool in plan.secondary_tools
        ]

        # Determine correlation strategy
        if plan.secondary_tools:
            correlation = self._infer_correlation_strategy(
                plan.primary_tool,
                plan.secondary_tools
            )
            if correlation:
                plan.requires_correlation = True
                plan.correlation_strategy = correlation

        # Boost confidence if LLM matches known patterns
        if self._llm_matches_known_pattern(query, plan.primary_tool):
            plan.confidence = min(0.9, plan.confidence + 0.15)
            plan.reasoning += " [VALIDATED: matches known pattern]"

        return plan

    def _infer_correlation_strategy(
        self,
        primary_tool: str,
        secondary_tools: List[str]
    ) -> Optional[str]:
        """Infer appropriate correlation strategy from tool combination"""

        # Vulnerability + Agent correlation
        if "vulnerability" in primary_tool.lower() and any("agent" in t.lower() for t in secondary_tools):
            return "vulnerability_with_agents"

        # Agent + Vulnerability correlation
        if "agent" in primary_tool.lower() and any("vulnerability" in t.lower() for t in secondary_tools):
            return "agents_with_vulnerabilities"

        # Alert + Agent correlation
        if "alert" in primary_tool.lower() and any("agent" in t.lower() for t in secondary_tools):
            return "alerts_with_agents"

        return None

    def _llm_matches_known_pattern(self, query: str, selected_tool: str) -> bool:
        """Check if LLM selection matches what rules would have chosen"""

        query_lower = query.lower()

        # Check keyword patterns
        for config in self.KEYWORD_PATTERNS.values():
            if config["tool"] == selected_tool:
                if any(kw in query_lower for kw in config.get("keywords", [])):
                    return True

        return False

    def get_statistics(self) -> Dict[str, Any]:
        """Get tool selection statistics"""

        total = self.stats["total"]
        if total == 0:
            return self.stats

        return {
            **self.stats,
            "percentages": {
                "rule_regex": (self.stats["rule_regex"] / total) * 100,
                "rule_keyword": (self.stats["rule_keyword"] / total) * 100,
                "llm": (self.stats["llm"] / total) * 100,
                "fallback": (self.stats["fallback"] / total) * 100
            }
        }


# ============================================================================
# TOOL EXECUTOR
# ============================================================================

class ToolExecutor:
    """Executes MCP tools with validation and error handling"""

    def __init__(self, mcp_tool_executor):
        """
        Args:
            mcp_tool_executor: Async function that executes MCP tools
                               Signature: async def(tool_name: str, args: dict) -> dict
        """
        self.mcp_tool_executor = mcp_tool_executor

    async def execute(
        self,
        tool_name: str,
        arguments: Dict[str, Any]
    ) -> ExecutionResult:
        """Execute a single tool with validation"""

        # Validate tool exists
        tool_meta = ToolRegistry.get_tool(tool_name)
        if not tool_meta:
            return ExecutionResult(
                tool_name=tool_name,
                arguments=arguments,
                success=False,
                data=None,
                error=f"Unknown tool: {tool_name}",
                execution_time=0.0
            )

        # Validate arguments
        valid, error_msg = ToolRegistry.validate_tool_arguments(tool_name, arguments)
        if not valid:
            return ExecutionResult(
                tool_name=tool_name,
                arguments=arguments,
                success=False,
                data=None,
                error=f"Invalid arguments: {error_msg}",
                execution_time=0.0
            )

        # Execute
        start_time = time.time()

        try:
            logger.info(f"Executing tool: {tool_name} with args: {arguments}")
            result = await self.mcp_tool_executor(tool_name, arguments)
            execution_time = time.time() - start_time

            logger.info(f"✅ Tool {tool_name} completed in {execution_time:.2f}s")

            return ExecutionResult(
                tool_name=tool_name,
                arguments=arguments,
                success=True,
                data=result,
                error=None,
                execution_time=execution_time
            )

        except Exception as e:
            execution_time = time.time() - start_time
            logger.error(f"❌ Tool {tool_name} failed after {execution_time:.2f}s: {e}")

            return ExecutionResult(
                tool_name=tool_name,
                arguments=arguments,
                success=False,
                data=None,
                error=str(e),
                execution_time=execution_time
            )

    async def execute_batch(
        self,
        tool_specs: List[Tuple[str, Dict[str, Any]]]
    ) -> List[ExecutionResult]:
        """Execute multiple tools in parallel"""

        tasks = [self.execute(tool_name, args) for tool_name, args in tool_specs]
        results = await asyncio.gather(*tasks, return_exceptions=False)
        return results


# ============================================================================
# QUERY ORCHESTRATOR - Main Entry Point
# ============================================================================

class QueryOrchestrator:
    """
    Main orchestrator coordinating:
    - Hybrid tool selection (rules + LLM)
    - Multi-tool execution
    - Data correlation
    - LLM analysis
    - Response formatting

    This REPLACES chat_handler.py
    """

    def __init__(self, mcp_tool_executor, ollama_client: OllamaClient):
        """
        Args:
            mcp_tool_executor: Async function to execute MCP tools
            ollama_client: OllamaClient instance for analysis (NOT tool selection)
        """
        self.selector = HybridToolSelector(ollama_client)
        self.executor = ToolExecutor(mcp_tool_executor)
        self.correlator = CorrelationEngine()
        self.formatter = ResponseFormatter()
        self.llm = ollama_client

        logger.info("QueryOrchestrator initialized with hybrid tool selection")


    def _detect_query_intent(self, tool_name: str, user_query: str = "") -> str:
        """Detect query intent from tool name and user query"""
        query_lower = user_query.lower()

        if 'running_agents' in tool_name or 'active' in query_lower:
            return 'active_agents'
        elif 'agent' in tool_name and 'status' in query_lower:
            return 'agent_status'
        elif 'critical_vulnerabilities' in tool_name:
            return 'critical_vulnerabilities'
        elif 'vulnerability' in tool_name:
            return 'vulnerabilities'
        elif 'alert' in tool_name:
            return 'recent_alerts'
        elif 'agent' in tool_name:
            return 'agents'
        else:
            return 'generic'

    async def process_query(self, user_query: str, context: Optional[QueryContext] = None) -> str:
        """
        Process natural language query end-to-end.

        Flow:
        1. Hybrid tool selection (rules + LLM fallback)
        2. Execute primary tool
        3. Execute secondary tools (parallel)
        4. Correlate results
        5. Generate LLM analysis
        6. Format response

        Args:
            user_query: Natural language query
            context: Optional query context

        Returns:
            Formatted markdown response
        """

        total_start = time.time()
        logger.info(f"📝 Processing query: {user_query[:100]}...")

        try:
            # Step 1: Hybrid tool selection
            plan = await self.selector.select_tools(user_query, context)
            logger.info(f"🎯 Tool plan: {plan.primary_tool} + {len(plan.secondary_tools)} secondary")
            logger.info(f"   Confidence: {plan.confidence:.2f}, Method: {plan.selection_method}")

            # Guardrail: Agent deep-dive tools require a specific agent_id
            if plan.primary_tool in ("get_agent_ports", "get_agent_processes", "get_agent_configuration", "check_agent_health"):
                if not plan.primary_args.get("agent_id"):
                    return (
                        "I can do that, but I need the **agent ID** (or exact agent name).\n\n"
                        "Examples:\n"
                        "- `Show open ports for agent 001`\n"
                        "- `List running processes for agent 015`\n"
                        "- `Get configuration for agent 001`\n"
                        "- `Check health for agent 001`"
                    )


            # Step 2: Execute primary tool
            primary_result = await self.executor.execute(
                plan.primary_tool,
                plan.primary_args
            )

            if not primary_result.success:
                return self._format_error_response(primary_result, plan)

            # Step 3: Execute secondary tools (parallel)
            secondary_results = []
            if plan.secondary_tools:
                tool_specs = list(zip(plan.secondary_tools, plan.secondary_args))
                secondary_results = await self.executor.execute_batch(tool_specs)

                # Log failures
                failed = [r for r in secondary_results if not r.success]
                if failed:
                    logger.warning(f"⚠️ {len(failed)} secondary tool(s) failed")

            # Step 4: Correlate results
            correlated_data = None
            if plan.requires_correlation and secondary_results:
                successful_secondary = [r for r in secondary_results if r.success]
                if successful_secondary:
                    try:
                        correlated_data = self.correlator.correlate(

                            strategy=plan.correlation_strategy,
                            primary_result=primary_result.data,
                            secondary_results=[r.data for r in successful_secondary],
                            context={"query": user_query}
                        )
                        logger.info(f"🔗 Correlation applied: {correlated_data.correlation_type}")
                    except Exception as e:
                        logger.error(f"Correlation failed: {e}")

            # Step 5: Generate LLM analysis (optional)
            llm_analysis = None

            # Generate analysis for correlated data
            if correlated_data and len(correlated_data.correlated_data) > 0:
                try:
                    llm_analysis = await self._generate_analysis(plan, correlated_data)
                except Exception as e:
                    logger.warning(f"LLM analysis failed: {e}")

            # ALSO generate analysis for critical vulnerabilities (even without correlation)
            elif "critical" in plan.primary_tool.lower() and "vulnerability" in plan.primary_tool.lower():
                # Extract vulnerability data
                tool_response = primary_result.data
                if "content" in tool_response:
                    import json
                    text_content = tool_response["content"][0].get("text", "{}")
                    try:
                        parsed = json.loads(text_content)
                        vuln_data = parsed.get("data", {}).get("affected_items", [])

                        if vuln_data and len(vuln_data) > 0:
                            # Create a mock CorrelationResult for analysis
                            from .correlation_engine import CorrelationResult
                            mock_correlation = CorrelationResult(
                                correlated_data=vuln_data[:10],  # Top 10
                                summary={"total_vulnerabilities": len(vuln_data), "critical_only": True},
                                correlation_type="critical_vulnerabilities",
                                primary_tool=plan.primary_tool,
                                secondary_tools=[]
                            )
                            try:
                                llm_analysis = await self._generate_analysis(plan, mock_correlation)
                            except Exception as e:
                                logger.warning(f"Critical vuln analysis failed: {e}")
                    except:
                        pass

            # Step 6: Format response
            response = self._format_response(
                plan=plan,
                primary_result=primary_result,
                secondary_results=secondary_results,
                correlated_data=correlated_data,
                llm_analysis=llm_analysis
            )

            total_time = time.time() - total_start
            logger.info(f"✅ Query processed in {total_time:.2f}s")

            # Add execution metadata to response
            response += f"\n\n---\n*Total execution time: {total_time:.2f}s*"

            return response

        except Exception as e:
            logger.error(f"❌ Query processing failed: {e}", exc_info=True)
            return self._format_exception_response(e)

    async def _generate_analysis(
        self,
        plan: ToolPlan,
        correlated_data: CorrelationResult
    ) -> Optional[str]:
        """Generate LLM-powered analysis from correlated data"""

        # Prepare summary for LLM
        summary_lines = [
            f"Query confidence: {plan.confidence:.0%}",
            f"Selection method: {plan.selection_method}",
            f"Total items: {len(correlated_data.correlated_data)}",
            ""
        ]

        # Add correlation summary
        for key, value in correlated_data.summary.items():
            summary_lines.append(f"{key}: {value}")

        # Add sample data (top 5)
        summary_lines.append("\nSample data:")
        for i, item in enumerate(correlated_data.correlated_data[:5], 1):
            if "cve_id" in item:
                summary_lines.append(
                    f"{i}. {item.get('cve_id')} - Severity: {item.get('severity')} - "
                    f"Agent: {item.get('agent', {}).get('name', 'N/A')}"
                )
            elif "rule_description" in item:
                summary_lines.append(
                    f"{i}. Alert Level {item.get('level')} - {item.get('rule_description')[:50]}"
                )
            elif "name" in item:
                summary_lines.append(
                    f"{i}. Agent: {item.get('name')} - Status: {item.get('status')} - "
                    f"Risk: {item.get('risk_score', 'N/A')}"
                )

        data_summary = "\n".join(summary_lines)

        # Determine analysis type
       # if "vulnerability" in plan.primary_tool.lower():
        tool = plan.primary_tool.lower()

        if ("vulnerability" in tool) or ("vulnerabilities" in tool) or ("critical_vulnerabilities" in tool) or ("vulnerability_summary" in tool):
            analysis_type = "vulnerability"
        elif "alert" in plan.primary_tool.lower():
            analysis_type = "alert"
        elif "agent" in plan.primary_tool.lower():
            analysis_type = "agent"
        else:
            analysis_type = "general"

        try:
            analysis = await self.llm.analyze_security_data(
                data_summary=data_summary,
                analysis_type=analysis_type
            )
            return analysis
        except Exception as e:
            logger.warning(f"LLM analysis generation failed: {e}")
            return None

    def _format_response(
        self,
        plan: ToolPlan,
        primary_result: ExecutionResult,
        secondary_results: List[ExecutionResult],
        correlated_data: Optional[CorrelationResult],
        llm_analysis: Optional[str]
    ) -> str:
        """Format final response - FIXED with exact tool matching"""

        # Extract data from MCP tool response structure
        import json
        
        tool_response = primary_result.data
        
        if "content" in tool_response and len(tool_response["content"]) > 0:
            text_content = tool_response["content"][0].get("text", "{}")
            try:
                parsed = json.loads(text_content)
                raw_data = parsed.get("data", {})
            except json.JSONDecodeError:
                raw_data = {}
        else:
            raw_data = tool_response.get("data", {})
        
        data = raw_data.get("affected_items", [])
        summary = {"total_items": len(data), "tool": primary_result.tool_name}

        logger.info(f"📊 DATA: {len(data)} items from {primary_result.tool_name}")

        # Override with correlation if available
        if correlated_data and hasattr(correlated_data, "correlated_data"):
            if correlated_data.correlated_data:
                logger.info(f"📊 Using correlation: {len(correlated_data.correlated_data)} items")
                data = correlated_data.correlated_data
                summary = correlated_data.summary

        # FIXED: Use EXACT tool name matching (not substring!)
        tool_name = plan.primary_tool
        
        logger.info(f"🎯 ROUTING for tool: {tool_name}")
        
        # Vulnerability tools
        if tool_name in ["get_wazuh_vulnerabilities", "get_wazuh_critical_vulnerabilities", "get_wazuh_vulnerability_summary"]:
            logger.info(f"🔴 → VULNERABILITY formatter")
            response = self.formatter.format_vulnerability_response(
                correlated_data=data,
                summary=summary,
                include_remediation=True
            )
        
        # Agent tools
        elif tool_name in ["get_wazuh_agents", "get_wazuh_running_agents", "check_agent_health"]:
            logger.info(f"💻 → AGENT formatter")
            status_filter = plan.primary_args.get("status")
            response = self.formatter.format_agent_status_response(
                correlated_data=data,
                summary=summary,
                status_filter=status_filter
            )
        
        # Alert tools
        elif tool_name in ["get_wazuh_alerts", "get_wazuh_alert_summary", "analyze_alert_patterns", "search_security_events"]:
            logger.info(f"🚨 → ALERT formatter")
            response = self.formatter.format_alert_response(
                correlated_data=data,
                summary=summary
            )
        
        # Process/Port tools
        elif tool_name == "get_agent_processes":
            logger.info(f"⚙️ → PROCESS formatter")
            response = f"## 🔧 Running Processes on Agent {plan.primary_args.get('agent_id', 'N/A')}\n\n"
            if data:
                response += "| PID | Name | CMD |\n|-----|------|-----|\n"
                for proc in data[:20]:
                    pid = proc.get('pid', 'N/A')
                    name = proc.get('name', 'N/A')
                    cmd = str(proc.get('cmd', 'N/A'))[:50]
                    response += f"| {pid} | {name} | {cmd} |\n"
            else:
                response += "No process data available\n"
        
        elif tool_name == "get_agent_ports":
            logger.info(f"🔌 → PORT formatter")
            response = f"## 🔌 Open Ports on Agent {plan.primary_args.get('agent_id', 'N/A')}\n\n"
            if data:
                response += "| Port | Protocol | State | Process |\n|------|----------|-------|---------|\n"
                for port in data[:20]:
                    port_num = port.get('local', {}).get('port', 'N/A')
                    protocol = port.get('protocol', 'N/A')
                    state = port.get('state', 'N/A')
                    process = port.get('process', 'N/A')
                    response += f"| {port_num} | {protocol} | {state} | {process} |\n"
            else:
                response += "No port data available\n"
        
        # Statistics tools
        elif "statistics" in tool_name.lower() or "stats" in tool_name.lower():
            logger.info(f"📈 → STATISTICS formatter")
            response = self.formatter.format_statistics_response(
                correlated_data=primary_result.data,
                summary=summary
            )
        
        # Unknown tools - use general formatter
        else:
            logger.warning(f"⚠️ → GENERAL formatter (unknown tool: {tool_name})")
            response = self.formatter.format_general_response(
                data=primary_result.data,
                title="Query Results"
            )

        # Add LLM analysis if available
        if llm_analysis:
            response += f"\n\n### 🔍 Security Analysis\n{llm_analysis}\n"

        # Add metadata footer
        response += "\n---\n"
        response += f"*Selection: {plan.selection_method} ({plan.confidence:.0%} confidence)*\n"
        response += f"*Primary tool: {primary_result.tool_name} ({primary_result.execution_time:.2f}s)*\n"

        if plan.secondary_tools:
            successful_secondary = [r for r in secondary_results if r.success]
            response += f"*Secondary tools: {len(successful_secondary)}/{len(plan.secondary_tools)} successful*\n"

        if correlated_data:
            response += f"*Correlation: {correlated_data.correlation_type}*\n"

        return response

    def _format_error_response(self, result: ExecutionResult, plan: ToolPlan) -> str:
        """Format error response"""

        return f"""## ⚠️ Tool Execution Error

**Tool**: {result.tool_name}
**Arguments**: {result.arguments}
**Error**: {result.error}

**Selection Details**:
- Method: {plan.selection_method}
- Confidence: {plan.confidence:.0%}
- Reasoning: {plan.reasoning}

**Troubleshooting**:
1. Check Wazuh server connectivity
2. Verify Wazuh Indexer is configured (for vulnerability/alert data)
3. Ensure tool arguments are valid
4. Check server logs for details

Please try:
- Rephrasing your query
- Using a simpler query
- Checking system status: "validate wazuh connection"

If the issue persists, contact support."""

    def _format_exception_response(self, exception: Exception) -> str:
        """Format exception response"""

        return f"""## ❌ System Error

An unexpected error occurred while processing your query.

**Error**: {str(exception)}

**What to try**:
1. Simplify your query
2. Try a different phrasing
3. Check system connectivity
4. Review server logs

**Examples of working queries**:
- "Show me critical vulnerabilities"
- "List all active agents"
- "Get security alerts from last 24 hours"

If the problem continues, please contact support."""

    def get_statistics(self) -> Dict[str, Any]:
        """Get orchestrator statistics"""

        return {
            "tool_selection": self.selector.get_statistics(),
            "timestamp": datetime.now().isoformat()
        }


# ============================================================================
# FACTORY FUNCTION
# ============================================================================

async def create_orchestrator(mcp_tool_executor) -> QueryOrchestrator:
    """
    Factory function to create and initialize orchestrator.

    Args:
        mcp_tool_executor: MCP tool executor function

    Returns:
        Initialized QueryOrchestrator with hybrid intelligence
    """

    import os

    # Initialize Ollama client
    ollama_host = os.getenv("OLLAMA_HOST", "http://localhost:11434")
    ollama_model = os.getenv("OLLAMA_MODEL", "qwen2.5:14b-instruct")

    ollama_client = OllamaClient(host=ollama_host, model=ollama_model)
    await ollama_client.initialize()

    # Create orchestrator
    orchestrator = QueryOrchestrator(
        mcp_tool_executor=mcp_tool_executor,
        ollama_client=ollama_client
    )

    logger.info("✅ QueryOrchestrator initialized with hybrid tool selection")
    logger.info(f"   LLM: {ollama_model} at {ollama_host}")
    logger.info(f"   Strategy: Rules first (fast), LLM fallback (flexible)")

    return orchestrator


## 🎯 **Key Features of This Hybrid Implementation**

### **1. Three-Tier Selection Strategy**`
