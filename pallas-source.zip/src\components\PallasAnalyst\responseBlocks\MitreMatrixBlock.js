/**
 * MitreMatrixBlock — Tactic × Technique heatmap for MITRE ATT&CK coverage
 *
 * Replaces flat MITRE coverage tables with a column-per-tactic visualization
 * mimicking the official ATT&CK Navigator layout (but condensed for inline
 * use). Each cell is a technique, color-coded by alert count.
 *
 * Two render modes (auto-picked by container width):
 *   1. **Heatmap mode** (≥700px container) — full tactics × techniques grid
 *   2. **Compact mode** (<700px) — tactic chips with inline technique counts
 *
 * Data shape (from BlockParser):
 *   {
 *     tactics: [
 *       {
 *         id: 'TA0001',
 *         name: 'Initial Access',
 *         techniques: [
 *           { id: 'T1190', name: 'Exploit Public-Facing Application', count: 12 },
 *           { id: 'T1133', name: 'External Remote Services',          count: 5 },
 *         ]
 *       },
 *       ...
 *     ],
 *     totalTechniques: 8,
 *     totalAlerts: 47
 *   }
 *
 * If only a flat list of techniques is available (no tactic grouping), they
 * fall under an "Uncategorized" tactic column.
 */

import { useState, useMemo } from 'react';
import { EuiIcon } from '@elastic/eui';
import { THEME, GRADIENTS, SHADOWS, TIMINGS } from '../../../utils/theme';
import { FONT } from '../PallasUI';
import { useContainerWidth, formatNumber } from './blockHelpers';

// ─── Heat color: count → color along amber → red gradient ──────────────────

function heatColor(count, max) {
  if (!count || count <= 0) return THEME.border;
  const pct = max > 0 ? count / max : 0;
  if (pct >= 0.75) return THEME.sevCritical;
  if (pct >= 0.50) return THEME.sevHigh;
  if (pct >= 0.25) return THEME.sevMedium;
  return THEME.primary;
}

function heatBg(count, max) {
  if (!count || count <= 0) return 'rgba(255,255,255,0.02)';
  const pct = max > 0 ? count / max : 0;
  if (pct >= 0.75) return 'rgba(239, 68, 68, 0.20)';
  if (pct >= 0.50) return 'rgba(249, 115, 22, 0.18)';
  if (pct >= 0.25) return 'rgba(245, 158, 11, 0.15)';
  return 'rgba(59, 130, 246, 0.12)';
}

// ─── Single technique cell ──────────────────────────────────────────────────

function TechniqueCell({ technique, max, onPivot }) {
  const [hovered, setHovered] = useState(false);
  const color = heatColor(technique.count, max);
  const bg = heatBg(technique.count, max);
  const url = `https://attack.mitre.org/techniques/${technique.id.toUpperCase()}/`;

  const handleClick = (e) => {
    e.stopPropagation();
    window.open(url, '_blank', 'noopener');
  };

  return (
    <div
      onMouseEnter={() => setHovered(true)}
      onMouseLeave={() => setHovered(false)}
      onClick={handleClick}
      role="button"
      tabIndex={0}
      onKeyDown={(e) => {
        if (e.key === 'Enter' || e.key === ' ') {
          e.preventDefault();
          handleClick(e);
        }
      }}
      title={`${technique.id} — ${technique.name || 'Unknown'} · ${technique.count} alert${technique.count === 1 ? '' : 's'} · click for ATT&CK Navigator`}
      style={{
        padding: '6px 8px',
        borderRadius: 5,
        background: hovered ? `${color}28` : bg,
        border: `1px solid ${hovered ? color : `${color}40`}`,
        cursor: 'pointer',
        transition: `all ${TIMINGS.fast} ${TIMINGS.ease}`,
        display: 'flex',
        flexDirection: 'column',
        gap: 2,
        minHeight: 42,
        boxShadow: hovered ? `0 0 8px ${color}50` : 'none',
        transform: hovered ? 'translateY(-1px)' : 'translateY(0)',
      }}
    >
      <span
        style={{
          fontFamily: FONT.mono,
          fontSize: 10,
          fontWeight: 700,
          color,
          letterSpacing: '0.02em',
          lineHeight: 1.1,
        }}
      >
        {technique.id}
      </span>
      <div
        style={{
          display: 'flex',
          alignItems: 'baseline',
          justifyContent: 'space-between',
          gap: 4,
        }}
      >
        <span
          style={{
            fontSize: 9,
            color: THEME.textSecondary,
            lineHeight: 1.15,
            overflow: 'hidden',
            textOverflow: 'ellipsis',
            whiteSpace: 'nowrap',
            maxWidth: '70%',
          }}
        >
          {technique.name || ''}
        </span>
        {technique.count > 0 && (
          <span
            style={{
              fontFamily: FONT.mono,
              fontSize: 11,
              fontWeight: 800,
              color,
              flexShrink: 0,
            }}
          >
            {formatNumber(technique.count)}
          </span>
        )}
      </div>
    </div>
  );
}

// ─── Tactic column (heatmap mode) ───────────────────────────────────────────

function TacticColumn({ tactic, max, onPivot }) {
  const techniques = tactic.techniques || [];
  const tacticTotal = techniques.reduce((sum, t) => sum + (t.count || 0), 0);

  return (
    <div
      style={{
        display: 'flex',
        flexDirection: 'column',
        gap: 4,
        minWidth: 0,
      }}
    >
      {/* Tactic header */}
      <div
        style={{
          padding: '6px 8px',
          borderRadius: 5,
          background: GRADIENTS.primaryAccent,
          color: '#fff',
          fontSize: 10,
          fontWeight: 700,
          textAlign: 'center',
          boxShadow: SHADOWS.md + ", inset 0 1px 0 rgba(255,255,255,0.04)",
          marginBottom: 2,
        }}
        title={`${tactic.id || ''} — ${tactic.name} · ${tacticTotal} total alerts`}
      >
        <div style={{ letterSpacing: '0.02em', textTransform: 'uppercase' }}>
          {tactic.name}
        </div>
        {tactic.id && (
          <div
            style={{
              fontFamily: FONT.mono,
              fontSize: 9,
              fontWeight: 600,
              opacity: 0.9,
              marginTop: 1,
            }}
          >
            {tactic.id}
          </div>
        )}
      </div>

      {/* Techniques in this tactic */}
      {techniques.map((t, idx) => (
        <TechniqueCell
          key={`${t.id}-${idx}`}
          technique={t}
          max={max}
          onPivot={onPivot}
        />
      ))}
    </div>
  );
}

// ─── Compact mode (narrow container) ────────────────────────────────────────

function CompactTactic({ tactic, max, onPivot }) {
  const [expanded, setExpanded] = useState(false);
  const techniques = tactic.techniques || [];
  const total = techniques.reduce((sum, t) => sum + (t.count || 0), 0);
  const color = heatColor(total, max);

  return (
    <div
      style={{
        background: 'rgba(255,255,255,0.02)',
        border: `1px solid ${THEME.border}`,
        borderRadius: 8,
        marginBottom: 6,
        overflow: 'hidden',
      }}
    >
      <button
        onClick={() => setExpanded(!expanded)}
        style={{
          width: '100%',
          padding: '8px 12px',
          background: 'transparent',
          border: 'none',
          display: 'flex',
          alignItems: 'center',
          gap: 8,
          cursor: 'pointer',
          color: THEME.text,
          fontFamily: 'inherit',
          textAlign: 'left',
        }}
      >
        <EuiIcon type={expanded ? 'arrowDown' : 'arrowRight'} size="s" color={THEME.textMuted} />
        <span
          style={{
            flex: 1,
            fontSize: 12,
            fontWeight: 600,
            color: THEME.text,
          }}
        >
          {tactic.name}
        </span>
        {tactic.id && (
          <span
            style={{
              fontFamily: FONT.mono,
              fontSize: 10,
              color: THEME.textMuted,
            }}
          >
            {tactic.id}
          </span>
        )}
        <span
          style={{
            fontFamily: FONT.mono,
            fontSize: 11,
            fontWeight: 700,
            color,
            padding: '2px 8px',
            borderRadius: 4,
            background: `${color}18`,
            border: `1px solid ${color}40`,
            minWidth: 32,
            textAlign: 'center',
          }}
        >
          {formatNumber(total)}
        </span>
      </button>
      {expanded && (
        <div style={{ padding: '4px 8px 10px', display: 'flex', flexDirection: 'column', gap: 4 }}>
          {techniques.map((t, idx) => (
            <TechniqueCell
              key={`${t.id}-${idx}`}
              technique={t}
              max={max}
              onPivot={onPivot}
            />
          ))}
        </div>
      )}
    </div>
  );
}

// ─── Main component ────────────────────────────────────────────────────────

export default function MitreMatrixBlock({ data, onPivot }) {
  const [containerRef, containerWidth] = useContainerWidth();
  const compact = containerWidth > 0 && containerWidth < 700;

  const tactics = data?.tactics || [];

  // Find the maximum technique count for color scaling
  const maxCount = useMemo(() => {
    let max = 0;
    for (const tactic of tactics) {
      for (const t of tactic.techniques || []) {
        if ((t.count || 0) > max) max = t.count;
      }
    }
    return max;
  }, [tactics]);

  const totalAlerts = useMemo(
    () => tactics.reduce((s, t) => s + (t.techniques || []).reduce((ss, x) => ss + (x.count || 0), 0), 0),
    [tactics]
  );
  const totalTechniques = useMemo(
    () => tactics.reduce((s, t) => s + (t.techniques?.length || 0), 0),
    [tactics]
  );

  if (tactics.length === 0) return null;

  return (
    <div
      ref={containerRef}
      style={{
        margin: '14px 0',
        background: GRADIENTS.card,
        border: `1px solid ${THEME.border}`,
        borderRadius: 12,
        padding: '14px 16px',
        boxShadow: SHADOWS.md + ", inset 0 1px 0 rgba(255,255,255,0.04)",
      }}
    >
      {/* Header */}
      <div
        style={{
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'space-between',
          marginBottom: 12,
          flexWrap: 'wrap',
          gap: 8,
        }}
      >
        <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
          <span
            style={{
              width: 3,
              height: 14,
              background: GRADIENTS.primaryAccent,
              borderRadius: 2,
              flexShrink: 0,
            }}
          />
          <h4
            style={{
              margin: 0,
              fontSize: 12,
              fontWeight: 700,
              color: THEME.textSecondary,
              textTransform: 'uppercase',
              letterSpacing: '0.05em',
            }}
          >
            MITRE ATT&amp;CK Coverage
          </h4>
        </div>
        <div
          style={{
            display: 'flex',
            gap: 12,
            fontFamily: FONT.mono,
            fontSize: 11,
            color: THEME.textMuted,
          }}
        >
          <span>
            {tactics.length} <span style={{ color: THEME.textFaint }}>tactics</span>
          </span>
          <span>
            {totalTechniques} <span style={{ color: THEME.textFaint }}>techniques</span>
          </span>
          <span>
            {formatNumber(totalAlerts)} <span style={{ color: THEME.textFaint }}>alerts</span>
          </span>
        </div>
      </div>

      {compact ? (
        <div>
          {tactics.map((tactic, idx) => (
            <CompactTactic
              key={`tactic-${idx}`}
              tactic={tactic}
              max={maxCount}
              onPivot={onPivot}
            />
          ))}
        </div>
      ) : (
        <div
          className="pallas-scrollbar"
          style={{
            overflowX: 'auto',
            paddingBottom: 4,
          }}
        >
          <div
            style={{
              display: 'grid',
              gridTemplateColumns: `repeat(${tactics.length}, minmax(140px, 1fr))`,
              gap: 8,
              minWidth: tactics.length * 144,
            }}
          >
            {tactics.map((tactic, idx) => (
              <TacticColumn
                key={`tactic-${idx}`}
                tactic={tactic}
                max={maxCount}
                onPivot={onPivot}
              />
            ))}
          </div>
        </div>
      )}

      {/* Heat scale legend */}
      <div
        style={{
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'flex-end',
          gap: 8,
          marginTop: 10,
          fontSize: 10,
          color: THEME.textMuted,
        }}
      >
        <span>Heat:</span>
        <div style={{ display: 'flex', alignItems: 'center', gap: 2 }}>
          {[0.1, 0.3, 0.5, 0.75, 1].map((p) => (
            <div
              key={p}
              style={{
                width: 14,
                height: 8,
                background: heatColor(p * (maxCount || 1), maxCount || 1),
                borderRadius: 1,
                opacity: p === 0.1 ? 0.5 : 1,
              }}
            />
          ))}
        </div>
        <span style={{ fontFamily: FONT.mono }}>
          1 → {formatNumber(maxCount)}
        </span>
      </div>
    </div>
  );
}
