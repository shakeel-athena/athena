"""
LLM Client - Ollama integration for analysis and synthesis
Used ONLY for generating insights, NOT for tool selection
"""

import httpx
import logging
from typing import Optional, Dict, Any
import asyncio

logger = logging.getLogger(__name__)


class OllamaClient:
    """
    Thin wrapper for Ollama API.
    Used exclusively for analysis generation, not tool orchestration.
    """
    
    def __init__(self, host: str = "http://localhost:11434", model: str = "qwen2.5:14b-instruct"):
        self.host = host
        self.model = model
        self.client: Optional[httpx.AsyncClient] = None
        self._initialized = False
    
    async def initialize(self):
        """Initialize HTTP client"""
        self.client = httpx.AsyncClient(timeout=180.0)
        self._initialized = True
        logger.info(f"OllamaClient initialized: {self.host} - {self.model}")
    
    async def _ensure_initialized(self):
        """Ensure client is initialized"""
        if not self._initialized:
            await self.initialize()
    
    async def generate(
        self,
        prompt: str,
        max_tokens: int = 500,
        temperature: float = 0.3,
        system_prompt: Optional[str] = None
    ) -> str:
        """
        Generate text from prompt.
        
        Args:
            prompt: User prompt
            max_tokens: Max tokens to generate
            temperature: Sampling temperature (lower = more deterministic)
            system_prompt: Optional system prompt
        
        Returns:
            Generated text
        """
        await self._ensure_initialized()
        
        try:
            payload = {
                "model": self.model,
                "prompt": prompt,
                "stream": False,
                "options": {
                    "temperature": temperature,
                    "num_predict": max_tokens,
                    "stop": ["</response>", "\n\n\n"]  # Stop sequences
                }
            }
            
            if system_prompt:
                payload["system"] = system_prompt
            
            response = await self.client.post(
                f"{self.host}/api/generate",
                json=payload
            )
            response.raise_for_status()
            
            data = response.json()
            generated_text = data.get("response", "").strip()
            
            logger.debug(f"Generated {len(generated_text)} characters")
            return generated_text
        
        except httpx.TimeoutException:
            logger.error("Ollama request timed out")
            raise Exception("LLM generation timed out")
        except httpx.HTTPStatusError as e:
            logger.error(f"Ollama HTTP error: {e.response.status_code}")
            raise Exception(f"LLM generation failed: {e.response.status_code}")
        except Exception as e:
            logger.error(f"Ollama generation error: {e}")
            raise
    
    async def analyze_security_data(
        self,
        data_summary: str,
        analysis_type: str = "general"
    ) -> str:
        """
        Generate security analysis from data summary.
        
        Args:
            data_summary: Structured summary of security data
            analysis_type: Type of analysis (vulnerability, alert, agent, etc.)
        
        Returns:
            Analysis text
        """
        
        system_prompt = """You are a senior SOC analyst with 15+ years of experience.
Your role is to analyze security data and provide actionable insights.

CRITICAL RULES:
1. ONLY reference data explicitly provided in the prompt
2. Do NOT invent CVE IDs, agent names, or metrics
3. Be concise - 2-3 sentences maximum
4. Focus on business impact and urgency
5. Provide specific, actionable recommendations"""
        
        if analysis_type == "vulnerability":
            prompt = f"""Analyze this vulnerability data and provide a concise summary:

{data_summary}

Provide:
1. Overall risk assessment (1-2 sentences)
2. Most critical concern
3. Immediate action required

Keep response under 150 words."""
        
        elif analysis_type == "alert":
            prompt = f"""Analyze these security alerts:

{data_summary}

Provide:
1. Pattern assessment (1-2 sentences)
2. Potential attack indicators
3. Recommended investigation steps

Keep response under 150 words."""
        
        elif analysis_type == "agent":
            prompt = f"""Analyze this agent status data:

{data_summary}

Provide:
1. Infrastructure health assessment
2. Critical issues requiring attention
3. Recommended actions

Keep response under 150 words."""
        
        else:
            prompt = f"""Analyze this security data:

{data_summary}

Provide a concise summary highlighting key findings and recommended actions.
Keep response under 150 words."""
        
        return await self.generate(
            prompt=prompt,
            system_prompt=system_prompt,
            max_tokens=200,
            temperature=0.3
        )
    
    async def generate_recommendations(
        self,
        findings: str,
        priority: str = "high"
    ) -> list[str]:
        """
        Generate actionable recommendations.
        
        Args:
            findings: Security findings summary
            priority: Priority level (critical, high, medium)
        
        Returns:
            List of recommendations
        """
        
        system_prompt = """You are a security architect providing actionable remediation guidance.
Generate specific, technical recommendations that can be implemented immediately."""
        
        prompt = f"""Based on these security findings:

{findings}

Generate 3-5 specific, actionable recommendations for {priority} priority issues.

Format as a numbered list:
1. [Action]
2. [Action]
...

Each recommendation should be:
- Specific and technical
- Immediately actionable
- Include relevant commands or tools where applicable

Recommendations:"""
        
        response = await self.generate(
            prompt=prompt,
            system_prompt=system_prompt,
            max_tokens=300,
            temperature=0.4
        )
        
        # Parse numbered list
        recommendations = []
        for line in response.split('\n'):
            line = line.strip()
            if line and (line[0].isdigit() or line.startswith('-')):
                # Remove number/bullet
                rec = line.lstrip('0123456789.-) ').strip()
                if rec:
                    recommendations.append(rec)
        
        return recommendations[:5]  # Max 5
    
    async def close(self):
        """Close HTTP client"""
        if self.client and not self.client.is_closed:
            await self.client.aclose()
            self._initialized = False
