/**
 * PallasCorrelations — Cross-tool pivot investigations
 *
 * Redesigned with shared PallasUI components and Correlations accent (#10B981).
 * Combine SIEM, NIDS, and vulnerability data through Pallas AI.
 */

import React, { useState, useRef, useEffect, useCallback } from 'react';
import { EuiIcon } from '@elastic/eui';
import { THEME } from '../../utils/theme';
import { MODULE_COLORS, ModuleHeader, ActionChip, SectionHeader, FONT, ChatDisclaimer } from './PallasUI';
import { usePallas } from '../../hooks/usePallas';
import { ResponsePanel, ComparePanel } from './PallasResponsePanel';
import { StrategyPanel } from './PallasStrategyPanel';
import { QueryHistory } from './PallasQueryHistory';

const ACCENT = MODULE_COLORS.correlations.accent;

// ─── Quick Actions ───────────────────────────────────────────────────────────

const CORRELATION_QUICK_ACTIONS = [
  { label: 'Security Posture', query: 'comprehensive security posture analysis', icon: 'shield' },
  { label: 'Combined Alerts', query: 'show combined alerts from all platforms', icon: 'layers' },
  { label: 'Alert + Vuln Correlation', query: 'correlate active alerts with known vulnerabilities', icon: 'link' },
  { label: 'Top Risk Agents', query: 'show top risk agents across alerts and vulnerabilities', icon: 'warning' },
  { label: 'Risk Scoring', query: 'calculate dynamic risk score for all agents', icon: 'visBarVerticalStacked' },
  { label: 'Scanning Detection', query: 'detect all scanning activity', icon: 'search' },
  { label: 'Wazuh + Suricata', query: 'correlate wazuh alerts with suricata alerts', icon: 'merge' },
  { label: 'Behavioral Baseline', query: 'establish behavioral baseline for critical agents', icon: 'visLine' },
  { label: 'IP Investigation', query: 'investigate IP {ip}', icon: 'globe', paramKey: 'ip', paramPlaceholder: 'IP Address (e.g. 192.168.1.100)' },
];

// ─── Strategy Categories ─────────────────────────────────────────────────────

const CORRELATION_STRATEGIES = [
  {
    name: 'Full Stack',
    icon: 'layers',
    strategies: [
      { label: 'Security Posture Overview', query: 'comprehensive security posture analysis', description: 'Cross-platform security health across SIEM, NIDS, and vulnerabilities' },
      { label: 'IP Investigation', query: 'investigate IP {ip}', description: 'Cross-correlate an IP across alerts, network traffic, and vulnerabilities', params: [{ key: 'ip', label: 'IP Address', placeholder: 'e.g. 192.168.1.100' }] },
      { label: 'Cross-Platform Correlation', query: 'show combined alerts from all platforms', description: 'Unified view of alerts from Wazuh and Suricata' },
      { label: 'Dynamic Risk Scoring', query: 'calculate dynamic risk score for all agents', description: 'Composite risk score from alerts, vulns, and network activity' },
    ],
  },
  {
    name: 'SIEM + NIDS',
    icon: 'merge',
    strategies: [
      { label: 'Alert + Network Correlation', query: 'correlate wazuh alerts with suricata alerts', description: 'Match endpoint alerts with network-level detections' },
      { label: 'Combined Scanning Detection', query: 'detect all scanning activity', description: 'Identify reconnaissance from both endpoint and network perspectives' },
    ],
  },
  {
    name: 'SIEM + Vulnerabilities',
    icon: 'search',
    strategies: [
      { label: 'Alert + Vuln Correlation', query: 'correlate active alerts with known vulnerabilities', description: 'Match triggered alerts against existing CVEs' },
      { label: 'Top Risk Agents', query: 'show top risk agents across alerts and vulnerabilities', description: 'Agents with highest combined alert + vulnerability exposure' },
      { label: 'Behavioral Baseline', query: 'establish behavioral baseline for critical agents', description: 'Normal vs anomalous behavior patterns for high-value endpoints' },
    ],
  },
];

// ─── Component ───────────────────────────────────────────────────────────────

export default function PallasCorrelations({ connectionStatus: externalStatus, onConnectionStatusChange, onQueryComplete }) {
  const {
    response,
    isLoading,
    connectionStatus: wsStatus,
    sendQuery,
    cancelQuery,
    clearResponse,
    queryHistory,
    pinnedResponses,
    pinResponse,
    unpinResponse,
  } = usePallas('correlations', { onQueryComplete });

  const [inputValue, setInputValue] = useState('');
  const [expandedChip, setExpandedChip] = useState(null);
  const [chipParamValue, setChipParamValue] = useState('');
  const [showStrategies, setShowStrategies] = useState(false);
  const [comparing, setComparing] = useState(false);

  const inputRef = useRef(null);
  const responseAreaRef = useRef(null);

  const effectiveStatus = wsStatus === 'connected' ? 'connected' : externalStatus;
  const isDisabled = isLoading || effectiveStatus !== 'connected';

  // Bubble WS status up to parent
  useEffect(() => {
    if (onConnectionStatusChange) onConnectionStatusChange(wsStatus);
  }, [wsStatus, onConnectionStatusChange]);

  useEffect(() => {
    if (response && responseAreaRef.current) {
      responseAreaRef.current.scrollTop = responseAreaRef.current.scrollHeight;
    }
  }, [response]);

  const handleSend = useCallback(() => {
    const trimmed = inputValue.trim();
    if (!trimmed || isDisabled) return;
    sendQuery(trimmed);
    setInputValue('');
    if (inputRef.current) inputRef.current.style.height = 'auto';
  }, [inputValue, isDisabled, sendQuery]);

  const handleInputChange = (e) => {
    setInputValue(e.target.value);
    const el = e.target;
    el.style.height = 'auto';
    el.style.height = Math.min(el.scrollHeight, 120) + 'px';
  };

  const handleKeyDown = (e) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  const handleQuickAction = useCallback((action) => {
    if (isDisabled) return;
    if (action.paramKey) {
      if (expandedChip === action.label) {
        setExpandedChip(null);
        setChipParamValue('');
      } else {
        setExpandedChip(action.label);
        setChipParamValue('');
      }
      return;
    }
    sendQuery(action.query);
  }, [isDisabled, expandedChip, sendQuery]);

  const handleParamSubmit = useCallback((action) => {
    const val = chipParamValue.trim();
    if (!val || isDisabled) return;
    const finalQuery = action.query.replace(`{${action.paramKey}}`, val);
    sendQuery(finalQuery);
    setExpandedChip(null);
    setChipParamValue('');
  }, [chipParamValue, isDisabled, sendQuery]);

  const handleStrategyExecute = useCallback((query) => {
    if (isDisabled) return;
    sendQuery(query);
    setShowStrategies(false);
  }, [isDisabled, sendQuery]);

  const handleHistorySelect = useCallback((query) => {
    setInputValue(query);
    if (inputRef.current) inputRef.current.focus();
  }, []);

  const handleHistoryExecute = useCallback((query) => {
    sendQuery(query);
  }, [sendQuery]);

  const handleSuggestionClick = useCallback((query) => {
    sendQuery(query);
  }, [sendQuery]);

  const handleExportPinned = useCallback((e) => {
    e.stopPropagation();
    const sections = pinnedResponses.map((p, i) => {
      const parts = [`## Pin ${i + 1} \u2014 ${new Date(p.timestamp).toLocaleString()}`];
      if (p.metadata?.strategy) parts.push(`**Strategy:** ${p.metadata.strategy}`);
      parts.push('', p.content);
      if (p.socAnalysis) parts.push('', `## SOC ANALYSIS\n${p.socAnalysis}`);
      return parts.join('\n');
    });
    const report = `# Pallas Correlations \u2014 Pinned Results Export\n**Exported:** ${new Date().toLocaleString()}\n**Count:** ${pinnedResponses.length}\n\n---\n\n${sections.join('\n\n---\n\n')}`;
    const blob = new Blob([report], { type: 'text/markdown;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `pallas-correlations-pinned-${new Date().toISOString().slice(0, 19).replace(/[:.]/g, '-')}.md`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  }, [pinnedResponses]);

  return (
    <div style={{ height: '100%', display: 'flex', flexDirection: 'column', overflow: 'hidden', fontFamily: FONT.base }}>
      {/* Module Header */}
      <ModuleHeader
        icon="layers"
        title="Correlations"
        description="Cross-tool pivot investigations — combine SIEM, NIDS, and vulnerability data"
        accent={ACCENT}
        connectionStatus={effectiveStatus}
        actions={
          response ? (
            <button
              onClick={clearResponse}
              aria-label="Clear response"
              style={{
                padding: '4px 8px', border: `1px solid ${THEME.border}`, borderRadius: 6,
                backgroundColor: 'transparent', cursor: 'pointer', display: 'flex', alignItems: 'center', outline: 'none',
              }}
            >
              <EuiIcon type="cross" size="s" color={THEME.textMuted} />
            </button>
          ) : null
        }
      />

      {/* Query Input */}
      <div style={{ padding: '12px 20px', borderBottom: `1px solid ${THEME.border}`, flexShrink: 0 }}>
        {effectiveStatus !== 'connected' && (
          <div style={{
            padding: '6px 12px', fontSize: 12,
            color: effectiveStatus === 'reconnecting' ? THEME.warning : '#F87171',
            backgroundColor: effectiveStatus === 'reconnecting' ? 'rgba(220,106,19,0.10)' : 'rgba(248,113,113,0.08)',
            borderRadius: 6, marginBottom: 8, display: 'flex', alignItems: 'center', gap: 6,
          }}>
            <EuiIcon type="warning" size="s" color={effectiveStatus === 'reconnecting' ? THEME.warning : '#F87171'} />
            {effectiveStatus === 'reconnecting' ? 'Reconnecting to server...' : 'Server disconnected'}
          </div>
        )}

        <div style={{ display: 'flex', gap: 8, alignItems: 'flex-end' }}>
          <div style={{ flex: 1 }}>
            <textarea
              ref={inputRef}
              value={inputValue}
              onChange={handleInputChange}
              onKeyDown={handleKeyDown}
              placeholder={effectiveStatus === 'connected' ? 'Ask a cross-platform correlation query...' : 'Waiting for connection...'}
              aria-label="Correlation query"
              rows={1}
              disabled={isDisabled}
              style={{
                width: '100%', padding: '10px 14px',
                border: `1px solid ${THEME.border}`, borderRadius: 8,
                outline: 'none', backgroundColor: 'rgba(255,255,255,0.02)',
                color: THEME.text, fontSize: 13, fontFamily: FONT.base,
                resize: 'none', lineHeight: 1.5, maxHeight: 120, boxSizing: 'border-box',
              }}
            />
          </div>

          <button
            onClick={isLoading ? cancelQuery : handleSend}
            disabled={!isLoading && (!inputValue.trim() || isDisabled)}
            style={{
              padding: '10px 18px', borderRadius: 8, border: 'none',
              background: isLoading ? THEME.danger : ACCENT,
              color: '#fff', fontSize: 13, fontWeight: 600,
              cursor: (!isLoading && (!inputValue.trim() || isDisabled)) ? 'not-allowed' : 'pointer',
              opacity: (!isLoading && (!inputValue.trim() || isDisabled)) ? 0.5 : 1,
              display: 'flex', alignItems: 'center', gap: 6,
              transition: 'opacity 0.15s', flexShrink: 0, outline: 'none',
            }}
          >
            {isLoading ? (
              <span style={{
                display: 'inline-block', width: 14, height: 14,
                border: '2px solid rgba(255,255,255,0.3)', borderTopColor: '#fff',
                borderRadius: '50%', animation: 'pallas-spin 0.6s linear infinite',
              }} />
            ) : (
              <EuiIcon type="returnKey" size="s" color="#fff" />
            )}
            {isLoading ? 'Cancel' : 'Send'}
          </button>

          <QueryHistory
            history={queryHistory}
            onSelect={handleHistorySelect}
            onExecute={handleHistoryExecute}
            disabled={isDisabled}
          />
        </div>
        <ChatDisclaimer align="center" marginTop={6} />
      </div>

      {/* Main Content */}
      <div ref={responseAreaRef} style={{ flex: 1, overflow: 'auto', padding: '16px 20px' }} className="pallas-scrollbar">

        {/* Quick Actions */}
        <SectionHeader icon="bolt" title="Quick Actions" accent={ACCENT} />
        <div style={{ display: 'flex', flexWrap: 'wrap', gap: 6, marginBottom: 16 }}>
          {CORRELATION_QUICK_ACTIONS.map((action) => (
            <div key={action.label} style={{ display: 'inline-flex', flexDirection: 'column' }}>
              <ActionChip
                icon={action.icon}
                label={action.label}
                onClick={() => handleQuickAction(action)}
                disabled={isDisabled}
                active={expandedChip === action.label}
                accent={ACCENT}
                hasParam={!!action.paramKey}
              />

              {action.paramKey && expandedChip === action.label && (
                <div style={{
                  display: 'flex', gap: 6, marginTop: 6, alignItems: 'center',
                }}>
                  <input
                    type="text"
                    value={chipParamValue}
                    onChange={(e) => setChipParamValue(e.target.value)}
                    onKeyDown={(e) => {
                      if (e.key === 'Enter') { e.preventDefault(); handleParamSubmit(action); }
                      if (e.key === 'Escape') { setExpandedChip(null); setChipParamValue(''); }
                    }}
                    placeholder={action.paramPlaceholder}
                    autoFocus
                    style={{
                      padding: '5px 10px', borderRadius: 6, border: `1px solid ${THEME.border}`,
                      backgroundColor: THEME.bg, color: THEME.text, fontSize: 12,
                      fontFamily: FONT.mono, outline: 'none', width: 200,
                    }}
                  />
                  <button
                    onClick={() => handleParamSubmit(action)}
                    disabled={!chipParamValue.trim()}
                    style={{
                      padding: '5px 12px', borderRadius: 6, border: 'none',
                      backgroundColor: chipParamValue.trim() ? ACCENT : THEME.border,
                      color: '#fff', fontSize: 12, fontWeight: 600,
                      cursor: chipParamValue.trim() ? 'pointer' : 'not-allowed', outline: 'none',
                    }}
                  >
                    <EuiIcon type="returnKey" size="s" color="#fff" />
                  </button>
                </div>
              )}
            </div>
          ))}
        </div>

        {/* Browse Strategies */}
        <div style={{ marginBottom: 16 }}>
          <ActionChip
            icon={showStrategies ? 'arrowUp' : 'list'}
            label={showStrategies ? 'Hide Strategies' : 'Browse All Strategies'}
            onClick={() => setShowStrategies(!showStrategies)}
            active={showStrategies}
            accent={ACCENT}
          />
          {showStrategies && (
            <div style={{ marginTop: 10 }}>
              <StrategyPanel
                categories={CORRELATION_STRATEGIES}
                onExecute={handleStrategyExecute}
                disabled={isDisabled}
                isLoading={isLoading}
                storageKey="correlations"
              />
            </div>
          )}
        </div>

        {/* Pinned Results */}
        {pinnedResponses.length > 0 && (
          <div style={{ marginBottom: 16 }}>
            <SectionHeader
              icon="pinFilled"
              title="Pinned Results"
              count={pinnedResponses.length}
              accent={ACCENT}
              actions={
                <div style={{ display: 'flex', gap: 6 }}>
                  <ActionChip icon="download" label="Export" onClick={handleExportPinned} accent={ACCENT} />
                  {pinnedResponses.length >= 2 && (
                    <ActionChip icon="merge" label="Compare" onClick={() => setComparing(!comparing)} active={comparing} accent={ACCENT} />
                  )}
                </div>
              }
            />

            {comparing && pinnedResponses.length >= 2 && (
              <div style={{ marginBottom: 12 }}>
                <ComparePanel pinnedResponses={pinnedResponses} onClose={() => setComparing(false)} accent={ACCENT} />
              </div>
            )}

            <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
              {pinnedResponses.map((pinned, idx) => (
                <div key={idx} style={{
                  position: 'relative', padding: '10px 14px', borderRadius: 8,
                  border: `1px solid ${THEME.border}`, backgroundColor: 'rgba(255,255,255,0.02)',
                }}>
                  <button
                    onClick={() => unpinResponse(idx)}
                    aria-label="Unpin"
                    style={{
                      position: 'absolute', top: 8, right: 8, padding: 4,
                      border: 'none', background: 'transparent', cursor: 'pointer',
                      display: 'flex', alignItems: 'center',
                    }}
                  >
                    <EuiIcon type="cross" size="s" color={THEME.textMuted} />
                  </button>
                  <ResponsePanel
                    content={pinned.content}
                    blocks={pinned.blocks}
                    metadata={pinned.metadata}
                    socAnalysis={pinned.socAnalysis}
                    suggestions={pinned.suggestions}
                    onSuggestionClick={handleSuggestionClick}
                    accent={ACCENT}
                  />
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Response Area */}
        <div style={{ display: 'flex', justifyContent: 'center', flex: 1, minHeight: 0 }}>
          {isLoading && !response ? (
            <ResponsePanel isLoading onCancel={cancelQuery} accent={ACCENT} />
          ) : response ? (
            <ResponsePanel
              content={response.content}
              blocks={response.blocks}
              metadata={response.metadata}
              socAnalysis={response.socAnalysis}
              suggestions={response.suggestions}
              isLoading={isLoading}
              onCancel={isLoading ? cancelQuery : undefined}
              onSuggestionClick={handleSuggestionClick}
              onPin={() => pinResponse(response)}
              isPinned={pinnedResponses.some((p) => p.content === response.content && p.timestamp === response.timestamp)}
              accent={ACCENT}
            />
          ) : null}
        </div>
      </div>
    </div>
  );
}
