/**
 * KPIGridBlock — Hero KPI cards with animated counters
 *
 * Renders a grid of KPI cards (responsive — auto-fit minmax 180px). Each card
 * has:
 *   - Big animated number (counts up from 0)
 *   - Label below
 *   - Severity-aware accent border for "Critical" / "High" / "Disconnected"
 *   - Ageleia hover lift + accent bar reveal
 *   - Optional click-to-pivot ("Critical: 21" → fires "show critical alerts")
 *
 * Data shape (from BlockParser):
 *   {
 *     title: 'Alert Summary (Last 24h)' | null,
 *     items: [
 *       { label: 'Total Alerts', value: 26207, raw_value: '26,207', is_percent: false },
 *       { label: 'Critical',     value: 21,    raw_value: '21',     is_percent: false },
 *       ...
 *     ]
 *   }
 */

import { useState, useMemo } from 'react';
import { EuiIcon } from '@elastic/eui';
import { THEME, GRADIENTS, SHADOWS, GLOWS, TIMINGS } from '../../../utils/theme';
import { FONT } from '../PallasUI';
import {
  useAnimatedCounter,
  formatNumber,
} from './blockHelpers';

// ─── Heuristic: pick an icon + accent color from the KPI label ──────────────

function inferKPIMeta(label) {
  const t = (label || '').toLowerCase();

  // Severity-tinted KPIs
  if (t.includes('critical')) return { icon: 'alert',   accent: THEME.sevCritical, glow: GLOWS.danger };
  if (t.includes('high'))     return { icon: 'warning', accent: THEME.sevHigh,     glow: GLOWS.warning };
  if (t.includes('medium'))   return { icon: 'dot',     accent: THEME.sevMedium,   glow: GLOWS.warning };
  if (t.includes('low'))      return { icon: 'check',   accent: THEME.sevLow,      glow: '0 0 0 transparent' };

  // Health / status KPIs
  if (t.includes('disconnect')) return { icon: 'offline',           accent: THEME.warning,      glow: GLOWS.warning };
  if (t.includes('active'))     return { icon: 'check',             accent: THEME.success,      glow: GLOWS.success };
  if (t.includes('never'))      return { icon: 'minusInCircle',     accent: THEME.textMuted,    glow: '0 0 0 transparent' };
  if (t.includes('healthy'))    return { icon: 'checkInCircleFilled', accent: THEME.success,    glow: GLOWS.success };

  // Object types
  if (t.includes('alert'))    return { icon: 'bell',          accent: THEME.primary, glow: GLOWS.primary };
  if (t.includes('vuln') || t.includes('cve')) return { icon: 'bug', accent: THEME.danger, glow: GLOWS.danger };
  if (t.includes('agent'))    return { icon: 'users',         accent: THEME.primary, glow: GLOWS.primary };
  if (t.includes('rule'))     return { icon: 'visText',       accent: THEME.primary, glow: GLOWS.primary };
  if (t.includes('event'))    return { icon: 'list',          accent: THEME.primary, glow: GLOWS.primary };
  if (t.includes('host'))     return { icon: 'storage',       accent: THEME.primary, glow: GLOWS.primary };
  if (t.includes('ip'))       return { icon: 'globe',         accent: THEME.accent,  glow: GLOWS.accent };
  if (t.includes('user'))     return { icon: 'user',          accent: THEME.primary, glow: GLOWS.primary };
  if (t.includes('total'))    return { icon: 'visBarVerticalStacked', accent: THEME.primary, glow: GLOWS.primary };

  // Default
  return { icon: 'visBarVerticalStacked', accent: THEME.primary, glow: GLOWS.primary };
}

// ─── Heuristic: should this KPI fire a follow-up query when clicked? ────────

function inferPivotQuery(label) {
  const lc = (label || '').toLowerCase();
  if (lc.includes('critical') && lc.includes('alert')) return 'show critical alerts';
  if (lc.includes('critical') && (lc.includes('vuln') || lc.includes('cve'))) return 'show critical vulnerabilities';
  if (lc === 'critical')      return 'show critical alerts';
  if (lc === 'high')          return 'show high severity alerts';
  if (lc === 'disconnected')  return 'show disconnected agents';
  if (lc === 'active')        return 'show active agents';
  if (lc.includes('never'))   return 'show never connected agents';
  if (lc.includes('total agents')) return 'show all agents';
  if (lc.includes('total alerts')) return 'show recent alerts';
  if (lc.includes('total vuln'))   return 'show vulnerability summary';
  return null;
}

// ─── Single KPI Card ────────────────────────────────────────────────────────

function KPICard({ item, onPivot }) {
  const [hovered, setHovered] = useState(false);
  const meta = useMemo(() => inferKPIMeta(item.label), [item.label]);
  const counter = useAnimatedCounter(item.value, 700);
  const pivotQuery = useMemo(() => inferPivotQuery(item.label), [item.label]);
  const clickable = !!pivotQuery && typeof onPivot === 'function';

  const handleClick = () => {
    if (clickable) onPivot(pivotQuery);
  };

  return (
    <div
      onMouseEnter={() => setHovered(true)}
      onMouseLeave={() => setHovered(false)}
      onClick={handleClick}
      role={clickable ? 'button' : undefined}
      tabIndex={clickable ? 0 : undefined}
      onKeyDown={clickable ? (e) => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); handleClick(); } } : undefined}
      style={{
        position: 'relative',
        background: GRADIENTS.card,
        border: `1px solid ${hovered ? meta.accent : THEME.border}`,
        borderRadius: 12,
        padding: '16px 18px',
        boxShadow: hovered ? `${SHADOWS.lg}, ${meta.glow}` : SHADOWS.md,
        transform: hovered ? 'translateY(-4px)' : 'translateY(0)',
        transition: `all ${TIMINGS.base} ${TIMINGS.ease}`,
        overflow: 'hidden',
        cursor: clickable ? 'pointer' : 'default',
        minHeight: 110,
        display: 'flex',
        flexDirection: 'column',
        justifyContent: 'space-between',
      }}
    >
      {/* Top accent bar (Ageleia signature) */}
      <div
        style={{
          position: 'absolute',
          top: 0,
          left: 0,
          right: 0,
          height: 3,
          background: `linear-gradient(90deg, ${meta.accent}, ${meta.accent}80)`,
          opacity: hovered ? 1 : 0.5,
          transition: `opacity ${TIMINGS.base} ${TIMINGS.ease}`,
          pointerEvents: 'none',
        }}
      />

      {/* Top row: icon + click hint */}
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 8 }}>
        <div
          style={{
            width: 28,
            height: 28,
            borderRadius: 8,
            background: `${meta.accent}15`,
            border: `1px solid ${meta.accent}30`,
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            flexShrink: 0,
          }}
        >
          <EuiIcon type={meta.icon} size="s" color={meta.accent} />
        </div>

        {clickable && hovered && (
          <span style={{ fontSize: 10, color: meta.accent, fontWeight: 600, opacity: 0.8, textTransform: 'uppercase', letterSpacing: '0.04em' }}>
            Click →
          </span>
        )}
      </div>

      {/* Big number */}
      <div
        style={{
          fontSize: 'clamp(24px, 3.5vw, 32px)',
          fontWeight: 700,
          fontFamily: FONT.mono,
          color: THEME.text,
          lineHeight: 1.05,
          letterSpacing: '-0.02em',
          marginTop: 4,
          marginBottom: 6,
        }}
      >
        {item.is_percent ? `${counter}%` : formatNumber(counter)}
      </div>

      {/* Label */}
      <div
        style={{
          fontSize: 11,
          fontWeight: 600,
          color: THEME.textSecondary,
          textTransform: 'uppercase',
          letterSpacing: '0.05em',
          lineHeight: 1.3,
        }}
      >
        {item.label}
      </div>
    </div>
  );
}

// ─── KPIGridBlock ────────────────────────────────────────────────────────────

export default function KPIGridBlock({ data, onPivot }) {
  if (!data || !data.items || data.items.length === 0) return null;

  const { title, items } = data;

  return (
    <div style={{ margin: '14px 0' }}>
      {title && (
        <div
          style={{
            display: 'flex',
            alignItems: 'center',
            gap: 8,
            marginBottom: 12,
          }}
        >
          <span
            style={{
              width: 3,
              height: 14,
              background: GRADIENTS.primaryAccent,
              borderRadius: 2,
              flexShrink: 0,
            }}
          />
          <h4
            style={{
              margin: 0,
              fontSize: 13,
              fontWeight: 700,
              color: THEME.text,
              textTransform: 'uppercase',
              letterSpacing: '0.05em',
              background: GRADIENTS.titleText,
              WebkitBackgroundClip: 'text',
              WebkitTextFillColor: 'transparent',
              backgroundClip: 'text',
            }}
          >
            {title}
          </h4>
        </div>
      )}

      <div
        style={{
          display: 'grid',
          gridTemplateColumns: 'repeat(auto-fit, minmax(170px, 1fr))',
          gap: 10,
        }}
      >
        {items.map((item, idx) => (
          <KPICard
            key={`${item.label}-${idx}`}
            item={item}
            onPivot={onPivot}
          />
        ))}
      </div>
    </div>
  );
}
