/**
 * blockHelpers — Shared utilities for response block components
 *
 * Includes:
 *   - useAnimatedCounter hook (count-up animation for KPI numbers)
 *   - useContainerWidth hook (ResizeObserver-based width detection)
 *   - useReducedMotion hook (respect prefers-reduced-motion)
 *   - getAgeliaCardStyle (the signature Ageleia card hover styles)
 *   - formatNumber / formatRelativeTime / etc.
 */

import { useState, useEffect, useRef, useCallback } from 'react';
import { THEME, GRADIENTS, SHADOWS, GLOWS, TIMINGS } from '../../../utils/theme';

// ─── useAnimatedCounter ──────────────────────────────────────────────────────
// Smoothly counts from 0 to target value over `duration` ms.
// Returns the current displayed value as an integer.
// Respects prefers-reduced-motion (instant if reduced).

export function useAnimatedCounter(targetValue, duration = 600) {
  const [value, setValue] = useState(0);
  const reducedMotion = useReducedMotion();

  useEffect(() => {
    if (typeof targetValue !== 'number' || isNaN(targetValue)) {
      setValue(0);
      return;
    }
    if (reducedMotion) {
      setValue(targetValue);
      return;
    }

    let start = null;
    let frameId = null;
    const startValue = 0;
    const delta = targetValue - startValue;

    const tick = (ts) => {
      if (start === null) start = ts;
      const elapsed = ts - start;
      const progress = Math.min(elapsed / duration, 1);
      // Ease-out cubic — fast start, slow finish
      const eased = 1 - Math.pow(1 - progress, 3);
      setValue(Math.round(startValue + delta * eased));
      if (progress < 1) {
        frameId = requestAnimationFrame(tick);
      }
    };
    frameId = requestAnimationFrame(tick);

    return () => {
      if (frameId !== null) cancelAnimationFrame(frameId);
    };
  }, [targetValue, duration, reducedMotion]);

  return value;
}

// ─── useReducedMotion ────────────────────────────────────────────────────────

export function useReducedMotion() {
  const [reduced, setReduced] = useState(false);

  useEffect(() => {
    if (typeof window === 'undefined' || !window.matchMedia) return;
    const mq = window.matchMedia('(prefers-reduced-motion: reduce)');
    setReduced(mq.matches);
    const handler = (e) => setReduced(e.matches);
    mq.addEventListener?.('change', handler);
    return () => mq.removeEventListener?.('change', handler);
  }, []);

  return reduced;
}

// ─── useContainerWidth ───────────────────────────────────────────────────────
// Returns [ref, width] — width updates as the container resizes.
// Use to make components container-width-aware (not viewport-width-aware).

export function useContainerWidth() {
  const ref = useRef(null);
  const [width, setWidth] = useState(0);

  useEffect(() => {
    if (!ref.current) return;
    if (typeof ResizeObserver === 'undefined') {
      setWidth(ref.current.clientWidth || 0);
      return;
    }
    const observer = new ResizeObserver((entries) => {
      const entry = entries[0];
      if (entry) setWidth(entry.contentRect.width);
    });
    observer.observe(ref.current);
    return () => observer.disconnect();
  }, []);

  return [ref, width];
}

// ─── Ageleia signature card style ────────────────────────────────────────────
// Returns a style object that gives any card the Ageleia hover signature:
// gradient bg, hover lift, accent border, shadow with glow.
//
// Usage:
//   const [hovered, setHovered] = useState(false);
//   <div
//     onMouseEnter={() => setHovered(true)}
//     onMouseLeave={() => setHovered(false)}
//     style={getAgeliaCardStyle({ hovered, accent: THEME.primary })}
//   >...</div>

export function getAgeliaCardStyle({ hovered = false, accent = THEME.primary, glow = GLOWS.primary, padding = 16 } = {}) {
  return {
    position: 'relative',
    background: GRADIENTS.card,
    backdropFilter: 'blur(10px)',
    WebkitBackdropFilter: 'blur(10px)',
    border: `1px solid ${hovered ? accent + '60' : THEME.border}`,
    borderTop: `1px solid ${hovered ? accent + '80' : THEME.borderSubtle}`,
    borderRadius: 12,
    padding,
    boxShadow: hovered
      ? `${SHADOWS.xl}, ${glow}, inset 0 1px 0 rgba(255,255,255,0.04)`
      : `${SHADOWS.md}, inset 0 1px 0 rgba(255,255,255,0.03)`,
    transform: hovered ? 'translateY(-3px)' : 'translateY(0)',
    transition: `all ${TIMINGS.base} ${TIMINGS.ease}`,
    overflow: 'hidden',
    cursor: 'default',
  };
}

// ─── The Ageleia 3px-top-accent-bar overlay ──────────────────────────────────
// Drop this <div> as the FIRST child of any card that uses getAgeliaCardStyle.

export function AgeliaTopAccentBar({ hovered = false, gradient = GRADIENTS.primaryAccent }) {
  return (
    <div
      style={{
        position: 'absolute',
        top: 0,
        left: 0,
        right: 0,
        height: 3,
        background: gradient,
        opacity: hovered ? 1 : 0.4,
        transition: `opacity ${TIMINGS.base} ${TIMINGS.ease}`,
        pointerEvents: 'none',
      }}
    />
  );
}

// ─── Number formatting ───────────────────────────────────────────────────────

export function formatNumber(n) {
  if (n == null || isNaN(n)) return '—';
  if (typeof n !== 'number') return String(n);
  return n.toLocaleString('en-US');
}

export function formatNumberCompact(n) {
  // 1234 → 1.2K, 12345 → 12.3K, 1234567 → 1.2M
  if (n == null || isNaN(n)) return '—';
  if (typeof n !== 'number') return String(n);
  if (Math.abs(n) < 1000) return String(n);
  if (Math.abs(n) < 1_000_000) return (n / 1000).toFixed(1).replace(/\.0$/, '') + 'K';
  if (Math.abs(n) < 1_000_000_000) return (n / 1_000_000).toFixed(1).replace(/\.0$/, '') + 'M';
  return (n / 1_000_000_000).toFixed(1).replace(/\.0$/, '') + 'B';
}

// ─── Relative time ───────────────────────────────────────────────────────────

export function formatRelativeTime(isoString) {
  if (!isoString) return '';
  const then = new Date(isoString);
  if (isNaN(then.getTime())) return isoString;
  const now = new Date();
  const diffMs = now.getTime() - then.getTime();
  const diffSec = Math.round(diffMs / 1000);
  const diffMin = Math.round(diffSec / 60);
  const diffHr  = Math.round(diffMin / 60);
  const diffDay = Math.round(diffHr / 24);

  if (Math.abs(diffSec) < 60) return diffSec >= 0 ? 'just now' : 'in moments';
  if (Math.abs(diffMin) < 60) return diffMin >= 0 ? `${diffMin} min ago` : `in ${-diffMin} min`;
  if (Math.abs(diffHr) < 24)  return diffHr  >= 0 ? `${diffHr} hr ago`   : `in ${-diffHr} hr`;
  if (Math.abs(diffDay) < 30) return diffDay >= 0 ? `${diffDay} day${diffDay === 1 ? '' : 's'} ago` : `in ${-diffDay} days`;
  return then.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' });
}

// ─── Severity → color helpers ────────────────────────────────────────────────

export function severityColor(severity) {
  if (!severity) return THEME.sevLow;
  const k = String(severity).toLowerCase();
  if (k === 'critical') return THEME.sevCritical;
  if (k === 'high')     return THEME.sevHigh;
  if (k === 'medium')   return THEME.sevMedium;
  if (k === 'low')      return THEME.sevLow;
  return THEME.sevLow;
}

export function severityGradient(severity) {
  if (!severity) return GRADIENTS.sevLow;
  const k = String(severity).toLowerCase();
  if (k === 'critical') return GRADIENTS.sevCritical;
  if (k === 'high')     return GRADIENTS.sevHigh;
  if (k === 'medium')   return GRADIENTS.sevMedium;
  if (k === 'low')      return GRADIENTS.sevLow;
  return GRADIENTS.sevLow;
}

export function severityGlow(severity) {
  const k = String(severity || '').toLowerCase();
  if (k === 'critical') return GLOWS.danger;
  if (k === 'high')     return GLOWS.warning;
  if (k === 'medium')   return GLOWS.warning;
  return '0 0 0 transparent';
}

// ─── Click-to-pivot helper ───────────────────────────────────────────────────
// Many block components fire follow-up queries when the user clicks an item.
// This helper accepts an `onPivot` callback that the parent (ResponsePanel)
// can pass through to a chat sendQuery.

export function usePivot(onPivot) {
  return useCallback(
    (query) => {
      if (typeof onPivot === 'function' && query) onPivot(query);
    },
    [onPivot]
  );
}

// ─── Block classification for Intelligence Briefing layout ──────────────────
// Hero blocks go to Row 1 (full-width summary visuals at the top).
// Detail blocks go to Row 2 left panel (scrollable data deep-dive).

export const HERO_BLOCK_TYPES = new Set([
  'kpi_grid',
  'severity_breakdown',
  'health_status',
  'risk_score',
  'time_series',
]);

export function classifyBlocks(blocks) {
  const hero = [];
  const detail = [];
  for (const block of blocks) {
    if (HERO_BLOCK_TYPES.has(block.type)) {
      hero.push(block);
    } else {
      detail.push(block);
    }
  }
  return { hero, detail };
}
