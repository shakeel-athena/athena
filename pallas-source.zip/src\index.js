import React from 'react';
import ReactDOM from 'react-dom/client';
import { EuiProvider } from '@elastic/eui';
import App from './App';

/**
 * Pallas AI — Dual Auth Mode Entry Point
 *
 * AUTH_MODE=keycloak  → Wraps app in ReactKeycloakProvider (SSO with Ageleia/Wazuh)
 * AUTH_MODE=apikey    → No login, API key handles auth (non-SSO Wazuh, standalone)
 *
 * Default: keycloak (if REACT_APP_AUTH_MODE not set)
 */

// Auth mode: env var at build time, or ?auth= URL param at runtime (for iframe embedding)
const urlParams = new URLSearchParams(window.location.search);
const AUTH_MODE = urlParams.get('auth') || process.env.REACT_APP_AUTH_MODE || 'keycloak';

// App-specific access role — user must have this Keycloak realm role to use Pallas
const PALLAS_ACCESS_ROLE = 'pallas-access';

// ── Loading Screen ──────────────────────────────────────────────────────────

const LoadingScreen = () => (
  <div style={{
    height: '100vh',
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#0D1117',
    color: '#8e9fbc',
    fontFamily: 'Inter, -apple-system, sans-serif',
    gap: 16,
  }}>
    <div style={{
      width: 24, height: 24, border: '2px solid #2A2B33',
      borderTopColor: '#16c5c0', borderRadius: '50%',
      animation: 'spin 0.8s linear infinite',
    }} />
    <span style={{ fontSize: 13 }}>Initializing Pallas AI...</span>
    <style>{`@keyframes spin { to { transform: rotate(360deg); } }`}</style>
  </div>
);

// ── Access Denied Screen ────────────────────────────────────────────────────

const PallasAccessDenied = ({ username, onLogout }) => (
  <div style={{
    minHeight: '100vh',
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#0D1117',
    fontFamily: 'Inter, -apple-system, sans-serif',
    color: '#e6edf3',
    padding: 24,
  }}>
    <div style={{
      maxWidth: 480,
      width: '100%',
      backgroundColor: '#161b22',
      borderRadius: 12,
      border: '1px solid #30363d',
      padding: 40,
      textAlign: 'center',
      boxShadow: '0 25px 50px -12px rgba(0, 0, 0, 0.5)',
    }}>
      <div style={{
        width: 64, height: 64, borderRadius: '50%',
        backgroundColor: 'rgba(239, 68, 68, 0.1)',
        display: 'flex', alignItems: 'center', justifyContent: 'center',
        margin: '0 auto 24px',
      }}>
        <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="#ef4444" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
          <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/>
          <line x1="12" y1="8" x2="12" y2="12"/>
          <line x1="12" y1="16" x2="12.01" y2="16"/>
        </svg>
      </div>
      <h1 style={{ fontSize: 24, fontWeight: 700, marginBottom: 12 }}>Access Denied</h1>
      <p style={{ fontSize: 15, color: '#8b949e', marginBottom: 8, lineHeight: 1.6 }}>
        Your account does not have access to <strong style={{ color: '#e6edf3' }}>Pallas AI</strong>.
      </p>
      <p style={{ fontSize: 13, color: '#484f58', marginBottom: 32, lineHeight: 1.5 }}>
        Contact your administrator to request access.
      </p>
      {username && (
        <div style={{
          backgroundColor: '#0D1117', borderRadius: 8, padding: '12px 16px',
          marginBottom: 24, border: '1px solid #30363d', fontSize: 13, color: '#8b949e',
        }}>
          Signed in as <strong style={{ color: '#e6edf3' }}>{username}</strong>
        </div>
      )}
      <button
        onClick={onLogout}
        style={{
          width: '100%', padding: '12px 24px', backgroundColor: '#16c5c0',
          color: '#fff', border: 'none', borderRadius: 8, fontSize: 14,
          fontWeight: 600, cursor: 'pointer',
        }}
        onMouseOver={(e) => e.target.style.backgroundColor = '#0ea5a0'}
        onMouseOut={(e) => e.target.style.backgroundColor = '#16c5c0'}
      >
        Sign in with a different account
      </button>
    </div>
  </div>
);

// ── Keycloak Mode ───────────────────────────────────────────────────────────

function KeycloakApp() {
  const { ReactKeycloakProvider } = require('@react-keycloak/web');
  const keycloak = require('./config/keycloak').default;
  const { keycloakInitOptions } = require('./config/keycloak');
  const [denied, setDenied] = React.useState(false);
  const [kcUsername, setKcUsername] = React.useState('');

  const onEvent = React.useCallback((event) => {
    if (event === 'onAuthSuccess' || event === 'onReady') {
      if (keycloak.authenticated && keycloak.tokenParsed) {
        const roles = keycloak.tokenParsed.realm_access?.roles || [];
        setKcUsername(keycloak.tokenParsed.preferred_username || '');
        if (!roles.includes(PALLAS_ACCESS_ROLE)) {
          setDenied(true);
        }
      }
    }
  }, [keycloak]);

  const onTokens = React.useCallback((tokens) => {
    if (tokens.token) {
      sessionStorage.setItem('keycloak_token', tokens.token);
    }
  }, []);

  return (
    <>
      <ReactKeycloakProvider
        authClient={keycloak}
        initOptions={keycloakInitOptions}
        LoadingComponent={<LoadingScreen />}
        onEvent={onEvent}
        onTokens={onTokens}
      >
        <EuiProvider colorMode="dark">
          <App />
        </EuiProvider>
      </ReactKeycloakProvider>
      {denied && (
        <div style={{ position: 'fixed', top: 0, left: 0, right: 0, bottom: 0, zIndex: 99999 }}>
          <PallasAccessDenied
            username={kcUsername}
            onLogout={() => keycloak.logout({ redirectUri: window.location.origin })}
          />
        </div>
      )}
    </>
  );
}

// ── API Key Mode (no login) ─────────────────────────────────────────────────

function ApiKeyApp() {
  return (
    <EuiProvider colorMode="dark">
      <App />
    </EuiProvider>
  );
}

// ── Render ───────────────────────────────────────────────────────────────────

const root = ReactDOM.createRoot(document.getElementById('root'));

if (AUTH_MODE === 'apikey') {
  console.info('[Pallas] Auth mode: API key (no Keycloak)');
  root.render(<ApiKeyApp />);
} else {
  console.info('[Pallas] Auth mode: Keycloak SSO');
  root.render(<KeycloakApp />);
}
