import React from 'react';
import ReactDOM from 'react-dom/client';
import { EuiProvider } from '@elastic/eui';
import App from './App';

/**
 * Pallas AI — Iframe-Bridge Entry Point
 *
 * This release: the Wazuh dashboard plugin (v2) loads Pallas in an iframe and
 * posts the resolved Wazuh username via `pallas-auth-token` postMessage. We
 * forward that identity to the backend as `X-Pallas-Iframe-User` + `x-api-key`.
 *
 * RE-ENABLE NEXT RELEASE — Keycloak SSO branch (commented out below) is
 * restored alongside Agelia. Default AUTH_MODE flips back to 'keycloak'.
 */

// Auth mode: env var at build time, or ?auth= URL param at runtime
const urlParams = new URLSearchParams(window.location.search);
const AUTH_MODE = urlParams.get('auth') || process.env.REACT_APP_AUTH_MODE || 'parent';

// Maximum time we wait for the parent (plugin) to post `pallas-auth-token`
// before rendering the standalone-fallback screen.
const PARENT_AUTH_TIMEOUT_MS = 5000;

// ── Loading Screen ──────────────────────────────────────────────────────────

const LoadingScreen = () => (
  <div style={{
    height: '100vh',
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#0D1117',
    color: '#8e9fbc',
    fontFamily: 'Inter, -apple-system, sans-serif',
    gap: 16,
  }}>
    <div style={{
      width: 24, height: 24, border: '2px solid #2A2B33',
      borderTopColor: '#16c5c0', borderRadius: '50%',
      animation: 'spin 0.8s linear infinite',
    }} />
    <span style={{ fontSize: 13 }}>Initializing Pallas AI...</span>
    <style>{`@keyframes spin { to { transform: rotate(360deg); } }`}</style>
  </div>
);

// ── Standalone-Access Fallback ──────────────────────────────────────────────
//
// Shown when Pallas is opened directly (not from the Wazuh dashboard plugin
// iframe) and no parent-auth postMessage arrives. Standalone access is for
// testing only — the backend still requires `x-api-key` so most actions will
// 401 without going through the plugin.

const StandaloneFallback = () => (
  <div style={{
    minHeight: '100vh',
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#0D1117',
    fontFamily: 'Inter, -apple-system, sans-serif',
    color: '#e6edf3',
    padding: 24,
  }}>
    <div style={{
      maxWidth: 520,
      width: '100%',
      backgroundColor: '#161b22',
      borderRadius: 12,
      border: '1px solid #30363d',
      padding: 40,
      textAlign: 'center',
      boxShadow: '0 25px 50px -12px rgba(0, 0, 0, 0.5)',
    }}>
      <div style={{
        width: 64, height: 64, borderRadius: '50%',
        backgroundColor: 'rgba(22, 197, 192, 0.1)',
        display: 'flex', alignItems: 'center', justifyContent: 'center',
        margin: '0 auto 24px',
      }}>
        <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="#16c5c0" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
          <rect x="3" y="3" width="18" height="18" rx="2"/>
          <line x1="9" y1="3" x2="9" y2="21"/>
        </svg>
      </div>
      <h1 style={{ fontSize: 22, fontWeight: 700, marginBottom: 12 }}>Open Pallas from the Wazuh dashboard</h1>
      <p style={{ fontSize: 14, color: '#8b949e', marginBottom: 8, lineHeight: 1.6 }}>
        Pallas is loaded as a plugin inside the Wazuh dashboard. Sign in to Wazuh and
        click <strong style={{ color: '#e6edf3' }}>Pallas</strong> in the side menu.
      </p>
      <p style={{ fontSize: 12, color: '#484f58', marginTop: 24, lineHeight: 1.5 }}>
        Direct access is for testing only — your account needs the <code style={{ color: '#e6edf3' }}>pallas-access</code> role.
      </p>
    </div>
  </div>
);

// ── Iframe-Bridge Mode (parent plugin posts pallas-auth-token) ──────────────
//
// The parent (Wazuh dashboard plugin v2) reads the Wazuh user via OSD security
// APIs, gates on the `pallas-access` backend role, and posts the identity
// here via window.postMessage. We validate origin, store the auth payload in
// window.__pallasParentAuth (read by pallasService.authHeaders), and re-render
// once it arrives so in-flight requests can retry with the new bearer.
//
// SECURITY: origin must match REACT_APP_PARENT_ORIGIN (or one of the CSV).
// Messages from any other origin are silently ignored.

const PARENT_ORIGIN = process.env.REACT_APP_PARENT_ORIGIN || '';
const PARENT_ORIGINS_CSV = process.env.REACT_APP_PARENT_ORIGINS_CSV || '';
const ALLOWED_PARENT_ORIGINS = (() => {
  const set = new Set();
  if (PARENT_ORIGIN) set.add(PARENT_ORIGIN);
  PARENT_ORIGINS_CSV.split(',').map(s => s.trim()).filter(Boolean).forEach(o => set.add(o));
  if (set.size === 0) {
    set.add('https://test.athenasecuritygrp.com');
    set.add('https://athenasecuritygrp.com');
    set.add('https://wazuh.athenasecuritygrp.com');
  }
  return set;
})();

function ParentAuthApp() {
  const [authReady, setAuthReady] = React.useState(!!window.__pallasParentAuth);
  const [timedOut, setTimedOut] = React.useState(false);

  React.useEffect(() => {
    const handler = (event) => {
      if (!ALLOWED_PARENT_ORIGINS.has(event.origin)) return;
      const data = event.data;
      if (!data || typeof data !== 'object') return;
      if (data.type !== 'pallas-auth-token') return;
      window.__pallasParentAuth = {
        token:        data.token || '',
        username:     data.username || '',
        displayName:  data.displayName || data.username || '',
        receivedAt:   Date.now(),
        parentOrigin: event.origin,
      };
      setAuthReady(true);
    };
    window.addEventListener('message', handler);

    try {
      window.parent.postMessage({ type: 'pallas-iframe-ready' }, '*');
    } catch (_) { /* sandboxed parent — non-fatal */ }

    const timer = setTimeout(() => {
      if (!window.__pallasParentAuth) setTimedOut(true);
    }, PARENT_AUTH_TIMEOUT_MS);

    return () => {
      window.removeEventListener('message', handler);
      clearTimeout(timer);
    };
  }, []);

  if (!authReady && timedOut) return <StandaloneFallback />;
  if (!authReady) return <LoadingScreen />;
  return (
    <EuiProvider colorMode="dark">
      <App />
    </EuiProvider>
  );
}

// ── API Key Mode (no login, no parent — pure standalone) ────────────────────

function ApiKeyApp() {
  return (
    <EuiProvider colorMode="dark">
      <App />
    </EuiProvider>
  );
}

// ── Render ───────────────────────────────────────────────────────────────────

const root = ReactDOM.createRoot(document.getElementById('root'));

if (AUTH_MODE === 'apikey') {
  console.info('[Pallas] Auth mode: API key (standalone, no parent auth)');
  root.render(<ApiKeyApp />);
} else {
  console.info('[Pallas] Auth mode: iframe-bridge (parent postMessage)');
  root.render(<ParentAuthApp />);
}

// RE-ENABLE NEXT RELEASE — Keycloak SSO branch
// When SSO + Agelia come back, restore:
//   • `import keycloak from './config/keycloak'`
//   • `KeycloakApp` component with ReactKeycloakProvider + PallasAccessDenied
//   • `AUTH_MODE === 'keycloak'` branch in the render switch
// The full prior implementation lives at: git show <pre-standalone-commit>:frontend/src/index.js
