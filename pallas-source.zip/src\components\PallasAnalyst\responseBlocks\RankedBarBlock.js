/**
 * RankedBarBlock — Horizontal bar chart for top-N rankings
 *
 * Replaces flat "top attackers / top targets / top signatures" tables.
 * Each row is a horizontal bar sized proportionally to the max value.
 * Rows are sortable, clickable (fires pivot query), and responsive.
 *
 * Data shape (from BlockParser for top_attackers):
 *   {
 *     kind: 'sources' | 'targets',
 *     entries: [
 *       { ip: '185.135.180.81', count: 9 },
 *       { ip: '13.107.226.21',  count: 5 },
 *       ...
 *     ]
 *   }
 *
 * Features:
 *   - Horizontal bars with proportional width (animate on mount)
 *   - Hover brightens bar and shows highlight glow
 *   - Click → fires `investigate IP X` query
 *   - "Sources" vs "Targets" label in header with directional icon
 *   - Collapses long lists (10 + "Show all N")
 *   - Uses JetBrains Mono for IP addresses
 *   - Gradient bars matching severity (count-based)
 */

import { useState, useMemo, useEffect } from 'react';
import { EuiIcon } from '@elastic/eui';
import { THEME, GRADIENTS, SHADOWS, TIMINGS } from '../../../utils/theme';
import { FONT } from '../PallasUI';
import { useAnimatedCounter, useReducedMotion, formatNumber } from './blockHelpers';

const DEFAULT_VISIBLE = 10;

// ─── Color picker: more hits = more red ─────────────────────────────────────

function barColorForRank(rank, total) {
  // Rank 0 (top attacker) = red, descending rank = orange/amber/primary
  if (rank === 0) return { main: THEME.sevCritical, gradient: GRADIENTS.sevCritical };
  if (rank <= 2)  return { main: THEME.sevHigh,     gradient: GRADIENTS.sevHigh };
  if (rank <= 5)  return { main: THEME.sevMedium,   gradient: GRADIENTS.sevMedium };
  return { main: THEME.primary, gradient: GRADIENTS.primary };
}

// ─── Bar row ─────────────────────────────────────────────────────────────────

function BarRow({ entry, rank, percentage, maxLabelWidth, onClick, animated }) {
  const [hovered, setHovered] = useState(false);
  const { main: barColor, gradient: barGradient } = barColorForRank(rank);
  const animatedCount = useAnimatedCounter(entry.count, 600);

  return (
    <div
      onMouseEnter={() => setHovered(true)}
      onMouseLeave={() => setHovered(false)}
      onClick={onClick}
      role={onClick ? 'button' : undefined}
      tabIndex={onClick ? 0 : undefined}
      style={{
        display: 'grid',
        gridTemplateColumns: `auto ${maxLabelWidth}px 1fr auto`,
        gap: 12,
        alignItems: 'center',
        padding: '7px 10px',
        borderRadius: 8,
        background: hovered ? 'rgba(255,255,255,0.03)' : 'transparent',
        cursor: onClick ? 'pointer' : 'default',
        transition: `background ${TIMINGS.fast} ${TIMINGS.ease}`,
      }}
    >
      {/* Rank number */}
      <span
        style={{
          fontSize: 10,
          fontWeight: 700,
          color: rank === 0 ? barColor : THEME.textMuted,
          fontFamily: FONT.mono,
          minWidth: 20,
          textAlign: 'right',
        }}
      >
        #{rank + 1}
      </span>

      {/* IP / label */}
      <span
        style={{
          fontFamily: FONT.mono,
          fontSize: 12,
          fontWeight: 600,
          color: hovered ? barColor : THEME.text,
          whiteSpace: 'nowrap',
          overflow: 'hidden',
          textOverflow: 'ellipsis',
          transition: `color ${TIMINGS.fast} ${TIMINGS.ease}`,
        }}
        title={entry.ip}
      >
        {entry.ip}
      </span>

      {/* The bar */}
      <div
        style={{
          position: 'relative',
          height: 14,
          background: 'rgba(255,255,255,0.04)',
          borderRadius: 7,
          overflow: 'hidden',
          border: `1px solid ${THEME.border}`,
        }}
      >
        <div
          style={{
            width: animated ? `${percentage}%` : '0%',
            height: '100%',
            background: barGradient,
            borderRadius: 6,
            boxShadow: hovered ? `0 0 10px ${barColor}90` : 'none',
            transition: `width ${TIMINGS.slowest} ${TIMINGS.ease}, box-shadow ${TIMINGS.fast} ${TIMINGS.ease}`,
            position: 'relative',
            overflow: 'hidden',
          }}
        >
          {/* Shimmer sweep */}
          <div
            style={{
              position: 'absolute',
              inset: 0,
              background: 'linear-gradient(90deg, transparent, rgba(255,255,255,0.20), transparent)',
              animation: 'pallas-sweep 2.4s ease-in-out infinite',
              pointerEvents: 'none',
            }}
          />
        </div>
      </div>

      {/* Count */}
      <span
        style={{
          fontFamily: FONT.mono,
          fontSize: 13,
          fontWeight: 700,
          color: hovered ? barColor : THEME.text,
          minWidth: 48,
          textAlign: 'right',
          transition: `color ${TIMINGS.fast} ${TIMINGS.ease}`,
        }}
      >
        {formatNumber(animatedCount)}
      </span>
    </div>
  );
}

// ─── Main component ────────────────────────────────────────────────────────

export default function RankedBarBlock({ data, onPivot }) {
  const reduced = useReducedMotion();
  const [mounted, setMounted] = useState(false);
  const [expanded, setExpanded] = useState(false);

  useEffect(() => {
    if (reduced) {
      setMounted(true);
      return;
    }
    const id = requestAnimationFrame(() => setMounted(true));
    return () => cancelAnimationFrame(id);
  }, [reduced]);

  const kind = data?.kind || 'sources';
  const entries = (data?.entries || []).filter(e => e.ip);

  // Sort descending by count (just in case) + find max for scaling
  const sorted = useMemo(
    () => [...entries].sort((a, b) => (b.count || 0) - (a.count || 0)),
    [entries]
  );
  const maxCount = sorted.length > 0 ? sorted[0].count : 1;
  const visible = expanded ? sorted : sorted.slice(0, DEFAULT_VISIBLE);

  if (sorted.length === 0) return null;

  const title = kind === 'targets' ? 'Top Destination IPs (Targets)' : 'Top Source IPs (Attackers)';
  const icon = kind === 'targets' ? 'exportAction' : 'importAction';

  return (
    <div
      style={{
        margin: '14px 0',
        background: GRADIENTS.card,
        border: `1px solid ${THEME.border}`,
        borderRadius: 12,
        padding: '14px 14px 10px',
        boxShadow: SHADOWS.md + ", inset 0 1px 0 rgba(255,255,255,0.04)",
      }}
    >
      {/* Header */}
      <div
        style={{
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'space-between',
          marginBottom: 10,
          flexWrap: 'wrap',
          gap: 8,
        }}
      >
        <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
          <div
            style={{
              width: 24,
              height: 24,
              borderRadius: 6,
              background: `${THEME.primary}15`,
              border: `1px solid ${THEME.primary}30`,
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              flexShrink: 0,
            }}
          >
            <EuiIcon type={icon} size="s" color={THEME.primary} />
          </div>
          <h4
            style={{
              margin: 0,
              fontSize: 12,
              fontWeight: 700,
              color: THEME.textSecondary,
              textTransform: 'uppercase',
              letterSpacing: '0.05em',
            }}
          >
            {title}
          </h4>
        </div>
        <span
          style={{
            fontSize: 10,
            color: THEME.textMuted,
            fontFamily: FONT.mono,
          }}
        >
          {sorted.length} {sorted.length === 1 ? 'entry' : 'entries'}
        </span>
      </div>

      {/* Rows */}
      <div style={{ display: 'flex', flexDirection: 'column', gap: 2 }}>
        {visible.map((entry, idx) => {
          const pct = maxCount > 0 ? (entry.count / maxCount) * 100 : 0;
          const pivotQuery = typeof onPivot === 'function' ? `investigate IP ${entry.ip}` : null;
          const handleClick = pivotQuery ? () => onPivot(pivotQuery) : null;
          return (
            <BarRow
              key={`${entry.ip}-${idx}`}
              entry={entry}
              rank={idx}
              percentage={pct}
              maxLabelWidth={140}
              onClick={handleClick}
              animated={mounted}
            />
          );
        })}
      </div>

      {/* Footer */}
      {sorted.length > DEFAULT_VISIBLE && (
        <div style={{ marginTop: 10, display: 'flex', justifyContent: 'center' }}>
          <button
            onClick={() => setExpanded(!expanded)}
            style={{
              display: 'inline-flex',
              alignItems: 'center',
              gap: 6,
              padding: '6px 16px',
              borderRadius: 8,
              border: `1px solid ${THEME.primary}40`,
              background: `${THEME.primary}10`,
              color: THEME.primary,
              fontSize: 11,
              fontWeight: 600,
              cursor: 'pointer',
              fontFamily: 'inherit',
              transition: `all ${TIMINGS.fast} ${TIMINGS.ease}`,
              outline: 'none',
            }}
            onMouseEnter={(e) => {
              e.currentTarget.style.background = `${THEME.primary}20`;
              e.currentTarget.style.borderColor = THEME.primary;
            }}
            onMouseLeave={(e) => {
              e.currentTarget.style.background = `${THEME.primary}10`;
              e.currentTarget.style.borderColor = `${THEME.primary}40`;
            }}
          >
            <EuiIcon type={expanded ? 'arrowUp' : 'arrowDown'} size="s" color={THEME.primary} />
            {expanded ? 'Show less' : `Show all ${sorted.length}`}
          </button>
        </div>
      )}
    </div>
  );
}
