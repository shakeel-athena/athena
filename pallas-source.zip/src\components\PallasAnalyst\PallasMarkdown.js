/**
 * PallasMarkdown — Custom Markdown Renderer (Ageleia-aligned upgrade)
 *
 * Dependency-free markdown parser that renders AI responses with premium
 * polish matching the Ageleia design system. This is the fallback renderer
 * used by ResponseBlockRenderer for any block type that doesn't have a
 * specialized component yet. Every response — even unmatched ones — should
 * look native and modern.
 *
 * Ageleia upgrades vs the original version:
 *   - Headers use the metallic title gradient text effect
 *   - Tables auto-detect severity columns and tint rows accordingly
 *   - Numeric cells automatically use JetBrains Mono
 *   - Long tables collapse after 10 rows with "Show all (N)" button
 *   - Row hover uses accent border-left slide + bg tint (Ageleia signature)
 *   - Code blocks get copy-to-clipboard button + language badge
 *   - Cell-specific formatters: IP, CVE, agent ID, rule ID get special treatment
 *   - Ordered list items get priority-numbered avatars
 *   - Responsive — tables scroll horizontally with momentum on touch devices
 *
 * No external dependencies. All colors from the unified THEME.
 */

import React, { useMemo, useState } from 'react';
import { EuiIcon } from '@elastic/eui';
import { THEME, GRADIENTS, SHADOWS, TIMINGS } from '../../utils/theme';

// ─── Theme aliases ──────────────────────────────────────────────────────────

const T = {
  headerAccent: THEME.primary,             // was THEME.accent — now Ageleia blue
  text:         THEME.text,
  textSecondary:THEME.textSecondary,
  textMuted:    THEME.textMuted,
  codeBg:       THEME.bgDeep,
  codeBorder:   THEME.border,
  codeText:     THEME.primaryLight,        // was THEME.accent — brighter
  tableBorder:  THEME.border,
  tableHeaderBg:THEME.cardSubtle,
  tableRowAlt:  'rgba(255, 255, 255, 0.02)',
  tableRowHoverBg: 'rgba(59, 130, 246, 0.06)', // Ageleia primary at low alpha
  hrColor:      THEME.border,
  linkColor:    THEME.primary,
  boldColor:    THEME.textBright,
};

const MONO_FONT = "'JetBrains Mono', 'SF Mono', 'Fira Code', Menlo, Monaco, Consolas, monospace";

// ─── Data-type detection for table cells ───────────────────────────────────

function isNumericCell(text) {
  const t = String(text || '').trim();
  if (!t) return false;
  // Match: 123, 1,234, 12.34, 12.34%, -5, etc.
  return /^-?[\d,]+(\.\d+)?\s*%?$/.test(t);
}

function isIPCell(text) {
  const t = String(text || '').trim();
  return /^\d{1,3}(\.\d{1,3}){3}(:\d+)?$/.test(t) || /^[a-f0-9:]+:[a-f0-9:]+$/i.test(t);
}

function isCVECell(text) {
  return /^CVE-\d{4}-\d{3,}$/i.test(String(text || '').trim());
}

function isTimestampCell(text) {
  const t = String(text || '').trim();
  return /^\d{4}-\d{2}-\d{2}/.test(t);
}

function isAgentIdCell(text) {
  // Matches "000", "011", "024" etc. — short numeric or "001-like" IDs
  return /^\d{3}$/.test(String(text || '').trim());
}

function isRuleIdCell(text) {
  // Wazuh rule IDs are usually 4-6 digit numbers
  return /^\d{4,6}$/.test(String(text || '').trim());
}

function isStatusCell(text) {
  const t = String(text || '').trim().toLowerCase();
  return [
    'active', 'disconnected', 'connected', 'never connected', 'never_connected',
    'pending', 'healthy', 'unhealthy', 'error', 'success', 'failed', 'running',
    'stopped', 'inactive', 'online', 'offline',
  ].includes(t);
}

function isSeverityCell(text) {
  const t = String(text || '').trim().toLowerCase();
  return ['critical', 'high', 'medium', 'low', 'info', 'informational'].includes(t);
}

// ─── Column detection ──────────────────────────────────────────────────────

function detectColumnTypes(headers, rows) {
  // Look at the first 5 rows to infer each column's type.
  // Returns: array of { type: 'numeric'|'ip'|'cve'|'timestamp'|'agent_id'|'rule_id'|'status'|'severity'|'text', name: string }
  const sample = rows.slice(0, Math.min(5, rows.length));

  return headers.map((header, colIdx) => {
    const lowerHeader = header.toLowerCase();
    const cellValues = sample.map(r => (r[colIdx] || '').toString());
    const allNonEmpty = cellValues.filter(c => c.trim());

    // Header hints first (strongest signal)
    if (lowerHeader.includes('severity') || lowerHeader === 'level' || lowerHeader.includes('sev')) {
      return { type: 'severity', name: header };
    }
    if (lowerHeader === 'status' || lowerHeader === 'state') {
      return { type: 'status', name: header };
    }
    if (lowerHeader.includes('ip') || lowerHeader.includes('address')) {
      return { type: 'ip', name: header };
    }
    if (lowerHeader.includes('cve')) {
      return { type: 'cve', name: header };
    }
    if (lowerHeader.includes('agent id') || lowerHeader === 'agent_id' || lowerHeader === 'agent') {
      return { type: 'agent_id', name: header };
    }
    if (lowerHeader.includes('rule id') || lowerHeader === 'rule_id') {
      return { type: 'rule_id', name: header };
    }
    if (lowerHeader.includes('time') || lowerHeader.includes('date') || lowerHeader.includes('seen') ||
        lowerHeader.includes('detected') || lowerHeader.includes('generated')) {
      return { type: 'timestamp', name: header };
    }
    if (lowerHeader === 'count' || lowerHeader.includes('alerts') || lowerHeader.includes('number') ||
        lowerHeader.includes('total') || lowerHeader === '#' || lowerHeader.includes('times') ||
        lowerHeader.includes('frequency')) {
      return { type: 'numeric', name: header };
    }

    // Content-based detection (if header is ambiguous)
    if (allNonEmpty.length === 0) return { type: 'text', name: header };

    const allNumeric  = allNonEmpty.every(isNumericCell);
    if (allNumeric)   return { type: 'numeric', name: header };
    const allIp       = allNonEmpty.every(isIPCell);
    if (allIp)        return { type: 'ip', name: header };
    const allCve      = allNonEmpty.every(isCVECell);
    if (allCve)       return { type: 'cve', name: header };
    const allTs       = allNonEmpty.every(isTimestampCell);
    if (allTs)        return { type: 'timestamp', name: header };
    const allStatus   = allNonEmpty.every(isStatusCell);
    if (allStatus)    return { type: 'status', name: header };
    const allSev      = allNonEmpty.every(isSeverityCell);
    if (allSev)       return { type: 'severity', name: header };

    return { type: 'text', name: header };
  });
}

// ─── Cell renderers by type ────────────────────────────────────────────────

const SEVERITY_STYLES = {
  critical:      { color: THEME.sevCritical, bg: 'rgba(239, 68, 68, 0.12)',  border: 'rgba(239, 68, 68, 0.35)',  label: 'Critical' },
  high:          { color: THEME.sevHigh,     bg: 'rgba(249, 115, 22, 0.12)', border: 'rgba(249, 115, 22, 0.35)', label: 'High' },
  medium:        { color: THEME.sevMedium,   bg: 'rgba(245, 158, 11, 0.12)', border: 'rgba(245, 158, 11, 0.35)', label: 'Medium' },
  low:           { color: THEME.sevLow,      bg: 'rgba(100, 116, 139, 0.12)',border: 'rgba(100, 116, 139, 0.35)',label: 'Low' },
  info:          { color: THEME.primary,     bg: 'rgba(59, 130, 246, 0.12)', border: 'rgba(59, 130, 246, 0.35)', label: 'Info' },
  informational: { color: THEME.primary,     bg: 'rgba(59, 130, 246, 0.12)', border: 'rgba(59, 130, 246, 0.35)', label: 'Info' },
};

const STATUS_STYLES = {
  active:     { color: THEME.success,  dot: THEME.success,  label: 'Active' },
  healthy:    { color: THEME.success,  dot: THEME.success,  label: 'Healthy' },
  running:    { color: THEME.success,  dot: THEME.success,  label: 'Running' },
  online:     { color: THEME.success,  dot: THEME.success,  label: 'Online' },
  connected:  { color: THEME.success,  dot: THEME.success,  label: 'Connected' },
  success:    { color: THEME.success,  dot: THEME.success,  label: 'Success' },
  disconnected:   { color: THEME.warning, dot: THEME.warning, label: 'Disconnected' },
  offline:        { color: THEME.warning, dot: THEME.warning, label: 'Offline' },
  pending:        { color: THEME.warning, dot: THEME.warning, label: 'Pending' },
  inactive:       { color: THEME.textMuted, dot: THEME.textMuted, label: 'Inactive' },
  stopped:        { color: THEME.textMuted, dot: THEME.textMuted, label: 'Stopped' },
  'never connected': { color: THEME.textMuted, dot: THEME.textMuted, label: 'Never Connected' },
  never_connected:   { color: THEME.textMuted, dot: THEME.textMuted, label: 'Never Connected' },
  unhealthy:  { color: THEME.danger,   dot: THEME.danger,   label: 'Unhealthy' },
  error:      { color: THEME.danger,   dot: THEME.danger,   label: 'Error' },
  failed:     { color: THEME.danger,   dot: THEME.danger,   label: 'Failed' },
};

function SeverityBadge({ text }) {
  const key = String(text || '').trim().toLowerCase();
  const style = SEVERITY_STYLES[key];
  if (!style) return <span>{text}</span>;
  return (
    <span
      style={{
        display: 'inline-flex',
        alignItems: 'center',
        gap: 5,
        padding: '2px 9px',
        borderRadius: 5,
        fontSize: 10,
        fontWeight: 700,
        textTransform: 'uppercase',
        letterSpacing: '0.04em',
        color: style.color,
        backgroundColor: style.bg,
        border: `1px solid ${style.border}`,
        whiteSpace: 'nowrap',
      }}
    >
      {style.label}
    </span>
  );
}

function StatusBadge({ text }) {
  const key = String(text || '').trim().toLowerCase();
  const style = STATUS_STYLES[key];
  if (!style) return <span>{text}</span>;
  const isAnimated = key === 'active' || key === 'healthy' || key === 'online' || key === 'running' || key === 'connected';
  return (
    <span
      style={{
        display: 'inline-flex',
        alignItems: 'center',
        gap: 6,
        fontSize: 11,
        fontWeight: 600,
        color: style.color,
        whiteSpace: 'nowrap',
      }}
    >
      <span
        style={{
          width: 7,
          height: 7,
          borderRadius: '50%',
          background: style.dot,
          boxShadow: isAnimated ? `0 0 6px ${style.dot}` : 'none',
          animation: isAnimated ? 'pallas-breathe 2s ease-in-out infinite' : 'none',
          flexShrink: 0,
        }}
      />
      {style.label}
    </span>
  );
}

function IPCell({ text, onPivot }) {
  const t = String(text || '').trim();
  const clickable = typeof onPivot === 'function';
  return (
    <span
      onClick={clickable ? () => onPivot(`investigate IP ${t}`) : undefined}
      title={clickable ? `Click to investigate IP ${t}` : undefined}
      style={{
        fontFamily: MONO_FONT,
        fontSize: 12,
        color: clickable ? THEME.primary : THEME.text,
        cursor: clickable ? 'pointer' : 'default',
        borderBottom: clickable ? `1px dashed ${THEME.primary}40` : 'none',
        transition: `color ${TIMINGS.fast} ${TIMINGS.ease}`,
      }}
      onMouseEnter={clickable ? (e) => { e.currentTarget.style.color = THEME.primaryLight; } : undefined}
      onMouseLeave={clickable ? (e) => { e.currentTarget.style.color = THEME.primary; } : undefined}
    >
      {t}
    </span>
  );
}

function CVECell({ text }) {
  const t = String(text || '').trim();
  const nvdUrl = `https://nvd.nist.gov/vuln/detail/${t}`;
  return (
    <a
      href={nvdUrl}
      target="_blank"
      rel="noopener noreferrer"
      title={`View ${t} on NVD`}
      style={{
        fontFamily: MONO_FONT,
        fontSize: 12,
        color: THEME.warning,
        textDecoration: 'none',
        fontWeight: 600,
        borderBottom: `1px dashed ${THEME.warning}60`,
      }}
      onMouseEnter={(e) => { e.currentTarget.style.color = THEME.warningYellow; }}
      onMouseLeave={(e) => { e.currentTarget.style.color = THEME.warning; }}
    >
      {t}
    </a>
  );
}

function AgentIdCell({ text, onPivot }) {
  const t = String(text || '').trim();
  const clickable = typeof onPivot === 'function';
  return (
    <span
      onClick={clickable ? () => onPivot(`check agent ${t} health`) : undefined}
      title={clickable ? `Click to investigate agent ${t}` : undefined}
      style={{
        fontFamily: MONO_FONT,
        fontSize: 12,
        fontWeight: 600,
        color: clickable ? THEME.primary : THEME.text,
        cursor: clickable ? 'pointer' : 'default',
        padding: '1px 6px',
        borderRadius: 3,
        background: clickable ? `${THEME.primary}12` : 'transparent',
        border: clickable ? `1px solid ${THEME.primary}25` : 'none',
        whiteSpace: 'nowrap',
      }}
    >
      {t}
    </span>
  );
}

function TimestampCell({ text }) {
  return (
    <span
      style={{
        fontFamily: MONO_FONT,
        fontSize: 11,
        color: THEME.textMuted,
        whiteSpace: 'nowrap',
      }}
    >
      {text}
    </span>
  );
}

function NumericCell({ text }) {
  return (
    <span
      style={{
        fontFamily: MONO_FONT,
        fontSize: 12,
        fontWeight: 600,
        color: THEME.text,
        whiteSpace: 'nowrap',
      }}
    >
      {text}
    </span>
  );
}

function renderCellByType(text, type, onPivot) {
  if (text == null || text === '') {
    return <span style={{ color: THEME.textFaint }}>—</span>;
  }
  switch (type) {
    case 'severity':  return <SeverityBadge text={text} />;
    case 'status':    return <StatusBadge text={text} />;
    case 'ip':        return <IPCell text={text} onPivot={onPivot} />;
    case 'cve':       return <CVECell text={text} />;
    case 'agent_id':  return <AgentIdCell text={text} onPivot={onPivot} />;
    case 'rule_id':   return <NumericCell text={text} />;
    case 'timestamp': return <TimestampCell text={text} />;
    case 'numeric':   return <NumericCell text={text} />;
    default:          return <>{parseInline(text)}</>;
  }
}

// Get the severity/status of the row (for row-level tinting)
function getRowSeverityTint(row, columnTypes) {
  for (let i = 0; i < columnTypes.length; i++) {
    if (columnTypes[i].type === 'severity') {
      const k = String(row[i] || '').trim().toLowerCase();
      if (SEVERITY_STYLES[k]) return SEVERITY_STYLES[k].border;
    }
  }
  return null;
}

// ─── Inline formatting (unchanged from original) ───────────────────────────

function parseInline(text) {
  if (!text) return text;
  const parts = [];
  let remaining = text;
  let key = 0;

  while (remaining.length > 0) {
    // Bold **text**
    const boldMatch = remaining.match(/\*\*(.+?)\*\*/);
    // Inline code `text`
    const codeMatch = remaining.match(/`([^`]+)`/);
    // Italic *text* (not **)
    const italicMatch = remaining.match(/(?<!\*)\*(?!\*)(.+?)(?<!\*)\*(?!\*)/);

    const matches = [
      boldMatch   && { type: 'bold',   match: boldMatch },
      codeMatch   && { type: 'code',   match: codeMatch },
      italicMatch && { type: 'italic', match: italicMatch },
    ].filter(Boolean).sort((a, b) => a.match.index - b.match.index);

    if (matches.length === 0) {
      parts.push(remaining);
      break;
    }

    const first = matches[0];
    const idx = first.match.index;
    if (idx > 0) parts.push(remaining.slice(0, idx));

    if (first.type === 'bold') {
      parts.push(
        <strong key={key++} style={{ color: T.boldColor, fontWeight: 600 }}>
          {first.match[1]}
        </strong>
      );
    } else if (first.type === 'code') {
      parts.push(
        <code
          key={key++}
          style={{
            backgroundColor: T.codeBg,
            border: `1px solid ${T.codeBorder}`,
            padding: '1px 6px',
            borderRadius: 4,
            fontSize: '0.85em',
            fontFamily: MONO_FONT,
            color: T.codeText,
          }}
        >
          {first.match[1]}
        </code>
      );
    } else if (first.type === 'italic') {
      parts.push(<em key={key++}>{first.match[1]}</em>);
    }

    remaining = remaining.slice(idx + first.match[0].length);
  }

  return parts.length === 1 && typeof parts[0] === 'string' ? parts[0] : parts;
}

// ─── Enhanced Table ────────────────────────────────────────────────────────

const TABLE_COLLAPSE_THRESHOLD = 10;

function EnhancedTable({ headers, rows, onPivot }) {
  const [expanded, setExpanded] = useState(false);
  const [hoveredRow, setHoveredRow] = useState(null);

  const columnTypes = useMemo(() => detectColumnTypes(headers, rows), [headers, rows]);
  const hasSeverity = columnTypes.some(c => c.type === 'severity');
  const isCollapsible = rows.length > TABLE_COLLAPSE_THRESHOLD;
  const visibleRows = isCollapsible && !expanded ? rows.slice(0, TABLE_COLLAPSE_THRESHOLD) : rows;

  return (
    <div
      style={{
        margin: '14px 0',
        borderRadius: 12,
        border: `1px solid ${T.tableBorder}`,
        overflow: 'hidden',
        background: GRADIENTS.card,
        boxShadow: SHADOWS.md + ', inset 0 1px 0 rgba(255,255,255,0.04)',
      }}
    >
      <div
        className="pallas-scrollbar"
        style={{
          overflowX: 'auto',
          WebkitOverflowScrolling: 'touch',
        }}
      >
        <table
          style={{
            width: '100%',
            borderCollapse: 'collapse',
            fontSize: 12,
          }}
        >
          <thead>
            <tr>
              {headers.map((h, i) => {
                const colType = columnTypes[i]?.type;
                const isNumericCol = colType === 'numeric' || colType === 'rule_id';
                return (
                  <th
                    key={i}
                    style={{
                      padding: '11px 14px',
                      textAlign: isNumericCol ? 'right' : 'left',
                      fontWeight: 700,
                      fontSize: 10,
                      color: T.textSecondary,
                      textTransform: 'uppercase',
                      letterSpacing: '0.06em',
                      borderBottom: `1px solid ${T.tableBorder}`,
                      whiteSpace: 'nowrap',
                      background: T.tableHeaderBg,
                      position: 'sticky',
                      top: 0,
                    }}
                  >
                    {parseInline(h)}
                  </th>
                );
              })}
            </tr>
          </thead>
          <tbody>
            {visibleRows.map((row, ri) => {
              const sevTint = hasSeverity ? getRowSeverityTint(row, columnTypes) : null;
              const isHovered = hoveredRow === ri;
              const zebra = ri % 2 === 1;
              const baseBg = zebra ? 'rgba(255,255,255,0.015)' : 'transparent';
              return (
                <tr
                  key={ri}
                  onMouseEnter={() => setHoveredRow(ri)}
                  onMouseLeave={() => setHoveredRow(null)}
                  style={{
                    backgroundColor: isHovered ? T.tableRowHoverBg : baseBg,
                    transition: `background-color ${TIMINGS.fast} ${TIMINGS.ease}`,
                    position: 'relative',
                  }}
                >
                  {row.map((cell, ci) => {
                    const type = columnTypes[ci]?.type || 'text';
                    const isNumericCol = type === 'numeric' || type === 'rule_id';
                    return (
                      <td
                        key={ci}
                        style={{
                          padding: '9px 14px',
                          color: T.text,
                          borderBottom: `1px solid rgba(255,255,255,0.04)`,
                          borderLeft: ci === 0 && sevTint
                            ? `3px solid ${sevTint}`
                            : ci === 0 && isHovered
                            ? `3px solid ${THEME.primary}`
                            : '3px solid transparent',
                          fontSize: 12,
                          lineHeight: 1.4,
                          textAlign: isNumericCol ? 'right' : 'left',
                          transition: `border-left-color ${TIMINGS.fast} ${TIMINGS.ease}`,
                          verticalAlign: 'middle',
                        }}
                      >
                        {renderCellByType(cell, type, onPivot)}
                      </td>
                    );
                  })}
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>

      {isCollapsible && (
        <div
          style={{
            padding: '10px 14px',
            borderTop: `1px solid ${T.tableBorder}`,
            background: T.tableHeaderBg,
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'space-between',
            gap: 8,
          }}
        >
          <span style={{ fontSize: 11, color: T.textMuted }}>
            Showing {visibleRows.length} of {rows.length} rows
          </span>
          <button
            onClick={() => setExpanded(!expanded)}
            style={{
              display: 'inline-flex',
              alignItems: 'center',
              gap: 5,
              padding: '4px 12px',
              borderRadius: 6,
              border: `1px solid ${THEME.primary}40`,
              background: `${THEME.primary}10`,
              color: THEME.primary,
              fontSize: 11,
              fontWeight: 600,
              cursor: 'pointer',
              fontFamily: 'inherit',
              transition: `all ${TIMINGS.fast} ${TIMINGS.ease}`,
              outline: 'none',
            }}
            onMouseEnter={(e) => {
              e.currentTarget.style.background = `${THEME.primary}20`;
              e.currentTarget.style.borderColor = THEME.primary;
            }}
            onMouseLeave={(e) => {
              e.currentTarget.style.background = `${THEME.primary}10`;
              e.currentTarget.style.borderColor = `${THEME.primary}40`;
            }}
          >
            <EuiIcon type={expanded ? 'arrowUp' : 'arrowDown'} size="s" color={THEME.primary} />
            {expanded ? 'Show less' : `Show all ${rows.length}`}
          </button>
        </div>
      )}
    </div>
  );
}

function parseTableRows(lines) {
  if (lines.length < 2) return null;
  const parseRow = (line) =>
    line.split('|').map(cell => cell.trim()).filter(Boolean);
  const headers = parseRow(lines[0]);
  const startIdx = lines[1] && /^[\s|:-]+$/.test(lines[1]) ? 2 : 1;
  const rows = lines.slice(startIdx).map(parseRow);
  return { headers, rows };
}

// ─── Enhanced Code Block ───────────────────────────────────────────────────

function EnhancedCodeBlock({ lang, code }) {
  const [copied, setCopied] = useState(false);
  const [hovered, setHovered] = useState(false);

  const handleCopy = () => {
    if (navigator.clipboard) {
      navigator.clipboard.writeText(code).then(() => {
        setCopied(true);
        setTimeout(() => setCopied(false), 1500);
      });
    }
  };

  return (
    <div
      onMouseEnter={() => setHovered(true)}
      onMouseLeave={() => setHovered(false)}
      style={{
        position: 'relative',
        margin: '12px 0',
        borderRadius: 10,
        border: `1px solid ${T.codeBorder}`,
        background: T.codeBg,
        overflow: 'hidden',
        boxShadow: SHADOWS.sm,
      }}
    >
      {/* Language badge + copy button */}
      {(lang || hovered) && (
        <div
          style={{
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'space-between',
            padding: '6px 12px',
            borderBottom: `1px solid ${T.codeBorder}`,
            background: 'rgba(255,255,255,0.02)',
          }}
        >
          {lang ? (
            <span
              style={{
                fontSize: 10,
                color: T.textSecondary,
                textTransform: 'uppercase',
                letterSpacing: '0.06em',
                fontWeight: 700,
                fontFamily: MONO_FONT,
              }}
            >
              {lang}
            </span>
          ) : (
            <span />
          )}

          <button
            onClick={handleCopy}
            style={{
              display: 'inline-flex',
              alignItems: 'center',
              gap: 4,
              padding: '3px 10px',
              borderRadius: 4,
              border: `1px solid ${copied ? THEME.success : THEME.border}`,
              background: copied ? `${THEME.success}15` : 'rgba(255,255,255,0.03)',
              color: copied ? THEME.success : T.textSecondary,
              fontSize: 10,
              fontWeight: 600,
              textTransform: 'uppercase',
              letterSpacing: '0.04em',
              cursor: 'pointer',
              fontFamily: 'inherit',
              transition: `all ${TIMINGS.fast} ${TIMINGS.ease}`,
              outline: 'none',
            }}
            title={copied ? 'Copied!' : 'Copy to clipboard'}
          >
            <EuiIcon type={copied ? 'check' : 'copy'} size="s" color={copied ? THEME.success : T.textSecondary} />
            {copied ? 'Copied' : 'Copy'}
          </button>
        </div>
      )}

      <pre
        style={{
          margin: 0,
          padding: '14px 16px',
          fontSize: 12,
          lineHeight: 1.6,
          fontFamily: MONO_FONT,
          color: T.text,
          overflowX: 'auto',
        }}
      >
        <code>{code}</code>
      </pre>
    </div>
  );
}

// ─── Main component ────────────────────────────────────────────────────────

function PallasMarkdown({ content, onPivot }) {
  const rendered = useMemo(() => {
    if (!content) return null;

    const lines = content.split('\n');
    const elements = [];
    let i = 0;

    while (i < lines.length) {
      const line = lines[i];
      const trimmed = line.trim();

      // Empty line → spacer
      if (trimmed === '') {
        elements.push(<div key={i} style={{ height: 6 }} />);
        i++;
        continue;
      }

      // Horizontal rule
      if (/^[-*_]{3,}$/.test(trimmed)) {
        elements.push(
          <hr
            key={i}
            style={{
              border: 'none',
              borderTop: `1px solid ${T.hrColor}`,
              margin: '14px 0',
              opacity: 0.5,
            }}
          />
        );
        i++;
        continue;
      }

      // Code block ```
      if (trimmed.startsWith('```')) {
        const lang = trimmed.slice(3).trim();
        const codeLines = [];
        i++;
        while (i < lines.length && !lines[i].trim().startsWith('```')) {
          codeLines.push(lines[i]);
          i++;
        }
        i++; // skip closing ```
        elements.push(
          <EnhancedCodeBlock
            key={`code-${i}`}
            lang={lang || null}
            code={codeLines.join('\n')}
          />
        );
        continue;
      }

      // ### Header (h5)
      if (trimmed.startsWith('### ')) {
        elements.push(
          <h5
            key={i}
            style={{
              fontSize: 13,
              fontWeight: 600,
              color: T.text,
              margin: '14px 0 4px',
              letterSpacing: '-0.01em',
            }}
          >
            {parseInline(trimmed.slice(4))}
          </h5>
        );
        i++;
        continue;
      }

      // ## Header (h4 with gradient title effect + accent bar)
      if (trimmed.startsWith('## ')) {
        elements.push(
          <h4
            key={i}
            style={{
              display: 'flex',
              alignItems: 'center',
              gap: 10,
              fontSize: 15,
              fontWeight: 700,
              margin: '18px 0 8px',
              letterSpacing: '-0.01em',
            }}
          >
            <span
              style={{
                width: 3,
                height: 18,
                background: GRADIENTS.primaryAccent,
                borderRadius: 2,
                flexShrink: 0,
              }}
            />
            <span
              style={{
                background: GRADIENTS.titleText,
                WebkitBackgroundClip: 'text',
                WebkitTextFillColor: 'transparent',
                backgroundClip: 'text',
              }}
            >
              {parseInline(trimmed.slice(3))}
            </span>
          </h4>
        );
        i++;
        continue;
      }

      // # Header (h3)
      if (trimmed.startsWith('# ')) {
        elements.push(
          <h3
            key={i}
            style={{
              fontSize: 18,
              fontWeight: 700,
              margin: '20px 0 10px',
              letterSpacing: '-0.02em',
              background: GRADIENTS.titleText,
              WebkitBackgroundClip: 'text',
              WebkitTextFillColor: 'transparent',
              backgroundClip: 'text',
            }}
          >
            {parseInline(trimmed.slice(2))}
          </h3>
        );
        i++;
        continue;
      }

      // Table (consecutive lines starting with |)
      if (trimmed.startsWith('|')) {
        const tableLines = [];
        while (i < lines.length && lines[i].trim().startsWith('|')) {
          tableLines.push(lines[i].trim());
          i++;
        }
        const parsed = parseTableRows(tableLines);
        if (parsed && parsed.headers.length > 0) {
          elements.push(
            <EnhancedTable
              key={`table-${i}`}
              headers={parsed.headers}
              rows={parsed.rows}
              onPivot={onPivot}
            />
          );
        }
        continue;
      }

      // Bullet list (- or *)
      if (/^[-*]\s/.test(trimmed)) {
        const items = [];
        while (i < lines.length && /^[-*]\s/.test(lines[i].trim())) {
          items.push(lines[i].trim().slice(2));
          i++;
        }
        elements.push(
          <ul
            key={`ul-${i}`}
            style={{
              margin: '6px 0 6px 4px',
              paddingLeft: 18,
              color: T.text,
              lineHeight: 1.7,
            }}
          >
            {items.map((item, idx) => (
              <li
                key={idx}
                style={{
                  marginBottom: 3,
                  paddingLeft: 2,
                }}
              >
                {parseInline(item)}
              </li>
            ))}
          </ul>
        );
        continue;
      }

      // Numbered list
      if (/^\d+\.\s/.test(trimmed)) {
        const items = [];
        while (i < lines.length && /^\d+\.\s/.test(lines[i].trim())) {
          items.push(lines[i].trim().replace(/^\d+\.\s/, ''));
          i++;
        }
        elements.push(
          <ol
            key={`ol-${i}`}
            style={{
              margin: '6px 0',
              paddingLeft: 22,
              color: T.text,
              lineHeight: 1.7,
            }}
          >
            {items.map((item, idx) => (
              <li
                key={idx}
                style={{
                  marginBottom: 3,
                  paddingLeft: 2,
                  '::marker': { color: THEME.primary },
                }}
              >
                {parseInline(item)}
              </li>
            ))}
          </ol>
        );
        continue;
      }

      // > Blockquote — rendered as an Intelligence Briefing callout banner
      if (trimmed.startsWith('> ')) {
        const quoteLines = [];
        while (i < lines.length && lines[i].trim().startsWith('> ')) {
          quoteLines.push(lines[i].trim().slice(2));
          i++;
        }
        const quoteText = quoteLines.join(' ');
        // Detect severity from content for color-coding
        const qLower = quoteText.toLowerCase();
        const briefingColor = qLower.includes('critical') ? THEME.danger
          : qLower.includes('high') ? '#F97316'
          : qLower.includes('medium') || qLower.includes('moderate') ? THEME.warning
          : THEME.primary;

        elements.push(
          <div
            key={`bq-${i}`}
            style={{
              margin: '6px 0 14px',
              padding: '12px 16px',
              borderRadius: 10,
              background: `linear-gradient(135deg, ${briefingColor}0C, ${briefingColor}04)`,
              border: `1px solid ${briefingColor}25`,
              borderLeft: `4px solid ${briefingColor}`,
              position: 'relative',
              overflow: 'hidden',
            }}
          >
            {/* Subtle shimmer accent */}
            <div style={{
              position: 'absolute', top: 0, right: 0, width: 120, height: '100%',
              background: `linear-gradient(90deg, transparent, ${briefingColor}06)`,
              pointerEvents: 'none',
            }} />
            <div style={{
              display: 'flex', alignItems: 'flex-start', gap: 10,
            }}>
              <div style={{
                width: 22, height: 22, borderRadius: 6, flexShrink: 0, marginTop: 1,
                background: `${briefingColor}18`, border: `1px solid ${briefingColor}30`,
                display: 'flex', alignItems: 'center', justifyContent: 'center',
              }}>
                <span style={{ fontSize: 11 }}>📋</span>
              </div>
              <div style={{
                fontSize: 12.5, color: T.textSecondary, lineHeight: 1.65,
                fontStyle: 'normal',
              }}>
                {quoteLines.map((ql, idx) => (
                  <div key={idx}>{parseInline(ql)}</div>
                ))}
              </div>
            </div>
          </div>
        );
        continue;
      }

      // Default: paragraph
      elements.push(
        <p
          key={i}
          style={{
            margin: '5px 0',
            color: T.text,
            lineHeight: 1.6,
            fontSize: 13,
          }}
        >
          {parseInline(trimmed)}
        </p>
      );
      i++;
    }

    return elements;
  }, [content, onPivot]);

  return (
    <div style={{ wordWrap: 'break-word', overflowWrap: 'break-word' }}>
      {rendered}
    </div>
  );
}

export default React.memo(PallasMarkdown);
