"""
BlockBuilder — Constructs typed JSON blocks for the v3 hybrid rendering protocol.

Each block corresponds to a specialized frontend React component (gauge, donut,
bar chart, card grid, timeline, etc.). When the WebSocket response includes a
`blocks` array, the frontend renders them directly — no markdown pattern-detection,
no heuristic matching, 100% reliable.

See BLOCK_SCHEMAS.md in the frontend repo for the full JSON contract.

Usage in a formatter:
    from .block_builder import BlockBuilder

    def format_agent_overview(self, agents):
        bb = BlockBuilder()
        bb.kpi_grid("Agent Summary", [...])
        bb.health_status(label="Fleet", percentage=92, ...)
        bb.agent_table([...])
        return markdown_str, bb.to_list()
"""

from typing import Any, Dict, List, Optional


# ─── Severity color palette (matches frontend THEME) ────────────────────────

SEV_COLORS = {
    "critical": "#EF4444",
    "high":     "#F97316",
    "medium":   "#F59E0B",
    "low":      "#64748B",
    "info":     "#64748B",
}


class BlockBuilder:
    """Accumulates typed blocks during response formatting."""

    def __init__(self):
        self._blocks: List[Dict[str, Any]] = []

    def add(self, block_type: str, data: dict) -> "BlockBuilder":
        self._blocks.append({"type": block_type, "data": data})
        return self

    def to_list(self) -> List[Dict[str, Any]]:
        """Return the accumulated blocks as a plain list of dicts."""
        return list(self._blocks)

    def __len__(self):
        return len(self._blocks)

    # ── Convenience methods ──────────────────────────────────────────────────

    def kpi_grid(self, title: Optional[str], items: list) -> "BlockBuilder":
        """
        Hero stats grid. Each item: {label, value, raw_value, is_percent}.
        """
        return self.add("kpi_grid", {"title": title, "items": items})

    def severity_breakdown(self, segments: list, total: int = None) -> "BlockBuilder":
        """
        Stacked severity bar. Each segment: {label, key, value, color}.
        """
        if total is None:
            total = sum(s.get("value", 0) for s in segments)
        return self.add("severity_breakdown", {"segments": segments, "total": total})

    def agent_table(self, agents: list) -> "BlockBuilder":
        """
        Agent card grid. Each agent: {agent_id, name, ip, os, version, status, last_keep_alive}.
        """
        return self.add("agent_table", {"agents": agents})

    def vulnerability_table(self, vulnerabilities: list) -> "BlockBuilder":
        """
        CVE card grid. Each vuln: {cve, severity, package, version, description, agent}.
        """
        return self.add("vulnerability_table", {"vulnerabilities": vulnerabilities})

    def rule_table(self, rules: list) -> "BlockBuilder":
        """
        Rule card grid. Each rule: {rule_id, description, level, groups, firedtimes}.
        """
        return self.add("rule_table", {"rules": rules})

    def top_attackers(self, kind: str, entries: list) -> "BlockBuilder":
        """
        Ranked horizontal bar chart. kind='sources'|'targets'.
        Each entry: {ip, count}.
        """
        return self.add("top_attackers", {"kind": kind, "entries": entries})

    def risk_score(self, level: str, score: int, max_score: int = 1000) -> "BlockBuilder":
        """Radial risk gauge."""
        return self.add("risk_score", {"level": level, "score": score, "max": max_score})

    def health_status(self, label: str, percentage: float, total: int,
                      active: int, disconnected: int, never_connected: int = 0) -> "BlockBuilder":
        """Donut chart for agent/service health."""
        return self.add("health_status", {
            "label": label,
            "percentage": round(percentage, 1),
            "total": total,
            "active": active,
            "disconnected": disconnected,
            "neverConnected": never_connected,
        })

    def time_series(self, points: list, metric_label: str = "Count",
                    time_label: str = "Time") -> "BlockBuilder":
        """
        Sparkline chart. Each point: {label, value}.
        """
        return self.add("time_series", {
            "points": points,
            "metricLabel": metric_label,
            "timeLabel": time_label,
        })

    def timeline(self, events: list, title: str = None) -> "BlockBuilder":
        """
        Vertical timeline. Each event: {timestamp, severity, title, detail, rule_id?, agent?}.
        """
        return self.add("timeline", {"events": events, "title": title})

    def flow_diagram(self, flows: list, title: str = None) -> "BlockBuilder":
        """
        Network flow rows. Each flow: {src_ip, dst_ip, src_port?, dst_port?, proto?, bytes?, packets?, action?}.
        """
        return self.add("flow_diagram", {"flows": flows, "title": title})

    def comparison(self, left: dict, right: dict, metrics: list,
                   title: str = None) -> "BlockBuilder":
        """
        Side-by-side comparison. left/right: {label, accent}.
        Each metric: {name, leftValue, rightValue}.
        """
        return self.add("comparison", {
            "title": title, "left": left, "right": right, "metrics": metrics,
        })

    def mitre_matrix(self, tactics: list, total_techniques: int = 0,
                     total_alerts: int = 0) -> "BlockBuilder":
        """
        MITRE ATT&CK tactic grid. Each tactic: {id, name, techniques: [{id, name, count}]}.
        """
        return self.add("mitre_matrix", {
            "tactics": tactics,
            "totalTechniques": total_techniques,
            "totalAlerts": total_alerts,
        })

    def badge_cloud(self, groups: list, title: str = None) -> "BlockBuilder":
        """
        Compliance / framework chip cloud.
        Each group: {framework, label?, items: [{id, label?}]}.
        """
        return self.add("badge_cloud", {"groups": groups, "title": title})

    def prose(self, content: str) -> "BlockBuilder":
        """Free-form markdown section."""
        return self.add("prose", {"content": content})

    def recommendations(self, items: list) -> "BlockBuilder":
        """
        Action list. Each item: {text, priority} where priority is
        'critical'|'high'|'medium'|'low'.
        """
        return self.add("recommendations", {"recommendations": items})

    # ── Helper: build KPI item dict ──────────────────────────────────────────

    @staticmethod
    def kpi_item(label: str, value, raw_value: str = None, is_percent: bool = False) -> dict:
        """Convenience factory for a single KPI item."""
        if raw_value is None:
            raw_value = f"{value:,}" if isinstance(value, (int, float)) else str(value)
            if is_percent:
                raw_value = f"{value}%"
        return {
            "label": label,
            "value": value if isinstance(value, (int, float)) else 0,
            "raw_value": raw_value,
            "is_percent": is_percent,
        }

    @staticmethod
    def sev_segment(label: str, value: int, level: str = None) -> dict:
        """Convenience factory for a severity segment."""
        key = (level or label).lower()
        return {
            "label": label,
            "key": key,
            "value": value,
            "color": SEV_COLORS.get(key, SEV_COLORS["low"]),
        }
