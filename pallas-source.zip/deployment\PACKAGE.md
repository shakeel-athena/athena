# Pallas Frontend — Deploy Package

**Frontend ONLY.** Backend (Wazuh-MCP-Server) is deployed separately and is NOT included in this bundle. This separation exists so that:

1. **Backend secrets stay out of the deploy artifact.** A leaked HuggingFace token (`hf_*`) burned us once when `backend/.env` got included in a public repo. Frontend bundle has no `.env` files, no API keys, no Keycloak secrets — only public source.
2. **Backend changes are infrequent.** Frontend ships per-feature; backend ships per-release. No reason to rebuild + redeploy the backend on every UI tweak.
3. **The two have different rebuild times.** Frontend rebuild = 60–90s. Backend rebuild + container swap = 5+ min and risks chat-WebSocket interruption.

## What's in the zip

| Path | Purpose |
|---|---|
| `src/` | React source — webpack bundles this into the image |
| `public/` | Static index.html + favicons + manifest |
| `package.json`, `package-lock.json` | npm dependencies (resolved during image build) |
| `deployment/Dockerfile.simple` | Multi-stage Dockerfile that runs `npm run build` then serves with nginx |
| `deployment/nginx.simple.conf` | nginx config — port 8001, SPA fallback, `/ai-analyst/` proxy to backend |

## What's NOT in the zip (intentional)

- ❌ `backend/` — Wazuh-MCP-Server lives at `/opt/mcpserver_rizwan_soar/Wazuh-MCP-Server/` on the server. Deploy backend changes by copying the file(s) directly on the server (see backend deploy notes).
- ❌ `node_modules/` — too large, rebuilt by `npm ci` inside the Docker image
- ❌ `.env`, `.env.*`, `*.key`, `*.pem` — never put secrets in deploy artifacts
- ❌ `.git/` — version control irrelevant on server

## Build the package (on your dev machine)

```powershell
cd "d:\Athena\Promochos\Main Branch\stages\pallas-app"
Remove-Item pallas-source.zip -ErrorAction SilentlyContinue

# FRONTEND ONLY — no backend folder
Compress-Archive `
  -Path src, public, package.json, package-lock.json, deployment `
  -DestinationPath pallas-source.zip -Force

# Sanity check — confirm no backend/ folder in the zip
Add-Type -AssemblyName System.IO.Compression.FileSystem
$archive = [System.IO.Compression.ZipFile]::OpenRead("$PWD\pallas-source.zip")
$hasBackend = $archive.Entries | Where-Object { $_.FullName -like 'backend/*' } | Select-Object -First 1
$archive.Dispose()
if ($hasBackend) {
  Write-Error "❌ Zip contains backend folder — re-run without 'backend' in -Path"
  exit 1
} else {
  Write-Host "✓ Zip is frontend-only" -ForegroundColor Green
}

# Sanity check — confirm no .env file
$archive = [System.IO.Compression.ZipFile]::OpenRead("$PWD\pallas-source.zip")
$hasEnv = $archive.Entries | Where-Object { $_.Name -like '.env*' } | Select-Object -First 1
$archive.Dispose()
if ($hasEnv) {
  Write-Error "❌ Zip contains .env file — secrets at risk"
  exit 1
} else {
  Write-Host "✓ Zip has no .env files" -ForegroundColor Green
}
```

## Upload + deploy

```powershell
scp pallas-source.zip root@172.16.134.12:/tmp/
```

```bash
# On Pallas server
cd /opt/pallas-app
unzip -qo /tmp/pallas-source.zip
docker build --no-cache -f Dockerfile.simple -t pallas-ui:latest .
docker stop pallas-ui && docker rm pallas-ui
docker run -d --name pallas-ui --network host --restart unless-stopped pallas-ui:latest
sleep 3
curl -sI http://localhost:8001/ | head -3
```

## Backend changes (separate path)

Backend code lives at `/opt/mcpserver_rizwan_soar/Wazuh-MCP-Server/` on the server. To deploy a backend change:

```bash
# Option A — direct edit on the server (small fixes)
vi /opt/mcpserver_rizwan_soar/Wazuh-MCP-Server/src/wazuh_mcp_server/server.py
cd /opt/mcpserver_rizwan_soar/Wazuh-MCP-Server
docker compose down && docker compose build --no-cache && docker compose up -d

# Option B — scp from dev machine (single file)
scp src/wazuh_mcp_server/server.py root@172.16.134.12:/opt/mcpserver_rizwan_soar/Wazuh-MCP-Server/src/wazuh_mcp_server/server.py
ssh root@172.16.134.12
cd /opt/mcpserver_rizwan_soar/Wazuh-MCP-Server && docker compose down && docker compose build --no-cache && docker compose up -d

# Option C — pull from a private repo (recommended for production)
# Set up a private GitHub repo for the backend code, then:
ssh root@172.16.134.12
cd /opt/mcpserver_rizwan_soar/Wazuh-MCP-Server && git pull origin main
docker compose down && docker compose build --no-cache && docker compose up -d
```

## Security notes

- The `pallas-source.zip` file may still be uploaded to a Git-hosted deploy repo (e.g. for the no-VPN deploy flow). **That repo MUST be private**. Even with `.env` excluded, public exposure of the deploy zip is a footgun.
- Rotate any HuggingFace / OpenRouter / API tokens after first use to confirm no historical leak. Check via:
  ```
  https://github.com/search?q=%22hf_%22+user%3A<your-org>&type=code
  ```
- Add `.env*` and `*.key` to `.gitignore` at the repo root if not already there.
