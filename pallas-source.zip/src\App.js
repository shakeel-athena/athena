/**
 * Pallas AI — Standalone Application
 *
 * Self-contained Pallas workspace with own navigation, header, and status bar.
 * No dependency on Ageleia Layout, Sidebar, or Header.
 */

import { useState, useEffect, useCallback, lazy, Suspense } from 'react';
import { THEME } from './utils/theme';
import { fetchMeta } from './services/pallasService';
import { PALLAS_KEYFRAMES, MODULE_COLORS, Spinner } from './components/PallasAnalyst/PallasUI';
import { VALID_MODULES } from './components/PallasAnalyst/PallasNavigationRail';
import { PallasErrorBoundary } from './components/PallasAnalyst/PallasErrorBoundary';

// Module components (lazy loaded)
const PallasSOCChat = lazy(() => import('./components/PallasAnalyst/PallasSOCChat'));
const PallasDetectIOC = lazy(() => import('./components/PallasAnalyst/PallasDetectIOC'));
const PallasDecoderLab = lazy(() => import('./components/PallasAnalyst/PallasDecoderLab'));
const PallasSIEMTools = lazy(() => import('./components/PallasAnalyst/PallasSIEMTools'));
const PallasNIDSTools = lazy(() => import('./components/PallasAnalyst/PallasNIDSTools'));
const PallasVulnsDashboard = lazy(() => import('./components/PallasAnalyst/PallasVulnsDashboard'));
const PallasCorrelations = lazy(() => import('./components/PallasAnalyst/PallasCorrelations'));
const PallasAttackNarrative = lazy(() => import('./components/PallasAnalyst/PallasAttackNarrative'));

// ─── Helpers ────────────────────────────────────────────────────────────────

const DEFAULT_TOOL_HEALTH = {
  wazuh_manager: 'connecting',
  wazuh_indexer: 'connecting',
  suricata: 'connecting',
  ollama: 'connecting',
};

const getInitialModule = () => {
  const hash = window.location.hash.slice(1);
  return VALID_MODULES.includes(hash) ? hash : 'chat';
};

function ModuleLoadingFallback({ moduleId }) {
  const mc = MODULE_COLORS[moduleId] || MODULE_COLORS.chat;
  return (
    <div style={{
      display: 'flex', flexDirection: 'column', alignItems: 'center',
      justifyContent: 'center', height: '100%', gap: 12,
      animation: 'pallas-fadeIn 0.2s ease',
    }}>
      <Spinner size={20} color={mc.accent} />
      <span style={{ fontSize: 12, color: THEME.textMuted, fontWeight: 500 }}>
        Loading {mc.label}...
      </span>
    </div>
  );
}

// ─── Main App ───────────────────────────────────────────────────────────────

export default function App() {
  const [activeModule, setActiveModule] = useState(getInitialModule);
  const [connectionStatus, setConnectionStatus] = useState('connecting');
  const [toolHealth, setToolHealth] = useState(DEFAULT_TOOL_HEALTH);
  const [commandPaletteOpen, setCommandPaletteOpen] = useState(false);
  const [pendingChatQuery, setPendingChatQuery] = useState(null);

  // ─── Hide preloader once app mounts ─────────────────────────────────────
  useEffect(() => {
    if (window.__hidePallasPreloader) window.__hidePallasPreloader();
  }, []);

  // ─── Tool health polling ──────────────────────────────────────────────────

  const fetchToolHealth = useCallback(async () => {
    try {
      const data = await fetchMeta();
      const svc = data.services || {};
      const mapStatus = (key) => {
        const val = svc[key];
        if (!val) return 'disabled';
        if (val === 'healthy') return 'connected';
        if (typeof val === 'string' && val.startsWith('unhealthy')) return 'error';
        return 'connecting';
      };
      setToolHealth({
        wazuh_manager: mapStatus('wazuh_manager'),
        wazuh_indexer: mapStatus('wazuh_indexer'),
        suricata: mapStatus('suricata_ids'),
        ollama: svc.query_orchestrator === 'initialized' ? 'connected' : 'disabled',
      });
      setConnectionStatus('connected');
    } catch {
      setConnectionStatus((prev) => (prev === 'connected' ? prev : 'error'));
    }
  }, []);

  useEffect(() => {
    fetchToolHealth();
    const interval = setInterval(fetchToolHealth, 30000);
    return () => clearInterval(interval);
  }, [fetchToolHealth]);

  useEffect(() => {
    if (connectionStatus === 'connected') {
      setToolHealth((prev) => {
        const hasRestData = prev.wazuh_manager === 'connected';
        if (hasRestData) return prev;
        return { wazuh_manager: 'connected', wazuh_indexer: 'connected', suricata: 'connected', ollama: 'connected' };
      });
    }
  }, [connectionStatus]);

  // ─── Ctrl+K command palette ─────────────────────────────────────────────

  useEffect(() => {
    const handleKeyDown = (e) => {
      if ((e.ctrlKey || e.metaKey) && e.key === 'k') {
        e.preventDefault();
        setCommandPaletteOpen((prev) => !prev);
      }
      if (e.key === 'Escape') setCommandPaletteOpen(false);
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);

  // ─── URL hash sync ────────────────────────────────────────────────────────

  useEffect(() => { window.location.hash = activeModule; }, [activeModule]);

  useEffect(() => {
    const onHashChange = () => {
      const hash = window.location.hash.slice(1);
      if (VALID_MODULES.includes(hash)) setActiveModule(hash);
    };
    window.addEventListener('hashchange', onHashChange);
    return () => window.removeEventListener('hashchange', onHashChange);
  }, []);

  // ─── Cross-module query completion ────────────────────────────────────────

  const handleQueryComplete = useCallback((module, query, durationMs) => {
    if (module === activeModule) return;
    console.info(`[Pallas] ${module} query completed in ${(durationMs / 1000).toFixed(1)}s`);
  }, [activeModule]);

  // ─── Module renderer ──────────────────────────────────────────────────────

  const renderModule = () => {
    const commonProps = {
      connectionStatus,
      onConnectionStatusChange: setConnectionStatus,
      onQueryComplete: handleQueryComplete,
    };

    switch (activeModule) {
      case 'chat':
        return (
          <PallasSOCChat
            {...commonProps}
            commandPaletteOpen={commandPaletteOpen}
            onCommandPaletteClose={() => setCommandPaletteOpen(false)}
            pendingQuery={pendingChatQuery}
            onPendingQueryConsumed={() => setPendingChatQuery(null)}
          />
        );
      case 'ioc': return <PallasDetectIOC {...commonProps} />;
      case 'decoder': return <PallasDecoderLab {...commonProps} />;
      case 'siem': return <PallasSIEMTools {...commonProps} toolHealth={toolHealth} />;
      case 'nids': return <PallasNIDSTools {...commonProps} toolHealth={toolHealth} />;
      case 'vulns': return <PallasVulnsDashboard {...commonProps} />;
      case 'correlations': return <PallasCorrelations {...commonProps} />;
      case 'narrative': return <PallasAttackNarrative {...commonProps} />;
      default: return null;
    }
  };

  // ─── Render ───────────────────────────────────────────────────────────────

  return (
    <div style={{
      height: '100vh',
      display: 'flex',
      flexDirection: 'column',
      backgroundColor: THEME.bg,
      overflow: 'hidden',
      fontFamily: 'Inter, -apple-system, BlinkMacSystemFont, sans-serif',
      fontSize: '13px',
      lineHeight: '1.5',
      color: THEME.text,
      WebkitFontSmoothing: 'antialiased',
    }}>
      <style>{PALLAS_KEYFRAMES}</style>

      {/* Module Content — full screen, no nav rail/header/statusbar when embedded */}
      <div className="pallas-scrollbar" style={{ flex: 1, overflow: 'hidden', position: 'relative' }}>
        <PallasErrorBoundary>
          <Suspense fallback={<ModuleLoadingFallback moduleId={activeModule} />}>
            <div key={activeModule} style={{ animation: 'pallas-fadeIn 0.2s ease', height: '100%' }}>
              {renderModule()}
            </div>
          </Suspense>
        </PallasErrorBoundary>
      </div>
    </div>
  );
}
