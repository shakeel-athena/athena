/**
 * PallasDetectIOC — IOC Reputation & IP Investigation plugin
 *
 * Redesigned with shared PallasUI components and IOC accent color (#EF4444).
 * Two-tab interface: IOC Reputation (WebSocket) + IP Investigation (REST).
 */

import React, { useState, useCallback, useEffect } from 'react';
import { EuiIcon } from '@elastic/eui';
import { THEME } from '../../utils/theme';
import { MODULE_COLORS, ActionChip, GlassCard, FONT, ChatDisclaimer } from './PallasUI';
import { usePallas } from '../../hooks/usePallas';
import { ResponsePanel } from './PallasResponsePanel';
import { pallasPost } from '../../services/pallasService';
import PallasLogo from '../../artifacts/pallas-icon-light.svg';

const ACCENT = MODULE_COLORS.ioc.accent;
const BTN_BG = 'linear-gradient(135deg, #00BFB3 0%, #00D4C8 100%)'; // Matches chat send button

// ─── Indicator type definitions ──────────────────────────────────────────────

const INDICATOR_TYPES = [
  { key: 'ip', label: 'IP Address', icon: 'globe', placeholder: 'e.g. 192.168.1.100' },
  { key: 'hash', label: 'File Hash', icon: 'document', placeholder: 'e.g. d41d8cd98f00b204e9800998ecf8427e' },
  { key: 'domain', label: 'Domain', icon: 'globe', placeholder: 'e.g. malware-c2.example.com' },
  { key: 'username', label: 'Username', icon: 'user', placeholder: 'e.g. jdoe' },
];

const TIME_RANGES = ['1h', '6h', '24h', '7d', '30d'];

// ─── Query builder ──────────────────────────────────────────────────────────

function buildIOCQuery(type, value) {
  const map = {
    ip: `check ioc reputation for IP ${value}`,
    hash: `check ioc reputation for hash ${value}`,
    domain: `check ioc reputation for domain ${value}`,
    username: `analyze security threat for user ${value}`,
  };
  return map[type] || `check ioc reputation for ${value}`;
}

// ─── IP Result Card ─────────────────────────────────────────────────────────

const IP_CARD_CONFIG = [
  { key: 'wazuh_alerts', label: 'Wazuh Alerts', color: '#4493F8' },
  { key: 'wazuh_vulnerabilities', label: 'Wazuh Vulnerabilities', color: '#F0B429' },
  { key: 'suricata_alerts', label: 'Suricata Alerts', color: '#FF8C42' },
];

function IPResultCard({ label, count, index, borderColor }) {
  return (
    <GlassCard style={{
      borderTop: `3px solid ${borderColor}`,
      padding: 16,
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'center',
      gap: 6,
    }}>
      <div style={{
        fontSize: 28, fontWeight: 700, fontFamily: FONT.mono, color: THEME.text,
      }}>
        {typeof count === 'number' ? count.toLocaleString() : '\u2014'}
      </div>
      <div style={{ fontSize: 12, color: THEME.textSecondary, fontWeight: 500 }}>{label}</div>
      {index && (
        <div style={{ fontSize: 10, color: THEME.textMuted, fontFamily: FONT.mono, marginTop: 2 }}>
          {index}
        </div>
      )}
    </GlassCard>
  );
}

// ─── Main Component ─────────────────────────────────────────────────────────

export default function PallasDetectIOC({ connectionStatus, onConnectionStatusChange, onQueryComplete, onClose, hideHeader }) {
  const accent = ACCENT;
  const [activeTab, setActiveTab] = useState('ioc');

  // IOC Reputation tab state
  const [indicator, setIndicator] = useState('');
  const [indicatorType, setIndicatorType] = useState('ip');
  const {
    response,
    isLoading,
    connectionStatus: wsStatus,
    sendQuery,
    cancelQuery,
    pinnedResponses,
    pinResponse,
    unpinResponse,
  } = usePallas('ioc', { onQueryComplete });

  // Bubble WS status up to parent
  useEffect(() => {
    if (onConnectionStatusChange) onConnectionStatusChange(wsStatus);
  }, [wsStatus, onConnectionStatusChange]);

  // IP Investigation tab state
  const [ipValue, setIpValue] = useState('');
  const [ipTimeRange, setIpTimeRange] = useState('24h');
  const [ipLoading, setIpLoading] = useState(false);
  const [ipResult, setIpResult] = useState(null);
  const [ipError, setIpError] = useState(null);

  // IOC handlers
  const handleIOCSearch = useCallback(() => {
    const trimmed = indicator.trim();
    if (!trimmed || isLoading) return;
    sendQuery(buildIOCQuery(indicatorType, trimmed));
  }, [indicator, indicatorType, isLoading, sendQuery]);

  const handleIOCKeyDown = useCallback((e) => {
    if (e.key === 'Enter') handleIOCSearch();
  }, [handleIOCSearch]);

  // IP Investigation handler
  const handleIPInvestigate = useCallback(async () => {
    const trimmed = ipValue.trim();
    if (!trimmed) return;
    setIpLoading(true);
    setIpResult(null);
    setIpError(null);
    try {
      const data = await pallasPost('/api/ip/investigate', { ip: trimmed, time_range: ipTimeRange });
      setIpResult(data);
      if (onQueryComplete) onQueryComplete('ioc', `IP investigate: ${trimmed}`, data.duration_ms);
    } catch (e) {
      setIpError(e.message || 'Failed to investigate IP');
    } finally {
      setIpLoading(false);
    }
  }, [ipValue, ipTimeRange, onQueryComplete]);

  const handleIPKeyDown = useCallback((e) => {
    if (e.key === 'Enter') handleIPInvestigate();
  }, [handleIPInvestigate]);

  const currentType = INDICATOR_TYPES.find((t) => t.key === indicatorType) || INDICATOR_TYPES[0];

  const tabs = [
    { key: 'ioc', label: 'IOC Reputation', icon: 'shield' },
    { key: 'ip', label: 'IP Investigation', icon: 'compute' },
  ];

  const hasResults = !!(response || isLoading || ipResult || ipLoading);

  return (
    <div style={{ display: 'flex', flexDirection: 'column', height: '100%', fontFamily: FONT.base }}>

      {/* ═══ WELCOME STATE — matches chat welcome screen ═══ */}
      {!hasResults && (
        <div style={{
          flex: 1, display: 'flex', flexDirection: 'column', alignItems: 'center',
          justifyContent: 'center', padding: '0 24px', gap: 0,
        }}>
          <img src={PallasLogo} alt="Pallas AI" style={{ width: 90, height: 90, marginBottom: 12, opacity: 0.9 }} />
          <h3 style={{ fontSize: 22, fontWeight: 700, color: THEME.text, margin: '0 0 6px', letterSpacing: '-0.01em' }}>
            Threat Intel
          </h3>
          <p style={{ fontSize: 13, color: THEME.textMuted, margin: '0 0 24px', textAlign: 'center', maxWidth: 420, lineHeight: 1.5 }}>
            Search for indicators of compromise and investigate IPs across all indexes
          </p>

          {/* Tab selector */}
          <div style={{ display: 'flex', gap: 6, marginBottom: 20 }}>
            {tabs.map((tab) => {
              const isActive = activeTab === tab.key;
              return (
                <button key={tab.key} onClick={() => setActiveTab(tab.key)} style={{
                  padding: '8px 20px', background: isActive ? `${accent}15` : 'transparent',
                  border: `1px solid ${isActive ? accent + '40' : THEME.border}`,
                  borderRadius: 8, color: isActive ? THEME.text : THEME.textSecondary,
                  fontSize: 13, fontWeight: isActive ? 600 : 400, cursor: 'pointer',
                  display: 'flex', alignItems: 'center', gap: 6, outline: 'none', transition: 'all 0.15s',
                }}>
                  <EuiIcon type={tab.icon} size="s" color={isActive ? accent : THEME.textSecondary} />
                  {tab.label}
                </button>
              );
            })}
          </div>

          {/* Indicator type chips (IOC tab) */}
          {activeTab === 'ioc' && (
            <div style={{ display: 'flex', gap: 8, marginBottom: 16 }}>
              {INDICATOR_TYPES.map((type) => (
                <ActionChip key={type.key} icon={type.icon} label={type.label}
                  onClick={() => setIndicatorType(type.key)} active={indicatorType === type.key} accent={accent} />
              ))}
            </div>
          )}

          {/* Time range chips (IP tab) */}
          {activeTab === 'ip' && (
            <div style={{ display: 'flex', gap: 6, marginBottom: 16 }}>
              {TIME_RANGES.map((range) => (
                <ActionChip key={range} label={range} onClick={() => setIpTimeRange(range)} active={ipTimeRange === range} accent={accent} />
              ))}
            </div>
          )}

          {/* Input field — centered, same style as chat */}
          <div style={{ width: '100%', maxWidth: 620, position: 'relative' }}>
            <div style={{
              borderRadius: 12, border: `1px solid ${THEME.border}`, backgroundColor: '#0D1520',
              display: 'flex', alignItems: 'center', overflow: 'hidden',
            }}>
              <input
                type="text"
                value={activeTab === 'ioc' ? indicator : ipValue}
                onChange={(e) => activeTab === 'ioc' ? setIndicator(e.target.value) : setIpValue(e.target.value)}
                onKeyDown={activeTab === 'ioc' ? handleIOCKeyDown : handleIPKeyDown}
                placeholder={activeTab === 'ioc' ? currentType.placeholder : 'Enter IP address (e.g. 10.0.0.50)'}
                style={{
                  flex: 1, padding: '14px 16px', border: 'none', outline: 'none',
                  backgroundColor: 'transparent', color: THEME.text, fontSize: 14,
                  fontFamily: activeTab === 'ip' ? FONT.mono : FONT.base, boxSizing: 'border-box',
                }}
              />
              <button
                onClick={activeTab === 'ioc' ? handleIOCSearch : handleIPInvestigate}
                disabled={activeTab === 'ioc' ? (!indicator.trim() || isLoading) : (!ipValue.trim() || ipLoading)}
                style={{
                  margin: 6, padding: '8px 18px', border: 'none', borderRadius: 8,
                  background: BTN_BG, color: '#fff', fontWeight: 600, fontSize: 13,
                  cursor: 'pointer', display: 'flex', alignItems: 'center', gap: 6,
                  opacity: (activeTab === 'ioc' ? (!indicator.trim() || isLoading) : (!ipValue.trim() || ipLoading)) ? 0.5 : 1,
                  outline: 'none', flexShrink: 0,
                }}
              >
                <EuiIcon type="search" size="s" color="#fff" />
                {activeTab === 'ioc' ? 'Search' : 'Investigate'}
              </button>
            </div>
            <ChatDisclaimer align="center" marginTop={6} />
          </div>
        </div>
      )}

      {/* ═══ RESULTS STATE — response on top, form at bottom ═══ */}
      {hasResults && (
        <>
          {/* Response area — scrollable, fills available space */}
          <div style={{ flex: 1, overflowY: 'auto', padding: '16px 24px' }} className="pallas-scrollbar">
            <div style={{ maxWidth: 1320, margin: '0 auto', width: '100%' }}>
              {activeTab === 'ioc' && (response || isLoading) && (
                <ResponsePanel
                  content={response?.content}
                  blocks={response?.blocks}
                  metadata={response?.metadata}
                  socAnalysis={response?.socAnalysis}
                  suggestions={response?.suggestions}
                  isLoading={isLoading}
                  onCancel={isLoading ? cancelQuery : undefined}
                  onPin={response ? () => pinResponse(response) : undefined}
                  isPinned={response ? pinnedResponses.some(
                    (p) => p.content === response.content && p.timestamp === response.timestamp
                  ) : false}
                  accent={accent}
                />
              )}

              {activeTab === 'ip' && (
                <>
                  {ipLoading && (
                    <div style={{ display: 'flex', alignItems: 'center', gap: 10, padding: '24px 0', justifyContent: 'center' }}>
                      <span style={{
                        display: 'inline-block', width: 20, height: 20,
                        border: `2px solid ${THEME.border}`, borderTopColor: accent,
                        borderRadius: '50%', animation: 'pallas-spin 0.6s linear infinite',
                      }} />
                      <span style={{ fontSize: 12, color: THEME.textSecondary }}>Searching across all indexes...</span>
                    </div>
                  )}
                  {ipError && (
                    <div style={{
                      padding: '10px 14px', background: 'rgba(239,68,68,0.12)',
                      border: '1px solid rgba(239,68,68,0.3)', borderRadius: 6, color: '#f87171', fontSize: 12,
                      display: 'flex', alignItems: 'center', gap: 8, marginBottom: 12,
                    }}>
                      <EuiIcon type="warning" size="s" color="#f87171" /> {ipError}
                    </div>
                  )}
                  {ipResult && !ipLoading && (
                    <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
                      <GlassCard style={{ textAlign: 'center', padding: '14px 0' }}>
                        <div style={{ fontSize: 32, fontWeight: 700, fontFamily: FONT.mono, color: accent }}>
                          {typeof ipResult.total === 'number' ? ipResult.total.toLocaleString() : '\u2014'}
                        </div>
                        <div style={{ fontSize: 11, color: THEME.textSecondary, marginTop: 4 }}>Total Hits</div>
                      </GlassCard>
                      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 10 }}>
                        {IP_CARD_CONFIG.map((cfg) => {
                          const result = ipResult.results
                            ? ipResult.results.find((r) => r.key === cfg.key || r.label === cfg.label)
                            : null;
                          return (
                            <IPResultCard key={cfg.key} label={cfg.label}
                              count={result ? result.count : 0} index={result ? result.index : null} borderColor={cfg.color} />
                          );
                        })}
                      </div>
                    </div>
                  )}
                </>
              )}
            </div>
          </div>

          {/* Bottom form — centered, no full-width background, matches chat input */}
          <div style={{
            flexShrink: 0, padding: '12px 24px 16px',
          }}>
            <div style={{ maxWidth: 680, margin: '0 auto', display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 10 }}>
              {/* Tabs */}
              <div style={{ display: 'flex', gap: 6 }}>
                {tabs.map((tab) => {
                  const isActive = activeTab === tab.key;
                  return (
                    <button key={tab.key} onClick={() => setActiveTab(tab.key)} style={{
                      padding: '6px 18px', background: isActive ? `${accent}15` : 'transparent',
                      border: `1px solid ${isActive ? accent + '40' : THEME.border}`,
                      borderRadius: 8, color: isActive ? THEME.text : THEME.textSecondary,
                      fontSize: 12, fontWeight: isActive ? 600 : 400, cursor: 'pointer',
                      display: 'flex', alignItems: 'center', gap: 5, outline: 'none', transition: 'all 0.15s',
                    }}>
                      <EuiIcon type={tab.icon} size="s" color={isActive ? accent : THEME.textSecondary} />
                      {tab.label}
                    </button>
                  );
                })}
              </div>

              {/* Indicator type / time range chips */}
              <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap', justifyContent: 'center' }}>
                {activeTab === 'ioc' && INDICATOR_TYPES.map((type) => (
                  <ActionChip key={type.key} icon={type.icon} label={type.label}
                    onClick={() => setIndicatorType(type.key)} active={indicatorType === type.key} accent={accent} />
                ))}
                {activeTab === 'ip' && TIME_RANGES.map((range) => (
                  <ActionChip key={range} label={range} onClick={() => setIpTimeRange(range)} active={ipTimeRange === range} accent={accent} />
                ))}
              </div>

              {/* Input field — same style as chat welcome input */}
              <div style={{ width: '100%' }}>
                <div style={{
                  borderRadius: 12, border: `1px solid ${THEME.border}`, backgroundColor: '#0D1520',
                  display: 'flex', alignItems: 'center', overflow: 'hidden',
                }}>
                  <input
                    type="text"
                    value={activeTab === 'ioc' ? indicator : ipValue}
                    onChange={(e) => activeTab === 'ioc' ? setIndicator(e.target.value) : setIpValue(e.target.value)}
                    onKeyDown={activeTab === 'ioc' ? handleIOCKeyDown : handleIPKeyDown}
                    placeholder={activeTab === 'ioc' ? currentType.placeholder : 'Enter IP address (e.g. 10.0.0.50)'}
                    style={{
                      flex: 1, padding: '12px 16px', border: 'none', outline: 'none',
                      backgroundColor: 'transparent', color: THEME.text, fontSize: 14,
                      fontFamily: activeTab === 'ip' ? FONT.mono : FONT.base, boxSizing: 'border-box',
                    }}
                  />
                  <button
                    onClick={activeTab === 'ioc' ? handleIOCSearch : handleIPInvestigate}
                    disabled={activeTab === 'ioc' ? (!indicator.trim() || isLoading) : (!ipValue.trim() || ipLoading)}
                    style={{
                      margin: 6, padding: '8px 18px', border: 'none', borderRadius: 8,
                      background: BTN_BG, color: '#fff', fontWeight: 600, fontSize: 13,
                      cursor: 'pointer', display: 'flex', alignItems: 'center', gap: 6,
                      opacity: (activeTab === 'ioc' ? (!indicator.trim() || isLoading) : (!ipValue.trim() || ipLoading)) ? 0.5 : 1,
                      outline: 'none', flexShrink: 0,
                    }}
                  >
                    <EuiIcon type="search" size="s" color="#fff" />
                    {(isLoading || ipLoading) ? 'Searching...' : 'Search'}
                  </button>
                </div>
                <ChatDisclaimer align="center" marginTop={6} />
              </div>
            </div>
          </div>
        </>
      )}
    </div>
  );
}

// end of PallasDetectIOC
