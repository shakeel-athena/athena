/**
 * EntityListBlock — Premium SOC card list for entity tables
 *
 * Renders parsed agent / vulnerability / rule tables as card-style rows
 * instead of flat HTML table cells. Each card has:
 *   - Severity stripe on the left (4px, full height)
 *   - Primary text (agent name / CVE / rule description)
 *   - Status badge or severity badge
 *   - Secondary meta (IP, OS, version / package + affected / group + level)
 *   - Relative timestamp (where applicable)
 *   - Action buttons (Investigate / NVD / View alerts / etc.)
 *
 * Handles 4 data shapes from BlockParser:
 *   - agent_table:        list of Wazuh agents
 *   - vulnerability_table: list of CVEs affecting packages
 *   - rule_table:         list of detection rules
 *   - (falls back for generic table → renders as grouped severity list)
 *
 * Responsive: auto-fill grid — 1 col <640px, 2 col 640–1080px, 3 col ≥1080px.
 * Cards have a fixed minimum width (340px) and flow into as many columns as
 * the container can accommodate. This keeps density high on wide desktops
 * without forcing a single fixed column count.
 *
 * Collapses to "show first N + Show all" for long lists — N scales with the
 * column count (12 rows for 1-col, 18 for 2-col, 24 for 3-col) so the
 * collapse visual footprint stays roughly the same regardless of width.
 */

import { useState, useMemo } from 'react';
import { EuiIcon } from '@elastic/eui';
import { THEME, GRADIENTS, SHADOWS, TIMINGS } from '../../../utils/theme';
import { FONT } from '../PallasUI';
import {
  useContainerWidth,
  severityColor,
  formatRelativeTime,
} from './blockHelpers';

// ─── Constants ───────────────────────────────────────────────────────────────

const MONO = FONT.mono;

// Collapse threshold scales with column count — keeps the "show first N"
// visual footprint roughly the same as we go from 1-col to 3-col layouts.
function visibleCountFor(cols) {
  if (cols >= 3) return 24;
  if (cols >= 2) return 18;
  return 12;
}

function columnsFor(width) {
  if (width === 0) return 1;     // initial render before ResizeObserver fires
  if (width >= 1080) return 3;
  if (width >= 640) return 2;
  return 1;
}

const SEVERITY_LABELS = {
  critical: 'Critical',
  high:     'High',
  medium:   'Medium',
  low:      'Low',
  info:     'Info',
  informational: 'Info',
};

const STATUS_META = {
  active:       { color: THEME.success,  label: 'Active',         pulse: true },
  connected:    { color: THEME.success,  label: 'Connected',      pulse: true },
  healthy:      { color: THEME.success,  label: 'Healthy',        pulse: true },
  disconnected: { color: THEME.warning,  label: 'Disconnected',   pulse: false },
  offline:      { color: THEME.warning,  label: 'Offline',        pulse: false },
  'never connected':  { color: THEME.textMuted, label: 'Never Connected', pulse: false },
  never_connected:    { color: THEME.textMuted, label: 'Never Connected', pulse: false },
  pending:      { color: THEME.warning,  label: 'Pending',        pulse: false },
  inactive:     { color: THEME.textMuted,label: 'Inactive',       pulse: false },
  unhealthy:    { color: THEME.danger,   label: 'Unhealthy',      pulse: true },
};

// ─── Reusable sub-components ────────────────────────────────────────────────

function SeverityStripe({ severity }) {
  const color = severityColor(severity);
  return (
    <div
      style={{
        position: 'absolute',
        left: 0,
        top: 0,
        bottom: 0,
        width: 4,
        background: `linear-gradient(180deg, ${color}, ${color}c0)`,
        boxShadow: `0 0 10px ${color}60`,
      }}
    />
  );
}

function SeverityBadge({ severity }) {
  const key = String(severity || '').toLowerCase();
  const color = severityColor(key);
  const label = SEVERITY_LABELS[key] || severity || 'Unknown';
  return (
    <span
      style={{
        display: 'inline-flex',
        alignItems: 'center',
        padding: '2px 9px',
        borderRadius: 5,
        fontSize: 10,
        fontWeight: 700,
        textTransform: 'uppercase',
        letterSpacing: '0.04em',
        color,
        background: `${color}18`,
        border: `1px solid ${color}40`,
        whiteSpace: 'nowrap',
      }}
    >
      {label}
    </span>
  );
}

function StatusDot({ status, size = 8 }) {
  const meta = STATUS_META[String(status || '').toLowerCase()] || { color: THEME.textMuted, pulse: false };
  return (
    <span
      style={{
        display: 'inline-block',
        width: size,
        height: size,
        borderRadius: '50%',
        background: meta.color,
        boxShadow: meta.pulse ? `0 0 8px ${meta.color}` : 'none',
        animation: meta.pulse ? 'pallas-breathe 2.2s ease-in-out infinite' : 'none',
        flexShrink: 0,
      }}
    />
  );
}

function StatusPill({ status }) {
  const meta = STATUS_META[String(status || '').toLowerCase()] || { color: THEME.textMuted, label: status || '—', pulse: false };
  return (
    <span
      style={{
        display: 'inline-flex',
        alignItems: 'center',
        gap: 6,
        fontSize: 11,
        fontWeight: 600,
        color: meta.color,
        whiteSpace: 'nowrap',
      }}
    >
      <StatusDot status={status} />
      {meta.label}
    </span>
  );
}

function ActionButton({ icon, label, onClick, color = THEME.primary }) {
  const [hovered, setHovered] = useState(false);
  return (
    <button
      onMouseEnter={() => setHovered(true)}
      onMouseLeave={() => setHovered(false)}
      onClick={onClick}
      style={{
        display: 'inline-flex',
        alignItems: 'center',
        gap: 5,
        padding: '4px 10px',
        borderRadius: 6,
        border: `1px solid ${hovered ? color : `${color}40`}`,
        background: hovered ? `${color}18` : `${color}08`,
        color,
        fontSize: 11,
        fontWeight: 600,
        cursor: 'pointer',
        fontFamily: 'inherit',
        transition: `all ${TIMINGS.fast} ${TIMINGS.ease}`,
        outline: 'none',
        whiteSpace: 'nowrap',
      }}
    >
      <EuiIcon type={icon} size="s" color={color} />
      {label}
    </button>
  );
}

function EntityCard({ children, severityColor: sev, hovered, onMouseEnter, onMouseLeave, onClick, clickable }) {
  return (
    <div
      onMouseEnter={onMouseEnter}
      onMouseLeave={onMouseLeave}
      onClick={onClick}
      role={clickable ? 'button' : undefined}
      tabIndex={clickable ? 0 : undefined}
      style={{
        position: 'relative',
        background: GRADIENTS.card,
        border: `1px solid ${hovered ? (sev || THEME.primary) : THEME.border}`,
        borderRadius: 10,
        padding: '12px 14px 12px 20px',
        boxShadow: hovered ? SHADOWS.lg : SHADOWS.sm,
        transform: hovered ? 'translateY(-2px)' : 'translateY(0)',
        transition: `all ${TIMINGS.fast} ${TIMINGS.ease}`,
        cursor: clickable ? 'pointer' : 'default',
        overflow: 'hidden',
      }}
    >
      {sev && <SeverityStripe severity={sev} />}
      {children}
    </div>
  );
}

// ─── Agent row card ──────────────────────────────────────────────────────────

function AgentCard({ agent, onPivot }) {
  const [hovered, setHovered] = useState(false);
  const clickable = typeof onPivot === 'function' && agent.agent_id;
  const status = String(agent.status || '').toLowerCase();

  // Agents have no "severity" — use status color as accent
  const accentColor =
    status === 'active' || status === 'connected' ? THEME.success :
    status === 'disconnected' || status === 'offline' ? THEME.warning :
    THEME.textMuted;

  const osShort = (agent.os || '').split(/[,;]/)[0].trim(); // trim long OS strings

  return (
    <EntityCard
      severityColor={null}
      hovered={hovered}
      onMouseEnter={() => setHovered(true)}
      onMouseLeave={() => setHovered(false)}
      onClick={clickable ? () => onPivot(`check agent ${agent.agent_id} health`) : undefined}
      clickable={clickable}
    >
      {/* Left accent stripe (status-colored) */}
      <div
        style={{
          position: 'absolute',
          left: 0, top: 0, bottom: 0, width: 4,
          background: `linear-gradient(180deg, ${accentColor}, ${accentColor}c0)`,
        }}
      />

      {/* Header row: ID + name + status pill */}
      <div
        style={{
          display: 'flex',
          alignItems: 'center',
          gap: 8,
          marginBottom: 6,
        }}
      >
        <span
          style={{
            fontFamily: MONO,
            fontSize: 11,
            fontWeight: 700,
            color: THEME.primary,
            padding: '2px 7px',
            borderRadius: 4,
            background: `${THEME.primary}14`,
            border: `1px solid ${THEME.primary}25`,
            flexShrink: 0,
          }}
        >
          {agent.agent_id || '—'}
        </span>
        <span
          style={{
            flex: 1,
            minWidth: 0,
            fontSize: 13,
            fontWeight: 600,
            color: THEME.text,
            overflow: 'hidden',
            textOverflow: 'ellipsis',
            whiteSpace: 'nowrap',
          }}
          title={agent.name}
        >
          {agent.name || 'Unknown'}
        </span>
        <StatusPill status={agent.status} />
      </div>

      {/* Metadata row — 2-line compact grid so cards are deterministic height */}
      <div
        style={{
          display: 'grid',
          gridTemplateColumns: 'minmax(0, auto) 1fr auto',
          rowGap: 3,
          columnGap: 10,
          alignItems: 'center',
          fontSize: 11,
          color: THEME.textMuted,
        }}
      >
        {/* Row 1: IP · OS · last-seen */}
        {agent.ip ? (
          <span
            style={{
              display: 'inline-flex',
              alignItems: 'center',
              gap: 4,
              fontFamily: MONO,
              color: THEME.textSecondary,
              minWidth: 0,
              overflow: 'hidden',
              textOverflow: 'ellipsis',
              whiteSpace: 'nowrap',
            }}
            title={agent.ip}
          >
            <EuiIcon type="globe" size="s" color={THEME.textMuted} />
            {agent.ip}
          </span>
        ) : <span />}
        {osShort ? (
          <span
            style={{
              display: 'inline-flex',
              alignItems: 'center',
              gap: 4,
              minWidth: 0,
              overflow: 'hidden',
              textOverflow: 'ellipsis',
              whiteSpace: 'nowrap',
            }}
            title={agent.os}
          >
            <EuiIcon type="storage" size="s" color={THEME.textMuted} />
            {osShort}
          </span>
        ) : <span />}
        {agent.last_keep_alive ? (
          <span
            style={{
              fontSize: 10,
              color: THEME.textFaint,
              fontFamily: MONO,
              whiteSpace: 'nowrap',
              justifySelf: 'end',
            }}
            title={`Last keep-alive: ${agent.last_keep_alive}`}
          >
            {formatRelativeTime(agent.last_keep_alive)}
          </span>
        ) : <span />}
      </div>

      {/* Version on its own line if present — keeps things quiet */}
      {agent.version && (
        <div
          style={{
            fontFamily: MONO,
            fontSize: 10,
            color: THEME.textFaint,
            marginTop: 4,
          }}
        >
          Wazuh agent v{agent.version}
        </div>
      )}
    </EntityCard>
  );
}

// ─── Vulnerability card ─────────────────────────────────────────────────────

function VulnerabilityCard({ vuln, onPivot }) {
  const [hovered, setHovered] = useState(false);
  const severity = String(vuln.severity || '').toLowerCase() || 'low';
  const sevColor = severityColor(severity);

  return (
    <EntityCard
      severityColor={severity}
      hovered={hovered}
      onMouseEnter={() => setHovered(true)}
      onMouseLeave={() => setHovered(false)}
      clickable={false}
    >
      {/* Header: CVE + severity + agent pivot (single deterministic row) */}
      <div
        style={{
          display: 'grid',
          gridTemplateColumns: 'auto auto minmax(0, 1fr) auto',
          alignItems: 'center',
          gap: 8,
          marginBottom: 6,
        }}
      >
        {vuln.cve ? (
          <a
            href={`https://nvd.nist.gov/vuln/detail/${vuln.cve}`}
            target="_blank"
            rel="noopener noreferrer"
            onClick={(e) => e.stopPropagation()}
            style={{
              fontFamily: MONO,
              fontSize: 12,
              fontWeight: 700,
              color: sevColor,
              textDecoration: 'none',
              padding: '2px 7px',
              borderRadius: 4,
              background: `${sevColor}12`,
              border: `1px solid ${sevColor}35`,
              whiteSpace: 'nowrap',
            }}
            title={`View ${vuln.cve} on NVD`}
          >
            {vuln.cve}
          </a>
        ) : <span />}
        <SeverityBadge severity={severity} />
        <span />
        {vuln.agent && typeof onPivot === 'function' ? (
          <span
            onClick={(e) => {
              e.stopPropagation();
              const m = String(vuln.agent).match(/\b(\d{3,})\b/);
              onPivot(m ? `check agent ${m[1]} health` : `show alerts for ${vuln.agent}`);
            }}
            style={{
              fontSize: 11,
              fontFamily: MONO,
              color: THEME.primary,
              cursor: 'pointer',
              padding: '2px 8px',
              borderRadius: 4,
              background: `${THEME.primary}10`,
              border: `1px solid ${THEME.primary}25`,
              whiteSpace: 'nowrap',
              justifySelf: 'end',
            }}
            title="Investigate affected agent"
          >
            {vuln.agent}
          </span>
        ) : <span />}
      </div>

      {/* Package + version — mono, single line */}
      {vuln.package && (
        <div
          style={{
            fontSize: 12,
            color: THEME.textSecondary,
            fontFamily: MONO,
            marginBottom: vuln.description ? 5 : 0,
            overflow: 'hidden',
            textOverflow: 'ellipsis',
            whiteSpace: 'nowrap',
          }}
          title={`${vuln.package}${vuln.version ? ' ' + vuln.version : ''}`}
        >
          {vuln.package}
          {vuln.version && <span style={{ color: THEME.textFaint }}> {vuln.version}</span>}
        </div>
      )}

      {/* Description — clamp to 2 lines */}
      {vuln.description && (
        <div
          style={{
            fontSize: 11,
            color: THEME.textMuted,
            lineHeight: 1.45,
            display: '-webkit-box',
            WebkitLineClamp: 2,
            WebkitBoxOrient: 'vertical',
            overflow: 'hidden',
          }}
        >
          {vuln.description}
        </div>
      )}

      {/* NVD link action — only on hover so it doesn't clutter the grid */}
      {vuln.cve && hovered && (
        <div style={{ marginTop: 8, display: 'flex', gap: 6 }}>
          <ActionButton
            icon="popout"
            label="View on NVD"
            onClick={(e) => {
              e.stopPropagation();
              window.open(`https://nvd.nist.gov/vuln/detail/${vuln.cve}`, '_blank', 'noopener');
            }}
            color={THEME.warning}
          />
        </div>
      )}
    </EntityCard>
  );
}

// ─── Rule card ──────────────────────────────────────────────────────────────

function RuleCard({ rule }) {
  const [hovered, setHovered] = useState(false);
  // Map level → severity (Wazuh rule levels: 0-3 low, 4-7 medium, 8-11 high, 12+ critical)
  const level = rule.level || 0;
  const severity =
    level >= 12 ? 'critical' :
    level >= 8  ? 'high' :
    level >= 4  ? 'medium' : 'low';
  const sevColor = severityColor(severity);

  return (
    <EntityCard
      severityColor={severity}
      hovered={hovered}
      onMouseEnter={() => setHovered(true)}
      onMouseLeave={() => setHovered(false)}
      clickable={false}
    >
      {/* Header: ID pill · level · severity badge · hits */}
      <div
        style={{
          display: 'grid',
          gridTemplateColumns: 'auto auto auto minmax(0, 1fr) auto',
          alignItems: 'center',
          gap: 8,
          marginBottom: 6,
        }}
      >
        {rule.rule_id ? (
          <span
            style={{
              fontFamily: MONO,
              fontSize: 11,
              fontWeight: 700,
              color: sevColor,
              padding: '2px 7px',
              borderRadius: 4,
              background: `${sevColor}14`,
              border: `1px solid ${sevColor}30`,
            }}
          >
            {rule.rule_id}
          </span>
        ) : <span />}
        <span
          style={{
            fontSize: 10,
            fontWeight: 700,
            color: THEME.textMuted,
            textTransform: 'uppercase',
            letterSpacing: '0.04em',
          }}
        >
          L{level}
        </span>
        <SeverityBadge severity={severity} />
        <span />
        {rule.firedtimes > 0 ? (
          <span
            style={{
              fontSize: 11,
              color: THEME.textMuted,
              fontFamily: MONO,
              whiteSpace: 'nowrap',
              justifySelf: 'end',
            }}
            title={`${rule.firedtimes.toLocaleString()} hits`}
          >
            {formatHits(rule.firedtimes)}
          </span>
        ) : <span />}
      </div>

      {/* Description — clamped 2 lines so cards stay uniform height */}
      <div
        style={{
          fontSize: 12,
          color: THEME.text,
          lineHeight: 1.45,
          marginBottom: rule.groups ? 5 : 0,
          display: '-webkit-box',
          WebkitLineClamp: 2,
          WebkitBoxOrient: 'vertical',
          overflow: 'hidden',
        }}
        title={rule.description || ''}
      >
        {rule.description || '(no description)'}
      </div>

      {rule.groups && (
        <div
          style={{
            fontSize: 10,
            color: THEME.textFaint,
            fontFamily: MONO,
            overflow: 'hidden',
            textOverflow: 'ellipsis',
            whiteSpace: 'nowrap',
          }}
          title={rule.groups}
        >
          {rule.groups}
        </div>
      )}
    </EntityCard>
  );
}

// Compact hit count formatter: 1234 → "1.2k", 12345 → "12k", 123456 → "123k"
function formatHits(n) {
  if (n < 1000) return String(n);
  if (n < 10000) return (n / 1000).toFixed(1).replace(/\.0$/, '') + 'k';
  if (n < 1_000_000) return Math.round(n / 1000) + 'k';
  return (n / 1_000_000).toFixed(1).replace(/\.0$/, '') + 'M';
}

// ─── Container for any list (collapse + header + responsive grid) ───────────

function EntityList({ title, count, total, cards, onToggle, expanded, columns }) {
  return (
    <div style={{ margin: '14px 0' }}>
      {/* Title bar */}
      <div
        style={{
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'space-between',
          marginBottom: 10,
          flexWrap: 'wrap',
          gap: 8,
        }}
      >
        <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
          <span
            style={{
              width: 3,
              height: 14,
              background: GRADIENTS.primaryAccent,
              borderRadius: 2,
              flexShrink: 0,
            }}
          />
          <h4
            style={{
              margin: 0,
              fontSize: 12,
              fontWeight: 700,
              color: THEME.textSecondary,
              textTransform: 'uppercase',
              letterSpacing: '0.05em',
            }}
          >
            {title}
          </h4>
          <span
            style={{
              fontSize: 11,
              color: THEME.textMuted,
              fontFamily: MONO,
            }}
          >
            ({count} of {total})
          </span>
        </div>
      </div>

      {/* Responsive auto-fill grid — 1/2/3 columns depending on container width */}
      <div
        style={{
          display: 'grid',
          gridTemplateColumns: `repeat(${columns}, minmax(0, 1fr))`,
          gap: 10,
          alignItems: 'stretch',
        }}
      >
        {cards}
      </div>

      {/* Footer: show N more / show less. Visible when the list has more
          rows than the current column-count's collapse threshold. */}
      {(expanded || total > count) && (
        <div
          style={{
            marginTop: 10,
            display: 'flex',
            justifyContent: 'center',
          }}
        >
          <button
            onClick={onToggle}
            style={{
              display: 'inline-flex',
              alignItems: 'center',
              gap: 6,
              padding: '7px 18px',
              borderRadius: 8,
              border: `1px solid ${THEME.primary}40`,
              background: `${THEME.primary}10`,
              color: THEME.primary,
              fontSize: 12,
              fontWeight: 600,
              cursor: 'pointer',
              fontFamily: 'inherit',
              transition: `all ${TIMINGS.fast} ${TIMINGS.ease}`,
              outline: 'none',
            }}
            onMouseEnter={(e) => {
              e.currentTarget.style.background = `${THEME.primary}20`;
              e.currentTarget.style.borderColor = THEME.primary;
            }}
            onMouseLeave={(e) => {
              e.currentTarget.style.background = `${THEME.primary}10`;
              e.currentTarget.style.borderColor = `${THEME.primary}40`;
            }}
          >
            <EuiIcon type={expanded ? 'arrowUp' : 'arrowDown'} size="s" color={THEME.primary} />
            {expanded ? 'Show less' : `Show all ${total}`}
          </button>
        </div>
      )}
    </div>
  );
}

// ─── Main component ────────────────────────────────────────────────────────

export default function EntityListBlock({ blockType, data, onPivot }) {
  const [ref, width] = useContainerWidth();
  const [expanded, setExpanded] = useState(false);

  const columns = columnsFor(width);
  const visibleThreshold = visibleCountFor(columns);

  // Pick the right entity list based on block type
  const { title, cards, total } = useMemo(() => {
    if (blockType === 'agent_table') {
      const agents = data?.agents || [];
      // Sort: disconnected/never-connected first (they need attention),
      // then active. Within each group, alphabetical by name.
      const statusOrder = (s) => {
        const k = String(s || '').toLowerCase();
        if (k === 'disconnected' || k === 'offline') return 0;
        if (k === 'never connected' || k === 'never_connected') return 1;
        if (k === 'pending' || k === 'inactive') return 2;
        return 3; // active, connected, healthy
      };
      const sorted = [...agents].sort((a, b) => {
        const d = statusOrder(a.status) - statusOrder(b.status);
        if (d !== 0) return d;
        return String(a.name || '').localeCompare(String(b.name || ''));
      });
      const visible = expanded ? sorted : sorted.slice(0, visibleThreshold);
      return {
        title: 'Agents',
        total: agents.length,
        cards: visible.map((a, i) => (
          <AgentCard key={`${a.agent_id || i}-${i}`} agent={a} onPivot={onPivot} />
        )),
      };
    }
    if (blockType === 'vulnerability_table') {
      const vulns = data?.vulnerabilities || [];
      // Sort by severity: critical → high → medium → low
      const sevOrder = { critical: 0, high: 1, medium: 2, low: 3, info: 4 };
      const sorted = [...vulns].sort(
        (a, b) => (sevOrder[String(a.severity).toLowerCase()] ?? 99) - (sevOrder[String(b.severity).toLowerCase()] ?? 99)
      );
      const visible = expanded ? sorted : sorted.slice(0, visibleThreshold);
      return {
        title: 'Vulnerabilities',
        total: vulns.length,
        cards: visible.map((v, i) => (
          <VulnerabilityCard key={`${v.cve || i}-${i}`} vuln={v} onPivot={onPivot} />
        )),
      };
    }
    if (blockType === 'rule_table') {
      const rules = data?.rules || [];
      // Sort by level descending (most severe first)
      const sorted = [...rules].sort((a, b) => (b.level || 0) - (a.level || 0));
      const visible = expanded ? sorted : sorted.slice(0, visibleThreshold);
      return {
        title: 'Detection Rules',
        total: rules.length,
        cards: visible.map((r, i) => <RuleCard key={`${r.rule_id || i}-${i}`} rule={r} />),
      };
    }
    return { title: 'Entities', total: 0, cards: [] };
  }, [blockType, data, expanded, onPivot, visibleThreshold]);

  if (total === 0) return null;

  return (
    <div ref={ref}>
      <EntityList
        title={title}
        count={cards.length}
        total={total}
        cards={cards}
        expanded={expanded}
        onToggle={() => setExpanded(!expanded)}
        columns={columns}
      />
    </div>
  );
}
