/**
 * PallasSIEMTools — SIEM Tools plugin for the Pallas AI Analyst
 *
 * Redesigned with shared PallasUI components and SIEM accent color (#61A2FF).
 * Provides quick-action chips, categorized strategies, parameterized queries,
 * pinned result management, and response display for SIEM operations.
 */

import React, { useState, useRef, useCallback, useEffect, useMemo } from 'react';
import { EuiIcon } from '@elastic/eui';
import { THEME } from '../../utils/theme';
import { MODULE_COLORS, ModuleHeader, ActionChip, SectionHeader, FONT, ChatDisclaimer } from './PallasUI';
import { usePallas } from '../../hooks/usePallas';
import { ResponsePanel, ComparePanel } from './PallasResponsePanel';
import { StrategyPanel } from './PallasStrategyPanel';
import { QueryHistory } from './PallasQueryHistory';
import { SIEM_PANEL_STRATEGIES } from './PallasStrategies';

const ACCENT = MODULE_COLORS.siem.accent;

// ─── Data ────────────────────────────────────────────────────────────────────

const SIEM_QUICK_ACTIONS = [
  { label: 'Active Agents', query: 'show active agents', icon: 'checkInCircleFilled' },
  { label: 'Disconnected Agents', query: 'show disconnected agents', icon: 'offline' },
  { label: 'Recent Alerts', query: 'show recent alerts', icon: 'bell' },
  { label: 'Alert Summary', query: 'show alert summary', icon: 'list' },
  { label: 'Top Rules', query: 'which rules trigger most frequently', icon: 'visBarVerticalStacked' },
  { label: 'Log Source Health', query: 'show log source health', icon: 'heartbeatApp' },
  { label: 'Security Report', query: 'generate security report', icon: 'reportingApp' },
  { label: 'Alert Patterns', query: 'analyze alert patterns', icon: 'visTagCloud' },
  { label: 'Open Ports', query: 'show ports for agent {agent_id}', icon: 'globe', paramKey: 'agent_id', paramPlaceholder: 'Agent ID (e.g. 011)' },
  { label: 'Running Processes', query: 'show processes for agent {agent_id}', icon: 'compute', paramKey: 'agent_id', paramPlaceholder: 'Agent ID (e.g. 011)' },
  { label: 'Software Inventory', query: 'show inventory for agent {agent_id}', icon: 'package', paramKey: 'agent_id', paramPlaceholder: 'Agent ID (e.g. 011)' },
  { label: 'Full Agent Investigation', query: 'full investigation for agent {agent_id}', icon: 'inspect', paramKey: 'agent_id', paramPlaceholder: 'Agent ID (e.g. 011)' },
  { label: 'Agent Health', query: 'check agent {agent_id} health', icon: 'heartbeatApp', paramKey: 'agent_id', paramPlaceholder: 'Agent ID (e.g. 011)' },
];

// ─── Component ───────────────────────────────────────────────────────────────

export default function PallasSIEMTools({ connectionStatus, onConnectionStatusChange, onQueryComplete, toolHealth }) {
  const {
    response,
    isLoading,
    connectionStatus: wsStatus,
    sendQuery,
    cancelQuery,
    clearResponse,
    queryHistory,
    favorites,
    toggleFavorite,
    pinnedResponses,
    pinResponse,
    unpinResponse,
  } = usePallas('siem', { onQueryComplete });

  const effectiveStatus = wsStatus === 'connected' ? 'connected' : connectionStatus;
  const isDisabled = isLoading || effectiveStatus !== 'connected';

  // Bubble WS status up to parent
  useEffect(() => {
    if (onConnectionStatusChange) onConnectionStatusChange(wsStatus);
  }, [wsStatus, onConnectionStatusChange]);

  const [customQuery, setCustomQuery] = useState('');
  const [expandedChip, setExpandedChip] = useState(null);
  const [chipParamValue, setChipParamValue] = useState('');
  const [showStrategies, setShowStrategies] = useState(false);
  const [compareMode, setCompareMode] = useState(false);
  const [showHistory, setShowHistory] = useState(false);

  const textareaRef = useRef(null);
  const resultsRef = useRef(null);
  const chipInputRef = useRef(null);

  useEffect(() => {
    if (response && resultsRef.current) {
      resultsRef.current.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
  }, [response]);

  const handleTextareaChange = useCallback((e) => {
    setCustomQuery(e.target.value);
    const el = e.target;
    el.style.height = 'auto';
    el.style.height = Math.min(el.scrollHeight, 120) + 'px';
  }, []);

  const handleSendQuery = useCallback(() => {
    const q = customQuery.trim();
    if (!q || isDisabled) return;
    sendQuery(q);
    setCustomQuery('');
    if (textareaRef.current) textareaRef.current.style.height = 'auto';
  }, [customQuery, isDisabled, sendQuery]);

  const handleTextareaKeyDown = useCallback((e) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSendQuery();
    }
  }, [handleSendQuery]);

  const handleQuickAction = useCallback((action) => {
    if (action.paramKey) {
      if (expandedChip === action.label) {
        setExpandedChip(null);
        setChipParamValue('');
      } else {
        setExpandedChip(action.label);
        setChipParamValue('');
        setTimeout(() => chipInputRef.current?.focus(), 50);
      }
      return;
    }
    if (isDisabled) return;
    sendQuery(action.query);
  }, [expandedChip, isDisabled, sendQuery]);

  const handleChipParamSubmit = useCallback((action) => {
    const val = chipParamValue.trim();
    if (!val || isDisabled) return;
    const finalQuery = action.query.replace(`{${action.paramKey}}`, val);
    sendQuery(finalQuery);
    setExpandedChip(null);
    setChipParamValue('');
  }, [chipParamValue, isDisabled, sendQuery]);

  const handleChipParamKeyDown = useCallback((e, action) => {
    if (e.key === 'Enter') {
      e.preventDefault();
      handleChipParamSubmit(action);
    } else if (e.key === 'Escape') {
      setExpandedChip(null);
      setChipParamValue('');
    }
  }, [handleChipParamSubmit]);

  const handleStrategySelect = useCallback((query) => {
    if (isDisabled) return;
    sendQuery(query);
    setShowStrategies(false);
  }, [isDisabled, sendQuery]);

  const handlePinCurrent = useCallback(() => {
    if (response) pinResponse(response);
  }, [response, pinResponse]);

  const handleExportPinned = useCallback(() => {
    if (!pinnedResponses.length) return;
    const md = pinnedResponses.map((r, i) => {
      const ts = r.timestamp ? new Date(r.timestamp).toLocaleString() : 'N/A';
      return `## Result ${i + 1} (${ts})\n\n${r.content || ''}\n`;
    }).join('\n---\n\n');
    const blob = new Blob([md], { type: 'text/markdown' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `pallas-siem-results-${Date.now()}.md`;
    a.click();
    URL.revokeObjectURL(url);
  }, [pinnedResponses]);

  const handleHistorySelect = useCallback((entry) => {
    setCustomQuery(entry.query || entry);
    setShowHistory(false);
    setTimeout(() => textareaRef.current?.focus(), 50);
  }, []);

  const handleHistoryRerun = useCallback((entry) => {
    if (isDisabled) return;
    sendQuery(entry.query || entry);
    setShowHistory(false);
  }, [isDisabled, sendQuery]);

  const wazuhDisconnected = useMemo(() => {
    if (!toolHealth) return false;
    return toolHealth.wazuh_manager !== 'connected' && toolHealth.wazuh_manager !== 'connecting';
  }, [toolHealth]);

  // ─── Render ────────────────────────────────────────────────────────────────

  return (
    <div style={{
      display: 'flex',
      flexDirection: 'column',
      height: '100%',
      fontFamily: FONT.base,
      color: THEME.text,
      overflow: 'hidden',
    }}>
      {/* Module Header */}
      <ModuleHeader
        icon="storage"
        title="SIEM Tools"
        description="Query agents, alerts, and endpoint telemetry via Pallas AI"
        accent={ACCENT}
        connectionStatus={effectiveStatus}
      />

      {/* Scrollable Content */}
      <div style={{ flex: 1, overflow: 'auto', padding: '16px 20px' }} className="pallas-scrollbar">

        {/* Wazuh Disconnected Warning */}
        {wazuhDisconnected && (
          <div style={{
            display: 'flex',
            alignItems: 'center',
            gap: 10,
            padding: '10px 14px',
            borderRadius: 8,
            backgroundColor: 'rgba(255,166,0,0.08)',
            border: '1px solid rgba(255,166,0,0.25)',
            color: '#FFA600',
            fontSize: 12,
            marginBottom: 14,
          }}>
            <EuiIcon type="warning" size="s" color="#FFA600" />
            <div>
              <strong>Wazuh Manager Disconnected</strong>
              <span style={{ marginLeft: 6, color: THEME.textSecondary }}>
                SIEM queries may fail or return stale data until the connection is restored.
              </span>
            </div>
          </div>
        )}

        {/* Custom Query Input */}
        <div style={{ marginBottom: 16 }}>
          <div style={{
            display: 'flex',
            gap: 8,
            alignItems: 'flex-end',
          }}>
            <div style={{ flex: 1, position: 'relative' }}>
              <textarea
                ref={textareaRef}
                value={customQuery}
                onChange={handleTextareaChange}
                onKeyDown={handleTextareaKeyDown}
                onFocus={() => setShowHistory(false)}
                placeholder="Ask Pallas about your SIEM data..."
                disabled={isDisabled}
                rows={1}
                style={{
                  width: '100%',
                  minHeight: 40,
                  maxHeight: 120,
                  padding: '10px 36px 10px 14px',
                  borderRadius: 8,
                  border: `1px solid ${THEME.border}`,
                  backgroundColor: 'rgba(255,255,255,0.02)',
                  color: THEME.text,
                  fontFamily: FONT.base,
                  fontSize: 13,
                  lineHeight: 1.5,
                  resize: 'none',
                  outline: 'none',
                  transition: 'border-color 0.15s',
                  boxSizing: 'border-box',
                  opacity: isDisabled ? 0.5 : 1,
                }}
              />
              <button
                onClick={() => setShowHistory((v) => !v)}
                disabled={!queryHistory.length}
                style={{
                  position: 'absolute',
                  right: 8,
                  top: '50%',
                  transform: 'translateY(-50%)',
                  background: 'none',
                  border: 'none',
                  color: queryHistory.length ? THEME.textSecondary : THEME.textMuted,
                  cursor: queryHistory.length ? 'pointer' : 'default',
                  padding: 4,
                  display: 'flex',
                  alignItems: 'center',
                }}
                title="Query History"
              >
                <EuiIcon type="arrowDown" size="s" />
              </button>
            </div>

            <button
              onClick={isLoading ? cancelQuery : handleSendQuery}
              disabled={!isLoading && (!customQuery.trim() || isDisabled)}
              style={{
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                gap: 6,
                padding: '10px 18px',
                borderRadius: 8,
                border: 'none',
                backgroundColor: isLoading ? THEME.danger : ACCENT,
                color: '#fff',
                fontFamily: FONT.base,
                fontSize: 13,
                fontWeight: 600,
                cursor: (!isLoading && (!customQuery.trim() || isDisabled)) ? 'not-allowed' : 'pointer',
                opacity: (!isLoading && (!customQuery.trim() || isDisabled)) ? 0.5 : 1,
                transition: 'all 0.15s',
                whiteSpace: 'nowrap',
                minHeight: 40,
                outline: 'none',
              }}
            >
              {isLoading ? (
                <>
                  <span style={{
                    display: 'inline-block', width: 14, height: 14,
                    border: '2px solid rgba(255,255,255,0.3)', borderTopColor: '#fff',
                    borderRadius: '50%', animation: 'pallas-spin 0.6s linear infinite',
                  }} />
                  Cancel
                </>
              ) : (
                <>
                  <EuiIcon type="returnKey" size="s" color="#fff" />
                  Send
                </>
              )}
            </button>
          </div>

          {showHistory && queryHistory.length > 0 && (
            <div style={{ position: 'relative', zIndex: 10, marginTop: 4 }}>
              <QueryHistory
                history={queryHistory}
                onSelect={handleHistorySelect}
                onExecute={handleHistoryRerun}
                disabled={isDisabled}
              />
            </div>
          )}
          <ChatDisclaimer align="center" marginTop={6} />
        </div>

        {/* Quick Actions */}
        <SectionHeader icon="bolt" title="Quick Actions" accent={ACCENT} count={SIEM_QUICK_ACTIONS.length} />
        <div style={{ display: 'flex', flexWrap: 'wrap', gap: 6, marginBottom: 16 }}>
          {SIEM_QUICK_ACTIONS.map((action) => {
            const isExpanded = expandedChip === action.label;

            return (
              <div key={action.label} style={{ display: 'flex', flexDirection: 'column' }}>
                <ActionChip
                  icon={action.icon}
                  label={action.label}
                  onClick={() => handleQuickAction(action)}
                  disabled={isDisabled && !action.paramKey}
                  active={isExpanded}
                  accent={ACCENT}
                  hasParam={!!action.paramKey}
                />

                {isExpanded && action.paramKey && (
                  <div style={{
                    display: 'flex',
                    alignItems: 'center',
                    gap: 6,
                    marginTop: 6,
                    padding: '6px 10px',
                    borderRadius: 6,
                    backgroundColor: 'rgba(255,255,255,0.02)',
                    border: `1px solid ${ACCENT}30`,
                  }}>
                    <input
                      ref={chipInputRef}
                      type="text"
                      value={chipParamValue}
                      onChange={(e) => setChipParamValue(e.target.value)}
                      onKeyDown={(e) => handleChipParamKeyDown(e, action)}
                      placeholder={action.paramPlaceholder}
                      style={{
                        flex: 1,
                        padding: '4px 8px',
                        borderRadius: 4,
                        border: `1px solid ${THEME.border}`,
                        backgroundColor: THEME.bg,
                        color: THEME.text,
                        fontFamily: FONT.mono,
                        fontSize: 12,
                        outline: 'none',
                        minWidth: 120,
                      }}
                    />
                    <button
                      onClick={() => handleChipParamSubmit(action)}
                      disabled={!chipParamValue.trim() || isDisabled}
                      style={{
                        padding: '4px 10px',
                        borderRadius: 4,
                        border: 'none',
                        backgroundColor: ACCENT,
                        color: '#fff',
                        fontSize: 11,
                        fontWeight: 600,
                        cursor: (!chipParamValue.trim() || isDisabled) ? 'not-allowed' : 'pointer',
                        opacity: (!chipParamValue.trim() || isDisabled) ? 0.5 : 1,
                        outline: 'none',
                      }}
                    >
                      <EuiIcon type="returnKey" size="s" color="#fff" />
                    </button>
                    <button
                      onClick={() => { setExpandedChip(null); setChipParamValue(''); }}
                      style={{
                        padding: '4px 6px',
                        borderRadius: 4,
                        border: 'none',
                        backgroundColor: 'transparent',
                        color: THEME.textSecondary,
                        cursor: 'pointer',
                        outline: 'none',
                      }}
                    >
                      <EuiIcon type="cross" size="s" />
                    </button>
                  </div>
                )}
              </div>
            );
          })}
        </div>

        {/* Browse Strategies */}
        <div style={{ marginBottom: 16 }}>
          <ActionChip
            icon={showStrategies ? 'arrowUp' : 'list'}
            label={showStrategies ? 'Hide Strategies' : 'Browse All Strategies'}
            onClick={() => setShowStrategies((v) => !v)}
            active={showStrategies}
            accent={ACCENT}
          />
          {showStrategies && (
            <div style={{ marginTop: 10 }}>
              <StrategyPanel
                categories={SIEM_PANEL_STRATEGIES}
                onExecute={handleStrategySelect}
                isDisabled={isDisabled}
              />
            </div>
          )}
        </div>

        {/* Pinned Results */}
        {pinnedResponses.length > 0 && (
          <div style={{ marginBottom: 16 }}>
            <SectionHeader
              icon="pinFilled"
              title="Pinned Results"
              count={pinnedResponses.length}
              accent={ACCENT}
              actions={
                <div style={{ display: 'flex', gap: 6 }}>
                  <ActionChip
                    icon="merge"
                    label="Compare"
                    onClick={() => setCompareMode((v) => !v)}
                    disabled={pinnedResponses.length < 2}
                    active={compareMode}
                    accent={ACCENT}
                  />
                  <ActionChip
                    icon="download"
                    label="Export"
                    onClick={handleExportPinned}
                    accent={ACCENT}
                  />
                </div>
              }
            />

            <div style={{ display: 'flex', flexWrap: 'wrap', gap: 6, marginBottom: compareMode ? 12 : 0 }}>
              {pinnedResponses.map((pr, idx) => (
                <div
                  key={idx}
                  style={{
                    display: 'inline-flex',
                    alignItems: 'center',
                    gap: 6,
                    padding: '4px 10px',
                    borderRadius: 6,
                    backgroundColor: 'rgba(255,255,255,0.02)',
                    border: `1px solid ${THEME.border}`,
                    fontSize: 11,
                    color: THEME.textSecondary,
                  }}
                >
                  <EuiIcon type="pinFilled" size="s" color={ACCENT} />
                  <span style={{ maxWidth: 160, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                    {pr.content ? pr.content.substring(0, 40) + '...' : `Result ${idx + 1}`}
                  </span>
                  <button
                    onClick={() => unpinResponse(idx)}
                    style={{
                      background: 'none', border: 'none', color: THEME.textMuted,
                      cursor: 'pointer', padding: 2, display: 'flex', alignItems: 'center',
                    }}
                    title="Unpin"
                  >
                    <EuiIcon type="cross" size="s" />
                  </button>
                </div>
              ))}
            </div>

            {compareMode && pinnedResponses.length >= 2 && (
              <ComparePanel
                pinnedResponses={pinnedResponses}
                onClose={() => setCompareMode(false)}
                accent={ACCENT}
              />
            )}
          </div>
        )}

        {/* Response Area */}
        <div ref={resultsRef}>
          {(response || isLoading) && (
            <div>
              <SectionHeader
                icon={isLoading ? 'clock' : 'check'}
                title={isLoading ? 'Processing...' : 'Results'}
                accent={ACCENT}
                actions={
                  response && !isLoading ? (
                    <div style={{ display: 'flex', gap: 6 }}>
                      <ActionChip icon="pinFilled" label="Pin" onClick={handlePinCurrent} accent={ACCENT} />
                      <ActionChip icon="cross" label="Clear" onClick={clearResponse} accent={ACCENT} />
                    </div>
                  ) : null
                }
              />
              <ResponsePanel
                content={response?.content}
                blocks={response?.blocks}
                metadata={response?.metadata}
                socAnalysis={response?.socAnalysis}
                suggestions={response?.suggestions}
                onSuggestionClick={(q) => { if (!isDisabled) sendQuery(q); }}
                isLoading={isLoading}
                onCancel={cancelQuery}
                onPin={handlePinCurrent}
                accent={ACCENT}
              />
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
