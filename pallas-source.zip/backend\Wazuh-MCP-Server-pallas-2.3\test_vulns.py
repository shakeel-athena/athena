import asyncio
import sys
sys.path.insert(0, '/app/src')

from wazuh_mcp_server.config import get_config, WazuhConfig
from wazuh_mcp_server.api.wazuh_client import WazuhClient

async def test():
    config = get_config()
    
    wazuh_config = WazuhConfig(
        wazuh_host=config.WAZUH_HOST,
        wazuh_user=config.WAZUH_USER,
        wazuh_pass=config.WAZUH_PASS,
        wazuh_port=config.WAZUH_PORT,
        verify_ssl=config.WAZUH_VERIFY_SSL,
        wazuh_indexer_host=config.WAZUH_INDEXER_HOST,
        wazuh_indexer_port=config.WAZUH_INDEXER_PORT,
        wazuh_indexer_user=config.WAZUH_INDEXER_USER,
        wazuh_indexer_pass=config.WAZUH_INDEXER_PASS
    )
    
    client = WazuhClient(wazuh_config)
    await client.initialize()
    
    print("\n=== TEST 1: All Vulnerabilities (no filters) ===")
    result = await client.get_vulnerabilities(limit=10000)
    vulns = result.get('vulnerabilities', [])
    print(f"Total returned: {len(vulns)}")
    
    by_severity = {}
    for v in vulns:
        sev = v.get('severity', 'Unknown')
        by_severity[sev] = by_severity.get(sev, 0) + 1
    
    print("Breakdown by severity:")
    for sev, count in sorted(by_severity.items()):
        print(f"  {sev}: {count}")
    
    print("\n=== TEST 2: Critical Only ===")
    result2 = await client.get_critical_vulnerabilities(limit=10000)
    crit_vulns = result2.get('vulnerabilities', [])
    print(f"Total critical: {len(crit_vulns)}")
    
    await client.close()

asyncio.run(test())
