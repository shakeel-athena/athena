"""
Correlation Engine - Intelligent multi-tool result correlation
Handles primary Ã¢â€ â€™ secondary tool orchestration and data merging

Supports:
- Vulnerabilities Ã¢â€ â€ Agents enrichment
- Agent ranking by vulnerability count
- Filters (active/disconnected + critical/high)
- Threshold queries (e.g., >100 vulnerabilities)
- Comparison queries (active vs disconnected)
- Agent posture deep-dive (vulns + ports + processes) when secondary tools are executed
"""

import json
import logging
from datetime import datetime, timezone
from typing import List, Dict, Any, Optional, Callable
from dataclasses import dataclass

logger = logging.getLogger(__name__)


@dataclass
class CorrelationResult:
    correlated_data: List[Dict[str, Any]]
    summary: Dict[str, Any]
    correlation_type: str
    primary_tool: str
    secondary_tools: List[str]


_PENDING_STRATEGIES: Dict[str, Callable] = {}


def register_strategy(name: str):
    """Decorator to register correlation strategies (lazy)"""
    def decorator(func):
        _PENDING_STRATEGIES[name] = func
        return func
    return decorator


class CorrelationEngine:
    """
    Correlates data from multiple tool executions.
    Handles MCP tool wrapper + Wazuh API structures robustly.
    """

    STRATEGIES: Dict[str, Callable] = {}

    # -----------------------------
    # Safe type conversion helper
    # -----------------------------
    def _safe_int(self, value, default=0):
        """Safely convert value to int, returning default on failure."""
        try:
            return int(value)
        except (ValueError, TypeError):
            return default

    # -----------------------------
    # Core normalize/extract helpers
    # -----------------------------
    def _normalize_tool_payload(self, payload: Any) -> Dict[str, Any]:
        """
        Normalize raw MCP tool responses to a consistent dict:
          {"data": {"affected_items":[...]}}
        Handles:
        - {"content":[{"text":"{json}"}]}
        - {"data": {...}}
        - {"affected_items":[...]}  (already data-like)
        """
        if payload is None:
            return {"data": {"affected_items": []}}

        if isinstance(payload, dict):
            # Check for raw data alongside MCP content (agent/vuln tools include both)
            if "data" in payload and isinstance(payload["data"], dict) and "content" in payload:
                raw_data = payload["data"]
                if "affected_items" in raw_data and isinstance(raw_data["affected_items"], list):
                    return {"data": raw_data}

            # MCP wrapper: {"content":[{"text":"...json..."}]}
            if "content" in payload and isinstance(payload.get("content"), list) and payload["content"]:
                text = payload["content"][0].get("text", "")
                if isinstance(text, str) and text.strip():
                    try:
                        parsed = json.loads(text)
                        if isinstance(parsed, dict):
                            if "data" in parsed and isinstance(parsed["data"], dict):
                                return parsed
                            if "affected_items" in parsed and isinstance(parsed.get("affected_items"), list):
                                return {"data": parsed}
                            # fallback: treat parsed as data object
                            return {"data": parsed}
                    except json.JSONDecodeError:
                        return {"data": {"affected_items": []}, "meta": {"raw_text": text[:500]}}

            # Wazuh-style: {"data": {...}}
            if "data" in payload and isinstance(payload["data"], dict):
                return payload

            # Data-like already
            if "affected_items" in payload and isinstance(payload.get("affected_items"), list):
                return {"data": payload}

            # Last fallback
            return {"data": {"affected_items": []}, "meta": {"raw": payload}}

        return {"data": {"affected_items": []}, "meta": {"payload_type": str(type(payload))}}

    def _items(self, normalized: Dict[str, Any]) -> List[Dict[str, Any]]:
        data = normalized.get("data", {})
        if isinstance(data, dict):
            items = data.get("affected_items", [])
            return items if isinstance(items, list) else []
        return []

    def _get_raw_text(self, normalized: Dict[str, Any]) -> str:
        """Extract raw text from a normalized payload (fallback for text-formatted responses)."""
        meta = normalized.get("meta", {})
        if isinstance(meta, dict):
            raw_text = meta.get("raw_text", "")
            if raw_text:
                return raw_text
        # Try extracting from the original content wrapper
        data = normalized.get("data", {})
        if isinstance(data, dict):
            text = data.get("text", "")
            if text:
                return text
        return ""

    def _extract_agent_from_raw(self, normalized: Dict[str, Any]) -> Dict[str, Any]:
        """Extract agent info from raw text when _items() returns empty.
        Handles cases where agent data is in text format from server.py."""
        raw = self._get_raw_text(normalized)
        if not raw:
            return {}
        # Try parsing as JSON first (most common case)
        try:
            parsed = json.loads(raw)
            if isinstance(parsed, dict):
                items = parsed.get("data", {}).get("affected_items", [])
                if items:
                    return items[0]
        except (json.JSONDecodeError, AttributeError):
            pass
        return {}

    def _get_agent_id(self, item: Dict[str, Any]) -> Optional[str]:
        """Extract and normalize agent_id from various document formats.
        Handles: direct 'agent_id', nested 'agent.id', or top-level 'id' for agent docs."""
        # Direct field
        if "agent_id" in item:
            return str(item["agent_id"]).lstrip("0") or "0"
        # Nested agent object (vulnerability/alert documents)
        agent = item.get("agent", {})
        if isinstance(agent, dict) and "id" in agent:
            return str(agent["id"]).lstrip("0") or "0"
        # Top-level 'id' if item looks like an agent (has 'status' + 'name')
        if "name" in item and "id" in item and "status" in item:
            return str(item["id"]).lstrip("0") or "0"
        return None

    def _normalize_agent_id(self, aid: Any) -> str:
        """Normalize agent ID for consistent matching (strip leading zeros)."""
        if aid is None:
            return ""
        return str(aid).lstrip("0") or "0"

    def _classify_pools(self, primary: Dict[str, Any], secondary: List[Dict[str, Any]]) -> tuple:
        """Classify all data pools into agents and non-agents (vulns/alerts).
        Returns (agents_list, other_list). Handles tool order variation."""
        agents: List[Dict[str, Any]] = []
        others: List[Dict[str, Any]] = []
        for pool in [primary] + list(secondary):
            items = self._items(pool)
            if not items:
                continue
            sample = items[0]
            is_agent = "status" in sample and "name" in sample and ("os" in sample or "ip" in sample)
            if is_agent:
                agents.extend(items)
            else:
                others.extend(items)
        return agents, others

    def _severity_rank(self, sev: Any) -> int:
        order = {"critical": 0, "high": 1, "medium": 2, "low": 3}
        return order.get(str(sev or "low").lower(), 99)

    def _extract_cvss_score(self, vuln: Dict[str, Any]) -> Optional[float]:
        cvss = vuln.get("cvss") or {}
        try:
            cvss3 = (cvss.get("cvss3") or {}).get("base_score")
            if cvss3 is not None:
                return float(cvss3)
            cvss2 = (cvss.get("cvss2") or {}).get("base_score")
            if cvss2 is not None:
                return float(cvss2)
        except Exception:
            return None
        return None

    def _compact_agent(self, a: Dict[str, Any]) -> Dict[str, Any]:
        return {
            "id": a.get("id"),
            "name": a.get("name"),
            "ip": a.get("ip"),
            "status": a.get("status"),
            "os": (a.get("os") or {}).get("name"),
            "os_version": (a.get("os") or {}).get("version"),
            "last_keep_alive": a.get("lastKeepAlive"),
            "groups": a.get("group", []) or a.get("groups", []),
        }

    def _summarize_vulnerabilities(self, vulns: List[Dict[str, Any]]) -> Dict[str, int]:
        out = {"total": len(vulns), "critical": 0, "high": 0, "medium": 0, "low": 0}
        for v in vulns:
            s = str(v.get("severity", "low")).lower()
            if s in out:
                out[s] += 1
        return out

    def _calculate_agent_risk_score(self, agent: Dict[str, Any], vulns: List[Dict[str, Any]]) -> int:
        score = 0
        vs = self._summarize_vulnerabilities(vulns)
        score += vs["critical"] * 25
        score += vs["high"] * 10
        score += vs["medium"] * 3
        score += vs["low"] * 1
        if str(agent.get("status", "")).lower() == "disconnected":
            score += 20
        return min(100, score)

    def _top_vulns_minimal(self, vulns: List[Dict[str, Any]], limit: int = 10) -> List[Dict[str, Any]]:
        def rank(v):
            return (self._severity_rank(v.get("severity")), -(self._extract_cvss_score(v) or 0.0))

        out = []
        for v in sorted(vulns, key=rank)[:limit]:
            out.append({
                "cve_id": v.get("id") or v.get("cve") or v.get("cve_id"),
                "severity": v.get("severity"),
                "cvss_score": self._extract_cvss_score(v),
                "package": (v.get("package") or {}).get("name"),
                "version": (v.get("package") or {}).get("version"),
                "status": v.get("status"),
                "detected_at": v.get("detected_at"),
                "agent_id": (v.get("agent") or {}).get("id"),
            })
        return out

    def _calculate_vuln_risk_factors(self, vuln: Dict[str, Any], agent: Dict[str, Any]) -> List[str]:
        factors: List[str] = []
        sev = str(vuln.get("severity", "")).lower()
        if sev in ("critical", "high"):
            factors.append(f"{sev.capitalize()} severity")

        if str(agent.get("status", "")).lower() == "disconnected":
            factors.append("Agent offline - patch visibility may be stale")

        groups = agent.get("group", []) or agent.get("groups", [])
        if any(("dmz" in str(g).lower()) or ("web" in str(g).lower()) for g in groups):
            factors.append("Internet-facing system (group heuristic)")

        score = self._extract_cvss_score(vuln)
        if score is not None and score >= 9.0:
            factors.append("CVSS >= 9.0")

        return factors

    def _count_by_agent_status(self, items: List[Dict[str, Any]]) -> Dict[str, int]:
        counts = {"active": 0, "disconnected": 0, "unknown": 0}
        for it in items:
            st = str((it.get("agent") or {}).get("status", "unknown")).lower()
            counts[st] = counts.get(st, 0) + 1 if st in counts else counts["unknown"] + 1
        return counts

    def _count_by_severity(self, items: List[Dict[str, Any]]) -> Dict[str, int]:
        out = {"Critical": 0, "High": 0, "Medium": 0, "Low": 0}
        for it in items:
            s = str(it.get("severity", "low")).lower()
            if s == "critical": out["Critical"] += 1
            elif s == "high": out["High"] += 1
            elif s == "medium": out["Medium"] += 1
            else: out["Low"] += 1
        return out

    # -----------------------------
    # Public API
    # -----------------------------
    def correlate(
        self,
        strategy: str,
        primary_result: Dict[str, Any],
        secondary_results: List[Dict[str, Any]],
        context: Optional[Dict[str, Any]] = None
    ) -> CorrelationResult:

        context = context or {}

        primary_norm = self._normalize_tool_payload(primary_result)
        secondary_norm = [self._normalize_tool_payload(r) for r in (secondary_results or [])]

        correlator = self.STRATEGIES.get(strategy)
        if not correlator:
            logger.warning(f"Unknown correlation strategy: {strategy}")
            return self._fallback(primary_norm, secondary_norm)

        try:
            return correlator(self, primary_norm, secondary_norm, context)
        except Exception as e:
            logger.error(f"Correlation '{strategy}' failed: {e}", exc_info=True)
            return self._fallback(primary_norm, secondary_norm)

    def _fallback(self, primary_norm: Dict[str, Any], secondary_norm: List[Dict[str, Any]]) -> CorrelationResult:
        all_items: List[Dict[str, Any]] = []
        all_items.extend(self._items(primary_norm))
        for r in secondary_norm:
            all_items.extend(self._items(r))

        return CorrelationResult(
            correlated_data=all_items,
            summary={"total_items": len(all_items), "mode": "fallback"},
            correlation_type="fallback",
            primary_tool="unknown",
            secondary_tools=[]
        )

    # ================================================================
    # STRATEGIES
    # ================================================================

    @register_strategy("vulnerability_with_agents")
    def vulnerability_with_agents(self, primary: Dict[str, Any], secondary: List[Dict[str, Any]], context: Dict[str, Any]) -> CorrelationResult:
        # Detect agents vs vulns from all pools (tool order may vary)
        all_pools = [primary] + list(secondary)
        vulns: List[Dict[str, Any]] = []
        agents: List[Dict[str, Any]] = []

        for pool in all_pools:
            items = self._items(pool)
            if items:
                sample = items[0]
                is_agent = "status" in sample and "name" in sample and ("os" in sample or "ip" in sample)
                if is_agent:
                    agents.extend(items)
                else:
                    vulns.extend(items)

        logger.info(f"[CORRELATION] vulnerability_with_agents: {len(vulns)} vulns, {len(agents)} agents")
        agent_map = {self._normalize_agent_id(a.get("id")): a for a in agents if a.get("id")}

        enriched: List[Dict[str, Any]] = []
        affected_agents = set()

        for v in vulns:
            aid = self._get_agent_id(v)
            # Extract CVE ID robustly — try dedicated fields first, then 'id' only if it looks like a CVE
            raw_id = v.get("id") or ""
            cve_id = v.get("cve_id") or v.get("cve") or (raw_id if "CVE" in str(raw_id).upper() else None) or raw_id or "Unknown"
            severity = v.get("severity") or "Unknown"

            if aid and aid in agent_map:
                a = agent_map[aid]
                affected_agents.add(aid)
                enriched.append({
                    "cve_id": cve_id,
                    "id": raw_id,
                    "severity": severity,
                    "status": v.get("status"),
                    "detected_at": v.get("detected_at"),
                    "description": (v.get("description") or "")[:250],
                    "cvss_score": self._extract_cvss_score(v),
                    "package": {
                        "name": (v.get("package") or {}).get("name"),
                        "version": (v.get("package") or {}).get("version"),
                    },
                    "agent": self._compact_agent(a),
                    "risk_factors": self._calculate_vuln_risk_factors(v, a),
                })
            else:
                agent_info = v.get("agent") or {}
                enriched.append({
                    "cve_id": cve_id,
                    "id": raw_id,
                    "severity": severity,
                    "package": {
                        "name": (v.get("package") or {}).get("name"),
                        "version": (v.get("package") or {}).get("version"),
                    },
                    "agent": {"id": aid or agent_info.get("id"), "name": agent_info.get("name", "Unknown"), "status": "N/A"},
                    "note": "Agent details not available"
                })

        enriched.sort(key=lambda x: self._severity_rank(x.get("severity")))

        # Deduplicate by CVE ID — aggregate affected agents per CVE
        cve_map: Dict[str, Dict[str, Any]] = {}
        for item in enriched:
            cve_id = item.get("cve_id") or item.get("id") or "unknown"
            if cve_id not in cve_map:
                cve_map[cve_id] = {
                    **item,
                    "affected_agents": [],
                    "affected_agent_count": 0,
                    "occurrence_count": 0,
                }
            entry = cve_map[cve_id]
            entry["occurrence_count"] += 1
            agent_info = item.get("agent", {})
            agent_id = agent_info.get("id") if agent_info else None
            if agent_id and agent_id not in [a.get("id") for a in entry["affected_agents"]]:
                entry["affected_agents"].append(agent_info)
            entry["affected_agent_count"] = len(entry["affected_agents"])

        deduplicated = list(cve_map.values())
        deduplicated.sort(key=lambda x: self._severity_rank(x.get("severity")))

        logger.info(f"[CORRELATION] Deduplicated: {len(enriched)} → {len(deduplicated)} unique CVEs")

        return CorrelationResult(
            correlated_data=deduplicated,
            summary={
                "total_vulnerabilities": len(vulns),
                "unique_cves": len(deduplicated),
                "affected_agents": len(affected_agents),
                "by_severity": self._count_by_severity(deduplicated),
                "by_agent_status": self._count_by_agent_status(deduplicated),
            },
            correlation_type="vulnerability_with_agents",
            primary_tool="get_wazuh_vulnerabilities",
            secondary_tools=["get_wazuh_agents"]
        )

    @register_strategy("agents_with_vulnerabilities")
    def agents_with_vulnerabilities(self, primary: Dict[str, Any], secondary: List[Dict[str, Any]], context: Dict[str, Any]) -> CorrelationResult:
        # Detect agents vs vulns from all pools (tool order may vary)
        all_pools = [primary] + list(secondary)
        agents: List[Dict[str, Any]] = []
        vulns: List[Dict[str, Any]] = []

        for pool in all_pools:
            items = self._items(pool)
            if items:
                sample = items[0]
                is_agent = "status" in sample and "name" in sample and ("os" in sample or "ip" in sample)
                if is_agent:
                    agents.extend(items)
                else:
                    vulns.extend(items)

        # Group vulnerabilities by normalized agent ID for reliable matching
        by_agent: Dict[str, List[Dict[str, Any]]] = {}
        for v in vulns:
            aid = self._get_agent_id(v)
            if aid:
                by_agent.setdefault(aid, []).append(v)

        logger.info(f"[CORRELATION] agents_with_vulnerabilities: {len(agents)} agents, {len(vulns)} vulns, {len(by_agent)} agent IDs with vulns")

        out: List[Dict[str, Any]] = []
        for a in agents:
            aid = self._normalize_agent_id(a.get("id"))
            vlist = by_agent.get(aid, []) if aid else []
            vs = self._summarize_vulnerabilities(vlist)
            out.append({
                **self._compact_agent(a),
                "vulnerability_count": vs["total"],
                "by_severity": {"critical": vs["critical"], "high": vs["high"], "medium": vs["medium"], "low": vs["low"]},
                "risk_score": self._calculate_agent_risk_score(a, vlist),
                "top_vulnerabilities": self._top_vulns_minimal(vlist, limit=10),
            })

        out.sort(key=lambda x: x.get("vulnerability_count", 0), reverse=True)

        return CorrelationResult(
            correlated_data=out,
            summary={
                "total_agents": len(agents),
                "total_vulnerabilities": len(vulns),
                "agents_with_vulnerabilities": sum(1 for x in out if x.get("vulnerability_count", 0) > 0),
            },
            correlation_type="agents_with_vulnerabilities",
            primary_tool="get_wazuh_agents",
            secondary_tools=["get_wazuh_vulnerabilities"]
        )

    @register_strategy("disconnected_agents_with_critical_vulns")
    def disconnected_agents_with_critical_vulns(self, primary: Dict[str, Any], secondary: List[Dict[str, Any]], context: Dict[str, Any]) -> CorrelationResult:
        agents, vulns = self._classify_pools(primary, secondary)

        critical = [v for v in vulns if str(v.get("severity", "")).lower() == "critical"]
        by_agent: Dict[str, List[Dict[str, Any]]] = {}
        for v in critical:
            aid = self._get_agent_id(v)
            if aid:
                by_agent.setdefault(aid, []).append(v)

        out: List[Dict[str, Any]] = []
        disconnected = [a for a in agents if str(a.get("status", "")).lower() == "disconnected"]
        for a in disconnected:
            aid = self._normalize_agent_id(a.get("id"))
            vlist = by_agent.get(aid, [])
            if not vlist:
                continue
            out.append({
                **self._compact_agent(a),
                "critical_vulnerability_count": len(vlist),
                "top_critical_vulnerabilities": self._top_vulns_minimal(vlist, limit=10),
                "risk_score": self._calculate_agent_risk_score(a, vlist),
            })

        out.sort(key=lambda x: x.get("critical_vulnerability_count", 0), reverse=True)

        return CorrelationResult(
            correlated_data=out,
            summary={
                "disconnected_agents_with_critical_vulns": len(out),
                "total_disconnected_agents": len(disconnected),
                "total_critical_vulns_seen": len(critical),
            },
            correlation_type="disconnected_agents_with_critical_vulns",
            primary_tool="get_wazuh_agents",
            secondary_tools=["get_wazuh_vulnerabilities"]
        )

    @register_strategy("top_agents_by_vuln_count")
    def top_agents_by_vuln_count(self, primary: Dict[str, Any], secondary: List[Dict[str, Any]], context: Dict[str, Any]) -> CorrelationResult:
        top_n = self._safe_int(context.get("top_n", 5), 5)

        agents, vulns = self._classify_pools(primary, secondary)
        agent_map = {self._normalize_agent_id(a.get("id")): a for a in agents if a.get("id")}

        counts: Dict[str, int] = {}
        for v in vulns:
            aid = self._get_agent_id(v)
            if aid:
                counts[aid] = counts.get(aid, 0) + 1

        ranked = sorted(counts.items(), key=lambda kv: kv[1], reverse=True)[:top_n]

        out: List[Dict[str, Any]] = []
        for aid, total in ranked:
            a = agent_map.get(aid, {"id": aid, "name": "Unknown", "status": "unknown"})
            out.append({**self._compact_agent(a), "vulnerability_count": total})

        return CorrelationResult(
            correlated_data=out,
            summary={"top_n": top_n, "total_vulnerabilities_seen": len(vulns)},
            correlation_type="top_agents_by_vuln_count",
            primary_tool="get_wazuh_agents",
            secondary_tools=["get_wazuh_vulnerabilities"]
        )

    @register_strategy("active_agents_vulns_over_threshold")
    def active_agents_vulns_over_threshold(self, primary: Dict[str, Any], secondary: List[Dict[str, Any]], context: Dict[str, Any]) -> CorrelationResult:
        threshold = self._safe_int(context.get("threshold", 100), 100)

        agents, vulns = self._classify_pools(primary, secondary)

        counts: Dict[str, int] = {}
        for v in vulns:
            aid = self._get_agent_id(v)
            if aid:
                counts[aid] = counts.get(aid, 0) + 1

        out: List[Dict[str, Any]] = []
        for a in agents:
            if str(a.get("status", "")).lower() != "active":
                continue
            aid = self._normalize_agent_id(a.get("id"))
            total = counts.get(aid, 0)
            if total > threshold:
                out.append({**self._compact_agent(a), "vulnerability_count": total})

        out.sort(key=lambda x: x.get("vulnerability_count", 0), reverse=True)

        return CorrelationResult(
            correlated_data=out,
            summary={"threshold": threshold, "active_agents_over_threshold": len(out)},
            correlation_type="active_agents_vulns_over_threshold",
            primary_tool="get_wazuh_agents",
            secondary_tools=["get_wazuh_vulnerabilities"]
        )

    @register_strategy("active_agents_with_high_vulns")
    def active_agents_with_high_vulns(self, primary: Dict[str, Any], secondary: List[Dict[str, Any]], context: Dict[str, Any]) -> CorrelationResult:
        agents, vulns = self._classify_pools(primary, secondary)

        high = [v for v in vulns if str(v.get("severity", "")).lower() == "high"]
        by_agent: Dict[str, int] = {}
        for v in high:
            aid = self._get_agent_id(v)
            if aid:
                by_agent[aid] = by_agent.get(aid, 0) + 1

        out: List[Dict[str, Any]] = []
        for a in agents:
            if str(a.get("status", "")).lower() != "active":
                continue
            aid = self._normalize_agent_id(a.get("id"))
            c = by_agent.get(aid, 0)
            if c > 0:
                out.append({**self._compact_agent(a), "high_vulnerability_count": c})

        out.sort(key=lambda x: x.get("high_vulnerability_count", 0), reverse=True)

        return CorrelationResult(
            correlated_data=out,
            summary={"active_agents_with_high_vulns": len(out), "total_high_vulns_seen": len(high)},
            correlation_type="active_agents_with_high_vulns",
            primary_tool="get_wazuh_agents",
            secondary_tools=["get_wazuh_vulnerabilities"]
        )

    @register_strategy("compare_vulns_active_vs_disconnected")
    def compare_vulns_active_vs_disconnected(self, primary: Dict[str, Any], secondary: List[Dict[str, Any]], context: Dict[str, Any]) -> CorrelationResult:
        # Detect agents vs vulns from primary and secondary (tool order may vary)
        all_pools = [primary] + list(secondary)
        agents: List[Dict[str, Any]] = []
        vulns: List[Dict[str, Any]] = []

        for pool in all_pools:
            items = self._items(pool)
            if items:
                sample = items[0]
                is_agent = "status" in sample and "name" in sample and ("os" in sample or "ip" in sample)
                if is_agent:
                    agents.extend(items)
                else:
                    vulns.extend(items)

        status_map = {self._normalize_agent_id(a.get("id")): str(a.get("status", "unknown")).lower() for a in agents if a.get("id")}
        logger.info(f"[CORRELATION] compare_vulns: {len(agents)} agents, {len(vulns)} vulns, status_map keys: {list(status_map.keys())[:10]}")

        active = disconnected = unknown = 0
        for v in vulns:
            aid = self._get_agent_id(v)
            st = status_map.get(aid, "unknown")
            if st == "active":
                active += 1
            elif st == "disconnected":
                disconnected += 1
            else:
                unknown += 1

        return CorrelationResult(
            correlated_data=[{
                "active_vulnerabilities": active,
                "disconnected_vulnerabilities": disconnected,
                "unknown_status_vulnerabilities": unknown
            }],
            summary={
                "active_vulnerabilities": active,
                "disconnected_vulnerabilities": disconnected,
                "unknown_status_vulnerabilities": unknown
            },
            correlation_type="compare_vulns_active_vs_disconnected",
            primary_tool="get_wazuh_agents",
            secondary_tools=["get_wazuh_vulnerabilities"]
        )


    @register_strategy("alerts_with_agents")
    def alerts_with_agents(self, primary: Dict[str, Any], secondary: List[Dict[str, Any]], context: Dict[str, Any]) -> CorrelationResult:
        """Enrich alerts with agent details — agent name, OS, status, groups."""
        agents, alerts = self._classify_pools(primary, secondary)
        # _classify_pools returns (agents, others) — here "others" are alerts
        agent_map = {self._normalize_agent_id(a.get("id")): a for a in agents if a.get("id")}

        enriched: List[Dict[str, Any]] = []
        severity_counts: Dict[str, int] = {"critical": 0, "high": 0, "medium": 0, "low": 0}
        rule_counts: Dict[str, int] = {}

        for alert in alerts:
            aid = self._get_agent_id(alert)
            agent_info = agent_map.get(aid) if aid else None
            rule = alert.get("rule") or {}
            level = self._safe_int(rule.get("level", 0))
            rule_id = str(rule.get("id", "unknown"))
            rule_counts[rule_id] = rule_counts.get(rule_id, 0) + 1

            sev = "critical" if level >= 12 else "high" if level >= 7 else "medium" if level >= 4 else "low"
            severity_counts[sev] += 1

            enriched.append({
                "timestamp": alert.get("timestamp") or alert.get("@timestamp", ""),
                "rule_id": rule_id,
                "rule_description": rule.get("description", ""),
                "level": level,
                "severity": sev,
                "agent_id": aid,
                "agent_name": (alert.get("agent") or {}).get("name", "Unknown"),
                "agent_status": (agent_info or {}).get("status", "unknown") if agent_info else "unknown",
                "agent_os": ((agent_info or {}).get("os") or {}).get("name", "N/A") if agent_info else "N/A",
                "agent_ip": (agent_info or {}).get("ip", "N/A") if agent_info else "N/A",
                "data": alert.get("data", {}),
            })

        top_rules = sorted(rule_counts.items(), key=lambda x: x[1], reverse=True)[:5]

        return CorrelationResult(
            correlated_data=enriched,
            summary={
                "total_alerts": len(alerts),
                "severity_breakdown": severity_counts,
                "top_rules": [{"rule_id": r, "count": c} for r, c in top_rules],
                "unique_agents": len({e["agent_id"] for e in enriched if e["agent_id"]}),
            },
            correlation_type="alerts_with_agents",
            primary_tool="get_wazuh_alerts",
            secondary_tools=["get_wazuh_agents"]
        )

    @register_strategy("agent_posture_deep_dive")
    def agent_posture_deep_dive(self, primary: Dict[str, Any], secondary: List[Dict[str, Any]], context: Dict[str, Any]) -> CorrelationResult:
        """Deep dive: single agent enriched with vulns + ports + processes."""
        agents = self._items(primary)
        agent = agents[0] if agents else {}

        # Fallback: if _items() returned nothing, try extracting from raw text
        if not agent:
            agent = self._extract_agent_from_raw(primary)

        vulns: List[Dict[str, Any]] = []
        ports: List[Dict[str, Any]] = []
        procs: List[Dict[str, Any]] = []
        ports_raw_text: str = ""
        procs_raw_text: str = ""

        for r in secondary:
            items = self._items(r)
            if items:
                sample = items[0]
                if "severity" in sample or "cve" in str(sample.get("id", "")):
                    vulns.extend(items)
                elif "port" in sample or "local" in sample or "local_port" in sample:
                    ports.extend(items)
                elif "pid" in sample or "name" in sample:
                    procs.extend(items)
                else:
                    procs.extend(items)
            else:
                # Fallback: extract raw text for ports/processes that come as markdown
                raw = self._get_raw_text(r)
                if raw:
                    if "port" in raw.lower()[:100] or "listening" in raw.lower()[:200]:
                        ports_raw_text = raw
                    elif "process" in raw.lower()[:100] or "pid" in raw.lower()[:200]:
                        procs_raw_text = raw

        vs = self._summarize_vulnerabilities(vulns)
        return CorrelationResult(
            correlated_data=[{
                "agent": self._compact_agent(agent),
                "vulnerability_summary": vs,
                "top_vulnerabilities": self._top_vulns_minimal(vulns, limit=10),
                "open_ports": ports[:20],
                "running_processes": procs[:20],
                "ports_raw_text": ports_raw_text,
                "procs_raw_text": procs_raw_text,
                "risk_score": self._calculate_agent_risk_score(agent, vulns),
            }],
            summary={
                "agent_id": agent.get("id"),
                "agent_name": agent.get("name"),
                "total_vulnerabilities": vs["total"],
                "open_ports": len(ports),
                "running_processes": len(procs),
                "has_ports_text": bool(ports_raw_text),
                "has_procs_text": bool(procs_raw_text),
            },
            correlation_type="agent_posture_deep_dive",
            primary_tool="get_wazuh_agents",
            secondary_tools=["get_wazuh_vulnerabilities", "get_agent_ports", "get_agent_processes"]
        )

    @register_strategy("alerts_with_vulnerabilities")
    def alerts_with_vulnerabilities(self, primary: Dict[str, Any], secondary: List[Dict[str, Any]], context: Dict[str, Any]) -> CorrelationResult:
        """Cross-correlate: agents with active alerts AND known vulnerabilities, ranked by combined risk."""
        # Classify ALL pools — tool order may vary
        all_pools = [primary] + list(secondary)
        alerts: List[Dict[str, Any]] = []
        vuln_items: List[Dict[str, Any]] = []
        agent_items: List[Dict[str, Any]] = []

        for pool in all_pools:
            items = self._items(pool)
            if not items:
                continue
            sample = items[0]
            # Detect agent items: have status + name + os/ip (from wazuh_client)
            is_agent = "status" in sample and "name" in sample and ("os" in sample or "ip" in sample)
            # Detect vulnerability items: have severity/cve/package fields (from wazuh_indexer)
            is_vuln = (
                "severity" in sample
                or "cve" in str(sample.get("id", "")).upper()
                or "package" in sample
                or "detected_at" in sample
                or "reference" in sample
            )
            # Detect alert items: have rule object
            is_alert = "rule" in sample or "@timestamp" in sample

            if is_agent and not is_vuln:
                agent_items.extend(items)
            elif is_vuln and not is_agent:
                vuln_items.extend(items)
            elif is_alert:
                alerts.extend(items)
            else:
                # Fallback: check more items for classification
                has_rule = any("rule" in i for i in items[:5])
                if has_rule:
                    alerts.extend(items)
                elif any("status" in i and "name" in i for i in items[:5]):
                    agent_items.extend(items)
                else:
                    vuln_items.extend(items)

        logger.info(f"[CORRELATION] alerts_with_vulnerabilities: {len(alerts)} alerts, {len(vuln_items)} vulns, {len(agent_items)} agents")

        # Build alert counts by agent (using normalized IDs)
        alert_by_agent: Dict[str, Dict[str, Any]] = {}
        for alert in alerts:
            aid = self._get_agent_id(alert)
            if not aid:
                continue
            if aid not in alert_by_agent:
                alert_by_agent[aid] = {"total": 0, "critical": 0, "high": 0, "medium": 0, "low": 0}
            alert_by_agent[aid]["total"] += 1
            rule = alert.get("rule", {}) if isinstance(alert.get("rule"), dict) else {}
            level = 0
            try:
                level = int(rule.get("level", alert.get("level", 0)))
            except (ValueError, TypeError):
                pass
            if level >= 12:
                alert_by_agent[aid]["critical"] += 1
            elif level >= 7:
                alert_by_agent[aid]["high"] += 1
            elif level >= 4:
                alert_by_agent[aid]["medium"] += 1
            else:
                alert_by_agent[aid]["low"] += 1

        # Build vuln counts by agent (using normalized IDs)
        vuln_by_agent: Dict[str, Dict[str, Any]] = {}
        for v in vuln_items:
            aid = self._get_agent_id(v)
            if not aid:
                continue
            if aid not in vuln_by_agent:
                vuln_by_agent[aid] = {"total": 0, "critical": 0, "high": 0, "medium": 0, "low": 0}
            vuln_by_agent[aid]["total"] += 1
            sev = str(v.get("severity", "low")).lower()
            if sev in vuln_by_agent[aid]:
                vuln_by_agent[aid][sev] += 1

        # Cross-reference: agents in BOTH sets (normalized IDs)
        both_agents = set(alert_by_agent.keys()) & set(vuln_by_agent.keys())
        agent_map = {self._normalize_agent_id(a.get("id")): a for a in agent_items if a.get("id")}
        logger.info(f"[CORRELATION] alerts_with_vulnerabilities: {len(alert_by_agent)} alert agents, {len(vuln_by_agent)} vuln agents, {len(both_agents)} in both")

        correlated: List[Dict[str, Any]] = []
        for aid in both_agents:
            a_counts = alert_by_agent[aid]
            v_counts = vuln_by_agent[aid]
            # Combined risk: alert severity weight + vuln severity weight
            alert_risk = a_counts["critical"] * 25 + a_counts["high"] * 10 + a_counts["medium"] * 3
            vuln_risk = v_counts["critical"] * 25 + v_counts["high"] * 10 + v_counts["medium"] * 3
            combined_risk = min(100, alert_risk + vuln_risk)

            agent_info = agent_map.get(aid, {})
            correlated.append({
                "agent_id": aid,
                "agent_name": agent_info.get("name", "Unknown"),
                "agent_status": agent_info.get("status", "unknown"),
                "alert_counts": a_counts,
                "vulnerability_counts": v_counts,
                "combined_risk": combined_risk,
            })

        correlated.sort(key=lambda x: x.get("combined_risk", 0), reverse=True)

        high_risk = [c for c in correlated if c["combined_risk"] >= 50]

        return CorrelationResult(
            correlated_data=correlated,
            summary={
                "agents_with_both": len(correlated),
                "high_risk_agents": len(high_risk),
                "total_alerts_analyzed": len(alerts),
                "total_vulns_analyzed": len(vuln_items),
            },
            correlation_type="alerts_with_vulnerabilities",
            primary_tool="get_wazuh_alerts",
            secondary_tools=["get_wazuh_vulnerabilities", "get_wazuh_agents"]
        )

    @register_strategy("rule_mitre_with_agents")
    def rule_mitre_with_agents(self, primary: Dict[str, Any], secondary: List[Dict[str, Any]], context: Dict[str, Any]) -> CorrelationResult:
        """MITRE coverage map enriched with which agents trigger which techniques."""
        # Primary: rule trigger analysis data
        primary_data = primary.get("data", primary)
        rules = primary_data.get("rules", [])
        if not rules and "affected_items" in primary_data:
            rules = primary_data["affected_items"]

        agents: List[Dict[str, Any]] = []
        for r in secondary:
            agents.extend(self._items(r))
        agent_map = {a.get("id"): a for a in agents if a.get("id")}

        # Build technique → rules mapping
        technique_map: Dict[str, Dict[str, Any]] = {}
        for rule in rules:
            techniques = rule.get("mitre_techniques", [])
            if isinstance(techniques, str):
                techniques = [techniques]
            for tech in techniques:
                if not tech:
                    continue
                if tech not in technique_map:
                    technique_map[tech] = {"technique": tech, "rules": [], "total_triggers": 0, "agents": set()}
                technique_map[tech]["rules"].append({
                    "rule_id": rule.get("rule_id"),
                    "count": rule.get("count", 0),
                    "description": rule.get("description", ""),
                })
                technique_map[tech]["total_triggers"] += rule.get("count", 0)

        # Convert sets to lists for JSON serialization
        enriched = []
        for tech, info in technique_map.items():
            enriched.append({
                "technique": info["technique"],
                "rules": info["rules"][:10],
                "rule_count": len(info["rules"]),
                "total_triggers": info["total_triggers"],
            })

        enriched.sort(key=lambda x: x["total_triggers"], reverse=True)

        return CorrelationResult(
            correlated_data=enriched,
            summary={
                "techniques_detected": len(enriched),
                "total_rules_with_mitre": sum(1 for r in rules if r.get("mitre_techniques")),
                "total_agents": len(agents),
            },
            correlation_type="rule_mitre_with_agents",
            primary_tool="get_rule_trigger_analysis",
            secondary_tools=["get_wazuh_agents"]
        )

    @register_strategy("fim_with_agent_posture")
    def fim_with_agent_posture(self, primary: Dict[str, Any], secondary: List[Dict[str, Any]], context: Dict[str, Any]) -> CorrelationResult:
        """FIM events enriched with agent context and running process correlation."""
        # Primary: FIM events
        primary_data = primary.get("data", primary)
        events = primary_data.get("events", [])
        if not events and "affected_items" in primary_data:
            events = primary_data["affected_items"]

        agents: List[Dict[str, Any]] = []
        procs: List[Dict[str, Any]] = []
        for r in secondary:
            items = self._items(r)
            if items:
                sample = items[0]
                if "pid" in sample or "name" in sample and "euser" in sample:
                    procs.extend(items)
                else:
                    agents.extend(items)

        agent_map = {a.get("id"): a for a in agents if a.get("id")}
        proc_names = {str(p.get("name", "")).lower() for p in procs}

        # Enrich FIM events with agent info
        enriched: List[Dict[str, Any]] = []
        for event in events:
            aid = event.get("agent_id") or (event.get("agent") or {}).get("id")
            agent_info = agent_map.get(aid, {})
            file_path = event.get("file_path") or event.get("syscheck_path", "")

            enriched.append({
                "timestamp": event.get("timestamp", ""),
                "agent_id": aid,
                "agent_name": agent_info.get("name", event.get("agent_name", "Unknown")),
                "agent_status": agent_info.get("status", "unknown"),
                "file_path": file_path,
                "change_type": event.get("change_type", event.get("syscheck_event", "unknown")),
                "user": event.get("user", event.get("syscheck_uname", "N/A")),
            })

        # Summary
        change_types = {}
        for e in enriched:
            ct = e.get("change_type", "unknown")
            change_types[ct] = change_types.get(ct, 0) + 1

        return CorrelationResult(
            correlated_data=enriched,
            summary={
                "total_fim_events": len(enriched),
                "change_types": change_types,
                "agents_affected": len({e["agent_id"] for e in enriched if e.get("agent_id")}),
                "total_agents": len(agents),
                "total_processes": len(procs),
            },
            correlation_type="fim_with_agent_posture",
            primary_tool="get_fim_events",
            secondary_tools=["get_wazuh_agents", "get_agent_processes"]
        )

    @register_strategy("vulnerability_trend_by_severity")
    def vulnerability_trend_by_severity(self, primary: Dict[str, Any], secondary: List[Dict[str, Any]], context: Dict[str, Any]) -> CorrelationResult:
        """Group vulnerabilities by severity with agent context."""
        vulns = self._items(primary)
        agents: List[Dict[str, Any]] = []
        for r in secondary:
            agents.extend(self._items(r))
        agent_map = {a.get("id"): a for a in agents if a.get("id")}

        by_severity: Dict[str, List[Dict]] = {"critical": [], "high": [], "medium": [], "low": []}
        for v in vulns:
            sev = str(v.get("severity", "low")).lower()
            if sev not in by_severity:
                sev = "low"
            aid = (v.get("agent") or {}).get("id")
            agent = agent_map.get(aid, {})
            by_severity[sev].append({
                "cve_id": v.get("id") or v.get("cve"),
                "cvss_score": self._extract_cvss_score(v),
                "package": (v.get("package") or {}).get("name"),
                "agent_name": agent.get("name") or (v.get("agent") or {}).get("name", "Unknown"),
                "agent_status": agent.get("status", "unknown"),
            })

        out = []
        for sev in ["critical", "high", "medium", "low"]:
            items = by_severity[sev]
            if items:
                out.append({
                    "severity": sev,
                    "count": len(items),
                    "top_10": sorted(items, key=lambda x: x.get("cvss_score") or 0, reverse=True)[:10],
                })

        return CorrelationResult(
            correlated_data=out,
            summary={
                "total_vulnerabilities": len(vulns),
                "critical": len(by_severity["critical"]),
                "high": len(by_severity["high"]),
                "medium": len(by_severity["medium"]),
                "low": len(by_severity["low"]),
            },
            correlation_type="vulnerability_trend_by_severity",
            primary_tool="get_wazuh_vulnerabilities",
            secondary_tools=["get_wazuh_agents"]
        )

    # ================================================================
    # SURICATA CORRELATION STRATEGIES
    # ================================================================

    # --- 3 Suricata-Internal Strategies ---

    @register_strategy("suricata_attacker_target_map")
    def suricata_attacker_target_map(self, primary: Dict[str, Any], secondary: List[Dict[str, Any]], context: Dict[str, Any]) -> CorrelationResult:
        """Map attacker IPs to targets with signature context from Suricata alerts + network analysis."""
        alerts = self._items(primary)
        network_data = {}
        for r in secondary:
            if isinstance(r, dict) and "top_source_ips" in r:
                network_data = r
                break
            items = self._items(r)
            if items and isinstance(items[0], dict) and "top_source_ips" in items[0]:
                network_data = items[0]
                break

        # Build attacker-target map from alerts
        attacker_map: Dict[str, Dict] = {}
        for a in alerts:
            src = a.get("src_ip", "")
            dst = a.get("dest_ip", "")
            alert_info = a.get("alert") or {}
            sig = alert_info.get("signature", "Unknown") if isinstance(alert_info, dict) else "Unknown"
            sev = alert_info.get("severity", 4) if isinstance(alert_info, dict) else 4

            if src not in attacker_map:
                attacker_map[src] = {"src_ip": src, "targets": {}, "signatures": set(), "alert_count": 0, "min_severity": 4}
            attacker_map[src]["targets"][dst] = attacker_map[src]["targets"].get(dst, 0) + 1
            attacker_map[src]["signatures"].add(sig)
            attacker_map[src]["alert_count"] += 1
            if isinstance(sev, int) and sev < attacker_map[src]["min_severity"]:
                attacker_map[src]["min_severity"] = sev

        # Convert to serializable list
        enriched = []
        for src, info in sorted(attacker_map.items(), key=lambda x: x[1]["alert_count"], reverse=True)[:20]:
            enriched.append({
                "src_ip": src,
                "alert_count": info["alert_count"],
                "unique_targets": len(info["targets"]),
                "top_targets": sorted(info["targets"].items(), key=lambda x: x[1], reverse=True)[:5],
                "unique_signatures": len(info["signatures"]),
                "top_signatures": list(info["signatures"])[:5],
                "min_severity": info["min_severity"],
            })

        return CorrelationResult(
            correlated_data=enriched,
            summary={
                "total_attackers": len(attacker_map),
                "total_alerts": len(alerts),
                "shown": len(enriched),
            },
            correlation_type="suricata_attacker_target_map",
            primary_tool="get_suricata_alerts",
            secondary_tools=["get_suricata_network_analysis"]
        )

    @register_strategy("suricata_signature_severity_analysis")
    def suricata_signature_severity_analysis(self, primary: Dict[str, Any], secondary: List[Dict[str, Any]], context: Dict[str, Any]) -> CorrelationResult:
        """Cross-reference Suricata signatures with severity distribution."""
        # Primary: alert summary, Secondary: critical alerts
        summary_data = primary if isinstance(primary, dict) and "top_signatures" in primary else {}
        if not summary_data:
            norm = self._normalize_tool_payload(primary)
            items = self._items(norm)
            if items and isinstance(items[0], dict) and "top_signatures" in items[0]:
                summary_data = items[0]

        critical_alerts = []
        for r in secondary:
            critical_alerts.extend(self._items(r))

        sigs = summary_data.get("top_signatures", [])
        sev_breakdown = summary_data.get("severity_breakdown", {})

        # Enrich signatures with critical alert context
        critical_sigs = set()
        for a in critical_alerts:
            alert = a.get("alert", {})
            critical_sigs.add(alert.get("signature", ""))

        enriched = []
        for s in sigs[:20]:
            sig_name = s.get("signature", "")
            enriched.append({
                "signature": sig_name,
                "count": s.get("count", 0),
                "has_critical": sig_name in critical_sigs,
            })

        return CorrelationResult(
            correlated_data=enriched,
            summary={
                "total_signatures": len(sigs),
                "severity_breakdown": sev_breakdown,
                "critical_signature_count": len(critical_sigs),
                "total_alerts": summary_data.get("total_alerts", 0),
            },
            correlation_type="suricata_signature_severity_analysis",
            primary_tool="get_suricata_alert_summary",
            secondary_tools=["get_suricata_critical_alerts"]
        )

    @register_strategy("suricata_network_threat_profile")
    def suricata_network_threat_profile(self, primary: Dict[str, Any], secondary: List[Dict[str, Any]], context: Dict[str, Any]) -> CorrelationResult:
        """Correlate network traffic patterns with threat categories."""
        # Primary: network analysis, Secondary: alert summary
        network = primary if isinstance(primary, dict) and "top_source_ips" in primary else {}
        if not network:
            norm = self._normalize_tool_payload(primary)
            items = self._items(norm)
            if items and isinstance(items[0], dict) and "top_source_ips" in items[0]:
                network = items[0]

        summary_data = {}
        for r in secondary:
            if isinstance(r, dict) and "top_categories" in r:
                summary_data = r
                break

        enriched = []
        src_ips = network.get("top_source_ips", [])
        for ip_info in src_ips[:15]:
            enriched.append({
                "ip": ip_info.get("ip", "N/A"),
                "alert_count": ip_info.get("count", 0),
                "type": "source",
            })

        dst_ips = network.get("top_dest_ips", [])
        for ip_info in dst_ips[:10]:
            enriched.append({
                "ip": ip_info.get("ip", "N/A"),
                "alert_count": ip_info.get("count", 0),
                "type": "destination",
            })

        return CorrelationResult(
            correlated_data=enriched,
            summary={
                "top_categories": summary_data.get("top_categories", [])[:10],
                "top_services": network.get("top_services", [])[:10],
                "total_source_ips": len(src_ips),
                "total_dest_ips": len(dst_ips),
                "total_alerts": summary_data.get("total_alerts", 0),
            },
            correlation_type="suricata_network_threat_profile",
            primary_tool="get_suricata_network_analysis",
            secondary_tools=["get_suricata_alert_summary"]
        )

    # --- 4 Wazuh-Suricata Cross-Platform Strategies ---

    @register_strategy("combined_alert_view")
    def combined_alert_view(self, primary: Dict[str, Any], secondary: List[Dict[str, Any]], context: Dict[str, Any]) -> CorrelationResult:
        """Unified alert timeline from Wazuh + Suricata."""
        raw_suricata = self._items(primary)
        # Defensive filter: only keep events that have an 'alert' object (skip HTTP/TLS/flow)
        suricata_alerts = [a for a in raw_suricata if a.get("alert")]
        wazuh_alerts = []
        for r in secondary:
            wazuh_alerts.extend(self._items(r))

        # Severity mapping: Suricata numeric severity -> label
        _sev_map = {1: "Critical", 2: "High", 3: "Medium"}

        # Normalize both into a common format
        unified = []
        for a in suricata_alerts:
            alert_info = a.get("alert", {})
            raw_sev = alert_info.get("severity")
            severity = _sev_map.get(raw_sev, "Low") if isinstance(raw_sev, int) else str(raw_sev) if raw_sev else "N/A"
            unified.append({
                "source": "Suricata",
                "timestamp": a.get("@timestamp", ""),
                "severity": severity,
                "description": alert_info.get("signature", "N/A"),
                "category": alert_info.get("category", "N/A"),
                "src_ip": a.get("src_ip") or (a.get("source") or {}).get("ip") or "N/A",
                "dest_ip": a.get("dest_ip") or (a.get("destination") or {}).get("ip") or "N/A",
            })

        for a in wazuh_alerts:
            rule = a.get("rule", {})
            agent = a.get("agent", {})
            unified.append({
                "source": "Wazuh",
                "timestamp": a.get("timestamp", a.get("@timestamp", "")),
                "severity": rule.get("level", "N/A"),
                "description": rule.get("description", "N/A"),
                "category": ", ".join(rule.get("groups", [])) if rule.get("groups") else "N/A",
                "src_ip": agent.get("ip", "N/A"),
                "dest_ip": "N/A",
            })

        # Sort by timestamp descending
        unified.sort(key=lambda x: x.get("timestamp", ""), reverse=True)

        return CorrelationResult(
            correlated_data=unified[:200],
            summary={
                "total_combined": len(unified),
                "suricata_count": len(suricata_alerts),
                "wazuh_count": len(wazuh_alerts),
            },
            correlation_type="combined_alert_view",
            primary_tool="get_suricata_alerts",
            secondary_tools=["get_wazuh_alerts"]
        )

    @register_strategy("wazuh_agents_suricata_detections")
    def wazuh_agents_suricata_detections(self, primary: Dict[str, Any], secondary: List[Dict[str, Any]], context: Dict[str, Any]) -> CorrelationResult:
        """Map Wazuh agent IPs to Suricata network detections."""
        agents = self._items(primary)
        suricata_alerts = []
        for r in secondary:
            suricata_alerts.extend(self._items(r))

        # Build IP → agent map
        ip_agent_map = {}
        for agent in agents:
            ip = agent.get("ip")
            if ip and ip != "127.0.0.1":
                ip_agent_map[ip] = agent

        # Match Suricata src/dest IPs to agent IPs
        enriched = []
        for agent_ip, agent in ip_agent_map.items():
            matching_alerts = []
            for a in suricata_alerts:
                if a.get("src_ip") == agent_ip or a.get("dest_ip") == agent_ip:
                    matching_alerts.append(a)

            if matching_alerts:
                enriched.append({
                    "agent_id": agent.get("id"),
                    "agent_name": agent.get("name"),
                    "agent_ip": agent_ip,
                    "agent_status": agent.get("status"),
                    "suricata_alerts": len(matching_alerts),
                    "as_source": sum(1 for a in matching_alerts if a.get("src_ip") == agent_ip),
                    "as_destination": sum(1 for a in matching_alerts if a.get("dest_ip") == agent_ip),
                    "unique_signatures": len(set(a.get("alert", {}).get("signature", "") for a in matching_alerts)),
                })

        enriched.sort(key=lambda x: x["suricata_alerts"], reverse=True)

        return CorrelationResult(
            correlated_data=enriched,
            summary={
                "total_agents": len(agents),
                "agents_with_detections": len(enriched),
                "total_suricata_alerts": len(suricata_alerts),
            },
            correlation_type="wazuh_agents_suricata_detections",
            primary_tool="get_wazuh_agents",
            secondary_tools=["get_suricata_alerts"]
        )

    @register_strategy("ioc_with_suricata_context")
    def ioc_with_suricata_context(self, primary: Dict[str, Any], secondary: List[Dict[str, Any]], context: Dict[str, Any]) -> CorrelationResult:
        """Enrich IOC reputation check with Suricata detection history."""
        ioc_data = primary if isinstance(primary, dict) else {}
        if not ioc_data:
            ioc_data = self._normalize_tool_payload(primary)

        suricata_alerts = []
        for r in secondary:
            suricata_alerts.extend(self._items(r))

        # Extract IOC indicator from context
        indicator = context.get("indicator", "")

        # Find Suricata alerts matching this indicator
        matching = []
        for a in suricata_alerts:
            if a.get("src_ip") == indicator or a.get("dest_ip") == indicator:
                matching.append({
                    "timestamp": a.get("@timestamp", "")[:19],
                    "signature": a.get("alert", {}).get("signature", "N/A"),
                    "category": a.get("alert", {}).get("category", "N/A"),
                    "severity": a.get("alert", {}).get("severity", "N/A"),
                    "direction": "source" if a.get("src_ip") == indicator else "destination",
                })

        enriched = [{
            "ioc_data": ioc_data,
            "suricata_detections": matching[:50],
            "suricata_detection_count": len(matching),
            "indicator": indicator,
        }]

        return CorrelationResult(
            correlated_data=enriched,
            summary={
                "indicator": indicator,
                "suricata_matches": len(matching),
                "total_suricata_checked": len(suricata_alerts),
            },
            correlation_type="ioc_with_suricata_context",
            primary_tool="check_ioc_reputation",
            secondary_tools=["get_suricata_alerts"]
        )

    @register_strategy("comprehensive_security_posture")
    def comprehensive_security_posture(self, primary: Dict[str, Any], secondary: List[Dict[str, Any]], context: Dict[str, Any]) -> CorrelationResult:
        """Full environment security posture: Wazuh agents + vulns + alerts + Suricata alerts."""
        agents = self._items(primary)

        wazuh_vulns = []
        wazuh_alerts = []
        suricata_alerts = []

        for r in secondary:
            items = self._items(r)
            if not items:
                continue
            sample = items[0] if items else {}
            # Detect data type by content
            if isinstance(sample, dict):
                if sample.get("alert", {}).get("signature"):
                    suricata_alerts.extend(items)
                elif sample.get("rule", {}).get("id"):
                    wazuh_alerts.extend(items)
                elif sample.get("cve") or sample.get("vulnerability"):
                    wazuh_vulns.extend(items)

        # Agent IP map for Suricata correlation
        ip_agent_map = {}
        for agent in agents:
            ip = agent.get("ip")
            if ip and ip != "127.0.0.1":
                ip_agent_map[ip] = agent.get("id")

        # Build per-agent posture
        enriched = []
        for agent in agents:
            if agent.get("id") == "000":
                continue
            aid = agent.get("id", "")
            agent_ip = agent.get("ip", "")

            # Count Wazuh vulnerabilities for this agent
            agent_vulns = [v for v in wazuh_vulns if (v.get("agent") or {}).get("id") == aid]
            # Count Wazuh alerts for this agent
            agent_wazuh_alerts = [a for a in wazuh_alerts if (a.get("agent") or {}).get("id") == aid]
            # Count Suricata detections for this agent's IP
            agent_suricata = [a for a in suricata_alerts if a.get("src_ip") == agent_ip or a.get("dest_ip") == agent_ip]

            enriched.append({
                "agent_id": aid,
                "agent_name": agent.get("name", "N/A"),
                "agent_ip": agent_ip,
                "agent_status": agent.get("status", "unknown"),
                "os": agent.get("os", {}).get("name", "N/A") if isinstance(agent.get("os"), dict) else str(agent.get("os", "N/A")),
                "vulnerabilities": len(agent_vulns),
                "wazuh_alerts": len(agent_wazuh_alerts),
                "suricata_detections": len(agent_suricata),
                "risk_score": len(agent_vulns) * 2 + len(agent_wazuh_alerts) + len(agent_suricata) * 3,
            })

        enriched.sort(key=lambda x: x["risk_score"], reverse=True)

        return CorrelationResult(
            correlated_data=enriched,
            summary={
                "total_agents": len([a for a in agents if a.get("id") != "000"]),
                "total_vulnerabilities": len(wazuh_vulns),
                "total_wazuh_alerts": len(wazuh_alerts),
                "total_suricata_alerts": len(suricata_alerts),
                "agents_with_suricata_detections": sum(1 for e in enriched if e["suricata_detections"] > 0),
            },
            correlation_type="comprehensive_security_posture",
            primary_tool="get_wazuh_agents",
            secondary_tools=["get_wazuh_vulnerabilities", "get_wazuh_alerts", "get_suricata_alerts"]
        )


    # ------------------------------------------------------------------
    # Helpers for Suricata & cross-platform strategies
    # ------------------------------------------------------------------
    def _normalize_payload(self, payload: Any) -> Dict[str, Any]:
        """Return the inner data dict from any MCP/tool payload."""
        norm = self._normalize_tool_payload(payload)
        data = norm.get("data", {})
        return data if isinstance(data, dict) else {}

    def _extract_items(self, data: Dict[str, Any]) -> List[Dict[str, Any]]:
        """Extract affected_items list from a normalized data dict."""
        items = data.get("affected_items", [])
        return items if isinstance(items, list) else []

    # ==================================================================
    # SURICATA DEEP VISIBILITY CORRELATION STRATEGIES
    # ==================================================================

    @register_strategy("suricata_http_alert_context")
    def suricata_http_alert_context(self, primary: Dict[str, Any], secondary: List[Dict[str, Any]], context: Dict[str, Any]) -> CorrelationResult:
        """Enrich Suricata alerts with HTTP traffic context."""
        # Extract alerts
        alerts = self._normalize_payload(primary)
        alert_items = self._extract_items(alerts)

        # Extract HTTP analysis from secondary
        http_data = {}
        if secondary:
            http_data = self._normalize_payload(secondary[0]) if secondary[0] else {}

        # Build attacker IP → HTTP context map
        alert_src_ips = set()
        for a in alert_items:
            src = a.get("src_ip", "")
            if src:
                alert_src_ips.add(src)

        # Extract top URLs and user agents from HTTP analysis
        top_urls = http_data.get("top_urls", [])
        top_user_agents = http_data.get("top_user_agents", [])
        total_http = http_data.get("total_events", 0)

        enriched = {
            "alerts": alert_items[:50],
            "alert_count": len(alert_items),
            "alert_source_ips": list(alert_src_ips)[:20],
            "http_context": {
                "total_http_events": total_http,
                "top_urls": top_urls[:10],
                "top_user_agents": top_user_agents[:10],
            }
        }

        return CorrelationResult(
            correlated_data=[enriched],
            summary={
                "total_alerts": len(alert_items),
                "unique_alert_sources": len(alert_src_ips),
                "total_http_events": total_http,
            },
            correlation_type="suricata_http_alert_context",
            primary_tool="get_suricata_alerts",
            secondary_tools=["get_suricata_http_analysis"]
        )

    @register_strategy("wazuh_suricata_mitre_unified")
    def wazuh_suricata_mitre_unified(self, primary: Dict[str, Any], secondary: List[Dict[str, Any]], context: Dict[str, Any]) -> CorrelationResult:
        """Unified MITRE ATT&CK coverage from Wazuh + Suricata."""
        # Primary: Suricata MITRE data
        suricata_mitre = self._normalize_payload(primary)

        # Secondary: Wazuh alerts (extract MITRE from rule data)
        wazuh_alerts = []
        if secondary:
            wazuh_data = self._normalize_payload(secondary[0]) if secondary[0] else {}
            wazuh_alerts = self._extract_items(wazuh_data)

        # Suricata tactics/techniques
        suricata_tactics = set()
        suricata_techniques = set()
        for t in suricata_mitre.get("tactics", []):
            suricata_tactics.add(t.get("tactic_name", ""))
        for t in suricata_mitre.get("techniques", []):
            suricata_techniques.add(t.get("technique_name", ""))

        # Wazuh MITRE data (from rule.mitre fields)
        wazuh_tactics = set()
        wazuh_techniques = set()
        for alert in wazuh_alerts:
            rule = alert.get("rule", {})
            mitre = rule.get("mitre", {})
            for tactic in mitre.get("tactic", []):
                wazuh_tactics.add(tactic)
            for technique in mitre.get("technique", []):
                wazuh_techniques.add(technique)
            for tid in mitre.get("id", []):
                wazuh_techniques.add(tid)

        # Build unified coverage
        all_tactics = suricata_tactics | wazuh_tactics
        all_techniques = suricata_techniques | wazuh_techniques
        overlap_tactics = suricata_tactics & wazuh_tactics
        overlap_techniques = suricata_techniques & wazuh_techniques

        enriched = {
            "suricata_tactics": sorted(suricata_tactics),
            "suricata_techniques": sorted(suricata_techniques),
            "suricata_total_mitre_alerts": suricata_mitre.get("total_mitre_alerts", 0),
            "wazuh_tactics": sorted(wazuh_tactics),
            "wazuh_techniques": sorted(wazuh_techniques),
            "wazuh_mitre_alerts": len([a for a in wazuh_alerts if a.get("rule", {}).get("mitre")]),
            "unified_tactics": sorted(all_tactics),
            "unified_techniques": sorted(all_techniques),
            "overlap_tactics": sorted(overlap_tactics),
            "overlap_techniques": sorted(overlap_techniques),
        }

        return CorrelationResult(
            correlated_data=enriched,
            summary={
                "suricata_unique_tactics": len(suricata_tactics),
                "suricata_unique_techniques": len(suricata_techniques),
                "wazuh_unique_tactics": len(wazuh_tactics),
                "wazuh_unique_techniques": len(wazuh_techniques),
                "total_unified_tactics": len(all_tactics),
                "total_unified_techniques": len(all_techniques),
                "overlapping_tactics": len(overlap_tactics),
            },
            correlation_type="wazuh_suricata_mitre_unified",
            primary_tool="get_suricata_mitre_mapping",
            secondary_tools=["get_wazuh_alerts"]
        )

    @register_strategy("suricata_tls_threat_detection")
    def suricata_tls_threat_detection(self, primary: Dict[str, Any], secondary: List[Dict[str, Any]], context: Dict[str, Any]) -> CorrelationResult:
        """Correlate TLS anomalies with Suricata alert data."""
        # Primary: TLS analysis
        tls_data = self._normalize_payload(primary)

        # Secondary: Suricata alerts
        alert_items = []
        if secondary:
            alert_data = self._normalize_payload(secondary[0]) if secondary[0] else {}
            alert_items = self._extract_items(alert_data)

        # Build alert IP set for cross-reference
        alert_src_ips = set()
        for a in alert_items:
            src = a.get("src_ip", "")
            if src:
                alert_src_ips.add(src)

        # Check TLS versions for legacy
        legacy_versions = {"TLS 1.0", "TLS 1.1", "SSLv3", "SSLv2"}
        tls_versions = tls_data.get("tls_versions", [])
        legacy_found = [v for v in tls_versions if v.get("version") in legacy_versions]

        # JA3 fingerprints
        top_ja3 = tls_data.get("top_ja3", [])
        total_tls = tls_data.get("total_events", 0)

        enriched = {
            "total_tls_events": total_tls,
            "tls_versions": tls_versions,
            "legacy_tls_found": legacy_found,
            "legacy_tls_count": sum(v.get("count", 0) for v in legacy_found),
            "top_ja3_fingerprints": top_ja3[:10],
            "total_alerts": len(alert_items),
            "alert_source_ips_count": len(alert_src_ips),
        }

        return CorrelationResult(
            correlated_data=enriched,
            summary={
                "total_tls_events": total_tls,
                "legacy_tls_versions_found": len(legacy_found),
                "legacy_tls_event_count": sum(v.get("count", 0) for v in legacy_found),
                "unique_ja3_fingerprints": len(top_ja3),
                "total_alerts": len(alert_items),
            },
            correlation_type="suricata_tls_threat_detection",
            primary_tool="get_suricata_tls_analysis",
            secondary_tools=["get_suricata_alerts"]
        )

    @register_strategy("suricata_recon_detection")
    def suricata_recon_detection(self, primary: Dict[str, Any], secondary: List[Dict[str, Any]], context: Dict[str, Any]) -> CorrelationResult:
        """Detect reconnaissance patterns by correlating HTTP, alerts, and network data."""
        # Primary: HTTP analysis
        http_data = self._normalize_payload(primary)

        # Secondary: alerts + network analysis
        alert_items = []
        network_data = {}
        for sec in secondary:
            if not sec:
                continue
            normalized = self._normalize_payload(sec)
            items = self._extract_items(normalized)
            if items:
                alert_items = items
            elif normalized.get("top_source_ips"):
                network_data = normalized

        # Extract HTTP top-talker source IPs from user agents
        suspicious_indicators = []

        # Check for scanner-like user agents in HTTP data
        top_uas = http_data.get("top_user_agents", [])
        scanner_keywords = ["curl", "wget", "python", "nikto", "nmap", "sqlmap",
                           "gobuster", "dirbuster", "masscan", "zgrab", "bot", "crawler"]
        for ua in top_uas:
            agent = ua.get("user_agent", "").lower()
            for keyword in scanner_keywords:
                if keyword in agent:
                    suspicious_indicators.append({
                        "type": "scanner_user_agent",
                        "indicator": ua.get("user_agent", ""),
                        "count": ua.get("count", 0),
                    })
                    break

        # Check for high 4xx/5xx responses (probing)
        status_codes = http_data.get("top_status_codes", [])
        error_codes = [s for s in status_codes if self._safe_int(s.get("status_code", 0)) >= 400]
        total_errors = sum(s.get("count", 0) for s in error_codes)

        # Cross-reference with alert data
        alert_src_ips = set()
        for a in alert_items:
            src = a.get("src_ip", "")
            if src:
                alert_src_ips.add(src)

        # Cross-reference with network top sources
        top_sources = network_data.get("top_source_ips", [])

        enriched = {
            "total_http_events": http_data.get("total_events", 0),
            "scanner_user_agents": suspicious_indicators,
            "http_error_codes": error_codes,
            "total_http_errors": total_errors,
            "total_alerts": len(alert_items),
            "alert_source_ips": list(alert_src_ips)[:20],
            "top_network_sources": top_sources[:10],
        }

        return CorrelationResult(
            correlated_data=enriched,
            summary={
                "total_http_events": http_data.get("total_events", 0),
                "scanner_agents_found": len(suspicious_indicators),
                "http_error_count": total_errors,
                "total_alerts": len(alert_items),
                "unique_alert_sources": len(alert_src_ips),
            },
            correlation_type="suricata_recon_detection",
            primary_tool="get_suricata_http_analysis",
            secondary_tools=["get_suricata_alerts", "get_suricata_network_analysis"]
        )


    # ==================================================================
    # PALLAS 3.2: UNIVERSAL QUERY COVERAGE CORRELATION STRATEGIES
    # ==================================================================

    # ------ Tier 1: Cross-Source Investigation ------

    @register_strategy("ip_investigation_pivot")
    def ip_investigation_pivot(self, primary: Dict[str, Any], secondary: List[Dict[str, Any]], context: Dict[str, Any]) -> CorrelationResult:
        """Cross-source IP investigation — search all data sources for a single IP."""
        # Primary: Wazuh alerts (filtered by IP via query)
        wazuh_data = self._normalize_payload(primary)
        wazuh_alerts = self._extract_items(wazuh_data)

        # Secondary[0]: Suricata alerts, [1]: Suricata HTTP, [2]: Wazuh agents
        suricata_alerts = []
        http_data = {}
        agents = []
        if len(secondary) > 0:
            s0 = self._normalize_payload(secondary[0])
            suricata_alerts = self._extract_items(s0)
        if len(secondary) > 1:
            http_data = self._normalize_payload(secondary[1])
        if len(secondary) > 2:
            s2 = self._normalize_payload(secondary[2])
            agents = self._extract_items(s2)

        # Target IP from context
        target_ip = context.get("ip_address", "")

        # Find matching agent
        matching_agent = None
        for a in agents:
            if a.get("id") == "000":
                continue
            agent_ip = a.get("ip", "") or a.get("registerIP", "")
            if agent_ip == target_ip:
                matching_agent = self._compact_agent(a)
                break

        # Wazuh alert summary for this IP
        wazuh_rules = {}
        for alert in wazuh_alerts[:200]:
            rule = alert.get("rule", {})
            desc = rule.get("description", "Unknown")
            wazuh_rules[desc] = wazuh_rules.get(desc, 0) + 1
        top_wazuh_rules = sorted(wazuh_rules.items(), key=lambda x: x[1], reverse=True)[:10]

        # Suricata alert summary for this IP
        suricata_sigs = {}
        for alert in suricata_alerts[:200]:
            sig = alert.get("alert", {}).get("signature", "") or alert.get("signature", "Unknown")
            suricata_sigs[sig] = suricata_sigs.get(sig, 0) + 1
        top_suricata_sigs = sorted(suricata_sigs.items(), key=lambda x: x[1], reverse=True)[:10]

        # HTTP activity summary
        http_urls = http_data.get("top_urls", [])[:10]
        http_user_agents = http_data.get("top_user_agents", [])[:10]

        enriched = {
            "target_ip": target_ip,
            "matching_agent": matching_agent,
            "wazuh_alerts": {
                "total": len(wazuh_alerts),
                "top_rules": [{"rule": r, "count": c} for r, c in top_wazuh_rules],
            },
            "suricata_alerts": {
                "total": len(suricata_alerts),
                "top_signatures": [{"signature": s, "count": c} for s, c in top_suricata_sigs],
            },
            "http_activity": {
                "total_events": http_data.get("total_events", 0),
                "top_urls": http_urls,
                "top_user_agents": http_user_agents,
            },
        }

        return CorrelationResult(
            correlated_data=enriched,
            summary={
                "target_ip": target_ip,
                "is_known_agent": matching_agent is not None,
                "wazuh_alert_count": len(wazuh_alerts),
                "suricata_alert_count": len(suricata_alerts),
                "http_event_count": http_data.get("total_events", 0),
            },
            correlation_type="ip_investigation_pivot",
            primary_tool="get_wazuh_alerts",
            secondary_tools=["get_suricata_alerts", "search_suricata_http", "get_wazuh_agents"]
        )

    @register_strategy("full_agent_investigation")
    def full_agent_investigation(self, primary: Dict[str, Any], secondary: List[Dict[str, Any]], context: Dict[str, Any]) -> CorrelationResult:
        """Complete agent security investigation across ALL data sources."""
        # Primary: agent data
        agent_data = self._normalize_payload(primary)
        agents = self._extract_items(agent_data)
        agent = agents[0] if agents else self._extract_agent_from_raw(self._normalize_tool_payload(primary))

        agent_id = self._normalize_agent_id(agent.get("id"))
        agent_ip = agent.get("ip", "") or agent.get("registerIP", "")

        # Secondary: [0]=vulns, [1]=ports, [2]=processes, [3]=alerts, [4]=fim
        vulns, ports, processes, alerts, fim_events = [], [], [], [], []
        for i, key in enumerate(["vulnerabilities", "ports", "processes", "alerts", "fim"]):
            if i < len(secondary):
                d = self._normalize_payload(secondary[i])
                items = self._extract_items(d)
                if key == "vulnerabilities":
                    vulns = [v for v in items if self._normalize_agent_id((v.get("agent") or {}).get("id")) == agent_id]
                elif key == "ports":
                    ports = items
                elif key == "processes":
                    processes = items
                elif key == "alerts":
                    alerts = [a for a in items if str((a.get("agent") or {}).get("id", "")).lstrip("0") == agent_id]
                elif key == "fim":
                    fim_events = items

        vuln_summary = self._summarize_vulnerabilities(vulns)
        risk_score = self._calculate_agent_risk_score(agent, vulns)

        # Add alert + FIM contribution to risk
        alert_risk = sum(5 for a in alerts if self._safe_int((a.get("rule") or {}).get("level", 0)) >= 12)
        alert_risk += sum(3 for a in alerts if 7 <= self._safe_int((a.get("rule") or {}).get("level", 0)) < 12)
        risk_score = min(100, risk_score + alert_risk)

        # Suspicious ports
        suspicious_ports = [p for p in ports if self._safe_int((p.get("local") or {}).get("port", 0)) in
                           (21, 23, 25, 445, 1433, 3306, 3389, 5432, 5900, 6379, 8080, 8443, 9200)]

        enriched = {
            "agent": self._compact_agent(agent),
            "risk_score": risk_score,
            "vulnerabilities": {
                "summary": vuln_summary,
                "top": self._top_vulns_minimal(vulns, 10),
            },
            "open_ports": {
                "total": len(ports),
                "suspicious": [{"port": (p.get("local") or {}).get("port"), "protocol": p.get("protocol"),
                                "process": (p.get("process") or {}).get("name", "N/A")} for p in suspicious_ports],
                "items": [{"port": (p.get("local") or {}).get("port"), "protocol": p.get("protocol"),
                           "state": p.get("state", "N/A"), "process": (p.get("process") or {}).get("name", "N/A")}
                          for p in ports[:20]],
            },
            "processes": {
                "total": len(processes),
                "items": [{"pid": p.get("pid"), "name": p.get("name"), "user": p.get("euser", "N/A")}
                          for p in processes[:20]],
            },
            "alerts": {
                "total": len(alerts),
                "items": [{"rule_id": (a.get("rule") or {}).get("id"),
                           "description": (a.get("rule") or {}).get("description", "N/A"),
                           "level": (a.get("rule") or {}).get("level"),
                           "timestamp": a.get("timestamp")} for a in alerts[:10]],
            },
            "fim_events": {
                "total": len(fim_events),
                "items": [{"path": e.get("syscheck", {}).get("path", "N/A"),
                           "event": e.get("syscheck", {}).get("event", "N/A"),
                           "timestamp": e.get("timestamp")} for e in fim_events[:10]],
            },
        }

        return CorrelationResult(
            correlated_data=enriched,
            summary={
                "agent_id": agent_id,
                "agent_name": agent.get("name", "N/A"),
                "risk_score": risk_score,
                "total_vulnerabilities": vuln_summary["total"],
                "critical_vulns": vuln_summary["critical"],
                "open_ports": len(ports),
                "suspicious_ports": len(suspicious_ports),
                "total_alerts": len(alerts),
                "fim_events": len(fim_events),
            },
            correlation_type="full_agent_investigation",
            primary_tool="get_wazuh_agents",
            secondary_tools=["get_wazuh_vulnerabilities", "get_agent_ports", "get_agent_processes",
                             "get_wazuh_alerts", "get_fim_events"]
        )

    @register_strategy("cross_platform_ip_correlation")
    def cross_platform_ip_correlation(self, primary: Dict[str, Any], secondary: List[Dict[str, Any]], context: Dict[str, Any]) -> CorrelationResult:
        """Find IPs that appear in both Wazuh and Suricata platforms."""
        # Primary: Suricata top attackers
        attacker_data = self._normalize_payload(primary)
        top_attackers = attacker_data.get("top_attackers", []) or self._extract_items(attacker_data)

        # Secondary[0]: Wazuh alerts, [1]: Wazuh agents
        wazuh_alerts = []
        agents = []
        if len(secondary) > 0:
            w0 = self._normalize_payload(secondary[0])
            wazuh_alerts = self._extract_items(w0)
        if len(secondary) > 1:
            a0 = self._normalize_payload(secondary[1])
            agents = self._extract_items(a0)

        # Build Suricata IP → count map
        suricata_ips = {}
        for att in top_attackers:
            ip = att.get("ip", "") or att.get("key", "")
            count = att.get("count", 0) or att.get("doc_count", 0)
            if ip:
                suricata_ips[ip] = count

        # Build Wazuh IP → count map from alerts
        wazuh_ips = {}
        for alert in wazuh_alerts:
            src_ip = (alert.get("data") or {}).get("srcip", "") or alert.get("src_ip", "")
            if src_ip:
                wazuh_ips[src_ip] = wazuh_ips.get(src_ip, 0) + 1

        # Build agent IP set
        agent_ips = {}
        for a in agents:
            if a.get("id") == "000":
                continue
            ip = a.get("ip", "") or a.get("registerIP", "")
            if ip:
                agent_ips[ip] = {"id": a.get("id"), "name": a.get("name", "N/A"), "status": a.get("status", "unknown")}

        # Cross-reference
        all_ips = set(suricata_ips.keys()) | set(wazuh_ips.keys())
        correlated = []
        for ip in sorted(all_ips):
            s_count = suricata_ips.get(ip, 0)
            w_count = wazuh_ips.get(ip, 0)
            agent_info = agent_ips.get(ip)
            detected_by = []
            if s_count > 0:
                detected_by.append("Suricata")
            if w_count > 0:
                detected_by.append("Wazuh")
            correlated.append({
                "ip": ip,
                "suricata_hits": s_count,
                "wazuh_hits": w_count,
                "total_hits": s_count + w_count,
                "detected_by": " + ".join(detected_by),
                "is_agent": agent_info is not None,
                "agent_id": agent_info["id"] if agent_info else None,
                "agent_name": agent_info["name"] if agent_info else None,
            })

        correlated.sort(key=lambda x: x["total_hits"], reverse=True)
        both_platforms = [c for c in correlated if c["suricata_hits"] > 0 and c["wazuh_hits"] > 0]

        return CorrelationResult(
            correlated_data=correlated[:50],
            summary={
                "total_unique_ips": len(all_ips),
                "ips_in_both_platforms": len(both_platforms),
                "suricata_only": len([c for c in correlated if c["suricata_hits"] > 0 and c["wazuh_hits"] == 0]),
                "wazuh_only": len([c for c in correlated if c["wazuh_hits"] > 0 and c["suricata_hits"] == 0]),
                "ips_matching_agents": len([c for c in correlated if c["is_agent"]]),
            },
            correlation_type="cross_platform_ip_correlation",
            primary_tool="get_suricata_top_attackers",
            secondary_tools=["get_wazuh_alerts", "get_wazuh_agents"]
        )

    @register_strategy("unified_scanning_detection")
    def unified_scanning_detection(self, primary: Dict[str, Any], secondary: List[Dict[str, Any]], context: Dict[str, Any]) -> CorrelationResult:
        """Unified scanner detection from Suricata suspicious activity + Wazuh alerts."""
        # Primary: Suricata suspicious activity
        suspicious = self._normalize_payload(primary)

        # Secondary[0]: Suricata top attackers, [1]: Wazuh alerts
        attacker_data = {}
        wazuh_alerts = []
        if len(secondary) > 0:
            attacker_data = self._normalize_payload(secondary[0])
        if len(secondary) > 1:
            w0 = self._normalize_payload(secondary[1])
            wazuh_alerts = self._extract_items(w0)

        # Suricata scanner IPs (from suspicious user agents)
        scanner_ips = {}
        for ua in suspicious.get("suspicious_user_agents", []):
            for ip in ua.get("src_ips", [])[:5]:
                ip_addr = ip.get("ip", "") or ip.get("key", "")
                if ip_addr:
                    scanner_ips.setdefault(ip_addr, {"sources": set(), "details": []})
                    scanner_ips[ip_addr]["sources"].add("Suricata (User Agent)")
                    scanner_ips[ip_addr]["details"].append(f"UA: {ua.get('user_agent', 'N/A')}")

        # Suricata top attackers
        for att in attacker_data.get("top_attackers", []):
            ip = att.get("ip", "") or att.get("key", "")
            if ip:
                scanner_ips.setdefault(ip, {"sources": set(), "details": []})
                scanner_ips[ip]["sources"].add("Suricata (Top Attacker)")
                count = att.get("count", 0) or att.get("doc_count", 0)
                scanner_ips[ip]["details"].append(f"Alerts: {count}")

        # Wazuh scan-related alerts (common scan rule descriptions)
        scan_keywords = ["scan", "brute", "attempt", "probe", "enumeration", "reconnaissance"]
        for alert in wazuh_alerts:
            rule_desc = (alert.get("rule") or {}).get("description", "").lower()
            if any(kw in rule_desc for kw in scan_keywords):
                src_ip = (alert.get("data") or {}).get("srcip", "")
                if src_ip:
                    scanner_ips.setdefault(src_ip, {"sources": set(), "details": []})
                    scanner_ips[src_ip]["sources"].add("Wazuh")
                    scanner_ips[src_ip]["details"].append(f"Rule: {(alert.get('rule') or {}).get('description', 'N/A')}")

        # Build result
        scanners = []
        for ip, info in sorted(scanner_ips.items(), key=lambda x: len(x[1]["sources"]), reverse=True):
            scanners.append({
                "ip": ip,
                "detected_by": " + ".join(sorted(info["sources"])),
                "platform_count": len(info["sources"]),
                "details": info["details"][:5],
            })

        return CorrelationResult(
            correlated_data=scanners[:30],
            summary={
                "total_scanner_ips": len(scanners),
                "multi_platform_detections": len([s for s in scanners if s["platform_count"] > 1]),
                "suricata_only": len([s for s in scanners if "Suricata" in s["detected_by"] and "Wazuh" not in s["detected_by"]]),
                "wazuh_only": len([s for s in scanners if "Wazuh" in s["detected_by"] and "Suricata" not in s["detected_by"]]),
            },
            correlation_type="unified_scanning_detection",
            primary_tool="get_suricata_suspicious_activity",
            secondary_tools=["get_suricata_top_attackers", "get_wazuh_alerts"]
        )

    # ------ Tier 2: Threat Analysis ------

    @register_strategy("attack_chain_analysis")
    def attack_chain_analysis(self, primary: Dict[str, Any], secondary: List[Dict[str, Any]], context: Dict[str, Any]) -> CorrelationResult:
        """Kill chain analysis — map observed MITRE tactics to attack progression."""
        # Full kill chain order
        KILL_CHAIN = [
            ("TA0043", "Reconnaissance"),
            ("TA0042", "Resource Development"),
            ("TA0001", "Initial Access"),
            ("TA0002", "Execution"),
            ("TA0003", "Persistence"),
            ("TA0004", "Privilege Escalation"),
            ("TA0005", "Defense Evasion"),
            ("TA0006", "Credential Access"),
            ("TA0007", "Discovery"),
            ("TA0008", "Lateral Movement"),
            ("TA0009", "Collection"),
            ("TA0011", "Command and Control"),
            ("TA0010", "Exfiltration"),
            ("TA0040", "Impact"),
        ]

        # Primary: Suricata MITRE data
        suricata_mitre = self._normalize_payload(primary)

        # Secondary[0]: Wazuh alerts, [1]: Suricata alerts
        wazuh_alerts = []
        suricata_alerts = []
        if len(secondary) > 0:
            w0 = self._normalize_payload(secondary[0])
            wazuh_alerts = self._extract_items(w0)
        if len(secondary) > 1:
            s0 = self._normalize_payload(secondary[1])
            suricata_alerts = self._extract_items(s0)

        # Collect observed tactics from Suricata MITRE
        observed_tactics = {}
        for t in suricata_mitre.get("tactics", []):
            tactic_name = t.get("tactic_name", "")
            tactic_id = t.get("tactic_id", "")
            count = t.get("count", 0) or t.get("doc_count", 0)
            if tactic_name or tactic_id:
                observed_tactics[tactic_name or tactic_id] = {
                    "id": tactic_id, "name": tactic_name, "count": count, "source": "Suricata"
                }

        # Collect from Wazuh alerts
        for alert in wazuh_alerts:
            mitre = (alert.get("rule") or {}).get("mitre", {})
            for tactic in mitre.get("tactic", []):
                if tactic not in observed_tactics:
                    observed_tactics[tactic] = {"id": "", "name": tactic, "count": 0, "source": "Wazuh"}
                observed_tactics[tactic]["count"] += 1
                if not observed_tactics[tactic]["source"] == "Both":
                    if observed_tactics[tactic]["source"] != "Wazuh":
                        observed_tactics[tactic]["source"] = "Both"

        # Collect techniques
        observed_techniques = {}
        for t in suricata_mitre.get("techniques", []):
            tech_name = t.get("technique_name", "")
            count = t.get("count", 0) or t.get("doc_count", 0)
            if tech_name:
                observed_techniques[tech_name] = {"count": count, "source": "Suricata"}

        for alert in wazuh_alerts:
            mitre = (alert.get("rule") or {}).get("mitre", {})
            for tech in mitre.get("technique", []):
                if tech not in observed_techniques:
                    observed_techniques[tech] = {"count": 0, "source": "Wazuh"}
                observed_techniques[tech]["count"] += 1

        # Build kill chain matrix
        chain_matrix = []
        for tactic_id, tactic_name in KILL_CHAIN:
            # Match by name (case-insensitive) or by ID
            matched = None
            for obs_name, obs_data in observed_tactics.items():
                if obs_name.lower() == tactic_name.lower() or obs_data.get("id") == tactic_id:
                    matched = obs_data
                    break
            chain_matrix.append({
                "tactic_id": tactic_id,
                "tactic_name": tactic_name,
                "observed": matched is not None,
                "alert_count": matched["count"] if matched else 0,
                "source": matched["source"] if matched else "N/A",
            })

        observed_count = sum(1 for c in chain_matrix if c["observed"])

        return CorrelationResult(
            correlated_data=[{
                "kill_chain": chain_matrix,
                "observed_techniques": [{"technique": k, "count": v["count"], "source": v["source"]}
                                        for k, v in sorted(observed_techniques.items(), key=lambda x: x[1]["count"], reverse=True)][:20],
                "total_wazuh_alerts": len(wazuh_alerts),
                "total_suricata_alerts": len(suricata_alerts),
            }],
            summary={
                "tactics_observed": observed_count,
                "tactics_total": len(KILL_CHAIN),
                "coverage_pct": round(observed_count / len(KILL_CHAIN) * 100, 1),
                "unique_techniques": len(observed_techniques),
                "gap_count": len(KILL_CHAIN) - observed_count,
            },
            correlation_type="attack_chain_analysis",
            primary_tool="get_suricata_mitre_mapping",
            secondary_tools=["get_wazuh_alerts", "get_suricata_alerts"]
        )

    @register_strategy("unified_threat_summary")
    def unified_threat_summary(self, primary: Dict[str, Any], secondary: List[Dict[str, Any]], context: Dict[str, Any]) -> CorrelationResult:
        """Prioritized threat summary across all data sources."""
        # Primary: Wazuh alert summary
        wazuh_summary = self._normalize_payload(primary)

        # Secondary[0]: Suricata alert summary, [1]: Vuln summary, [2]: Log source health
        suricata_summary = {}
        vuln_summary = {}
        log_health = {}
        if len(secondary) > 0:
            suricata_summary = self._normalize_payload(secondary[0])
        if len(secondary) > 1:
            vuln_summary = self._normalize_payload(secondary[1])
        if len(secondary) > 2:
            log_health = self._normalize_payload(secondary[2])

        # Build prioritized threat items
        threats = []

        # Critical vulnerabilities
        crit_vulns = vuln_summary.get("critical", 0) or vuln_summary.get("Critical", 0)
        if crit_vulns:
            threats.append({
                "rank": 0, "threat": f"{crit_vulns} Critical Vulnerabilities",
                "severity": "CRITICAL", "source": "Wazuh Vulnerability Scanner",
                "count": crit_vulns, "weight": crit_vulns * 5,
                "action": "Patch critical CVEs immediately; prioritize internet-facing systems"
            })

        # High vulnerabilities
        high_vulns = vuln_summary.get("high", 0) or vuln_summary.get("High", 0)
        if high_vulns:
            threats.append({
                "rank": 0, "threat": f"{high_vulns} High Vulnerabilities",
                "severity": "HIGH", "source": "Wazuh Vulnerability Scanner",
                "count": high_vulns, "weight": high_vulns * 3,
                "action": "Schedule patching within next maintenance window"
            })

        # High-level Wazuh alerts (level 12+)
        wazuh_levels = wazuh_summary.get("severity_breakdown", {})
        for level_str, count in wazuh_levels.items():
            try:
                level = int(level_str)
            except (ValueError, TypeError):
                continue
            if level >= 12 and count > 0:
                threats.append({
                    "rank": 0, "threat": f"{count} Critical Wazuh Alerts (Level {level}+)",
                    "severity": "CRITICAL", "source": "Wazuh SIEM",
                    "count": count, "weight": count * 5,
                    "action": "Investigate immediately — high-confidence security events"
                })
            elif level >= 7 and count > 0:
                threats.append({
                    "rank": 0, "threat": f"{count} High Wazuh Alerts (Level {level})",
                    "severity": "HIGH", "source": "Wazuh SIEM",
                    "count": count, "weight": count * 3,
                    "action": "Review alert details and validate for true positives"
                })

        # Suricata critical alerts
        suricata_severity = suricata_summary.get("severity_breakdown", {})
        sev1_count = suricata_severity.get("1", 0)  # severity 1 = critical in Suricata
        if sev1_count:
            threats.append({
                "rank": 0, "threat": f"{sev1_count} Critical IDS Alerts (Severity 1)",
                "severity": "CRITICAL", "source": "Suricata IDS",
                "count": sev1_count, "weight": sev1_count * 4,
                "action": "Investigate network intrusion attempts; check for successful exploitation"
            })
        sev2_count = suricata_severity.get("2", 0)
        if sev2_count:
            threats.append({
                "rank": 0, "threat": f"{sev2_count} High IDS Alerts (Severity 2)",
                "severity": "HIGH", "source": "Suricata IDS",
                "count": sev2_count, "weight": sev2_count * 3,
                "action": "Review IDS signatures for true positive rate"
            })

        # Silent/disconnected agents
        silent_agents = log_health.get("silent_agents", [])
        if silent_agents:
            threats.append({
                "rank": 0, "threat": f"{len(silent_agents)} Silent/Disconnected Agents",
                "severity": "MEDIUM", "source": "Agent Health",
                "count": len(silent_agents), "weight": len(silent_agents) * 3,
                "action": "Check agent connectivity; offline agents miss security events"
            })

        # Sort by weight descending and assign ranks
        threats.sort(key=lambda x: x["weight"], reverse=True)
        for i, t in enumerate(threats):
            t["rank"] = i + 1

        return CorrelationResult(
            correlated_data=threats[:10],
            summary={
                "total_threats_identified": len(threats),
                "critical_items": len([t for t in threats if t["severity"] == "CRITICAL"]),
                "high_items": len([t for t in threats if t["severity"] == "HIGH"]),
                "medium_items": len([t for t in threats if t["severity"] == "MEDIUM"]),
            },
            correlation_type="unified_threat_summary",
            primary_tool="get_wazuh_alert_summary",
            secondary_tools=["get_suricata_alert_summary", "get_wazuh_vulnerability_summary", "get_log_source_health"]
        )

    @register_strategy("vulnerability_exploit_correlation")
    def vulnerability_exploit_correlation(self, primary: Dict[str, Any], secondary: List[Dict[str, Any]], context: Dict[str, Any]) -> CorrelationResult:
        """Identify vulnerabilities that are being actively targeted by IDS alerts."""
        # Primary: Wazuh vulnerabilities
        vuln_data = self._normalize_payload(primary)
        vulns = self._extract_items(vuln_data)

        # Secondary[0]: Suricata alerts, [1]: Wazuh alerts
        suricata_alerts = []
        wazuh_alerts = []
        if len(secondary) > 0:
            s0 = self._normalize_payload(secondary[0])
            suricata_alerts = self._extract_items(s0)
        if len(secondary) > 1:
            w0 = self._normalize_payload(secondary[1])
            wazuh_alerts = self._extract_items(w0)

        # Build Suricata signature → CVE reference map
        sig_keywords = {}
        for alert in suricata_alerts:
            sig = alert.get("alert", {}).get("signature", "") or alert.get("signature", "")
            sig_lower = sig.lower()
            sig_keywords[sig_lower] = sig_keywords.get(sig_lower, 0) + 1

        # Build set of agent IDs with alerts
        alerted_agents = set()
        for alert in wazuh_alerts:
            aid = (alert.get("agent") or {}).get("id", "")
            if aid:
                alerted_agents.add(str(aid).lstrip("0") or "0")

        # Analyze each critical/high vulnerability
        enriched_vulns = []
        for v in sorted(vulns, key=lambda x: self._severity_rank(x.get("severity")))[:100]:
            cve_id = v.get("id") or v.get("cve") or v.get("cve_id") or ""
            severity = v.get("severity", "low")
            agent_id = self._normalize_agent_id((v.get("agent") or {}).get("id"))
            package = (v.get("package") or {}).get("name", "")

            # Check if any Suricata signature references this CVE or package
            related_sigs = []
            cve_lower = cve_id.lower()
            pkg_lower = package.lower()
            for sig_text, count in sig_keywords.items():
                if cve_lower and cve_lower in sig_text:
                    related_sigs.append({"signature": sig_text, "count": count, "match_type": "CVE"})
                elif pkg_lower and len(pkg_lower) > 3 and pkg_lower in sig_text:
                    related_sigs.append({"signature": sig_text, "count": count, "match_type": "Package"})

            # Check if agent has alerts
            agent_has_alerts = agent_id in alerted_agents


            # Determine targeting status
            if related_sigs:
                targeting = "ACTIVE"
            elif agent_has_alerts:
                targeting = "POTENTIAL"
            else:
                targeting = "NONE"

            enriched_vulns.append({
                "cve_id": cve_id,
                "severity": severity,
                "package": package,
                "agent_id": agent_id,
                "targeting_status": targeting,
                "related_signatures": related_sigs[:3],
                "agent_has_alerts": agent_has_alerts,
                "cvss_score": self._extract_cvss_score(v),
            })

        # Sort: ACTIVE first, then POTENTIAL, then NONE; within group by severity
        status_order = {"ACTIVE": 0, "POTENTIAL": 1, "NONE": 2}
        enriched_vulns.sort(key=lambda x: (status_order.get(x["targeting_status"], 3), self._severity_rank(x["severity"])))

        return CorrelationResult(
            correlated_data=enriched_vulns[:30],
            summary={
                "total_vulnerabilities_analyzed": len(vulns),
                "actively_targeted": len([v for v in enriched_vulns if v["targeting_status"] == "ACTIVE"]),
                "potentially_targeted": len([v for v in enriched_vulns if v["targeting_status"] == "POTENTIAL"]),
                "not_targeted": len([v for v in enriched_vulns if v["targeting_status"] == "NONE"]),
                "total_suricata_signatures": len(sig_keywords),
            },
            correlation_type="vulnerability_exploit_correlation",
            primary_tool="get_wazuh_vulnerabilities",
            secondary_tools=["get_suricata_alerts", "get_wazuh_alerts"]
        )

    @register_strategy("detection_coverage_gap")
    def detection_coverage_gap(self, primary: Dict[str, Any], secondary: List[Dict[str, Any]], context: Dict[str, Any]) -> CorrelationResult:
        """MITRE ATT&CK coverage gap analysis across Wazuh + Suricata."""
        FULL_FRAMEWORK = {
            "TA0043": "Reconnaissance", "TA0042": "Resource Development",
            "TA0001": "Initial Access", "TA0002": "Execution",
            "TA0003": "Persistence", "TA0004": "Privilege Escalation",
            "TA0005": "Defense Evasion", "TA0006": "Credential Access",
            "TA0007": "Discovery", "TA0008": "Lateral Movement",
            "TA0009": "Collection", "TA0011": "Command and Control",
            "TA0010": "Exfiltration", "TA0040": "Impact",
        }

        # Primary: Wazuh MITRE coverage
        wazuh_mitre = self._normalize_payload(primary)

        # Secondary[0]: Suricata MITRE mapping
        suricata_mitre = {}
        if len(secondary) > 0:
            suricata_mitre = self._normalize_payload(secondary[0])

        # Collect Wazuh tactics + techniques
        wazuh_tactics = set()
        wazuh_techniques = set()
        for t in wazuh_mitre.get("tactics", []):
            name = t.get("name", "") or t.get("tactic", "")
            if name:
                wazuh_tactics.add(name)
        for t in wazuh_mitre.get("techniques", []):
            name = t.get("name", "") or t.get("technique", "") or t.get("id", "")
            if name:
                wazuh_techniques.add(name)
        # Also check affected_items for Wazuh format
        wazuh_items = self._extract_items(wazuh_mitre)
        for alert in wazuh_items:
            mitre = (alert.get("rule") or {}).get("mitre", {})
            for tactic in mitre.get("tactic", []):
                wazuh_tactics.add(tactic)
            for tech in mitre.get("technique", []):
                wazuh_techniques.add(tech)

        # Collect Suricata tactics + techniques
        suricata_tactics = set()
        suricata_techniques = set()
        for t in suricata_mitre.get("tactics", []):
            name = t.get("tactic_name", "") or t.get("name", "")
            if name:
                suricata_tactics.add(name)
        for t in suricata_mitre.get("techniques", []):
            name = t.get("technique_name", "") or t.get("name", "")
            if name:
                suricata_techniques.add(name)

        # Build coverage matrix
        coverage_matrix = []
        all_covered = wazuh_tactics | suricata_tactics
        for tactic_id, tactic_name in FULL_FRAMEWORK.items():
            # Match by name (case-insensitive)
            wazuh_has = any(tactic_name.lower() == t.lower() for t in wazuh_tactics)
            suricata_has = any(tactic_name.lower() == t.lower() for t in suricata_tactics)

            if wazuh_has and suricata_has:
                status = "COVERED (Both)"
            elif wazuh_has:
                status = "COVERED (Wazuh)"
            elif suricata_has:
                status = "COVERED (Suricata)"
            else:
                status = "GAP"

            coverage_matrix.append({
                "tactic_id": tactic_id,
                "tactic_name": tactic_name,
                "wazuh_covered": wazuh_has,
                "suricata_covered": suricata_has,
                "status": status,
            })

        covered_count = sum(1 for c in coverage_matrix if c["status"] != "GAP")
        gap_count = len(FULL_FRAMEWORK) - covered_count

        return CorrelationResult(
            correlated_data=[{
                "coverage_matrix": coverage_matrix,
                "wazuh_techniques": sorted(wazuh_techniques),
                "suricata_techniques": sorted(suricata_techniques),
                "combined_techniques": sorted(wazuh_techniques | suricata_techniques),
                "gaps": [c for c in coverage_matrix if c["status"] == "GAP"],
            }],
            summary={
                "tactics_covered": covered_count,
                "tactics_total": len(FULL_FRAMEWORK),
                "coverage_pct": round(covered_count / len(FULL_FRAMEWORK) * 100, 1),
                "gap_count": gap_count,
                "wazuh_unique_techniques": len(wazuh_techniques),
                "suricata_unique_techniques": len(suricata_techniques),
                "combined_unique_techniques": len(wazuh_techniques | suricata_techniques),
            },
            correlation_type="detection_coverage_gap",
            primary_tool="get_mitre_coverage",
            secondary_tools=["get_suricata_mitre_mapping"]
        )

    # ------ Tier 3: Contextual Enrichment ------

    @register_strategy("fim_alert_correlation")
    def fim_alert_correlation(self, primary: Dict[str, Any], secondary: List[Dict[str, Any]], context: Dict[str, Any]) -> CorrelationResult:
        """Correlate file integrity changes with temporally close alerts."""
        # Primary: FIM events
        fim_data = self._normalize_payload(primary)
        fim_events = self._extract_items(fim_data)

        # Secondary[0]: Wazuh alerts, [1]: Agents
        wazuh_alerts = []
        agents = []
        if len(secondary) > 0:
            w0 = self._normalize_payload(secondary[0])
            wazuh_alerts = self._extract_items(w0)
        if len(secondary) > 1:
            a0 = self._normalize_payload(secondary[1])
            agents = self._extract_items(a0)

        # Build agent lookup
        agent_map = {}
        for a in agents:
            aid = self._normalize_agent_id(a.get("id"))
            if aid != "0":
                agent_map[aid] = self._compact_agent(a)

        # Build alerts by agent
        alerts_by_agent = {}
        for alert in wazuh_alerts:
            aid = self._normalize_agent_id((alert.get("agent") or {}).get("id"))
            alerts_by_agent.setdefault(aid, []).append(alert)

        # Correlate FIM events with alerts
        correlated = []
        for fim in fim_events[:50]:
            syscheck = fim.get("syscheck", {})
            fim_path = syscheck.get("path", "N/A")
            fim_event = syscheck.get("event", "N/A")
            fim_agent_id = self._normalize_agent_id((fim.get("agent") or {}).get("id"))
            fim_ts = fim.get("timestamp", "")

            # Find alerts from same agent
            agent_alerts = alerts_by_agent.get(fim_agent_id, [])
            related_alerts = []
            for alert in agent_alerts[:50]:
                alert_rule = (alert.get("rule") or {})
                related_alerts.append({
                    "rule_id": alert_rule.get("id"),
                    "description": alert_rule.get("description", "N/A"),
                    "level": alert_rule.get("level"),
                    "timestamp": alert.get("timestamp"),
                })

            # Risk assessment
            is_binary = any(fim_path.startswith(p) for p in ["/usr/bin", "/usr/sbin", "/bin", "/sbin", "/usr/lib"])
            has_high_alerts = any(self._safe_int(a.get("level", 0)) >= 10 for a in related_alerts)
            risk = "HIGH" if (is_binary and has_high_alerts) else "MEDIUM" if (is_binary or has_high_alerts) else "LOW"

            correlated.append({
                "file_path": fim_path,
                "change_type": fim_event,
                "agent_id": fim_agent_id,
                "agent_name": agent_map.get(fim_agent_id, {}).get("name", "N/A"),
                "timestamp": fim_ts,
                "related_alerts_count": len(related_alerts),
                "related_alerts": related_alerts[:5],
                "risk_level": risk,
                "is_system_binary": is_binary,
            })

        correlated.sort(key=lambda x: {"HIGH": 0, "MEDIUM": 1, "LOW": 2}.get(x["risk_level"], 3))

        return CorrelationResult(
            correlated_data=correlated,
            summary={
                "total_fim_events": len(fim_events),
                "events_with_alerts": len([c for c in correlated if c["related_alerts_count"] > 0]),
                "high_risk_changes": len([c for c in correlated if c["risk_level"] == "HIGH"]),
                "medium_risk_changes": len([c for c in correlated if c["risk_level"] == "MEDIUM"]),
                "system_binary_changes": len([c for c in correlated if c["is_system_binary"]]),
            },
            correlation_type="fim_alert_correlation",
            primary_tool="get_fim_events",
            secondary_tools=["get_wazuh_alerts", "get_wazuh_agents"]
        )

    @register_strategy("port_exposure_risk")
    def port_exposure_risk(self, primary: Dict[str, Any], secondary: List[Dict[str, Any]], context: Dict[str, Any]) -> CorrelationResult:
        """Assess risk of open ports based on IDS targeting and known vulnerabilities."""
        # Primary: Agent ports
        port_data = self._normalize_payload(primary)
        ports = self._extract_items(port_data)

        # Secondary[0]: Suricata alerts, [1]: Vulnerabilities
        suricata_alerts = []
        vulns = []
        if len(secondary) > 0:
            s0 = self._normalize_payload(secondary[0])
            suricata_alerts = self._extract_items(s0)
        if len(secondary) > 1:
            v0 = self._normalize_payload(secondary[1])
            vulns = self._extract_items(v0)

        # Build port → IDS alert count map
        targeted_ports = {}
        for alert in suricata_alerts:
            dest_port = alert.get("dest_port")
            if dest_port:
                dp = self._safe_int(dest_port)
                targeted_ports[dp] = targeted_ports.get(dp, 0) + 1

        # Build package → vuln map
        vuln_packages = {}
        for v in vulns:
            pkg = (v.get("package") or {}).get("name", "").lower()
            if pkg:
                vuln_packages.setdefault(pkg, []).append({
                    "cve": v.get("id") or v.get("cve") or "N/A",
                    "severity": v.get("severity", "low"),
                })

        # High-risk port definitions
        HIGH_RISK_PORTS = {21: "FTP", 22: "SSH", 23: "Telnet", 25: "SMTP", 80: "HTTP",
                          110: "POP3", 135: "RPC", 139: "NetBIOS", 143: "IMAP",
                          443: "HTTPS", 445: "SMB", 1433: "MSSQL", 1521: "Oracle",
                          3306: "MySQL", 3389: "RDP", 5432: "PostgreSQL",
                          5900: "VNC", 6379: "Redis", 8080: "HTTP-Alt",
                          8443: "HTTPS-Alt", 9200: "Elasticsearch", 27017: "MongoDB"}

        # Assess each port
        port_risks = []
        for p in ports:
            port_num = self._safe_int((p.get("local") or {}).get("port", 0))
            protocol = p.get("protocol", "tcp")
            process_name = (p.get("process") or {}).get("name", "N/A")
            state = p.get("state", "N/A")

            ids_hits = targeted_ports.get(port_num, 0)
            service_name = HIGH_RISK_PORTS.get(port_num, "")
            process_vulns = vuln_packages.get(process_name.lower(), [])

            # Risk scoring
            risk_score = 0
            risk_factors = []
            if ids_hits > 0:
                risk_score += min(ids_hits * 2, 30)
                risk_factors.append(f"{ids_hits} IDS alerts targeting this port")
            if service_name:
                risk_score += 10
                risk_factors.append(f"Known service: {service_name}")
            if port_num in (23, 21, 445, 3389, 5900, 6379, 27017):
                risk_score += 15
                risk_factors.append("High-risk protocol")
            if process_vulns:
                risk_score += len(process_vulns) * 5
                risk_factors.append(f"{len(process_vulns)} known CVEs for {process_name}")

            risk_level = "CRITICAL" if risk_score >= 40 else "HIGH" if risk_score >= 20 else "MEDIUM" if risk_score >= 10 else "LOW"

            port_risks.append({
                "port": port_num,
                "protocol": protocol,
                "service": service_name or process_name,
                "state": state,
                "process": process_name,
                "ids_alerts": ids_hits,
                "related_cves": [v["cve"] for v in process_vulns[:3]],
                "risk_level": risk_level,
                "risk_score": risk_score,
                "risk_factors": risk_factors,
            })

        port_risks.sort(key=lambda x: x["risk_score"], reverse=True)

        return CorrelationResult(
            correlated_data=port_risks[:30],
            summary={
                "total_open_ports": len(ports),
                "critical_risk": len([p for p in port_risks if p["risk_level"] == "CRITICAL"]),
                "high_risk": len([p for p in port_risks if p["risk_level"] == "HIGH"]),
                "ports_with_ids_hits": len([p for p in port_risks if p["ids_alerts"] > 0]),
                "ports_with_cves": len([p for p in port_risks if p["related_cves"]]),
            },
            correlation_type="port_exposure_risk",
            primary_tool="get_agent_ports",
            secondary_tools=["get_suricata_alerts", "get_wazuh_vulnerabilities"]
        )

    @register_strategy("top_risk_agents_composite")
    def top_risk_agents_composite(self, primary: Dict[str, Any], secondary: List[Dict[str, Any]], context: Dict[str, Any]) -> CorrelationResult:
        """Composite risk ranking of agents across all data sources."""
        # Primary: Agents
        agent_data = self._normalize_payload(primary)
        agents = self._extract_items(agent_data)

        # Secondary[0]: Vulnerabilities, [1]: Wazuh alerts, [2]: Suricata alerts
        vulns = []
        wazuh_alerts = []
        suricata_alerts = []
        if len(secondary) > 0:
            v0 = self._normalize_payload(secondary[0])
            vulns = self._extract_items(v0)
        if len(secondary) > 1:
            w0 = self._normalize_payload(secondary[1])
            wazuh_alerts = self._extract_items(w0)
        if len(secondary) > 2:
            s0 = self._normalize_payload(secondary[2])
            suricata_alerts = self._extract_items(s0)

        # Build vulns by agent
        vulns_by_agent = {}
        for v in vulns:
            aid = self._normalize_agent_id((v.get("agent") or {}).get("id"))
            vulns_by_agent.setdefault(aid, []).append(v)

        # Build alerts by agent
        alerts_by_agent = {}
        for a in wazuh_alerts:
            aid = self._normalize_agent_id((a.get("agent") or {}).get("id"))
            alerts_by_agent.setdefault(aid, []).append(a)

        # Build Suricata alerts by IP
        suricata_by_ip = {}
        for a in suricata_alerts:
            for ip_key in ["src_ip", "dest_ip"]:
                ip = a.get(ip_key, "")
                if ip:
                    suricata_by_ip.setdefault(ip, []).append(a)

        # Score each agent
        ranked = []
        for agent in agents:
            if agent.get("id") == "000":
                continue
            aid = self._normalize_agent_id(agent.get("id"))
            agent_ip = agent.get("ip", "") or agent.get("registerIP", "")

            agent_vulns = vulns_by_agent.get(aid, [])
            agent_alerts = alerts_by_agent.get(aid, [])
            agent_suricata = suricata_by_ip.get(agent_ip, [])

            # Composite risk score
            vuln_summary = self._summarize_vulnerabilities(agent_vulns)
            vuln_score = vuln_summary["critical"] * 5 + vuln_summary["high"] * 3 + vuln_summary["medium"] * 1

            alert_score = 0
            for al in agent_alerts:
                level = self._safe_int((al.get("rule") or {}).get("level", 0))
                if level >= 12:
                    alert_score += 5
                elif level >= 7:
                    alert_score += 3
                else:
                    alert_score += 1

            suricata_score = len(agent_suricata) * 2

            health_penalty = 10 if str(agent.get("status", "")).lower() == "disconnected" else 0

            total_score = vuln_score + alert_score + suricata_score + health_penalty

            # Top risk factor
            factors = []
            if vuln_summary["critical"] > 0:
                factors.append(f"{vuln_summary['critical']} critical CVEs")
            if alert_score > 10:
                factors.append(f"{len(agent_alerts)} security alerts")
            if suricata_score > 0:
                factors.append(f"{len(agent_suricata)} IDS detections")
            if health_penalty > 0:
                factors.append("Agent disconnected")

            ranked.append({
                "agent_id": agent.get("id"),
                "agent_name": agent.get("name", "N/A"),
                "ip": agent_ip,
                "status": agent.get("status", "unknown"),
                "risk_score": total_score,
                "vuln_count": vuln_summary["total"],
                "critical_vulns": vuln_summary["critical"],
                "alert_count": len(agent_alerts),
                "ids_hits": len(agent_suricata),
                "top_risk_factors": factors[:3],
            })

        ranked.sort(key=lambda x: x["risk_score"], reverse=True)

        # Assign ranks
        for i, r in enumerate(ranked):
            r["rank"] = i + 1

        return CorrelationResult(
            correlated_data=ranked[:20],
            summary={
                "total_agents_analyzed": len(ranked),
                "agents_with_critical_risk": len([r for r in ranked if r["risk_score"] >= 40]),
                "agents_with_high_risk": len([r for r in ranked if 20 <= r["risk_score"] < 40]),
                "highest_risk_agent": ranked[0]["agent_name"] if ranked else "N/A",
                "highest_risk_score": ranked[0]["risk_score"] if ranked else 0,
            },
            correlation_type="top_risk_agents_composite",
            primary_tool="get_wazuh_agents",
            secondary_tools=["get_wazuh_vulnerabilities", "get_wazuh_alerts", "get_suricata_alerts"]
        )

    @register_strategy("alert_context_enrichment")
    def alert_context_enrichment(self, primary: Dict[str, Any], secondary: List[Dict[str, Any]], context: Dict[str, Any]) -> CorrelationResult:
        """Enrich alerts with full context: agent profile, vulnerabilities, IDS detections."""
        # Primary: Wazuh alerts
        alert_data = self._normalize_payload(primary)
        alerts = self._extract_items(alert_data)

        # Secondary[0]: Agents, [1]: Vulnerabilities, [2]: Suricata alerts
        agents = []
        vulns = []
        suricata_alerts = []
        if len(secondary) > 0:
            a0 = self._normalize_payload(secondary[0])
            agents = self._extract_items(a0)
        if len(secondary) > 1:
            v0 = self._normalize_payload(secondary[1])
            vulns = self._extract_items(v0)
        if len(secondary) > 2:
            s0 = self._normalize_payload(secondary[2])
            suricata_alerts = self._extract_items(s0)

        # Build agent lookup
        agent_map = {}
        for a in agents:
            aid = self._normalize_agent_id(a.get("id"))
            if aid != "0":
                agent_map[aid] = self._compact_agent(a)

        # Build vuln count by agent
        vuln_by_agent = {}
        for v in vulns:
            aid = self._normalize_agent_id((v.get("agent") or {}).get("id"))
            vuln_by_agent.setdefault(aid, {"total": 0, "critical": 0, "high": 0})
            vuln_by_agent[aid]["total"] += 1
            sev = str(v.get("severity", "")).lower()
            if sev == "critical":
                vuln_by_agent[aid]["critical"] += 1
            elif sev == "high":
                vuln_by_agent[aid]["high"] += 1

        # Build Suricata alert summary by IP
        suricata_by_ip = {}
        for sa in suricata_alerts:
            for ip_key in ["src_ip", "dest_ip"]:
                ip = sa.get(ip_key, "")
                if ip:
                    suricata_by_ip.setdefault(ip, []).append(
                        sa.get("alert", {}).get("signature", "") or sa.get("signature", "N/A")
                    )

        # Enrich each alert
        enriched = []
        for alert in alerts[:20]:
            rule = alert.get("rule", {})
            aid = self._normalize_agent_id((alert.get("agent") or {}).get("id"))
            agent_info = agent_map.get(aid, {})
            agent_ip = agent_info.get("ip", "")

            # MITRE context
            mitre = rule.get("mitre", {})
            mitre_tactics = mitre.get("tactic", [])
            mitre_techniques = mitre.get("technique", [])

            # Related IDS detections for this agent's IP
            related_ids = []
            if agent_ip:
                sigs = suricata_by_ip.get(agent_ip, [])
                # Deduplicate
                seen = set()
                for s in sigs:
                    if s not in seen:
                        related_ids.append(s)
                        seen.add(s)

            enriched.append({
                "alert": {
                    "rule_id": rule.get("id"),
                    "description": rule.get("description", "N/A"),
                    "level": rule.get("level"),
                    "groups": rule.get("groups", []),
                    "timestamp": alert.get("timestamp"),
                },
                "agent": agent_info or {"name": "N/A", "status": "unknown"},
                "vulnerability_status": vuln_by_agent.get(aid, {"total": 0, "critical": 0, "high": 0}),
                "mitre_context": {
                    "tactics": mitre_tactics,
                    "techniques": mitre_techniques,
                } if mitre_tactics or mitre_techniques else None,
                "related_ids_detections": related_ids[:5],
            })

        return CorrelationResult(
            correlated_data=enriched,
            summary={
                "total_alerts_enriched": len(enriched),
                "alerts_with_mitre": len([e for e in enriched if e["mitre_context"]]),
                "alerts_with_ids_context": len([e for e in enriched if e["related_ids_detections"]]),
                "agents_involved": len(set(self._normalize_agent_id((a.get("agent") or {}).get("id")) for a in alerts[:20])),
            },
            correlation_type="alert_context_enrichment",
            primary_tool="get_wazuh_alerts",
            secondary_tools=["get_wazuh_agents", "get_wazuh_vulnerabilities", "get_suricata_alerts"]
        )


    # ==================================================================
    # PALLAS 3.5: TEMPORAL ATTACK SEQUENCE
    # ==================================================================

    # Attack phase classification keywords
    _ATTACK_PHASES = {
        "RECON": ["scan", "enumerat", "discover", "probe", "nmap", "masscan", "reconnaissance", "sweep", "portscan"],
        "ACCESS": ["login", "logon", "authenticat", "brute", "credential", "password", "ssh", "rdp", "failed login", "successful login"],
        "EXECUTION": ["powershell", "cmd.exe", "wscript", "cscript", "mshta", "rundll32", "regsvr32", "execute", "spawn", "process creat"],
        "PERSISTENCE": ["scheduled task", "service creat", "registry", "startup", "autorun", "cron", "systemd", "persist"],
        "PRIV_ESC": ["privilege", "escalat", "token", "impersonat", "sudo", "setuid", "SeDebug", "4672", "4673", "elevat"],
        "LATERAL": ["lateral", "psexec", "wmi", "smb", "remote exec", "winrm", "pass.the.hash", "movement", "pivot"],
        "C2": ["c2", "c&c", "command.and.control", "beacon", "callback", "cobalt", "empire", "metasploit", "reverse.shell"],
        "EXFIL": ["exfil", "upload", "transfer", "dns tunnel", "data.leak", "staging", "compress", "archive"],
    }

    _PHASE_ORDER = ["RECON", "ACCESS", "EXECUTION", "PERSISTENCE", "PRIV_ESC", "LATERAL", "C2", "EXFIL"]

    def _classify_phase(self, event_text: str) -> str:
        """Classify an event into an attack phase based on keywords."""
        text_lower = event_text.lower()
        for phase, keywords in self._ATTACK_PHASES.items():
            for kw in keywords:
                if kw in text_lower:
                    return phase
        return "UNKNOWN"

    def _extract_event_timestamp(self, event: dict) -> Optional[str]:
        """Extract timestamp from various event formats."""
        for field in ["timestamp", "@timestamp", "data.timestamp", "rule.timestamp"]:
            val = event.get(field)
            if val:
                return str(val)
        # Nested access for data.timestamp
        data = event.get("data", {})
        if isinstance(data, dict) and data.get("timestamp"):
            return str(data["timestamp"])
        return None

    def _extract_event_entity(self, event: dict) -> str:
        """Extract the primary entity (agent ID, IP, user) from an event."""
        # Try agent ID first
        agent = event.get("agent", {})
        if isinstance(agent, dict) and agent.get("id"):
            return f"agent:{agent['id']}"
        # Try source IP
        for field in ["src_ip", "srcip", "data.srcip", "data.src_ip"]:
            val = event.get(field)
            if val:
                return f"ip:{val}"
        data = event.get("data", {})
        if isinstance(data, dict):
            for f in ["srcip", "src_ip"]:
                val = data.get(f)
                if val:
                    return f"ip:{val}"
        # Try user
        for field in ["data.dstuser", "data.srcuser"]:
            val = event.get(field)
            if val:
                return f"user:{val}"
        if isinstance(data, dict):
            for f in ["dstuser", "srcuser"]:
                val = data.get(f)
                if val:
                    return f"user:{val}"
        return "unknown"

    def _extract_event_severity(self, event: dict) -> int:
        """Extract numeric severity from event (higher = worse)."""
        # Wazuh rule level
        rule = event.get("rule", {})
        if isinstance(rule, dict):
            level = rule.get("level")
            if level is not None:
                try:
                    return int(level)
                except (ValueError, TypeError):
                    pass
        # Suricata severity
        alert = event.get("alert", {})
        if isinstance(alert, dict):
            sev = alert.get("severity")
            if sev is not None:
                try:
                    # Suricata: 1=highest, invert to make higher=worse
                    return max(1, 15 - int(sev) * 3)
                except (ValueError, TypeError):
                    pass
        return 5  # default medium

    def _build_event_text(self, event: dict) -> str:
        """Build searchable text from event for phase classification."""
        parts = []
        rule = event.get("rule", {})
        if isinstance(rule, dict):
            parts.append(str(rule.get("description", "")))
            parts.extend(str(g) for g in (rule.get("groups") or []))
        alert = event.get("alert") or {}
        if isinstance(alert, dict):
            parts.append(str(alert.get("signature", "")))
            parts.append(str(alert.get("category", "")))
            meta = alert.get("metadata") or {}
            if isinstance(meta, dict):
                parts.extend(str(v) for v in (meta.get("mitre_tactic_name") or []) if v)
                parts.extend(str(v) for v in (meta.get("mitre_technique_name") or []) if v)
        data = event.get("data", {})
        if isinstance(data, dict):
            parts.append(str(data.get("title", "")))
            parts.append(str(data.get("type", "")))
        return " ".join(parts)

    @register_strategy("temporal_attack_sequence")
    def temporal_attack_sequence(self, primary: Dict[str, Any], secondary: List[Dict[str, Any]], context: Dict[str, Any]) -> CorrelationResult:
        """
        Pallas 3.5: Temporal attack sequence detection.
        Merges events from Wazuh + Suricata, groups by entity, sorts by timestamp,
        classifies into MITRE-aligned attack phases, and detects multi-phase sequences.
        """
        # 1. Merge all events into unified timeline
        wazuh_events = self._items(primary)
        all_events = []

        for ev in wazuh_events:
            ts = self._extract_event_timestamp(ev)
            text = self._build_event_text(ev)
            phase = self._classify_phase(text)
            entity = self._extract_event_entity(ev)
            severity = self._extract_event_severity(ev)
            rule = ev.get("rule", {})
            desc = rule.get("description", "Unknown event") if isinstance(rule, dict) else "Unknown event"
            all_events.append({
                "timestamp": ts or "1970-01-01T00:00:00",
                "entity": entity,
                "phase": phase,
                "severity": severity,
                "source": "Wazuh",
                "description": desc[:120],
                "rule_id": rule.get("id") if isinstance(rule, dict) else None,
                "groups": rule.get("groups", []) if isinstance(rule, dict) else [],
                "raw": ev,
            })

        # Add Suricata events from secondaries
        for sec in secondary:
            suricata_items = self._items(sec)
            for ev in suricata_items:
                ts = self._extract_event_timestamp(ev) or ev.get("timestamp", "1970-01-01T00:00:00")
                text = self._build_event_text(ev)
                phase = self._classify_phase(text)
                severity = self._extract_event_severity(ev)
                alert_info = ev.get("alert", {})
                desc = alert_info.get("signature", "IDS Detection") if isinstance(alert_info, dict) else "IDS Detection"
                src_ip = ev.get("src_ip", ev.get("srcip", "N/A"))
                dest_ip = ev.get("dest_ip", ev.get("destip", "N/A"))
                entity_val = f"ip:{src_ip}" if src_ip != "N/A" else f"ip:{dest_ip}"
                all_events.append({
                    "timestamp": str(ts),
                    "entity": entity_val,
                    "phase": phase,
                    "severity": severity,
                    "source": "Suricata",
                    "description": desc[:120],
                    "src_ip": src_ip,
                    "dest_ip": dest_ip,
                    "raw": ev,
                })

        # Build agent lookup from secondary agent data
        agent_map = {}
        for sec in secondary:
            agents = self._items(sec)
            for a in agents:
                if isinstance(a, dict) and a.get("id") and a.get("name"):
                    agent_map[f"agent:{a['id']}"] = a.get("name", "Unknown")
                    ip = a.get("ip")
                    if ip:
                        agent_map[f"ip:{ip}"] = a.get("name", "Unknown")

        # 2. Sort all events by timestamp
        all_events.sort(key=lambda e: e["timestamp"])

        # 3. Group by entity
        entity_events = {}
        for ev in all_events:
            ent = ev["entity"]
            entity_events.setdefault(ent, []).append(ev)

        # 4. Detect multi-phase sequences
        sequences = []
        time_window_hours = context.get("time_window_hours", 24)

        for entity, events in entity_events.items():
            if len(events) < 2:
                continue

            # Find distinct phases
            phases_seen = []
            for ev in events:
                if ev["phase"] != "UNKNOWN" and (not phases_seen or phases_seen[-1] != ev["phase"]):
                    phases_seen.append(ev["phase"])

            # Need at least 2 distinct phases for a sequence
            unique_phases = list(dict.fromkeys(phases_seen))
            if len(unique_phases) < 2:
                continue

            # Calculate time span
            first_ts = events[0]["timestamp"]
            last_ts = events[-1]["timestamp"]

            # Check phase ordering (are they progressing through kill chain?)
            phase_indices = [self._PHASE_ORDER.index(p) if p in self._PHASE_ORDER else -1 for p in unique_phases]
            valid_indices = [i for i in phase_indices if i >= 0]
            is_progressive = len(valid_indices) >= 2 and valid_indices == sorted(valid_indices)

            # Calculate risk score
            max_severity = max(ev["severity"] for ev in events)
            source_types = set(ev["source"] for ev in events)
            cross_source = len(source_types) > 1

            risk_score = (
                len(unique_phases) * 15 +
                max_severity * 3 +
                (20 if cross_source else 0) +
                (15 if is_progressive else 0) +
                min(len(events), 20) * 2
            )
            risk_score = min(100, risk_score)

            if risk_score < 75:
                risk_level = "HIGH" if risk_score >= 50 else "MEDIUM"
            else:
                risk_level = "CRITICAL"

            entity_name = agent_map.get(entity, entity)

            sequences.append({
                "entity": entity,
                "entity_name": entity_name,
                "risk_score": risk_score,
                "risk_level": risk_level,
                "phases": unique_phases,
                "phase_count": len(unique_phases),
                "event_count": len(events),
                "first_timestamp": first_ts,
                "last_timestamp": last_ts,
                "cross_source": cross_source,
                "is_progressive": is_progressive,
                "max_severity": max_severity,
                "events": events[:30],  # Limit events per sequence for output
            })

        # 5. Sort by risk score descending
        sequences.sort(key=lambda s: s["risk_score"], reverse=True)

        return CorrelationResult(
            correlated_data=sequences[:20],
            summary={
                "total_sequences": len(sequences),
                "critical_sequences": len([s for s in sequences if s["risk_level"] == "CRITICAL"]),
                "high_sequences": len([s for s in sequences if s["risk_level"] == "HIGH"]),
                "entities_involved": len(entity_events),
                "total_events_analyzed": len(all_events),
                "wazuh_events": len(wazuh_events),
                "suricata_events": len(all_events) - len(wazuh_events),
                "cross_source_sequences": len([s for s in sequences if s["cross_source"]]),
                "progressive_sequences": len([s for s in sequences if s["is_progressive"]]),
            },
            correlation_type="temporal_attack_sequence",
            primary_tool="search_security_events",
            secondary_tools=["get_wazuh_agents", "get_suricata_alerts"]
        )

    # ==================================================================
    # PALLAS 3.5: MULTI-ASSET CAMPAIGN DETECTION
    # ==================================================================

    @register_strategy("multi_asset_campaign_detection")
    def multi_asset_campaign_detection(self, primary: Dict[str, Any], secondary: List[Dict[str, Any]], context: Dict[str, Any]) -> CorrelationResult:
        """
        Pallas 3.5: Multi-asset campaign detection.
        Primary = Wazuh alerts, Secondary = [Suricata alerts, agents].
        Detects coordinated campaigns, builds attack graphs, identifies shadow IT,
        and flags anomalous encryption patterns.
        """
        wazuh_alerts = self._items(primary)
        suricata_data = self._items(secondary[0]) if len(secondary) > 0 else []
        agents = self._items(secondary[1]) if len(secondary) > 1 else []

        # Build IP → agent map
        ip_to_agent = {}
        agent_id_to_name = {}
        known_ips = set()
        for a in agents:
            aid = str(a.get("id", ""))
            if aid == "000":
                continue
            ip = a.get("ip")
            name = a.get("name", "Unknown")
            agent_id_to_name[aid] = name
            if ip:
                ip_to_agent[ip] = {"id": aid, "name": name}
                known_ips.add(ip)

        # --- Campaign Detection ---
        # Group alerts by shared indicators (MITRE technique, signature, src_ip)
        indicator_agents = {}  # indicator -> set of agent IDs

        for wa in wazuh_alerts:
            agent_info = wa.get("agent", {})
            aid = str(agent_info.get("id", "")) if isinstance(agent_info, dict) else ""
            if not aid or aid == "000":
                continue

            rule = wa.get("rule", {})
            if not isinstance(rule, dict):
                continue

            # MITRE techniques as indicators
            mitre = rule.get("mitre", {})
            if isinstance(mitre, dict):
                for tech in mitre.get("technique", []):
                    if isinstance(tech, str):
                        indicator_agents.setdefault(f"mitre:{tech}", set()).add(aid)

            # Rule groups as indicators
            for g in rule.get("groups", []):
                if isinstance(g, str) and g not in ("syslog", "local", "wazuh"):
                    indicator_agents.setdefault(f"group:{g}", set()).add(aid)

        # Add Suricata indicators
        for sa in suricata_data:
            alert_info = sa.get("alert", {})
            sig = alert_info.get("signature", "") if isinstance(alert_info, dict) else ""
            src_ip = sa.get("src_ip", "")
            dest_ip = sa.get("dest_ip", "")

            target_agent = ip_to_agent.get(dest_ip) or ip_to_agent.get(src_ip)
            if target_agent and sig:
                indicator_agents.setdefault(f"ids_sig:{sig[:60]}", set()).add(target_agent["id"])
            if src_ip:
                indicator_agents.setdefault(f"src_ip:{src_ip}", set()).add(target_agent["id"] if target_agent else f"ext:{src_ip}")

        # Identify campaigns: same indicator on 3+ agents
        campaigns = []
        for indicator, agent_set in indicator_agents.items():
            real_agents = {a for a in agent_set if not a.startswith("ext:")}
            if len(real_agents) >= 2:  # 2+ agents = potential campaign (lower threshold for smaller environments)
                campaigns.append({
                    "indicator": indicator,
                    "indicator_type": indicator.split(":")[0],
                    "indicator_value": ":".join(indicator.split(":")[1:]),
                    "agents_affected": len(real_agents),
                    "agent_ids": list(real_agents)[:10],
                    "agent_names": [agent_id_to_name.get(a, a) for a in list(real_agents)[:10]],
                })

        campaigns.sort(key=lambda c: c["agents_affected"], reverse=True)

        # --- Attack Graph ---
        # Build edges between agents based on network connections
        graph_edges = []
        for sa in suricata_data:
            src_ip = sa.get("src_ip", "")
            dest_ip = sa.get("dest_ip", "")
            src_agent = ip_to_agent.get(src_ip)
            dest_agent = ip_to_agent.get(dest_ip)

            if src_agent and dest_agent and src_agent["id"] != dest_agent["id"]:
                alert_info = sa.get("alert", {})
                sig = alert_info.get("signature", "traffic") if isinstance(alert_info, dict) else "traffic"
                graph_edges.append({
                    "source": src_agent["name"],
                    "source_id": src_agent["id"],
                    "target": dest_agent["name"],
                    "target_id": dest_agent["id"],
                    "alert_type": sig[:50],
                    "src_ip": src_ip,
                    "dest_ip": dest_ip,
                })

        # Deduplicate edges
        seen_edges = set()
        unique_edges = []
        for e in graph_edges:
            key = f"{e['source_id']}->{e['target_id']}:{e['alert_type']}"
            if key not in seen_edges:
                seen_edges.add(key)
                unique_edges.append(e)

        # --- Shadow IT Detection ---
        # IPs in Suricata that are NOT in known agents
        internal_prefixes = ("10.", "172.16.", "172.17.", "172.18.", "172.19.",
                             "172.20.", "172.21.", "172.22.", "172.23.", "172.24.",
                             "172.25.", "172.26.", "172.27.", "172.28.", "172.29.",
                             "172.30.", "172.31.", "192.168.")
        unknown_internal_ips = {}
        for sa in suricata_data:
            for ip_field in ["src_ip", "dest_ip"]:
                ip = sa.get(ip_field, "")
                if any(ip.startswith(pfx) for pfx in internal_prefixes) and ip not in known_ips:
                    entry = unknown_internal_ips.setdefault(ip, {"ip": ip, "connections": 0, "external_targets": set()})
                    entry["connections"] += 1
                    other_ip = sa.get("dest_ip" if ip_field == "src_ip" else "src_ip", "")
                    if not any(other_ip.startswith(pfx) for pfx in internal_prefixes):
                        entry["external_targets"].add(other_ip)

        shadow_it = []
        for ip, info in unknown_internal_ips.items():
            if info["connections"] >= 3:  # At least 3 connections
                shadow_it.append({
                    "ip": ip,
                    "connections": info["connections"],
                    "external_targets": len(info["external_targets"]),
                    "risk": "HIGH" if info["external_targets"] else "MEDIUM",
                })
        shadow_it.sort(key=lambda s: s["connections"], reverse=True)

        # --- Anomalous Encryption ---
        encryption_anomalies = []
        for sa in suricata_data:
            tls = sa.get("tls", {})
            if not isinstance(tls, dict) or not tls:
                continue
            version = tls.get("version", "")
            ja3_hash = tls.get("ja3", {}).get("hash", "") if isinstance(tls.get("ja3"), dict) else ""

            anomaly_reasons = []
            if version and version in ("TLSv1.0", "TLSv1.1", "SSLv3"):
                anomaly_reasons.append(f"Legacy protocol: {version}")
            if not version and tls:
                anomaly_reasons.append("Missing TLS version")

            if anomaly_reasons:
                encryption_anomalies.append({
                    "src_ip": sa.get("src_ip", "?"),
                    "dest_ip": sa.get("dest_ip", "?"),
                    "tls_version": version or "Unknown",
                    "ja3_hash": ja3_hash[:16] if ja3_hash else "N/A",
                    "anomaly_reasons": anomaly_reasons,
                })

        return CorrelationResult(
            correlated_data=campaigns[:20],
            summary={
                "total_campaigns": len(campaigns),
                "total_indicators": len(indicator_agents),
                "wazuh_alerts_analyzed": len(wazuh_alerts),
                "suricata_alerts_analyzed": len(suricata_data),
                "agents_in_campaigns": len(set(a for c in campaigns for a in c["agent_ids"])),
                "attack_graph_edges": unique_edges[:20],
                "attack_graph_node_count": len(set(e["source_id"] for e in unique_edges) | set(e["target_id"] for e in unique_edges)),
                "shadow_it": shadow_it[:10],
                "shadow_it_count": len(shadow_it),
                "encryption_anomalies": encryption_anomalies[:10],
                "encryption_anomaly_count": len(encryption_anomalies),
            },
            correlation_type="multi_asset_campaign_detection",
            primary_tool="get_wazuh_alerts",
            secondary_tools=["get_suricata_alerts", "get_wazuh_agents"]
        )


    # ==================================================================
    # PALLAS 3.5: ALERT NOISE ANALYSIS
    # ==================================================================

    @register_strategy("alert_noise_analysis")
    def alert_noise_analysis(self, primary: Dict[str, Any], secondary: List[Dict[str, Any]], context: Dict[str, Any]) -> CorrelationResult:
        """
        Pallas 3.5: Alert noise analysis.
        Primary = rule trigger analysis, Secondary = [alert timeline, agents].
        Identifies false positive candidates, noisy rules, and low-severity stealth chains.
        """
        rule_data = self._items(primary)
        timeline_data = self._items(secondary[0]) if len(secondary) > 0 else []
        agents = self._items(secondary[1]) if len(secondary) > 1 else []

        # If primary is rule trigger analysis, it may be a list of {rule_id, count, ...}
        # Or it could be raw text; normalize
        rule_stats = {}
        for r in rule_data:
            if isinstance(r, dict):
                rid = str(r.get("rule_id", r.get("id", r.get("key", ""))))
                count = r.get("count", r.get("doc_count", 1))
                desc = r.get("description", r.get("rule_description", ""))
                level = r.get("level", r.get("rule_level", 0))
                groups = r.get("groups", r.get("rule_groups", []))
                if rid:
                    try:
                        count = int(count)
                    except (ValueError, TypeError):
                        count = 1
                    try:
                        level = int(level)
                    except (ValueError, TypeError):
                        level = 0
                    rule_stats[rid] = {
                        "rule_id": rid,
                        "count": count,
                        "description": str(desc)[:80],
                        "level": level,
                        "groups": groups if isinstance(groups, list) else [],
                    }

        # Build agent count
        agent_count = len([a for a in agents if str(a.get("id", "")) != "000"])

        # Analyze timeline for temporal distribution
        rule_agent_dist = {}  # rule_id -> set of agent IDs that fired it
        rule_hourly_dist = {}  # rule_id -> {hour: count}
        agent_low_sev_rules = {}  # agent_id -> set of rule_ids with level < 7

        for t in timeline_data:
            if not isinstance(t, dict):
                continue
            rule = t.get("rule", {})
            if not isinstance(rule, dict):
                continue
            rid = str(rule.get("id", ""))
            level = rule.get("level", 0)
            try:
                level = int(level)
            except (ValueError, TypeError):
                level = 0

            agent_info = t.get("agent", {})
            aid = str(agent_info.get("id", "")) if isinstance(agent_info, dict) else ""

            if rid:
                rule_agent_dist.setdefault(rid, set()).add(aid)
                # Hourly distribution
                ts = t.get("timestamp", t.get("@timestamp", ""))
                try:
                    hour = datetime.fromisoformat(str(ts)[:19].replace("Z", "+00:00")).hour
                    hourly = rule_hourly_dist.setdefault(rid, {})
                    hourly[hour] = hourly.get(hour, 0) + 1
                except (ValueError, TypeError):
                    pass

            # Track low-severity per agent for stealth chain detection
            if level < 7 and aid and rid:
                agent_low_sev_rules.setdefault(aid, set()).add(rid)

        # Identify false positive candidates
        fp_candidates = []
        for rid, stats in rule_stats.items():
            reasons = []
            fp_score = 0

            # Criterion 1: Fires on ALL agents uniformly = not targeted = likely FP
            agent_set = rule_agent_dist.get(rid, set())
            if agent_count > 1 and len(agent_set) >= agent_count:
                fp_score += 30
                reasons.append(f"Fires on all {len(agent_set)} agents (not targeted)")

            # Criterion 2: Very high fire count
            if stats["count"] > 500:
                fp_score += 25
                reasons.append(f"High volume: {stats['count']:,} triggers")
            elif stats["count"] > 100:
                fp_score += 15
                reasons.append(f"Moderate volume: {stats['count']:,} triggers")

            # Criterion 3: Low severity + high count = operational noise
            if stats["level"] < 7 and stats["count"] > 100:
                fp_score += 20
                reasons.append(f"Low severity (Level {stats['level']}) with high count")

            # Criterion 4: Fires during business hours only on most agents = operational
            hourly = rule_hourly_dist.get(rid, {})
            if hourly:
                biz_count = sum(hourly.get(h, 0) for h in range(8, 18))
                total_count = sum(hourly.values())
                if total_count > 0 and biz_count / total_count > 0.85:
                    fp_score += 15
                    reasons.append("85%+ during business hours (operational noise)")

            fp_score = min(100, fp_score)

            if fp_score >= 30:  # Only report if reasonably FP-looking
                fp_candidates.append({
                    "rule_id": rid,
                    "description": stats["description"],
                    "level": stats["level"],
                    "count": stats["count"],
                    "fp_score": fp_score,
                    "fp_reasons": reasons,
                    "agents_affected": len(agent_set),
                    "groups": stats["groups"][:5],
                })

        fp_candidates.sort(key=lambda x: x["fp_score"], reverse=True)

        # Identify low-severity stealth chains
        stealth_chains = []
        agent_names = {str(a.get("id", "")): a.get("name", "Unknown") for a in agents}
        for aid, low_rules in agent_low_sev_rules.items():
            if len(low_rules) >= 5:  # 5+ different low-severity rules = possible stealth
                stealth_chains.append({
                    "agent_id": aid,
                    "agent_name": agent_names.get(aid, "Unknown"),
                    "distinct_low_sev_rules": len(low_rules),
                    "rule_ids": list(low_rules)[:10],
                    "risk_level": "HIGH" if len(low_rules) >= 8 else "MEDIUM",
                })
        stealth_chains.sort(key=lambda x: x["distinct_low_sev_rules"], reverse=True)

        # Generate tuning recommendations
        tuning_recs = []
        for fp in fp_candidates[:10]:
            if fp["fp_score"] >= 60:
                tuning_recs.append({
                    "rule_id": fp["rule_id"],
                    "description": fp["description"],
                    "recommendation": f"Consider tuning or excluding Rule {fp['rule_id']} — fires {fp['count']:,}x, likely false positive (score {fp['fp_score']})",
                    "action": "exclude_or_tune",
                })
            elif fp["fp_score"] >= 40:
                tuning_recs.append({
                    "rule_id": fp["rule_id"],
                    "description": fp["description"],
                    "recommendation": f"Review Rule {fp['rule_id']} threshold — fires {fp['count']:,}x, possibly noisy",
                    "action": "review_threshold",
                })

        return CorrelationResult(
            correlated_data=fp_candidates[:20],
            summary={
                "total_rules_analyzed": len(rule_stats),
                "fp_candidates": len(fp_candidates),
                "high_confidence_fps": len([f for f in fp_candidates if f["fp_score"] >= 60]),
                "tuning_recommendations": tuning_recs[:10],
                "stealth_chains": stealth_chains[:10],
                "stealth_chain_count": len(stealth_chains),
                "agent_count": agent_count,
            },
            correlation_type="alert_noise_analysis",
            primary_tool="get_rule_trigger_analysis",
            secondary_tools=["get_alert_timeline", "get_wazuh_agents"]
        )

    # ==================================================================
    # PALLAS 3.5: OFF-HOURS ANOMALY DETECTION
    # ==================================================================

    @register_strategy("off_hours_anomaly_detection")
    def off_hours_anomaly_detection(self, primary: Dict[str, Any], secondary: List[Dict[str, Any]], context: Dict[str, Any]) -> CorrelationResult:
        """
        Pallas 3.5: Off-hours anomaly detection.
        Primary = security events, Secondary = [agents, suricata_alerts].
        Identifies activity outside business hours (08:00-18:00) and flags anomalies.
        """
        events = self._items(primary)
        agents = self._items(secondary[0]) if len(secondary) > 0 else []
        suricata_data = self._items(secondary[1]) if len(secondary) > 1 else []

        business_start = context.get("business_start", 8)
        business_end = context.get("business_end", 18)

        # Build agent lookup
        agent_lookup = {}
        for a in agents:
            aid = str(a.get("id", ""))
            if aid and aid != "000":
                agent_lookup[aid] = {"name": a.get("name", "Unknown"), "ip": a.get("ip", "N/A"), "os": (a.get("os", {}) or {}).get("name", "Unknown")}

        # Analyze Wazuh events by time
        agent_stats = {}
        off_hours_events = []

        for ev in events:
            ts = self._extract_event_timestamp(ev) or ""
            agent_info = ev.get("agent", {})
            aid = str(agent_info.get("id", "")) if isinstance(agent_info, dict) else ""
            if not aid:
                continue

            hour = None
            try:
                ts_str = str(ts)[:19]
                dt = datetime.fromisoformat(ts_str.replace("Z", "+00:00"))
                hour = dt.hour
            except (ValueError, TypeError):
                continue

            entry = agent_stats.setdefault(aid, {"total": 0, "off_hours": 0, "off_hours_events": [], "hour_dist": {}})
            entry["total"] += 1
            entry["hour_dist"][hour] = entry["hour_dist"].get(hour, 0) + 1

            is_off_hours = hour < business_start or hour >= business_end

            if is_off_hours:
                entry["off_hours"] += 1
                rule = ev.get("rule", {})
                desc = rule.get("description", "Unknown") if isinstance(rule, dict) else "Unknown"
                level = rule.get("level", 0) if isinstance(rule, dict) else 0
                groups = rule.get("groups", []) if isinstance(rule, dict) else []

                event_entry = {
                    "agent_id": aid,
                    "agent_name": agent_lookup.get(aid, {}).get("name", "Unknown"),
                    "timestamp": ts_str,
                    "hour": hour,
                    "description": str(desc)[:80],
                    "level": level,
                    "groups": groups[:5],
                }

                if len(entry["off_hours_events"]) < 10:
                    entry["off_hours_events"].append(event_entry)
                off_hours_events.append(event_entry)

        # Add Suricata off-hours events
        suricata_off_hours = []
        for s in suricata_data:
            ts = s.get("timestamp", s.get("@timestamp", ""))
            try:
                ts_str = str(ts)[:19]
                dt = datetime.fromisoformat(ts_str.replace("Z", "+00:00"))
                hour = dt.hour
            except (ValueError, TypeError):
                continue

            if hour < business_start or hour >= business_end:
                alert_info = s.get("alert", {})
                suricata_off_hours.append({
                    "src_ip": s.get("src_ip", "?"),
                    "dest_ip": s.get("dest_ip", "?"),
                    "signature": alert_info.get("signature", "?")[:60] if isinstance(alert_info, dict) else "?",
                    "severity": alert_info.get("severity", "?") if isinstance(alert_info, dict) else "?",
                    "timestamp": ts_str,
                    "hour": hour,
                })

        # Build anomaly report per agent
        anomalous_agents = []
        for aid, stats in agent_stats.items():
            if stats["total"] == 0:
                continue
            off_ratio = stats["off_hours"] / stats["total"]
            agent_info = agent_lookup.get(aid, {"name": "Unknown", "ip": "N/A", "os": "Unknown"})

            # Flag anomalous patterns
            suspicious_patterns = []
            for ev in stats["off_hours_events"]:
                groups = ev.get("groups", [])
                desc = ev.get("description", "").lower()
                # Check for particularly suspicious off-hours activity
                if any(kw in desc for kw in ["powershell", "cmd", "script", "remote", "rdp", "ssh", "login"]):
                    suspicious_patterns.append(ev)
                elif any(g in ["powershell", "sshd", "authentication_success", "authentication_failed"] for g in groups):
                    suspicious_patterns.append(ev)

            anomalous_agents.append({
                "agent_id": aid,
                "agent_name": agent_info["name"],
                "agent_ip": agent_info["ip"],
                "agent_os": agent_info["os"],
                "total_events": stats["total"],
                "off_hours_events": stats["off_hours"],
                "off_hours_ratio": round(off_ratio, 3),
                "is_anomalous": off_ratio > 0.4 or len(suspicious_patterns) > 0,
                "suspicious_count": len(suspicious_patterns),
                "suspicious_patterns": suspicious_patterns[:5],
                "sample_events": stats["off_hours_events"][:5],
                "hour_distribution": stats["hour_dist"],
            })

        # Sort: anomalous first, then by off-hours ratio
        anomalous_agents.sort(key=lambda a: (0 if a["is_anomalous"] else 1, -a["off_hours_ratio"]))

        return CorrelationResult(
            correlated_data=anomalous_agents[:20],
            summary={
                "total_events_analyzed": sum(s["total"] for s in agent_stats.values()),
                "total_off_hours_events": sum(s["off_hours"] for s in agent_stats.values()),
                "agents_analyzed": len(agent_stats),
                "anomalous_agents": len([a for a in anomalous_agents if a["is_anomalous"]]),
                "business_hours": f"{business_start:02d}:00-{business_end:02d}:00",
                "suricata_off_hours": suricata_off_hours[:10],
                "suricata_off_hours_count": len(suricata_off_hours),
            },
            correlation_type="off_hours_anomaly_detection",
            primary_tool="search_security_events",
            secondary_tools=["get_wazuh_agents", "get_suricata_alerts"]
        )

    # ==================================================================
    # PALLAS 3.5: DATA EXFILTRATION DETECTION
    # ==================================================================

    _COMPRESSION_TOOLS = {"zip", "rar", "7z", "tar", "gzip", "bzip2", "xz", "compress", "winzip", "winrar", "7-zip"}
    _SENSITIVE_DIRS = {"/etc", "/var/log", "/home", "/root", "/opt", "c:\\users", "c:\\windows\\system32",
                       "/tmp", "/var/tmp", "appdata", "documents", "desktop", "downloads"}

    @register_strategy("data_exfiltration_detection")
    def data_exfiltration_detection(self, primary: Dict[str, Any], secondary: List[Dict[str, Any]], context: Dict[str, Any]) -> CorrelationResult:
        """
        Pallas 3.5: Data exfiltration detection.
        Primary = FIM events, Secondary = [agent processes, Suricata alerts].
        Detects: bulk file access, compression activity, outbound data transfer.
        """
        fim_events = self._items(primary)
        process_data = self._items(secondary[0]) if len(secondary) > 0 else []
        suricata_data = self._items(secondary[1]) if len(secondary) > 1 else []

        # Analyze FIM events for bulk file access
        agent_fim = {}
        for f in fim_events:
            agent_info = f.get("agent", {})
            aid = str(agent_info.get("id", "")) if isinstance(agent_info, dict) else ""
            if not aid:
                continue
            entry = agent_fim.setdefault(aid, {
                "agent_name": agent_info.get("name", "Unknown") if isinstance(agent_info, dict) else "Unknown",
                "file_count": 0,
                "sensitive_files": 0,
                "file_types": set(),
                "directories": set(),
                "events": [],
            })
            entry["file_count"] += 1

            # Check syscheck data
            syscheck = f.get("syscheck", f.get("data", {}))
            if isinstance(syscheck, dict):
                path = str(syscheck.get("path", "")).lower()
                entry["directories"].add("/".join(path.replace("\\", "/").split("/")[:3]))
                ext = path.rsplit(".", 1)[-1] if "." in path else ""
                if ext:
                    entry["file_types"].add(ext)
                # Sensitive directory check
                for sd in self._SENSITIVE_DIRS:
                    if sd in path:
                        entry["sensitive_files"] += 1
                        break

            if len(entry["events"]) < 5:
                entry["events"].append({
                    "path": str(syscheck.get("path", "?"))[:80] if isinstance(syscheck, dict) else "?",
                    "event": str(syscheck.get("event", f.get("rule", {}).get("description", "?")))[:60] if isinstance(syscheck, dict) else "?",
                    "timestamp": str(f.get("timestamp", ""))[:19],
                })

        # Analyze processes for compression tools
        agent_compression = {}
        for p in process_data:
            aid = str(p.get("agent_id", ""))
            if not aid:
                continue
            proc_name = str(p.get("name", p.get("process", ""))).lower()
            cmd = str(p.get("cmd", p.get("command", ""))).lower()
            for tool in self._COMPRESSION_TOOLS:
                if tool in proc_name or tool in cmd:
                    entry = agent_compression.setdefault(aid, {"tools": set(), "processes": []})
                    entry["tools"].add(tool)
                    if len(entry["processes"]) < 3:
                        entry["processes"].append({
                            "name": proc_name[:40],
                            "pid": p.get("pid", "?"),
                            "user": str(p.get("euser", p.get("user", "?")))[:20],
                        })
                    break

        # Analyze Suricata for outbound transfer indicators
        outbound_indicators = []
        for s in suricata_data:
            alert_info = s.get("alert", {})
            if not isinstance(alert_info, dict):
                continue
            sig = str(alert_info.get("signature", "")).lower()
            cat = str(alert_info.get("category", "")).lower()
            # Look for data transfer / exfiltration signatures
            if any(kw in sig or kw in cat for kw in ["exfil", "data leak", "large upload", "suspicious transfer", "dns tunnel", "covert"]):
                outbound_indicators.append({
                    "signature": alert_info.get("signature", "?")[:60],
                    "src_ip": s.get("src_ip", "?"),
                    "dest_ip": s.get("dest_ip", "?"),
                    "severity": alert_info.get("severity", "?"),
                    "timestamp": str(s.get("timestamp", ""))[:19],
                })
            # Also check for high-volume flows
            flow = s.get("flow", {})
            if isinstance(flow, dict):
                bytes_out = flow.get("bytes_toserver", 0)
                if isinstance(bytes_out, (int, float)) and bytes_out > 10_000_000:  # >10MB
                    outbound_indicators.append({
                        "signature": f"Large outbound flow ({bytes_out / 1_000_000:.1f}MB)",
                        "src_ip": s.get("src_ip", "?"),
                        "dest_ip": s.get("dest_ip", "?"),
                        "severity": 2,
                        "timestamp": str(s.get("timestamp", ""))[:19],
                    })

        # Build exfiltration risk indicators per agent
        exfil_indicators = []
        all_agents = set(list(agent_fim.keys()) + list(agent_compression.keys()))
        for aid in all_agents:
            fim = agent_fim.get(aid, {"agent_name": "Unknown", "file_count": 0, "sensitive_files": 0, "file_types": set(), "directories": set(), "events": []})
            comp = agent_compression.get(aid, {"tools": set(), "processes": []})

            risk_score = 0
            indicators = []

            # Bulk file access
            if fim["file_count"] > 20:
                risk_score += 30
                indicators.append(f"Bulk file access ({fim['file_count']} files)")
            elif fim["file_count"] > 5:
                risk_score += 15
                indicators.append(f"Multiple file access ({fim['file_count']} files)")

            # Sensitive directory access
            if fim["sensitive_files"] > 0:
                risk_score += 20
                indicators.append(f"Sensitive directory access ({fim['sensitive_files']} files)")

            # Compression tool detected
            if comp["tools"]:
                risk_score += 25
                indicators.append(f"Compression tools: {', '.join(comp['tools'])}")

            # Combined: file access + compression = high risk
            if fim["file_count"] > 5 and comp["tools"]:
                risk_score += 15
                indicators.append("File access + compression (exfiltration pattern)")

            risk_score = min(100, risk_score)
            if risk_score >= 60:
                risk_level = "CRITICAL"
            elif risk_score >= 40:
                risk_level = "HIGH"
            elif risk_score >= 20:
                risk_level = "MEDIUM"
            else:
                risk_level = "LOW"

            exfil_indicators.append({
                "agent_id": aid,
                "agent_name": fim["agent_name"],
                "risk_score": risk_score,
                "risk_level": risk_level,
                "indicators": indicators,
                "file_count": fim["file_count"],
                "sensitive_files": fim["sensitive_files"],
                "compression_tools": list(comp.get("tools", set())),
                "file_types": list(fim.get("file_types", set()))[:10],
                "directories": list(fim.get("directories", set()))[:10],
                "sample_events": fim.get("events", []),
            })

        exfil_indicators.sort(key=lambda x: x["risk_score"], reverse=True)

        return CorrelationResult(
            correlated_data=exfil_indicators[:20],
            summary={
                "total_fim_events": len(fim_events),
                "agents_with_fim": len(agent_fim),
                "agents_with_compression": len(agent_compression),
                "outbound_indicators": outbound_indicators[:10],
                "outbound_count": len(outbound_indicators),
                "critical_risk": len([e for e in exfil_indicators if e["risk_level"] == "CRITICAL"]),
                "high_risk": len([e for e in exfil_indicators if e["risk_level"] == "HIGH"]),
            },
            correlation_type="data_exfiltration_detection",
            primary_tool="get_fim_events",
            secondary_tools=["get_agent_processes", "get_suricata_alerts"]
        )

    # ==================================================================
    # PALLAS 3.5: CROSS-PLATFORM THREAT CORRELATION
    # ==================================================================

    @register_strategy("cross_platform_threat_correlation")
    def cross_platform_threat_correlation(self, primary: Dict[str, Any], secondary: List[Dict[str, Any]], context: Dict[str, Any]) -> CorrelationResult:
        """
        Pallas 3.5: Cross-platform threat correlation.
        Primary = Suricata alerts (network), Secondary = [Wazuh alerts, agents, HTTP data].
        Correlates network IDS detections with endpoint events on the same host.
        Detects C2 beaconing via periodic traffic analysis.
        """
        suricata_alerts = self._items(primary)
        wazuh_alerts = self._items(secondary[0]) if len(secondary) > 0 else []
        agents = self._items(secondary[1]) if len(secondary) > 1 else []
        http_data = self._items(secondary[2]) if len(secondary) > 2 else []

        # Build IP → agent map
        ip_to_agent = {}
        for a in agents:
            ip = a.get("ip")
            aid = str(a.get("id", ""))
            name = a.get("name", "Unknown")
            if ip:
                ip_to_agent[ip] = {"id": aid, "name": name, "status": a.get("status", "unknown")}

        # Build per-agent Wazuh alert index
        wazuh_by_agent = {}
        for wa in wazuh_alerts:
            agent_info = wa.get("agent", {})
            aid = str(agent_info.get("id", "")) if isinstance(agent_info, dict) else ""
            if aid:
                wazuh_by_agent.setdefault(aid, []).append(wa)

        # Analyze Suricata alerts and correlate with endpoints
        correlated_threats = []
        ip_flow_times = {}  # For beaconing detection: dest_ip -> list of timestamps

        for sa in suricata_alerts:
            src_ip = sa.get("src_ip", sa.get("srcip", ""))
            dest_ip = sa.get("dest_ip", sa.get("destip", ""))
            alert_info = sa.get("alert", {})
            signature = alert_info.get("signature", "Unknown") if isinstance(alert_info, dict) else "Unknown"
            category = alert_info.get("category", "") if isinstance(alert_info, dict) else ""
            severity = alert_info.get("severity", 3) if isinstance(alert_info, dict) else 3

            # Track flow timestamps for beaconing
            ts = sa.get("timestamp", sa.get("@timestamp", ""))
            if dest_ip and ts:
                ip_flow_times.setdefault(dest_ip, []).append(str(ts))

            # Find matching agent
            agent_info = ip_to_agent.get(src_ip) or ip_to_agent.get(dest_ip)
            if not agent_info:
                continue

            # Find matching Wazuh alerts on same agent
            matching_wazuh = wazuh_by_agent.get(agent_info["id"], [])

            # Build correlation entry
            entry = {
                "suricata_signature": signature,
                "suricata_category": category,
                "suricata_severity": severity,
                "src_ip": src_ip,
                "dest_ip": dest_ip,
                "agent_id": agent_info["id"],
                "agent_name": agent_info["name"],
                "agent_status": agent_info["status"],
                "wazuh_alert_count": len(matching_wazuh),
                "wazuh_top_rules": [],
                "confidence": "HIGH" if matching_wazuh else "MEDIUM",
                "timestamp": str(ts)[:19],
            }

            # Add top Wazuh rules for this agent
            for wa in matching_wazuh[:3]:
                rule = wa.get("rule", {})
                if isinstance(rule, dict):
                    entry["wazuh_top_rules"].append({
                        "id": rule.get("id", "?"),
                        "description": str(rule.get("description", ""))[:60],
                        "level": rule.get("level", 0),
                    })

            correlated_threats.append(entry)

        # C2 Beaconing detection: analyze flow interval periodicity
        beaconing_suspects = []
        for dest_ip, timestamps in ip_flow_times.items():
            if len(timestamps) < 5:
                continue
            # Sort and calculate intervals
            sorted_ts = sorted(timestamps)
            intervals = []
            for i in range(1, len(sorted_ts)):
                try:
                    t1 = sorted_ts[i - 1][:19]
                    t2 = sorted_ts[i][:19]
                    dt1 = datetime.fromisoformat(t1.replace("Z", "+00:00"))
                    dt2 = datetime.fromisoformat(t2.replace("Z", "+00:00"))
                    diff = abs((dt2 - dt1).total_seconds())
                    if 0 < diff < 86400:  # Ignore > 24h gaps
                        intervals.append(diff)
                except (ValueError, TypeError):
                    continue

            if len(intervals) < 4:
                continue

            # Check periodicity: low coefficient of variation = beaconing
            avg_interval = sum(intervals) / len(intervals)
            if avg_interval < 1:
                continue
            variance = sum((x - avg_interval) ** 2 for x in intervals) / len(intervals)
            std_dev = variance ** 0.5
            cv = std_dev / avg_interval  # Coefficient of variation

            if cv < 0.3:  # Less than 30% variation = suspicious periodicity
                agent_info = ip_to_agent.get(dest_ip, {"id": "?", "name": dest_ip, "status": "?"})
                beaconing_suspects.append({
                    "dest_ip": dest_ip,
                    "agent_id": agent_info.get("id", "?"),
                    "agent_name": agent_info.get("name", dest_ip),
                    "connection_count": len(timestamps),
                    "avg_interval_sec": round(avg_interval, 1),
                    "coefficient_variation": round(cv, 3),
                    "beacon_confidence": "HIGH" if cv < 0.15 else "MEDIUM",
                })

        beaconing_suspects.sort(key=lambda b: b["coefficient_variation"])

        # Sort correlated threats by severity
        correlated_threats.sort(key=lambda t: (0 if t["confidence"] == "HIGH" else 1, t["suricata_severity"]))

        return CorrelationResult(
            correlated_data=correlated_threats[:30],
            summary={
                "total_suricata_alerts": len(suricata_alerts),
                "total_correlated": len(correlated_threats),
                "high_confidence": len([t for t in correlated_threats if t["confidence"] == "HIGH"]),
                "medium_confidence": len([t for t in correlated_threats if t["confidence"] == "MEDIUM"]),
                "agents_affected": len(set(t["agent_id"] for t in correlated_threats)),
                "beaconing_suspects": beaconing_suspects[:10],
                "beaconing_count": len(beaconing_suspects),
            },
            correlation_type="cross_platform_threat_correlation",
            primary_tool="get_suricata_alerts",
            secondary_tools=["get_wazuh_alerts", "get_wazuh_agents", "search_suricata_http"]
        )

    # ==================================================================
    # PALLAS 3.5: DYNAMIC RISK SCORING
    # ==================================================================

    _HIGH_RISK_PORTS = {21, 22, 23, 25, 135, 139, 445, 1433, 1521, 3306, 3389, 5432, 5900, 5985, 8080, 8443, 9200}

    @register_strategy("dynamic_risk_scoring")
    def dynamic_risk_scoring(self, primary: Dict[str, Any], secondary: List[Dict[str, Any]], context: Dict[str, Any]) -> CorrelationResult:
        """
        Pallas 3.5: Composite risk scoring across vulns, alerts, IDS, exposure, and compliance.
        Primary = agents, Secondary = [vulns, alerts, suricata_alerts, ports].
        """
        agents = self._items(primary)
        agents = [a for a in agents if str(a.get("id", "")) != "000"]

        # Parse secondary data (order matches pattern definition)
        vuln_data = self._items(secondary[0]) if len(secondary) > 0 else []
        alert_data = self._items(secondary[1]) if len(secondary) > 1 else []
        suricata_data = self._items(secondary[2]) if len(secondary) > 2 else []
        port_data = self._items(secondary[3]) if len(secondary) > 3 else []

        # Build per-agent vulnerability index
        vuln_by_agent = {}
        for v in vuln_data:
            aid = str(v.get("agent_id") or (v.get("agent") or {}).get("id", "")) if isinstance(v, dict) else ""
            if not aid:
                continue
            sev = str(v.get("severity", v.get("condition", ""))).lower()
            entry = vuln_by_agent.setdefault(aid, {"critical": 0, "high": 0, "medium": 0, "low": 0, "total": 0, "top_cves": []})
            entry["total"] += 1
            if "critical" in sev:
                entry["critical"] += 1
            elif "high" in sev:
                entry["high"] += 1
            elif "medium" in sev:
                entry["medium"] += 1
            else:
                entry["low"] += 1
            cve = v.get("cve", v.get("id", ""))
            cvss = v.get("cvss3_score") or ((v.get("cvss") or {}).get("cvss3") or {}).get("base_score", 0) if isinstance(v, dict) else 0
            if cve and len(entry["top_cves"]) < 5:
                entry["top_cves"].append({"cve": cve, "cvss": cvss, "severity": sev})

        # Build per-agent alert index
        alert_by_agent = {}
        for a in alert_data:
            agent_info = a.get("agent", {})
            aid = str(agent_info.get("id", "")) if isinstance(agent_info, dict) else ""
            if not aid:
                continue
            rule = a.get("rule") or {}
            if not isinstance(rule, dict):
                rule = {}
            level = self._safe_int(rule.get("level", 0))
            entry = alert_by_agent.setdefault(aid, {"critical": 0, "high": 0, "medium": 0, "total": 0, "mitre_tactics": set()})
            entry["total"] += 1
            if level >= 12:
                entry["critical"] += 1
            elif level >= 8:
                entry["high"] += 1
            elif level >= 5:
                entry["medium"] += 1
            # Track MITRE tactics
            if isinstance(rule, dict):
                mitre = rule.get("mitre", {})
                if isinstance(mitre, dict):
                    for t in mitre.get("tactic", []):
                        if isinstance(t, str):
                            entry["mitre_tactics"].add(t)

        # Build IP → agent map for Suricata correlation
        ip_to_agent = {}
        for a in agents:
            ip = a.get("ip")
            aid = str(a.get("id", ""))
            if ip and aid:
                ip_to_agent[ip] = aid

        # Build per-agent IDS detection count
        ids_by_agent = {}
        for s in suricata_data:
            src_ip = s.get("src_ip", s.get("srcip", ""))
            dest_ip = s.get("dest_ip", s.get("destip", ""))
            target_aid = ip_to_agent.get(dest_ip) or ip_to_agent.get(src_ip)
            if target_aid:
                alert_info = s.get("alert", {})
                sev = self._safe_int(alert_info.get("severity", 3), 3) if isinstance(alert_info, dict) else 3
                entry = ids_by_agent.setdefault(target_aid, {"count": 0, "weighted": 0, "signatures": set()})
                entry["count"] += 1
                entry["weighted"] += max(1, 5 - sev) * 3  # Sev 1=12, Sev 2=9, Sev 3=6
                sig = alert_info.get("signature", "") if isinstance(alert_info, dict) else ""
                if sig and len(entry["signatures"]) < 5:
                    entry["signatures"].add(sig[:80])

        # Build per-agent port exposure
        port_by_agent = {}
        for p in port_data:
            aid = str(p.get("agent_id", ""))
            if not aid:
                continue
            port_num = p.get("local", {}).get("port") if isinstance(p.get("local"), dict) else p.get("port")
            if port_num is None:
                continue
            try:
                port_num = int(port_num)
            except (ValueError, TypeError):
                continue
            entry = port_by_agent.setdefault(aid, {"total": 0, "high_risk": 0, "ports": []})
            entry["total"] += 1
            if port_num in self._HIGH_RISK_PORTS:
                entry["high_risk"] += 1
            if len(entry["ports"]) < 10:
                entry["ports"].append(port_num)

        # Calculate composite risk for each agent
        scored_agents = []
        for a in agents:
            aid = str(a.get("id", ""))

            # Vulnerability score
            v = vuln_by_agent.get(aid, {"critical": 0, "high": 0, "medium": 0, "low": 0, "total": 0, "top_cves": []})
            vuln_score = min(40, v["critical"] * 25 + v["high"] * 10 + v["medium"] * 3 + v["low"] * 1)

            # Alert score
            al = alert_by_agent.get(aid, {"critical": 0, "high": 0, "medium": 0, "total": 0, "mitre_tactics": set()})
            alert_score = min(30, al["critical"] * 30 + al["high"] * 15 + al["medium"] * 5)

            # IDS score
            ids = ids_by_agent.get(aid, {"count": 0, "weighted": 0, "signatures": set()})
            ids_score = min(20, ids["weighted"])

            # Exposure score
            pt = port_by_agent.get(aid, {"total": 0, "high_risk": 0, "ports": []})
            exposure_score = min(15, pt["total"] * 2 + pt["high_risk"] * 8)

            # Disconnected penalty
            status = str(a.get("status", "")).lower()
            status_penalty = 5 if status == "disconnected" else 0

            composite = min(100, vuln_score + alert_score + ids_score + exposure_score + status_penalty)

            if composite >= 75:
                risk_level = "CRITICAL"
            elif composite >= 50:
                risk_level = "HIGH"
            elif composite >= 25:
                risk_level = "MEDIUM"
            else:
                risk_level = "LOW"

            scored_agents.append({
                "agent_id": aid,
                "agent_name": a.get("name", "Unknown"),
                "agent_ip": a.get("ip", "N/A"),
                "agent_status": status,
                "agent_os": (a.get("os", {}) or {}).get("name", "Unknown"),
                "composite_score": composite,
                "risk_level": risk_level,
                "vuln_score": vuln_score,
                "alert_score": alert_score,
                "ids_score": ids_score,
                "exposure_score": exposure_score,
                "vuln_detail": v,
                "alert_detail": {"critical": al["critical"], "high": al["high"], "medium": al["medium"], "total": al["total"], "mitre_tactics": list(al.get("mitre_tactics", set()))},
                "ids_detail": {"count": ids["count"], "signatures": list(ids.get("signatures", set()))},
                "port_detail": pt,
            })

        # Sort by composite risk descending
        scored_agents.sort(key=lambda x: x["composite_score"], reverse=True)

        return CorrelationResult(
            correlated_data=scored_agents[:20],
            summary={
                "total_agents": len(scored_agents),
                "critical_risk": len([a for a in scored_agents if a["risk_level"] == "CRITICAL"]),
                "high_risk": len([a for a in scored_agents if a["risk_level"] == "HIGH"]),
                "medium_risk": len([a for a in scored_agents if a["risk_level"] == "MEDIUM"]),
                "low_risk": len([a for a in scored_agents if a["risk_level"] == "LOW"]),
                "avg_score": round(sum(a["composite_score"] for a in scored_agents) / max(len(scored_agents), 1), 1),
                "max_score": scored_agents[0]["composite_score"] if scored_agents else 0,
            },
            correlation_type="dynamic_risk_scoring",
            primary_tool="get_wazuh_agents",
            secondary_tools=["get_wazuh_vulnerabilities", "get_wazuh_alerts", "get_suricata_alerts", "get_agent_ports"]
        )

    # ==================================================================
    # PALLAS 3.4: AGENT HEALTH ANALYTICS
    # ==================================================================

    @register_strategy("agent_health_overview")
    def agent_health_overview(self, primary: Dict[str, Any], secondary: List[Dict[str, Any]], context: Dict[str, Any]) -> CorrelationResult:
        """Agent fleet health: OS grouping, version comparison, staleness detection, enrollment recency."""
        agents = self._items(primary)

        # Exclude manager
        agents = [a for a in agents if str(a.get("id", "")) != "000"]

        os_groups = {}
        version_counts = {}
        stale_agents = []
        recently_enrolled = []
        now = datetime.now(timezone.utc)

        for a in agents:
            # OS grouping
            os_info = a.get("os", {})
            if isinstance(os_info, dict):
                os_name = os_info.get("name", "Unknown")
                os_platform = os_info.get("platform", "Unknown")
            else:
                os_name = "Unknown"
                os_platform = "Unknown"
            os_key = f"{os_platform}/{os_name}"
            os_groups.setdefault(os_key, []).append(a)

            # Version tracking
            version = str(a.get("version", "Unknown")).replace("Wazuh v", "")
            version_counts[version] = version_counts.get(version, 0) + 1

            # Staleness detection (>6 hours since last keepalive)
            last_ka = a.get("lastKeepAlive", "")
            if last_ka and a.get("status", "").lower() == "active":
                try:
                    ka_str = str(last_ka).replace("Z", "+00:00")
                    if "+" not in ka_str and "-" not in ka_str[10:]:
                        ka_str += "+00:00"
                    ka_time = datetime.fromisoformat(ka_str)
                    hours_since = (now - ka_time).total_seconds() / 3600
                    if hours_since > 6:
                        stale_agents.append({**a, "_hours_since_contact": round(hours_since, 1)})
                except Exception:
                    pass

            # Enrollment recency (registered within last 7 days)
            reg_date = a.get("dateAdd", a.get("registered_date", ""))
            if reg_date:
                try:
                    reg_str = str(reg_date).replace("Z", "+00:00")
                    if "+" not in reg_str and "-" not in reg_str[10:]:
                        reg_str += "+00:00"
                    reg_time = datetime.fromisoformat(reg_str)
                    days_since = (now - reg_time).total_seconds() / 86400
                    if days_since <= 7:
                        recently_enrolled.append({**a, "_days_since_enrollment": round(days_since, 1)})
                except Exception:
                    pass

        # Determine majority version
        majority_version = max(version_counts, key=version_counts.get) if version_counts else "Unknown"
        mismatched = [a for a in agents if str(a.get("version", "")).replace("Wazuh v", "") != majority_version]

        return CorrelationResult(
            correlated_data=agents,
            summary={
                "total_agents": len(agents),
                "os_groups": {k: len(v) for k, v in os_groups.items()},
                "os_groups_detail": os_groups,
                "version_counts": version_counts,
                "majority_version": majority_version,
                "mismatched_agents": mismatched,
                "mismatched_count": len(mismatched),
                "stale_agents": stale_agents,
                "stale_count": len(stale_agents),
                "recently_enrolled": recently_enrolled,
                "recently_enrolled_count": len(recently_enrolled),
            },
            correlation_type="agent_health_overview",
            primary_tool="get_wazuh_agents",
            secondary_tools=[]
        )


    @register_strategy("agent_event_volume")
    def agent_event_volume(self, primary: Dict[str, Any], secondary: List[Dict[str, Any]], context: Dict[str, Any]) -> CorrelationResult:
        """Cross-reference log source health data with agent info to detect volume anomalies."""
        health_data = primary
        agents = []
        for r in secondary:
            agents.extend(self._items(r))

        agent_map = {str(a.get("id", "")): a for a in agents if a.get("id")}

        # Extract event counts from health data
        raw_data = health_data if isinstance(health_data, dict) else {}
        data_section = raw_data.get("data", raw_data)
        if isinstance(data_section, dict):
            agent_event_counts = data_section.get("agent_event_counts", data_section.get("affected_items", []))
        else:
            agent_event_counts = data_section if isinstance(data_section, list) else []

        # Calculate stats
        counts = [a.get("event_count", a.get("doc_count", 0)) for a in agent_event_counts
                  if isinstance(a.get("event_count", a.get("doc_count", 0)), (int, float))]
        avg_count = sum(counts) / len(counts) if counts else 0
        anomalies = []

        for aec in agent_event_counts:
            aid = str(aec.get("agent_id", aec.get("key", "")))
            count = aec.get("event_count", aec.get("doc_count", 0))
            agent_info = agent_map.get(aid, {})

            deviation = abs(count - avg_count) / avg_count if avg_count > 0 else 0
            if deviation > 2.0 or count == 0:
                anomalies.append({
                    "agent_id": aid,
                    "agent_name": aec.get("agent_name", agent_info.get("name", "Unknown")),
                    "event_count": count,
                    "average": round(avg_count, 1),
                    "deviation_factor": round(deviation, 2),
                    "anomaly_type": "silent" if count == 0 else ("high_volume" if count > avg_count else "low_volume"),
                    "agent_status": agent_info.get("status", "unknown"),
                    "agent_os": (agent_info.get("os", {}) or {}).get("name", "Unknown"),
                })

        return CorrelationResult(
            correlated_data=agent_event_counts,
            summary={
                "total_agents_reporting": len(agent_event_counts),
                "average_event_count": round(avg_count, 1),
                "total_events": sum(counts),
                "anomalies": anomalies,
                "anomaly_count": len(anomalies),
            },
            correlation_type="agent_event_volume",
            primary_tool="get_log_source_health",
            secondary_tools=["get_wazuh_agents"]
        )


# Apply pending strategy registrations
CorrelationEngine.STRATEGIES = _PENDING_STRATEGIES

# ============================================================================
# LESSONS LEARNED / CHANGELOG
# ============================================================================
#
# Date: 2026-02-19
#
# Root Cause:
#   1. The CorrelationEngine itself was correct. The failure was upstream:
#      the orchestrator passed the wrong tool's data to the correlation engine.
#      When search_security_events was incorrectly routed to get_wazuh_alerts,
#      the alerts_with_agents correlation ran on unfiltered alert data (10k events)
#      producing a 10k-item result set instead of 4 virustotal events.
#   2. The _fallback() method correctly returns all primary items, so the
#      "never return empty" requirement was already satisfied IF primary data
#      was correct. The root cause was wrong tool selection upstream.
#   3. No issues found in the correlation strategies themselves.
#
# Fix Summary (in correlation_engine.py):
#   - No logic changes required to correlation strategies.
#   - Added this LESSONS LEARNED section as required.
#   - The real fix is in query_orchestrator.py (correct tool selection)
#     and response_formatter.py (format_search_events_response added).
#
# Defensive notes already correct in this file:
#   - _normalize_tool_payload() handles all 3 MCP payload formats.
#   - _fallback() always returns primary items, never empty.
#   - All strategies are exception-wrapped and fall back to _fallback().
#
# Future Prevention:
#   - When a new integration (e.g. CrowdStrike, Suricata) produces events
#     via search_security_events, ensure the alerts_with_agents correlation
#     still works (agent enrichment is optional, not required).
#   - Add a smoke test: "search virustotal event" → assert primary_tool ==
#     search_security_events AND primary_args["query"] contains "virustotal".
