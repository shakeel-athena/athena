"""
Response Formatter - Structured, categorized formatting for large datasets
Handles markdown tables, summaries, and categorization
"""

import json
from typing import List, Dict, Any, Optional
from datetime import datetime


class ResponseFormatter:
    """
    Formats tool results and correlated data into structured,
    readable responses with categorization for large datasets.
    """
    
    def format_vulnerability_response(
        self,
        correlated_data: List[Dict[str, Any]],
        summary: Dict[str, Any],
        include_remediation: bool = True
    ) -> str:
        """
        Format vulnerability analysis with categorization.
        
        Handles:
        - Large datasets (100+ vulns)
        - Grouping by severity, agent, package
        - Remediation guidance
        """
        
        output = ["## 🔒 Vulnerability Analysis\n"]
        
        # Summary section
        output.append("### 📊 Summary")
        output.append(f"- **Total Vulnerabilities**: {summary.get('total_vulnerabilities', 0)}")
        output.append(f"- **Affected Agents**: {summary.get('affected_agents', 0)}")
        
        by_severity = summary.get("by_severity", {})
        output.append(f"- **By Severity**:")
        output.append(f"  - 🔴 Critical: {by_severity.get('Critical', 0)}")
        output.append(f"  - 🟠 High: {by_severity.get('High', 0)}")
        output.append(f"  - 🟡 Medium: {by_severity.get('Medium', 0)}")
        output.append(f"  - 🟢 Low: {by_severity.get('Low', 0)}")
        output.append("")
        
        # Critical vulnerabilities table (top 10)
        critical_vulns = [v for v in correlated_data if v.get("severity") == "Critical"]
        if critical_vulns:
            output.append("### 🚨 Critical Vulnerabilities (Immediate Action Required)")
            output.append("")
            output.append(self._format_vulnerability_table(critical_vulns[:10]))
            
            if len(critical_vulns) > 10:
                output.append(f"\n*Showing top 10 of {len(critical_vulns)} critical vulnerabilities*\n")
        
        # High severity (top 10)
        high_vulns = [v for v in correlated_data if v.get("severity") == "High"]
        if high_vulns:
            output.append("### ⚠️ High Severity Vulnerabilities")
            output.append("")
            output.append(self._format_vulnerability_table(high_vulns[:10]))
            
            if len(high_vulns) > 10:
                output.append(f"\n*Showing top 10 of {len(high_vulns)} high severity vulnerabilities*\n")
        
        # Categorization by agent (if many vulns)
        if len(correlated_data) > 20:
            output.append("### 🖥️ Vulnerabilities by Agent")
            output.append("")
            by_agent = self._group_by_agent(correlated_data)
            
            # Top 5 most vulnerable agents
            sorted_agents = sorted(by_agent.items(), key=lambda x: len(x[1]), reverse=True)[:5]
            for agent_name, agent_vulns in sorted_agents:
                vuln_counts = self._count_severities(agent_vulns)
                output.append(
                    f"- **{agent_name}**: {len(agent_vulns)} total "
                    f"(Critical: {vuln_counts['Critical']}, High: {vuln_counts['High']})"
                )
            output.append("")
        
        # Remediation guidance
        if include_remediation and critical_vulns:
            output.append("### ✅ Recommended Actions")
            output.append("")
            output.append("**IMMEDIATE (< 24 hours):**")
            
            for i, vuln in enumerate(critical_vulns[:3], 1):
                cve = vuln.get("cve_id", "Unknown")
                agent = vuln.get("agent", {}).get("name", "Unknown")
                package = vuln.get("package", {}).get("name", "Unknown")
                
                output.append(f"{i}. **{cve}** on `{agent}`")
                output.append(f"   - Affected package: `{package}`")
                output.append(f"   - Action: Apply vendor security patch immediately")
                output.append(f"   - Risk: {', '.join(vuln.get('risk_factors', ['High priority']))}")
                output.append("")
            
            output.append("**SCHEDULED (< 7 days):**")
            output.append(f"- Patch {len(high_vulns)} high-severity vulnerabilities")
            output.append("- Review and apply security updates during maintenance window")
            output.append("")
        
        return "\n".join(output)
    
    def format_agent_status_response(
        self,
        correlated_data: List[Dict[str, Any]],
        summary: Dict[str, Any],
        status_filter: Optional[str] = None
    ) -> str:
        """
        Format agent status with vulnerability correlation.
        
        Handles:
        - Active vs disconnected filtering
        - Risk scoring
        - Vulnerability counts per agent
        """
        
        output = ["## 💻 Agent Status Report\n"]
        
        # Summary
        output.append("### 📊 Summary")
        output.append(f"- **Total Agents**: {summary.get('total_agents', 0)}")
        output.append(f"- **Agents with Vulnerabilities**: {summary.get('agents_with_vulnerabilities', 0)}")
        output.append(f"- **High Risk Agents**: {summary.get('high_risk_agents', 0)}")
        output.append("")
        
        # Filter agents by status if specified
        if status_filter:
            filtered_agents = [a for a in correlated_data if a.get("status") == status_filter]
            output.append(f"### 🔍 Filtered View: {status_filter.capitalize()} Agents Only")
            output.append(f"*Showing {len(filtered_agents)} of {len(correlated_data)} agents*\n")
            agents_to_display = filtered_agents
        else:
            agents_to_display = correlated_data
        
        # High risk agents table
        high_risk = [a for a in agents_to_display if a.get("risk_score", 0) > 70]
        if high_risk:
            output.append("### 🚨 High Risk Agents")
            output.append("")
            output.append(self._format_agent_table(high_risk))
        
        # Active agents
        active_agents = [a for a in agents_to_display if a.get("status") == "active"]
        if active_agents and (not status_filter or status_filter == "active"):
            output.append("### ✅ Active Agents")
            output.append("")
            output.append(self._format_agent_table(active_agents[:15]))
            
            if len(active_agents) > 15:
                output.append(f"\n*Showing top 15 of {len(active_agents)} active agents*\n")
        
        # Disconnected agents
        disconnected_agents = [a for a in agents_to_display if a.get("status") == "disconnected"]
        if disconnected_agents and (not status_filter or status_filter == "disconnected"):
            output.append("### ⚠️ Disconnected Agents")
            output.append("")
            output.append(self._format_agent_table(disconnected_agents[:15]))
            
            if len(disconnected_agents) > 15:
                output.append(f"\n*Showing top 15 of {len(disconnected_agents)} disconnected agents*\n")
        
        return "\n".join(output)
    
    def format_alert_response(
        self,
        correlated_data: List[Dict[str, Any]],
        summary: Dict[str, Any]
    ) -> str:
        """Format security alerts with agent context"""
        
        output = ["## 🚨 Security Alerts\n"]
        
        # Summary
        output.append("### 📊 Summary")
        output.append(f"- **Total Alerts**: {summary.get('total_alerts', 0)}")
        output.append(f"- **Unique Agents**: {summary.get('unique_agents', 0)}")
        
        by_level = summary.get("by_level", {})
        output.append(f"- **By Level**:")
        for level in sorted(by_level.keys(), key=lambda x: int(x) if x.isdigit() else 0, reverse=True):
            output.append(f"  - Level {level}: {by_level[level]}")
        output.append("")
        
        # High-level alerts (12+)
        high_level = [a for a in correlated_data if a.get("level", 0) >= 12]
        if high_level:
            output.append("### 🔴 Critical Alerts (Level 12+)")
            output.append("")
            output.append(self._format_alert_table(high_level[:10]))
        
        # Medium-level alerts (7-11)
        medium_level = [a for a in correlated_data if 7 <= a.get("level", 0) < 12]
        if medium_level:
            output.append("### 🟡 Important Alerts (Level 7-11)")
            output.append("")
            output.append(self._format_alert_table(medium_level[:10]))
        
        return "\n".join(output)
    
    def format_general_response(
        self,
        data: Any,
        title: str = "Response"
    ) -> str:
        """Format generic data response"""
        
        output = [f"## {title}\n"]
        
        if isinstance(data, dict):
            if "summary" in data:
                output.append("### Summary")
                output.append(self._format_dict_as_list(data["summary"]))
                output.append("")
            
            if "data" in data:
                output.append("### Data")
                output.append(f"```json\n{json.dumps(data['data'], indent=2)[:1000]}\n```")
        elif isinstance(data, list):
            output.append(f"*Found {len(data)} items*\n")
            output.append(f"```json\n{json.dumps(data[:5], indent=2)}\n```")
        else:
            output.append(f"```\n{str(data)[:1000]}\n```")
        
        return "\n".join(output)
    
    # ================================================================
    # TABLE FORMATTERS
    # ================================================================
    
    def _format_vulnerability_table(self, vulns: List[Dict]) -> str:
        """Format vulnerabilities as markdown table"""
        
        lines = [
            "| CVE ID | Severity | CVSS | Agent | Package | Status |",
            "|--------|----------|------|-------|---------|--------|"
        ]
        
        for v in vulns:
            agent_name = v.get("agent", {}).get("name", "N/A")
            package_name = v.get("package", {}).get("name", "N/A")
            cvss = v.get("cvss", "N/A")
            
            lines.append(
                f"| {v.get('cve_id', 'N/A')} | "
                f"{v.get('severity', 'N/A')} | "
                f"{cvss} | "
                f"{agent_name} | "
                f"{package_name} | "
                f"{v.get('status', 'N/A')} |"
            )
        
        return "\n".join(lines)
    
    def _format_agent_table(self, agents: List[Dict]) -> str:
        """Format agents as markdown table"""
        
        lines = [
            "| Agent | IP | OS | Status | Risk | Vulnerabilities |",
            "|-------|----|----|--------|------|-----------------|"
        ]
        
        for a in agents:
            vuln_summary = a.get("vulnerability_summary", {})
            vuln_str = f"C:{vuln_summary.get('critical', 0)} H:{vuln_summary.get('high', 0)}"
            
            status_icon = "✅" if a.get("status") == "active" else "❌"
            risk = a.get("risk_score", 0)
            risk_icon = "🔴" if risk > 70 else ("🟡" if risk > 30 else "🟢")
            
            lines.append(
                f"| {a.get('name', 'N/A')} | "
                f"{a.get('ip', 'N/A')} | "
                f"{a.get('os', 'N/A')} | "
                f"{status_icon} {a.get('status', 'N/A')} | "
                f"{risk_icon} {risk} | "
                f"{vuln_str} |"
            )
        
        return "\n".join(lines)
    
    def _format_alert_table(self, alerts: List[Dict]) -> str:
        """Format alerts as markdown table"""
        
        lines = [
            "| Time | Level | Description | Agent | Tactic |",
            "|------|-------|-------------|-------|--------|"
        ]
        
        for a in alerts:
            timestamp = a.get("timestamp", "N/A")
            if timestamp != "N/A":
                timestamp = timestamp[:19].replace("T", " ")
            
            description = a.get("rule_description", "N/A")
            if len(description) > 50:
                description = description[:47] + "..."
            
            tactics = a.get("mitre_tactics", [])
            tactic_str = tactics[0] if tactics else "N/A"
            
            lines.append(
                f"| {timestamp} | "
                f"{a.get('level', 'N/A')} | "
                f"{description} | "
                f"{a.get('agent', {}).get('name', 'N/A')} | "
                f"{tactic_str} |"
            )
        
        return "\n".join(lines)
    
    # ================================================================
    # HELPER METHODS
    # ================================================================
    
    def _group_by_agent(self, vulns: List[Dict]) -> Dict[str, List[Dict]]:
        """Group vulnerabilities by agent"""
        grouped = {}
        for vuln in vulns:
            agent_name = vuln.get("agent", {}).get("name", "Unknown")
            if agent_name not in grouped:
                grouped[agent_name] = []
            grouped[agent_name].append(vuln)
        return grouped
    
    def _count_severities(self, vulns: List[Dict]) -> Dict[str, int]:
        """Count vulnerabilities by severity"""
        counts = {"Critical": 0, "High": 0, "Medium": 0, "Low": 0}
        for vuln in vulns:
            severity = vuln.get("severity", "Low")
            if severity in counts:
                counts[severity] += 1
        return counts
    
    def _format_dict_as_list(self, d: Dict) -> str:
        """Format dictionary as bullet list"""
        lines = []
        for key, value in d.items():
            lines.append(f"- **{key}**: {value}")
        return "\n".join(lines)
