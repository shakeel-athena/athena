/**
 * BlockParser — Pattern-detection layer for Pallas response markdown
 *
 * Splits a markdown response into a sequence of typed blocks. Each block
 * carries:
 *   - type:   discriminant string ('kpi_grid', 'severity_breakdown', 'agent_table', ...)
 *   - data:   parsed/structured payload for the renderer
 *   - raw:    the original lines (used for prose fallback)
 *   - start:  starting line index (for debugging)
 *   - end:    ending line index (for debugging)
 *
 * The renderer (ResponseBlockRenderer) maps each block.type to a specialized
 * React component. Unmatched content falls through to the existing
 * PallasMarkdown renderer via the 'prose' block type — ZERO regression for
 * any response we don't yet recognize.
 *
 * Detection is intentionally conservative — when in doubt, fall through to
 * prose. Don't graphify text that wasn't meant to be a chart.
 */

// ─── Block type constants ───────────────────────────────────────────────────

export const BLOCK_TYPES = {
  KPI_GRID:           'kpi_grid',
  SEVERITY_BREAKDOWN: 'severity_breakdown',
  AGENT_TABLE:        'agent_table',
  VULN_TABLE:         'vulnerability_table',
  RULE_TABLE:         'rule_table',
  TOP_ATTACKERS:      'top_attackers',
  TIME_SERIES:        'time_series',
  RISK_SCORE:         'risk_score',
  HEALTH_STATUS:      'health_status',
  RECOMMENDATIONS:    'recommendations',
  CODE_BLOCK:         'code_block',
  MITRE_MATRIX:       'mitre_matrix',
  BADGE_CLOUD:        'badge_cloud',
  TIMELINE:           'timeline',
  FLOW_DIAGRAM:       'flow_diagram',
  COMPARISON:         'comparison',
  PROSE:              'prose',
};

// ─── Helpers ─────────────────────────────────────────────────────────────────

const SEV_COLORS = {
  critical: '#EF4444',
  high:     '#F97316',
  medium:   '#F59E0B',
  low:      '#64748B',
};

function isBlankLine(line) {
  return !line || !line.trim();
}

function isHeaderLine(line) {
  const t = (line || '').trim();
  return /^#{1,6}\s+/.test(t);
}

function stripHeader(line) {
  return (line || '').trim().replace(/^#{1,6}\s+/, '').trim();
}

function parseTableRow(line) {
  // "| a | b | c |" -> ["a","b","c"]
  return line.split('|').map(c => c.trim()).filter(c => c.length > 0);
}

function isTableLine(line) {
  return (line || '').trim().startsWith('|');
}

function isTableSeparator(line) {
  // | --- | --- |
  return /^\s*\|?[\s|:-]+\|?\s*$/.test(line || '') && (line || '').includes('-');
}

function parseInt0(s) {
  if (s == null) return 0;
  const m = String(s).replace(/[,\s]/g, '').match(/^-?\d+/);
  return m ? parseInt(m[0], 10) : 0;
}

function looksLikeNumber(s) {
  return /^-?\d[\d,\s]*(\.\d+)?\s*%?$/.test((s || '').trim());
}

// ─── Detector: Code block ───────────────────────────────────────────────────
// Highest priority — we never want to scan inside code fences for other patterns

function tryCodeBlock(lines, i) {
  const line = lines[i];
  if (!line || !line.trim().startsWith('```')) return null;

  const lang = line.trim().slice(3).trim();
  const codeLines = [];
  let j = i + 1;
  while (j < lines.length && !lines[j].trim().startsWith('```')) {
    codeLines.push(lines[j]);
    j++;
  }
  // include closing fence
  const end = Math.min(j, lines.length - 1);

  return {
    type: BLOCK_TYPES.CODE_BLOCK,
    data: {
      language: lang || null,
      code: codeLines.join('\n'),
    },
    raw: lines.slice(i, end + 1),
    start: i,
    end,
  };
}

// ─── Detector: Severity breakdown line ──────────────────────────────────────
// Matches patterns like:
//   "🔴 Critical: 21 | 🟠 High: 188 | 🟡 Medium: 23990 | 🟢 Low: 2008"
//   "Critical: 21 · High: 188 · Medium: 23990 · Low: 2008"
//   "Critical 21 / High 188 / Medium 23990 / Low 2008"

const SEVERITY_KEYWORDS = ['critical', 'high', 'medium', 'low', 'info', 'informational'];

function tryDetectSeverityBreakdown(lines, i) {
  const line = lines[i];
  if (!line) return null;
  const t = line.trim();
  if (t.length < 10) return null;

  // Must contain at least 2 severity keywords with adjacent numbers
  const lc = t.toLowerCase();
  const found = SEVERITY_KEYWORDS.filter(k => lc.includes(k));
  if (found.length < 2) return null;

  // Try to extract pairs: word + number
  // Strategy: split by common separators (|, ·, /, ;) and parse each chunk.
  // Also try comma-separated: "Critical: 21, High: 188, Medium: 23990"
  let chunks = t.split(/\s*[|·•/;]\s*/).filter(Boolean);
  if (chunks.length < 2) {
    // Retry with comma separator — but only when each chunk has a colon/= inside
    const commaChunks = t.split(/\s*,\s*/).filter(Boolean);
    if (commaChunks.length >= 2 && commaChunks.every(c => /[:=]/.test(c))) {
      chunks = commaChunks;
    }
  }
  if (chunks.length < 2) return null;

  const segments = [];
  for (const chunk of chunks) {
    // Extract trailing number
    const m = chunk.match(/([🔴🟠🟡🟢⚫⚪]?\s*)([A-Za-z]+)(?:\s*[:=]?\s*)([0-9][0-9,]*)\s*$/);
    if (!m) continue;
    const label = m[2].toLowerCase();
    if (!SEVERITY_KEYWORDS.includes(label)) continue;
    const value = parseInt0(m[3]);
    segments.push({
      label: label.charAt(0).toUpperCase() + label.slice(1),
      key:   label,
      value,
      color: SEV_COLORS[label] || SEV_COLORS.low,
    });
  }

  if (segments.length < 2) return null;
  const total = segments.reduce((a, b) => a + b.value, 0);
  if (total === 0) return null;

  return {
    type: BLOCK_TYPES.SEVERITY_BREAKDOWN,
    data: { segments, total },
    raw: [line],
    start: i,
    end: i,
  };
}

// ─── Detector: KPI grid ─────────────────────────────────────────────────────
// Matches patterns like:
//   Total Alerts: 26,207
//   Critical: 21
//   Total Vulnerabilities: 98,158
//
// Looks for 2-6 consecutive lines that each match "Label: Number" or
// "Total Label NUMBER" patterns. These usually appear after a section header
// like "## Alert Summary" — we use that header (if present) as the group title.

// Matches "Label: 123" or "Label = 14.3%" or "**Label**: 26,207"
// Also handles trailing parentheticals: "Total Agents: 49 (excluding manager)"
// And pipe-separated multi-KPIs on one line: "**Total:** 49 | **Active:** 7"
// Used inside tryDetectKPIGrid's segment loop.
// Handles bold labels where the colon can be inside or outside the bold:
//   "**Total Agents:** 49"  ← colon inside bold
//   "**Total Agents**: 49"  ← colon outside bold
//   "Total Agents: 49"      ← no bold
// Also handles parenthetical suffixes and trailing text after the number.
const KPI_SEGMENT_RE = /^(?:[*•-]\s*)?\*{0,2}([A-Za-z][A-Za-z0-9 /()&]+?)\s*[:=]?\s*\*{0,2}\s*[:=]?\s*\*{0,2}([0-9][0-9,]*(?:\.\d+)?\s*%?)\*{0,2}(?:\s*\(.*?\))?(?:\s+\S.*)?$/;

// Reject KPI groups that are clearly garbage from over-eager pattern matching.
// Triggered cases observed in production:
//   - Ports formatter emitted "**Adobe Desktop Service:** 6 (TCP)" × 14 lines → 14 cards "6 TCP"
//   - Ports prose emitted "**Port 63138:**" → card with port-number-as-value
//   - Inventory table rendered each network interface as its own KPI (UTUN × 4, EN × 1, …)
//   - All-zero rows ("0 AWDL, 0 EN, 0 LLW") carry no information
function isJunkKPIGroup(items) {
  if (!items || items.length === 0) return true;

  // 1. Duplicate labels — same label appearing more than once means we're
  //    iterating table rows, not extracting distinct metrics. Drop the group.
  const labelCounts = new Map();
  for (const it of items) {
    const k = String(it.label || '').toLowerCase().trim();
    labelCounts.set(k, (labelCounts.get(k) || 0) + 1);
  }
  for (const c of labelCounts.values()) {
    if (c > 1) return true;
  }

  // 2. All values are zero (and no percentages) — useless as a headline metric.
  const allZero = items.every(it => !it.is_percent && (it.value === 0 || it.value == null));
  if (allZero) return true;

  // 3. Values look like port numbers / IDs / timestamps rather than counts.
  //    Heuristic: label is single short word like "Port" / "ID" / "CVE" AND
  //    value is a large arbitrary integer (>= 1024, common port-range threshold).
  const idLikeLabel = /^(port|ports?|id|ids?|cve|pid|tid|uid|gid|fd|sid)$/i;
  const looksLikeIdentifier = items.every(it =>
    idLikeLabel.test(String(it.label || '').trim()) &&
    !it.is_percent &&
    typeof it.value === 'number' && it.value >= 1024
  );
  if (looksLikeIdentifier) return true;

  return false;
}

function tryDetectKPIGrid(lines, i) {
  // Allow an optional header line as the group title (## Foo or ### Foo)
  let titleLine = null;
  let scanFrom = i;
  if (isHeaderLine(lines[i])) {
    titleLine = stripHeader(lines[i]);
    scanFrom = i + 1;
    // skip blank lines after header
    while (scanFrom < lines.length && isBlankLine(lines[scanFrom])) scanFrom++;
  }

  // 4. Don't try to extract KPIs from inside markdown tables — table rows
  //    look like "| Name | 6 | active |" and the parser would treat each row
  //    as a "Name: 6" KPI, producing one card per row. Tables go to
  //    tryDetectTable; let it handle them.
  if (scanFrom < lines.length && isTableLine(lines[scanFrom])) return null;

  const items = [];
  let j = scanFrom;
  let consecutiveBlanks = 0;

  while (j < lines.length) {
    const line = lines[j];
    if (isBlankLine(line)) {
      consecutiveBlanks++;
      if (consecutiveBlanks > 1) break;
      j++;
      continue;
    }
    consecutiveBlanks = 0;

    // Stop if we hit a markdown table — that's a different block type.
    if (isTableLine(line)) break;

    // Guard: don't consume standalone health lines — they should go to the health detector.
    // But allow pipe-separated lines that CONTAIN health as one of multiple KPIs.
    if (!line.includes('|') && /(?:Agent|Infrastructure|System)\s+Health\s*[:=]?\s*\D*?\d+(?:\.\d+)?\s*%\s*online/i.test(line.trim())) {
      break;
    }

    // Try splitting by pipe first — handles "**Total:** 49 | **Active:** 7 | **Health:** 92%"
    const segments = line.trim().split(/\s*\|\s*/).filter(Boolean);
    let matched = false;

    for (const seg of segments) {
      const m = seg.trim().match(KPI_SEGMENT_RE);
      if (!m) continue;
      const label = m[1].trim();
      const value = m[2].trim();
      if (!looksLikeNumber(value)) continue;
      items.push({
        label,
        value: parseInt0(value),
        raw_value: value,
        is_percent: value.includes('%'),
      });
      matched = true;
    }

    if (!matched) break;
    j++;
    if (items.length >= 12) break;  // cap at 12 KPIs
  }

  // Need at least 2 KPI items to be a "grid", OR 1 item if the section header
  // contains summary-related keywords. This prevents numbered headings like
  // "## 1. GITHUB VULNERABILITY ALERT" + "12 LEVEL" from creating giant KPI tiles.
  if (items.length === 0) return null;
  if (items.length === 1 && !titleLine) return null;
  if (items.length === 1 && titleLine) {
    const t = titleLine.toLowerCase();
    const isSummaryTitle = /summary|overview|total|health|status|score|assessment|distribution|breakdown|statistics|report|pattern|analysis/.test(t);
    if (!isSummaryTitle) return null;
  }

  // Final guard: reject groups that match known garbage shapes (duplicate
  // labels, all-zero, port-numbers-as-values). See isJunkKPIGroup.
  if (isJunkKPIGroup(items)) return null;

  return {
    type: BLOCK_TYPES.KPI_GRID,
    data: {
      title: titleLine,
      items,
    },
    raw: lines.slice(i, j),
    start: i,
    end: j - 1,
  };
}

// ─── Detector: Markdown table (consume + detect type) ───────────────────────
// Consumes consecutive | rows, then inspects column headers to decide:
//   - agent table → BLOCK_TYPES.AGENT_TABLE
//   - vulnerability table → BLOCK_TYPES.VULN_TABLE
//   - rule table → BLOCK_TYPES.RULE_TABLE
//   - top attackers/sources/dest → BLOCK_TYPES.TOP_ATTACKERS
//   - otherwise → null (let the prose fallback render it as a flat HTML table
//     via existing PallasMarkdown)

function tryDetectTable(lines, i) {
  if (!isTableLine(lines[i])) return null;

  const tableLines = [];
  let j = i;
  while (j < lines.length && isTableLine(lines[j])) {
    tableLines.push(lines[j].trim());
    j++;
  }
  if (tableLines.length < 2) return null;

  const headers = parseTableRow(tableLines[0]).map(h => h.toLowerCase());
  const startData = isTableSeparator(tableLines[1]) ? 2 : 1;
  const rows = tableLines.slice(startData).map(parseTableRow);

  // Build structured row objects
  const rowObjects = rows.map((cells, idx) => {
    const obj = { _index: idx };
    headers.forEach((h, hi) => {
      obj[h] = (cells[hi] || '').trim();
    });
    return obj;
  });

  // Classify by header signature
  const headerSet = new Set(headers);
  const hasAny = (...keys) => keys.some(k => headerSet.has(k));
  const hasAll = (...keys) => keys.every(k => headerSet.has(k));

  let type = null;
  let typeData = {};

  // Comparison table?  Exactly 3 columns where first is "metric"/"factor"/"key"
  // and the other two look like state labels (e.g. "Active" + "Disconnected").
  // Most specific check, runs first.
  if (
    headers.length === 3
    && (hasAny('metric', 'factor', 'key', 'attribute', 'feature') || /^(.*\s+vs\s+.*|.*\s+versus\s+.*)$/i.test(headers[0]))
  ) {
    const metricCol = headers.findIndex((h) => ['metric', 'factor', 'key', 'attribute', 'feature'].includes(h));
    const leftLabel  = headers[metricCol === 0 ? 1 : 0];
    const rightLabel = headers[metricCol === 2 ? 1 : 2];

    // Pick accent colors based on label semantics.
    // IMPORTANT: order matters — check "disconnect/offline" BEFORE "connected/online"
    // since "disconnected" contains "connected" as a substring.
    const accentForLabel = (label) => {
      const l = String(label || '').toLowerCase();
      if (/disconnect|offline|inactive|stopped|pending|degraded/.test(l)) return 'warning';
      if (/critical|fail|error|deny|block|breach|unhealthy/.test(l))      return 'danger';
      if (/\bactive\b|healthy|\bonline\b|\bconnected\b|success|allow/.test(l)) return 'success';
      if (/before|previous|baseline|old/.test(l))                          return 'muted';
      if (/after|current|now|new/.test(l))                                 return 'primary';
      return 'primary';
    };

    type = BLOCK_TYPES.COMPARISON;
    typeData = {
      left:  { label: leftLabel,  accent: accentForLabel(leftLabel) },
      right: { label: rightLabel, accent: accentForLabel(rightLabel) },
      metrics: rowObjects.map((r) => {
        const lv = r[leftLabel.toLowerCase()];
        const rv = r[rightLabel.toLowerCase()];
        const lvNum = parseInt0(lv);
        const rvNum = parseInt0(rv);
        return {
          name:       r[headers[metricCol]] || Object.values(r)[metricCol],
          leftValue:  /^\d/.test(String(lv || '')) ? lvNum : (lv || ''),
          rightValue: /^\d/.test(String(rv || '')) ? rvNum : (rv || ''),
        };
      }),
    };

    if (typeData.metrics.length === 0) {
      type = null;
      typeData = {};
    }
  }

  // Agent table?  Common columns: agent id / name / ip / status / os / version
  else if (hasAny('agent id', 'agent_id') && hasAny('name', 'agent name') && hasAny('status', 'state')) {
    type = BLOCK_TYPES.AGENT_TABLE;
    typeData = {
      agents: rowObjects.map(r => ({
        agent_id:    r['agent id'] || r['agent_id'] || r['id'] || '',
        name:        r['name'] || r['agent name'] || '',
        ip:          r['ip'] || r['ip address'] || r['ipaddress'] || '',
        os:          r['os'] || r['operating system'] || '',
        version:     r['version'] || '',
        status:      (r['status'] || r['state'] || '').toLowerCase(),
        last_keep_alive: r['last keep alive'] || r['last seen'] || r['lastkeepalive'] || '',
      })),
    };
  }
  // Vulnerability table?  Common columns: cve / severity / package / agent
  else if (hasAny('cve', 'cve id') && (hasAny('severity', 'level') || hasAny('package', 'name'))) {
    type = BLOCK_TYPES.VULN_TABLE;
    typeData = {
      vulnerabilities: rowObjects.map(r => ({
        cve:         r['cve'] || r['cve id'] || r['cve_id'] || '',
        severity:    (r['severity'] || r['level'] || '').toLowerCase(),
        package:     r['package'] || r['package name'] || r['name'] || '',
        version:     r['version'] || r['package version'] || '',
        agent:       r['agent'] || r['agent name'] || r['affected'] || '',
        description: r['description'] || r['summary'] || r['title'] || '',
      })),
    };
  }
  // Rule table?  Columns: rule id / level / description
  // Conservative: must NOT have a timestamp/time column (those are timelines).
  else if (
    hasAny('rule id', 'rule_id')
    && hasAny('level', 'severity', 'description')
    && !hasAny('timestamp', 'time', 'datetime', 'date')
  ) {
    type = BLOCK_TYPES.RULE_TABLE;
    typeData = {
      rules: rowObjects.map(r => ({
        rule_id:     r['rule id'] || r['rule_id'] || r['id'] || '',
        level:       parseInt0(r['level']) || 0,
        description: r['description'] || r['name'] || '',
        groups:      r['groups'] || r['group'] || '',
        firedtimes:  parseInt0(r['firedtimes'] || r['fired times'] || r['count']),
      })),
    };
  }
  // Network flow table?  Columns: src_ip + dst_ip (+ optional ports / proto / bytes)
  else if (
    hasAny('src ip', 'src_ip', 'source ip', 'source_ip')
    && hasAny('dst ip', 'dst_ip', 'destination ip', 'destination_ip', 'dest ip', 'dest_ip')
  ) {
    type = BLOCK_TYPES.FLOW_DIAGRAM;
    typeData = {
      flows: rowObjects.map((r) => ({
        src_ip:   r['src ip'] || r['src_ip'] || r['source ip'] || r['source_ip'] || '',
        dst_ip:   r['dst ip'] || r['dst_ip'] || r['destination ip'] || r['destination_ip'] || r['dest ip'] || r['dest_ip'] || '',
        src_port: parseInt0(r['src port'] || r['src_port'] || r['source port']) || null,
        dst_port: parseInt0(r['dst port'] || r['dst_port'] || r['destination port'] || r['dest port']) || null,
        proto:    r['proto'] || r['protocol'] || '',
        bytes:    parseInt0(r['bytes'] || r['byte count']) || null,
        packets:  parseInt0(r['packets'] || r['pkts'] || r['packet count']) || null,
        action:   r['action'] || r['verdict'] || '',
      })).filter((f) => f.src_ip && f.dst_ip),
    };
    // Sort by bytes descending if we have byte counts
    if (typeData.flows.some((f) => f.bytes)) {
      typeData.flows.sort((a, b) => (b.bytes || 0) - (a.bytes || 0));
    }
  }
  // Timeline?  Columns: timestamp + severity + description (alert sequences)
  // Distinguish from agent/vuln/rule tables: this MUST have a timestamp
  // column AND (severity OR rule description) but NOT agent ID columns.
  else if (
    hasAny('timestamp', 'time', 'datetime', 'date')
    && (hasAny('severity', 'level') || hasAny('description', 'event', 'message', 'alert'))
    && !hasAny('agent id', 'agent_id', 'cve', 'cve id')
    && rowObjects.length >= 1
  ) {
    type = BLOCK_TYPES.TIMELINE;
    typeData = {
      events: rowObjects.map((r) => {
        const sev = (r['severity'] || r['level'] || '').toLowerCase();
        // If level is numeric (Wazuh-style), map to severity
        let normSev = sev;
        const lvl = parseInt0(sev);
        if (lvl >= 12) normSev = 'critical';
        else if (lvl >= 8) normSev = 'high';
        else if (lvl >= 4) normSev = 'medium';
        else if (lvl >= 1) normSev = 'low';
        else if (!normSev) normSev = 'info';

        return {
          timestamp: r['timestamp'] || r['time'] || r['datetime'] || r['date'] || '',
          severity:  normSev,
          title:     r['description'] || r['event'] || r['message'] || r['alert'] || r['rule description'] || '',
          detail:    [
            r['rule id'] && `rule ${r['rule id']}`,
            r['agent'] && `agent ${r['agent']}`,
            r['source ip'] && `src ${r['source ip']}`,
            r['source'] && `source ${r['source']}`,
          ].filter(Boolean).join(' · '),
          rule_id:   r['rule id'] || r['rule_id'] || '',
          agent:     r['agent'] || '',
        };
      }).filter((e) => e.title || e.timestamp),
    };
  }
  // MITRE matrix?  Columns: tactic / technique / count
  else if (
    (hasAny('tactic', 'tactic id', 'mitre tactic') && hasAny('technique', 'technique id', 'mitre technique'))
    || (hasAny('tactic') && hasAny('count', 'alerts'))
  ) {
    // Group rows by tactic
    const tacticMap = new Map();  // tacticName → { id, name, techniques }
    rowObjects.forEach((r) => {
      const tacticName  = r['tactic'] || r['tactic id'] || r['mitre tactic'] || 'Uncategorized';
      const tacticId    = r['tactic id'] || (tacticName.match(/TA\d{4}/i)?.[0] ?? '');
      const techniqueId = r['technique id'] || r['technique'] || r['mitre technique'] || r['id'] || '';
      const techniqueName = r['technique name'] || r['name'] || (r['technique'] !== techniqueId ? r['technique'] : '') || '';
      const count = parseInt0(r['count'] || r['alerts'] || r['hits'] || r['frequency']);

      if (!techniqueId) return;
      if (!tacticMap.has(tacticName)) {
        tacticMap.set(tacticName, { id: tacticId, name: tacticName, techniques: [] });
      }
      tacticMap.get(tacticName).techniques.push({
        id: String(techniqueId).replace(/[^A-Z0-9.]/gi, ''),
        name: techniqueName,
        count,
      });
    });

    if (tacticMap.size > 0) {
      type = BLOCK_TYPES.MITRE_MATRIX;
      typeData = {
        tactics: Array.from(tacticMap.values()),
      };
    }
  }
  // Top attackers/sources/destinations?  Columns: ip + count
  else if (
    hasAll('source ip', 'alert count') ||
    hasAll('destination ip', 'alert count') ||
    hasAll('ip', 'count') ||
    (hasAny('source ip', 'destination ip', 'src ip', 'dst ip', 'src_ip', 'dst_ip') &&
     hasAny('count', 'alerts', 'alert count', 'hits'))
  ) {
    const isDest = hasAny('destination ip', 'dst ip', 'dst_ip');
    type = BLOCK_TYPES.TOP_ATTACKERS;
    typeData = {
      kind: isDest ? 'targets' : 'sources',
      entries: rowObjects.map(r => ({
        ip:    r['source ip'] || r['destination ip'] || r['ip'] || r['src ip'] || r['dst ip'] || r['src_ip'] || r['dst_ip'] || '',
        count: parseInt0(r['alert count'] || r['count'] || r['alerts'] || r['hits']),
      })).filter(e => e.ip).sort((a, b) => b.count - a.count),
    };
  }
  // Time series? Columns include a timestamp/date/hour and a numeric column
  else if (
    hasAny('date', 'time', 'hour', 'day', 'timestamp', 'datetime', 'period')
    && headers.length >= 2
  ) {
    const timeCol = headers.findIndex(h =>
      ['date', 'time', 'hour', 'day', 'timestamp', 'datetime', 'period'].includes(h)
    );
    // Pick the first numeric column that isn't the time column
    let valCol = -1;
    for (let h = 0; h < headers.length; h++) {
      if (h === timeCol) continue;
      // Check if this column is numeric across the rows
      const allNumeric = rows.length > 0 && rows.every((r) => {
        const v = String(r[h] || '').replace(/[,\s%]/g, '');
        return /^-?\d+(\.\d+)?$/.test(v);
      });
      if (allNumeric) { valCol = h; break; }
    }
    if (timeCol >= 0 && valCol >= 0) {
      const points = rows
        .map((r) => ({
          label: (r[timeCol] || '').toString(),
          value: parseInt0(r[valCol]),
        }))
        .filter((p) => p.label);
      if (points.length >= 2) {
        type = BLOCK_TYPES.TIME_SERIES;
        typeData = {
          points,
          metricLabel: headers[valCol],
          timeLabel:   headers[timeCol],
        };
      }
    }
  }

  if (!type) return null;  // Unrecognized table → fall through to prose

  return {
    type,
    data: { ...typeData, headers, rowCount: rowObjects.length },
    raw: lines.slice(i, j),
    start: i,
    end: j - 1,
  };
}

// ─── Detector: Recommendations list ─────────────────────────────────────────
// Header "Recommendations" / "Recommended Actions" / "Priority Actions"
// followed by a numbered or bulleted list

const RECOMMENDATION_HEADERS = [
  'recommendations', 'recommended actions', 'priority actions',
  'action required', 'next steps', 'recommended action',
  'key findings', 'threat indicators', 'findings',
  'remediation steps', 'mitigation', 'corrective actions',
];

function tryDetectRecommendations(lines, i) {
  const line = lines[i];
  if (!line) return null;

  // Accept both markdown headers (## Recommendations) and bold/plain prefixes
  // ("Recommended Actions:" or "**Next Steps**:")
  let title;
  if (isHeaderLine(line)) {
    title = stripHeader(line).toLowerCase();
  } else {
    // Strip bold markers and trailing colon: "**Recommended Actions**:" → "recommended actions"
    const cleaned = line.trim().replace(/^\*{1,2}|\*{1,2}$/g, '').replace(/\s*:\s*$/, '').trim().toLowerCase();
    title = cleaned;
  }
  if (!RECOMMENDATION_HEADERS.some(h => title.includes(h))) return null;

  const items = [];
  let j = i + 1;
  while (j < lines.length && isBlankLine(lines[j])) j++;

  // Consume numbered or bulleted list lines.
  // Also accept plain continuation text after the header (common when the LLM
  // writes "Action Required:\n43 agents need investigation.\nCheck: X, Y, Z"
  // without bullets). We accept up to 6 plain lines as individual items,
  // stopping at a new section header or blank gap.
  let consecutiveBlanks = 0;
  while (j < lines.length) {
    const t = lines[j].trim();
    if (isBlankLine(lines[j])) {
      consecutiveBlanks++;
      if (consecutiveBlanks > 1) break;  // double blank = new section
      j++;
      continue;
    }
    consecutiveBlanks = 0;

    if (isHeaderLine(lines[j])) break;  // new section starts

    const m = t.match(/^(?:(\d+)\.|[-*•])\s+(.+)$/);
    if (m) {
      items.push(m[2].trim());
    } else if (t.length > 10 && items.length < 6) {
      // Plain text continuation — treat as an action item
      items.push(t);
    } else {
      break;
    }
    j++;
    if (items.length >= 12) break;
  }

  if (items.length < 1) return null;

  // Heuristic priority assignment: first 1-2 = critical/high, rest = medium
  const recommendations = items.map((text, idx) => ({
    text,
    priority: idx === 0 ? 'critical' : idx === 1 ? 'high' : idx <= 3 ? 'medium' : 'low',
  }));

  return {
    type: BLOCK_TYPES.RECOMMENDATIONS,
    data: { recommendations },
    raw: lines.slice(i, j),
    start: i,
    end: j - 1,
  };
}

// ─── Detector: Risk score card ──────────────────────────────────────────────
// Looks for "Overall Risk: [HIGH|MEDIUM|LOW|CRITICAL]" or "Risk Score: NNN"

function tryDetectRiskScore(lines, i) {
  const line = lines[i];
  if (!line) return null;
  const t = line.trim();

  // Pattern 1: "Overall Risk: HIGH (Score: 836)"
  // Pattern 2: "Risk Score: 836"
  // Pattern 3: "Overall Risk: [HIGH] (Score: 836)"
  let level = null;
  let score = null;
  let max = 1000;

  // Handles: "Overall Risk: HIGH (Score: 830)", "Overall Risk: [HIGH] High (Score: 830)",
  // "Risk: CRITICAL", "Overall Risk: [HIGH|HIGH] (Score: 830)", "Risk Score: 830/1000"
  const m1 = t.match(/(?:Overall\s+)?Risk\s*[:=]\s*\[?(CRITICAL|HIGH|MEDIUM|LOW)\]?[\s|]?(?:CRITICAL|HIGH|MEDIUM|LOW)?\s*(?:\(\s*Score\s*[:=]\s*(\d+)\s*(?:\/\s*(\d+))?\s*\))?/i);
  if (m1) {
    level = m1[1].toLowerCase();
    if (m1[2]) score = parseInt(m1[2], 10);
    if (m1[3]) max = parseInt(m1[3], 10);
    // If no score in parens, try to find "Score: NNN" anywhere on the same line
    if (score == null) {
      const scoreMatch = t.match(/Score\s*[:=]\s*(\d+)\s*(?:\/\s*(\d+))?/i);
      if (scoreMatch) {
        score = parseInt(scoreMatch[1], 10);
        if (scoreMatch[2]) max = parseInt(scoreMatch[2], 10);
      }
    }
  } else {
    const m2 = t.match(/Risk\s*Score\s*[:=]\s*(\d+)\s*(?:\/\s*(\d+))?/i);
    if (m2) {
      score = parseInt(m2[1], 10);
      if (m2[2]) max = parseInt(m2[2], 10);
      // Derive level from score
      const pct = score / max;
      if (pct >= 0.8) level = 'critical';
      else if (pct >= 0.6) level = 'high';
      else if (pct >= 0.3) level = 'medium';
      else level = 'low';
    }
  }

  if (level == null) return null;

  return {
    type: BLOCK_TYPES.RISK_SCORE,
    data: { level, score, max },
    raw: [line],
    start: i,
    end: i,
  };
}

// ─── Detector: Health status ────────────────────────────────────────────────
// "Agent Health: 🔴 8% online" or "Infrastructure Health: 8% online"

function tryDetectHealthStatus(lines, i) {
  const line = lines[i];
  if (!line) return null;
  const t = line.trim();

  // Strip leading emojis/symbols/whitespace BEFORE regex match — easier than
  // trying to match them inside a character class (emoji surrogate pairs are
  // tricky in JS regex without the `u` flag).
  // Pattern: "Agent Health: 8% online" or "Agent Health 8% online"
  const m = t.match(/(Agent|Infrastructure|System)\s+Health\s*[:=]?\s*\D*?(\d+(?:\.\d+)?)\s*%\s*online/i);
  if (!m) return null;

  const percentage = parseFloat(m[2]);

  // Look backward AND forward up to 8 lines for "Total Agents: X / Active: Y /
  // Disconnected: Z" patterns so the donut chart has segment counts.
  let total = null, active = null, disconnected = null, neverConnected = null;
  const lookbackStart = Math.max(0, i - 8);
  const lookforwardEnd = Math.min(lines.length, i + 8);
  for (let k = lookbackStart; k < lookforwardEnd; k++) {
    if (k === i) continue;  // skip the health line itself
    const lt = (lines[k] || '').trim();
    if (!lt) continue;
    const mTotal = lt.match(/^\*{0,2}Total\s+(?:Agents?)?\*{0,2}\s*[:=]\s*\*{0,2}(\d[\d,]*)\*{0,2}\s*$/i);
    if (mTotal) total = parseInt(mTotal[1].replace(/,/g, ''), 10);
    const mActive = lt.match(/^\*{0,2}Active\*{0,2}\s*[:=]\s*\*{0,2}(\d[\d,]*)\*{0,2}\s*$/i);
    if (mActive) active = parseInt(mActive[1].replace(/,/g, ''), 10);
    const mDisc = lt.match(/^\*{0,2}Disconnected\*{0,2}\s*[:=]\s*\*{0,2}(\d[\d,]*)\*{0,2}\s*$/i);
    if (mDisc) disconnected = parseInt(mDisc[1].replace(/,/g, ''), 10);
    const mNever = lt.match(/^\*{0,2}Never\s+Connected\*{0,2}\s*[:=]\s*\*{0,2}(\d[\d,]*)\*{0,2}\s*$/i);
    if (mNever) neverConnected = parseInt(mNever[1].replace(/,/g, ''), 10);
  }

  // Derive missing values where possible
  if (total != null && active != null && disconnected == null && neverConnected == null) {
    // Only have total + active → derive disconnected as the rest
    disconnected = Math.max(0, total - active);
  }

  return {
    type: BLOCK_TYPES.HEALTH_STATUS,
    data: {
      label: `${m[1]} Health`,
      percentage,
      total,
      active,
      disconnected,
      neverConnected,
    },
    raw: [line],
    start: i,
    end: i,
  };
}

// ─── Detector: Badge cloud (MITRE / compliance / rule groups inline lists) ─
//
// Matches lines like:
//   "MITRE: T1190, T1133, T1059"
//   "MITRE ATT&CK Techniques: T1190 (Exploit Public-Facing App), T1133"
//   "Compliance: PCI-DSS 10.2.5, HIPAA 164.312.b, NIST AU.14"
//   "PCI-DSS: 10.2.5, 11.4"
//   "Rule Groups: pam, syslog, authentication_failed"
//
// Conservative — only matches when the prefix is one of the known framework
// keywords AND the value list contains 2+ comma-separated items.

const BADGE_LINE_PATTERNS = [
  // MITRE ATT&CK
  { framework: 'mitre',    re: /^(?:MITRE(?:\s+ATT&?CK)?|MITRE\s+Tactics?|MITRE\s+Techniques?|ATT&?CK)\s*[:=]\s*(.+)$/i, parser: parseMitreList },
  // Compliance frameworks (each can appear standalone)
  { framework: 'pci',      re: /^(?:PCI[-\s]?DSS|PCI)\s*[:=]\s*(.+)$/i,      parser: parseControlList },
  { framework: 'hipaa',    re: /^HIPAA\s*[:=]\s*(.+)$/i,                       parser: parseControlList },
  { framework: 'nist',     re: /^(?:NIST(?:\s+800-?53)?)\s*[:=]\s*(.+)$/i,    parser: parseControlList },
  { framework: 'gdpr',     re: /^GDPR\s*[:=]\s*(.+)$/i,                        parser: parseControlList },
  { framework: 'gpg13',    re: /^GPG\s*13\s*[:=]\s*(.+)$/i,                    parser: parseControlList },
  { framework: 'tsc',      re: /^TSC\s*[:=]\s*(.+)$/i,                         parser: parseControlList },
  { framework: 'iso27001', re: /^ISO\s*27001\s*[:=]\s*(.+)$/i,                 parser: parseControlList },
  // Generic compliance summary
  { framework: 'group',    re: /^(?:Rule\s+)?Groups?\s*[:=]\s*(.+)$/i,         parser: parseGroupList },
];

function parseMitreList(value) {
  // Split on commas / pipes / "and"
  // Each item: T1190 or T1190.001 or "T1190 (Exploit Public-Facing App)"
  const tokens = value.split(/\s*[,|]\s*|\s+and\s+/i).map((s) => s.trim()).filter(Boolean);
  const items = [];
  for (const tok of tokens) {
    const m = tok.match(/^\[?(T\d{4}(?:\.\d{3})?|TA\d{4})\]?\s*(?:[(:]\s*([^)]+?)\)?)?$/i);
    if (m) {
      items.push({ id: m[1].toUpperCase(), label: m[2] ? m[2].trim() : '' });
    }
  }
  return items;
}

function parseControlList(value) {
  // Compliance: "10.2.5, 11.4" or "PCI-DSS 10.2.5, HIPAA 164.312.b"
  const tokens = value.split(/\s*[,|]\s*|\s+and\s+/i).map((s) => s.trim()).filter(Boolean);
  const items = [];
  for (const tok of tokens) {
    // Strip optional framework prefix if it leaked through
    const cleaned = tok.replace(/^(?:PCI[-\s]?DSS|HIPAA|NIST(?:\s+800-?53)?|GDPR|GPG\s*13|TSC|ISO\s*27001)\s*/i, '').trim();
    if (cleaned && /^[0-9A-Za-z][\w.-]{1,30}$/.test(cleaned)) {
      items.push({ id: cleaned });
    }
  }
  return items;
}

function parseGroupList(value) {
  const tokens = value.split(/\s*[,|]\s*/).map((s) => s.trim()).filter(Boolean);
  return tokens
    .filter((t) => /^[A-Za-z][\w_-]{1,40}$/.test(t))
    .map((t) => ({ id: t }));
}

function tryDetectBadgeCloud(lines, i) {
  const line = lines[i];
  if (!line) return null;
  const t = line.trim();
  if (t.length < 6) return null;

  // Strip optional markdown bold/italic markers
  const cleaned = t.replace(/^\*+|\*+$/g, '').trim();

  // Try each framework pattern
  for (const pat of BADGE_LINE_PATTERNS) {
    const m = cleaned.match(pat.re);
    if (!m) continue;
    const items = pat.parser(m[1]);
    if (items.length < 2) continue;  // require 2+ items to be a "cloud"
    return {
      type: BLOCK_TYPES.BADGE_CLOUD,
      data: {
        groups: [{ framework: pat.framework, items }],
      },
      raw: [line],
      start: i,
      end: i,
    };
  }

  return null;
}

// ─── Prose fallback (consume contiguous lines that don't match anything) ────
// We greedy-consume until we hit something that COULD start a new block.

function consumeProse(lines, i, detectors) {
  const proseLines = [lines[i]];
  let j = i + 1;
  while (j < lines.length) {
    // Stop if any detector matches at j
    let isStartOfBlock = false;
    for (const detect of detectors) {
      if (detect(lines, j)) { isStartOfBlock = true; break; }
    }
    if (isStartOfBlock) break;
    proseLines.push(lines[j]);
    j++;
    // Cap prose blocks at 60 lines so renderer doesn't choke
    if (proseLines.length >= 60) break;
  }

  return {
    type: BLOCK_TYPES.PROSE,
    data: { content: proseLines.join('\n') },
    raw: proseLines,
    start: i,
    end: j - 1,
  };
}

// ─── Main parser ────────────────────────────────────────────────────────────
// Order matters — earlier detectors win. Code blocks are first because we
// must never scan inside them. Severity breakdown is before KPI grid because
// "Critical: 21" is detected as a KPI item if you look at it line-by-line,
// but "🔴 Critical: 21 | 🟠 High: 188" should be a severity bar.

// ─── Detector: Related queries footer ────────────────────────────────────────
// Backend embeds "**Related queries:** `show X` | `check Y`" in markdown.
// The frontend already renders suggestions as styled chips — strip these lines
// so they don't clutter the prose.

function tryDetectRelatedQueries(lines, i) {
  const t = (lines[i] || '').trim();
  // Match: "**Related queries:**" or "Related queries:" or "---" preceding it
  if (/^\*{0,2}Related\s+quer/i.test(t) || /^\*{0,2}Suggested\s+quer/i.test(t)) {
    // Consume the line (and optional following blank lines)
    let j = i + 1;
    while (j < lines.length && isBlankLine(lines[j])) j++;
    return {
      type: BLOCK_TYPES.PROSE,
      data: { content: '' },  // empty — suppress the duplicated footer
      raw: lines.slice(i, j),
      start: i,
      end: j - 1,
    };
  }
  return null;
}

// ─── Detector: Metadata footer lines ────────────────────────────────────────
// Backend appends "*Selection: pattern_match (92% confidence)*" and
// "*Primary tool: get_wazuh_agents (1.42s)*" etc. — strip these debug lines.

function tryDetectMetadataFooter(lines, i) {
  const t = (lines[i] || '').trim();
  if (/^\*Selection:\s/i.test(t) || /^\*Primary\s+tool:/i.test(t) ||
      /^\*Secondary\s+tool/i.test(t) || /^\*Total\s+execution\s+time/i.test(t) ||
      /^\*Correlation:/i.test(t) || /^\*Last\s+updated:/i.test(t)) {
    return {
      type: BLOCK_TYPES.PROSE,
      data: { content: '' },
      raw: [lines[i]],
      start: i,
      end: i,
    };
  }
  return null;
}

// Order matters — earlier detectors win.
// Code blocks first (never scan inside fences).
// Health + Risk before KPI because "Agent Health: 8% online" and
// "Overall Risk: HIGH" would otherwise match as KPI items.
// Severity before KPI because "Critical: 21" is a valid KPI item
// but "Critical: 21 | High: 188" should be a severity bar.
const DETECTORS = [
  tryCodeBlock,
  tryDetectSeverityBreakdown,
  tryDetectHealthStatus,
  tryDetectRiskScore,
  tryDetectRecommendations,   // before KPI — "### Action Required" is recs, not a KPI header
  tryDetectKPIGrid,
  tryDetectTable,
  tryDetectRelatedQueries,
  tryDetectMetadataFooter,
  tryDetectBadgeCloud,
];

// ─── Preamble stripper ──────────────────────────────────────────────────────
// The backend often embeds "Query: ...", "Tools Used: ...", "Results: ..."
// at the top of the markdown body. The frontend header already shows this
// metadata — displaying it again wastes ~80px of vertical space. We strip
// these known metadata-prefix lines from the top of the response.

const PREAMBLE_PREFIXES = [
  /^(?:\*{0,2})Query(?:\*{0,2})\s*[:=]/i,
  /^(?:\*{0,2})Tools?\s+Used(?:\*{0,2})\s*[:=]/i,
  /^(?:\*{0,2})Results?(?:\*{0,2})\s*[:=]/i,
  /^(?:\*{0,2})Strategy(?:\*{0,2})\s*[:=]/i,
  /^(?:\*{0,2})Execution\s+Time(?:\*{0,2})\s*[:=]/i,
  /^(?:\*{0,2})Match\s+Type(?:\*{0,2})\s*[:=]/i,
  /^(?:\*{0,2})Correlation(?:\*{0,2})\s*[:=]/i,
];

function stripPreambleLines(lines) {
  let start = 0;
  // Only strip from the very top of the response (first ~15 lines)
  const limit = Math.min(lines.length, 15);
  while (start < limit) {
    const t = (lines[start] || '').trim();
    if (!t) { start++; continue; }  // skip blanks
    if (PREAMBLE_PREFIXES.some(re => re.test(t))) {
      start++;
      continue;
    }
    break;  // first non-preamble, non-blank line → stop
  }
  return start > 0 ? lines.slice(start) : lines;
}

export function parseResponseBlocks(markdown) {
  if (!markdown || typeof markdown !== 'string') return [];

  const lines = stripPreambleLines(markdown.split('\n'));
  const blocks = [];
  let i = 0;

  while (i < lines.length) {
    // Skip leading blank lines (don't emit empty blocks)
    if (isBlankLine(lines[i])) {
      i++;
      continue;
    }

    // Try each specialized detector in order
    let block = null;
    for (const detect of DETECTORS) {
      block = detect(lines, i);
      if (block) break;
    }

    // No specialized match → consume as prose until next block boundary
    if (!block) {
      block = consumeProse(lines, i, DETECTORS);
    }

    blocks.push(block);
    i = block.end + 1;
  }

  return blocks;
}

// ─── Debug helper ───────────────────────────────────────────────────────────

export function debugBlocks(markdown) {
  const blocks = parseResponseBlocks(markdown);
  return blocks.map(b => ({
    type: b.type,
    lines: `${b.start}-${b.end}`,
    summary: b.type === 'prose'
      ? `${(b.data.content || '').slice(0, 80)}...`
      : JSON.stringify(b.data).slice(0, 120),
  }));
}
