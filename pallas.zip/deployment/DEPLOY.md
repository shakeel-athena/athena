# Pallas AI Standalone — Deployment Guide

## Prerequisites

1. **Pallas MCP Server** already running on 172.16.134.12:3000
2. **DNS record**: `pallas.athenasecuritygrp.com` → 172.16.134.12
3. **SSL certificate** at `/etc/letsencrypt/live/pallas.athenasecuritygrp.com/`
4. **Keycloak client** `pallas-ui` created in `athena-security` realm

## Keycloak Client Setup

In Keycloak Admin → Realm: athena-security → Clients → Create:

| Setting | Value |
|---------|-------|
| Client ID | `pallas-ui` |
| Protocol | openid-connect |
| Access Type | public |
| Standard Flow | enabled |
| Direct Access | enabled |
| Valid Redirect URIs | `https://pallas.athenasecuritygrp.com/*` |
| Web Origins | `https://pallas.athenasecuritygrp.com` |

For local development, also add:
- Valid Redirect URIs: `http://localhost:3001/*`
- Web Origins: `http://localhost:3001`

## Deploy

```bash
# On 172.16.134.12
cd /opt/pallas-app/deployment

# Create .env with API key
echo "REACT_APP_PALLAS_API_KEY=your-api-key-here" > .env

# Build and start
docker compose -f docker-compose.pallas.yml up -d --build

# Verify
docker compose -f docker-compose.pallas.yml ps
curl -k https://pallas.athenasecuritygrp.com/
```

## SSL Certificate (Let's Encrypt)

```bash
# Install certbot if not present
apt install certbot

# Get certificate (stop nginx first if port 80 is in use)
certbot certonly --standalone -d pallas.athenasecuritygrp.com

# Auto-renew (add to crontab)
0 0 1 * * certbot renew --quiet
```

## Verify

1. `https://pallas.athenasecuritygrp.com/` → Keycloak login → Pallas workspace
2. Send query → WebSocket works → AI response renders
3. All 8 modules load via hash routing
4. Daily Standup shows KPIs + AI analysis

## Update

```bash
# Pull latest code, rebuild
cd /opt/pallas-app/deployment
docker compose -f docker-compose.pallas.yml up -d --build
```

## Troubleshoot

```bash
# Check container status
docker compose -f docker-compose.pallas.yml ps

# Check logs
docker compose -f docker-compose.pallas.yml logs pallas-ui
docker compose -f docker-compose.pallas.yml logs pallas-nginx

# Check if MCP server is reachable
curl http://localhost:3000/ai-analyst/health

# Check if UI is serving
curl http://localhost:8080/
```
