/**
 * Athena Unified Theme — Agelia Design System
 *
 * Single source of truth for ALL dark-theme colors across:
 *   - Threat Topology main page
 *   - ZoneSummaryModal / AgentDetailModal
 *   - All tab content and sub-components
 *
 * Based on the Agelia Design System (blue-navy palette).
 * Import as: import { THEME } from '../utils/theme';
 */

// ─── Core Palette ────────────────────────────────────────────────────────────

export const THEME = {
  // Backgrounds — Athena Dark palette (unified across page + modals)
  bg:           '#151519',   // Page / modal panel background
  bgDeep:       '#0E0E11',   // Canvas / deepest layer
  card:         '#1D1E24',   // Card / panel surface
  cardDark:     '#151519',   // Same as bg — flat sections / tab containers
  cardSubtle:   '#1D1E24',   // Same as card — meta bars, table headers
  cardHover:    '#25262E',   // Hover state — slightly lighter than card

  // Borders — Athena Dark palette
  border:       '#2A2B33',   // Standard border / divider
  borderLight:  '#35363F',   // Active / lighter border
  borderSubtle: '#1D1E24',   // Same as card — subtle row dividers
  borderFaint:  '#151519',   // Same as bg — faintest divider

  // Text
  text:         '#ffffff',   // Primary text
  textBright:   '#e8f0ff',   // Bright emphasis
  textSecondary:'#8e9fbc',   // Secondary / labels
  textMuted:    '#5a6d8a',   // Muted (metadata, timestamps)
  textFaint:    '#3d5070',   // Faint (disabled-ish)
  textDisabled: '#2a3a54',   // Disabled

  // Accent colors
  primary:      '#61a2ff',   // Primary blue
  accent:       '#16c5c0',   // Cyan accent
  success:      '#24c292',   // Success green
  successLight: '#7de2d1',   // Light cyan
  danger:       '#f6726a',   // Danger coral
  warning:      '#dc6a13',   // Warning orange
  warningYellow:'#fec514',   // Yellow

  // Severity (alerts / threat levels)
  sevCritical:  '#EF4444',   // Red
  sevHigh:      '#F97316',   // Orange
  sevMedium:    '#F59E0B',   // Amber
  sevLow:       '#64748B',   // Slate

  // Status
  statusActive:       '#10B981',
  statusDisconnected: '#F59E0B',
  statusInactive:     '#6B7280',

  // Glows (for halos / highlights)
  primaryGlow:  'rgba(97, 162, 255, 0.5)',
  accentGlow:   'rgba(22, 197, 192, 0.5)',
  successGlow:  'rgba(36, 194, 146, 0.5)',
  dangerGlow:   'rgba(246, 114, 106, 0.5)',
  warningGlow:  'rgba(220, 106, 19, 0.5)',

  // Shadows
  panelShadow:  '-8px 0 32px rgba(0, 0, 0, 0.6)',
  backdropBg:   'rgba(0, 0, 0, 0.5)',
};

// ─── Legacy alias (drop-in for NetworkTopology.js AGELIA_COLORS) ─────────────

export const AGELIA_COLORS = {
  background:    THEME.bg,
  panel:         THEME.card,
  panelDark:     THEME.cardDark,
  border:        THEME.border,
  borderLight:   THEME.borderLight,
  text:          THEME.text,
  textSecondary: THEME.textSecondary,
  textMuted:     '#94A3B8',          // Matched to modal secondary text
  primary:       THEME.primary,
  success:       THEME.success,
  successLight:  THEME.successLight,
  danger:        THEME.danger,
  warning:       THEME.warning,
  warningYellow: THEME.warningYellow,
  accent:        THEME.accent,
  accentGlow:    THEME.accentGlow,
  dangerGlow:    THEME.dangerGlow,
  warningGlow:   THEME.warningGlow,
  successGlow:   THEME.successGlow,
  primaryGlow:   THEME.primaryGlow,
};
