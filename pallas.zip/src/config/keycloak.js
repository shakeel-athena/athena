import Keycloak from 'keycloak-js';

const keycloak = new Keycloak({
  url: process.env.REACT_APP_KEYCLOAK_URL || 'https://keycloak.athenasecuritygrp.com',
  realm: process.env.REACT_APP_KEYCLOAK_REALM || 'athena-security',
  clientId: process.env.REACT_APP_KEYCLOAK_CLIENT_ID || 'pallas-ui',
});

export const keycloakInitOptions = {
  onLoad: 'login-required',
  checkLoginIframe: false,
  pkceMethod: 'S256',
};

export default keycloak;
