const { createProxyMiddleware } = require('http-proxy-middleware');

module.exports = function (app) {
  // Proxy Pallas MCP Server (REST + WebSocket)
  app.use(
    '/ai-analyst',
    createProxyMiddleware({
      target: 'https://test.athenasecuritygrp.com',
      changeOrigin: true,
      ws: true,
      secure: true,
      onProxyReq: (proxyReq) => {
        if (!proxyReq.getHeader('origin')) {
          proxyReq.setHeader('Origin', 'https://test.athenasecuritygrp.com');
        }
      },
    })
  );
};
