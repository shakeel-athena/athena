/**
 * Pallas AI Analyst Service
 *
 * MCP (Model Context Protocol) client + WebSocket factory for the Pallas server.
 * Completely separate from apiClient.js — Pallas uses its own Origin-based auth,
 * not Keycloak JWT.
 */

const PALLAS_BASE_URL = process.env.REACT_APP_PALLAS_URL || '/ai-analyst';
const PALLAS_WS_URL = process.env.REACT_APP_PALLAS_WS_URL || '';
const PALLAS_API_KEY = process.env.REACT_APP_PALLAS_API_KEY || 'aI9xT2kP7vR4nQ8mW6sE3bH5dL1fG0jN2yU4cX9zA7';

// ---------------------------------------------------------------------------
// Keycloak JWT helper — forwards user identity alongside API key
// ---------------------------------------------------------------------------

function getKeycloakToken() {
  try {
    const raw = sessionStorage.getItem('keycloak_token') || localStorage.getItem('keycloak_token');
    return raw || null;
  } catch {
    return null;
  }
}

function authHeaders() {
  const headers = {
    'x-api-key': PALLAS_API_KEY,
  };
  const jwt = getKeycloakToken();
  if (jwt) {
    headers['Authorization'] = `Bearer ${jwt}`;
  }
  return headers;
}

// ---------------------------------------------------------------------------
// Config
// ---------------------------------------------------------------------------

export const PALLAS_CONFIG = {
  get baseUrl() {
    // If absolute URL provided, use as-is; otherwise resolve against origin
    if (PALLAS_BASE_URL.startsWith('http')) return PALLAS_BASE_URL;
    return `${window.location.origin}${PALLAS_BASE_URL}`;
  },
  get wsUrl() {
    // Explicit WS URL takes precedence (supports reverse proxy configs)
    if (PALLAS_WS_URL) {
      const wsBase = PALLAS_WS_URL.replace(/\/$/, '');
      return `${wsBase}/ws/chat?api_key=${PALLAS_API_KEY}`;
    }
    // Derive from base URL — replace http(s) with ws(s)
    const base = this.baseUrl;
    const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
    const hostPath = base.replace(/^https?:\/\//, '');
    return `${protocol}//${hostPath}/ws/chat?api_key=${PALLAS_API_KEY}`;
  },
  get apiKey() {
    return PALLAS_API_KEY;
  },
};

// ---------------------------------------------------------------------------
// Internal helpers
// ---------------------------------------------------------------------------

let _requestId = 0;
const nextId = () => ++_requestId;

async function mcpRequest(method, params = {}) {
  const url = `${PALLAS_CONFIG.baseUrl}/`;
  const body = {
    jsonrpc: '2.0',
    method,
    params,
    id: nextId(),
  };

  const response = await fetch(url, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Accept': 'application/json',
      ...authHeaders(),
    },
    body: JSON.stringify(body),
  });

  if (!response.ok) {
    throw new Error(`MCP HTTP error: ${response.status} ${response.statusText}`);
  }

  const data = await response.json();

  if (data.error) {
    throw new Error(data.error.message || 'MCP error');
  }

  return data.result;
}

// ---------------------------------------------------------------------------
// MCP Protocol Methods
// ---------------------------------------------------------------------------

/**
 * Initialize MCP session — returns server info + capabilities
 */
export async function mcpInitialize() {
  return mcpRequest('initialize', {
    protocolVersion: '2025-06-18',
    capabilities: {},
    clientInfo: { name: 'athena-pallas', version: '1.0.0' },
  });
}

/**
 * List all available MCP tools
 */
export async function mcpListTools() {
  const result = await mcpRequest('tools/list', {});
  return result?.tools || [];
}

/**
 * Call an MCP tool and return the parsed result
 * @param {string} toolName - Tool name (e.g. 'get_wazuh_agents')
 * @param {object} args - Tool arguments
 * @returns {{ text: string, isError: boolean }}
 */
export async function mcpCall(toolName, args = {}) {
  const result = await mcpRequest('tools/call', {
    name: toolName,
    arguments: args,
  });

  const content = result?.content?.[0];
  return {
    text: content?.text || '',
    isError: result?.isError || false,
  };
}

// ---------------------------------------------------------------------------
// REST Endpoints (non-MCP)
// ---------------------------------------------------------------------------

/**
 * Fetch server health status
 */
export async function fetchHealth() {
  const response = await fetch(`${PALLAS_CONFIG.baseUrl}/health`, {
    headers: authHeaders(),
  });
  if (!response.ok) throw new Error(`Health check failed: ${response.status}`);
  return response.json();
}

/**
 * Fetch server meta — tool health, feature flags.
 * Used by workspace layout for NavigationRail + StatusBar health dots.
 *
 * The Pallas server exposes /health (not /meta). We fetch /health and
 * map its `services` object into the shape the frontend expects:
 *   { cti_enabled, ollama_enabled, services }
 *
 * @returns {{ cti_enabled: boolean, ollama_enabled: boolean, services: object }}
 */
export async function fetchMeta() {
  const response = await fetch(`${PALLAS_CONFIG.baseUrl}/health`, {
    headers: authHeaders(),
  });
  if (!response.ok) throw new Error(`Meta fetch failed: ${response.status}`);
  const data = await response.json();

  // Map /health services into the meta shape the workspace layout expects
  const svc = data.services || {};
  return {
    cti_enabled: svc.suricata_ids === 'healthy',
    ollama_enabled: Boolean(svc.query_orchestrator && svc.query_orchestrator !== 'unhealthy'),
    services: svc,
    version: data.version,
    status: data.status,
  };
}

/**
 * Authenticated POST to a Pallas REST endpoint.
 * Used by AttackNarrative, DecoderLab, DetectIOC for non-MCP endpoints.
 * @param {string} path - Endpoint path (e.g. '/api/narrative/generate')
 * @param {object} body - JSON body
 * @returns {Promise<any>} Parsed JSON response
 */
export async function pallasPost(path, body = {}) {
  const response = await fetch(`${PALLAS_CONFIG.baseUrl}${path}`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      ...authHeaders(),
    },
    body: JSON.stringify(body),
  });
  if (!response.ok) {
    const errText = await response.text().catch(() => '');
    throw new Error(response.status === 404
      ? `Endpoint ${path} not available. Ensure the MCP server has been updated.`
      : `HTTP ${response.status}: ${errText}`);
  }
  return response.json();
}

// ---------------------------------------------------------------------------
// WebSocket Factory
// ---------------------------------------------------------------------------

/**
 * Create a WebSocket connection to the Pallas chat endpoint.
 * Returns the raw WebSocket instance — consumers manage lifecycle.
 */
export function createChatSocket() {
  return new WebSocket(PALLAS_CONFIG.wsUrl);
}

// ---------------------------------------------------------------------------
// Tool Metadata (for Tool Runner UI)
// ---------------------------------------------------------------------------

export const PALLAS_TOOL_CATEGORIES = [
  {
    name: 'Alerts & Events',
    tools: [
      'get_wazuh_alerts',
      'get_wazuh_alert_summary',
      'analyze_alert_patterns',
      'search_security_events',
      'get_top_security_threats',
    ],
  },
  {
    name: 'Agents',
    tools: [
      'get_wazuh_agents',
      'get_wazuh_running_agents',
      'check_agent_health',
      'get_agent_processes',
      'get_agent_ports',
      'get_agent_configuration',
    ],
  },
  {
    name: 'Vulnerabilities',
    tools: [
      'get_wazuh_vulnerabilities',
      'get_wazuh_critical_vulnerabilities',
      'get_wazuh_vulnerability_summary',
    ],
  },
  {
    name: 'Intelligence & Compliance',
    tools: [
      'analyze_security_threat',
      'check_ioc_reputation',
      'perform_risk_assessment',
      'generate_security_report',
      'run_compliance_check',
    ],
  },
  {
    name: 'System & Cluster',
    tools: [
      'get_wazuh_statistics',
      'get_wazuh_weekly_stats',
      'get_wazuh_cluster_health',
      'get_wazuh_cluster_nodes',
      'get_wazuh_rules_summary',
      'get_wazuh_remoted_stats',
      'get_wazuh_log_collector_stats',
      'search_wazuh_manager_logs',
      'get_wazuh_manager_error_logs',
      'validate_wazuh_connection',
    ],
  },
];
