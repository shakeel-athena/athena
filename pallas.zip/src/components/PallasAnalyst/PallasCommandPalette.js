import React, { useState, useEffect, useRef, useCallback, useMemo } from 'react';
import { EuiIcon } from '@elastic/eui';
import { THEME } from '../../utils/theme';
import { ALL_STRATEGY_CATEGORIES } from './PallasStrategies';

// ─── Fuzzy Match ─────────────────────────────────────────────────────────────

/**
 * Character-by-character fuzzy match with consecutive bonus scoring.
 * Returns 0 if query doesn't fully match (all chars not found in order).
 */
function fuzzyMatch(text, query) {
  if (!query) return 1;
  const t = text.toLowerCase();
  const q = query.toLowerCase();
  let score = 0;
  let ti = 0;
  let qi = 0;
  let consecutive = 0;

  while (ti < t.length && qi < q.length) {
    if (t[ti] === q[qi]) {
      score += 1 + consecutive * 2;
      consecutive++;
      qi++;
    } else {
      consecutive = 0;
    }
    ti++;
  }

  // Query not fully matched
  if (qi < q.length) return 0;

  return score;
}

// ─── Parameter Substitution ──────────────────────────────────────────────────

/**
 * Replaces {key} placeholders in a query template with provided values.
 * @param {string} query  - Template string, e.g. 'show ports for agent {agent_id}'
 * @param {Object} values - Map of key → value
 */
function substituteParams(query, values) {
  return query.replace(/\{(\w+)\}/g, (match, key) => {
    return values[key] !== undefined ? values[key] : match;
  });
}

// ─── Categories & Strategies (derived from shared PallasStrategies.js) ───────
// Maps the shared { strategies: [...] } format to CommandPalette's { items: [...] } format.

function buildCategories(sharedCategories) {
  return sharedCategories.map(cat => ({
    id: cat.id,
    label: cat.label || cat.name,
    icon: cat.icon,
    items: cat.strategies,
  }));
}

export const CATEGORIES = buildCategories(ALL_STRATEGY_CATEGORIES);

// ─── Quick Actions Tab Filter ────────────────────────────────────────────────

const QA_TABS = [
  { id: 'all', label: 'All' },
  { id: 'edr', label: 'EDR' },
  { id: 'nids', label: 'NIDS' },
  { id: 'vulns', label: 'Vulnerabilities' },
  { id: 'other', label: 'Other' },
];

const QA_TAB_CATEGORY_MAP = {
  edr: ['siem-agents', 'siem-alerts', 'siem-endpoints'],
  nids: ['nids-alerts', 'nids-hunting', 'nids-network'],
  vulns: ['vulnerabilities'],
};

function filterByTab(categories, tabId) {
  if (tabId === 'all') return categories;
  const allowedIds = QA_TAB_CATEGORY_MAP[tabId];
  if (allowedIds) {
    return categories.filter((cat) => allowedIds.includes(cat.id));
  }
  // "other" = everything not in edr/nids/vulns
  const allMapped = Object.values(QA_TAB_CATEGORY_MAP).flat();
  return categories.filter((cat) => !allMapped.includes(cat.id));
}

function makeSlashCommand(query) {
  return '/' + query.split(' ').slice(0, 3).join('-').toLowerCase();
}

// ─── Flat item list for keyboard navigation ───────────────────────────────────

function buildFlatItems(categories) {
  const flat = [];
  categories.forEach((cat) => {
    cat.items.forEach((item) => {
      flat.push({ ...item, categoryId: cat.id, categoryLabel: cat.label });
    });
  });
  return flat;
}

// ─── Filtered categories (for search) ────────────────────────────────────────

function filterCategories(categories, query) {
  if (!query.trim()) return categories;
  return categories
    .map((cat) => {
      const items = cat.items
        .map((item) => {
          const labelScore = fuzzyMatch(item.label, query);
          const descScore = item.description ? fuzzyMatch(item.description, query) * 0.5 : 0;
          const queryScore = fuzzyMatch(item.query, query) * 0.7;
          const score = Math.max(labelScore, descScore, queryScore);
          return { item, score };
        })
        .filter(({ score }) => score > 0)
        .sort((a, b) => b.score - a.score)
        .map(({ item }) => item);
      return { ...cat, items };
    })
    .filter((cat) => cat.items.length > 0);
}

// ─── Styles ──────────────────────────────────────────────────────────────────

const S = {
  overlay: {
    position: 'fixed',
    inset: 0,
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
    backdropFilter: 'blur(4px)',
    WebkitBackdropFilter: 'blur(4px)',
    zIndex: 1000,
    display: 'flex',
    alignItems: 'stretch',
    justifyContent: 'flex-end',
    animation: 'pallas-fadeIn 0.15s ease-out',
  },
  panel: {
    width: '100%',
    maxWidth: 620,
    height: '100%',
    backgroundColor: THEME.card,
    borderLeft: `1px solid ${THEME.border}`,
    borderRadius: 0,
    boxShadow: '-8px 0 30px rgba(0,0,0,0.4)',
    display: 'flex',
    flexDirection: 'column',
    overflow: 'hidden',
    animation: 'pallas-fadeIn 0.15s ease-out',
    fontFamily: 'Inter, -apple-system, BlinkMacSystemFont, sans-serif',
  },
  searchBar: {
    display: 'flex',
    alignItems: 'center',
    gap: 10,
    padding: '12px 16px',
    borderBottom: `1px solid ${THEME.border}`,
    flexShrink: 0,
  },
  searchIcon: {
    color: THEME.textMuted,
    flexShrink: 0,
  },
  searchInput: {
    flex: 1,
    background: 'transparent',
    border: 'none',
    outline: 'none',
    color: THEME.text,
    fontSize: 15,
    fontFamily: 'Inter, -apple-system, BlinkMacSystemFont, sans-serif',
  },
  escBadge: {
    padding: '2px 7px',
    borderRadius: 5,
    backgroundColor: 'rgba(255,255,255,0.06)',
    color: THEME.textMuted,
    fontSize: 11,
    fontFamily: 'SFMono-Regular, Menlo, Monaco, Consolas, monospace',
    flexShrink: 0,
    userSelect: 'none',
  },
  scrollArea: {
    overflowY: 'auto',
    flex: 1,
    padding: '8px 0',
  },
  categoryHeader: {
    display: 'flex',
    alignItems: 'center',
    gap: 7,
    padding: '10px 16px 5px',
    color: THEME.textMuted,
    fontSize: 11,
    fontWeight: 600,
    textTransform: 'uppercase',
    letterSpacing: '0.08em',
    userSelect: 'none',
  },
  item: (isSelected) => ({
    display: 'flex',
    flexDirection: 'column',
    padding: '8px 16px',
    cursor: 'pointer',
    backgroundColor: isSelected ? 'rgba(255,255,255,0.04)' : 'transparent',
    borderLeft: isSelected ? `2px solid ${THEME.accent}` : '2px solid transparent',
    transition: 'background-color 0.1s',
  }),
  itemRow: {
    display: 'flex',
    alignItems: 'center',
    gap: 8,
  },
  itemLabel: (isSelected) => ({
    color: isSelected ? THEME.text : THEME.textSecondary,
    fontSize: 14,
    fontWeight: isSelected ? 500 : 400,
    flex: 1,
  }),
  paramBadge: {
    padding: '1px 6px',
    borderRadius: 4,
    backgroundColor: `rgba(22, 197, 192, 0.12)`,
    color: THEME.accent,
    fontSize: 10,
    fontFamily: 'SFMono-Regular, Menlo, Monaco, Consolas, monospace',
    border: `1px solid rgba(22, 197, 192, 0.25)`,
    userSelect: 'none',
  },
  enterHint: {
    color: THEME.textMuted,
    fontSize: 11,
    userSelect: 'none',
  },
  itemDescription: {
    color: THEME.textMuted,
    fontSize: 12,
    marginTop: 2,
    marginLeft: 0,
    paddingLeft: 0,
  },
  footer: {
    borderTop: `1px solid ${THEME.border}`,
    padding: '8px 16px',
    display: 'flex',
    alignItems: 'center',
    gap: 16,
    color: THEME.textMuted,
    fontSize: 11,
    flexShrink: 0,
    userSelect: 'none',
  },
  footerKey: {
    display: 'inline-flex',
    alignItems: 'center',
    gap: 4,
    color: THEME.textMuted,
    fontSize: 11,
  },
  footerKbd: {
    padding: '1px 5px',
    borderRadius: 3,
    backgroundColor: 'rgba(255,255,255,0.06)',
    fontFamily: 'SFMono-Regular, Menlo, Monaco, Consolas, monospace',
    fontSize: 10,
  },
  footerSpacer: {
    flex: 1,
  },
  footerCount: {
    color: THEME.textMuted,
    fontSize: 11,
  },
  // Param mode
  paramBar: {
    display: 'flex',
    alignItems: 'center',
    gap: 10,
    padding: '12px 16px',
    borderBottom: `1px solid ${THEME.border}`,
    flexShrink: 0,
  },
  paramLabel: {
    color: THEME.textSecondary,
    fontSize: 13,
    flexShrink: 0,
    whiteSpace: 'nowrap',
  },
  paramInput: {
    flex: 1,
    background: 'transparent',
    border: 'none',
    outline: 'none',
    color: THEME.text,
    fontSize: 15,
    fontFamily: 'Inter, -apple-system, BlinkMacSystemFont, sans-serif',
  },
  paramRunBtn: {
    padding: '5px 14px',
    borderRadius: 7,
    backgroundColor: THEME.accent,
    color: '#0a1a1a',
    fontSize: 13,
    fontWeight: 600,
    border: 'none',
    cursor: 'pointer',
    flexShrink: 0,
  },
  paramBackBtn: {
    padding: '5px 10px',
    borderRadius: 7,
    backgroundColor: 'transparent',
    color: THEME.textSecondary,
    fontSize: 13,
    border: `1px solid ${THEME.border}`,
    cursor: 'pointer',
    flexShrink: 0,
  },
  paramQueryPreview: {
    padding: '10px 16px',
    borderBottom: `1px solid ${THEME.border}`,
    color: THEME.textMuted,
    fontSize: 12,
    fontFamily: 'SFMono-Regular, Menlo, Monaco, Consolas, monospace',
    flexShrink: 0,
    backgroundColor: `rgba(0,0,0,0.15)`,
  },
  paramQueryHighlight: {
    color: THEME.accent,
  },
};

// ─── Keyframe injection ───────────────────────────────────────────────────────

const ANIMATION_CSS = `
@keyframes pallas-fadeIn {
  from { opacity: 0; }
  to   { opacity: 1; }
}
@keyframes pallas-scaleIn {
  from { opacity: 0; transform: scale(0.94) translateY(-8px); }
  to   { opacity: 1; transform: scale(1) translateY(0); }
}
`;

function ensureAnimations() {
  if (document.getElementById('pallas-cmd-animations')) return;
  const style = document.createElement('style');
  style.id = 'pallas-cmd-animations';
  style.textContent = ANIMATION_CSS;
  document.head.appendChild(style);
}

// ─── Query preview renderer ───────────────────────────────────────────────────

function renderQueryPreview(query, paramKey, paramValue) {
  const placeholder = `{${paramKey}}`;
  const idx = query.indexOf(placeholder);
  if (idx === -1) return <span style={{ color: THEME.textMuted }}>{query}</span>;

  const before = query.slice(0, idx);
  const after = query.slice(idx + placeholder.length);
  const display = paramValue || placeholder;

  return (
    <>
      <span style={{ color: THEME.textMuted }}>{before}</span>
      <span style={S.paramQueryHighlight}>{display}</span>
      <span style={{ color: THEME.textMuted }}>{after}</span>
    </>
  );
}

// ─── Main Component ───────────────────────────────────────────────────────────

function PallasCommandPalette({ isOpen, onClose, onSelect }) {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedIndex, setSelectedIndex] = useState(0);
  const [viewMode, setViewMode] = useState('grid'); // 'grid' | 'list'
  const [activeTab, setActiveTab] = useState('all');

  // Param mode state
  const [paramMode, setParamMode] = useState(false);
  const [paramItem, setParamItem] = useState(null);
  const [paramValues, setParamValues] = useState({});
  const [paramInputValue, setParamInputValue] = useState('');

  const searchInputRef = useRef(null);
  const paramInputRef = useRef(null);
  const selectedItemRef = useRef(null);

  // Inject animations once
  useEffect(() => {
    ensureAnimations();
  }, []);

  // Reset state when palette opens
  useEffect(() => {
    if (isOpen) {
      setSearchQuery('');
      setSelectedIndex(0);
      setParamMode(false);
      setParamItem(null);
      setParamValues({});
      setParamInputValue('');
      // Auto-focus search input
      requestAnimationFrame(() => {
        requestAnimationFrame(() => {
          if (searchInputRef.current) {
            searchInputRef.current.focus();
          }
        });
      });
    }
  }, [isOpen]);

  // Auto-focus param input when entering param mode
  useEffect(() => {
    if (paramMode && paramInputRef.current) {
      requestAnimationFrame(() => {
        requestAnimationFrame(() => {
          if (paramInputRef.current) paramInputRef.current.focus();
        });
      });
    }
  }, [paramMode]);

  // Scroll selected item into view
  useEffect(() => {
    if (selectedItemRef.current) {
      selectedItemRef.current.scrollIntoView({ block: 'nearest', behavior: 'smooth' });
    }
  }, [selectedIndex]);

  // Compute filtered categories & flat list
  const tabFilteredCategories = filterByTab(CATEGORIES, activeTab);
  const filteredCategories = filterCategories(tabFilteredCategories, searchQuery);
  const flatItems = buildFlatItems(filteredCategories);
  const totalStrategies = buildFlatItems(CATEGORIES).length;
  const allGridItems = buildFlatItems(filteredCategories);

  const executeItem = useCallback(
    (item) => {
      if (item.params && item.params.length > 0) {
        // Enter param mode — for simplicity handle single-param items
        setParamItem(item);
        setParamValues({});
        setParamInputValue('');
        setParamMode(true);
      } else {
        onSelect(item.query);
        onClose();
      }
    },
    [onSelect, onClose]
  );

  const executeParamItem = useCallback(() => {
    if (!paramItem) return;
    const param = paramItem.params[0];
    const value = paramInputValue.trim();
    const finalValues = { ...paramValues, [param.key]: value };
    const finalQuery = substituteParams(paramItem.query, finalValues);
    onSelect(finalQuery);
    onClose();
  }, [paramItem, paramInputValue, paramValues, onSelect, onClose]);

  const exitParamMode = useCallback(() => {
    setParamMode(false);
    setParamItem(null);
    setParamValues({});
    setParamInputValue('');
    // Re-focus search
    requestAnimationFrame(() => {
      requestAnimationFrame(() => {
        if (searchInputRef.current) searchInputRef.current.focus();
      });
    });
  }, []);

  // Keyboard handler — search mode
  const handleSearchKeyDown = useCallback(
    (e) => {
      if (e.key === 'ArrowDown') {
        e.preventDefault();
        setSelectedIndex((i) => Math.min(i + 1, flatItems.length - 1));
      } else if (e.key === 'ArrowUp') {
        e.preventDefault();
        setSelectedIndex((i) => Math.max(i - 1, 0));
      } else if (e.key === 'Enter') {
        e.preventDefault();
        if (flatItems[selectedIndex]) {
          executeItem(flatItems[selectedIndex]);
        }
      } else if (e.key === 'Escape') {
        e.preventDefault();
        onClose();
      }
    },
    [flatItems, selectedIndex, executeItem, onClose]
  );

  // Reset selectedIndex when search changes
  const handleSearchChange = useCallback((e) => {
    setSearchQuery(e.target.value);
    setSelectedIndex(0);
  }, []);

  // Keyboard handler — param mode
  const handleParamKeyDown = useCallback(
    (e) => {
      if (e.key === 'Enter') {
        e.preventDefault();
        executeParamItem();
      } else if (e.key === 'Escape') {
        e.preventDefault();
        exitParamMode();
      }
    },
    [executeParamItem, exitParamMode]
  );

  // Track flat index across rendered items
  let flatIdx = 0;

  if (!isOpen) return null;

  const currentParam = paramMode && paramItem && paramItem.params ? paramItem.params[0] : null;

  return (
    <div
      style={S.overlay}
      onMouseDown={(e) => {
        if (e.target === e.currentTarget) onClose();
      }}
    >
      <div style={S.panel} onMouseDown={(e) => e.stopPropagation()}>
        {/* ── Title Bar ──────────────────────────────────────── */}
        <div style={{
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'space-between',
          padding: '14px 16px 0',
          flexShrink: 0,
        }}>
          <h3 style={{ fontSize: 16, fontWeight: 700, color: THEME.text, margin: 0 }}>
            Quick Actions
          </h3>
          <button
            onClick={onClose}
            aria-label="Close"
            style={{
              width: 28, height: 28, borderRadius: 6,
              border: 'none', background: 'rgba(255,255,255,0.06)',
              cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center',
            }}
          >
            <EuiIcon type="cross" size="s" color={THEME.textMuted} />
          </button>
        </div>

        {/* ── Category Tabs + View Toggle ────────────────────── */}
        {!paramMode && (
          <div style={{
            display: 'flex',
            alignItems: 'center',
            padding: '10px 16px 0',
            gap: 0,
            flexShrink: 0,
          }}>
            {QA_TABS.map((tab) => {
              const isActive = activeTab === tab.id;
              return (
                <button
                  key={tab.id}
                  onClick={() => { setActiveTab(tab.id); setSelectedIndex(0); }}
                  style={{
                    padding: '6px 14px',
                    border: 'none',
                    borderBottom: isActive ? `2px solid ${THEME.accent}` : '2px solid transparent',
                    background: 'transparent',
                    color: isActive ? THEME.text : THEME.textMuted,
                    fontSize: 13,
                    fontWeight: isActive ? 600 : 400,
                    fontFamily: 'Inter, -apple-system, sans-serif',
                    cursor: 'pointer',
                    transition: 'all 0.12s',
                  }}
                >
                  {tab.label}
                </button>
              );
            })}
            <div style={{ marginLeft: 'auto', display: 'flex', gap: 2 }}>
              {[
                { mode: 'grid', icon: 'grid', label: 'Grid' },
                { mode: 'list', icon: 'list', label: 'List' },
              ].map((v) => (
                <button
                  key={v.mode}
                  onClick={() => setViewMode(v.mode)}
                  style={{
                    display: 'inline-flex',
                    alignItems: 'center',
                    gap: 4,
                    padding: '4px 10px',
                    borderRadius: 6,
                    border: 'none',
                    background: viewMode === v.mode ? 'rgba(22, 197, 192, 0.12)' : 'transparent',
                    color: viewMode === v.mode ? THEME.accent : THEME.textMuted,
                    fontSize: 12,
                    fontWeight: 500,
                    fontFamily: 'Inter, -apple-system, sans-serif',
                    cursor: 'pointer',
                  }}
                >
                  <EuiIcon type={v.icon} size="s" color="inherit" />
                  {v.label}
                </button>
              ))}
            </div>
          </div>
        )}

        {/* ── Search Bar / Param Bar ─────────────────────────── */}
        {!paramMode ? (
          <div style={S.searchBar}>
            <EuiIcon type="search" size="m" style={S.searchIcon} />
            <input
              ref={searchInputRef}
              style={S.searchInput}
              type="text"
              placeholder="Search strategies..."
              value={searchQuery}
              onChange={handleSearchChange}
              onKeyDown={handleSearchKeyDown}
            />
            <span style={S.escBadge}>ESC</span>
          </div>
        ) : (
          <>
            <div style={S.paramBar}>
              <span style={S.paramLabel}>{currentParam ? currentParam.label + ':' : 'Parameter:'}</span>
              <input
                ref={paramInputRef}
                style={S.paramInput}
                type="text"
                placeholder={currentParam ? currentParam.placeholder : ''}
                value={paramInputValue}
                onChange={(e) => setParamInputValue(e.target.value)}
                onKeyDown={handleParamKeyDown}
              />
              <button style={S.paramRunBtn} onClick={executeParamItem}>
                Run
              </button>
              <button style={S.paramBackBtn} onClick={exitParamMode}>
                Back
              </button>
            </div>
            {paramItem && (
              <div style={S.paramQueryPreview}>
                {currentParam
                  ? renderQueryPreview(paramItem.query, currentParam.key, paramInputValue.trim())
                  : paramItem.query}
              </div>
            )}
          </>
        )}

        {/* ── Scrollable Strategy List / Grid (search mode only) ── */}
        {!paramMode && (
          <div style={S.scrollArea}>
            {filteredCategories.length === 0 && (
              <div
                style={{
                  padding: '32px 16px',
                  textAlign: 'center',
                  color: THEME.textMuted,
                  fontSize: 14,
                }}
              >
                No strategies found for &quot;{searchQuery}&quot;
              </div>
            )}

            {/* ── Grid View ──────────────────────────────────────── */}
            {viewMode === 'grid' && filteredCategories.length > 0 && (
              <div style={{
                display: 'grid',
                gridTemplateColumns: 'repeat(3, 1fr)',
                gap: 10,
                padding: '12px 16px',
              }}>
                {allGridItems.map((item) => (
                  <div
                    key={`grid-${item.label}-${item.query}`}
                    onClick={() => executeItem(item)}
                    style={{
                      padding: 14,
                      borderRadius: 10,
                      border: `1px solid ${THEME.border}`,
                      backgroundColor: 'rgba(255,255,255,0.02)',
                      cursor: 'pointer',
                      transition: 'all 0.12s',
                    }}
                    onMouseEnter={(e) => {
                      e.currentTarget.style.borderColor = THEME.accent + '40';
                      e.currentTarget.style.backgroundColor = 'rgba(22, 197, 192, 0.04)';
                    }}
                    onMouseLeave={(e) => {
                      e.currentTarget.style.borderColor = THEME.border;
                      e.currentTarget.style.backgroundColor = 'rgba(255,255,255,0.02)';
                    }}
                  >
                    <div style={{
                      fontSize: 13,
                      fontWeight: 600,
                      color: THEME.text,
                      marginBottom: 4,
                    }}>
                      {item.label}
                    </div>
                    {item.description && (
                      <div style={{
                        fontSize: 11,
                        color: THEME.textMuted,
                        lineHeight: 1.4,
                        marginBottom: 8,
                        display: '-webkit-box',
                        WebkitLineClamp: 2,
                        WebkitBoxOrient: 'vertical',
                        overflow: 'hidden',
                      }}>
                        {item.description}
                      </div>
                    )}
                    <div style={{
                      fontSize: 11,
                      color: THEME.accent,
                      fontFamily: 'SFMono-Regular, Menlo, Monaco, Consolas, monospace',
                      opacity: 0.8,
                    }}>
                      {makeSlashCommand(item.query)}
                    </div>
                  </div>
                ))}
              </div>
            )}

            {/* ── List View ──────────────────────────────────────── */}
            {viewMode === 'list' && filteredCategories.map((cat) => (
              <div key={cat.id}>
                <div style={S.categoryHeader}>
                  <EuiIcon type={cat.icon} size="s" color={THEME.textMuted} />
                  {cat.label}
                </div>
                {cat.items.map((item) => {
                  const currentFlatIdx = flatIdx++;
                  const isSelected = selectedIndex === currentFlatIdx;
                  return (
                    <div
                      key={`${cat.id}-${item.label}`}
                      ref={isSelected ? selectedItemRef : null}
                      style={S.item(isSelected)}
                      onMouseEnter={() => setSelectedIndex(currentFlatIdx)}
                      onClick={() => executeItem(item)}
                    >
                      <div style={S.itemRow}>
                        <span style={S.itemLabel(isSelected)}>{item.label}</span>
                        {item.params && item.params.length > 0 && (
                          <span style={S.paramBadge}>param</span>
                        )}
                        {isSelected && <span style={S.enterHint}>Enter ↵</span>}
                      </div>
                      {item.description && (
                        <div style={S.itemDescription}>{item.description}</div>
                      )}
                    </div>
                  );
                })}
              </div>
            ))}
          </div>
        )}

        {/* ── Footer ────────────────────────────────────────── */}
        <div style={S.footer}>
          {!paramMode ? (
            <>
              <span style={S.footerKey}>
                <span style={S.footerKbd}>↑↓</span> Navigate
              </span>
              <span style={S.footerKey}>
                <span style={S.footerKbd}>Enter</span> Select
              </span>
              <span style={S.footerKey}>
                <span style={S.footerKbd}>Esc</span> Close
              </span>
              <span style={S.footerSpacer} />
              <span style={S.footerCount}>{totalStrategies} strategies</span>
            </>
          ) : (
            <>
              <span style={S.footerKey}>
                <span style={S.footerKbd}>Enter</span> Run
              </span>
              <span style={S.footerKey}>
                <span style={S.footerKbd}>Esc</span> Back
              </span>
            </>
          )}
        </div>
      </div>
    </div>
  );
}

export default PallasCommandPalette;
