/**
 * PallasQueryHistory — Query history dropdown for PallasChat
 *
 * Shows past queries with timestamps and strategy badges.
 * Clicking a row fills the input; clicking re-run executes immediately.
 */

import React, { useState, useRef, useEffect, useCallback } from 'react';
import { EuiIcon } from '@elastic/eui';
import { THEME } from '../../componen../../utils/theme';

// ─── Time Formatting ──────────────────────────────────────────────────────────

function formatTime(timestamp) {
  const now = Date.now();
  const diffMs = now - new Date(timestamp).getTime();
  const diffMin = Math.floor(diffMs / 60000);

  if (diffMin < 1) return 'just now';
  if (diffMin < 60) return `${diffMin}m ago`;

  const diffHr = Math.floor(diffMin / 60);
  if (diffHr < 24) return `${diffHr}h ago`;

  return new Date(timestamp).toLocaleDateString();
}

// ─── Styles ───────────────────────────────────────────────────────────────────

const styles = {
  wrapper: {
    position: 'relative',
    display: 'inline-block',
  },

  triggerButton: (isOpen, disabled) => ({
    display: 'inline-flex',
    alignItems: 'center',
    gap: 6,
    padding: '5px 12px',
    border: `1px solid ${THEME.border}`,
    borderRadius: 20,
    backgroundColor: isOpen ? 'rgba(22, 197, 192, 0.12)' : 'transparent',
    color: isOpen ? THEME.accent : THEME.textSecondary,
    fontSize: 12,
    fontFamily: 'inherit',
    cursor: disabled ? 'not-allowed' : 'pointer',
    opacity: disabled ? 0.5 : 1,
    transition: 'background-color 0.15s, color 0.15s, border-color 0.15s',
    outline: 'none',
    whiteSpace: 'nowrap',
    borderColor: isOpen ? THEME.accent : THEME.border,
  }),

  panel: {
    position: 'absolute',
    top: 'calc(100% + 6px)',
    left: 0,
    width: 380,
    maxHeight: 300,
    overflowY: 'auto',
    backgroundColor: THEME.card,
    border: `1px solid ${THEME.border}`,
    borderRadius: 10,
    boxShadow: THEME.panelShadow,
    zIndex: 100,
  },

  panelHeader: {
    padding: '10px 14px 6px',
    fontSize: 11,
    fontWeight: 600,
    letterSpacing: '0.08em',
    textTransform: 'uppercase',
    color: THEME.textMuted,
    borderBottom: `1px solid ${THEME.border}`,
  },

  item: (hovered) => ({
    display: 'flex',
    alignItems: 'center',
    gap: 10,
    padding: '9px 12px',
    cursor: 'pointer',
    backgroundColor: hovered ? 'rgba(255,255,255,0.04)' : 'transparent',
    transition: 'background-color 0.15s',
    borderBottom: `1px solid ${THEME.border}`,
  }),

  itemIcon: {
    flexShrink: 0,
    color: THEME.textMuted,
  },

  itemBody: {
    flex: 1,
    minWidth: 0,
  },

  queryText: {
    fontSize: 13,
    color: THEME.text,
    whiteSpace: 'nowrap',
    overflow: 'hidden',
    textOverflow: 'ellipsis',
  },

  itemMeta: {
    display: 'flex',
    alignItems: 'center',
    gap: 6,
    marginTop: 2,
  },

  timestamp: {
    fontSize: 11,
    color: THEME.textMuted,
  },

  strategyBadge: {
    fontSize: 10,
    padding: '1px 7px',
    borderRadius: 10,
    backgroundColor: 'rgba(22, 197, 192, 0.12)',
    color: THEME.accent,
    border: `1px solid rgba(22, 197, 192, 0.25)`,
    whiteSpace: 'nowrap',
  },

  rerunButton: (hovered) => ({
    flexShrink: 0,
    width: 28,
    height: 28,
    borderRadius: 7,
    border: 'none',
    backgroundColor: hovered ? 'rgba(22, 197, 192, 0.3)' : 'rgba(22, 197, 192, 0.15)',
    color: THEME.accent,
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    cursor: 'pointer',
    transition: 'background-color 0.15s',
    outline: 'none',
  }),
};

// ─── HistoryItem ──────────────────────────────────────────────────────────────

function HistoryItem({ entry, onSelect, onExecute }) {
  const [rowHovered, setRowHovered] = useState(false);
  const [btnHovered, setBtnHovered] = useState(false);

  const handleRowClick = useCallback(() => {
    onSelect(entry.query);
  }, [entry.query, onSelect]);

  const handleRerun = useCallback((e) => {
    e.stopPropagation();
    onExecute(entry.query);
  }, [entry.query, onExecute]);

  return (
    <div
      style={styles.item(rowHovered)}
      onMouseEnter={() => setRowHovered(true)}
      onMouseLeave={() => setRowHovered(false)}
      onClick={handleRowClick}
      role="button"
      tabIndex={0}
      onKeyDown={(e) => { if (e.key === 'Enter' || e.key === ' ') handleRowClick(); }}
      aria-label={`Select query: ${entry.query}`}
    >
      {/* Search icon */}
      <span style={styles.itemIcon}>
        <EuiIcon type="search" size="s" />
      </span>

      {/* Body */}
      <div style={styles.itemBody}>
        <div style={styles.queryText} title={entry.query}>
          {entry.query}
        </div>
        <div style={styles.itemMeta}>
          <span style={styles.timestamp}>{formatTime(entry.timestamp)}</span>
          {entry.strategy && (
            <span style={styles.strategyBadge}>
              {entry.strategy.replace(/_/g, ' ')}
            </span>
          )}
        </div>
      </div>

      {/* Re-run button */}
      <button
        style={styles.rerunButton(btnHovered)}
        onMouseEnter={() => setBtnHovered(true)}
        onMouseLeave={() => setBtnHovered(false)}
        onClick={handleRerun}
        aria-label={`Re-run query: ${entry.query}`}
        title="Re-run this query"
      >
        <EuiIcon type="playFilled" size="s" />
      </button>
    </div>
  );
}

// ─── QueryHistory ─────────────────────────────────────────────────────────────

export function QueryHistory({ history, onSelect, onExecute, disabled }) {
  const [isOpen, setIsOpen] = useState(false);
  const [triggerHovered, setTriggerHovered] = useState(false);
  const wrapperRef = useRef(null);

  // Close on outside click
  useEffect(() => {
    if (!isOpen) return;

    function handleMouseDown(e) {
      if (wrapperRef.current && !wrapperRef.current.contains(e.target)) {
        setIsOpen(false);
      }
    }

    document.addEventListener('mousedown', handleMouseDown);
    return () => document.removeEventListener('mousedown', handleMouseDown);
  }, [isOpen]);

  // Close on Escape
  useEffect(() => {
    if (!isOpen) return;

    function handleKeyDown(e) {
      if (e.key === 'Escape') {
        setIsOpen(false);
      }
    }

    document.addEventListener('keydown', handleKeyDown, true);
    return () => document.removeEventListener('keydown', handleKeyDown, true);
  }, [isOpen]);

  const handleToggle = useCallback(() => {
    if (!disabled) setIsOpen(prev => !prev);
  }, [disabled]);

  const handleSelect = useCallback((query) => {
    onSelect(query);
    setIsOpen(false);
  }, [onSelect]);

  const handleExecute = useCallback((query) => {
    onExecute(query);
    setIsOpen(false);
  }, [onExecute]);

  // Don't render if no history
  if (!history || history.length === 0) return null;

  return (
    <div ref={wrapperRef} style={styles.wrapper}>
      {/* Trigger */}
      <button
        style={{
          ...styles.triggerButton(isOpen, disabled),
          ...(triggerHovered && !isOpen && !disabled
            ? { borderColor: THEME.textSecondary, color: THEME.text }
            : {}),
        }}
        onMouseEnter={() => setTriggerHovered(true)}
        onMouseLeave={() => setTriggerHovered(false)}
        onClick={handleToggle}
        disabled={disabled}
        aria-haspopup="listbox"
        aria-expanded={isOpen}
        aria-label={`Query history, ${history.length} items`}
      >
        <EuiIcon type="clock" size="s" />
        <span>History ({history.length})</span>
        <EuiIcon type={isOpen ? 'arrowUp' : 'arrowDown'} size="s" />
      </button>

      {/* Dropdown panel */}
      {isOpen && (
        <div style={styles.panel} role="listbox" aria-label="Recent queries">
          <div style={styles.panelHeader}>Recent Queries</div>
          {history.map((entry, idx) => (
            <HistoryItem
              key={idx}
              entry={entry}
              onSelect={handleSelect}
              onExecute={handleExecute}
            />
          ))}
        </div>
      )}
    </div>
  );
}

export default QueryHistory;
