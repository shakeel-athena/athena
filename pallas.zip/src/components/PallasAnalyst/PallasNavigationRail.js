/**
 * PallasNavigationRail — Module Navigation
 *
 * Redesigned: Slim rail that expands on hover to show labels.
 * Each module has a signature accent color and integrated health dot.
 * Groups: AI Tools | Investigation | Analysis | Forensics
 */

import React from 'react';
import { EuiIcon, EuiToolTip } from '@elastic/eui';
import { THEME } from '../../utils/theme';
import { MODULE_COLORS } from './PallasUI';

// ─── Module Definitions ───────────────────────────────────────────────────────

const NAV_GROUPS = [
  {
    label: 'AI TOOLS',
    items: [
      { id: 'chat',    label: 'SOC Chat',      icon: 'discuss',   desc: 'AI-powered security queries' },
      { id: 'ioc',     label: 'Threat Intel',   icon: 'search',    desc: 'IOC reputation & IP lookup' },
      { id: 'decoder', label: 'Decoder Lab',    icon: 'wrench',    desc: 'AI decoder generation' },
    ],
  },
  {
    label: 'INVESTIGATION',
    items: [
      { id: 'siem',  label: 'SIEM',            icon: 'storage', desc: 'Agents, alerts & endpoints' },
      { id: 'nids',  label: 'NIDS',            icon: 'globe',   desc: 'Network intrusion detection' },
      { id: 'vulns', label: 'Vulnerabilities', icon: 'bug',     desc: 'CVE risk assessment' },
    ],
  },
  {
    label: 'ANALYSIS',
    items: [
      { id: 'correlations', label: 'Correlations', icon: 'layers',   desc: 'Cross-platform intelligence' },
      { id: 'narrative',    label: 'Narrative',     icon: 'timeline', desc: 'AI forensic narratives' },
    ],
  },
];

// Flat list for external consumers
const ALL_ITEMS = NAV_GROUPS.flatMap(g => g.items);
export const VALID_MODULES = ALL_ITEMS.map(i => i.id);

// Tool health mapping: which tools each module depends on
const MODULE_HEALTH_MAP = {
  chat:         ['wazuh_manager'],
  ioc:          ['wazuh_manager'],
  decoder:      ['ollama'],
  siem:         ['wazuh_manager', 'wazuh_indexer'],
  nids:         ['suricata'],
  vulns:        ['wazuh_indexer'],
  correlations: ['wazuh_manager', 'suricata'],
  narrative:    ['wazuh_manager'],
};

function getModuleHealth(moduleId, toolHealth) {
  const deps = MODULE_HEALTH_MAP[moduleId] || [];
  if (!deps.length) return 'unknown';
  const statuses = deps.map(d => toolHealth[d] || 'disabled');
  if (statuses.every(s => s === 'connected')) return 'connected';
  if (statuses.some(s => s === 'connected')) return 'partial';
  if (statuses.every(s => s === 'disabled')) return 'disabled';
  return 'disconnected';
}

// ─── NavButton ────────────────────────────────────────────────────────────────

function NavButton({ item, isActive, expanded, onClick, healthStatus }) {
  const [hovered, setHovered] = React.useState(false);
  const mc = MODULE_COLORS[item.id] || MODULE_COLORS.chat;
  const isHighlighted = isActive || hovered;

  // Health dot color
  let healthColor = THEME.textMuted;
  let healthGlow = 'none';
  if (healthStatus === 'connected') {
    healthColor = THEME.statusActive;
    healthGlow = `0 0 4px ${THEME.statusActive}`;
  } else if (healthStatus === 'partial') {
    healthColor = THEME.warning;
  } else if (healthStatus === 'disconnected') {
    healthColor = THEME.danger;
  }

  return (
    <EuiToolTip position="right" content={expanded ? undefined : `${item.label} — ${item.desc}`}>
      <button
        onClick={() => onClick(item.id)}
        onMouseEnter={() => setHovered(true)}
        onMouseLeave={() => setHovered(false)}
        aria-label={item.label}
        aria-current={isActive ? 'page' : undefined}
        style={{
          width: '100%',
          height: 40,
          display: 'flex',
          alignItems: 'center',
          gap: 10,
          padding: expanded ? '0 12px' : '0',
          justifyContent: expanded ? 'flex-start' : 'center',
          cursor: 'pointer',
          border: 'none',
          borderLeft: isActive ? `3px solid ${mc.accent}` : '3px solid transparent',
          backgroundColor: isActive
            ? mc.accent + '10'
            : hovered
              ? 'rgba(255, 255, 255, 0.03)'
              : 'transparent',
          boxShadow: isActive ? `inset 0 0 16px ${mc.glow}` : 'none',
          transition: 'all 0.15s ease',
          outline: 'none',
          position: 'relative',
        }}
      >
        {/* Icon with health dot */}
        <div style={{ position: 'relative', flexShrink: 0 }}>
          <EuiIcon
            type={item.icon}
            size="m"
            color={isHighlighted ? mc.accent : THEME.textMuted}
          />
          {/* Health dot — bottom-right corner of icon */}
          <span style={{
            position: 'absolute',
            bottom: -1,
            right: -2,
            width: 6,
            height: 6,
            borderRadius: '50%',
            backgroundColor: healthColor,
            boxShadow: healthGlow,
            border: `1px solid ${THEME.card}`,
          }} />
        </div>

        {/* Label (visible when expanded) */}
        {expanded && (
          <div style={{
            display: 'flex',
            flexDirection: 'column',
            minWidth: 0,
            opacity: expanded ? 1 : 0,
            transition: 'opacity 0.15s ease',
          }}>
            <span style={{
              fontSize: 12,
              fontWeight: isActive ? 600 : 500,
              color: isHighlighted ? mc.accent : THEME.textSecondary,
              whiteSpace: 'nowrap',
              overflow: 'hidden',
              textOverflow: 'ellipsis',
              lineHeight: 1.2,
            }}>
              {item.label}
            </span>
          </div>
        )}
      </button>
    </EuiToolTip>
  );
}

// ─── PallasNavigationRail ─────────────────────────────────────────────────────

export function PallasNavigationRail({ activeModule, onModuleChange, toolHealth = {} }) {
  const [expanded, setExpanded] = React.useState(false);

  return (
    <nav
      aria-label="Module navigation"
      onMouseEnter={() => setExpanded(true)}
      onMouseLeave={() => setExpanded(false)}
      style={{
        width: expanded ? 170 : 52,
        minWidth: expanded ? 170 : 52,
        display: 'flex',
        flexDirection: 'column',
        backgroundColor: THEME.card,
        borderRight: `1px solid ${THEME.border}`,
        height: '100%',
        overflow: 'hidden',
        transition: 'width 0.2s cubic-bezier(0.4, 0, 0.2, 1), min-width 0.2s cubic-bezier(0.4, 0, 0.2, 1)',
        flexShrink: 0,
      }}
    >
      <div className="pallas-scrollbar" style={{
        flex: 1,
        display: 'flex',
        flexDirection: 'column',
        paddingTop: 6,
        paddingBottom: 6,
        overflowY: 'auto',
        overflowX: 'hidden',
      }}>
        {NAV_GROUPS.map((group, gi) => (
          <React.Fragment key={group.label}>
            {/* Group divider */}
            {gi > 0 && (
              <div style={{
                height: 1,
                margin: '6px 10px',
                backgroundColor: THEME.border,
                opacity: 0.4,
              }} />
            )}

            {/* Group label (visible when expanded) */}
            {expanded && (
              <div style={{
                fontSize: 9,
                fontWeight: 700,
                color: THEME.textFaint,
                textTransform: 'uppercase',
                letterSpacing: '0.1em',
                padding: '6px 16px 2px',
                whiteSpace: 'nowrap',
                overflow: 'hidden',
              }}>
                {group.label}
              </div>
            )}

            {/* Module buttons */}
            {group.items.map(item => (
              <NavButton
                key={item.id}
                item={item}
                isActive={activeModule === item.id}
                expanded={expanded}
                onClick={onModuleChange}
                healthStatus={getModuleHealth(item.id, toolHealth)}
              />
            ))}
          </React.Fragment>
        ))}
      </div>
    </nav>
  );
}

export default PallasNavigationRail;
