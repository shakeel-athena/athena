/**
 * PallasDecoderLab — Decoder Lab AI Plugin
 *
 * Redesigned with shared PallasUI components and Decoder accent color (#C084FC).
 * Generate and test Wazuh decoders from raw log samples using AI.
 */

import React, { useState, useCallback } from 'react';
import { EuiIcon } from '@elastic/eui';
import { THEME } from '../../utils/theme';
import { MODULE_COLORS, ModuleHeader, ActionChip, GlassCard, PillBadge, FONT } from './PallasUI';
import { ResponsePanel } from './PallasResponsePanel';
import { pallasPost } from '../../services/pallasService';

const ACCENT = MODULE_COLORS.decoder.accent;

// ─── Constants ───────────────────────────────────────────────────────────────

const EXPECTED_FIELDS = ['srcip', 'dstip', 'srcport', 'dstport', 'user', 'action', 'protocol', 'id', 'url', 'status'];

const INITIAL_STEPS = [
  { id: 'analyze',  label: 'Analyzing Log',       status: 'pending' },
  { id: 'generate', label: 'Generating Decoder',  status: 'pending' },
  { id: 'test',     label: 'Testing with Logtest', status: 'pending' },
  { id: 'complete', label: 'Complete',             status: 'pending' },
];

// ─── DecoderStepper ─────────────────────────────────────────────────────────

function DecoderStepper({ steps }) {
  return (
    <div style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'center', gap: 0, margin: '24px 0' }}>
      {steps.map((step, i) => {
        const isLast = i === steps.length - 1;
        const circleSize = 32;

        let bg = THEME.bgDeep;
        let borderColor = THEME.border;
        let content = <span style={{ fontSize: 13, fontWeight: 600, color: THEME.textSecondary }}>{i + 1}</span>;

        if (step.status === 'active') {
          bg = ACCENT;
          borderColor = ACCENT;
          content = (
            <span style={{
              display: 'inline-block', width: 14, height: 14,
              border: '2px solid rgba(255,255,255,0.3)', borderTopColor: '#fff',
              borderRadius: '50%', animation: 'pallas-spin 0.6s linear infinite',
            }} />
          );
        } else if (step.status === 'complete') {
          bg = '#00C853';
          borderColor = '#00C853';
          content = <EuiIcon type="check" size="s" color="#fff" />;
        } else if (step.status === 'error') {
          bg = '#FF4D4D';
          borderColor = '#FF4D4D';
          content = <EuiIcon type="cross" size="s" color="#fff" />;
        }

        const connectorBg = step.status === 'complete'
          ? `linear-gradient(90deg, ${ACCENT}, ${ACCENT}AA)`
          : THEME.border;

        return (
          <div key={step.id} style={{ display: 'flex', alignItems: 'flex-start' }}>
            <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', minWidth: 80 }}>
              <div style={{
                width: circleSize, height: circleSize, borderRadius: '50%',
                background: bg, border: `2px solid ${borderColor}`,
                display: 'flex', alignItems: 'center', justifyContent: 'center',
              }}>
                {content}
              </div>
              <span style={{
                marginTop: 8, fontSize: 11,
                fontWeight: step.status === 'active' || step.status === 'complete' ? 700 : 400,
                color: step.status === 'active' || step.status === 'complete' ? THEME.text : THEME.textSecondary,
                textAlign: 'center', whiteSpace: 'nowrap',
              }}>
                {step.label}
              </span>
            </div>
            {!isLast && (
              <div style={{
                width: 48, height: 2, marginTop: circleSize / 2,
                background: connectorBg, flexShrink: 0,
              }} />
            )}
          </div>
        );
      })}
    </div>
  );
}

// ─── Main Component ─────────────────────────────────────────────────────────

export default function PallasDecoderLab({ connectionStatus, onQueryComplete }) {
  const [rawLog, setRawLog] = useState('');
  const [selectedFields, setSelectedFields] = useState([]);
  const [isGenerating, setIsGenerating] = useState(false);
  const [result, setResult] = useState(null);
  const [copiedXml, setCopiedXml] = useState(false);
  const [steps, setSteps] = useState(INITIAL_STEPS.map(s => ({ ...s })));
  const [aiExplanation, setAiExplanation] = useState('');
  const [aiLoading, setAiLoading] = useState(false);
  const [aiError, setAiError] = useState('');

  const toggleField = useCallback((field) => {
    setSelectedFields(prev =>
      prev.includes(field) ? prev.filter(f => f !== field) : [...prev, field]
    );
  }, []);

  const updateStep = useCallback((stepId, status) => {
    setSteps(prev => prev.map(s => s.id === stepId ? { ...s, status } : s));
  }, []);

  // ── Generate decoder ──────────────────────────────────────────────────

  const handleGenerate = useCallback(async () => {
    if (!rawLog.trim() || isGenerating) return;

    setIsGenerating(true);
    setResult(null);
    setAiExplanation('');
    setAiError('');
    setSteps(INITIAL_STEPS.map(s => ({ ...s })));

    try {
      updateStep('analyze', 'active');
      await new Promise(r => setTimeout(r, 600));
      updateStep('analyze', 'complete');

      updateStep('generate', 'active');
      const data = await pallasPost('/api/decoder/generate', {
        raw_log: rawLog.trim(),
        hints: { expected_fields: selectedFields },
      });
      updateStep('generate', 'complete');

      updateStep('test', 'active');
      await new Promise(r => setTimeout(r, 400));

      if (data.success === false || data.error) {
        updateStep('test', 'error');
        updateStep('complete', 'error');
        setResult({ error: data.error || 'Decoder generation failed', ...data });
      } else {
        updateStep('test', 'complete');
        updateStep('complete', 'complete');
        setResult(data);
        if (onQueryComplete) onQueryComplete('decoder', 'Generate decoder', 0);
      }
    } catch (err) {
      setSteps(prev => prev.map(s => s.status === 'active' ? { ...s, status: 'error' } : s));
      setResult({ error: err.message });
    } finally {
      setIsGenerating(false);
    }
  }, [rawLog, selectedFields, isGenerating, updateStep, onQueryComplete]);

  // ── Explain decoder ───────────────────────────────────────────────────

  const handleExplain = useCallback(async () => {
    if (!result?.decoder_xml || aiLoading) return;
    setAiLoading(true);
    setAiError('');
    setAiExplanation('');
    try {
      const data = await pallasPost('/api/decoder/explain', { decoder_xml: result.decoder_xml });
      setAiExplanation(data.explanation || data.text || JSON.stringify(data));
    } catch (err) {
      setAiError(err.message);
    } finally {
      setAiLoading(false);
    }
  }, [result, aiLoading]);

  // ── Copy XML ──────────────────────────────────────────────────────────

  const handleCopyXml = useCallback(() => {
    if (!result?.decoder_xml) return;
    navigator.clipboard.writeText(result.decoder_xml).then(() => {
      setCopiedXml(true);
      setTimeout(() => setCopiedXml(false), 2000);
    });
  }, [result]);

  // ── Render ────────────────────────────────────────────────────────────

  return (
    <div style={{ display: 'flex', flexDirection: 'column', height: '100%', fontFamily: FONT.base }}>
      {/* Module Header */}
      <ModuleHeader
        icon="wrench"
        title="Decoder Lab"
        description="Generate and test Wazuh decoders from raw log samples using AI"
        accent={ACCENT}
        connectionStatus={connectionStatus}
      />

      {/* Scrollable content */}
      <div style={{ flex: 1, overflowY: 'auto', padding: '16px 20px' }} className="pallas-scrollbar">
        {/* Input Panel */}
        <GlassCard style={{ padding: 20, marginBottom: 20 }}>
          {/* Raw Log */}
          <label style={{ display: 'block', fontSize: 12, fontWeight: 600, color: THEME.textSecondary, marginBottom: 6 }}>
            <EuiIcon type="document" size="s" color={ACCENT} /> Raw Log Sample
          </label>
          <textarea
            value={rawLog}
            onChange={e => setRawLog(e.target.value)}
            placeholder="Paste a raw log line here..."
            rows={4}
            style={{
              width: '100%', background: 'rgba(255,255,255,0.02)',
              border: `1px solid ${THEME.border}`, borderRadius: 8,
              color: THEME.text, fontFamily: FONT.mono, fontSize: 13,
              padding: '10px 12px', resize: 'vertical', outline: 'none', boxSizing: 'border-box',
            }}
          />

          {/* Expected Fields */}
          <div style={{ marginTop: 16 }}>
            <label style={{ display: 'block', fontSize: 12, fontWeight: 600, color: THEME.textSecondary, marginBottom: 8 }}>
              <EuiIcon type="list" size="s" color={ACCENT} /> Expected Fields (optional)
            </label>
            <div style={{ display: 'flex', flexWrap: 'wrap', gap: 6 }}>
              {EXPECTED_FIELDS.map(field => (
                <ActionChip
                  key={field}
                  label={field}
                  onClick={() => toggleField(field)}
                  active={selectedFields.includes(field)}
                  accent={ACCENT}
                  style={{ fontFamily: FONT.mono }}
                />
              ))}
            </div>
          </div>

          {/* Generate Button */}
          <div style={{ display: 'flex', justifyContent: 'flex-end', marginTop: 18 }}>
            <button
              onClick={handleGenerate}
              disabled={!rawLog.trim() || isGenerating}
              style={{
                background: (!rawLog.trim() || isGenerating) ? THEME.border : ACCENT,
                border: 'none', borderRadius: 8, color: '#fff',
                fontSize: 13, fontWeight: 700, padding: '9px 22px',
                cursor: (!rawLog.trim() || isGenerating) ? 'not-allowed' : 'pointer',
                display: 'flex', alignItems: 'center', gap: 6,
                opacity: (!rawLog.trim() || isGenerating) ? 0.5 : 1,
                outline: 'none',
              }}
            >
              {isGenerating ? (
                <span style={{
                  display: 'inline-block', width: 14, height: 14,
                  border: '2px solid rgba(255,255,255,0.3)', borderTopColor: '#fff',
                  borderRadius: '50%', animation: 'pallas-spin 0.6s linear infinite',
                }} />
              ) : (
                <EuiIcon type="wrench" size="s" color="#fff" />
              )}
              {isGenerating ? 'Generating...' : 'Generate Decoder'}
            </button>
          </div>
        </GlassCard>

        {/* Stepper */}
        {isGenerating && <DecoderStepper steps={steps} />}

        {/* Results */}
        {result && (
          <div style={{ marginTop: 8 }}>
            {/* Error block */}
            {result.error && !result.decoder_xml && (
              <div style={{
                background: 'rgba(255, 77, 77, 0.08)', border: '1px solid rgba(255, 77, 77, 0.3)',
                borderRadius: 8, padding: '14px 18px', color: '#FF6B6B', fontSize: 13,
                marginBottom: 16, display: 'flex', alignItems: 'center', gap: 8,
              }}>
                <EuiIcon type="cross" size="s" color="#FF6B6B" /> {result.error}
              </div>
            )}

            {/* Decoder XML card */}
            {result.decoder_xml && (
              <GlassCard style={{
                overflow: 'hidden', marginBottom: 20,
                borderLeft: `4px solid ${ACCENT}`,
              }}>
                {/* Header */}
                <div style={{
                  display: 'flex', alignItems: 'center', justifyContent: 'space-between',
                  padding: '12px 16px', borderBottom: `1px solid ${THEME.border}`,
                }}>
                  <span style={{ fontSize: 13, fontWeight: 700, color: THEME.text, display: 'flex', alignItems: 'center', gap: 6 }}>
                    <EuiIcon type="document" size="s" color={ACCENT} /> Decoder XML
                  </span>
                  <div style={{ display: 'flex', gap: 8 }}>
                    <button
                      onClick={handleExplain}
                      disabled={aiLoading}
                      style={{
                        background: 'transparent', border: `1px solid ${ACCENT}`,
                        borderRadius: 6, color: ACCENT, fontSize: 12, fontWeight: 600,
                        padding: '4px 12px', cursor: aiLoading ? 'not-allowed' : 'pointer',
                        display: 'flex', alignItems: 'center', gap: 4, outline: 'none',
                      }}
                    >
                      {aiLoading ? (
                        <span style={{
                          display: 'inline-block', width: 11, height: 11,
                          border: '2px solid rgba(255,255,255,0.3)', borderTopColor: ACCENT,
                          borderRadius: '50%', animation: 'pallas-spin 0.6s linear infinite',
                        }} />
                      ) : (
                        <EuiIcon type="inspect" size="s" color={ACCENT} />
                      )}
                      {aiLoading ? 'Explaining...' : 'Explain'}
                    </button>
                    <button
                      onClick={handleCopyXml}
                      style={{
                        background: 'transparent', border: `1px solid ${THEME.border}`,
                        borderRadius: 6, color: copiedXml ? '#00C853' : THEME.textSecondary,
                        fontSize: 12, fontWeight: 600, padding: '4px 12px', cursor: 'pointer',
                        display: 'flex', alignItems: 'center', gap: 4, outline: 'none',
                      }}
                    >
                      <EuiIcon type={copiedXml ? 'check' : 'copy'} size="s" />
                      {copiedXml ? 'Copied' : 'Copy'}
                    </button>
                  </div>
                </div>

                {/* XML content */}
                <pre style={{
                  margin: 0, padding: 16, background: THEME.bg, color: THEME.text,
                  fontFamily: FONT.mono, fontSize: 12, lineHeight: 1.6,
                  overflowX: 'auto', whiteSpace: 'pre-wrap', wordBreak: 'break-word',
                }}>
                  {result.decoder_xml}
                </pre>
              </GlassCard>
            )}

            {/* AI Explanation */}
            {aiExplanation && (
              <div style={{ marginBottom: 20 }}>
                <ResponsePanel content={aiExplanation} accent={ACCENT} />
              </div>
            )}

            {aiError && (
              <div style={{
                background: 'rgba(255, 77, 77, 0.08)', border: '1px solid rgba(255, 77, 77, 0.3)',
                borderRadius: 8, padding: '10px 14px', color: '#FF6B6B', fontSize: 12,
                marginBottom: 16, display: 'flex', alignItems: 'center', gap: 8,
              }}>
                <EuiIcon type="cross" size="s" color="#FF6B6B" /> {aiError}
              </div>
            )}

            {/* Extracted Fields */}
            {result.extracted_fields && Object.keys(result.extracted_fields).length > 0 && (
              <GlassCard style={{ padding: 16, marginBottom: 20 }}>
                <h4 style={{ margin: '0 0 12px', fontSize: 13, fontWeight: 700, color: THEME.text, display: 'flex', alignItems: 'center', gap: 6 }}>
                  <EuiIcon type="list" size="s" color={ACCENT} /> Extracted Fields
                </h4>
                <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(200px, 1fr))', gap: 10 }}>
                  {Object.entries(result.extracted_fields).map(([key, value]) => (
                    <div key={key} style={{
                      background: 'rgba(255,255,255,0.02)', border: `1px solid ${THEME.border}`,
                      borderRadius: 6, padding: '8px 12px', display: 'flex', alignItems: 'center', gap: 8,
                    }}>
                      <div style={{ flex: 1, minWidth: 0 }}>
                        <div style={{ fontSize: 11, fontFamily: FONT.mono, color: THEME.textMuted, marginBottom: 2 }}>{key}</div>
                        <div style={{ fontSize: 13, fontFamily: FONT.mono, color: THEME.text, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{value}</div>
                      </div>
                      <EuiIcon type="check" size="s" color="#00C853" />
                    </div>
                  ))}
                </div>
              </GlassCard>
            )}

            {/* Attempt History */}
            {result.attempts && result.attempts.length > 0 && (
              <GlassCard style={{ padding: 16, marginBottom: 20 }}>
                <h4 style={{ margin: '0 0 12px', fontSize: 13, fontWeight: 700, color: THEME.text, display: 'flex', alignItems: 'center', gap: 6 }}>
                  <EuiIcon type="refresh" size="s" color={ACCENT} /> Attempt History
                </h4>
                <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
                  {result.attempts.map((attempt, i) => {
                    const success = attempt.success || attempt.status === 'success';
                    return (
                      <div key={i} style={{
                        display: 'flex', alignItems: 'center', gap: 10, padding: '8px 12px',
                        background: 'rgba(255,255,255,0.02)', border: `1px solid ${THEME.border}`,
                        borderRadius: 6, fontSize: 13,
                      }}>
                        <span style={{ color: THEME.textMuted, fontWeight: 600, fontSize: 12, minWidth: 24 }}>#{i + 1}</span>
                        <PillBadge
                          label={success ? 'PASS' : 'FAIL'}
                          color={success ? '#00C853' : '#FF4D4D'}
                          bg={success ? 'rgba(0,200,83,0.12)' : 'rgba(255,77,77,0.12)'}
                          style={{ fontSize: 10, fontWeight: 700 }}
                        />
                        <span style={{ color: success ? THEME.text : '#FF6B6B' }}>
                          {success ? 'Decoder validated successfully' : (attempt.error || attempt.message || 'Validation failed')}
                        </span>
                      </div>
                    );
                  })}
                </div>
              </GlassCard>
            )}
          </div>
        )}

        {/* Completed Stepper */}
        {result && !isGenerating && <DecoderStepper steps={steps} />}
      </div>
    </div>
  );
}
