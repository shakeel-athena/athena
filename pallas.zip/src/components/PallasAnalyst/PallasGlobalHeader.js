/**
 * PallasGlobalHeader — Unified Top Bar
 *
 * Redesigned: Single compact header that combines branding + module context.
 * Shows current module name with its accent color, connection status,
 * command palette trigger, and a subtle accent gradient underline.
 */

import React from 'react';
import { EuiIcon, EuiToolTip } from '@elastic/eui';
import { THEME } from '../../utils/theme';
import { MODULE_COLORS, FONT } from './PallasUI';

// ─── Connection Status ───────────────────────────────────────────────────────

const STATUS_MAP = {
  connected:    { color: THEME.statusActive, label: 'Online',         icon: 'checkInCircleFilled' },
  connecting:   { color: THEME.warning,      label: 'Connecting...',  icon: 'clock' },
  reconnecting: { color: THEME.warning,      label: 'Reconnecting...', icon: 'refresh' },
  error:        { color: THEME.danger,       label: 'Offline',        icon: 'crossInACircleFilled' },
};

// ─── Sub-components ──────────────────────────────────────────────────────────

function PallasBranding({ moduleAccent }) {
  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
      <div style={{
        width: 28,
        height: 28,
        borderRadius: 8,
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        background: `linear-gradient(135deg, ${moduleAccent}25, ${moduleAccent}08)`,
        border: `1px solid ${moduleAccent}30`,
      }}>
        <EuiIcon type="machineLearningApp" size="m" color={moduleAccent} />
      </div>
      <div style={{ display: 'flex', flexDirection: 'column', lineHeight: 1 }}>
        <span style={{
          fontSize: 14,
          fontWeight: 700,
          letterSpacing: '0.1em',
          color: moduleAccent,
          fontFamily: FONT.base,
        }}>
          PALLAS
        </span>
        <span style={{
          fontSize: 9,
          fontWeight: 600,
          letterSpacing: '0.08em',
          textTransform: 'uppercase',
          color: THEME.textMuted,
        }}>
          SOC Intelligence
        </span>
      </div>
    </div>
  );
}

function CommandPaletteButton({ onClick, accent }) {
  const [hovered, setHovered] = React.useState(false);

  return (
    <EuiToolTip position="bottom" content="Command Palette (Ctrl+K)">
      <button
        onClick={onClick}
        onMouseEnter={() => setHovered(true)}
        onMouseLeave={() => setHovered(false)}
        aria-label="Open command palette (Ctrl+K)"
        style={{
          display: 'flex',
          alignItems: 'center',
          gap: 6,
          padding: '4px 12px',
          borderRadius: 8,
          border: `1px solid ${hovered ? accent + '40' : THEME.border}`,
          backgroundColor: hovered ? accent + '08' : 'rgba(255, 255, 255, 0.02)',
          cursor: 'pointer',
          color: hovered ? accent : THEME.textMuted,
          fontSize: 11,
          fontWeight: 500,
          fontFamily: 'inherit',
          transition: 'all 0.15s ease',
          outline: 'none',
        }}
      >
        <EuiIcon type="search" size="s" />
        <span style={{ fontFamily: FONT.mono, fontSize: 10 }}>Ctrl+K</span>
      </button>
    </EuiToolTip>
  );
}

function ConnectionStatus({ status }) {
  const config = STATUS_MAP[status] || STATUS_MAP.error;
  const isPulsing = status === 'connecting' || status === 'reconnecting';

  return (
    <div style={{
      display: 'flex',
      alignItems: 'center',
      gap: 5,
      padding: '3px 8px',
      borderRadius: 6,
      background: config.color + '10',
      border: `1px solid ${config.color}20`,
    }}>
      <span style={{
        width: 6,
        height: 6,
        borderRadius: '50%',
        backgroundColor: config.color,
        boxShadow: status === 'connected' ? `0 0 6px ${config.color}` : 'none',
        animation: isPulsing ? 'pallas-breathe 1.5s ease-in-out infinite' : 'none',
        flexShrink: 0,
      }} />
      <span style={{
        fontSize: 10,
        fontWeight: 600,
        color: config.color,
        letterSpacing: '0.02em',
      }}>
        {config.label}
      </span>
    </div>
  );
}

// ─── PallasGlobalHeader ──────────────────────────────────────────────────────

export function PallasGlobalHeader({ connectionStatus, activeModule, onCommandPalette }) {
  const mc = MODULE_COLORS[activeModule] || MODULE_COLORS.chat;

  return (
    <header
      role="banner"
      style={{
        height: 46,
        minHeight: 46,
        display: 'flex',
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'space-between',
        padding: '0 14px',
        backgroundColor: THEME.card,
        borderBottom: `1px solid ${THEME.border}`,
        boxShadow: `0 1px 4px rgba(0,0,0,0.25), inset 0 -1px 0 ${mc.accent}15`,
        zIndex: 10,
        flexShrink: 0,
        position: 'relative',
      }}
    >
      {/* Left: Branding */}
      <PallasBranding moduleAccent={mc.accent} />

      {/* Center: Module name — subtle, centered */}
      <div style={{
        position: 'absolute',
        left: '50%',
        transform: 'translateX(-50%)',
        display: 'flex',
        alignItems: 'center',
        gap: 6,
      }}>
        <span style={{
          fontSize: 11,
          fontWeight: 600,
          color: mc.accent,
          letterSpacing: '0.04em',
          textTransform: 'uppercase',
          opacity: 0.8,
        }}>
          {mc.label}
        </span>
      </div>

      {/* Right: Controls */}
      <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
        {onCommandPalette && (
          <CommandPaletteButton onClick={onCommandPalette} accent={mc.accent} />
        )}
        <ConnectionStatus status={connectionStatus} />
        <span style={{
          fontSize: 10,
          color: THEME.textFaint,
          fontFamily: FONT.mono,
          padding: '2px 5px',
          borderRadius: 4,
          background: 'rgba(255,255,255,0.03)',
          border: `1px solid ${THEME.border}`,
        }}>
          v4.0
        </span>
      </div>

      {/* Accent gradient underline */}
      <div style={{
        position: 'absolute',
        bottom: 0,
        left: 0,
        right: 0,
        height: 1,
        background: `linear-gradient(90deg, transparent 10%, ${mc.accent}30 50%, transparent 90%)`,
      }} />
    </header>
  );
}

export default PallasGlobalHeader;
