/**
 * PallasResponsePanel — Structured response display panel
 *
 * Redesigned with module accent color support, improved visual hierarchy,
 * confidence gauge always visible, SOC Analysis as distinct card,
 * and better suggestion chips.
 *
 * Exports:
 *   - ResponsePanel (named + default) — main response display
 *   - ComparePanel (named) — side-by-side comparison of pinned responses
 */

import React, { useState, useCallback } from 'react';
import { EuiIcon, EuiToolTip } from '@elastic/eui';
import { THEME } from '../../utils/theme';
import { FONT } from './PallasUI';
import PallasMarkdown from './PallasMarkdown';

// ─── ConfidenceGauge ─────────────────────────────────────────────────────────

function ConfidenceGauge({ value, accent }) {
  const pct = Math.round((value || 0) * 100);
  const color = pct >= 90 ? THEME.success : pct >= 70 ? accent || THEME.sevMedium : THEME.sevHigh;

  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
      <div style={{
        width: 48,
        height: 4,
        borderRadius: 2,
        backgroundColor: THEME.border,
        overflow: 'hidden',
        flexShrink: 0,
      }}>
        <div style={{
          width: `${pct}%`,
          height: '100%',
          backgroundColor: color,
          borderRadius: 2,
          transition: 'width 0.4s ease',
        }} />
      </div>
      <span style={{
        fontSize: 11,
        color,
        fontWeight: 700,
        fontFamily: FONT.mono,
        minWidth: 28,
      }}>
        {pct}%
      </span>
    </div>
  );
}

// ─── MetadataBar ─────────────────────────────────────────────────────────────

const MATCH_TYPE_STYLES = {
  pattern_match:  { label: 'Pattern Match',  color: THEME.accent,     bg: 'rgba(22, 197, 192, 0.12)' },
  keyword_match:  { label: 'Keyword Match',  color: THEME.primary,    bg: 'rgba(97, 162, 255, 0.12)' },
  ai_interpreted: { label: 'AI Interpreted', color: THEME.sevMedium,  bg: 'rgba(245, 158, 11, 0.12)' },
  fallback:       { label: 'Fallback',       color: THEME.textMuted,  bg: 'rgba(90, 109, 138, 0.15)' },
};

function formatStrategy(s) {
  if (!s) return '—';
  return s.replace(/_/g, ' ').replace(/\b\w/g, c => c.toUpperCase());
}

function MetaChip({ icon, label, value, mono, accent }) {
  const accentColor = accent || THEME.accent;
  return (
    <div style={{
      display: 'inline-flex',
      alignItems: 'center',
      gap: 6,
      padding: '4px 10px',
      borderRadius: 6,
      background: 'rgba(255,255,255,0.03)',
      border: `1px solid ${THEME.border}`,
    }}>
      {icon && <EuiIcon type={icon} size="s" color={accentColor} />}
      <span style={{ fontSize: 10, color: THEME.textMuted, fontWeight: 600, textTransform: 'uppercase', letterSpacing: '0.03em' }}>
        {label}
      </span>
      <span style={{
        fontSize: 11,
        color: THEME.text,
        fontWeight: 500,
        fontFamily: mono ? FONT.mono : undefined,
      }}>
        {value}
      </span>
    </div>
  );
}

function MetadataBar({ metadata, accent }) {
  if (!metadata) return null;

  const matchInfo = MATCH_TYPE_STYLES[metadata.match_type] || MATCH_TYPE_STYLES.fallback;
  const accentColor = accent || THEME.accent;

  return (
    <div style={{
      display: 'flex',
      flexWrap: 'wrap',
      alignItems: 'center',
      gap: 6,
      marginBottom: 16,
    }}>
      {/* Query */}
      {metadata.query && (
        <MetaChip icon="search" label="Query" value={metadata.query} accent={accentColor} />
      )}

      {/* Primary Tool */}
      {metadata.tools?.primary && (
        <MetaChip icon="wrench" label="Tool" value={metadata.tools.primary} mono accent={accentColor} />
      )}

      {/* Results count */}
      {metadata.results_count != null && (
        <MetaChip icon="database" label="Results" value={`${metadata.results_count} found`} accent={accentColor} />
      )}

      {/* Execution Time */}
      {typeof metadata.execution_time === 'number' && (
        <MetaChip icon="clock" label="Time" value={`${metadata.execution_time.toFixed(2)}s`} mono accent={accentColor} />
      )}

      {/* Match Type — pushed right */}
      {metadata.match_type && (
        <span style={{
          display: 'inline-flex',
          alignItems: 'center',
          padding: '3px 10px',
          borderRadius: 6,
          fontSize: 10,
          fontWeight: 600,
          textTransform: 'uppercase',
          letterSpacing: '0.03em',
          color: matchInfo.color,
          backgroundColor: matchInfo.bg,
          marginLeft: 'auto',
        }}>
          {matchInfo.label}
        </span>
      )}

      {/* Correlation */}
      {metadata.correlation_type && (
        <MetaChip label="Correlation" value={formatStrategy(metadata.correlation_type)} accent={accentColor} />
      )}
    </div>
  );
}

function MetaItem({ label, value, mono }) {
  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: 4 }}>
      <span style={{
        fontSize: 10,
        color: THEME.textMuted,
        fontWeight: 600,
        textTransform: 'uppercase',
        letterSpacing: '0.03em',
      }}>
        {label}
      </span>
      <span style={{
        fontSize: 12,
        color: THEME.textSecondary,
        fontWeight: 500,
        fontFamily: mono ? FONT.mono : undefined,
      }}>
        {value || '—'}
      </span>
    </div>
  );
}

// ─── SOCAnalysisSection ───────────────────────────────────────────────────────

function SOCAnalysisSection({ content, accent }) {
  if (!content) return null;
  const accentColor = accent || THEME.accent;

  return (
    <div style={{
      marginTop: 16,
      borderRadius: 8,
      overflow: 'hidden',
      border: `1px solid ${accentColor}20`,
    }}>
      {/* Header strip */}
      <div style={{
        display: 'flex',
        alignItems: 'center',
        gap: 8,
        padding: '8px 14px',
        background: accentColor + '08',
        borderBottom: `1px solid ${accentColor}15`,
      }}>
        <div style={{
          width: 20,
          height: 20,
          borderRadius: '50%',
          background: `linear-gradient(135deg, ${accentColor}, ${accentColor}60)`,
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          flexShrink: 0,
        }}>
          <EuiIcon type="securitySignal" size="s" color="#ffffff" />
        </div>
        <span style={{
          fontSize: 11,
          fontWeight: 700,
          color: accentColor,
          textTransform: 'uppercase',
          letterSpacing: '0.05em',
        }}>
          SOC Analysis
        </span>
      </div>

      {/* Content */}
      <div style={{
        padding: '12px 14px',
        background: accentColor + '04',
      }}>
        <PallasMarkdown content={content} />
      </div>
    </div>
  );
}

// ─── SuggestionChips ─────────────────────────────────────────────────────────

function SuggestionChips({ suggestions, onSuggestionClick, accent }) {
  const [hoveredIdx, setHoveredIdx] = useState(null);
  const accentColor = accent || THEME.accent;

  if (!suggestions || suggestions.length === 0) return null;

  return (
    <div style={{
      marginTop: 20,
      padding: '14px 16px',
      borderRadius: 8,
      background: 'rgba(255,255,255,0.02)',
      border: `1px solid ${THEME.border}`,
    }}>
      <div style={{
        display: 'flex',
        alignItems: 'center',
        gap: 6,
        marginBottom: 10,
      }}>
        <EuiIcon type="branch" size="s" color={accentColor} />
        <span style={{
          fontSize: 11,
          fontWeight: 700,
          color: THEME.textSecondary,
          textTransform: 'uppercase',
          letterSpacing: '0.04em',
        }}>
          Related queries
        </span>
      </div>
      <div style={{ display: 'flex', flexWrap: 'wrap', gap: 8 }}>
        {suggestions.map((suggestion, idx) => (
          <button
            key={idx}
            onClick={() => onSuggestionClick && onSuggestionClick(suggestion)}
            onMouseEnter={() => setHoveredIdx(idx)}
            onMouseLeave={() => setHoveredIdx(null)}
            style={{
              padding: '7px 14px',
              borderRadius: 20,
              border: `1px solid ${hoveredIdx === idx ? accentColor + '60' : accentColor + '25'}`,
              backgroundColor: hoveredIdx === idx ? accentColor + '12' : accentColor + '06',
              color: hoveredIdx === idx ? accentColor : THEME.textSecondary,
              fontSize: 12,
              fontWeight: 500,
              cursor: 'pointer',
              transition: 'all 0.15s ease',
              fontFamily: 'inherit',
              outline: 'none',
            }}
          >
            {suggestion}
          </button>
        ))}
      </div>
    </div>
  );
}

// ─── LoadingSkeleton ──────────────────────────────────────────────────────────

const PIPELINE_STAGES = [
  { icon: 'search',            label: 'Selecting strategy' },
  { icon: 'database',          label: 'Querying data' },
  { icon: 'link',              label: 'Correlating results' },
  { icon: 'editorCodeBlock',   label: 'Formatting response' },
  { icon: 'securitySignal',    label: 'SOC analysis' },
  { icon: 'check',             label: 'Finalizing' },
];

function LoadingSkeleton({ onCancel, elapsedSeconds, currentStage, accent }) {
  const stageIdx = Math.min(currentStage || 0, PIPELINE_STAGES.length - 1);
  const stage = PIPELINE_STAGES[stageIdx];
  const accentColor = accent || THEME.accent;

  return (
    <div style={{
      padding: '20px 0',
      animation: 'pallas-fadeIn 0.3s ease',
    }}>
      {/* Pipeline stages — horizontal */}
      <div style={{
        display: 'flex',
        alignItems: 'center',
        gap: 0,
        marginBottom: 24,
      }}>
        {PIPELINE_STAGES.map((s, i) => {
          const isDone = i < stageIdx;
          const isActive = i === stageIdx;
          const color = isDone ? THEME.success : isActive ? accentColor : THEME.textMuted + '40';
          return (
            <React.Fragment key={i}>
              <div style={{
                display: 'flex',
                flexDirection: 'column',
                alignItems: 'center',
                gap: 6,
                flex: 1,
                opacity: isDone || isActive ? 1 : 0.4,
                transition: 'opacity 0.3s',
              }}>
                <div style={{
                  width: 28,
                  height: 28,
                  borderRadius: '50%',
                  background: isDone
                    ? THEME.success + '20'
                    : isActive
                      ? `linear-gradient(135deg, ${accentColor}30, ${accentColor}10)`
                      : 'rgba(255,255,255,0.04)',
                  border: `1.5px solid ${color}`,
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  flexShrink: 0,
                  animation: isActive ? 'pallas-glow 2s ease-in-out infinite' : 'none',
                }}>
                  <EuiIcon
                    type={isDone ? 'check' : s.icon}
                    size="s"
                    color={isDone ? THEME.success : isActive ? accentColor : THEME.textMuted}
                  />
                </div>
                <span style={{
                  fontSize: 9,
                  fontWeight: isActive ? 600 : 400,
                  color: isActive ? accentColor : isDone ? THEME.textSecondary : THEME.textMuted,
                  textAlign: 'center',
                  lineHeight: 1.2,
                }}>
                  {s.label}
                </span>
              </div>
              {i < PIPELINE_STAGES.length - 1 && (
                <div style={{
                  flex: 0.5,
                  height: 1,
                  backgroundColor: isDone ? THEME.success + '40' : THEME.border,
                  marginBottom: 20,
                  transition: 'background-color 0.3s',
                }} />
              )}
            </React.Fragment>
          );
        })}
      </div>

      {/* Cancel + timer */}
      <div style={{
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'space-between',
        marginBottom: 16,
      }}>
        <span style={{ fontSize: 12, color: THEME.textMuted }}>
          {stage.label}...
          {elapsedSeconds != null && (
            <span style={{ fontFamily: FONT.mono, marginLeft: 6, fontSize: 11, color: THEME.textMuted }}>
              {elapsedSeconds}s
            </span>
          )}
        </span>
        {onCancel && (
          <button
            onClick={onCancel}
            style={{
              padding: '5px 14px',
              borderRadius: 6,
              border: `1px solid ${THEME.border}`,
              backgroundColor: 'rgba(255,255,255,0.03)',
              color: THEME.textMuted,
              fontSize: 12,
              cursor: 'pointer',
              fontFamily: 'inherit',
              outline: 'none',
              transition: 'all 0.15s',
            }}
            onMouseEnter={(e) => {
              e.currentTarget.style.borderColor = '#F87171';
              e.currentTarget.style.color = '#F87171';
            }}
            onMouseLeave={(e) => {
              e.currentTarget.style.borderColor = THEME.border;
              e.currentTarget.style.color = THEME.textMuted;
            }}
          >
            Cancel
          </button>
        )}
      </div>

      {/* Shimmer lines */}
      {[100, 90, 95, 75, 85].map((w, i) => (
        <div
          key={i}
          style={{
            height: 8,
            borderRadius: 4,
            backgroundColor: 'rgba(255,255,255,0.04)',
            width: `${w}%`,
            marginBottom: 8,
            overflow: 'hidden',
            position: 'relative',
          }}
        >
          <div style={{
            position: 'absolute',
            inset: 0,
            background: `linear-gradient(90deg, transparent 0%, ${accentColor}08 50%, transparent 100%)`,
            animation: 'pallas-shimmer 1.8s infinite',
            animationDelay: `${i * 0.15}s`,
          }} />
        </div>
      ))}
    </div>
  );
}

// ─── Action Button ────────────────────────────────────────────────────────────

function ActionButton({ tooltip, iconType, onClick, active, accent }) {
  const [hovered, setHovered] = useState(false);
  const accentColor = accent || THEME.accent;

  return (
    <EuiToolTip content={tooltip} position="top">
      <button
        onClick={onClick}
        onMouseEnter={() => setHovered(true)}
        onMouseLeave={() => setHovered(false)}
        style={{
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          width: 26,
          height: 26,
          borderRadius: 5,
          border: `1px solid ${active || hovered ? accentColor + '40' : THEME.border}`,
          backgroundColor: active ? accentColor + '12' : hovered ? accentColor + '08' : 'transparent',
          cursor: 'pointer',
          transition: 'all 0.15s ease',
          flexShrink: 0,
          outline: 'none',
        }}
        aria-label={tooltip}
      >
        <EuiIcon
          type={iconType}
          size="s"
          color={active || hovered ? accentColor : THEME.textMuted}
        />
      </button>
    </EuiToolTip>
  );
}

// ─── ResponsePanel ────────────────────────────────────────────────────────────

function ResponsePanel({
  content,
  metadata,
  socAnalysis,
  suggestions,
  onSuggestionClick,
  isLoading,
  onCancel,
  onPin,
  isPinned,
  onRetry,
  warn,
  accent,
  // Loading state extras
  elapsedSeconds,
  currentStage,
}) {
  const [collapsed, setCollapsed] = useState(false);
  const [copied, setCopied] = useState(false);
  const accentColor = accent || THEME.accent;

  const handleCopy = useCallback(() => {
    if (!content) return;
    navigator.clipboard.writeText(content).then(() => {
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    });
  }, [content]);

  const handleExport = useCallback(() => {
    if (!content) return;
    const strategy = metadata?.strategy || 'response';
    const timestamp = new Date().toISOString().slice(0, 19).replace(/:/g, '-');
    const filename = `pallas-${strategy}-${timestamp}.md`;

    let mdContent = content;
    if (socAnalysis) {
      mdContent += `\n\n---\n## SOC Analysis\n\n${socAnalysis}`;
    }

    const blob = new Blob([mdContent], { type: 'text/markdown' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    a.click();
    URL.revokeObjectURL(url);
  }, [content, metadata, socAnalysis]);

  // Nothing to render
  if (!isLoading && !content) return null;

  return (
    <div style={{
      backgroundColor: THEME.card,
      borderRadius: 12,
      border: `1px solid ${THEME.border}`,
      overflow: 'hidden',
      boxShadow: '0 2px 12px rgba(0,0,0,0.2)',
      animation: 'pallas-fadeIn 0.25s ease',
    }}>
      {/* Accent top line */}
      <div style={{
        height: 2,
        background: `linear-gradient(90deg, ${accentColor}, ${accentColor}40, transparent)`,
      }} />

      {/* Header row */}
      <div style={{
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'space-between',
        padding: '10px 16px',
        borderBottom: `1px solid ${THEME.border}`,
        background: 'rgba(255,255,255,0.015)',
      }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
          <div style={{
            width: 22,
            height: 22,
            borderRadius: 6,
            background: `${accentColor}15`,
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            flexShrink: 0,
          }}>
            <EuiIcon type="machineLearningApp" size="s" color={accentColor} />
          </div>
          {metadata?.strategy && (
            <span style={{
              fontSize: 12,
              fontWeight: 600,
              color: THEME.text,
            }}>
              {formatStrategy(metadata.strategy)}
            </span>
          )}
          {!metadata?.strategy && (
            <span style={{
              fontSize: 12,
              fontWeight: 600,
              color: THEME.text,
            }}>
              Response
            </span>
          )}
          {metadata?.confidence != null && !collapsed && (
            <ConfidenceGauge value={metadata.confidence} accent={accentColor} />
          )}
        </div>

        {/* Action buttons */}
        <div style={{ display: 'flex', gap: 4 }}>
          <ActionButton
            tooltip={copied ? 'Copied!' : 'Copy response'}
            iconType={copied ? 'checkInCircleFilled' : 'copy'}
            onClick={handleCopy}
            active={copied}
            accent={accentColor}
          />
          <ActionButton
            tooltip="Export as .md"
            iconType="download"
            onClick={handleExport}
            accent={accentColor}
          />
          {onPin && (
            <ActionButton
              tooltip={isPinned ? 'Unpin response' : 'Pin for comparison'}
              iconType={isPinned ? 'pinFilled' : 'pin'}
              onClick={onPin}
              active={isPinned}
              accent={accentColor}
            />
          )}
          <ActionButton
            tooltip={collapsed ? 'Expand' : 'Collapse'}
            iconType={collapsed ? 'expand' : 'minimize'}
            onClick={() => setCollapsed(c => !c)}
            accent={accentColor}
          />
        </div>
      </div>

      {/* Content area */}
      {!collapsed && (
        <div style={{ padding: '16px 18px' }}>
          {isLoading ? (
            <LoadingSkeleton
              onCancel={onCancel}
              elapsedSeconds={elapsedSeconds}
              currentStage={currentStage}
              accent={accentColor}
            />
          ) : (
            <>
              {metadata && <MetadataBar metadata={metadata} accent={accentColor} />}
              <PallasMarkdown content={content} />
              {socAnalysis && <SOCAnalysisSection content={socAnalysis} accent={accentColor} />}
              {suggestions && suggestions.length > 0 && (
                <SuggestionChips
                  suggestions={suggestions}
                  onSuggestionClick={onSuggestionClick}
                  accent={accentColor}
                />
              )}
              {/* Retry button */}
              {warn && onRetry && (
                <div style={{ marginTop: 14 }}>
                  <button
                    onClick={onRetry}
                    style={{
                      display: 'inline-flex',
                      alignItems: 'center',
                      gap: 6,
                      padding: '6px 16px',
                      borderRadius: 6,
                      border: `1px solid ${accentColor}`,
                      backgroundColor: accentColor + '10',
                      color: accentColor,
                      fontSize: 12,
                      fontWeight: 600,
                      cursor: 'pointer',
                      fontFamily: 'inherit',
                      transition: 'all 0.15s ease',
                      outline: 'none',
                    }}
                  >
                    <EuiIcon type="refresh" size="s" color={accentColor} />
                    Retry Query
                  </button>
                </div>
              )}
            </>
          )}
        </div>
      )}
    </div>
  );
}

// ─── ComparePanel ─────────────────────────────────────────────────────────────

export function ComparePanel({ pinnedResponses, onClose, accent }) {
  const [leftIdx, setLeftIdx] = useState(0);
  const [rightIdx, setRightIdx] = useState(Math.min(1, pinnedResponses.length - 1));
  const accentColor = accent || THEME.accent;

  if (!pinnedResponses || pinnedResponses.length === 0) return null;

  const left = pinnedResponses[leftIdx];
  const right = pinnedResponses[rightIdx];

  return (
    <div style={{
      backgroundColor: THEME.bg,
      border: `1px solid ${THEME.border}`,
      borderRadius: 10,
      overflow: 'hidden',
      animation: 'pallas-fadeIn 0.25s ease',
    }}>
      {/* Header */}
      <div style={{
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'space-between',
        padding: '8px 14px',
        borderBottom: `1px solid ${THEME.border}`,
        backgroundColor: THEME.card,
      }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
          <EuiIcon type="layers" size="s" color={accentColor} />
          <span style={{
            fontSize: 11,
            fontWeight: 700,
            color: accentColor,
            textTransform: 'uppercase',
            letterSpacing: '0.05em',
          }}>
            Compare Responses
          </span>
          <span style={{ fontSize: 10, color: THEME.textMuted }}>
            ({pinnedResponses.length} pinned)
          </span>
        </div>
        <ActionButton tooltip="Close comparison" iconType="cross" onClick={onClose} accent={accentColor} />
      </div>

      {/* Selector rows */}
      <div style={{
        display: 'grid',
        gridTemplateColumns: '1fr 1fr',
        gap: 1,
        backgroundColor: THEME.border,
      }}>
        <SelectorRow
          label="Left"
          responses={pinnedResponses}
          selectedIdx={leftIdx}
          onSelect={setLeftIdx}
          accent={accentColor}
        />
        <SelectorRow
          label="Right"
          responses={pinnedResponses}
          selectedIdx={rightIdx}
          onSelect={setRightIdx}
          accent={THEME.primary}
        />
      </div>

      {/* Side-by-side panels */}
      <div style={{
        display: 'grid',
        gridTemplateColumns: '1fr 1fr',
        gap: 12,
        padding: 12,
      }}>
        <ResponsePanel {...left} onPin={undefined} isPinned={false} accent={accentColor} />
        <ResponsePanel {...right} onPin={undefined} isPinned={false} accent={THEME.primary} />
      </div>
    </div>
  );
}

function SelectorRow({ label, responses, selectedIdx, onSelect, accent }) {
  return (
    <div style={{
      backgroundColor: THEME.card,
      padding: '6px 10px',
      display: 'flex',
      alignItems: 'center',
      gap: 6,
      flexWrap: 'wrap',
    }}>
      <span style={{
        fontSize: 10,
        color: THEME.textMuted,
        fontWeight: 700,
        textTransform: 'uppercase',
        letterSpacing: '0.04em',
        marginRight: 2,
        flexShrink: 0,
      }}>
        {label}:
      </span>
      {responses.map((r, i) => {
        const isSelected = i === selectedIdx;
        return (
          <button
            key={i}
            onClick={() => onSelect(i)}
            style={{
              padding: '2px 10px',
              borderRadius: 4,
              border: `1px solid ${isSelected ? accent : THEME.border}`,
              backgroundColor: isSelected ? accent + '15' : 'transparent',
              color: isSelected ? accent : THEME.textMuted,
              fontSize: 11,
              fontWeight: isSelected ? 600 : 400,
              cursor: 'pointer',
              fontFamily: 'inherit',
              transition: 'all 0.15s ease',
              outline: 'none',
            }}
          >
            {r.metadata?.strategy ? formatStrategy(r.metadata.strategy) : `Response ${i + 1}`}
          </button>
        );
      })}
    </div>
  );
}

// ─── Exports ──────────────────────────────────────────────────────────────────

export { ResponsePanel };
export default ResponsePanel;
