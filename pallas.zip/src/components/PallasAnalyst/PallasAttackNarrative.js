/**
 * PallasAttackNarrative — Attack Narrative AI Plugin
 *
 * Redesigned with shared PallasUI components and Narrative accent color (#A78BFA).
 * Alert browser with on-demand AI forensic narrative generation.
 */

import React, { useState, useEffect, useRef, useCallback } from 'react';
import { EuiIcon } from '@elastic/eui';
import { THEME } from '../../utils/theme';
import { MODULE_COLORS, ModuleHeader, PillBadge, EmptyState, FONT } from './PallasUI';
import { pallasPost } from '../../services/pallasService';
import PallasMarkdown from './PallasMarkdown';

const ACCENT = MODULE_COLORS.narrative.accent;

// ─── Constants ───────────────────────────────────────────────────────────────

const TIME_RANGES = [
  { value: '12h', label: '12 Hours' },
  { value: '24h', label: '24 Hours' },
  { value: '48h', label: '48 Hours' },
  { value: '7d', label: '7 Days' },
];

const SEVERITY_COLORS = {
  critical: { bg: 'rgba(255,77,77,0.12)', text: '#FF6B6B', border: 'rgba(255,77,77,0.3)' },
  high:     { bg: 'rgba(255,140,66,0.12)', text: '#FF8C42', border: 'rgba(255,140,66,0.3)' },
  medium:   { bg: 'rgba(240,180,41,0.12)', text: '#F0B429', border: 'rgba(240,180,41,0.3)' },
  low:      { bg: 'rgba(0,212,200,0.12)',  text: '#00D4C8', border: 'rgba(0,212,200,0.3)' },
};

const SOURCE_COLORS = {
  wazuh:    { bg: 'rgba(0,212,200,0.12)', text: THEME.accent, border: 'rgba(0,212,200,0.25)' },
  suricata: { bg: 'rgba(251,146,60,0.12)', text: '#FB923C', border: 'rgba(251,146,60,0.25)' },
};

// ─── Helpers ─────────────────────────────────────────────────────────────────

function formatTimestamp(ts) {
  if (!ts) return '';
  return new Date(ts).toLocaleString('en-US', {
    month: 'short', day: 'numeric', hour: 'numeric',
    minute: '2-digit', second: '2-digit', hour12: true,
  });
}

function normalizeSeverity(level) {
  if (level >= 15) return 'critical';
  if (level >= 12) return 'high';
  if (level >= 7)  return 'medium';
  return 'low';
}

// ─── Component ───────────────────────────────────────────────────────────────

export default function PallasAttackNarrative({ connectionStatus, onQueryComplete }) {
  const [alerts, setAlerts] = useState([]);
  const [metadata, setMetadata] = useState(null);
  const [isLoading, setIsLoading] = useState(false);
  const [loadError, setLoadError] = useState(null);
  const [timeRange, setTimeRange] = useState('24h');
  const [generatingAlertId, setGeneratingAlertId] = useState(null);
  const [narratives, setNarratives] = useState({});
  const [typewriterText, setTypewriterText] = useState({});
  const [expandedAlertId, setExpandedAlertId] = useState(null);
  const [pinnedNarratives, setPinnedNarratives] = useState([]);
  const [compareMode, setCompareMode] = useState(false);
  const typewriterRef = useRef({});
  const [hasScanned, setHasScanned] = useState(false);

  // ── Fetch alerts ─────────────────────────────────────────────────────────

  const fetchAlerts = useCallback(async (range) => {
    setIsLoading(true);
    setLoadError(null);
    setHasScanned(true);
    try {
      const data = await pallasPost('/api/narrative/generate', { time_range: range, min_level: 12, max_alerts: 200 });
      setAlerts(data.alerts || []);
      setMetadata(data.metadata || null);
      if (onQueryComplete) onQueryComplete('narrative', `Scan ${range} (${(data.alerts || []).length} alerts)`, 0);
    } catch (err) {
      setLoadError(err.message);
      setAlerts([]);
      setMetadata(null);
    } finally {
      setIsLoading(false);
    }
  }, [onQueryComplete]);

  useEffect(() => {
    return () => { Object.values(typewriterRef.current).forEach(clearInterval); };
  }, []);

  // ── Generate narrative ───────────────────────────────────────────────────

  const generateNarrative = useCallback(async (alert) => {
    if (generatingAlertId) return;
    setGeneratingAlertId(alert.id);
    setExpandedAlertId(alert.id);

    try {
      const data = await pallasPost('/api/narrative/enhance', alert);
      const fullText = data.narrative || 'No narrative returned.';
      let index = 0;
      if (typewriterRef.current[alert.id]) clearInterval(typewriterRef.current[alert.id]);

      typewriterRef.current[alert.id] = setInterval(() => {
        index += 3;
        if (index >= fullText.length) {
          clearInterval(typewriterRef.current[alert.id]);
          delete typewriterRef.current[alert.id];
          setTypewriterText((prev) => { const next = { ...prev }; delete next[alert.id]; return next; });
          setNarratives((prev) => ({ ...prev, [alert.id]: fullText }));
        } else {
          setTypewriterText((prev) => ({ ...prev, [alert.id]: fullText.slice(0, index) }));
        }
      }, 12);
    } catch (err) {
      setNarratives((prev) => ({ ...prev, [alert.id]: `Error: ${err.message}` }));
    } finally {
      setGeneratingAlertId(null);
    }
  }, [generatingAlertId]);

  // ── Time range change ──────────────────────────────────────────────────

  const handleTimeRangeChange = (range) => {
    setTimeRange(range);
    setNarratives({});
    setTypewriterText({});
    setExpandedAlertId(null);
    Object.values(typewriterRef.current).forEach(clearInterval);
    typewriterRef.current = {};
    fetchAlerts(range);
  };

  const toggleNarrative = (alertId) => {
    setExpandedAlertId((prev) => (prev === alertId ? null : alertId));
  };

  // ── Pin / Unpin / Export ──────────────────────────────────────────────

  const pinNarrative = useCallback((alert) => {
    const text = narratives[alert.id];
    if (!text) return;
    setPinnedNarratives((prev) => {
      if (prev.length >= 5) return prev;
      if (prev.some((p) => p.alertId === alert.id)) return prev;
      const description = alert.rule?.description || alert.description || alert.alert_msg || 'Alert';
      return [...prev, { alertId: alert.id, description, narrative: text, timestamp: new Date() }];
    });
  }, [narratives]);

  const unpinNarrative = useCallback((index) => {
    setPinnedNarratives((prev) => prev.filter((_, i) => i !== index));
  }, []);

  const exportPinnedNarratives = useCallback(() => {
    if (!pinnedNarratives.length) return;
    const md = pinnedNarratives.map((p, i) => {
      const ts = p.timestamp ? new Date(p.timestamp).toLocaleString() : 'N/A';
      return `## Narrative ${i + 1}: ${p.description} (${ts})\n\n${p.narrative}\n`;
    }).join('\n---\n\n');
    const blob = new Blob([md], { type: 'text/markdown' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `pallas-narratives-${Date.now()}.md`;
    a.click();
    URL.revokeObjectURL(url);
  }, [pinnedNarratives]);

  // ── Render helpers ───────────────────────────────────────────────────────

  const renderSeverityBadge = (level, severity) => {
    const sev = severity || normalizeSeverity(level);
    const colors = SEVERITY_COLORS[sev] || SEVERITY_COLORS.low;
    return (
      <PillBadge
        label={sev}
        color={colors.text}
        bg={colors.bg}
        border={colors.border}
        style={{ textTransform: 'uppercase', letterSpacing: 0.5 }}
      />
    );
  };

  const renderSourceBadge = (source) => {
    const key = (source || '').toLowerCase();
    const colors = SOURCE_COLORS[key] || SOURCE_COLORS.wazuh;
    return (
      <PillBadge
        label={source || 'Unknown'}
        color={colors.text}
        bg={colors.bg}
        border={colors.border}
        style={{ textTransform: 'uppercase', letterSpacing: 0.5 }}
      />
    );
  };

  const renderMitreBadges = (alert) => {
    if ((alert.source || '').toLowerCase() !== 'wazuh') return null;
    const tactics = alert.mitre_tactics || alert.rule?.mitre?.tactic || [];
    const techniques = alert.mitre_techniques || alert.rule?.mitre?.technique || [];
    if (!tactics.length && !techniques.length) return null;

    return (
      <div style={{ display: 'flex', flexWrap: 'wrap', gap: 4, marginTop: 6 }}>
        {(Array.isArray(tactics) ? tactics : [tactics]).map((t, i) => (
          <PillBadge key={`tac-${i}`} label={t} color={THEME.accent} bg="rgba(22,197,192,0.12)" border="rgba(22,197,192,0.25)" />
        ))}
        {(Array.isArray(techniques) ? techniques : [techniques]).map((t, i) => (
          <PillBadge key={`tech-${i}`} label={t} color={THEME.textMuted} bg="rgba(255,255,255,0.04)" border={THEME.border} />
        ))}
      </div>
    );
  };

  const renderNarrativeButton = (alert) => {
    const isGenerating = generatingAlertId === alert.id;
    const hasNarrative = !!narratives[alert.id];
    const isExpanded = expandedAlertId === alert.id;
    const isTyping = !!typewriterText[alert.id];

    if (isGenerating || isTyping) {
      return (
        <button disabled style={{
          display: 'inline-flex', alignItems: 'center', gap: 6, padding: '5px 12px',
          borderRadius: 6, border: `1px solid ${ACCENT}`, background: 'transparent',
          color: ACCENT, fontSize: 12, fontWeight: 600, cursor: 'wait',
        }}>
          <span style={{
            display: 'inline-block', width: 12, height: 12,
            border: '2px solid rgba(255,255,255,0.3)', borderTopColor: ACCENT,
            borderRadius: '50%', animation: 'pallas-spin 0.6s linear infinite',
          }} />
          Generating...
        </button>
      );
    }

    if (hasNarrative) {
      const isPinned = pinnedNarratives.some((p) => p.alertId === alert.id);
      return (
        <div style={{ display: 'inline-flex', alignItems: 'center', gap: 8 }}>
          <button
            onClick={() => toggleNarrative(alert.id)}
            style={{
              display: 'inline-flex', alignItems: 'center', gap: 6, padding: '5px 12px',
              borderRadius: 6, border: `1px solid ${ACCENT}44`, background: `${ACCENT}1A`,
              color: ACCENT, fontSize: 12, fontWeight: 600, cursor: 'pointer',
            }}
          >
            <EuiIcon type="check" size="s" color={ACCENT} />
            {isExpanded ? 'Hide Narrative' : 'Show Narrative'}
          </button>
          <button
            onClick={() => pinNarrative(alert)}
            disabled={isPinned || pinnedNarratives.length >= 5}
            style={{
              display: 'inline-flex', alignItems: 'center', gap: 5, padding: '5px 10px',
              borderRadius: 6, border: `1px solid ${isPinned ? ACCENT : THEME.border}`,
              background: isPinned ? `${ACCENT}1A` : 'transparent',
              color: isPinned ? ACCENT : THEME.textSecondary, fontSize: 11, fontWeight: 600,
              cursor: isPinned ? 'default' : 'pointer', opacity: isPinned ? 0.7 : 1,
            }}
          >
            <EuiIcon type={isPinned ? 'check' : 'pinFilled'} size="s" />
            {isPinned ? 'Pinned' : 'Pin'}
          </button>
          <PillBadge label="AI ENHANCED" color={ACCENT} bg={`${ACCENT}26`} style={{ fontSize: 10, letterSpacing: 0.8 }} />
        </div>
      );
    }

    return (
      <button
        onClick={() => generateNarrative(alert)}
        disabled={!!generatingAlertId}
        style={{
          display: 'inline-flex', alignItems: 'center', gap: 6, padding: '5px 12px',
          borderRadius: 6, border: `1px solid ${ACCENT}`, background: 'transparent',
          color: ACCENT, fontSize: 12, fontWeight: 600,
          cursor: generatingAlertId ? 'not-allowed' : 'pointer',
          opacity: generatingAlertId ? 0.5 : 1,
        }}
      >
        <EuiIcon type="sparkles" size="s" color={ACCENT} /> AI Narrative
      </button>
    );
  };

  const renderNarrativePanel = (alert) => {
    const isExpanded = expandedAlertId === alert.id;
    const isTyping = !!typewriterText[alert.id];
    const text = isTyping ? typewriterText[alert.id] : narratives[alert.id];
    if (!isExpanded && !isTyping) return null;
    if (!text) return null;

    return (
      <div style={{
        marginTop: 10, padding: 14, borderRadius: 6,
        background: THEME.bgDeep, border: `1px solid ${ACCENT}33`,
      }}>
        {text.split('\n').map((para, i) => (
          <p key={i} style={{
            margin: i === 0 ? 0 : '8px 0 0 0', fontSize: 13, lineHeight: 1.65, color: THEME.textSecondary,
          }}>
            {para}
            {isTyping && i === text.split('\n').length - 1 && (
              <span style={{
                display: 'inline-block', width: 2, height: 14, marginLeft: 2,
                background: ACCENT, verticalAlign: 'text-bottom',
                animation: 'pallas-pulse 0.8s ease-in-out infinite',
              }} />
            )}
          </p>
        ))}
      </div>
    );
  };

  // ── Alert card ─────────────────────────────────────────────────────────

  const renderAlertCard = (alert) => {
    const isGenerating = generatingAlertId === alert.id;
    const source = (alert.source || '').toLowerCase();
    const description = alert.rule?.description || alert.description || alert.alert_msg || 'No description';
    const sev = alert.severity || normalizeSeverity(alert.level);
    const sevColor = SEVERITY_COLORS[sev] || SEVERITY_COLORS.low;

    return (
      <div key={alert.id} style={{
        padding: 14, borderRadius: 8,
        background: 'rgba(255,255,255,0.03)',
        border: `1px solid ${isGenerating ? ACCENT : THEME.border}`,
        borderLeft: `3px solid ${sevColor.text}`,
        transition: 'border-color 0.3s ease',
      }}>
        {/* Row 1 */}
        <div style={{ display: 'flex', alignItems: 'center', gap: 8, flexWrap: 'wrap' }}>
          {renderSeverityBadge(alert.level, alert.severity)}
          {renderSourceBadge(alert.source)}
          <span style={{
            flex: 1, fontSize: 13, fontWeight: 500, color: THEME.text,
            overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap', minWidth: 0,
          }} title={description}>
            {description}
          </span>
          <span style={{ fontSize: 11, color: THEME.textMuted, whiteSpace: 'nowrap', flexShrink: 0 }}>
            {formatTimestamp(alert.timestamp)}
          </span>
        </div>

        {/* Row 2 */}
        <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginTop: 8, fontSize: 12, color: THEME.textSecondary }}>
          <span>
            <span style={{ color: THEME.textMuted }}>Level:</span>{' '}
            <span style={{ fontWeight: 600 }}>{alert.level ?? '\u2014'}</span>
          </span>
          {source === 'wazuh' && alert.agent?.name && (
            <span>
              <span style={{ color: THEME.textMuted }}>Agent:</span>{' '}
              <span style={{ fontWeight: 500 }}>{alert.agent.name}</span>
            </span>
          )}
          {source === 'suricata' && (
            <span>
              <span style={{ color: THEME.textMuted }}>IPs:</span>{' '}
              <span style={{ fontWeight: 500 }}>{alert.src_ip || '\u2014'} {'\u2192'} {alert.dest_ip || '\u2014'}</span>
            </span>
          )}
          {(alert.category || alert.rule?.groups?.[0]) && (
            <span>
              <span style={{ color: THEME.textMuted }}>Category:</span>{' '}
              <span style={{ fontWeight: 500 }}>{alert.category || alert.rule?.groups?.[0]}</span>
            </span>
          )}
        </div>

        {/* MITRE badges */}
        {renderMitreBadges(alert)}

        {/* AI Narrative button */}
        <div style={{ marginTop: 10 }}>{renderNarrativeButton(alert)}</div>

        {/* Narrative panel */}
        {renderNarrativePanel(alert)}
      </div>
    );
  };

  // ── Main render ────────────────────────────────────────────────────────

  return (
    <div style={{ display: 'flex', flexDirection: 'column', height: '100%', fontFamily: FONT.base }}>
      {/* Module Header */}
      <ModuleHeader
        icon="timeline"
        title="Attack Narrative AI"
        description="Critical alerts from Wazuh + Suricata with on-demand AI forensic narratives"
        accent={ACCENT}
        connectionStatus={connectionStatus}
        actions={
          <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
            {metadata?.scan_duration && (
              <PillBadge label={metadata.scan_duration} color={ACCENT} bg={`${ACCENT}1A`} border={`${ACCENT}33`} />
            )}
            {/* Time range buttons */}
            {TIME_RANGES.map((tr) => {
              const isActive = timeRange === tr.value;
              return (
                <button
                  key={tr.value}
                  onClick={() => handleTimeRangeChange(tr.value)}
                  disabled={isLoading}
                  style={{
                    padding: '4px 10px', borderRadius: 5, fontSize: 11, fontWeight: 600,
                    border: `1px solid ${isActive ? ACCENT : THEME.border}`,
                    background: isActive ? `${ACCENT}1A` : 'transparent',
                    color: isActive ? ACCENT : THEME.textSecondary,
                    cursor: isLoading ? 'not-allowed' : 'pointer',
                    opacity: isLoading ? 0.5 : 1, transition: 'all 0.2s',
                    outline: 'none',
                  }}
                >
                  {tr.label}
                </button>
              );
            })}
            <button
              onClick={() => fetchAlerts(timeRange)}
              disabled={isLoading}
              aria-label="Refresh alerts"
              style={{
                display: 'inline-flex', alignItems: 'center', justifyContent: 'center',
                width: 30, height: 30, borderRadius: 6, border: `1px solid ${THEME.border}`,
                background: 'transparent', cursor: isLoading ? 'not-allowed' : 'pointer',
                opacity: isLoading ? 0.5 : 1, outline: 'none',
              }}
            >
              <EuiIcon type="refresh" size="s" color={THEME.textSecondary} />
            </button>
          </div>
        }
      />

      {/* Scrollable content */}
      <div style={{ flex: 1, overflowY: 'auto', padding: '16px 20px' }} className="pallas-scrollbar">
        {/* Metadata bar */}
        {metadata && !isLoading && (
          <div style={{
            display: 'flex', alignItems: 'center', gap: 16, padding: '8px 12px',
            marginBottom: 14, borderRadius: 6, background: THEME.cardSubtle,
            border: `1px solid ${THEME.border}`, fontSize: 12, color: THEME.textSecondary, flexWrap: 'wrap',
          }}>
            <span><span style={{ color: THEME.textMuted }}>Total:</span> <span style={{ fontWeight: 700, color: THEME.text }}>{metadata.total_alerts ?? alerts.length}</span></span>
            <span><span style={{ color: THEME.textMuted }}>Wazuh:</span> <span style={{ fontWeight: 700, color: THEME.accent }}>{metadata.wazuh_count ?? '\u2014'}</span></span>
            <span><span style={{ color: THEME.textMuted }}>Suricata:</span> <span style={{ fontWeight: 700, color: '#FB923C' }}>{metadata.suricata_count ?? '\u2014'}</span></span>
            {metadata.min_level && (
              <span><span style={{ color: THEME.textMuted }}>Level \u2265</span> <span style={{ fontWeight: 600 }}>{metadata.min_level}</span></span>
            )}
            {metadata.time_range && (
              <span><span style={{ color: THEME.textMuted }}>Range:</span> <span style={{ fontWeight: 500 }}>{metadata.time_range}</span></span>
            )}
          </div>
        )}

        {/* Error state */}
        {loadError && (
          <div style={{
            padding: '10px 14px', borderRadius: 6, marginBottom: 14,
            background: 'rgba(239,68,68,0.1)', border: '1px solid rgba(239,68,68,0.3)',
            color: '#EF4444', fontSize: 13, display: 'flex', alignItems: 'center', gap: 8,
          }}>
            <EuiIcon type="warning" size="s" color="#EF4444" /> {loadError}
          </div>
        )}

        {/* Loading state */}
        {isLoading && (
          <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', padding: '60px 20px', gap: 14 }}>
            <span style={{
              display: 'inline-block', width: 32, height: 32,
              border: `3px solid ${THEME.border}`, borderTopColor: ACCENT,
              borderRadius: '50%', animation: 'pallas-spin 0.6s linear infinite',
            }} />
            <span style={{ fontSize: 14, fontWeight: 600, color: THEME.text }}>Fetching critical alerts...</span>
            <span style={{ fontSize: 12, color: THEME.textMuted }}>
              Querying Wazuh and Suricata for the last {TIME_RANGES.find((t) => t.value === timeRange)?.label || timeRange}
            </span>
          </div>
        )}

        {/* Welcome state */}
        {!isLoading && !loadError && !hasScanned && (
          <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', padding: '60px 20px', gap: 14 }}>
            <EuiIcon type="sparkles" size="xxl" color={ACCENT} />
            <span style={{ fontSize: 16, fontWeight: 600, color: THEME.text }}>Ready to Scan</span>
            <span style={{ fontSize: 13, color: THEME.textSecondary, textAlign: 'center', maxWidth: 420, lineHeight: '1.5' }}>
              Click <strong>Scan Alerts</strong> to fetch critical alerts (level &ge; 12) from Wazuh and Suricata.
              Each alert can then be enhanced with an AI-generated forensic narrative.
            </span>
            <button
              onClick={() => fetchAlerts(timeRange)}
              style={{
                marginTop: 8, padding: '10px 28px', borderRadius: 8, border: 'none',
                background: ACCENT, color: '#fff', fontSize: 14, fontWeight: 600,
                cursor: 'pointer', display: 'flex', alignItems: 'center', gap: 8,
                outline: 'none',
              }}
            >
              <EuiIcon type="refresh" size="s" color="#fff" /> Scan Alerts
            </button>
          </div>
        )}

        {/* Empty state */}
        {!isLoading && !loadError && hasScanned && alerts.length === 0 && (
          <EmptyState
            icon="check"
            title="No Critical Alerts"
            description="No alerts at level 12 or above found in the selected time range. Adjust the range or check back later."
            accent={ACCENT}
          />
        )}

        {/* Pinned Narratives */}
        {pinnedNarratives.length > 0 && (
          <div style={{ marginBottom: 16 }}>
            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 10 }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: 6, fontSize: 12, fontWeight: 600, color: THEME.textSecondary, textTransform: 'uppercase', letterSpacing: '0.5px' }}>
                <EuiIcon type="pinFilled" size="s" color={ACCENT} />
                Pinned Narratives
                <span style={{ fontSize: 11, fontWeight: 400, color: THEME.textMuted, textTransform: 'none', letterSpacing: 'normal' }}>
                  ({pinnedNarratives.length})
                </span>
              </div>
              <div style={{ display: 'flex', gap: 8 }}>
                {pinnedNarratives.length >= 2 && (
                  <button
                    onClick={() => setCompareMode((v) => !v)}
                    style={{
                      display: 'inline-flex', alignItems: 'center', gap: 5, padding: '4px 10px',
                      borderRadius: 6, border: `1px solid ${compareMode ? ACCENT : THEME.border}`,
                      backgroundColor: compareMode ? `${ACCENT}1A` : 'transparent',
                      color: compareMode ? ACCENT : THEME.textSecondary,
                      fontSize: 11, fontWeight: 500, cursor: 'pointer', outline: 'none',
                    }}
                  >
                    <EuiIcon type="merge" size="s" /> Compare
                  </button>
                )}
                <button
                  onClick={exportPinnedNarratives}
                  style={{
                    display: 'inline-flex', alignItems: 'center', gap: 5, padding: '4px 10px',
                    borderRadius: 6, border: `1px solid ${THEME.border}`, backgroundColor: 'transparent',
                    color: THEME.textSecondary, fontSize: 11, fontWeight: 500, cursor: 'pointer', outline: 'none',
                  }}
                >
                  <EuiIcon type="download" size="s" /> Export
                </button>
              </div>
            </div>

            {/* Pinned chips */}
            <div style={{ display: 'flex', flexWrap: 'wrap', gap: 6, marginBottom: compareMode ? 12 : 0 }}>
              {pinnedNarratives.map((p, idx) => (
                <div key={p.alertId} style={{
                  display: 'inline-flex', alignItems: 'center', gap: 6, padding: '4px 10px',
                  borderRadius: 6, backgroundColor: THEME.cardSubtle || 'rgba(255,255,255,0.03)',
                  border: `1px solid ${THEME.border}`, fontSize: 11, color: THEME.textSecondary,
                }}>
                  <EuiIcon type="pinFilled" size="s" color={ACCENT} />
                  <span style={{ maxWidth: 180, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                    {p.description.substring(0, 50)}
                  </span>
                  <button
                    onClick={() => unpinNarrative(idx)}
                    style={{ background: 'none', border: 'none', color: THEME.textMuted, cursor: 'pointer', padding: 2, display: 'flex', alignItems: 'center' }}
                    title="Unpin"
                  >
                    <EuiIcon type="cross" size="s" />
                  </button>
                </div>
              ))}
            </div>

            {/* Compare view */}
            {compareMode && pinnedNarratives.length >= 2 && (
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12, marginTop: 8 }}>
                {pinnedNarratives.slice(0, 2).map((p, idx) => (
                  <div key={p.alertId} style={{
                    padding: 14, borderRadius: 8, background: THEME.bgDeep || 'rgba(0,0,0,0.15)',
                    border: `1px solid ${idx === 0 ? `${ACCENT}4D` : 'rgba(97,162,255,0.3)'}`,
                  }}>
                    <div style={{
                      fontSize: 11, fontWeight: 600, color: idx === 0 ? ACCENT : '#61A2FF',
                      textTransform: 'uppercase', letterSpacing: '0.4px', marginBottom: 8,
                    }}>
                      {p.description.substring(0, 60)}
                    </div>
                    <PallasMarkdown content={p.narrative} />
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {/* Alert cards */}
        {!isLoading && alerts.length > 0 && (
          <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
            {alerts.map(renderAlertCard)}
          </div>
        )}
      </div>
    </div>
  );
}
