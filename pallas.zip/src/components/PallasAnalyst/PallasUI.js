/**
 * PallasUI — Shared Component & Style Library
 *
 * Single source of truth for all Pallas micro-components, style factories,
 * and design tokens. Every module imports from here instead of defining
 * inline styles independently.
 *
 * Design system: "SOC Command Center" — information-dense, dark, military-grade.
 */

import React from 'react';
import { EuiIcon } from '@elastic/eui';
import { THEME } from '../../utils/theme';

// ─── Module Accent Colors ────────────────────────────────────────────────────

export const MODULE_COLORS = {
  chat:         { accent: '#16c5c0', glow: 'rgba(22, 197, 192, 0.25)', label: 'SOC Chat' },
  ioc:          { accent: '#EF4444', glow: 'rgba(239, 68, 68, 0.25)',  label: 'Threat Intel' },
  decoder:      { accent: '#C084FC', glow: 'rgba(192, 132, 252, 0.25)', label: 'Decoder Lab' },
  siem:         { accent: '#61A2FF', glow: 'rgba(97, 162, 255, 0.25)', label: 'SIEM' },
  nids:         { accent: '#F97316', glow: 'rgba(249, 115, 22, 0.25)', label: 'NIDS' },
  vulns:        { accent: '#F59E0B', glow: 'rgba(245, 158, 11, 0.25)', label: 'Vulnerabilities' },
  correlations: { accent: '#10B981', glow: 'rgba(16, 185, 129, 0.25)', label: 'Correlations' },
  narrative:    { accent: '#A78BFA', glow: 'rgba(167, 139, 250, 0.25)', label: 'Attack Narrative' },
};

// ─── Typography ──────────────────────────────────────────────────────────────

export const FONT = {
  base: "'Inter', -apple-system, BlinkMacSystemFont, sans-serif",
  mono: "'JetBrains Mono', 'SF Mono', 'Fira Code', monospace",
};

// ─── Shared Keyframe CSS ─────────────────────────────────────────────────────

export const PALLAS_KEYFRAMES = `
  @keyframes pallas-pulse {
    0%, 100% { opacity: 0.4; }
    50% { opacity: 0.7; }
  }
  @keyframes pallas-spin {
    to { transform: rotate(360deg); }
  }
  @keyframes pallas-shimmer {
    0% { background-position: -200% 0; }
    100% { background-position: 200% 0; }
  }
  @keyframes pallas-fadeIn {
    from { opacity: 0; transform: translateY(6px); }
    to { opacity: 1; transform: translateY(0); }
  }
  @keyframes pallas-slideUp {
    from { opacity: 0; transform: translateY(12px); }
    to { opacity: 1; transform: translateY(0); }
  }
  @keyframes pallas-scaleIn {
    from { opacity: 0; transform: scale(0.96); }
    to { opacity: 1; transform: scale(1); }
  }
  @keyframes pallas-glow {
    0%, 100% { box-shadow: 0 0 4px rgba(22, 197, 192, 0.15); }
    50% { box-shadow: 0 0 12px rgba(22, 197, 192, 0.35); }
  }
  @keyframes pallas-breathe {
    0%, 100% { opacity: 0.6; }
    50% { opacity: 1; }
  }
  .pallas-scrollbar::-webkit-scrollbar { width: 5px; height: 5px; }
  .pallas-scrollbar::-webkit-scrollbar-track { background: transparent; }
  .pallas-scrollbar::-webkit-scrollbar-thumb {
    background: rgba(255,255,255,0.12);
    border-radius: 3px;
  }
  .pallas-scrollbar::-webkit-scrollbar-thumb:hover {
    background: rgba(255,255,255,0.22);
  }
`;

// ─── GlassCard ───────────────────────────────────────────────────────────────

/**
 * Semi-transparent card with subtle border and optional accent glow.
 * Used for panels, result containers, KPI cards.
 */
export function GlassCard({ children, accent, glow, padding = 16, style, onClick, ...rest }) {
  const [hovered, setHovered] = React.useState(false);
  const isClickable = !!onClick;

  const cardStyle = {
    background: 'rgba(29, 30, 36, 0.7)',
    backdropFilter: 'blur(12px)',
    WebkitBackdropFilter: 'blur(12px)',
    border: `1px solid ${hovered && accent ? accent + '40' : THEME.border}`,
    borderRadius: 10,
    padding,
    transition: 'border-color 0.2s ease, box-shadow 0.2s ease, transform 0.15s ease',
    boxShadow: hovered && glow ? `0 0 20px ${glow}` : '0 1px 3px rgba(0,0,0,0.2)',
    cursor: isClickable ? 'pointer' : 'default',
    transform: hovered && isClickable ? 'translateY(-1px)' : 'none',
    ...style,
  };

  return (
    <div
      style={cardStyle}
      onMouseEnter={() => setHovered(true)}
      onMouseLeave={() => setHovered(false)}
      onClick={onClick}
      {...rest}
    >
      {children}
    </div>
  );
}

// ─── KPICard ─────────────────────────────────────────────────────────────────

/**
 * Compact metric card showing a number, label, and optional trend.
 * Used in module dashboard headers.
 */
export function KPICard({ value, label, icon, accent = THEME.accent, onClick, trend, compact }) {
  const [hovered, setHovered] = React.useState(false);

  return (
    <div
      onClick={onClick}
      onMouseEnter={() => setHovered(true)}
      onMouseLeave={() => setHovered(false)}
      style={{
        display: 'flex',
        alignItems: 'center',
        gap: compact ? 8 : 12,
        padding: compact ? '8px 12px' : '12px 16px',
        background: hovered ? 'rgba(255,255,255,0.04)' : 'rgba(255,255,255,0.02)',
        border: `1px solid ${hovered ? accent + '30' : THEME.border}`,
        borderRadius: 8,
        cursor: onClick ? 'pointer' : 'default',
        transition: 'all 0.15s ease',
        minWidth: 0,
        flex: 1,
      }}
    >
      {icon && (
        <div style={{
          width: compact ? 28 : 34,
          height: compact ? 28 : 34,
          borderRadius: 8,
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          background: accent + '15',
          flexShrink: 0,
        }}>
          <EuiIcon type={icon} size="s" color={accent} />
        </div>
      )}
      <div style={{ minWidth: 0 }}>
        <div style={{
          fontSize: compact ? 16 : 20,
          fontWeight: 700,
          color: THEME.text,
          lineHeight: 1.2,
          fontFamily: FONT.mono,
        }}>
          {value ?? '—'}
          {trend && (
            <span style={{
              fontSize: 10,
              fontWeight: 600,
              marginLeft: 4,
              color: trend > 0 ? THEME.danger : THEME.success,
            }}>
              {trend > 0 ? `+${trend}%` : `${trend}%`}
            </span>
          )}
        </div>
        <div style={{
          fontSize: 10,
          fontWeight: 600,
          color: THEME.textMuted,
          textTransform: 'uppercase',
          letterSpacing: '0.05em',
          lineHeight: 1.3,
          whiteSpace: 'nowrap',
          overflow: 'hidden',
          textOverflow: 'ellipsis',
        }}>
          {label}
        </div>
      </div>
    </div>
  );
}

// ─── SectionHeader ───────────────────────────────────────────────────────────

/**
 * Consistent section divider with icon, title, count badge, and action slot.
 */
export function SectionHeader({ icon, title, count, accent = THEME.textSecondary, actions, style }) {
  return (
    <div style={{
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'space-between',
      marginBottom: 10,
      ...style,
    }}>
      <div style={{
        display: 'flex',
        alignItems: 'center',
        gap: 6,
        fontSize: 11,
        fontWeight: 700,
        color: accent,
        textTransform: 'uppercase',
        letterSpacing: '0.06em',
      }}>
        {icon && <EuiIcon type={icon} size="s" color={accent} />}
        {title}
        {count != null && (
          <span style={{
            fontSize: 10,
            fontWeight: 500,
            color: THEME.textMuted,
            textTransform: 'none',
            letterSpacing: 'normal',
            marginLeft: 2,
          }}>
            ({count})
          </span>
        )}
      </div>
      {actions && <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>{actions}</div>}
    </div>
  );
}

// ─── ActionChip ──────────────────────────────────────────────────────────────

/**
 * Quick action button with icon, label, and optional parameter indicator.
 * Used across all query modules for quick actions.
 */
export function ActionChip({ icon, label, onClick, disabled, active, accent = THEME.accent, hasParam }) {
  const [hovered, setHovered] = React.useState(false);
  const isActive = active || hovered;

  return (
    <button
      onClick={onClick}
      disabled={disabled}
      onMouseEnter={() => setHovered(true)}
      onMouseLeave={() => setHovered(false)}
      style={{
        display: 'inline-flex',
        alignItems: 'center',
        gap: 5,
        padding: '5px 12px',
        borderRadius: 6,
        border: `1px solid ${isActive ? accent + '50' : THEME.border}`,
        background: isActive ? accent + '10' : 'transparent',
        color: isActive ? accent : THEME.textSecondary,
        fontSize: 12,
        fontWeight: 500,
        fontFamily: 'inherit',
        cursor: disabled ? 'not-allowed' : 'pointer',
        opacity: disabled ? 0.4 : 1,
        transition: 'all 0.15s ease',
        whiteSpace: 'nowrap',
        outline: 'none',
      }}
    >
      {icon && <EuiIcon type={icon} size="s" color={isActive ? accent : THEME.textMuted} />}
      {label}
      {hasParam && (
        <EuiIcon type="arrowDown" size="s" color={THEME.textMuted} style={{ marginLeft: -2 }} />
      )}
    </button>
  );
}

// ─── PillBadge ───────────────────────────────────────────────────────────────

/**
 * Compact colored badge for status, severity, source labels.
 */
export function PillBadge({ label, color = THEME.accent, bg, border, size = 'default', style }) {
  const small = size === 'small';
  return (
    <span style={{
      display: 'inline-flex',
      alignItems: 'center',
      padding: small ? '1px 6px' : '2px 8px',
      borderRadius: 4,
      fontSize: small ? 9 : 10,
      fontWeight: 700,
      textTransform: 'uppercase',
      letterSpacing: '0.04em',
      color: color,
      backgroundColor: bg || color + '18',
      border: border ? `1px solid ${border}` : undefined,
      lineHeight: 1.4,
      whiteSpace: 'nowrap',
      ...style,
    }}>
      {label}
    </span>
  );
}

// ─── IconButton ──────────────────────────────────────────────────────────────

/**
 * Small icon-only button with tooltip built-in.
 */
export function IconButton({ icon, onClick, disabled, title, accent = THEME.textSecondary, size = 14 }) {
  const [hovered, setHovered] = React.useState(false);

  return (
    <button
      onClick={onClick}
      disabled={disabled}
      title={title}
      onMouseEnter={() => setHovered(true)}
      onMouseLeave={() => setHovered(false)}
      style={{
        display: 'inline-flex',
        alignItems: 'center',
        justifyContent: 'center',
        width: 26,
        height: 26,
        borderRadius: 6,
        border: 'none',
        background: hovered ? 'rgba(255,255,255,0.06)' : 'transparent',
        color: hovered ? accent : THEME.textMuted,
        cursor: disabled ? 'not-allowed' : 'pointer',
        opacity: disabled ? 0.4 : 1,
        transition: 'all 0.12s ease',
        padding: 0,
        outline: 'none',
      }}
    >
      <EuiIcon type={icon} size="s" color={hovered ? accent : THEME.textMuted} />
    </button>
  );
}

// ─── Spinner ─────────────────────────────────────────────────────────────────

/**
 * Unified loading spinner. Three variants: inline, overlay, skeleton.
 */
export function Spinner({ size = 16, color = THEME.accent, style }) {
  return (
    <span style={{
      display: 'inline-block',
      width: size,
      height: size,
      border: `2px solid ${THEME.border}`,
      borderTopColor: color,
      borderRadius: '50%',
      animation: 'pallas-spin 0.7s linear infinite',
      flexShrink: 0,
      ...style,
    }} />
  );
}

// ─── EmptyState ──────────────────────────────────────────────────────────────

/**
 * Illustrated empty state with guidance text and optional CTA.
 */
export function EmptyState({ icon = 'search', title, description, action, accent = THEME.accent }) {
  return (
    <div style={{
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'center',
      justifyContent: 'center',
      padding: '48px 24px',
      textAlign: 'center',
      animation: 'pallas-fadeIn 0.3s ease',
    }}>
      <div style={{
        width: 56,
        height: 56,
        borderRadius: 16,
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        background: accent + '10',
        border: `1px solid ${accent}20`,
        marginBottom: 16,
      }}>
        <EuiIcon type={icon} size="xl" color={accent} />
      </div>
      {title && (
        <div style={{
          fontSize: 15,
          fontWeight: 600,
          color: THEME.text,
          marginBottom: 6,
        }}>
          {title}
        </div>
      )}
      {description && (
        <div style={{
          fontSize: 12,
          color: THEME.textMuted,
          maxWidth: 340,
          lineHeight: 1.5,
        }}>
          {description}
        </div>
      )}
      {action && <div style={{ marginTop: 16 }}>{action}</div>}
    </div>
  );
}

// ─── ModuleHeader ────────────────────────────────────────────────────────────

/**
 * Standard module header with icon, title, description, and connection status.
 * Replaces the per-module header that each component was defining independently.
 */
export function ModuleHeader({ icon, title, description, accent = THEME.accent, connectionStatus, actions }) {
  return (
    <div style={{
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'space-between',
      padding: '14px 20px',
      borderBottom: `1px solid ${THEME.border}`,
      background: `linear-gradient(180deg, ${accent}06 0%, transparent 100%)`,
      flexShrink: 0,
    }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
        <div style={{
          width: 32,
          height: 32,
          borderRadius: 8,
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          background: accent + '15',
          border: `1px solid ${accent}25`,
        }}>
          <EuiIcon type={icon} size="m" color={accent} />
        </div>
        <div>
          <div style={{
            fontSize: 15,
            fontWeight: 700,
            color: THEME.text,
            lineHeight: 1.2,
          }}>
            {title}
          </div>
          {description && (
            <div style={{
              fontSize: 11,
              color: THEME.textMuted,
              lineHeight: 1.3,
              marginTop: 1,
            }}>
              {description}
            </div>
          )}
        </div>
      </div>
      <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
        {connectionStatus && (
          <div style={{
            display: 'flex',
            alignItems: 'center',
            gap: 5,
            fontSize: 11,
            color: connectionStatus === 'connected' ? THEME.statusActive : THEME.textMuted,
          }}>
            <span style={{
              width: 6,
              height: 6,
              borderRadius: '50%',
              background: connectionStatus === 'connected' ? THEME.statusActive : THEME.textMuted,
              boxShadow: connectionStatus === 'connected' ? `0 0 6px ${THEME.statusActive}` : 'none',
            }} />
            {connectionStatus === 'connected' ? 'Connected' : 'Offline'}
          </div>
        )}
        {actions}
      </div>
    </div>
  );
}

// ─── QueryInput ──────────────────────────────────────────────────────────────

/**
 * Standard query input bar used across all query modules.
 * Replaces the per-module textarea + send button pattern.
 */
export function QueryInput({
  value,
  onChange,
  onSubmit,
  onCancel,
  isLoading,
  disabled,
  placeholder = 'Ask Pallas...',
  accent = THEME.accent,
}) {
  const handleKeyDown = (e) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      if (value.trim() && !isLoading && !disabled) onSubmit();
    }
  };

  return (
    <div style={{
      display: 'flex',
      alignItems: 'center',
      gap: 8,
      padding: '8px 12px',
      background: 'rgba(255,255,255,0.02)',
      border: `1px solid ${THEME.border}`,
      borderRadius: 10,
      transition: 'border-color 0.15s ease',
    }}>
      <EuiIcon type="editorCodeBlock" size="s" color={THEME.textMuted} />
      <input
        type="text"
        value={value}
        onChange={(e) => onChange(e.target.value)}
        onKeyDown={handleKeyDown}
        disabled={disabled || isLoading}
        placeholder={placeholder}
        style={{
          flex: 1,
          background: 'transparent',
          border: 'none',
          outline: 'none',
          color: THEME.text,
          fontSize: 13,
          fontFamily: FONT.base,
          lineHeight: 1.5,
        }}
      />
      {isLoading ? (
        <button
          onClick={onCancel}
          style={{
            display: 'flex',
            alignItems: 'center',
            gap: 5,
            padding: '5px 14px',
            borderRadius: 6,
            border: `1px solid ${THEME.danger}40`,
            background: THEME.danger + '15',
            color: THEME.danger,
            fontSize: 12,
            fontWeight: 600,
            fontFamily: 'inherit',
            cursor: 'pointer',
            outline: 'none',
          }}
        >
          <Spinner size={12} color={THEME.danger} />
          Cancel
        </button>
      ) : (
        <button
          onClick={onSubmit}
          disabled={!value.trim() || disabled}
          style={{
            display: 'flex',
            alignItems: 'center',
            gap: 5,
            padding: '5px 14px',
            borderRadius: 6,
            border: 'none',
            background: !value.trim() || disabled ? THEME.border : accent,
            color: !value.trim() || disabled ? THEME.textMuted : '#000',
            fontSize: 12,
            fontWeight: 600,
            fontFamily: 'inherit',
            cursor: !value.trim() || disabled ? 'not-allowed' : 'pointer',
            transition: 'all 0.15s ease',
            outline: 'none',
          }}
        >
          <EuiIcon type="returnKey" size="s" color={!value.trim() || disabled ? THEME.textMuted : '#000'} />
          Send
        </button>
      )}
    </div>
  );
}

// ─── Toast ───────────────────────────────────────────────────────────────────

/**
 * Lightweight toast notification. Self-dismissing after duration.
 */
export function Toast({ message, type = 'success', duration = 3000, onDismiss }) {
  React.useEffect(() => {
    const timer = setTimeout(onDismiss, duration);
    return () => clearTimeout(timer);
  }, [duration, onDismiss]);

  const colors = {
    success: { bg: THEME.success + '20', border: THEME.success + '40', text: THEME.success },
    error:   { bg: THEME.danger + '20',  border: THEME.danger + '40',  text: THEME.danger },
    info:    { bg: THEME.primary + '20', border: THEME.primary + '40', text: THEME.primary },
  };
  const c = colors[type] || colors.info;

  return (
    <div style={{
      position: 'fixed',
      bottom: 40,
      right: 20,
      zIndex: 9999,
      padding: '8px 16px',
      borderRadius: 8,
      background: c.bg,
      border: `1px solid ${c.border}`,
      color: c.text,
      fontSize: 12,
      fontWeight: 600,
      animation: 'pallas-slideUp 0.2s ease',
      backdropFilter: 'blur(12px)',
      WebkitBackdropFilter: 'blur(12px)',
    }}>
      {message}
    </div>
  );
}

// ─── SkeletonLine ────────────────────────────────────────────────────────────

/**
 * Shimmer loading placeholder line.
 */
export function SkeletonLine({ width = '100%', height = 12, style }) {
  return (
    <div style={{
      width,
      height,
      borderRadius: 4,
      background: `linear-gradient(90deg, ${THEME.border} 25%, ${THEME.cardHover} 50%, ${THEME.border} 75%)`,
      backgroundSize: '200% 100%',
      animation: 'pallas-shimmer 1.5s ease infinite',
      ...style,
    }} />
  );
}

// ─── Divider ─────────────────────────────────────────────────────────────────

export function Divider({ style }) {
  return (
    <div style={{
      height: 1,
      background: THEME.border,
      opacity: 0.5,
      margin: '8px 0',
      ...style,
    }} />
  );
}

// ─── StandupKPICard ─────────────────────────────────────────────────────────

export function StandupKPICard({ icon, label, value, subValue, color = THEME.accent }) {
  return (
    <div style={{
      flex: '1 1 0',
      minWidth: 140,
      padding: '14px 16px',
      borderRadius: 10,
      background: `linear-gradient(135deg, ${color}08, ${color}03)`,
      border: `1px solid ${color}20`,
      display: 'flex',
      flexDirection: 'column',
      gap: 6,
    }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
        <EuiIcon type={icon} size="s" color={THEME.textMuted} />
        <span style={{
          fontSize: 10,
          fontWeight: 700,
          color: THEME.textMuted,
          textTransform: 'uppercase',
          letterSpacing: '0.06em',
        }}>
          {label}
        </span>
      </div>
      <span style={{
        fontSize: 26,
        fontWeight: 700,
        color: THEME.text,
        fontFamily: FONT.mono,
        lineHeight: 1.1,
      }}>
        {value}
      </span>
      {subValue && (
        <span style={{ fontSize: 11, color: THEME.textMuted }}>
          {subValue}
        </span>
      )}
    </div>
  );
}

// ─── RiskScoreBadge ─────────────────────────────────────────────────────────

export function RiskScoreBadge({ score, maxScore = 1000 }) {
  const pct = Math.min(score / maxScore, 1);
  const riskColor = score >= 600 ? THEME.sevHigh : score >= 300 ? THEME.sevMedium : THEME.success;
  const riskLabel = score >= 600 ? 'HIGH' : score >= 300 ? 'MEDIUM' : 'LOW';
  const radius = 36;
  const stroke = 6;
  const circumference = 2 * Math.PI * radius;
  const dashOffset = circumference * (1 - pct);

  return (
    <div style={{
      display: 'flex',
      alignItems: 'center',
      gap: 16,
      padding: '14px 20px',
      borderRadius: 10,
      background: `${riskColor}06`,
      border: `1px solid ${riskColor}20`,
      flex: 1,
    }}>
      <svg width={88} height={88} viewBox="0 0 88 88" style={{ flexShrink: 0 }}>
        <circle cx="44" cy="44" r={radius} fill="none" stroke={THEME.border} strokeWidth={stroke} opacity={0.3} />
        <circle
          cx="44" cy="44" r={radius} fill="none"
          stroke={riskColor} strokeWidth={stroke}
          strokeLinecap="round"
          strokeDasharray={circumference}
          strokeDashoffset={dashOffset}
          transform="rotate(-90 44 44)"
          style={{ transition: 'stroke-dashoffset 1s ease' }}
        />
        <text x="44" y="40" textAnchor="middle" fill={riskColor} fontSize="18" fontWeight="800" fontFamily={FONT.mono}>
          {score}
        </text>
        <text x="44" y="56" textAnchor="middle" fill={THEME.textMuted} fontSize="9" fontWeight="600" letterSpacing="0.08em">
          {riskLabel}
        </text>
      </svg>
      <div>
        <div style={{ fontSize: 10, fontWeight: 700, color: THEME.textMuted, textTransform: 'uppercase', letterSpacing: '0.06em', marginBottom: 4 }}>
          Risk Score
        </div>
        <div style={{ fontSize: 13, color: THEME.textSecondary, lineHeight: 1.4 }}>
          Overall environment risk based on agent coverage, alert severity, and vulnerability exposure
        </div>
      </div>
    </div>
  );
}

// ─── CoverageBar ────────────────────────────────────────────────────────────

export function CoverageBar({ active, total, label = 'Agent Coverage' }) {
  const pct = total > 0 ? (active / total) * 100 : 0;
  const barColor = pct >= 80 ? THEME.success : pct >= 50 ? THEME.sevMedium : THEME.sevHigh;

  return (
    <div style={{
      padding: '14px 20px',
      borderRadius: 10,
      background: `${barColor}06`,
      border: `1px solid ${barColor}20`,
      flex: 1,
    }}>
      <div style={{
        fontSize: 10,
        fontWeight: 700,
        color: THEME.textMuted,
        textTransform: 'uppercase',
        letterSpacing: '0.06em',
        marginBottom: 8,
      }}>
        {label}
      </div>
      <div style={{ display: 'flex', alignItems: 'baseline', gap: 8, marginBottom: 8 }}>
        <span style={{ fontSize: 26, fontWeight: 700, color: THEME.text, fontFamily: FONT.mono, lineHeight: 1 }}>
          {active}
        </span>
        <span style={{ fontSize: 14, color: THEME.textMuted }}>
          / {total} active
        </span>
        <span style={{
          marginLeft: 'auto',
          fontSize: 13,
          fontWeight: 700,
          color: barColor,
          fontFamily: FONT.mono,
        }}>
          {pct.toFixed(1)}%
        </span>
      </div>
      <div style={{
        height: 6,
        borderRadius: 3,
        backgroundColor: THEME.border,
        overflow: 'hidden',
      }}>
        <div style={{
          width: `${pct}%`,
          height: '100%',
          borderRadius: 3,
          backgroundColor: barColor,
          transition: 'width 1s ease',
        }} />
      </div>
    </div>
  );
}
