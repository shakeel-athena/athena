/**
 * PallasVulnsDashboard — Vulnerability-focused Pallas AI query interface
 *
 * Redesigned with shared PallasUI components and Vulns accent color (#F59E0B).
 * CVE analysis, vulnerability correlation, and risk assessment via the
 * Pallas WebSocket backend.
 */

import React, { useState, useRef, useEffect, useCallback } from 'react';
import { EuiIcon } from '@elastic/eui';
import { THEME } from '../../utils/theme';
import { MODULE_COLORS, ModuleHeader, ActionChip, SectionHeader, EmptyState, FONT } from './PallasUI';
import { usePallas } from '../../hooks/usePallas';
import { ResponsePanel } from './PallasResponsePanel';
import { StrategyPanel } from './PallasStrategyPanel';
import { QueryHistory } from './PallasQueryHistory';

const ACCENT = MODULE_COLORS.vulns.accent;

// ─── Quick Actions ───────────────────────────────────────────────────────────

const VULN_QUICK_ACTIONS = [
  { label: 'Vulnerability Summary', query: 'show vulnerability summary', icon: 'bug' },
  { label: 'Critical CVEs', query: 'show critical vulnerabilities', icon: 'warning' },
  { label: 'Vulns by Agent', query: 'show vulnerabilities with agent details', icon: 'users' },
  { label: 'Top Vulnerable Agents', query: 'show top vulnerable agents', icon: 'visBarVerticalStacked' },
  { label: 'Active + High Vulns', query: 'active agents with high vulnerabilities', icon: 'checkInCircleFilled' },
  { label: 'Disconnected + Critical', query: 'disconnected agents with critical vulnerabilities', icon: 'offline' },
  { label: 'Compare by Status', query: 'compare vulnerabilities active vs disconnected', icon: 'merge' },
  { label: 'Behavioral Baseline', query: 'establish behavioral baseline', icon: 'visLine' },
];

// ─── Strategy Categories ─────────────────────────────────────────────────────

const VULN_STRATEGIES = [
  {
    name: 'Risk Assessment',
    icon: 'shield',
    strategies: [
      { label: 'Vulnerability Summary', query: 'show vulnerability summary', description: 'Overall vulnerability landscape and severity breakdown' },
      { label: 'Critical CVEs', query: 'show critical vulnerabilities', description: 'Critical severity vulnerabilities requiring immediate action' },
      { label: 'Top Vulnerable Agents', query: 'show top vulnerable agents', description: 'Agents ranked by vulnerability count and severity' },
      { label: 'Compare by Status', query: 'compare vulnerabilities active vs disconnected', description: 'Compare vulnerability exposure across agent statuses' },
    ],
  },
  {
    name: 'Agent Exposure',
    icon: 'compute',
    strategies: [
      { label: 'Active + High Vulns', query: 'active agents with high vulnerabilities', description: 'Active agents with unpatched high-severity CVEs' },
      { label: 'Disconnected + Critical', query: 'disconnected agents with critical vulnerabilities', description: 'Unreachable agents with critical exposure' },
      { label: 'Vulns by Agent', query: 'show vulnerabilities with agent details', description: 'Full vulnerability details per agent' },
      { label: 'Agent Posture Deep Dive', query: 'deep dive security posture for agent {agent_id}', description: 'Full security posture for a specific agent', params: [{ key: 'agent_id', label: 'Agent ID', placeholder: 'e.g. 019' }] },
    ],
  },
  {
    name: 'Investigation',
    icon: 'inspect',
    strategies: [
      { label: 'Alert + Vuln Correlation', query: 'correlate alerts with vulnerabilities', description: 'Match triggered alerts against existing CVEs' },
      { label: 'CVE Lookup', query: 'show vulnerability summary for {cve_id}', description: 'Deep dive into a specific CVE', params: [{ key: 'cve_id', label: 'CVE ID', placeholder: 'e.g. CVE-2024-1234' }] },
      { label: 'Behavioral Baseline', query: 'establish behavioral baseline', description: 'Normal vs anomalous behavior patterns' },
    ],
  },
];

// ─── Component ───────────────────────────────────────────────────────────────

export default function PallasVulnsDashboard({ connectionStatus: externalStatus, onConnectionStatusChange, onQueryComplete }) {
  const {
    response,
    isLoading,
    connectionStatus: wsStatus,
    sendQuery,
    cancelQuery,
    clearResponse,
    queryHistory,
    pinnedResponses,
    pinResponse,
    unpinResponse,
  } = usePallas('vulns', { onQueryComplete });

  const [inputValue, setInputValue] = useState('');
  const [showStrategies, setShowStrategies] = useState(false);

  const inputRef = useRef(null);
  const responseAreaRef = useRef(null);

  const effectiveStatus = wsStatus === 'connected' ? 'connected' : externalStatus;
  const isDisabled = isLoading || effectiveStatus !== 'connected';

  // Bubble WS status up to parent
  useEffect(() => {
    if (onConnectionStatusChange) onConnectionStatusChange(wsStatus);
  }, [wsStatus, onConnectionStatusChange]);

  useEffect(() => {
    if (response && responseAreaRef.current) {
      responseAreaRef.current.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
  }, [response]);

  const handleSend = useCallback(() => {
    const trimmed = inputValue.trim();
    if (!trimmed || isDisabled) return;
    sendQuery(trimmed);
    setInputValue('');
    if (inputRef.current) inputRef.current.style.height = 'auto';
  }, [inputValue, isDisabled, sendQuery]);

  const handleQuickAction = useCallback((query) => {
    if (isDisabled) return;
    sendQuery(query);
  }, [isDisabled, sendQuery]);

  const handleStrategyExecute = useCallback((query) => {
    if (isDisabled) return;
    sendQuery(query);
    setShowStrategies(false);
  }, [isDisabled, sendQuery]);

  const handleHistorySelect = useCallback((query) => {
    setInputValue(query);
    if (inputRef.current) inputRef.current.focus();
  }, []);

  const handleHistoryExecute = useCallback((query) => {
    if (isDisabled) return;
    sendQuery(query);
  }, [isDisabled, sendQuery]);

  const handleSuggestionClick = useCallback((query) => {
    if (isDisabled) return;
    sendQuery(query);
  }, [isDisabled, sendQuery]);

  const handleInputChange = (e) => {
    setInputValue(e.target.value);
    const el = e.target;
    el.style.height = 'auto';
    el.style.height = Math.min(el.scrollHeight, 120) + 'px';
  };

  const handleKeyDown = (e) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  return (
    <div style={{
      height: '100%',
      display: 'flex',
      flexDirection: 'column',
      overflow: 'hidden',
      fontFamily: FONT.base,
    }}>
      {/* Module Header */}
      <ModuleHeader
        icon="bug"
        title="Vulnerabilities"
        description="CVE analysis, vulnerability correlation, and risk assessment"
        accent={ACCENT}
        connectionStatus={effectiveStatus}
        actions={
          response ? (
            <button
              onClick={clearResponse}
              aria-label="Clear response"
              style={{
                padding: '4px 8px', border: `1px solid ${THEME.border}`, borderRadius: 6,
                backgroundColor: 'transparent', cursor: 'pointer', display: 'flex', alignItems: 'center',
                outline: 'none',
              }}
            >
              <EuiIcon type="cross" size="s" color={THEME.textMuted} />
            </button>
          ) : null
        }
      />

      {/* Query Input */}
      <div style={{
        padding: '12px 20px',
        borderBottom: `1px solid ${THEME.border}`,
        flexShrink: 0,
      }}>
        {effectiveStatus !== 'connected' && (
          <div style={{
            padding: '6px 12px',
            fontSize: 12,
            color: effectiveStatus === 'reconnecting' ? THEME.warning : '#F87171',
            backgroundColor: effectiveStatus === 'reconnecting' ? 'rgba(220,106,19,0.10)' : 'rgba(248,113,113,0.08)',
            borderRadius: 6,
            marginBottom: 8,
            display: 'flex',
            alignItems: 'center',
            gap: 6,
          }}>
            <EuiIcon type="warning" size="s" color={effectiveStatus === 'reconnecting' ? THEME.warning : '#F87171'} />
            {effectiveStatus === 'reconnecting' ? 'Reconnecting to server...' : 'Server disconnected'}
          </div>
        )}

        <div style={{ display: 'flex', gap: 8, alignItems: 'flex-end' }}>
          <div style={{ flex: 1, position: 'relative' }}>
            <textarea
              ref={inputRef}
              value={inputValue}
              onChange={handleInputChange}
              onKeyDown={handleKeyDown}
              placeholder={effectiveStatus === 'connected'
                ? 'Ask about vulnerabilities, CVEs, agent exposure...'
                : 'Waiting for connection...'}
              aria-label="Vulnerability query"
              rows={1}
              disabled={isDisabled}
              style={{
                width: '100%',
                padding: '10px 14px',
                border: `1px solid ${THEME.border}`,
                borderRadius: 8,
                outline: 'none',
                backgroundColor: 'rgba(255,255,255,0.02)',
                color: THEME.text,
                fontSize: 13,
                fontFamily: FONT.base,
                resize: 'none',
                lineHeight: 1.5,
                maxHeight: 120,
                boxSizing: 'border-box',
              }}
            />
          </div>

          <QueryHistory
            history={queryHistory}
            onSelect={handleHistorySelect}
            onExecute={handleHistoryExecute}
            disabled={isDisabled}
          />

          <button
            onClick={isLoading ? cancelQuery : handleSend}
            disabled={!isLoading && (!inputValue.trim() || isDisabled)}
            aria-label={isLoading ? 'Cancel' : 'Send'}
            style={{
              padding: '10px 18px',
              borderRadius: 8,
              border: 'none',
              background: isLoading ? THEME.danger : ACCENT,
              color: '#fff',
              fontSize: 13,
              fontWeight: 600,
              cursor: (!isLoading && (!inputValue.trim() || isDisabled)) ? 'not-allowed' : 'pointer',
              opacity: (!isLoading && (!inputValue.trim() || isDisabled)) ? 0.5 : 1,
              display: 'flex',
              alignItems: 'center',
              gap: 6,
              transition: 'opacity 0.15s',
              flexShrink: 0,
              outline: 'none',
            }}
          >
            {isLoading ? (
              <span style={{
                display: 'inline-block', width: 14, height: 14,
                border: '2px solid rgba(255,255,255,0.3)', borderTopColor: '#fff',
                borderRadius: '50%', animation: 'pallas-spin 0.6s linear infinite',
              }} />
            ) : (
              <EuiIcon type="returnKey" size="s" color="#fff" />
            )}
            {isLoading ? 'Cancel' : 'Send'}
          </button>
        </div>
      </div>

      {/* Main Content */}
      <div style={{ flex: 1, overflow: 'auto', padding: '16px 20px' }} className="pallas-scrollbar">

        {/* Quick Actions */}
        <SectionHeader icon="bolt" title="Quick Actions" accent={ACCENT} />
        <div style={{ display: 'flex', flexWrap: 'wrap', gap: 6, marginBottom: 16 }}>
          {VULN_QUICK_ACTIONS.map((action) => (
            <ActionChip
              key={action.label}
              icon={action.icon}
              label={action.label}
              onClick={() => handleQuickAction(action.query)}
              disabled={isDisabled}
              accent={ACCENT}
            />
          ))}
        </div>

        {/* Browse Strategies */}
        <div style={{ marginBottom: 16 }}>
          <ActionChip
            icon={showStrategies ? 'arrowUp' : 'list'}
            label={showStrategies ? 'Hide Strategies' : 'Browse All Strategies'}
            onClick={() => setShowStrategies(!showStrategies)}
            active={showStrategies}
            accent={ACCENT}
          />
          {showStrategies && (
            <div style={{ marginTop: 10 }}>
              <StrategyPanel
                categories={VULN_STRATEGIES}
                onExecute={handleStrategyExecute}
                disabled={isDisabled}
                isLoading={isLoading}
                defaultExpandedIndex={0}
                storageKey="vulns"
              />
            </div>
          )}
        </div>

        {/* Pinned Results */}
        {pinnedResponses.length > 0 && (
          <div style={{ marginBottom: 16 }}>
            <SectionHeader icon="pinFilled" title="Pinned Results" count={pinnedResponses.length} accent={ACCENT} />
            <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
              {pinnedResponses.map((pinned, idx) => (
                <div key={idx} style={{
                  padding: '10px 12px',
                  borderRadius: 8,
                  border: `1px solid ${THEME.border}`,
                  backgroundColor: 'rgba(255,255,255,0.02)',
                  display: 'flex',
                  justifyContent: 'space-between',
                  alignItems: 'center',
                }}>
                  <div style={{ flex: 1, minWidth: 0 }}>
                    <div style={{ fontSize: 12, color: THEME.text, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                      {(pinned.metadata?.strategy) ? pinned.metadata.strategy.replace(/_/g, ' ') : 'Query result'}
                    </div>
                    <div style={{ fontSize: 10, color: THEME.textMuted, marginTop: 2 }}>
                      {new Date(pinned.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                    </div>
                  </div>
                  <button
                    onClick={() => unpinResponse(idx)}
                    aria-label="Unpin"
                    style={{
                      padding: 4, border: 'none', background: 'transparent',
                      cursor: 'pointer', display: 'flex', alignItems: 'center',
                    }}
                  >
                    <EuiIcon type="cross" size="s" color={THEME.textMuted} />
                  </button>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Response Area */}
        <div ref={responseAreaRef}>
          {isLoading && !response ? (
            <ResponsePanel isLoading onCancel={cancelQuery} accent={ACCENT} />
          ) : response ? (
            <ResponsePanel
              content={response.content}
              metadata={response.metadata}
              socAnalysis={response.socAnalysis}
              suggestions={response.suggestions}
              isLoading={isLoading}
              onCancel={isLoading ? cancelQuery : undefined}
              onSuggestionClick={handleSuggestionClick}
              onPin={() => pinResponse(response)}
              isPinned={pinnedResponses.some((p) => p.content === response.content && p.timestamp === response.timestamp)}
              accent={ACCENT}
            />
          ) : (
            <EmptyState
              icon="bug"
              title="Vulnerability Intelligence"
              description="Query CVEs, correlate vulnerabilities with agents, assess risk exposure, and generate remediation strategies. Select a quick action or type a query above."
              accent={ACCENT}
            />
          )}
        </div>
      </div>
    </div>
  );
}
