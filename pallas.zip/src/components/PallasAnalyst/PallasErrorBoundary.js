import React, { Component } from 'react';
import { THEME } from '../../utils/theme';

export class PallasErrorBoundary extends Component {
  constructor(props) {
    super(props);
    this.state = {
      hasError:    false,
      error:       null,
      errorInfo:   null,
      showDetails: false,
    };
    this.handleReset       = this.handleReset.bind(this);
    this.toggleDetails     = this.toggleDetails.bind(this);
  }

  static getDerivedStateFromError(error) {
    return { hasError: true, error };
  }

  componentDidCatch(error, errorInfo) {
    console.error('[PallasErrorBoundary] Uncaught error:', error, errorInfo);
    this.setState({ errorInfo });
  }

  handleReset() {
    this.setState({
      hasError:    false,
      error:       null,
      errorInfo:   null,
      showDetails: false,
    });
  }

  toggleDetails() {
    this.setState(prev => ({ showDetails: !prev.showDetails }));
  }

  render() {
    const { hasError, error, errorInfo, showDetails } = this.state;

    if (!hasError) {
      return this.props.children;
    }

    const componentStack =
      errorInfo && errorInfo.componentStack ? errorInfo.componentStack : '';

    return (
      <div style={{ padding: 24 }}>
        {/* Red callout box */}
        <div
          style={{
            background:   'rgba(246, 114, 106, 0.08)',
            border:       '1px solid rgba(246, 114, 106, 0.3)',
            borderRadius: 10,
            padding:      20,
          }}
        >
          {/* Title */}
          <p
            style={{
              fontSize:   16,
              fontWeight: 'bold',
              color:      THEME.text,
              margin:     '0 0 10px 0',
            }}
          >
            Something went wrong
          </p>

          {/* Description */}
          <p
            style={{
              fontSize: 13,
              color:    THEME.textSecondary,
              margin:   '0 0 18px 0',
            }}
          >
            An unexpected error occurred in the Pallas Analyst interface. You can
            try recovering without a full page reload, or reload the page to start
            fresh.
          </p>

          {/* Action buttons */}
          <div style={{ display: 'flex', gap: 10, marginBottom: error ? 16 : 0 }}>
            <button
              onClick={this.handleReset}
              style={{
                background:   THEME.danger,
                color:        '#ffffff',
                border:       'none',
                borderRadius: 6,
                padding:      '7px 16px',
                fontSize:     13,
                cursor:       'pointer',
                fontWeight:   500,
              }}
            >
              Try Again
            </button>

            <button
              onClick={() => window.location.reload()}
              style={{
                background:   'transparent',
                color:        THEME.danger,
                border:       `1px solid ${THEME.danger}`,
                borderRadius: 6,
                padding:      '7px 16px',
                fontSize:     13,
                cursor:       'pointer',
                fontWeight:   500,
              }}
            >
              Reload Page
            </button>
          </div>

          {/* Error details toggle */}
          {error && (
            <div>
              <button
                onClick={this.toggleDetails}
                style={{
                  background:  'transparent',
                  border:      'none',
                  color:       THEME.textSecondary,
                  fontSize:    12,
                  cursor:      'pointer',
                  padding:     '4px 0',
                  textDecoration: 'underline',
                }}
              >
                {showDetails ? 'Hide Error Details' : 'View Error Details'}
              </button>

              {showDetails && (
                <pre
                  style={{
                    marginTop:    10,
                    padding:      12,
                    background:   THEME.bgDeep,
                    border:       `1px solid ${THEME.border}`,
                    borderRadius: 6,
                    fontFamily:   'monospace',
                    fontSize:     11,
                    color:        THEME.textSecondary,
                    maxHeight:    200,
                    overflowY:    'auto',
                    whiteSpace:   'pre-wrap',
                    wordBreak:    'break-word',
                    margin:       '10px 0 0 0',
                  }}
                >
                  {error.toString()}
                  {componentStack}
                </pre>
              )}
            </div>
          )}
        </div>
      </div>
    );
  }
}

export default PallasErrorBoundary;
