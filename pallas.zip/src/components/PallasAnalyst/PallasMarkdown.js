/**
 * PallasMarkdown — Custom Markdown Renderer
 *
 * Dependency-free markdown parser ported from pallas/public/components/chat/MarkdownRenderer.tsx.
 * Renders AI responses with tables, headers, lists, code blocks, and inline formatting.
 * All colors from Agelia THEME (single source of truth).
 */

import React, { useMemo } from 'react';
import { THEME } from '../../utils/theme';

const T = {
  headerAccent: THEME.accent,
  text: THEME.text,
  textSecondary: THEME.textSecondary,
  codeBg: THEME.bgDeep,
  codeBorder: THEME.border,
  codeText: THEME.accent,
  tableBorder: THEME.border,
  tableHeaderBg: THEME.cardSubtle,
  tableRowAlt: 'rgba(255, 255, 255, 0.02)',
  hrColor: THEME.border,
  linkColor: THEME.primary,
  boldColor: THEME.textBright,
};

// ─── Inline formatting ──────────────────────────────────────────────────────

function parseInline(text) {
  if (!text) return text;
  const parts = [];
  let remaining = text;
  let key = 0;

  while (remaining.length > 0) {
    // Bold **text**
    const boldMatch = remaining.match(/\*\*(.+?)\*\*/);
    // Inline code `text`
    const codeMatch = remaining.match(/`([^`]+)`/);
    // Italic *text* (not **)
    const italicMatch = remaining.match(/(?<!\*)\*(?!\*)(.+?)(?<!\*)\*(?!\*)/);

    // Find earliest match
    const matches = [
      boldMatch && { type: 'bold', match: boldMatch },
      codeMatch && { type: 'code', match: codeMatch },
      italicMatch && { type: 'italic', match: italicMatch },
    ].filter(Boolean).sort((a, b) => a.match.index - b.match.index);

    if (matches.length === 0) {
      parts.push(remaining);
      break;
    }

    const first = matches[0];
    const idx = first.match.index;

    if (idx > 0) {
      parts.push(remaining.slice(0, idx));
    }

    if (first.type === 'bold') {
      parts.push(
        <strong key={key++} style={{ color: T.boldColor, fontWeight: 600 }}>
          {first.match[1]}
        </strong>
      );
    } else if (first.type === 'code') {
      parts.push(
        <code key={key++} style={{
          backgroundColor: T.codeBg,
          border: `1px solid ${T.codeBorder}`,
          padding: '1px 5px',
          borderRadius: 3,
          fontSize: '0.85em',
          fontFamily: 'SFMono-Regular, Menlo, Monaco, Consolas, monospace',
          color: T.codeText,
        }}>
          {first.match[1]}
        </code>
      );
    } else if (first.type === 'italic') {
      parts.push(<em key={key++}>{first.match[1]}</em>);
    }

    remaining = remaining.slice(idx + first.match[0].length);
  }

  return parts.length === 1 && typeof parts[0] === 'string' ? parts[0] : parts;
}

// ─── Table renderer ─────────────────────────────────────────────────────────

function renderTable(lines) {
  if (lines.length < 2) return null;

  const parseRow = (line) =>
    line.split('|').map(cell => cell.trim()).filter(Boolean);

  const headers = parseRow(lines[0]);

  // Skip separator row (---|---|---)
  const startIdx = lines[1] && /^[\s|:-]+$/.test(lines[1]) ? 2 : 1;
  const rows = lines.slice(startIdx).map(parseRow);

  return (
    <div style={{ overflowX: 'auto', margin: '12px 0', borderRadius: 8, border: `1px solid ${T.tableBorder}` }}>
      <table style={{
        width: '100%',
        borderCollapse: 'collapse',
        fontSize: 12,
      }}>
        <thead>
          <tr style={{
            backgroundColor: T.tableHeaderBg || 'rgba(255,255,255,0.04)',
          }}>
            {headers.map((h, i) => (
              <th key={i} style={{
                padding: '10px 14px',
                textAlign: 'left',
                fontWeight: 600,
                fontSize: 11,
                color: T.textSecondary || T.text,
                textTransform: 'uppercase',
                letterSpacing: '0.03em',
                borderBottom: `1px solid ${T.tableBorder}`,
                whiteSpace: 'nowrap',
              }}>
                {parseInline(h)}
              </th>
            ))}
          </tr>
        </thead>
        <tbody>
          {rows.map((row, ri) => (
            <tr key={ri} style={{
              backgroundColor: ri % 2 === 1 ? 'rgba(255,255,255,0.02)' : 'transparent',
              transition: 'background-color 0.1s',
            }}
              onMouseEnter={(e) => { e.currentTarget.style.backgroundColor = 'rgba(22,197,192,0.04)'; }}
              onMouseLeave={(e) => { e.currentTarget.style.backgroundColor = ri % 2 === 1 ? 'rgba(255,255,255,0.02)' : 'transparent'; }}
            >
              {row.map((cell, ci) => (
                <td key={ci} style={{
                  padding: '8px 14px',
                  color: T.text,
                  borderBottom: `1px solid rgba(255,255,255,0.04)`,
                  fontSize: 12,
                  lineHeight: 1.4,
                }}>
                  {parseInline(cell)}
                </td>
              ))}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

// ─── Main component ─────────────────────────────────────────────────────────

function PallasMarkdown({ content }) {
  const rendered = useMemo(() => {
    if (!content) return null;

    const lines = content.split('\n');
    const elements = [];
    let i = 0;

    while (i < lines.length) {
      const line = lines[i];
      const trimmed = line.trim();

      // Empty line → spacer
      if (trimmed === '') {
        elements.push(<div key={i} style={{ height: 6 }} />);
        i++;
        continue;
      }

      // Horizontal rule
      if (/^[-*_]{3,}$/.test(trimmed)) {
        elements.push(
          <hr key={i} style={{
            border: 'none',
            borderTop: `1px solid ${T.hrColor}`,
            margin: '12px 0',
          }} />
        );
        i++;
        continue;
      }

      // Code block ```
      if (trimmed.startsWith('```')) {
        const lang = trimmed.slice(3).trim();
        const codeLines = [];
        i++;
        while (i < lines.length && !lines[i].trim().startsWith('```')) {
          codeLines.push(lines[i]);
          i++;
        }
        i++; // skip closing ```
        elements.push(
          <pre key={`code-${i}`} style={{
            backgroundColor: T.codeBg,
            border: `1px solid ${T.codeBorder}`,
            borderRadius: 6,
            padding: '12px 16px',
            margin: '8px 0',
            overflowX: 'auto',
            fontSize: 12,
            lineHeight: 1.5,
            fontFamily: 'SFMono-Regular, Menlo, Monaco, Consolas, monospace',
            color: T.text,
          }}>
            {lang && (
              <div style={{
                fontSize: 10,
                color: T.textSecondary,
                marginBottom: 6,
                textTransform: 'uppercase',
                letterSpacing: '0.5px',
              }}>{lang}</div>
            )}
            <code>{codeLines.join('\n')}</code>
          </pre>
        );
        continue;
      }

      // ### Header (h5)
      if (trimmed.startsWith('### ')) {
        elements.push(
          <h5 key={i} style={{
            fontSize: 14,
            fontWeight: 600,
            color: T.text,
            margin: '12px 0 4px',
          }}>
            {parseInline(trimmed.slice(4))}
          </h5>
        );
        i++;
        continue;
      }

      // ## Header (h4 with accent bar)
      if (trimmed.startsWith('## ')) {
        elements.push(
          <h4 key={i} style={{
            display: 'flex',
            alignItems: 'center',
            gap: 8,
            fontSize: 15,
            fontWeight: 600,
            color: T.text,
            margin: '14px 0 6px',
          }}>
            <span style={{
              width: 3,
              height: 18,
              backgroundColor: T.headerAccent,
              borderRadius: 2,
              flexShrink: 0,
            }} />
            {parseInline(trimmed.slice(3))}
          </h4>
        );
        i++;
        continue;
      }

      // # Header (h3)
      if (trimmed.startsWith('# ')) {
        elements.push(
          <h3 key={i} style={{
            fontSize: 17,
            fontWeight: 700,
            color: T.text,
            margin: '16px 0 8px',
          }}>
            {parseInline(trimmed.slice(2))}
          </h3>
        );
        i++;
        continue;
      }

      // Table (consecutive lines starting with |)
      if (trimmed.startsWith('|')) {
        const tableLines = [];
        while (i < lines.length && lines[i].trim().startsWith('|')) {
          tableLines.push(lines[i].trim());
          i++;
        }
        elements.push(
          <React.Fragment key={`table-${i}`}>
            {renderTable(tableLines)}
          </React.Fragment>
        );
        continue;
      }

      // Bullet list (- or *)
      if (/^[-*]\s/.test(trimmed)) {
        const items = [];
        while (i < lines.length && /^[-*]\s/.test(lines[i].trim())) {
          items.push(lines[i].trim().slice(2));
          i++;
        }
        elements.push(
          <ul key={`ul-${i}`} style={{
            margin: '6px 0',
            paddingLeft: 20,
            color: T.text,
            lineHeight: 1.7,
          }}>
            {items.map((item, idx) => (
              <li key={idx} style={{ marginBottom: 2 }}>
                {parseInline(item)}
              </li>
            ))}
          </ul>
        );
        continue;
      }

      // Numbered list
      if (/^\d+\.\s/.test(trimmed)) {
        const items = [];
        while (i < lines.length && /^\d+\.\s/.test(lines[i].trim())) {
          items.push(lines[i].trim().replace(/^\d+\.\s/, ''));
          i++;
        }
        elements.push(
          <ol key={`ol-${i}`} style={{
            margin: '6px 0',
            paddingLeft: 22,
            color: T.text,
            lineHeight: 1.7,
          }}>
            {items.map((item, idx) => (
              <li key={idx} style={{ marginBottom: 2 }}>
                {parseInline(item)}
              </li>
            ))}
          </ol>
        );
        continue;
      }

      // > Blockquote
      if (trimmed.startsWith('> ')) {
        const quoteLines = [];
        while (i < lines.length && lines[i].trim().startsWith('> ')) {
          quoteLines.push(lines[i].trim().slice(2));
          i++;
        }
        elements.push(
          <blockquote key={`bq-${i}`} style={{
            borderLeft: `3px solid ${T.headerAccent}`,
            paddingLeft: 12,
            margin: '8px 0',
            color: T.textSecondary,
            fontStyle: 'italic',
            lineHeight: 1.6,
          }}>
            {quoteLines.map((ql, idx) => (
              <div key={idx}>{parseInline(ql)}</div>
            ))}
          </blockquote>
        );
        continue;
      }

      // Default: paragraph
      elements.push(
        <p key={i} style={{
          margin: '4px 0',
          color: T.text,
          lineHeight: 1.6,
          fontSize: 13,
        }}>
          {parseInline(trimmed)}
        </p>
      );
      i++;
    }

    return elements;
  }, [content]);

  return (
    <div style={{ wordWrap: 'break-word', overflowWrap: 'break-word' }}>
      {rendered}
    </div>
  );
}

export default React.memo(PallasMarkdown);
