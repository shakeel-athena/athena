/**
 * PallasNIDSTools — NIDS Intelligence query interface
 *
 * Redesigned with shared PallasUI components and NIDS accent color (#F97316).
 * Suricata-powered network intrusion detection and traffic analysis.
 */

import React, { useState, useRef, useEffect, useCallback } from 'react';
import { EuiIcon } from '@elastic/eui';
import { THEME } from '../../utils/theme';
import { MODULE_COLORS, ModuleHeader, ActionChip, SectionHeader, EmptyState, FONT } from './PallasUI';
import { usePallas } from '../../hooks/usePallas';
import { ResponsePanel, ComparePanel } from './PallasResponsePanel';
import { StrategyPanel } from './PallasStrategyPanel';
import { QueryHistory } from './PallasQueryHistory';
import { NIDS_PANEL_STRATEGIES } from './PallasStrategies';

const ACCENT = MODULE_COLORS.nids.accent;

// ─── Quick Actions ───────────────────────────────────────────────────────────

const NIDS_QUICK_ACTIONS = [
  { label: 'IDS Alerts', query: 'show suricata alerts', icon: 'bell' },
  { label: 'Critical Alerts', query: 'show critical suricata alerts', icon: 'warning' },
  { label: 'High Severity', query: 'show high severity suricata alerts', icon: 'importAction' },
  { label: 'Alert Summary', query: 'show suricata alert summary', icon: 'list' },
  { label: 'Top Signatures', query: 'show top suricata signatures', icon: 'visBarVerticalStacked' },
  { label: 'Top Attackers', query: 'show top suricata attackers', icon: 'globe' },
  { label: 'Network Analysis', query: 'suricata network analysis', icon: 'cloud' },
  { label: 'Categories', query: 'show suricata alert categories', icon: 'visTagCloud' },
  { label: 'Health Status', query: 'show suricata health status', icon: 'heartbeatApp' },
  { label: 'Search Alerts', query: 'search suricata alerts for {keyword}', icon: 'search', paramKey: 'keyword', paramPlaceholder: 'e.g. CVE-2024, exploit, malware' },
];

// ─── Component ───────────────────────────────────────────────────────────────

export default function PallasNIDSTools({ connectionStatus: externalStatus, onConnectionStatusChange, onQueryComplete, toolHealth }) {
  const [inputValue, setInputValue] = useState('');
  const [showStrategies, setShowStrategies] = useState(false);
  const [pinnedCollapsed, setPinnedCollapsed] = useState(false);
  const [expandedPinIndex, setExpandedPinIndex] = useState(null);
  const [comparing, setComparing] = useState(false);
  const [chipParams, setChipParams] = useState({});
  const [activeParamChip, setActiveParamChip] = useState(null);

  const inputRef = useRef(null);
  const responseRef = useRef(null);

  const {
    response,
    isLoading,
    connectionStatus,
    sendQuery,
    cancelQuery,
    clearResponse,
    queryHistory,
    pinnedResponses,
    pinResponse,
    unpinResponse,
  } = usePallas('nids', { onQueryComplete });

  const effectiveStatus = connectionStatus === 'connected' ? 'connected' : externalStatus;
  const suricataDisabled = toolHealth?.suricata === 'disabled';
  const allDisabled = isLoading || effectiveStatus !== 'connected';

  // Bubble WS status up to parent
  useEffect(() => {
    if (onConnectionStatusChange) onConnectionStatusChange(connectionStatus);
  }, [connectionStatus, onConnectionStatusChange]);

  useEffect(() => {
    if (response && responseRef.current) {
      responseRef.current.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
  }, [response]);

  // ── Handlers ───────────────────────────────────────────────────────────────

  const handleSend = useCallback(() => {
    const trimmed = inputValue.trim();
    if (!trimmed || allDisabled) return;
    sendQuery(trimmed);
    setInputValue('');
    if (inputRef.current) inputRef.current.style.height = 'auto';
  }, [inputValue, allDisabled, sendQuery]);

  const handleChipClick = useCallback((action, idx) => {
    if (allDisabled) return;
    if (action.paramKey) {
      if (activeParamChip === idx) {
        const val = (chipParams[action.paramKey] || '').trim();
        if (!val) return;
        sendQuery(action.query.replace(`{${action.paramKey}}`, val));
        setActiveParamChip(null);
        setChipParams({});
      } else {
        setActiveParamChip(idx);
      }
      return;
    }
    sendQuery(action.query);
  }, [allDisabled, activeParamChip, chipParams, sendQuery]);

  const handleParamKeyDown = useCallback((e, action) => {
    if (e.key === 'Enter') {
      e.preventDefault();
      const val = (chipParams[action.paramKey] || '').trim();
      if (!val) return;
      sendQuery(action.query.replace(`{${action.paramKey}}`, val));
      setActiveParamChip(null);
      setChipParams({});
    } else if (e.key === 'Escape') {
      setActiveParamChip(null);
    }
  }, [chipParams, sendQuery]);

  const handleStrategyExecute = useCallback((query) => {
    sendQuery(query);
    setShowStrategies(false);
  }, [sendQuery]);

  const handleSuggestionClick = useCallback((query) => {
    sendQuery(query);
  }, [sendQuery]);

  const handleHistorySelect = useCallback((query) => {
    setInputValue(query);
    if (inputRef.current) inputRef.current.focus();
  }, []);

  const handleHistoryExecute = useCallback((query) => {
    sendQuery(query);
  }, [sendQuery]);

  const handleInputChange = (e) => {
    setInputValue(e.target.value);
    const el = e.target;
    el.style.height = 'auto';
    el.style.height = Math.min(el.scrollHeight, 120) + 'px';
  };

  const handleKeyDown = (e) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  const handleExportPinned = (e) => {
    e.stopPropagation();
    const sections = pinnedResponses.map((p, i) => {
      const parts = [`## Pin ${i + 1} \u2014 ${new Date(p.timestamp).toLocaleString()}`];
      if (p.metadata?.strategy) parts.push(`**Strategy:** ${p.metadata.strategy}`);
      parts.push('', p.content);
      if (p.socAnalysis) parts.push('', `## SOC ANALYSIS\n${p.socAnalysis}`);
      return parts.join('\n');
    });
    const report = `# Pallas NIDS Tools \u2014 Pinned Results Export\n**Exported:** ${new Date().toLocaleString()}\n**Count:** ${pinnedResponses.length}\n\n---\n\n${sections.join('\n\n---\n\n')}`;
    const blob = new Blob([report], { type: 'text/markdown;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `pallas-nids-pinned-${new Date().toISOString().slice(0, 19).replace(/[:.]/g, '-')}.md`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  // ── Render ─────────────────────────────────────────────────────────────────

  return (
    <div style={{
      height: '100%',
      display: 'flex',
      flexDirection: 'column',
      overflow: 'hidden',
      fontFamily: FONT.base,
    }}>
      {/* Module Header */}
      <ModuleHeader
        icon="globe"
        title="NIDS Intelligence"
        description="Suricata-powered network intrusion detection and traffic analysis"
        accent={ACCENT}
        connectionStatus={effectiveStatus}
        actions={
          response ? (
            <button
              onClick={clearResponse}
              aria-label="Clear response"
              style={{
                padding: '4px 8px', border: `1px solid ${THEME.border}`, borderRadius: 6,
                backgroundColor: 'transparent', cursor: 'pointer', display: 'flex', alignItems: 'center',
                outline: 'none',
              }}
            >
              <EuiIcon type="cross" size="s" color={THEME.textMuted} />
            </button>
          ) : null
        }
      />

      {/* Query Input */}
      <div style={{
        padding: '12px 20px',
        borderBottom: `1px solid ${THEME.border}`,
        flexShrink: 0,
      }}>
        {/* Suricata Disabled Banner */}
        {suricataDisabled && (
          <div style={{
            padding: '10px 14px',
            borderRadius: 8,
            border: '1px solid rgba(255,166,0,0.3)',
            backgroundColor: 'rgba(255,166,0,0.08)',
            marginBottom: 10,
            display: 'flex',
            alignItems: 'flex-start',
            gap: 10,
          }}>
            <EuiIcon type="warning" size="s" color="#FFA600" />
            <div>
              <div style={{ fontSize: 13, fontWeight: 600, color: '#FFA600', marginBottom: 4 }}>
                Suricata Integration Disabled
              </div>
              <div style={{ fontSize: 12, color: THEME.textSecondary, lineHeight: 1.5 }}>
                The Suricata NIDS integration is currently disabled. Configure the
                Suricata EVE log path and enable it in your deployment configuration
                (<code style={{ fontSize: 11, color: ACCENT }}>docker-compose.yml</code>).
              </div>
            </div>
          </div>
        )}

        {/* Connection Error Banner */}
        {!suricataDisabled && effectiveStatus !== 'connected' && (
          <div style={{
            padding: '8px 14px',
            fontSize: 12,
            color: effectiveStatus === 'reconnecting' ? THEME.warning : '#F87171',
            backgroundColor: effectiveStatus === 'reconnecting' ? 'rgba(220,106,19,0.10)' : 'rgba(248,113,113,0.08)',
            borderRadius: 6,
            marginBottom: 10,
            display: 'flex',
            alignItems: 'center',
            gap: 6,
          }}>
            <EuiIcon type="warning" size="s" color={effectiveStatus === 'reconnecting' ? THEME.warning : '#F87171'} />
            {effectiveStatus === 'reconnecting' ? 'Reconnecting to server...' : 'Server disconnected'}
          </div>
        )}

        <div style={{ display: 'flex', gap: 8, alignItems: 'flex-end' }}>
          <div style={{ flex: 1, position: 'relative' }}>
            <textarea
              ref={inputRef}
              value={inputValue}
              onChange={handleInputChange}
              onKeyDown={handleKeyDown}
              placeholder={allDisabled
                ? 'Waiting for connection...'
                : 'Ask about network intrusion data... (Enter to send)'}
              aria-label="NIDS intelligence query"
              rows={1}
              disabled={allDisabled}
              style={{
                width: '100%',
                padding: '10px 14px',
                border: `1px solid ${THEME.border}`,
                borderRadius: 8,
                outline: 'none',
                backgroundColor: 'rgba(255,255,255,0.02)',
                color: THEME.text,
                fontSize: 13,
                fontFamily: FONT.base,
                resize: 'none',
                lineHeight: 1.5,
                maxHeight: 120,
                boxSizing: 'border-box',
              }}
            />
          </div>

          <QueryHistory
            history={queryHistory}
            onSelect={handleHistorySelect}
            onExecute={handleHistoryExecute}
            disabled={allDisabled}
          />

          <button
            onClick={isLoading ? cancelQuery : handleSend}
            disabled={!isLoading && (!inputValue.trim() || allDisabled)}
            aria-label={isLoading ? 'Cancel' : 'Send'}
            style={{
              padding: '10px 18px',
              borderRadius: 8,
              border: 'none',
              background: isLoading ? THEME.danger : ACCENT,
              color: '#fff',
              fontSize: 13,
              fontWeight: 600,
              cursor: (!isLoading && (!inputValue.trim() || allDisabled)) ? 'not-allowed' : 'pointer',
              opacity: (!isLoading && (!inputValue.trim() || allDisabled)) ? 0.5 : 1,
              display: 'flex',
              alignItems: 'center',
              gap: 6,
              transition: 'opacity 0.15s',
              flexShrink: 0,
              outline: 'none',
            }}
          >
            {isLoading ? (
              <span style={{
                display: 'inline-block', width: 14, height: 14,
                border: '2px solid rgba(255,255,255,0.3)', borderTopColor: '#fff',
                borderRadius: '50%', animation: 'pallas-spin 0.6s linear infinite',
              }} />
            ) : (
              <EuiIcon type="returnKey" size="s" color="#fff" />
            )}
            {isLoading ? 'Cancel' : 'Send'}
          </button>
        </div>
      </div>

      {/* Main Content */}
      <div style={{ flex: 1, overflow: 'auto', padding: '16px 20px' }} className="pallas-scrollbar">

        {/* Quick Actions */}
        <SectionHeader icon="bolt" title="Quick Actions" accent={ACCENT} />
        <div style={{ display: 'flex', flexWrap: 'wrap', gap: 6, marginBottom: 16 }}>
          {NIDS_QUICK_ACTIONS.map((action, idx) => {
            const isParamActive = activeParamChip === idx;

            return (
              <div key={action.label} style={{ display: 'flex', alignItems: 'center', gap: 0 }}>
                <ActionChip
                  icon={action.icon}
                  label={action.label}
                  onClick={() => handleChipClick(action, idx)}
                  disabled={allDisabled}
                  accent={ACCENT}
                />

                {/* Inline param input */}
                {isParamActive && (
                  <div style={{
                    display: 'flex',
                    alignItems: 'center',
                    border: `1px solid ${ACCENT}33`,
                    borderLeft: 'none',
                    borderRadius: '0 16px 16px 0',
                    backgroundColor: `${ACCENT}0F`,
                    overflow: 'hidden',
                  }}>
                    <input
                      autoFocus
                      type="text"
                      value={chipParams[action.paramKey] || ''}
                      onChange={(e) => setChipParams(prev => ({
                        ...prev,
                        [action.paramKey]: e.target.value,
                      }))}
                      onKeyDown={(e) => handleParamKeyDown(e, action)}
                      placeholder={action.paramPlaceholder || ''}
                      style={{
                        width: 200,
                        padding: '6px 10px',
                        border: 'none',
                        outline: 'none',
                        backgroundColor: 'transparent',
                        color: THEME.text,
                        fontSize: 12,
                        fontFamily: FONT.base,
                      }}
                    />
                    <button
                      onClick={() => {
                        const val = (chipParams[action.paramKey] || '').trim();
                        if (!val) return;
                        sendQuery(action.query.replace(`{${action.paramKey}}`, val));
                        setActiveParamChip(null);
                        setChipParams({});
                      }}
                      disabled={!(chipParams[action.paramKey] || '').trim()}
                      aria-label="Execute search"
                      style={{
                        padding: '4px 10px', border: 'none', backgroundColor: 'transparent',
                        color: (chipParams[action.paramKey] || '').trim() ? ACCENT : THEME.textMuted,
                        cursor: (chipParams[action.paramKey] || '').trim() ? 'pointer' : 'not-allowed',
                        fontSize: 12, fontFamily: FONT.base, fontWeight: 600,
                      }}
                    >
                      <EuiIcon type="returnKey" size="s" />
                    </button>
                    <button
                      onClick={() => { setActiveParamChip(null); setChipParams({}); }}
                      aria-label="Cancel"
                      style={{
                        padding: '4px 8px', border: 'none', backgroundColor: 'transparent',
                        color: THEME.textMuted, cursor: 'pointer', fontSize: 12,
                      }}
                    >
                      <EuiIcon type="cross" size="s" />
                    </button>
                  </div>
                )}
              </div>
            );
          })}
        </div>

        {/* Browse Strategies */}
        <div style={{ marginBottom: 16 }}>
          <ActionChip
            icon={showStrategies ? 'arrowUp' : 'list'}
            label={showStrategies ? 'Hide Strategies' : 'Browse All Strategies'}
            onClick={() => setShowStrategies(!showStrategies)}
            active={showStrategies}
            accent={ACCENT}
          />
          {showStrategies && (
            <div style={{ marginTop: 10 }}>
              <StrategyPanel
                categories={NIDS_PANEL_STRATEGIES}
                onExecute={handleStrategyExecute}
                disabled={allDisabled}
                isLoading={isLoading}
                defaultExpandedIndex={0}
                storageKey="nids"
              />
            </div>
          )}
        </div>

        {/* Pinned Results */}
        {pinnedResponses.length > 0 && (
          <div style={{ marginBottom: 16 }}>
            <div
              onClick={() => setPinnedCollapsed(!pinnedCollapsed)}
              style={{
                display: 'flex', alignItems: 'center', gap: 8, padding: '8px 12px',
                border: `1px solid ${THEME.border}`, borderRadius: 6,
                backgroundColor: 'rgba(255,255,255,0.02)', cursor: 'pointer', marginBottom: 8,
              }}
            >
              <EuiIcon type="pinFilled" size="s" color={ACCENT} />
              <span style={{ fontSize: 12, fontWeight: 600, color: THEME.textSecondary }}>
                Pinned Results ({pinnedResponses.length})
              </span>

              <span
                role="button"
                tabIndex={0}
                onClick={handleExportPinned}
                onKeyDown={(e) => { if (e.key === 'Enter') handleExportPinned(e); }}
                aria-label="Export all pinned"
                style={{
                  marginLeft: 'auto', marginRight: 8, padding: '2px 8px', borderRadius: 4,
                  fontSize: 11, fontWeight: 500, color: THEME.textMuted, cursor: 'pointer',
                }}
              >
                <EuiIcon type="download" size="s" /> Export
              </span>

              {pinnedResponses.length >= 2 && (
                <span
                  role="button"
                  tabIndex={0}
                  onClick={(e) => { e.stopPropagation(); setComparing(!comparing); }}
                  onKeyDown={(e) => { if (e.key === 'Enter') { e.stopPropagation(); setComparing(!comparing); } }}
                  aria-label="Compare pinned"
                  style={{
                    padding: '2px 8px', borderRadius: 4, fontSize: 11, fontWeight: 500,
                    color: comparing ? ACCENT : THEME.textMuted, cursor: 'pointer',
                  }}
                >
                  <EuiIcon type="merge" size="s" /> Compare
                </span>
              )}

              <EuiIcon type={pinnedCollapsed ? 'arrowDown' : 'arrowUp'} size="s" color={THEME.textMuted} />
            </div>

            {!pinnedCollapsed && (
              <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
                {comparing && pinnedResponses.length >= 2 && (
                  <ComparePanel
                    pinnedResponses={pinnedResponses}
                    onClose={() => setComparing(false)}
                    accent={ACCENT}
                  />
                )}

                {pinnedResponses.map((pinned, idx) => (
                  <div key={idx} style={{
                    padding: '10px 14px', borderRadius: 8,
                    border: `1px solid ${THEME.border}`, backgroundColor: 'rgba(255,255,255,0.02)',
                  }}>
                    <div style={{
                      display: 'flex', justifyContent: 'space-between', alignItems: 'center',
                      marginBottom: expandedPinIndex === idx ? 8 : 0,
                    }}>
                      <div style={{ flex: 1, minWidth: 0 }}>
                        <div style={{ fontSize: 12, color: THEME.text, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                          {pinned.metadata?.strategy ? pinned.metadata.strategy.replace(/_/g, ' ') : 'Query result'}
                        </div>
                        <div style={{ fontSize: 10, color: THEME.textMuted, marginTop: 2 }}>
                          {new Date(pinned.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                          {pinned.metadata?.execution_time_ms && ` \u00B7 ${(pinned.metadata.execution_time_ms / 1000).toFixed(1)}s`}
                        </div>
                      </div>
                      <div style={{ display: 'flex', gap: 4, flexShrink: 0 }}>
                        <button
                          onClick={() => setExpandedPinIndex(expandedPinIndex === idx ? null : idx)}
                          aria-label={expandedPinIndex === idx ? 'Collapse' : 'Expand'}
                          style={{ padding: 4, border: 'none', background: 'transparent', cursor: 'pointer', display: 'flex', alignItems: 'center' }}
                        >
                          <EuiIcon type={expandedPinIndex === idx ? 'arrowUp' : 'arrowDown'} size="s" color={THEME.textMuted} />
                        </button>
                        <button
                          onClick={() => unpinResponse(idx)}
                          aria-label="Unpin"
                          style={{ padding: 4, border: 'none', background: 'transparent', cursor: 'pointer', display: 'flex', alignItems: 'center' }}
                        >
                          <EuiIcon type="cross" size="s" color={THEME.textMuted} />
                        </button>
                      </div>
                    </div>

                    {expandedPinIndex === idx && (
                      <ResponsePanel
                        content={pinned.content}
                        metadata={pinned.metadata}
                        socAnalysis={pinned.socAnalysis}
                        suggestions={pinned.suggestions}
                        onSuggestionClick={handleSuggestionClick}
                        accent={ACCENT}
                      />
                    )}
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {/* Response Area */}
        <div ref={responseRef}>
          {isLoading && !response ? (
            <ResponsePanel isLoading onCancel={cancelQuery} accent={ACCENT} />
          ) : response ? (
            <ResponsePanel
              content={response.content}
              metadata={response.metadata}
              socAnalysis={response.socAnalysis}
              suggestions={response.suggestions}
              isLoading={isLoading}
              onCancel={isLoading ? cancelQuery : undefined}
              onSuggestionClick={handleSuggestionClick}
              onPin={() => pinResponse(response)}
              isPinned={pinnedResponses.some(
                (p) => p.content === response.content && p.timestamp === response.timestamp
              )}
              accent={ACCENT}
            />
          ) : (
            <EmptyState
              icon="globe"
              title="NIDS Intelligence"
              description="Query Suricata alerts, analyze network traffic, investigate signatures, and detect intrusions. Select a quick action or type a query above."
              accent={ACCENT}
            />
          )}
        </div>
      </div>
    </div>
  );
}
