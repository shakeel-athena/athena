/**
 * PallasDetectIOC — IOC Reputation & IP Investigation plugin
 *
 * Redesigned with shared PallasUI components and IOC accent color (#EF4444).
 * Two-tab interface: IOC Reputation (WebSocket) + IP Investigation (REST).
 */

import React, { useState, useCallback, useEffect } from 'react';
import { EuiIcon } from '@elastic/eui';
import { THEME } from '../../utils/theme';
import { MODULE_COLORS, ModuleHeader, ActionChip, GlassCard, FONT } from './PallasUI';
import { usePallas } from '../../hooks/usePallas';
import { ResponsePanel } from './PallasResponsePanel';
import { pallasPost } from '../../services/pallasService';

const ACCENT = MODULE_COLORS.ioc.accent;

// ─── Indicator type definitions ──────────────────────────────────────────────

const INDICATOR_TYPES = [
  { key: 'ip', label: 'IP Address', icon: 'globe', placeholder: 'e.g. 192.168.1.100' },
  { key: 'hash', label: 'File Hash', icon: 'document', placeholder: 'e.g. d41d8cd98f00b204e9800998ecf8427e' },
  { key: 'domain', label: 'Domain', icon: 'globe', placeholder: 'e.g. malware-c2.example.com' },
  { key: 'username', label: 'Username', icon: 'user', placeholder: 'e.g. jdoe' },
];

const TIME_RANGES = ['1h', '6h', '24h', '7d', '30d'];

// ─── Query builder ──────────────────────────────────────────────────────────

function buildIOCQuery(type, value) {
  const map = {
    ip: `check ioc reputation for IP ${value}`,
    hash: `check ioc reputation for hash ${value}`,
    domain: `check ioc reputation for domain ${value}`,
    username: `analyze security threat for user ${value}`,
  };
  return map[type] || `check ioc reputation for ${value}`;
}

// ─── IP Result Card ─────────────────────────────────────────────────────────

const IP_CARD_CONFIG = [
  { key: 'wazuh_alerts', label: 'Wazuh Alerts', color: '#4493F8' },
  { key: 'wazuh_vulnerabilities', label: 'Wazuh Vulnerabilities', color: '#F0B429' },
  { key: 'suricata_alerts', label: 'Suricata Alerts', color: '#FF8C42' },
];

function IPResultCard({ label, count, index, borderColor }) {
  return (
    <GlassCard style={{
      borderTop: `3px solid ${borderColor}`,
      padding: 16,
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'center',
      gap: 6,
    }}>
      <div style={{
        fontSize: 28, fontWeight: 700, fontFamily: FONT.mono, color: THEME.text,
      }}>
        {typeof count === 'number' ? count.toLocaleString() : '\u2014'}
      </div>
      <div style={{ fontSize: 12, color: THEME.textSecondary, fontWeight: 500 }}>{label}</div>
      {index && (
        <div style={{ fontSize: 10, color: THEME.textMuted, fontFamily: FONT.mono, marginTop: 2 }}>
          {index}
        </div>
      )}
    </GlassCard>
  );
}

// ─── Main Component ─────────────────────────────────────────────────────────

export default function PallasDetectIOC({ connectionStatus, onConnectionStatusChange, onQueryComplete }) {
  const [activeTab, setActiveTab] = useState('ioc');

  // IOC Reputation tab state
  const [indicator, setIndicator] = useState('');
  const [indicatorType, setIndicatorType] = useState('ip');
  const {
    response,
    isLoading,
    connectionStatus: wsStatus,
    sendQuery,
    cancelQuery,
    pinnedResponses,
    pinResponse,
    unpinResponse,
  } = usePallas('ioc', { onQueryComplete });

  // Bubble WS status up to parent
  useEffect(() => {
    if (onConnectionStatusChange) onConnectionStatusChange(wsStatus);
  }, [wsStatus, onConnectionStatusChange]);

  // IP Investigation tab state
  const [ipValue, setIpValue] = useState('');
  const [ipTimeRange, setIpTimeRange] = useState('24h');
  const [ipLoading, setIpLoading] = useState(false);
  const [ipResult, setIpResult] = useState(null);
  const [ipError, setIpError] = useState(null);

  // IOC handlers
  const handleIOCSearch = useCallback(() => {
    const trimmed = indicator.trim();
    if (!trimmed || isLoading) return;
    sendQuery(buildIOCQuery(indicatorType, trimmed));
  }, [indicator, indicatorType, isLoading, sendQuery]);

  const handleIOCKeyDown = useCallback((e) => {
    if (e.key === 'Enter') handleIOCSearch();
  }, [handleIOCSearch]);

  // IP Investigation handler
  const handleIPInvestigate = useCallback(async () => {
    const trimmed = ipValue.trim();
    if (!trimmed) return;
    setIpLoading(true);
    setIpResult(null);
    setIpError(null);
    try {
      const data = await pallasPost('/api/ip/investigate', { ip: trimmed, time_range: ipTimeRange });
      setIpResult(data);
      if (onQueryComplete) onQueryComplete('ioc', `IP investigate: ${trimmed}`, data.duration_ms);
    } catch (e) {
      setIpError(e.message || 'Failed to investigate IP');
    } finally {
      setIpLoading(false);
    }
  }, [ipValue, ipTimeRange, onQueryComplete]);

  const handleIPKeyDown = useCallback((e) => {
    if (e.key === 'Enter') handleIPInvestigate();
  }, [handleIPInvestigate]);

  const currentType = INDICATOR_TYPES.find((t) => t.key === indicatorType) || INDICATOR_TYPES[0];

  const tabs = [
    { key: 'ioc', label: 'IOC Reputation', icon: 'shield' },
    { key: 'ip', label: 'IP Investigation', icon: 'compute' },
  ];

  return (
    <div style={{ display: 'flex', flexDirection: 'column', height: '100%', fontFamily: FONT.base }}>
      {/* Module Header */}
      <ModuleHeader
        icon="search"
        title="Detect IOC"
        description="IOC reputation analysis and cross-index IP investigation"
        accent={ACCENT}
        connectionStatus={wsStatus === 'connected' ? 'connected' : connectionStatus}
      />

      {/* Tab bar */}
      <div style={{ display: 'flex', borderBottom: `1px solid ${THEME.border}`, flexShrink: 0 }}>
        {tabs.map((tab) => {
          const isActive = activeTab === tab.key;
          return (
            <button
              key={tab.key}
              onClick={() => setActiveTab(tab.key)}
              style={{
                flex: 1, padding: '10px 0', background: 'transparent', border: 'none',
                borderBottom: isActive ? `2px solid ${ACCENT}` : '2px solid transparent',
                color: isActive ? THEME.text : THEME.textSecondary,
                fontSize: 13, fontWeight: isActive ? 600 : 400, cursor: 'pointer',
                display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 6,
                transition: 'all 0.15s', outline: 'none',
              }}
            >
              <EuiIcon type={tab.icon} size="s" color={isActive ? ACCENT : THEME.textSecondary} />
              {tab.label}
            </button>
          );
        })}
      </div>

      {/* Tab content */}
      <div style={{ flex: 1, overflowY: 'auto', padding: '16px 20px' }} className="pallas-scrollbar">
        {activeTab === 'ioc' && (
          <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
            {/* Indicator type selector */}
            <div>
              <div style={{ fontSize: 11, color: THEME.textSecondary, marginBottom: 6, fontWeight: 500 }}>
                Indicator Type
              </div>
              <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap' }}>
                {INDICATOR_TYPES.map((type) => (
                  <ActionChip
                    key={type.key}
                    icon={type.icon}
                    label={type.label}
                    onClick={() => setIndicatorType(type.key)}
                    active={indicatorType === type.key}
                    accent={ACCENT}
                  />
                ))}
              </div>
            </div>

            {/* Indicator value input */}
            <div>
              <div style={{ fontSize: 11, color: THEME.textSecondary, marginBottom: 6, fontWeight: 500 }}>
                Indicator Value
              </div>
              <input
                type="text"
                value={indicator}
                onChange={(e) => setIndicator(e.target.value)}
                onKeyDown={handleIOCKeyDown}
                placeholder={currentType.placeholder}
                style={{
                  width: '100%', padding: '10px 14px', background: 'rgba(255,255,255,0.02)',
                  border: `1px solid ${THEME.border}`, borderRadius: 8, color: THEME.text,
                  fontSize: 13, outline: 'none', fontFamily: FONT.base, boxSizing: 'border-box',
                }}
              />
            </div>

            {/* Search button */}
            <div style={{ display: 'flex', gap: 8 }}>
              <button
                onClick={handleIOCSearch}
                disabled={!indicator.trim() || isLoading}
                style={{
                  padding: '10px 20px', border: 'none', borderRadius: 8,
                  background: (!indicator.trim() || isLoading) ? THEME.border : ACCENT,
                  color: '#fff', fontWeight: 600, fontSize: 13,
                  cursor: (!indicator.trim() || isLoading) ? 'not-allowed' : 'pointer',
                  opacity: (!indicator.trim() || isLoading) ? 0.5 : 1,
                  display: 'flex', alignItems: 'center', gap: 6, outline: 'none',
                }}
              >
                {isLoading ? (
                  <span style={{
                    display: 'inline-block', width: 14, height: 14,
                    border: '2px solid rgba(255,255,255,0.3)', borderTopColor: '#fff',
                    borderRadius: '50%', animation: 'pallas-spin 0.6s linear infinite',
                  }} />
                ) : (
                  <EuiIcon type="search" size="s" color="#fff" />
                )}
                {isLoading ? 'Searching...' : 'Search IOC'}
              </button>
              {isLoading && (
                <button
                  onClick={cancelQuery}
                  style={{
                    padding: '10px 16px', border: `1px solid ${THEME.border}`, borderRadius: 8,
                    background: 'transparent', color: THEME.textSecondary, fontSize: 13, cursor: 'pointer',
                    outline: 'none',
                  }}
                >
                  Cancel
                </button>
              )}
            </div>

            {/* Response */}
            {(response || isLoading) && (
              <div style={{ marginTop: 8 }}>
                <ResponsePanel
                  content={response?.content}
                  metadata={response?.metadata}
                  socAnalysis={response?.socAnalysis}
                  suggestions={response?.suggestions}
                  isLoading={isLoading}
                  onCancel={isLoading ? cancelQuery : undefined}
                  onPin={response ? () => pinResponse(response) : undefined}
                  isPinned={response ? pinnedResponses.some(
                    (p) => p.content === response.content && p.timestamp === response.timestamp
                  ) : false}
                  accent={ACCENT}
                />
              </div>
            )}
          </div>
        )}

        {activeTab === 'ip' && (
          <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
            {/* IP input */}
            <div>
              <div style={{ fontSize: 11, color: THEME.textSecondary, marginBottom: 6, fontWeight: 500 }}>
                IP Address
              </div>
              <input
                type="text"
                value={ipValue}
                onChange={(e) => setIpValue(e.target.value)}
                onKeyDown={handleIPKeyDown}
                placeholder="e.g. 10.0.0.50"
                style={{
                  width: '100%', padding: '10px 14px', background: 'rgba(255,255,255,0.02)',
                  border: `1px solid ${THEME.border}`, borderRadius: 8, color: THEME.text,
                  fontSize: 13, outline: 'none', fontFamily: FONT.mono, boxSizing: 'border-box',
                }}
              />
            </div>

            {/* Time range */}
            <div>
              <div style={{ fontSize: 11, color: THEME.textSecondary, marginBottom: 6, fontWeight: 500 }}>
                Time Range
              </div>
              <div style={{ display: 'flex', gap: 6 }}>
                {TIME_RANGES.map((range) => (
                  <ActionChip
                    key={range}
                    label={range}
                    onClick={() => setIpTimeRange(range)}
                    active={ipTimeRange === range}
                    accent={ACCENT}
                  />
                ))}
              </div>
            </div>

            {/* Investigate button */}
            <div>
              <button
                onClick={handleIPInvestigate}
                disabled={!ipValue.trim() || ipLoading}
                style={{
                  padding: '10px 20px', border: 'none', borderRadius: 8,
                  background: (!ipValue.trim() || ipLoading) ? THEME.border : ACCENT,
                  color: '#fff', fontWeight: 600, fontSize: 13,
                  cursor: (!ipValue.trim() || ipLoading) ? 'not-allowed' : 'pointer',
                  opacity: (!ipValue.trim() || ipLoading) ? 0.5 : 1,
                  display: 'flex', alignItems: 'center', gap: 6, outline: 'none',
                }}
              >
                {ipLoading ? (
                  <span style={{
                    display: 'inline-block', width: 14, height: 14,
                    border: '2px solid rgba(255,255,255,0.3)', borderTopColor: '#fff',
                    borderRadius: '50%', animation: 'pallas-spin 0.6s linear infinite',
                  }} />
                ) : (
                  <EuiIcon type="search" size="s" color="#fff" />
                )}
                {ipLoading ? 'Investigating...' : 'Investigate IP'}
              </button>
            </div>

            {/* Loading */}
            {ipLoading && (
              <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 10, padding: 24 }}>
                <span style={{
                  display: 'inline-block', width: 24, height: 24,
                  border: `3px solid ${THEME.border}`, borderTopColor: ACCENT,
                  borderRadius: '50%', animation: 'pallas-spin 0.6s linear infinite',
                }} />
                <span style={{ fontSize: 12, color: THEME.textSecondary }}>Searching across all indexes...</span>
              </div>
            )}

            {/* Error */}
            {ipError && (
              <div style={{
                padding: '10px 14px', background: 'rgba(239,68,68,0.12)',
                border: '1px solid rgba(239,68,68,0.3)', borderRadius: 6, color: '#f87171', fontSize: 12,
                display: 'flex', alignItems: 'center', gap: 8,
              }}>
                <EuiIcon type="warning" size="s" color="#f87171" /> {ipError}
              </div>
            )}

            {/* Results */}
            {ipResult && !ipLoading && (
              <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
                {/* Total count */}
                <GlassCard style={{ textAlign: 'center', padding: '16px 0' }}>
                  <div style={{ fontSize: 36, fontWeight: 700, fontFamily: FONT.mono, color: ACCENT }}>
                    {typeof ipResult.total === 'number' ? ipResult.total.toLocaleString() : '\u2014'}
                  </div>
                  <div style={{ fontSize: 11, color: THEME.textSecondary, marginTop: 4 }}>Total Hits</div>
                </GlassCard>

                {/* 3-column cards */}
                <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 10 }}>
                  {IP_CARD_CONFIG.map((cfg) => {
                    const result = ipResult.results
                      ? ipResult.results.find((r) => r.key === cfg.key || r.label === cfg.label)
                      : null;
                    return (
                      <IPResultCard
                        key={cfg.key}
                        label={cfg.label}
                        count={result ? result.count : 0}
                        index={result ? result.index : null}
                        borderColor={cfg.color}
                      />
                    );
                  })}
                </div>

                {/* Duration */}
                {ipResult.duration_ms != null && (
                  <div style={{ fontSize: 10, color: THEME.textMuted, textAlign: 'right' }}>
                    Completed in {ipResult.duration_ms}ms
                  </div>
                )}
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
