/**
 * PallasStatusBar — Enhanced Bottom Bar
 *
 * Redesigned: Icons + color-coded labels instead of tiny dots.
 * Shows service count and version info.
 */

import React from 'react';
import { EuiIcon, EuiToolTip } from '@elastic/eui';
import { THEME } from '../../utils/theme';
import { FONT } from './PallasUI';

// ─── Tool Configuration ──────────────────────────────────────────────────────

const TOOLS = [
  { key: 'wazuh_manager', label: 'Wazuh',     icon: 'storage' },
  { key: 'wazuh_indexer',  label: 'Indexer',    icon: 'database' },
  { key: 'suricata',       label: 'Suricata',   icon: 'globe' },
  { key: 'ollama',         label: 'Ollama AI',  icon: 'machineLearningApp' },
];

function getStatusStyle(status) {
  switch (status) {
    case 'connected':
      return { color: THEME.statusActive, bg: THEME.statusActive + '15', label: 'Online' };
    case 'connecting':
      return { color: THEME.warning, bg: THEME.warning + '15', label: 'Connecting' };
    case 'disconnected':
    case 'error':
      return { color: THEME.danger, bg: THEME.danger + '15', label: 'Offline' };
    case 'disabled':
    default:
      return { color: THEME.textMuted, bg: 'transparent', label: 'Disabled' };
  }
}

// ─── ToolIndicator ───────────────────────────────────────────────────────────

function ToolIndicator({ tool, status }) {
  const s = getStatusStyle(status);

  return (
    <EuiToolTip position="top" content={`${tool.label}: ${s.label}`}>
      <div style={{
        display: 'flex',
        alignItems: 'center',
        gap: 4,
        padding: '1px 6px',
        borderRadius: 4,
        background: s.bg,
        cursor: 'default',
        transition: 'all 0.15s ease',
      }}>
        <EuiIcon type={tool.icon} size="s" color={s.color} style={{ width: 10, height: 10 }} />
        <span style={{
          fontSize: 10,
          fontWeight: 500,
          color: s.color,
          whiteSpace: 'nowrap',
        }}>
          {tool.label}
        </span>
        <span style={{
          width: 5,
          height: 5,
          borderRadius: '50%',
          backgroundColor: s.color,
          boxShadow: status === 'connected' ? `0 0 4px ${s.color}` : 'none',
          flexShrink: 0,
        }} />
      </div>
    </EuiToolTip>
  );
}

// ─── PallasStatusBar ─────────────────────────────────────────────────────────

export function PallasStatusBar({ toolHealth = {} }) {
  const connectedCount = TOOLS.filter(t => toolHealth[t.key] === 'connected').length;

  return (
    <div style={{
      height: 26,
      display: 'flex',
      flexDirection: 'row',
      alignItems: 'center',
      justifyContent: 'space-between',
      padding: '0 12px',
      background: THEME.bgDeep,
      borderTop: `1px solid ${THEME.border}`,
      flexShrink: 0,
    }}>
      {/* LEFT: Tool indicators */}
      <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
        {TOOLS.map(tool => (
          <ToolIndicator
            key={tool.key}
            tool={tool}
            status={toolHealth[tool.key] || 'disabled'}
          />
        ))}
      </div>

      {/* RIGHT: Summary + version */}
      <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
        <span style={{
          fontSize: 10,
          color: connectedCount > 0 ? THEME.textSecondary : THEME.textMuted,
          fontFamily: FONT.mono,
        }}>
          {connectedCount}/{TOOLS.length} services
        </span>
        <span style={{
          fontSize: 10,
          color: THEME.textFaint,
          fontFamily: FONT.mono,
        }}>
          Pallas v4.0
        </span>
      </div>
    </div>
  );
}

export default PallasStatusBar;
