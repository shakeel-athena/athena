/**
 * PallasStrategyPanel — Accordion-style categorized strategy selector
 *
 * Port of the Pallas plugin's strategy-panel.tsx (TypeScript → JavaScript).
 * Uses Athena's unified THEME from ThreatLandscape for all color tokens.
 *
 * Features:
 *   - Search across all strategies (shown when totalStrategies > 10)
 *   - Recently-used strategy pills (localStorage, MAX_RECENT = 4)
 *   - Category accordion with expand/collapse
 *   - Inline param inputs for parameterized strategies
 *   - Arrow Up/Down keyboard navigation between strategy buttons
 */

import React, {
  useState,
  useRef,
  useCallback,
  useEffect,
  useMemo,
} from 'react';
import { EuiIcon, EuiLoadingSpinner } from '@elastic/eui';
import { THEME } from '../../utils/theme';

// ─── Constants ────────────────────────────────────────────────────────────────

const MAX_RECENT = 4;
const FONT_BASE = 'Inter, -apple-system, BlinkMacSystemFont, sans-serif';
const FONT_CODE = 'SFMono-Regular, Menlo, Monaco, Consolas, monospace'; // eslint-disable-line no-unused-vars
const DURATION_FAST = '0.15s';

const HOVER_SUBTLE    = 'rgba(22, 197, 192, 0.06)';
const HOVER_ACTIVE    = 'rgba(22, 197, 192, 0.08)';
const HOVER_STRONG    = 'rgba(22, 197, 192, 0.12)';

// ─── Keyframe styles (injected once) ─────────────────────────────────────────

const PANEL_STYLES = `
  @keyframes pallas-fadeIn {
    from { opacity: 0; transform: translateY(-4px); }
    to   { opacity: 1; transform: translateY(0); }
  }
`;

// ─── localStorage helpers ─────────────────────────────────────────────────────

function storageKey(key) {
  return `pallas-recent-${key}`;
}

function loadRecent(key) {
  try {
    const raw = localStorage.getItem(storageKey(key));
    if (!raw) return [];
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? parsed : [];
  } catch {
    return [];
  }
}

function saveRecent(key, labels) {
  try {
    localStorage.setItem(storageKey(key), JSON.stringify(labels));
  } catch {
    // localStorage unavailable — silent failure
  }
}

function trackUsage(key, label) {
  const current = loadRecent(key);
  const filtered = current.filter(l => l !== label);
  const next = [label, ...filtered].slice(0, MAX_RECENT);
  saveRecent(key, next);
  return next;
}

// ─── substituteParams ─────────────────────────────────────────────────────────

/**
 * Replaces `{key}` placeholders in a query string with provided values.
 * @param {string} query
 * @param {Object} values  — e.g. { ip: '1.2.3.4', port: '443' }
 * @returns {string}
 */
export function substituteParams(query, values) {
  if (!values || typeof query !== 'string') return query;
  return query.replace(/\{(\w+)\}/g, (match, k) =>
    Object.prototype.hasOwnProperty.call(values, k) ? values[k] : match
  );
}

// ─── ParamInput ───────────────────────────────────────────────────────────────

function ParamInput({ strategy, onRun, onCancel, isDark }) { // eslint-disable-line no-unused-vars
  const [values, setValues] = useState(() => {
    const init = {};
    (strategy.params || []).forEach(p => { init[p.key] = ''; });
    return init;
  });
  const firstRef = useRef(null);

  useEffect(() => {
    if (firstRef.current) firstRef.current.focus();
  }, []);

  const allFilled = useMemo(
    () => (strategy.params || []).every(p => (values[p.key] || '').trim() !== ''),
    [values, strategy.params]
  );

  const handleRun = useCallback(() => {
    if (!allFilled) return;
    const filled = {};
    (strategy.params || []).forEach(p => { filled[p.key] = values[p.key].trim(); });
    onRun(substituteParams(strategy.query, filled));
  }, [allFilled, values, strategy, onRun]);

  const handleKeyDown = useCallback((e) => {
    if (e.key === 'Enter' && allFilled) {
      e.preventDefault();
      e.stopPropagation();
      handleRun();
    }
    if (e.key === 'Escape') {
      e.preventDefault();
      e.stopPropagation();
      onCancel();
    }
  }, [allFilled, handleRun, onCancel]);

  return (
    <div
      style={{
        animation: `pallas-fadeIn ${DURATION_FAST} ease`,
        marginTop: 6,
        padding: '10px 12px',
        backgroundColor: HOVER_ACTIVE,
        border: `1px solid rgba(22, 197, 192, 0.2)`,
        borderRadius: 6,
      }}
    >
      {(strategy.params || []).map((param, idx) => (
        <div key={param.key} style={{ marginBottom: idx < strategy.params.length - 1 ? 8 : 0 }}>
          <label style={{
            display: 'block',
            fontSize: 10,
            fontWeight: 600,
            color: THEME.textSecondary,
            textTransform: 'uppercase',
            letterSpacing: '0.4px',
            marginBottom: 4,
            fontFamily: FONT_BASE,
          }}>
            {param.label}
          </label>
          <input
            ref={idx === 0 ? firstRef : null}
            type="text"
            placeholder={param.placeholder || ''}
            value={values[param.key] || ''}
            onChange={e => setValues(prev => ({ ...prev, [param.key]: e.target.value }))}
            onKeyDown={handleKeyDown}
            style={{
              width: '100%',
              padding: '5px 9px',
              backgroundColor: THEME.bg,
              border: `1px solid ${THEME.border}`,
              borderRadius: 5,
              color: THEME.text,
              fontSize: 12,
              fontFamily: FONT_BASE,
              outline: 'none',
              boxSizing: 'border-box',
              transition: `border-color ${DURATION_FAST}`,
            }}
            onFocus={e => {
              e.target.style.borderColor = THEME.accent;
              e.target.style.boxShadow = `0 0 0 1px ${THEME.accent}`;
            }}
            onBlur={e => {
              e.target.style.borderColor = THEME.border;
              e.target.style.boxShadow = 'none';
            }}
          />
        </div>
      ))}

      <div style={{ display: 'flex', gap: 6, marginTop: 10, justifyContent: 'flex-end' }}>
        <button
          onClick={onCancel}
          style={{
            padding: '4px 10px',
            fontSize: 11,
            fontWeight: 500,
            fontFamily: FONT_BASE,
            backgroundColor: 'transparent',
            border: `1px solid ${THEME.border}`,
            borderRadius: 5,
            color: THEME.textSecondary,
            cursor: 'pointer',
            transition: `all ${DURATION_FAST}`,
          }}
          onMouseEnter={e => {
            e.currentTarget.style.borderColor = THEME.borderLight;
            e.currentTarget.style.color = THEME.text;
          }}
          onMouseLeave={e => {
            e.currentTarget.style.borderColor = THEME.border;
            e.currentTarget.style.color = THEME.textSecondary;
          }}
        >
          Cancel
        </button>
        <button
          onClick={handleRun}
          disabled={!allFilled}
          style={{
            padding: '4px 12px',
            fontSize: 11,
            fontWeight: 600,
            fontFamily: FONT_BASE,
            background: allFilled
              ? `linear-gradient(135deg, ${THEME.accent}, #0ea5a0)`
              : THEME.card,
            border: `1px solid ${allFilled ? THEME.accent : THEME.border}`,
            borderRadius: 5,
            color: allFilled ? '#ffffff' : THEME.textMuted,
            cursor: allFilled ? 'pointer' : 'not-allowed',
            transition: `all ${DURATION_FAST}`,
          }}
          onMouseEnter={e => {
            if (allFilled) e.currentTarget.style.opacity = '0.9';
          }}
          onMouseLeave={e => {
            e.currentTarget.style.opacity = '1';
          }}
        >
          Run
        </button>
      </div>
    </div>
  );
}

// ─── StrategyButton ───────────────────────────────────────────────────────────

function StrategyButton({
  strategy,
  onExecute,
  disabled,
  isLoading,
  isExpanded,
  onToggleParams,
  onParamRun,
  onParamCancel,
  btnRef,
  isDark,
}) {
  const hasParams = strategy.params && strategy.params.length > 0;
  const [hovered, setHovered] = useState(false);

  const handleClick = useCallback(() => {
    if (disabled) return;
    if (hasParams) {
      onToggleParams();
    } else {
      onExecute(strategy.query);
    }
  }, [disabled, hasParams, onToggleParams, onExecute, strategy.query]);

  const handleKeyDown = useCallback((e) => {
    if (e.key === 'Enter' || e.key === ' ') {
      e.preventDefault();
      handleClick();
    }
    // Arrow navigation is handled at the panel level
  }, [handleClick]);

  const bgColor = isExpanded
    ? HOVER_STRONG
    : hovered
    ? HOVER_SUBTLE
    : 'transparent';

  const leftBorderColor = (hovered || isExpanded) ? THEME.accent : 'transparent';

  return (
    <div style={{ marginBottom: 2 }}>
      <button
        ref={btnRef}
        data-strategy-btn="true"
        onClick={handleClick}
        onKeyDown={handleKeyDown}
        disabled={disabled}
        style={{
          width: '100%',
          display: 'flex',
          alignItems: 'flex-start',
          gap: 8,
          padding: '7px 10px 7px 10px',
          border: 'none',
          borderLeft: `2px solid ${leftBorderColor}`,
          backgroundColor: bgColor,
          borderRadius: 5,
          cursor: disabled ? 'not-allowed' : 'pointer',
          opacity: disabled ? 0.5 : 1,
          transition: `background-color ${DURATION_FAST}, border-left-color ${DURATION_FAST}`,
          textAlign: 'left',
          outline: 'none',
        }}
        onMouseEnter={() => setHovered(true)}
        onMouseLeave={() => setHovered(false)}
        onFocus={() => setHovered(true)}
        onBlur={() => setHovered(false)}
      >
        {/* Optional strategy icon */}
        {strategy.icon && (
          <div style={{ marginTop: 1, flexShrink: 0 }}>
            <EuiIcon type={strategy.icon} size="s" color={THEME.textSecondary} />
          </div>
        )}

        {/* Label + description column */}
        <div style={{ flex: 1, minWidth: 0 }}>
          {/* Label row */}
          <div style={{ display: 'flex', alignItems: 'center', gap: 5, flexWrap: 'wrap' }}>
            <span style={{
              fontSize: 13,
              fontWeight: 500,
              color: THEME.text,
              fontFamily: FONT_BASE,
              lineHeight: 1.3,
            }}>
              {strategy.label}
            </span>

            {/* Param badges */}
            {hasParams && strategy.params.map(p => (
              <span key={p.key} style={{
                fontSize: 10,
                fontWeight: 600,
                padding: '1px 6px',
                borderRadius: 3,
                backgroundColor: 'rgba(22, 197, 192, 0.15)',
                color: THEME.accent,
                fontFamily: FONT_BASE,
                letterSpacing: '0.3px',
                flexShrink: 0,
              }}>
                {p.key}
              </span>
            ))}
          </div>

          {/* Description */}
          {strategy.description && (
            <div style={{
              fontSize: 11,
              color: THEME.textMuted,
              marginTop: 2,
              fontFamily: FONT_BASE,
              lineHeight: 1.4,
            }}>
              {strategy.description}
            </div>
          )}
        </div>

        {/* Loading spinner (no-param strategies only) */}
        {isLoading && !hasParams && (
          <div style={{ flexShrink: 0, marginTop: 2 }}>
            <EuiLoadingSpinner size="s" />
          </div>
        )}
      </button>

      {/* Inline param input */}
      {isExpanded && hasParams && (
        <div style={{ paddingLeft: 12, paddingRight: 4 }}>
          <ParamInput
            strategy={strategy}
            onRun={onParamRun}
            onCancel={onParamCancel}
            isDark={isDark}
          />
        </div>
      )}
    </div>
  );
}

// ─── CategorySection ──────────────────────────────────────────────────────────

function CategorySection({
  category,
  isExpanded,
  onToggle,
  visibleStrategies,
  expandedStrategyLabel,
  onExecute,
  disabled,
  isLoading,
  onStrategyToggle,
  onParamRun,
  onParamCancel,
  strategyBtnRefs,
  isDark,
}) {
  if (visibleStrategies.length === 0) return null;

  return (
    <div style={{ marginBottom: 4 }}>
      {/* Category header */}
      <button
        onClick={onToggle}
        style={{
          width: '100%',
          display: 'flex',
          alignItems: 'center',
          gap: 6,
          padding: '7px 10px',
          border: 'none',
          backgroundColor: 'transparent',
          cursor: 'pointer',
          borderRadius: 5,
          transition: `background-color ${DURATION_FAST}`,
          outline: 'none',
        }}
        onMouseEnter={e => { e.currentTarget.style.backgroundColor = HOVER_SUBTLE; }}
        onMouseLeave={e => { e.currentTarget.style.backgroundColor = 'transparent'; }}
      >
        <EuiIcon type={category.icon || 'list'} size="s" color={THEME.textSecondary} />
        <span style={{
          flex: 1,
          textAlign: 'left',
          fontSize: 11,
          fontWeight: 600,
          color: THEME.textSecondary,
          textTransform: 'uppercase',
          letterSpacing: '0.5px',
          fontFamily: FONT_BASE,
        }}>
          {category.name}
        </span>

        {/* Count badge */}
        <span style={{
          fontSize: 10,
          fontWeight: 600,
          color: THEME.textMuted,
          backgroundColor: THEME.card,
          border: `1px solid ${THEME.border}`,
          borderRadius: 10,
          padding: '1px 6px',
          fontFamily: FONT_BASE,
          marginRight: 4,
        }}>
          {visibleStrategies.length}
        </span>

        <EuiIcon
          type={isExpanded ? 'arrowDown' : 'arrowRight'}
          size="s"
          color={THEME.textMuted}
        />
      </button>

      {/* Strategy list */}
      {isExpanded && (
        <div style={{ paddingLeft: 6, paddingRight: 2, paddingBottom: 4 }}>
          {visibleStrategies.map((strategy) => (
            <StrategyButton
              key={strategy.label}
              strategy={strategy}
              onExecute={onExecute}
              disabled={disabled}
              isLoading={isLoading}
              isExpanded={expandedStrategyLabel === strategy.label}
              onToggleParams={() => onStrategyToggle(strategy.label)}
              onParamRun={(query) => onParamRun(strategy.label, query)}
              onParamCancel={onParamCancel}
              btnRef={strategyBtnRefs ? el => { strategyBtnRefs.current[strategy.label] = el; } : undefined}
              isDark={isDark}
            />
          ))}
        </div>
      )}
    </div>
  );
}

// ─── StrategyPanel (main) ─────────────────────────────────────────────────────

/**
 * StrategyPanel
 *
 * @param {Object}   props
 * @param {Array}    props.categories           — [{ name, icon, strategies: [{ label, query, icon?, description?, params?: [...] }] }]
 * @param {Function} props.onExecute            — Called with the final query string
 * @param {boolean}  props.disabled             — Disables all interaction
 * @param {boolean}  [props.isLoading]          — Shows spinner on active no-param strategy
 * @param {number}   [props.defaultExpandedIndex=0] — Initially expanded category index
 * @param {string}   [props.storageKey]         — localStorage key for recently-used tracking
 * @param {boolean}  [props.isDark=true]        — Dark mode flag (reserved for future use)
 */
export function StrategyPanel({
  categories = [],
  onExecute,
  disabled = false,
  isLoading = false,
  defaultExpandedIndex = 0,
  storageKey: storageKeyProp,
  isDark = true,
}) {
  // ── Search ──────────────────────────────────────────────────────────────────
  const [searchQuery, setSearchQuery] = useState('');
  const searchRef = useRef(null);

  // ── Recently used ────────────────────────────────────────────────────────────
  const [recentLabels, setRecentLabels] = useState(() =>
    storageKeyProp ? loadRecent(storageKeyProp) : []
  );

  // ── Expanded categories ───────────────────────────────────────────────────────
  const [expandedCategories, setExpandedCategories] = useState(() => {
    const initial = {};
    categories.forEach((cat, idx) => {
      initial[cat.name] = idx === defaultExpandedIndex;
    });
    return initial;
  });

  // ── Expanded strategy (param input) ──────────────────────────────────────────
  const [expandedStrategyLabel, setExpandedStrategyLabel] = useState(null);

  // ── Strategy button refs for keyboard nav ────────────────────────────────────
  const strategyBtnRefs = useRef({});

  // ── Derived: all strategies flat map ─────────────────────────────────────────
  const allStrategies = useMemo(() => {
    const map = {};
    categories.forEach(cat => {
      cat.strategies.forEach(s => { map[s.label] = s; });
    });
    return map;
  }, [categories]);

  const totalStrategies = useMemo(
    () => categories.reduce((sum, cat) => sum + cat.strategies.length, 0),
    [categories]
  );

  const showSearch = totalStrategies > 10;

  // ── Filtered categories ───────────────────────────────────────────────────────
  const lowerSearch = searchQuery.toLowerCase().trim();

  const filteredCategories = useMemo(() => {
    if (!lowerSearch) return categories.map(cat => ({ ...cat, filtered: cat.strategies }));
    return categories.map(cat => ({
      ...cat,
      filtered: cat.strategies.filter(s =>
        s.label.toLowerCase().includes(lowerSearch) ||
        (s.description && s.description.toLowerCase().includes(lowerSearch))
      ),
    }));
  }, [categories, lowerSearch]);

  const totalMatches = useMemo(
    () => filteredCategories.reduce((sum, cat) => sum + cat.filtered.length, 0),
    [filteredCategories]
  );

  // Auto-expand all matching categories when searching
  useEffect(() => {
    if (!lowerSearch) return;
    const updates = {};
    filteredCategories.forEach(cat => {
      if (cat.filtered.length > 0) updates[cat.name] = true;
    });
    setExpandedCategories(prev => ({ ...prev, ...updates }));
  }, [lowerSearch]); // eslint-disable-line react-hooks/exhaustive-deps

  // ── Handlers ─────────────────────────────────────────────────────────────────

  const handleExecute = useCallback((query) => {
    if (disabled) return;
    // Find label for recent tracking
    const strategy = Object.values(allStrategies).find(s => s.query === query);
    if (strategy && storageKeyProp) {
      setRecentLabels(trackUsage(storageKeyProp, strategy.label));
    }
    setExpandedStrategyLabel(null);
    onExecute(query);
  }, [disabled, allStrategies, storageKeyProp, onExecute]);

  const handleStrategyToggle = useCallback((label) => {
    setExpandedStrategyLabel(prev => prev === label ? null : label);
  }, []);

  const handleParamRun = useCallback((label, query) => {
    if (storageKeyProp) {
      setRecentLabels(trackUsage(storageKeyProp, label));
    }
    setExpandedStrategyLabel(null);
    onExecute(query);
  }, [storageKeyProp, onExecute]);

  const handleParamCancel = useCallback(() => {
    setExpandedStrategyLabel(null);
  }, []);

  const handleCategoryToggle = useCallback((name) => {
    setExpandedCategories(prev => ({ ...prev, [name]: !prev[name] }));
  }, []);

  const handleRecentClick = useCallback((label) => {
    if (disabled) return;
    const strategy = allStrategies[label];
    if (!strategy) return;
    if (strategy.params && strategy.params.length > 0) {
      // Find which category and expand it, then toggle param input
      const cat = categories.find(c => c.strategies.some(s => s.label === label));
      if (cat) {
        setExpandedCategories(prev => ({ ...prev, [cat.name]: true }));
      }
      setExpandedStrategyLabel(label);
    } else {
      handleExecute(strategy.query);
    }
  }, [disabled, allStrategies, categories, handleExecute]);

  // ── Keyboard navigation (Arrow Up/Down) ──────────────────────────────────────

  const handlePanelKeyDown = useCallback((e) => {
    // Don't interfere when a param input or the search input is focused
    const tag = e.target.tagName.toLowerCase();
    if (tag === 'input' || tag === 'textarea') return;

    if (e.key !== 'ArrowDown' && e.key !== 'ArrowUp') return;

    e.preventDefault();

    const btns = Object.values(strategyBtnRefs.current).filter(Boolean);
    if (btns.length === 0) return;

    const currentIdx = btns.indexOf(document.activeElement);
    let nextIdx;
    if (e.key === 'ArrowDown') {
      nextIdx = currentIdx < btns.length - 1 ? currentIdx + 1 : 0;
    } else {
      nextIdx = currentIdx > 0 ? currentIdx - 1 : btns.length - 1;
    }
    btns[nextIdx].focus();
  }, []);

  // ── Search clear on Escape ────────────────────────────────────────────────────

  const handleSearchKeyDown = useCallback((e) => {
    if (e.key === 'Escape') {
      setSearchQuery('');
      e.preventDefault();
    }
  }, []);

  // ── Render ────────────────────────────────────────────────────────────────────

  return (
    <>
      <style>{PANEL_STYLES}</style>

      <div
        onKeyDown={handlePanelKeyDown}
        style={{
          display: 'flex',
          flexDirection: 'column',
          height: '100%',
          backgroundColor: THEME.card,
          fontFamily: FONT_BASE,
        }}
      >
        {/* Search input */}
        {showSearch && (
          <div style={{
            padding: '10px 10px 6px',
            borderBottom: `1px solid ${THEME.border}`,
          }}>
            <div style={{ position: 'relative' }}>
              <div style={{
                position: 'absolute',
                left: 9,
                top: '50%',
                transform: 'translateY(-50%)',
                pointerEvents: 'none',
              }}>
                <EuiIcon type="search" size="s" color={THEME.textMuted} />
              </div>
              <input
                ref={searchRef}
                type="text"
                placeholder="Search strategies…"
                value={searchQuery}
                onChange={e => setSearchQuery(e.target.value)}
                onKeyDown={handleSearchKeyDown}
                style={{
                  width: '100%',
                  padding: '6px 28px 6px 30px',
                  backgroundColor: THEME.bg,
                  border: `1px solid ${THEME.border}`,
                  borderRadius: 5,
                  color: THEME.text,
                  fontSize: 12,
                  fontFamily: FONT_BASE,
                  outline: 'none',
                  boxSizing: 'border-box',
                  transition: `border-color ${DURATION_FAST}`,
                }}
                onFocus={e => {
                  e.target.style.borderColor = THEME.accent;
                  e.target.style.boxShadow = `0 0 0 1px ${THEME.accent}`;
                }}
                onBlur={e => {
                  e.target.style.borderColor = THEME.border;
                  e.target.style.boxShadow = 'none';
                }}
              />
              {/* Clear button */}
              {searchQuery && (
                <button
                  onClick={() => setSearchQuery('')}
                  style={{
                    position: 'absolute',
                    right: 6,
                    top: '50%',
                    transform: 'translateY(-50%)',
                    background: 'none',
                    border: 'none',
                    cursor: 'pointer',
                    padding: 2,
                    display: 'flex',
                    alignItems: 'center',
                    color: THEME.textMuted,
                  }}
                  title="Clear search"
                >
                  <EuiIcon type="cross" size="s" color={THEME.textMuted} />
                </button>
              )}
            </div>
            {/* Match count */}
            {searchQuery && (
              <div style={{
                marginTop: 4,
                fontSize: 10,
                color: THEME.textMuted,
                fontFamily: FONT_BASE,
                paddingLeft: 2,
              }}>
                {totalMatches} {totalMatches === 1 ? 'match' : 'matches'}
              </div>
            )}
          </div>
        )}

        {/* Recently used */}
        {!searchQuery && storageKeyProp && recentLabels.length > 0 && (
          <div style={{
            padding: '8px 10px 6px',
            borderBottom: `1px solid ${THEME.border}`,
          }}>
            <div style={{
              fontSize: 10,
              fontWeight: 600,
              color: THEME.textMuted,
              textTransform: 'uppercase',
              letterSpacing: '0.5px',
              marginBottom: 6,
              fontFamily: FONT_BASE,
            }}>
              Recently Used
            </div>
            <div style={{ display: 'flex', flexWrap: 'wrap', gap: 4 }}>
              {recentLabels.map(label => (
                <button
                  key={label}
                  onClick={() => handleRecentClick(label)}
                  disabled={disabled}
                  title={allStrategies[label]?.query || label}
                  style={{
                    fontSize: 11,
                    fontWeight: 500,
                    padding: '3px 9px',
                    borderRadius: 12,
                    border: `1px solid ${THEME.border}`,
                    backgroundColor: THEME.bg,
                    color: THEME.textSecondary,
                    cursor: disabled ? 'not-allowed' : 'pointer',
                    fontFamily: FONT_BASE,
                    transition: `all ${DURATION_FAST}`,
                    opacity: disabled ? 0.5 : 1,
                  }}
                  onMouseEnter={e => {
                    if (!disabled) {
                      e.currentTarget.style.backgroundColor = HOVER_ACTIVE;
                      e.currentTarget.style.borderColor = THEME.accent;
                      e.currentTarget.style.color = THEME.text;
                    }
                  }}
                  onMouseLeave={e => {
                    e.currentTarget.style.backgroundColor = THEME.bg;
                    e.currentTarget.style.borderColor = THEME.border;
                    e.currentTarget.style.color = THEME.textSecondary;
                  }}
                >
                  {label}
                </button>
              ))}
            </div>
          </div>
        )}

        {/* Category list */}
        <div style={{
          flex: 1,
          overflowY: 'auto',
          padding: '6px 4px',
        }}>
          {filteredCategories.map((cat) => (
            <CategorySection
              key={cat.name}
              category={cat}
              isExpanded={!!expandedCategories[cat.name]}
              onToggle={() => handleCategoryToggle(cat.name)}
              visibleStrategies={cat.filtered}
              expandedStrategyLabel={expandedStrategyLabel}
              onExecute={handleExecute}
              disabled={disabled}
              isLoading={isLoading}
              onStrategyToggle={handleStrategyToggle}
              onParamRun={handleParamRun}
              onParamCancel={handleParamCancel}
              strategyBtnRefs={strategyBtnRefs}
              isDark={isDark}
            />
          ))}

          {/* Empty state when searching */}
          {searchQuery && totalMatches === 0 && (
            <div style={{
              padding: '24px 12px',
              textAlign: 'center',
              color: THEME.textMuted,
              fontSize: 12,
              fontFamily: FONT_BASE,
            }}>
              No strategies match "{searchQuery}"
            </div>
          )}
        </div>
      </div>
    </>
  );
}

export default StrategyPanel;
