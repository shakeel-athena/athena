import React from 'react';
import ReactDOM from 'react-dom/client';
import { ReactKeycloakProvider } from '@react-keycloak/web';
import { EuiProvider } from '@elastic/eui';
import keycloak, { keycloakInitOptions } from './config/keycloak';
import App from './App';

// Loading screen while Keycloak initializes
const LoadingScreen = () => (
  <div style={{
    height: '100vh',
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#0D1117',
    color: '#8e9fbc',
    fontFamily: 'Inter, -apple-system, sans-serif',
    gap: 16,
  }}>
    <div style={{
      width: 24, height: 24, border: '2px solid #2A2B33',
      borderTopColor: '#16c5c0', borderRadius: '50%',
      animation: 'spin 0.8s linear infinite',
    }} />
    <span style={{ fontSize: 13 }}>Initializing Pallas AI...</span>
    <style>{`@keyframes spin { to { transform: rotate(360deg); } }`}</style>
  </div>
);

// Store token for pallasService to use
const onTokens = (tokens) => {
  if (tokens.token) {
    sessionStorage.setItem('keycloak_token', tokens.token);
  }
};

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
  <ReactKeycloakProvider
    authClient={keycloak}
    initOptions={keycloakInitOptions}
    LoadingComponent={<LoadingScreen />}
    onTokens={onTokens}
  >
    <EuiProvider colorMode="dark">
      <App />
    </EuiProvider>
  </ReactKeycloakProvider>
);
